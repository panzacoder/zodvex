import { model as model000 } from './models/model000'
import { model as model001 } from './models/model001'
import { model as model002 } from './models/model002'
import { model as model003 } from './models/model003'
import { model as model004 } from './models/model004'
import { model as model005 } from './models/model005'
import { model as model006 } from './models/model006'
import { model as model007 } from './models/model007'
import { model as model008 } from './models/model008'
import { model as model009 } from './models/model009'
import { model as model010 } from './models/model010'
import { model as model011 } from './models/model011'
import { model as model012 } from './models/model012'
import { model as model013 } from './models/model013'
import { model as model014 } from './models/model014'
import { model as model015 } from './models/model015'
import { model as model016 } from './models/model016'
export const registry = { model000, model001, model002, model003, model004, model005, model006, model007, model008, model009, model010, model011, model012, model013, model014, model015, model016 }
export function load(table: string) {
  const model = registry[table as keyof typeof registry]
  if (!model) throw new Error('Unknown table key')
  return model
}
export function retainedChecksum() {
  return Object.entries(registry).reduce((sum, [name, model]) => sum + name.length + Object.keys(model.schema.insert.shape).length, 0)
}
