/* eslint-disable */
/**
 * Generated `api` utility.
 *
 * THIS CODE IS AUTOMATICALLY GENERATED.
 *
 * To regenerate, run `npx convex dev`.
 * @module
 */

import type * as canary from "../canary.js";
import type * as dynamic from "../dynamic.js";
import type * as dynamicRegistry from "../dynamicRegistry.js";
import type * as helpers from "../helpers.js";
import type * as models_model000 from "../models/model000.js";
import type * as models_model001 from "../models/model001.js";
import type * as models_model002 from "../models/model002.js";
import type * as models_model003 from "../models/model003.js";
import type * as models_model004 from "../models/model004.js";
import type * as models_model005 from "../models/model005.js";
import type * as models_model006 from "../models/model006.js";
import type * as models_model007 from "../models/model007.js";
import type * as models_model008 from "../models/model008.js";
import type * as models_model009 from "../models/model009.js";
import type * as models_model010 from "../models/model010.js";
import type * as models_model011 from "../models/model011.js";
import type * as models_model012 from "../models/model012.js";
import type * as models_model013 from "../models/model013.js";
import type * as models_model014 from "../models/model014.js";
import type * as models_model015 from "../models/model015.js";
import type * as models_model016 from "../models/model016.js";
import type * as shared_observation from "../shared/observation.js";
import type * as shared_operation from "../shared/operation.js";
import type * as shared_result from "../shared/result.js";
import type * as shared_shape from "../shared/shape.js";
import type * as static_ from "../static.js";
import type * as staticRegistry from "../staticRegistry.js";

import type {
  ApiFromModules,
  FilterApi,
  FunctionReference,
} from "convex/server";

declare const fullApi: ApiFromModules<{
  canary: typeof canary;
  dynamic: typeof dynamic;
  dynamicRegistry: typeof dynamicRegistry;
  helpers: typeof helpers;
  "models/model000": typeof models_model000;
  "models/model001": typeof models_model001;
  "models/model002": typeof models_model002;
  "models/model003": typeof models_model003;
  "models/model004": typeof models_model004;
  "models/model005": typeof models_model005;
  "models/model006": typeof models_model006;
  "models/model007": typeof models_model007;
  "models/model008": typeof models_model008;
  "models/model009": typeof models_model009;
  "models/model010": typeof models_model010;
  "models/model011": typeof models_model011;
  "models/model012": typeof models_model012;
  "models/model013": typeof models_model013;
  "models/model014": typeof models_model014;
  "models/model015": typeof models_model015;
  "models/model016": typeof models_model016;
  "shared/observation": typeof shared_observation;
  "shared/operation": typeof shared_operation;
  "shared/result": typeof shared_result;
  "shared/shape": typeof shared_shape;
  static: typeof static_;
  staticRegistry: typeof staticRegistry;
}>;

/**
 * A utility for referencing Convex functions in your app's public API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = api.myModule.myFunction;
 * ```
 */
export declare const api: FilterApi<
  typeof fullApi,
  FunctionReference<any, "public">
>;

/**
 * A utility for referencing Convex functions in your app's internal API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = internal.myModule.myFunction;
 * ```
 */
export declare const internal: FilterApi<
  typeof fullApi,
  FunctionReference<any, "internal">
>;

export declare const components: {};
