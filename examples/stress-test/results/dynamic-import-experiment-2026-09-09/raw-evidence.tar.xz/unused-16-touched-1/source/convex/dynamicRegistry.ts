const loaders: Record<string, () => Promise<unknown>> = {
  'model000': () => import('./models/model000'),
  'model001': () => import('./models/model001'),
  'model002': () => import('./models/model002'),
  'model003': () => import('./models/model003'),
  'model004': () => import('./models/model004'),
  'model005': () => import('./models/model005'),
  'model006': () => import('./models/model006'),
  'model007': () => import('./models/model007'),
  'model008': () => import('./models/model008'),
  'model009': () => import('./models/model009'),
  'model010': () => import('./models/model010'),
  'model011': () => import('./models/model011'),
  'model012': () => import('./models/model012'),
  'model013': () => import('./models/model013'),
  'model014': () => import('./models/model014'),
  'model015': () => import('./models/model015'),
  'model016': () => import('./models/model016'),
}
export async function load(table: string) {
  const loader = loaders[table]
  if (!loader) throw new Error('Unknown table key')
  return (await loader() as typeof import('./models/model000')).model
}
export function retainedChecksum() { return Object.keys(loaders).reduce((sum, name) => sum + name.length, 0) }
