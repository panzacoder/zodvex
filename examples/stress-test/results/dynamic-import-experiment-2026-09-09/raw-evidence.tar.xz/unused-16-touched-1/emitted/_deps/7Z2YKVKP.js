import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model010.ts
m("model-init:model010");
var l = o("model010", e(32));

export {
  l as a
};
//# sourceMappingURL=7Z2YKVKP.js.map
