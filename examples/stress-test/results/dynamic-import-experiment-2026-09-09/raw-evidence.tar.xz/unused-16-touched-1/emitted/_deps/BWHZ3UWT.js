import {
  a as u
} from "./V4JDGLX5.js";
import {
  a as y
} from "./5PXKOPYO.js";
import {
  a as g
} from "./3KKBOPCO.js";
import {
  a as k
} from "./BEY6CV7L.js";
import {
  a as b
} from "./TXG2FVAL.js";
import {
  a as s
} from "./LMWUKZAL.js";
import {
  a as i
} from "./GYUTJ3XM.js";
import {
  a
} from "./VSKNOBMU.js";
import {
  a as f
} from "./CM7PCYUA.js";
import {
  a as p
} from "./JDYY7C4Q.js";
import {
  a as n
} from "./IQ5EA24B.js";
import {
  a as c
} from "./7Z2YKVKP.js";
import {
  a as h
} from "./QNUBZY2S.js";
import {
  a as r
} from "./BZ3CEX4W.js";
import {
  a as l
} from "./ZJW33SAG.js";
import {
  a as t
} from "./O3FQPIRV.js";
import {
  a as d
} from "./GZGXZGJY.js";
import {
  a as e
} from "./5B5TEMMX.js";

// convex/staticRegistry.ts
var w = { model000: r, model001: l, model002: t, model003: d, model004: s, model005: i, model006: a, model007: f, model008: p, model009: n, model010: c, model011: h, model012: u, model013: y, model014: g, model015: k, model016: b };
function L(m) {
  let o = w[m];
  if (!o) throw new Error("Unknown table key");
  return o;
}
e(L, "load");
function M() {
  return Object.entries(w).reduce((m, [o, x]) => m + o.length + Object.keys(x.schema.insert.shape).length, 0);
}
e(M, "retainedChecksum");

export {
  w as a,
  L as b,
  M as c
};
//# sourceMappingURL=BWHZ3UWT.js.map
