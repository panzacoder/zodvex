import {
  a as o
} from "./5B5TEMMX.js";

// convex/dynamicRegistry.ts
var r = {
  model000: /* @__PURE__ */ o(() => import("../models/model000.js"), "model000"),
  model001: /* @__PURE__ */ o(() => import("../models/model001.js"), "model001"),
  model002: /* @__PURE__ */ o(() => import("../models/model002.js"), "model002"),
  model003: /* @__PURE__ */ o(() => import("../models/model003.js"), "model003"),
  model004: /* @__PURE__ */ o(() => import("../models/model004.js"), "model004"),
  model005: /* @__PURE__ */ o(() => import("../models/model005.js"), "model005"),
  model006: /* @__PURE__ */ o(() => import("../models/model006.js"), "model006"),
  model007: /* @__PURE__ */ o(() => import("../models/model007.js"), "model007"),
  model008: /* @__PURE__ */ o(() => import("../models/model008.js"), "model008"),
  model009: /* @__PURE__ */ o(() => import("../models/model009.js"), "model009"),
  model010: /* @__PURE__ */ o(() => import("../models/model010.js"), "model010"),
  model011: /* @__PURE__ */ o(() => import("../models/model011.js"), "model011"),
  model012: /* @__PURE__ */ o(() => import("../models/model012.js"), "model012"),
  model013: /* @__PURE__ */ o(() => import("../models/model013.js"), "model013"),
  model014: /* @__PURE__ */ o(() => import("../models/model014.js"), "model014"),
  model015: /* @__PURE__ */ o(() => import("../models/model015.js"), "model015"),
  model016: /* @__PURE__ */ o(() => import("../models/model016.js"), "model016")
};
async function t(m) {
  let e = r[m];
  if (!e) throw new Error("Unknown table key");
  return (await e()).model;
}
o(t, "load");
function d() {
  return Object.keys(r).reduce((m, e) => m + e.length, 0);
}
o(d, "retainedChecksum");

export {
  t as a,
  d as b
};
//# sourceMappingURL=X6JUJAL5.js.map
