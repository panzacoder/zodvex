import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model002.ts
m("model-init:model002");
var l = o("model002", e(32));

export {
  l as a
};
//# sourceMappingURL=O3FQPIRV.js.map
