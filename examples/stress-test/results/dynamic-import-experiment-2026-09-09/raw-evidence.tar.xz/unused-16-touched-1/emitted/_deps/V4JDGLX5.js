import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model012.ts
m("model-init:model012");
var l = o("model012", e(32));

export {
  l as a
};
//# sourceMappingURL=V4JDGLX5.js.map
