import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model011.ts
m("model-init:model011");
var l = o("model011", e(32));

export {
  l as a
};
//# sourceMappingURL=QNUBZY2S.js.map
