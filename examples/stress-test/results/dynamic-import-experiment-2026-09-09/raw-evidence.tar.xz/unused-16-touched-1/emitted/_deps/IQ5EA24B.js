import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model009.ts
m("model-init:model009");
var l = o("model009", e(32));

export {
  l as a
};
//# sourceMappingURL=IQ5EA24B.js.map
