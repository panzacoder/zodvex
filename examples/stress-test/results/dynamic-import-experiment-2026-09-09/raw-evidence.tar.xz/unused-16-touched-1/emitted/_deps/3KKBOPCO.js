import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model014.ts
m("model-init:model014");
var l = o("model014", e(32));

export {
  l as a
};
//# sourceMappingURL=3KKBOPCO.js.map
