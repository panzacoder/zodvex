import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model004.ts
m("model-init:model004");
var l = o("model004", e(32));

export {
  l as a
};
//# sourceMappingURL=LMWUKZAL.js.map
