import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model006.ts
m("model-init:model006");
var l = o("model006", e(32));

export {
  l as a
};
//# sourceMappingURL=VSKNOBMU.js.map
