import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model015.ts
m("model-init:model015");
var l = o("model015", e(32));

export {
  l as a
};
//# sourceMappingURL=BEY6CV7L.js.map
