import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model003.ts
m("model-init:model003");
var l = o("model003", e(32));

export {
  l as a
};
//# sourceMappingURL=GZGXZGJY.js.map
