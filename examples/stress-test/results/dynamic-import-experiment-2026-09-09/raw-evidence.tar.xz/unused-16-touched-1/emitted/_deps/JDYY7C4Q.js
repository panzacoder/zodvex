import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model008.ts
m("model-init:model008");
var l = o("model008", e(32));

export {
  l as a
};
//# sourceMappingURL=JDYY7C4Q.js.map
