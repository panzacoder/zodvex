import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model001.ts
m("model-init:model001");
var l = o("model001", e(32));

export {
  l as a
};
//# sourceMappingURL=ZJW33SAG.js.map
