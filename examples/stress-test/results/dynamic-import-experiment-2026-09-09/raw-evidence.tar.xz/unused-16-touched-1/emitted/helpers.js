import {
  a as xe
} from "./_deps/AQJ3QLJ2.js";
import {
  c as Ce
} from "./_deps/VNSRRA4A.js";
import {
  c as R
} from "./_deps/EYM35JYW.js";
import {
  a as ge,
  b as S
} from "./_deps/KY4JIOXG.js";
import {
  A as ie,
  B as se,
  C as ce,
  D as ue,
  E as fe,
  F as T,
  G as ae,
  H as le,
  I as de,
  J as E,
  K as pe,
  L as me,
  M as be,
  N as ye,
  O as ke,
  P as ze,
  Q as we,
  R as F,
  S as i,
  U as he,
  d as Z,
  e as U,
  f as B,
  g as L,
  h as q,
  i as M,
  j as D,
  k as J,
  l as Q,
  m as W,
  n as G,
  o as K,
  p as H,
  q as X,
  r as _,
  s as Y,
  u as v,
  v as ee,
  w as ne,
  x as te,
  y as re,
  z as oe
} from "./_deps/WWZ3L44K.js";
import {
  g as P,
  h as n,
  i as V
} from "./_deps/W3VG7GIX.js";
import {
  a as s
} from "./_deps/5B5TEMMX.js";

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/convex-helpers@0.1.113+b9ed8f5244cf7f28/node_modules/convex-helpers/index.js
function j(e, r) {
  return Object.fromEntries(Object.entries(e).filter(([t]) => r.includes(t)));
}
s(j, "pick");
var Ue = Symbol();

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/convex-helpers@0.1.113+b9ed8f5244cf7f28/node_modules/convex-helpers/validators.js
var Je = n.string(), Qe = n.float64(), We = n.float64(), Ge = n.boolean(), Ke = n.int64(), He = n.int64(), Xe = n.any(), Ye = n.null(), { id: ve, object: en, array: nn, bytes: tn, literal: rn, optional: on, union: sn } = n, cn = n.bytes();
function $(e, r) {
  let t = P(e);
  if (Object.keys(r).length === 0)
    return t;
  switch (t.kind) {
    case "object":
      return n.object(Se(t.fields, r));
    case "union":
      return n.union(...t.members.map((o) => $(o, r)));
    default:
      throw new Error("Cannot add arguments to a validator that is not an object or union.");
  }
}
s($, "addFieldsToValidator");
function Se(e, r) {
  let t = { ...e };
  for (let [o, c] of Object.entries(r)) {
    let u = t[o];
    if (u) {
      if (u.kind !== c.kind)
        throw new Error(`Cannot intersect validators with different kinds: ${u.kind} and ${c.kind}`);
      u.isOptional !== c.isOptional && u.isOptional === "optional" && (t[o] = c);
    } else
      t[o] = c;
  }
  return t;
}
s(Se, "intersectValidators");
var un = n.optional(n.any());
function h(e) {
  let { kind: r, isOptional: t } = e;
  if (t === "required")
    return e;
  switch (r) {
    case "id":
      return n.id(e.tableName);
    case "string":
      return n.string();
    case "float64":
      return n.float64();
    case "int64":
      return n.int64();
    case "boolean":
      return n.boolean();
    case "null":
      return n.null();
    case "any":
      return n.any();
    case "literal":
      return n.literal(e.value);
    case "bytes":
      return n.bytes();
    case "object":
      return n.object(e.fields);
    case "array":
      return n.array(e.element);
    case "record":
      return n.record(e.key, e.value);
    case "union":
      return n.union(...e.members);
    default:
      throw new Error("Unknown Convex validator type: " + r);
  }
}
s(h, "vRequired");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/convex-helpers@0.1.113+b9ed8f5244cf7f28/node_modules/convex-helpers/server/customFunctions.js
var g = {
  args: {},
  input() {
    return { args: {}, ctx: {} };
  }
};

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/convex-helpers@0.1.113+b9ed8f5244cf7f28/node_modules/convex-helpers/server/zod4.js
function $e(e, r) {
  return Pe(e, r);
}
s($e, "zCustomAction");
function Ne(e) {
  let r = /* @__PURE__ */ new WeakSet();
  function t(o) {
    if (r.has(o))
      return n.any();
    r.add(o);
    let c = o instanceof T ? n.optional(t(o._zod.def.innerType)) : o instanceof E ? t(o._zod.def.in) : Oe(o, t);
    return r.delete(o), c;
  }
  return s(t, "zodToConvexInner"), t(e);
}
s(Ne, "zodToConvex");
function Ae(e) {
  let r = /* @__PURE__ */ new WeakSet();
  function t(o) {
    if (r.has(o))
      return n.any();
    r.add(o);
    let c = o instanceof T ? t(o._zod.def.innerType) : o instanceof E ? t(o._zod.def.out) : o instanceof ce ? n.any() : Oe(o, t);
    return r.delete(o), c;
  }
  return s(t, "zodOutputToConvexInner"), t(e);
}
s(Ae, "zodOutputToConvex");
function Ie(e) {
  return Object.fromEntries(Object.entries(e).map(([r, t]) => [r, Ne(t)]));
}
s(Ie, "zodToConvexFields");
function Pe(e, r) {
  let t = r.input ?? g.input, o = r.args ?? g.args;
  return /* @__PURE__ */ s(function(u) {
    let { args: d, handler: y = u, skipConvexValidation: k = !1, returns: l, ...x } = u, p = l && !(l instanceof Z) ? F(l) : l, N = p && !k ? { returns: Ae(p) } : null;
    if (d) {
      let f = d;
      if (f instanceof Z)
        if (f instanceof _)
          f = f._zod.def.shape;
        else
          throw new Error("Unsupported zod type as args validator: " + f.constructor.name);
      let z = Ie(f);
      return e({
        args: k ? void 0 : $(z, o),
        ...N,
        handler: /* @__PURE__ */ s(async (a, C) => {
          let m = await t(a, j(C, Object.keys(o)), x), w = j(C, Object.keys(f)), b = await F(f).safeParseAsync(w);
          if (!b.success)
            throw new V({
              ZodError: JSON.parse(JSON.stringify(b.error.issues, null, 2))
            });
          let A = b.data, Ee = { ...a, ...m.ctx }, Fe = { ...A, ...m.args }, O = await y(Ee, Fe), I = p ? await p.parseAsync(O === void 0 ? null : O) : O;
          return m.onSuccess && await m.onSuccess({ ctx: a, args: A, result: I }), I;
        }, "handler")
      });
    }
    if (k && Object.keys(o).length > 0)
      throw new Error("If you're using a custom function with arguments for the input customization, you cannot skip convex validation.");
    return e({
      ...N,
      handler: /* @__PURE__ */ s(async (f, z) => {
        let a = await t(f, z, x), C = { ...f, ...a.ctx }, m = { ...z, ...a.args }, w = await y(C, m), b = p ? await p.parseAsync(w === void 0 ? null : w) : w;
        return a.onSuccess && await a.onSuccess({ ctx: f, args: z, result: b }), b;
      }, "handler")
    });
  }, "customBuilder");
}
s(Pe, "customFnBuilder");
function Oe(e, r) {
  if (e instanceof U)
    return n.string();
  if (e instanceof B || e instanceof de)
    return n.number();
  if (e instanceof q)
    return n.int64();
  if (e instanceof L)
    return n.boolean();
  if (e instanceof J)
    return n.null();
  if (e instanceof Q || e instanceof W)
    return n.any();
  if (e instanceof X) {
    let t = r(e._zod.def.element);
    if (t.isOptional === "optional")
      throw new Error("Arrays of optional values are not supported");
    return n.array(t);
  }
  if (e instanceof _)
    return n.object(Object.fromEntries(Object.entries(e._zod.def.shape).map(([t, o]) => [
      t,
      r(o)
    ])));
  if (e instanceof Y)
    return n.union(...e._zod.def.options.map(r));
  if (e instanceof G)
    return n.union();
  if (e instanceof ee) {
    let { items: t, rest: o } = e._zod.def;
    return n.array(n.union(...[
      ...t,
      // + rest if set
      ...o !== null ? [o] : []
    ].map(r)));
  }
  if (e instanceof ie) {
    let { values: t } = e._zod.def;
    return t.length === 1 ? je(t[0]) : n.union(...t.map(je));
  }
  if (e instanceof oe)
    return n.union(...Object.entries(e._zod.def.entries).filter(([t, o]) => t === o || isNaN(Number(t))).map(([t, o]) => n.literal(o)));
  if (e instanceof ue)
    return n.optional(r(e._zod.def.innerType));
  if (e instanceof ae)
    return h(r(e._zod.def.innerType));
  if (e instanceof fe) {
    let t = r(e._zod.def.innerType);
    return t.isOptional === "optional" ? n.optional(n.union(h(t), n.null())) : n.union(t, n.null());
  }
  if (e instanceof ne) {
    let { keyType: t, valueType: o } = e._zod.def, c = t._zod.values === void 0, u = r(o), d = r(t), y = Ze(d);
    if (y !== null) {
      let k = c || u.isOptional === "optional" ? n.optional(u) : h(u), l = {};
      for (let x of y)
        l[x] = k;
      return n.object(l);
    }
    return n.record(_e(d) ? d : n.string(), h(u));
  }
  if (e instanceof pe)
    return r(e._zod.def.innerType);
  if (e instanceof ke)
    return r(e._zod.def.getter());
  if (e instanceof me)
    return n.string();
  if (e instanceof ze) {
    let t = Ve.get(e);
    return t !== void 0 && typeof t.tableName == "string" ? n.id(t.tableName) : n.any();
  }
  if (e instanceof v)
    return n.any();
  if (e instanceof le)
    return r(e._zod.def.innerType);
  if (e instanceof H || e instanceof M || e instanceof te || e instanceof re || e instanceof ye || e instanceof se || e instanceof be || e instanceof K || e instanceof D)
    throw new Error(`Validator ${e.constructor.name} is not supported in Convex`);
  return n.any();
}
s(Oe, "zodToConvexCommon");
function je(e) {
  if (e === void 0)
    throw new Error("undefined is not a valid Convex value");
  return e === null ? n.null() : n.literal(e);
}
s(je, "convexToZodLiteral");
function Ze(e) {
  if (e.kind === "literal") {
    let r = e;
    return typeof r.value == "string" ? [r.value] : null;
  }
  if (e.kind === "union") {
    let r = e, t = [];
    for (let o of r.members) {
      let c = Ze(o);
      if (c === null)
        return null;
      t.push(...c);
    }
    return t;
  }
  return null;
}
s(Ze, "extractStringLiterals");
function _e(e) {
  return e.kind === "string" || e.kind === "id" ? !0 : e.kind === "union" ? e.members.every(_e) : !1;
}
s(_e, "isValidRecordKey");
var Ve = we();

// convex/helpers.ts
ge("helper-init:probe");
var Te = i.object(he(32)), Re = $e(R, g), Jn = Re({
  args: { nonce: i.string(), tables: i.array(i.string()), gc: i.boolean() },
  returns: i.object({
    nonce: i.string(),
    before: i.array(i.string()),
    after: i.array(i.string()),
    touched: i.array(i.string()),
    registryChecksum: i.number(),
    liveFields: i.number(),
    results: i.array(i.object({
      date: i.number(),
      secret: i.string(),
      nestedDate: i.number(),
      nestedSecret: i.string(),
      arrayNumber: i.number(),
      roundTrip: i.boolean(),
      invalidInputRejected: i.boolean(),
      invalidUnionRejected: i.boolean(),
      invalidOutputRejected: i.boolean(),
      wireValidInvalidInputRejected: i.boolean()
    }))
  }),
  handler: /* @__PURE__ */ s(async (e, r) => {
    if (r.tables.length !== 1 || r.tables[0] !== "model000") throw new Error("Only the required helper schema is available");
    let t = S(), o = [xe(Te, 32, i.parse, i.encode)];
    return Ce(r.gc), {
      nonce: r.nonce,
      before: t,
      after: S(),
      touched: r.tables,
      registryChecksum: 0,
      liveFields: Object.keys(Te.shape).length,
      results: o
    };
  }, "handler")
});
export {
  Jn as probe
};
//# sourceMappingURL=helpers.js.map
