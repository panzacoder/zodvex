import {
  a,
  b
} from "./_deps/X6JUJAL5.js";
import "./_deps/5B5TEMMX.js";
export {
  a as load,
  b as retainedChecksum
};
//# sourceMappingURL=dynamicRegistry.js.map
