const initialized: string[] = []
export function recordModuleInit(marker: string) { initialized.push(marker) }
export function initializedModules() { return [...initialized].sort() }
