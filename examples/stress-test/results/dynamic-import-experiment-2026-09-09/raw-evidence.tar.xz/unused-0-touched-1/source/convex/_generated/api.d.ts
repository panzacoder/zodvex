/* eslint-disable */
/**
 * Generated `api` utility.
 *
 * THIS CODE IS AUTOMATICALLY GENERATED.
 *
 * To regenerate, run `npx convex dev`.
 * @module
 */

import type * as canary from "../canary.js";
import type * as dynamic from "../dynamic.js";
import type * as dynamicRegistry from "../dynamicRegistry.js";
import type * as helpers from "../helpers.js";
import type * as models_model000 from "../models/model000.js";
import type * as shared_observation from "../shared/observation.js";
import type * as shared_operation from "../shared/operation.js";
import type * as shared_result from "../shared/result.js";
import type * as shared_shape from "../shared/shape.js";
import type * as static_ from "../static.js";
import type * as staticRegistry from "../staticRegistry.js";

import type {
  ApiFromModules,
  FilterApi,
  FunctionReference,
} from "convex/server";

declare const fullApi: ApiFromModules<{
  canary: typeof canary;
  dynamic: typeof dynamic;
  dynamicRegistry: typeof dynamicRegistry;
  helpers: typeof helpers;
  "models/model000": typeof models_model000;
  "shared/observation": typeof shared_observation;
  "shared/operation": typeof shared_operation;
  "shared/result": typeof shared_result;
  "shared/shape": typeof shared_shape;
  static: typeof static_;
  staticRegistry: typeof staticRegistry;
}>;

/**
 * A utility for referencing Convex functions in your app's public API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = api.myModule.myFunction;
 * ```
 */
export declare const api: FilterApi<
  typeof fullApi,
  FunctionReference<any, "public">
>;

/**
 * A utility for referencing Convex functions in your app's internal API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = internal.myModule.myFunction;
 * ```
 */
export declare const internal: FilterApi<
  typeof fullApi,
  FunctionReference<any, "internal">
>;

export declare const components: {};
