import { action, query, mutation } from './_generated/server'
import { decodeDoc, encodeDoc } from 'zodvex'
import { load, retainedChecksum } from './dynamicRegistry'
import { exercise } from './shared/operation'
import { initializedModules } from './shared/observation'
import { resultValidator, argsValidator, forceGc } from './shared/result'
async function handler(_ctx: unknown, args: { nonce: string; tables: string[]; gc: boolean }) {
  if (args.tables.length < 1 || args.tables.length > 8 || new Set(args.tables).size !== args.tables.length)
    throw new Error('Invalid bounded table selection')
  const before = initializedModules()
  const loaded = []
  const results = []
  for (const table of args.tables) {
    const model = await load(table)
    loaded.push(model)
    results.push(exercise(model.schema.insert, 32, decodeDoc, encodeDoc))
  }
  forceGc(args.gc)
  return { nonce: args.nonce, before, after: initializedModules(), touched: args.tables,
    registryChecksum: retainedChecksum(), liveFields: loaded.reduce((sum, model) => sum + Object.keys(model.schema.insert.shape).length, 0), results }
}
export const probe = action({ args: argsValidator, returns: resultValidator, handler })
export const queryProbe = query({ args: argsValidator, returns: resultValidator, handler })
export const mutationProbe = mutation({ args: argsValidator, returns: resultValidator, handler })
