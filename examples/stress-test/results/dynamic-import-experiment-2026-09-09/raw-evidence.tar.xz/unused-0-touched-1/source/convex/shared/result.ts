import { v } from 'convex/values'
export const resultValidator = v.object({
  nonce: v.string(), before: v.array(v.string()), after: v.array(v.string()),
  touched: v.array(v.string()), registryChecksum: v.number(), liveFields: v.number(),
  results: v.array(v.object({ date: v.number(), secret: v.string(), nestedDate: v.number(),
    nestedSecret: v.string(), arrayNumber: v.number(), roundTrip: v.boolean(),
    invalidInputRejected: v.boolean(), invalidUnionRejected: v.boolean(), invalidOutputRejected: v.boolean(), wireValidInvalidInputRejected: v.boolean() })),
})
export const argsValidator = { nonce: v.string(), tables: v.array(v.string()), gc: v.boolean() }
export function forceGc(enabled: boolean) {
  if (!enabled) return
  const gc = (globalThis as { gc?: () => void }).gc
  if (!gc) throw new Error('GC diagnostic unavailable')
  gc(); gc()
}
