import { model as model000 } from './models/model000'
export const registry = { model000 }
export function load(table: string) {
  const model = registry[table as keyof typeof registry]
  if (!model) throw new Error('Unknown table key')
  return model
}
export function retainedChecksum() {
  return Object.entries(registry).reduce((sum, [name, model]) => sum + name.length + Object.keys(model.schema.insert.shape).length, 0)
}
