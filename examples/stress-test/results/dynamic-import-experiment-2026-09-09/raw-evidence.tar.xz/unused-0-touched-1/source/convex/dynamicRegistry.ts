const loaders: Record<string, () => Promise<unknown>> = {
  'model000': () => import('./models/model000'),
}
export async function load(table: string) {
  const loader = loaders[table]
  if (!loader) throw new Error('Unknown table key')
  return (await loader() as typeof import('./models/model000')).model
}
export function retainedChecksum() { return Object.keys(loaders).reduce((sum, name) => sum + name.length, 0) }
