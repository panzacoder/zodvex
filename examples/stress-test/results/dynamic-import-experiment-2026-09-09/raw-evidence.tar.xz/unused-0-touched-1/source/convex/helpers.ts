import { z } from 'zod'
import { zCustomAction } from 'convex-helpers/server/zod4'
import { NoOp } from 'convex-helpers/server/customFunctions'
import { action } from './_generated/server'
import { makeFields } from './shared/shape'
import { exercise } from './shared/operation'
import { initializedModules, recordModuleInit } from './shared/observation'
import { forceGc } from './shared/result'
recordModuleInit('helper-init:probe')
const schema = z.object(makeFields(32))
const helperAction = zCustomAction(action, NoOp)
export const probe = helperAction({
  args: { nonce: z.string(), tables: z.array(z.string()), gc: z.boolean() },
  returns: z.object({ nonce: z.string(), before: z.array(z.string()), after: z.array(z.string()),
    touched: z.array(z.string()), registryChecksum: z.number(), liveFields: z.number(),
    results: z.array(z.object({ date: z.number(), secret: z.string(), nestedDate: z.number(),
      nestedSecret: z.string(), arrayNumber: z.number(), roundTrip: z.boolean(),
      invalidInputRejected: z.boolean(), invalidUnionRejected: z.boolean(), invalidOutputRejected: z.boolean(), wireValidInvalidInputRejected: z.boolean() })) }),
  handler: async (_ctx, args) => {
    if (args.tables.length !== 1 || args.tables[0] !== 'model000') throw new Error('Only the required helper schema is available')
    const before = initializedModules()
    const results = [exercise(schema, 32, z.parse, z.encode)]
    forceGc(args.gc)
    return { nonce: args.nonce, before, after: initializedModules(), touched: args.tables,
      registryChecksum: 0, liveFields: Object.keys(schema.shape).length, results }
  },
})
