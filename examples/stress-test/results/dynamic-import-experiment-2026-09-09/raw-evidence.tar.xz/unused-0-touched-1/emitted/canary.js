import {
  a as r
} from "./_deps/EYM35JYW.js";
import {
  h as n
} from "./_deps/W3VG7GIX.js";
import {
  a as e
} from "./_deps/5B5TEMMX.js";

// convex/canary.ts
var d = r({
  args: { nonce: n.string() },
  returns: n.object({ nonce: n.string(), unused: n.number(), touched: n.number(), width: n.number() }),
  handler: /* @__PURE__ */ e((t, o) => ({ nonce: o.nonce, unused: 0, touched: 1, width: 32 }), "handler")
});
export {
  d as ready
};
//# sourceMappingURL=canary.js.map
