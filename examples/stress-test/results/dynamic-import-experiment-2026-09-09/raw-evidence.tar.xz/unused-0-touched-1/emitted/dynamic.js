import {
  a as f,
  b as p
} from "./_deps/JBMPIAK5.js";
import {
  a as u,
  b as d,
  c as m
} from "./_deps/EYM35JYW.js";
import {
  a as b,
  b as h
} from "./_deps/IKXYHD27.js";
import {
  b as s
} from "./_deps/KY4JIOXG.js";
import {
  a as g
} from "./_deps/AQJ3QLJ2.js";
import "./_deps/WWZ3L44K.js";
import {
  a as o,
  b as r,
  c as w
} from "./_deps/VNSRRA4A.js";
import "./_deps/W3VG7GIX.js";
import {
  a
} from "./_deps/5B5TEMMX.js";

// convex/dynamic.ts
async function c(y, e) {
  if (e.tables.length < 1 || e.tables.length > 8 || new Set(e.tables).size !== e.tables.length)
    throw new Error("Invalid bounded table selection");
  let x = s(), i = [], l = [];
  for (let n of e.tables) {
    let t = await f(n);
    i.push(t), l.push(g(t.schema.insert, 32, b, h));
  }
  return w(e.gc), {
    nonce: e.nonce,
    before: x,
    after: s(),
    touched: e.tables,
    registryChecksum: p(),
    liveFields: i.reduce((n, t) => n + Object.keys(t.schema.insert.shape).length, 0),
    results: l
  };
}
a(c, "handler");
var P = m({ args: r, returns: o, handler: c }), V = u({ args: r, returns: o, handler: c }), j = d({ args: r, returns: o, handler: c });
export {
  j as mutationProbe,
  P as probe,
  V as queryProbe
};
//# sourceMappingURL=dynamic.js.map
