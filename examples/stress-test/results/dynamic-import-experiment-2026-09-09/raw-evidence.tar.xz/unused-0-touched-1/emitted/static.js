import {
  b as g,
  c as w
} from "./_deps/SHPSD72D.js";
import {
  a as u,
  b as d,
  c as m
} from "./_deps/EYM35JYW.js";
import "./_deps/BZ3CEX4W.js";
import {
  a as b,
  b as h
} from "./_deps/IKXYHD27.js";
import {
  b as s
} from "./_deps/KY4JIOXG.js";
import {
  a as f
} from "./_deps/AQJ3QLJ2.js";
import "./_deps/WWZ3L44K.js";
import {
  a as o,
  b as r,
  c as p
} from "./_deps/VNSRRA4A.js";
import "./_deps/W3VG7GIX.js";
import {
  a
} from "./_deps/5B5TEMMX.js";

// convex/static.ts
async function c(y, e) {
  if (e.tables.length < 1 || e.tables.length > 8 || new Set(e.tables).size !== e.tables.length)
    throw new Error("Invalid bounded table selection");
  let x = s(), i = [], l = [];
  for (let n of e.tables) {
    let t = await g(n);
    i.push(t), l.push(f(t.schema.insert, 32, b, h));
  }
  return p(e.gc), {
    nonce: e.nonce,
    before: x,
    after: s(),
    touched: e.tables,
    registryChecksum: w(),
    liveFields: i.reduce((n, t) => n + Object.keys(t.schema.insert.shape).length, 0),
    results: l
  };
}
a(c, "handler");
var P = m({ args: r, returns: o, handler: c }), V = u({ args: r, returns: o, handler: c }), j = d({ args: r, returns: o, handler: c });
export {
  j as mutationProbe,
  P as probe,
  V as queryProbe
};
//# sourceMappingURL=static.js.map
