import {
  a
} from "../_deps/AQJ3QLJ2.js";
import "../_deps/WWZ3L44K.js";
import "../_deps/5B5TEMMX.js";
export {
  a as exercise
};
//# sourceMappingURL=operation.js.map
