import {
  a,
  b
} from "../_deps/KY4JIOXG.js";
import "../_deps/5B5TEMMX.js";
export {
  b as initializedModules,
  a as recordModuleInit
};
//# sourceMappingURL=observation.js.map
