import {
  a,
  b,
  c
} from "./_deps/SHPSD72D.js";
import "./_deps/BZ3CEX4W.js";
import "./_deps/IKXYHD27.js";
import "./_deps/KY4JIOXG.js";
import "./_deps/WWZ3L44K.js";
import "./_deps/W3VG7GIX.js";
import "./_deps/5B5TEMMX.js";
export {
  b as load,
  a as registry,
  c as retainedChecksum
};
//# sourceMappingURL=staticRegistry.js.map
