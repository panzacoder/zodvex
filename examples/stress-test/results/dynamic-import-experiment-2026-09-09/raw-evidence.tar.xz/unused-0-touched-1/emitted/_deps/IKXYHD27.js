import {
  D as z,
  E as D,
  S as o,
  a as m,
  b as j,
  c as x,
  d as h,
  r as y,
  s as _,
  t as O
} from "./WWZ3L44K.js";
import {
  a as i
} from "./5B5TEMMX.js";

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/packages/zodvex/dist/index.js
function w(e) {
  if (e == null)
    return e;
  if (Array.isArray(e))
    return e.map(w);
  if (typeof e == "object" && e.constructor === Object) {
    let n = {};
    for (let [t, r] of Object.entries(e))
      r !== void 0 && (n[t] = w(r));
    return n;
  }
  return e;
}
i(w, "stripUndefined");
var C = /* @__PURE__ */ new WeakMap(), P = {
  getMetadata: /* @__PURE__ */ i((e) => C.get(e), "getMetadata"),
  setMetadata: /* @__PURE__ */ i((e, n) => C.set(e, n), "setMetadata")
};
var ue = o.discriminatedUnion("success", [
  o.object({ success: o.literal(!0) }),
  o.object({ success: o.literal(!1), error: o.string() })
]), fe = o.object({
  formErrors: o.array(o.string()),
  fieldErrors: o.record(o.string(), o.array(o.string()))
});
function de(e, n) {
  return j(e, n);
}
i(de, "decodeDoc");
function le(e, n) {
  return w(x(e, n));
}
i(le, "encodeDoc");
var U = "__zodvexMeta";
function S(e, n) {
  Object.defineProperty(e, U, {
    value: n,
    enumerable: !1,
    writable: !1,
    configurable: !1
  });
}
i(S, "attachMeta");
function k(e) {
  let n = o.string().check(
    o.refine((r) => typeof r == "string" && r.length > 0, {
      message: `Invalid ID for table "${e}"`
    }),
    o.describe(`convexId:${e}`)
  );
  P.setMetadata(n, {
    isConvexId: !0,
    tableName: e
  });
  let t = n;
  return t._tableName = e, t;
}
i(k, "id");
function Z(e) {
  return e instanceof _ || e instanceof O;
}
i(Z, "isZodUnion");
function E(e) {
  return e instanceof _, e._zod.def.options;
}
i(E, "getUnionOptions");
function F(e) {
  if (e.length < 2)
    throw new Error(
      `z.union() requires at least 2 options, but received ${e.length}. This indicates an invalid union schema was passed to zodTable().`
    );
}
i(F, "assertUnionOptions");
function M(e) {
  return F(e), o.union(e);
}
i(M, "createUnionFromOptions");
function N(e, n) {
  if (Z(n)) {
    let r = E(n).map((a) => {
      if (a instanceof y) {
        let c = {
          ...a._zod.def.shape,
          _id: k(e),
          _creationTime: o.number()
        };
        return m(a, { ...a._zod.def, shape: c });
      }
      return a;
    });
    return M(r);
  }
  if (n instanceof y) {
    let t = { ...n._zod.def.shape, _id: k(e), _creationTime: o.number() };
    return m(n, { ...n._zod.def, shape: t });
  }
  return n;
}
i(N, "addSystemFields");
function V(e) {
  return e instanceof z ? e : new z({ type: "optional", innerType: e });
}
i(V, "ensureOptional");
function A(e) {
  return new z({
    type: "optional",
    innerType: new D({ type: "nullable", innerType: e })
  });
}
i(A, "nullableOptional2");
function W(e) {
  let n = {};
  for (let [t, r] of Object.entries(e))
    n[t] = V(r);
  return n;
}
i(W, "createPartialShape");
function T(e, n) {
  return o.object({
    _id: k(e),
    _creationTime: o.optional(o.number()),
    ...W(n)
  });
}
i(T, "createUpdateObjectSchema");
function B(e) {
  return o.object({
    page: o.array(e),
    isDone: o.boolean(),
    continueCursor: o.string(),
    splitCursor: A(o.string()),
    pageStatus: A(o.enum(["SplitRecommended", "SplitRequired"]))
  });
}
i(B, "createPaginatedDocSchema");
function I(e, n, t = o.object(n)) {
  let r = N(e, t);
  return {
    doc: r,
    base: t,
    insert: t,
    update: T(e, n),
    docArray: o.array(r),
    paginatedDoc: B(r)
  };
}
i(I, "createObjectSchemaBundle");
function J(e, n) {
  if (Z(n)) {
    let t = E(n).map((r) => r instanceof y ? T(e, r._zod.def.shape) : r);
    return M(t);
  }
  return n instanceof y ? T(e, n._zod.def.shape) : n;
}
i(J, "createSchemaUpdateSchema");
function K(e, n) {
  let t = N(e, n);
  return {
    doc: t,
    base: n,
    insert: n,
    update: J(e, n),
    docArray: o.array(t),
    paginatedDoc: B(t)
  };
}
i(K, "createSchemaBundle");
function R(e, n) {
  let t;
  return {
    get: /* @__PURE__ */ i(() => t || (t = n ?? o.object(e), t), "get")
  };
}
i(R, "lazyValidator");
function b(e, n, t, r, a = {}, c = {}, u = {}, d = null) {
  let l = R(n, d), f = {
    name: e,
    fields: n,
    schema: t,
    indexes: a,
    searchIndexes: c,
    vectorIndexes: u,
    get validator() {
      return l.get();
    },
    index(s, p) {
      return b(
        e,
        n,
        t,
        r,
        { ...a, [s]: [...p, "_creationTime"] },
        c,
        u,
        d
      );
    },
    searchIndex(s, p) {
      return b(
        e,
        n,
        t,
        r,
        a,
        { ...c, [s]: p },
        u,
        d
      );
    },
    vectorIndex(s, p) {
      return b(
        e,
        n,
        t,
        r,
        a,
        c,
        { ...u, [s]: p },
        d
      );
    }
  };
  return S(f, { type: "model", tableName: e, definitionSource: r, schemas: t }), f;
}
i(b, "createModel");
function g(e, n, t, r, a = {}, c = {}, u = {}) {
  let d = R(n, t), l = {
    name: e,
    fields: n,
    indexes: a,
    searchIndexes: c,
    vectorIndexes: u,
    get validator() {
      return d.get();
    },
    index(f, s) {
      return g(
        e,
        n,
        t,
        r,
        { ...a, [f]: [...s, "_creationTime"] },
        c,
        u
      );
    },
    searchIndex(f, s) {
      return g(
        e,
        n,
        t,
        r,
        a,
        { ...c, [f]: s },
        u
      );
    },
    vectorIndex(f, s) {
      return g(e, n, t, r, a, c, {
        ...u,
        [f]: s
      });
    }
  };
  return t !== null && (l.schema = t), S(l, { type: "model", tableName: e, definitionSource: r }), l;
}
i(g, "createSlimModel");
function $(e, n, t) {
  let r = t?.schemaHelpers === !1;
  if (n instanceof h)
    return r ? g(e, {}, n, "schema") : b(
      e,
      {},
      K(e, n),
      "schema",
      void 0,
      void 0,
      void 0,
      n
    );
  let a = n;
  return r ? g(e, a, null, "shape") : b(e, a, I(e, a), "shape");
}
i($, "defineZodModel");
function pe(e, n, t) {
  return n instanceof h, $(e, n, t);
}
i(pe, "defineZodModel2");
function v(e) {
  let n = /* @__PURE__ */ Symbol.for(`zodvex.zx.cache.${e}`), t = globalThis, r = t[n];
  if (r) return r;
  let a = /* @__PURE__ */ new WeakMap();
  return t[n] = a, a;
}
i(v, "sharedWeakMap");
var ye = v("base"), be = v("doc"), ge = v("update"), ze = v("docArray");

export {
  de as a,
  le as b,
  pe as c
};
//# sourceMappingURL=IKXYHD27.js.map
