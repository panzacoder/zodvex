import {
  a as o
} from "./5B5TEMMX.js";

// convex/dynamicRegistry.ts
var r = {
  model000: /* @__PURE__ */ o(() => import("../models/model000.js"), "model000")
};
async function t(n) {
  let e = r[n];
  if (!e) throw new Error("Unknown table key");
  return (await e()).model;
}
o(t, "load");
function s() {
  return Object.keys(r).reduce((n, e) => n + e.length, 0);
}
o(s, "retainedChecksum");

export {
  t as a,
  s as b
};
//# sourceMappingURL=JBMPIAK5.js.map
