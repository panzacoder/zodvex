import {
  a as i
} from "./5B5TEMMX.js";

// convex/shared/observation.ts
var t = [];
function o(n) {
  t.push(n);
}
i(o, "recordModuleInit");
function r() {
  return [...t].sort();
}
i(r, "initializedModules");

export {
  o as a,
  r as b
};
//# sourceMappingURL=KY4JIOXG.js.map
