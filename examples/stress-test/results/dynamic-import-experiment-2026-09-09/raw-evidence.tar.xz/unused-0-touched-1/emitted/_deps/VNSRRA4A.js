import {
  h as e
} from "./W3VG7GIX.js";
import {
  a as n
} from "./5B5TEMMX.js";

// convex/shared/result.ts
var o = e.object({
  nonce: e.string(),
  before: e.array(e.string()),
  after: e.array(e.string()),
  touched: e.array(e.string()),
  registryChecksum: e.number(),
  liveFields: e.number(),
  results: e.array(e.object({
    date: e.number(),
    secret: e.string(),
    nestedDate: e.number(),
    nestedSecret: e.string(),
    arrayNumber: e.number(),
    roundTrip: e.boolean(),
    invalidInputRejected: e.boolean(),
    invalidUnionRejected: e.boolean(),
    invalidOutputRejected: e.boolean(),
    wireValidInvalidInputRejected: e.boolean()
  }))
}), i = { nonce: e.string(), tables: e.array(e.string()), gc: e.boolean() };
function s(t) {
  if (!t) return;
  let r = globalThis.gc;
  if (!r) throw new Error("GC diagnostic unavailable");
  r(), r();
}
n(s, "forceGc");

export {
  o as a,
  i as b,
  s as c
};
//# sourceMappingURL=VNSRRA4A.js.map
