import {
  a as n
} from "./BZ3CEX4W.js";
import {
  a as r
} from "./5B5TEMMX.js";

// convex/staticRegistry.ts
var o = { model000: n };
function c(t) {
  let e = o[t];
  if (!e) throw new Error("Unknown table key");
  return e;
}
r(c, "load");
function a() {
  return Object.entries(o).reduce((t, [e, s]) => t + e.length + Object.keys(s.schema.insert.shape).length, 0);
}
r(a, "retainedChecksum");

export {
  o as a,
  c as b,
  a as c
};
//# sourceMappingURL=SHPSD72D.js.map
