import {
  a as u,
  b as he
} from "./5B5TEMMX.js";

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/external.js
var W = {};
he(W, {
  $brand: () => Li,
  $input: () => pc,
  $output: () => fc,
  NEVER: () => Ci,
  TimePrecision: () => Ic,
  ZodAny: () => ll,
  ZodArray: () => pl,
  ZodBase64: () => fi,
  ZodBase64URL: () => pi,
  ZodBigInt: () => jt,
  ZodBigIntFormat: () => $i,
  ZodBoolean: () => St,
  ZodCIDRv4: () => di,
  ZodCIDRv6: () => mi,
  ZodCUID: () => ii,
  ZodCUID2: () => oi,
  ZodCatch: () => Zl,
  ZodCodec: () => yr,
  ZodCompileAsyncError: () => me,
  ZodCompileUnsupportedError: () => U,
  ZodCreditCard: () => nl,
  ZodCustom: () => br,
  ZodCustomStringFormat: () => wt,
  ZodDate: () => pr,
  ZodDefault: () => Pl,
  ZodDiscriminatedUnion: () => vl,
  ZodE164: () => gi,
  ZodEmail: () => ei,
  ZodEmoji: () => ri,
  ZodEnum: () => xt,
  ZodError: () => T$,
  ZodExactOptional: () => bi,
  ZodFile: () => wl,
  ZodFirstPartyTypeKind: () => Bl,
  ZodFunction: () => Kl,
  ZodGUID: () => ti,
  ZodIPv4: () => si,
  ZodIPv6: () => li,
  ZodISODate: () => Oe,
  ZodISODateTime: () => De,
  ZodISODuration: () => Ne,
  ZodISOTime: () => Ue,
  ZodIntersection: () => $l,
  ZodIssueCode: () => E$,
  ZodJWT: () => vi,
  ZodKSUID: () => ci,
  ZodLazy: () => Fl,
  ZodLiteral: () => Il,
  ZodMAC: () => rl,
  ZodMap: () => kl,
  ZodNaN: () => El,
  ZodNanoID: () => ni,
  ZodNever: () => ml,
  ZodNonOptional: () => ki,
  ZodNull: () => cl,
  ZodNullable: () => jl,
  ZodNumber: () => zt,
  ZodNumberFormat: () => qe,
  ZodObject: () => vr,
  ZodOptional: () => hr,
  ZodPipe: () => _r,
  ZodPrefault: () => Ol,
  ZodPreprocess: () => Cl,
  ZodPromise: () => Ml,
  ZodReadonly: () => Ll,
  ZodRealError: () => ie,
  ZodRecord: () => kt,
  ZodSet: () => xl,
  ZodString: () => It,
  ZodStringFormat: () => C,
  ZodSuccess: () => Tl,
  ZodSymbol: () => al,
  ZodTemplateLiteral: () => Rl,
  ZodTransform: () => zl,
  ZodTuple: () => _l,
  ZodType: () => D,
  ZodULID: () => ai,
  ZodURL: () => fr,
  ZodUUID: () => $e,
  ZodUndefined: () => ul,
  ZodUnion: () => $r,
  ZodUnknown: () => dl,
  ZodVoid: () => fl,
  ZodXID: () => ui,
  ZodXor: () => gl,
  _ZodString: () => Qn,
  _default: () => Dl,
  _function: () => cf,
  any: () => Cm,
  array: () => gr,
  base64: () => ym,
  base64url: () => bm,
  bigint: () => Nm,
  boolean: () => ol,
  catch: () => Al,
  check: () => sf,
  cidrv4: () => hm,
  cidrv6: () => _m,
  clone: () => T,
  codec: () => nf,
  coerce: () => ql,
  compile: () => hc,
  config: () => M,
  core: () => ye,
  creditCard: () => xm,
  cuid: () => lm,
  cuid2: () => dm,
  custom: () => lf,
  date: () => Vm,
  decode: () => qs,
  decodeAsync: () => Ys,
  deepPartial: () => kf,
  describe: () => df,
  discriminatedUnion: () => Wm,
  e164: () => km,
  email: () => em,
  emoji: () => cm,
  encode: () => Bs,
  encodeAsync: () => Xs,
  endsWith: () => ft,
  enum: () => _i,
  exactOptional: () => Sl,
  file: () => Qm,
  flattenError: () => Rt,
  float32: () => Pm,
  float64: () => Dm,
  formatError: () => Ft,
  fromJSONSchema: () => yf,
  function: () => cf,
  getDiscriminatedOption: () => Ta,
  getErrorMap: () => L$,
  globalRegistry: () => B,
  gt: () => ge,
  gte: () => ce,
  guid: () => tm,
  hash: () => jm,
  hex: () => Sm,
  hostname: () => zm,
  httpUrl: () => um,
  includes: () => dt,
  input: () => If,
  instanceof: () => ff,
  int: () => Yn,
  int32: () => Om,
  int64: () => Tm,
  intersection: () => hl,
  invertCodec: () => of,
  ipv4: () => gm,
  ipv6: () => $m,
  iso: () => kr,
  json: () => gf,
  jwt: () => Im,
  keyof: () => Rm,
  ksuid: () => pm,
  lazy: () => Jl,
  length: () => Ke,
  literal: () => Hm,
  locales: () => nr,
  looseObject: () => Mm,
  looseRecord: () => Bm,
  lowercase: () => st,
  lt: () => pe,
  lte: () => ue,
  mac: () => vm,
  map: () => qm,
  maxLength: () => Me,
  maxSize: () => ze,
  memoizer: () => Ht,
  meta: () => mf,
  mime: () => pt,
  minLength: () => _e,
  minSize: () => ve,
  multipleOf: () => we,
  nan: () => rf,
  nanoid: () => sm,
  nativeEnum: () => Ym,
  negative: () => Ln,
  never: () => hi,
  nonnegative: () => Rn,
  nonoptional: () => Nl,
  nonpositive: () => Vn,
  normalize: () => gt,
  null: () => sl,
  nullable: () => mr,
  nullish: () => ef,
  number: () => il,
  object: () => Fm,
  optional: () => Ge,
  output: () => wf,
  overwrite: () => fe,
  parse: () => Ms,
  parseAsync: () => Ks,
  partialRecord: () => Gm,
  pipe: () => Hn,
  positive: () => Cn,
  prefault: () => Ul,
  preprocess: () => vf,
  prettifyError: () => Mi,
  promise: () => uf,
  properties: () => Jn,
  property: () => Fn,
  readonly: () => Vl,
  record: () => bl,
  refine: () => Wl,
  regex: () => ct,
  regexes: () => X,
  registry: () => gn,
  safeDecode: () => Qs,
  safeDecodeAsync: () => tl,
  safeEncode: () => Hs,
  safeEncodeAsync: () => el,
  safeParse: () => Ws,
  safeParseAsync: () => Gs,
  set: () => Xm,
  setErrorMap: () => C$,
  size: () => Je,
  slugify: () => _t,
  startsWith: () => mt,
  strictObject: () => Jm,
  string: () => dr,
  stringFormat: () => wm,
  stringbool: () => pf,
  success: () => tf,
  superRefine: () => Gl,
  symbol: () => Am,
  templateLiteral: () => af,
  toJSONSchema: () => Gn,
  toLowerCase: () => $t,
  toUpperCase: () => ht,
  toZod: () => Ut,
  transform: () => yi,
  treeifyError: () => Ji,
  trim: () => vt,
  tuple: () => yl,
  uint32: () => Um,
  uint64: () => Zm,
  ulid: () => mm,
  undefined: () => Em,
  union: () => Pt,
  unknown: () => We,
  uppercase: () => lt,
  url: () => am,
  util: () => y,
  uuid: () => rm,
  uuidv4: () => nm,
  uuidv6: () => im,
  uuidv7: () => om,
  validate: () => Gi,
  validateAsync: () => Bi,
  void: () => Lm,
  xid: () => fm,
  xor: () => Km
});

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/index.js
var ye = {};
he(ye, {
  $ZodAny: () => za,
  $ZodArray: () => Oa,
  $ZodAsyncError: () => re,
  $ZodBase64: () => ga,
  $ZodBase64URL: () => va,
  $ZodBigInt: () => an,
  $ZodBigIntFormat: () => ka,
  $ZodBoolean: () => Bt,
  $ZodCIDRv4: () => fa,
  $ZodCIDRv6: () => pa,
  $ZodCUID: () => ta,
  $ZodCUID2: () => ra,
  $ZodCatch: () => Xa,
  $ZodCheck: () => L,
  $ZodCheckBigIntFormat: () => Do,
  $ZodCheckEndsWith: () => Fo,
  $ZodCheckGreaterThan: () => Jr,
  $ZodCheckIncludes: () => Vo,
  $ZodCheckLengthEquals: () => Ao,
  $ZodCheckLessThan: () => Fr,
  $ZodCheckLowerCase: () => Co,
  $ZodCheckMaxLength: () => To,
  $ZodCheckMaxSize: () => Oo,
  $ZodCheckMimeType: () => Jo,
  $ZodCheckMinLength: () => Zo,
  $ZodCheckMinSize: () => Uo,
  $ZodCheckMultipleOf: () => jo,
  $ZodCheckNumberFormat: () => Po,
  $ZodCheckOverwrite: () => Mo,
  $ZodCheckProperty: () => Mr,
  $ZodCheckRegex: () => Eo,
  $ZodCheckSizeEquals: () => No,
  $ZodCheckStartsWith: () => Ro,
  $ZodCheckStringFormat: () => ot,
  $ZodCheckUpperCase: () => Lo,
  $ZodCodec: () => Xt,
  $ZodCreditCard: () => ha,
  $ZodCustom: () => nu,
  $ZodCustomStringFormat: () => ya,
  $ZodCyclicError: () => mn,
  $ZodDate: () => Da,
  $ZodDefault: () => Wa,
  $ZodDiscriminatedUnion: () => Za,
  $ZodE164: () => $a,
  $ZodEmail: () => qo,
  $ZodEmoji: () => Qo,
  $ZodEncodeError: () => xe,
  $ZodEnum: () => Va,
  $ZodError: () => Vt,
  $ZodExactOptional: () => Ma,
  $ZodFile: () => Fa,
  $ZodFunction: () => tu,
  $ZodGUID: () => Go,
  $ZodIPv4: () => la,
  $ZodIPv6: () => da,
  $ZodISODate: () => ua,
  $ZodISODateTime: () => aa,
  $ZodISODuration: () => sa,
  $ZodISOTime: () => ca,
  $ZodIntersection: () => Aa,
  $ZodJWT: () => _a,
  $ZodKSUID: () => oa,
  $ZodLazy: () => Yt,
  $ZodLiteral: () => Ra,
  $ZodMAC: () => ma,
  $ZodMap: () => Ca,
  $ZodNaN: () => Ya,
  $ZodNanoID: () => ea,
  $ZodNever: () => ja,
  $ZodNonOptional: () => Ba,
  $ZodNull: () => wa,
  $ZodNullable: () => Ka,
  $ZodNumber: () => on,
  $ZodNumberFormat: () => ba,
  $ZodObject: () => Pd,
  $ZodObjectJIT: () => Ua,
  $ZodOptional: () => cn,
  $ZodPipe: () => sn,
  $ZodPrefault: () => Ga,
  $ZodPreprocess: () => Ha,
  $ZodPromise: () => ru,
  $ZodReadonly: () => Qa,
  $ZodRealError: () => ne,
  $ZodRecord: () => Ea,
  $ZodRegistry: () => pn,
  $ZodSet: () => La,
  $ZodString: () => Ce,
  $ZodStringFormat: () => E,
  $ZodSuccess: () => qa,
  $ZodSymbol: () => xa,
  $ZodTemplateLiteral: () => eu,
  $ZodTransform: () => Ja,
  $ZodTuple: () => un,
  $ZodType: () => j,
  $ZodULID: () => na,
  $ZodURL: () => Ho,
  $ZodUUID: () => Bo,
  $ZodUndefined: () => Ia,
  $ZodUnion: () => qt,
  $ZodUnknown: () => Sa,
  $ZodVoid: () => Pa,
  $ZodXID: () => ia,
  $ZodXor: () => Na,
  $brand: () => Li,
  $constructor: () => f,
  $input: () => pc,
  $output: () => fc,
  Doc: () => Ee,
  INVALID: () => ae,
  JSONSchema: () => Yd,
  JSONSchemaGenerator: () => Bn,
  NEVER: () => Ci,
  TimePrecision: () => Ic,
  URL_BAD_FORMAT: () => Xo,
  URL_UNPARSEABLE: () => Yo,
  ZodCompileAsyncError: () => me,
  ZodCompileUnsupportedError: () => U,
  _any: () => Rc,
  _array: () => Bc,
  _base64: () => Tn,
  _base64url: () => Zn,
  _bigint: () => Tc,
  _boolean: () => Uc,
  _catch: () => I$,
  _check: () => Md,
  _cidrv4: () => Un,
  _cidrv6: () => Nn,
  _coercedBigint: () => Zc,
  _coercedBoolean: () => Nc,
  _coercedDate: () => Wc,
  _coercedNumber: () => zc,
  _coercedString: () => bc,
  _creditCard: () => xc,
  _cuid: () => wn,
  _cuid2: () => zn,
  _custom: () => Xc,
  _date: () => Kc,
  _decode: () => Ur,
  _decodeAsync: () => Tr,
  _default: () => b$,
  _discriminatedUnion: () => s$,
  _e164: () => An,
  _email: () => $n,
  _emoji: () => xn,
  _encode: () => Or,
  _encodeAsync: () => Nr,
  _endsWith: () => ft,
  _enum: () => g$,
  _file: () => qc,
  _float32: () => jc,
  _float64: () => Pc,
  _gt: () => ge,
  _gte: () => ce,
  _guid: () => hn,
  _includes: () => dt,
  _int: () => Sc,
  _int32: () => Dc,
  _int64: () => Ac,
  _intersection: () => l$,
  _ipv4: () => Dn,
  _ipv6: () => On,
  _isoDate: () => ar,
  _isoDateTime: () => or,
  _isoDuration: () => cr,
  _isoTime: () => ur,
  _jwt: () => En,
  _ksuid: () => Pn,
  _lazy: () => j$,
  _length: () => Ke,
  _literal: () => $$,
  _lowercase: () => st,
  _lt: () => pe,
  _lte: () => ue,
  _mac: () => kc,
  _map: () => f$,
  _max: () => ue,
  _maxLength: () => Me,
  _maxSize: () => ze,
  _mime: () => pt,
  _min: () => ce,
  _minLength: () => _e,
  _minSize: () => ve,
  _multipleOf: () => we,
  _nan: () => Gc,
  _nanoid: () => In,
  _nativeEnum: () => v$,
  _negative: () => Ln,
  _never: () => Jc,
  _nonnegative: () => Rn,
  _nonoptional: () => k$,
  _nonpositive: () => Vn,
  _normalize: () => gt,
  _null: () => Vc,
  _nullable: () => y$,
  _number: () => wc,
  _optional: () => _$,
  _overwrite: () => fe,
  _parse: () => tt,
  _parseAsync: () => rt,
  _pipe: () => w$,
  _positive: () => Cn,
  _promise: () => P$,
  _properties: () => Jn,
  _property: () => Fn,
  _readonly: () => z$,
  _record: () => m$,
  _refine: () => Yc,
  _regex: () => ct,
  _safeDecode: () => Ar,
  _safeDecodeAsync: () => Cr,
  _safeEncode: () => Zr,
  _safeEncodeAsync: () => Er,
  _safeParse: () => nt,
  _safeParseAsync: () => it,
  _set: () => p$,
  _size: () => Je,
  _slugify: () => _t,
  _startsWith: () => mt,
  _string: () => yc,
  _stringFormat: () => yt,
  _stringbool: () => ts,
  _success: () => x$,
  _superRefine: () => Hc,
  _symbol: () => Cc,
  _templateLiteral: () => S$,
  _toLowerCase: () => $t,
  _toUpperCase: () => ht,
  _transform: () => h$,
  _trim: () => vt,
  _tuple: () => d$,
  _uint32: () => Oc,
  _uint64: () => Ec,
  _ulid: () => Sn,
  _undefined: () => Lc,
  _union: () => u$,
  _unknown: () => Fc,
  _uppercase: () => lt,
  _url: () => ir,
  _uuid: () => _n,
  _uuidv4: () => yn,
  _uuidv6: () => bn,
  _uuidv7: () => kn,
  _void: () => Mc,
  _xid: () => jn,
  _xor: () => c$,
  clone: () => T,
  compile: () => hc,
  compileFn: () => vn,
  config: () => M,
  createStandardJSONSchemaMethod: () => bt,
  createToJSONSchemaMethod: () => ns,
  decode: () => pp,
  decodeAsync: () => vp,
  describe: () => Qc,
  encode: () => fp,
  encodeAsync: () => gp,
  extractDefs: () => je,
  finalize: () => Pe,
  flattenError: () => Rt,
  formatError: () => Ft,
  getDiscriminatedOption: () => Ta,
  globalConfig: () => G,
  globalRegistry: () => B,
  handleUnrepresentable: () => K,
  initializeContext: () => Se,
  isBackEdge: () => fn,
  isRecursiveSchema: () => uu,
  isValidBase64: () => Gt,
  isValidBase64URL: () => tn,
  isValidCIDRv6: () => en,
  isValidCreditCard: () => rn,
  isValidIPv6: () => Wt,
  isValidJWT: () => nn,
  locales: () => nr,
  memoizer: () => Ht,
  mergeValues: () => at,
  meta: () => es,
  parse: () => Pr,
  parseAsync: () => Dr,
  parseURLObject: () => Xr,
  prettifyError: () => Mi,
  process: () => Z,
  regexes: () => X,
  registry: () => gn,
  safeDecode: () => hp,
  safeDecodeAsync: () => yp,
  safeEncode: () => $p,
  safeEncodeAsync: () => _p,
  safeParse: () => Ki,
  safeParseAsync: () => Wi,
  standardProps: () => qr,
  stripTabAndNewline: () => Yr,
  toDotPath: () => ad,
  toJSONSchema: () => Gn,
  toZod: () => Ut,
  treeifyError: () => Ji,
  urlHostnameOk: () => Hr,
  urlProtocolOk: () => Qr,
  util: () => y,
  validate: () => Gi,
  validateAsync: () => Bi,
  version: () => Ko
});

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/util.js
var y = {};
he(y, {
  BIGINT_FORMAT_RANGES: () => Ui,
  CONSTANT_CATCH: () => Sr,
  Class: () => wi,
  NUMBER_FORMAT_RANGES: () => Oi,
  aborted: () => ke,
  allowsEval: () => ji,
  assert: () => Uf,
  assertEqual: () => jf,
  assertIs: () => Df,
  assertNever: () => Of,
  assertNotEqual: () => Pf,
  assignProp: () => J,
  attachSchema: () => zr,
  base64ToUint8Array: () => ed,
  base64urlToUint8Array: () => Xf,
  cached: () => Qe,
  captureStackTrace: () => wr,
  cleanEnum: () => qf,
  cleanRegex: () => Tt,
  clone: () => T,
  cloneDef: () => Tf,
  codePointLength: () => Ze,
  constantCatch: () => Ai,
  createTransparentProxy: () => Vf,
  defineLazy: () => zi,
  defineLazyInternal: () => O,
  esc: () => Q,
  escapeRegex: () => le,
  explicitlyAborted: () => Ni,
  extend: () => Jf,
  finalizeIssue: () => te,
  floatSafeRemainder: () => Zt,
  getElementAtPath: () => Zf,
  getEnumValues: () => Nt,
  getLengthableOrigin: () => Lt,
  getParsedType: () => Lf,
  getSizableOrigin: () => Ct,
  hexToUint8Array: () => Hf,
  hide: () => Zi,
  installLazyProp: () => np,
  isObject: () => Te,
  isPlainObject: () => se,
  issue: () => et,
  joinValues: () => p,
  jsonStringifyReplacer: () => He,
  members: () => Ti,
  merge: () => Kf,
  mergeDefs: () => de,
  normalizeParams: () => b,
  nullish: () => Ir,
  numKeys: () => Cf,
  objectClone: () => Nf,
  omit: () => Ff,
  optionalKeys: () => Di,
  own: () => Ye,
  parsedType: () => _,
  partial: () => Wf,
  pick: () => Rf,
  prefixIssues: () => ee,
  primitiveTypes: () => Pi,
  promiseAllObject: () => Af,
  propertyKeyTypes: () => Et,
  randomString: () => Ef,
  required: () => Gf,
  safeExtend: () => Mf,
  shallowClone: () => At,
  slugify: () => Si,
  stringifyPrimitive: () => h,
  toZod: () => Ut,
  uint8ArrayToBase64: () => td,
  uint8ArrayToBase64url: () => Yf,
  uint8ArrayToHex: () => Qf,
  unwrapMessage: () => Xe
});
function jf(e) {
  return e;
}
u(jf, "assertEqual");
function Pf(e) {
  return e;
}
u(Pf, "assertNotEqual");
function Ut() {
  return (e) => e;
}
u(Ut, "toZod");
function Df(e) {
}
u(Df, "assertIs");
function Of(e) {
  throw new Error("Unexpected value in exhaustive check");
}
u(Of, "assertNever");
function Uf(e) {
}
u(Uf, "assert");
function Nt(e) {
  let r = Object.values(e).filter((o) => typeof o == "number");
  return Object.entries(e).filter(([o, t]) => r.indexOf(+o) === -1).map(([o, t]) => t);
}
u(Nt, "getEnumValues");
function p(e, r = "|") {
  return e.map((i) => h(i)).join(r);
}
u(p, "joinValues");
function He(e, r) {
  return typeof r == "bigint" ? r.toString() : r;
}
u(He, "jsonStringifyReplacer");
function Qe(e) {
  return {
    get value() {
      {
        let i = e();
        return Object.defineProperty(this, "value", { value: i }), i;
      }
      throw new Error("cached value already set");
    }
  };
}
u(Qe, "cached");
function Ir(e) {
  return e == null;
}
u(Ir, "nullish");
function Tt(e) {
  let r = e.startsWith("^") ? 1 : 0, i = e.endsWith("$") ? e.length - 1 : e.length;
  return e.slice(r, i);
}
u(Tt, "cleanRegex");
function Zt(e, r) {
  let i = e / r, o = Math.round(i), t = 4 * Number.EPSILON * Math.max(Math.abs(i), 1);
  return Math.abs(i - o) < t ? 0 : i - o;
}
u(Zt, "floatSafeRemainder");
var Ql = /* @__PURE__ */ Symbol("evaluating");
function zi(e, r, i) {
  let o;
  Object.defineProperty(e, r, {
    get() {
      if (o !== Ql)
        return o === void 0 && (o = Ql, o = i()), o;
    },
    set(t) {
      Object.defineProperty(e, r, {
        value: t
        // configurable: true,
      });
    },
    configurable: !0
  });
}
u(zi, "defineLazy");
function Nf(e) {
  return Object.create(Object.getPrototypeOf(e), Object.getOwnPropertyDescriptors(e));
}
u(Nf, "objectClone");
function J(e, r, i) {
  Object.defineProperty(e, r, {
    value: i,
    writable: !0,
    enumerable: !0,
    configurable: !0
  });
}
u(J, "assignProp");
function de(...e) {
  let r = {};
  for (let i of e) {
    let o = Object.getOwnPropertyDescriptors(i);
    Object.assign(r, o);
  }
  return Object.defineProperties({}, r);
}
u(de, "mergeDefs");
function Tf(e) {
  return de(e._zod.def);
}
u(Tf, "cloneDef");
function Zf(e, r) {
  return r ? r.reduce((i, o) => i?.[o], e) : e;
}
u(Zf, "getElementAtPath");
function Af(e) {
  let r = Object.keys(e), i = r.map((o) => e[o]);
  return Promise.all(i).then((o) => {
    let t = {};
    for (let n = 0; n < r.length; n++)
      t[r[n]] = o[n];
    return t;
  });
}
u(Af, "promiseAllObject");
function Ef(e = 10) {
  let r = "abcdefghijklmnopqrstuvwxyz", i = "";
  for (let o = 0; o < e; o++)
    i += r[Math.floor(Math.random() * r.length)];
  return i;
}
u(Ef, "randomString");
function Q(e) {
  return JSON.stringify(e);
}
u(Q, "esc");
function Si(e) {
  return e.toLowerCase().trim().replace(/[^\w\s-]/g, "").replace(/[\s_-]+/g, "-").replace(/^-+|-+$/g, "");
}
u(Si, "slugify");
var wr = "captureStackTrace" in Error ? Error.captureStackTrace : (...e) => {
};
function Te(e) {
  return typeof e == "object" && e !== null && !Array.isArray(e);
}
u(Te, "isObject");
var ji = /* @__PURE__ */ Qe(() => {
  if (G.jitless || typeof navigator < "u" && navigator?.userAgent?.includes("Cloudflare"))
    return !1;
  try {
    let e = Function;
    return new e(""), !0;
  } catch {
    return !1;
  }
});
function se(e) {
  if (Te(e) === !1)
    return !1;
  let r = e.constructor;
  if (r === void 0 || typeof r != "function")
    return !0;
  let i = r.prototype;
  return !(Te(i) === !1 || Object.prototype.hasOwnProperty.call(i, "isPrototypeOf") === !1);
}
u(se, "isPlainObject");
function At(e) {
  return se(e) ? { ...e } : Array.isArray(e) ? [...e] : e instanceof Map ? new Map(e) : e instanceof Set ? new Set(e) : e;
}
u(At, "shallowClone");
function Cf(e) {
  let r = 0;
  for (let i in e)
    Object.prototype.hasOwnProperty.call(e, i) && r++;
  return r;
}
u(Cf, "numKeys");
var Lf = /* @__PURE__ */ u((e) => {
  let r = typeof e;
  switch (r) {
    case "undefined":
      return "undefined";
    case "string":
      return "string";
    case "number":
      return Number.isNaN(e) ? "nan" : "number";
    case "boolean":
      return "boolean";
    case "function":
      return "function";
    case "bigint":
      return "bigint";
    case "symbol":
      return "symbol";
    case "object":
      return Array.isArray(e) ? "array" : e === null ? "null" : e.then && typeof e.then == "function" && e.catch && typeof e.catch == "function" ? "promise" : typeof Map < "u" && e instanceof Map ? "map" : typeof Set < "u" && e instanceof Set ? "set" : typeof Date < "u" && e instanceof Date ? "date" : typeof File < "u" && e instanceof File ? "file" : "object";
    default:
      throw new Error(`Unknown data type: ${r}`);
  }
}, "getParsedType"), Et = /* @__PURE__ */ new Set(["string", "number", "symbol"]), Pi = /* @__PURE__ */ new Set([
  "string",
  "number",
  "bigint",
  "boolean",
  "symbol",
  "undefined"
]);
function le(e) {
  return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
u(le, "escapeRegex");
function T(e, r, i) {
  let o = new e._zod.constr(r ?? e._zod.def);
  return (!r || i?.parent) && (o._zod.parent = e), o;
}
u(T, "clone");
function b(e) {
  let r = e;
  if (!r)
    return {};
  if (typeof r == "string")
    return { error: /* @__PURE__ */ u(() => r, "error") };
  if (r?.message !== void 0) {
    if (r?.error !== void 0)
      throw new Error("Cannot specify both `message` and `error` params");
    r.error = r.message;
  }
  return delete r.message, typeof r.error == "string" ? { ...r, error: /* @__PURE__ */ u(() => r.error, "error") } : r;
}
u(b, "normalizeParams");
function Vf(e) {
  let r;
  return new Proxy({}, {
    get(i, o, t) {
      return r ?? (r = e()), Reflect.get(r, o, t);
    },
    set(i, o, t, n) {
      return r ?? (r = e()), Reflect.set(r, o, t, n);
    },
    has(i, o) {
      return r ?? (r = e()), Reflect.has(r, o);
    },
    deleteProperty(i, o) {
      return r ?? (r = e()), Reflect.deleteProperty(r, o);
    },
    ownKeys(i) {
      return r ?? (r = e()), Reflect.ownKeys(r);
    },
    getOwnPropertyDescriptor(i, o) {
      return r ?? (r = e()), Reflect.getOwnPropertyDescriptor(r, o);
    },
    defineProperty(i, o, t) {
      return r ?? (r = e()), Reflect.defineProperty(r, o, t);
    }
  });
}
u(Vf, "createTransparentProxy");
function h(e) {
  return typeof e == "bigint" ? e.toString() + "n" : typeof e == "string" ? `"${e}"` : `${e}`;
}
u(h, "stringifyPrimitive");
function Di(e) {
  return Object.keys(e).filter((r) => e[r]._zod.optin !== void 0 && e[r]._zod.optout === "optional");
}
u(Di, "optionalKeys");
var Oi = {
  safeint: [Number.MIN_SAFE_INTEGER, Number.MAX_SAFE_INTEGER],
  int32: [-2147483648, 2147483647],
  uint32: [0, 4294967295],
  float32: [-34028234663852886e22, 34028234663852886e22],
  float64: [-Number.MAX_VALUE, Number.MAX_VALUE]
}, Ui = {
  int64: [/* @__PURE__ */ BigInt("-9223372036854775808"), /* @__PURE__ */ BigInt("9223372036854775807")],
  uint64: [/* @__PURE__ */ BigInt(0), /* @__PURE__ */ BigInt("18446744073709551615")]
};
function Rf(e, r) {
  let i = e._zod.def, o = i.checks;
  if (o && o.length > 0)
    throw new Error(".pick() cannot be used on object schemas containing refinements");
  let n = de(e._zod.def, {
    get shape() {
      let a = {};
      for (let c of Reflect.ownKeys(r)) {
        if (!Object.prototype.hasOwnProperty.call(i.shape, c))
          throw new Error(`Unrecognized key: "${String(c)}"`);
        r[c] && J(a, c, i.shape[c]);
      }
      return J(this, "shape", a), a;
    },
    checks: []
  });
  return T(e, n);
}
u(Rf, "pick");
function Ff(e, r) {
  let i = e._zod.def, o = i.checks;
  if (o && o.length > 0)
    throw new Error(".omit() cannot be used on object schemas containing refinements");
  let n = de(e._zod.def, {
    get shape() {
      let a = { ...e._zod.def.shape };
      for (let c of Reflect.ownKeys(r)) {
        if (!Object.prototype.hasOwnProperty.call(i.shape, c))
          throw new Error(`Unrecognized key: "${String(c)}"`);
        r[c] && delete a[c];
      }
      return J(this, "shape", a), a;
    },
    checks: []
  });
  return T(e, n);
}
u(Ff, "omit");
function Jf(e, r) {
  if (!se(r))
    throw new Error("Invalid input to extend: expected a plain object");
  let i = e._zod.def.checks;
  if (i && i.length > 0) {
    let n = e._zod.def.shape;
    for (let a of Reflect.ownKeys(r))
      if (Object.getOwnPropertyDescriptor(n, a) !== void 0)
        throw new Error("Cannot overwrite keys on object schemas containing refinements. Use `.safeExtend()` instead.");
  }
  let t = de(e._zod.def, {
    get shape() {
      let n = { ...e._zod.def.shape, ...r };
      return J(this, "shape", n), n;
    }
  });
  return T(e, t);
}
u(Jf, "extend");
function Mf(e, r) {
  if (!se(r))
    throw new Error("Invalid input to safeExtend: expected a plain object");
  let i = de(e._zod.def, {
    get shape() {
      let o = { ...e._zod.def.shape, ...r };
      return J(this, "shape", o), o;
    }
  });
  return T(e, i);
}
u(Mf, "safeExtend");
function Kf(e, r) {
  if (!r?._zod?.def)
    throw new Error("Invalid input to merge: expected an object schema. To merge a plain shape, use `.extend()`.");
  if (e._zod.def.checks?.length)
    throw new Error(".merge() cannot be used on object schemas containing refinements. Use .safeExtend() instead.");
  let i = de(e._zod.def, {
    get shape() {
      let o = { ...e._zod.def.shape, ...r._zod.def.shape };
      return J(this, "shape", o), o;
    },
    get catchall() {
      return r._zod.def.catchall;
    },
    checks: r._zod.def.checks ?? []
  });
  return T(e, i);
}
u(Kf, "merge");
function Wf(e, r, i, o = "partial") {
  let n = r._zod.def.checks;
  if (n && n.length > 0)
    throw new Error(`.${o}() cannot be used on object schemas containing refinements`);
  let c = de(r._zod.def, {
    get shape() {
      let s = r._zod.def.shape, l = { ...s };
      if (i)
        for (let d of Reflect.ownKeys(i)) {
          if (!Object.prototype.hasOwnProperty.call(s, d))
            throw new Error(`Unrecognized key: "${String(d)}"`);
          i[d] && (l[d] = e ? new e({
            type: "optional",
            innerType: s[d]
          }) : s[d]);
        }
      else
        for (let d of Reflect.ownKeys(s))
          l[d] = e ? new e({
            type: "optional",
            innerType: s[d]
          }) : s[d];
      return J(this, "shape", l), l;
    },
    checks: []
  });
  return T(r, c);
}
u(Wf, "partial");
function Gf(e, r, i) {
  let o = de(r._zod.def, {
    get shape() {
      let t = r._zod.def.shape, n = { ...t };
      if (i)
        for (let a of Reflect.ownKeys(i)) {
          if (!Object.prototype.hasOwnProperty.call(n, a))
            throw new Error(`Unrecognized key: "${String(a)}"`);
          i[a] && (n[a] = new e({
            type: "nonoptional",
            innerType: t[a]
          }));
        }
      else
        for (let a of Reflect.ownKeys(t))
          n[a] = new e({
            type: "nonoptional",
            innerType: t[a]
          });
      return J(this, "shape", n), n;
    }
  });
  return T(r, o);
}
u(Gf, "required");
function ke(e, r = 0) {
  if (e.aborted === !0)
    return !0;
  for (let i = r; i < e.issues.length; i++)
    if (e.issues[i]?.continue !== !0)
      return !0;
  return !1;
}
u(ke, "aborted");
function Ni(e, r = 0) {
  if (e.aborted === !0)
    return !0;
  for (let i = r; i < e.issues.length; i++)
    if (e.issues[i]?.continue === !1)
      return !0;
  return !1;
}
u(Ni, "explicitlyAborted");
function ee(e, r) {
  return r.map((i) => {
    var o;
    return (o = i).path ?? (o.path = []), i.path.unshift(e), i;
  });
}
u(ee, "prefixIssues");
function Xe(e) {
  return typeof e == "string" ? e : e?.message;
}
u(Xe, "unwrapMessage");
function zr(e, r, i) {
  var o;
  for (let t = r; t < e.length; t++)
    (o = e[t]).schema ?? (o.schema = i);
}
u(zr, "attachSchema");
function te(e, r, i) {
  var o;
  let t = e.inst?._zod?.traits;
  t?.has("$ZodType") && (t.has("$ZodCheck") ? (o = e).schema ?? (o.schema = e.inst) : e.schema = e.inst);
  let n = e.schema !== e.inst ? e.schema?._zod.def?.error : void 0, a = e.message ? e.message : Xe(e.inst?._zod.def?.error?.(e)) ?? Xe(n?.(e)) ?? Xe(r?.error?.(e)) ?? Xe(i.customError?.(e)) ?? Xe(i.localeError?.(e)) ?? "Invalid input", { inst: c, schema: s, continue: l, input: d, ...m } = e;
  return m.path ?? (m.path = []), m.message = a, r?.reportInput && (m.input = d), m;
}
u(te, "finalizeIssue");
function Ct(e) {
  return e instanceof Set ? "set" : e instanceof Map ? "map" : e instanceof File ? "file" : "unknown";
}
u(Ct, "getSizableOrigin");
var Bf = /[\uD800-\uDBFF]/;
function Ze(e) {
  let r = e.length;
  if (!Bf.test(e))
    return r;
  let i = r;
  for (let o = 0; o < r - 1; o++)
    (e.charCodeAt(o) & 64512) === 55296 && (e.charCodeAt(o + 1) & 64512) === 56320 && (i--, o++);
  return i;
}
u(Ze, "codePointLength");
function Lt(e) {
  return Array.isArray(e) ? "array" : typeof e == "string" ? "string" : "unknown";
}
u(Lt, "getLengthableOrigin");
function _(e) {
  let r = typeof e;
  switch (r) {
    case "number":
      return Number.isNaN(e) ? "nan" : "number";
    case "object": {
      if (e === null)
        return "null";
      if (Array.isArray(e))
        return "array";
      let i = e;
      if (i && Object.getPrototypeOf(i) !== Object.prototype && "constructor" in i && i.constructor)
        return i.constructor.name;
    }
  }
  return r;
}
u(_, "parsedType");
function et(...e) {
  let [r, i, o] = e;
  return typeof r == "string" ? {
    message: r,
    code: "custom",
    input: i,
    inst: o
  } : { ...r };
}
u(et, "issue");
function qf(e) {
  return Object.entries(e).filter(([r, i]) => Number.isNaN(Number.parseInt(r, 10))).map((r) => r[1]);
}
u(qf, "cleanEnum");
function ed(e) {
  let r = atob(e), i = new Uint8Array(r.length);
  for (let o = 0; o < r.length; o++)
    i[o] = r.charCodeAt(o);
  return i;
}
u(ed, "base64ToUint8Array");
function td(e) {
  let r = "";
  for (let i = 0; i < e.length; i++)
    r += String.fromCharCode(e[i]);
  return btoa(r);
}
u(td, "uint8ArrayToBase64");
function Xf(e) {
  let r = e.replace(/-/g, "+").replace(/_/g, "/"), i = "=".repeat((4 - r.length % 4) % 4);
  return ed(r + i);
}
u(Xf, "base64urlToUint8Array");
function Yf(e) {
  return td(e).replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, "");
}
u(Yf, "uint8ArrayToBase64url");
function Hf(e) {
  let r = e.replace(/^0x/, "");
  if (r.length % 2 !== 0)
    throw new Error("Invalid hex string length");
  let i = new Uint8Array(r.length / 2);
  for (let o = 0; o < r.length; o += 2)
    i[o / 2] = Number.parseInt(r.slice(o, o + 2), 16);
  return i;
}
u(Hf, "hexToUint8Array");
function Qf(e) {
  return Array.from(e).map((r) => r.toString(16).padStart(2, "0")).join("");
}
u(Qf, "uint8ArrayToHex");
var wi = class {
  static {
    u(this, "Class");
  }
  constructor(...r) {
  }
};
function Ti(e, r) {
  for (let i in r) {
    let o = Object.getOwnPropertyDescriptor(r, i);
    o.get ? Object.defineProperty(e, i, { ...o, enumerable: !1 }) : ep(e, i, o.value);
  }
}
u(Ti, "members");
function Ye(e, r, i, o = !0) {
  return Object.defineProperty(e, r, { configurable: !0, writable: !0, enumerable: o, value: i }), i;
}
u(Ye, "own");
function Zi(e, r, i) {
  return Ye(e, r, i, !1);
}
u(Zi, "hide");
function ep(e, r, i) {
  Object.defineProperty(e, r, {
    configurable: !0,
    get() {
      return this == null ? i : Ye(this, r, i.bind(this));
    },
    set(o) {
      Ye(this, r, o);
    }
  });
}
u(ep, "defineBound");
function tp(e, r) {
  let i = Object.getPrototypeOf(e);
  return r in i ? void 0 : i;
}
u(tp, "claim");
var Ii, be = !1, rp = {
  configurable: !0,
  get() {
    be = !0;
  }
};
function O(e, r, i) {
  let o = Object.getPrototypeOf(e._zod);
  if (r in o && Ii !== e._zod) {
    Ii = void 0;
    return;
  }
  Ii = e._zod, Object.defineProperty(o, r, {
    configurable: !0,
    get() {
      Object.defineProperty(this, r, rp);
      let t = be;
      be = !1;
      try {
        let n = i(this);
        return be ? delete this[r] : Object.defineProperty(this, r, { configurable: !0, writable: !0, value: n }), be = be || t, n;
      } catch (n) {
        throw delete this[r], be = be || t, n;
      }
    },
    set(t) {
      Object.defineProperty(this, r, { configurable: !0, writable: !0, value: t });
    }
  });
}
u(O, "defineLazyInternal");
function np(e, r, i, o) {
  let t = tp(e, r);
  t && Object.defineProperty(t, r, {
    configurable: !0,
    get() {
      let n = { configurable: !0, writable: !0, enumerable: o, value: void 0 };
      return Object.defineProperty(this, r, n), n.value = i(this), Object.defineProperty(this, r, n), n.value;
    },
    set(n) {
      Object.defineProperty(this, r, { configurable: !0, writable: !0, enumerable: o, value: n });
    }
  });
}
u(np, "installLazyProp");
var Sr = "~constantCatch";
function Ai(e) {
  let r = /* @__PURE__ */ u(() => e, "fn");
  return r[Sr] = !0, r;
}
u(Ai, "constantCatch");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/core.js
var rd, Ci = /* @__PURE__ */ Object.freeze({
  status: "aborted"
}), Ei = { value: void 0, enumerable: !1 }, nd = "captureStackTrace" in Error ? Error : null;
function ip(e) {
  let r = nd;
  if (r) {
    let i = r.stackTraceLimit;
    if (typeof i == "number") {
      try {
        r.stackTraceLimit = 0;
      } catch {
        return nd = null, new e();
      }
      try {
        return new e();
      } finally {
        r.stackTraceLimit = i;
      }
    }
  }
  return new e();
}
u(ip, "newError");
// @__NO_SIDE_EFFECTS__
function f(e, r, i, o) {
  let t = {};
  function n(g) {
    this.def = g, this.constr = m, this.traits = /* @__PURE__ */ new Set();
  }
  u(n, "Internals"), n.prototype = t;
  let a = i, c = a && /* @__PURE__ */ new WeakSet();
  function s(g, v) {
    if (!g._zod) {
      Ei.value = new n(v);
      try {
        Object.defineProperty(g, "_zod", Ei);
      } finally {
        Ei.value = void 0;
      }
    }
    if (g._zod.traits.has(e))
      return;
    if (g._zod.traits.add(e), r(g, v), c) {
      let k = Object.getPrototypeOf(g), I = g._zod.constr.prototype, A = k;
      for (; A && A !== I; )
        A = Object.getPrototypeOf(A);
      let w = A ?? k;
      c.has(w) || (c.add(w), Ti(w, a));
    }
    let $ = m.prototype;
    for (let k in $)
      Object.prototype.hasOwnProperty.call($, k) && (k in g || (g[k] = $[k].bind(g)));
  }
  u(s, "init");
  let l = o?.Parent ?? Object;
  class d extends l {
    static {
      u(this, "Definition");
    }
  }
  Object.defineProperty(d, "name", { value: e });
  function m(g) {
    let v = o?.Parent ? ip(d) : this;
    s(v, g);
    let $ = v._zod.deferred;
    if ($) {
      for (let I of $)
        I();
      v._zod.deferred = void 0;
    }
    let k = globalThis.__zod_globalConfig?.postProcessor;
    return k && k(v), v;
  }
  return u(m, "_"), Object.defineProperty(m, "init", { value: s }), Object.defineProperty(m, Symbol.hasInstance, {
    value: /* @__PURE__ */ u((g) => o?.Parent && g instanceof o.Parent ? !0 : g?._zod?.traits?.has(e), "value")
  }), Object.defineProperty(m, "name", { value: e }), m;
}
u(f, "$constructor");
var Li = /* @__PURE__ */ Symbol("zod_brand"), re = class extends Error {
  static {
    u(this, "$ZodAsyncError");
  }
  constructor() {
    super("Encountered Promise during synchronous parse. Use .parseAsync() instead.");
  }
}, xe = class extends Error {
  static {
    u(this, "$ZodEncodeError");
  }
  constructor(r) {
    super(`Encountered unidirectional transform during encode: ${r}`), this.name = "ZodEncodeError";
  }
};
(rd = globalThis).__zod_globalConfig ?? (rd.__zod_globalConfig = {});
var G = globalThis.__zod_globalConfig;
function M(e) {
  return e && Object.assign(G, e), G;
}
u(M, "config");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/errors.js
function op() {
  let e = this._zod;
  return e.message ?? (e.message = JSON.stringify(e.def, He, 2)), e.message;
}
u(op, "_getMessage");
function ap(e) {
  this._zod.message = e;
}
u(ap, "_setMessage");
var up = {
  get: op,
  set: ap,
  enumerable: !0,
  configurable: !0
}, Ri = { value: void 0, enumerable: !1 }, Fi = { value: void 0, enumerable: !1 }, id = /* @__PURE__ */ new WeakSet([Object.prototype, Error.prototype]), od = /* @__PURE__ */ u((e, r) => {
  e.name = "$ZodError", Ri.value = e._zod, Object.defineProperty(e, "_zod", Ri), Fi.value = r, Object.defineProperty(e, "issues", Fi), Ri.value = void 0, Fi.value = void 0, Object.defineProperty(e, "message", up);
  let i = Object.getPrototypeOf(e);
  id.has(i) || (id.add(i), Object.defineProperty(i, "toString", {
    configurable: !0,
    enumerable: !1,
    get() {
      let o = /* @__PURE__ */ u(() => this.message, "value");
      return Object.defineProperty(this, "toString", { value: o, configurable: !0, writable: !0 }), o;
    },
    set(o) {
      Object.defineProperty(this, "toString", { value: o, configurable: !0, writable: !0 });
    }
  }));
}, "initializer"), Vt = f("$ZodError", od), ne = f("$ZodError", od, void 0, {
  Parent: Error
});
function cp(e, r, i) {
  return Object.prototype.hasOwnProperty.call(e, r) || (r === "__proto__" ? Object.defineProperty(e, r, { value: i(), writable: !0, enumerable: !0, configurable: !0 }) : e[r] = i()), e[r];
}
u(cp, "node");
function Rt(e, r = (i) => i.message) {
  let i = {}, o = [];
  for (let t of e.issues)
    t.path.length > 0 ? cp(i, t.path[0], () => []).push(r(t)) : o.push(r(t));
  return { formErrors: o, fieldErrors: i };
}
u(Rt, "flattenError");
function Ft(e, r = (i) => i.message) {
  let i = { _errors: [] }, o = /* @__PURE__ */ u((t, n = []) => {
    for (let a of t.issues)
      if (a.code === "invalid_union" && a.errors.length)
        a.errors.map((c) => o({ issues: c }, [...n, ...a.path]));
      else if (a.code === "invalid_key")
        o({ issues: a.issues }, [...n, ...a.path]);
      else if (a.code === "invalid_element")
        o({ issues: a.issues }, [...n, ...a.path]);
      else {
        let c = [...n, ...a.path];
        if (c.length === 0)
          i._errors.push(r(a));
        else {
          let s = i, l = 0;
          for (; l < c.length; ) {
            let d = c[l], m = l === c.length - 1;
            if (d === "_errors") {
              m && s._errors.push(r(a)), l++;
              continue;
            }
            Object.prototype.hasOwnProperty.call(s, d) || Object.defineProperty(s, d, {
              value: { _errors: [] },
              enumerable: !0,
              writable: !0,
              configurable: !0
            });
            let g = s[d];
            m && g._errors.push(r(a)), s = g, l++;
          }
        }
      }
  }, "processError");
  return o(e), i;
}
u(Ft, "formatError");
function Ji(e, r = (i) => i.message) {
  let i = { errors: [] }, o = /* @__PURE__ */ u((t, n = []) => {
    var a;
    for (let c of t.issues)
      if (c.code === "invalid_union" && c.errors.length)
        c.errors.map((s) => o({ issues: s }, [...n, ...c.path]));
      else if (c.code === "invalid_key")
        o({ issues: c.issues }, [...n, ...c.path]);
      else if (c.code === "invalid_element")
        o({ issues: c.issues }, [...n, ...c.path]);
      else {
        let s = [...n, ...c.path];
        if (s.length === 0) {
          i.errors.push(r(c));
          continue;
        }
        let l = i, d = 0;
        for (; d < s.length; ) {
          let m = s[d], g = d === s.length - 1;
          typeof m == "string" ? (l.properties ?? (l.properties = {}), Object.prototype.hasOwnProperty.call(l.properties, m) || Object.defineProperty(l.properties, m, {
            value: { errors: [] },
            enumerable: !0,
            writable: !0,
            configurable: !0
          }), l = l.properties[m]) : (l.items ?? (l.items = []), (a = l.items)[m] ?? (a[m] = { errors: [] }), l = l.items[m]), g && l.errors.push(r(c)), d++;
        }
      }
  }, "processError");
  return o(e), i;
}
u(Ji, "treeifyError");
function ad(e) {
  let r = [], i = e.map((o) => typeof o == "object" ? o.key : o);
  for (let o of i)
    typeof o == "number" ? r.push(`[${o}]`) : typeof o == "symbol" ? r.push(`[${JSON.stringify(String(o))}]`) : /[^\w$]/.test(o) ? r.push(`[${JSON.stringify(o)}]`) : (r.length && r.push("."), r.push(o));
  return r.join("");
}
u(ad, "toDotPath");
function Mi(e) {
  let r = [], i = [...e.issues].sort((o, t) => (o.path ?? []).length - (t.path ?? []).length);
  for (let o of i)
    r.push(`\u2716 ${o.message}`), o.path?.length && r.push(`  \u2192 at ${ad(o.path)}`);
  return r.join(`
`);
}
u(Mi, "prettifyError");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/parse.js
function jr(e, r) {
  return { callee: r?.callee ?? e, Err: r?.Err };
}
u(jr, "finalizeParams");
var tt = /* @__PURE__ */ u((e) => {
  let r = /* @__PURE__ */ u((i, o, t, n) => {
    let a = t ? { ...t, async: !1 } : { async: !1 }, c = i._zod.run({ value: o, issues: [] }, a);
    if (c instanceof Promise)
      throw new re();
    if (c.issues.length) {
      let s = new (n?.Err ?? e)(c.issues.map((l) => te(l, a, M())));
      throw wr(s, n?.callee ?? r), s;
    }
    return c.value;
  }, "fn");
  return r;
}, "_parse"), Pr = /* @__PURE__ */ tt(ne), rt = /* @__PURE__ */ u((e) => {
  let r = /* @__PURE__ */ u(async (i, o, t, n) => {
    let a = t ? { ...t, async: !0 } : { async: !0 }, c = i._zod.run({ value: o, issues: [] }, a);
    if (c instanceof Promise && (c = await c), c.issues.length) {
      let s = new (n?.Err ?? e)(c.issues.map((l) => te(l, a, M())));
      throw wr(s, n?.callee ?? r), s;
    }
    return c.value;
  }, "fn");
  return r;
}, "_parseAsync"), Dr = /* @__PURE__ */ rt(ne), nt = /* @__PURE__ */ u((e) => (r, i, o) => {
  let t = o ? { ...o, async: !1 } : { async: !1 }, n = r._zod.run({ value: i, issues: [] }, t);
  if (n instanceof Promise)
    throw new re();
  return n.issues.length ? {
    success: !1,
    error: new (e ?? Vt)(n.issues.map((a) => te(a, t, M())))
  } : { success: !0, data: n.value };
}, "_safeParse"), Ki = /* @__PURE__ */ nt(ne), it = /* @__PURE__ */ u((e) => async (r, i, o) => {
  let t = o ? { ...o, async: !0 } : { async: !0 }, n = r._zod.run({ value: i, issues: [] }, t);
  return n instanceof Promise && (n = await n), n.issues.length ? {
    success: !1,
    error: new e(n.issues.map((a) => te(a, t, M())))
  } : { success: !0, data: n.value };
}, "_safeParseAsync"), Wi = /* @__PURE__ */ it(ne), lp = /* @__PURE__ */ Symbol.for("zod.compile.invalid"), dp = /* @__PURE__ */ Symbol.for("zod.compile.fallback"), Gi = /* @__PURE__ */ u(((e, r, i) => {
  let o = e._zod.bag.validator;
  return o !== void 0 && o(r) !== lp ? !0 : mp(e, r, i);
}), "validate");
function mp(e, r, i) {
  let o = i ? { ...i, async: !1 } : { async: !1 }, t = e._zod.bag.fallbackRun, n;
  if (t ? (o[dp] = !0, n = t({ value: r, issues: [] }, o)) : n = e._zod.run({ value: r, issues: [] }, o), n instanceof Promise)
    throw new re();
  return n.issues.length === 0;
}
u(mp, "validateFallback");
var Bi = /* @__PURE__ */ u(async (e, r, i) => {
  let o = i ? { ...i, async: !0 } : { async: !0 }, t = e._zod.run({ value: r, issues: [] }, o);
  return t instanceof Promise && (t = await t), t.issues.length === 0;
}, "validateAsync"), Or = /* @__PURE__ */ u((e) => {
  let r = tt(e), i = /* @__PURE__ */ u((o, t, n, a) => {
    let c = n ? { ...n, direction: "backward" } : { direction: "backward" };
    return r(o, t, c, jr(i, a));
  }, "fn");
  return i;
}, "_encode"), fp = /* @__PURE__ */ Or(ne), Ur = /* @__PURE__ */ u((e) => {
  let r = tt(e), i = /* @__PURE__ */ u((o, t, n, a) => r(o, t, n, jr(i, a)), "fn");
  return i;
}, "_decode"), pp = /* @__PURE__ */ Ur(ne), Nr = /* @__PURE__ */ u((e) => {
  let r = rt(e), i = /* @__PURE__ */ u(async (o, t, n, a) => {
    let c = n ? { ...n, direction: "backward" } : { direction: "backward" };
    return await r(o, t, c, jr(i, a));
  }, "fn");
  return i;
}, "_encodeAsync"), gp = /* @__PURE__ */ Nr(ne), Tr = /* @__PURE__ */ u((e) => {
  let r = rt(e), i = /* @__PURE__ */ u(async (o, t, n, a) => await r(o, t, n, jr(i, a)), "fn");
  return i;
}, "_decodeAsync"), vp = /* @__PURE__ */ Tr(ne), Zr = /* @__PURE__ */ u((e) => (r, i, o) => {
  let t = o ? { ...o, direction: "backward" } : { direction: "backward" };
  return nt(e)(r, i, t);
}, "_safeEncode"), $p = /* @__PURE__ */ Zr(ne), Ar = /* @__PURE__ */ u((e) => (r, i, o) => nt(e)(r, i, o), "_safeDecode"), hp = /* @__PURE__ */ Ar(ne), Er = /* @__PURE__ */ u((e) => async (r, i, o) => {
  let t = o ? { ...o, direction: "backward" } : { direction: "backward" };
  return it(e)(r, i, t);
}, "_safeEncodeAsync"), _p = /* @__PURE__ */ Er(ne), Cr = /* @__PURE__ */ u((e) => async (r, i, o) => it(e)(r, i, o), "_safeDecodeAsync"), yp = /* @__PURE__ */ Cr(ne);

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/regexes.js
var X = {};
he(X, {
  base64: () => fo,
  base64url: () => Lr,
  bigint: () => yo,
  boolean: () => bo,
  browserEmail: () => jp,
  cidrv4: () => lo,
  cidrv6: () => mo,
  creditCard: () => Vr,
  cuid: () => Xi,
  cuid2: () => Yi,
  date: () => vo,
  datetime: () => ho,
  domain: () => Op,
  duration: () => no,
  e164: () => go,
  email: () => oo,
  emoji: () => ao,
  extendedDuration: () => bp,
  guid: () => io,
  hex: () => Np,
  hostname: () => Dp,
  html5Email: () => wp,
  httpProtocol: () => po,
  idnEmail: () => Sp,
  integer: () => Jt,
  ipv4: () => uo,
  ipv6: () => co,
  ksuid: () => eo,
  lowercase: () => Io,
  mac: () => so,
  md5_base64: () => Zp,
  md5_base64url: () => Ap,
  md5_hex: () => Tp,
  nanoid: () => to,
  nanoidOfLength: () => ro,
  null: () => ko,
  number: () => Ie,
  rfc5322Email: () => zp,
  sha1_base64: () => Cp,
  sha1_base64url: () => Lp,
  sha1_hex: () => Ep,
  sha256_base64: () => Rp,
  sha256_base64url: () => Fp,
  sha256_hex: () => Vp,
  sha384_base64: () => Mp,
  sha384_base64url: () => Kp,
  sha384_hex: () => Jp,
  sha512_base64: () => Gp,
  sha512_base64url: () => Bp,
  sha512_hex: () => Wp,
  string: () => _o,
  time: () => $o,
  ulid: () => Hi,
  undefined: () => xo,
  unicodeEmail: () => ud,
  uppercase: () => wo,
  uuid: () => Ae,
  uuid4: () => kp,
  uuid6: () => xp,
  uuid7: () => Ip,
  xid: () => Qi
});
var Xi = /^[cC][0-9a-z]{6,}$/, Yi = /^[0-9a-z]+$/, Hi = /^[0-7][0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{25}$/, Qi = /^[0-9a-vA-V]{20}$/, eo = /^[A-Za-z0-9]{27}$/, to = /^[a-zA-Z0-9_-]{21}$/;
function ro(e) {
  return new RegExp(`^[a-zA-Z0-9_-]{${e}}$`);
}
u(ro, "nanoidOfLength");
var no = /^P(?:(\d+W)|(?!.*W)(?=\d|T\d)(\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+([.,]\d+)?S)?)?)$/, bp = /^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/, io = /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/, Ae = /* @__PURE__ */ u((e) => e ? new RegExp(`^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${e}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`) : /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/, "uuid"), kp = /* @__PURE__ */ Ae(4), xp = /* @__PURE__ */ Ae(6), Ip = /* @__PURE__ */ Ae(7), oo = /^(?!\.)(?!.*\.\.)([A-Za-z0-9_'+\-\.]*)[A-Za-z0-9_+-]@([A-Za-z0-9][A-Za-z0-9\-]*\.)+[A-Za-z]{2,}$/, wp = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/, zp = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/, ud = /^[^\s@"]{1,64}@[^\s@]{1,255}$/u, Sp = ud, jp = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/, Pp = "^[\\p{Extended_Pictographic}\\p{Emoji_Component}]+$";
function ao() {
  return new RegExp(Pp, "u");
}
u(ao, "emoji");
var uo = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/, co = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))$/, so = /* @__PURE__ */ u((e) => {
  let r = le(e ?? ":");
  return new RegExp(`^(?:[0-9A-F]{2}${r}){5}[0-9A-F]{2}$|^(?:[0-9a-f]{2}${r}){5}[0-9a-f]{2}$`);
}, "mac"), lo = /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/([0-9]|[1-2][0-9]|3[0-2])$/, mo = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/, fo = /^$|^(?:[0-9a-zA-Z+/]{4})*(?:(?:[0-9a-zA-Z+/]{2}==)|(?:[0-9a-zA-Z+/]{3}=))?$/, Lr = /^[A-Za-z0-9_-]*$/, Dp = /^(?=.{1,253}\.?$)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[-0-9a-zA-Z]{0,61}[0-9a-zA-Z])?)*\.?$/, Op = /^(?=.{1,253}$)([a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,63}$/, po = /^https?$/, go = /^\+[1-9]\d{6,14}$/, Vr = /^\d(?:[ -]?\d){11,18}$/, cd = "(?:(?:\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-(?:(?:0[13578]|1[02])-(?:0[1-9]|[12]\\d|3[01])|(?:0[469]|11)-(?:0[1-9]|[12]\\d|30)|(?:02)-(?:0[1-9]|1\\d|2[0-8])))";
function Up(e) {
  return new RegExp(`^${e}$`);
}
u(Up, "anchor");
var vo = /* @__PURE__ */ Up(cd);
function qi(e) {
  let r = "(?:[01]\\d|2[0-3]):[0-5]\\d";
  return typeof e.precision == "number" ? e.precision === -1 ? `${r}` : e.precision === 0 ? `${r}:[0-5]\\d` : `${r}:[0-5]\\d\\.\\d{${e.precision}}` : e.seconds ? `${r}:[0-5]\\d(?:\\.\\d+)?` : `${r}(?::[0-5]\\d(?:\\.\\d+)?)?`;
}
u(qi, "timeSource");
function $o(e) {
  return new RegExp(`^${qi(e)}$`);
}
u($o, "time");
function ho(e) {
  let r = ["Z"];
  e.offset && r.push("([+-](?:[01]\\d|2[0-3]):[0-5]\\d)");
  let i = `${qi({ precision: e.precision, seconds: !0 })}(?:${r.join("|")})`, o = e.local ? `${i}|${qi({ precision: e.precision })}` : i;
  return new RegExp(`^${cd}T(?:${o})$`);
}
u(ho, "datetime");
var _o = /* @__PURE__ */ u((e) => {
  let r = e ? `[\\s\\S]{${e?.minimum ?? 0},${e?.maximum ?? ""}}` : "[\\s\\S]*";
  return new RegExp(`^${r}$`);
}, "string"), yo = /^-?\d+n?$/, Jt = /^-?\d+$/, Ie = /^-?\d+(?:\.\d+)?$/, bo = /^(?:true|false)$/i, ko = /^null$/i;
var xo = /^undefined$/i;
var Io = /^[^A-Z]*$/, wo = /^[^a-z]*$/, Np = /^[0-9a-fA-F]*$/;
function Mt(e, r) {
  return new RegExp(`^[A-Za-z0-9+/]{${e}}${r}$`);
}
u(Mt, "fixedBase64");
function Kt(e) {
  return new RegExp(`^[A-Za-z0-9_-]{${e}}$`);
}
u(Kt, "fixedBase64url");
var Tp = /^[0-9a-fA-F]{32}$/, Zp = /* @__PURE__ */ Mt(22, "=="), Ap = /* @__PURE__ */ Kt(22), Ep = /^[0-9a-fA-F]{40}$/, Cp = /* @__PURE__ */ Mt(27, "="), Lp = /* @__PURE__ */ Kt(27), Vp = /^[0-9a-fA-F]{64}$/, Rp = /* @__PURE__ */ Mt(43, "="), Fp = /* @__PURE__ */ Kt(43), Jp = /^[0-9a-fA-F]{96}$/, Mp = /* @__PURE__ */ Mt(64, ""), Kp = /* @__PURE__ */ Kt(64), Wp = /^[0-9a-fA-F]{128}$/, Gp = /* @__PURE__ */ Mt(86, "=="), Bp = /* @__PURE__ */ Kt(86);

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/checks.js
var L = /* @__PURE__ */ f("$ZodCheck", (e, r) => {
  var i;
  e._zod ?? (e._zod = {}), e._zod.def = r, (i = e._zod).onattach ?? (i.onattach = []);
}), zo = /* @__PURE__ */ u((e) => {
  let r = e.value;
  return !Ir(r) && r.size !== void 0;
}, "_whenHasSize"), So = /* @__PURE__ */ u((e) => {
  let r = e.value;
  return !Ir(r) && r.length !== void 0;
}, "_whenHasLength"), Rr = {
  number: "number",
  bigint: "bigint",
  object: "date"
}, Fr = /* @__PURE__ */ f("$ZodCheckLessThan", (e, r) => {
  L.init(e, r);
  let i = Rr[typeof r.value];
  e._zod.onattach.push((o) => {
    let t = o._zod.bag, n = (r.inclusive ? t.maximum : t.exclusiveMaximum) ?? Number.POSITIVE_INFINITY;
    r.value < n && (r.inclusive ? t.maximum = r.value : t.exclusiveMaximum = r.value);
  }), e._zod.check = (o) => {
    (r.inclusive ? o.value <= r.value : o.value < r.value) || o.issues.push({
      origin: Rr[typeof o.value] ?? i,
      code: "too_big",
      maximum: typeof r.value == "object" ? r.value.getTime() : r.value,
      input: o.value,
      inclusive: r.inclusive,
      inst: e,
      continue: !r.abort
    });
  };
}), Jr = /* @__PURE__ */ f("$ZodCheckGreaterThan", (e, r) => {
  L.init(e, r);
  let i = Rr[typeof r.value];
  e._zod.onattach.push((o) => {
    let t = o._zod.bag, n = (r.inclusive ? t.minimum : t.exclusiveMinimum) ?? Number.NEGATIVE_INFINITY;
    r.value > n && (r.inclusive ? t.minimum = r.value : t.exclusiveMinimum = r.value);
  }), e._zod.check = (o) => {
    (r.inclusive ? o.value >= r.value : o.value > r.value) || o.issues.push({
      origin: Rr[typeof o.value] ?? i,
      code: "too_small",
      minimum: typeof r.value == "object" ? r.value.getTime() : r.value,
      input: o.value,
      inclusive: r.inclusive,
      inst: e,
      continue: !r.abort
    });
  };
}), jo = /* @__PURE__ */ f("$ZodCheckMultipleOf", (e, r) => {
  L.init(e, r), e._zod.onattach.push((i) => {
    var o;
    (o = i._zod.bag).multipleOf ?? (o.multipleOf = r.value);
  }), e._zod.check = (i) => {
    if (typeof i.value != typeof r.value)
      throw new Error("Cannot mix number and bigint in multiple_of check.");
    (typeof i.value == "bigint" ? (
      // `value % 0n` throws, and nothing is a multiple of zero — the number branch already fails this way via NaN
      r.value !== BigInt(0) && i.value % r.value === BigInt(0)
    ) : Zt(i.value, r.value) === 0) || i.issues.push({
      origin: typeof i.value,
      code: "not_multiple_of",
      divisor: r.value,
      input: i.value,
      inst: e,
      continue: !r.abort
    });
  };
}), Po = /* @__PURE__ */ f("$ZodCheckNumberFormat", (e, r) => {
  L.init(e, r), r.format = r.format || "float64";
  let i = r.format?.includes("int"), o = i ? "int" : "number", [t, n] = Oi[r.format];
  e._zod.onattach.push((a) => {
    let c = a._zod.bag;
    c.format = r.format, c.minimum = t, c.maximum = n, i && (c.pattern = Jt);
  }), e._zod.check = (a) => {
    let c = a.value;
    if (i) {
      if (!Number.isInteger(c)) {
        a.issues.push({
          expected: o,
          format: r.format,
          code: "invalid_type",
          continue: !1,
          input: c,
          inst: e
        });
        return;
      }
      if (!Number.isSafeInteger(c)) {
        c > 0 ? a.issues.push({
          input: c,
          code: "too_big",
          maximum: Number.MAX_SAFE_INTEGER,
          note: "Integers must be within the safe integer range.",
          inst: e,
          origin: o,
          inclusive: !0,
          continue: !r.abort
        }) : a.issues.push({
          input: c,
          code: "too_small",
          minimum: Number.MIN_SAFE_INTEGER,
          note: "Integers must be within the safe integer range.",
          inst: e,
          origin: o,
          inclusive: !0,
          continue: !r.abort
        });
        return;
      }
    }
    c < t && a.issues.push({
      origin: "number",
      input: c,
      code: "too_small",
      minimum: t,
      inclusive: !0,
      inst: e,
      continue: !r.abort
    }), c > n && a.issues.push({
      origin: "number",
      input: c,
      code: "too_big",
      maximum: n,
      inclusive: !0,
      inst: e,
      continue: !r.abort
    });
  };
}), Do = /* @__PURE__ */ f("$ZodCheckBigIntFormat", (e, r) => {
  L.init(e, r);
  let [i, o] = Ui[r.format];
  e._zod.onattach.push((t) => {
    let n = t._zod.bag;
    n.format = r.format, n.minimum = i, n.maximum = o;
  }), e._zod.check = (t) => {
    let n = t.value;
    n < i && t.issues.push({
      origin: "bigint",
      input: n,
      code: "too_small",
      minimum: i,
      inclusive: !0,
      inst: e,
      continue: !r.abort
    }), n > o && t.issues.push({
      origin: "bigint",
      input: n,
      code: "too_big",
      maximum: o,
      inclusive: !0,
      inst: e,
      continue: !r.abort
    });
  };
}), Oo = /* @__PURE__ */ f("$ZodCheckMaxSize", (e, r) => {
  var i;
  L.init(e, r), (i = e._zod.def).when ?? (i.when = zo), e._zod.onattach.push((o) => {
    let t = o._zod.bag.maximum ?? Number.POSITIVE_INFINITY;
    r.maximum < t && (o._zod.bag.maximum = r.maximum);
  }), e._zod.check = (o) => {
    let t = o.value;
    t.size <= r.maximum || o.issues.push({
      origin: Ct(t),
      code: "too_big",
      maximum: r.maximum,
      inclusive: !0,
      input: t,
      inst: e,
      continue: !r.abort
    });
  };
}), Uo = /* @__PURE__ */ f("$ZodCheckMinSize", (e, r) => {
  var i;
  L.init(e, r), (i = e._zod.def).when ?? (i.when = zo), e._zod.onattach.push((o) => {
    let t = o._zod.bag.minimum ?? Number.NEGATIVE_INFINITY;
    r.minimum > t && (o._zod.bag.minimum = r.minimum);
  }), e._zod.check = (o) => {
    let t = o.value;
    t.size >= r.minimum || o.issues.push({
      origin: Ct(t),
      code: "too_small",
      minimum: r.minimum,
      inclusive: !0,
      input: t,
      inst: e,
      continue: !r.abort
    });
  };
}), No = /* @__PURE__ */ f("$ZodCheckSizeEquals", (e, r) => {
  var i;
  L.init(e, r), (i = e._zod.def).when ?? (i.when = zo), e._zod.onattach.push((o) => {
    let t = o._zod.bag;
    t.minimum = r.size, t.maximum = r.size, t.size = r.size;
  }), e._zod.check = (o) => {
    let t = o.value, n = t.size;
    if (n === r.size)
      return;
    let a = n > r.size;
    o.issues.push({
      origin: Ct(t),
      ...a ? { code: "too_big", maximum: r.size } : { code: "too_small", minimum: r.size },
      inclusive: !0,
      exact: !0,
      input: o.value,
      inst: e,
      continue: !r.abort
    });
  };
}), To = /* @__PURE__ */ f("$ZodCheckMaxLength", (e, r) => {
  var i;
  L.init(e, r), (i = e._zod.def).when ?? (i.when = So), e._zod.onattach.push((o) => {
    let t = o._zod.bag.maximum ?? Number.POSITIVE_INFINITY;
    r.maximum < t && (o._zod.bag.maximum = r.maximum);
  }), e._zod.check = (o) => {
    let t = o.value, n = t.length;
    if ((typeof t == "string" && n > r.maximum ? Ze(t) : n) <= r.maximum)
      return;
    let c = Lt(t);
    o.issues.push({
      origin: c,
      code: "too_big",
      maximum: r.maximum,
      inclusive: !0,
      input: t,
      inst: e,
      continue: !r.abort
    });
  };
}), Zo = /* @__PURE__ */ f("$ZodCheckMinLength", (e, r) => {
  var i;
  L.init(e, r), (i = e._zod.def).when ?? (i.when = So), e._zod.onattach.push((o) => {
    let t = o._zod.bag.minimum ?? Number.NEGATIVE_INFINITY;
    r.minimum > t && (o._zod.bag.minimum = r.minimum);
  }), e._zod.check = (o) => {
    let t = o.value, n = t.length;
    if ((typeof t == "string" && n >= r.minimum && n < r.minimum * 2 ? Ze(t) : n) >= r.minimum)
      return;
    let c = Lt(t);
    o.issues.push({
      origin: c,
      code: "too_small",
      minimum: r.minimum,
      inclusive: !0,
      input: t,
      inst: e,
      continue: !r.abort
    });
  };
}), Ao = /* @__PURE__ */ f("$ZodCheckLengthEquals", (e, r) => {
  var i;
  L.init(e, r), (i = e._zod.def).when ?? (i.when = So), e._zod.onattach.push((o) => {
    let t = o._zod.bag;
    t.minimum = r.length, t.maximum = r.length, t.length = r.length;
  }), e._zod.check = (o) => {
    let t = o.value, n = t.length, a = typeof t == "string" && n >= r.length && n <= r.length * 2 ? Ze(t) : n;
    if (a === r.length)
      return;
    let c = Lt(t), s = a > r.length;
    o.issues.push({
      origin: c,
      ...s ? { code: "too_big", maximum: r.length } : { code: "too_small", minimum: r.length },
      inclusive: !0,
      exact: !0,
      input: o.value,
      inst: e,
      continue: !r.abort
    });
  };
}), ot = /* @__PURE__ */ f("$ZodCheckStringFormat", (e, r) => {
  var i, o;
  L.init(e, r), e._zod.onattach.push((t) => {
    let n = t._zod.bag;
    n.format = r.format, r.pattern && (n.patterns ?? (n.patterns = /* @__PURE__ */ new Set()), n.patterns.add(r.pattern));
  }), r.pattern ? (i = e._zod).check ?? (i.check = (t) => {
    r.pattern.lastIndex = 0, !r.pattern.test(t.value) && t.issues.push({
      origin: "string",
      code: "invalid_format",
      format: r.format,
      input: t.value,
      ...r.pattern ? { pattern: r.pattern.toString() } : {},
      inst: e,
      continue: !r.abort
    });
  }) : (o = e._zod).check ?? (o.check = () => {
  });
}), Eo = /* @__PURE__ */ f("$ZodCheckRegex", (e, r) => {
  ot.init(e, r), e._zod.check = (i) => {
    r.pattern.lastIndex = 0, !r.pattern.test(i.value) && i.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "regex",
      input: i.value,
      pattern: r.pattern.toString(),
      inst: e,
      continue: !r.abort
    });
  };
}), Co = /* @__PURE__ */ f("$ZodCheckLowerCase", (e, r) => {
  r.pattern ?? (r.pattern = Io), ot.init(e, r);
}), Lo = /* @__PURE__ */ f("$ZodCheckUpperCase", (e, r) => {
  r.pattern ?? (r.pattern = wo), ot.init(e, r);
}), Vo = /* @__PURE__ */ f("$ZodCheckIncludes", (e, r) => {
  L.init(e, r);
  let i = le(r.includes), o = new RegExp(typeof r.position == "number" ? `^.{${r.position},}${i}` : i);
  r.pattern = o, e._zod.onattach.push((t) => {
    let n = t._zod.bag;
    n.patterns ?? (n.patterns = /* @__PURE__ */ new Set()), n.patterns.add(o);
  }), e._zod.check = (t) => {
    t.value.includes(r.includes, r.position) || t.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "includes",
      includes: r.includes,
      input: t.value,
      inst: e,
      continue: !r.abort
    });
  };
}), Ro = /* @__PURE__ */ f("$ZodCheckStartsWith", (e, r) => {
  L.init(e, r);
  let i = new RegExp(`^${le(r.prefix)}.*`);
  r.pattern ?? (r.pattern = i), e._zod.onattach.push((o) => {
    let t = o._zod.bag;
    t.patterns ?? (t.patterns = /* @__PURE__ */ new Set()), t.patterns.add(i);
  }), e._zod.check = (o) => {
    o.value.startsWith(r.prefix) || o.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "starts_with",
      prefix: r.prefix,
      input: o.value,
      inst: e,
      continue: !r.abort
    });
  };
}), Fo = /* @__PURE__ */ f("$ZodCheckEndsWith", (e, r) => {
  L.init(e, r);
  let i = new RegExp(`.*${le(r.suffix)}$`);
  r.pattern ?? (r.pattern = i), e._zod.onattach.push((o) => {
    let t = o._zod.bag;
    t.patterns ?? (t.patterns = /* @__PURE__ */ new Set()), t.patterns.add(i);
  }), e._zod.check = (o) => {
    o.value.endsWith(r.suffix) || o.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "ends_with",
      suffix: r.suffix,
      input: o.value,
      inst: e,
      continue: !r.abort
    });
  };
});
function sd(e, r, i) {
  e.issues.length && r.issues.push(...ee(i, e.issues));
}
u(sd, "handleCheckPropertyResult");
var Mr = /* @__PURE__ */ f("$ZodCheckProperty", (e, r) => {
  L.init(e, r), e._zod.check = (i) => {
    let o = r.schema._zod.run({
      value: i.value[r.property],
      issues: []
    }, {});
    if (o instanceof Promise)
      return o.then((t) => sd(t, i, r.property));
    sd(o, i, r.property);
  };
}), Jo = /* @__PURE__ */ f("$ZodCheckMimeType", (e, r) => {
  L.init(e, r);
  let i = new Set(r.mime);
  e._zod.onattach.push((o) => {
    o._zod.bag.mime = r.mime;
  }), e._zod.check = (o) => {
    i.has(o.value.type) || o.issues.push({
      code: "invalid_value",
      values: r.mime,
      input: o.value.type,
      inst: e,
      continue: !r.abort
    });
  };
}), Mo = /* @__PURE__ */ f("$ZodCheckOverwrite", (e, r) => {
  L.init(e, r), e._zod.check = (i) => {
    i.value = r.tx(i.value);
  };
});

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/doc.js
var Ee = class {
  static {
    u(this, "Doc");
  }
  constructor(r = [], i = {}) {
    this.content = [], this.indent = 0, this.args = r, this.closed = i;
  }
  indented(r) {
    this.indent += 1, r(this), this.indent -= 1;
  }
  write(r) {
    if (typeof r == "function") {
      r(this, { execution: "sync" }), r(this, { execution: "async" });
      return;
    }
    let o = r.split(`
`).filter((a) => a), t = Math.min(...o.map((a) => a.length - a.trimStart().length)), n = o.map((a) => a.slice(t)).map((a) => " ".repeat(this.indent * 2) + a);
    for (let a of n)
      this.content.push(a);
  }
  compile() {
    let r = Function, i = this?.content ?? [""];
    return new r(...Object.keys(this.closed), `return function (${this.args.join(", ")}) {
${i.join(`
`)}
};`)(...Object.values(this.closed));
  }
};

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/versions.js
var Ko = {
  major: 4,
  minor: 5,
  patch: 4
};

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/schemas.js
var j = /* @__PURE__ */ f("$ZodType", (e, r) => {
  var i;
  e ?? (e = {}), e._zod.def = r, e._zod.bag = e._zod.bag || {}, e._zod.version = Ko;
  let o = e._zod.def.checks, t = e._zod.traits.has("$ZodCheck") ? [e, ...o ?? []] : o?.length ? [...o] : [];
  for (let n of t)
    for (let a of n._zod.onattach)
      a(e);
  if (t.length === 0)
    (i = e._zod).deferred ?? (i.deferred = []), e._zod.deferred?.push(() => {
      e._zod.run = e._zod.parse;
    });
  else {
    let n = /* @__PURE__ */ u((c, s, l) => {
      if (c.memo)
        return c;
      let d = ke(c), m;
      for (let g of s) {
        if (g._zod.def.when) {
          if (Ni(c) || !g._zod.def.when(c))
            continue;
        } else if (d)
          continue;
        let v = c.issues.length, $ = g._zod.check(c);
        if ($ instanceof Promise && l?.async === !1)
          throw new re();
        if (m || $ instanceof Promise)
          m = (m ?? Promise.resolve()).then(async () => {
            await $, c.issues.length !== v && (zr(c.issues, v, e), d || (d = ke(c, v)));
          });
        else {
          if (c.issues.length === v)
            continue;
          zr(c.issues, v, e), d || (d = ke(c, v));
        }
      }
      return m ? m.then(() => c) : c;
    }, "runChecks"), a = /* @__PURE__ */ u((c, s, l) => {
      if (ke(c))
        return c.aborted = !0, c;
      let d = n(s, t, l);
      if (d instanceof Promise) {
        if (l.async === !1)
          throw new re();
        return d.then((m) => e._zod.parse(m, l));
      }
      return e._zod.parse(d, l);
    }, "handleCanaryResult");
    e._zod.run = (c, s) => {
      if (s.skipChecks)
        return e._zod.parse(c, s);
      if (s.direction === "backward") {
        let d = e._zod.parse({ value: c.value, issues: [] }, { ...s, skipChecks: !0 });
        return d instanceof Promise ? d.then((m) => a(m, c, s)) : a(d, c, s);
      }
      let l = e._zod.parse(c, s);
      if (l instanceof Promise) {
        if (s.async === !1)
          throw new re();
        return l.then((d) => n(d, t, s));
      }
      return n(l, t, s);
    };
  }
}, {
  // Wrappers extend this by installing a richer factory over it; reading it eagerly would defeat the laziness.
  get "~standard"() {
    return Zi(this, "~standard", qr(this));
  },
  set "~standard"(e) {
    Ye(this, "~standard", e);
  }
}), dd = /* @__PURE__ */ u((e) => e.success ? { value: e.data } : { issues: e.error?.issues }, "toStandardResult");
function qr(e) {
  return {
    validate: /* @__PURE__ */ u((r) => {
      try {
        return dd(Ki(e, r));
      } catch {
        return Wi(e, r).then(dd);
      }
    }, "validate"),
    vendor: "zod",
    version: 1
  };
}
u(qr, "standardProps");
var Ce = /* @__PURE__ */ f("$ZodString", (e, r) => {
  j.init(e, r), e._zod.pattern = [...e?._zod.bag?.patterns ?? []].pop() ?? _o(e._zod.bag), e._zod.parse = (i, o) => {
    if (r.coerce)
      try {
        i.value = String(i.value);
      } catch {
      }
    return typeof i.value == "string" || i.issues.push({
      expected: "string",
      code: "invalid_type",
      input: i.value,
      inst: e
    }), i;
  };
}), E = /* @__PURE__ */ f("$ZodStringFormat", (e, r) => {
  ot.init(e, r), Ce.init(e, r);
}), Go = /* @__PURE__ */ f("$ZodGUID", (e, r) => {
  r.pattern ?? (r.pattern = io), E.init(e, r);
}), Bo = /* @__PURE__ */ f("$ZodUUID", (e, r) => {
  if (r.version) {
    let o = {
      v1: 1,
      v2: 2,
      v3: 3,
      v4: 4,
      v5: 5,
      v6: 6,
      v7: 7,
      v8: 8
    }[r.version];
    if (o === void 0)
      throw new Error(`Invalid UUID version: "${r.version}"`);
    r.pattern ?? (r.pattern = Ae(o));
  } else
    r.pattern ?? (r.pattern = Ae());
  E.init(e, r);
}), qo = /* @__PURE__ */ f("$ZodEmail", (e, r) => {
  r.pattern ?? (r.pattern = oo), E.init(e, r);
}), Xo = 1, Yo = 2;
function Xr(e, r) {
  if (!r.normalize && r.protocol?.source === po.source && !/^https?:\/\//i.test(e))
    return Xo;
  try {
    return new URL(e);
  } catch {
    return Yo;
  }
}
u(Xr, "parseURLObject");
var qp = /[\t\n\r]/g;
function Yr(e) {
  return e.replace(qp, "");
}
u(Yr, "stripTabAndNewline");
function Hr(e, r) {
  return r.lastIndex = 0, r.test(e.hostname);
}
u(Hr, "urlHostnameOk");
function Qr(e, r) {
  return r.lastIndex = 0, r.test(e.protocol.endsWith(":") ? e.protocol.slice(0, -1) : e.protocol);
}
u(Qr, "urlProtocolOk");
var Ho = /* @__PURE__ */ f("$ZodURL", (e, r) => {
  E.init(e, r), e._zod.check = (i) => {
    try {
      let o = i.value.trim(), t = Xr(o, r);
      if (t === Xo) {
        i.issues.push({
          code: "invalid_format",
          format: "url",
          note: "Invalid URL format",
          input: i.value,
          inst: e,
          continue: !r.abort
        });
        return;
      }
      if (t === Yo) {
        i.issues.push({
          code: "invalid_format",
          format: "url",
          input: i.value,
          inst: e,
          continue: !r.abort
        });
        return;
      }
      r.hostname && !Hr(t, r.hostname) && i.issues.push({
        code: "invalid_format",
        format: "url",
        note: "Invalid hostname",
        pattern: r.hostname.source,
        input: i.value,
        inst: e,
        continue: !r.abort
      }), r.protocol && !Qr(t, r.protocol) && i.issues.push({
        code: "invalid_format",
        format: "url",
        note: "Invalid protocol",
        pattern: r.protocol.source,
        input: i.value,
        inst: e,
        continue: !r.abort
      }), i.value = r.normalize ? t.href : Yr(o);
      return;
    } catch {
      i.issues.push({
        code: "invalid_format",
        format: "url",
        input: i.value,
        inst: e,
        continue: !r.abort
      });
    }
  };
}), Qo = /* @__PURE__ */ f("$ZodEmoji", (e, r) => {
  r.pattern ?? (r.pattern = ao()), E.init(e, r);
}), ea = /* @__PURE__ */ f("$ZodNanoID", (e, r) => {
  if (r.length !== void 0 && (!Number.isInteger(r.length) || r.length < 1))
    throw new Error(`Invalid nanoid length: ${r.length}`);
  r.pattern ?? (r.pattern = r.length === void 0 ? to : ro(r.length)), E.init(e, r);
}), ta = /* @__PURE__ */ f("$ZodCUID", (e, r) => {
  r.pattern ?? (r.pattern = Xi), E.init(e, r);
}), ra = /* @__PURE__ */ f("$ZodCUID2", (e, r) => {
  r.pattern ?? (r.pattern = Yi), E.init(e, r);
}), na = /* @__PURE__ */ f("$ZodULID", (e, r) => {
  r.pattern ?? (r.pattern = Hi), E.init(e, r);
}), ia = /* @__PURE__ */ f("$ZodXID", (e, r) => {
  r.pattern ?? (r.pattern = Qi), E.init(e, r);
}), oa = /* @__PURE__ */ f("$ZodKSUID", (e, r) => {
  r.pattern ?? (r.pattern = eo), E.init(e, r);
}), aa = /* @__PURE__ */ f("$ZodISODateTime", (e, r) => {
  r.pattern ?? (r.pattern = ho(r)), E.init(e, r), (r.local || r.precision === -1) && (e._zod.bag.laxFormat = !0, e._zod.onattach.push((i) => {
    i._zod.bag.laxFormat = !0;
  }));
}), ua = /* @__PURE__ */ f("$ZodISODate", (e, r) => {
  r.pattern ?? (r.pattern = vo), E.init(e, r);
}), ca = /* @__PURE__ */ f("$ZodISOTime", (e, r) => {
  r.pattern ?? (r.pattern = $o(r)), E.init(e, r);
}), sa = /* @__PURE__ */ f("$ZodISODuration", (e, r) => {
  r.pattern ?? (r.pattern = no), E.init(e, r);
}), la = /* @__PURE__ */ f("$ZodIPv4", (e, r) => {
  r.pattern ?? (r.pattern = uo), E.init(e, r), e._zod.bag.format = "ipv4";
}), Xp = /^[0-9a-fA-F:.]+$/;
function Wt(e) {
  if (!Xp.test(e))
    return !1;
  try {
    return new URL(`http://[${e}]`), !0;
  } catch {
    return !1;
  }
}
u(Wt, "isValidIPv6");
var da = /* @__PURE__ */ f("$ZodIPv6", (e, r) => {
  r.pattern ?? (r.pattern = co), E.init(e, r), e._zod.bag.format = "ipv6", e._zod.check = (i) => {
    Wt(i.value) || i.issues.push({
      code: "invalid_format",
      format: "ipv6",
      input: i.value,
      inst: e,
      continue: !r.abort
    });
  };
}), ma = /* @__PURE__ */ f("$ZodMAC", (e, r) => {
  r.pattern ?? (r.pattern = so(r.delimiter)), E.init(e, r), e._zod.bag.format = "mac";
}), fa = /* @__PURE__ */ f("$ZodCIDRv4", (e, r) => {
  r.pattern ?? (r.pattern = lo), E.init(e, r);
});
function en(e) {
  let r = e.split("/");
  if (r.length !== 2)
    return !1;
  let [i, o] = r;
  if (!o)
    return !1;
  let t = Number(o);
  return `${t}` !== o || t < 0 || t > 128 ? !1 : Wt(i);
}
u(en, "isValidCIDRv6");
var pa = /* @__PURE__ */ f("$ZodCIDRv6", (e, r) => {
  r.pattern ?? (r.pattern = mo), E.init(e, r), e._zod.check = (i) => {
    en(i.value) || i.issues.push({
      code: "invalid_format",
      format: "cidrv6",
      input: i.value,
      inst: e,
      continue: !r.abort
    });
  };
});
function Gt(e) {
  if (e === "")
    return !0;
  if (/\s/.test(e) || e.length % 4 !== 0)
    return !1;
  try {
    return atob(e), !0;
  } catch {
    return !1;
  }
}
u(Gt, "isValidBase64");
var ga = /* @__PURE__ */ f("$ZodBase64", (e, r) => {
  r.pattern ?? (r.pattern = fo), E.init(e, r), e._zod.bag.contentEncoding = "base64", e._zod.check = (i) => {
    Gt(i.value) || i.issues.push({
      code: "invalid_format",
      format: "base64",
      input: i.value,
      inst: e,
      continue: !r.abort
    });
  };
});
function tn(e) {
  if (!Lr.test(e))
    return !1;
  let r = e.replace(/[-_]/g, (o) => o === "-" ? "+" : "/"), i = r.padEnd(Math.ceil(r.length / 4) * 4, "=");
  return Gt(i);
}
u(tn, "isValidBase64URL");
var va = /* @__PURE__ */ f("$ZodBase64URL", (e, r) => {
  r.pattern ?? (r.pattern = Lr), E.init(e, r), e._zod.bag.contentEncoding = "base64url", e._zod.check = (i) => {
    tn(i.value) || i.issues.push({
      code: "invalid_format",
      format: "base64url",
      input: i.value,
      inst: e,
      continue: !r.abort
    });
  };
}), $a = /* @__PURE__ */ f("$ZodE164", (e, r) => {
  r.pattern ?? (r.pattern = go), E.init(e, r);
}), Yp = /[- ]/g;
function Hp(e) {
  let r = e.length, i = 1, o = 0;
  for (; r; ) {
    let t = +e[--r];
    i ^= 1, o += i ? [0, 2, 4, 6, 8, 1, 3, 5, 7, 9][t] : t;
  }
  return o % 10 === 0;
}
u(Hp, "isLuhnAlgo");
function rn(e) {
  return Vr.test(e) ? Hp(e.replace(Yp, "")) : !1;
}
u(rn, "isValidCreditCard");
var ha = /* @__PURE__ */ f("$ZodCreditCard", (e, r) => {
  r.pattern ?? (r.pattern = Vr), E.init(e, r), e._zod.check = (i) => {
    rn(i.value) || i.issues.push({
      code: "invalid_format",
      format: "credit_card",
      input: i.value,
      inst: e,
      continue: !r.abort
    });
  };
});
function nn(e, r = null) {
  try {
    let i = e.split(".");
    if (i.length !== 3)
      return !1;
    let [o] = i;
    if (!o)
      return !1;
    let t = JSON.parse(atob(o));
    return !("typ" in t && t?.typ !== "JWT" || !t.alg || r && (!("alg" in t) || t.alg !== r));
  } catch {
    return !1;
  }
}
u(nn, "isValidJWT");
var _a = /* @__PURE__ */ f("$ZodJWT", (e, r) => {
  E.init(e, r), e._zod.check = (i) => {
    nn(i.value, r.alg) || i.issues.push({
      code: "invalid_format",
      format: "jwt",
      input: i.value,
      inst: e,
      continue: !r.abort
    });
  };
}), ya = /* @__PURE__ */ f("$ZodCustomStringFormat", (e, r) => {
  E.init(e, r), e._zod.check = (i) => {
    r.fn(i.value) || i.issues.push({
      code: "invalid_format",
      format: r.format,
      input: i.value,
      inst: e,
      continue: !r.abort
    });
  };
}), on = /* @__PURE__ */ f("$ZodNumber", (e, r) => {
  j.init(e, r), e._zod.pattern = e._zod.bag.pattern ?? Ie, e._zod.parse = (i, o) => {
    if (r.coerce)
      try {
        i.value = Number(i.value);
      } catch {
      }
    let t = i.value;
    if (typeof t == "number" && !Number.isNaN(t) && Number.isFinite(t))
      return i;
    let n = typeof t == "number" ? Number.isNaN(t) ? "NaN" : Number.isFinite(t) ? void 0 : String(t) : void 0;
    return i.issues.push({
      expected: "number",
      code: "invalid_type",
      input: t,
      inst: e,
      ...n ? { received: n } : {}
    }), i;
  };
}), ba = /* @__PURE__ */ f("$ZodNumberFormat", (e, r) => {
  Po.init(e, r), on.init(e, r);
}), Bt = /* @__PURE__ */ f("$ZodBoolean", (e, r) => {
  j.init(e, r), e._zod.pattern = bo, e._zod.parse = (i, o) => {
    if (r.coerce)
      try {
        i.value = !!i.value;
      } catch {
      }
    let t = i.value;
    return typeof t == "boolean" || i.issues.push({
      expected: "boolean",
      code: "invalid_type",
      input: t,
      inst: e
    }), i;
  };
}), an = /* @__PURE__ */ f("$ZodBigInt", (e, r) => {
  j.init(e, r), e._zod.pattern = yo, e._zod.parse = (i, o) => {
    if (r.coerce)
      try {
        i.value = BigInt(i.value);
      } catch {
      }
    return typeof i.value == "bigint" || i.issues.push({
      expected: "bigint",
      code: "invalid_type",
      input: i.value,
      inst: e
    }), i;
  };
}), ka = /* @__PURE__ */ f("$ZodBigIntFormat", (e, r) => {
  Do.init(e, r), an.init(e, r);
}), xa = /* @__PURE__ */ f("$ZodSymbol", (e, r) => {
  j.init(e, r), e._zod.parse = (i, o) => {
    let t = i.value;
    return typeof t == "symbol" || i.issues.push({
      expected: "symbol",
      code: "invalid_type",
      input: t,
      inst: e
    }), i;
  };
}), Ia = /* @__PURE__ */ f("$ZodUndefined", (e, r) => {
  j.init(e, r), e._zod.pattern = xo, e._zod.values = /* @__PURE__ */ new Set([void 0]), e._zod.parse = (i, o) => {
    let t = i.value;
    return typeof t > "u" || i.issues.push({
      expected: "undefined",
      code: "invalid_type",
      input: t,
      inst: e
    }), i;
  };
}), wa = /* @__PURE__ */ f("$ZodNull", (e, r) => {
  j.init(e, r), e._zod.pattern = ko, e._zod.values = /* @__PURE__ */ new Set([null]), e._zod.parse = (i, o) => {
    let t = i.value;
    return t === null || i.issues.push({
      expected: "null",
      code: "invalid_type",
      input: t,
      inst: e
    }), i;
  };
}), za = /* @__PURE__ */ f("$ZodAny", (e, r) => {
  j.init(e, r), e._zod.parse = (i) => i;
}), Sa = /* @__PURE__ */ f("$ZodUnknown", (e, r) => {
  j.init(e, r), e._zod.parse = (i) => i;
}), ja = /* @__PURE__ */ f("$ZodNever", (e, r) => {
  j.init(e, r), e._zod.parse = (i, o) => (i.issues.push({
    expected: "never",
    code: "invalid_type",
    input: i.value,
    inst: e
  }), i);
}), Pa = /* @__PURE__ */ f("$ZodVoid", (e, r) => {
  j.init(e, r), e._zod.parse = (i, o) => {
    let t = i.value;
    return typeof t > "u" || i.issues.push({
      expected: "void",
      code: "invalid_type",
      input: t,
      inst: e
    }), i;
  };
}), Da = /* @__PURE__ */ f("$ZodDate", (e, r) => {
  j.init(e, r), e._zod.parse = (i, o) => {
    if (r.coerce)
      try {
        i.value = new Date(i.value);
      } catch {
      }
    let t = i.value, n = t instanceof Date;
    return n && !Number.isNaN(t.getTime()) || i.issues.push({
      expected: "date",
      code: "invalid_type",
      input: t,
      ...n ? { received: "Invalid Date" } : {},
      inst: e
    }), i;
  };
});
function md(e, r, i) {
  e.issues.length && r.issues.push(...ee(i, e.issues)), r.value[i] = e.value;
}
u(md, "handleArrayResult");
var Oa = /* @__PURE__ */ f("$ZodArray", (e, r) => {
  j.init(e, r);
  let i = G.memoizer;
  i?.attach(e), e._zod.parse = (o, t) => {
    let n = o.value;
    if (!Array.isArray(n))
      return o.issues.push({
        expected: "array",
        code: "invalid_type",
        input: n,
        inst: e
      }), o;
    o.value = i ? i.alloc(e, o, Array(n.length), t) : Array(n.length);
    let a = [];
    for (let c = 0; c < n.length; c++) {
      let s = n[c], l = r.element._zod.run({
        value: s,
        issues: []
      }, t);
      l instanceof Promise ? a.push(l.then((d) => md(d, o, c))) : md(l, o, c);
    }
    return a.length ? Promise.all(a).then(() => o) : o;
  };
});
function Br(e, r, i, o, t, n) {
  let a = i in o, c = n === "optional";
  if (!(!a && c && t === "optional")) {
    if (e.issues.length) {
      if (t !== void 0 && c && !a)
        return;
      r.issues.push(...ee(i, e.issues));
    }
    if (!a && t === void 0) {
      e.issues.length || r.issues.push({
        code: "invalid_type",
        expected: "nonoptional",
        input: void 0,
        path: [i]
      });
      return;
    }
    e.value === void 0 ? a && (r.value[i] = void 0) : r.value[i] = e.value;
  }
}
u(Br, "handlePropertyResult");
var Qp = [];
function Sd(e) {
  let r = Object.keys(e.shape), i = Object.getOwnPropertySymbols(e.shape), o = i.length ? i : Qp, t = o.length ? [...r, ...o] : r;
  for (let a of t)
    if (!e.shape?.[a]?._zod?.traits?.has("$ZodType"))
      throw new Error(`Invalid element at key "${String(a)}": expected a Zod schema`);
  let n = Di(e.shape);
  return {
    ...e,
    allKeys: t,
    symbolKeys: o,
    // string-only: handleCatchall matches it against `for...in`, which never yields a symbol
    keySet: new Set(r),
    numKeys: r.length,
    optionalKeys: new Set(n)
  };
}
u(Sd, "normalizeDef");
function jd(e, r, i, o, t, n) {
  let a = [], c = t.keySet, s = t.catchall._zod, l = s.def.type, d = s.optin, m = s.optout;
  for (let g in r) {
    if (c.has(g))
      continue;
    if (g === "__proto__") {
      l === "never" && a.push(g);
      continue;
    }
    if (l === "never") {
      a.push(g);
      continue;
    }
    let v = s.run({ value: r[g], issues: [] }, o);
    v instanceof Promise ? e.push(v.then(($) => Br($, i, g, r, d, m))) : Br(v, i, g, r, d, m);
  }
  return a.length && i.issues.push({
    code: "unrecognized_keys",
    keys: a,
    input: r,
    inst: n,
    // Describes the shape of the input, not the validity of the parsed value, so it never aborts. The parse still fails; the schema's own checks just get to run first, and an enclosing intersection can reconcile the key against a sibling operand.
    continue: !0
  }), e.length ? Promise.all(e).then(() => i) : i;
}
u(jd, "handleCatchall");
var Wo = /* @__PURE__ */ new WeakMap(), Pd = /* @__PURE__ */ f("$ZodObject", (e, r) => {
  if (j.init(e, r), !Object.getOwnPropertyDescriptor(r, "shape")?.get) {
    let s = r.shape;
    Wo.set(r, s), Object.defineProperty(r, "shape", {
      get: /* @__PURE__ */ u(() => {
        let l = { ...s };
        return Object.defineProperty(r, "shape", {
          value: l
        }), Wo.set(r, l), l;
      }, "get")
    });
  }
  let o = Qe(() => Sd(r));
  O(e, "propValues", (s) => {
    let l = s.def.shape, d = {};
    for (let m in l) {
      let g = l[m]._zod;
      if (g.values) {
        Object.prototype.hasOwnProperty.call(d, m) || J(d, m, /* @__PURE__ */ new Set());
        for (let v of g.values)
          d[m].add(v);
        g.optin !== void 0 && d[m].add(void 0);
      }
    }
    return d;
  });
  let t = Te, n = r.catchall, a, c = G.memoizer;
  c?.attach(e), e._zod.parse = (s, l) => {
    a ?? (a = o.value);
    let d = s.value;
    if (!t(d))
      return s.issues.push({
        expected: "object",
        code: "invalid_type",
        input: d,
        inst: e
      }), s;
    s.value = c ? c.alloc(e, s, {}, l) : {};
    let m = [], g = a.shape;
    for (let v of a.allKeys) {
      if (v === "__proto__")
        continue;
      let $ = g[v], k = $._zod.optin, I = $._zod.optout, A = $._zod.run({ value: d[v], issues: [] }, l);
      A instanceof Promise ? m.push(A.then((w) => Br(w, s, v, d, k, I))) : Br(A, s, v, d, k, I);
    }
    return n ? jd(m, d, s, l, o.value, e) : m.length ? Promise.all(m).then(() => s) : s;
  };
}), Ua = /* @__PURE__ */ f("$ZodObjectJIT", (e, r) => {
  Pd.init(e, r);
  let i = e._zod.parse, o = Qe(() => Sd(r)), t = G.memoizer, n = /* @__PURE__ */ u((v) => {
    let $ = o.value, k = $.symbolKeys, I = new Ee(["payload", "ctx"], { shape: v, inst: e, memo: t, syms: k }), A = /* @__PURE__ */ u((R) => `shape[${R}]._zod.run({ value: input[${R}], issues: [] }, ctx)`, "parseStr"), w = /* @__PURE__ */ u((R, N) => `
          for (let i = 0; i < ${R}.issues.length; i++) {
            const iss = ${R}.issues[i];
            iss.path = iss.path ? [${N}, ...iss.path] : [${N}];
            payload.issues.push(iss);
          }`, "prefixStr");
    I.write("const input = payload.value;");
    let P = /* @__PURE__ */ Object.create(null), V = 0;
    for (let R of $.allKeys)
      P[R] = `key_${V++}`;
    I.write(t ? "const newResult = memo.alloc(inst, payload, {}, ctx);" : "const newResult = {};");
    for (let R of $.allKeys) {
      if (R === "__proto__")
        continue;
      let N = P[R], q = typeof R == "symbol" ? `syms[${k.indexOf(R)}]` : Q(R), Ot = `${q} in input`, Xl = v[R], Yl = Xl?._zod?.optin, Hl = Yl !== void 0, zf = Xl?._zod?.optout === "optional";
      if (I.write(`const ${N} = ${A(q)};`), Hl && zf) {
        let Sf = Yl === "optional" ? `${N}_present` : `${N}.value !== undefined || ${N}_present`;
        I.write(`
        const ${N}_present = ${Ot};
        if (!${N}.issues.length || ${N}_present) {
          if (${N}.issues.length) {${w(N, q)}
          }

          if (${Sf}) {
            newResult[${q}] = ${N}.value;
          }
        }

      `);
      } else Hl ? I.write(`
        if (${N}.issues.length) {${w(N, q)}
        }
        
        if (${N}.value === undefined) {
          if (${Ot}) {
            newResult[${q}] = undefined;
          }
        } else {
          newResult[${q}] = ${N}.value;
        }

      `) : I.write(`
        const ${N}_present = ${Ot};
        if (${N}.issues.length) {${w(N, q)}
        }
        if (!${N}_present && !${N}.issues.length) {
          payload.issues.push({
            code: "invalid_type",
            expected: "nonoptional",
            input: undefined,
            path: [${q}]
          });
        }

        if (${N}_present) {
          newResult[${q}] = ${N}.value;
        }

      `);
    }
    return I.write("payload.value = newResult;"), I.write("return payload;"), I.compile();
  }, "generateFastpass"), a, c = Te, s = !G.jitless, d = s && ji.value, m = r.catchall, g;
  e._zod.parse = (v, $) => {
    g ?? (g = o.value);
    let k = v.value;
    return c(k) ? s && d && $?.async === !1 && $.jitless !== !0 ? (a || (a = n(r.shape)), v = a(v, $), m ? jd([], k, v, $, g, e) : v) : i(v, $) : (v.issues.push({
      expected: "object",
      code: "invalid_type",
      input: k,
      inst: e
    }), v);
  };
});
function fd(e, r, i, o) {
  for (let n of e)
    if (n.issues.length === 0)
      return r.value = n.value, r;
  let t = e.filter((n) => !ke(n));
  return t.length === 1 ? (r.value = t[0].value, t[0]) : (r.issues.push({
    code: "invalid_union",
    input: r.value,
    inst: i,
    errors: e.map((n) => n.issues.map((a) => te(a, o, M())))
  }), r);
}
u(fd, "handleUnionResults");
var qt = /* @__PURE__ */ f("$ZodUnion", (e, r) => {
  j.init(e, r), O(e, "optin", (o) => o.def.options.some((t) => t._zod.optin === "defaulted") ? "defaulted" : o.def.options.some((t) => t._zod.optin !== void 0) ? "optional" : void 0), O(e, "optout", (o) => o.def.options.some((t) => t._zod.optout === "optional") ? "optional" : void 0), O(e, "values", (o) => {
    if (o.def.options.every((t) => t._zod.values))
      return new Set(o.def.options.flatMap((t) => Array.from(t._zod.values)));
  }), O(e, "pattern", (o) => {
    if (o.def.options.every((t) => t._zod.pattern)) {
      let t = o.def.options.map((n) => n._zod.pattern);
      return new RegExp(`^(${t.map((n) => Tt(n.source)).join("|")})$`);
    }
  });
  let i = r.options.length === 1 ? r.options[0]._zod.run : null;
  e._zod.parse = (o, t) => {
    if (i)
      return i(o, t);
    let n = !1, a = [];
    for (let c of r.options) {
      let s = c._zod.run({
        value: o.value,
        issues: []
      }, t);
      if (s instanceof Promise)
        a.push(s), n = !0;
      else {
        if (s.issues.length === 0)
          return s;
        a.push(s);
      }
    }
    return n ? Promise.all(a).then((c) => fd(c, o, e, t)) : fd(a, o, e, t);
  };
});
function pd(e, r, i, o) {
  let t = [];
  for (let n = 0; n < e.length; n++)
    e[n].issues.length === 0 && t.push(n);
  return t.length === 1 ? (r.value = e[t[0]].value, r) : (t.length === 0 ? r.issues.push({
    code: "invalid_union",
    input: r.value,
    inst: i,
    errors: e.map((n) => n.issues.map((a) => te(a, o, M())))
  }) : r.issues.push({
    code: "invalid_union",
    input: r.value,
    inst: i,
    errors: [],
    inclusive: !1,
    matches: t
  }), r);
}
u(pd, "handleExclusiveUnionResults");
var Na = /* @__PURE__ */ f("$ZodXor", (e, r) => {
  qt.init(e, r), r.inclusive = !1;
  let i = r.options.length === 1 ? r.options[0]._zod.run : null;
  e._zod.parse = (o, t) => {
    if (i)
      return i(o, t);
    let n = !1, a = [];
    for (let c of r.options) {
      let s = c._zod.run({
        value: o.value,
        issues: []
      }, t);
      s instanceof Promise ? (a.push(s), n = !0) : a.push(s);
    }
    return n ? Promise.all(a).then((c) => pd(c, o, e, t)) : pd(a, o, e, t);
  };
});
function Ta(e, r) {
  let i = e._zod, o = i.bag.optionsMap;
  if (!o) {
    o = /* @__PURE__ */ new Map();
    let { options: t, discriminator: n } = i.def;
    for (let a of t)
      for (let c of a._zod.propValues?.[n] ?? [])
        o.has(c) || o.set(c, a);
    i.bag.optionsMap = o;
  }
  return o.get(r);
}
u(Ta, "getDiscriminatedOption");
var Za = /* @__PURE__ */ f("$ZodDiscriminatedUnion", (e, r) => {
  r.inclusive = !1, qt.init(e, r);
  let i = e._zod.parse;
  O(e, "propValues", (t) => {
    let n = {};
    for (let a of t.def.options) {
      let c = a._zod.propValues;
      if (!c || Object.keys(c).length === 0)
        throw new Error(`Invalid discriminated union option at index "${t.def.options.indexOf(a)}"`);
      for (let [s, l] of Object.entries(c)) {
        Object.prototype.hasOwnProperty.call(n, s) || J(n, s, /* @__PURE__ */ new Set());
        for (let d of l)
          n[s].add(d);
      }
    }
    return n;
  }), r.options.forEach((t, n) => {
    let a = Wo.get(t._zod.def);
    if (a && !Object.prototype.hasOwnProperty.call(a, r.discriminator))
      throw new Error(`Invalid discriminated union option at index "${n}"`);
  });
  let o = Qe(() => {
    let t = r.options, n = /* @__PURE__ */ new Map();
    for (let a of t) {
      let c = a._zod.propValues?.[r.discriminator];
      if (!c || c.size === 0)
        throw new Error(`Invalid discriminated union option at index "${r.options.indexOf(a)}"`);
      for (let s of c) {
        if (n.has(s))
          throw new Error(`Duplicate discriminator value "${String(s)}"`);
        n.set(s, a);
      }
    }
    return n;
  });
  e._zod.parse = (t, n) => {
    let a = t.value;
    if (!Te(a))
      return t.issues.push({
        code: "invalid_type",
        expected: "object",
        input: a,
        inst: e
      }), t;
    let c = o.value.get(a?.[r.discriminator]);
    return c ? c._zod.run(t, n) : r.unionFallback || n.direction === "backward" ? i(t, n) : (t.issues.push({
      code: "invalid_union",
      errors: [],
      note: "No matching discriminator",
      discriminator: r.discriminator,
      options: Array.from(o.value.keys()),
      input: a,
      path: [r.discriminator],
      inst: e
    }), t);
  };
}), Aa = /* @__PURE__ */ f("$ZodIntersection", (e, r) => {
  j.init(e, r), e._zod.parse = (i, o) => {
    let t = i.value, n = r.left._zod.run({ value: t, issues: [] }, o), a = r.right._zod.run({ value: t, issues: [] }, o);
    return n instanceof Promise || a instanceof Promise ? Promise.all([n, a]).then(([s, l]) => gd(i, s, l)) : gd(i, n, a);
  };
});
function at(e, r) {
  if (e === r)
    return { valid: !0, data: e };
  if (e instanceof Date && r instanceof Date && +e == +r)
    return { valid: !0, data: e };
  if (se(e) && se(r)) {
    let i = Object.keys(r), o = Object.keys(e).filter((n) => i.indexOf(n) !== -1), t = { ...e, ...r };
    Object.prototype.hasOwnProperty.call(t, "__proto__") && delete t.__proto__;
    for (let n of o) {
      if (n === "__proto__")
        continue;
      let a = at(e[n], r[n]);
      if (!a.valid)
        return {
          valid: !1,
          mergeErrorPath: [n, ...a.mergeErrorPath]
        };
      t[n] = a.data;
    }
    return { valid: !0, data: t };
  }
  if (Array.isArray(e) && Array.isArray(r)) {
    if (e.length !== r.length)
      return { valid: !1, mergeErrorPath: [] };
    let i = [];
    for (let o = 0; o < e.length; o++) {
      let t = e[o], n = r[o], a = at(t, n);
      if (!a.valid)
        return {
          valid: !1,
          mergeErrorPath: [o, ...a.mergeErrorPath]
        };
      i.push(a.data);
    }
    return { valid: !0, data: i };
  }
  return { valid: !1, mergeErrorPath: [] };
}
u(at, "mergeValues");
function gd(e, r, i) {
  let o = /* @__PURE__ */ new Map(), t, n = /* @__PURE__ */ new Map(), a = /* @__PURE__ */ u((l, d) => {
    let m;
    if (l.code === "unrecognized_keys" && !l.path?.length)
      t ?? (t = l), m = l.keys;
    else if (l.code === "invalid_key" && l.origin === "record" && l.path?.length === 1) {
      let g = String(l.path[0]);
      n.has(g) || n.set(g, l), m = [g];
    } else
      return !1;
    for (let g of m)
      o.has(g) || o.set(g, {}), o.get(g)[d] = !0;
    return !0;
  }, "collect");
  for (let l of r.issues)
    a(l, "l") || e.issues.push(l);
  for (let l of i.issues)
    a(l, "r") || e.issues.push(l);
  let c = [...o].filter(([, l]) => l.l && l.r).map(([l]) => l);
  if (c.length) {
    let l = t ? c.filter((d) => t.keys.includes(d)) : [];
    l.length && e.issues.push({ ...t, keys: l });
    for (let d of c)
      !l.includes(d) && n.has(d) && e.issues.push(n.get(d));
  }
  let s = at(r.value, i.value);
  if (!s.valid) {
    if (ke(e))
      return e;
    throw new Error(`Unmergable intersection. Error path: ${JSON.stringify(s.mergeErrorPath)}`);
  }
  return e.value = s.data, e;
}
u(gd, "handleIntersectionResults");
var un = /* @__PURE__ */ f("$ZodTuple", (e, r) => {
  j.init(e, r);
  let i = r.items, o = G.memoizer;
  o?.attach(e), e._zod.parse = (t, n) => {
    let a = t.value;
    if (!Array.isArray(a))
      return t.issues.push({
        input: a,
        inst: e,
        expected: "tuple",
        code: "invalid_type"
      }), t;
    t.value = o ? o.alloc(e, t, [], n) : [];
    let c = [], s = vd(i, "optin"), l = vd(i, "optout");
    if (!r.rest) {
      if (a.length < s)
        return t.issues.push({
          code: "too_small",
          minimum: s,
          inclusive: !0,
          input: a,
          inst: e,
          origin: "array"
        }), t;
      a.length > i.length && t.issues.push({
        code: "too_big",
        maximum: i.length,
        inclusive: !0,
        input: a,
        inst: e,
        origin: "array"
      });
    }
    let d = new Array(i.length);
    for (let m = 0; m < i.length; m++) {
      let g = i[m]._zod.run({ value: a[m], issues: [] }, n);
      g instanceof Promise ? c.push(g.then((v) => {
        d[m] = v;
      })) : d[m] = g;
    }
    if (r.rest) {
      let m = i.length - 1, g = a.slice(i.length);
      for (let v of g) {
        m++;
        let $ = r.rest._zod.run({ value: v, issues: [] }, n);
        $ instanceof Promise ? c.push($.then((k) => $d(k, t, m))) : $d($, t, m);
      }
    }
    return c.length ? Promise.all(c).then(() => hd(d, t, i, a, l)) : hd(d, t, i, a, l);
  };
});
function vd(e, r) {
  for (let i = e.length - 1; i >= 0; i--)
    if (!(r === "optin" ? e[i]._zod.optin !== void 0 : e[i]._zod.optout === "optional"))
      return i + 1;
  return 0;
}
u(vd, "getTupleOptStart");
function $d(e, r, i) {
  e.issues.length && r.issues.push(...ee(i, e.issues)), r.value[i] = e.value;
}
u($d, "handleTupleResult");
function hd(e, r, i, o, t) {
  for (let n = 0; n < i.length; n++) {
    let a = e[n], c = n < o.length;
    if (!c && n >= t && i[n]._zod.optin === "optional") {
      r.value.length = n;
      break;
    }
    if (a.issues.length) {
      if (!c && n >= t) {
        r.value.length = n;
        break;
      }
      r.issues.push(...ee(n, a.issues));
    }
    r.value[n] = a.value;
  }
  for (let n = r.value.length - 1; n >= o.length && (i[n]._zod.optout === "optional" && r.value[n] === void 0); n--)
    r.value.length = n;
  return r;
}
u(hd, "handleTupleResults");
var Ea = /* @__PURE__ */ f("$ZodRecord", (e, r) => {
  j.init(e, r);
  let i = G.memoizer;
  i?.attach(e), e._zod.parse = (o, t) => {
    let n = o.value;
    if (!se(n))
      return o.issues.push({
        expected: "record",
        code: "invalid_type",
        input: n,
        inst: e
      }), o;
    let a = [], c = r.keyType._zod.values;
    if (c && !r.partial) {
      o.value = i ? i.alloc(e, o, {}, t) : {};
      let s = /* @__PURE__ */ new Set();
      for (let d of c)
        if (typeof d == "string" || typeof d == "number" || typeof d == "symbol") {
          if (s.add(typeof d == "number" ? d.toString() : d), d === "__proto__")
            continue;
          let m = r.keyType._zod.run({ value: d, issues: [] }, t);
          if (m instanceof Promise)
            throw new Error("Async schemas not supported in object keys currently");
          if (m.issues.length) {
            o.issues.push({
              code: "invalid_key",
              origin: "record",
              issues: m.issues.map(($) => te($, t, M())),
              input: d,
              path: [d],
              inst: e
            });
            continue;
          }
          let g = m.value;
          if (g === "__proto__")
            continue;
          let v = r.valueType._zod.run({ value: n[d], issues: [] }, t);
          v instanceof Promise ? a.push(v.then(($) => {
            $.issues.length && o.issues.push(...ee(d, $.issues)), o.value[g] = $.value;
          })) : (v.issues.length && o.issues.push(...ee(d, v.issues)), o.value[g] = v.value);
        }
      let l;
      for (let d in n)
        if (!s.has(d))
          if (r.mode === "loose") {
            if (d === "__proto__")
              continue;
            o.value[d] = n[d];
          } else
            l = l ?? [], l.push(d);
      l && l.length > 0 && o.issues.push({
        code: "unrecognized_keys",
        input: n,
        inst: e,
        keys: l,
        continue: !0
      });
    } else {
      o.value = i ? i.alloc(e, o, {}, t) : {};
      let s;
      for (let l of Reflect.ownKeys(n)) {
        if (l === "__proto__" || !Object.prototype.propertyIsEnumerable.call(n, l))
          continue;
        let d = r.keyType._zod.run({ value: l, issues: [] }, t);
        if (d instanceof Promise)
          throw new Error("Async schemas not supported in object keys currently");
        if (typeof l == "string" && Ie.test(l) && d.issues.length) {
          let $ = r.keyType._zod.run({ value: Number(l), issues: [] }, t);
          if ($ instanceof Promise)
            throw new Error("Async schemas not supported in object keys currently");
          $.issues.length === 0 && (d = $);
        }
        if (d.issues.length) {
          r.mode === "loose" ? o.value[l] = n[l] : c ? (s = s ?? [], s.push(l)) : o.issues.push({
            code: "invalid_key",
            origin: "record",
            issues: d.issues.map(($) => te($, t, M())),
            input: l,
            path: [l],
            inst: e
          });
          continue;
        }
        let g = d.value;
        if (g === "__proto__")
          continue;
        let v = r.valueType._zod.run({ value: n[l], issues: [] }, t);
        v instanceof Promise ? a.push(v.then(($) => {
          $.issues.length && o.issues.push(...ee(l, $.issues)), o.value[g] = $.value;
        })) : (v.issues.length && o.issues.push(...ee(l, v.issues)), o.value[g] = v.value);
      }
      s && s.length > 0 && o.issues.push({
        code: "unrecognized_keys",
        input: n,
        inst: e,
        keys: s,
        continue: !0
      });
    }
    return a.length ? Promise.all(a).then(() => o) : o;
  };
}), Ca = /* @__PURE__ */ f("$ZodMap", (e, r) => {
  j.init(e, r);
  let i = G.memoizer;
  i?.attach(e), e._zod.parse = (o, t) => {
    let n = o.value;
    if (!(n instanceof Map))
      return o.issues.push({
        expected: "map",
        code: "invalid_type",
        input: n,
        inst: e
      }), o;
    let a = [];
    o.value = i ? i.alloc(e, o, /* @__PURE__ */ new Map(), t) : /* @__PURE__ */ new Map();
    for (let [c, s] of n) {
      let l = r.keyType._zod.run({ value: c, issues: [] }, t), d = r.valueType._zod.run({ value: s, issues: [] }, t);
      l instanceof Promise || d instanceof Promise ? a.push(Promise.all([l, d]).then(([m, g]) => {
        _d(m, g, o, c, n, e, t);
      })) : _d(l, d, o, c, n, e, t);
    }
    return a.length ? Promise.all(a).then(() => o) : o;
  };
});
function _d(e, r, i, o, t, n, a) {
  e.issues.length && (Et.has(typeof o) ? i.issues.push(...ee(o, e.issues)) : i.issues.push({
    code: "invalid_key",
    origin: "map",
    input: t,
    inst: n,
    issues: e.issues.map((c) => te(c, a, M()))
  })), r.issues.length && (Et.has(typeof o) ? i.issues.push(...ee(o, r.issues)) : i.issues.push({
    origin: "map",
    code: "invalid_element",
    input: t,
    inst: n,
    key: o,
    issues: r.issues.map((c) => te(c, a, M()))
  })), i.value.set(e.value, r.value);
}
u(_d, "handleMapResult");
var La = /* @__PURE__ */ f("$ZodSet", (e, r) => {
  j.init(e, r);
  let i = G.memoizer;
  i?.attach(e), e._zod.parse = (o, t) => {
    let n = o.value;
    if (!(n instanceof Set))
      return o.issues.push({
        input: n,
        inst: e,
        expected: "set",
        code: "invalid_type"
      }), o;
    let a = [];
    o.value = i ? i.alloc(e, o, /* @__PURE__ */ new Set(), t) : /* @__PURE__ */ new Set();
    for (let c of n) {
      let s = r.valueType._zod.run({ value: c, issues: [] }, t);
      s instanceof Promise ? a.push(s.then((l) => yd(l, o))) : yd(s, o);
    }
    return a.length ? Promise.all(a).then(() => o) : o;
  };
});
function yd(e, r) {
  e.issues.length && r.issues.push(...e.issues), r.value.add(e.value);
}
u(yd, "handleSetResult");
var Va = /* @__PURE__ */ f("$ZodEnum", (e, r) => {
  j.init(e, r);
  let i = Nt(r.entries), o = new Set(i);
  e._zod.values = o;
  let t = i.filter((n) => Et.has(typeof n));
  e._zod.pattern = new RegExp(t.length ? `^(${t.map((n) => le(n.toString())).join("|")})$` : "^[^\\s\\S]$"), e._zod.parse = (n, a) => {
    let c = n.value;
    return o.has(c) || n.issues.push({
      code: "invalid_value",
      values: i,
      input: c,
      inst: e
    }), n;
  };
}), Ra = /* @__PURE__ */ f("$ZodLiteral", (e, r) => {
  j.init(e, r);
  let i = new Set(r.values);
  e._zod.values = i, e._zod.pattern = new RegExp(r.values.length ? `^(${r.values.map((o) => typeof o == "string" ? le(o) : o ? le(o.toString()) : String(o)).join("|")})$` : "^[^\\s\\S]$"), e._zod.parse = (o, t) => {
    let n = o.value;
    return i.has(n) || o.issues.push({
      code: "invalid_value",
      values: r.values,
      input: n,
      inst: e
    }), o;
  };
}), Fa = /* @__PURE__ */ f("$ZodFile", (e, r) => {
  j.init(e, r), e._zod.parse = (i, o) => {
    let t = i.value;
    return t instanceof File || i.issues.push({
      expected: "file",
      code: "invalid_type",
      input: t,
      inst: e
    }), i;
  };
}), Ja = /* @__PURE__ */ f("$ZodTransform", (e, r) => {
  j.init(e, r), e._zod.optin = "optional", G.memoizer?.guard(e), e._zod.parse = (i, o) => {
    if (o.direction === "backward")
      throw new xe(e.constructor.name);
    let t = r.transform(i.value, i);
    if (o.async)
      return (t instanceof Promise ? t : Promise.resolve(t)).then((a) => (i.value = a, i));
    if (t instanceof Promise)
      throw new re();
    return i.value = t, i;
  };
});
function bd(e, r) {
  return e.value = r.issues.length ? void 0 : r.value, e;
}
u(bd, "handleOptionalResult");
var cn = /* @__PURE__ */ f("$ZodOptional", (e, r) => {
  j.init(e, r), O(e, "optin", (i) => i.def.innerType._zod.optin === "defaulted" ? "defaulted" : "optional"), e._zod.optout = "optional", O(e, "values", (i) => {
    let o = i.def.innerType._zod.values;
    return o ? /* @__PURE__ */ new Set([...o, void 0]) : void 0;
  }), O(e, "pattern", (i) => {
    let o = i.def.innerType._zod.pattern;
    return o ? new RegExp(`^(${Tt(o.source)})?$`) : void 0;
  }), e._zod.parse = (i, o) => {
    if (i.value === void 0) {
      if (r.innerType._zod.optin !== "defaulted")
        return i;
      let t = r.innerType._zod.run({ value: i.value, issues: [] }, o);
      return t instanceof Promise ? t.then((n) => bd(i, n)) : bd(i, t);
    }
    return r.innerType._zod.run(i, o);
  };
}), Ma = /* @__PURE__ */ f("$ZodExactOptional", (e, r) => {
  cn.init(e, r), O(e, "values", (i) => i.def.innerType._zod.values), O(e, "pattern", (i) => i.def.innerType._zod.pattern), e._zod.parse = (i, o) => r.innerType._zod.run(i, o);
}), Ka = /* @__PURE__ */ f("$ZodNullable", (e, r) => {
  j.init(e, r), O(e, "optin", (i) => i.def.innerType._zod.optin), O(e, "optout", (i) => i.def.innerType._zod.optout), O(e, "pattern", (i) => {
    let o = i.def.innerType._zod.pattern;
    return o ? new RegExp(`^(${Tt(o.source)}|null)$`) : void 0;
  }), O(e, "values", (i) => i.def.innerType._zod.values ? /* @__PURE__ */ new Set([...i.def.innerType._zod.values, null]) : void 0), e._zod.parse = (i, o) => i.value === null ? i : r.innerType._zod.run(i, o);
}), Wa = /* @__PURE__ */ f("$ZodDefault", (e, r) => {
  j.init(e, r), e._zod.optin = "defaulted", O(e, "values", (i) => i.def.innerType._zod.values), e._zod.parse = (i, o) => {
    if (o.direction === "backward")
      return r.innerType._zod.run(i, o);
    if (i.value === void 0)
      return i.value = r.defaultValue, i;
    let t = r.innerType._zod.run(i, o);
    return t instanceof Promise ? t.then((n) => kd(n, r)) : kd(t, r);
  };
});
function kd(e, r) {
  return e.value === void 0 && (e.value = r.defaultValue), e;
}
u(kd, "handleDefaultResult");
var Ga = /* @__PURE__ */ f("$ZodPrefault", (e, r) => {
  j.init(e, r), e._zod.optin = "defaulted", O(e, "values", (i) => i.def.innerType._zod.values), e._zod.parse = (i, o) => (o.direction === "backward" || i.value === void 0 && (i.value = r.defaultValue), r.innerType._zod.run(i, o));
}), Ba = /* @__PURE__ */ f("$ZodNonOptional", (e, r) => {
  j.init(e, r), O(e, "values", (i) => {
    let o = i.def.innerType._zod.values;
    return o ? new Set([...o].filter((t) => t !== void 0)) : void 0;
  }), e._zod.parse = (i, o) => {
    let t = r.innerType._zod.run(i, o);
    return t instanceof Promise ? t.then((n) => xd(n, e)) : xd(t, e);
  };
});
function xd(e, r) {
  return !e.issues.length && e.value === void 0 && e.issues.push({
    code: "invalid_type",
    expected: "nonoptional",
    input: e.value,
    inst: r
  }), e;
}
u(xd, "handleNonOptionalResult");
var qa = /* @__PURE__ */ f("$ZodSuccess", (e, r) => {
  j.init(e, r), e._zod.parse = (i, o) => {
    if (o.direction === "backward")
      throw new xe("ZodSuccess");
    let t = r.innerType._zod.run(i, o);
    return t instanceof Promise ? t.then((n) => (i.value = n.issues.length === 0, i)) : (i.value = t.issues.length === 0, i);
  };
});
function Id(e, r, i, o) {
  return r.issues.length ? (e.value = i.catchValue({
    ...r,
    value: e.value,
    error: {
      issues: r.issues.map((t) => te(t, o, M()))
    },
    input: e.value
  }), e) : (e.value = r.value, r.memo && (e.memo = !0), e);
}
u(Id, "handleCatchResult");
var Xa = /* @__PURE__ */ f("$ZodCatch", (e, r) => {
  j.init(e, r), O(e, "optin", (i) => i.def.innerType._zod.optin === "defaulted" ? "defaulted" : "optional"), O(e, "optout", (i) => i.def.innerType._zod.optout), O(e, "values", (i) => i.def.innerType._zod.values), e._zod.parse = (i, o) => {
    if (o.direction === "backward")
      return r.innerType._zod.run(i, o);
    let t = r.innerType._zod.run({ value: i.value, issues: [] }, o);
    return t instanceof Promise ? t.then((n) => Id(i, n, r, o)) : Id(i, t, r, o);
  };
}), Ya = /* @__PURE__ */ f("$ZodNaN", (e, r) => {
  j.init(e, r), e._zod.parse = (i, o) => ((typeof i.value != "number" || !Number.isNaN(i.value)) && i.issues.push({
    input: i.value,
    inst: e,
    expected: "nan",
    code: "invalid_type"
  }), i);
}), sn = /* @__PURE__ */ f("$ZodPipe", (e, r) => {
  j.init(e, r), O(e, "values", (i) => i.def.in._zod.values), O(e, "optin", (i) => i.def.in._zod.optin), O(e, "optout", (i) => i.def.out._zod.optout), O(e, "propValues", (i) => i.def.in._zod.propValues), e._zod.parse = (i, o) => {
    if (o.direction === "backward") {
      let n = r.out._zod.run(i, o);
      return n instanceof Promise ? n.then((a) => Kr(a, r.in, o)) : Kr(n, r.in, o);
    }
    let t = r.in._zod.run(i, o);
    return t instanceof Promise ? t.then((n) => Kr(n, r.out, o)) : Kr(t, r.out, o);
  };
});
function Kr(e, r, i) {
  return e.issues.some((o) => o.code !== "unrecognized_keys") ? (e.aborted = !0, e) : r._zod.run({ value: e.value, issues: e.issues }, i);
}
u(Kr, "handlePipeResult");
var Xt = /* @__PURE__ */ f("$ZodCodec", (e, r) => {
  j.init(e, r), O(e, "values", (i) => i.def.in._zod.values), O(e, "optin", (i) => i.def.in._zod.optin), O(e, "optout", (i) => i.def.out._zod.optout), O(e, "propValues", (i) => i.def.in._zod.propValues), e._zod.parse = (i, o) => {
    if ((o.direction || "forward") === "forward") {
      let n = r.in._zod.run(i, o);
      return n instanceof Promise ? n.then((a) => Wr(a, r, o)) : Wr(n, r, o);
    } else {
      let n = r.out._zod.run(i, o);
      return n instanceof Promise ? n.then((a) => Wr(a, r, o)) : Wr(n, r, o);
    }
  };
});
function Wr(e, r, i) {
  if (e.issues.length)
    return e.aborted = !0, e;
  if ((i.direction || "forward") === "forward") {
    let t = r.transform(e.value, e);
    return t instanceof Promise ? t.then((n) => Gr(e, n, r.out, i)) : Gr(e, t, r.out, i);
  } else {
    let t = r.reverseTransform(e.value, e);
    return t instanceof Promise ? t.then((n) => Gr(e, n, r.in, i)) : Gr(e, t, r.in, i);
  }
}
u(Wr, "handleCodecAResult");
function Gr(e, r, i, o) {
  return e.issues.length ? (e.aborted = !0, e) : i._zod.run({ value: r, issues: e.issues }, o);
}
u(Gr, "handleCodecTxResult");
var Ha = /* @__PURE__ */ f("$ZodPreprocess", (e, r) => {
  sn.init(e, r);
}), Qa = /* @__PURE__ */ f("$ZodReadonly", (e, r) => {
  j.init(e, r), O(e, "propValues", (i) => i.def.innerType._zod.propValues), O(e, "values", (i) => i.def.innerType._zod.values), O(e, "optin", (i) => i.def.innerType?._zod?.optin), O(e, "optout", (i) => i.def.innerType?._zod?.optout), e._zod.parse = (i, o) => {
    if (o.direction === "backward")
      return r.innerType._zod.run(i, o);
    let t = r.innerType._zod.run(i, o);
    return t instanceof Promise ? t.then(wd) : wd(t);
  };
});
function wd(e) {
  return e.memo || (e.value = Object.freeze(e.value)), e;
}
u(wd, "handleReadonlyResult");
var eu = /* @__PURE__ */ f("$ZodTemplateLiteral", (e, r) => {
  j.init(e, r);
  let i = [];
  for (let o of r.parts)
    if (typeof o == "object" && o !== null) {
      if (!o._zod.pattern)
        throw new Error(`Invalid template literal part, no pattern found: ${[...o._zod.traits].shift()}`);
      let t = o._zod.pattern instanceof RegExp ? o._zod.pattern.source : o._zod.pattern;
      if (!t)
        throw new Error(`Invalid template literal part: ${o._zod.traits}`);
      let n = t.startsWith("^") ? 1 : 0, a = t.endsWith("$") ? t.length - 1 : t.length;
      i.push(t.slice(n, a));
    } else if (o === null || Pi.has(typeof o))
      i.push(le(`${o}`));
    else
      throw new Error(`Invalid template literal part: ${o}`);
  e._zod.pattern = new RegExp(`^${i.join("")}$`), e._zod.parse = (o, t) => typeof o.value != "string" ? (o.issues.push({
    input: o.value,
    inst: e,
    expected: "string",
    code: "invalid_type"
  }), o) : (e._zod.pattern.lastIndex = 0, e._zod.pattern.test(o.value) || o.issues.push({
    input: o.value,
    inst: e,
    code: "invalid_format",
    format: r.format ?? "template_literal",
    pattern: e._zod.pattern.source
  }), o);
}), tu = /* @__PURE__ */ f("$ZodFunction", (e, r) => (j.init(e, r), Object.defineProperty(e, "_def", { value: r }), e._zod.def = r, e.implement = (i) => {
  if (typeof i != "function")
    throw new Error("implement() must be called with a function");
  return Object.defineProperty(function(...o) {
    let t = e._def.input ? Pr(e._def.input, o) : o, n = Reflect.apply(i, this, t);
    return e._def.output ? Pr(e._def.output, n) : n;
  }, "_zod", { value: e._zod, enumerable: !1 });
}, e.implementAsync = (i) => {
  if (typeof i != "function")
    throw new Error("implementAsync() must be called with a function");
  return Object.defineProperty(async function(...o) {
    let t = e._def.input ? await Dr(e._def.input, o) : o, n = await Reflect.apply(i, this, t);
    return e._def.output ? await Dr(e._def.output, n) : n;
  }, "_zod", { value: e._zod, enumerable: !1 });
}, e._zod.parse = (i, o) => typeof i.value != "function" ? (i.issues.push({
  code: "invalid_type",
  expected: "function",
  input: i.value,
  inst: e
}), i) : (e._def.output && e._def.output._zod.def.type === "promise" ? i.value = e.implementAsync(i.value) : i.value = e.implement(i.value), i), e.input = (...i) => {
  let o = e.constructor;
  return Array.isArray(i[0]) ? new o({
    type: "function",
    input: new un({
      type: "tuple",
      items: i[0],
      rest: i[1]
    }),
    output: e._def.output
  }) : new o({
    type: "function",
    input: i[0],
    output: e._def.output
  });
}, e.output = (i) => {
  let o = e.constructor;
  return new o({
    type: "function",
    input: e._def.input,
    output: i
  });
}, e)), ru = /* @__PURE__ */ f("$ZodPromise", (e, r) => {
  j.init(e, r), e._zod.parse = (i, o) => Promise.resolve(i.value).then((t) => r.innerType._zod.run({ value: t, issues: [] }, o));
}), Yt = /* @__PURE__ */ f("$ZodLazy", (e, r) => {
  j.init(e, r), zi(e._zod, "innerType", () => {
    let i = r;
    return i._cachedInner || (i._cachedInner = r.getter()), i._cachedInner;
  }), O(e, "pattern", (i) => i.innerType?._zod?.pattern), O(e, "propValues", (i) => i.innerType?._zod?.propValues), O(e, "optin", (i) => i.innerType?._zod?.optin ?? void 0), O(e, "optout", (i) => i.innerType?._zod?.optout ?? void 0), e._zod.parse = (i, o) => e._zod.innerType._zod.run(i, o);
}), nu = /* @__PURE__ */ f("$ZodCustom", (e, r) => {
  L.init(e, r), j.init(e, r), e._zod.parse = (i, o) => i, e._zod.check = (i) => {
    let o = i.value, t = r.fn(o);
    if (t instanceof Promise)
      return t.then((n) => zd(n, i, o, e));
    zd(t, i, o, e);
  };
});
function zd(e, r, i, o) {
  if (!e) {
    let t = {
      code: "custom",
      input: i,
      inst: o,
      // incorporates params.error into issue reporting
      path: [...o._zod.def.path ?? []],
      // incorporates params.error into issue reporting
      continue: !o._zod.def.abort
      // params: inst._zod.def.params,
    };
    o._zod.def.params && (t.params = o._zod.def.params), r.issues.push(et(t));
  }
}
u(zd, "handleRefineResult");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/memoizer.js
var mn = class extends Error {
  static {
    u(this, "$ZodCyclicError");
  }
  constructor() {
    super("Cannot parse a reference cycle that closes through a transform"), this.name = "ZodCyclicError";
  }
}, ou = "~memo", Od = [];
function iu(e) {
  return e.map((r) => r.path ? { ...r, path: r.path.slice() } : { ...r });
}
u(iu, "cloneIssues");
var Ud = /* @__PURE__ */ new WeakMap();
function au(e, r) {
  let i = Ud.get(e);
  if (i !== void 0)
    return i;
  if (r.has(e))
    return !0;
  r.add(e);
  let o = !1, t = /* @__PURE__ */ u((c) => {
    !o && c?._zod && au(c, r) && (o = !0);
  }, "check"), n = e._zod.def, a = n.type;
  switch (a) {
    case "object": {
      for (let c of Reflect.ownKeys(n.shape))
        t(n.shape[c]);
      t(n.catchall);
      break;
    }
    case "array":
      t(n.element);
      break;
    case "tuple":
      for (let c of n.items)
        t(c);
      t(n.rest);
      break;
    case "record":
    case "map":
      t(n.keyType), t(n.valueType);
      break;
    case "set":
      t(n.valueType);
      break;
    case "union":
      for (let c of n.options)
        t(c);
      break;
    case "intersection":
      t(n.left), t(n.right);
      break;
    case "optional":
    case "nullable":
    case "default":
    case "prefault":
    case "catch":
    case "readonly":
    case "nonoptional":
    case "promise":
    case "success":
      t(n.innerType);
      break;
    case "pipe":
      t(n.in), t(n.out);
      break;
    case "function":
      t(n.input), t(n.output);
      break;
    // reading `_zod.innerType` resolves the getter once and caches it
    case "lazy":
      t(e._zod.innerType);
      break;
    // a leaf by choice: `parts` are regex fragments, not data positions
    case "template_literal":
    // leaves
    case "string":
    case "number":
    case "int":
    case "boolean":
    case "bigint":
    case "symbol":
    case "undefined":
    case "null":
    case "void":
    case "never":
    case "any":
    case "unknown":
    case "date":
    case "nan":
    case "enum":
    case "literal":
    case "file":
    case "transform":
    case "custom":
      break;
    default:
      for (let c in n) {
        let s = Object.getOwnPropertyDescriptor(n, c);
        if (!s || s.get)
          continue;
        let l = s.value;
        if (!(!l || typeof l != "object")) {
          if (l._zod)
            t(l);
          else if (Array.isArray(l))
            for (let d of l)
              t(d);
        }
      }
  }
  return r.delete(e), Ud.set(e, o), o;
}
u(au, "isRecursive");
function uu(e) {
  return au(e, /* @__PURE__ */ new Set());
}
u(uu, "isRecursiveSchema");
function eg(e, r) {
  let i = e.buckets.get(r);
  return i || (i = /* @__PURE__ */ new Map(), e.buckets.set(r, i)), i;
}
u(eg, "bucketFor");
var ln, dn = [], tg = {
  alloc(e, r, i) {
    let o = ln;
    if (!o)
      return i;
    ln = void 0;
    let t = { value: i, issues: null };
    return o.set(r.value, t), dn.push(t), i;
  },
  guard(e) {
    var r;
    (r = e._zod).deferred ?? (r.deferred = []), e._zod.deferred.push(() => {
      let i = e._zod.parse, o = /* @__PURE__ */ u((t, n) => {
        if (n.direction !== "backward" && fn(n, t.value))
          throw new mn();
        return i(t, n);
      }, "wrapped");
      e._zod.parse = o, e._zod.run === i && (e._zod.run = o);
    });
  },
  attach(e) {
    var r;
    let i, o, t;
    (r = e._zod).deferred ?? (r.deferred = []), e._zod.deferred.push(() => {
      let n = e._zod.parse, a = /* @__PURE__ */ u((c, s) => {
        if (i === void 0 && (i = au(e, /* @__PURE__ */ new Set()), !i))
          return e._zod.parse = n, e._zod.run === a && (e._zod.run = n), n(c, s);
        let l = c.value;
        if (l === null || typeof l != "object")
          return n(c, s);
        let d = s[ou];
        d || (d = { buckets: /* @__PURE__ */ new Map(), backEdges: void 0 }, s[ou] = d);
        let m;
        o === s ? m = t : (m = eg(d, e), o = s, t = m);
        let g = m.get(l);
        if (g)
          return c.value = g.value, g.issues ? g.issues.length && c.issues.push(...iu(g.issues)) : (c.memo = !0, d.backEdges ?? (d.backEdges = /* @__PURE__ */ new Set()), d.backEdges.add(g.value)), c;
        ln = m;
        let v = dn.length, $ = n(c, s);
        ln = void 0;
        let k = dn.length > v ? dn.pop() : void 0;
        return $ instanceof Promise ? $.then((I) => (k && (k.issues = I.issues.length ? iu(I.issues) : Od), I)) : (k && (k.issues = $.issues.length ? iu($.issues) : Od), $);
      }, "wrapped");
      e._zod.parse = a, e._zod.run === n && (e._zod.run = a);
    });
  }
};
function Ht() {
  return tg;
}
u(Ht, "memoizer");
function fn(e, r) {
  let i = e[ou]?.backEdges;
  return i !== void 0 && r !== null && typeof r == "object" && i.has(r);
}
u(fn, "isBackEdge");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/index.js
var nr = {};
he(nr, {
  ar: () => cu,
  az: () => su,
  be: () => lu,
  bg: () => du,
  bn: () => mu,
  ca: () => fu,
  ckb: () => pu,
  cs: () => gu,
  da: () => vu,
  de: () => $u,
  el: () => hu,
  en: () => Qt,
  eo: () => _u,
  es: () => yu,
  fa: () => bu,
  fi: () => ku,
  fr: () => xu,
  frCA: () => Iu,
  gu: () => wu,
  he: () => zu,
  hi: () => Su,
  hr: () => ju,
  hu: () => Pu,
  hy: () => Du,
  id: () => Ou,
  is: () => Uu,
  it: () => Nu,
  ja: () => Tu,
  ka: () => Zu,
  kh: () => Au,
  km: () => er,
  kn: () => Eu,
  ko: () => Cu,
  lt: () => Lu,
  mk: () => Vu,
  ms: () => Ru,
  ne: () => Fu,
  nl: () => Ju,
  nn: () => Mu,
  no: () => Ku,
  ota: () => Wu,
  pl: () => Bu,
  ps: () => Gu,
  pt: () => qu,
  ptBR: () => Xu,
  ro: () => Yu,
  ru: () => Hu,
  sk: () => Qu,
  sl: () => ec,
  sv: () => tc,
  ta: () => rc,
  th: () => nc,
  tk: () => ic,
  tr: () => oc,
  ua: () => ac,
  uk: () => rr,
  ur: () => uc,
  uz: () => cc,
  vi: () => sc,
  yo: () => mc,
  zhCN: () => lc,
  zhTW: () => dc
});

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ar.js
var rg = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "\u062D\u0631\u0641", verb: "\u0623\u0646 \u064A\u062D\u0648\u064A" },
    file: { unit: "\u0628\u0627\u064A\u062A", verb: "\u0623\u0646 \u064A\u062D\u0648\u064A" },
    array: { unit: "\u0639\u0646\u0635\u0631", verb: "\u0623\u0646 \u064A\u062D\u0648\u064A" },
    set: { unit: "\u0639\u0646\u0635\u0631", verb: "\u0623\u0646 \u064A\u062D\u0648\u064A" },
    map: { unit: "\u0639\u0646\u0635\u0631", verb: "\u0623\u0646 \u064A\u062D\u0648\u064A" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "\u0645\u062F\u062E\u0644",
    email: "\u0628\u0631\u064A\u062F \u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A",
    url: "\u0631\u0627\u0628\u0637",
    emoji: "\u0625\u064A\u0645\u0648\u062C\u064A",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u062A\u0627\u0631\u064A\u062E \u0648\u0648\u0642\u062A \u0628\u0645\u0639\u064A\u0627\u0631 ISO",
    date: "\u062A\u0627\u0631\u064A\u062E \u0628\u0645\u0639\u064A\u0627\u0631 ISO",
    time: "\u0648\u0642\u062A \u0628\u0645\u0639\u064A\u0627\u0631 ISO",
    duration: "\u0645\u062F\u0629 \u0628\u0645\u0639\u064A\u0627\u0631 ISO",
    ipv4: "\u0639\u0646\u0648\u0627\u0646 IPv4",
    ipv6: "\u0639\u0646\u0648\u0627\u0646 IPv6",
    mac: "\u0639\u0646\u0648\u0627\u0646 MAC",
    cidrv4: "\u0645\u062F\u0649 \u0639\u0646\u0627\u0648\u064A\u0646 \u0628\u0635\u064A\u063A\u0629 IPv4",
    cidrv6: "\u0645\u062F\u0649 \u0639\u0646\u0627\u0648\u064A\u0646 \u0628\u0635\u064A\u063A\u0629 IPv6",
    base64: "\u0646\u064E\u0635 \u0628\u062A\u0631\u0645\u064A\u0632 base64-encoded",
    base64url: "\u0646\u064E\u0635 \u0628\u062A\u0631\u0645\u064A\u0632 base64url-encoded",
    json_string: "\u0646\u064E\u0635 \u0639\u0644\u0649 \u0647\u064A\u0626\u0629 JSON",
    e164: "\u0631\u0642\u0645 \u0647\u0627\u062A\u0641 \u0628\u0645\u0639\u064A\u0627\u0631 E.164",
    credit_card: "\u0631\u0642\u0645 \u0628\u0637\u0627\u0642\u0629 \u0627\u0644\u0627\u0626\u062A\u0645\u0627\u0646",
    jwt: "JWT",
    template_literal: "\u0645\u062F\u062E\u0644"
  }, o = {
    nan: "NaN"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u0645\u062F\u062E\u0644\u0627\u062A \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644\u0629: \u064A\u0641\u062A\u0631\u0636 \u0625\u062F\u062E\u0627\u0644 instanceof ${t.expected}\u060C \u0648\u0644\u0643\u0646 \u062A\u0645 \u0625\u062F\u062E\u0627\u0644 ${c}` : `\u0645\u062F\u062E\u0644\u0627\u062A \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644\u0629: \u064A\u0641\u062A\u0631\u0636 \u0625\u062F\u062E\u0627\u0644 ${n}\u060C \u0648\u0644\u0643\u0646 \u062A\u0645 \u0625\u062F\u062E\u0627\u0644 ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u0645\u062F\u062E\u0644\u0627\u062A \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644\u0629: \u064A\u0641\u062A\u0631\u0636 \u0625\u062F\u062E\u0627\u0644 ${h(t.values[0])}` : `\u0627\u062E\u062A\u064A\u0627\u0631 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062A\u0648\u0642\u0639 \u0627\u0646\u062A\u0642\u0627\u0621 \u0623\u062D\u062F \u0647\u0630\u0647 \u0627\u0644\u062E\u064A\u0627\u0631\u0627\u062A: ${p(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? ` \u0623\u0643\u0628\u0631 \u0645\u0646 \u0627\u0644\u0644\u0627\u0632\u0645: \u064A\u0641\u062A\u0631\u0636 \u0623\u0646 \u062A\u0643\u0648\u0646 ${t.origin ?? "\u0627\u0644\u0642\u064A\u0645\u0629"} ${n} ${t.maximum.toString()} ${a.unit ?? "\u0639\u0646\u0635\u0631"}` : `\u0623\u0643\u0628\u0631 \u0645\u0646 \u0627\u0644\u0644\u0627\u0632\u0645: \u064A\u0641\u062A\u0631\u0636 \u0623\u0646 \u062A\u0643\u0648\u0646 ${t.origin ?? "\u0627\u0644\u0642\u064A\u0645\u0629"} ${n} ${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u0623\u0635\u063A\u0631 \u0645\u0646 \u0627\u0644\u0644\u0627\u0632\u0645: \u064A\u0641\u062A\u0631\u0636 \u0644\u0640 ${t.origin} \u0623\u0646 \u064A\u0643\u0648\u0646 ${n} ${t.minimum.toString()} ${a.unit}` : `\u0623\u0635\u063A\u0631 \u0645\u0646 \u0627\u0644\u0644\u0627\u0632\u0645: \u064A\u0641\u062A\u0631\u0636 \u0644\u0640 ${t.origin} \u0623\u0646 \u064A\u0643\u0648\u0646 ${n} ${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u0646\u064E\u0635 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u0628\u062F\u0623 \u0628\u0640 "${t.prefix}"` : n.format === "ends_with" ? `\u0646\u064E\u0635 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u0646\u062A\u0647\u064A \u0628\u0640 "${n.suffix}"` : n.format === "includes" ? `\u0646\u064E\u0635 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u062A\u0636\u0645\u0651\u064E\u0646 "${n.includes}"` : n.format === "regex" ? `\u0646\u064E\u0635 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u0637\u0627\u0628\u0642 \u0627\u0644\u0646\u0645\u0637 ${n.pattern}` : `${i[n.format] ?? t.format} \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644`;
      }
      case "not_multiple_of":
        return `\u0631\u0642\u0645 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u0643\u0648\u0646 \u0645\u0646 \u0645\u0636\u0627\u0639\u0641\u0627\u062A ${t.divisor}`;
      case "unrecognized_keys":
        return `\u0645\u0639\u0631\u0641${t.keys.length > 1 ? "\u0627\u062A" : ""} \u063A\u0631\u064A\u0628${t.keys.length > 1 ? "\u0629" : ""}: ${p(t.keys, "\u060C ")}`;
      case "invalid_key":
        return `\u0645\u0639\u0631\u0641 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644 \u0641\u064A ${t.origin}`;
      case "invalid_union":
        return "\u0645\u062F\u062E\u0644 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644";
      case "invalid_element":
        return `\u0645\u062F\u062E\u0644 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644 \u0641\u064A ${t.origin}`;
      default:
        return "\u0645\u062F\u062E\u0644 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644";
    }
  };
}, "error");
function cu() {
  return {
    localeError: rg()
  };
}
u(cu, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/az.js
var ng = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "simvol", verb: "olmal\u0131d\u0131r" },
    file: { unit: "bayt", verb: "olmal\u0131d\u0131r" },
    array: { unit: "element", verb: "olmal\u0131d\u0131r" },
    set: { unit: "element", verb: "olmal\u0131d\u0131r" },
    map: { unit: "element", verb: "olmal\u0131d\u0131r" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "input",
    email: "email address",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datetime",
    date: "ISO date",
    time: "ISO time",
    duration: "ISO duration",
    ipv4: "IPv4 address",
    ipv6: "IPv6 address",
    mac: "MAC address",
    cidrv4: "IPv4 range",
    cidrv6: "IPv6 range",
    base64: "base64-encoded string",
    base64url: "base64url-encoded string",
    json_string: "JSON string",
    e164: "E.164 number",
    credit_card: "kredit kart\u0131 n\xF6mr\u0259si",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Yanl\u0131\u015F d\u0259y\u0259r: g\xF6zl\u0259nil\u0259n instanceof ${t.expected}, daxil olan ${c}` : `Yanl\u0131\u015F d\u0259y\u0259r: g\xF6zl\u0259nil\u0259n ${n}, daxil olan ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Yanl\u0131\u015F d\u0259y\u0259r: g\xF6zl\u0259nil\u0259n ${h(t.values[0])}` : `Yanl\u0131\u015F se\xE7im: a\u015Fa\u011F\u0131dak\u0131lardan biri olmal\u0131d\u0131r: ${p(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\xC7ox b\xF6y\xFCk: g\xF6zl\u0259nil\u0259n ${t.origin ?? "d\u0259y\u0259r"} ${n}${t.maximum.toString()} ${a.unit ?? "element"}` : `\xC7ox b\xF6y\xFCk: g\xF6zl\u0259nil\u0259n ${t.origin ?? "d\u0259y\u0259r"} ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\xC7ox ki\xE7ik: g\xF6zl\u0259nil\u0259n ${t.origin} ${n}${t.minimum.toString()} ${a.unit}` : `\xC7ox ki\xE7ik: g\xF6zl\u0259nil\u0259n ${t.origin} ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Yanl\u0131\u015F m\u0259tn: "${n.prefix}" il\u0259 ba\u015Flamal\u0131d\u0131r` : n.format === "ends_with" ? `Yanl\u0131\u015F m\u0259tn: "${n.suffix}" il\u0259 bitm\u0259lidir` : n.format === "includes" ? `Yanl\u0131\u015F m\u0259tn: "${n.includes}" daxil olmal\u0131d\u0131r` : n.format === "regex" ? `Yanl\u0131\u015F m\u0259tn: ${n.pattern} \u015Fablonuna uy\u011Fun olmal\u0131d\u0131r` : `Yanl\u0131\u015F ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Yanl\u0131\u015F \u0259d\u0259d: ${t.divisor} il\u0259 b\xF6l\xFCn\u0259 bil\u0259n olmal\u0131d\u0131r`;
      case "unrecognized_keys":
        return `Tan\u0131nmayan a\xE7ar${t.keys.length > 1 ? "lar" : ""}: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `${t.origin} daxilind\u0259 yanl\u0131\u015F a\xE7ar`;
      case "invalid_union":
        return "Yanl\u0131\u015F d\u0259y\u0259r";
      case "invalid_element":
        return `${t.origin} daxilind\u0259 yanl\u0131\u015F d\u0259y\u0259r`;
      default:
        return "Yanl\u0131\u015F d\u0259y\u0259r";
    }
  };
}, "error");
function su() {
  return {
    localeError: ng()
  };
}
u(su, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/be.js
function Nd(e, r, i, o) {
  let t = Math.abs(e), n = t % 10, a = t % 100;
  return a >= 11 && a <= 19 ? o : n === 1 ? r : n >= 2 && n <= 4 ? i : o;
}
u(Nd, "getBelarusianPlural");
var ig = /* @__PURE__ */ u(() => {
  let e = {
    string: {
      unit: {
        one: "\u0441\u0456\u043C\u0432\u0430\u043B",
        few: "\u0441\u0456\u043C\u0432\u0430\u043B\u044B",
        many: "\u0441\u0456\u043C\u0432\u0430\u043B\u0430\u045E"
      },
      verb: "\u043C\u0435\u0446\u044C"
    },
    array: {
      unit: {
        one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
        few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u044B",
        many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430\u045E"
      },
      verb: "\u043C\u0435\u0446\u044C"
    },
    set: {
      unit: {
        one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
        few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u044B",
        many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430\u045E"
      },
      verb: "\u043C\u0435\u0446\u044C"
    },
    map: {
      unit: {
        one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
        few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u044B",
        many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430\u045E"
      },
      verb: "\u043C\u0435\u0446\u044C"
    },
    file: {
      unit: {
        one: "\u0431\u0430\u0439\u0442",
        few: "\u0431\u0430\u0439\u0442\u044B",
        many: "\u0431\u0430\u0439\u0442\u0430\u045E"
      },
      verb: "\u043C\u0435\u0446\u044C"
    }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "\u0443\u0432\u043E\u0434",
    email: "email \u0430\u0434\u0440\u0430\u0441",
    url: "URL",
    emoji: "\u044D\u043C\u043E\u0434\u0437\u0456",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0434\u0430\u0442\u0430 \u0456 \u0447\u0430\u0441",
    date: "ISO \u0434\u0430\u0442\u0430",
    time: "ISO \u0447\u0430\u0441",
    duration: "ISO \u043F\u0440\u0430\u0446\u044F\u0433\u043B\u0430\u0441\u0446\u044C",
    ipv4: "IPv4 \u0430\u0434\u0440\u0430\u0441",
    ipv6: "IPv6 \u0430\u0434\u0440\u0430\u0441",
    mac: "MAC \u0430\u0434\u0440\u0430\u0441",
    cidrv4: "IPv4 \u0434\u044B\u044F\u043F\u0430\u0437\u043E\u043D",
    cidrv6: "IPv6 \u0434\u044B\u044F\u043F\u0430\u0437\u043E\u043D",
    base64: "\u0440\u0430\u0434\u043E\u043A \u0443 \u0444\u0430\u0440\u043C\u0430\u0446\u0435 base64",
    base64url: "\u0440\u0430\u0434\u043E\u043A \u0443 \u0444\u0430\u0440\u043C\u0430\u0446\u0435 base64url",
    json_string: "JSON \u0440\u0430\u0434\u043E\u043A",
    e164: "\u043D\u0443\u043C\u0430\u0440 E.164",
    credit_card: "\u043D\u0443\u043C\u0430\u0440 \u043A\u0440\u044D\u0434\u044B\u0442\u043D\u0430\u0439 \u043A\u0430\u0440\u0442\u044B",
    jwt: "JWT",
    template_literal: "\u0443\u0432\u043E\u0434"
  }, o = {
    nan: "NaN",
    number: "\u043B\u0456\u043A",
    array: "\u043C\u0430\u0441\u0456\u045E"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434: \u0447\u0430\u043A\u0430\u045E\u0441\u044F instanceof ${t.expected}, \u0430\u0442\u0440\u044B\u043C\u0430\u043D\u0430 ${c}` : `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434: \u0447\u0430\u043A\u0430\u045E\u0441\u044F ${n}, \u0430\u0442\u0440\u044B\u043C\u0430\u043D\u0430 ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F ${h(t.values[0])}` : `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0432\u0430\u0440\u044B\u044F\u043D\u0442: \u0447\u0430\u043A\u0430\u045E\u0441\u044F \u0430\u0434\u0437\u0456\u043D \u0437 ${p(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        if (a) {
          let c = Number(t.maximum), s = Nd(c, a.unit.one, a.unit.few, a.unit.many);
          return `\u0417\u0430\u043D\u0430\u0434\u0442\u0430 \u0432\u044F\u043B\u0456\u043A\u0456: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F, \u0448\u0442\u043E ${t.origin ?? "\u0437\u043D\u0430\u0447\u044D\u043D\u043D\u0435"} \u043F\u0430\u0432\u0456\u043D\u043D\u0430 ${a.verb} ${n}${t.maximum.toString()} ${s}`;
        }
        return `\u0417\u0430\u043D\u0430\u0434\u0442\u0430 \u0432\u044F\u043B\u0456\u043A\u0456: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F, \u0448\u0442\u043E ${t.origin ?? "\u0437\u043D\u0430\u0447\u044D\u043D\u043D\u0435"} \u043F\u0430\u0432\u0456\u043D\u043D\u0430 \u0431\u044B\u0446\u044C ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        if (a) {
          let c = Number(t.minimum), s = Nd(c, a.unit.one, a.unit.few, a.unit.many);
          return `\u0417\u0430\u043D\u0430\u0434\u0442\u0430 \u043C\u0430\u043B\u044B: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F, \u0448\u0442\u043E ${t.origin} \u043F\u0430\u0432\u0456\u043D\u043D\u0430 ${a.verb} ${n}${t.minimum.toString()} ${s}`;
        }
        return `\u0417\u0430\u043D\u0430\u0434\u0442\u0430 \u043C\u0430\u043B\u044B: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F, \u0448\u0442\u043E ${t.origin} \u043F\u0430\u0432\u0456\u043D\u043D\u0430 \u0431\u044B\u0446\u044C ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0440\u0430\u0434\u043E\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u043F\u0430\u0447\u044B\u043D\u0430\u0446\u0446\u0430 \u0437 "${n.prefix}"` : n.format === "ends_with" ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0440\u0430\u0434\u043E\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u0437\u0430\u043A\u0430\u043D\u0447\u0432\u0430\u0446\u0446\u0430 \u043D\u0430 "${n.suffix}"` : n.format === "includes" ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0440\u0430\u0434\u043E\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u0437\u043C\u044F\u0448\u0447\u0430\u0446\u044C "${n.includes}"` : n.format === "regex" ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0440\u0430\u0434\u043E\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u0430\u0434\u043F\u0430\u0432\u044F\u0434\u0430\u0446\u044C \u0448\u0430\u0431\u043B\u043E\u043D\u0443 ${n.pattern}` : `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u043B\u0456\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u0431\u044B\u0446\u044C \u043A\u0440\u0430\u0442\u043D\u044B\u043C ${t.divisor}`;
      case "unrecognized_keys":
        return `\u041D\u0435\u0440\u0430\u0441\u043F\u0430\u0437\u043D\u0430\u043D\u044B ${t.keys.length > 1 ? "\u043A\u043B\u044E\u0447\u044B" : "\u043A\u043B\u044E\u0447"}: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u043A\u043B\u044E\u0447 \u0443 ${t.origin}`;
      case "invalid_union":
        return "\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434";
      case "invalid_element":
        return `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u0430\u0435 \u0437\u043D\u0430\u0447\u044D\u043D\u043D\u0435 \u045E ${t.origin}`;
      default:
        return "\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434";
    }
  };
}, "error");
function lu() {
  return {
    localeError: ig()
  };
}
u(lu, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/bg.js
var og = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "\u0441\u0438\u043C\u0432\u043E\u043B\u0430", verb: "\u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430" },
    file: { unit: "\u0431\u0430\u0439\u0442\u0430", verb: "\u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430" },
    array: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0430", verb: "\u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430" },
    set: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0430", verb: "\u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430" },
    map: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0430", verb: "\u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "\u0432\u0445\u043E\u0434",
    email: "\u0438\u043C\u0435\u0439\u043B \u0430\u0434\u0440\u0435\u0441",
    url: "URL",
    emoji: "\u0435\u043C\u043E\u0434\u0436\u0438",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0432\u0440\u0435\u043C\u0435",
    date: "ISO \u0434\u0430\u0442\u0430",
    time: "ISO \u0432\u0440\u0435\u043C\u0435",
    duration: "ISO \u043F\u0440\u043E\u0434\u044A\u043B\u0436\u0438\u0442\u0435\u043B\u043D\u043E\u0441\u0442",
    ipv4: "IPv4 \u0430\u0434\u0440\u0435\u0441",
    ipv6: "IPv6 \u0430\u0434\u0440\u0435\u0441",
    mac: "MAC \u0430\u0434\u0440\u0435\u0441",
    cidrv4: "IPv4 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D",
    cidrv6: "IPv6 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D",
    base64: "base64-\u043A\u043E\u0434\u0438\u0440\u0430\u043D \u043D\u0438\u0437",
    base64url: "base64url-\u043A\u043E\u0434\u0438\u0440\u0430\u043D \u043D\u0438\u0437",
    json_string: "JSON \u043D\u0438\u0437",
    e164: "E.164 \u043D\u043E\u043C\u0435\u0440",
    credit_card: "\u043D\u043E\u043C\u0435\u0440 \u043D\u0430 \u043A\u0440\u0435\u0434\u0438\u0442\u043D\u0430 \u043A\u0430\u0440\u0442\u0430",
    jwt: "JWT",
    template_literal: "\u0432\u0445\u043E\u0434"
  }, o = {
    nan: "NaN",
    number: "\u0447\u0438\u0441\u043B\u043E",
    array: "\u043C\u0430\u0441\u0438\u0432"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434: \u043E\u0447\u0430\u043A\u0432\u0430\u043D instanceof ${t.expected}, \u043F\u043E\u043B\u0443\u0447\u0435\u043D ${c}` : `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434: \u043E\u0447\u0430\u043A\u0432\u0430\u043D ${n}, \u043F\u043E\u043B\u0443\u0447\u0435\u043D ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434: \u043E\u0447\u0430\u043A\u0432\u0430\u043D ${h(t.values[0])}` : `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u0430 \u043E\u043F\u0446\u0438\u044F: \u043E\u0447\u0430\u043A\u0432\u0430\u043D\u043E \u0435\u0434\u043D\u043E \u043E\u0442 ${p(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u0422\u0432\u044A\u0440\u0434\u0435 \u0433\u043E\u043B\u044F\u043C\u043E: \u043E\u0447\u0430\u043A\u0432\u0430 \u0441\u0435 ${t.origin ?? "\u0441\u0442\u043E\u0439\u043D\u043E\u0441\u0442"} \u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430 ${n}${t.maximum.toString()} ${a.unit ?? "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0430"}` : `\u0422\u0432\u044A\u0440\u0434\u0435 \u0433\u043E\u043B\u044F\u043C\u043E: \u043E\u0447\u0430\u043A\u0432\u0430 \u0441\u0435 ${t.origin ?? "\u0441\u0442\u043E\u0439\u043D\u043E\u0441\u0442"} \u0434\u0430 \u0431\u044A\u0434\u0435 ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u0422\u0432\u044A\u0440\u0434\u0435 \u043C\u0430\u043B\u043A\u043E: \u043E\u0447\u0430\u043A\u0432\u0430 \u0441\u0435 ${t.origin} \u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430 ${n}${t.minimum.toString()} ${a.unit}` : `\u0422\u0432\u044A\u0440\u0434\u0435 \u043C\u0430\u043B\u043A\u043E: \u043E\u0447\u0430\u043A\u0432\u0430 \u0441\u0435 ${t.origin} \u0434\u0430 \u0431\u044A\u0434\u0435 ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        if (n.format === "starts_with")
          return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043D\u0438\u0437: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0437\u0430\u043F\u043E\u0447\u0432\u0430 \u0441 "${n.prefix}"`;
        if (n.format === "ends_with")
          return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043D\u0438\u0437: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0437\u0430\u0432\u044A\u0440\u0448\u0432\u0430 \u0441 "${n.suffix}"`;
        if (n.format === "includes")
          return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043D\u0438\u0437: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0432\u043A\u043B\u044E\u0447\u0432\u0430 "${n.includes}"`;
        if (n.format === "regex")
          return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043D\u0438\u0437: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0441\u044A\u0432\u043F\u0430\u0434\u0430 \u0441 ${n.pattern}`;
        let a = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D";
        return n.format === "emoji" && (a = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u043E"), n.format === "datetime" && (a = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u043E"), n.format === "date" && (a = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u0430"), n.format === "time" && (a = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u043E"), n.format === "duration" && (a = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u0430"), `${a} ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u043E \u0447\u0438\u0441\u043B\u043E: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0431\u044A\u0434\u0435 \u043A\u0440\u0430\u0442\u043D\u043E \u043D\u0430 ${t.divisor}`;
      case "unrecognized_keys":
        return `\u041D\u0435\u0440\u0430\u0437\u043F\u043E\u0437\u043D\u0430\u0442${t.keys.length > 1 ? "\u0438" : ""} \u043A\u043B\u044E\u0447${t.keys.length > 1 ? "\u043E\u0432\u0435" : ""}: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043A\u043B\u044E\u0447 \u0432 ${t.origin}`;
      case "invalid_union":
        return "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434";
      case "invalid_element":
        return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u0430 \u0441\u0442\u043E\u0439\u043D\u043E\u0441\u0442 \u0432 ${t.origin}`;
      default:
        return "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434";
    }
  };
}, "error");
function du() {
  return {
    localeError: og()
  };
}
u(du, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/bn.js
var ag = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "\u0985\u0995\u09CD\u09B7\u09B0", verb: "\u09A5\u09BE\u0995\u09A4\u09C7 \u09B9\u09AC\u09C7" },
    file: { unit: "\u09AC\u09BE\u0987\u099F", verb: "\u09A5\u09BE\u0995\u09A4\u09C7 \u09B9\u09AC\u09C7" },
    array: { unit: "\u0986\u0987\u099F\u09C7\u09AE", verb: "\u09A5\u09BE\u0995\u09A4\u09C7 \u09B9\u09AC\u09C7" },
    set: { unit: "\u0986\u0987\u099F\u09C7\u09AE", verb: "\u09A5\u09BE\u0995\u09A4\u09C7 \u09B9\u09AC\u09C7" },
    map: { unit: "\u098F\u09A8\u09CD\u099F\u09CD\u09B0\u09BF", verb: "\u09A5\u09BE\u0995\u09A4\u09C7 \u09B9\u09AC\u09C7" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "\u0987\u09A8\u09AA\u09C1\u099F",
    email: "\u0987\u09AE\u09C7\u0987\u09B2 \u09A0\u09BF\u0995\u09BE\u09A8\u09BE",
    url: "URL",
    emoji: "\u0987\u09AE\u09CB\u099C\u09BF",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u09A4\u09BE\u09B0\u09BF\u0996 \u0993 \u09B8\u09AE\u09AF\u09BC",
    date: "ISO \u09A4\u09BE\u09B0\u09BF\u0996",
    time: "ISO \u09B8\u09AE\u09AF\u09BC",
    duration: "ISO \u09B8\u09AE\u09AF\u09BC\u0995\u09BE\u09B2",
    ipv4: "IPv4 \u09A0\u09BF\u0995\u09BE\u09A8\u09BE",
    ipv6: "IPv6 \u09A0\u09BF\u0995\u09BE\u09A8\u09BE",
    mac: "MAC \u09A0\u09BF\u0995\u09BE\u09A8\u09BE",
    cidrv4: "IPv4 \u09B0\u09C7\u099E\u09CD\u099C",
    cidrv6: "IPv6 \u09B0\u09C7\u099E\u09CD\u099C",
    base64: "base64-\u098F\u09A8\u0995\u09CB\u09A1\u09C7\u09A1 \u09B8\u09CD\u099F\u09CD\u09B0\u09BF\u0982",
    base64url: "base64url-\u098F\u09A8\u0995\u09CB\u09A1\u09C7\u09A1 \u09B8\u09CD\u099F\u09CD\u09B0\u09BF\u0982",
    json_string: "JSON \u09B8\u09CD\u099F\u09CD\u09B0\u09BF\u0982",
    e164: "E.164 \u09A8\u09AE\u09CD\u09AC\u09B0",
    credit_card: "\u0995\u09CD\u09B0\u09C7\u09A1\u09BF\u099F \u0995\u09BE\u09B0\u09CD\u09A1 \u09A8\u09AE\u09CD\u09AC\u09B0",
    jwt: "JWT",
    template_literal: "\u0987\u09A8\u09AA\u09C1\u099F"
  }, o = {
    nan: "NaN"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return `\u0985\u09AC\u09C8\u09A7 \u0987\u09A8\u09AA\u09C1\u099F: \u09AA\u09CD\u09B0\u09A4\u09CD\u09AF\u09BE\u09B6\u09BF\u09A4 ${n}, \u09AA\u09CD\u09B0\u09BE\u09AA\u09CD\u09A4 ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u0985\u09AC\u09C8\u09A7 \u0987\u09A8\u09AA\u09C1\u099F: \u09AA\u09CD\u09B0\u09A4\u09CD\u09AF\u09BE\u09B6\u09BF\u09A4 ${h(t.values[0])}` : `\u0985\u09AC\u09C8\u09A7 \u0985\u09AA\u09B6\u09A8: ${p(t.values, " | ")} \u098F\u09B0 \u09AE\u09A7\u09CD\u09AF\u09C7 \u098F\u0995\u099F\u09BF \u09AA\u09CD\u09B0\u09A4\u09CD\u09AF\u09BE\u09B6\u09BF\u09A4`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u0985\u09A8\u09C7\u0995 \u09AC\u09A1\u09BC: ${t.origin ?? "\u09AE\u09BE\u09A8"} ${n}${t.maximum.toString()} ${a.unit ?? "\u098F\u09B2\u09BF\u09AE\u09C7\u09A8\u09CD\u099F"} \u09B9\u09A4\u09C7 \u09B9\u09AC\u09C7` : `\u0985\u09A8\u09C7\u0995 \u09AC\u09A1\u09BC: ${t.origin ?? "\u09AE\u09BE\u09A8"} ${n}${t.maximum.toString()} \u09B9\u09A4\u09C7 \u09B9\u09AC\u09C7`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u0985\u09A8\u09C7\u0995 \u099B\u09CB\u099F: ${t.origin} ${n}${t.minimum.toString()} ${a.unit} \u09B9\u09A4\u09C7 \u09B9\u09AC\u09C7` : `\u0985\u09A8\u09C7\u0995 \u099B\u09CB\u099F: ${t.origin} ${n}${t.minimum.toString()} \u09B9\u09A4\u09C7 \u09B9\u09AC\u09C7`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u0985\u09AC\u09C8\u09A7 \u09B8\u09CD\u099F\u09CD\u09B0\u09BF\u0982: "${n.prefix}" \u09A6\u09BF\u09AF\u09BC\u09C7 \u09B6\u09C1\u09B0\u09C1 \u09B9\u09A4\u09C7 \u09B9\u09AC\u09C7` : n.format === "ends_with" ? `\u0985\u09AC\u09C8\u09A7 \u09B8\u09CD\u099F\u09CD\u09B0\u09BF\u0982: "${n.suffix}" \u09A6\u09BF\u09AF\u09BC\u09C7 \u09B6\u09C7\u09B7 \u09B9\u09A4\u09C7 \u09B9\u09AC\u09C7` : n.format === "includes" ? `\u0985\u09AC\u09C8\u09A7 \u09B8\u09CD\u099F\u09CD\u09B0\u09BF\u0982: "${n.includes}" \u0985\u09A8\u09CD\u09A4\u09B0\u09CD\u09AD\u09C1\u0995\u09CD\u09A4 \u09A5\u09BE\u0995\u09A4\u09C7 \u09B9\u09AC\u09C7` : n.format === "regex" ? `\u0985\u09AC\u09C8\u09A7 \u09B8\u09CD\u099F\u09CD\u09B0\u09BF\u0982: ${n.pattern} \u09AA\u09CD\u09AF\u09BE\u099F\u09BE\u09B0\u09CD\u09A8 \u09AE\u09BF\u09B2\u09A4\u09C7 \u09B9\u09AC\u09C7` : `\u0985\u09AC\u09C8\u09A7 ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u0985\u09AC\u09C8\u09A7 \u09A8\u09AE\u09CD\u09AC\u09B0: ${t.divisor} \u098F\u09B0 \u0997\u09C1\u09A3\u09BF\u09A4\u0995 \u09B9\u09A4\u09C7 \u09B9\u09AC\u09C7`;
      case "unrecognized_keys":
        return `\u0985\u099A\u09C7\u09A8\u09BE \u0995\u09C0${t.keys.length > 1 ? "\u0997\u09C1\u09B2\u09CB" : ""}: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `${t.origin} \u098F \u0985\u09AC\u09C8\u09A7 \u0995\u09C0`;
      case "invalid_union":
        return t.options && Array.isArray(t.options) && t.options.length > 0 ? `\u0985\u09AC\u09C8\u09A7 \u09A1\u09BF\u09B8\u0995\u09CD\u09B0\u09BF\u09AE\u09BF\u09A8\u09C7\u099F\u09B0 \u09AE\u09BE\u09A8\u0964 \u09AA\u09CD\u09B0\u09A4\u09CD\u09AF\u09BE\u09B6\u09BF\u09A4 ${t.options.map((a) => `'${a}'`).join(" | ")}` : "\u0985\u09AC\u09C8\u09A7 \u0987\u09A8\u09AA\u09C1\u099F";
      case "invalid_element":
        return `${t.origin} \u098F \u0985\u09AC\u09C8\u09A7 \u09AE\u09BE\u09A8`;
      default:
        return "\u0985\u09AC\u09C8\u09A7 \u0987\u09A8\u09AA\u09C1\u099F";
    }
  };
}, "error");
function mu() {
  return {
    localeError: ag()
  };
}
u(mu, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ca.js
var ug = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "car\xE0cters", verb: "contenir" },
    file: { unit: "bytes", verb: "contenir" },
    array: { unit: "elements", verb: "contenir" },
    set: { unit: "elements", verb: "contenir" },
    map: { unit: "elements", verb: "contenir" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "entrada",
    email: "adre\xE7a electr\xF2nica",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "data i hora ISO",
    date: "data ISO",
    time: "hora ISO",
    duration: "durada ISO",
    ipv4: "adre\xE7a IPv4",
    ipv6: "adre\xE7a IPv6",
    mac: "adre\xE7a MAC",
    cidrv4: "rang IPv4",
    cidrv6: "rang IPv6",
    base64: "cadena codificada en base64",
    base64url: "cadena codificada en base64url",
    json_string: "cadena JSON",
    e164: "n\xFAmero E.164",
    credit_card: "n\xFAmero de targeta de cr\xE8dit",
    jwt: "JWT",
    template_literal: "entrada"
  }, o = {
    nan: "NaN"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Tipus inv\xE0lid: s'esperava instanceof ${t.expected}, s'ha rebut ${c}` : `Tipus inv\xE0lid: s'esperava ${n}, s'ha rebut ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Valor inv\xE0lid: s'esperava ${h(t.values[0])}` : `Opci\xF3 inv\xE0lida: s'esperava una de ${p(t.values, " o ")}`;
      case "too_big": {
        let n = t.inclusive ? "com a m\xE0xim" : "menys de", a = r(t.origin);
        return a ? `Massa gran: s'esperava que ${t.origin ?? "el valor"} contingu\xE9s ${n} ${t.maximum.toString()} ${a.unit ?? "elements"}` : `Massa gran: s'esperava que ${t.origin ?? "el valor"} fos ${n} ${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? "com a m\xEDnim" : "m\xE9s de", a = r(t.origin);
        return a ? `Massa petit: s'esperava que ${t.origin} contingu\xE9s ${n} ${t.minimum.toString()} ${a.unit}` : `Massa petit: s'esperava que ${t.origin} fos ${n} ${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Format inv\xE0lid: ha de comen\xE7ar amb "${n.prefix}"` : n.format === "ends_with" ? `Format inv\xE0lid: ha d'acabar amb "${n.suffix}"` : n.format === "includes" ? `Format inv\xE0lid: ha d'incloure "${n.includes}"` : n.format === "regex" ? `Format inv\xE0lid: ha de coincidir amb el patr\xF3 ${n.pattern}` : `Format inv\xE0lid per a ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `N\xFAmero inv\xE0lid: ha de ser m\xFAltiple de ${t.divisor}`;
      case "unrecognized_keys":
        return `Clau${t.keys.length > 1 ? "s" : ""} no reconeguda${t.keys.length > 1 ? "s" : ""}: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `Clau inv\xE0lida a ${t.origin}`;
      case "invalid_union":
        return "Entrada inv\xE0lida";
      // Could also be "Tipus d'unió invàlid" but "Entrada invàlida" is more general
      case "invalid_element":
        return `Element inv\xE0lid a ${t.origin}`;
      default:
        return "Entrada inv\xE0lida";
    }
  };
}, "error");
function fu() {
  return {
    localeError: ug()
  };
}
u(fu, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ckb.js
var cg = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "\u067E\u06CC\u062A", verb: "\u0628\u06CE\u062A" },
    file: { unit: "\u0628\u0627\u06CC\u062A", verb: "\u0628\u06CE\u062A" },
    array: { unit: "\u062F\u0627\u0646\u06D5", verb: "\u0628\u06CE\u062A" },
    set: { unit: "\u062F\u0627\u0646\u06D5", verb: "\u0628\u06CE\u062A" },
    map: { unit: "\u062F\u0627\u0646\u06D5", verb: "\u0628\u06CE\u062A" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "regex",
    email: "\u0626\u06CC\u0645\u06D5\u06CC\u06B5",
    url: "\u0628\u06D5\u0633\u062A\u06D5\u0631 (URL)",
    emoji: "\u0626\u06CC\u0645\u06C6\u062C\u06CC",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u0695\u06CE\u06A9\u06D5\u0648\u062A \u0648 \u06A9\u0627\u062A",
    date: "\u0695\u06CE\u06A9\u06D5\u0648\u062A",
    time: "\u06A9\u0627\u062A",
    duration: "\u0645\u0627\u0648\u06D5",
    ipv4: "\u0646\u0627\u0648\u0646\u06CC\u0634\u0627\u0646\u06CC IPv4",
    ipv6: "\u0646\u0627\u0648\u0646\u06CC\u0634\u0627\u0646\u06CC IPv6",
    mac: "\u0646\u0627\u0648\u0646\u06CC\u0634\u0627\u0646\u06CC MAC",
    cidrv4: "\u0645\u06D5\u0648\u062F\u0627\u06CC IPv4",
    cidrv6: "\u0645\u06D5\u0648\u062F\u0627\u06CC IPv6",
    base64: "\u062F\u06D5\u0642\u06CC base64",
    base64url: "\u062F\u06D5\u0642\u06CC base64url",
    json_string: "\u062F\u06D5\u0642\u06CC JSON",
    e164: "\u0698\u0645\u0627\u0631\u06D5\u06CC E.164",
    credit_card: "\u0698\u0645\u0627\u0631\u06D5\u06CC \u06A9\u0627\u0631\u062A\u06CC \u06A9\u0631\u06CE\u062F\u06CC\u062A",
    jwt: "JWT",
    template_literal: "\u062A\u06CE\u06A9\u0631\u062F\u06D5"
  }, o = {
    nan: "NaN",
    string: "\u0646\u0648\u0648\u0633\u06CC\u0646",
    number: "\u0698\u0645\u0627\u0631\u06D5",
    boolean: "boolean",
    array: "array",
    object: "object",
    date: "\u0695\u06CE\u06A9\u06D5\u0648\u062A",
    integer: "\u0698\u0645\u0627\u0631\u06D5",
    float: "\u0698\u0645\u0627\u0631\u06D5",
    null: "null",
    undefined: "undefined",
    function: "function",
    symbol: "symbol",
    unknown: "unknown",
    promise: "promise",
    void: "void",
    never: "never",
    map: "map",
    set: "set"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a, s = ["\u0627", "\u0648", "\u06C6", "\u0648\u0648", "\u06D5", "\u06CC", "\u06CE"].some((d) => c.endsWith(d)) ? "\u06CC\u06D5" : "\u06D5", l = /^[a-zA-Z]+$/.test(c);
        return a === "null" || a === "undefined" ? "\u062F\u0627\u0648\u0627\u06A9\u0631\u0627\u0648\u06D5" : `\u0686\u0627\u0648\u06D5\u0695\u0648\u0627\u0646\u06A9\u0631\u0627\u0648\u06D5 ${n} \u0628\u06CE\u062A\u060C \u0628\u06D5\u06B5\u0627\u0645 ${c}${l ? "" : s}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u0628\u06D5\u0647\u0627\u06A9\u06D5 \u0646\u0627\u062F\u0631\u0648\u0648\u0633\u062A\u06D5: \u0686\u0627\u0648\u06D5\u0695\u0648\u0627\u0646\u06A9\u0631\u0627\u0648\u06D5 ${h(t.values[0])} \u0628\u06CE\u062A` : `\u0647\u06D5\u06B5\u0628\u0698\u0627\u0631\u062F\u06D5\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A: \u0686\u0627\u0648\u06D5\u0695\u0648\u0627\u0646\u06A9\u0631\u0627\u0648\u06D5 \u06CC\u06D5\u06A9\u06CE\u06A9 \u0628\u06CE\u062A \u0644\u06D5 ${p(t.values, "|")}`;
      case "too_big": {
        let n = r(t.origin);
        return n ? `\u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 \u0628\u06D5 \u0644\u0627\u06CC\u06D5\u0646\u06CC \u0632\u06C6\u0631\u06D5\u0648\u06D5 ${t.maximum.toString()} ${n.unit} ${n.verb}` : `\u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 \u0628\u06D5 \u0644\u0627\u06CC\u06D5\u0646\u06CC \u0632\u06C6\u0631\u06D5\u0648\u06D5 ${t.maximum.toString()} \u0628\u06CE\u062A`;
      }
      case "too_small": {
        let n = r(t.origin);
        return n ? `\u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 \u0628\u06D5 \u0644\u0627\u06CC\u06D5\u0646\u06CC \u06A9\u06D5\u0645\u06D5\u0648\u06D5 ${t.minimum.toString()} ${n.unit} ${n.verb}` : `\u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 \u0628\u06D5 \u0644\u0627\u06CC\u06D5\u0646\u06CC \u06A9\u06D5\u0645\u06D5\u0648\u06D5 ${t.minimum.toString()} \u0628\u06CE\u062A`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u062F\u06D5\u0642\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A: \u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 \u062F\u06D5\u0633\u062A\u067E\u06CE\u0628\u06A9\u0627\u062A \u0628\u06D5 "${n.prefix}"` : n.format === "ends_with" ? `\u062F\u06D5\u0642\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A: \u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 \u06A9\u06C6\u062A\u0627\u06CC\u06CC\u0628\u06CE\u062A \u0628\u06D5 "${n.suffix}"` : n.format === "includes" ? `\u062F\u06D5\u0642\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A: \u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 "${n.includes}" \u0644\u06D5\u062E\u06C6\u0628\u06AF\u0631\u06CE\u062A` : n.format === "regex" ? `\u062F\u06D5\u0642\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A: \u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 \u0644\u06D5\u06AF\u06D5\u06B5 \u067E\u0627\u062A\u06CE\u0631\u0646\u06CC ${n.pattern} \u0628\u06AF\u0648\u0646\u062C\u06CE\u062A` : `\u0628\u06D5\u0647\u0627\u06CC ${i[n.format] ?? t.format} \u0646\u0627\u062F\u0631\u0648\u0633\u062A\u06D5`;
      }
      case "not_multiple_of":
        return `\u0698\u0645\u0627\u0631\u06D5\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A: \u062F\u06D5\u0628\u06CE\u062A \u0686\u06D5\u0646\u062F \u0647\u06CE\u0646\u062F\u06D5 \u0628\u06CE\u062A \u0628\u06C6 ${t.divisor}`;
      case "unrecognized_keys":
        return `\u06A9\u0644\u06CC\u0644\u06CC \u0646\u06D5\u0646\u0627\u0633\u0631\u0627\u0648: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `\u06A9\u0644\u06CC\u0644\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A \u0644\u06D5 ${t.origin}`;
      case "invalid_union":
        return t.options && Array.isArray(t.options) && t.options.length > 0 ? `\u0628\u06D5\u0647\u0627\u06CC \u0646\u06D5\u0646\u0627\u0633\u0631\u0627\u0648 \u0647\u06D5\u06CC\u06D5. \u0628\u06D5\u0647\u0627\u06CC \u0686\u0627\u0648\u06D5\u0695\u0648\u0627\u0646\u06A9\u0631\u0627\u0648: ${t.options.map((a) => `'${a}'`).join(" | ")}` : "\u06CC\u06D5\u06A9\u06AF\u0631\u062A\u0646\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A";
      case "invalid_element":
        return `${t.origin} \u0628\u06D5\u0647\u0627\u06A9\u06D5 \u0646\u0627\u062F\u0631\u0648\u0633\u062A\u06D5`;
      default:
        return "\u062A\u06CE\u06A9\u0631\u062F\u06D5\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A";
    }
  };
}, "error");
function pu() {
  return {
    localeError: cg()
  };
}
u(pu, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/cs.js
var sg = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "znak\u016F", verb: "m\xEDt" },
    file: { unit: "bajt\u016F", verb: "m\xEDt" },
    array: { unit: "prvk\u016F", verb: "m\xEDt" },
    set: { unit: "prvk\u016F", verb: "m\xEDt" },
    map: { unit: "prvk\u016F", verb: "m\xEDt" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "regul\xE1rn\xED v\xFDraz",
    email: "e-mailov\xE1 adresa",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "datum a \u010Das ve form\xE1tu ISO",
    date: "datum ve form\xE1tu ISO",
    time: "\u010Das ve form\xE1tu ISO",
    duration: "doba trv\xE1n\xED ISO",
    ipv4: "IPv4 adresa",
    ipv6: "IPv6 adresa",
    mac: "MAC adresa",
    cidrv4: "rozsah IPv4",
    cidrv6: "rozsah IPv6",
    base64: "\u0159et\u011Bzec zak\xF3dovan\xFD ve form\xE1tu base64",
    base64url: "\u0159et\u011Bzec zak\xF3dovan\xFD ve form\xE1tu base64url",
    json_string: "\u0159et\u011Bzec ve form\xE1tu JSON",
    e164: "\u010D\xEDslo E.164",
    credit_card: "\u010D\xEDslo kreditn\xED karty",
    jwt: "JWT",
    template_literal: "vstup"
  }, o = {
    nan: "NaN",
    number: "\u010D\xEDslo",
    string: "\u0159et\u011Bzec",
    function: "funkce",
    array: "pole"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Neplatn\xFD vstup: o\u010Dek\xE1v\xE1no instanceof ${t.expected}, obdr\u017Eeno ${c}` : `Neplatn\xFD vstup: o\u010Dek\xE1v\xE1no ${n}, obdr\u017Eeno ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Neplatn\xFD vstup: o\u010Dek\xE1v\xE1no ${h(t.values[0])}` : `Neplatn\xE1 mo\u017Enost: o\u010Dek\xE1v\xE1na jedna z hodnot ${p(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Hodnota je p\u0159\xEDli\u0161 velk\xE1: ${t.origin ?? "hodnota"} mus\xED m\xEDt ${n}${t.maximum.toString()} ${a.unit ?? "prvk\u016F"}` : `Hodnota je p\u0159\xEDli\u0161 velk\xE1: ${t.origin ?? "hodnota"} mus\xED b\xFDt ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Hodnota je p\u0159\xEDli\u0161 mal\xE1: ${t.origin ?? "hodnota"} mus\xED m\xEDt ${n}${t.minimum.toString()} ${a.unit ?? "prvk\u016F"}` : `Hodnota je p\u0159\xEDli\u0161 mal\xE1: ${t.origin ?? "hodnota"} mus\xED b\xFDt ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Neplatn\xFD \u0159et\u011Bzec: mus\xED za\u010D\xEDnat na "${n.prefix}"` : n.format === "ends_with" ? `Neplatn\xFD \u0159et\u011Bzec: mus\xED kon\u010Dit na "${n.suffix}"` : n.format === "includes" ? `Neplatn\xFD \u0159et\u011Bzec: mus\xED obsahovat "${n.includes}"` : n.format === "regex" ? `Neplatn\xFD \u0159et\u011Bzec: mus\xED odpov\xEDdat vzoru ${n.pattern}` : `Neplatn\xFD form\xE1t ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Neplatn\xE9 \u010D\xEDslo: mus\xED b\xFDt n\xE1sobkem ${t.divisor}`;
      case "unrecognized_keys":
        return `Nezn\xE1m\xE9 kl\xED\u010De: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `Neplatn\xFD kl\xED\u010D v ${t.origin}`;
      case "invalid_union":
        return "Neplatn\xFD vstup";
      case "invalid_element":
        return `Neplatn\xE1 hodnota v ${t.origin}`;
      default:
        return "Neplatn\xFD vstup";
    }
  };
}, "error");
function gu() {
  return {
    localeError: sg()
  };
}
u(gu, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/da.js
var lg = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "tegn", verb: "havde" },
    file: { unit: "bytes", verb: "havde" },
    array: { unit: "elementer", verb: "indeholdt" },
    set: { unit: "elementer", verb: "indeholdt" },
    map: { unit: "elementer", verb: "indeholdt" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "input",
    email: "e-mailadresse",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO dato- og klokkesl\xE6t",
    date: "ISO-dato",
    time: "ISO-klokkesl\xE6t",
    duration: "ISO-varighed",
    ipv4: "IPv4-adresse",
    ipv6: "IPv6-adresse",
    mac: "MAC-adresse",
    cidrv4: "IPv4-spektrum",
    cidrv6: "IPv6-spektrum",
    base64: "base64-kodet streng",
    base64url: "base64url-kodet streng",
    json_string: "JSON-streng",
    e164: "E.164-nummer",
    credit_card: "kreditkortnummer",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN",
    string: "streng",
    number: "tal",
    boolean: "boolean",
    array: "liste",
    object: "objekt",
    set: "s\xE6t",
    file: "fil"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Ugyldigt input: forventede instanceof ${t.expected}, fik ${c}` : `Ugyldigt input: forventede ${n}, fik ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Ugyldig v\xE6rdi: forventede ${h(t.values[0])}` : `Ugyldigt valg: forventede en af f\xF8lgende ${p(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin), c = o[t.origin] ?? t.origin;
        return a ? `For stor: forventede ${c ?? "value"} ${a.verb} ${n} ${t.maximum.toString()} ${a.unit ?? "elementer"}` : `For stor: forventede ${c ?? "value"} havde ${n} ${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin), c = o[t.origin] ?? t.origin;
        return a ? `For lille: forventede ${c} ${a.verb} ${n} ${t.minimum.toString()} ${a.unit}` : `For lille: forventede ${c} havde ${n} ${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Ugyldig streng: skal starte med "${n.prefix}"` : n.format === "ends_with" ? `Ugyldig streng: skal ende med "${n.suffix}"` : n.format === "includes" ? `Ugyldig streng: skal indeholde "${n.includes}"` : n.format === "regex" ? `Ugyldig streng: skal matche m\xF8nsteret ${n.pattern}` : `Ugyldig ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Ugyldigt tal: skal v\xE6re deleligt med ${t.divisor}`;
      case "unrecognized_keys":
        return `${t.keys.length > 1 ? "Ukendte n\xF8gler" : "Ukendt n\xF8gle"}: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `Ugyldig n\xF8gle i ${t.origin}`;
      case "invalid_union":
        return "Ugyldigt input: matcher ingen af de tilladte typer";
      case "invalid_element":
        return `Ugyldig v\xE6rdi i ${t.origin}`;
      default:
        return "Ugyldigt input";
    }
  };
}, "error");
function vu() {
  return {
    localeError: lg()
  };
}
u(vu, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/de.js
var dg = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "Zeichen", verb: "zu haben" },
    file: { unit: "Bytes", verb: "zu haben" },
    array: { unit: "Elemente", verb: "zu haben" },
    set: { unit: "Elemente", verb: "zu haben" },
    map: { unit: "Elemente", verb: "zu haben" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "Eingabe",
    email: "E-Mail-Adresse",
    url: "URL",
    emoji: "Emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO-Datum und -Uhrzeit",
    date: "ISO-Datum",
    time: "ISO-Uhrzeit",
    duration: "ISO-Dauer",
    ipv4: "IPv4-Adresse",
    ipv6: "IPv6-Adresse",
    mac: "MAC-Adresse",
    cidrv4: "IPv4-Bereich",
    cidrv6: "IPv6-Bereich",
    base64: "Base64-codierter String",
    base64url: "Base64-URL-codierter String",
    json_string: "JSON-String",
    e164: "E.164-Nummer",
    credit_card: "Kreditkartennummer",
    jwt: "JWT",
    template_literal: "Eingabe"
  }, o = {
    nan: "NaN",
    number: "Zahl",
    array: "Array"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Ung\xFCltige Eingabe: erwartet instanceof ${t.expected}, erhalten ${c}` : `Ung\xFCltige Eingabe: erwartet ${n}, erhalten ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Ung\xFCltige Eingabe: erwartet ${h(t.values[0])}` : `Ung\xFCltige Option: erwartet eine von ${p(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Zu gro\xDF: erwartet, dass ${t.origin ?? "Wert"} ${n}${t.maximum.toString()} ${a.unit ?? "Elemente"} hat` : `Zu gro\xDF: erwartet, dass ${t.origin ?? "Wert"} ${n}${t.maximum.toString()} ist`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Zu klein: erwartet, dass ${t.origin} ${n}${t.minimum.toString()} ${a.unit} hat` : `Zu klein: erwartet, dass ${t.origin} ${n}${t.minimum.toString()} ist`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Ung\xFCltiger String: muss mit "${n.prefix}" beginnen` : n.format === "ends_with" ? `Ung\xFCltiger String: muss mit "${n.suffix}" enden` : n.format === "includes" ? `Ung\xFCltiger String: muss "${n.includes}" enthalten` : n.format === "regex" ? `Ung\xFCltiger String: muss dem Muster ${n.pattern} entsprechen` : `Ung\xFCltig: ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Ung\xFCltige Zahl: muss ein Vielfaches von ${t.divisor} sein`;
      case "unrecognized_keys":
        return `${t.keys.length > 1 ? "Unbekannte Schl\xFCssel" : "Unbekannter Schl\xFCssel"}: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `Ung\xFCltiger Schl\xFCssel in ${t.origin}`;
      case "invalid_union":
        return "Ung\xFCltige Eingabe";
      case "invalid_element":
        return `Ung\xFCltiger Wert in ${t.origin}`;
      default:
        return "Ung\xFCltige Eingabe";
    }
  };
}, "error");
function $u() {
  return {
    localeError: dg()
  };
}
u($u, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/el.js
var mg = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "\u03C7\u03B1\u03C1\u03B1\u03BA\u03C4\u03AE\u03C1\u03B5\u03C2", verb: "\u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9" },
    file: { unit: "bytes", verb: "\u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9" },
    array: { unit: "\u03C3\u03C4\u03BF\u03B9\u03C7\u03B5\u03AF\u03B1", verb: "\u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9" },
    set: { unit: "\u03C3\u03C4\u03BF\u03B9\u03C7\u03B5\u03AF\u03B1", verb: "\u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9" },
    map: { unit: "\u03BA\u03B1\u03C4\u03B1\u03C7\u03C9\u03C1\u03AE\u03C3\u03B5\u03B9\u03C2", verb: "\u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "\u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2",
    email: "\u03B4\u03B9\u03B5\u03CD\u03B8\u03C5\u03BD\u03C3\u03B7 email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u03B7\u03BC\u03B5\u03C1\u03BF\u03BC\u03B7\u03BD\u03AF\u03B1 \u03BA\u03B1\u03B9 \u03CE\u03C1\u03B1",
    date: "ISO \u03B7\u03BC\u03B5\u03C1\u03BF\u03BC\u03B7\u03BD\u03AF\u03B1",
    time: "ISO \u03CE\u03C1\u03B1",
    duration: "ISO \u03B4\u03B9\u03AC\u03C1\u03BA\u03B5\u03B9\u03B1",
    ipv4: "\u03B4\u03B9\u03B5\u03CD\u03B8\u03C5\u03BD\u03C3\u03B7 IPv4",
    ipv6: "\u03B4\u03B9\u03B5\u03CD\u03B8\u03C5\u03BD\u03C3\u03B7 IPv6",
    mac: "\u03B4\u03B9\u03B5\u03CD\u03B8\u03C5\u03BD\u03C3\u03B7 MAC",
    cidrv4: "\u03B5\u03CD\u03C1\u03BF\u03C2 IPv4",
    cidrv6: "\u03B5\u03CD\u03C1\u03BF\u03C2 IPv6",
    base64: "\u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC \u03BA\u03C9\u03B4\u03B9\u03BA\u03BF\u03C0\u03BF\u03B9\u03B7\u03BC\u03AD\u03BD\u03B7 \u03C3\u03B5 base64",
    base64url: "\u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC \u03BA\u03C9\u03B4\u03B9\u03BA\u03BF\u03C0\u03BF\u03B9\u03B7\u03BC\u03AD\u03BD\u03B7 \u03C3\u03B5 base64url",
    json_string: "\u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC JSON",
    e164: "\u03B1\u03C1\u03B9\u03B8\u03BC\u03CC\u03C2 E.164",
    credit_card: "\u03B1\u03C1\u03B9\u03B8\u03BC\u03CC\u03C2 \u03C0\u03B9\u03C3\u03C4\u03C9\u03C4\u03B9\u03BA\u03AE\u03C2 \u03BA\u03AC\u03C1\u03C4\u03B1\u03C2",
    jwt: "JWT",
    template_literal: "\u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2"
  }, o = {
    nan: "NaN"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return typeof t.expected == "string" && /^[A-Z]/.test(t.expected) ? `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD instanceof ${t.expected}, \u03BB\u03AE\u03C6\u03B8\u03B7\u03BA\u03B5 ${c}` : `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${n}, \u03BB\u03AE\u03C6\u03B8\u03B7\u03BA\u03B5 ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${h(t.values[0])}` : `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03C0\u03B9\u03BB\u03BF\u03B3\u03AE: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD \u03AD\u03BD\u03B1 \u03B1\u03C0\u03CC ${p(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u03A0\u03BF\u03BB\u03CD \u03BC\u03B5\u03B3\u03AC\u03BB\u03BF: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${t.origin ?? "\u03C4\u03B9\u03BC\u03AE"} \u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9 ${n}${t.maximum.toString()} ${a.unit ?? "\u03C3\u03C4\u03BF\u03B9\u03C7\u03B5\u03AF\u03B1"}` : `\u03A0\u03BF\u03BB\u03CD \u03BC\u03B5\u03B3\u03AC\u03BB\u03BF: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${t.origin ?? "\u03C4\u03B9\u03BC\u03AE"} \u03BD\u03B1 \u03B5\u03AF\u03BD\u03B1\u03B9 ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u03A0\u03BF\u03BB\u03CD \u03BC\u03B9\u03BA\u03C1\u03CC: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${t.origin} \u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9 ${n}${t.minimum.toString()} ${a.unit}` : `\u03A0\u03BF\u03BB\u03CD \u03BC\u03B9\u03BA\u03C1\u03CC: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${t.origin} \u03BD\u03B1 \u03B5\u03AF\u03BD\u03B1\u03B9 ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC: \u03C0\u03C1\u03AD\u03C0\u03B5\u03B9 \u03BD\u03B1 \u03BE\u03B5\u03BA\u03B9\u03BD\u03AC \u03BC\u03B5 "${n.prefix}"` : n.format === "ends_with" ? `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC: \u03C0\u03C1\u03AD\u03C0\u03B5\u03B9 \u03BD\u03B1 \u03C4\u03B5\u03BB\u03B5\u03B9\u03CE\u03BD\u03B5\u03B9 \u03BC\u03B5 "${n.suffix}"` : n.format === "includes" ? `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC: \u03C0\u03C1\u03AD\u03C0\u03B5\u03B9 \u03BD\u03B1 \u03C0\u03B5\u03C1\u03B9\u03AD\u03C7\u03B5\u03B9 "${n.includes}"` : n.format === "regex" ? `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC: \u03C0\u03C1\u03AD\u03C0\u03B5\u03B9 \u03BD\u03B1 \u03C4\u03B1\u03B9\u03C1\u03B9\u03AC\u03B6\u03B5\u03B9 \u03BC\u03B5 \u03C4\u03BF \u03BC\u03BF\u03C4\u03AF\u03B2\u03BF ${n.pattern}` : `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03BF: ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03BF\u03C2 \u03B1\u03C1\u03B9\u03B8\u03BC\u03CC\u03C2: \u03C0\u03C1\u03AD\u03C0\u03B5\u03B9 \u03BD\u03B1 \u03B5\u03AF\u03BD\u03B1\u03B9 \u03C0\u03BF\u03BB\u03BB\u03B1\u03C0\u03BB\u03AC\u03C3\u03B9\u03BF \u03C4\u03BF\u03C5 ${t.divisor}`;
      case "unrecognized_keys":
        return `\u0386\u03B3\u03BD\u03C9\u03C3\u03C4${t.keys.length > 1 ? "\u03B1" : "\u03BF"} \u03BA\u03BB\u03B5\u03B9\u03B4${t.keys.length > 1 ? "\u03B9\u03AC" : "\u03AF"}: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03BF \u03BA\u03BB\u03B5\u03B9\u03B4\u03AF \u03C3\u03C4\u03BF ${t.origin}`;
      case "invalid_union":
        return "\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2";
      case "invalid_element":
        return `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03C4\u03B9\u03BC\u03AE \u03C3\u03C4\u03BF ${t.origin}`;
      default:
        return "\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2";
    }
  };
}, "error");
function hu() {
  return {
    localeError: mg()
  };
}
u(hu, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/en.js
var fg = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "characters", verb: "to have" },
    file: { unit: "bytes", verb: "to have" },
    array: { unit: "items", verb: "to have" },
    set: { unit: "items", verb: "to have" },
    map: { unit: "entries", verb: "to have" }
  };
  function r(n) {
    return e[n] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "input",
    email: "email address",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datetime",
    date: "ISO date",
    time: "ISO time",
    duration: "ISO duration",
    ipv4: "IPv4 address",
    ipv6: "IPv6 address",
    mac: "MAC address",
    cidrv4: "IPv4 range",
    cidrv6: "IPv6 range",
    base64: "base64-encoded string",
    base64url: "base64url-encoded string",
    json_string: "JSON string",
    e164: "E.164 number",
    credit_card: "credit card number",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    // Compatibility: "nan" -> "NaN" for display
    nan: "NaN"
    // All other type names omitted - they fall back to raw values via ?? operator
  };
  function t(n, a) {
    return n === "number" && typeof a == "number" && !Number.isFinite(a) ? String(a) : o[n] ?? n;
  }
  return u(t, "getTypeName"), (n) => {
    switch (n.code) {
      case "invalid_type": {
        let a = t(n.expected), c = _(n.input), s = t(c, n.input);
        return `Invalid input: expected ${a}, received ${s}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `Invalid input: expected ${h(n.values[0])}` : `Invalid option: expected one of ${p(n.values, "|")}`;
      case "too_big": {
        let a = n.exact ? "exactly " : n.inclusive ? "<=" : "<", c = r(n.origin);
        return c ? `Too big: expected ${n.origin ?? "value"} to have ${a}${n.maximum.toString()} ${c.unit ?? "elements"}` : `Too big: expected ${n.origin ?? "value"} to be ${a}${n.maximum.toString()}`;
      }
      case "too_small": {
        let a = n.exact ? "exactly " : n.inclusive ? ">=" : ">", c = r(n.origin);
        return c ? `Too small: expected ${n.origin} to have ${a}${n.minimum.toString()} ${c.unit}` : `Too small: expected ${n.origin} to be ${a}${n.minimum.toString()}`;
      }
      case "invalid_format": {
        let a = n;
        return a.format === "starts_with" ? `Invalid string: must start with "${a.prefix}"` : a.format === "ends_with" ? `Invalid string: must end with "${a.suffix}"` : a.format === "includes" ? `Invalid string: must include "${a.includes}"` : a.format === "regex" ? `Invalid string: must match pattern ${a.pattern}` : `Invalid ${i[a.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `Invalid number: must be a multiple of ${n.divisor}`;
      case "unrecognized_keys":
        return `Unrecognized key${n.keys.length > 1 ? "s" : ""}: ${p(n.keys, ", ")}`;
      case "invalid_key":
        return `Invalid key in ${n.origin}`;
      case "invalid_union":
        return n.options && Array.isArray(n.options) && n.options.length > 0 ? `Invalid discriminator value. Expected ${n.options.map((c) => `'${c}'`).join(" | ")}` : n.inclusive === !1 ? "Invalid input: more than one option matched" : "Invalid input";
      case "invalid_element":
        return `Invalid value in ${n.origin}`;
      default:
        return "Invalid input";
    }
  };
}, "error");
function Qt() {
  return {
    localeError: fg()
  };
}
u(Qt, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/eo.js
var pg = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "karaktrojn", verb: "havi" },
    file: { unit: "bajtojn", verb: "havi" },
    array: { unit: "elementojn", verb: "havi" },
    set: { unit: "elementojn", verb: "havi" },
    map: { unit: "elementojn", verb: "havi" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "enigo",
    email: "retadreso",
    url: "URL",
    emoji: "emo\u011Dio",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO-datotempo",
    date: "ISO-dato",
    time: "ISO-tempo",
    duration: "ISO-da\u016Dro",
    ipv4: "IPv4-adreso",
    ipv6: "IPv6-adreso",
    mac: "MAC-adreso",
    cidrv4: "IPv4-rango",
    cidrv6: "IPv6-rango",
    base64: "64-ume kodita karaktraro",
    base64url: "URL-64-ume kodita karaktraro",
    json_string: "JSON-karaktraro",
    e164: "E.164-nombro",
    credit_card: "kreditkarta numero",
    jwt: "JWT",
    template_literal: "enigo"
  }, o = {
    nan: "NaN",
    number: "nombro",
    array: "tabelo",
    null: "senvalora"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Nevalida enigo: atendi\u011Dis instanceof ${t.expected}, ricevi\u011Dis ${c}` : `Nevalida enigo: atendi\u011Dis ${n}, ricevi\u011Dis ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Nevalida enigo: atendi\u011Dis ${h(t.values[0])}` : `Nevalida opcio: atendi\u011Dis unu el ${p(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Tro granda: atendi\u011Dis ke ${t.origin ?? "valoro"} havu ${n}${t.maximum.toString()} ${a.unit ?? "elementojn"}` : `Tro granda: atendi\u011Dis ke ${t.origin ?? "valoro"} havu ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Tro malgranda: atendi\u011Dis ke ${t.origin} havu ${n}${t.minimum.toString()} ${a.unit}` : `Tro malgranda: atendi\u011Dis ke ${t.origin} estu ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Nevalida karaktraro: devas komenci\u011Di per "${n.prefix}"` : n.format === "ends_with" ? `Nevalida karaktraro: devas fini\u011Di per "${n.suffix}"` : n.format === "includes" ? `Nevalida karaktraro: devas inkluzivi "${n.includes}"` : n.format === "regex" ? `Nevalida karaktraro: devas kongrui kun la modelo ${n.pattern}` : `Nevalida ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Nevalida nombro: devas esti oblo de ${t.divisor}`;
      case "unrecognized_keys":
        return `Nekonata${t.keys.length > 1 ? "j" : ""} \u015Dlosilo${t.keys.length > 1 ? "j" : ""}: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `Nevalida \u015Dlosilo en ${t.origin}`;
      case "invalid_union":
        return "Nevalida enigo";
      case "invalid_element":
        return `Nevalida valoro en ${t.origin}`;
      default:
        return "Nevalida enigo";
    }
  };
}, "error");
function _u() {
  return {
    localeError: pg()
  };
}
u(_u, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/es.js
var gg = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "caracteres", verb: "tener" },
    file: { unit: "bytes", verb: "tener" },
    array: { unit: "elementos", verb: "tener" },
    set: { unit: "elementos", verb: "tener" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "entrada",
    email: "direcci\xF3n de correo electr\xF3nico",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "fecha y hora ISO",
    date: "fecha ISO",
    time: "hora ISO",
    duration: "duraci\xF3n ISO",
    ipv4: "direcci\xF3n IPv4",
    ipv6: "direcci\xF3n IPv6",
    mac: "direcci\xF3n MAC",
    cidrv4: "rango IPv4",
    cidrv6: "rango IPv6",
    base64: "cadena codificada en base64",
    base64url: "URL codificada en base64",
    json_string: "cadena JSON",
    e164: "n\xFAmero E.164",
    credit_card: "n\xFAmero de tarjeta de cr\xE9dito",
    jwt: "JWT",
    template_literal: "entrada"
  }, o = {
    nan: "NaN",
    string: "texto",
    number: "n\xFAmero",
    boolean: "booleano",
    array: "arreglo",
    object: "objeto",
    set: "conjunto",
    file: "archivo",
    date: "fecha",
    bigint: "n\xFAmero grande",
    symbol: "s\xEDmbolo",
    undefined: "indefinido",
    null: "nulo",
    function: "funci\xF3n",
    map: "mapa",
    record: "registro",
    tuple: "tupla",
    enum: "enumeraci\xF3n",
    union: "uni\xF3n",
    literal: "literal",
    promise: "promesa",
    void: "vac\xEDo",
    never: "nunca",
    unknown: "desconocido",
    any: "cualquiera"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Entrada inv\xE1lida: se esperaba instanceof ${t.expected}, recibido ${c}` : `Entrada inv\xE1lida: se esperaba ${n}, recibido ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Entrada inv\xE1lida: se esperaba ${h(t.values[0])}` : `Opci\xF3n inv\xE1lida: se esperaba una de ${p(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin), c = o[t.origin] ?? t.origin;
        return a ? `Demasiado grande: se esperaba que ${c ?? "valor"} tuviera ${n}${t.maximum.toString()} ${a.unit ?? "elementos"}` : `Demasiado grande: se esperaba que ${c ?? "valor"} fuera ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin), c = o[t.origin] ?? t.origin;
        return a ? `Demasiado peque\xF1o: se esperaba que ${c} tuviera ${n}${t.minimum.toString()} ${a.unit}` : `Demasiado peque\xF1o: se esperaba que ${c} fuera ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Cadena inv\xE1lida: debe comenzar con "${n.prefix}"` : n.format === "ends_with" ? `Cadena inv\xE1lida: debe terminar en "${n.suffix}"` : n.format === "includes" ? `Cadena inv\xE1lida: debe incluir "${n.includes}"` : n.format === "regex" ? `Cadena inv\xE1lida: debe coincidir con el patr\xF3n ${n.pattern}` : `Inv\xE1lido ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `N\xFAmero inv\xE1lido: debe ser m\xFAltiplo de ${t.divisor}`;
      case "unrecognized_keys":
        return `Llave${t.keys.length > 1 ? "s" : ""} desconocida${t.keys.length > 1 ? "s" : ""}: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `Llave inv\xE1lida en ${o[t.origin] ?? t.origin}`;
      case "invalid_union":
        return "Entrada inv\xE1lida";
      case "invalid_element":
        return `Valor inv\xE1lido en ${o[t.origin] ?? t.origin}`;
      default:
        return "Entrada inv\xE1lida";
    }
  };
}, "error");
function yu() {
  return {
    localeError: gg()
  };
}
u(yu, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/fa.js
var vg = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "\u06A9\u0627\u0631\u0627\u06A9\u062A\u0631", verb: "\u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F" },
    file: { unit: "\u0628\u0627\u06CC\u062A", verb: "\u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F" },
    array: { unit: "\u0622\u06CC\u062A\u0645", verb: "\u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F" },
    set: { unit: "\u0622\u06CC\u062A\u0645", verb: "\u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F" },
    map: { unit: "\u0622\u06CC\u062A\u0645", verb: "\u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "\u0648\u0631\u0648\u062F\u06CC",
    email: "\u0622\u062F\u0631\u0633 \u0627\u06CC\u0645\u06CC\u0644",
    url: "URL",
    emoji: "\u0627\u06CC\u0645\u0648\u062C\u06CC",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u062A\u0627\u0631\u06CC\u062E \u0648 \u0632\u0645\u0627\u0646 \u0627\u06CC\u0632\u0648",
    date: "\u062A\u0627\u0631\u06CC\u062E \u0627\u06CC\u0632\u0648",
    time: "\u0632\u0645\u0627\u0646 \u0627\u06CC\u0632\u0648",
    duration: "\u0645\u062F\u062A \u0632\u0645\u0627\u0646 \u0627\u06CC\u0632\u0648",
    ipv4: "IPv4 \u0622\u062F\u0631\u0633",
    ipv6: "IPv6 \u0622\u062F\u0631\u0633",
    mac: "MAC \u0622\u062F\u0631\u0633",
    cidrv4: "IPv4 \u062F\u0627\u0645\u0646\u0647",
    cidrv6: "IPv6 \u062F\u0627\u0645\u0646\u0647",
    base64: "base64-encoded \u0631\u0634\u062A\u0647",
    base64url: "base64url-encoded \u0631\u0634\u062A\u0647",
    json_string: "JSON \u0631\u0634\u062A\u0647",
    e164: "E.164 \u0639\u062F\u062F",
    credit_card: "\u0634\u0645\u0627\u0631\u0647 \u06A9\u0627\u0631\u062A \u0627\u0639\u062A\u0628\u0627\u0631\u06CC",
    jwt: "JWT",
    template_literal: "\u0648\u0631\u0648\u062F\u06CC"
  }, o = {
    nan: "NaN",
    number: "\u0639\u062F\u062F",
    array: "\u0622\u0631\u0627\u06CC\u0647"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0645\u06CC\u200C\u0628\u0627\u06CC\u0633\u062A instanceof ${t.expected} \u0645\u06CC\u200C\u0628\u0648\u062F\u060C ${c} \u062F\u0631\u06CC\u0627\u0641\u062A \u0634\u062F` : `\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0645\u06CC\u200C\u0628\u0627\u06CC\u0633\u062A ${n} \u0645\u06CC\u200C\u0628\u0648\u062F\u060C ${c} \u062F\u0631\u06CC\u0627\u0641\u062A \u0634\u062F`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0645\u06CC\u200C\u0628\u0627\u06CC\u0633\u062A ${h(t.values[0])} \u0645\u06CC\u200C\u0628\u0648\u062F` : `\u06AF\u0632\u06CC\u0646\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0645\u06CC\u200C\u0628\u0627\u06CC\u0633\u062A \u06CC\u06A9\u06CC \u0627\u0632 ${p(t.values, "|")} \u0645\u06CC\u200C\u0628\u0648\u062F`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u062E\u06CC\u0644\u06CC \u0628\u0632\u0631\u06AF: ${t.origin ?? "\u0645\u0642\u062F\u0627\u0631"} \u0628\u0627\u06CC\u062F ${n}${t.maximum.toString()} ${a.unit ?? "\u0639\u0646\u0635\u0631"} \u0628\u0627\u0634\u062F` : `\u062E\u06CC\u0644\u06CC \u0628\u0632\u0631\u06AF: ${t.origin ?? "\u0645\u0642\u062F\u0627\u0631"} \u0628\u0627\u06CC\u062F ${n}${t.maximum.toString()} \u0628\u0627\u0634\u062F`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u062E\u06CC\u0644\u06CC \u06A9\u0648\u0686\u06A9: ${t.origin} \u0628\u0627\u06CC\u062F ${n}${t.minimum.toString()} ${a.unit} \u0628\u0627\u0634\u062F` : `\u062E\u06CC\u0644\u06CC \u06A9\u0648\u0686\u06A9: ${t.origin} \u0628\u0627\u06CC\u062F ${n}${t.minimum.toString()} \u0628\u0627\u0634\u062F`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u0631\u0634\u062A\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0628\u0627 "${n.prefix}" \u0634\u0631\u0648\u0639 \u0634\u0648\u062F` : n.format === "ends_with" ? `\u0631\u0634\u062A\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0628\u0627 "${n.suffix}" \u062A\u0645\u0627\u0645 \u0634\u0648\u062F` : n.format === "includes" ? `\u0631\u0634\u062A\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0634\u0627\u0645\u0644 "${n.includes}" \u0628\u0627\u0634\u062F` : n.format === "regex" ? `\u0631\u0634\u062A\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0628\u0627 \u0627\u0644\u06AF\u0648\u06CC ${n.pattern} \u0645\u0637\u0627\u0628\u0642\u062A \u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F` : `${i[n.format] ?? t.format} \u0646\u0627\u0645\u0639\u062A\u0628\u0631`;
      }
      case "not_multiple_of":
        return `\u0639\u062F\u062F \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0645\u0636\u0631\u0628 ${t.divisor} \u0628\u0627\u0634\u062F`;
      case "unrecognized_keys":
        return `\u06A9\u0644\u06CC\u062F${t.keys.length > 1 ? "\u0647\u0627\u06CC" : ""} \u0646\u0627\u0634\u0646\u0627\u0633: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `\u06A9\u0644\u06CC\u062F \u0646\u0627\u0634\u0646\u0627\u0633 \u062F\u0631 ${t.origin}`;
      case "invalid_union":
        return "\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631";
      case "invalid_element":
        return `\u0645\u0642\u062F\u0627\u0631 \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u062F\u0631 ${t.origin}`;
      default:
        return "\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631";
    }
  };
}, "error");
function bu() {
  return {
    localeError: vg()
  };
}
u(bu, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/fi.js
var $g = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "merkki\xE4", subject: "merkkijonon" },
    file: { unit: "tavua", subject: "tiedoston" },
    array: { unit: "alkiota", subject: "listan" },
    set: { unit: "alkiota", subject: "joukon" },
    map: { unit: "alkiota", subject: "kuvauksen" },
    number: { unit: "", subject: "luvun" },
    bigint: { unit: "", subject: "suuren kokonaisluvun" },
    int: { unit: "", subject: "kokonaisluvun" },
    date: { unit: "", subject: "p\xE4iv\xE4m\xE4\xE4r\xE4n" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "s\xE4\xE4nn\xF6llinen lauseke",
    email: "s\xE4hk\xF6postiosoite",
    url: "URL-osoite",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO-aikaleima",
    date: "ISO-p\xE4iv\xE4m\xE4\xE4r\xE4",
    time: "ISO-aika",
    duration: "ISO-kesto",
    ipv4: "IPv4-osoite",
    ipv6: "IPv6-osoite",
    mac: "MAC-osoite",
    cidrv4: "IPv4-alue",
    cidrv6: "IPv6-alue",
    base64: "base64-koodattu merkkijono",
    base64url: "base64url-koodattu merkkijono",
    json_string: "JSON-merkkijono",
    e164: "E.164-luku",
    credit_card: "luottokortin numero",
    jwt: "JWT",
    template_literal: "templaattimerkkijono"
  }, o = {
    nan: "NaN"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Virheellinen tyyppi: odotettiin instanceof ${t.expected}, oli ${c}` : `Virheellinen tyyppi: odotettiin ${n}, oli ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Virheellinen sy\xF6te: t\xE4ytyy olla ${h(t.values[0])}` : `Virheellinen valinta: t\xE4ytyy olla yksi seuraavista: ${p(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Liian suuri: ${a.subject} t\xE4ytyy olla ${n}${t.maximum.toString()} ${a.unit}`.trim() : `Liian suuri: arvon t\xE4ytyy olla ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Liian pieni: ${a.subject} t\xE4ytyy olla ${n}${t.minimum.toString()} ${a.unit}`.trim() : `Liian pieni: arvon t\xE4ytyy olla ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Virheellinen sy\xF6te: t\xE4ytyy alkaa "${n.prefix}"` : n.format === "ends_with" ? `Virheellinen sy\xF6te: t\xE4ytyy loppua "${n.suffix}"` : n.format === "includes" ? `Virheellinen sy\xF6te: t\xE4ytyy sis\xE4lt\xE4\xE4 "${n.includes}"` : n.format === "regex" ? `Virheellinen sy\xF6te: t\xE4ytyy vastata s\xE4\xE4nn\xF6llist\xE4 lauseketta ${n.pattern}` : `Virheellinen ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Virheellinen luku: t\xE4ytyy olla luvun ${t.divisor} monikerta`;
      case "unrecognized_keys":
        return `${t.keys.length > 1 ? "Tuntemattomat avaimet" : "Tuntematon avain"}: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return "Virheellinen avain tietueessa";
      case "invalid_union":
        return "Virheellinen unioni";
      case "invalid_element":
        return "Virheellinen arvo joukossa";
      default:
        return "Virheellinen sy\xF6te";
    }
  };
}, "error");
function ku() {
  return {
    localeError: $g()
  };
}
u(ku, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/fr.js
var hg = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "caract\xE8res", verb: "avoir" },
    file: { unit: "octets", verb: "avoir" },
    array: { unit: "\xE9l\xE9ments", verb: "avoir" },
    set: { unit: "\xE9l\xE9ments", verb: "avoir" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "expression r\xE9guli\xE8re",
    email: "adresse e-mail",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "date et heure ISO",
    date: "date ISO",
    time: "heure ISO",
    duration: "dur\xE9e ISO",
    ipv4: "adresse IPv4",
    ipv6: "adresse IPv6",
    mac: "adresse MAC",
    cidrv4: "plage IPv4",
    cidrv6: "plage IPv6",
    base64: "cha\xEEne de caract\xE8res encod\xE9e en base64",
    base64url: "cha\xEEne de caract\xE8res encod\xE9e en base64url",
    json_string: "cha\xEEne de caract\xE8res JSON",
    e164: "num\xE9ro au format E.164",
    credit_card: "num\xE9ro de carte de cr\xE9dit",
    jwt: "JWT",
    template_literal: "entr\xE9e"
  }, o = {
    string: "cha\xEEne de caract\xE8res",
    number: "nombre",
    int: "entier",
    boolean: "bool\xE9en",
    bigint: "grand entier",
    symbol: "symbole",
    undefined: "ind\xE9fini",
    null: "null",
    never: "jamais",
    void: "vide",
    date: "date",
    array: "tableau",
    object: "objet",
    tuple: "tuple",
    record: "record",
    map: "map",
    set: "ensemble",
    file: "fichier",
    nonoptional: "non optionnel",
    nan: "NaN",
    function: "fonction"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Entr\xE9e invalide : instance de ${t.expected} attendu, ${c} re\xE7u` : `Entr\xE9e invalide : ${n} attendu, ${c} re\xE7u`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Entr\xE9e invalide : ${h(t.values[0])} attendu` : `Option invalide : une valeur parmi ${p(t.values, "|")} attendue`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Trop grand : ${o[t.origin] ?? "valeur"} doit ${a.verb} ${n}${t.maximum.toString()} ${a.unit ?? "\xE9l\xE9ment(s)"}` : `Trop grand : ${o[t.origin] ?? "valeur"} doit \xEAtre ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Trop petit : ${o[t.origin] ?? "valeur"} doit ${a.verb} ${n}${t.minimum.toString()} ${a.unit}` : `Trop petit : ${o[t.origin] ?? "valeur"} doit \xEAtre ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Cha\xEEne de caract\xE8res invalide : doit commencer par "${n.prefix}"` : n.format === "ends_with" ? `Cha\xEEne de caract\xE8res invalide : doit se terminer par "${n.suffix}"` : n.format === "includes" ? `Cha\xEEne de caract\xE8res invalide : doit inclure "${n.includes}"` : n.format === "regex" ? `Cha\xEEne de caract\xE8res invalide : doit correspondre au motif ${n.pattern}` : `${i[n.format] ?? t.format} invalide`;
      }
      case "not_multiple_of":
        return `Nombre invalide : doit \xEAtre un multiple de ${t.divisor}`;
      case "unrecognized_keys":
        return `Cl\xE9${t.keys.length > 1 ? "s" : ""} non reconnue${t.keys.length > 1 ? "s" : ""} : ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `Cl\xE9 invalide dans ${t.origin}`;
      case "invalid_union":
        return "Entr\xE9e invalide";
      case "invalid_element":
        return `Valeur invalide dans ${t.origin}`;
      default:
        return "Entr\xE9e invalide";
    }
  };
}, "error");
function xu() {
  return {
    localeError: hg()
  };
}
u(xu, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/fr-CA.js
var _g = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "caract\xE8res", verb: "avoir" },
    file: { unit: "octets", verb: "avoir" },
    array: { unit: "\xE9l\xE9ments", verb: "avoir" },
    set: { unit: "\xE9l\xE9ments", verb: "avoir" },
    map: { unit: "\xE9l\xE9ments", verb: "avoir" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "entr\xE9e",
    email: "adresse courriel",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "date-heure ISO",
    date: "date ISO",
    time: "heure ISO",
    duration: "dur\xE9e ISO",
    ipv4: "adresse IPv4",
    ipv6: "adresse IPv6",
    mac: "adresse MAC",
    cidrv4: "plage IPv4",
    cidrv6: "plage IPv6",
    base64: "cha\xEEne encod\xE9e en base64",
    base64url: "cha\xEEne encod\xE9e en base64url",
    json_string: "cha\xEEne JSON",
    e164: "num\xE9ro E.164",
    credit_card: "num\xE9ro de carte de cr\xE9dit",
    jwt: "JWT",
    template_literal: "entr\xE9e"
  }, o = {
    nan: "NaN"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Entr\xE9e invalide : attendu instanceof ${t.expected}, re\xE7u ${c}` : `Entr\xE9e invalide : attendu ${n}, re\xE7u ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Entr\xE9e invalide : attendu ${h(t.values[0])}` : `Option invalide : attendu l'une des valeurs suivantes ${p(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "\u2264" : "<", a = r(t.origin);
        return a ? `Trop grand : attendu que ${t.origin ?? "la valeur"} ait ${n}${t.maximum.toString()} ${a.unit}` : `Trop grand : attendu que ${t.origin ?? "la valeur"} soit ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? "\u2265" : ">", a = r(t.origin);
        return a ? `Trop petit : attendu que ${t.origin} ait ${n}${t.minimum.toString()} ${a.unit}` : `Trop petit : attendu que ${t.origin} soit ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Cha\xEEne invalide : doit commencer par "${n.prefix}"` : n.format === "ends_with" ? `Cha\xEEne invalide : doit se terminer par "${n.suffix}"` : n.format === "includes" ? `Cha\xEEne invalide : doit inclure "${n.includes}"` : n.format === "regex" ? `Cha\xEEne invalide : doit correspondre au motif ${n.pattern}` : `${i[n.format] ?? t.format} invalide`;
      }
      case "not_multiple_of":
        return `Nombre invalide : doit \xEAtre un multiple de ${t.divisor}`;
      case "unrecognized_keys":
        return `Cl\xE9${t.keys.length > 1 ? "s" : ""} non reconnue${t.keys.length > 1 ? "s" : ""} : ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `Cl\xE9 invalide dans ${t.origin}`;
      case "invalid_union":
        return "Entr\xE9e invalide";
      case "invalid_element":
        return `Valeur invalide dans ${t.origin}`;
      default:
        return "Entr\xE9e invalide";
    }
  };
}, "error");
function Iu() {
  return {
    localeError: _g()
  };
}
u(Iu, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/gu.js
var yg = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "\u0A85\u0A95\u0ACD\u0AB7\u0AB0", verb: "\u0AB9\u0ACB\u0AB5\u0ABE \u0A9C\u0ACB\u0A88\u0A8F" },
    file: { unit: "\u0AAC\u0ABE\u0AAF\u0A9F", verb: "\u0AB9\u0ACB\u0AB5\u0ABE \u0A9C\u0ACB\u0A88\u0A8F" },
    array: { unit: "\u0A86\u0A87\u0A9F\u0AAE", verb: "\u0AB9\u0ACB\u0AB5\u0ABE \u0A9C\u0ACB\u0A88\u0A8F" },
    set: { unit: "\u0A86\u0A87\u0A9F\u0AAE", verb: "\u0AB9\u0ACB\u0AB5\u0ABE \u0A9C\u0ACB\u0A88\u0A8F" },
    map: { unit: "\u0A8F\u0AA8\u0ACD\u0A9F\u0ACD\u0AB0\u0AC0", verb: "\u0AB9\u0ACB\u0AB5\u0ABE \u0A9C\u0ACB\u0A88\u0A8F" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "\u0A87\u0AA8\u0AAA\u0AC1\u0A9F",
    email: "\u0A88\u0AAE\u0AC7\u0A87\u0AB2 \u0A8F\u0AA1\u0ACD\u0AB0\u0AC7\u0AB8",
    url: "URL",
    emoji: "\u0A87\u0AAE\u0ACB\u0A9C\u0AC0",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0AA4\u0ABE\u0AB0\u0AC0\u0A96 \u0A85\u0AA8\u0AC7 \u0AB8\u0AAE\u0AAF",
    date: "ISO \u0AA4\u0ABE\u0AB0\u0AC0\u0A96",
    time: "ISO \u0AB8\u0AAE\u0AAF",
    duration: "ISO \u0A85\u0AB5\u0AA7\u0ABF",
    ipv4: "IPv4 \u0A8F\u0AA1\u0ACD\u0AB0\u0AC7\u0AB8",
    ipv6: "IPv6 \u0A8F\u0AA1\u0ACD\u0AB0\u0AC7\u0AB8",
    mac: "MAC \u0A8F\u0AA1\u0ACD\u0AB0\u0AC7\u0AB8",
    cidrv4: "IPv4 \u0AB6\u0ACD\u0AB0\u0AC7\u0AA3\u0AC0",
    cidrv6: "IPv6 \u0AB6\u0ACD\u0AB0\u0AC7\u0AA3\u0AC0",
    base64: "base64-\u0A8F\u0AA8\u0ACD\u0A95\u0ACB\u0AA1\u0AC7\u0AA1 \u0AB8\u0ACD\u0A9F\u0ACD\u0AB0\u0ABF\u0A82\u0A97",
    base64url: "base64url-\u0A8F\u0AA8\u0ACD\u0A95\u0ACB\u0AA1\u0AC7\u0AA1 \u0AB8\u0ACD\u0A9F\u0ACD\u0AB0\u0ABF\u0A82\u0A97",
    json_string: "JSON \u0AB8\u0ACD\u0A9F\u0ACD\u0AB0\u0ABF\u0A82\u0A97",
    e164: "E.164 \u0AA8\u0A82\u0AAC\u0AB0",
    credit_card: "\u0A95\u0ACD\u0AB0\u0AC7\u0AA1\u0ABF\u0A9F \u0A95\u0ABE\u0AB0\u0ACD\u0AA1 \u0AA8\u0A82\u0AAC\u0AB0",
    jwt: "JWT",
    template_literal: "\u0A87\u0AA8\u0AAA\u0AC1\u0A9F"
  }, o = {
    nan: "NaN"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0A87\u0AA8\u0AAA\u0AC1\u0A9F: \u0A85\u0AAA\u0AC7\u0A95\u0ACD\u0AB7\u0ABF\u0AA4 ${n}, \u0AAA\u0ACD\u0AB0\u0ABE\u0AAA\u0ACD\u0AA4 ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0A87\u0AA8\u0AAA\u0AC1\u0A9F: \u0A85\u0AAA\u0AC7\u0A95\u0ACD\u0AB7\u0ABF\u0AA4 ${h(t.values[0])}` : `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AB5\u0ABF\u0A95\u0AB2\u0ACD\u0AAA: ${p(t.values, " | ")} \u0AAE\u0ABE\u0AA7\u0ACD\u0AAF\u0AAE\u0AA5\u0AC0 \u0A8F\u0A95 \u0A85\u0AAA\u0AC7\u0A95\u0ACD\u0AB7\u0ABF\u0AA4`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u0A96\u0AC2\u0AAC \u0AAE\u0ACB\u0A9F\u0AC1\u0A82: ${t.origin ?? "\u0AAE\u0AC2\u0AB2\u0ACD\u0AAF"} ${n}${t.maximum.toString()} ${a.unit ?? "\u0A8F\u0AB2\u0ABF\u0AAE\u0AC7\u0AA8\u0ACD\u0A9F"} \u0AB9\u0ACB\u0AB5\u0ABE \u0A9C\u0ACB\u0A88\u0A8F` : `\u0A96\u0AC2\u0AAC \u0AAE\u0ACB\u0A9F\u0AC1\u0A82: ${t.origin ?? "\u0AAE\u0AC2\u0AB2\u0ACD\u0AAF"} ${n}${t.maximum.toString()} \u0AB9\u0ACB\u0AB5\u0AC1\u0A82 \u0A9C\u0ACB\u0A88\u0A8F`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u0A96\u0AC2\u0AAC \u0AA8\u0ABE\u0AA8\u0AC1\u0A82: ${t.origin} ${n}${t.minimum.toString()} ${a.unit} \u0AB9\u0ACB\u0AB5\u0ABE \u0A9C\u0ACB\u0A88\u0A8F` : `\u0A96\u0AC2\u0AAC \u0AA8\u0ABE\u0AA8\u0AC1\u0A82: ${t.origin} ${n}${t.minimum.toString()} \u0AB9\u0ACB\u0AB5\u0AC1\u0A82 \u0A9C\u0ACB\u0A88\u0A8F`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AB8\u0ACD\u0A9F\u0ACD\u0AB0\u0ABF\u0A82\u0A97: "${n.prefix}" \u0AA5\u0AC0 \u0AB6\u0AB0\u0AC2 \u0AA5\u0AB5\u0AC1\u0A82 \u0A9C\u0ACB\u0A88\u0A8F` : n.format === "ends_with" ? `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AB8\u0ACD\u0A9F\u0ACD\u0AB0\u0ABF\u0A82\u0A97: "${n.suffix}" \u0AAA\u0AB0 \u0AB8\u0AAE\u0ABE\u0AAA\u0ACD\u0AA4 \u0AA5\u0AB5\u0AC1\u0A82 \u0A9C\u0ACB\u0A88\u0A8F` : n.format === "includes" ? `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AB8\u0ACD\u0A9F\u0ACD\u0AB0\u0ABF\u0A82\u0A97: "${n.includes}" \u0AB6\u0ABE\u0AAE\u0AC7\u0AB2 \u0AB9\u0ACB\u0AB5\u0AC1\u0A82 \u0A9C\u0ACB\u0A88\u0A8F` : n.format === "regex" ? `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AB8\u0ACD\u0A9F\u0ACD\u0AB0\u0ABF\u0A82\u0A97: \u0AAA\u0AC7\u0A9F\u0AB0\u0ACD\u0AA8 ${n.pattern} \u0AB8\u0ABE\u0AA5\u0AC7 \u0AAE\u0AC7\u0AB3 \u0A96\u0ABE\u0AB5\u0AC1\u0A82 \u0A9C\u0ACB\u0A88\u0A8F` : `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AA8\u0A82\u0AAC\u0AB0: ${t.divisor} \u0AA8\u0ACB \u0A97\u0AC1\u0AA3\u0ABE\u0A82\u0A95 \u0AB9\u0ACB\u0AB5\u0ACB \u0A9C\u0ACB\u0A88\u0A8F`;
      case "unrecognized_keys":
        return `\u0A93\u0AB3\u0A96\u0AC0 \u0AB6\u0A95\u0ABE\u0AA4\u0ABE \u0AA8\u0AB9\u0AC0\u0A82 \u0AA4\u0AC7 \u0A95\u0AC0${t.keys.length > 1 ? "\u0A93" : ""}: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `${t.origin} \u0AAE\u0ABE\u0A82 \u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0A95\u0AC0`;
      case "invalid_union":
        return t.options && Array.isArray(t.options) && t.options.length > 0 ? `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AA1\u0ABF\u0AB8\u0ACD\u0A95\u0ACD\u0AB0\u0ABF\u0AAE\u0ABF\u0AA8\u0AC7\u0A9F\u0AB0 \u0AAE\u0AC2\u0AB2\u0ACD\u0AAF. \u0A85\u0AAA\u0AC7\u0A95\u0ACD\u0AB7\u0ABF\u0AA4 ${t.options.map((a) => `'${a}'`).join(" | ")}` : "\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0A87\u0AA8\u0AAA\u0AC1\u0A9F";
      case "invalid_element":
        return `${t.origin} \u0AAE\u0ABE\u0A82 \u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AAE\u0AC2\u0AB2\u0ACD\u0AAF`;
      default:
        return "\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0A87\u0AA8\u0AAA\u0AC1\u0A9F";
    }
  };
}, "error");
function wu() {
  return {
    localeError: yg()
  };
}
u(wu, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/he.js
var bg = /* @__PURE__ */ u(() => {
  let e = {
    string: { label: "\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA", gender: "f" },
    number: { label: "\u05DE\u05E1\u05E4\u05E8", gender: "m" },
    boolean: { label: "\u05E2\u05E8\u05DA \u05D1\u05D5\u05DC\u05D9\u05D0\u05E0\u05D9", gender: "m" },
    bigint: { label: "BigInt", gender: "m" },
    date: { label: "\u05EA\u05D0\u05E8\u05D9\u05DA", gender: "m" },
    array: { label: "\u05DE\u05E2\u05E8\u05DA", gender: "m" },
    object: { label: "\u05D0\u05D5\u05D1\u05D9\u05D9\u05E7\u05D8", gender: "m" },
    null: { label: "\u05E2\u05E8\u05DA \u05E8\u05D9\u05E7 (null)", gender: "m" },
    undefined: { label: "\u05E2\u05E8\u05DA \u05DC\u05D0 \u05DE\u05D5\u05D2\u05D3\u05E8 (undefined)", gender: "m" },
    symbol: { label: "\u05E1\u05D9\u05DE\u05D1\u05D5\u05DC (Symbol)", gender: "m" },
    function: { label: "\u05E4\u05D5\u05E0\u05E7\u05E6\u05D9\u05D4", gender: "f" },
    map: { label: "\u05DE\u05E4\u05D4 (Map)", gender: "f" },
    set: { label: "\u05E7\u05D1\u05D5\u05E6\u05D4 (Set)", gender: "f" },
    file: { label: "\u05E7\u05D5\u05D1\u05E5", gender: "m" },
    promise: { label: "Promise", gender: "m" },
    NaN: { label: "NaN", gender: "m" },
    unknown: { label: "\u05E2\u05E8\u05DA \u05DC\u05D0 \u05D9\u05D3\u05D5\u05E2", gender: "m" },
    value: { label: "\u05E2\u05E8\u05DA", gender: "m" }
  }, r = {
    string: { unit: "\u05EA\u05D5\u05D5\u05D9\u05DD", shortLabel: "\u05E7\u05E6\u05E8", longLabel: "\u05D0\u05E8\u05D5\u05DA" },
    file: { unit: "\u05D1\u05D9\u05D9\u05D8\u05D9\u05DD", shortLabel: "\u05E7\u05D8\u05DF", longLabel: "\u05D2\u05D3\u05D5\u05DC" },
    array: { unit: "\u05E4\u05E8\u05D9\u05D8\u05D9\u05DD", shortLabel: "\u05E7\u05D8\u05DF", longLabel: "\u05D2\u05D3\u05D5\u05DC" },
    set: { unit: "\u05E4\u05E8\u05D9\u05D8\u05D9\u05DD", shortLabel: "\u05E7\u05D8\u05DF", longLabel: "\u05D2\u05D3\u05D5\u05DC" },
    number: { unit: "", shortLabel: "\u05E7\u05D8\u05DF", longLabel: "\u05D2\u05D3\u05D5\u05DC" }
    // no unit
  }, i = /* @__PURE__ */ u((l) => l ? e[l] : void 0, "typeEntry"), o = /* @__PURE__ */ u((l) => {
    let d = i(l);
    return d ? d.label : l ?? e.unknown.label;
  }, "typeLabel"), t = /* @__PURE__ */ u((l) => `\u05D4${o(l)}`, "withDefinite"), n = /* @__PURE__ */ u((l) => (i(l)?.gender ?? "m") === "f" ? "\u05E6\u05E8\u05D9\u05DB\u05D4 \u05DC\u05D4\u05D9\u05D5\u05EA" : "\u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA", "verbFor"), a = /* @__PURE__ */ u((l) => l ? r[l] ?? null : null, "getSizing"), c = {
    regex: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    email: { label: "\u05DB\u05EA\u05D5\u05D1\u05EA \u05D0\u05D9\u05DE\u05D9\u05D9\u05DC", gender: "f" },
    url: { label: "\u05DB\u05EA\u05D5\u05D1\u05EA \u05E8\u05E9\u05EA", gender: "f" },
    emoji: { label: "\u05D0\u05D9\u05DE\u05D5\u05D2'\u05D9", gender: "m" },
    uuid: { label: "UUID", gender: "m" },
    uuidv4: { label: "UUIDv4", gender: "m" },
    uuidv6: { label: "UUIDv6", gender: "m" },
    nanoid: { label: "nanoid", gender: "m" },
    guid: { label: "GUID", gender: "m" },
    cuid: { label: "cuid", gender: "m" },
    cuid2: { label: "cuid2", gender: "m" },
    ulid: { label: "ULID", gender: "m" },
    xid: { label: "XID", gender: "m" },
    ksuid: { label: "KSUID", gender: "m" },
    datetime: { label: "\u05EA\u05D0\u05E8\u05D9\u05DA \u05D5\u05D6\u05DE\u05DF ISO", gender: "m" },
    date: { label: "\u05EA\u05D0\u05E8\u05D9\u05DA ISO", gender: "m" },
    time: { label: "\u05D6\u05DE\u05DF ISO", gender: "m" },
    duration: { label: "\u05DE\u05E9\u05DA \u05D6\u05DE\u05DF ISO", gender: "m" },
    ipv4: { label: "\u05DB\u05EA\u05D5\u05D1\u05EA IPv4", gender: "f" },
    ipv6: { label: "\u05DB\u05EA\u05D5\u05D1\u05EA IPv6", gender: "f" },
    mac: { label: "\u05DB\u05EA\u05D5\u05D1\u05EA MAC", gender: "f" },
    cidrv4: { label: "\u05D8\u05D5\u05D5\u05D7 IPv4", gender: "m" },
    cidrv6: { label: "\u05D8\u05D5\u05D5\u05D7 IPv6", gender: "m" },
    base64: { label: "\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D1\u05D1\u05E1\u05D9\u05E1 64", gender: "f" },
    base64url: { label: "\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D1\u05D1\u05E1\u05D9\u05E1 64 \u05DC\u05DB\u05EA\u05D5\u05D1\u05D5\u05EA \u05E8\u05E9\u05EA", gender: "f" },
    json_string: { label: "\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA JSON", gender: "f" },
    e164: { label: "\u05DE\u05E1\u05E4\u05E8 E.164", gender: "m" },
    credit_card: { label: "\u05DE\u05E1\u05E4\u05E8 \u05DB\u05E8\u05D8\u05D9\u05E1 \u05D0\u05E9\u05E8\u05D0\u05D9", gender: "m" },
    jwt: { label: "JWT", gender: "m" },
    template_literal: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    ends_with: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    includes: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    lowercase: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    starts_with: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    uppercase: { label: "\u05E7\u05DC\u05D8", gender: "m" }
  }, s = {
    nan: "NaN"
  };
  return (l) => {
    switch (l.code) {
      case "invalid_type": {
        let d = l.expected, m = s[d ?? ""] ?? o(d), g = _(l.input), v = s[g] ?? e[g]?.label ?? g;
        return /^[A-Z]/.test(l.expected) ? `\u05E7\u05DC\u05D8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA instanceof ${l.expected}, \u05D4\u05EA\u05E7\u05D1\u05DC ${v}` : `\u05E7\u05DC\u05D8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA ${m}, \u05D4\u05EA\u05E7\u05D1\u05DC ${v}`;
      }
      case "invalid_value": {
        if (l.values.length === 1)
          return `\u05E2\u05E8\u05DA \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05D4\u05E2\u05E8\u05DA \u05D7\u05D9\u05D9\u05D1 \u05DC\u05D4\u05D9\u05D5\u05EA ${h(l.values[0])}`;
        let d = l.values.map((v) => h(v));
        if (l.values.length === 2)
          return `\u05E2\u05E8\u05DA \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05D4\u05D0\u05E4\u05E9\u05E8\u05D5\u05D9\u05D5\u05EA \u05D4\u05DE\u05EA\u05D0\u05D9\u05DE\u05D5\u05EA \u05D4\u05DF ${d[0]} \u05D0\u05D5 ${d[1]}`;
        let m = d[d.length - 1];
        return `\u05E2\u05E8\u05DA \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05D4\u05D0\u05E4\u05E9\u05E8\u05D5\u05D9\u05D5\u05EA \u05D4\u05DE\u05EA\u05D0\u05D9\u05DE\u05D5\u05EA \u05D4\u05DF ${d.slice(0, -1).join(", ")} \u05D0\u05D5 ${m}`;
      }
      case "too_big": {
        let d = a(l.origin), m = t(l.origin ?? "value");
        if (l.origin === "string")
          return `${d?.longLabel ?? "\u05D0\u05E8\u05D5\u05DA"} \u05DE\u05D3\u05D9: ${m} \u05E6\u05E8\u05D9\u05DB\u05D4 \u05DC\u05D4\u05DB\u05D9\u05DC ${l.maximum.toString()} ${d?.unit ?? ""} ${l.inclusive ? "\u05D0\u05D5 \u05E4\u05D7\u05D5\u05EA" : "\u05DC\u05DB\u05DC \u05D4\u05D9\u05D5\u05EA\u05E8"}`.trim();
        if (l.origin === "number") {
          let $ = l.inclusive ? `\u05E7\u05D8\u05DF \u05D0\u05D5 \u05E9\u05D5\u05D5\u05D4 \u05DC-${l.maximum}` : `\u05E7\u05D8\u05DF \u05DE-${l.maximum}`;
          return `\u05D2\u05D3\u05D5\u05DC \u05DE\u05D3\u05D9: ${m} \u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA ${$}`;
        }
        if (l.origin === "array" || l.origin === "set") {
          let $ = l.origin === "set" ? "\u05E6\u05E8\u05D9\u05DB\u05D4" : "\u05E6\u05E8\u05D9\u05DA", k = l.inclusive ? `${l.maximum} ${d?.unit ?? ""} \u05D0\u05D5 \u05E4\u05D7\u05D5\u05EA` : `\u05E4\u05D7\u05D5\u05EA \u05DE-${l.maximum} ${d?.unit ?? ""}`;
          return `\u05D2\u05D3\u05D5\u05DC \u05DE\u05D3\u05D9: ${m} ${$} \u05DC\u05D4\u05DB\u05D9\u05DC ${k}`.trim();
        }
        let g = l.inclusive ? "<=" : "<", v = n(l.origin ?? "value");
        return d?.unit ? `${d.longLabel} \u05DE\u05D3\u05D9: ${m} ${v} ${g}${l.maximum.toString()} ${d.unit}` : `${d?.longLabel ?? "\u05D2\u05D3\u05D5\u05DC"} \u05DE\u05D3\u05D9: ${m} ${v} ${g}${l.maximum.toString()}`;
      }
      case "too_small": {
        let d = a(l.origin), m = t(l.origin ?? "value");
        if (l.origin === "string")
          return `${d?.shortLabel ?? "\u05E7\u05E6\u05E8"} \u05DE\u05D3\u05D9: ${m} \u05E6\u05E8\u05D9\u05DB\u05D4 \u05DC\u05D4\u05DB\u05D9\u05DC ${l.minimum.toString()} ${d?.unit ?? ""} ${l.inclusive ? "\u05D0\u05D5 \u05D9\u05D5\u05EA\u05E8" : "\u05DC\u05E4\u05D7\u05D5\u05EA"}`.trim();
        if (l.origin === "number") {
          let $ = l.inclusive ? `\u05D2\u05D3\u05D5\u05DC \u05D0\u05D5 \u05E9\u05D5\u05D5\u05D4 \u05DC-${l.minimum}` : `\u05D2\u05D3\u05D5\u05DC \u05DE-${l.minimum}`;
          return `\u05E7\u05D8\u05DF \u05DE\u05D3\u05D9: ${m} \u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA ${$}`;
        }
        if (l.origin === "array" || l.origin === "set") {
          let $ = l.origin === "set" ? "\u05E6\u05E8\u05D9\u05DB\u05D4" : "\u05E6\u05E8\u05D9\u05DA";
          if (l.minimum === 1 && l.inclusive) {
            let I = (l.origin === "set", "\u05DC\u05E4\u05D7\u05D5\u05EA \u05E4\u05E8\u05D9\u05D8 \u05D0\u05D7\u05D3");
            return `\u05E7\u05D8\u05DF \u05DE\u05D3\u05D9: ${m} ${$} \u05DC\u05D4\u05DB\u05D9\u05DC ${I}`;
          }
          let k = l.inclusive ? `${l.minimum} ${d?.unit ?? ""} \u05D0\u05D5 \u05D9\u05D5\u05EA\u05E8` : `\u05D9\u05D5\u05EA\u05E8 \u05DE-${l.minimum} ${d?.unit ?? ""}`;
          return `\u05E7\u05D8\u05DF \u05DE\u05D3\u05D9: ${m} ${$} \u05DC\u05D4\u05DB\u05D9\u05DC ${k}`.trim();
        }
        let g = l.inclusive ? ">=" : ">", v = n(l.origin ?? "value");
        return d?.unit ? `${d.shortLabel} \u05DE\u05D3\u05D9: ${m} ${v} ${g}${l.minimum.toString()} ${d.unit}` : `${d?.shortLabel ?? "\u05E7\u05D8\u05DF"} \u05DE\u05D3\u05D9: ${m} ${v} ${g}${l.minimum.toString()}`;
      }
      case "invalid_format": {
        let d = l;
        if (d.format === "starts_with")
          return `\u05D4\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D7\u05D9\u05D9\u05D1\u05EA \u05DC\u05D4\u05EA\u05D7\u05D9\u05DC \u05D1 "${d.prefix}"`;
        if (d.format === "ends_with")
          return `\u05D4\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D7\u05D9\u05D9\u05D1\u05EA \u05DC\u05D4\u05E1\u05EA\u05D9\u05D9\u05DD \u05D1 "${d.suffix}"`;
        if (d.format === "includes")
          return `\u05D4\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D7\u05D9\u05D9\u05D1\u05EA \u05DC\u05DB\u05DC\u05D5\u05DC "${d.includes}"`;
        if (d.format === "regex")
          return `\u05D4\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D7\u05D9\u05D9\u05D1\u05EA \u05DC\u05D4\u05EA\u05D0\u05D9\u05DD \u05DC\u05EA\u05D1\u05E0\u05D9\u05EA ${d.pattern}`;
        let m = c[d.format], g = m?.label ?? d.format, $ = (m?.gender ?? "m") === "f" ? "\u05EA\u05E7\u05D9\u05E0\u05D4" : "\u05EA\u05E7\u05D9\u05DF";
        return `${g} \u05DC\u05D0 ${$}`;
      }
      case "not_multiple_of":
        return `\u05DE\u05E1\u05E4\u05E8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05D7\u05D9\u05D9\u05D1 \u05DC\u05D4\u05D9\u05D5\u05EA \u05DE\u05DB\u05E4\u05DC\u05D4 \u05E9\u05DC ${l.divisor}`;
      case "unrecognized_keys":
        return `\u05DE\u05E4\u05EA\u05D7${l.keys.length > 1 ? "\u05D5\u05EA" : ""} \u05DC\u05D0 \u05DE\u05D6\u05D5\u05D4${l.keys.length > 1 ? "\u05D9\u05DD" : "\u05D4"}: ${p(l.keys, ", ")}`;
      case "invalid_key":
        return "\u05E9\u05D3\u05D4 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF \u05D1\u05D0\u05D5\u05D1\u05D9\u05D9\u05E7\u05D8";
      case "invalid_union":
        return "\u05E7\u05DC\u05D8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF";
      case "invalid_element":
        return `\u05E2\u05E8\u05DA \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF \u05D1${t(l.origin ?? "array")}`;
      default:
        return "\u05E7\u05DC\u05D8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF";
    }
  };
}, "error");
function zu() {
  return {
    localeError: bg()
  };
}
u(zu, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/hi.js
var kg = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "\u0905\u0915\u094D\u0937\u0930", verb: "\u0930\u0916\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F" },
    file: { unit: "\u092C\u093E\u0907\u091F\u094D\u0938", verb: "\u0930\u0916\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F" },
    array: { unit: "\u0924\u0924\u094D\u0935", verb: "\u0930\u0916\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F" },
    set: { unit: "\u0924\u0924\u094D\u0935", verb: "\u0930\u0916\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F" },
    map: { unit: "\u092A\u094D\u0930\u0935\u093F\u0937\u094D\u091F\u093F\u092F\u093E\u0901", verb: "\u0930\u0916\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "\u0907\u0928\u092A\u0941\u091F",
    email: "\u0908\u092E\u0947\u0932 \u092A\u0924\u093E",
    url: "URL",
    emoji: "\u0907\u092E\u094B\u091C\u0940",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0924\u093F\u0925\u093F \u0914\u0930 \u0938\u092E\u092F",
    date: "ISO \u0924\u093F\u0925\u093F",
    time: "ISO \u0938\u092E\u092F",
    duration: "ISO \u0905\u0935\u0927\u093F",
    ipv4: "IPv4 \u092A\u0924\u093E",
    ipv6: "IPv6 \u092A\u0924\u093E",
    mac: "MAC \u092A\u0924\u093E",
    cidrv4: "IPv4 \u0936\u094D\u0930\u0947\u0923\u0940",
    cidrv6: "IPv6 \u0936\u094D\u0930\u0947\u0923\u0940",
    base64: "Base64-\u090F\u0928\u094D\u0915\u094B\u0921\u0947\u0921 \u0938\u094D\u091F\u094D\u0930\u093F\u0902\u0917",
    base64url: "Base64URL-\u090F\u0928\u094D\u0915\u094B\u0921\u0947\u0921 \u0938\u094D\u091F\u094D\u0930\u093F\u0902\u0917",
    json_string: "JSON \u0938\u094D\u091F\u094D\u0930\u093F\u0902\u0917",
    e164: "E.164 \u0938\u0902\u0916\u094D\u092F\u093E",
    credit_card: "\u0915\u094D\u0930\u0947\u0921\u093F\u091F \u0915\u093E\u0930\u094D\u0921 \u0938\u0902\u0916\u094D\u092F\u093E",
    jwt: "JWT",
    template_literal: "\u0907\u0928\u092A\u0941\u091F"
  }, o = {
    nan: "NaN"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return `\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 ${n}, \u092A\u094D\u0930\u093E\u092A\u094D\u0924 ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 ${h(t.values[0])}` : `\u0905\u092E\u093E\u0928\u094D\u092F \u0935\u093F\u0915\u0932\u094D\u092A: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 \u092E\u093E\u0928\u094B\u0902 \u092E\u0947\u0902 \u0938\u0947 \u090F\u0915 ${p(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u092C\u0939\u0941\u0924 \u092C\u0921\u093C\u093E: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 \u0925\u093E \u0915\u093F ${t.origin ?? "\u092E\u093E\u0928"} \u092E\u0947\u0902 ${n}${t.maximum} ${a.unit} \u0939\u094B\u0902` : `\u092C\u0939\u0941\u0924 \u092C\u0921\u093C\u093E: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 \u0925\u093E \u0915\u093F ${t.origin ?? "\u092E\u093E\u0928"} ${n}${t.maximum} \u0939\u094B`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u092C\u0939\u0941\u0924 \u091B\u094B\u091F\u093E: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 \u0925\u093E \u0915\u093F ${t.origin} \u092E\u0947\u0902 ${n}${t.minimum} ${a.unit} \u0939\u094B\u0902` : `\u092C\u0939\u0941\u0924 \u091B\u094B\u091F\u093E: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 \u0925\u093E \u0915\u093F ${t.origin} ${n}${t.minimum} \u0939\u094B`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0902\u0917: "${n.prefix}" \u0938\u0947 \u0936\u0941\u0930\u0942 \u0939\u094B\u0928\u093E \u091A\u093E\u0939\u093F\u090F` : n.format === "ends_with" ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0902\u0917: "${n.suffix}" \u092A\u0930 \u0938\u092E\u093E\u092A\u094D\u0924 \u0939\u094B\u0928\u093E \u091A\u093E\u0939\u093F\u090F` : n.format === "includes" ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0902\u0917: \u0907\u0938\u092E\u0947\u0902 "${n.includes}" \u0936\u093E\u092E\u093F\u0932 \u0939\u094B\u0928\u093E \u091A\u093E\u0939\u093F\u090F` : n.format === "regex" ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0902\u0917: \u092A\u0948\u091F\u0930\u094D\u0928 ${n.pattern} \u0938\u0947 \u092E\u0947\u0932 \u0916\u093E\u0928\u093E \u091A\u093E\u0939\u093F\u090F` : `\u0905\u092E\u093E\u0928\u094D\u092F ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u0902\u0916\u094D\u092F\u093E: \u092F\u0939 ${t.divisor} \u0915\u093E \u0917\u0941\u0923\u091C \u0939\u094B\u0928\u093E \u091A\u093E\u0939\u093F\u090F`;
      case "unrecognized_keys":
        return `\u0905\u092A\u0930\u093F\u091A\u093F\u0924 \u0915\u0941\u0902\u091C\u0940${t.keys.length > 1 ? "\u092F\u093E\u0901" : ""}: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `\u0905\u092E\u093E\u0928\u094D\u092F \u0915\u0941\u0902\u091C\u0940: ${t.origin} \u092E\u0947\u0902`;
      case "invalid_union":
        return t.options && Array.isArray(t.options) && t.options.length > 0 ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0921\u093F\u0938\u094D\u0915\u094D\u0930\u093F\u092E\u093F\u0928\u0947\u091F\u0930 \u092E\u093E\u0928: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 ${t.options.map((a) => `'${a}'`).join(" | ")}` : "\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F";
      case "invalid_element":
        return `\u0905\u092E\u093E\u0928\u094D\u092F \u092E\u093E\u0928: ${t.origin} \u092E\u0947\u0902`;
      default:
        return "\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F";
    }
  };
}, "error");
function Su() {
  return {
    localeError: kg()
  };
}
u(Su, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/hr.js
var xg = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "znakova", verb: "imati" },
    file: { unit: "bajtova", verb: "imati" },
    array: { unit: "stavki", verb: "imati" },
    set: { unit: "stavki", verb: "imati" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "unos",
    email: "email adresa",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datum i vrijeme",
    date: "ISO datum",
    time: "ISO vrijeme",
    duration: "ISO trajanje",
    ipv4: "IPv4 adresa",
    ipv6: "IPv6 adresa",
    mac: "MAC adresa",
    cidrv4: "IPv4 raspon",
    cidrv6: "IPv6 raspon",
    base64: "base64 kodirani tekst",
    base64url: "base64url kodirani tekst",
    json_string: "JSON tekst",
    e164: "E.164 broj",
    credit_card: "broj kreditne kartice",
    jwt: "JWT",
    template_literal: "unos"
  }, o = {
    nan: "NaN",
    string: "tekst",
    number: "broj",
    boolean: "boolean",
    array: "niz",
    object: "objekt",
    set: "skup",
    file: "datoteka",
    date: "datum",
    bigint: "bigint",
    symbol: "simbol",
    undefined: "undefined",
    null: "null",
    function: "funkcija",
    map: "mapa"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Neispravan unos: o\u010Dekuje se instanceof ${t.expected}, a primljeno je ${c}` : `Neispravan unos: o\u010Dekuje se ${n}, a primljeno je ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Neispravna vrijednost: o\u010Dekivano ${h(t.values[0])}` : `Neispravna opcija: o\u010Dekivano jedno od ${p(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin), c = o[t.origin] ?? t.origin;
        return a ? `Preveliko: o\u010Dekivano da ${c ?? "vrijednost"} ima ${n}${t.maximum.toString()} ${a.unit ?? "elemenata"}` : `Preveliko: o\u010Dekivano da ${c ?? "vrijednost"} bude ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin), c = o[t.origin] ?? t.origin;
        return a ? `Premalo: o\u010Dekivano da ${c} ima ${n}${t.minimum.toString()} ${a.unit}` : `Premalo: o\u010Dekivano da ${c} bude ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Neispravan tekst: mora zapo\u010Dinjati s "${n.prefix}"` : n.format === "ends_with" ? `Neispravan tekst: mora zavr\u0161avati s "${n.suffix}"` : n.format === "includes" ? `Neispravan tekst: mora sadr\u017Eavati "${n.includes}"` : n.format === "regex" ? `Neispravan tekst: mora odgovarati uzorku ${n.pattern}` : `Neispravna ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Neispravan broj: mora biti vi\u0161ekratnik od ${t.divisor}`;
      case "unrecognized_keys":
        return `Neprepoznat${t.keys.length > 1 ? "i klju\u010Devi" : " klju\u010D"}: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `Neispravan klju\u010D u ${o[t.origin] ?? t.origin}`;
      case "invalid_union":
        return "Neispravan unos";
      case "invalid_element":
        return `Neispravna vrijednost u ${o[t.origin] ?? t.origin}`;
      default:
        return "Neispravan unos";
    }
  };
}, "error");
function ju() {
  return {
    localeError: xg()
  };
}
u(ju, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/hu.js
var Ig = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "karakter", verb: "legyen" },
    file: { unit: "byte", verb: "legyen" },
    array: { unit: "elem", verb: "legyen" },
    set: { unit: "elem", verb: "legyen" },
    map: { unit: "elem", verb: "legyen" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "bemenet",
    email: "email c\xEDm",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO id\u0151b\xE9lyeg",
    date: "ISO d\xE1tum",
    time: "ISO id\u0151",
    duration: "ISO id\u0151intervallum",
    ipv4: "IPv4 c\xEDm",
    ipv6: "IPv6 c\xEDm",
    mac: "MAC c\xEDm",
    cidrv4: "IPv4 tartom\xE1ny",
    cidrv6: "IPv6 tartom\xE1ny",
    base64: "base64-k\xF3dolt string",
    base64url: "base64url-k\xF3dolt string",
    json_string: "JSON string",
    e164: "E.164 sz\xE1m",
    credit_card: "hitelk\xE1rtyasz\xE1m",
    jwt: "JWT",
    template_literal: "bemenet"
  }, o = {
    nan: "NaN",
    number: "sz\xE1m",
    array: "t\xF6mb"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\xC9rv\xE9nytelen bemenet: a v\xE1rt \xE9rt\xE9k instanceof ${t.expected}, a kapott \xE9rt\xE9k ${c}` : `\xC9rv\xE9nytelen bemenet: a v\xE1rt \xE9rt\xE9k ${n}, a kapott \xE9rt\xE9k ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\xC9rv\xE9nytelen bemenet: a v\xE1rt \xE9rt\xE9k ${h(t.values[0])}` : `\xC9rv\xE9nytelen opci\xF3: valamelyik \xE9rt\xE9k v\xE1rt ${p(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `T\xFAl nagy: ${t.origin ?? "\xE9rt\xE9k"} m\xE9rete t\xFAl nagy ${n}${t.maximum.toString()} ${a.unit ?? "elem"}` : `T\xFAl nagy: a bemeneti \xE9rt\xE9k ${t.origin ?? "\xE9rt\xE9k"} t\xFAl nagy: ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `T\xFAl kicsi: a bemeneti \xE9rt\xE9k ${t.origin} m\xE9rete t\xFAl kicsi ${n}${t.minimum.toString()} ${a.unit}` : `T\xFAl kicsi: a bemeneti \xE9rt\xE9k ${t.origin} t\xFAl kicsi ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\xC9rv\xE9nytelen string: "${n.prefix}" \xE9rt\xE9kkel kell kezd\u0151dnie` : n.format === "ends_with" ? `\xC9rv\xE9nytelen string: "${n.suffix}" \xE9rt\xE9kkel kell v\xE9gz\u0151dnie` : n.format === "includes" ? `\xC9rv\xE9nytelen string: "${n.includes}" \xE9rt\xE9ket kell tartalmaznia` : n.format === "regex" ? `\xC9rv\xE9nytelen string: ${n.pattern} mint\xE1nak kell megfelelnie` : `\xC9rv\xE9nytelen ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\xC9rv\xE9nytelen sz\xE1m: ${t.divisor} t\xF6bbsz\xF6r\xF6s\xE9nek kell lennie`;
      case "unrecognized_keys":
        return `Ismeretlen kulcs${t.keys.length > 1 ? "s" : ""}: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `\xC9rv\xE9nytelen kulcs ${t.origin}`;
      case "invalid_union":
        return "\xC9rv\xE9nytelen bemenet";
      case "invalid_element":
        return `\xC9rv\xE9nytelen \xE9rt\xE9k: ${t.origin}`;
      default:
        return "\xC9rv\xE9nytelen bemenet";
    }
  };
}, "error");
function Pu() {
  return {
    localeError: Ig()
  };
}
u(Pu, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/hy.js
function Td(e, r, i) {
  return Math.abs(e) === 1 ? r : i;
}
u(Td, "getArmenianPlural");
function ut(e) {
  if (!e)
    return "";
  let r = ["\u0561", "\u0565", "\u0568", "\u056B", "\u0578", "\u0578\u0582", "\u0585"], i = e[e.length - 1];
  return e + (r.includes(i) ? "\u0576" : "\u0568");
}
u(ut, "withDefiniteArticle");
var wg = /* @__PURE__ */ u(() => {
  let e = {
    string: {
      unit: {
        one: "\u0576\u0577\u0561\u0576",
        many: "\u0576\u0577\u0561\u0576\u0576\u0565\u0580"
      },
      verb: "\u0578\u0582\u0576\u0565\u0576\u0561\u056C"
    },
    file: {
      unit: {
        one: "\u0562\u0561\u0575\u0569",
        many: "\u0562\u0561\u0575\u0569\u0565\u0580"
      },
      verb: "\u0578\u0582\u0576\u0565\u0576\u0561\u056C"
    },
    array: {
      unit: {
        one: "\u057F\u0561\u0580\u0580",
        many: "\u057F\u0561\u0580\u0580\u0565\u0580"
      },
      verb: "\u0578\u0582\u0576\u0565\u0576\u0561\u056C"
    },
    set: {
      unit: {
        one: "\u057F\u0561\u0580\u0580",
        many: "\u057F\u0561\u0580\u0580\u0565\u0580"
      },
      verb: "\u0578\u0582\u0576\u0565\u0576\u0561\u056C"
    },
    map: {
      unit: {
        one: "\u057F\u0561\u0580\u0580",
        many: "\u057F\u0561\u0580\u0580\u0565\u0580"
      },
      verb: "\u0578\u0582\u0576\u0565\u0576\u0561\u056C"
    }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "\u0574\u0578\u0582\u057F\u0584",
    email: "\u0567\u056C. \u0570\u0561\u057D\u0581\u0565",
    url: "URL",
    emoji: "\u0567\u0574\u0578\u057B\u056B",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0561\u0574\u057D\u0561\u0569\u056B\u057E \u0587 \u056A\u0561\u0574",
    date: "ISO \u0561\u0574\u057D\u0561\u0569\u056B\u057E",
    time: "ISO \u056A\u0561\u0574",
    duration: "ISO \u057F\u0587\u0578\u0572\u0578\u0582\u0569\u0575\u0578\u0582\u0576",
    ipv4: "IPv4 \u0570\u0561\u057D\u0581\u0565",
    ipv6: "IPv6 \u0570\u0561\u057D\u0581\u0565",
    mac: "MAC \u0570\u0561\u057D\u0581\u0565",
    cidrv4: "IPv4 \u0574\u056B\u057B\u0561\u056F\u0561\u0575\u0584",
    cidrv6: "IPv6 \u0574\u056B\u057B\u0561\u056F\u0561\u0575\u0584",
    base64: "base64 \u0571\u0587\u0561\u0579\u0561\u0583\u0578\u057E \u057F\u0578\u0572",
    base64url: "base64url \u0571\u0587\u0561\u0579\u0561\u0583\u0578\u057E \u057F\u0578\u0572",
    json_string: "JSON \u057F\u0578\u0572",
    e164: "E.164 \u0570\u0561\u0574\u0561\u0580",
    credit_card: "\u056F\u0580\u0565\u0564\u056B\u057F \u0584\u0561\u0580\u057F\u056B \u0570\u0561\u0574\u0561\u0580",
    jwt: "JWT",
    template_literal: "\u0574\u0578\u0582\u057F\u0584"
  }, o = {
    nan: "NaN",
    number: "\u0569\u056B\u057E",
    array: "\u0566\u0561\u0576\u0563\u057E\u0561\u056E"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567\u0580 instanceof ${t.expected}, \u057D\u057F\u0561\u0581\u057E\u0565\u056C \u0567 ${c}` : `\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567\u0580 ${n}, \u057D\u057F\u0561\u0581\u057E\u0565\u056C \u0567 ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567\u0580 ${h(t.values[1])}` : `\u054D\u056D\u0561\u056C \u057F\u0561\u0580\u0562\u0565\u0580\u0561\u056F\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567\u0580 \u0570\u0565\u057F\u0587\u0575\u0561\u056C\u0576\u0565\u0580\u056B\u0581 \u0574\u0565\u056F\u0568\u055D ${p(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        if (a) {
          let c = Number(t.maximum), s = Td(c, a.unit.one, a.unit.many);
          return `\u0549\u0561\u0583\u0561\u0566\u0561\u0576\u0581 \u0574\u0565\u056E \u0561\u0580\u056A\u0565\u0584\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567, \u0578\u0580 ${ut(t.origin ?? "\u0561\u0580\u056A\u0565\u0584")} \u056F\u0578\u0582\u0576\u0565\u0576\u0561 ${n}${t.maximum.toString()} ${s}`;
        }
        return `\u0549\u0561\u0583\u0561\u0566\u0561\u0576\u0581 \u0574\u0565\u056E \u0561\u0580\u056A\u0565\u0584\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567, \u0578\u0580 ${ut(t.origin ?? "\u0561\u0580\u056A\u0565\u0584")} \u056C\u056B\u0576\u056B ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        if (a) {
          let c = Number(t.minimum), s = Td(c, a.unit.one, a.unit.many);
          return `\u0549\u0561\u0583\u0561\u0566\u0561\u0576\u0581 \u0583\u0578\u0584\u0580 \u0561\u0580\u056A\u0565\u0584\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567, \u0578\u0580 ${ut(t.origin)} \u056F\u0578\u0582\u0576\u0565\u0576\u0561 ${n}${t.minimum.toString()} ${s}`;
        }
        return `\u0549\u0561\u0583\u0561\u0566\u0561\u0576\u0581 \u0583\u0578\u0584\u0580 \u0561\u0580\u056A\u0565\u0584\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567, \u0578\u0580 ${ut(t.origin)} \u056C\u056B\u0576\u056B ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u054D\u056D\u0561\u056C \u057F\u0578\u0572\u2024 \u057A\u0565\u057F\u0584 \u0567 \u057D\u056F\u057D\u057E\u056B "${n.prefix}"-\u0578\u057E` : n.format === "ends_with" ? `\u054D\u056D\u0561\u056C \u057F\u0578\u0572\u2024 \u057A\u0565\u057F\u0584 \u0567 \u0561\u057E\u0561\u0580\u057F\u057E\u056B "${n.suffix}"-\u0578\u057E` : n.format === "includes" ? `\u054D\u056D\u0561\u056C \u057F\u0578\u0572\u2024 \u057A\u0565\u057F\u0584 \u0567 \u057A\u0561\u0580\u0578\u0582\u0576\u0561\u056F\u056B "${n.includes}"` : n.format === "regex" ? `\u054D\u056D\u0561\u056C \u057F\u0578\u0572\u2024 \u057A\u0565\u057F\u0584 \u0567 \u0570\u0561\u0574\u0561\u057A\u0561\u057F\u0561\u057D\u056D\u0561\u0576\u056B ${n.pattern} \u0571\u0587\u0561\u0579\u0561\u0583\u056B\u0576` : `\u054D\u056D\u0561\u056C ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u054D\u056D\u0561\u056C \u0569\u056B\u057E\u2024 \u057A\u0565\u057F\u0584 \u0567 \u0562\u0561\u0566\u0574\u0561\u057A\u0561\u057F\u056B\u056F \u056C\u056B\u0576\u056B ${t.divisor}-\u056B`;
      case "unrecognized_keys":
        return `\u0549\u0573\u0561\u0576\u0561\u0579\u057E\u0561\u056E \u0562\u0561\u0576\u0561\u056C\u056B${t.keys.length > 1 ? "\u0576\u0565\u0580" : ""}. ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `\u054D\u056D\u0561\u056C \u0562\u0561\u0576\u0561\u056C\u056B ${ut(t.origin)}-\u0578\u0582\u0574`;
      case "invalid_union":
        return "\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574";
      case "invalid_element":
        return `\u054D\u056D\u0561\u056C \u0561\u0580\u056A\u0565\u0584 ${ut(t.origin)}-\u0578\u0582\u0574`;
      default:
        return "\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574";
    }
  };
}, "error");
function Du() {
  return {
    localeError: wg()
  };
}
u(Du, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/id.js
var zg = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "karakter", verb: "memiliki" },
    file: { unit: "byte", verb: "memiliki" },
    array: { unit: "item", verb: "memiliki" },
    set: { unit: "item", verb: "memiliki" },
    map: { unit: "item", verb: "memiliki" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "input",
    email: "alamat email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "tanggal dan waktu format ISO",
    date: "tanggal format ISO",
    time: "jam format ISO",
    duration: "durasi format ISO",
    ipv4: "alamat IPv4",
    ipv6: "alamat IPv6",
    mac: "alamat MAC",
    cidrv4: "rentang alamat IPv4",
    cidrv6: "rentang alamat IPv6",
    base64: "string dengan enkode base64",
    base64url: "string dengan enkode base64url",
    json_string: "string JSON",
    e164: "angka E.164",
    credit_card: "nomor kartu kredit",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Input tidak valid: diharapkan instanceof ${t.expected}, diterima ${c}` : `Input tidak valid: diharapkan ${n}, diterima ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Input tidak valid: diharapkan ${h(t.values[0])}` : `Pilihan tidak valid: diharapkan salah satu dari ${p(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Terlalu besar: diharapkan ${t.origin ?? "value"} memiliki ${n}${t.maximum.toString()} ${a.unit ?? "elemen"}` : `Terlalu besar: diharapkan ${t.origin ?? "value"} menjadi ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Terlalu kecil: diharapkan ${t.origin} memiliki ${n}${t.minimum.toString()} ${a.unit}` : `Terlalu kecil: diharapkan ${t.origin} menjadi ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `String tidak valid: harus dimulai dengan "${n.prefix}"` : n.format === "ends_with" ? `String tidak valid: harus berakhir dengan "${n.suffix}"` : n.format === "includes" ? `String tidak valid: harus menyertakan "${n.includes}"` : n.format === "regex" ? `String tidak valid: harus sesuai pola ${n.pattern}` : `${i[n.format] ?? t.format} tidak valid`;
      }
      case "not_multiple_of":
        return `Angka tidak valid: harus kelipatan dari ${t.divisor}`;
      case "unrecognized_keys":
        return `Kunci tidak dikenali ${t.keys.length > 1 ? "s" : ""}: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `Kunci tidak valid di ${t.origin}`;
      case "invalid_union":
        return "Input tidak valid";
      case "invalid_element":
        return `Nilai tidak valid di ${t.origin}`;
      default:
        return "Input tidak valid";
    }
  };
}, "error");
function Ou() {
  return {
    localeError: zg()
  };
}
u(Ou, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/is.js
var Sg = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "stafi", verb: "a\xF0 hafa" },
    file: { unit: "b\xE6ti", verb: "a\xF0 hafa" },
    array: { unit: "hluti", verb: "a\xF0 hafa" },
    set: { unit: "hluti", verb: "a\xF0 hafa" },
    map: { unit: "hluti", verb: "a\xF0 hafa" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "gildi",
    email: "netfang",
    url: "vefsl\xF3\xF0",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO dagsetning og t\xEDmi",
    date: "ISO dagsetning",
    time: "ISO t\xEDmi",
    duration: "ISO t\xEDmalengd",
    ipv4: "IPv4 address",
    ipv6: "IPv6 address",
    mac: "MAC address",
    cidrv4: "IPv4 range",
    cidrv6: "IPv6 range",
    base64: "base64-encoded strengur",
    base64url: "base64url-encoded strengur",
    json_string: "JSON strengur",
    e164: "E.164 t\xF6lugildi",
    credit_card: "kreditkortan\xFAmer",
    jwt: "JWT",
    template_literal: "gildi"
  }, o = {
    nan: "NaN",
    number: "n\xFAmer",
    array: "fylki"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Rangt gildi: \xDE\xFA sl\xF3st inn ${c} \xFEar sem \xE1 a\xF0 vera instanceof ${t.expected}` : `Rangt gildi: \xDE\xFA sl\xF3st inn ${c} \xFEar sem \xE1 a\xF0 vera ${n}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Rangt gildi: gert r\xE1\xF0 fyrir ${h(t.values[0])}` : `\xD3gilt val: m\xE1 vera eitt af eftirfarandi ${p(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Of st\xF3rt: gert er r\xE1\xF0 fyrir a\xF0 ${t.origin ?? "gildi"} hafi ${n}${t.maximum.toString()} ${a.unit ?? "hluti"}` : `Of st\xF3rt: gert er r\xE1\xF0 fyrir a\xF0 ${t.origin ?? "gildi"} s\xE9 ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Of l\xEDti\xF0: gert er r\xE1\xF0 fyrir a\xF0 ${t.origin} hafi ${n}${t.minimum.toString()} ${a.unit}` : `Of l\xEDti\xF0: gert er r\xE1\xF0 fyrir a\xF0 ${t.origin} s\xE9 ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\xD3gildur strengur: ver\xF0ur a\xF0 byrja \xE1 "${n.prefix}"` : n.format === "ends_with" ? `\xD3gildur strengur: ver\xF0ur a\xF0 enda \xE1 "${n.suffix}"` : n.format === "includes" ? `\xD3gildur strengur: ver\xF0ur a\xF0 innihalda "${n.includes}"` : n.format === "regex" ? `\xD3gildur strengur: ver\xF0ur a\xF0 fylgja mynstri ${n.pattern}` : `Rangt ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `R\xF6ng tala: ver\xF0ur a\xF0 vera margfeldi af ${t.divisor}`;
      case "unrecognized_keys":
        return `\xD3\xFEekkt ${t.keys.length > 1 ? "ir lyklar" : "ur lykill"}: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `Rangur lykill \xED ${t.origin}`;
      case "invalid_union":
        return "Rangt gildi";
      case "invalid_element":
        return `Rangt gildi \xED ${t.origin}`;
      default:
        return "Rangt gildi";
    }
  };
}, "error");
function Uu() {
  return {
    localeError: Sg()
  };
}
u(Uu, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/it.js
var jg = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "caratteri", verb: "avere" },
    file: { unit: "byte", verb: "avere" },
    array: { unit: "elementi", verb: "avere" },
    set: { unit: "elementi", verb: "avere" },
    map: { unit: "elementi", verb: "avere" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "input",
    email: "indirizzo email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "data e ora ISO",
    date: "data ISO",
    time: "ora ISO",
    duration: "durata ISO",
    ipv4: "indirizzo IPv4",
    ipv6: "indirizzo IPv6",
    mac: "indirizzo MAC",
    cidrv4: "intervallo IPv4",
    cidrv6: "intervallo IPv6",
    base64: "stringa codificata in base64",
    base64url: "URL codificata in base64",
    json_string: "stringa JSON",
    e164: "numero E.164",
    credit_card: "numero di carta di credito",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN",
    number: "numero",
    array: "vettore"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Input non valido: atteso instanceof ${t.expected}, ricevuto ${c}` : `Input non valido: atteso ${n}, ricevuto ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Input non valido: atteso ${h(t.values[0])}` : `Opzione non valida: atteso uno tra ${p(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Troppo grande: ${t.origin ?? "valore"} deve avere ${n}${t.maximum.toString()} ${a.unit ?? "elementi"}` : `Troppo grande: ${t.origin ?? "valore"} deve essere ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Troppo piccolo: ${t.origin} deve avere ${n}${t.minimum.toString()} ${a.unit}` : `Troppo piccolo: ${t.origin} deve essere ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Stringa non valida: deve iniziare con "${n.prefix}"` : n.format === "ends_with" ? `Stringa non valida: deve terminare con "${n.suffix}"` : n.format === "includes" ? `Stringa non valida: deve includere "${n.includes}"` : n.format === "regex" ? `Stringa non valida: deve corrispondere al pattern ${n.pattern}` : `Input non valido: ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Numero non valido: deve essere un multiplo di ${t.divisor}`;
      case "unrecognized_keys":
        return `Chiav${t.keys.length > 1 ? "i" : "e"} non riconosciut${t.keys.length > 1 ? "e" : "a"}: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `Chiave non valida in ${t.origin}`;
      case "invalid_union":
        return "Input non valido";
      case "invalid_element":
        return `Valore non valido in ${t.origin}`;
      default:
        return "Input non valido";
    }
  };
}, "error");
function Nu() {
  return {
    localeError: jg()
  };
}
u(Nu, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ja.js
var Pg = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "\u6587\u5B57", verb: "\u3067\u3042\u308B" },
    file: { unit: "\u30D0\u30A4\u30C8", verb: "\u3067\u3042\u308B" },
    array: { unit: "\u8981\u7D20", verb: "\u3067\u3042\u308B" },
    set: { unit: "\u8981\u7D20", verb: "\u3067\u3042\u308B" },
    map: { unit: "\u8981\u7D20", verb: "\u3067\u3042\u308B" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "\u5165\u529B\u5024",
    email: "\u30E1\u30FC\u30EB\u30A2\u30C9\u30EC\u30B9",
    url: "URL",
    emoji: "\u7D75\u6587\u5B57",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO\u65E5\u6642",
    date: "ISO\u65E5\u4ED8",
    time: "ISO\u6642\u523B",
    duration: "ISO\u671F\u9593",
    ipv4: "IPv4\u30A2\u30C9\u30EC\u30B9",
    ipv6: "IPv6\u30A2\u30C9\u30EC\u30B9",
    mac: "MAC\u30A2\u30C9\u30EC\u30B9",
    cidrv4: "IPv4\u7BC4\u56F2",
    cidrv6: "IPv6\u7BC4\u56F2",
    base64: "base64\u30A8\u30F3\u30B3\u30FC\u30C9\u6587\u5B57\u5217",
    base64url: "base64url\u30A8\u30F3\u30B3\u30FC\u30C9\u6587\u5B57\u5217",
    json_string: "JSON\u6587\u5B57\u5217",
    e164: "E.164\u756A\u53F7",
    credit_card: "\u30AF\u30EC\u30B8\u30C3\u30C8\u30AB\u30FC\u30C9\u756A\u53F7",
    jwt: "JWT",
    template_literal: "\u5165\u529B\u5024"
  }, o = {
    nan: "NaN",
    number: "\u6570\u5024",
    array: "\u914D\u5217"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u7121\u52B9\u306A\u5165\u529B: instanceof ${t.expected}\u304C\u671F\u5F85\u3055\u308C\u307E\u3057\u305F\u304C\u3001${c}\u304C\u5165\u529B\u3055\u308C\u307E\u3057\u305F` : `\u7121\u52B9\u306A\u5165\u529B: ${n}\u304C\u671F\u5F85\u3055\u308C\u307E\u3057\u305F\u304C\u3001${c}\u304C\u5165\u529B\u3055\u308C\u307E\u3057\u305F`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u7121\u52B9\u306A\u5165\u529B: ${h(t.values[0])}\u304C\u671F\u5F85\u3055\u308C\u307E\u3057\u305F` : `\u7121\u52B9\u306A\u9078\u629E: ${p(t.values, "\u3001")}\u306E\u3044\u305A\u308C\u304B\u3067\u3042\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`;
      case "too_big": {
        let n = t.inclusive ? "\u4EE5\u4E0B\u3067\u3042\u308B" : "\u3088\u308A\u5C0F\u3055\u3044", a = r(t.origin);
        return a ? `\u5927\u304D\u3059\u304E\u308B\u5024: ${t.origin ?? "\u5024"}\u306F${t.maximum.toString()}${a.unit ?? "\u8981\u7D20"}${n}\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : `\u5927\u304D\u3059\u304E\u308B\u5024: ${t.origin ?? "\u5024"}\u306F${t.maximum.toString()}${n}\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`;
      }
      case "too_small": {
        let n = t.inclusive ? "\u4EE5\u4E0A\u3067\u3042\u308B" : "\u3088\u308A\u5927\u304D\u3044", a = r(t.origin);
        return a ? `\u5C0F\u3055\u3059\u304E\u308B\u5024: ${t.origin}\u306F${t.minimum.toString()}${a.unit}${n}\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : `\u5C0F\u3055\u3059\u304E\u308B\u5024: ${t.origin}\u306F${t.minimum.toString()}${n}\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u7121\u52B9\u306A\u6587\u5B57\u5217: "${n.prefix}"\u3067\u59CB\u307E\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : n.format === "ends_with" ? `\u7121\u52B9\u306A\u6587\u5B57\u5217: "${n.suffix}"\u3067\u7D42\u308F\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : n.format === "includes" ? `\u7121\u52B9\u306A\u6587\u5B57\u5217: "${n.includes}"\u3092\u542B\u3080\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : n.format === "regex" ? `\u7121\u52B9\u306A\u6587\u5B57\u5217: \u30D1\u30BF\u30FC\u30F3${n.pattern}\u306B\u4E00\u81F4\u3059\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : `\u7121\u52B9\u306A${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u7121\u52B9\u306A\u6570\u5024: ${t.divisor}\u306E\u500D\u6570\u3067\u3042\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`;
      case "unrecognized_keys":
        return `\u8A8D\u8B58\u3055\u308C\u3066\u3044\u306A\u3044\u30AD\u30FC${t.keys.length > 1 ? "\u7FA4" : ""}: ${p(t.keys, "\u3001")}`;
      case "invalid_key":
        return `${t.origin}\u5185\u306E\u7121\u52B9\u306A\u30AD\u30FC`;
      case "invalid_union":
        return "\u7121\u52B9\u306A\u5165\u529B";
      case "invalid_element":
        return `${t.origin}\u5185\u306E\u7121\u52B9\u306A\u5024`;
      default:
        return "\u7121\u52B9\u306A\u5165\u529B";
    }
  };
}, "error");
function Tu() {
  return {
    localeError: Pg()
  };
}
u(Tu, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ka.js
var Dg = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "\u10E1\u10D8\u10DB\u10D1\u10DD\u10DA\u10DD", verb: "\u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1" },
    file: { unit: "\u10D1\u10D0\u10D8\u10E2\u10D8", verb: "\u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1" },
    array: { unit: "\u10D4\u10DA\u10D4\u10DB\u10D4\u10DC\u10E2\u10D8", verb: "\u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1" },
    set: { unit: "\u10D4\u10DA\u10D4\u10DB\u10D4\u10DC\u10E2\u10D8", verb: "\u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1" },
    map: { unit: "\u10D4\u10DA\u10D4\u10DB\u10D4\u10DC\u10E2\u10D8", verb: "\u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "\u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0",
    email: "\u10D4\u10DA-\u10E4\u10DD\u10E1\u10E2\u10D8\u10E1 \u10DB\u10D8\u10E1\u10D0\u10DB\u10D0\u10E0\u10D7\u10D8",
    url: "URL",
    emoji: "\u10D4\u10DB\u10DD\u10EF\u10D8",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u10D7\u10D0\u10E0\u10D8\u10E6\u10D8-\u10D3\u10E0\u10DD",
    date: "\u10D7\u10D0\u10E0\u10D8\u10E6\u10D8",
    time: "\u10D3\u10E0\u10DD",
    duration: "\u10EE\u10D0\u10DC\u10D2\u10E0\u10EB\u10DA\u10D8\u10D5\u10DD\u10D1\u10D0",
    ipv4: "IPv4 \u10DB\u10D8\u10E1\u10D0\u10DB\u10D0\u10E0\u10D7\u10D8",
    ipv6: "IPv6 \u10DB\u10D8\u10E1\u10D0\u10DB\u10D0\u10E0\u10D7\u10D8",
    mac: "MAC \u10DB\u10D8\u10E1\u10D0\u10DB\u10D0\u10E0\u10D7\u10D8",
    cidrv4: "IPv4 \u10D3\u10D8\u10D0\u10DE\u10D0\u10D6\u10DD\u10DC\u10D8",
    cidrv6: "IPv6 \u10D3\u10D8\u10D0\u10DE\u10D0\u10D6\u10DD\u10DC\u10D8",
    base64: "base64-\u10D9\u10DD\u10D3\u10D8\u10E0\u10D4\u10D1\u10E3\u10DA\u10D8 \u10D5\u10D4\u10DA\u10D8",
    base64url: "base64url-\u10D9\u10DD\u10D3\u10D8\u10E0\u10D4\u10D1\u10E3\u10DA\u10D8 \u10D5\u10D4\u10DA\u10D8",
    json_string: "JSON \u10D5\u10D4\u10DA\u10D8",
    e164: "E.164 \u10DC\u10DD\u10DB\u10D4\u10E0\u10D8",
    credit_card: "\u10E1\u10D0\u10D9\u10E0\u10D4\u10D3\u10D8\u10E2\u10DD \u10D1\u10D0\u10E0\u10D0\u10D7\u10D8\u10E1 \u10DC\u10DD\u10DB\u10D4\u10E0\u10D8",
    jwt: "JWT",
    template_literal: "\u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0"
  }, o = {
    nan: "NaN",
    number: "\u10E0\u10D8\u10EA\u10EE\u10D5\u10D8",
    string: "\u10D5\u10D4\u10DA\u10D8",
    boolean: "\u10D1\u10E3\u10DA\u10D4\u10D0\u10DC\u10D8",
    function: "\u10E4\u10E3\u10DC\u10E5\u10EA\u10D8\u10D0",
    array: "\u10DB\u10D0\u10E1\u10D8\u10D5\u10D8"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 instanceof ${t.expected}, \u10DB\u10D8\u10E6\u10D4\u10D1\u10E3\u10DA\u10D8 ${c}` : `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${n}, \u10DB\u10D8\u10E6\u10D4\u10D1\u10E3\u10DA\u10D8 ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${h(t.values[0])}` : `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D5\u10D0\u10E0\u10D8\u10D0\u10DC\u10E2\u10D8: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8\u10D0 \u10D4\u10E0\u10D7-\u10D4\u10E0\u10D7\u10D8 ${p(t.values, "|")}-\u10D3\u10D0\u10DC`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u10D6\u10D4\u10D3\u10DB\u10D4\u10E2\u10D0\u10D3 \u10D3\u10D8\u10D3\u10D8: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${t.origin ?? "\u10DB\u10DC\u10D8\u10E8\u10D5\u10DC\u10D4\u10DA\u10DD\u10D1\u10D0"} ${a.verb} ${n}${t.maximum.toString()} ${a.unit}` : `\u10D6\u10D4\u10D3\u10DB\u10D4\u10E2\u10D0\u10D3 \u10D3\u10D8\u10D3\u10D8: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${t.origin ?? "\u10DB\u10DC\u10D8\u10E8\u10D5\u10DC\u10D4\u10DA\u10DD\u10D1\u10D0"} \u10D8\u10E7\u10DD\u10E1 ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u10D6\u10D4\u10D3\u10DB\u10D4\u10E2\u10D0\u10D3 \u10DE\u10D0\u10E2\u10D0\u10E0\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${t.origin} ${a.verb} ${n}${t.minimum.toString()} ${a.unit}` : `\u10D6\u10D4\u10D3\u10DB\u10D4\u10E2\u10D0\u10D3 \u10DE\u10D0\u10E2\u10D0\u10E0\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${t.origin} \u10D8\u10E7\u10DD\u10E1 ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D5\u10D4\u10DA\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10D8\u10EC\u10E7\u10D4\u10D1\u10DD\u10D3\u10D4\u10E1 "${n.prefix}"-\u10D8\u10D7` : n.format === "ends_with" ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D5\u10D4\u10DA\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10DB\u10D7\u10D0\u10D5\u10E0\u10D3\u10D4\u10D1\u10DD\u10D3\u10D4\u10E1 "${n.suffix}"-\u10D8\u10D7` : n.format === "includes" ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D5\u10D4\u10DA\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1 "${n.includes}"-\u10E1` : n.format === "regex" ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D5\u10D4\u10DA\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D4\u10E1\u10D0\u10D1\u10D0\u10DB\u10D4\u10D1\u10DD\u10D3\u10D4\u10E1 \u10E8\u10D0\u10D1\u10DA\u10DD\u10DC\u10E1 ${n.pattern}` : `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E0\u10D8\u10EA\u10EE\u10D5\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10D8\u10E7\u10DD\u10E1 ${t.divisor}-\u10D8\u10E1 \u10EF\u10D4\u10E0\u10D0\u10D3\u10D8`;
      case "unrecognized_keys":
        return `\u10E3\u10EA\u10DC\u10DD\u10D1\u10D8 \u10D2\u10D0\u10E1\u10D0\u10E6\u10D4\u10D1${t.keys.length > 1 ? "\u10D4\u10D1\u10D8" : "\u10D8"}: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D2\u10D0\u10E1\u10D0\u10E6\u10D4\u10D1\u10D8 ${t.origin}-\u10E8\u10D8`;
      case "invalid_union":
        return "\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0";
      case "invalid_element":
        return `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10DB\u10DC\u10D8\u10E8\u10D5\u10DC\u10D4\u10DA\u10DD\u10D1\u10D0 ${t.origin}-\u10E8\u10D8`;
      default:
        return "\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0";
    }
  };
}, "error");
function Zu() {
  return {
    localeError: Dg()
  };
}
u(Zu, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/km.js
var Og = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "\u178F\u17BD\u17A2\u1780\u17D2\u179F\u179A", verb: "\u1782\u17BD\u179A\u1798\u17B6\u1793" },
    file: { unit: "\u1794\u17C3", verb: "\u1782\u17BD\u179A\u1798\u17B6\u1793" },
    array: { unit: "\u1792\u17B6\u178F\u17BB", verb: "\u1782\u17BD\u179A\u1798\u17B6\u1793" },
    set: { unit: "\u1792\u17B6\u178F\u17BB", verb: "\u1782\u17BD\u179A\u1798\u17B6\u1793" },
    map: { unit: "\u1792\u17B6\u178F\u17BB", verb: "\u1782\u17BD\u179A\u1798\u17B6\u1793" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B",
    email: "\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793\u17A2\u17CA\u17B8\u1798\u17C2\u179B",
    url: "URL",
    emoji: "\u179F\u1789\u17D2\u1789\u17B6\u17A2\u17B6\u179A\u1798\u17D2\u1798\u178E\u17CD",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u1780\u17B6\u179B\u1794\u179A\u17B7\u1785\u17D2\u1786\u17C1\u1791 \u1793\u17B7\u1784\u1798\u17C9\u17C4\u1784 ISO",
    date: "\u1780\u17B6\u179B\u1794\u179A\u17B7\u1785\u17D2\u1786\u17C1\u1791 ISO",
    time: "\u1798\u17C9\u17C4\u1784 ISO",
    duration: "\u179A\u1799\u17C8\u1796\u17C1\u179B ISO",
    ipv4: "\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793 IPv4",
    ipv6: "\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793 IPv6",
    mac: "\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793 MAC",
    cidrv4: "\u178A\u17C2\u1793\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793 IPv4",
    cidrv6: "\u178A\u17C2\u1793\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793 IPv6",
    base64: "\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u17A2\u17CA\u17B7\u1780\u17BC\u178A base64",
    base64url: "\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u17A2\u17CA\u17B7\u1780\u17BC\u178A base64url",
    json_string: "\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A JSON",
    e164: "\u179B\u17C1\u1781 E.164",
    credit_card: "\u179B\u17C1\u1781\u1794\u17D0\u178E\u17D2\u178E\u17A5\u178E\u1791\u17B6\u1793",
    jwt: "JWT",
    template_literal: "\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B"
  }, o = {
    nan: "NaN",
    number: "\u179B\u17C1\u1781",
    array: "\u17A2\u17B6\u179A\u17C1 (Array)",
    null: "\u1782\u17D2\u1798\u17B6\u1793\u178F\u1798\u17D2\u179B\u17C3 (null)"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A instanceof ${t.expected} \u1794\u17C9\u17BB\u1793\u17D2\u178F\u17C2\u1791\u1791\u17BD\u179B\u1794\u17B6\u1793 ${c}` : `\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${n} \u1794\u17C9\u17BB\u1793\u17D2\u178F\u17C2\u1791\u1791\u17BD\u179B\u1794\u17B6\u1793 ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${h(t.values[0])}` : `\u1787\u1798\u17D2\u179A\u17BE\u179F\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1787\u17B6\u1798\u17BD\u1799\u1780\u17D2\u1793\u17BB\u1784\u1785\u17C6\u178E\u17C4\u1798 ${p(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u1792\u17C6\u1796\u17C1\u1780\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${t.origin ?? "\u178F\u1798\u17D2\u179B\u17C3"} ${n} ${t.maximum.toString()} ${a.unit ?? "\u1792\u17B6\u178F\u17BB"}` : `\u1792\u17C6\u1796\u17C1\u1780\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${t.origin ?? "\u178F\u1798\u17D2\u179B\u17C3"} ${n} ${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u178F\u17BC\u1785\u1796\u17C1\u1780\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${t.origin} ${n} ${t.minimum.toString()} ${a.unit}` : `\u178F\u17BC\u1785\u1796\u17C1\u1780\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${t.origin} ${n} ${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1785\u17B6\u1794\u17CB\u1795\u17D2\u178F\u17BE\u1798\u178A\u17C4\u1799 "${n.prefix}"` : n.format === "ends_with" ? `\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1794\u1789\u17D2\u1785\u1794\u17CB\u178A\u17C4\u1799 "${n.suffix}"` : n.format === "includes" ? `\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1798\u17B6\u1793 "${n.includes}"` : n.format === "regex" ? `\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u178F\u17C2\u1795\u17D2\u1782\u17BC\u1795\u17D2\u1782\u1784\u1793\u17B9\u1784\u1791\u1798\u17D2\u179A\u1784\u17CB\u178A\u17C2\u179B\u1794\u17B6\u1793\u1780\u17C6\u178E\u178F\u17CB ${n.pattern}` : `\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u179B\u17C1\u1781\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u178F\u17C2\u1787\u17B6\u1796\u17A0\u17BB\u1782\u17BB\u178E\u1793\u17C3 ${t.divisor}`;
      case "unrecognized_keys":
        return `\u179A\u1780\u1783\u17BE\u1789\u179F\u17C4\u1798\u17B7\u1793\u179F\u17D2\u1782\u17B6\u179B\u17CB\u17D6 ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `\u179F\u17C4\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u1793\u17C5\u1780\u17D2\u1793\u17BB\u1784 ${t.origin}`;
      case "invalid_union":
        return "\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C";
      case "invalid_element":
        return `\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u1793\u17C5\u1780\u17D2\u1793\u17BB\u1784 ${t.origin}`;
      default:
        return "\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C";
    }
  };
}, "error");
function er() {
  return {
    localeError: Og()
  };
}
u(er, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/kh.js
function Au() {
  return er();
}
u(Au, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/kn.js
var Ug = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "\u0C85\u0C95\u0CCD\u0CB7\u0CB0\u0C97\u0CB3\u0CC1", verb: "\u0CB9\u0CCA\u0C82\u0CA6\u0CB2\u0CC1" },
    file: { unit: "\u0CAC\u0CC8\u0C9F\u0CCD\u200C\u0C97\u0CB3\u0CC1", verb: "\u0CB9\u0CCA\u0C82\u0CA6\u0CB2\u0CC1" },
    array: { unit: "\u0CB5\u0CB8\u0CCD\u0CA4\u0CC1\u0C97\u0CB3\u0CC1", verb: "\u0CB9\u0CCA\u0C82\u0CA6\u0CB2\u0CC1" },
    set: { unit: "\u0CB5\u0CB8\u0CCD\u0CA4\u0CC1\u0C97\u0CB3\u0CC1", verb: "\u0CB9\u0CCA\u0C82\u0CA6\u0CB2\u0CC1" },
    map: { unit: "entries", verb: "\u0CB9\u0CCA\u0C82\u0CA6\u0CB2\u0CC1" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "\u0C87\u0CA8\u0CCD\u0CAA\u0CC1\u0C9F\u0CCD",
    email: "email \u0CB5\u0CBF\u0CB3\u0CBE\u0CB8",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0CA6\u0CBF\u0CA8\u0CBE\u0C82\u0C95\u0CA6 \u0CB8\u0CAE\u0CAF",
    date: "ISO \u0CA6\u0CBF\u0CA8\u0CBE\u0C82\u0C95",
    time: "ISO \u0CB8\u0CAE\u0CAF",
    duration: "ISO \u0C85\u0CB5\u0CA7\u0CBF",
    ipv4: "IPv4 \u0CB5\u0CBF\u0CB3\u0CBE\u0CB8",
    ipv6: "IPv6 \u0CB5\u0CBF\u0CB3\u0CBE\u0CB8",
    mac: "MAC \u0CB5\u0CBF\u0CB3\u0CBE\u0CB8",
    cidrv4: "IPv4 \u0CB5\u0CCD\u0CAF\u0CBE\u0CAA\u0CCD\u0CA4\u0CBF\u0CAF",
    cidrv6: "IPv6 \u0CB5\u0CCD\u0CAF\u0CBE\u0CAA\u0CCD\u0CA4\u0CBF\u0CAF",
    base64: "base64-encoded\u0CB8\u0CCD\u0C9F\u0CCD\u0CB0\u0CBF\u0C82\u0C97\u0CCD",
    base64url: "base64url-encoded\u0CB8\u0CCD\u0C9F\u0CCD\u0CB0\u0CBF\u0C82\u0C97\u0CCD",
    json_string: "JSON\u0CB8\u0CCD\u0C9F\u0CCD\u0CB0\u0CBF\u0C82\u0C97\u0CCD",
    e164: "E.164 \u0CB8\u0C82\u0C96\u0CCD\u0CAF\u0CC6",
    credit_card: "\u0C95\u0CCD\u0CB0\u0CC6\u0CA1\u0CBF\u0C9F\u0CCD \u0C95\u0CBE\u0CB0\u0CCD\u0CA1\u0CCD \u0CB8\u0C82\u0C96\u0CCD\u0CAF\u0CC6",
    jwt: "JWT",
    template_literal: "\u0C87\u0CA8\u0CCD\u0CAA\u0CC1\u0C9F\u0CCD"
  }, o = {
    // Compatibility: "nan" -> "NaN" for display
    nan: "NaN"
    // All other type names omitted - they fall back to raw values via ?? operator
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0C87\u0CA8\u0CCD\u200C\u0CAA\u0CC1\u0C9F\u0CCD: \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${n}, \u0CB8\u0CCD\u0CB5\u0CC0\u0C95\u0CB0\u0CBF\u0CB8\u0CBF\u0CA6\u0CA8\u0CC1 ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0C87\u0CA8\u0CCD\u200C\u0CAA\u0CC1\u0C9F\u0CCD: \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${h(t.values[0])}` : `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0C86\u0CAF\u0CCD\u0C95\u0CC6: \u0C87\u0CB5\u0CC1\u0C97\u0CB3\u0CB2\u0CCD\u0CB2\u0CBF \u0C92\u0C82\u0CA6\u0CA8\u0CCD\u0CA8\u0CC1 \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${p(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u0CA4\u0CC1\u0C82\u0CAC\u0CBE \u0CA6\u0CCA\u0CA1\u0CCD\u0CA1\u0CA6\u0CC1: \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${t.origin ?? "value"} \u0CB9\u0CCA\u0C82\u0CA6\u0CB2\u0CC1 ${n}${t.maximum.toString()} ${a.unit ?? "\u0C85\u0C82\u0CB6\u0C97\u0CB3\u0CC1"}` : `\u0CA4\u0CC1\u0C82\u0CAC\u0CBE \u0CA6\u0CCA\u0CA1\u0CCD\u0CA1\u0CA6\u0CC1: \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${t.origin ?? "value"} \u0C8E\u0C82\u0CA6\u0CC1 ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u0CA4\u0CC1\u0C82\u0CAC\u0CBE \u0C9A\u0CBF\u0C95\u0CCD\u0C95\u0CA6\u0CC1: \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${t.origin} \u0CB9\u0CCA\u0C82\u0CA6\u0CB2\u0CC1 ${n}${t.minimum.toString()} ${a.unit}` : `\u0CA4\u0CC1\u0C82\u0CAC\u0CBE \u0C9A\u0CBF\u0C95\u0CCD\u0C95\u0CA6\u0CC1: \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${t.origin} \u0C8E\u0C82\u0CA6\u0CC1 ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF\u0CB5\u0CBE\u0CA6 \u0CB8\u0CCD\u0C9F\u0CCD\u0CB0\u0CBF\u0C82\u0C97\u0CCD: \u0C87\u0CA6\u0CB0\u0CCA\u0C82\u0CA6\u0CBF\u0C97\u0CC6 \u0CAA\u0CCD\u0CB0\u0CBE\u0CB0\u0C82\u0CAD\u0CBF\u0CB8\u0CAC\u0CC7\u0C95\u0CC1 "${n.prefix}"` : n.format === "ends_with" ? `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF\u0CB5\u0CBE\u0CA6 \u0CB8\u0CCD\u0C9F\u0CCD\u0CB0\u0CBF\u0C82\u0C97\u0CCD: \u0C87\u0CA6\u0CB0\u0CCA\u0C82\u0CA6\u0CBF\u0C97\u0CC6 \u0C95\u0CCA\u0CA8\u0CC6\u0C97\u0CCA\u0CB3\u0CCD\u0CB3\u0CAC\u0CC7\u0C95\u0CC1 "${n.suffix}"` : n.format === "includes" ? `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0CB8\u0CCD\u0C9F\u0CCD\u0CB0\u0CBF\u0C82\u0C97\u0CCD: \u0C92\u0CB3\u0C97\u0CCA\u0C82\u0CA1\u0CBF\u0CB0\u0CAC\u0CC7\u0C95\u0CC1 "${n.includes}"` : n.format === "regex" ? `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF\u0CB5\u0CBE\u0CA6 \u0CB8\u0CCD\u0C9F\u0CCD\u0CB0\u0CBF\u0C82\u0C97\u0CCD: \u0CAE\u0CBE\u0CA6\u0CB0\u0CBF\u0C97\u0CC6 \u0CB9\u0CCA\u0C82\u0CA6\u0CBF\u0C95\u0CC6\u0CAF\u0CBE\u0C97\u0CAC\u0CC7\u0C95\u0CC1 ${n.pattern}` : `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0CB8\u0C82\u0C96\u0CCD\u0CAF\u0CC6: \u0CAC\u0CB9\u0CC1\u0CB8\u0C82\u0C96\u0CCD\u0CAF\u0CC6\u0CAF\u0CBE\u0C97\u0CBF\u0CB0\u0CAC\u0CC7\u0C95\u0CC1 ${t.divisor}`;
      case "unrecognized_keys":
        return `\u0C97\u0CC1\u0CB0\u0CC1\u0CA4\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CA6 \u0C95\u0CC0 ${t.keys.length > 1 ? "s" : ""}: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF\u0CB5\u0CBE\u0CA6 \u0C95\u0CC0 \u0C87\u0CA8\u0CCD ${t.origin}`;
      case "invalid_union":
        return t.options && Array.isArray(t.options) && t.options.length > 0 ? `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0CA4\u0CBE\u0CB0\u0CA4\u0CAE\u0CCD\u0CAF \u0CAE\u0CCC\u0CB2\u0CCD\u0CAF. \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${t.options.map((a) => `'${a}'`).join(" | ")}` : "\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0C87\u0CA8\u0CCD\u200C\u0CAA\u0CC1\u0C9F\u0CCD";
      case "invalid_element":
        return `\u0CB0\u0CB2\u0CCD\u0CB2\u0CBF \u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0CAE\u0CCC\u0CB2\u0CCD\u0CAF ${t.origin}`;
      default:
        return "\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0C87\u0CA8\u0CCD\u200C\u0CAA\u0CC1\u0C9F\u0CCD";
    }
  };
}, "error");
function Eu() {
  return {
    localeError: Ug()
  };
}
u(Eu, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ko.js
var Ng = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "\uBB38\uC790", verb: "to have" },
    file: { unit: "\uBC14\uC774\uD2B8", verb: "to have" },
    array: { unit: "\uAC1C", verb: "to have" },
    set: { unit: "\uAC1C", verb: "to have" },
    map: { unit: "\uAC1C", verb: "to have" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "\uC785\uB825",
    email: "\uC774\uBA54\uC77C \uC8FC\uC18C",
    url: "URL",
    emoji: "\uC774\uBAA8\uC9C0",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \uB0A0\uC9DC\uC2DC\uAC04",
    date: "ISO \uB0A0\uC9DC",
    time: "ISO \uC2DC\uAC04",
    duration: "ISO \uAE30\uAC04",
    ipv4: "IPv4 \uC8FC\uC18C",
    ipv6: "IPv6 \uC8FC\uC18C",
    mac: "MAC \uC8FC\uC18C",
    cidrv4: "IPv4 \uBC94\uC704",
    cidrv6: "IPv6 \uBC94\uC704",
    base64: "base64 \uC778\uCF54\uB529 \uBB38\uC790\uC5F4",
    base64url: "base64url \uC778\uCF54\uB529 \uBB38\uC790\uC5F4",
    json_string: "JSON \uBB38\uC790\uC5F4",
    e164: "E.164 \uBC88\uD638",
    credit_card: "\uC2E0\uC6A9\uCE74\uB4DC \uBC88\uD638",
    jwt: "JWT",
    template_literal: "\uC785\uB825"
  }, o = {
    nan: "NaN"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\uC798\uBABB\uB41C \uC785\uB825: \uC608\uC0C1 \uD0C0\uC785\uC740 instanceof ${t.expected}, \uBC1B\uC740 \uD0C0\uC785\uC740 ${c}\uC785\uB2C8\uB2E4` : `\uC798\uBABB\uB41C \uC785\uB825: \uC608\uC0C1 \uD0C0\uC785\uC740 ${n}, \uBC1B\uC740 \uD0C0\uC785\uC740 ${c}\uC785\uB2C8\uB2E4`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\uC798\uBABB\uB41C \uC785\uB825: \uAC12\uC740 ${h(t.values[0])} \uC774\uC5B4\uC57C \uD569\uB2C8\uB2E4` : `\uC798\uBABB\uB41C \uC635\uC158: ${p(t.values, "\uB610\uB294 ")} \uC911 \uD558\uB098\uC5EC\uC57C \uD569\uB2C8\uB2E4`;
      case "too_big": {
        let n = t.inclusive ? "\uC774\uD558" : "\uBBF8\uB9CC", a = n === "\uBBF8\uB9CC" ? "\uC774\uC5B4\uC57C \uD569\uB2C8\uB2E4" : "\uC5EC\uC57C \uD569\uB2C8\uB2E4", c = r(t.origin), s = c?.unit ?? "\uC694\uC18C";
        return c ? `${t.origin ?? "\uAC12"}\uC774 \uB108\uBB34 \uD07D\uB2C8\uB2E4: ${t.maximum.toString()}${s} ${n}${a}` : `${t.origin ?? "\uAC12"}\uC774 \uB108\uBB34 \uD07D\uB2C8\uB2E4: ${t.maximum.toString()} ${n}${a}`;
      }
      case "too_small": {
        let n = t.inclusive ? "\uC774\uC0C1" : "\uCD08\uACFC", a = n === "\uC774\uC0C1" ? "\uC774\uC5B4\uC57C \uD569\uB2C8\uB2E4" : "\uC5EC\uC57C \uD569\uB2C8\uB2E4", c = r(t.origin), s = c?.unit ?? "\uC694\uC18C";
        return c ? `${t.origin ?? "\uAC12"}\uC774 \uB108\uBB34 \uC791\uC2B5\uB2C8\uB2E4: ${t.minimum.toString()}${s} ${n}${a}` : `${t.origin ?? "\uAC12"}\uC774 \uB108\uBB34 \uC791\uC2B5\uB2C8\uB2E4: ${t.minimum.toString()} ${n}${a}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\uC798\uBABB\uB41C \uBB38\uC790\uC5F4: "${n.prefix}"(\uC73C)\uB85C \uC2DC\uC791\uD574\uC57C \uD569\uB2C8\uB2E4` : n.format === "ends_with" ? `\uC798\uBABB\uB41C \uBB38\uC790\uC5F4: "${n.suffix}"(\uC73C)\uB85C \uB05D\uB098\uC57C \uD569\uB2C8\uB2E4` : n.format === "includes" ? `\uC798\uBABB\uB41C \uBB38\uC790\uC5F4: "${n.includes}"\uC744(\uB97C) \uD3EC\uD568\uD574\uC57C \uD569\uB2C8\uB2E4` : n.format === "regex" ? `\uC798\uBABB\uB41C \uBB38\uC790\uC5F4: \uC815\uADDC\uC2DD ${n.pattern} \uD328\uD134\uACFC \uC77C\uCE58\uD574\uC57C \uD569\uB2C8\uB2E4` : `\uC798\uBABB\uB41C ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\uC798\uBABB\uB41C \uC22B\uC790: ${t.divisor}\uC758 \uBC30\uC218\uC5EC\uC57C \uD569\uB2C8\uB2E4`;
      case "unrecognized_keys":
        return `\uC778\uC2DD\uD560 \uC218 \uC5C6\uB294 \uD0A4: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `\uC798\uBABB\uB41C \uD0A4: ${t.origin}`;
      case "invalid_union":
        return "\uC798\uBABB\uB41C \uC785\uB825";
      case "invalid_element":
        return `\uC798\uBABB\uB41C \uAC12: ${t.origin}`;
      default:
        return "\uC798\uBABB\uB41C \uC785\uB825";
    }
  };
}, "error");
function Cu() {
  return {
    localeError: Ng()
  };
}
u(Cu, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/lt.js
var tr = /* @__PURE__ */ u((e) => e.charAt(0).toUpperCase() + e.slice(1), "capitalizeFirstCharacter");
function Zd(e) {
  let r = Math.abs(e), i = r % 10, o = r % 100;
  return o >= 11 && o <= 19 || i === 0 ? "many" : i === 1 ? "one" : "few";
}
u(Zd, "getUnitTypeFromNumber");
var Tg = /* @__PURE__ */ u(() => {
  let e = {
    string: {
      unit: {
        one: "simbolis",
        few: "simboliai",
        many: "simboli\u0173"
      },
      verb: {
        smaller: {
          inclusive: "turi b\u016Bti ne ilgesn\u0117 kaip",
          notInclusive: "turi b\u016Bti trumpesn\u0117 kaip"
        },
        bigger: {
          inclusive: "turi b\u016Bti ne trumpesn\u0117 kaip",
          notInclusive: "turi b\u016Bti ilgesn\u0117 kaip"
        }
      }
    },
    file: {
      unit: {
        one: "baitas",
        few: "baitai",
        many: "bait\u0173"
      },
      verb: {
        smaller: {
          inclusive: "turi b\u016Bti ne didesnis kaip",
          notInclusive: "turi b\u016Bti ma\u017Eesnis kaip"
        },
        bigger: {
          inclusive: "turi b\u016Bti ne ma\u017Eesnis kaip",
          notInclusive: "turi b\u016Bti didesnis kaip"
        }
      }
    },
    array: {
      unit: {
        one: "element\u0105",
        few: "elementus",
        many: "element\u0173"
      },
      verb: {
        smaller: {
          inclusive: "turi tur\u0117ti ne daugiau kaip",
          notInclusive: "turi tur\u0117ti ma\u017Eiau kaip"
        },
        bigger: {
          inclusive: "turi tur\u0117ti ne ma\u017Eiau kaip",
          notInclusive: "turi tur\u0117ti daugiau kaip"
        }
      }
    },
    set: {
      unit: {
        one: "element\u0105",
        few: "elementus",
        many: "element\u0173"
      },
      verb: {
        smaller: {
          inclusive: "turi tur\u0117ti ne daugiau kaip",
          notInclusive: "turi tur\u0117ti ma\u017Eiau kaip"
        },
        bigger: {
          inclusive: "turi tur\u0117ti ne ma\u017Eiau kaip",
          notInclusive: "turi tur\u0117ti daugiau kaip"
        }
      }
    }
  };
  function r(t, n, a, c) {
    let s = e[t] ?? null;
    return s === null ? s : {
      unit: s.unit[n],
      verb: s.verb[c][a ? "inclusive" : "notInclusive"]
    };
  }
  u(r, "getSizing");
  let i = {
    regex: "\u012Fvestis",
    email: "el. pa\u0161to adresas",
    url: "URL",
    emoji: "jaustukas",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO data ir laikas",
    date: "ISO data",
    time: "ISO laikas",
    duration: "ISO trukm\u0117",
    ipv4: "IPv4 adresas",
    ipv6: "IPv6 adresas",
    mac: "MAC adresas",
    cidrv4: "IPv4 tinklo prefiksas (CIDR)",
    cidrv6: "IPv6 tinklo prefiksas (CIDR)",
    base64: "base64 u\u017Ekoduota eilut\u0117",
    base64url: "base64url u\u017Ekoduota eilut\u0117",
    json_string: "JSON eilut\u0117",
    e164: "E.164 numeris",
    credit_card: "kredito kortel\u0117s numeris",
    jwt: "JWT",
    template_literal: "\u012Fvestis"
  }, o = {
    nan: "NaN",
    number: "skai\u010Dius",
    bigint: "sveikasis skai\u010Dius",
    string: "eilut\u0117",
    boolean: "login\u0117 reik\u0161m\u0117",
    undefined: "neapibr\u0117\u017Eta reik\u0161m\u0117",
    function: "funkcija",
    symbol: "simbolis",
    array: "masyvas",
    object: "objektas",
    null: "nulin\u0117 reik\u0161m\u0117"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Gautas tipas ${c}, o tik\u0117tasi - instanceof ${t.expected}` : `Gautas tipas ${c}, o tik\u0117tasi - ${n}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Privalo b\u016Bti ${h(t.values[0])}` : `Privalo b\u016Bti vienas i\u0161 ${p(t.values, "|")} pasirinkim\u0173`;
      case "too_big": {
        let n = o[t.origin] ?? t.origin, a = r(t.origin, Zd(Number(t.maximum)), t.inclusive ?? !1, "smaller");
        if (a?.verb)
          return `${tr(n ?? t.origin ?? "reik\u0161m\u0117")} ${a.verb} ${t.maximum.toString()} ${a.unit ?? "element\u0173"}`;
        let c = t.inclusive ? "ne didesnis kaip" : "ma\u017Eesnis kaip";
        return `${tr(n ?? t.origin ?? "reik\u0161m\u0117")} turi b\u016Bti ${c} ${t.maximum.toString()} ${a?.unit}`;
      }
      case "too_small": {
        let n = o[t.origin] ?? t.origin, a = r(t.origin, Zd(Number(t.minimum)), t.inclusive ?? !1, "bigger");
        if (a?.verb)
          return `${tr(n ?? t.origin ?? "reik\u0161m\u0117")} ${a.verb} ${t.minimum.toString()} ${a.unit ?? "element\u0173"}`;
        let c = t.inclusive ? "ne ma\u017Eesnis kaip" : "didesnis kaip";
        return `${tr(n ?? t.origin ?? "reik\u0161m\u0117")} turi b\u016Bti ${c} ${t.minimum.toString()} ${a?.unit}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Eilut\u0117 privalo prasid\u0117ti "${n.prefix}"` : n.format === "ends_with" ? `Eilut\u0117 privalo pasibaigti "${n.suffix}"` : n.format === "includes" ? `Eilut\u0117 privalo \u012Ftraukti "${n.includes}"` : n.format === "regex" ? `Eilut\u0117 privalo atitikti ${n.pattern}` : `Neteisingas ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Skai\u010Dius privalo b\u016Bti ${t.divisor} kartotinis.`;
      case "unrecognized_keys":
        return `Neatpa\u017Eint${t.keys.length > 1 ? "i" : "as"} rakt${t.keys.length > 1 ? "ai" : "as"}: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return "Rastas klaidingas raktas";
      case "invalid_union":
        return "Klaidinga \u012Fvestis";
      case "invalid_element": {
        let n = o[t.origin] ?? t.origin;
        return `${tr(n ?? t.origin ?? "reik\u0161m\u0117")} turi klaiding\u0105 \u012Fvest\u012F`;
      }
      default:
        return "Klaidinga \u012Fvestis";
    }
  };
}, "error");
function Lu() {
  return {
    localeError: Tg()
  };
}
u(Lu, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/mk.js
var Zg = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "\u0437\u043D\u0430\u0446\u0438", verb: "\u0434\u0430 \u0438\u043C\u0430\u0430\u0442" },
    file: { unit: "\u0431\u0430\u0458\u0442\u0438", verb: "\u0434\u0430 \u0438\u043C\u0430\u0430\u0442" },
    array: { unit: "\u0441\u0442\u0430\u0432\u043A\u0438", verb: "\u0434\u0430 \u0438\u043C\u0430\u0430\u0442" },
    set: { unit: "\u0441\u0442\u0430\u0432\u043A\u0438", verb: "\u0434\u0430 \u0438\u043C\u0430\u0430\u0442" },
    map: { unit: "\u0441\u0442\u0430\u0432\u043A\u0438", verb: "\u0434\u0430 \u0438\u043C\u0430\u0430\u0442" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "\u0432\u043D\u0435\u0441",
    email: "\u0430\u0434\u0440\u0435\u0441\u0430 \u043D\u0430 \u0435-\u043F\u043E\u0448\u0442\u0430",
    url: "URL",
    emoji: "\u0435\u043C\u043E\u045F\u0438",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0434\u0430\u0442\u0443\u043C \u0438 \u0432\u0440\u0435\u043C\u0435",
    date: "ISO \u0434\u0430\u0442\u0443\u043C",
    time: "ISO \u0432\u0440\u0435\u043C\u0435",
    duration: "ISO \u0432\u0440\u0435\u043C\u0435\u0442\u0440\u0430\u0435\u045A\u0435",
    ipv4: "IPv4 \u0430\u0434\u0440\u0435\u0441\u0430",
    ipv6: "IPv6 \u0430\u0434\u0440\u0435\u0441\u0430",
    mac: "MAC \u0430\u0434\u0440\u0435\u0441\u0430",
    cidrv4: "IPv4 \u043E\u043F\u0441\u0435\u0433",
    cidrv6: "IPv6 \u043E\u043F\u0441\u0435\u0433",
    base64: "base64-\u0435\u043D\u043A\u043E\u0434\u0438\u0440\u0430\u043D\u0430 \u043D\u0438\u0437\u0430",
    base64url: "base64url-\u0435\u043D\u043A\u043E\u0434\u0438\u0440\u0430\u043D\u0430 \u043D\u0438\u0437\u0430",
    json_string: "JSON \u043D\u0438\u0437\u0430",
    e164: "E.164 \u0431\u0440\u043E\u0458",
    credit_card: "\u0431\u0440\u043E\u0458 \u043D\u0430 \u043A\u0440\u0435\u0434\u0438\u0442\u043D\u0430 \u043A\u0430\u0440\u0442\u0438\u0447\u043A\u0430",
    jwt: "JWT",
    template_literal: "\u0432\u043D\u0435\u0441"
  }, o = {
    nan: "NaN",
    number: "\u0431\u0440\u043E\u0458",
    array: "\u043D\u0438\u0437\u0430"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u0413\u0440\u0435\u0448\u0435\u043D \u0432\u043D\u0435\u0441: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 instanceof ${t.expected}, \u043F\u0440\u0438\u043C\u0435\u043D\u043E ${c}` : `\u0413\u0440\u0435\u0448\u0435\u043D \u0432\u043D\u0435\u0441: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${n}, \u043F\u0440\u0438\u043C\u0435\u043D\u043E ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Invalid input: expected ${h(t.values[0])}` : `\u0413\u0440\u0435\u0448\u0430\u043D\u0430 \u043E\u043F\u0446\u0438\u0458\u0430: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 \u0435\u0434\u043D\u0430 ${p(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u041F\u0440\u0435\u043C\u043D\u043E\u0433\u0443 \u0433\u043E\u043B\u0435\u043C: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${t.origin ?? "\u0432\u0440\u0435\u0434\u043D\u043E\u0441\u0442\u0430"} \u0434\u0430 \u0438\u043C\u0430 ${n}${t.maximum.toString()} ${a.unit ?? "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0438"}` : `\u041F\u0440\u0435\u043C\u043D\u043E\u0433\u0443 \u0433\u043E\u043B\u0435\u043C: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${t.origin ?? "\u0432\u0440\u0435\u0434\u043D\u043E\u0441\u0442\u0430"} \u0434\u0430 \u0431\u0438\u0434\u0435 ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u041F\u0440\u0435\u043C\u043D\u043E\u0433\u0443 \u043C\u0430\u043B: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${t.origin} \u0434\u0430 \u0438\u043C\u0430 ${n}${t.minimum.toString()} ${a.unit}` : `\u041F\u0440\u0435\u043C\u043D\u043E\u0433\u0443 \u043C\u0430\u043B: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${t.origin} \u0434\u0430 \u0431\u0438\u0434\u0435 ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u041D\u0435\u0432\u0430\u0436\u0435\u0447\u043A\u0430 \u043D\u0438\u0437\u0430: \u043C\u043E\u0440\u0430 \u0434\u0430 \u0437\u0430\u043F\u043E\u0447\u043D\u0443\u0432\u0430 \u0441\u043E "${n.prefix}"` : n.format === "ends_with" ? `\u041D\u0435\u0432\u0430\u0436\u0435\u0447\u043A\u0430 \u043D\u0438\u0437\u0430: \u043C\u043E\u0440\u0430 \u0434\u0430 \u0437\u0430\u0432\u0440\u0448\u0443\u0432\u0430 \u0441\u043E "${n.suffix}"` : n.format === "includes" ? `\u041D\u0435\u0432\u0430\u0436\u0435\u0447\u043A\u0430 \u043D\u0438\u0437\u0430: \u043C\u043E\u0440\u0430 \u0434\u0430 \u0432\u043A\u043B\u0443\u0447\u0443\u0432\u0430 "${n.includes}"` : n.format === "regex" ? `\u041D\u0435\u0432\u0430\u0436\u0435\u0447\u043A\u0430 \u043D\u0438\u0437\u0430: \u043C\u043E\u0440\u0430 \u0434\u0430 \u043E\u0434\u0433\u043E\u0430\u0440\u0430 \u043D\u0430 \u043F\u0430\u0442\u0435\u0440\u043D\u043E\u0442 ${n.pattern}` : `Invalid ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u0413\u0440\u0435\u0448\u0435\u043D \u0431\u0440\u043E\u0458: \u043C\u043E\u0440\u0430 \u0434\u0430 \u0431\u0438\u0434\u0435 \u0434\u0435\u043B\u0438\u0432 \u0441\u043E ${t.divisor}`;
      case "unrecognized_keys":
        return `${t.keys.length > 1 ? "\u041D\u0435\u043F\u0440\u0435\u043F\u043E\u0437\u043D\u0430\u0435\u043D\u0438 \u043A\u043B\u0443\u0447\u0435\u0432\u0438" : "\u041D\u0435\u043F\u0440\u0435\u043F\u043E\u0437\u043D\u0430\u0435\u043D \u043A\u043B\u0443\u0447"}: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `\u0413\u0440\u0435\u0448\u0435\u043D \u043A\u043B\u0443\u0447 \u0432\u043E ${t.origin}`;
      case "invalid_union":
        return "\u0413\u0440\u0435\u0448\u0435\u043D \u0432\u043D\u0435\u0441";
      case "invalid_element":
        return `\u0413\u0440\u0435\u0448\u043D\u0430 \u0432\u0440\u0435\u0434\u043D\u043E\u0441\u0442 \u0432\u043E ${t.origin}`;
      default:
        return "\u0413\u0440\u0435\u0448\u0435\u043D \u0432\u043D\u0435\u0441";
    }
  };
}, "error");
function Vu() {
  return {
    localeError: Zg()
  };
}
u(Vu, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ms.js
var Ag = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "aksara", verb: "mempunyai" },
    file: { unit: "bait", verb: "mempunyai" },
    array: { unit: "elemen", verb: "mempunyai" },
    set: { unit: "elemen", verb: "mempunyai" },
    map: { unit: "elemen", verb: "mempunyai" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "input",
    email: "alamat e-mel",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "tarikh masa ISO",
    date: "tarikh ISO",
    time: "masa ISO",
    duration: "tempoh ISO",
    ipv4: "alamat IPv4",
    ipv6: "alamat IPv6",
    mac: "alamat MAC",
    cidrv4: "julat IPv4",
    cidrv6: "julat IPv6",
    base64: "string dikodkan base64",
    base64url: "string dikodkan base64url",
    json_string: "string JSON",
    e164: "nombor E.164",
    credit_card: "nombor kad kredit",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN",
    number: "nombor"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Input tidak sah: dijangka instanceof ${t.expected}, diterima ${c}` : `Input tidak sah: dijangka ${n}, diterima ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Input tidak sah: dijangka ${h(t.values[0])}` : `Pilihan tidak sah: dijangka salah satu daripada ${p(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Terlalu besar: dijangka ${t.origin ?? "nilai"} ${a.verb} ${n}${t.maximum.toString()} ${a.unit ?? "elemen"}` : `Terlalu besar: dijangka ${t.origin ?? "nilai"} adalah ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Terlalu kecil: dijangka ${t.origin} ${a.verb} ${n}${t.minimum.toString()} ${a.unit}` : `Terlalu kecil: dijangka ${t.origin} adalah ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `String tidak sah: mesti bermula dengan "${n.prefix}"` : n.format === "ends_with" ? `String tidak sah: mesti berakhir dengan "${n.suffix}"` : n.format === "includes" ? `String tidak sah: mesti mengandungi "${n.includes}"` : n.format === "regex" ? `String tidak sah: mesti sepadan dengan corak ${n.pattern}` : `${i[n.format] ?? t.format} tidak sah`;
      }
      case "not_multiple_of":
        return `Nombor tidak sah: perlu gandaan ${t.divisor}`;
      case "unrecognized_keys":
        return `Kunci tidak dikenali: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `Kunci tidak sah dalam ${t.origin}`;
      case "invalid_union":
        return "Input tidak sah";
      case "invalid_element":
        return `Nilai tidak sah dalam ${t.origin}`;
      default:
        return "Input tidak sah";
    }
  };
}, "error");
function Ru() {
  return {
    localeError: Ag()
  };
}
u(Ru, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ne.js
var Eg = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "\u0905\u0915\u094D\u0937\u0930", verb: "\u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B" },
    file: { unit: "\u092C\u093E\u0907\u091F", verb: "\u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B" },
    array: { unit: "\u0924\u0924\u094D\u0935", verb: "\u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B" },
    set: { unit: "\u0924\u0924\u094D\u0935", verb: "\u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B" },
    map: { unit: "\u092A\u094D\u0930\u0935\u093F\u0937\u094D\u091F\u093F", verb: "\u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "\u0907\u0928\u092A\u0941\u091F",
    email: "\u0907\u092E\u0947\u0932 \u0920\u0947\u0917\u093E\u0928\u093E",
    url: "URL",
    emoji: "\u0907\u092E\u094B\u091C\u0940",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u092E\u093F\u0924\u093F \u0930 \u0938\u092E\u092F",
    date: "ISO \u092E\u093F\u0924\u093F",
    time: "ISO \u0938\u092E\u092F",
    duration: "ISO \u0905\u0935\u0927\u093F",
    ipv4: "IPv4 \u0920\u0947\u0917\u093E\u0928\u093E",
    ipv6: "IPv6 \u0920\u0947\u0917\u093E\u0928\u093E",
    mac: "MAC \u0920\u0947\u0917\u093E\u0928\u093E",
    cidrv4: "IPv4 \u0926\u093E\u092F\u0930\u093E",
    cidrv6: "IPv6 \u0926\u093E\u092F\u0930\u093E",
    base64: "base64-\u0907\u0928\u094D\u0915\u094B\u0921 \u0917\u0930\u093F\u090F\u0915\u094B \u0938\u094D\u091F\u094D\u0930\u093F\u0919",
    base64url: "base64url-\u0907\u0928\u094D\u0915\u094B\u0921 \u0917\u0930\u093F\u090F\u0915\u094B \u0938\u094D\u091F\u094D\u0930\u093F\u0919",
    json_string: "JSON \u0938\u094D\u091F\u094D\u0930\u093F\u0919",
    e164: "E.164 \u0928\u092E\u094D\u092C\u0930",
    credit_card: "\u0915\u094D\u0930\u0947\u0921\u093F\u091F \u0915\u093E\u0930\u094D\u0921 \u0928\u092E\u094D\u092C\u0930",
    jwt: "JWT",
    template_literal: "\u0907\u0928\u092A\u0941\u091F"
  }, o = {
    nan: "NaN"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return `\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 ${n}, \u092A\u094D\u0930\u093E\u092A\u094D\u0924 ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 ${h(t.values[0])}` : `\u0905\u092E\u093E\u0928\u094D\u092F \u0935\u093F\u0915\u0932\u094D\u092A: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 \u092E\u093E\u0928\u0939\u0930\u0942 \u092E\u0927\u094D\u092F\u0947 \u090F\u0915 ${p(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u0927\u0947\u0930\u0948 \u0920\u0942\u0932\u094B: ${t.origin ?? "\u092E\u093E\u0928"} \u092E\u093E ${n}${t.maximum.toString()} ${a.unit} ${a.verb}` : `\u0927\u0947\u0930\u0948 \u0920\u0942\u0932\u094B: ${t.origin ?? "\u092E\u093E\u0928"} ${n}${t.maximum.toString()} \u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u0927\u0947\u0930\u0948 \u0938\u093E\u0928\u094B: ${t.origin} \u092E\u093E ${n}${t.minimum.toString()} ${a.unit} ${a.verb}` : `\u0927\u0947\u0930\u0948 \u0938\u093E\u0928\u094B: ${t.origin} ${n}${t.minimum.toString()} \u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0919: "${n.prefix}" \u092C\u093E\u091F \u0938\u0941\u0930\u0941 \u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B` : n.format === "ends_with" ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0919: "${n.suffix}" \u092E\u093E \u0938\u092E\u093E\u092A\u094D\u0924 \u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B` : n.format === "includes" ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0919: "${n.includes}" \u0938\u092E\u093E\u0935\u0947\u0936 \u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B` : n.format === "regex" ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0919: \u0922\u093E\u0901\u091A\u093E ${n.pattern} \u0938\u0901\u0917 \u092E\u0947\u0932 \u0916\u093E\u0928\u0941\u092A\u0930\u094D\u091B` : `\u0905\u092E\u093E\u0928\u094D\u092F ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u0902\u0916\u094D\u092F\u093E: ${t.divisor} \u0915\u094B \u0917\u0941\u0923\u091C \u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B`;
      case "unrecognized_keys":
        return `\u0905\u092A\u0930\u093F\u091A\u093F\u0924 \u0915\u0941\u091E\u094D\u091C\u0940${t.keys.length > 1 ? "\u0939\u0930\u0942" : ""}: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `\u0905\u092E\u093E\u0928\u094D\u092F \u0915\u0941\u091E\u094D\u091C\u0940: ${t.origin} \u092E\u093E`;
      case "invalid_union":
        return t.options && Array.isArray(t.options) && t.options.length > 0 ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0921\u093F\u0938\u094D\u0915\u094D\u0930\u093F\u092E\u093F\u0928\u0947\u091F\u0930 \u092E\u093E\u0928: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 ${t.options.map((a) => `'${a}'`).join(" | ")}` : "\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F";
      case "invalid_element":
        return `\u0905\u092E\u093E\u0928\u094D\u092F \u092E\u093E\u0928: ${t.origin} \u092E\u093E`;
      default:
        return "\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F";
    }
  };
}, "error");
function Fu() {
  return {
    localeError: Eg()
  };
}
u(Fu, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/nl.js
var Cg = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "tekens", verb: "heeft" },
    file: { unit: "bytes", verb: "heeft" },
    array: { unit: "elementen", verb: "heeft" },
    set: { unit: "elementen", verb: "heeft" },
    map: { unit: "elementen", verb: "heeft" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "invoer",
    email: "emailadres",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datum en tijd",
    date: "ISO datum",
    time: "ISO tijd",
    duration: "ISO duur",
    ipv4: "IPv4-adres",
    ipv6: "IPv6-adres",
    mac: "MAC-adres",
    cidrv4: "IPv4-bereik",
    cidrv6: "IPv6-bereik",
    base64: "base64-gecodeerde tekst",
    base64url: "base64 URL-gecodeerde tekst",
    json_string: "JSON string",
    e164: "E.164-nummer",
    credit_card: "creditcardnummer",
    jwt: "JWT",
    template_literal: "invoer"
  }, o = {
    nan: "NaN",
    number: "getal"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Ongeldige invoer: verwacht instanceof ${t.expected}, ontving ${c}` : `Ongeldige invoer: verwacht ${n}, ontving ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Ongeldige invoer: verwacht ${h(t.values[0])}` : `Ongeldige optie: verwacht \xE9\xE9n van ${p(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin), c = t.origin === "date" ? "laat" : t.origin === "string" ? "lang" : "groot";
        return a ? `Te ${c}: verwacht dat ${t.origin ?? "waarde"} ${n}${t.maximum.toString()} ${a.unit ?? "elementen"} ${a.verb}` : `Te ${c}: verwacht dat ${t.origin ?? "waarde"} ${n}${t.maximum.toString()} is`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin), c = t.origin === "date" ? "vroeg" : t.origin === "string" ? "kort" : "klein";
        return a ? `Te ${c}: verwacht dat ${t.origin} ${n}${t.minimum.toString()} ${a.unit} ${a.verb}` : `Te ${c}: verwacht dat ${t.origin} ${n}${t.minimum.toString()} is`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Ongeldige tekst: moet met "${n.prefix}" beginnen` : n.format === "ends_with" ? `Ongeldige tekst: moet op "${n.suffix}" eindigen` : n.format === "includes" ? `Ongeldige tekst: moet "${n.includes}" bevatten` : n.format === "regex" ? `Ongeldige tekst: moet overeenkomen met patroon ${n.pattern}` : `Ongeldig: ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Ongeldig getal: moet een veelvoud van ${t.divisor} zijn`;
      case "unrecognized_keys":
        return `Onbekende key${t.keys.length > 1 ? "s" : ""}: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `Ongeldige key in ${t.origin}`;
      case "invalid_union":
        return "Ongeldige invoer";
      case "invalid_element":
        return `Ongeldige waarde in ${t.origin}`;
      default:
        return "Ongeldige invoer";
    }
  };
}, "error");
function Ju() {
  return {
    localeError: Cg()
  };
}
u(Ju, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/nn.js
var Lg = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "teikn", verb: "\xE5 ha" },
    file: { unit: "bytes", verb: "\xE5 ha" },
    array: { unit: "element", verb: "\xE5 innehalde" },
    set: { unit: "element", verb: "\xE5 innehalde" },
    map: { unit: "element", verb: "\xE5 innehalde" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "input",
    email: "e-postadresse",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO dato- og klokkeslett",
    date: "ISO-dato",
    time: "ISO-klokkeslett",
    duration: "ISO-varigheit",
    ipv4: "IPv4-adresse",
    ipv6: "IPv6-adresse",
    mac: "MAC-adresse",
    cidrv4: "IPv4-spekter",
    cidrv6: "IPv6-spekter",
    base64: "base64-enkoda streng",
    base64url: "base64url-enkoda streng",
    json_string: "JSON-streng",
    e164: "E.164-nummer",
    credit_card: "kredittkortnummer",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN",
    number: "tal",
    array: "liste"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Ugyldig input: forventa instanceof ${t.expected}, fekk ${c}` : `Ugyldig input: forventa ${n}, fekk ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Ugyldig verdi: forventa ${h(t.values[0])}` : `Ugyldig val: forventa eitt av ${p(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `For stor(t): forventa ${t.origin ?? "value"} til \xE5 ha ${n}${t.maximum.toString()} ${a.unit ?? "element"}` : `For stor(t): forventa ${t.origin ?? "value"} til \xE5 ha ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `For lite(n): forventa ${t.origin} til \xE5 ha ${n}${t.minimum.toString()} ${a.unit}` : `For lite(n): forventa ${t.origin} til \xE5 ha ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Ugyldig streng: m\xE5 starte med "${n.prefix}"` : n.format === "ends_with" ? `Ugyldig streng: m\xE5 slutte med "${n.suffix}"` : n.format === "includes" ? `Ugyldig streng: m\xE5 innehalde "${n.includes}"` : n.format === "regex" ? `Ugyldig streng: m\xE5 matche m\xF8nsteret ${n.pattern}` : `Ugyldig ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Ugyldig tal: m\xE5 vere eit multiplum av ${t.divisor}`;
      case "unrecognized_keys":
        return `${t.keys.length > 1 ? "Ukjende n\xF8klar" : "Ukjend n\xF8kkel"}: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `Ugyldig n\xF8kkel i ${t.origin}`;
      case "invalid_union":
        return "Ugyldig input";
      case "invalid_element":
        return `Ugyldig verdi i ${t.origin}`;
      default:
        return "Ugyldig input";
    }
  };
}, "error");
function Mu() {
  return {
    localeError: Lg()
  };
}
u(Mu, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/no.js
var Vg = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "tegn", verb: "\xE5 ha" },
    file: { unit: "bytes", verb: "\xE5 ha" },
    array: { unit: "elementer", verb: "\xE5 inneholde" },
    set: { unit: "elementer", verb: "\xE5 inneholde" },
    map: { unit: "elementer", verb: "\xE5 inneholde" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "input",
    email: "e-postadresse",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO dato- og klokkeslett",
    date: "ISO-dato",
    time: "ISO-klokkeslett",
    duration: "ISO-varighet",
    ipv4: "IPv4-adresse",
    ipv6: "IPv6-adresse",
    mac: "MAC-adresse",
    cidrv4: "IPv4-spekter",
    cidrv6: "IPv6-spekter",
    base64: "base64-enkodet streng",
    base64url: "base64url-enkodet streng",
    json_string: "JSON-streng",
    e164: "E.164-nummer",
    credit_card: "kredittkortnummer",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN",
    number: "tall",
    array: "liste"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Ugyldig input: forventet instanceof ${t.expected}, fikk ${c}` : `Ugyldig input: forventet ${n}, fikk ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Ugyldig verdi: forventet ${h(t.values[0])}` : `Ugyldig valg: forventet en av ${p(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `For stor(t): forventet ${t.origin ?? "value"} til \xE5 ha ${n}${t.maximum.toString()} ${a.unit ?? "elementer"}` : `For stor(t): forventet ${t.origin ?? "value"} til \xE5 ha ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `For lite(n): forventet ${t.origin} til \xE5 ha ${n}${t.minimum.toString()} ${a.unit}` : `For lite(n): forventet ${t.origin} til \xE5 ha ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Ugyldig streng: m\xE5 starte med "${n.prefix}"` : n.format === "ends_with" ? `Ugyldig streng: m\xE5 ende med "${n.suffix}"` : n.format === "includes" ? `Ugyldig streng: m\xE5 inneholde "${n.includes}"` : n.format === "regex" ? `Ugyldig streng: m\xE5 matche m\xF8nsteret ${n.pattern}` : `Ugyldig ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Ugyldig tall: m\xE5 v\xE6re et multiplum av ${t.divisor}`;
      case "unrecognized_keys":
        return `${t.keys.length > 1 ? "Ukjente n\xF8kler" : "Ukjent n\xF8kkel"}: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `Ugyldig n\xF8kkel i ${t.origin}`;
      case "invalid_union":
        return "Ugyldig input";
      case "invalid_element":
        return `Ugyldig verdi i ${t.origin}`;
      default:
        return "Ugyldig input";
    }
  };
}, "error");
function Ku() {
  return {
    localeError: Vg()
  };
}
u(Ku, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ota.js
var Rg = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "harf", verb: "olmal\u0131d\u0131r" },
    file: { unit: "bayt", verb: "olmal\u0131d\u0131r" },
    array: { unit: "unsur", verb: "olmal\u0131d\u0131r" },
    set: { unit: "unsur", verb: "olmal\u0131d\u0131r" },
    map: { unit: "unsur", verb: "olmal\u0131d\u0131r" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "giren",
    email: "epostag\xE2h",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO heng\xE2m\u0131",
    date: "ISO tarihi",
    time: "ISO zaman\u0131",
    duration: "ISO m\xFCddeti",
    ipv4: "IPv4 ni\u015F\xE2n\u0131",
    ipv6: "IPv6 ni\u015F\xE2n\u0131",
    mac: "MAC ni\u015F\xE2n\u0131",
    cidrv4: "IPv4 menzili",
    cidrv6: "IPv6 menzili",
    base64: "base64-\u015Fifreli metin",
    base64url: "base64url-\u015Fifreli metin",
    json_string: "JSON metin",
    e164: "E.164 say\u0131s\u0131",
    credit_card: "i'tib\xE2r kart\u0131 numaras\u0131",
    jwt: "JWT",
    template_literal: "giren"
  }, o = {
    nan: "NaN",
    number: "numara",
    array: "saf",
    null: "gayb"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `F\xE2sit giren: umulan instanceof ${t.expected}, al\u0131nan ${c}` : `F\xE2sit giren: umulan ${n}, al\u0131nan ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `F\xE2sit giren: umulan ${h(t.values[0])}` : `F\xE2sit tercih: m\xFBteberler ${p(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Fazla b\xFCy\xFCk: ${t.origin ?? "value"}, ${n}${t.maximum.toString()} ${a.unit ?? "elements"} sahip olmal\u0131yd\u0131.` : `Fazla b\xFCy\xFCk: ${t.origin ?? "value"}, ${n}${t.maximum.toString()} olmal\u0131yd\u0131.`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Fazla k\xFC\xE7\xFCk: ${t.origin}, ${n}${t.minimum.toString()} ${a.unit} sahip olmal\u0131yd\u0131.` : `Fazla k\xFC\xE7\xFCk: ${t.origin}, ${n}${t.minimum.toString()} olmal\u0131yd\u0131.`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `F\xE2sit metin: "${n.prefix}" ile ba\u015Flamal\u0131.` : n.format === "ends_with" ? `F\xE2sit metin: "${n.suffix}" ile bitmeli.` : n.format === "includes" ? `F\xE2sit metin: "${n.includes}" ihtiv\xE2 etmeli.` : n.format === "regex" ? `F\xE2sit metin: ${n.pattern} nak\u015F\u0131na uymal\u0131.` : `F\xE2sit ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `F\xE2sit say\u0131: ${t.divisor} kat\u0131 olmal\u0131yd\u0131.`;
      case "unrecognized_keys":
        return `Tan\u0131nmayan anahtar ${t.keys.length > 1 ? "s" : ""}: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `${t.origin} i\xE7in tan\u0131nmayan anahtar var.`;
      case "invalid_union":
        return "Giren tan\u0131namad\u0131.";
      case "invalid_element":
        return `${t.origin} i\xE7in tan\u0131nmayan k\u0131ymet var.`;
      default:
        return "K\u0131ymet tan\u0131namad\u0131.";
    }
  };
}, "error");
function Wu() {
  return {
    localeError: Rg()
  };
}
u(Wu, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ps.js
var Fg = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "\u062A\u0648\u06A9\u064A", verb: "\u0648\u0644\u0631\u064A" },
    file: { unit: "\u0628\u0627\u06CC\u067C\u0633", verb: "\u0648\u0644\u0631\u064A" },
    array: { unit: "\u062A\u0648\u06A9\u064A", verb: "\u0648\u0644\u0631\u064A" },
    set: { unit: "\u062A\u0648\u06A9\u064A", verb: "\u0648\u0644\u0631\u064A" },
    map: { unit: "\u062A\u0648\u06A9\u064A", verb: "\u0648\u0644\u0631\u064A" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "\u0648\u0631\u0648\u062F\u064A",
    email: "\u0628\u0631\u06CC\u069A\u0646\u0627\u0644\u06CC\u06A9",
    url: "\u06CC\u0648 \u0622\u0631 \u0627\u0644",
    emoji: "\u0627\u06CC\u0645\u0648\u062C\u064A",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u0646\u06CC\u067C\u0647 \u0627\u0648 \u0648\u062E\u062A",
    date: "\u0646\u06D0\u067C\u0647",
    time: "\u0648\u062E\u062A",
    duration: "\u0645\u0648\u062F\u0647",
    ipv4: "\u062F IPv4 \u067E\u062A\u0647",
    ipv6: "\u062F IPv6 \u067E\u062A\u0647",
    mac: "\u062F MAC \u067E\u062A\u0647",
    cidrv4: "\u062F IPv4 \u0633\u0627\u062D\u0647",
    cidrv6: "\u062F IPv6 \u0633\u0627\u062D\u0647",
    base64: "base64-encoded \u0645\u062A\u0646",
    base64url: "base64url-encoded \u0645\u062A\u0646",
    json_string: "JSON \u0645\u062A\u0646",
    e164: "\u062F E.164 \u0634\u0645\u06D0\u0631\u0647",
    credit_card: "\u062F \u06A9\u0631\u06CC\u0689\u06CC\u067C \u06A9\u0627\u0631\u062A \u0634\u0645\u06CC\u0631\u0647",
    jwt: "JWT",
    template_literal: "\u0648\u0631\u0648\u062F\u064A"
  }, o = {
    nan: "NaN",
    number: "\u0639\u062F\u062F",
    array: "\u0627\u0631\u06D0"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u0646\u0627\u0633\u0645 \u0648\u0631\u0648\u062F\u064A: \u0628\u0627\u06CC\u062F instanceof ${t.expected} \u0648\u0627\u06CC, \u0645\u06AB\u0631 ${c} \u062A\u0631\u0644\u0627\u0633\u0647 \u0634\u0648` : `\u0646\u0627\u0633\u0645 \u0648\u0631\u0648\u062F\u064A: \u0628\u0627\u06CC\u062F ${n} \u0648\u0627\u06CC, \u0645\u06AB\u0631 ${c} \u062A\u0631\u0644\u0627\u0633\u0647 \u0634\u0648`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u0646\u0627\u0633\u0645 \u0648\u0631\u0648\u062F\u064A: \u0628\u0627\u06CC\u062F ${h(t.values[0])} \u0648\u0627\u06CC` : `\u0646\u0627\u0633\u0645 \u0627\u0646\u062A\u062E\u0627\u0628: \u0628\u0627\u06CC\u062F \u06CC\u0648 \u0644\u0647 ${p(t.values, "|")} \u0685\u062E\u0647 \u0648\u0627\u06CC`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u0689\u06CC\u0631 \u0644\u0648\u06CC: ${t.origin ?? "\u0627\u0631\u0632\u069A\u062A"} \u0628\u0627\u06CC\u062F ${n}${t.maximum.toString()} ${a.unit ?? "\u0639\u0646\u0635\u0631\u0648\u0646\u0647"} \u0648\u0644\u0631\u064A` : `\u0689\u06CC\u0631 \u0644\u0648\u06CC: ${t.origin ?? "\u0627\u0631\u0632\u069A\u062A"} \u0628\u0627\u06CC\u062F ${n}${t.maximum.toString()} \u0648\u064A`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u0689\u06CC\u0631 \u06A9\u0648\u0686\u0646\u06CC: ${t.origin} \u0628\u0627\u06CC\u062F ${n}${t.minimum.toString()} ${a.unit} \u0648\u0644\u0631\u064A` : `\u0689\u06CC\u0631 \u06A9\u0648\u0686\u0646\u06CC: ${t.origin} \u0628\u0627\u06CC\u062F ${n}${t.minimum.toString()} \u0648\u064A`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u0646\u0627\u0633\u0645 \u0645\u062A\u0646: \u0628\u0627\u06CC\u062F \u062F "${n.prefix}" \u0633\u0631\u0647 \u067E\u06CC\u0644 \u0634\u064A` : n.format === "ends_with" ? `\u0646\u0627\u0633\u0645 \u0645\u062A\u0646: \u0628\u0627\u06CC\u062F \u062F "${n.suffix}" \u0633\u0631\u0647 \u067E\u0627\u06CC \u062A\u0647 \u0648\u0631\u0633\u064A\u0696\u064A` : n.format === "includes" ? `\u0646\u0627\u0633\u0645 \u0645\u062A\u0646: \u0628\u0627\u06CC\u062F "${n.includes}" \u0648\u0644\u0631\u064A` : n.format === "regex" ? `\u0646\u0627\u0633\u0645 \u0645\u062A\u0646: \u0628\u0627\u06CC\u062F \u062F ${n.pattern} \u0633\u0631\u0647 \u0645\u0637\u0627\u0628\u0642\u062A \u0648\u0644\u0631\u064A` : `${i[n.format] ?? t.format} \u0646\u0627\u0633\u0645 \u062F\u06CC`;
      }
      case "not_multiple_of":
        return `\u0646\u0627\u0633\u0645 \u0639\u062F\u062F: \u0628\u0627\u06CC\u062F \u062F ${t.divisor} \u0645\u0636\u0631\u0628 \u0648\u064A`;
      case "unrecognized_keys":
        return `\u0646\u0627\u0633\u0645 ${t.keys.length > 1 ? "\u06A9\u0644\u06CC\u0689\u0648\u0646\u0647" : "\u06A9\u0644\u06CC\u0689"}: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `\u0646\u0627\u0633\u0645 \u06A9\u0644\u06CC\u0689 \u067E\u0647 ${t.origin} \u06A9\u06D0`;
      case "invalid_union":
        return "\u0646\u0627\u0633\u0645\u0647 \u0648\u0631\u0648\u062F\u064A";
      case "invalid_element":
        return `\u0646\u0627\u0633\u0645 \u0639\u0646\u0635\u0631 \u067E\u0647 ${t.origin} \u06A9\u06D0`;
      default:
        return "\u0646\u0627\u0633\u0645\u0647 \u0648\u0631\u0648\u062F\u064A";
    }
  };
}, "error");
function Gu() {
  return {
    localeError: Fg()
  };
}
u(Gu, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/pl.js
var Jg = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "znak\xF3w", verb: "mie\u0107" },
    file: { unit: "bajt\xF3w", verb: "mie\u0107" },
    array: { unit: "element\xF3w", verb: "mie\u0107" },
    set: { unit: "element\xF3w", verb: "mie\u0107" },
    map: { unit: "element\xF3w", verb: "mie\u0107" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "wyra\u017Cenie",
    email: "adres email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "data i godzina w formacie ISO",
    date: "data w formacie ISO",
    time: "godzina w formacie ISO",
    duration: "czas trwania ISO",
    ipv4: "adres IPv4",
    ipv6: "adres IPv6",
    mac: "adres MAC",
    cidrv4: "zakres IPv4",
    cidrv6: "zakres IPv6",
    base64: "ci\u0105g znak\xF3w zakodowany w formacie base64",
    base64url: "ci\u0105g znak\xF3w zakodowany w formacie base64url",
    json_string: "ci\u0105g znak\xF3w w formacie JSON",
    e164: "liczba E.164",
    credit_card: "numer karty kredytowej",
    jwt: "JWT",
    template_literal: "wej\u015Bcie"
  }, o = {
    nan: "NaN",
    number: "liczba",
    array: "tablica"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Nieprawid\u0142owe dane wej\u015Bciowe: oczekiwano instanceof ${t.expected}, otrzymano ${c}` : `Nieprawid\u0142owe dane wej\u015Bciowe: oczekiwano ${n}, otrzymano ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Nieprawid\u0142owe dane wej\u015Bciowe: oczekiwano ${h(t.values[0])}` : `Nieprawid\u0142owa opcja: oczekiwano jednej z warto\u015Bci ${p(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Za du\u017Ca warto\u015B\u0107: oczekiwano, \u017Ce ${t.origin ?? "warto\u015B\u0107"} b\u0119dzie mie\u0107 ${n}${t.maximum.toString()} ${a.unit ?? "element\xF3w"}` : `Zbyt du\u017C(y/a/e): oczekiwano, \u017Ce ${t.origin ?? "warto\u015B\u0107"} b\u0119dzie wynosi\u0107 ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Za ma\u0142a warto\u015B\u0107: oczekiwano, \u017Ce ${t.origin ?? "warto\u015B\u0107"} b\u0119dzie mie\u0107 ${n}${t.minimum.toString()} ${a.unit ?? "element\xF3w"}` : `Zbyt ma\u0142(y/a/e): oczekiwano, \u017Ce ${t.origin ?? "warto\u015B\u0107"} b\u0119dzie wynosi\u0107 ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Nieprawid\u0142owy ci\u0105g znak\xF3w: musi zaczyna\u0107 si\u0119 od "${n.prefix}"` : n.format === "ends_with" ? `Nieprawid\u0142owy ci\u0105g znak\xF3w: musi ko\u0144czy\u0107 si\u0119 na "${n.suffix}"` : n.format === "includes" ? `Nieprawid\u0142owy ci\u0105g znak\xF3w: musi zawiera\u0107 "${n.includes}"` : n.format === "regex" ? `Nieprawid\u0142owy ci\u0105g znak\xF3w: musi odpowiada\u0107 wzorcowi ${n.pattern}` : `Nieprawid\u0142ow(y/a/e) ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Nieprawid\u0142owa liczba: musi by\u0107 wielokrotno\u015Bci\u0105 ${t.divisor}`;
      case "unrecognized_keys":
        return `Nierozpoznane klucze${t.keys.length > 1 ? "s" : ""}: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `Nieprawid\u0142owy klucz w ${t.origin}`;
      case "invalid_union":
        return "Nieprawid\u0142owe dane wej\u015Bciowe";
      case "invalid_element":
        return `Nieprawid\u0142owa warto\u015B\u0107 w ${t.origin}`;
      default:
        return "Nieprawid\u0142owe dane wej\u015Bciowe";
    }
  };
}, "error");
function Bu() {
  return {
    localeError: Jg()
  };
}
u(Bu, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/pt.js
var Mg = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "caracteres" },
    file: { unit: "bytes" },
    array: { unit: "elementos" },
    set: { unit: "elementos" },
    map: { unit: "entradas" }
  };
  function r(a) {
    return e[a] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "a entrada",
    email: "o endere\xE7o de e-mail",
    url: "o URL",
    emoji: "o emoji",
    uuid: "o UUID",
    uuidv4: "o UUIDv4",
    uuidv6: "o UUIDv6",
    nanoid: "o nanoid",
    guid: "o GUID",
    cuid: "o cuid",
    cuid2: "o cuid2",
    ulid: "o ULID",
    xid: "o XID",
    ksuid: "o KSUID",
    datetime: "a data e hora ISO",
    date: "a data ISO",
    time: "a hora ISO",
    duration: "a dura\xE7\xE3o ISO",
    ipv4: "o endere\xE7o IPv4",
    ipv6: "o endere\xE7o IPv6",
    mac: "o endere\xE7o MAC",
    cidrv4: "o intervalo de endere\xE7os IPv4",
    cidrv6: "o intervalo de endere\xE7os IPv6",
    base64: "o texto codificado em base64",
    base64url: "o texto codificado em base64url",
    json_string: "o texto JSON",
    e164: "o n\xFAmero E.164",
    credit_card: "o n\xFAmero de cart\xE3o de cr\xE9dito",
    jwt: "o JWT",
    template_literal: "a entrada"
  }, o = {
    masculine: { definite: "o", indefinite: "um" },
    feminine: { definite: "a", indefinite: "uma" }
  }, t = {
    string: { name: "texto", articles: o.masculine },
    number: { name: "n\xFAmero", articles: o.masculine },
    int: { name: "n\xFAmero inteiro", articles: o.masculine },
    boolean: { name: "valor booleano", articles: o.masculine },
    bigint: { name: "n\xFAmero bigint", articles: o.masculine },
    symbol: { name: "s\xEDmbolo", articles: o.masculine },
    undefined: { name: 'valor "undefined"', articles: o.masculine },
    null: { name: 'valor "nulo"', articles: o.masculine },
    never: { name: 'valor "never"', articles: o.masculine },
    void: { name: 'valor "void"', articles: o.masculine },
    date: { name: "data", articles: o.feminine },
    array: { name: "vetor", articles: o.masculine },
    object: { name: "objeto", articles: o.masculine },
    tuple: { name: "tuplo", articles: o.masculine },
    record: { name: "registo", articles: o.masculine },
    map: { name: "mapa", articles: o.masculine },
    set: { name: "conjunto", articles: o.masculine },
    file: { name: "ficheiro", articles: o.masculine },
    nonoptional: { name: "valor n\xE3o opcional", articles: o.masculine },
    nan: { name: 'valor "NaN"', articles: o.masculine },
    // Compatibility: "nan" -> "NaN" for display
    function: { name: "fun\xE7\xE3o", articles: o.feminine }
  };
  function n(a, c) {
    let s = t[a] ?? { name: `valor "${a}"`, articles: o.masculine };
    return `${s.articles[c]} ${s.name}`;
  }
  return u(n, "translateOriginWithArticle"), (a) => {
    switch (a.code) {
      case "invalid_type": {
        let c = n(a.expected, "indefinite"), s = _(a.input), l = n(s, "indefinite");
        return `Entrada inv\xE1lida: esperava ${c}, recebeu ${l}`;
      }
      case "invalid_value":
        return a.values.length === 1 ? `Entrada inv\xE1lida: esperava ${h(a.values[0])}` : `Op\xE7\xE3o inv\xE1lida: esperava uma das seguintes op\xE7\xF5es: ${p(a.values, "|")}`;
      case "too_big": {
        let c = a.inclusive ? "<=" : "<", s = r(a.origin);
        return s ? `Demasiado grande: esperava que ${n(a.origin, "definite")} tivesse ${c} ${a.maximum.toString()} ${s.unit ?? "elementos"}` : `Demasiado grande: esperava que ${n(a.origin, "definite")} fosse ${c} ${a.maximum.toString()}`;
      }
      case "too_small": {
        let c = a.inclusive ? ">=" : ">", s = r(a.origin);
        return s ? `Demasiado pequeno: esperava que ${n(a.origin, "definite")} tivesse ${c} ${a.minimum.toString()} ${s.unit ?? "elementos"}` : `Demasiado pequeno: esperava que ${n(a.origin, "definite")} fosse ${c} ${a.minimum.toString()}`;
      }
      case "invalid_format": {
        let c = a;
        return c.format === "starts_with" ? `Texto inv\xE1lido: deve come\xE7ar por "${c.prefix}"` : c.format === "ends_with" ? `Texto inv\xE1lido: deve terminar em "${c.suffix}"` : c.format === "includes" ? `Texto inv\xE1lido: deve incluir "${c.includes}"` : c.format === "regex" ? `Texto inv\xE1lido: deve corresponder ao padr\xE3o ${c.pattern}` : `Formato d${i[c.format] ?? a.format} inv\xE1lido`;
      }
      case "not_multiple_of":
        return `N\xFAmero inv\xE1lido: deve ser m\xFAltiplo de ${a.divisor}`;
      case "unrecognized_keys": {
        let c = a.keys.length > 1 ? "s" : "";
        return `Chave${c} inv\xE1lida${c}: ${p(a.keys, ", ")}`;
      }
      case "invalid_key":
        return `Entrada inv\xE1lida n${n(a.origin, "definite")}`;
      case "invalid_union":
        return a.options && Array.isArray(a.options) && a.options.length > 0 ? `Valor de discrimina\xE7\xE3o inv\xE1lido. Esperava ${a.options.map((s) => `'${s}'`).join(" | ")}` : "Entrada inv\xE1lida";
      case "invalid_element":
        return `Entrada inv\xE1lida n${n(a.origin, "definite")}`;
      default:
        return "Entrada inv\xE1lida";
    }
  };
}, "error");
function qu() {
  return {
    localeError: Mg()
  };
}
u(qu, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/pt-BR.js
var Kg = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "caracteres" },
    file: { unit: "bytes" },
    array: { unit: "elementos" },
    set: { unit: "elementos" },
    map: { unit: "entradas" }
  };
  function r(a) {
    return e[a] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "a entrada",
    email: "o endere\xE7o de e-mail",
    url: "o URL",
    emoji: "o emoji",
    uuid: "o UUID",
    uuidv4: "o UUIDv4",
    uuidv6: "o UUIDv6",
    nanoid: "o nanoid",
    guid: "o GUID",
    cuid: "o cuid",
    cuid2: "o cuid2",
    ulid: "o ULID",
    xid: "o XID",
    ksuid: "o KSUID",
    datetime: "a data e hora ISO",
    date: "a data ISO",
    time: "a hora ISO",
    duration: "a dura\xE7\xE3o ISO",
    ipv4: "o endere\xE7o IPv4",
    ipv6: "o endere\xE7o IPv6",
    mac: "o endere\xE7o MAC",
    cidrv4: "a faixa de endere\xE7os IPv4",
    cidrv6: "a faixa de endere\xE7os IPv6",
    base64: "o texto codificado em base64",
    base64url: "o texto codificado em base64url",
    json_string: "o texto JSON",
    e164: "o n\xFAmero E.164",
    credit_card: "o n\xFAmero de cart\xE3o de cr\xE9dito",
    jwt: "o JWT",
    template_literal: "a entrada"
  }, o = {
    masculine: { definite: "o", indefinite: "um" },
    feminine: { definite: "a", indefinite: "uma" }
  }, t = {
    string: { name: "texto", articles: o.masculine },
    number: { name: "n\xFAmero", articles: o.masculine },
    int: { name: "n\xFAmero inteiro", articles: o.masculine },
    boolean: { name: "valor booleano", articles: o.masculine },
    bigint: { name: "n\xFAmero bigint", articles: o.masculine },
    symbol: { name: "s\xEDmbolo", articles: o.masculine },
    undefined: { name: 'valor "undefined"', articles: o.masculine },
    null: { name: 'valor "nulo"', articles: o.masculine },
    never: { name: 'valor "never"', articles: o.masculine },
    void: { name: 'valor "void"', articles: o.masculine },
    date: { name: "data", articles: o.feminine },
    array: { name: "vetor", articles: o.masculine },
    object: { name: "objeto", articles: o.masculine },
    tuple: { name: "tupla", articles: o.feminine },
    record: { name: "registro", articles: o.masculine },
    map: { name: "mapa", articles: o.masculine },
    set: { name: "conjunto", articles: o.masculine },
    file: { name: "arquivo", articles: o.masculine },
    nonoptional: { name: "valor n\xE3o opcional", articles: o.masculine },
    nan: { name: 'valor "NaN"', articles: o.masculine },
    // Compatibility: "nan" -> "NaN" for display
    function: { name: "fun\xE7\xE3o", articles: o.feminine }
  };
  function n(a, c) {
    let s = t[a] ?? { name: `valor "${a}"`, articles: o.masculine };
    return `${s.articles[c]} ${s.name}`;
  }
  return u(n, "translateOriginWithArticle"), (a) => {
    switch (a.code) {
      case "invalid_type": {
        let c = n(a.expected, "indefinite"), s = _(a.input), l = n(s, "indefinite");
        return `Entrada inv\xE1lida: esperava ${c}, recebeu ${l}`;
      }
      case "invalid_value":
        return a.values.length === 1 ? `Entrada inv\xE1lida: esperava ${h(a.values[0])}` : `Op\xE7\xE3o inv\xE1lida: esperava uma das seguintes op\xE7\xF5es: ${p(a.values, "|")}`;
      case "too_big": {
        let c = a.inclusive ? "<=" : "<", s = r(a.origin);
        return s ? `Grande demais: esperava que ${n(a.origin, "definite")} tivesse ${c} ${a.maximum.toString()} ${s.unit ?? "elementos"}` : `Grande demais: esperava que ${n(a.origin, "definite")} fosse ${c} ${a.maximum.toString()}`;
      }
      case "too_small": {
        let c = a.inclusive ? ">=" : ">", s = r(a.origin);
        return s ? `Pequeno demais: esperava que ${n(a.origin, "definite")} tivesse ${c} ${a.minimum.toString()} ${s.unit ?? "elementos"}` : `Pequeno demais: esperava que ${n(a.origin, "definite")} fosse ${c} ${a.minimum.toString()}`;
      }
      case "invalid_format": {
        let c = a;
        return c.format === "starts_with" ? `Texto inv\xE1lido: deve come\xE7ar com "${c.prefix}"` : c.format === "ends_with" ? `Texto inv\xE1lido: deve terminar com "${c.suffix}"` : c.format === "includes" ? `Texto inv\xE1lido: deve incluir "${c.includes}"` : c.format === "regex" ? `Texto inv\xE1lido: deve corresponder ao padr\xE3o ${c.pattern}` : `Formato d${i[c.format] ?? a.format} inv\xE1lido`;
      }
      case "not_multiple_of":
        return `N\xFAmero inv\xE1lido: deve ser m\xFAltiplo de ${a.divisor}`;
      case "unrecognized_keys": {
        let c = a.keys.length > 1 ? "s" : "";
        return `Chave${c} inv\xE1lida${c}: ${p(a.keys, ", ")}`;
      }
      case "invalid_key":
        return `Entrada inv\xE1lida n${n(a.origin, "definite")}`;
      case "invalid_union":
        return a.options && Array.isArray(a.options) && a.options.length > 0 ? `Valor de discrimina\xE7\xE3o inv\xE1lido. Esperava ${a.options.map((s) => `'${s}'`).join(" | ")}` : "Entrada inv\xE1lida";
      case "invalid_element":
        return `Entrada inv\xE1lida n${n(a.origin, "definite")}`;
      default:
        return "Entrada inv\xE1lida";
    }
  };
}, "error");
function Xu() {
  return {
    localeError: Kg()
  };
}
u(Xu, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ro.js
var Wg = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "caractere", verb: "s\u0103 aib\u0103" },
    file: { unit: "octe\u021Bi", verb: "s\u0103 aib\u0103" },
    array: { unit: "elemente", verb: "s\u0103 aib\u0103" },
    set: { unit: "elemente", verb: "s\u0103 aib\u0103" },
    map: { unit: "intr\u0103ri", verb: "s\u0103 aib\u0103" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "intrare",
    email: "adres\u0103 de email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "dat\u0103 \u0219i or\u0103 ISO",
    date: "dat\u0103 ISO",
    time: "or\u0103 ISO",
    duration: "durat\u0103 ISO",
    ipv4: "adres\u0103 IPv4",
    ipv6: "adres\u0103 IPv6",
    mac: "adres\u0103 MAC",
    cidrv4: "interval IPv4",
    cidrv6: "interval IPv6",
    base64: "\u0219ir codat base64",
    base64url: "\u0219ir codat base64url",
    json_string: "\u0219ir JSON",
    e164: "num\u0103r E.164",
    credit_card: "num\u0103r de card de credit",
    jwt: "JWT",
    template_literal: "intrare"
  }, o = {
    nan: "NaN",
    string: "\u0219ir",
    number: "num\u0103r",
    boolean: "boolean",
    function: "func\u021Bie",
    array: "matrice",
    object: "obiect",
    undefined: "nedefinit",
    symbol: "simbol",
    bigint: "num\u0103r mare",
    void: "void",
    never: "never",
    map: "hart\u0103",
    set: "set"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return `Intrare invalid\u0103: a\u0219teptat ${n}, primit ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Intrare invalid\u0103: a\u0219teptat ${h(t.values[0])}` : `Op\u021Biune invalid\u0103: a\u0219teptat una dintre ${p(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Prea mare: a\u0219teptat ca ${t.origin ?? "valoarea"} ${a.verb} ${n}${t.maximum.toString()} ${a.unit ?? "elemente"}` : `Prea mare: a\u0219teptat ca ${t.origin ?? "valoarea"} s\u0103 fie ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Prea mic: a\u0219teptat ca ${t.origin} ${a.verb} ${n}${t.minimum.toString()} ${a.unit}` : `Prea mic: a\u0219teptat ca ${t.origin} s\u0103 fie ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u0218ir invalid: trebuie s\u0103 \xEEnceap\u0103 cu "${n.prefix}"` : n.format === "ends_with" ? `\u0218ir invalid: trebuie s\u0103 se termine cu "${n.suffix}"` : n.format === "includes" ? `\u0218ir invalid: trebuie s\u0103 includ\u0103 "${n.includes}"` : n.format === "regex" ? `\u0218ir invalid: trebuie s\u0103 se potriveasc\u0103 cu modelul ${n.pattern}` : `Format invalid: ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Num\u0103r invalid: trebuie s\u0103 fie multiplu de ${t.divisor}`;
      case "unrecognized_keys":
        return `Chei nerecunoscute: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `Cheie invalid\u0103 \xEEn ${t.origin}`;
      case "invalid_union":
        return "Intrare invalid\u0103";
      case "invalid_element":
        return `Valoare invalid\u0103 \xEEn ${t.origin}`;
      default:
        return "Intrare invalid\u0103";
    }
  };
}, "error");
function Yu() {
  return {
    localeError: Wg()
  };
}
u(Yu, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ru.js
function Ad(e, r, i, o) {
  let t = Math.abs(e), n = t % 10, a = t % 100;
  return a >= 11 && a <= 19 ? o : n === 1 ? r : n >= 2 && n <= 4 ? i : o;
}
u(Ad, "getRussianPlural");
var Gg = /* @__PURE__ */ u(() => {
  let e = {
    string: {
      unit: {
        one: "\u0441\u0438\u043C\u0432\u043E\u043B",
        few: "\u0441\u0438\u043C\u0432\u043E\u043B\u0430",
        many: "\u0441\u0438\u043C\u0432\u043E\u043B\u043E\u0432"
      },
      verb: "\u0438\u043C\u0435\u0442\u044C"
    },
    file: {
      unit: {
        one: "\u0431\u0430\u0439\u0442",
        few: "\u0431\u0430\u0439\u0442\u0430",
        many: "\u0431\u0430\u0439\u0442"
      },
      verb: "\u0438\u043C\u0435\u0442\u044C"
    },
    array: {
      unit: {
        one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
        few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430",
        many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u043E\u0432"
      },
      verb: "\u0438\u043C\u0435\u0442\u044C"
    },
    set: {
      unit: {
        one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
        few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430",
        many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u043E\u0432"
      },
      verb: "\u0438\u043C\u0435\u0442\u044C"
    },
    map: {
      unit: {
        one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
        few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430",
        many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u043E\u0432"
      },
      verb: "\u0438\u043C\u0435\u0442\u044C"
    }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "\u0432\u0432\u043E\u0434",
    email: "email \u0430\u0434\u0440\u0435\u0441",
    url: "URL",
    emoji: "\u044D\u043C\u043E\u0434\u0437\u0438",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0434\u0430\u0442\u0430 \u0438 \u0432\u0440\u0435\u043C\u044F",
    date: "ISO \u0434\u0430\u0442\u0430",
    time: "ISO \u0432\u0440\u0435\u043C\u044F",
    duration: "ISO \u0434\u043B\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C",
    ipv4: "IPv4 \u0430\u0434\u0440\u0435\u0441",
    ipv6: "IPv6 \u0430\u0434\u0440\u0435\u0441",
    mac: "MAC \u0430\u0434\u0440\u0435\u0441",
    cidrv4: "IPv4 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D",
    cidrv6: "IPv6 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D",
    base64: "\u0441\u0442\u0440\u043E\u043A\u0430 \u0432 \u0444\u043E\u0440\u043C\u0430\u0442\u0435 base64",
    base64url: "\u0441\u0442\u0440\u043E\u043A\u0430 \u0432 \u0444\u043E\u0440\u043C\u0430\u0442\u0435 base64url",
    json_string: "JSON \u0441\u0442\u0440\u043E\u043A\u0430",
    e164: "\u043D\u043E\u043C\u0435\u0440 E.164",
    credit_card: "\u043D\u043E\u043C\u0435\u0440 \u043A\u0440\u0435\u0434\u0438\u0442\u043D\u043E\u0439 \u043A\u0430\u0440\u0442\u044B",
    jwt: "JWT",
    template_literal: "\u0432\u0432\u043E\u0434"
  }, o = {
    nan: "NaN",
    number: "\u0447\u0438\u0441\u043B\u043E",
    array: "\u043C\u0430\u0441\u0441\u0438\u0432"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0432\u0432\u043E\u0434: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C instanceof ${t.expected}, \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u043E ${c}` : `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0432\u0432\u043E\u0434: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C ${n}, \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u043E ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0432\u0432\u043E\u0434: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C ${h(t.values[0])}` : `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0432\u0430\u0440\u0438\u0430\u043D\u0442: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C \u043E\u0434\u043D\u043E \u0438\u0437 ${p(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        if (a) {
          let c = Number(t.maximum), s = Ad(c, a.unit.one, a.unit.few, a.unit.many);
          return `\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C, \u0447\u0442\u043E ${t.origin ?? "\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435"} \u0431\u0443\u0434\u0435\u0442 \u0438\u043C\u0435\u0442\u044C ${n}${t.maximum.toString()} ${s}`;
        }
        return `\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C, \u0447\u0442\u043E ${t.origin ?? "\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435"} \u0431\u0443\u0434\u0435\u0442 ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        if (a) {
          let c = Number(t.minimum), s = Ad(c, a.unit.one, a.unit.few, a.unit.many);
          return `\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u043C\u0430\u043B\u0435\u043D\u044C\u043A\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C, \u0447\u0442\u043E ${t.origin} \u0431\u0443\u0434\u0435\u0442 \u0438\u043C\u0435\u0442\u044C ${n}${t.minimum.toString()} ${s}`;
        }
        return `\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u043C\u0430\u043B\u0435\u043D\u044C\u043A\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C, \u0447\u0442\u043E ${t.origin} \u0431\u0443\u0434\u0435\u0442 ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u0441\u0442\u0440\u043E\u043A\u0430: \u0434\u043E\u043B\u0436\u043D\u0430 \u043D\u0430\u0447\u0438\u043D\u0430\u0442\u044C\u0441\u044F \u0441 "${n.prefix}"` : n.format === "ends_with" ? `\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u0441\u0442\u0440\u043E\u043A\u0430: \u0434\u043E\u043B\u0436\u043D\u0430 \u0437\u0430\u043A\u0430\u043D\u0447\u0438\u0432\u0430\u0442\u044C\u0441\u044F \u043D\u0430 "${n.suffix}"` : n.format === "includes" ? `\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u0441\u0442\u0440\u043E\u043A\u0430: \u0434\u043E\u043B\u0436\u043D\u0430 \u0441\u043E\u0434\u0435\u0440\u0436\u0430\u0442\u044C "${n.includes}"` : n.format === "regex" ? `\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u0441\u0442\u0440\u043E\u043A\u0430: \u0434\u043E\u043B\u0436\u043D\u0430 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u043E\u0432\u0430\u0442\u044C \u0448\u0430\u0431\u043B\u043E\u043D\u0443 ${n.pattern}` : `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u041D\u0435\u0432\u0435\u0440\u043D\u043E\u0435 \u0447\u0438\u0441\u043B\u043E: \u0434\u043E\u043B\u0436\u043D\u043E \u0431\u044B\u0442\u044C \u043A\u0440\u0430\u0442\u043D\u044B\u043C ${t.divisor}`;
      case "unrecognized_keys":
        return `\u041D\u0435\u0440\u0430\u0441\u043F\u043E\u0437\u043D\u0430\u043D\u043D${t.keys.length > 1 ? "\u044B\u0435" : "\u044B\u0439"} \u043A\u043B\u044E\u0447${t.keys.length > 1 ? "\u0438" : ""}: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u043A\u043B\u044E\u0447 \u0432 ${t.origin}`;
      case "invalid_union":
        return "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0435 \u0432\u0445\u043E\u0434\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435";
      case "invalid_element":
        return `\u041D\u0435\u0432\u0435\u0440\u043D\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u0432 ${t.origin}`;
      default:
        return "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0435 \u0432\u0445\u043E\u0434\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435";
    }
  };
}, "error");
function Hu() {
  return {
    localeError: Gg()
  };
}
u(Hu, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/sk.js
var Bg = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "znakov", verb: "ma\u0165" },
    file: { unit: "bajtov", verb: "ma\u0165" },
    array: { unit: "prvkov", verb: "ma\u0165" },
    set: { unit: "prvkov", verb: "ma\u0165" },
    map: { unit: "polo\u017Eiek", verb: "ma\u0165" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "regul\xE1rny v\xFDraz",
    email: "e-mailov\xE1 adresa",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "d\xE1tum a \u010Das vo form\xE1te ISO",
    date: "d\xE1tum vo form\xE1te ISO",
    time: "\u010Das vo form\xE1te ISO",
    duration: "doba trvania ISO",
    ipv4: "IPv4 adresa",
    ipv6: "IPv6 adresa",
    mac: "MAC adresa",
    cidrv4: "rozsah IPv4",
    cidrv6: "rozsah IPv6",
    base64: "re\u0165azec zak\xF3dovan\xFD vo form\xE1te base64",
    base64url: "re\u0165azec zak\xF3dovan\xFD vo form\xE1te base64url",
    json_string: "re\u0165azec vo form\xE1te JSON",
    e164: "\u010D\xEDslo E.164",
    credit_card: "\u010D\xEDslo kreditnej karty",
    jwt: "JWT",
    template_literal: "vstup"
  }, o = {
    nan: "NaN",
    number: "\u010D\xEDslo",
    string: "re\u0165azec",
    function: "funkcia",
    array: "pole"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Neplatn\xFD vstup: o\u010Dak\xE1van\xE9 instanceof ${t.expected}, obdr\u017Ean\xE9 ${c}` : `Neplatn\xFD vstup: o\u010Dak\xE1van\xE9 ${n}, obdr\u017Ean\xE9 ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Neplatn\xFD vstup: o\u010Dak\xE1van\xE9 ${h(t.values[0])}` : `Neplatn\xFD vstup: o\u010Dak\xE1van\xE1 jedna z hodn\xF4t ${p(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Hodnota je pr\xEDli\u0161 ve\u013Ek\xE1: ${t.origin ?? "hodnota"} mus\xED ma\u0165 ${n}${t.maximum.toString()} ${a.unit ?? "prvkov"}` : `Hodnota je pr\xEDli\u0161 ve\u013Ek\xE1: ${t.origin ?? "hodnota"} mus\xED by\u0165 ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Hodnota je pr\xEDli\u0161 mal\xE1: ${t.origin ?? "hodnota"} mus\xED ma\u0165 ${n}${t.minimum.toString()} ${a.unit ?? "prvkov"}` : `Hodnota je pr\xEDli\u0161 mal\xE1: ${t.origin ?? "hodnota"} mus\xED by\u0165 ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Neplatn\xFD re\u0165azec: mus\xED za\u010D\xEDna\u0165 na "${n.prefix}"` : n.format === "ends_with" ? `Neplatn\xFD re\u0165azec: mus\xED kon\u010Di\u0165 na "${n.suffix}"` : n.format === "includes" ? `Neplatn\xFD re\u0165azec: mus\xED obsahova\u0165 "${n.includes}"` : n.format === "regex" ? `Neplatn\xFD re\u0165azec: mus\xED zodpoveda\u0165 vzoru ${n.pattern}` : `Neplatn\xFD form\xE1t ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Neplatn\xE9 \u010D\xEDslo: mus\xED by\u0165 n\xE1sobkom ${t.divisor}`;
      case "unrecognized_keys":
        return `Nezn\xE1me kl\xFA\u010De: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `Neplatn\xFD kl\xFA\u010D v ${t.origin}`;
      case "invalid_union":
        return "Neplatn\xFD vstup";
      case "invalid_element":
        return `Neplatn\xE1 hodnota v ${t.origin}`;
      default:
        return "Neplatn\xFD vstup";
    }
  };
}, "error");
function Qu() {
  return {
    localeError: Bg()
  };
}
u(Qu, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/sl.js
var qg = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "znakov", verb: "imeti" },
    file: { unit: "bajtov", verb: "imeti" },
    array: { unit: "elementov", verb: "imeti" },
    set: { unit: "elementov", verb: "imeti" },
    map: { unit: "elementov", verb: "imeti" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "vnos",
    email: "e-po\u0161tni naslov",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datum in \u010Das",
    date: "ISO datum",
    time: "ISO \u010Das",
    duration: "ISO trajanje",
    ipv4: "IPv4 naslov",
    ipv6: "IPv6 naslov",
    mac: "MAC naslov",
    cidrv4: "obseg IPv4",
    cidrv6: "obseg IPv6",
    base64: "base64 kodiran niz",
    base64url: "base64url kodiran niz",
    json_string: "JSON niz",
    e164: "E.164 \u0161tevilka",
    credit_card: "\u0161tevilka kreditne kartice",
    jwt: "JWT",
    template_literal: "vnos"
  }, o = {
    nan: "NaN",
    number: "\u0161tevilo",
    array: "tabela"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Neveljaven vnos: pri\u010Dakovano instanceof ${t.expected}, prejeto ${c}` : `Neveljaven vnos: pri\u010Dakovano ${n}, prejeto ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Neveljaven vnos: pri\u010Dakovano ${h(t.values[0])}` : `Neveljavna mo\u017Enost: pri\u010Dakovano eno izmed ${p(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Preveliko: pri\u010Dakovano, da bo ${t.origin ?? "vrednost"} imelo ${n}${t.maximum.toString()} ${a.unit ?? "elementov"}` : `Preveliko: pri\u010Dakovano, da bo ${t.origin ?? "vrednost"} ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Premajhno: pri\u010Dakovano, da bo ${t.origin} imelo ${n}${t.minimum.toString()} ${a.unit}` : `Premajhno: pri\u010Dakovano, da bo ${t.origin} ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Neveljaven niz: mora se za\u010Deti z "${n.prefix}"` : n.format === "ends_with" ? `Neveljaven niz: mora se kon\u010Dati z "${n.suffix}"` : n.format === "includes" ? `Neveljaven niz: mora vsebovati "${n.includes}"` : n.format === "regex" ? `Neveljaven niz: mora ustrezati vzorcu ${n.pattern}` : `Neveljaven ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Neveljavno \u0161tevilo: mora biti ve\u010Dkratnik ${t.divisor}`;
      case "unrecognized_keys":
        return `Neprepoznan${t.keys.length > 1 ? "i klju\u010Di" : " klju\u010D"}: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `Neveljaven klju\u010D v ${t.origin}`;
      case "invalid_union":
        return "Neveljaven vnos";
      case "invalid_element":
        return `Neveljavna vrednost v ${t.origin}`;
      default:
        return "Neveljaven vnos";
    }
  };
}, "error");
function ec() {
  return {
    localeError: qg()
  };
}
u(ec, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/sv.js
var Xg = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "tecken", verb: "att ha" },
    file: { unit: "bytes", verb: "att ha" },
    array: { unit: "objekt", verb: "att inneh\xE5lla" },
    set: { unit: "objekt", verb: "att inneh\xE5lla" },
    map: { unit: "objekt", verb: "att inneh\xE5lla" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "regulj\xE4rt uttryck",
    email: "e-postadress",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO-datum och tid",
    date: "ISO-datum",
    time: "ISO-tid",
    duration: "ISO-varaktighet",
    ipv4: "IPv4-adress",
    ipv6: "IPv6-adress",
    mac: "MAC-adress",
    cidrv4: "IPv4-spektrum",
    cidrv6: "IPv6-spektrum",
    base64: "base64-kodad str\xE4ng",
    base64url: "base64url-kodad str\xE4ng",
    json_string: "JSON-str\xE4ng",
    e164: "E.164-nummer",
    credit_card: "kreditkortsnummer",
    jwt: "JWT",
    template_literal: "mall-literal"
  }, o = {
    nan: "NaN",
    number: "antal",
    array: "lista"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Ogiltig inmatning: f\xF6rv\xE4ntat instanceof ${t.expected}, fick ${c}` : `Ogiltig inmatning: f\xF6rv\xE4ntat ${n}, fick ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Ogiltig inmatning: f\xF6rv\xE4ntat ${h(t.values[0])}` : `Ogiltigt val: f\xF6rv\xE4ntade en av ${p(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `F\xF6r stor(t): f\xF6rv\xE4ntade ${t.origin ?? "v\xE4rdet"} att ha ${n}${t.maximum.toString()} ${a.unit ?? "element"}` : `F\xF6r stor(t): f\xF6rv\xE4ntat ${t.origin ?? "v\xE4rdet"} att ha ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `F\xF6r lite(t): f\xF6rv\xE4ntade ${t.origin ?? "v\xE4rdet"} att ha ${n}${t.minimum.toString()} ${a.unit}` : `F\xF6r lite(t): f\xF6rv\xE4ntade ${t.origin ?? "v\xE4rdet"} att ha ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Ogiltig str\xE4ng: m\xE5ste b\xF6rja med "${n.prefix}"` : n.format === "ends_with" ? `Ogiltig str\xE4ng: m\xE5ste sluta med "${n.suffix}"` : n.format === "includes" ? `Ogiltig str\xE4ng: m\xE5ste inneh\xE5lla "${n.includes}"` : n.format === "regex" ? `Ogiltig str\xE4ng: m\xE5ste matcha m\xF6nstret "${n.pattern}"` : `Ogiltig(t) ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Ogiltigt tal: m\xE5ste vara en multipel av ${t.divisor}`;
      case "unrecognized_keys":
        return `${t.keys.length > 1 ? "Ok\xE4nda nycklar" : "Ok\xE4nd nyckel"}: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `Ogiltig nyckel i ${t.origin ?? "v\xE4rdet"}`;
      case "invalid_union":
        return "Ogiltig input";
      case "invalid_element":
        return `Ogiltigt v\xE4rde i ${t.origin ?? "v\xE4rdet"}`;
      default:
        return "Ogiltig input";
    }
  };
}, "error");
function tc() {
  return {
    localeError: Xg()
  };
}
u(tc, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ta.js
var Yg = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "\u0B8E\u0BB4\u0BC1\u0BA4\u0BCD\u0BA4\u0BC1\u0B95\u0BCD\u0B95\u0BB3\u0BCD", verb: "\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD" },
    file: { unit: "\u0BAA\u0BC8\u0B9F\u0BCD\u0B9F\u0BC1\u0B95\u0BB3\u0BCD", verb: "\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD" },
    array: { unit: "\u0B89\u0BB1\u0BC1\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD", verb: "\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD" },
    set: { unit: "\u0B89\u0BB1\u0BC1\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD", verb: "\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD" },
    map: { unit: "\u0B89\u0BB1\u0BC1\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD", verb: "\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "\u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1",
    email: "\u0BAE\u0BBF\u0BA9\u0BCD\u0BA9\u0B9E\u0BCD\u0B9A\u0BB2\u0BCD \u0BAE\u0BC1\u0B95\u0BB5\u0BB0\u0BBF",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0BA4\u0BC7\u0BA4\u0BBF \u0BA8\u0BC7\u0BB0\u0BAE\u0BCD",
    date: "ISO \u0BA4\u0BC7\u0BA4\u0BBF",
    time: "ISO \u0BA8\u0BC7\u0BB0\u0BAE\u0BCD",
    duration: "ISO \u0B95\u0BBE\u0BB2 \u0B85\u0BB3\u0BB5\u0BC1",
    ipv4: "IPv4 \u0BAE\u0BC1\u0B95\u0BB5\u0BB0\u0BBF",
    ipv6: "IPv6 \u0BAE\u0BC1\u0B95\u0BB5\u0BB0\u0BBF",
    mac: "MAC \u0BAE\u0BC1\u0B95\u0BB5\u0BB0\u0BBF",
    cidrv4: "IPv4 \u0BB5\u0BB0\u0BAE\u0BCD\u0BAA\u0BC1",
    cidrv6: "IPv6 \u0BB5\u0BB0\u0BAE\u0BCD\u0BAA\u0BC1",
    base64: "base64-encoded \u0B9A\u0BB0\u0BAE\u0BCD",
    base64url: "base64url-encoded \u0B9A\u0BB0\u0BAE\u0BCD",
    json_string: "JSON \u0B9A\u0BB0\u0BAE\u0BCD",
    e164: "E.164 \u0B8E\u0BA3\u0BCD",
    credit_card: "\u0B95\u0B9F\u0BA9\u0BCD \u0B85\u0B9F\u0BCD\u0B9F\u0BC8 \u0B8E\u0BA3\u0BCD",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN",
    number: "\u0B8E\u0BA3\u0BCD",
    array: "\u0B85\u0BA3\u0BBF",
    null: "\u0BB5\u0BC6\u0BB1\u0BC1\u0BAE\u0BC8"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 instanceof ${t.expected}, \u0BAA\u0BC6\u0BB1\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${c}` : `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${n}, \u0BAA\u0BC6\u0BB1\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${h(t.values[0])}` : `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0BB5\u0BBF\u0BB0\u0BC1\u0BAA\u0BCD\u0BAA\u0BAE\u0BCD: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${p(t.values, "|")} \u0B87\u0BB2\u0BCD \u0B92\u0BA9\u0BCD\u0BB1\u0BC1`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u0BAE\u0BBF\u0B95 \u0BAA\u0BC6\u0BB0\u0BBF\u0BAF\u0BA4\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${t.origin ?? "\u0BAE\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1"} ${n}${t.maximum.toString()} ${a.unit ?? "\u0B89\u0BB1\u0BC1\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD"} \u0B86\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : `\u0BAE\u0BBF\u0B95 \u0BAA\u0BC6\u0BB0\u0BBF\u0BAF\u0BA4\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${t.origin ?? "\u0BAE\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1"} ${n}${t.maximum.toString()} \u0B86\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u0BAE\u0BBF\u0B95\u0B9A\u0BCD \u0B9A\u0BBF\u0BB1\u0BBF\u0BAF\u0BA4\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${t.origin} ${n}${t.minimum.toString()} ${a.unit} \u0B86\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : `\u0BAE\u0BBF\u0B95\u0B9A\u0BCD \u0B9A\u0BBF\u0BB1\u0BBF\u0BAF\u0BA4\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${t.origin} ${n}${t.minimum.toString()} \u0B86\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B9A\u0BB0\u0BAE\u0BCD: "${n.prefix}" \u0B87\u0BB2\u0BCD \u0BA4\u0BCA\u0B9F\u0B99\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : n.format === "ends_with" ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B9A\u0BB0\u0BAE\u0BCD: "${n.suffix}" \u0B87\u0BB2\u0BCD \u0BAE\u0BC1\u0B9F\u0BBF\u0BB5\u0B9F\u0BC8\u0BAF \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : n.format === "includes" ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B9A\u0BB0\u0BAE\u0BCD: "${n.includes}" \u0B90 \u0B89\u0BB3\u0BCD\u0BB3\u0B9F\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : n.format === "regex" ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B9A\u0BB0\u0BAE\u0BCD: ${n.pattern} \u0BAE\u0BC1\u0BB1\u0BC8\u0BAA\u0BBE\u0B9F\u0BCD\u0B9F\u0BC1\u0B9F\u0BA9\u0BCD \u0BAA\u0BCA\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B8E\u0BA3\u0BCD: ${t.divisor} \u0B87\u0BA9\u0BCD \u0BAA\u0BB2\u0BAE\u0BBE\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD`;
      case "unrecognized_keys":
        return `\u0B85\u0B9F\u0BC8\u0BAF\u0BBE\u0BB3\u0BAE\u0BCD \u0BA4\u0BC6\u0BB0\u0BBF\u0BAF\u0BBE\u0BA4 \u0BB5\u0BBF\u0B9A\u0BC8${t.keys.length > 1 ? "\u0B95\u0BB3\u0BCD" : ""}: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `${t.origin} \u0B87\u0BB2\u0BCD \u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0BB5\u0BBF\u0B9A\u0BC8`;
      case "invalid_union":
        return "\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1";
      case "invalid_element":
        return `${t.origin} \u0B87\u0BB2\u0BCD \u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0BAE\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1`;
      default:
        return "\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1";
    }
  };
}, "error");
function rc() {
  return {
    localeError: Yg()
  };
}
u(rc, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/th.js
var Hg = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "\u0E15\u0E31\u0E27\u0E2D\u0E31\u0E01\u0E29\u0E23", verb: "\u0E04\u0E27\u0E23\u0E21\u0E35" },
    file: { unit: "\u0E44\u0E1A\u0E15\u0E4C", verb: "\u0E04\u0E27\u0E23\u0E21\u0E35" },
    array: { unit: "\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23", verb: "\u0E04\u0E27\u0E23\u0E21\u0E35" },
    set: { unit: "\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23", verb: "\u0E04\u0E27\u0E23\u0E21\u0E35" },
    map: { unit: "\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23", verb: "\u0E04\u0E27\u0E23\u0E21\u0E35" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E17\u0E35\u0E48\u0E1B\u0E49\u0E2D\u0E19",
    email: "\u0E17\u0E35\u0E48\u0E2D\u0E22\u0E39\u0E48\u0E2D\u0E35\u0E40\u0E21\u0E25",
    url: "URL",
    emoji: "\u0E2D\u0E34\u0E42\u0E21\u0E08\u0E34",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48\u0E40\u0E27\u0E25\u0E32\u0E41\u0E1A\u0E1A ISO",
    date: "\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48\u0E41\u0E1A\u0E1A ISO",
    time: "\u0E40\u0E27\u0E25\u0E32\u0E41\u0E1A\u0E1A ISO",
    duration: "\u0E0A\u0E48\u0E27\u0E07\u0E40\u0E27\u0E25\u0E32\u0E41\u0E1A\u0E1A ISO",
    ipv4: "\u0E17\u0E35\u0E48\u0E2D\u0E22\u0E39\u0E48 IPv4",
    ipv6: "\u0E17\u0E35\u0E48\u0E2D\u0E22\u0E39\u0E48 IPv6",
    mac: "\u0E17\u0E35\u0E48\u0E2D\u0E22\u0E39\u0E48 MAC",
    cidrv4: "\u0E0A\u0E48\u0E27\u0E07 IP \u0E41\u0E1A\u0E1A IPv4",
    cidrv6: "\u0E0A\u0E48\u0E27\u0E07 IP \u0E41\u0E1A\u0E1A IPv6",
    base64: "\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E41\u0E1A\u0E1A Base64",
    base64url: "\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E41\u0E1A\u0E1A Base64 \u0E2A\u0E33\u0E2B\u0E23\u0E31\u0E1A URL",
    json_string: "\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E41\u0E1A\u0E1A JSON",
    e164: "\u0E40\u0E1A\u0E2D\u0E23\u0E4C\u0E42\u0E17\u0E23\u0E28\u0E31\u0E1E\u0E17\u0E4C\u0E23\u0E30\u0E2B\u0E27\u0E48\u0E32\u0E07\u0E1B\u0E23\u0E30\u0E40\u0E17\u0E28 (E.164)",
    credit_card: "\u0E2B\u0E21\u0E32\u0E22\u0E40\u0E25\u0E02\u0E1A\u0E31\u0E15\u0E23\u0E40\u0E04\u0E23\u0E14\u0E34\u0E15",
    jwt: "\u0E42\u0E17\u0E40\u0E04\u0E19 JWT",
    template_literal: "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E17\u0E35\u0E48\u0E1B\u0E49\u0E2D\u0E19"
  }, o = {
    nan: "NaN",
    number: "\u0E15\u0E31\u0E27\u0E40\u0E25\u0E02",
    array: "\u0E2D\u0E32\u0E23\u0E4C\u0E40\u0E23\u0E22\u0E4C (Array)",
    null: "\u0E44\u0E21\u0E48\u0E21\u0E35\u0E04\u0E48\u0E32 (null)"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u0E1B\u0E23\u0E30\u0E40\u0E20\u0E17\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E04\u0E27\u0E23\u0E40\u0E1B\u0E47\u0E19 instanceof ${t.expected} \u0E41\u0E15\u0E48\u0E44\u0E14\u0E49\u0E23\u0E31\u0E1A ${c}` : `\u0E1B\u0E23\u0E30\u0E40\u0E20\u0E17\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E04\u0E27\u0E23\u0E40\u0E1B\u0E47\u0E19 ${n} \u0E41\u0E15\u0E48\u0E44\u0E14\u0E49\u0E23\u0E31\u0E1A ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u0E04\u0E48\u0E32\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E04\u0E27\u0E23\u0E40\u0E1B\u0E47\u0E19 ${h(t.values[0])}` : `\u0E15\u0E31\u0E27\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E04\u0E27\u0E23\u0E40\u0E1B\u0E47\u0E19\u0E2B\u0E19\u0E36\u0E48\u0E07\u0E43\u0E19 ${p(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "\u0E44\u0E21\u0E48\u0E40\u0E01\u0E34\u0E19" : "\u0E19\u0E49\u0E2D\u0E22\u0E01\u0E27\u0E48\u0E32", a = r(t.origin);
        return a ? `\u0E40\u0E01\u0E34\u0E19\u0E01\u0E33\u0E2B\u0E19\u0E14: ${t.origin ?? "\u0E04\u0E48\u0E32"} \u0E04\u0E27\u0E23\u0E21\u0E35${n} ${t.maximum.toString()} ${a.unit ?? "\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23"}` : `\u0E40\u0E01\u0E34\u0E19\u0E01\u0E33\u0E2B\u0E19\u0E14: ${t.origin ?? "\u0E04\u0E48\u0E32"} \u0E04\u0E27\u0E23\u0E21\u0E35${n} ${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? "\u0E2D\u0E22\u0E48\u0E32\u0E07\u0E19\u0E49\u0E2D\u0E22" : "\u0E21\u0E32\u0E01\u0E01\u0E27\u0E48\u0E32", a = r(t.origin);
        return a ? `\u0E19\u0E49\u0E2D\u0E22\u0E01\u0E27\u0E48\u0E32\u0E01\u0E33\u0E2B\u0E19\u0E14: ${t.origin} \u0E04\u0E27\u0E23\u0E21\u0E35${n} ${t.minimum.toString()} ${a.unit}` : `\u0E19\u0E49\u0E2D\u0E22\u0E01\u0E27\u0E48\u0E32\u0E01\u0E33\u0E2B\u0E19\u0E14: ${t.origin} \u0E04\u0E27\u0E23\u0E21\u0E35${n} ${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E15\u0E49\u0E2D\u0E07\u0E02\u0E36\u0E49\u0E19\u0E15\u0E49\u0E19\u0E14\u0E49\u0E27\u0E22 "${n.prefix}"` : n.format === "ends_with" ? `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E15\u0E49\u0E2D\u0E07\u0E25\u0E07\u0E17\u0E49\u0E32\u0E22\u0E14\u0E49\u0E27\u0E22 "${n.suffix}"` : n.format === "includes" ? `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E15\u0E49\u0E2D\u0E07\u0E21\u0E35 "${n.includes}" \u0E2D\u0E22\u0E39\u0E48\u0E43\u0E19\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21` : n.format === "regex" ? `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E15\u0E49\u0E2D\u0E07\u0E15\u0E23\u0E07\u0E01\u0E31\u0E1A\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E17\u0E35\u0E48\u0E01\u0E33\u0E2B\u0E19\u0E14 ${n.pattern}` : `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u0E15\u0E31\u0E27\u0E40\u0E25\u0E02\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E15\u0E49\u0E2D\u0E07\u0E40\u0E1B\u0E47\u0E19\u0E08\u0E33\u0E19\u0E27\u0E19\u0E17\u0E35\u0E48\u0E2B\u0E32\u0E23\u0E14\u0E49\u0E27\u0E22 ${t.divisor} \u0E44\u0E14\u0E49\u0E25\u0E07\u0E15\u0E31\u0E27`;
      case "unrecognized_keys":
        return `\u0E1E\u0E1A\u0E04\u0E35\u0E22\u0E4C\u0E17\u0E35\u0E48\u0E44\u0E21\u0E48\u0E23\u0E39\u0E49\u0E08\u0E31\u0E01: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `\u0E04\u0E35\u0E22\u0E4C\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07\u0E43\u0E19 ${t.origin}`;
      case "invalid_union":
        return "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E44\u0E21\u0E48\u0E15\u0E23\u0E07\u0E01\u0E31\u0E1A\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E22\u0E39\u0E40\u0E19\u0E35\u0E22\u0E19\u0E17\u0E35\u0E48\u0E01\u0E33\u0E2B\u0E19\u0E14\u0E44\u0E27\u0E49";
      case "invalid_element":
        return `\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07\u0E43\u0E19 ${t.origin}`;
      default:
        return "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07";
    }
  };
}, "error");
function nc() {
  return {
    localeError: Hg()
  };
}
u(nc, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/tk.js
var Qg = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "simwol", verb: "bolmaly" },
    file: { unit: "ba\xFDt", verb: "bolmaly" },
    array: { unit: "elementler", verb: "bolmaly" },
    set: { unit: "elementler", verb: "bolmaly" },
    map: { unit: "elementler", verb: "bolmaly" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "giri\u015F",
    email: "e-po\xE7ta salgysy",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO sene we wagt",
    date: "ISO sene",
    time: "ISO wagt",
    duration: "ISO wagt aralygy",
    ipv4: "IPv4 salgysy",
    ipv6: "IPv6 salgysy",
    mac: "MAC salgysy",
    cidrv4: "IPv4 aralygy",
    cidrv6: "IPv6 aralygy",
    base64: "base64 bilen \u015Fifrlenen setir",
    base64url: "base64url bilen \u015Fifrlenen setir",
    json_string: "JSON setiri",
    e164: "E.164 nomeri",
    credit_card: "kredit kartyny\u0148 nomeri",
    jwt: "JWT",
    template_literal: "\u015Fablon"
  }, o = {
    nan: "NaN"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return `N\xE4dogry baha: gara\u015Fylan ${n} \xFDerine ${c} alyndy`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `N\xE4dogry baha: ${h(t.values[0])} bolmaly` : `N\xE4dogry sa\xFDlaw: a\u015Fakdakylardan biri bolmaly: ${p(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Has uly: gara\u015Fyl\xFDan ${t.origin ?? "baha"} ${n} ${t.maximum.toString()} ${a.unit ?? "element"}` : `Has uly: gara\u015Fyl\xFDan ${t.origin ?? "baha"} ${n} ${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Has ki\xE7i: gara\u015Fyl\xFDan ${t.origin} ${n} ${t.minimum.toString()} ${a.unit}` : `Has ki\xE7i: gara\u015Fyl\xFDan ${t.origin} ${n} ${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `N\xE4dogry setir: "${n.prefix}" bilen ba\u015Flamaly` : n.format === "ends_with" ? `N\xE4dogry setir: "${n.suffix}" bilen gutarmaly` : n.format === "includes" ? `N\xE4dogry setir: "${n.includes}" saklamaly` : n.format === "regex" ? `N\xE4dogry setir: ${n.pattern} nusga la\xFDyk bolmaly` : `N\xE4dogry ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `N\xE4dogry san: ${t.divisor} bilen galyndysyz b\xF6l\xFCnmeli`;
      case "unrecognized_keys":
        return `Tanalma\xFDan a\xE7ar${t.keys.length > 1 ? "lar" : ""}: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `${t.origin} i\xE7inde n\xE4dogry a\xE7ar`;
      case "invalid_union":
        return "N\xE4dogry baha";
      case "invalid_element":
        return `${t.origin} i\xE7inde n\xE4dogry baha`;
      default:
        return "N\xE4dogry baha";
    }
  };
}, "error");
function ic() {
  return {
    localeError: Qg()
  };
}
u(ic, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/tr.js
var ev = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "karakter", verb: "olmal\u0131" },
    file: { unit: "bayt", verb: "olmal\u0131" },
    array: { unit: "\xF6\u011Fe", verb: "olmal\u0131" },
    set: { unit: "\xF6\u011Fe", verb: "olmal\u0131" },
    map: { unit: "\xF6\u011Fe", verb: "olmal\u0131" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "girdi",
    email: "e-posta adresi",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO tarih ve saat",
    date: "ISO tarih",
    time: "ISO saat",
    duration: "ISO s\xFCre",
    ipv4: "IPv4 adresi",
    ipv6: "IPv6 adresi",
    mac: "MAC adresi",
    cidrv4: "IPv4 aral\u0131\u011F\u0131",
    cidrv6: "IPv6 aral\u0131\u011F\u0131",
    base64: "base64 ile \u015Fifrelenmi\u015F metin",
    base64url: "base64url ile \u015Fifrelenmi\u015F metin",
    json_string: "JSON dizesi",
    e164: "E.164 say\u0131s\u0131",
    credit_card: "kredi kart\u0131 numaras\u0131",
    jwt: "JWT",
    template_literal: "\u015Eablon dizesi"
  }, o = {
    nan: "NaN"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Ge\xE7ersiz de\u011Fer: beklenen instanceof ${t.expected}, al\u0131nan ${c}` : `Ge\xE7ersiz de\u011Fer: beklenen ${n}, al\u0131nan ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Ge\xE7ersiz de\u011Fer: beklenen ${h(t.values[0])}` : `Ge\xE7ersiz se\xE7enek: a\u015Fa\u011F\u0131dakilerden biri olmal\u0131: ${p(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\xC7ok b\xFCy\xFCk: beklenen ${t.origin ?? "de\u011Fer"} ${n}${t.maximum.toString()} ${a.unit ?? "\xF6\u011Fe"}` : `\xC7ok b\xFCy\xFCk: beklenen ${t.origin ?? "de\u011Fer"} ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\xC7ok k\xFC\xE7\xFCk: beklenen ${t.origin} ${n}${t.minimum.toString()} ${a.unit}` : `\xC7ok k\xFC\xE7\xFCk: beklenen ${t.origin} ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Ge\xE7ersiz metin: "${n.prefix}" ile ba\u015Flamal\u0131` : n.format === "ends_with" ? `Ge\xE7ersiz metin: "${n.suffix}" ile bitmeli` : n.format === "includes" ? `Ge\xE7ersiz metin: "${n.includes}" i\xE7ermeli` : n.format === "regex" ? `Ge\xE7ersiz metin: ${n.pattern} desenine uymal\u0131` : `Ge\xE7ersiz ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Ge\xE7ersiz say\u0131: ${t.divisor} ile tam b\xF6l\xFCnebilmeli`;
      case "unrecognized_keys":
        return `Tan\u0131nmayan anahtar${t.keys.length > 1 ? "lar" : ""}: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `${t.origin} i\xE7inde ge\xE7ersiz anahtar`;
      case "invalid_union":
        return "Ge\xE7ersiz de\u011Fer";
      case "invalid_element":
        return `${t.origin} i\xE7inde ge\xE7ersiz de\u011Fer`;
      default:
        return "Ge\xE7ersiz de\u011Fer";
    }
  };
}, "error");
function oc() {
  return {
    localeError: ev()
  };
}
u(oc, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/uk.js
var tv = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "\u0441\u0438\u043C\u0432\u043E\u043B\u0456\u0432", verb: "\u043C\u0430\u0442\u0438\u043C\u0435" },
    file: { unit: "\u0431\u0430\u0439\u0442\u0456\u0432", verb: "\u043C\u0430\u0442\u0438\u043C\u0435" },
    array: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0456\u0432", verb: "\u043C\u0430\u0442\u0438\u043C\u0435" },
    set: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0456\u0432", verb: "\u043C\u0430\u0442\u0438\u043C\u0435" },
    map: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0456\u0432", verb: "\u043C\u0430\u0442\u0438\u043C\u0435" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "\u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456",
    email: "\u0430\u0434\u0440\u0435\u0441\u0430 \u0435\u043B\u0435\u043A\u0442\u0440\u043E\u043D\u043D\u043E\u0457 \u043F\u043E\u0448\u0442\u0438",
    url: "URL",
    emoji: "\u0435\u043C\u043E\u0434\u0437\u0456",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u0434\u0430\u0442\u0430 \u0442\u0430 \u0447\u0430\u0441 ISO",
    date: "\u0434\u0430\u0442\u0430 ISO",
    time: "\u0447\u0430\u0441 ISO",
    duration: "\u0442\u0440\u0438\u0432\u0430\u043B\u0456\u0441\u0442\u044C ISO",
    ipv4: "\u0430\u0434\u0440\u0435\u0441\u0430 IPv4",
    ipv6: "\u0430\u0434\u0440\u0435\u0441\u0430 IPv6",
    mac: "\u0430\u0434\u0440\u0435\u0441\u0430 MAC",
    cidrv4: "\u0434\u0456\u0430\u043F\u0430\u0437\u043E\u043D IPv4",
    cidrv6: "\u0434\u0456\u0430\u043F\u0430\u0437\u043E\u043D IPv6",
    base64: "\u0440\u044F\u0434\u043E\u043A \u0443 \u043A\u043E\u0434\u0443\u0432\u0430\u043D\u043D\u0456 base64",
    base64url: "\u0440\u044F\u0434\u043E\u043A \u0443 \u043A\u043E\u0434\u0443\u0432\u0430\u043D\u043D\u0456 base64url",
    json_string: "\u0440\u044F\u0434\u043E\u043A JSON",
    e164: "\u043D\u043E\u043C\u0435\u0440 E.164",
    credit_card: "\u043D\u043E\u043C\u0435\u0440 \u043A\u0440\u0435\u0434\u0438\u0442\u043D\u043E\u0457 \u043A\u0430\u0440\u0442\u043A\u0438",
    jwt: "JWT",
    template_literal: "\u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456"
  }, o = {
    nan: "NaN",
    number: "\u0447\u0438\u0441\u043B\u043E",
    array: "\u043C\u0430\u0441\u0438\u0432"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F instanceof ${t.expected}, \u043E\u0442\u0440\u0438\u043C\u0430\u043D\u043E ${c}` : `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F ${n}, \u043E\u0442\u0440\u0438\u043C\u0430\u043D\u043E ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F ${h(t.values[0])}` : `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0430 \u043E\u043F\u0446\u0456\u044F: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F \u043E\u0434\u043D\u0435 \u0437 ${p(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u0417\u0430\u043D\u0430\u0434\u0442\u043E \u0432\u0435\u043B\u0438\u043A\u0435: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F, \u0449\u043E ${t.origin ?? "\u0437\u043D\u0430\u0447\u0435\u043D\u043D\u044F"} ${a.verb} ${n}${t.maximum.toString()} ${a.unit ?? "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0456\u0432"}` : `\u0417\u0430\u043D\u0430\u0434\u0442\u043E \u0432\u0435\u043B\u0438\u043A\u0435: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F, \u0449\u043E ${t.origin ?? "\u0437\u043D\u0430\u0447\u0435\u043D\u043D\u044F"} \u0431\u0443\u0434\u0435 ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u0417\u0430\u043D\u0430\u0434\u0442\u043E \u043C\u0430\u043B\u0435: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F, \u0449\u043E ${t.origin} ${a.verb} ${n}${t.minimum.toString()} ${a.unit}` : `\u0417\u0430\u043D\u0430\u0434\u0442\u043E \u043C\u0430\u043B\u0435: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F, \u0449\u043E ${t.origin} \u0431\u0443\u0434\u0435 ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u0440\u044F\u0434\u043E\u043A: \u043F\u043E\u0432\u0438\u043D\u0435\u043D \u043F\u043E\u0447\u0438\u043D\u0430\u0442\u0438\u0441\u044F \u0437 "${n.prefix}"` : n.format === "ends_with" ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u0440\u044F\u0434\u043E\u043A: \u043F\u043E\u0432\u0438\u043D\u0435\u043D \u0437\u0430\u043A\u0456\u043D\u0447\u0443\u0432\u0430\u0442\u0438\u0441\u044F \u043D\u0430 "${n.suffix}"` : n.format === "includes" ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u0440\u044F\u0434\u043E\u043A: \u043F\u043E\u0432\u0438\u043D\u0435\u043D \u043C\u0456\u0441\u0442\u0438\u0442\u0438 "${n.includes}"` : n.format === "regex" ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u0440\u044F\u0434\u043E\u043A: \u043F\u043E\u0432\u0438\u043D\u0435\u043D \u0432\u0456\u0434\u043F\u043E\u0432\u0456\u0434\u0430\u0442\u0438 \u0448\u0430\u0431\u043B\u043E\u043D\u0443 ${n.pattern}` : `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0435 \u0447\u0438\u0441\u043B\u043E: \u043F\u043E\u0432\u0438\u043D\u043D\u043E \u0431\u0443\u0442\u0438 \u043A\u0440\u0430\u0442\u043D\u0438\u043C ${t.divisor}`;
      case "unrecognized_keys":
        return `\u041D\u0435\u0440\u043E\u0437\u043F\u0456\u0437\u043D\u0430\u043D\u0438\u0439 \u043A\u043B\u044E\u0447${t.keys.length > 1 ? "\u0456" : ""}: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u043A\u043B\u044E\u0447 \u0443 ${t.origin}`;
      case "invalid_union":
        return "\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456";
      case "invalid_element":
        return `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u043D\u044F \u0443 ${t.origin}`;
      default:
        return "\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456";
    }
  };
}, "error");
function rr() {
  return {
    localeError: tv()
  };
}
u(rr, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ua.js
function ac() {
  return rr();
}
u(ac, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ur.js
var rv = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "\u062D\u0631\u0648\u0641", verb: "\u06C1\u0648\u0646\u0627" },
    file: { unit: "\u0628\u0627\u0626\u0679\u0633", verb: "\u06C1\u0648\u0646\u0627" },
    array: { unit: "\u0622\u0626\u0679\u0645\u0632", verb: "\u06C1\u0648\u0646\u0627" },
    set: { unit: "\u0622\u0626\u0679\u0645\u0632", verb: "\u06C1\u0648\u0646\u0627" },
    map: { unit: "\u0622\u0626\u0679\u0645\u0632", verb: "\u06C1\u0648\u0646\u0627" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "\u0627\u0646 \u067E\u0679",
    email: "\u0627\u06CC \u0645\u06CC\u0644 \u0627\u06CC\u0688\u0631\u06CC\u0633",
    url: "\u06CC\u0648 \u0622\u0631 \u0627\u06CC\u0644",
    emoji: "\u0627\u06CC\u0645\u0648\u062C\u06CC",
    uuid: "\u06CC\u0648 \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC",
    uuidv4: "\u06CC\u0648 \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC \u0648\u06CC 4",
    uuidv6: "\u06CC\u0648 \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC \u0648\u06CC 6",
    nanoid: "\u0646\u06CC\u0646\u0648 \u0622\u0626\u06CC \u0688\u06CC",
    guid: "\u062C\u06CC \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC",
    cuid: "\u0633\u06CC \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC",
    cuid2: "\u0633\u06CC \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC 2",
    ulid: "\u06CC\u0648 \u0627\u06CC\u0644 \u0622\u0626\u06CC \u0688\u06CC",
    xid: "\u0627\u06CC\u06A9\u0633 \u0622\u0626\u06CC \u0688\u06CC",
    ksuid: "\u06A9\u06D2 \u0627\u06CC\u0633 \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC",
    datetime: "\u0622\u0626\u06CC \u0627\u06CC\u0633 \u0627\u0648 \u0688\u06CC\u0679 \u0679\u0627\u0626\u0645",
    date: "\u0622\u0626\u06CC \u0627\u06CC\u0633 \u0627\u0648 \u062A\u0627\u0631\u06CC\u062E",
    time: "\u0622\u0626\u06CC \u0627\u06CC\u0633 \u0627\u0648 \u0648\u0642\u062A",
    duration: "\u0622\u0626\u06CC \u0627\u06CC\u0633 \u0627\u0648 \u0645\u062F\u062A",
    ipv4: "\u0622\u0626\u06CC \u067E\u06CC \u0648\u06CC 4 \u0627\u06CC\u0688\u0631\u06CC\u0633",
    ipv6: "\u0622\u0626\u06CC \u067E\u06CC \u0648\u06CC 6 \u0627\u06CC\u0688\u0631\u06CC\u0633",
    mac: "\u0627\u06CC\u0645 \u0627\u06D2 \u0633\u06CC \u0627\u06CC\u0688\u0631\u06CC\u0633",
    cidrv4: "\u0622\u0626\u06CC \u067E\u06CC \u0648\u06CC 4 \u0631\u06CC\u0646\u062C",
    cidrv6: "\u0622\u0626\u06CC \u067E\u06CC \u0648\u06CC 6 \u0631\u06CC\u0646\u062C",
    base64: "\u0628\u06CC\u0633 64 \u0627\u0646 \u06A9\u0648\u0688\u0688 \u0633\u0679\u0631\u0646\u06AF",
    base64url: "\u0628\u06CC\u0633 64 \u06CC\u0648 \u0622\u0631 \u0627\u06CC\u0644 \u0627\u0646 \u06A9\u0648\u0688\u0688 \u0633\u0679\u0631\u0646\u06AF",
    json_string: "\u062C\u06D2 \u0627\u06CC\u0633 \u0627\u0648 \u0627\u06CC\u0646 \u0633\u0679\u0631\u0646\u06AF",
    e164: "\u0627\u06CC 164 \u0646\u0645\u0628\u0631",
    credit_card: "\u06A9\u0631\u06CC\u0688\u0679 \u06A9\u0627\u0631\u0688 \u0646\u0645\u0628\u0631",
    jwt: "\u062C\u06D2 \u0688\u0628\u0644\u06CC\u0648 \u0679\u06CC",
    template_literal: "\u0627\u0646 \u067E\u0679"
  }, o = {
    nan: "NaN",
    number: "\u0646\u0645\u0628\u0631",
    array: "\u0622\u0631\u06D2",
    null: "\u0646\u0644"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679: instanceof ${t.expected} \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627\u060C ${c} \u0645\u0648\u0635\u0648\u0644 \u06C1\u0648\u0627` : `\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679: ${n} \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627\u060C ${c} \u0645\u0648\u0635\u0648\u0644 \u06C1\u0648\u0627`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679: ${h(t.values[0])} \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627` : `\u063A\u0644\u0637 \u0622\u067E\u0634\u0646: ${p(t.values, "|")} \u0645\u06CC\u06BA \u0633\u06D2 \u0627\u06CC\u06A9 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u0628\u06C1\u062A \u0628\u0691\u0627: ${t.origin ?? "\u0648\u06CC\u0644\u06CC\u0648"} \u06A9\u06D2 ${n}${t.maximum.toString()} ${a.unit ?? "\u0639\u0646\u0627\u0635\u0631"} \u06C1\u0648\u0646\u06D2 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u06D2` : `\u0628\u06C1\u062A \u0628\u0691\u0627: ${t.origin ?? "\u0648\u06CC\u0644\u06CC\u0648"} \u06A9\u0627 ${n}${t.maximum.toString()} \u06C1\u0648\u0646\u0627 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u0628\u06C1\u062A \u0686\u06BE\u0648\u0679\u0627: ${t.origin} \u06A9\u06D2 ${n}${t.minimum.toString()} ${a.unit} \u06C1\u0648\u0646\u06D2 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u06D2` : `\u0628\u06C1\u062A \u0686\u06BE\u0648\u0679\u0627: ${t.origin} \u06A9\u0627 ${n}${t.minimum.toString()} \u06C1\u0648\u0646\u0627 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u063A\u0644\u0637 \u0633\u0679\u0631\u0646\u06AF: "${n.prefix}" \u0633\u06D2 \u0634\u0631\u0648\u0639 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2` : n.format === "ends_with" ? `\u063A\u0644\u0637 \u0633\u0679\u0631\u0646\u06AF: "${n.suffix}" \u067E\u0631 \u062E\u062A\u0645 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2` : n.format === "includes" ? `\u063A\u0644\u0637 \u0633\u0679\u0631\u0646\u06AF: "${n.includes}" \u0634\u0627\u0645\u0644 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2` : n.format === "regex" ? `\u063A\u0644\u0637 \u0633\u0679\u0631\u0646\u06AF: \u067E\u06CC\u0679\u0631\u0646 ${n.pattern} \u0633\u06D2 \u0645\u06CC\u0686 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2` : `\u063A\u0644\u0637 ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u063A\u0644\u0637 \u0646\u0645\u0628\u0631: ${t.divisor} \u06A9\u0627 \u0645\u0636\u0627\u0639\u0641 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2`;
      case "unrecognized_keys":
        return `\u063A\u06CC\u0631 \u062A\u0633\u0644\u06CC\u0645 \u0634\u062F\u06C1 \u06A9\u06CC${t.keys.length > 1 ? "\u0632" : ""}: ${p(t.keys, "\u060C ")}`;
      case "invalid_key":
        return `${t.origin} \u0645\u06CC\u06BA \u063A\u0644\u0637 \u06A9\u06CC`;
      case "invalid_union":
        return "\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679";
      case "invalid_element":
        return `${t.origin} \u0645\u06CC\u06BA \u063A\u0644\u0637 \u0648\u06CC\u0644\u06CC\u0648`;
      default:
        return "\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679";
    }
  };
}, "error");
function uc() {
  return {
    localeError: rv()
  };
}
u(uc, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/uz.js
var nv = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "belgi", verb: "bo\u2018lishi kerak" },
    file: { unit: "bayt", verb: "bo\u2018lishi kerak" },
    array: { unit: "element", verb: "bo\u2018lishi kerak" },
    set: { unit: "element", verb: "bo\u2018lishi kerak" },
    map: { unit: "yozuv", verb: "bo\u2018lishi kerak" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "kirish",
    email: "elektron pochta manzili",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO sana va vaqti",
    date: "ISO sana",
    time: "ISO vaqt",
    duration: "ISO davomiylik",
    ipv4: "IPv4 manzil",
    ipv6: "IPv6 manzil",
    mac: "MAC manzil",
    cidrv4: "IPv4 diapazon",
    cidrv6: "IPv6 diapazon",
    base64: "base64 kodlangan satr",
    base64url: "base64url kodlangan satr",
    json_string: "JSON satr",
    e164: "E.164 raqam",
    credit_card: "kredit karta raqami",
    jwt: "JWT",
    template_literal: "kirish"
  }, o = {
    nan: "NaN",
    number: "raqam",
    array: "massiv"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Noto\u2018g\u2018ri kirish: kutilgan instanceof ${t.expected}, qabul qilingan ${c}` : `Noto\u2018g\u2018ri kirish: kutilgan ${n}, qabul qilingan ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Noto\u2018g\u2018ri kirish: kutilgan ${h(t.values[0])}` : `Noto\u2018g\u2018ri variant: quyidagilardan biri kutilgan ${p(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Juda katta: kutilgan ${t.origin ?? "qiymat"} ${n}${t.maximum.toString()} ${a.unit} ${a.verb}` : `Juda katta: kutilgan ${t.origin ?? "qiymat"} ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Juda kichik: kutilgan ${t.origin} ${n}${t.minimum.toString()} ${a.unit} ${a.verb}` : `Juda kichik: kutilgan ${t.origin} ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Noto\u2018g\u2018ri satr: "${n.prefix}" bilan boshlanishi kerak` : n.format === "ends_with" ? `Noto\u2018g\u2018ri satr: "${n.suffix}" bilan tugashi kerak` : n.format === "includes" ? `Noto\u2018g\u2018ri satr: "${n.includes}" ni o\u2018z ichiga olishi kerak` : n.format === "regex" ? `Noto\u2018g\u2018ri satr: ${n.pattern} shabloniga mos kelishi kerak` : `Noto\u2018g\u2018ri ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Noto\u2018g\u2018ri raqam: ${t.divisor} ning karralisi bo\u2018lishi kerak`;
      case "unrecognized_keys":
        return `Noma\u2019lum kalit${t.keys.length > 1 ? "lar" : ""}: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `${t.origin} dagi kalit noto\u2018g\u2018ri`;
      case "invalid_union":
        return "Noto\u2018g\u2018ri kirish";
      case "invalid_element":
        return `${t.origin} da noto\u2018g\u2018ri qiymat`;
      default:
        return "Noto\u2018g\u2018ri kirish";
    }
  };
}, "error");
function cc() {
  return {
    localeError: nv()
  };
}
u(cc, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/vi.js
var iv = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "k\xFD t\u1EF1", verb: "c\xF3" },
    file: { unit: "byte", verb: "c\xF3" },
    array: { unit: "ph\u1EA7n t\u1EED", verb: "c\xF3" },
    set: { unit: "ph\u1EA7n t\u1EED", verb: "c\xF3" },
    map: { unit: "ph\u1EA7n t\u1EED", verb: "c\xF3" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "\u0111\u1EA7u v\xE0o",
    email: "\u0111\u1ECBa ch\u1EC9 email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ng\xE0y gi\u1EDD ISO",
    date: "ng\xE0y ISO",
    time: "gi\u1EDD ISO",
    duration: "kho\u1EA3ng th\u1EDDi gian ISO",
    ipv4: "\u0111\u1ECBa ch\u1EC9 IPv4",
    ipv6: "\u0111\u1ECBa ch\u1EC9 IPv6",
    mac: "\u0111\u1ECBa ch\u1EC9 MAC",
    cidrv4: "d\u1EA3i IPv4",
    cidrv6: "d\u1EA3i IPv6",
    base64: "chu\u1ED7i m\xE3 h\xF3a base64",
    base64url: "chu\u1ED7i m\xE3 h\xF3a base64url",
    json_string: "chu\u1ED7i JSON",
    e164: "s\u1ED1 E.164",
    credit_card: "s\u1ED1 th\u1EBB t\xEDn d\u1EE5ng",
    jwt: "JWT",
    template_literal: "\u0111\u1EA7u v\xE0o"
  }, o = {
    nan: "NaN",
    number: "s\u1ED1",
    array: "m\u1EA3ng"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7: mong \u0111\u1EE3i instanceof ${t.expected}, nh\u1EADn \u0111\u01B0\u1EE3c ${c}` : `\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7: mong \u0111\u1EE3i ${n}, nh\u1EADn \u0111\u01B0\u1EE3c ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7: mong \u0111\u1EE3i ${h(t.values[0])}` : `T\xF9y ch\u1ECDn kh\xF4ng h\u1EE3p l\u1EC7: mong \u0111\u1EE3i m\u1ED9t trong c\xE1c gi\xE1 tr\u1ECB ${p(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Qu\xE1 l\u1EDBn: mong \u0111\u1EE3i ${t.origin ?? "gi\xE1 tr\u1ECB"} ${a.verb} ${n}${t.maximum.toString()} ${a.unit ?? "ph\u1EA7n t\u1EED"}` : `Qu\xE1 l\u1EDBn: mong \u0111\u1EE3i ${t.origin ?? "gi\xE1 tr\u1ECB"} ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Qu\xE1 nh\u1ECF: mong \u0111\u1EE3i ${t.origin} ${a.verb} ${n}${t.minimum.toString()} ${a.unit}` : `Qu\xE1 nh\u1ECF: mong \u0111\u1EE3i ${t.origin} ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Chu\u1ED7i kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i b\u1EAFt \u0111\u1EA7u b\u1EB1ng "${n.prefix}"` : n.format === "ends_with" ? `Chu\u1ED7i kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i k\u1EBFt th\xFAc b\u1EB1ng "${n.suffix}"` : n.format === "includes" ? `Chu\u1ED7i kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i bao g\u1ED3m "${n.includes}"` : n.format === "regex" ? `Chu\u1ED7i kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i kh\u1EDBp v\u1EDBi m\u1EABu ${n.pattern}` : `${i[n.format] ?? t.format} kh\xF4ng h\u1EE3p l\u1EC7`;
      }
      case "not_multiple_of":
        return `S\u1ED1 kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i l\xE0 b\u1ED9i s\u1ED1 c\u1EE7a ${t.divisor}`;
      case "unrecognized_keys":
        return `Kh\xF3a kh\xF4ng \u0111\u01B0\u1EE3c nh\u1EADn d\u1EA1ng: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `Kh\xF3a kh\xF4ng h\u1EE3p l\u1EC7 trong ${t.origin}`;
      case "invalid_union":
        return "\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7";
      case "invalid_element":
        return `Gi\xE1 tr\u1ECB kh\xF4ng h\u1EE3p l\u1EC7 trong ${t.origin}`;
      default:
        return "\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7";
    }
  };
}, "error");
function sc() {
  return {
    localeError: iv()
  };
}
u(sc, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/zh-CN.js
var ov = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "\u5B57\u7B26", verb: "\u5305\u542B" },
    file: { unit: "\u5B57\u8282", verb: "\u5305\u542B" },
    array: { unit: "\u9879", verb: "\u5305\u542B" },
    set: { unit: "\u9879", verb: "\u5305\u542B" },
    map: { unit: "\u9879", verb: "\u5305\u542B" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "\u8F93\u5165",
    email: "\u7535\u5B50\u90AE\u4EF6",
    url: "URL",
    emoji: "\u8868\u60C5\u7B26\u53F7",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO\u65E5\u671F\u65F6\u95F4",
    date: "ISO\u65E5\u671F",
    time: "ISO\u65F6\u95F4",
    duration: "ISO\u65F6\u957F",
    ipv4: "IPv4\u5730\u5740",
    ipv6: "IPv6\u5730\u5740",
    mac: "MAC\u5730\u5740",
    cidrv4: "IPv4\u7F51\u6BB5",
    cidrv6: "IPv6\u7F51\u6BB5",
    base64: "base64\u7F16\u7801\u5B57\u7B26\u4E32",
    base64url: "base64url\u7F16\u7801\u5B57\u7B26\u4E32",
    json_string: "JSON\u5B57\u7B26\u4E32",
    e164: "E.164\u53F7\u7801",
    credit_card: "\u4FE1\u7528\u5361\u53F7",
    jwt: "JWT",
    template_literal: "\u8F93\u5165"
  }, o = {
    nan: "NaN",
    number: "\u6570\u5B57",
    array: "\u6570\u7EC4",
    null: "\u7A7A\u503C(null)"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u65E0\u6548\u8F93\u5165\uFF1A\u671F\u671B instanceof ${t.expected}\uFF0C\u5B9E\u9645\u63A5\u6536 ${c}` : `\u65E0\u6548\u8F93\u5165\uFF1A\u671F\u671B ${n}\uFF0C\u5B9E\u9645\u63A5\u6536 ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u65E0\u6548\u8F93\u5165\uFF1A\u671F\u671B ${h(t.values[0])}` : `\u65E0\u6548\u9009\u9879\uFF1A\u671F\u671B\u4EE5\u4E0B\u4E4B\u4E00 ${p(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u6570\u503C\u8FC7\u5927\uFF1A\u671F\u671B ${t.origin ?? "\u503C"} ${n}${t.maximum.toString()} ${a.unit ?? "\u4E2A\u5143\u7D20"}` : `\u6570\u503C\u8FC7\u5927\uFF1A\u671F\u671B ${t.origin ?? "\u503C"} ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u6570\u503C\u8FC7\u5C0F\uFF1A\u671F\u671B ${t.origin} ${n}${t.minimum.toString()} ${a.unit}` : `\u6570\u503C\u8FC7\u5C0F\uFF1A\u671F\u671B ${t.origin} ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u65E0\u6548\u5B57\u7B26\u4E32\uFF1A\u5FC5\u987B\u4EE5 "${n.prefix}" \u5F00\u5934` : n.format === "ends_with" ? `\u65E0\u6548\u5B57\u7B26\u4E32\uFF1A\u5FC5\u987B\u4EE5 "${n.suffix}" \u7ED3\u5C3E` : n.format === "includes" ? `\u65E0\u6548\u5B57\u7B26\u4E32\uFF1A\u5FC5\u987B\u5305\u542B "${n.includes}"` : n.format === "regex" ? `\u65E0\u6548\u5B57\u7B26\u4E32\uFF1A\u5FC5\u987B\u6EE1\u8DB3\u6B63\u5219\u8868\u8FBE\u5F0F ${n.pattern}` : `\u65E0\u6548${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u65E0\u6548\u6570\u5B57\uFF1A\u5FC5\u987B\u662F ${t.divisor} \u7684\u500D\u6570`;
      case "unrecognized_keys":
        return `\u51FA\u73B0\u672A\u77E5\u7684\u952E(key): ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `${t.origin} \u4E2D\u7684\u952E(key)\u65E0\u6548`;
      case "invalid_union":
        return "\u65E0\u6548\u8F93\u5165";
      case "invalid_element":
        return `${t.origin} \u4E2D\u5305\u542B\u65E0\u6548\u503C(value)`;
      default:
        return "\u65E0\u6548\u8F93\u5165";
    }
  };
}, "error");
function lc() {
  return {
    localeError: ov()
  };
}
u(lc, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/zh-TW.js
var av = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "\u5B57\u5143", verb: "\u64C1\u6709" },
    file: { unit: "\u4F4D\u5143\u7D44", verb: "\u64C1\u6709" },
    array: { unit: "\u9805\u76EE", verb: "\u64C1\u6709" },
    set: { unit: "\u9805\u76EE", verb: "\u64C1\u6709" },
    map: { unit: "\u9805\u76EE", verb: "\u64C1\u6709" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "\u8F38\u5165",
    email: "\u90F5\u4EF6\u5730\u5740",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u65E5\u671F\u6642\u9593",
    date: "ISO \u65E5\u671F",
    time: "ISO \u6642\u9593",
    duration: "ISO \u671F\u9593",
    ipv4: "IPv4 \u4F4D\u5740",
    ipv6: "IPv6 \u4F4D\u5740",
    mac: "MAC \u4F4D\u5740",
    cidrv4: "IPv4 \u7BC4\u570D",
    cidrv6: "IPv6 \u7BC4\u570D",
    base64: "base64 \u7DE8\u78BC\u5B57\u4E32",
    base64url: "base64url \u7DE8\u78BC\u5B57\u4E32",
    json_string: "JSON \u5B57\u4E32",
    e164: "E.164 \u6578\u503C",
    credit_card: "\u4FE1\u7528\u5361\u865F",
    jwt: "JWT",
    template_literal: "\u8F38\u5165"
  }, o = {
    nan: "NaN"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u7121\u6548\u7684\u8F38\u5165\u503C\uFF1A\u9810\u671F\u70BA instanceof ${t.expected}\uFF0C\u4F46\u6536\u5230 ${c}` : `\u7121\u6548\u7684\u8F38\u5165\u503C\uFF1A\u9810\u671F\u70BA ${n}\uFF0C\u4F46\u6536\u5230 ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u7121\u6548\u7684\u8F38\u5165\u503C\uFF1A\u9810\u671F\u70BA ${h(t.values[0])}` : `\u7121\u6548\u7684\u9078\u9805\uFF1A\u9810\u671F\u70BA\u4EE5\u4E0B\u5176\u4E2D\u4E4B\u4E00 ${p(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u6578\u503C\u904E\u5927\uFF1A\u9810\u671F ${t.origin ?? "\u503C"} \u61C9\u70BA ${n}${t.maximum.toString()} ${a.unit ?? "\u500B\u5143\u7D20"}` : `\u6578\u503C\u904E\u5927\uFF1A\u9810\u671F ${t.origin ?? "\u503C"} \u61C9\u70BA ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u6578\u503C\u904E\u5C0F\uFF1A\u9810\u671F ${t.origin} \u61C9\u70BA ${n}${t.minimum.toString()} ${a.unit}` : `\u6578\u503C\u904E\u5C0F\uFF1A\u9810\u671F ${t.origin} \u61C9\u70BA ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u7121\u6548\u7684\u5B57\u4E32\uFF1A\u5FC5\u9808\u4EE5 "${n.prefix}" \u958B\u982D` : n.format === "ends_with" ? `\u7121\u6548\u7684\u5B57\u4E32\uFF1A\u5FC5\u9808\u4EE5 "${n.suffix}" \u7D50\u5C3E` : n.format === "includes" ? `\u7121\u6548\u7684\u5B57\u4E32\uFF1A\u5FC5\u9808\u5305\u542B "${n.includes}"` : n.format === "regex" ? `\u7121\u6548\u7684\u5B57\u4E32\uFF1A\u5FC5\u9808\u7B26\u5408\u683C\u5F0F ${n.pattern}` : `\u7121\u6548\u7684 ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u7121\u6548\u7684\u6578\u5B57\uFF1A\u5FC5\u9808\u70BA ${t.divisor} \u7684\u500D\u6578`;
      case "unrecognized_keys":
        return `\u7121\u6CD5\u8B58\u5225\u7684\u9375\u503C${t.keys.length > 1 ? "\u5011" : ""}\uFF1A${p(t.keys, "\u3001")}`;
      case "invalid_key":
        return `${t.origin} \u4E2D\u6709\u7121\u6548\u7684\u9375\u503C`;
      case "invalid_union":
        return "\u7121\u6548\u7684\u8F38\u5165\u503C";
      case "invalid_element":
        return `${t.origin} \u4E2D\u6709\u7121\u6548\u7684\u503C`;
      default:
        return "\u7121\u6548\u7684\u8F38\u5165\u503C";
    }
  };
}, "error");
function dc() {
  return {
    localeError: av()
  };
}
u(dc, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/yo.js
var uv = /* @__PURE__ */ u(() => {
  let e = {
    string: { unit: "\xE0mi", verb: "n\xED" },
    file: { unit: "bytes", verb: "n\xED" },
    array: { unit: "nkan", verb: "n\xED" },
    set: { unit: "nkan", verb: "n\xED" },
    map: { unit: "nkan", verb: "n\xED" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  u(r, "getSizing");
  let i = {
    regex: "\u1EB9\u0300r\u1ECD \xECb\xE1w\u1ECDl\xE9",
    email: "\xE0d\xEDr\u1EB9\u0301s\xEC \xECm\u1EB9\u0301l\xEC",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\xE0k\xF3k\xF2 ISO",
    date: "\u1ECDj\u1ECD\u0301 ISO",
    time: "\xE0k\xF3k\xF2 ISO",
    duration: "\xE0k\xF3k\xF2 t\xF3 p\xE9 ISO",
    ipv4: "\xE0d\xEDr\u1EB9\u0301s\xEC IPv4",
    ipv6: "\xE0d\xEDr\u1EB9\u0301s\xEC IPv6",
    mac: "\xE0d\xEDr\u1EB9\u0301s\xEC MAC",
    cidrv4: "\xE0gb\xE8gb\xE8 IPv4",
    cidrv6: "\xE0gb\xE8gb\xE8 IPv6",
    base64: "\u1ECD\u0300r\u1ECD\u0300 t\xED a k\u1ECD\u0301 n\xED base64",
    base64url: "\u1ECD\u0300r\u1ECD\u0300 base64url",
    json_string: "\u1ECD\u0300r\u1ECD\u0300 JSON",
    e164: "n\u1ECD\u0301mb\xE0 E.164",
    credit_card: "n\u1ECDmba kaadi gbese",
    jwt: "JWT",
    template_literal: "\u1EB9\u0300r\u1ECD \xECb\xE1w\u1ECDl\xE9"
  }, o = {
    nan: "NaN",
    number: "n\u1ECD\u0301mb\xE0",
    array: "akop\u1ECD"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = _(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e: a n\xED l\xE1ti fi instanceof ${t.expected}, \xE0m\u1ECD\u0300 a r\xED ${c}` : `\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e: a n\xED l\xE1ti fi ${n}, \xE0m\u1ECD\u0300 a r\xED ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e: a n\xED l\xE1ti fi ${h(t.values[0])}` : `\xC0\u1E63\xE0y\xE0n a\u1E63\xEC\u1E63e: yan \u1ECD\u0300kan l\xE1ra ${p(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `T\xF3 p\u1ECD\u0300 j\xF9: a n\xED l\xE1ti j\u1EB9\u0301 p\xE9 ${t.origin ?? "iye"} ${a.verb} ${n}${t.maximum} ${a.unit}` : `T\xF3 p\u1ECD\u0300 j\xF9: a n\xED l\xE1ti j\u1EB9\u0301 ${n}${t.maximum}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `K\xE9r\xE9 ju: a n\xED l\xE1ti j\u1EB9\u0301 p\xE9 ${t.origin} ${a.verb} ${n}${t.minimum} ${a.unit}` : `K\xE9r\xE9 ju: a n\xED l\xE1ti j\u1EB9\u0301 ${n}${t.minimum}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u1ECC\u0300r\u1ECD\u0300 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 b\u1EB9\u0300r\u1EB9\u0300 p\u1EB9\u0300l\xFA "${n.prefix}"` : n.format === "ends_with" ? `\u1ECC\u0300r\u1ECD\u0300 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 par\xED p\u1EB9\u0300l\xFA "${n.suffix}"` : n.format === "includes" ? `\u1ECC\u0300r\u1ECD\u0300 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 n\xED "${n.includes}"` : n.format === "regex" ? `\u1ECC\u0300r\u1ECD\u0300 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 b\xE1 \xE0p\u1EB9\u1EB9r\u1EB9 mu ${n.pattern}` : `A\u1E63\xEC\u1E63e: ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `N\u1ECD\u0301mb\xE0 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 j\u1EB9\u0301 \xE8y\xE0 p\xEDp\xEDn ti ${t.divisor}`;
      case "unrecognized_keys":
        return `B\u1ECDt\xECn\xEC \xE0\xECm\u1ECD\u0300: ${p(t.keys, ", ")}`;
      case "invalid_key":
        return `B\u1ECDt\xECn\xEC a\u1E63\xEC\u1E63e n\xEDn\xFA ${t.origin}`;
      case "invalid_union":
        return "\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e";
      case "invalid_element":
        return `Iye a\u1E63\xEC\u1E63e n\xEDn\xFA ${t.origin}`;
      default:
        return "\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e";
    }
  };
}, "error");
function mc() {
  return {
    localeError: uv()
  };
}
u(mc, "default");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/registries.js
var Ed, fc = /* @__PURE__ */ Symbol("ZodOutput"), pc = /* @__PURE__ */ Symbol("ZodInput"), pn = class {
  static {
    u(this, "$ZodRegistry");
  }
  constructor() {
    this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map();
  }
  add(r, ...i) {
    let o = i[0];
    return this._map.set(r, o), o && typeof o == "object" && "id" in o && this._idmap.set(o.id, r), this;
  }
  clear() {
    return this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map(), this;
  }
  remove(r) {
    let i = this._map.get(r);
    return i && typeof i == "object" && "id" in i && this._idmap.delete(i.id), this._map.delete(r), this;
  }
  get(r) {
    let i = r._zod.parent;
    if (i) {
      let o = { ...this.get(i) ?? {} };
      delete o.id;
      let t = { ...o, ...this._map.get(r) };
      return Object.keys(t).length ? t : void 0;
    }
    return this._map.get(r);
  }
  has(r) {
    return this._map.has(r);
  }
};
function gn() {
  return new pn();
}
u(gn, "registry");
(Ed = globalThis).__zod_globalRegistry ?? (Ed.__zod_globalRegistry = gn());
var B = globalThis.__zod_globalRegistry;

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/compile.js
var ae = Symbol.for("zod.compile.invalid"), Cd = Symbol.for("zod.compile.fallback"), me = class extends Error {
  static {
    u(this, "ZodCompileAsyncError");
  }
  constructor(r = "z.compile does not support async refinements, transforms, or checks") {
    super(r), this.name = "ZodCompileAsyncError";
  }
}, U = class extends Error {
  static {
    u(this, "ZodCompileUnsupportedError");
  }
  constructor(r, i = !0) {
    super(`z.compile does not support ${r}; this schema must use the runtime parser`), this.name = "ZodCompileUnsupportedError", this.islandable = i;
  }
};
function sv(e, r) {
  try {
    return vn(e, { assertOnly: !0 });
  } catch {
    return r;
  }
}
u(sv, "compileValidator");
function hc(e, r) {
  try {
    let i = vn(e), o = T(e), t = e._zod.run, n = t.__originalRun ?? t, a = /* @__PURE__ */ u((c, s) => {
      if (s?.async || s?.direction === "backward" || s?.skipChecks || s?.[Cd] || s && fn(s, c.value))
        return n(c, s);
      let l = i(c.value);
      return l !== ae ? (c.value = l, c) : (s && (s[Cd] = !0), n(c, s));
    }, "wrapped");
    return a.__originalRun = n, o._zod.bag.fallbackRun = n, o._zod.bag.validator = sv(e, i), o._zod.run = a, t.__originalRun || lv(o, e, i), o;
  } catch (i) {
    if (r?.strict)
      throw i;
    return e;
  }
}
u(hc, "compile");
function lv(e, r, i) {
  let o = e, t = r;
  if (typeof t.safeParse == "function") {
    let n = t.safeParse;
    o.safeParse = (a, c) => {
      let s = i(a);
      return s !== ae ? { success: !0, data: s } : n(a, c);
    };
  }
  if (typeof t.parse == "function") {
    let n = t.parse;
    o.parse = (a, c) => {
      let s = i(a);
      return s !== ae ? s : n(a, c);
    };
  }
}
u(lv, "installCompiledUserMethods");
function vn(e, r) {
  let i = !0;
  try {
    i = uu(e);
  } catch {
  }
  if (i)
    throw new U("a schema whose subtree contains a reference cycle");
  let o = {
    constants: /* @__PURE__ */ new Map(),
    constantCounter: 0,
    varCounter: 0
  }, t = new Ee(["input"]), n = F(t, o, e, "input", !r?.assertOnly);
  t.write(n === null ? "return true;" : `return ${n};`);
  let a = ["INVALID", ...o.constants.keys()], c = [ae, ...o.constants.values()], s = t.content.join(`
`), l = r?.debug ? a.length > 0 ? `// Constants: ${a.join(", ")}
${s}` : s : "", d = Function, m = `return (input) => {
${s}
}`, g;
  try {
    g = new d(...a, m)(...c);
  } catch (v) {
    throw new U(`this schema (generated code failed to evaluate: ${v.message})`);
  }
  return r?.debug && (g.code = l), g;
}
u(vn, "compileFn");
function z(e, r) {
  for (let [o, t] of e.constants)
    if (t === r)
      return o;
  let i = `c${e.constantCounter++}`;
  return e.constants.set(i, r), i;
}
u(z, "addConstant");
function S(e) {
  return `v${e.varCounter++}`;
}
u(S, "newVar");
function dv(e, r) {
  let i = e._zod.run({ value: r, issues: [] }, {});
  if (i && typeof i.then == "function")
    return ae;
  let o = i;
  return o.issues.length === 0 ? o.value : ae;
}
u(dv, "runtimeRun");
function Y(e, r, i, o, t = !0) {
  let n = e.content.length, a = r.constants.size, c = r.constantCounter, s = r.varCounter;
  try {
    return F(e, r, i, o, t);
  } catch (l) {
    if (!(l instanceof U) || !l.islandable)
      throw l;
    if (e.content.length = n, r.constants.size > a) {
      let d = Array.from(r.constants.keys()).slice(a);
      for (let m of d)
        r.constants.delete(m);
    }
    return r.constantCounter = c, r.varCounter = s, mv(e, r, i, o);
  }
}
u(Y, "compileChild");
function mv(e, r, i, o) {
  let t = z(r, i), n = z(r, dv), a = S(r);
  return e.write(`const ${a} = ${n}(${t}, ${o});`), e.write(`if (${a} === INVALID) return INVALID;`), a;
}
u(mv, "emitRuntimeIsland");
var fv = /* @__PURE__ */ new Set([
  "max_size",
  "min_size",
  "size_equals",
  "max_length",
  "min_length",
  "length_equals"
]);
function pv(e, r, i, o) {
  let t = i._zod.def.checks;
  if (!t || t.length === 0)
    return o;
  let n = o;
  for (let a of t) {
    let c = a._zod.def;
    if (c.when && !fv.has(c.check))
      throw new U('check with a custom "when" condition');
    switch (c.check) {
      case "greater_than":
        gv(e, r, c, n);
        break;
      case "less_than":
        vv(e, r, c, n);
        break;
      case "multiple_of":
        $v(e, r, c, n);
        break;
      case "number_format":
        Fd(e, c, n);
        break;
      case "min_length": {
        let s = Le(c.minimum, "min_length"), l = gc(e, r, n, `${n}.length >= ${s} && ${n}.length < ${c.minimum * 2}`);
        e.write(`if (${l} < ${s}) return INVALID;`);
        break;
      }
      case "max_length": {
        let s = Le(c.maximum, "max_length"), l = gc(e, r, n, `${n}.length > ${s}`);
        e.write(`if (${l} > ${s}) return INVALID;`);
        break;
      }
      case "length_equals": {
        let s = Le(c.length, "length_equals"), l = gc(e, r, n, `${n}.length >= ${s} && ${n}.length <= ${c.length * 2}`);
        e.write(`if (${l} !== ${s}) return INVALID;`);
        break;
      }
      case "min_size":
        e.write(`if (${n}.size < ${Le(c.minimum, "min_size")}) return INVALID;`);
        break;
      case "max_size":
        e.write(`if (${n}.size > ${Le(c.maximum, "max_size")}) return INVALID;`);
        break;
      case "size_equals":
        e.write(`if (${n}.size !== ${Le(c.size, "size_equals")}) return INVALID;`);
        break;
      case "string_format":
        n = Jd(e, r, c, n);
        break;
      case "custom":
        n = kv(e, r, a, n);
        break;
      case "bigint_format":
        hv(e, c, n);
        break;
      case "mime_type":
        _v(e, r, c, n);
        break;
      case "property":
        yv(e, r, c, n);
        break;
      case "overwrite": {
        let s = S(r);
        bv(e, r, a, n, s), n = s;
        break;
      }
      default:
        throw new U(`check type ${c.check}`);
    }
  }
  return n;
}
u(pv, "generateChecks");
function gc(e, r, i, o) {
  let t = z(r, Ze), n = S(r);
  return e.write(`const ${n} = typeof ${i} === "string" && ${o} ? ${t}(${i}) : ${i}.length;`), n;
}
u(gc, "codePointLengthVar");
function Le(e, r) {
  if (typeof e != "number" || !Number.isFinite(e))
    throw new U(`${r} bound of type ${typeof e}`);
  return `${e}`;
}
u(Le, "numericOperand");
function Rd(e, r) {
  if (typeof r == "bigint")
    return `${r}n`;
  if (typeof r == "number") {
    if (Number.isNaN(r))
      throw new U("comparison check with NaN bound");
    return `${r}`;
  }
  if (r instanceof Date) {
    if (Number.isNaN(r.getTime()))
      throw new U("comparison check with Invalid Date bound");
    return z(e, r);
  }
  throw new U(`comparison check bound of type ${typeof r}`);
}
u(Rd, "comparisonOperand");
function gv(e, r, i, o) {
  let t = i.inclusive ? "<" : "<=";
  e.write(`if (${o} ${t} ${Rd(r, i.value)}) return INVALID;`);
}
u(gv, "generateGreaterThanCheck");
function vv(e, r, i, o) {
  let t = i.inclusive ? ">" : ">=";
  e.write(`if (${o} ${t} ${Rd(r, i.value)}) return INVALID;`);
}
u(vv, "generateLessThanCheck");
function $v(e, r, i, o) {
  if (typeof i.value == "bigint") {
    if (i.value === BigInt(0))
      throw new U("multiple_of check with a zero divisor");
    e.write(`if (${o} % ${i.value}n !== 0n) return INVALID;`);
  } else {
    let t = z(r, Zt);
    e.write(`if (${t}(${o}, ${Le(i.value, "multiple_of")}) !== 0) return INVALID;`);
  }
}
u($v, "generateMultipleOfCheck");
function Fd(e, r, i) {
  let o = r.format;
  switch (o) {
    case "safeint":
      e.write(`if (!Number.isSafeInteger(${i})) return INVALID;`);
      break;
    case "int32":
      e.write(`if (!Number.isInteger(${i}) || ${i} < -2147483648 || ${i} > 2147483647) return INVALID;`);
      break;
    case "uint32":
      e.write(`if (!Number.isInteger(${i}) || ${i} < 0 || ${i} > 4294967295) return INVALID;`);
      break;
    case "float32":
      e.write(`if (!Number.isFinite(${i}) || ${i} < -3.4028234663852886e38 || ${i} > 3.4028234663852886e38) return INVALID;`);
      break;
    case "float64":
      e.write(`if (!Number.isFinite(${i})) return INVALID;`);
      break;
    default:
      throw new U(`number format ${o}`);
  }
}
u(Fd, "generateNumberFormatCheck");
function hv(e, r, i) {
  let o = r.format;
  if (o)
    switch (o) {
      case "int64":
        e.write(`if (${i} < -9223372036854775808n || ${i} > 9223372036854775807n) return INVALID;`);
        break;
      case "uint64":
        e.write(`if (${i} < 0n || ${i} > 18446744073709551615n) return INVALID;`);
        break;
      default:
        throw new U(`bigint format ${o}`);
    }
}
u(hv, "generateBigIntFormatCheck");
function _v(e, r, i, o) {
  let t = i.mime;
  if (t && t.length > 0) {
    let n = z(r, new Set(t));
    e.write(`if (!${n}.has(${o}.type)) return INVALID;`);
  }
}
u(_v, "generateMimeTypeCheck");
function yv(e, r, i, o) {
  let t = `${o}[${JSON.stringify(i.property)}]`;
  F(e, r, i.schema, t);
}
u(yv, "generatePropertyCheck");
function bv(e, r, i, o, t) {
  let n = i._zod.def.tx;
  if (!n)
    throw new U("overwrite check without a transform function");
  if (Fe(n))
    throw new me("z.compile: async overwrite transforms are not supported");
  let a = z(r, n);
  e.write(`const ${t} = ${a}(${o});`);
}
u(bv, "generateOverwriteCheck");
function vc() {
  throw new re();
}
u(vc, "throwAsync");
function _c(e) {
  this.issues.push(e);
}
u(_c, "pushIssue");
function kv(e, r, i, o) {
  let t = i._zod.def;
  if (t.fn) {
    if (Fe(t.fn))
      throw new me("z.compile: async .refine() predicates are not supported");
    let n = z(r, t.fn), a = z(r, vc), c = S(r);
    return e.write(`const ${c} = ${n}(${o});`), e.write(`if (${c} instanceof Promise) ${a}();`), e.write(`if (!${c}) return INVALID;`), o;
  }
  if (i._zod.check) {
    if (Fe(i._zod.check))
      throw new me("z.compile: async .superRefine() / check functions are not supported");
    let n = i._zod.check, c = z(r, /* @__PURE__ */ u((l) => {
      let d = { value: l, issues: [], addIssue: _c };
      return n(d) instanceof Promise && vc(), d.issues.length === 0 ? d.value : ae;
    }, "helperFn")), s = S(r);
    return e.write(`const ${s} = ${c}(${o});`), e.write(`if (${s} === INVALID) return INVALID;`), s;
  }
  throw new U("custom check without a predicate or check function");
}
u(kv, "generateCustomRefineCheck");
var xv = /* @__PURE__ */ new Set([
  "cidrv4",
  "cuid",
  "cuid2",
  "date",
  "datetime",
  "duration",
  "e164",
  "email",
  "emoji",
  "ends_with",
  "guid",
  "includes",
  "ipv4",
  "ksuid",
  "lowercase",
  "mac",
  "nanoid",
  "regex",
  "starts_with",
  "time",
  "ulid",
  "uppercase",
  "uuid",
  "xid"
]);
function Jd(e, r, i, o) {
  let t = i.format;
  if (t === "base64") {
    let s = z(r, Gt);
    return e.write(`if (!${s}(${o})) return INVALID;`), o;
  }
  if (t === "base64url") {
    let s = z(r, tn);
    return e.write(`if (!${s}(${o})) return INVALID;`), o;
  }
  if (t === "jwt") {
    let s = z(r, nn), l = z(r, i.alg ?? null);
    return e.write(`if (!${s}(${o}, ${l})) return INVALID;`), o;
  }
  if (t === "ipv6") {
    let s = z(r, Wt);
    return e.write(`if (!${s}(${o})) return INVALID;`), o;
  }
  if (t === "cidrv6") {
    let s = z(r, en);
    return e.write(`if (!${s}(${o})) return INVALID;`), o;
  }
  if (t === "credit_card") {
    let s = z(r, rn);
    return e.write(`if (!${s}(${o})) return INVALID;`), o;
  }
  let n = i;
  if (t === "url" || t === "httpurl" || n.normalize || n.hostname !== void 0 || n.protocol !== void 0) {
    let s = z(r, Xr), l = z(r, i), d = S(r), m = S(r);
    if (e.write(`const ${d} = ${o}.trim();`), e.write(`const ${m} = ${s}(${d}, ${l});`), e.write(`if (typeof ${m} === "number") return INVALID;`), n.hostname !== void 0) {
      let $ = z(r, Hr);
      e.write(`if (!${$}(${m}, ${l}.hostname)) return INVALID;`);
    }
    if (n.protocol !== void 0) {
      let $ = z(r, Qr);
      e.write(`if (!${$}(${m}, ${l}.protocol)) return INVALID;`);
    }
    let g = S(r), v = n.normalize ? `${m}.href` : `${z(r, Yr)}(${d})`;
    return e.write(`const ${g} = ${v};`), g;
  }
  let a = i.fn;
  if (a) {
    if (Fe(a))
      throw new U(`async string format ${t}`);
    let s = z(r, a);
    return e.write(`if (!${s}(${o})) return INVALID;`), o;
  }
  if (xv.has(t) && i.pattern) {
    let s = z(r, i.pattern);
    return e.write(`${s}.lastIndex = 0;`), e.write(`if (!${s}.test(${o})) return INVALID;`), o;
  }
  let c = i.format;
  switch (c) {
    case "regex":
      throw new U("regex format without a pattern");
    case "lowercase":
      e.write(`if (${o} !== ${o}.toLowerCase()) return INVALID;`);
      break;
    case "uppercase":
      e.write(`if (${o} !== ${o}.toUpperCase()) return INVALID;`);
      break;
    case "includes":
      e.write(`if (!${o}.includes(${Q(i.includes)})) return INVALID;`);
      break;
    case "starts_with": {
      let s = i.prefix;
      e.write(`if (${o}.slice(0, ${s.length}) !== ${Q(s)}) return INVALID;`);
      break;
    }
    case "ends_with": {
      let s = i.suffix;
      e.write(`if (${o}.slice(-${s.length}) !== ${Q(s)}) return INVALID;`);
      break;
    }
    default:
      throw new U(`string format ${c}`);
  }
  return o;
}
u(Jd, "generateStringFormatCheck");
function F(e, r, i, o, t = !0) {
  let n = i._zod.def, a = n.type;
  if (n.coerce)
    throw new U(`coercion (z.coerce.${a}())`);
  let c = t || !!n.checks?.length, s;
  switch (a) {
    case "string":
      s = Iv(e, r, i, o);
      break;
    case "number":
      s = wv(e, i, o);
      break;
    case "boolean":
      s = zv(e, o);
      break;
    case "bigint":
      s = Sv(e, i, o);
      break;
    case "symbol":
      s = jv(e, o);
      break;
    case "undefined":
      s = Pv(e, o);
      break;
    case "null":
      s = Dv(e, o);
      break;
    case "any":
    case "unknown":
      s = o;
      break;
    case "never":
      e.write("return INVALID;"), s = o;
      break;
    case "void":
      s = Ov(e, o);
      break;
    case "nan":
      s = Uv(e, o);
      break;
    case "date":
      s = Nv(e, o);
      break;
    case "object":
      s = Tv(e, r, i, o, c);
      break;
    case "optional":
      s = Zv(e, r, i, o, c);
      break;
    case "nullable":
      s = Cv(e, r, i, o, c);
      break;
    case "array":
      s = Lv(e, r, i, o, c);
      break;
    case "literal":
      s = Vv(e, r, i, o);
      break;
    case "enum":
      s = Rv(e, r, i, o);
      break;
    case "readonly": {
      let l = Ld(e, r, i, o), d = S(r);
      e.write(`const ${d} = Object.freeze(${l});`), s = d;
      break;
    }
    case "success":
      Ld(e, r, i, o), s = "true";
      break;
    case "default":
    case "prefault":
      s = Fv(e, r, i, o);
      break;
    case "nonoptional":
      s = Jv(e, r, i, o);
      break;
    case "tuple":
      s = Mv(e, r, i, o);
      break;
    case "union":
      s = Kv(e, r, i, o);
      break;
    case "intersection":
      s = Bv(e, r, i, o);
      break;
    case "record":
      s = qv(e, r, i, o);
      break;
    case "map":
      s = Yv(e, r, i, o);
      break;
    case "set":
      s = Hv(e, r, i, o);
      break;
    case "file":
      s = Qv(e, o);
      break;
    case "template_literal":
      s = e$(e, r, i, o);
      break;
    case "lazy":
      s = t$(e, r, i, o);
      break;
    case "pipe":
      s = r$(e, r, i, o);
      break;
    case "custom":
      s = n$(e, r, i, o);
      break;
    case "transform":
      s = a$(e, r, i, o);
      break;
    case "catch":
      s = o$(e, r, i, o);
      break;
    default:
      throw new U(`schema type ${a}`);
  }
  return s === null ? null : pv(e, r, i, s);
}
u(F, "generateCheck");
function Iv(e, r, i, o) {
  e.write(`if (typeof ${o} !== "string") return INVALID;`);
  let t = i._zod.def;
  return t.format === void 0 ? o : Jd(e, r, t, o);
}
u(Iv, "generateStringCheck");
function wv(e, r, i) {
  e.write(`if (typeof ${i} !== "number" || !Number.isFinite(${i})) return INVALID;`);
  let o = r._zod.def;
  return o.check === "number_format" && o.format && Fd(e, { format: o.format }, i), i;
}
u(wv, "generateNumberCheck");
function zv(e, r) {
  return e.write(`if (typeof ${r} !== "boolean") return INVALID;`), r;
}
u(zv, "generateBooleanCheck");
function Sv(e, r, i) {
  e.write(`if (typeof ${i} !== "bigint") return INVALID;`);
  let o = r._zod.def;
  if (o.format)
    switch (o.format) {
      case "int64":
        e.write(`if (${i} < -9223372036854775808n || ${i} > 9223372036854775807n) return INVALID;`);
        break;
      case "uint64":
        e.write(`if (${i} < 0n || ${i} > 18446744073709551615n) return INVALID;`);
        break;
    }
  return i;
}
u(Sv, "generateBigIntCheck");
function jv(e, r) {
  return e.write(`if (typeof ${r} !== "symbol") return INVALID;`), r;
}
u(jv, "generateSymbolCheck");
function Pv(e, r) {
  return e.write(`if (${r} !== undefined) return INVALID;`), r;
}
u(Pv, "generateUndefinedCheck");
function Dv(e, r) {
  return e.write(`if (${r} !== null) return INVALID;`), r;
}
u(Dv, "generateNullCheck");
function Ov(e, r) {
  return e.write(`if (${r} !== undefined) return INVALID;`), r;
}
u(Ov, "generateVoidCheck");
function Uv(e, r) {
  return e.write(`if (typeof ${r} !== "number" || !Number.isNaN(${r})) return INVALID;`), r;
}
u(Uv, "generateNaNCheck");
function Nv(e, r) {
  return e.write(`if (!(${r} instanceof Date) || Number.isNaN(${r}.getTime())) return INVALID;`), r;
}
u(Nv, "generateDateCheck");
function Tv(e, r, i, o, t = !0) {
  let n = i._zod.def;
  e.write(`if (typeof ${o} !== "object" || ${o} === null || Array.isArray(${o})) return INVALID;`);
  let a = n.shape, c = Object.keys(a), s = Object.getOwnPropertySymbols(a), l = s.length ? [...c, ...s] : c, d = /* @__PURE__ */ u((w) => typeof w == "symbol" ? z(r, w) : Q(w), "keyExpr"), m = /* @__PURE__ */ u((w) => typeof w == "symbol" ? `[${d(w)}]` : Q(w), "propKey"), g = a;
  if (c.includes("__proto__"))
    throw new U('object shape key "__proto__"');
  let v = /* @__PURE__ */ new Map();
  for (let w of l) {
    let P = g[w], V = d(w), R = S(r);
    if (e.write(`const ${R} = ${o}[${V}];`), P._zod.optin !== void 0) {
      let N = S(r);
      e.write(`let ${N} = (() => {`), e.indented((q) => {
        let Ot = Y(q, r, P, R);
        q.write(`return ${Ot};`);
      }), e.write("})();"), P._zod.optout === "optional" ? (e.write(`if (${N} === INVALID) {`), e.indented((q) => {
        q.write(`if (${V} in ${o}) return INVALID;`), q.write(`${N} = undefined;`);
      }), e.write("}")) : e.write(`if (${N} === INVALID) return INVALID;`), v.set(w, N);
    } else {
      Ev(P) && e.write(`if (!(${V} in ${o})) return INVALID;`);
      let N = Y(e, r, P, R, t);
      N !== null && v.set(w, N);
    }
  }
  let $ = n.catchall, k = "none";
  if ($) {
    let w = $._zod.def.type;
    if (w === "never") {
      let P = c.map((V) => `k !== ${Q(V)}`).join(" && ") || "true";
      e.write(`for (const k in ${o}) {`), e.indented((V) => {
        V.write(`if (${P}) return INVALID;`);
      }), e.write("}");
    } else (w === "unknown" || w === "any") && !$._zod.def.checks?.length ? k = "passthrough" : k = "schema";
  }
  let I = S(r), A = l.some((w) => Re(g[w]) || $c(g[w]));
  if (!t) {
    if (k === "schema") {
      let w = c.length > 0 ? z(r, new Set(c)) : null;
      e.write(`for (const k in ${o}) {`), e.indented((P) => {
        P.write('if (k === "__proto__") continue;'), w && P.write(`if (${w}.has(k)) continue;`);
        let V = S(r);
        P.write(`const ${V} = ${o}[k];`), Y(P, r, $, V, !1);
      }), e.write("}");
    }
    return null;
  }
  if (A) {
    e.write(`const ${I} = {};`);
    for (let w of l) {
      let P = d(w), V = v.get(w);
      $c(g[w]) ? e.write(`if (${P} in ${o}) ${I}[${P}] = ${V};`) : Re(g[w]) ? e.write(`if (${V} !== undefined || ${P} in ${o}) ${I}[${P}] = ${V};`) : e.write(`${I}[${P}] = ${V};`);
    }
  } else {
    let w = l.map((P) => `${m(P)}: ${v.get(P)}`).join(", ");
    e.write(`const ${I} = { ${w} };`);
  }
  if (k !== "none") {
    let w = c.length > 0 ? z(r, new Set(c)) : null;
    e.write(`for (const k in ${o}) {`), e.indented((P) => {
      if (P.write('if (k === "__proto__") continue;'), w && P.write(`if (${w}.has(k)) continue;`), k === "passthrough")
        P.write(`${I}[k] = ${o}[k];`);
      else {
        let V = S(r);
        P.write(`const ${V} = ${o}[k];`);
        let R = Y(P, r, $, V);
        P.write(`${I}[k] = ${R};`);
      }
    }), e.write("}");
  }
  return I;
}
u(Tv, "generateObjectCheck");
function Zv(e, r, i, o, t = !0) {
  let n = i._zod.def;
  if (Av(i))
    return F(e, r, n.innerType, o, t);
  if (n.innerType._zod.optin === "defaulted") {
    let c = S(r), s = S(r);
    return e.write(`let ${c};`), e.write(`if (${o} === undefined) {`), e.indented((l) => {
      l.write(`const ${s} = (() => {`), l.indented((d) => {
        let m = F(d, r, n.innerType, o);
        d.write(`return ${m};`);
      }), l.write("})();"), l.write(`if (${s} !== INVALID) ${c} = ${s};`);
    }), e.write("} else {"), e.indented((l) => {
      let d = F(l, r, n.innerType, o);
      l.write(`${c} = ${d};`);
    }), e.write("}"), c;
  }
  let a = t ? S(r) : null;
  return a && e.write(`let ${a};`), e.write(`if (${o} !== undefined) {`), e.indented((c) => {
    let s = F(c, r, n.innerType, o, t);
    a && s !== null && c.write(`${a} = ${s};`);
  }), e.write("}"), a;
}
u(Zv, "generateOptionalCheck");
function Av(e) {
  return e._zod.traits?.has("$ZodExactOptional") === !0;
}
u(Av, "isExactOptional");
function Ev(e) {
  return e._zod.optin === void 0 && Ve(e);
}
u(Ev, "requiresPresenceCheck");
function Ve(e) {
  if (e._zod.def.coerce)
    return !0;
  let r = e._zod.def;
  switch (r.type) {
    case "any":
    case "unknown":
    case "undefined":
    case "void":
    case "default":
    case "prefault":
    case "transform":
    case "custom":
    case "lazy":
      return !0;
    case "string":
    case "number":
    case "boolean":
    case "bigint":
    case "symbol":
    case "null":
    case "never":
    case "nan":
    case "date":
    case "object":
    case "array":
    case "tuple":
    case "record":
    case "map":
    case "set":
    case "file":
    case "template_literal":
      return !1;
    case "nonoptional":
      return r.innerType ? Ve(r.innerType) : !1;
    case "literal":
      return !!r.values?.includes(void 0);
    case "enum":
      return !!e._zod.values?.has(void 0);
    case "optional":
    case "nullable":
    case "readonly":
    case "success":
      return r.innerType ? Ve(r.innerType) : !0;
    case "catch":
      return !0;
    case "union":
      return r.options ? r.options.some(Ve) : !0;
    case "intersection":
      return !r.left || !r.right ? !0 : Ve(r.left) && Ve(r.right);
    case "pipe":
      return r.in ? Ve(r.in) : !0;
    default:
      return !0;
  }
}
u(Ve, "fastPathAcceptsAbsence");
function $c(e) {
  return e._zod.optin === "optional" && e._zod.optout === "optional";
}
u($c, "dropsWhenAbsent");
function Re(e) {
  let r = e._zod.def;
  switch (r.type) {
    case "string":
    case "number":
    case "boolean":
    case "bigint":
    case "symbol":
    case "null":
    case "nan":
    case "date":
    case "object":
    case "array":
    case "tuple":
    case "record":
    case "map":
    case "set":
    case "file":
    case "template_literal":
    case "never":
    case "success":
      return !1;
    case "literal":
      return !!r.values?.includes(void 0);
    case "enum":
      return !!e._zod.values?.has(void 0);
    case "optional":
      return !0;
    case "nullable":
    case "readonly":
    case "nonoptional":
      return r.innerType ? Re(r.innerType) : !0;
    case "union":
      return r.options ? r.options.some(Re) : !0;
    case "intersection":
      return !r.left || !r.right || Re(r.left) || Re(r.right);
    case "pipe":
      return r.out ? Re(r.out) : !0;
    default:
      return !0;
  }
}
u(Re, "mayOutputUndefined");
function Cv(e, r, i, o, t = !0) {
  let n = i._zod.def, a = t ? S(r) : null;
  return a && e.write(`let ${a} = null;`), e.write(`if (${o} !== null) {`), e.indented((c) => {
    let s = F(c, r, n.innerType, o, t);
    a && s !== null && c.write(`${a} = ${s};`);
  }), e.write("}"), a;
}
u(Cv, "generateNullableCheck");
function Lv(e, r, i, o, t = !0) {
  let n = i._zod.def;
  e.write(`if (!Array.isArray(${o})) return INVALID;`);
  let a = t ? S(r) : null, c = S(r), s = S(r);
  return a && e.write(`const ${a} = new Array(${o}.length);`), e.write(`for (let ${c} = 0; ${c} < ${o}.length; ${c}++) {`), e.indented((l) => {
    l.write(`const ${s} = ${o}[${c}];`);
    let d = Y(l, r, n.element, s, t);
    a && d !== null && l.write(`${a}[${c}] = ${d};`);
  }), e.write("}"), a;
}
u(Lv, "generateArrayCheck");
function Vv(e, r, i, o) {
  let n = i._zod.def.values;
  if (n.length !== 1) {
    let c = z(r, new Set(n));
    return e.write(`if (!${c}.has(${o})) return INVALID;`), o;
  }
  let a = n[0];
  if (typeof a == "number" && Number.isNaN(a)) {
    let c = z(r, new Set(n));
    return e.write(`if (!${c}.has(${o})) return INVALID;`), o;
  }
  if (typeof a == "string")
    e.write(`if (${o} !== ${Q(a)}) return INVALID;`);
  else if (typeof a == "number" || typeof a == "boolean")
    e.write(`if (${o} !== ${a}) return INVALID;`);
  else if (a === null)
    e.write(`if (${o} !== null) return INVALID;`);
  else if (a === void 0)
    e.write(`if (${o} !== undefined) return INVALID;`);
  else if (typeof a == "bigint")
    e.write(`if (${o} !== ${a}n) return INVALID;`);
  else
    throw new U(`literal type ${typeof a}`);
  return o;
}
u(Vv, "generateLiteralCheck");
function Rv(e, r, i, o) {
  let t = i._zod.values;
  if (!t)
    throw new U("enum schema without enumerated values");
  let n = z(r, t);
  return e.write(`if (!${n}.has(${o})) return INVALID;`), o;
}
u(Rv, "generateEnumCheck");
function Ld(e, r, i, o) {
  let t = i._zod.def;
  return F(e, r, t.innerType, o);
}
u(Ld, "generateWrapperCheck");
function Fv(e, r, i, o) {
  let t = i._zod.def, a = Object.getOwnPropertyDescriptor(i._zod.def, "defaultValue") ? () => i._zod.def.defaultValue : void 0;
  if (i._zod.def.type === "prefault") {
    if (!a)
      return F(e, r, t.innerType, o);
    let s = z(r, a), l = S(r);
    return e.write(`let ${l} = ${o};`), e.write(`if (${o} === undefined) ${l} = ${s}();`), F(e, r, t.innerType, l);
  }
  let c = S(r);
  if (a) {
    let s = z(r, a), l = z(r, At);
    e.write(`let ${c};`), e.write(`if (${o} === undefined) {`), e.indented((d) => {
      d.write(`${c} = ${l}(${s}());`);
    }), e.write("} else {"), e.indented((d) => {
      let m = F(d, r, t.innerType, o);
      d.write(`${c} = ${m} === undefined ? ${l}(${s}()) : ${m};`);
    }), e.write("}");
  } else
    e.write(`let ${c};`), e.write(`if (${o} !== undefined) {`), e.indented((s) => {
      let l = F(s, r, t.innerType, o);
      s.write(`${c} = ${l};`);
    }), e.write("}");
  return c;
}
u(Fv, "generateDefaultCheck");
function Jv(e, r, i, o) {
  let t = i._zod.def, n = F(e, r, t.innerType, o), a = S(r);
  return e.write(`const ${a} = ${n};`), e.write(`if (${a} === undefined) return INVALID;`), a;
}
u(Jv, "generateNonOptionalCheck");
function Mv(e, r, i, o) {
  let t = i._zod.def, n = t.items, a = t.rest;
  e.write(`if (!Array.isArray(${o})) return INVALID;`);
  let c = Vd(n, "optin"), s = Vd(n, "optout");
  a ? e.write(`if (${o}.length < ${c}) return INVALID;`) : e.write(`if (${o}.length < ${c} || ${o}.length > ${n.length}) return INVALID;`);
  let l = S(r);
  e.write(`const ${l} = [];`);
  for (let d = 0; d < n.length; d++) {
    let m = n[d];
    if (d >= s)
      e.write(`if (${l}.length === ${d}) {`), e.indented((g) => {
        g.write(`if (${d} < ${o}.length) {`), g.indented((v) => {
          let $ = S(r);
          v.write(`const ${$} = ${o}[${d}];`);
          let k = Y(v, r, m, $);
          v.write(`${l}[${d}] = ${k};`);
        }), g.write("} else {"), g.indented((v) => {
          if ($c(m)) {
            v.write(`${l}.length = ${d};`);
            return;
          }
          let $ = S(r), k = S(r);
          v.write(`const ${$} = undefined;`), v.write(`const ${k} = (() => {`), v.indented((I) => {
            let A = Y(I, r, m, $);
            I.write(`return ${A};`);
          }), v.write("})();"), v.write(`if (${k} === INVALID || ${k} === undefined) ${l}.length = ${d};`), v.write(`else ${l}[${d}] = ${k};`);
        }), g.write("}");
      }), e.write("}");
    else {
      let g = S(r);
      e.write(`const ${g} = ${o}[${d}];`);
      let v = Y(e, r, m, g);
      e.write(`${l}[${d}] = ${v};`);
    }
  }
  if (a) {
    let d = S(r), m = S(r);
    e.write(`for (let ${d} = ${n.length}; ${d} < ${o}.length; ${d}++) {`), e.indented((g) => {
      g.write(`const ${m} = ${o}[${d}];`);
      let v = Y(g, r, a, m);
      g.write(`${l}[${d}] = ${v};`);
    }), e.write("}");
  }
  return l;
}
u(Mv, "generateTupleCheck");
function Vd(e, r) {
  for (let i = e.length - 1; i >= 0; i--)
    if (!(r === "optin" ? e[i]._zod.optin !== void 0 : e[i]._zod.optout === "optional"))
      return i + 1;
  return 0;
}
u(Vd, "getTupleOptStart");
function Kv(e, r, i, o) {
  let t = i._zod.def, n = t.options;
  if (t.discriminator)
    return Wv(e, r, t, o);
  if (t.inclusive === !1)
    throw new U("exclusive unions (z.xor)");
  if (n.length === 0)
    return e.write("return INVALID;"), o;
  if (n.length === 1)
    return F(e, r, n[0], o);
  if (n.every((s) => s._zod.def.type === "literal" && !s._zod.def.checks?.length)) {
    let s = new Set(n.flatMap((d) => d._zod.def.values)), l = z(r, s);
    return e.write(`if (!${l}.has(${o})) return INVALID;`), o;
  }
  let c = S(r);
  e.write(`let ${c};`);
  for (let s = 0; s < n.length; s++) {
    let l = n[s];
    s === 0 ? e.write(`${c} = (() => {`) : e.write(`if (${c} === INVALID) ${c} = (() => {`), e.indented((d) => {
      let m = F(d, r, l, o);
      d.write(`return ${m};`);
    }), e.write("})();");
  }
  return e.write(`if (${c} === INVALID) return INVALID;`), c;
}
u(Kv, "generateUnionCheck");
function Wv(e, r, i, o) {
  if (i.unionFallback)
    throw new U("discriminated union with unionFallback");
  if (i.options.length === 0)
    return e.write("return INVALID;"), o;
  let t = S(r), n = S(r);
  e.write(`const ${t} = ${o}?.[${Q(i.discriminator)}];`), e.write(`let ${n};`);
  let a = !0, c = /* @__PURE__ */ new Set();
  for (let s of i.options) {
    let l = s._zod.propValues?.[i.discriminator];
    if (!l || l.size === 0)
      throw new U("discriminated union option without static discriminator values");
    for (let g of l) {
      if (c.has(g))
        throw new U(`duplicate discriminator value ${String(g)}`);
      c.add(g);
    }
    let d = Array.from(l, (g) => Gv(r, t, g)), m = a ? "if" : "else if";
    e.write(`${m} (${d.join(" || ")}) {`), e.indented((g) => {
      let v = F(g, r, s, o);
      g.write(`${n} = ${v};`);
    }), e.write("}"), a = !1;
  }
  return e.write("else { return INVALID; }"), n;
}
u(Wv, "generateDiscriminatedUnionCheck");
function Gv(e, r, i) {
  if (typeof i == "string")
    return `${r} === ${Q(i)}`;
  if (typeof i == "number")
    return Number.isNaN(i) ? `Number.isNaN(${r})` : `${r} === ${i}`;
  if (typeof i == "boolean")
    return `${r} === ${i}`;
  if (i === null)
    return `${r} === null`;
  if (i === void 0)
    return `${r} === undefined`;
  if (typeof i == "bigint")
    return `${r} === ${i}n`;
  if (typeof i == "symbol") {
    let o = z(e, i);
    return `${r} === ${o}`;
  }
  throw new U(`literal discriminator value ${String(i)}`);
}
u(Gv, "literalEquality");
function Bv(e, r, i, o) {
  let t = i._zod.def, n = Y(e, r, t.left, o), a = Y(e, r, t.right, o), c = z(r, at), s = S(r);
  return e.write(`const ${s} = ${c}(${n}, ${a});`), e.write(`if (!${s}.valid) return INVALID;`), `${s}.data`;
}
u(Bv, "generateIntersectionCheck");
function qv(e, r, i, o) {
  let t = i._zod.def, n = z(r, se);
  e.write(`if (!${n}(${o})) return INVALID;`);
  let a = S(r), c = S(r), s = S(r);
  e.write(`const ${a} = {};`);
  let l = t, d = l.partial ? void 0 : t.keyType._zod.values;
  if (d) {
    let $ = [];
    for (let I of d) {
      if (!(typeof I == "string" || typeof I == "number" || typeof I == "symbol"))
        throw new U(`record key value ${String(I)}`);
      let A = typeof I == "number" ? I.toString() : I;
      if (A === "__proto__")
        throw new U('record key "__proto__"');
      $.push(A);
      let w = z(r, I), P = F(e, r, t.keyType, w), V = S(r);
      e.write(`const ${V} = ${o}[${Xv(r, A)}];`);
      let R = Y(e, r, t.valueType, V);
      e.write(`${a}[${P}] = ${R};`);
    }
    let k = z(r, new Set($));
    return e.write(`for (const ${c} in ${o}) {`), e.indented((I) => {
      I.write(`if (${k}.has(${c})) continue;`), l.mode === "loose" ? I.write(`if (${c} !== "__proto__") ${a}[${c}] = ${o}[${c}];`) : I.write("return INVALID;");
    }), e.write("}"), a;
  }
  let m = t.keyType._zod.def;
  if (!(m.type === "string" && m.format === void 0 && !m.coerce && (m.checks?.length ?? 0) === 0)) {
    let $ = t.mode === "loose", k = z(r, vn(t.keyType)), I = z(r, Ie), A = z(r, Object.prototype.propertyIsEnumerable), w = S(r);
    return e.write(`for (const ${c} of Reflect.ownKeys(${o})) {`), e.indented((P) => {
      P.write(`if (${c} === "__proto__") continue;`), P.write(`if (!${A}.call(${o}, ${c})) continue;`), P.write(`let ${w} = ${k}(${c});`), P.write(`if (${w} === INVALID && typeof ${c} === "string" && ${I}.test(${c})) ${w} = ${k}(Number(${c}));`), $ ? P.write(`if (${w} === INVALID) { ${a}[${c}] = ${o}[${c}]; continue; }`) : P.write(`if (${w} === INVALID) return INVALID;`), P.write(`if (${w} === "__proto__") continue;`);
      let V = S(r);
      P.write(`const ${V} = ${o}[${c}];`);
      let R = Y(P, r, t.valueType, V);
      P.write(`${a}[${w}] = ${R};`);
    }), e.write("}"), a;
  }
  let v = z(r, Object.prototype.propertyIsEnumerable);
  return e.write(`for (const ${c} of Reflect.ownKeys(${o})) {`), e.indented(($) => {
    $.write(`if (${c} === "__proto__") continue;`), $.write(`if (!${v}.call(${o}, ${c})) continue;`), $.write(`if (typeof ${c} !== "string") return INVALID;`), $.write(`const ${s} = ${o}[${c}];`);
    let k = Y($, r, t.valueType, s);
    $.write(`${a}[${c}] = ${k};`);
  }), e.write("}"), a;
}
u(qv, "generateRecordCheck");
function Xv(e, r) {
  return typeof r == "string" ? Q(r) : z(e, r);
}
u(Xv, "literalPropertyKey");
function Yv(e, r, i, o) {
  let t = i._zod.def;
  e.write(`if (!(${o} instanceof Map)) return INVALID;`);
  let n = S(r), a = S(r), c = S(r);
  return e.write(`const ${n} = new Map();`), e.write(`for (const [${a}, ${c}] of ${o}) {`), e.indented((s) => {
    let l = F(s, r, t.keyType, a), d = F(s, r, t.valueType, c);
    s.write(`${n}.set(${l}, ${d});`);
  }), e.write("}"), n;
}
u(Yv, "generateMapCheck");
function Hv(e, r, i, o) {
  let t = i._zod.def;
  e.write(`if (!(${o} instanceof Set)) return INVALID;`);
  let n = S(r), a = S(r);
  return e.write(`const ${n} = new Set();`), e.write(`for (const ${a} of ${o}) {`), e.indented((c) => {
    let s = F(c, r, t.valueType, a);
    c.write(`${n}.add(${s});`);
  }), e.write("}"), n;
}
u(Hv, "generateSetCheck");
function Qv(e, r) {
  return e.write(`if (!(${r} instanceof File)) return INVALID;`), r;
}
u(Qv, "generateFileCheck");
function e$(e, r, i, o) {
  e.write(`if (typeof ${o} !== "string") return INVALID;`);
  let t = i._zod.pattern;
  if (t) {
    let n = z(r, t);
    e.write(`${n}.lastIndex = 0;`), e.write(`if (!${n}.test(${o})) return INVALID;`);
  }
  return o;
}
u(e$, "generateTemplateLiteralCheck");
function t$(e, r, i, o) {
  let t = i._zod.def, n = z(r, t.getter), a = z(r, { parser: null });
  e.write(`if (!${a}.parser) {`), e.indented((s) => {
    s.write(`const inner = ${n}();`), s.write(`${a}.parser = function(input) {`), s.indented((l) => {
      l.write("const result = inner._zod.run({ value: input, issues: [] }, {});"), l.write("return result.issues.length === 0 ? result.value : INVALID;");
    }), s.write("};");
  }), e.write("}");
  let c = S(r);
  return e.write(`const ${c} = ${a}.parser(${o});`), e.write(`if (${c} === INVALID) return INVALID;`), c;
}
u(t$, "generateLazyCheck");
function r$(e, r, i, o) {
  let t = i._zod.def, n = F(e, r, t.in, o);
  if (t.transform) {
    if (Fe(t.transform))
      throw new me("z.compile: async transforms in pipes are not supported");
    let a = t.transform, s = z(r, /* @__PURE__ */ u((d) => {
      let m = { value: d, issues: [], addIssue: _c }, g = a(d, m);
      return g instanceof Promise ? ae : m.issues.length === 0 ? g : ae;
    }, "helperFn")), l = S(r);
    return e.write(`const ${l} = ${s}(${n});`), e.write(`if (${l} === INVALID) return INVALID;`), F(e, r, t.out, l);
  } else
    return F(e, r, t.out, n);
}
u(r$, "generatePipeCheck");
function Fe(e) {
  return typeof e == "function" && (e.constructor.name === "AsyncFunction" || e[Symbol.toStringTag] === "AsyncFunction");
}
u(Fe, "isAsyncFunction");
function n$(e, r, i, o) {
  let t = i._zod.def;
  if (t.fn) {
    if (Fe(t.fn))
      throw new me("z.compile: async custom predicates are not supported");
    let n = z(r, t.fn), a = z(r, vc), c = S(r);
    e.write(`const ${c} = ${n}(${o});`), e.write(`if (${c} instanceof Promise) ${a}();`), e.write(`if (!${c}) return INVALID;`);
  } else
    throw new U("custom schema without a predicate function");
  return o;
}
u(n$, "generateCustomCheck");
function i$(e, r, i) {
  let o = e._zod.run({ value: i, issues: [] }, {});
  if (o && typeof o.then == "function")
    return ae;
  let t = o;
  return t.issues.length === 0 ? t.value : r();
}
u(i$, "runtimeCatch");
function o$(e, r, i, o) {
  let t = i._zod.def;
  if (!t.catchValue[Sr])
    throw new U("catch with a callback (only a constant catch value compiles)", !1);
  let n = S(r);
  e.write(`let ${n} = (() => {`), e.indented((l) => {
    let d = Y(l, r, t.innerType, o);
    l.write(`return ${d};`);
  }), e.write("})();");
  let a = z(r, t.innerType), c = z(r, t.catchValue), s = z(r, i$);
  return e.write(`if (${n} === INVALID) {`), e.indented((l) => {
    l.write(`${n} = ${s}(${a}, ${c}, ${o});`), l.write(`if (${n} === INVALID) return INVALID;`);
  }), e.write("}"), n;
}
u(o$, "generateCatchCheck");
function a$(e, r, i, o) {
  let t = i._zod.def;
  if (t.transform) {
    if (Fe(t.transform))
      throw new me("z.compile: async transforms are not supported");
    let n = t.transform, c = z(r, /* @__PURE__ */ u((l) => {
      let d = { value: l, issues: [], addIssue: _c }, m = n(l, d);
      return m instanceof Promise ? ae : d.issues.length === 0 ? m : ae;
    }, "helperFn")), s = S(r);
    return e.write(`const ${s} = ${c}(${o});`), e.write(`if (${s} === INVALID) return INVALID;`), s;
  }
  return o;
}
u(a$, "generateTransformCheck");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/api.js
// @__NO_SIDE_EFFECTS__
function yc(e, r) {
  return new e({
    type: "string",
    ...b(r)
  });
}
u(yc, "_string");
// @__NO_SIDE_EFFECTS__
function bc(e, r) {
  return new e({
    type: "string",
    coerce: !0,
    ...b(r)
  });
}
u(bc, "_coercedString");
// @__NO_SIDE_EFFECTS__
function $n(e, r) {
  return new e({
    type: "string",
    format: "email",
    check: "string_format",
    abort: !1,
    ...b(r)
  });
}
u($n, "_email");
// @__NO_SIDE_EFFECTS__
function hn(e, r) {
  return new e({
    type: "string",
    format: "guid",
    check: "string_format",
    abort: !1,
    ...b(r)
  });
}
u(hn, "_guid");
// @__NO_SIDE_EFFECTS__
function _n(e, r) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    ...b(r)
  });
}
u(_n, "_uuid");
// @__NO_SIDE_EFFECTS__
function yn(e, r) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v4",
    ...b(r)
  });
}
u(yn, "_uuidv4");
// @__NO_SIDE_EFFECTS__
function bn(e, r) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v6",
    ...b(r)
  });
}
u(bn, "_uuidv6");
// @__NO_SIDE_EFFECTS__
function kn(e, r) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v7",
    ...b(r)
  });
}
u(kn, "_uuidv7");
// @__NO_SIDE_EFFECTS__
function ir(e, r) {
  return new e({
    type: "string",
    format: "url",
    check: "string_format",
    abort: !1,
    ...b(r)
  });
}
u(ir, "_url");
// @__NO_SIDE_EFFECTS__
function xn(e, r) {
  return new e({
    type: "string",
    format: "emoji",
    check: "string_format",
    abort: !1,
    ...b(r)
  });
}
u(xn, "_emoji");
// @__NO_SIDE_EFFECTS__
function In(e, r) {
  return new e({
    type: "string",
    format: "nanoid",
    check: "string_format",
    abort: !1,
    ...b(r)
  });
}
u(In, "_nanoid");
// @__NO_SIDE_EFFECTS__
function wn(e, r) {
  return new e({
    type: "string",
    format: "cuid",
    check: "string_format",
    abort: !1,
    ...b(r)
  });
}
u(wn, "_cuid");
// @__NO_SIDE_EFFECTS__
function zn(e, r) {
  return new e({
    type: "string",
    format: "cuid2",
    check: "string_format",
    abort: !1,
    ...b(r)
  });
}
u(zn, "_cuid2");
// @__NO_SIDE_EFFECTS__
function Sn(e, r) {
  return new e({
    type: "string",
    format: "ulid",
    check: "string_format",
    abort: !1,
    ...b(r)
  });
}
u(Sn, "_ulid");
// @__NO_SIDE_EFFECTS__
function jn(e, r) {
  return new e({
    type: "string",
    format: "xid",
    check: "string_format",
    abort: !1,
    ...b(r)
  });
}
u(jn, "_xid");
// @__NO_SIDE_EFFECTS__
function Pn(e, r) {
  return new e({
    type: "string",
    format: "ksuid",
    check: "string_format",
    abort: !1,
    ...b(r)
  });
}
u(Pn, "_ksuid");
// @__NO_SIDE_EFFECTS__
function Dn(e, r) {
  return new e({
    type: "string",
    format: "ipv4",
    check: "string_format",
    abort: !1,
    ...b(r)
  });
}
u(Dn, "_ipv4");
// @__NO_SIDE_EFFECTS__
function On(e, r) {
  return new e({
    type: "string",
    format: "ipv6",
    check: "string_format",
    abort: !1,
    ...b(r)
  });
}
u(On, "_ipv6");
// @__NO_SIDE_EFFECTS__
function kc(e, r) {
  return new e({
    type: "string",
    format: "mac",
    check: "string_format",
    abort: !1,
    ...b(r)
  });
}
u(kc, "_mac");
// @__NO_SIDE_EFFECTS__
function Un(e, r) {
  return new e({
    type: "string",
    format: "cidrv4",
    check: "string_format",
    abort: !1,
    ...b(r)
  });
}
u(Un, "_cidrv4");
// @__NO_SIDE_EFFECTS__
function Nn(e, r) {
  return new e({
    type: "string",
    format: "cidrv6",
    check: "string_format",
    abort: !1,
    ...b(r)
  });
}
u(Nn, "_cidrv6");
// @__NO_SIDE_EFFECTS__
function Tn(e, r) {
  return new e({
    type: "string",
    format: "base64",
    check: "string_format",
    abort: !1,
    ...b(r)
  });
}
u(Tn, "_base64");
// @__NO_SIDE_EFFECTS__
function Zn(e, r) {
  return new e({
    type: "string",
    format: "base64url",
    check: "string_format",
    abort: !1,
    ...b(r)
  });
}
u(Zn, "_base64url");
// @__NO_SIDE_EFFECTS__
function An(e, r) {
  return new e({
    type: "string",
    format: "e164",
    check: "string_format",
    abort: !1,
    ...b(r)
  });
}
u(An, "_e164");
// @__NO_SIDE_EFFECTS__
function xc(e, r) {
  return new e({
    type: "string",
    format: "credit_card",
    check: "string_format",
    abort: !1,
    ...b(r)
  });
}
u(xc, "_creditCard");
// @__NO_SIDE_EFFECTS__
function En(e, r) {
  return new e({
    type: "string",
    format: "jwt",
    check: "string_format",
    abort: !1,
    ...b(r)
  });
}
u(En, "_jwt");
var Ic = {
  Any: null,
  Minute: -1,
  Second: 0,
  Millisecond: 3,
  Microsecond: 6
};
// @__NO_SIDE_EFFECTS__
function or(e, r) {
  return new e({
    type: "string",
    format: "datetime",
    check: "string_format",
    offset: !1,
    local: !1,
    precision: null,
    ...b(r)
  });
}
u(or, "_isoDateTime");
// @__NO_SIDE_EFFECTS__
function ar(e, r) {
  return new e({
    type: "string",
    format: "date",
    check: "string_format",
    ...b(r)
  });
}
u(ar, "_isoDate");
// @__NO_SIDE_EFFECTS__
function ur(e, r) {
  return new e({
    type: "string",
    format: "time",
    check: "string_format",
    precision: null,
    ...b(r)
  });
}
u(ur, "_isoTime");
// @__NO_SIDE_EFFECTS__
function cr(e, r) {
  return new e({
    type: "string",
    format: "duration",
    check: "string_format",
    ...b(r)
  });
}
u(cr, "_isoDuration");
// @__NO_SIDE_EFFECTS__
function wc(e, r) {
  return new e({
    type: "number",
    checks: [],
    ...b(r)
  });
}
u(wc, "_number");
// @__NO_SIDE_EFFECTS__
function zc(e, r) {
  return new e({
    type: "number",
    coerce: !0,
    checks: [],
    ...b(r)
  });
}
u(zc, "_coercedNumber");
// @__NO_SIDE_EFFECTS__
function Sc(e, r) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "safeint",
    ...b(r)
  });
}
u(Sc, "_int");
// @__NO_SIDE_EFFECTS__
function jc(e, r) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "float32",
    ...b(r)
  });
}
u(jc, "_float32");
// @__NO_SIDE_EFFECTS__
function Pc(e, r) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "float64",
    ...b(r)
  });
}
u(Pc, "_float64");
// @__NO_SIDE_EFFECTS__
function Dc(e, r) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "int32",
    ...b(r)
  });
}
u(Dc, "_int32");
// @__NO_SIDE_EFFECTS__
function Oc(e, r) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "uint32",
    ...b(r)
  });
}
u(Oc, "_uint32");
// @__NO_SIDE_EFFECTS__
function Uc(e, r) {
  return new e({
    type: "boolean",
    ...b(r)
  });
}
u(Uc, "_boolean");
// @__NO_SIDE_EFFECTS__
function Nc(e, r) {
  return new e({
    type: "boolean",
    coerce: !0,
    ...b(r)
  });
}
u(Nc, "_coercedBoolean");
// @__NO_SIDE_EFFECTS__
function Tc(e, r) {
  return new e({
    type: "bigint",
    ...b(r)
  });
}
u(Tc, "_bigint");
// @__NO_SIDE_EFFECTS__
function Zc(e, r) {
  return new e({
    type: "bigint",
    coerce: !0,
    ...b(r)
  });
}
u(Zc, "_coercedBigint");
// @__NO_SIDE_EFFECTS__
function Ac(e, r) {
  return new e({
    type: "bigint",
    check: "bigint_format",
    abort: !1,
    format: "int64",
    ...b(r)
  });
}
u(Ac, "_int64");
// @__NO_SIDE_EFFECTS__
function Ec(e, r) {
  return new e({
    type: "bigint",
    check: "bigint_format",
    abort: !1,
    format: "uint64",
    ...b(r)
  });
}
u(Ec, "_uint64");
// @__NO_SIDE_EFFECTS__
function Cc(e, r) {
  return new e({
    type: "symbol",
    ...b(r)
  });
}
u(Cc, "_symbol");
// @__NO_SIDE_EFFECTS__
function Lc(e, r) {
  return new e({
    type: "undefined",
    ...b(r)
  });
}
u(Lc, "_undefined");
// @__NO_SIDE_EFFECTS__
function Vc(e, r) {
  return new e({
    type: "null",
    ...b(r)
  });
}
u(Vc, "_null");
// @__NO_SIDE_EFFECTS__
function Rc(e) {
  return new e({
    type: "any"
  });
}
u(Rc, "_any");
// @__NO_SIDE_EFFECTS__
function Fc(e) {
  return new e({
    type: "unknown"
  });
}
u(Fc, "_unknown");
// @__NO_SIDE_EFFECTS__
function Jc(e, r) {
  return new e({
    type: "never",
    ...b(r)
  });
}
u(Jc, "_never");
// @__NO_SIDE_EFFECTS__
function Mc(e, r) {
  return new e({
    type: "void",
    ...b(r)
  });
}
u(Mc, "_void");
// @__NO_SIDE_EFFECTS__
function Kc(e, r) {
  return new e({
    type: "date",
    ...b(r)
  });
}
u(Kc, "_date");
// @__NO_SIDE_EFFECTS__
function Wc(e, r) {
  return new e({
    type: "date",
    coerce: !0,
    ...b(r)
  });
}
u(Wc, "_coercedDate");
// @__NO_SIDE_EFFECTS__
function Gc(e, r) {
  return new e({
    type: "nan",
    ...b(r)
  });
}
u(Gc, "_nan");
// @__NO_SIDE_EFFECTS__
function pe(e, r) {
  return new Fr({
    check: "less_than",
    ...b(r),
    value: e,
    inclusive: !1
  });
}
u(pe, "_lt");
// @__NO_SIDE_EFFECTS__
function ue(e, r) {
  return new Fr({
    check: "less_than",
    ...b(r),
    value: e,
    inclusive: !0
  });
}
u(ue, "_lte");
// @__NO_SIDE_EFFECTS__
function ge(e, r) {
  return new Jr({
    check: "greater_than",
    ...b(r),
    value: e,
    inclusive: !1
  });
}
u(ge, "_gt");
// @__NO_SIDE_EFFECTS__
function ce(e, r) {
  return new Jr({
    check: "greater_than",
    ...b(r),
    value: e,
    inclusive: !0
  });
}
u(ce, "_gte");
// @__NO_SIDE_EFFECTS__
function Cn(e) {
  return /* @__PURE__ */ ge(0, e);
}
u(Cn, "_positive");
// @__NO_SIDE_EFFECTS__
function Ln(e) {
  return /* @__PURE__ */ pe(0, e);
}
u(Ln, "_negative");
// @__NO_SIDE_EFFECTS__
function Vn(e) {
  return /* @__PURE__ */ ue(0, e);
}
u(Vn, "_nonpositive");
// @__NO_SIDE_EFFECTS__
function Rn(e) {
  return /* @__PURE__ */ ce(0, e);
}
u(Rn, "_nonnegative");
// @__NO_SIDE_EFFECTS__
function we(e, r) {
  return new jo({
    check: "multiple_of",
    ...b(r),
    value: e
  });
}
u(we, "_multipleOf");
// @__NO_SIDE_EFFECTS__
function ze(e, r) {
  return new Oo({
    check: "max_size",
    ...b(r),
    maximum: e
  });
}
u(ze, "_maxSize");
// @__NO_SIDE_EFFECTS__
function ve(e, r) {
  return new Uo({
    check: "min_size",
    ...b(r),
    minimum: e
  });
}
u(ve, "_minSize");
// @__NO_SIDE_EFFECTS__
function Je(e, r) {
  return new No({
    check: "size_equals",
    ...b(r),
    size: e
  });
}
u(Je, "_size");
// @__NO_SIDE_EFFECTS__
function Me(e, r) {
  return new To({
    check: "max_length",
    ...b(r),
    maximum: e
  });
}
u(Me, "_maxLength");
// @__NO_SIDE_EFFECTS__
function _e(e, r) {
  return new Zo({
    check: "min_length",
    ...b(r),
    minimum: e
  });
}
u(_e, "_minLength");
// @__NO_SIDE_EFFECTS__
function Ke(e, r) {
  return new Ao({
    check: "length_equals",
    ...b(r),
    length: e
  });
}
u(Ke, "_length");
// @__NO_SIDE_EFFECTS__
function ct(e, r) {
  return new Eo({
    check: "string_format",
    format: "regex",
    ...b(r),
    pattern: e
  });
}
u(ct, "_regex");
// @__NO_SIDE_EFFECTS__
function st(e) {
  return new Co({
    check: "string_format",
    format: "lowercase",
    ...b(e)
  });
}
u(st, "_lowercase");
// @__NO_SIDE_EFFECTS__
function lt(e) {
  return new Lo({
    check: "string_format",
    format: "uppercase",
    ...b(e)
  });
}
u(lt, "_uppercase");
// @__NO_SIDE_EFFECTS__
function dt(e, r) {
  return new Vo({
    check: "string_format",
    format: "includes",
    ...b(r),
    includes: e
  });
}
u(dt, "_includes");
// @__NO_SIDE_EFFECTS__
function mt(e, r) {
  return new Ro({
    check: "string_format",
    format: "starts_with",
    ...b(r),
    prefix: e
  });
}
u(mt, "_startsWith");
// @__NO_SIDE_EFFECTS__
function ft(e, r) {
  return new Fo({
    check: "string_format",
    format: "ends_with",
    ...b(r),
    suffix: e
  });
}
u(ft, "_endsWith");
// @__NO_SIDE_EFFECTS__
function Fn(e, r, i) {
  return new Mr({
    check: "property",
    property: e,
    schema: r,
    ...b(i)
  });
}
u(Fn, "_property");
// @__NO_SIDE_EFFECTS__
function Jn(e) {
  return Object.entries(e).map(([r, i]) => new Mr({ check: "property", property: r, schema: i }));
}
u(Jn, "_properties");
// @__NO_SIDE_EFFECTS__
function pt(e, r) {
  return new Jo({
    check: "mime_type",
    mime: e,
    ...b(r)
  });
}
u(pt, "_mime");
// @__NO_SIDE_EFFECTS__
function fe(e) {
  return new Mo({
    check: "overwrite",
    tx: e
  });
}
u(fe, "_overwrite");
// @__NO_SIDE_EFFECTS__
function gt(e) {
  return /* @__PURE__ */ fe((r) => r.normalize(e));
}
u(gt, "_normalize");
// @__NO_SIDE_EFFECTS__
function vt() {
  return /* @__PURE__ */ fe((e) => e.trim());
}
u(vt, "_trim");
// @__NO_SIDE_EFFECTS__
function $t() {
  return /* @__PURE__ */ fe((e) => e.toLowerCase());
}
u($t, "_toLowerCase");
// @__NO_SIDE_EFFECTS__
function ht() {
  return /* @__PURE__ */ fe((e) => e.toUpperCase());
}
u(ht, "_toUpperCase");
// @__NO_SIDE_EFFECTS__
function _t() {
  return /* @__PURE__ */ fe((e) => Si(e));
}
u(_t, "_slugify");
// @__NO_SIDE_EFFECTS__
function Bc(e, r, i) {
  return new e({
    type: "array",
    element: r,
    // get element() {
    //   return element;
    // },
    ...b(i)
  });
}
u(Bc, "_array");
// @__NO_SIDE_EFFECTS__
function u$(e, r, i) {
  return new e({
    type: "union",
    options: r,
    ...b(i)
  });
}
u(u$, "_union");
function c$(e, r, i) {
  return new e({
    type: "union",
    options: r,
    inclusive: !1,
    ...b(i)
  });
}
u(c$, "_xor");
// @__NO_SIDE_EFFECTS__
function s$(e, r, i, o) {
  return new e({
    type: "union",
    options: i,
    discriminator: r,
    ...b(o)
  });
}
u(s$, "_discriminatedUnion");
// @__NO_SIDE_EFFECTS__
function l$(e, r, i) {
  return new e({
    type: "intersection",
    left: r,
    right: i
  });
}
u(l$, "_intersection");
// @__NO_SIDE_EFFECTS__
function d$(e, r, i, o) {
  let t = i instanceof j, n = t ? o : i, a = t ? i : null;
  return new e({
    type: "tuple",
    items: r,
    rest: a,
    ...b(n)
  });
}
u(d$, "_tuple");
// @__NO_SIDE_EFFECTS__
function m$(e, r, i, o) {
  return new e({
    type: "record",
    keyType: r,
    valueType: i,
    ...b(o)
  });
}
u(m$, "_record");
// @__NO_SIDE_EFFECTS__
function f$(e, r, i, o) {
  return new e({
    type: "map",
    keyType: r,
    valueType: i,
    ...b(o)
  });
}
u(f$, "_map");
// @__NO_SIDE_EFFECTS__
function p$(e, r, i) {
  return new e({
    type: "set",
    valueType: r,
    ...b(i)
  });
}
u(p$, "_set");
// @__NO_SIDE_EFFECTS__
function g$(e, r, i) {
  let o = Array.isArray(r) ? Object.fromEntries(r.map((t) => [t, t])) : r;
  return new e({
    type: "enum",
    entries: o,
    ...b(i)
  });
}
u(g$, "_enum");
// @__NO_SIDE_EFFECTS__
function v$(e, r, i) {
  return new e({
    type: "enum",
    entries: r,
    ...b(i)
  });
}
u(v$, "_nativeEnum");
// @__NO_SIDE_EFFECTS__
function $$(e, r, i) {
  return new e({
    type: "literal",
    values: Array.isArray(r) ? r : [r],
    ...b(i)
  });
}
u($$, "_literal");
// @__NO_SIDE_EFFECTS__
function qc(e, r) {
  return new e({
    type: "file",
    ...b(r)
  });
}
u(qc, "_file");
// @__NO_SIDE_EFFECTS__
function h$(e, r) {
  return new e({
    type: "transform",
    transform: r
  });
}
u(h$, "_transform");
// @__NO_SIDE_EFFECTS__
function _$(e, r) {
  return new e({
    type: "optional",
    innerType: r
  });
}
u(_$, "_optional");
// @__NO_SIDE_EFFECTS__
function y$(e, r) {
  return new e({
    type: "nullable",
    innerType: r
  });
}
u(y$, "_nullable");
// @__NO_SIDE_EFFECTS__
function b$(e, r, i) {
  return new e({
    type: "default",
    innerType: r,
    get defaultValue() {
      return typeof i == "function" ? i() : At(i);
    }
  });
}
u(b$, "_default");
// @__NO_SIDE_EFFECTS__
function k$(e, r, i) {
  return new e({
    type: "nonoptional",
    innerType: r,
    ...b(i)
  });
}
u(k$, "_nonoptional");
// @__NO_SIDE_EFFECTS__
function x$(e, r) {
  return new e({
    type: "success",
    innerType: r
  });
}
u(x$, "_success");
// @__NO_SIDE_EFFECTS__
function I$(e, r, i) {
  return new e({
    type: "catch",
    innerType: r,
    catchValue: typeof i == "function" ? i : Ai(i)
  });
}
u(I$, "_catch");
// @__NO_SIDE_EFFECTS__
function w$(e, r, i) {
  return new e({
    type: "pipe",
    in: r,
    out: i
  });
}
u(w$, "_pipe");
// @__NO_SIDE_EFFECTS__
function z$(e, r) {
  return new e({
    type: "readonly",
    innerType: r
  });
}
u(z$, "_readonly");
// @__NO_SIDE_EFFECTS__
function S$(e, r, i) {
  return new e({
    type: "template_literal",
    parts: r,
    ...b(i)
  });
}
u(S$, "_templateLiteral");
// @__NO_SIDE_EFFECTS__
function j$(e, r) {
  return new e({
    type: "lazy",
    getter: r
  });
}
u(j$, "_lazy");
// @__NO_SIDE_EFFECTS__
function P$(e, r) {
  return new e({
    type: "promise",
    innerType: r
  });
}
u(P$, "_promise");
// @__NO_SIDE_EFFECTS__
function Xc(e, r, i) {
  let o = b(i);
  return o.abort ?? (o.abort = !0), new e({
    type: "custom",
    check: "custom",
    fn: r,
    ...o
  });
}
u(Xc, "_custom");
// @__NO_SIDE_EFFECTS__
function Yc(e, r, i) {
  return new e({
    type: "custom",
    check: "custom",
    fn: r,
    ...b(i)
  });
}
u(Yc, "_refine");
// @__NO_SIDE_EFFECTS__
function Hc(e, r) {
  let i = /* @__PURE__ */ Md((o) => (o.addIssue = (t) => {
    if (typeof t == "string")
      o.issues.push(et(t, o.value, i._zod.def));
    else {
      let n = t;
      n.fatal && (n.continue = !1), n.code ?? (n.code = "custom"), "input" in n || (n.input = o.value), n.inst ?? (n.inst = i), n.continue ?? (n.continue = !i._zod.def.abort), o.issues.push(et(n));
    }
  }, e(o.value, o)), r);
  return i;
}
u(Hc, "_superRefine");
// @__NO_SIDE_EFFECTS__
function Md(e, r) {
  let i = new L({
    check: "custom",
    ...b(r)
  });
  return i._zod.check = e, i;
}
u(Md, "_check");
// @__NO_SIDE_EFFECTS__
function Qc(e) {
  let r = new L({ check: "describe" });
  return r._zod.onattach = [
    (i) => {
      let o = B.get(i) ?? {};
      B.add(i, { ...o, description: e });
    }
  ], r._zod.check = () => {
  }, r;
}
u(Qc, "describe");
// @__NO_SIDE_EFFECTS__
function es(e) {
  let r = new L({ check: "meta" });
  return r._zod.onattach = [
    (i) => {
      let o = B.get(i) ?? {};
      B.add(i, { ...o, ...e });
    }
  ], r._zod.check = () => {
  }, r;
}
u(es, "meta");
// @__NO_SIDE_EFFECTS__
function ts(e, r) {
  let i = b(r), o = i.truthy ?? ["true", "1", "yes", "on", "y", "enabled"], t = i.falsy ?? ["false", "0", "no", "off", "n", "disabled"];
  i.case !== "sensitive" && (o = o.map((v) => typeof v == "string" ? v.toLowerCase() : v), t = t.map((v) => typeof v == "string" ? v.toLowerCase() : v));
  let n = new Set(o), a = new Set(t), c = e.Codec ?? Xt, s = e.Boolean ?? Bt, l = e.String ?? Ce, d = new l({ type: "string", error: i.error }), m = new s({ type: "boolean", error: i.error }), g = new c({
    type: "pipe",
    in: d,
    out: m,
    transform: /* @__PURE__ */ u(((v, $) => {
      let k = v;
      return i.case !== "sensitive" && (k = k.toLowerCase()), n.has(k) ? !0 : a.has(k) ? !1 : ($.issues.push({
        code: "invalid_value",
        expected: "stringbool",
        values: [...n, ...a],
        input: $.value,
        inst: g,
        continue: !1
      }), {});
    }), "transform"),
    reverseTransform: /* @__PURE__ */ u(((v, $) => v === !0 ? o[0] || "true" : t[0] || "false"), "reverseTransform"),
    error: i.error
  });
  return g._zod.bag.truthy = o, g._zod.bag.falsy = t, g._zod.bag.case = i.case ?? "insensitive", g;
}
u(ts, "_stringbool");
// @__NO_SIDE_EFFECTS__
function yt(e, r, i, o = {}) {
  let t = b(o), n = {
    check: "string_format",
    type: "string",
    format: r,
    fn: typeof i == "function" ? i : (c) => i.test(c),
    ...t
  };
  return i instanceof RegExp && (n.pattern = i), new e(n);
}
u(yt, "_stringFormat");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/to-json-schema.js
function sr(e, ...r) {
  for (let i of r)
    for (let o of Reflect.ownKeys(i))
      Object.prototype.propertyIsEnumerable.call(i, o) && J(e, o, i[o]);
  return e;
}
u(sr, "assignProps");
function Se(e) {
  let r = e?.target ?? "draft-2020-12";
  return r === "draft-4" && (r = "draft-04"), r === "draft-7" && (r = "draft-07"), {
    processors: e.processors ?? {},
    metadataRegistry: e?.metadata ?? B,
    target: r,
    unrepresentable: e?.unrepresentable ?? "throw",
    override: e?.override ?? (() => {
    }),
    io: e?.io ?? "output",
    counter: 0,
    seen: /* @__PURE__ */ new Map(),
    sharedDefsExtractedFor: void 0,
    sharedEmitDoneFor: void 0,
    cycles: e?.cycles ?? "ref",
    reused: e?.reused ?? "inline",
    intersections: [],
    deferred: [],
    external: e?.external ?? void 0
  };
}
u(Se, "initializeContext");
function K(e, r, i, o, t) {
  let n = typeof r.unrepresentable == "function" ? r.unrepresentable({ zodSchema: e, path: o.path, message: t }) : r.unrepresentable;
  if (n === "any")
    return !1;
  if (n === void 0 || n === "throw")
    throw new Error(t);
  return Object.assign(i, n), !0;
}
u(K, "handleUnrepresentable");
function Z(e, r, i = { path: [], schemaPath: [] }) {
  var o;
  let t = e._zod.def, n = r.seen.get(e);
  if (n)
    return n.count++, i.schemaPath.includes(e) && (n.cycle = i.path), n.schema;
  let a = { schema: {}, count: 1, cycle: void 0, path: i.path };
  r.seen.set(e, a), r.sharedDefsExtractedFor = void 0, r.sharedEmitDoneFor = void 0;
  let c = e._zod.toJSONSchema?.();
  if (c)
    a.schema = c;
  else {
    let d = {
      ...i,
      schemaPath: [...i.schemaPath, e],
      path: i.path
    };
    if (e._zod.processJSONSchema)
      e._zod.processJSONSchema(r, a.schema, d);
    else {
      let g = a.schema, v = r.processors[t.type];
      if (!v)
        throw new Error(`[toJSONSchema]: Non-representable type encountered: ${t.type}`);
      v(e, r, g, d);
    }
    let m = e._zod.parent;
    m && (a.ref || (a.ref = m), Z(m, r, d), r.seen.get(m).isParent = !0);
  }
  let s = r.metadataRegistry.get(e);
  return s && sr(a.schema, s), r.io === "input" && H(e) && (delete a.schema.examples, delete a.schema.default), r.io === "input" && "_prefault" in a.schema && ((o = a.schema).default ?? (o.default = a.schema._prefault)), delete a.schema._prefault, r.seen.get(e).schema;
}
u(Z, "process");
function Kd(e) {
  return e.replace(/~/g, "~0").replace(/\//g, "~1");
}
u(Kd, "encodeJSONPointerSegment");
function je(e, r) {
  let i = e.seen.get(r);
  if (!i)
    throw new Error("Unprocessed schema. This is a bug in Zod.");
  if (e.external && e.sharedDefsExtractedFor === e.external)
    return;
  let o = /* @__PURE__ */ new Map();
  for (let a of e.seen.entries()) {
    let c = e.metadataRegistry.get(a[0])?.id;
    if (c) {
      let s = o.get(c);
      if (s && s !== a[0])
        throw new Error(`Duplicate schema id "${c}" detected during JSON Schema conversion. Two different schemas cannot share the same id when converted together.`);
      o.set(c, a[0]);
    }
  }
  let t = /* @__PURE__ */ u((a) => {
    let c = e.target === "draft-2020-12" ? "$defs" : "definitions";
    if (e.external) {
      let m = e.external.registry.get(a[0])?.id, g = e.external.uri ?? (($) => $);
      if (m)
        return { ref: g(m) };
      let v = a[1].defId ?? a[1].schema.id ?? `schema${e.counter++}`;
      return a[1].defId = v, { defId: v, ref: `${g("__shared")}#/${c}/${Kd(v)}` };
    }
    let s = "#", l = `${s}/${c}/`;
    if (a[1] === i && !a[1].schema.id)
      return { ref: s };
    let d = a[1].schema.id ?? `__schema${e.counter++}`;
    return { defId: d, ref: l + Kd(d) };
  }, "makeURI"), n = /* @__PURE__ */ u((a) => {
    if (a[1].schema.$ref)
      return;
    let c = a[1], { ref: s, defId: l } = t(a);
    c.def = { ...c.schema }, l && (c.defId = l);
    let d = c.schema;
    for (let m in d)
      delete d[m];
    d.$ref = s;
  }, "extractToDef");
  if (e.cycles === "throw")
    for (let a of e.seen.entries()) {
      let c = a[1];
      if (c.cycle)
        throw new Error(`Cycle detected: #/${c.cycle?.join("/")}/<root>

Set the \`cycles\` parameter to \`"ref"\` to resolve cyclical schemas with defs.`);
    }
  for (let a of e.seen.entries()) {
    let c = a[1];
    if (r === a[0]) {
      n(a);
      continue;
    }
    if (e.external) {
      let l = e.external.registry.get(a[0])?.id;
      if (r !== a[0] && l) {
        n(a);
        continue;
      }
    }
    if (e.metadataRegistry.get(a[0])?.id) {
      n(a);
      continue;
    }
    if (c.cycle) {
      n(a);
      continue;
    }
    if (c.count > 1 && e.reused === "ref") {
      n(a);
      continue;
    }
  }
  e.external && (e.sharedDefsExtractedFor = e.external);
}
u(je, "extractDefs");
function Bd(e) {
  let r = e.anyOf;
  if (!Array.isArray(r) || r.length === 0 || e.type !== void 0)
    return;
  let i = [];
  for (let o of r) {
    if (!o || typeof o != "object")
      return;
    Bd(o);
    let t = Object.keys(o);
    if (t.length !== 1 || t[0] !== "type")
      return;
    let n = o.type;
    for (let a of Array.isArray(n) ? n : [n]) {
      if (typeof a != "string")
        return;
      i.includes(a) || i.push(a);
    }
  }
  delete e.anyOf, e.type = i.length === 1 ? i[0] : i;
}
u(Bd, "compactTypeUnion");
var qd = /* @__PURE__ */ new Set(["type", "properties", "required", "additionalProperties"]), Wd = ["oneOf", "anyOf"];
function Gd(e) {
  let r = e.additionalProperties;
  return r === void 0 || r === !1 || typeof r != "object" || r === null ? null : Object.keys(r).length ? r : null;
}
u(Gd, "undeclaredConstraint");
function rs(e) {
  let r = [];
  for (let n of e) {
    if (typeof n != "object" || n.type !== "object")
      return null;
    for (let a in n)
      if (!qd.has(a))
        return null;
    r.push(n);
  }
  let i = {}, o = /* @__PURE__ */ new Set();
  for (let n of r) {
    for (let a in n.properties) {
      if (Object.prototype.hasOwnProperty.call(i, a))
        continue;
      let c = [];
      for (let l of r) {
        let d = l.properties?.[a] ?? Gd(l);
        d != null && (c.some((m) => JSON.stringify(m) === JSON.stringify(d)) || c.push(d));
      }
      let s = c.length === 1 ? c[0] : rs(c) ?? { allOf: c };
      J(i, a, s);
    }
    for (let a of n.required ?? [])
      o.add(a);
  }
  let t = { type: "object", properties: i };
  if (o.size && (t.required = [...o]), r.every((n) => n.additionalProperties === !1))
    t.additionalProperties = !1;
  else {
    let n = [];
    for (let a of r) {
      let c = Gd(a);
      c && !n.some((s) => JSON.stringify(s) === JSON.stringify(c)) && n.push(c);
    }
    n.length === 1 ? t.additionalProperties = n[0] : n.length > 1 && (t.additionalProperties = { allOf: n });
  }
  return t;
}
u(rs, "foldObjects");
function D$(e) {
  let r = e.allOf;
  if (!Array.isArray(r) || r.length < 2)
    return;
  for (let t of qd)
    if (t in e)
      return;
  let i = r.filter((t) => Wd.some((n) => Array.isArray(t[n]))), o = null;
  if (!i.length)
    o = rs(r);
  else {
    let t = i[0], n = Wd.find((s) => Array.isArray(t[s]));
    if (Object.keys(t).length !== 1)
      return;
    let a = r.filter((s) => s !== t), c = t[n].map((s) => rs([...a, s]));
    if (c.some((s) => !s))
      return;
    o = { [n]: c };
  }
  o && (delete e.allOf, sr(e, o));
}
u(D$, "foldIntersection");
function Pe(e, r) {
  let i = e.seen.get(r);
  if (!i)
    throw new Error("Unprocessed schema. This is a bug in Zod.");
  let o = /* @__PURE__ */ u((c) => {
    let s = e.seen.get(c);
    if (s.ref === null)
      return;
    let l = s.def ?? s.schema, d = { ...l }, m = s.ref;
    if (s.ref = null, m) {
      o(m);
      let v = e.seen.get(m), $ = v.schema;
      if ($.$ref && (e.target === "draft-07" || e.target === "draft-04" || e.target === "openapi-3.0") ? (l.allOf = l.allOf ?? [], l.allOf.push($)) : sr(l, $), sr(l, d), c._zod.parent === m)
        for (let I in l)
          I === "$ref" || I === "allOf" || I in d || delete l[I];
      if ($.$ref && v.def)
        for (let I in l)
          I === "$ref" || I === "allOf" || I in v.def && JSON.stringify(l[I]) === JSON.stringify(v.def[I]) && delete l[I];
    }
    let g = c._zod.parent;
    if (g && g !== m) {
      o(g);
      let v = e.seen.get(g);
      if (v?.schema.$ref && (l.$ref = v.schema.$ref, v.def))
        for (let $ in l)
          $ === "$ref" || $ === "allOf" || $ in v.def && JSON.stringify(l[$]) === JSON.stringify(v.def[$]) && delete l[$];
    }
    e.override({
      zodSchema: c,
      jsonSchema: l,
      path: s.path ?? []
    });
  }, "flattenRef");
  if (!e.external || e.sharedEmitDoneFor !== e.external) {
    for (let c of [...e.seen.entries()].reverse())
      o(c[0]);
    if (e.target !== "openapi-3.0")
      for (let c of e.seen.entries())
        Bd(c[1].def ?? c[1].schema);
    for (let c of e.deferred)
      c();
    if (e.intersections.length) {
      let c = /* @__PURE__ */ new Map();
      for (let s of e.seen.values())
        for (let l of [s.schema, s.def]) {
          let d = l?.allOf;
          if (!Array.isArray(d))
            continue;
          let m = c.get(d);
          m ? m.push(l) : c.set(d, [l]);
        }
      for (let s of e.intersections)
        for (let l of c.get(s) ?? [])
          D$(l);
    }
  }
  let t = {};
  if (e.target === "draft-2020-12" ? t.$schema = "https://json-schema.org/draft/2020-12/schema" : e.target === "draft-07" ? t.$schema = "http://json-schema.org/draft-07/schema#" : e.target === "draft-04" ? t.$schema = "http://json-schema.org/draft-04/schema#" : e.target, e.external?.uri) {
    let c = e.external.registry.get(r)?.id;
    if (!c)
      throw new Error("Schema is missing an `id` property");
    t.$id = e.external.uri(c);
  }
  sr(t, i.defId ? i.schema : i.def ?? i.schema);
  let n = e.metadataRegistry.get(r)?.id;
  n !== void 0 && t.id === n && delete t.id;
  let a = e.external?.defs ?? {};
  if (!e.external || e.sharedEmitDoneFor !== e.external)
    for (let c of e.seen.entries()) {
      let s = c[1];
      s.def && s.defId && (s.def.id === s.defId && delete s.def.id, J(a, s.defId, s.def));
    }
  e.external && (e.sharedEmitDoneFor = e.external), e.external || Object.keys(a).length > 0 && (e.target === "draft-2020-12" ? t.$defs = a : t.definitions = a);
  try {
    let c = JSON.parse(JSON.stringify(t));
    return Object.defineProperty(c, "~standard", {
      value: {
        ...r["~standard"],
        jsonSchema: {
          input: bt(r, "input", e.processors),
          output: bt(r, "output", e.processors)
        }
      },
      enumerable: !1,
      writable: !1
    }), c;
  } catch {
    throw new Error("Error converting schema to JSON.");
  }
}
u(Pe, "finalize");
function H(e, r) {
  let i = r ?? { seen: /* @__PURE__ */ new Set() };
  if (i.seen.has(e))
    return !1;
  i.seen.add(e);
  let o = e._zod.def;
  if (o.type === "transform")
    return !0;
  if (o.type === "array")
    return H(o.element, i);
  if (o.type === "set")
    return H(o.valueType, i);
  if (o.type === "lazy")
    return H(o.getter(), i);
  if (o.type === "promise" || o.type === "optional" || o.type === "nonoptional" || o.type === "nullable" || o.type === "readonly" || o.type === "default" || o.type === "prefault" || o.type === "catch")
    return H(o.innerType, i);
  if (o.type === "intersection")
    return H(o.left, i) || H(o.right, i);
  if (o.type === "record" || o.type === "map")
    return H(o.keyType, i) || H(o.valueType, i);
  if (o.type === "pipe")
    return e._zod.traits.has("$ZodCodec") ? !0 : H(o.in, i) || H(o.out, i);
  if (o.type === "object") {
    for (let t in o.shape)
      if (H(o.shape[t], i))
        return !0;
    return !1;
  }
  if (o.type === "union") {
    for (let t of o.options)
      if (H(t, i))
        return !0;
    return !1;
  }
  if (o.type === "tuple") {
    for (let t of o.items)
      if (H(t, i))
        return !0;
    return !!(o.rest && H(o.rest, i));
  }
  return !1;
}
u(H, "isTransforming");
var ns = /* @__PURE__ */ u((e, r = {}) => (i) => {
  let o = Se({ ...i, processors: r });
  return Z(e, o), je(o, e), Pe(o, e);
}, "createToJSONSchemaMethod"), bt = /* @__PURE__ */ u((e, r, i = {}) => (o) => {
  let { libraryOptions: t, target: n } = o ?? {}, a = Se({ ...t ?? {}, target: n, io: r, processors: i });
  return Z(e, a), je(a, e), Pe(a, e);
}, "createStandardJSONSchemaMethod");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/json-schema-processors.js
var O$ = {
  guid: "uuid",
  url: "uri",
  datetime: "date-time",
  json_string: "json-string",
  regex: ""
  // do not set
}, as = /* @__PURE__ */ u((e, r, i, o) => {
  let t = i;
  t.type = "string";
  let { minimum: n, maximum: a, format: c, patterns: s, contentEncoding: l, laxFormat: d } = e._zod.bag;
  if (typeof n == "number" && (t.minLength = n), typeof a == "number" && (t.maxLength = a), c && (t.format = O$[c] ?? c, t.format === "" && delete t.format, (c === "time" || d) && delete t.format), l && (t.contentEncoding = l), s && s.size > 0) {
    let m = [...s];
    m.length === 1 ? t.pattern = m[0].source : m.length > 1 && (t.allOf = [
      ...m.map((g) => ({
        ...r.target === "draft-07" || r.target === "draft-04" || r.target === "openapi-3.0" ? { type: "string" } : {},
        pattern: g.source
      }))
    ]);
  }
}, "stringProcessor"), us = /* @__PURE__ */ u((e, r, i, o) => {
  let t = i, { minimum: n, maximum: a, format: c, multipleOf: s, exclusiveMaximum: l, exclusiveMinimum: d } = e._zod.bag;
  typeof c == "string" && c.includes("int") ? t.type = "integer" : t.type = "number";
  let m = typeof d == "number" && d >= (n ?? Number.NEGATIVE_INFINITY), g = typeof l == "number" && l <= (a ?? Number.POSITIVE_INFINITY), v = r.target === "draft-04" || r.target === "openapi-3.0";
  m ? v ? (t.minimum = d, t.exclusiveMinimum = !0) : t.exclusiveMinimum = d : typeof n == "number" && (t.minimum = n), g ? v ? (t.maximum = l, t.exclusiveMaximum = !0) : t.exclusiveMaximum = l : typeof a == "number" && (t.maximum = a), typeof s == "number" && (Number.isFinite(s) && s !== 0 ? t.multipleOf = Math.abs(s) : K(e, r, t, o, `A multipleOf divisor of ${s} cannot be represented in JSON Schema`));
}, "numberProcessor"), cs = /* @__PURE__ */ u((e, r, i, o) => {
  i.type = "boolean";
}, "booleanProcessor"), ss = /* @__PURE__ */ u((e, r, i, o) => {
  K(e, r, i, o, "BigInt cannot be represented in JSON Schema");
}, "bigintProcessor"), ls = /* @__PURE__ */ u((e, r, i, o) => {
  K(e, r, i, o, "Symbols cannot be represented in JSON Schema");
}, "symbolProcessor"), ds = /* @__PURE__ */ u((e, r, i, o) => {
  r.target === "openapi-3.0" ? (i.type = "string", i.nullable = !0, i.enum = [null]) : i.type = "null";
}, "nullProcessor"), ms = /* @__PURE__ */ u((e, r, i, o) => {
  K(e, r, i, o, "Undefined cannot be represented in JSON Schema");
}, "undefinedProcessor"), fs = /* @__PURE__ */ u((e, r, i, o) => {
  K(e, r, i, o, "Void cannot be represented in JSON Schema");
}, "voidProcessor"), ps = /* @__PURE__ */ u((e, r, i, o) => {
  i.not = {};
}, "neverProcessor"), gs = /* @__PURE__ */ u((e, r, i, o) => {
}, "anyProcessor"), vs = /* @__PURE__ */ u((e, r, i, o) => {
}, "unknownProcessor"), $s = /* @__PURE__ */ u((e, r, i, o) => {
  K(e, r, i, o, "Date cannot be represented in JSON Schema");
}, "dateProcessor"), hs = /* @__PURE__ */ u((e, r, i, o) => {
  let t = e._zod.def, n = Nt(t.entries);
  if (n.length === 0) {
    i.not = {};
    return;
  }
  n.every((a) => typeof a == "number") && (i.type = "number"), n.every((a) => typeof a == "string") && (i.type = "string"), i.enum = n;
}, "enumProcessor"), _s = /* @__PURE__ */ u((e, r, i, o) => {
  let t = e._zod.def;
  if (t.values.length === 0) {
    i.not = {};
    return;
  }
  let n = [];
  for (let a of t.values)
    if (a === void 0) {
      if (K(e, r, i, o, "Literal `undefined` cannot be represented in JSON Schema"))
        return;
    } else if (typeof a == "bigint") {
      if (K(e, r, i, o, "BigInt literals cannot be represented in JSON Schema"))
        return;
      n.push(Number(a));
    } else
      n.push(a);
  if (n.length !== 0)
    if (n.length === 1) {
      let a = n[0];
      i.type = a === null ? "null" : typeof a, r.target === "draft-04" || r.target === "openapi-3.0" ? i.enum = [a] : i.const = a;
    } else
      n.every((a) => typeof a == "number") && (i.type = "number"), n.every((a) => typeof a == "string") && (i.type = "string"), n.every((a) => typeof a == "boolean") && (i.type = "boolean"), n.every((a) => a === null) && (i.type = "null"), i.enum = n;
}, "literalProcessor"), ys = /* @__PURE__ */ u((e, r, i, o) => {
  K(e, r, i, o, "NaN cannot be represented in JSON Schema");
}, "nanProcessor"), bs = /* @__PURE__ */ u((e, r, i, o) => {
  let t = i, n = e._zod.pattern;
  if (!n)
    throw new Error("Pattern not found in template literal");
  t.type = "string", t.pattern = n.source;
}, "templateLiteralProcessor"), ks = /* @__PURE__ */ u((e, r, i, o) => {
  let t = i, n = {
    type: "string",
    format: "binary",
    contentEncoding: "binary"
  }, { minimum: a, maximum: c, mime: s } = e._zod.bag;
  a !== void 0 && (n.minLength = a), c !== void 0 && (n.maxLength = c), s ? s.length === 1 ? (n.contentMediaType = s[0], Object.assign(t, n)) : (Object.assign(t, n), t.anyOf = s.map((l) => ({ contentMediaType: l }))) : Object.assign(t, n);
}, "fileProcessor"), xs = /* @__PURE__ */ u((e, r, i, o) => {
  i.type = "boolean";
}, "successProcessor"), Is = /* @__PURE__ */ u((e, r, i, o) => {
  K(e, r, i, o, "Custom types cannot be represented in JSON Schema");
}, "customProcessor"), ws = /* @__PURE__ */ u((e, r, i, o) => {
  K(e, r, i, o, "Function types cannot be represented in JSON Schema");
}, "functionProcessor"), zs = /* @__PURE__ */ u((e, r, i, o) => {
  K(e, r, i, o, "Transforms cannot be represented in JSON Schema");
}, "transformProcessor"), Ss = /* @__PURE__ */ u((e, r, i, o) => {
  K(e, r, i, o, "Map cannot be represented in JSON Schema");
}, "mapProcessor"), js = /* @__PURE__ */ u((e, r, i, o) => {
  K(e, r, i, o, "Set cannot be represented in JSON Schema");
}, "setProcessor"), Ps = /* @__PURE__ */ u((e, r, i, o) => {
  let t = i, n = e._zod.def, { minimum: a, maximum: c } = e._zod.bag;
  typeof a == "number" && (t.minItems = a), typeof c == "number" && (t.maxItems = c), t.type = "array", t.items = Z(n.element, r, {
    ...o,
    path: [...o.path, "items"]
  });
}, "arrayProcessor");
function lr(e) {
  let r = e._zod.def;
  return r.type === "pipe" && r.in._zod.traits.has("$ZodTransform") ? lr(r.out) : r.type === "catch" ? lr(r.innerType) : e._zod.optin;
}
u(lr, "inputOptin");
var Ds = /* @__PURE__ */ u((e, r, i, o) => {
  let t = i, n = e._zod.def, a = n.shape;
  if (Object.getOwnPropertySymbols(a).length && K(e, r, t, o, "Symbol keys cannot be represented in JSON Schema"))
    return;
  t.type = "object", t.properties = {};
  for (let d in a)
    J(t.properties, d, Z(a[d], r, {
      ...o,
      path: [...o.path, "properties", d]
    }));
  let s = new Set(Object.keys(a)), l = new Set([...s].filter((d) => {
    let m = n.shape[d];
    return r.io === "input" ? lr(m) === void 0 : m._zod.optout === void 0;
  }));
  l.size > 0 && (t.required = Array.from(l)), n.catchall?._zod.def.type === "never" ? t.additionalProperties = !1 : n.catchall ? n.catchall && (t.additionalProperties = Z(n.catchall, r, {
    ...o,
    path: [...o.path, "additionalProperties"]
  })) : r.io === "output" && (t.additionalProperties = !1);
}, "objectProcessor"), Kn = /* @__PURE__ */ u((e, r, i, o) => {
  let t = e._zod.def, n = t.inclusive === !1, a = t.options.map((c, s) => Z(c, r, {
    ...o,
    path: [...o.path, n ? "oneOf" : "anyOf", s]
  }));
  n ? i.oneOf = a : i.anyOf = a;
}, "unionProcessor"), Os = /* @__PURE__ */ u((e, r, i, o) => {
  let t = e._zod.def, n = Z(t.left, r, {
    ...o,
    path: [...o.path, "allOf", 0]
  }), a = Z(t.right, r, {
    ...o,
    path: [...o.path, "allOf", 1]
  }), c = /* @__PURE__ */ u((l) => "allOf" in l && Object.keys(l).length === 1, "isSimpleIntersection"), s = [
    ...c(n) ? n.allOf : [n],
    ...c(a) ? a.allOf : [a]
  ];
  i.allOf = s, r.intersections.push(s);
}, "intersectionProcessor"), Us = /* @__PURE__ */ u((e, r, i, o) => {
  let t = i, n = e._zod.def;
  t.type = "array";
  let a = r.target === "draft-2020-12" ? "prefixItems" : "items", c = r.target === "draft-2020-12" || r.target === "openapi-3.0" ? "items" : "additionalItems", s = n.items.map((k, I) => Z(k, r, {
    ...o,
    path: [...o.path, a, I]
  })), l = n.rest ? Z(n.rest, r, {
    ...o,
    path: [...o.path, c, ...r.target === "openapi-3.0" ? [n.items.length] : []]
  }) : null, d = n.items.length;
  for (; d > 0; ) {
    let k = n.items[d - 1];
    if (!(r.io === "input" ? lr(k) !== void 0 : k._zod.optout === "optional"))
      break;
    d--;
  }
  let m = n.items.length, g = !n.rest;
  r.target === "draft-2020-12" ? (t.prefixItems = s, g ? t.items = !1 : l && (t.items = l), d > 0 && (t.minItems = d), g && (t.maxItems = m)) : r.target === "openapi-3.0" ? (t.items = {
    anyOf: s
  }, l && t.items.anyOf.push(l), d > 0 && (t.minItems = d), g && (t.maxItems = m)) : (t.items = s, g ? t.additionalItems = !1 : l && (t.additionalItems = l), d > 0 && (t.minItems = d), g && (t.maxItems = m));
  let { minimum: v, maximum: $ } = e._zod.bag;
  typeof v == "number" && (t.minItems = v), typeof $ == "number" && (t.maxItems = $);
}, "tupleProcessor");
function is(e, r, i) {
  if (r.$ref) {
    if (i.has(r))
      return r;
    i.add(r);
    let $ = e.get(r)?.def;
    if (!$)
      return r;
    let k = is(e, $, i);
    return k === $ ? r : k;
  }
  for (let $ of ["anyOf", "oneOf"]) {
    let k = r[$];
    if (!Array.isArray(k))
      continue;
    let I = k.map((A) => is(e, A, i));
    I.some((A, w) => A !== k[w]) && (r = { ...r, [$]: I });
  }
  let o = Array.isArray(r.type) ? r.type : [r.type], t = !o.includes("string") && o.some(($) => $ === "number" || $ === "integer"), n = r.enum ?? (r.const !== void 0 ? [r.const] : void 0);
  if (!t && !n?.some(($) => typeof $ == "number"))
    return r;
  let { minimum: a, maximum: c, exclusiveMinimum: s, exclusiveMaximum: l, multipleOf: d, format: m, id: g, ...v } = r;
  return v.enum ? v.enum = v.enum.map(($) => typeof $ == "number" ? String($) : $) : typeof v.const == "number" && (v.const = String(v.const)), t && (v.type = "string", n || (v.pattern = (o.includes("number") ? Ie : Jt).source)), v;
}
u(is, "stringifyKeyNames");
var os = /* @__PURE__ */ new WeakMap();
function U$(e) {
  let r = /* @__PURE__ */ new Map();
  for (let o of e.seen.values())
    o.def && !r.has(o.schema) && r.set(o.schema, o);
  let i = /* @__PURE__ */ new Map();
  for (let o of os.get(e) ?? []) {
    let t = e.seen.get(o), n = (t?.def ?? t?.schema)?.propertyNames;
    if (!n || n === !0 || i.has(n))
      continue;
    let a = is(r, n, /* @__PURE__ */ new Set());
    a !== n && i.set(n, a);
  }
  if (i.size)
    for (let o of e.seen.values())
      for (let t of [o.schema, o.def]) {
        let n = t && i.get(t.propertyNames);
        n && (t.propertyNames = n);
      }
}
u(U$, "rewriteKeyNames");
var Ns = /* @__PURE__ */ u((e, r, i, o) => {
  let t = i, n = e._zod.def;
  t.type = "object";
  let a = n.keyType, s = a._zod.bag?.patterns;
  if (n.mode === "loose" && s && s.size > 0) {
    let m = Z(n.valueType, r, {
      ...o,
      path: [...o.path, "patternProperties", "*"]
    });
    t.patternProperties = {};
    for (let g of s)
      J(t.patternProperties, g.source, m);
  } else {
    if (r.target === "draft-07" || r.target === "draft-2020-12") {
      t.propertyNames = Z(n.keyType, r, {
        ...o,
        path: [...o.path, "propertyNames"]
      });
      let m = os.get(r);
      m || (m = [], os.set(r, m), r.deferred.push(() => U$(r))), m.push(e);
    }
    t.additionalProperties = Z(n.valueType, r, {
      ...o,
      path: [...o.path, "additionalProperties"]
    });
  }
  let l = a._zod.values, d = r.io === "input" && lr(n.valueType) !== void 0;
  if (l && !n.partial && !d) {
    let m = [...l].filter((g) => typeof g == "string" || typeof g == "number");
    m.length > 0 && (t.required = m.map(String));
  }
}, "recordProcessor"), Ts = /* @__PURE__ */ u((e, r, i, o) => {
  let t = e._zod.def, n = Z(t.innerType, r, o), a = r.seen.get(e);
  r.target === "openapi-3.0" ? (a.ref = t.innerType, i.nullable = !0) : i.anyOf = [n, { type: "null" }];
}, "nullableProcessor"), Zs = /* @__PURE__ */ u((e, r, i, o) => {
  let t = e._zod.def;
  Z(t.innerType, r, o);
  let n = r.seen.get(e);
  n.ref = t.innerType;
}, "nonoptionalProcessor"), As = Symbol();
function Xd(e, r, i, o, t) {
  let n = !1, a = JSON.stringify(e, (c, s) => typeof s != "bigint" ? s : (n = !0, null));
  return n ? (K(r, i, o, t, "BigInt defaults cannot be represented in JSON Schema"), As) : JSON.parse(a);
}
u(Xd, "serializeDefaultValue");
var Es = /* @__PURE__ */ u((e, r, i, o) => {
  let t = e._zod.def;
  Z(t.innerType, r, o);
  let n = r.seen.get(e);
  n.ref = t.innerType;
  let a = Xd(t.defaultValue, e, r, i, o);
  a !== As && (i.default = a);
}, "defaultProcessor"), Cs = /* @__PURE__ */ u((e, r, i, o) => {
  let t = e._zod.def;
  Z(t.innerType, r, o);
  let n = r.seen.get(e);
  if (n.ref = t.innerType, r.io !== "input")
    return;
  let a = Xd(t.defaultValue, e, r, i, o);
  a !== As && (i._prefault = a);
}, "prefaultProcessor"), Ls = /* @__PURE__ */ u((e, r, i, o) => {
  let t = e._zod.def;
  Z(t.innerType, r, o);
  let n = r.seen.get(e);
  n.ref = t.innerType;
  let a;
  try {
    a = t.catchValue(void 0);
  } catch {
    K(e, r, i, o, "Dynamic catch values are not supported in JSON Schema");
    return;
  }
  i.default = a;
}, "catchProcessor"), Vs = /* @__PURE__ */ u((e, r, i, o) => {
  let t = e._zod.def, n = t.in._zod.traits.has("$ZodTransform"), a = r.io === "input" ? n ? t.out : t.in : t.out;
  Z(a, r, o);
  let c = r.seen.get(e);
  c.ref = a;
}, "pipeProcessor"), Rs = /* @__PURE__ */ u((e, r, i, o) => {
  let t = e._zod.def;
  Z(t.innerType, r, o);
  let n = r.seen.get(e);
  n.ref = t.innerType, i.readOnly = !0;
}, "readonlyProcessor"), Fs = /* @__PURE__ */ u((e, r, i, o) => {
  let t = e._zod.def;
  Z(t.innerType, r, o);
  let n = r.seen.get(e);
  n.ref = t.innerType;
}, "promiseProcessor"), Wn = /* @__PURE__ */ u((e, r, i, o) => {
  let t = e._zod.def;
  Z(t.innerType, r, o);
  let n = r.seen.get(e);
  n.ref = t.innerType;
}, "optionalProcessor"), Js = /* @__PURE__ */ u((e, r, i, o) => {
  let t = e._zod.innerType;
  Z(t, r, o);
  let n = r.seen.get(e);
  n.ref = t;
}, "lazyProcessor"), Mn = {
  string: as,
  number: us,
  boolean: cs,
  bigint: ss,
  symbol: ls,
  null: ds,
  undefined: ms,
  void: fs,
  never: ps,
  any: gs,
  unknown: vs,
  date: $s,
  enum: hs,
  literal: _s,
  nan: ys,
  template_literal: bs,
  file: ks,
  success: xs,
  custom: Is,
  function: ws,
  transform: zs,
  map: Ss,
  set: js,
  array: Ps,
  object: Ds,
  union: Kn,
  intersection: Os,
  tuple: Us,
  record: Ns,
  nullable: Ts,
  nonoptional: Zs,
  default: Es,
  prefault: Cs,
  catch: Ls,
  pipe: Vs,
  readonly: Rs,
  promise: Fs,
  optional: Wn,
  lazy: Js
};
function Gn(e, r) {
  if ("_idmap" in e) {
    let o = e, t = Se({ ...r, processors: Mn }), n = {};
    for (let s of o._idmap.entries()) {
      let [l, d] = s;
      Z(d, t);
    }
    let a = {}, c = {
      registry: o,
      uri: r?.uri,
      defs: n
    };
    t.external = c;
    for (let s of o._idmap.entries()) {
      let [l, d] = s;
      je(t, d), J(a, l, Pe(t, d));
    }
    if (Object.keys(n).length > 0) {
      let s = t.target === "draft-2020-12" ? "$defs" : "definitions";
      a.__shared = {
        [s]: n
      };
    }
    return { schemas: a };
  }
  let i = Se({ ...r, processors: Mn });
  return Z(e, i), je(i, e), Pe(i, e);
}
u(Gn, "toJSONSchema");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/json-schema-generator.js
var Bn = class {
  static {
    u(this, "JSONSchemaGenerator");
  }
  /** @deprecated Access via ctx instead */
  get metadataRegistry() {
    return this.ctx.metadataRegistry;
  }
  /** @deprecated Access via ctx instead */
  get target() {
    return this.ctx.target;
  }
  // annotated so the .d.cts emits an indexed access rather than an inline `import()` of an ESM path
  /** @deprecated Access via ctx instead */
  get unrepresentable() {
    return this.ctx.unrepresentable;
  }
  /** @deprecated Access via ctx instead */
  get override() {
    return this.ctx.override;
  }
  /** @deprecated Access via ctx instead */
  get io() {
    return this.ctx.io;
  }
  /** @deprecated Access via ctx instead */
  get counter() {
    return this.ctx.counter;
  }
  set counter(r) {
    this.ctx.counter = r;
  }
  /** @deprecated Access via ctx instead */
  get seen() {
    return this.ctx.seen;
  }
  constructor(r) {
    let i = r?.target ?? "draft-2020-12";
    i === "draft-4" && (i = "draft-04"), i === "draft-7" && (i = "draft-07"), this.ctx = Se({
      processors: Mn,
      target: i,
      ...r?.metadata && { metadata: r.metadata },
      ...r?.unrepresentable && { unrepresentable: r.unrepresentable },
      ...r?.override && { override: r.override },
      ...r?.io && { io: r.io }
    });
  }
  /**
   * Process a schema to prepare it for JSON Schema generation.
   * This must be called before emit().
   */
  process(r, i = { path: [], schemaPath: [] }) {
    return Z(r, this.ctx, i);
  }
  /**
   * Emit the final JSON Schema after processing.
   * Must call process() first.
   */
  emit(r, i) {
    i && (i.cycles && (this.ctx.cycles = i.cycles), i.reused && (this.ctx.reused = i.reused), i.external && (this.ctx.external = i.external)), this.ctx.sharedDefsExtractedFor = void 0, this.ctx.sharedEmitDoneFor = void 0, je(this.ctx, r);
    let o = Pe(this.ctx, r), { "~standard": t, ...n } = o;
    return n;
  }
};

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/json-schema.js
var Yd = {};

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/schemas.js
var Dt = {};
he(Dt, {
  ZodAny: () => ll,
  ZodArray: () => pl,
  ZodBase64: () => fi,
  ZodBase64URL: () => pi,
  ZodBigInt: () => jt,
  ZodBigIntFormat: () => $i,
  ZodBoolean: () => St,
  ZodCIDRv4: () => di,
  ZodCIDRv6: () => mi,
  ZodCUID: () => ii,
  ZodCUID2: () => oi,
  ZodCatch: () => Zl,
  ZodCodec: () => yr,
  ZodCreditCard: () => nl,
  ZodCustom: () => br,
  ZodCustomStringFormat: () => wt,
  ZodDate: () => pr,
  ZodDefault: () => Pl,
  ZodDiscriminatedUnion: () => vl,
  ZodE164: () => gi,
  ZodEmail: () => ei,
  ZodEmoji: () => ri,
  ZodEnum: () => xt,
  ZodExactOptional: () => bi,
  ZodFile: () => wl,
  ZodFunction: () => Kl,
  ZodGUID: () => ti,
  ZodIPv4: () => si,
  ZodIPv6: () => li,
  ZodISODate: () => Oe,
  ZodISODateTime: () => De,
  ZodISODuration: () => Ne,
  ZodISOTime: () => Ue,
  ZodIntersection: () => $l,
  ZodJWT: () => vi,
  ZodKSUID: () => ci,
  ZodLazy: () => Fl,
  ZodLiteral: () => Il,
  ZodMAC: () => rl,
  ZodMap: () => kl,
  ZodNaN: () => El,
  ZodNanoID: () => ni,
  ZodNever: () => ml,
  ZodNonOptional: () => ki,
  ZodNull: () => cl,
  ZodNullable: () => jl,
  ZodNumber: () => zt,
  ZodNumberFormat: () => qe,
  ZodObject: () => vr,
  ZodOptional: () => hr,
  ZodPipe: () => _r,
  ZodPrefault: () => Ol,
  ZodPreprocess: () => Cl,
  ZodPromise: () => Ml,
  ZodReadonly: () => Ll,
  ZodRecord: () => kt,
  ZodSet: () => xl,
  ZodString: () => It,
  ZodStringFormat: () => C,
  ZodSuccess: () => Tl,
  ZodSymbol: () => al,
  ZodTemplateLiteral: () => Rl,
  ZodTransform: () => zl,
  ZodTuple: () => _l,
  ZodType: () => D,
  ZodULID: () => ai,
  ZodURL: () => fr,
  ZodUUID: () => $e,
  ZodUndefined: () => ul,
  ZodUnion: () => $r,
  ZodUnknown: () => dl,
  ZodVoid: () => fl,
  ZodXID: () => ui,
  ZodXor: () => gl,
  _ZodString: () => Qn,
  _default: () => Dl,
  _function: () => cf,
  any: () => Cm,
  array: () => gr,
  base64: () => ym,
  base64url: () => bm,
  bigint: () => Nm,
  boolean: () => ol,
  catch: () => Al,
  check: () => sf,
  cidrv4: () => hm,
  cidrv6: () => _m,
  codec: () => nf,
  creditCard: () => xm,
  cuid: () => lm,
  cuid2: () => dm,
  custom: () => lf,
  date: () => Vm,
  describe: () => df,
  discriminatedUnion: () => Wm,
  e164: () => km,
  email: () => em,
  emoji: () => cm,
  enum: () => _i,
  exactOptional: () => Sl,
  file: () => Qm,
  float32: () => Pm,
  float64: () => Dm,
  function: () => cf,
  guid: () => tm,
  hash: () => jm,
  hex: () => Sm,
  hostname: () => zm,
  httpUrl: () => um,
  instanceof: () => ff,
  int: () => Yn,
  int32: () => Om,
  int64: () => Tm,
  intersection: () => hl,
  invertCodec: () => of,
  ipv4: () => gm,
  ipv6: () => $m,
  json: () => gf,
  jwt: () => Im,
  keyof: () => Rm,
  ksuid: () => pm,
  lazy: () => Jl,
  literal: () => Hm,
  looseObject: () => Mm,
  looseRecord: () => Bm,
  mac: () => vm,
  map: () => qm,
  meta: () => mf,
  nan: () => rf,
  nanoid: () => sm,
  nativeEnum: () => Ym,
  never: () => hi,
  nonoptional: () => Nl,
  null: () => sl,
  nullable: () => mr,
  nullish: () => ef,
  number: () => il,
  object: () => Fm,
  optional: () => Ge,
  partialRecord: () => Gm,
  pipe: () => Hn,
  prefault: () => Ul,
  preprocess: () => vf,
  promise: () => uf,
  readonly: () => Vl,
  record: () => bl,
  refine: () => Wl,
  set: () => Xm,
  strictObject: () => Jm,
  string: () => dr,
  stringFormat: () => wm,
  stringbool: () => pf,
  success: () => tf,
  superRefine: () => Gl,
  symbol: () => Am,
  templateLiteral: () => af,
  transform: () => yi,
  tuple: () => yl,
  uint32: () => Um,
  uint64: () => Zm,
  ulid: () => mm,
  undefined: () => Em,
  union: () => Pt,
  unknown: () => We,
  url: () => am,
  uuid: () => rm,
  uuidv4: () => nm,
  uuidv6: () => im,
  uuidv7: () => om,
  void: () => Lm,
  xid: () => fm,
  xor: () => Km
});

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/checks.js
var qn = {};
he(qn, {
  endsWith: () => ft,
  gt: () => ge,
  gte: () => ce,
  includes: () => dt,
  length: () => Ke,
  lowercase: () => st,
  lt: () => pe,
  lte: () => ue,
  maxLength: () => Me,
  maxSize: () => ze,
  mime: () => pt,
  minLength: () => _e,
  minSize: () => ve,
  multipleOf: () => we,
  negative: () => Ln,
  nonnegative: () => Rn,
  nonpositive: () => Vn,
  normalize: () => gt,
  overwrite: () => fe,
  positive: () => Cn,
  properties: () => Jn,
  property: () => Fn,
  regex: () => ct,
  size: () => Je,
  slugify: () => _t,
  startsWith: () => mt,
  toLowerCase: () => $t,
  toUpperCase: () => ht,
  trim: () => vt,
  uppercase: () => lt
});

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/errors.js
var Hd = /* @__PURE__ */ new WeakSet([Object.prototype, Error.prototype]);
function Xn(e, r, i) {
  Object.defineProperty(e, r, {
    configurable: !0,
    enumerable: !1,
    get() {
      let o = i(this);
      return Object.defineProperty(this, r, { value: o, configurable: !0, writable: !0 }), o;
    },
    set(o) {
      Object.defineProperty(this, r, { value: o, configurable: !0, writable: !0 });
    }
  });
}
u(Xn, "_lazyMethod");
var Qd = /* @__PURE__ */ u((e, r) => {
  Vt.init(e, r), e.name = "ZodError";
  let i = Object.getPrototypeOf(e);
  Hd.has(i) || (Hd.add(i), Xn(i, "format", (o) => (t) => Ft(o, t)), Xn(i, "flatten", (o) => (t) => Rt(o, t)), Xn(i, "addIssue", (o) => (t) => {
    o.issues.push(t), o.message = JSON.stringify(o.issues, He, 2);
  }), Xn(i, "addIssues", (o) => (t) => {
    o.issues.push(...t), o.message = JSON.stringify(o.issues, He, 2);
  }), Object.defineProperty(i, "isEmpty", {
    configurable: !0,
    enumerable: !1,
    get() {
      return this.issues.length === 0;
    }
  }));
}, "initializer"), T$ = /* @__PURE__ */ f("ZodError", Qd), ie = /* @__PURE__ */ f("ZodError", Qd, void 0, {
  Parent: Error
});

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/parse.js
var Ms = /* @__PURE__ */ tt(ie), Ks = /* @__PURE__ */ rt(ie), Ws = /* @__PURE__ */ nt(ie), Gs = /* @__PURE__ */ it(ie), Bs = /* @__PURE__ */ Or(ie), qs = /* @__PURE__ */ Ur(ie), Xs = /* @__PURE__ */ Nr(ie), Ys = /* @__PURE__ */ Tr(ie), Hs = /* @__PURE__ */ Zr(ie), Qs = /* @__PURE__ */ Ar(ie), el = /* @__PURE__ */ Er(ie), tl = /* @__PURE__ */ Cr(ie);

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/schemas.js
function A$() {
  G.localeError || M(Qt());
}
u(A$, "_ensureDefaultLocale");
function Be() {
  G.memoizer || M({ memoizer: Ht() });
}
u(Be, "_ensureDefaultMemoizer");
var D = /* @__PURE__ */ f("ZodType", (e, r) => (A$(), j.init(e, r), e.def = r, e.type = r.type, e), {
  check(...e) {
    let r = this.def;
    return this.clone(y.mergeDefs(r, {
      checks: [
        ...r.checks ?? [],
        ...e.map((i) => typeof i == "function" ? { _zod: { check: i, def: { check: "custom" }, onattach: [] } } : i)
      ]
    }), { parent: !0 });
  },
  with(...e) {
    return this.check(...e);
  },
  clone(e, r) {
    return T(this, e, r);
  },
  brand() {
    return this;
  },
  register(e, r) {
    return e.add(this, r), this;
  },
  refine(e, r) {
    return this.check(Wl(e, r));
  },
  superRefine(e, r) {
    return this.check(Gl(e, r));
  },
  overwrite(e) {
    return this.check(fe(e));
  },
  optional() {
    return Ge(this);
  },
  exactOptional() {
    return Sl(this);
  },
  nullable() {
    return mr(this);
  },
  nullish() {
    return Ge(mr(this));
  },
  nonoptional(e) {
    return Nl(this, e);
  },
  array() {
    return gr(this);
  },
  or(e) {
    return Pt([this, e]);
  },
  and(e) {
    return hl(this, e);
  },
  transform(e) {
    return Hn(this, yi(e));
  },
  default(e) {
    return Dl(this, e);
  },
  prefault(e) {
    return Ul(this, e);
  },
  catch(e) {
    return Al(this, e);
  },
  pipe(e) {
    return Hn(this, e);
  },
  readonly() {
    return Vl(this);
  },
  describe(e) {
    let r = this.clone();
    return B.add(r, { description: e }), r;
  },
  meta(...e) {
    if (e.length === 0)
      return B.get(this);
    let r = this.clone();
    return B.add(r, e[0]), r;
  },
  isOptional() {
    return this.safeParse(void 0).success;
  },
  isNullable() {
    return this.safeParse(null).success;
  },
  apply(e, ...r) {
    return r.length === 0 ? e(this) : e(this, ...r);
  },
  // Overrides core's `~standard` to add `jsonSchema`. Must stay a prototype entry: redefining it per instance demotes instances to dictionary mode.
  get "~standard"() {
    return y.hide(this, "~standard", {
      ...qr(this),
      jsonSchema: {
        input: bt(this, "input"),
        output: bt(this, "output")
      }
    });
  },
  set "~standard"(e) {
    y.own(this, "~standard", e);
  },
  parse: /* @__PURE__ */ u(function e(r, i) {
    return Ms(this, r, i, { callee: e });
  }, "_parse"),
  parseAsync: /* @__PURE__ */ u(async function e(r, i) {
    return await Ks(this, r, i, { callee: e });
  }, "_parseAsync"),
  safeParse(e, r) {
    return Ws(this, e, r);
  },
  async safeParseAsync(e, r) {
    return Gs(this, e, r);
  },
  // `spa` is an alias: same function object as `safeParseAsync`, as before.
  get spa() {
    return this?.safeParseAsync;
  },
  set spa(e) {
    y.own(this, "spa", e);
  },
  encode: /* @__PURE__ */ u(function e(r, i) {
    return Bs(this, r, i, { callee: e });
  }, "_encode"),
  decode: /* @__PURE__ */ u(function e(r, i) {
    return qs(this, r, i, { callee: e });
  }, "_decode"),
  encodeAsync: /* @__PURE__ */ u(async function e(r, i) {
    return await Xs(this, r, i, { callee: e });
  }, "_encodeAsync"),
  decodeAsync: /* @__PURE__ */ u(async function e(r, i) {
    return await Ys(this, r, i, { callee: e });
  }, "_decodeAsync"),
  safeEncode(e, r) {
    return Hs(this, e, r);
  },
  safeDecode(e, r) {
    return Qs(this, e, r);
  },
  async safeEncodeAsync(e, r) {
    return el(this, e, r);
  },
  async safeDecodeAsync(e, r) {
    return tl(this, e, r);
  },
  toJSONSchema(e) {
    return ns(this, {})(e);
  },
  // Reads through to the registry on every access, so it must not cache.
  get description() {
    return B.get(this)?.description;
  },
  // No setter: `schema._def = x` throws, as it did when `_def` was a non-writable own property.
  get _def() {
    return this._zod.def;
  }
}), Qn = /* @__PURE__ */ f("_ZodString", (e, r) => {
  Ce.init(e, r), D.init(e, r), e._zod.processJSONSchema = (o, t, n) => as(e, o, t, n);
  let i = e._zod.bag;
  e.format = i.format ?? null, e.minLength = i.minimum ?? null, e.maxLength = i.maximum ?? null;
}, {
  regex(...e) {
    return this.check(ct(...e));
  },
  includes(...e) {
    return this.check(dt(...e));
  },
  startsWith(...e) {
    return this.check(mt(...e));
  },
  endsWith(...e) {
    return this.check(ft(...e));
  },
  min(...e) {
    return this.check(_e(...e));
  },
  max(...e) {
    return this.check(Me(...e));
  },
  length(...e) {
    return this.check(Ke(...e));
  },
  nonempty(...e) {
    return this.check(_e(1, ...e));
  },
  lowercase(e) {
    return this.check(st(e));
  },
  uppercase(e) {
    return this.check(lt(e));
  },
  trim() {
    return this.check(vt());
  },
  normalize(...e) {
    return this.check(gt(...e));
  },
  toLowerCase() {
    return this.check($t());
  },
  toUpperCase() {
    return this.check(ht());
  },
  slugify() {
    return this.check(_t());
  }
}), It = /* @__PURE__ */ f("ZodString", (e, r) => {
  Ce.init(e, r), Qn.init(e, r);
}, {
  email(e) {
    return this.check($n(ei, e));
  },
  url(e) {
    return this.check(ir(fr, e));
  },
  jwt(e) {
    return this.check(En(vi, e));
  },
  emoji(e) {
    return this.check(xn(ri, e));
  },
  guid(e) {
    return this.check(hn(ti, e));
  },
  uuid(e) {
    return this.check(_n($e, e));
  },
  uuidv4(e) {
    return this.check(yn($e, e));
  },
  uuidv6(e) {
    return this.check(bn($e, e));
  },
  uuidv7(e) {
    return this.check(kn($e, e));
  },
  nanoid(e) {
    return this.check(In(ni, e));
  },
  cuid(e) {
    return this.check(wn(ii, e));
  },
  cuid2(e) {
    return this.check(zn(oi, e));
  },
  ulid(e) {
    return this.check(Sn(ai, e));
  },
  base64(e) {
    return this.check(Tn(fi, e));
  },
  base64url(e) {
    return this.check(Zn(pi, e));
  },
  xid(e) {
    return this.check(jn(ui, e));
  },
  ksuid(e) {
    return this.check(Pn(ci, e));
  },
  ipv4(e) {
    return this.check(Dn(si, e));
  },
  ipv6(e) {
    return this.check(On(li, e));
  },
  cidrv4(e) {
    return this.check(Un(di, e));
  },
  cidrv6(e) {
    return this.check(Nn(mi, e));
  },
  e164(e) {
    return this.check(An(gi, e));
  },
  datetime(e) {
    return this.check(or(De, e));
  },
  date(e) {
    return this.check(ar(Oe, e));
  },
  time(e) {
    return this.check(ur(Ue, e));
  },
  duration(e) {
    return this.check(cr(Ne, e));
  }
});
function dr(e) {
  return yc(It, e);
}
u(dr, "string");
var C = /* @__PURE__ */ f("ZodStringFormat", (e, r) => {
  E.init(e, r), Qn.init(e, r);
}), De = /* @__PURE__ */ f("ZodISODateTime", (e, r) => {
  aa.init(e, r), C.init(e, r);
}), Oe = /* @__PURE__ */ f("ZodISODate", (e, r) => {
  ua.init(e, r), C.init(e, r);
}), Ue = /* @__PURE__ */ f("ZodISOTime", (e, r) => {
  ca.init(e, r), C.init(e, r);
}), Ne = /* @__PURE__ */ f("ZodISODuration", (e, r) => {
  sa.init(e, r), C.init(e, r);
}), ei = /* @__PURE__ */ f("ZodEmail", (e, r) => {
  qo.init(e, r), C.init(e, r);
});
function em(e) {
  return $n(ei, e);
}
u(em, "email");
var ti = /* @__PURE__ */ f("ZodGUID", (e, r) => {
  Go.init(e, r), C.init(e, r);
});
function tm(e) {
  return hn(ti, e);
}
u(tm, "guid");
var $e = /* @__PURE__ */ f("ZodUUID", (e, r) => {
  Bo.init(e, r), C.init(e, r);
});
function rm(e) {
  return _n($e, e);
}
u(rm, "uuid");
function nm(e) {
  return yn($e, e);
}
u(nm, "uuidv4");
function im(e) {
  return bn($e, e);
}
u(im, "uuidv6");
function om(e) {
  return kn($e, e);
}
u(om, "uuidv7");
var fr = /* @__PURE__ */ f("ZodURL", (e, r) => {
  Ho.init(e, r), C.init(e, r);
});
function am(e) {
  return ir(fr, e);
}
u(am, "url");
function um(e) {
  return ir(fr, {
    protocol: X.httpProtocol,
    hostname: X.domain,
    ...y.normalizeParams(e)
  });
}
u(um, "httpUrl");
var ri = /* @__PURE__ */ f("ZodEmoji", (e, r) => {
  Qo.init(e, r), C.init(e, r);
});
function cm(e) {
  return xn(ri, e);
}
u(cm, "emoji");
var ni = /* @__PURE__ */ f("ZodNanoID", (e, r) => {
  ea.init(e, r), C.init(e, r);
});
function sm(e) {
  return In(ni, e);
}
u(sm, "nanoid");
var ii = /* @__PURE__ */ f("ZodCUID", (e, r) => {
  ta.init(e, r), C.init(e, r);
});
function lm(e) {
  return wn(ii, e);
}
u(lm, "cuid");
var oi = /* @__PURE__ */ f("ZodCUID2", (e, r) => {
  ra.init(e, r), C.init(e, r);
});
function dm(e) {
  return zn(oi, e);
}
u(dm, "cuid2");
var ai = /* @__PURE__ */ f("ZodULID", (e, r) => {
  na.init(e, r), C.init(e, r);
});
function mm(e) {
  return Sn(ai, e);
}
u(mm, "ulid");
var ui = /* @__PURE__ */ f("ZodXID", (e, r) => {
  ia.init(e, r), C.init(e, r);
});
function fm(e) {
  return jn(ui, e);
}
u(fm, "xid");
var ci = /* @__PURE__ */ f("ZodKSUID", (e, r) => {
  oa.init(e, r), C.init(e, r);
});
function pm(e) {
  return Pn(ci, e);
}
u(pm, "ksuid");
var si = /* @__PURE__ */ f("ZodIPv4", (e, r) => {
  la.init(e, r), C.init(e, r);
});
function gm(e) {
  return Dn(si, e);
}
u(gm, "ipv4");
var rl = /* @__PURE__ */ f("ZodMAC", (e, r) => {
  ma.init(e, r), C.init(e, r);
});
function vm(e) {
  return kc(rl, e);
}
u(vm, "mac");
var li = /* @__PURE__ */ f("ZodIPv6", (e, r) => {
  da.init(e, r), C.init(e, r);
});
function $m(e) {
  return On(li, e);
}
u($m, "ipv6");
var di = /* @__PURE__ */ f("ZodCIDRv4", (e, r) => {
  fa.init(e, r), C.init(e, r);
});
function hm(e) {
  return Un(di, e);
}
u(hm, "cidrv4");
var mi = /* @__PURE__ */ f("ZodCIDRv6", (e, r) => {
  pa.init(e, r), C.init(e, r);
});
function _m(e) {
  return Nn(mi, e);
}
u(_m, "cidrv6");
var fi = /* @__PURE__ */ f("ZodBase64", (e, r) => {
  ga.init(e, r), C.init(e, r);
});
function ym(e) {
  return Tn(fi, e);
}
u(ym, "base64");
var pi = /* @__PURE__ */ f("ZodBase64URL", (e, r) => {
  va.init(e, r), C.init(e, r);
});
function bm(e) {
  return Zn(pi, e);
}
u(bm, "base64url");
var gi = /* @__PURE__ */ f("ZodE164", (e, r) => {
  $a.init(e, r), C.init(e, r);
});
function km(e) {
  return An(gi, e);
}
u(km, "e164");
var nl = /* @__PURE__ */ f("ZodCreditCard", (e, r) => {
  ha.init(e, r), C.init(e, r);
});
function xm(e) {
  return xc(nl, e);
}
u(xm, "creditCard");
var vi = /* @__PURE__ */ f("ZodJWT", (e, r) => {
  _a.init(e, r), C.init(e, r);
});
function Im(e) {
  return En(vi, e);
}
u(Im, "jwt");
var wt = /* @__PURE__ */ f("ZodCustomStringFormat", (e, r) => {
  ya.init(e, r), C.init(e, r);
});
function wm(e, r, i = {}) {
  return yt(wt, e, r, i);
}
u(wm, "stringFormat");
function zm(e) {
  return yt(wt, "hostname", X.hostname, e);
}
u(zm, "hostname");
function Sm(e) {
  return yt(wt, "hex", X.hex, e);
}
u(Sm, "hex");
function jm(e, r) {
  let i = r?.enc ?? "hex", o = `${e}_${i}`, t = X[o];
  if (!t)
    throw new Error(`Unrecognized hash format: ${o}`);
  return yt(wt, o, t, r);
}
u(jm, "hash");
var zt = /* @__PURE__ */ f("ZodNumber", (e, r) => {
  on.init(e, r), D.init(e, r), e._zod.processJSONSchema = (o, t, n) => us(e, o, t, n);
  let i = e._zod.bag;
  e.minValue = Math.max(i.minimum ?? Number.NEGATIVE_INFINITY, i.exclusiveMinimum ?? Number.NEGATIVE_INFINITY) ?? null, e.maxValue = Math.min(i.maximum ?? Number.POSITIVE_INFINITY, i.exclusiveMaximum ?? Number.POSITIVE_INFINITY) ?? null, e.isInt = (i.format ?? "").includes("int") || Number.isSafeInteger(i.multipleOf ?? 0.5), e.isFinite = !0, e.format = i.format ?? null;
}, {
  gt(e, r) {
    return this.check(ge(e, r));
  },
  gte(e, r) {
    return this.check(ce(e, r));
  },
  min(e, r) {
    return this.check(ce(e, r));
  },
  lt(e, r) {
    return this.check(pe(e, r));
  },
  lte(e, r) {
    return this.check(ue(e, r));
  },
  max(e, r) {
    return this.check(ue(e, r));
  },
  int(e) {
    return this.check(Yn(e));
  },
  safe(e) {
    return this.check(Yn(e));
  },
  positive(e) {
    return this.check(ge(0, e));
  },
  nonnegative(e) {
    return this.check(ce(0, e));
  },
  negative(e) {
    return this.check(pe(0, e));
  },
  nonpositive(e) {
    return this.check(ue(0, e));
  },
  multipleOf(e, r) {
    return this.check(we(e, r));
  },
  step(e, r) {
    return this.check(we(e, r));
  },
  finite() {
    return this;
  }
});
function il(e) {
  return wc(zt, e);
}
u(il, "number");
var qe = /* @__PURE__ */ f("ZodNumberFormat", (e, r) => {
  ba.init(e, r), zt.init(e, r);
});
function Yn(e) {
  return Sc(qe, e);
}
u(Yn, "int");
function Pm(e) {
  return jc(qe, e);
}
u(Pm, "float32");
function Dm(e) {
  return Pc(qe, e);
}
u(Dm, "float64");
function Om(e) {
  return Dc(qe, e);
}
u(Om, "int32");
function Um(e) {
  return Oc(qe, e);
}
u(Um, "uint32");
var St = /* @__PURE__ */ f("ZodBoolean", (e, r) => {
  Bt.init(e, r), D.init(e, r), e._zod.processJSONSchema = (i, o, t) => cs(e, i, o, t);
});
function ol(e) {
  return Uc(St, e);
}
u(ol, "boolean");
var jt = /* @__PURE__ */ f("ZodBigInt", (e, r) => {
  an.init(e, r), D.init(e, r), e._zod.processJSONSchema = (o, t, n) => ss(e, o, t, n);
  let i = e._zod.bag;
  e.minValue = i.minimum ?? null, e.maxValue = i.maximum ?? null, e.format = i.format ?? null;
}, {
  gte(e, r) {
    return this.check(ce(e, r));
  },
  min(e, r) {
    return this.check(ce(e, r));
  },
  gt(e, r) {
    return this.check(ge(e, r));
  },
  lt(e, r) {
    return this.check(pe(e, r));
  },
  lte(e, r) {
    return this.check(ue(e, r));
  },
  max(e, r) {
    return this.check(ue(e, r));
  },
  positive(e) {
    return this.check(ge(BigInt(0), e));
  },
  negative(e) {
    return this.check(pe(BigInt(0), e));
  },
  nonpositive(e) {
    return this.check(ue(BigInt(0), e));
  },
  nonnegative(e) {
    return this.check(ce(BigInt(0), e));
  },
  multipleOf(e, r) {
    return this.check(we(e, r));
  }
});
function Nm(e) {
  return Tc(jt, e);
}
u(Nm, "bigint");
var $i = /* @__PURE__ */ f("ZodBigIntFormat", (e, r) => {
  ka.init(e, r), jt.init(e, r);
});
function Tm(e) {
  return Ac($i, e);
}
u(Tm, "int64");
function Zm(e) {
  return Ec($i, e);
}
u(Zm, "uint64");
var al = /* @__PURE__ */ f("ZodSymbol", (e, r) => {
  xa.init(e, r), D.init(e, r), e._zod.processJSONSchema = (i, o, t) => ls(e, i, o, t);
});
function Am(e) {
  return Cc(al, e);
}
u(Am, "symbol");
var ul = /* @__PURE__ */ f("ZodUndefined", (e, r) => {
  Ia.init(e, r), D.init(e, r), e._zod.processJSONSchema = (i, o, t) => ms(e, i, o, t);
});
function Em(e) {
  return Lc(ul, e);
}
u(Em, "_undefined");
var cl = /* @__PURE__ */ f("ZodNull", (e, r) => {
  wa.init(e, r), D.init(e, r), e._zod.processJSONSchema = (i, o, t) => ds(e, i, o, t);
});
function sl(e) {
  return Vc(cl, e);
}
u(sl, "_null");
var ll = /* @__PURE__ */ f("ZodAny", (e, r) => {
  za.init(e, r), D.init(e, r), e._zod.processJSONSchema = (i, o, t) => gs(e, i, o, t);
});
function Cm() {
  return Rc(ll);
}
u(Cm, "any");
var dl = /* @__PURE__ */ f("ZodUnknown", (e, r) => {
  Sa.init(e, r), D.init(e, r), e._zod.processJSONSchema = (i, o, t) => vs(e, i, o, t);
});
function We() {
  return Fc(dl);
}
u(We, "unknown");
var ml = /* @__PURE__ */ f("ZodNever", (e, r) => {
  ja.init(e, r), D.init(e, r), e._zod.processJSONSchema = (i, o, t) => ps(e, i, o, t);
});
function hi(e) {
  return Jc(ml, e);
}
u(hi, "never");
var fl = /* @__PURE__ */ f("ZodVoid", (e, r) => {
  Pa.init(e, r), D.init(e, r), e._zod.processJSONSchema = (i, o, t) => fs(e, i, o, t);
});
function Lm(e) {
  return Mc(fl, e);
}
u(Lm, "_void");
var pr = /* @__PURE__ */ f("ZodDate", (e, r) => {
  Da.init(e, r), D.init(e, r), e._zod.processJSONSchema = (o, t, n) => $s(e, o, t, n), e.min = (o, t) => e.check(ce(o, t)), e.max = (o, t) => e.check(ue(o, t));
  let i = e._zod.bag;
  e.minDate = i.minimum ? new Date(i.minimum) : null, e.maxDate = i.maximum ? new Date(i.maximum) : null;
});
function Vm(e) {
  return Kc(pr, e);
}
u(Vm, "date");
var pl = /* @__PURE__ */ f("ZodArray", (e, r) => {
  Be(), Oa.init(e, r), D.init(e, r), e._zod.processJSONSchema = (i, o, t) => Ps(e, i, o, t), e.element = r.element;
}, {
  min(e, r) {
    return this.check(_e(e, r));
  },
  nonempty(e) {
    return this.check(_e(1, e));
  },
  max(e, r) {
    return this.check(Me(e, r));
  },
  length(e, r) {
    return this.check(Ke(e, r));
  },
  unwrap() {
    return this.element;
  }
});
function gr(e, r) {
  return Bc(pl, e, r);
}
u(gr, "array");
function Rm(e) {
  let r = e._zod.def.shape;
  return _i(Object.keys(r));
}
u(Rm, "keyof");
var vr = /* @__PURE__ */ f("ZodObject", (e, r) => {
  Be(), Ua.init(e, r), D.init(e, r), e._zod.processJSONSchema = (i, o, t) => Ds(e, i, o, t), y.installLazyProp(e, "shape", (i) => i._zod.def.shape, !1);
}, {
  keyof() {
    return _i(Object.keys(this._zod.def.shape));
  },
  catchall(e) {
    return this.clone({ ...this._zod.def, catchall: e });
  },
  passthrough() {
    return this.clone({ ...this._zod.def, catchall: We() });
  },
  loose() {
    return this.clone({ ...this._zod.def, catchall: We() });
  },
  strict() {
    return this.clone({ ...this._zod.def, catchall: hi() });
  },
  strip() {
    return this.clone({ ...this._zod.def, catchall: void 0 });
  },
  extend(e) {
    return y.extend(this, e);
  },
  safeExtend(e) {
    return y.safeExtend(this, e);
  },
  merge(e) {
    return y.merge(this, e);
  },
  pick(e) {
    return y.pick(this, e);
  },
  omit(e) {
    return y.omit(this, e);
  },
  partial(...e) {
    return y.partial(hr, this, e[0]);
  },
  exactPartial(...e) {
    return y.partial(bi, this, e[0], "exactPartial");
  },
  required(...e) {
    return y.required(ki, this, e[0]);
  }
});
function Fm(e, r) {
  let i = {
    type: "object",
    shape: e ?? {},
    ...y.normalizeParams(r)
  };
  return new vr(i);
}
u(Fm, "object");
function Jm(e, r) {
  return new vr({
    type: "object",
    shape: e,
    catchall: hi(),
    ...y.normalizeParams(r)
  });
}
u(Jm, "strictObject");
function Mm(e, r) {
  return new vr({
    type: "object",
    shape: e,
    catchall: We(),
    ...y.normalizeParams(r)
  });
}
u(Mm, "looseObject");
var $r = /* @__PURE__ */ f("ZodUnion", (e, r) => {
  qt.init(e, r), D.init(e, r), e._zod.processJSONSchema = (i, o, t) => Kn(e, i, o, t), e.options = r.options;
});
function Pt(e, r) {
  return new $r({
    type: "union",
    options: e,
    ...y.normalizeParams(r)
  });
}
u(Pt, "union");
var gl = /* @__PURE__ */ f("ZodXor", (e, r) => {
  $r.init(e, r), Na.init(e, r), e._zod.processJSONSchema = (i, o, t) => Kn(e, i, o, t), e.options = r.options;
});
function Km(e, r) {
  return new gl({
    type: "union",
    options: e,
    inclusive: !1,
    ...y.normalizeParams(r)
  });
}
u(Km, "xor");
var vl = /* @__PURE__ */ f("ZodDiscriminatedUnion", (e, r) => {
  $r.init(e, r), Za.init(e, r);
});
function Wm(e, r, i) {
  return new vl({
    type: "union",
    options: r,
    discriminator: e,
    ...y.normalizeParams(i)
  });
}
u(Wm, "discriminatedUnion");
var $l = /* @__PURE__ */ f("ZodIntersection", (e, r) => {
  Aa.init(e, r), D.init(e, r), e._zod.processJSONSchema = (i, o, t) => Os(e, i, o, t);
});
function hl(e, r) {
  return new $l({
    type: "intersection",
    left: e,
    right: r
  });
}
u(hl, "intersection");
var _l = /* @__PURE__ */ f("ZodTuple", (e, r) => {
  Be(), un.init(e, r), D.init(e, r), e._zod.processJSONSchema = (i, o, t) => Us(e, i, o, t);
}, {
  rest(e) {
    return this.clone({
      ...this._zod.def,
      rest: e
    });
  },
  partial() {
    let e = this._zod.def;
    if (e.checks?.length)
      throw new Error(".partial() cannot be used on tuple schemas containing refinements");
    return this.clone({
      ...e,
      items: e.items.map((r) => new hr({ type: "optional", innerType: r }))
    });
  }
});
function yl(e, r, i) {
  let o = r instanceof j, t = o ? i : r, n = o ? r : null;
  return new _l({
    type: "tuple",
    items: e,
    rest: n,
    ...y.normalizeParams(t)
  });
}
u(yl, "tuple");
var kt = /* @__PURE__ */ f("ZodRecord", (e, r) => {
  Be(), Ea.init(e, r), D.init(e, r), e._zod.processJSONSchema = (i, o, t) => Ns(e, i, o, t), e.keyType = r.keyType, e.valueType = r.valueType;
});
function bl(e, r, i) {
  return !r || !r._zod ? new kt({
    type: "record",
    keyType: dr(),
    valueType: e,
    ...y.normalizeParams(r)
  }) : new kt({
    type: "record",
    keyType: e,
    valueType: r,
    ...y.normalizeParams(i)
  });
}
u(bl, "record");
function Gm(e, r, i) {
  return new kt({
    type: "record",
    keyType: e,
    valueType: r,
    ...y.normalizeParams(i),
    partial: !0
  });
}
u(Gm, "partialRecord");
function Bm(e, r, i) {
  return new kt({
    type: "record",
    keyType: e,
    valueType: r,
    mode: "loose",
    ...y.normalizeParams(i)
  });
}
u(Bm, "looseRecord");
var kl = /* @__PURE__ */ f("ZodMap", (e, r) => {
  Be(), Ca.init(e, r), D.init(e, r), e._zod.processJSONSchema = (i, o, t) => Ss(e, i, o, t), e.keyType = r.keyType, e.valueType = r.valueType, e.min = (...i) => e.check(ve(...i)), e.nonempty = (i) => e.check(ve(1, i)), e.max = (...i) => e.check(ze(...i)), e.size = (...i) => e.check(Je(...i));
});
function qm(e, r, i) {
  return new kl({
    type: "map",
    keyType: e,
    valueType: r,
    ...y.normalizeParams(i)
  });
}
u(qm, "map");
var xl = /* @__PURE__ */ f("ZodSet", (e, r) => {
  Be(), La.init(e, r), D.init(e, r), e._zod.processJSONSchema = (i, o, t) => js(e, i, o, t), e.min = (...i) => e.check(ve(...i)), e.nonempty = (i) => e.check(ve(1, i)), e.max = (...i) => e.check(ze(...i)), e.size = (...i) => e.check(Je(...i));
});
function Xm(e, r) {
  return new xl({
    type: "set",
    valueType: e,
    ...y.normalizeParams(r)
  });
}
u(Xm, "set");
var xt = /* @__PURE__ */ f("ZodEnum", (e, r) => {
  Va.init(e, r), D.init(e, r), e._zod.processJSONSchema = (o, t, n) => hs(e, o, t, n), e.enum = r.entries, e.options = Object.values(r.entries);
  let i = new Set(Object.keys(r.entries));
  e.extract = (o, t) => {
    let n = {};
    for (let a of o)
      if (i.has(a))
        n[a] = r.entries[a];
      else
        throw new Error(`Key ${a} not found in enum`);
    return new xt({
      ...r,
      checks: [],
      ...y.normalizeParams(t),
      entries: n
    });
  }, e.exclude = (o, t) => {
    let n = { ...r.entries };
    for (let a of o)
      if (i.has(a))
        delete n[a];
      else
        throw new Error(`Key ${a} not found in enum`);
    return new xt({
      ...r,
      checks: [],
      ...y.normalizeParams(t),
      entries: n
    });
  };
});
function _i(e, r) {
  let i = Array.isArray(e) ? Object.fromEntries(e.map((o) => [o, o])) : e;
  return new xt({
    type: "enum",
    entries: i,
    ...y.normalizeParams(r)
  });
}
u(_i, "_enum");
function Ym(e, r) {
  return new xt({
    type: "enum",
    entries: e,
    ...y.normalizeParams(r)
  });
}
u(Ym, "nativeEnum");
var Il = /* @__PURE__ */ f("ZodLiteral", (e, r) => {
  Ra.init(e, r), D.init(e, r), e._zod.processJSONSchema = (i, o, t) => _s(e, i, o, t), e.values = new Set(r.values), Object.defineProperty(e, "value", {
    get() {
      if (r.values.length > 1)
        throw new Error("This schema contains multiple valid literal values. Use `.values` instead.");
      return r.values[0];
    }
  });
});
function Hm(e, r) {
  return new Il({
    type: "literal",
    values: Array.isArray(e) ? e : [e],
    ...y.normalizeParams(r)
  });
}
u(Hm, "literal");
var wl = /* @__PURE__ */ f("ZodFile", (e, r) => {
  Fa.init(e, r), D.init(e, r), e._zod.processJSONSchema = (i, o, t) => ks(e, i, o, t), e.min = (i, o) => e.check(ve(i, o)), e.max = (i, o) => e.check(ze(i, o)), e.mime = (i, o) => e.check(pt(Array.isArray(i) ? i : [i], o));
});
function Qm(e) {
  return qc(wl, e);
}
u(Qm, "file");
var zl = /* @__PURE__ */ f("ZodTransform", (e, r) => {
  Be(), Ja.init(e, r), D.init(e, r), e._zod.processJSONSchema = (i, o, t) => zs(e, i, o, t), e._zod.parse = (i, o) => {
    if (o.direction === "backward")
      throw new xe(e.constructor.name);
    i.addIssue = (n) => {
      if (typeof n == "string")
        i.issues.push(y.issue(n, i.value, r));
      else {
        let a = n;
        a.fatal && (a.continue = !1), a.code ?? (a.code = "custom"), "input" in a || (a.input = i.value), a.inst ?? (a.inst = e), i.issues.push(y.issue(a));
      }
    };
    let t = r.transform(i.value, i);
    return t instanceof Promise ? t.then((n) => (i.value = n, i)) : (i.value = t, i);
  };
});
function yi(e) {
  return new zl({
    type: "transform",
    transform: e
  });
}
u(yi, "transform");
var hr = /* @__PURE__ */ f("ZodOptional", (e, r) => {
  cn.init(e, r), D.init(e, r), e._zod.processJSONSchema = (i, o, t) => Wn(e, i, o, t), e.unwrap = () => e._zod.def.innerType;
});
function Ge(e) {
  return new hr({
    type: "optional",
    innerType: e
  });
}
u(Ge, "optional");
var bi = /* @__PURE__ */ f("ZodExactOptional", (e, r) => {
  Ma.init(e, r), D.init(e, r), e._zod.processJSONSchema = (i, o, t) => Wn(e, i, o, t), e.unwrap = () => e._zod.def.innerType;
});
function Sl(e) {
  return new bi({
    type: "optional",
    innerType: e
  });
}
u(Sl, "exactOptional");
var jl = /* @__PURE__ */ f("ZodNullable", (e, r) => {
  Ka.init(e, r), D.init(e, r), e._zod.processJSONSchema = (i, o, t) => Ts(e, i, o, t), e.unwrap = () => e._zod.def.innerType;
});
function mr(e) {
  return new jl({
    type: "nullable",
    innerType: e
  });
}
u(mr, "nullable");
function ef(e) {
  return Ge(mr(e));
}
u(ef, "nullish");
var Pl = /* @__PURE__ */ f("ZodDefault", (e, r) => {
  Wa.init(e, r), D.init(e, r), e._zod.processJSONSchema = (i, o, t) => Es(e, i, o, t), e.unwrap = () => e._zod.def.innerType, e.removeDefault = e.unwrap;
});
function Dl(e, r) {
  return new Pl({
    type: "default",
    innerType: e,
    get defaultValue() {
      return typeof r == "function" ? r() : y.shallowClone(r);
    }
  });
}
u(Dl, "_default");
var Ol = /* @__PURE__ */ f("ZodPrefault", (e, r) => {
  Ga.init(e, r), D.init(e, r), e._zod.processJSONSchema = (i, o, t) => Cs(e, i, o, t), e.unwrap = () => e._zod.def.innerType;
});
function Ul(e, r) {
  return new Ol({
    type: "prefault",
    innerType: e,
    get defaultValue() {
      return typeof r == "function" ? r() : y.shallowClone(r);
    }
  });
}
u(Ul, "prefault");
var ki = /* @__PURE__ */ f("ZodNonOptional", (e, r) => {
  Ba.init(e, r), D.init(e, r), e._zod.processJSONSchema = (i, o, t) => Zs(e, i, o, t), e.unwrap = () => e._zod.def.innerType;
});
function Nl(e, r) {
  return new ki({
    type: "nonoptional",
    innerType: e,
    ...y.normalizeParams(r)
  });
}
u(Nl, "nonoptional");
var Tl = /* @__PURE__ */ f("ZodSuccess", (e, r) => {
  qa.init(e, r), D.init(e, r), e._zod.processJSONSchema = (i, o, t) => xs(e, i, o, t), e.unwrap = () => e._zod.def.innerType;
});
function tf(e) {
  return new Tl({
    type: "success",
    innerType: e
  });
}
u(tf, "success");
var Zl = /* @__PURE__ */ f("ZodCatch", (e, r) => {
  Xa.init(e, r), D.init(e, r), e._zod.processJSONSchema = (i, o, t) => Ls(e, i, o, t), e.unwrap = () => e._zod.def.innerType, e.removeCatch = e.unwrap;
});
function Al(e, r) {
  return new Zl({
    type: "catch",
    innerType: e,
    catchValue: typeof r == "function" ? r : y.constantCatch(r)
  });
}
u(Al, "_catch");
var El = /* @__PURE__ */ f("ZodNaN", (e, r) => {
  Ya.init(e, r), D.init(e, r), e._zod.processJSONSchema = (i, o, t) => ys(e, i, o, t);
});
function rf(e) {
  return Gc(El, e);
}
u(rf, "nan");
var _r = /* @__PURE__ */ f("ZodPipe", (e, r) => {
  sn.init(e, r), D.init(e, r), e._zod.processJSONSchema = (i, o, t) => Vs(e, i, o, t), e.in = r.in, e.out = r.out;
});
function Hn(e, r) {
  return new _r({
    type: "pipe",
    in: e,
    out: r
    // ...util.normalizeParams(params),
  });
}
u(Hn, "pipe");
var yr = /* @__PURE__ */ f("ZodCodec", (e, r) => {
  _r.init(e, r), Xt.init(e, r);
});
function nf(e, r, i) {
  return new yr({
    type: "pipe",
    in: e,
    out: r,
    transform: i.decode,
    reverseTransform: i.encode
  });
}
u(nf, "codec");
function of(e) {
  let r = e._zod.def;
  return new yr({
    type: "pipe",
    in: r.out,
    out: r.in,
    transform: r.reverseTransform,
    reverseTransform: r.transform
  });
}
u(of, "invertCodec");
var Cl = /* @__PURE__ */ f("ZodPreprocess", (e, r) => {
  _r.init(e, r), Ha.init(e, r);
}), Ll = /* @__PURE__ */ f("ZodReadonly", (e, r) => {
  Qa.init(e, r), D.init(e, r), e._zod.processJSONSchema = (i, o, t) => Rs(e, i, o, t), e.unwrap = () => e._zod.def.innerType;
});
function Vl(e) {
  return new Ll({
    type: "readonly",
    innerType: e
  });
}
u(Vl, "readonly");
var Rl = /* @__PURE__ */ f("ZodTemplateLiteral", (e, r) => {
  eu.init(e, r), D.init(e, r), e._zod.processJSONSchema = (i, o, t) => bs(e, i, o, t);
});
function af(e, r) {
  return new Rl({
    type: "template_literal",
    parts: e,
    ...y.normalizeParams(r)
  });
}
u(af, "templateLiteral");
var Fl = /* @__PURE__ */ f("ZodLazy", (e, r) => {
  Yt.init(e, r), D.init(e, r), e._zod.processJSONSchema = (i, o, t) => Js(e, i, o, t), e.unwrap = () => e._zod.def.getter();
});
function Jl(e) {
  return new Fl({
    type: "lazy",
    getter: e
  });
}
u(Jl, "lazy");
var Ml = /* @__PURE__ */ f("ZodPromise", (e, r) => {
  ru.init(e, r), D.init(e, r), e._zod.processJSONSchema = (i, o, t) => Fs(e, i, o, t), e.unwrap = () => e._zod.def.innerType;
});
function uf(e) {
  return new Ml({
    type: "promise",
    innerType: e
  });
}
u(uf, "promise");
var Kl = /* @__PURE__ */ f("ZodFunction", (e, r) => {
  tu.init(e, r), D.init(e, r), e._zod.processJSONSchema = (i, o, t) => ws(e, i, o, t);
});
function cf(e) {
  return new Kl({
    type: "function",
    input: Array.isArray(e?.input) ? yl(e?.input) : e?.input ?? gr(We()),
    output: e?.output ?? We()
  });
}
u(cf, "_function");
var br = /* @__PURE__ */ f("ZodCustom", (e, r) => {
  nu.init(e, r), D.init(e, r), e._zod.processJSONSchema = (i, o, t) => Is(e, i, o, t);
});
function sf(e) {
  let r = new L({
    check: "custom"
    // ...util.normalizeParams(params),
  });
  return r._zod.check = e, r;
}
u(sf, "check");
function lf(e, r) {
  return Xc(br, e ?? (() => !0), r);
}
u(lf, "custom");
function Wl(e, r = {}) {
  return Yc(br, e, r);
}
u(Wl, "refine");
function Gl(e, r) {
  return Hc(e, r);
}
u(Gl, "superRefine");
var df = Qc, mf = es;
function ff(e, r = {}) {
  let i = new br({
    type: "custom",
    check: "custom",
    fn: /* @__PURE__ */ u((o) => o instanceof e, "fn"),
    abort: !0,
    ...y.normalizeParams(r)
  });
  return i._zod.bag.Class = e, i._zod.check = (o) => {
    o.value instanceof e || o.issues.push({
      code: "invalid_type",
      expected: e.name,
      input: o.value,
      inst: i,
      path: [...i._zod.def.path ?? []]
    });
  }, i;
}
u(ff, "_instanceof");
var pf = /* @__PURE__ */ u((...e) => ts({
  Codec: yr,
  Boolean: St,
  String: It
}, ...e), "stringbool");
function gf(e) {
  let r = Jl(() => Pt([dr(e), il(), ol(), sl(), gr(r), bl(dr(), r)]));
  return r;
}
u(gf, "json");
function vf(e, r) {
  return new Cl({
    type: "pipe",
    in: yi(e),
    out: r
  });
}
u(vf, "preprocess");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/compat.js
var E$ = {
  invalid_type: "invalid_type",
  too_big: "too_big",
  too_small: "too_small",
  invalid_format: "invalid_format",
  not_multiple_of: "not_multiple_of",
  unrecognized_keys: "unrecognized_keys",
  invalid_union: "invalid_union",
  invalid_key: "invalid_key",
  invalid_element: "invalid_element",
  invalid_value: "invalid_value",
  custom: "custom"
};
function C$(e) {
  M({
    customError: e
  });
}
u(C$, "setErrorMap");
function L$() {
  return M().customError;
}
u(L$, "getErrorMap");
var Bl;
Bl || (Bl = {});

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/iso.js
var kr = {};
he(kr, {
  ZodISODate: () => Oe,
  ZodISODateTime: () => De,
  ZodISODuration: () => Ne,
  ZodISOTime: () => Ue,
  date: () => R$,
  datetime: () => V$,
  duration: () => J$,
  time: () => F$
});
function V$(e) {
  return or(De, e);
}
u(V$, "datetime");
function R$(e) {
  return ar(Oe, e);
}
u(R$, "date");
function F$(e) {
  return ur(Ue, e);
}
u(F$, "time");
function J$(e) {
  return cr(Ne, e);
}
u(J$, "duration");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/from-json-schema.js
var x = {
  ...Dt,
  ...qn,
  iso: kr
}, M$ = /* @__PURE__ */ new Set([
  // Schema identification
  "$schema",
  "$ref",
  "$defs",
  "definitions",
  // Core schema keywords
  "$id",
  "id",
  "$comment",
  "$anchor",
  "$vocabulary",
  "$dynamicRef",
  "$dynamicAnchor",
  // Type
  "type",
  "enum",
  "const",
  // Composition
  "anyOf",
  "oneOf",
  "allOf",
  "not",
  // Object
  "properties",
  "required",
  "additionalProperties",
  "patternProperties",
  "propertyNames",
  "minProperties",
  "maxProperties",
  // Array
  "items",
  "prefixItems",
  "additionalItems",
  "minItems",
  "maxItems",
  "uniqueItems",
  "contains",
  "minContains",
  "maxContains",
  // String
  "minLength",
  "maxLength",
  "pattern",
  "format",
  // Number
  "minimum",
  "maximum",
  "exclusiveMinimum",
  "exclusiveMaximum",
  "multipleOf",
  // Already handled metadata
  "description",
  "default",
  // Content
  "contentEncoding",
  "contentMediaType",
  "contentSchema",
  // Unsupported (error-throwing)
  "unevaluatedItems",
  "unevaluatedProperties",
  "if",
  "then",
  "else",
  "dependentSchemas",
  "dependentRequired",
  // OpenAPI
  "nullable",
  "readOnly"
]);
function K$(e, r) {
  let i = e.$schema;
  return i === "https://json-schema.org/draft/2020-12/schema" ? "draft-2020-12" : i === "http://json-schema.org/draft-07/schema#" ? "draft-7" : i === "http://json-schema.org/draft-04/schema#" ? "draft-4" : r ?? "draft-2020-12";
}
u(K$, "detectVersion");
function $f(e, r) {
  return e.map((i, o) => o < r ? i : i.optional());
}
u($f, "applyMinItems");
function W$(e) {
  return e.replace(/~1/g, "/").replace(/~0/g, "~");
}
u(W$, "decodeJSONPointerSegment");
function G$(e, r) {
  if (!e.startsWith("#"))
    throw new Error("External $ref is not supported, only local refs (#/...) are allowed");
  let i = e.slice(1).split("/").filter(Boolean);
  if (i.length === 0)
    return r.rootSchema;
  let o = r.version === "draft-2020-12" ? "$defs" : "definitions";
  if (i[0] === o) {
    let t = i[1] === void 0 ? void 0 : W$(i[1]);
    if (!t || !r.defs[t])
      throw new Error(`Reference not found: ${e}`);
    return r.defs[t];
  }
  throw new Error(`Reference not found: ${e}`);
}
u(G$, "resolveRef");
function B$(e, r) {
  return x.transform((o) => o).check((o) => {
    let t = o.value;
    if (!(typeof t != "object" || t === null || Array.isArray(t)))
      for (let n of Object.getOwnPropertyNames(t)) {
        let a = r.safeParse(n);
        a.success || o.issues.push({
          code: "invalid_key",
          origin: "record",
          issues: a.error.issues,
          input: n,
          path: [n],
          continue: !0
        });
      }
  }).pipe(e);
}
u(B$, "checkPropertyNames");
function hf(e, r) {
  if (e !== !1)
    return e === void 0 || e === !0 ? x.any() : oe(e, r);
}
u(hf, "getTupleRest");
var q$ = /^(?:[01]\d|2[0-3]):[0-5]\d:[0-5]\d(?:\.\d+)?(?:Z|[+-](?:[01]\d|2[0-3]):[0-5]\d)$/;
function _f(e, r) {
  if (e.not !== void 0) {
    if (typeof e.not == "object" && Object.keys(e.not).length === 0)
      return x.never();
    throw new Error("not is not supported in Zod (except { not: {} } for never)");
  }
  if (e.unevaluatedItems !== void 0)
    throw new Error("unevaluatedItems is not supported");
  if (e.unevaluatedProperties !== void 0)
    throw new Error("unevaluatedProperties is not supported");
  if (e.if !== void 0 || e.then !== void 0 || e.else !== void 0)
    throw new Error("Conditional schemas (if/then/else) are not supported");
  if (e.dependentSchemas !== void 0 || e.dependentRequired !== void 0)
    throw new Error("dependentSchemas and dependentRequired are not supported");
  if (e.$ref) {
    let t = e.$ref;
    if (r.refs.has(t))
      return r.refs.get(t);
    if (r.processing.has(t))
      return x.lazy(() => {
        if (!r.refs.has(t))
          throw new Error(`Circular reference not resolved: ${t}`);
        return r.refs.get(t);
      });
    r.processing.add(t);
    let n = G$(t, r), a = oe(n, r);
    return r.refs.set(t, a), r.processing.delete(t), a;
  }
  if (e.enum !== void 0) {
    let t = e.enum;
    if (r.version === "openapi-3.0" && e.nullable === !0 && t.length === 1 && t[0] === null)
      return x.null();
    if (t.length === 0)
      return x.never();
    if (t.length === 1)
      return x.literal(t[0]);
    if (t.every((a) => typeof a == "string"))
      return x.enum(t);
    let n = t.map((a) => x.literal(a));
    return n.length < 2 ? n[0] : x.union([n[0], n[1], ...n.slice(2)]);
  }
  if (e.const !== void 0)
    return x.literal(e.const);
  let i = e.type;
  if (Array.isArray(i)) {
    let t = i.map((n) => {
      let a = { ...e, type: n };
      return _f(a, r);
    });
    return t.length === 0 ? x.never() : t.length === 1 ? t[0] : x.union(t);
  }
  if (!i)
    return x.any();
  let o;
  switch (i) {
    case "string": {
      let t = x.string();
      if (e.format) {
        let n = e.format;
        n === "email" ? t = t.check(x.email()) : n === "uri" || n === "uri-reference" ? t = t.check(x.url()) : n === "uuid" || n === "guid" ? t = t.check(x.uuid()) : n === "date-time" ? t = t.check(x.iso.datetime({ offset: !0 })) : n === "date" ? t = t.check(x.iso.date()) : n === "time" ? t = t.check(x.regex(q$)) : n === "duration" ? t = t.check(x.iso.duration()) : n === "hostname" ? t = t.check(x.hostname()) : n === "ipv4" ? t = t.check(x.ipv4()) : n === "ipv6" ? t = t.check(x.ipv6()) : n === "mac" ? t = t.check(x.mac()) : n === "cidr" ? t = t.check(x.cidrv4()) : n === "cidr-v6" ? t = t.check(x.cidrv6()) : n === "base64" ? t = t.check(x.base64()) : n === "base64url" ? t = t.check(x.base64url()) : n === "e164" ? t = t.check(x.e164()) : n === "credit_card" ? t = t.check(x.creditCard()) : n === "jwt" ? t = t.check(x.jwt()) : n === "emoji" ? t = t.check(x.emoji()) : n === "nanoid" ? t = t.check(x.nanoid()) : n === "cuid" ? t = t.check(x.cuid()) : n === "cuid2" ? t = t.check(x.cuid2()) : n === "ulid" ? t = t.check(x.ulid()) : n === "xid" ? t = t.check(x.xid()) : n === "ksuid" && (t = t.check(x.ksuid()));
      }
      typeof e.minLength == "number" && (t = t.min(e.minLength)), typeof e.maxLength == "number" && (t = t.max(e.maxLength)), e.pattern && (t = t.regex(new RegExp(e.pattern))), o = t;
      break;
    }
    case "number":
    case "integer": {
      let t = i === "integer" ? x.number().int() : x.number();
      typeof e.minimum == "number" && e.exclusiveMinimum !== !0 && (t = t.min(e.minimum)), typeof e.maximum == "number" && e.exclusiveMaximum !== !0 && (t = t.max(e.maximum)), typeof e.exclusiveMinimum == "number" ? t = t.gt(e.exclusiveMinimum) : e.exclusiveMinimum === !0 && typeof e.minimum == "number" && (t = t.gt(e.minimum)), typeof e.exclusiveMaximum == "number" ? t = t.lt(e.exclusiveMaximum) : e.exclusiveMaximum === !0 && typeof e.maximum == "number" && (t = t.lt(e.maximum)), typeof e.multipleOf == "number" && (t = t.multipleOf(e.multipleOf)), o = t;
      break;
    }
    case "boolean": {
      o = x.boolean();
      break;
    }
    case "null": {
      o = x.null();
      break;
    }
    case "object": {
      let t = {}, n = e.properties || {}, a = new Set(e.required || []), c = typeof e.additionalProperties == "object" ? oe(e.additionalProperties, r) : void 0;
      for (let [s, l] of Object.entries(n)) {
        let d = oe(l, r);
        J(t, s, a.has(s) ? d : d.optional());
      }
      if (e.patternProperties) {
        let s = e.patternProperties, l = Object.keys(s), d = [];
        for (let g of l) {
          let v = oe(s[g], r), $ = x.string().regex(new RegExp(g));
          d.push(x.looseRecord($, v));
        }
        let m = [];
        if (Object.keys(t).length > 0 && m.push(x.object(t).passthrough()), m.push(...d), m.length === 0)
          o = x.object({}).passthrough();
        else if (m.length === 1)
          o = m[0];
        else {
          let g = x.intersection(m[0], m[1]);
          for (let v = 2; v < m.length; v++)
            g = x.intersection(g, m[v]);
          o = g;
        }
        if (e.additionalProperties === !1) {
          let g = Object.keys(t), v = l.map((k) => new RegExp(k)), $ = o;
          o = o.check((k) => {
            if (!se(k.value))
              return;
            let I = [];
            for (let A of Object.keys(k.value))
              g.includes(A) || v.some((w) => w.test(A)) || I.push(A);
            I.length && k.issues.push({
              code: "unrecognized_keys",
              keys: I,
              input: k.value,
              inst: $
            });
          });
        }
      } else {
        let s = x.object(t);
        e.additionalProperties === !1 ? o = s.strict() : c ? o = s.catchall(c) : o = s.passthrough();
      }
      if (e.propertyNames !== void 0 && e.propertyNames !== !0) {
        let s = typeof e.propertyNames == "object" && e.propertyNames.type === void 0 ? { type: "string", ...e.propertyNames } : e.propertyNames;
        o = B$(o, oe(s, r));
      }
      break;
    }
    case "array": {
      let t = e.prefixItems, n = e.items;
      if (t && Array.isArray(t)) {
        let a = typeof e.minItems == "number" ? e.minItems : 0, c = t.map((m) => oe(m, r)), s = $f(c, a), l = Array.isArray(n) ? void 0 : hf(n, r), d = x.tuple(s);
        o = l ? d.rest(l) : d, typeof e.minItems == "number" && (o = o.check(x.minLength(e.minItems))), typeof e.maxItems == "number" && (o = o.check(x.maxLength(e.maxItems)));
      } else if (Array.isArray(n)) {
        let a = typeof e.minItems == "number" ? e.minItems : 0, c = n.map((m) => oe(m, r)), s = $f(c, a), l = hf(e.additionalItems, r), d = x.tuple(s);
        o = l ? d.rest(l) : d, typeof e.minItems == "number" && (o = o.check(x.minLength(e.minItems))), typeof e.maxItems == "number" && (o = o.check(x.maxLength(e.maxItems)));
      } else if (n !== void 0) {
        let a = oe(n, r), c = x.array(a);
        typeof e.minItems == "number" && (c = c.min(e.minItems)), typeof e.maxItems == "number" && (c = c.max(e.maxItems)), o = c;
      } else
        o = x.array(x.any());
      break;
    }
    default:
      throw new Error(`Unsupported type: ${i}`);
  }
  return o;
}
u(_f, "convertBaseSchema");
function oe(e, r) {
  if (typeof e == "boolean")
    return e ? x.any() : x.never();
  let i = _f(e, r), o = e.type || e.enum !== void 0 || e.const !== void 0;
  if (e.anyOf && Array.isArray(e.anyOf)) {
    let c = e.anyOf.map((l) => oe(l, r)), s = x.union(c);
    i = o ? x.intersection(i, s) : s;
  }
  if (e.oneOf && Array.isArray(e.oneOf)) {
    let c = e.oneOf.map((l) => oe(l, r)), s = x.xor(c);
    i = o ? x.intersection(i, s) : s;
  }
  if (e.allOf && Array.isArray(e.allOf))
    if (e.allOf.length === 0)
      i = o ? i : x.any();
    else {
      let c = o ? i : oe(e.allOf[0], r), s = o ? 0 : 1;
      for (let l = s; l < e.allOf.length; l++)
        c = x.intersection(c, oe(e.allOf[l], r));
      i = c;
    }
  e.nullable === !0 && r.version === "openapi-3.0" && (i = x.nullable(i)), e.readOnly === !0 && (i = x.readonly(i)), e.default !== void 0 && (i = i.default(e.default));
  let t = {}, n = ["$id", "id", "$comment", "$anchor", "$vocabulary", "$dynamicRef", "$dynamicAnchor"];
  for (let c of n)
    c in e && (t[c] = e[c]);
  let a = ["contentEncoding", "contentMediaType", "contentSchema"];
  for (let c of a)
    c in e && (t[c] = e[c]);
  e.propertyNames !== void 0 && e.type === "object" && e.$ref === void 0 && (t.propertyNames = e.propertyNames);
  for (let c of Object.keys(e))
    M$.has(c) || J(t, c, e[c]);
  return Object.keys(t).length > 0 && r.registry.add(i, t), e.description && (i = i.describe(e.description)), i;
}
u(oe, "convertSchema");
function yf(e, r) {
  if (typeof e == "boolean")
    return e ? x.any() : x.never();
  let i;
  try {
    i = JSON.parse(JSON.stringify(e));
  } catch {
    throw new Error("fromJSONSchema input is not valid JSON (possibly cyclic); use $defs/$ref for recursive schemas");
  }
  let o = K$(i, r?.defaultTarget), t = i.$defs || i.definitions || {}, n = {
    version: o,
    defs: t,
    refs: /* @__PURE__ */ new Map(),
    processing: /* @__PURE__ */ new Set(),
    rootSchema: i,
    registry: r?.registry ?? B
  };
  return oe(i, n);
}
u(yf, "fromJSONSchema");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/visit.js
var bf = Symbol("z.visit/resolving");
function xr(e, r) {
  let i = typeof r == "function" ? r : (a, c) => {
    let s = r[a._zod.def.type];
    return s ? s(a, c) : a;
  }, o = /* @__PURE__ */ new Map();
  function t(a) {
    let c = o.get(a);
    if (c === bf)
      return new Yt({
        type: "lazy",
        getter: /* @__PURE__ */ u(() => o.get(a), "getter")
      });
    if (c !== void 0)
      return c;
    o.set(a, bf);
    let s = n(a), l = i(s, s !== a);
    return o.set(a, l), l;
  }
  u(t, "run");
  function n(a) {
    let c = a._zod.def, s = c.type;
    switch (s) {
      case "object": {
        let l = c.shape, d = Object.keys(l), m = !1, g = {};
        for (let $ of d) {
          let k = t(l[$]);
          k !== l[$] && (m = !0), g[$] = k;
        }
        let v = c.catchall;
        return c.catchall && (v = t(c.catchall), v !== c.catchall && (m = !0)), m ? T(a, { ...c, shape: g, catchall: v }) : a;
      }
      case "array": {
        let l = t(c.element);
        return l === c.element ? a : T(a, { ...c, element: l });
      }
      case "tuple": {
        let l = c.items, d = !1, m = [];
        for (let v of l) {
          let $ = t(v);
          $ !== v && (d = !0), m.push($);
        }
        let g = c.rest;
        return c.rest && (g = t(c.rest), g !== c.rest && (d = !0)), d ? T(a, { ...c, items: m, rest: g }) : a;
      }
      case "record":
      case "map": {
        let l = t(c.keyType), d = t(c.valueType);
        return l === c.keyType && d === c.valueType ? a : T(a, { ...c, keyType: l, valueType: d });
      }
      case "set": {
        let l = t(c.valueType);
        return l === c.valueType ? a : T(a, { ...c, valueType: l });
      }
      case "union": {
        let l = c.options, d = !1, m = [];
        for (let g of l) {
          let v = t(g);
          v !== g && (d = !0), m.push(v);
        }
        return d ? T(a, { ...c, options: m }) : a;
      }
      case "intersection": {
        let l = t(c.left), d = t(c.right);
        return l === c.left && d === c.right ? a : T(a, { ...c, left: l, right: d });
      }
      case "optional":
      case "nullable":
      case "default":
      case "prefault":
      case "catch":
      case "readonly":
      case "nonoptional":
      case "promise":
      case "success": {
        let l = t(c.innerType);
        return l === c.innerType ? a : T(a, { ...c, innerType: l });
      }
      case "pipe": {
        let l = t(c.in), d = t(c.out);
        return l === c.in && d === c.out ? a : T(a, { ...c, in: l, out: d });
      }
      case "function": {
        let l = t(c.input), d = t(c.output);
        return l === c.input && d === c.output ? a : T(a, { ...c, input: l, output: d });
      }
      case "lazy": {
        let l = c.getter, { _cachedInner: d, ...m } = c;
        return T(a, { ...m, getter: /* @__PURE__ */ u(() => t(l()), "getter") });
      }
      // A leaf by choice: `parts` are regex fragments, not data positions.
      case "template_literal":
      // Leaves.
      case "string":
      case "number":
      case "int":
      case "boolean":
      case "bigint":
      case "symbol":
      case "undefined":
      case "null":
      case "void":
      case "never":
      case "any":
      case "unknown":
      case "date":
      case "nan":
      case "enum":
      case "literal":
      case "file":
      case "transform":
      case "custom":
        return a;
      default:
        return a;
    }
  }
  return u(n, "mapInner"), t(e);
}
u(xr, "visit");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/deep-partial.js
function kf(e) {
  return xr(e, {
    object: /* @__PURE__ */ u((r) => r.partial(), "object"),
    // Every partialed option now admits `undefined`, which the constructor rejects as a duplicate.
    union: /* @__PURE__ */ u((r) => {
      let i = r._zod.def;
      return i.discriminator === void 0 ? r : Pt(i.options);
    }, "union")
  });
}
u(kf, "deepPartial");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/in-out.js
function X$(e, r) {
  if (!r?.length)
    return e;
  let i = e._zod.def;
  return T(e, de(i, { checks: [...i.checks ?? [], ...r] }), { parent: !0 });
}
u(X$, "withChecks");
function xf(e) {
  return X$(e.out, e.checks);
}
u(xf, "outSide");
function Y$(e) {
  return e.in._zod.traits.has("$ZodTransform") ? xf(e) : e.in;
}
u(Y$, "inSide");
function If(e) {
  return xr(e, {
    pipe: /* @__PURE__ */ u((r) => Y$(r._zod.def), "pipe"),
    // A default value belongs to the output side, so a rewritten inner type leaves it stranded. `.default()` widens the declared input type with `undefined`, and `optional` is what carries that across.
    default: /* @__PURE__ */ u((r, i) => i ? Ge(r._zod.def.innerType) : r, "default"),
    // A catch value is output-side too, but `.catch()` leaves the declared input type alone, so the inner schema stands on its own.
    catch: /* @__PURE__ */ u((r, i) => i ? r._zod.def.innerType : r, "catch")
  });
}
u(If, "input");
function wf(e) {
  return xr(e, {
    pipe: /* @__PURE__ */ u((r) => xf(r._zod.def), "pipe"),
    // A prefault value is fed through the schema, which makes it input-side, so a rewritten inner type leaves it stranded.
    prefault: /* @__PURE__ */ u((r, i) => i ? r._zod.def.innerType : r, "prefault")
  });
}
u(wf, "output");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/coerce.js
var ql = {};
he(ql, {
  bigint: () => th,
  boolean: () => eh,
  date: () => rh,
  number: () => Q$,
  string: () => H$
});
function H$(e) {
  return bc(It, e);
}
u(H$, "string");
function Q$(e) {
  return zc(zt, e);
}
u(Q$, "number");
function eh(e) {
  return Nc(St, e);
}
u(eh, "boolean");
function th(e) {
  return Zc(jt, e);
}
u(th, "bigint");
function rh(e) {
  return Wc(pr, e);
}
u(rh, "date");

// convex/shared/shape.ts
var xi = class {
  constructor(r) {
    this.value = r;
  }
  static {
    u(this, "SecretText");
  }
  toWire() {
    return this.value;
  }
};
function yx(e) {
  let r = /* @__PURE__ */ u(() => W.codec(W.number(), W.date(), {
    decode: /* @__PURE__ */ u((t) => new Date(t), "decode"),
    encode: /* @__PURE__ */ u((t) => t.getTime(), "encode")
  }), "date"), i = /* @__PURE__ */ u(() => W.codec(W.string(), W.instanceof(xi), {
    decode: /* @__PURE__ */ u((t) => new xi(t), "decode"),
    encode: /* @__PURE__ */ u((t) => t.toWire(), "encode")
  }), "secret"), o = {};
  for (let t = 0; t < e; t++)
    switch (t % 4) {
      case 0:
        o[`f${t}`] = r();
        break;
      case 1:
        o[`f${t}`] = i();
        break;
      case 2:
        o[`f${t}`] = W.discriminatedUnion("kind", [
          W.object({ kind: W.literal("dated"), at: r(), tag: W.string().optional() }),
          W.object({ kind: W.literal("text"), secret: i() })
        ]);
        break;
      case 3:
        o[`f${t}`] = W.array(W.union([W.string(), W.number()]));
        break;
    }
  return o;
}
u(yx, "makeFields");
function bx(e) {
  let r = {};
  for (let i = 0; i < e; i++)
    switch (i % 4) {
      case 0:
        r[`f${i}`] = 17e11 + i;
        break;
      case 1:
        r[`f${i}`] = `item-${i}`;
        break;
      case 2:
        r[`f${i}`] = Math.floor(i / 4) % 2 === 0 ? { kind: "dated", at: 17e11 + i } : { kind: "text", secret: `item-${i}` };
        break;
      case 3:
        r[`f${i}`] = ["entry", i];
        break;
    }
  return r;
}
u(bx, "makeWire");

export {
  T as a,
  Pr as b,
  fp as c,
  j as d,
  Ce as e,
  on as f,
  Bt as g,
  an as h,
  xa as i,
  Ia as j,
  wa as k,
  za as l,
  Sa as m,
  ja as n,
  Pa as o,
  Da as p,
  Oa as q,
  Pd as r,
  qt as s,
  Za as t,
  Aa as u,
  un as v,
  Ea as w,
  Ca as x,
  La as y,
  Va as z,
  Ra as A,
  Fa as B,
  Ja as C,
  cn as D,
  Ka as E,
  Wa as F,
  Ba as G,
  Xa as H,
  Ya as I,
  sn as J,
  Qa as K,
  eu as L,
  tu as M,
  ru as N,
  Yt as O,
  nu as P,
  gn as Q,
  Fm as R,
  W as S,
  xi as T,
  yx as U,
  bx as V
};
//# sourceMappingURL=WWZ3L44K.js.map
