import {
  T as d,
  V as p
} from "./WWZ3L44K.js";
import {
  a as w
} from "./5B5TEMMX.js";

// convex/shared/operation.ts
function y(t, k, a, l) {
  let n = p(k), e = a(t, n);
  if (!(e.f0 instanceof Date) || !(e.f1 instanceof d))
    throw new Error("Top-level codec decode failed");
  let i = e.f2, o = e.f6;
  if (i.kind !== "dated" || !(i.at instanceof Date) || o.kind !== "text" || !(o.secret instanceof d))
    throw new Error("Nested union codec decode failed");
  e.f0 = new Date(e.f0.getTime() + 1e3), e.f1 = new d(e.f1.toWire().toUpperCase()), i.at = new Date(i.at.getTime() + 2e3);
  let r = l(t, e), m = {
    ...n,
    f0: 1700000001e3,
    f1: "ITEM-1",
    f2: { kind: "dated", at: 1700000002002 }
  };
  if (JSON.stringify(r) !== JSON.stringify(m))
    throw new Error("Codec round trip changed wire values");
  let c = !1;
  try {
    a(t, { ...n, f0: "invalid timestamp" });
  } catch {
    c = !0;
  }
  let f = !1;
  try {
    a(t, { ...n, f2: { kind: "dated", at: "invalid timestamp" } });
  } catch {
    f = !0;
  }
  let s = !1;
  try {
    a(t, { ...n, f0: 1e100 });
  } catch {
    s = !0;
  }
  let u = !1;
  try {
    l(t, { ...e, f0: "not a Date" });
  } catch {
    u = !0;
  }
  if (!c || !f || !u || !s)
    throw new Error("Codec validation accepted an invalid value");
  return {
    date: r.f0,
    secret: r.f1,
    nestedDate: r.f2.at,
    nestedSecret: o.secret.toWire(),
    arrayNumber: r.f3[1],
    roundTrip: !0,
    invalidInputRejected: c,
    invalidUnionRejected: f,
    invalidOutputRejected: u,
    wireValidInvalidInputRejected: s
  };
}
w(y, "exercise");

export {
  y as a
};
//# sourceMappingURL=AQJ3QLJ2.js.map
