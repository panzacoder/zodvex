import {
  a as v,
  b as h,
  c as d,
  d as x,
  e as ce,
  f as le,
  g as j,
  h as i,
  i as de
} from "./W3VG7GIX.js";
import {
  a as n
} from "./5B5TEMMX.js";

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/index.js
var f = "1.32.0";

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/syscall.js
function E(t, e) {
  if (typeof Convex > "u" || Convex.syscall === void 0)
    throw new Error(
      "The Convex database and auth objects are being used outside of a Convex backend. Did you mean to use `useQuery` or `useMutation` to call a Convex function?"
    );
  let r = Convex.syscall(t, JSON.stringify(e));
  return JSON.parse(r);
}
n(E, "performSyscall");
async function c(t, e) {
  if (typeof Convex > "u" || Convex.asyncSyscall === void 0)
    throw new Error(
      "The Convex database and auth objects are being used outside of a Convex backend. Did you mean to use `useQuery` or `useMutation` to call a Convex function?"
    );
  let r;
  try {
    r = await Convex.asyncSyscall(t, JSON.stringify(e));
  } catch (o) {
    if (o.data !== void 0) {
      let s = new de(o.message);
      throw s.data = h(o.data), s;
    }
    throw new Error(o.message);
  }
  return JSON.parse(r);
}
n(c, "performAsyncSyscall");
function C(t, e) {
  if (typeof Convex > "u" || Convex.jsSyscall === void 0)
    throw new Error(
      "The Convex database and auth objects are being used outside of a Convex backend. Did you mean to use `useQuery` or `useMutation` to call a Convex function?"
    );
  return Convex.jsSyscall(t, e);
}
n(C, "performJsSyscall");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/functionName.js
var I = Symbol.for("functionName");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/components/paths.js
var pe = Symbol.for("toReferencePath");
function Je(t) {
  return t[pe] ?? null;
}
n(Je, "extractReferencePath");
function Ue(t) {
  return t.startsWith("function://");
}
n(Ue, "isFunctionHandle");
function w(t) {
  let e;
  if (typeof t == "string")
    Ue(t) ? e = { functionHandle: t } : e = { name: t };
  else if (t[I])
    e = { name: t[I] };
  else {
    let r = Je(t);
    if (!r)
      throw new Error(`${t} is not a functionReference`);
    e = { reference: r };
  }
  return e;
}
n(w, "getFunctionAddress");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/actions_impl.js
function Q(t, e, r) {
  return {
    ...w(e),
    args: d(v(r)),
    version: f,
    requestId: t
  };
}
n(Q, "syscallArgs");
function fe(t) {
  return {
    runQuery: /* @__PURE__ */ n(async (e, r) => {
      let o = await c(
        "1.0/actions/query",
        Q(t, e, r)
      );
      return h(o);
    }, "runQuery"),
    runMutation: /* @__PURE__ */ n(async (e, r) => {
      let o = await c(
        "1.0/actions/mutation",
        Q(t, e, r)
      );
      return h(o);
    }, "runMutation"),
    runAction: /* @__PURE__ */ n(async (e, r) => {
      let o = await c(
        "1.0/actions/action",
        Q(t, e, r)
      );
      return h(o);
    }, "runAction")
  };
}
n(fe, "setupActionCalls");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/vector_search.js
var je = Object.defineProperty, Qe = /* @__PURE__ */ n((t, e, r) => e in t ? je(t, e, { enumerable: !0, configurable: !0, writable: !0, value: r }) : t[e] = r, "__defNormalProp"), he = /* @__PURE__ */ n((t, e, r) => Qe(t, typeof e != "symbol" ? e + "" : e, r), "__publicField"), N = class {
  static {
    n(this, "FilterExpression");
  }
  /**
   * @internal
   */
  constructor() {
    he(this, "_isExpression"), he(this, "_value");
  }
};

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/validate.js
function a(t, e, r, o) {
  if (t === void 0)
    throw new TypeError(
      `Must provide arg ${e} \`${o}\` to \`${r}\``
    );
}
n(a, "validateArg");
function me(t, e, r, o) {
  if (!Number.isInteger(t) || t < 0)
    throw new TypeError(
      `Arg ${e} \`${o}\` to \`${r}\` must be a non-negative integer`
    );
}
n(me, "validateArgIsNonNegativeInteger");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/vector_search_impl.js
var Ge = Object.defineProperty, He = /* @__PURE__ */ n((t, e, r) => e in t ? Ge(t, e, { enumerable: !0, configurable: !0, writable: !0, value: r }) : t[e] = r, "__defNormalProp"), G = /* @__PURE__ */ n((t, e, r) => He(t, typeof e != "symbol" ? e + "" : e, r), "__publicField");
function ye(t) {
  return async (e, r, o) => {
    if (a(e, 1, "vectorSearch", "tableName"), a(r, 2, "vectorSearch", "indexName"), a(o, 3, "vectorSearch", "query"), !o.vector || !Array.isArray(o.vector) || o.vector.length === 0)
      throw Error("`vector` must be a non-empty Array in vectorSearch");
    return await new H(
      t,
      e + "." + r,
      o
    ).collect();
  };
}
n(ye, "setupActionVectorSearch");
var H = class {
  static {
    n(this, "VectorQueryImpl");
  }
  constructor(e, r, o) {
    G(this, "requestId"), G(this, "state"), this.requestId = e;
    let s = o.filter ? $(o.filter(ze)) : null;
    this.state = {
      type: "preparing",
      query: {
        indexName: r,
        limit: o.limit,
        vector: o.vector,
        expressions: s
      }
    };
  }
  async collect() {
    if (this.state.type === "consumed")
      throw new Error("This query is closed and can't emit any more values.");
    let e = this.state.query;
    this.state = { type: "consumed" };
    let { results: r } = await c("1.0/actions/vectorSearch", {
      requestId: this.requestId,
      version: f,
      query: e
    });
    return r;
  }
}, S = class extends N {
  static {
    n(this, "ExpressionImpl");
  }
  constructor(e) {
    super(), G(this, "inner"), this.inner = e;
  }
  serialize() {
    return this.inner;
  }
};
function $(t) {
  return t instanceof S ? t.serialize() : { $literal: x(t) };
}
n($, "serializeExpression");
var ze = {
  //  Comparisons  /////////////////////////////////////////////////////////////
  eq(t, e) {
    if (typeof t != "string")
      throw new Error("The first argument to `q.eq` must be a field name.");
    return new S({
      $eq: [
        $(new S({ $field: t })),
        $(e)
      ]
    });
  },
  //  Logic  ///////////////////////////////////////////////////////////////////
  or(...t) {
    return new S({ $or: t.map($) });
  }
};

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/authentication_impl.js
function q(t) {
  return {
    getUserIdentity: /* @__PURE__ */ n(async () => await c("1.0/getUserIdentity", {
      requestId: t
    }), "getUserIdentity")
  };
}
n(q, "setupAuth");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/filter_builder.js
var Ve = Object.defineProperty, We = /* @__PURE__ */ n((t, e, r) => e in t ? Ve(t, e, { enumerable: !0, configurable: !0, writable: !0, value: r }) : t[e] = r, "__defNormalProp"), xe = /* @__PURE__ */ n((t, e, r) => We(t, typeof e != "symbol" ? e + "" : e, r), "__publicField"), R = class {
  static {
    n(this, "Expression");
  }
  /**
   * @internal
   */
  constructor() {
    xe(this, "_isExpression"), xe(this, "_value");
  }
};

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/filter_builder_impl.js
var Be = Object.defineProperty, De = /* @__PURE__ */ n((t, e, r) => e in t ? Be(t, e, { enumerable: !0, configurable: !0, writable: !0, value: r }) : t[e] = r, "__defNormalProp"), ke = /* @__PURE__ */ n((t, e, r) => De(t, typeof e != "symbol" ? e + "" : e, r), "__publicField"), m = class extends R {
  static {
    n(this, "ExpressionImpl");
  }
  constructor(e) {
    super(), ke(this, "inner"), this.inner = e;
  }
  serialize() {
    return this.inner;
  }
};
function l(t) {
  return t instanceof m ? t.serialize() : { $literal: x(t) };
}
n(l, "serializeExpression");
var we = {
  //  Comparisons  /////////////////////////////////////////////////////////////
  eq(t, e) {
    return new m({
      $eq: [l(t), l(e)]
    });
  },
  neq(t, e) {
    return new m({
      $neq: [l(t), l(e)]
    });
  },
  lt(t, e) {
    return new m({
      $lt: [l(t), l(e)]
    });
  },
  lte(t, e) {
    return new m({
      $lte: [l(t), l(e)]
    });
  },
  gt(t, e) {
    return new m({
      $gt: [l(t), l(e)]
    });
  },
  gte(t, e) {
    return new m({
      $gte: [l(t), l(e)]
    });
  },
  //  Arithmetic  //////////////////////////////////////////////////////////////
  add(t, e) {
    return new m({
      $add: [l(t), l(e)]
    });
  },
  sub(t, e) {
    return new m({
      $sub: [l(t), l(e)]
    });
  },
  mul(t, e) {
    return new m({
      $mul: [l(t), l(e)]
    });
  },
  div(t, e) {
    return new m({
      $div: [l(t), l(e)]
    });
  },
  mod(t, e) {
    return new m({
      $mod: [l(t), l(e)]
    });
  },
  neg(t) {
    return new m({ $neg: l(t) });
  },
  //  Logic  ///////////////////////////////////////////////////////////////////
  and(...t) {
    return new m({ $and: t.map(l) });
  },
  or(...t) {
    return new m({ $or: t.map(l) });
  },
  not(t) {
    return new m({ $not: l(t) });
  },
  //  Other  ///////////////////////////////////////////////////////////////////
  field(t) {
    return new m({ $field: t });
  }
};

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/index_range_builder.js
var Le = Object.defineProperty, Ye = /* @__PURE__ */ n((t, e, r) => e in t ? Le(t, e, { enumerable: !0, configurable: !0, writable: !0, value: r }) : t[e] = r, "__defNormalProp"), Ke = /* @__PURE__ */ n((t, e, r) => Ye(t, typeof e != "symbol" ? e + "" : e, r), "__publicField"), F = class {
  static {
    n(this, "IndexRange");
  }
  /**
   * @internal
   */
  constructor() {
    Ke(this, "_isIndexRange");
  }
};

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/index_range_builder_impl.js
var Xe = Object.defineProperty, Ze = /* @__PURE__ */ n((t, e, r) => e in t ? Xe(t, e, { enumerable: !0, configurable: !0, writable: !0, value: r }) : t[e] = r, "__defNormalProp"), ge = /* @__PURE__ */ n((t, e, r) => Ze(t, typeof e != "symbol" ? e + "" : e, r), "__publicField"), O = class t extends F {
  static {
    n(this, "IndexRangeBuilderImpl");
  }
  constructor(e) {
    super(), ge(this, "rangeExpressions"), ge(this, "isConsumed"), this.rangeExpressions = e, this.isConsumed = !1;
  }
  static new() {
    return new t([]);
  }
  consume() {
    if (this.isConsumed)
      throw new Error(
        "IndexRangeBuilder has already been used! Chain your method calls like `q => q.eq(...).eq(...)`. See https://docs.convex.dev/using/indexes"
      );
    this.isConsumed = !0;
  }
  eq(e, r) {
    return this.consume(), new t(
      this.rangeExpressions.concat({
        type: "Eq",
        fieldPath: e,
        value: x(r)
      })
    );
  }
  gt(e, r) {
    return this.consume(), new t(
      this.rangeExpressions.concat({
        type: "Gt",
        fieldPath: e,
        value: x(r)
      })
    );
  }
  gte(e, r) {
    return this.consume(), new t(
      this.rangeExpressions.concat({
        type: "Gte",
        fieldPath: e,
        value: x(r)
      })
    );
  }
  lt(e, r) {
    return this.consume(), new t(
      this.rangeExpressions.concat({
        type: "Lt",
        fieldPath: e,
        value: x(r)
      })
    );
  }
  lte(e, r) {
    return this.consume(), new t(
      this.rangeExpressions.concat({
        type: "Lte",
        fieldPath: e,
        value: x(r)
      })
    );
  }
  export() {
    return this.consume(), this.rangeExpressions;
  }
};

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/search_filter_builder.js
var et = Object.defineProperty, tt = /* @__PURE__ */ n((t, e, r) => e in t ? et(t, e, { enumerable: !0, configurable: !0, writable: !0, value: r }) : t[e] = r, "__defNormalProp"), rt = /* @__PURE__ */ n((t, e, r) => tt(t, typeof e != "symbol" ? e + "" : e, r), "__publicField"), M = class {
  static {
    n(this, "SearchFilter");
  }
  /**
   * @internal
   */
  constructor() {
    rt(this, "_isSearchFilter");
  }
};

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/search_filter_builder_impl.js
var nt = Object.defineProperty, ot = /* @__PURE__ */ n((t, e, r) => e in t ? nt(t, e, { enumerable: !0, configurable: !0, writable: !0, value: r }) : t[e] = r, "__defNormalProp"), ve = /* @__PURE__ */ n((t, e, r) => ot(t, typeof e != "symbol" ? e + "" : e, r), "__publicField"), J = class t extends M {
  static {
    n(this, "SearchFilterBuilderImpl");
  }
  constructor(e) {
    super(), ve(this, "filters"), ve(this, "isConsumed"), this.filters = e, this.isConsumed = !1;
  }
  static new() {
    return new t([]);
  }
  consume() {
    if (this.isConsumed)
      throw new Error(
        "SearchFilterBuilder has already been used! Chain your method calls like `q => q.search(...).eq(...)`."
      );
    this.isConsumed = !0;
  }
  search(e, r) {
    return a(e, 1, "search", "fieldName"), a(r, 2, "search", "query"), this.consume(), new t(
      this.filters.concat({
        type: "Search",
        fieldPath: e,
        value: r
      })
    );
  }
  eq(e, r) {
    return a(e, 1, "eq", "fieldName"), arguments.length !== 2 && a(r, 2, "search", "value"), this.consume(), new t(
      this.filters.concat({
        type: "Eq",
        fieldPath: e,
        value: x(r)
      })
    );
  }
  export() {
    return this.consume(), this.filters;
  }
};

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/query_impl.js
var st = Object.defineProperty, it = /* @__PURE__ */ n((t, e, r) => e in t ? st(t, e, { enumerable: !0, configurable: !0, writable: !0, value: r }) : t[e] = r, "__defNormalProp"), z = /* @__PURE__ */ n((t, e, r) => it(t, typeof e != "symbol" ? e + "" : e, r), "__publicField"), be = 256, _ = class {
  static {
    n(this, "QueryInitializerImpl");
  }
  constructor(e) {
    z(this, "tableName"), this.tableName = e;
  }
  withIndex(e, r) {
    a(e, 1, "withIndex", "indexName");
    let o = O.new();
    return r !== void 0 && (o = r(o)), new b({
      source: {
        type: "IndexRange",
        indexName: this.tableName + "." + e,
        range: o.export(),
        order: null
      },
      operators: []
    });
  }
  withSearchIndex(e, r) {
    a(e, 1, "withSearchIndex", "indexName"), a(r, 2, "withSearchIndex", "searchFilter");
    let o = J.new();
    return new b({
      source: {
        type: "Search",
        indexName: this.tableName + "." + e,
        filters: r(o).export()
      },
      operators: []
    });
  }
  fullTableScan() {
    return new b({
      source: {
        type: "FullTableScan",
        tableName: this.tableName,
        order: null
      },
      operators: []
    });
  }
  order(e) {
    return this.fullTableScan().order(e);
  }
  // This is internal API and should not be exposed to developers yet.
  async count() {
    let e = await c("1.0/count", {
      table: this.tableName
    });
    return h(e);
  }
  filter(e) {
    return this.fullTableScan().filter(e);
  }
  limit(e) {
    return this.fullTableScan().limit(e);
  }
  collect() {
    return this.fullTableScan().collect();
  }
  take(e) {
    return this.fullTableScan().take(e);
  }
  paginate(e) {
    return this.fullTableScan().paginate(e);
  }
  first() {
    return this.fullTableScan().first();
  }
  unique() {
    return this.fullTableScan().unique();
  }
  [Symbol.asyncIterator]() {
    return this.fullTableScan()[Symbol.asyncIterator]();
  }
};
function Se(t) {
  throw new Error(
    t === "consumed" ? "This query is closed and can't emit any more values." : "This query has been chained with another operator and can't be reused."
  );
}
n(Se, "throwClosedError");
var b = class t {
  static {
    n(this, "QueryImpl");
  }
  constructor(e) {
    z(this, "state"), z(this, "tableNameForErrorMessages"), this.state = { type: "preparing", query: e }, e.source.type === "FullTableScan" ? this.tableNameForErrorMessages = e.source.tableName : this.tableNameForErrorMessages = e.source.indexName.split(".")[0];
  }
  takeQuery() {
    if (this.state.type !== "preparing")
      throw new Error(
        "A query can only be chained once and can't be chained after iteration begins."
      );
    let e = this.state.query;
    return this.state = { type: "closed" }, e;
  }
  startQuery() {
    if (this.state.type === "executing")
      throw new Error("Iteration can only begin on a query once.");
    (this.state.type === "closed" || this.state.type === "consumed") && Se(this.state.type);
    let e = this.state.query, { queryId: r } = E("1.0/queryStream", { query: e, version: f });
    return this.state = { type: "executing", queryId: r }, r;
  }
  closeQuery() {
    if (this.state.type === "executing") {
      let e = this.state.queryId;
      E("1.0/queryCleanup", { queryId: e });
    }
    this.state = { type: "consumed" };
  }
  order(e) {
    a(e, 1, "order", "order");
    let r = this.takeQuery();
    if (r.source.type === "Search")
      throw new Error(
        "Search queries must always be in relevance order. Can not set order manually."
      );
    if (r.source.order !== null)
      throw new Error("Queries may only specify order at most once");
    return r.source.order = e, new t(r);
  }
  filter(e) {
    a(e, 1, "filter", "predicate");
    let r = this.takeQuery();
    if (r.operators.length >= be)
      throw new Error(
        `Can't construct query with more than ${be} operators`
      );
    return r.operators.push({
      filter: l(e(we))
    }), new t(r);
  }
  limit(e) {
    a(e, 1, "limit", "n");
    let r = this.takeQuery();
    return r.operators.push({ limit: e }), new t(r);
  }
  [Symbol.asyncIterator]() {
    return this.startQuery(), this;
  }
  async next() {
    (this.state.type === "closed" || this.state.type === "consumed") && Se(this.state.type);
    let e = this.state.type === "preparing" ? this.startQuery() : this.state.queryId, { value: r, done: o } = await c("1.0/queryStreamNext", {
      queryId: e
    });
    return o && this.closeQuery(), { value: h(r), done: o };
  }
  return() {
    return this.closeQuery(), Promise.resolve({ done: !0, value: void 0 });
  }
  async paginate(e) {
    if (a(e, 1, "paginate", "options"), typeof e?.numItems != "number" || e.numItems < 0)
      throw new Error(
        `\`options.numItems\` must be a positive number. Received \`${e?.numItems}\`.`
      );
    let r = this.takeQuery(), o = e.numItems, s = e.cursor, u = e?.endCursor ?? null, p = e.maximumRowsRead ?? null, { page: y, isDone: A, continueCursor: T, splitCursor: Fe, pageStatus: Oe } = await c("1.0/queryPage", {
      query: r,
      cursor: s,
      endCursor: u,
      pageSize: o,
      maximumRowsRead: p,
      maximumBytesRead: e.maximumBytesRead,
      version: f
    });
    return {
      page: y.map((Me) => h(Me)),
      isDone: A,
      continueCursor: T,
      splitCursor: Fe,
      pageStatus: Oe
    };
  }
  async collect() {
    let e = [];
    for await (let r of this)
      e.push(r);
    return e;
  }
  async take(e) {
    return a(e, 1, "take", "n"), me(e, 1, "take", "n"), this.limit(e).collect();
  }
  async first() {
    let e = await this.take(1);
    return e.length === 0 ? null : e[0];
  }
  async unique() {
    let e = await this.take(2);
    if (e.length === 0)
      return null;
    if (e.length === 2)
      throw new Error(`unique() query returned more than one result from table ${this.tableNameForErrorMessages}:
 [${e[0]._id}, ${e[1]._id}, ...]`);
    return e[0];
  }
};

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/database_impl.js
async function V(t, e, r) {
  if (a(e, 1, "get", "id"), typeof e != "string")
    throw new Error(
      `Invalid argument \`id\` for \`db.get\`, expected string but got '${typeof e}': ${e}`
    );
  let o = {
    id: d(e),
    isSystem: r,
    version: f,
    table: t
  }, s = await c("1.0/get", o);
  return h(s);
}
n(V, "get");
function L() {
  let t = /* @__PURE__ */ n((s = !1) => ({
    get: /* @__PURE__ */ n(async (u, p) => p !== void 0 ? await V(u, p, s) : await V(void 0, u, s), "get"),
    query: /* @__PURE__ */ n((u) => new P(u, s).query(), "query"),
    normalizeId: /* @__PURE__ */ n((u, p) => {
      a(u, 1, "normalizeId", "tableName"), a(p, 2, "normalizeId", "id");
      let y = u.startsWith("_");
      if (y !== s)
        throw new Error(
          `${y ? "System" : "User"} tables can only be accessed from db.${s ? "" : "system."}normalizeId().`
        );
      let A = E("1.0/db/normalizeId", {
        table: u,
        idString: p
      });
      return h(A).id;
    }, "normalizeId"),
    // We set the system reader on the next line
    system: null,
    table: /* @__PURE__ */ n((u) => new P(u, s), "table")
  }), "reader"), { system: e, ...r } = t(!0), o = t();
  return o.system = r, o;
}
n(L, "setupReader");
async function _e(t, e) {
  if (t.startsWith("_"))
    throw new Error("System tables (prefixed with `_`) are read-only.");
  a(t, 1, "insert", "table"), a(e, 2, "insert", "value");
  let r = await c("1.0/insert", {
    table: t,
    value: d(e)
  });
  return h(r)._id;
}
n(_e, "insert");
async function W(t, e, r) {
  a(e, 1, "patch", "id"), a(r, 2, "patch", "value"), await c("1.0/shallowMerge", {
    id: d(e),
    value: ce(r),
    table: t
  });
}
n(W, "patch");
async function B(t, e, r) {
  a(e, 1, "replace", "id"), a(r, 2, "replace", "value"), await c("1.0/replace", {
    id: d(e),
    value: d(r),
    table: t
  });
}
n(B, "replace");
async function D(t, e) {
  a(e, 1, "delete", "id"), await c("1.0/remove", {
    id: d(e),
    table: t
  });
}
n(D, "delete_");
function Ae() {
  let t = L();
  return {
    get: t.get,
    query: t.query,
    normalizeId: t.normalizeId,
    system: t.system,
    insert: /* @__PURE__ */ n(async (e, r) => await _e(e, r), "insert"),
    patch: /* @__PURE__ */ n(async (e, r, o) => o !== void 0 ? await W(e, r, o) : await W(void 0, e, r), "patch"),
    replace: /* @__PURE__ */ n(async (e, r, o) => o !== void 0 ? await B(e, r, o) : await B(void 0, e, r), "replace"),
    delete: /* @__PURE__ */ n(async (e, r) => r !== void 0 ? await D(e, r) : await D(void 0, e), "delete"),
    table: /* @__PURE__ */ n((e) => new k(e, !1), "table")
  };
}
n(Ae, "setupWriter");
var P = class {
  static {
    n(this, "TableReader");
  }
  constructor(e, r) {
    this.tableName = e, this.isSystem = r;
  }
  async get(e) {
    return V(this.tableName, e, this.isSystem);
  }
  query() {
    let e = this.tableName.startsWith("_");
    if (e !== this.isSystem)
      throw new Error(
        `${e ? "System" : "User"} tables can only be accessed from db.${this.isSystem ? "" : "system."}query().`
      );
    return new _(this.tableName);
  }
}, k = class extends P {
  static {
    n(this, "TableWriter");
  }
  async insert(e) {
    return _e(this.tableName, e);
  }
  async patch(e, r) {
    return W(this.tableName, e, r);
  }
  async replace(e, r) {
    return B(this.tableName, e, r);
  }
  async delete(e) {
    return D(this.tableName, e);
  }
};

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/scheduler_impl.js
function Ee() {
  return {
    runAfter: /* @__PURE__ */ n(async (t, e, r) => {
      let o = Pe(t, e, r);
      return await c("1.0/schedule", o);
    }, "runAfter"),
    runAt: /* @__PURE__ */ n(async (t, e, r) => {
      let o = Te(
        t,
        e,
        r
      );
      return await c("1.0/schedule", o);
    }, "runAt"),
    cancel: /* @__PURE__ */ n(async (t) => {
      a(t, 1, "cancel", "id");
      let e = { id: d(t) };
      await c("1.0/cancel_job", e);
    }, "cancel")
  };
}
n(Ee, "setupMutationScheduler");
function Ie(t) {
  return {
    runAfter: /* @__PURE__ */ n(async (e, r, o) => {
      let s = {
        requestId: t,
        ...Pe(e, r, o)
      };
      return await c("1.0/actions/schedule", s);
    }, "runAfter"),
    runAt: /* @__PURE__ */ n(async (e, r, o) => {
      let s = {
        requestId: t,
        ...Te(e, r, o)
      };
      return await c("1.0/actions/schedule", s);
    }, "runAt"),
    cancel: /* @__PURE__ */ n(async (e) => {
      a(e, 1, "cancel", "id");
      let r = {
        requestId: t,
        id: d(e)
      };
      return await c("1.0/actions/cancel_job", r);
    }, "cancel")
  };
}
n(Ie, "setupActionScheduler");
function Pe(t, e, r) {
  if (typeof t != "number")
    throw new Error("`delayMs` must be a number");
  if (!isFinite(t))
    throw new Error("`delayMs` must be a finite number");
  if (t < 0)
    throw new Error("`delayMs` must be non-negative");
  let o = v(r), s = w(e), u = (Date.now() + t) / 1e3;
  return {
    ...s,
    ts: u,
    args: d(o),
    version: f
  };
}
n(Pe, "runAfterSyscallArgs");
function Te(t, e, r) {
  let o;
  if (t instanceof Date)
    o = t.valueOf() / 1e3;
  else if (typeof t == "number")
    o = t / 1e3;
  else
    throw new Error("The invoke time must a Date or a timestamp");
  let s = w(e), u = v(r);
  return {
    ...s,
    ts: o,
    args: d(u),
    version: f
  };
}
n(Te, "runAtSyscallArgs");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/storage_impl.js
function Y(t) {
  return {
    getUrl: /* @__PURE__ */ n(async (e) => (a(e, 1, "getUrl", "storageId"), await c("1.0/storageGetUrl", {
      requestId: t,
      version: f,
      storageId: e
    })), "getUrl"),
    getMetadata: /* @__PURE__ */ n(async (e) => await c("1.0/storageGetMetadata", {
      requestId: t,
      version: f,
      storageId: e
    }), "getMetadata")
  };
}
n(Y, "setupStorageReader");
function K(t) {
  let e = Y(t);
  return {
    generateUploadUrl: /* @__PURE__ */ n(async () => await c("1.0/storageGenerateUploadUrl", {
      requestId: t,
      version: f
    }), "generateUploadUrl"),
    delete: /* @__PURE__ */ n(async (r) => {
      await c("1.0/storageDelete", {
        requestId: t,
        version: f,
        storageId: r
      });
    }, "delete"),
    getUrl: e.getUrl,
    getMetadata: e.getMetadata
  };
}
n(K, "setupStorageWriter");
function Ce(t) {
  return {
    ...K(t),
    store: /* @__PURE__ */ n(async (r, o) => await C("storage/storeBlob", {
      requestId: t,
      version: f,
      blob: r,
      options: o
    }), "store"),
    get: /* @__PURE__ */ n(async (r) => await C("storage/getBlob", {
      requestId: t,
      version: f,
      storageId: r
    }), "get")
  };
}
n(Ce, "setupStorageActionWriter");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/registration_impl.js
async function at(t, e) {
  let o = h(JSON.parse(e)), s = {
    db: Ae(),
    auth: q(""),
    storage: K(""),
    scheduler: Ee(),
    runQuery: /* @__PURE__ */ n((p, y) => X("query", p, y), "runQuery"),
    runMutation: /* @__PURE__ */ n((p, y) => X("mutation", p, y), "runMutation")
  }, u = await Z(t, s, o);
  return Ne(u), JSON.stringify(d(u === void 0 ? null : u));
}
n(at, "invokeMutation");
function Ne(t) {
  if (t instanceof _ || t instanceof b)
    throw new Error(
      "Return value is a Query. Results must be retrieved with `.collect()`, `.take(n), `.unique()`, or `.first()`."
    );
}
n(Ne, "validateReturnValue");
async function Z(t, e, r) {
  let o;
  try {
    o = await Promise.resolve(t(e, ...r));
  } catch (s) {
    throw ut(s);
  }
  return o;
}
n(Z, "invokeFunction");
function ee(t, e) {
  return (r, o) => (globalThis.console.warn(
    `Convex functions should not directly call other Convex functions. Consider calling a helper function instead. e.g. \`export const foo = ${t}(...); await foo(ctx);\` is not supported. See https://docs.convex.dev/production/best-practices/#use-helper-functions-to-write-shared-code`
  ), e(r, o));
}
n(ee, "dontCallDirectly");
function ut(t) {
  if (typeof t == "object" && t !== null && Symbol.for("ConvexError") in t) {
    let e = t;
    return e.data = JSON.stringify(
      d(e.data === void 0 ? null : e.data)
    ), e.ConvexErrorSymbol = Symbol.for("ConvexError"), e;
  } else
    return t;
}
n(ut, "serializeConvexErrorData");
function te() {
  if (typeof window > "u" || window.__convexAllowFunctionsInBrowser)
    return;
  (Object.getOwnPropertyDescriptor(globalThis, "window")?.get?.toString().includes("[native code]") ?? !1) && console.error(
    "Convex functions should not be imported in the browser. This will throw an error in future versions of `convex`. If this is a false negative, please report it to Convex support."
  );
}
n(te, "assertNotBrowser");
function $e(t, e) {
  if (e === void 0)
    throw new Error(
      `A validator is undefined for field "${t}". This is often caused by circular imports. See https://docs.convex.dev/error#undefined-validator for details.`
    );
  return e;
}
n($e, "strictReplacer");
function re(t) {
  return () => {
    let e = i.any();
    return typeof t == "object" && t.args !== void 0 && (e = j(t.args)), JSON.stringify(e.json, $e);
  };
}
n(re, "exportArgs");
function ne(t) {
  return () => {
    let e;
    return typeof t == "object" && t.returns !== void 0 && (e = j(t.returns)), JSON.stringify(e ? e.json : null, $e);
  };
}
n(ne, "exportReturns");
var oe = /* @__PURE__ */ n(((t) => {
  let e = typeof t == "function" ? t : t.handler, r = ee("mutation", e);
  return te(), r.isMutation = !0, r.isPublic = !0, r.invokeMutation = (o) => at(e, o), r.exportArgs = re(t), r.exportReturns = ne(t), r._handler = e, r;
}), "mutationGeneric");
async function ct(t, e) {
  let o = h(JSON.parse(e)), s = {
    db: L(),
    auth: q(""),
    storage: Y(""),
    runQuery: /* @__PURE__ */ n((p, y) => X("query", p, y), "runQuery")
  }, u = await Z(t, s, o);
  return Ne(u), JSON.stringify(d(u === void 0 ? null : u));
}
n(ct, "invokeQuery");
var se = /* @__PURE__ */ n(((t) => {
  let e = typeof t == "function" ? t : t.handler, r = ee("query", e);
  return te(), r.isQuery = !0, r.isPublic = !0, r.invokeQuery = (o) => ct(e, o), r.exportArgs = re(t), r.exportReturns = ne(t), r._handler = e, r;
}), "queryGeneric");
async function lt(t, e, r) {
  let o = h(JSON.parse(r)), u = {
    ...fe(e),
    auth: q(e),
    scheduler: Ie(e),
    storage: Ce(e),
    vectorSearch: ye(e)
  }, p = await Z(t, u, o);
  return JSON.stringify(d(p === void 0 ? null : p));
}
n(lt, "invokeAction");
var ie = /* @__PURE__ */ n(((t) => {
  let e = typeof t == "function" ? t : t.handler, r = ee("action", e);
  return te(), r.isAction = !0, r.isPublic = !0, r.invokeAction = (o, s) => lt(e, o, s), r.exportArgs = re(t), r.exportReturns = ne(t), r._handler = e, r;
}), "actionGeneric");
async function X(t, e, r) {
  let o = v(r), s = {
    udfType: t,
    args: d(o),
    ...w(e)
  }, u = await c("1.0/runUdf", s);
  return h(u);
}
n(X, "runUdf");

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/pagination.js
var sn = i.object({
  numItems: i.number(),
  cursor: i.union(i.string(), i.null()),
  endCursor: i.optional(i.union(i.string(), i.null())),
  id: i.optional(i.number()),
  maximumRowsRead: i.optional(i.number()),
  maximumBytesRead: i.optional(i.number())
});

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/api.js
function qe(t = []) {
  let e = {
    get(r, o) {
      if (typeof o == "string") {
        let s = [...t, o];
        return qe(s);
      } else if (o === I) {
        if (t.length < 2) {
          let p = ["api", ...t].join(".");
          throw new Error(
            `API path is expected to be of the form \`api.moduleName.functionName\`. Found: \`${p}\``
          );
        }
        let s = t.slice(0, -1).join("/"), u = t[t.length - 1];
        return u === "default" ? s : s + ":" + u;
      } else return o === Symbol.toStringTag ? "FunctionReference" : void 0;
    }
  };
  return new Proxy({}, e);
}
n(qe, "createApi");
var dt = qe();

// ../../../../../../../tmp/zodvex-dynamic-import-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/schema.js
var ft = Object.defineProperty, ht = /* @__PURE__ */ n((t, e, r) => e in t ? ft(t, e, { enumerable: !0, configurable: !0, writable: !0, value: r }) : t[e] = r, "__defNormalProp"), g = /* @__PURE__ */ n((t, e, r) => ht(t, typeof e != "symbol" ? e + "" : e, r), "__publicField"), U = class {
  static {
    n(this, "TableDefinition");
  }
  /**
   * @internal
   */
  constructor(e) {
    g(this, "indexes"), g(this, "stagedDbIndexes"), g(this, "searchIndexes"), g(this, "stagedSearchIndexes"), g(this, "vectorIndexes"), g(this, "stagedVectorIndexes"), g(this, "validator"), this.indexes = [], this.stagedDbIndexes = [], this.searchIndexes = [], this.stagedSearchIndexes = [], this.vectorIndexes = [], this.stagedVectorIndexes = [], this.validator = e;
  }
  /**
   * This API is experimental: it may change or disappear.
   *
   * Returns indexes defined on this table.
   * Intended for the advanced use cases of dynamically deciding which index to use for a query.
   * If you think you need this, please chime in on ths issue in the Convex JS GitHub repo.
   * https://github.com/get-convex/convex-js/issues/49
   */
  " indexes"() {
    return this.indexes;
  }
  index(e, r) {
    return Array.isArray(r) ? this.indexes.push({
      indexDescriptor: e,
      fields: r
    }) : r.staged ? this.stagedDbIndexes.push({
      indexDescriptor: e,
      fields: r.fields
    }) : this.indexes.push({
      indexDescriptor: e,
      fields: r.fields
    }), this;
  }
  searchIndex(e, r) {
    return r.staged ? this.stagedSearchIndexes.push({
      indexDescriptor: e,
      searchField: r.searchField,
      filterFields: r.filterFields || []
    }) : this.searchIndexes.push({
      indexDescriptor: e,
      searchField: r.searchField,
      filterFields: r.filterFields || []
    }), this;
  }
  vectorIndex(e, r) {
    return r.staged ? this.stagedVectorIndexes.push({
      indexDescriptor: e,
      vectorField: r.vectorField,
      dimensions: r.dimensions,
      filterFields: r.filterFields || []
    }) : this.vectorIndexes.push({
      indexDescriptor: e,
      vectorField: r.vectorField,
      dimensions: r.dimensions,
      filterFields: r.filterFields || []
    }), this;
  }
  /**
   * Work around for https://github.com/microsoft/TypeScript/issues/57035
   */
  self() {
    return this;
  }
  /**
   * Export the contents of this definition.
   *
   * This is called internally by the Convex framework.
   * @internal
   */
  export() {
    let e = this.validator.json;
    if (typeof e != "object")
      throw new Error(
        "Invalid validator: please make sure that the parameter of `defineTable` is valid (see https://docs.convex.dev/database/schemas)"
      );
    return {
      indexes: this.indexes,
      stagedDbIndexes: this.stagedDbIndexes,
      searchIndexes: this.searchIndexes,
      stagedSearchIndexes: this.stagedSearchIndexes,
      vectorIndexes: this.vectorIndexes,
      stagedVectorIndexes: this.stagedVectorIndexes,
      documentType: e
    };
  }
};
function ae(t) {
  return le(t) ? new U(t) : new U(i.object(t));
}
n(ae, "defineTable");
var ue = class {
  static {
    n(this, "SchemaDefinition");
  }
  /**
   * @internal
   */
  constructor(e, r) {
    g(this, "tables"), g(this, "strictTableNameTypes"), g(this, "schemaValidation"), this.tables = e, this.schemaValidation = r?.schemaValidation === void 0 ? !0 : r.schemaValidation;
  }
  /**
   * Export the contents of this definition.
   *
   * This is called internally by the Convex framework.
   * @internal
   */
  export() {
    return JSON.stringify({
      tables: Object.entries(this.tables).map(([e, r]) => {
        let {
          indexes: o,
          stagedDbIndexes: s,
          searchIndexes: u,
          stagedSearchIndexes: p,
          vectorIndexes: y,
          stagedVectorIndexes: A,
          documentType: T
        } = r.export();
        return {
          tableName: e,
          indexes: o,
          stagedDbIndexes: s,
          searchIndexes: u,
          stagedSearchIndexes: p,
          vectorIndexes: y,
          stagedVectorIndexes: A,
          documentType: T
        };
      }),
      schemaValidation: this.schemaValidation
    });
  }
};
function Re(t, e) {
  return new ue(t, e);
}
n(Re, "defineSchema");
var Nn = Re({
  _scheduled_functions: ae({
    name: i.string(),
    args: i.array(i.any()),
    scheduledTime: i.float64(),
    completedTime: i.optional(i.float64()),
    state: i.union(
      i.object({ kind: i.literal("pending") }),
      i.object({ kind: i.literal("inProgress") }),
      i.object({ kind: i.literal("success") }),
      i.object({ kind: i.literal("failed"), error: i.string() }),
      i.object({ kind: i.literal("canceled") })
    )
  }),
  _storage: ae({
    sha256: i.string(),
    size: i.float64(),
    contentType: i.optional(i.string())
  })
});

// convex/_generated/server.js
var oo = se;
var so = oe;
var io = ie;

export {
  oo as a,
  so as b,
  io as c
};
//# sourceMappingURL=EYM35JYW.js.map
