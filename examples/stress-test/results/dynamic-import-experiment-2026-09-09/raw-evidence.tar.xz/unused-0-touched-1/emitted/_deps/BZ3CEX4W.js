import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model000.ts
m("model-init:model000");
var l = o("model000", e(32));

export {
  l as a
};
//# sourceMappingURL=BZ3CEX4W.js.map
