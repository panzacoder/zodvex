import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model067.ts
m("model-init:model067");
var l = o("model067", e(32));

export {
  l as a
};
//# sourceMappingURL=2KBO6V6E.js.map
