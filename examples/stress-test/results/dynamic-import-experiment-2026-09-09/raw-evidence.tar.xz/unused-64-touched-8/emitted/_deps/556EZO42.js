import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model065.ts
m("model-init:model065");
var l = o("model065", e(32));

export {
  l as a
};
//# sourceMappingURL=556EZO42.js.map
