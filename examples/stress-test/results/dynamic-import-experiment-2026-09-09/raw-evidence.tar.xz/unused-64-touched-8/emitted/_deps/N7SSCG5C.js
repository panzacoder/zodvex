import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model071.ts
m("model-init:model071");
var l = o("model071", e(32));

export {
  l as a
};
//# sourceMappingURL=N7SSCG5C.js.map
