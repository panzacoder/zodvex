import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model068.ts
m("model-init:model068");
var l = o("model068", e(32));

export {
  l as a
};
//# sourceMappingURL=RPU7526K.js.map
