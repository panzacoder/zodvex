import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model066.ts
m("model-init:model066");
var l = o("model066", e(32));

export {
  l as a
};
//# sourceMappingURL=KL5B5DW3.js.map
