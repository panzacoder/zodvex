import {
  a as ko
} from "./RPU7526K.js";
import {
  a as bo
} from "./VBTKJIR6.js";
import {
  a as wo
} from "./4DW6OIP3.js";
import {
  a as xo
} from "./N7SSCG5C.js";
import {
  a as fo
} from "./GZBSUFA2.js";
import {
  a as po
} from "./ELCRTJKI.js";
import {
  a as no
} from "./Y2AK6NEG.js";
import {
  a as co
} from "./4WI7T6FM.js";
import {
  a as ho
} from "./RT3KPP4N.js";
import {
  a as uo
} from "./556EZO42.js";
import {
  a as yo
} from "./KL5B5DW3.js";
import {
  a as go
} from "./2KBO6V6E.js";
import {
  a as mo
} from "./BVS2IOTO.js";
import {
  a as eo
} from "./M6QYKPKQ.js";
import {
  a as ro
} from "./CMJEL2JR.js";
import {
  a as lo
} from "./CLFTPLMU.js";
import {
  a as to
} from "./Y4JIPGUV.js";
import {
  a as so
} from "./QHGYYOQ7.js";
import {
  a as io
} from "./DZZ54JH7.js";
import {
  a as ao
} from "./ZZYN72QX.js";
import {
  a as V
} from "./ARWF4E3E.js";
import {
  a as W
} from "./YVEBSYWO.js";
import {
  a as X
} from "./MCJX5RIU.js";
import {
  a as Y
} from "./L5YZYL6Q.js";
import {
  a as Z
} from "./6YSV66YB.js";
import {
  a as _
} from "./FQ7UVVQR.js";
import {
  a as $
} from "./Y3BMHHJE.js";
import {
  a as oo
} from "./C3BNBPOE.js";
import {
  a as L
} from "./PZFQE7F2.js";
import {
  a as M
} from "./IUCJUUAJ.js";
import {
  a as N
} from "./S32ZKO2M.js";
import {
  a as P
} from "./H4FAQEJI.js";
import {
  a as Q
} from "./FPLAI6ZL.js";
import {
  a as R
} from "./2HTS3V2Z.js";
import {
  a as S
} from "./MTWP54L7.js";
import {
  a as T
} from "./5VF4Q4C3.js";
import {
  a as B
} from "./ILTAMMZ3.js";
import {
  a as D
} from "./K7S2QLVF.js";
import {
  a as F
} from "./BE7XHATS.js";
import {
  a as G
} from "./KPKSKBAJ.js";
import {
  a as H
} from "./VGXJCSJ5.js";
import {
  a as I
} from "./66GGXB65.js";
import {
  a as J
} from "./VIJVUKSB.js";
import {
  a as K
} from "./7PNIPCGA.js";
import {
  a as O
} from "./3TFW3E53.js";
import {
  a as C
} from "./46R5Q2HV.js";
import {
  a as E
} from "./EWIWEGF6.js";
import {
  a as U
} from "./XRL7BBAO.js";
import {
  a as q
} from "./QWKGAXLK.js";
import {
  a as v
} from "./IX5QSF2C.js";
import {
  a as z
} from "./4EXSQQQO.js";
import {
  a as A
} from "./A7XLJVKU.js";
import {
  a as u
} from "./V4JDGLX5.js";
import {
  a as y
} from "./5PXKOPYO.js";
import {
  a as g
} from "./3KKBOPCO.js";
import {
  a as k
} from "./BEY6CV7L.js";
import {
  a as b
} from "./TXG2FVAL.js";
import {
  a as w
} from "./LYKQUYPS.js";
import {
  a as x
} from "./UZ6HZCMS.js";
import {
  a as j
} from "./ZTHTIARM.js";
import {
  a as s
} from "./LMWUKZAL.js";
import {
  a as i
} from "./GYUTJ3XM.js";
import {
  a
} from "./VSKNOBMU.js";
import {
  a as f
} from "./CM7PCYUA.js";
import {
  a as p
} from "./JDYY7C4Q.js";
import {
  a as n
} from "./IQ5EA24B.js";
import {
  a as c
} from "./7Z2YKVKP.js";
import {
  a as h
} from "./QNUBZY2S.js";
import {
  a as r
} from "./BZ3CEX4W.js";
import {
  a as l
} from "./ZJW33SAG.js";
import {
  a as d
} from "./O3FQPIRV.js";
import {
  a as t
} from "./GZGXZGJY.js";
import {
  a as e
} from "./5B5TEMMX.js";

// convex/staticRegistry.ts
var jo = { model000: r, model001: l, model002: d, model003: t, model004: s, model005: i, model006: a, model007: f, model008: p, model009: n, model010: c, model011: h, model012: u, model013: y, model014: g, model015: k, model016: b, model017: w, model018: x, model019: j, model020: O, model021: C, model022: E, model023: U, model024: q, model025: v, model026: z, model027: A, model028: B, model029: D, model030: F, model031: G, model032: H, model033: I, model034: J, model035: K, model036: L, model037: M, model038: N, model039: P, model040: Q, model041: R, model042: S, model043: T, model044: V, model045: W, model046: X, model047: Y, model048: Z, model049: _, model050: $, model051: oo, model052: mo, model053: eo, model054: ro, model055: lo, model056: to, model057: so, model058: io, model059: ao, model060: fo, model061: po, model062: no, model063: co, model064: ho, model065: uo, model066: yo, model067: go, model068: ko, model069: bo, model070: wo, model071: xo };
function Pm(m) {
  let o = jo[m];
  if (!o) throw new Error("Unknown table key");
  return o;
}
e(Pm, "load");
function Qm() {
  return Object.entries(jo).reduce((m, [o, Oo]) => m + o.length + Object.keys(Oo.schema.insert.shape).length, 0);
}
e(Qm, "retainedChecksum");

export {
  jo as a,
  Pm as b,
  Qm as c
};
//# sourceMappingURL=ZM7IBXQS.js.map
