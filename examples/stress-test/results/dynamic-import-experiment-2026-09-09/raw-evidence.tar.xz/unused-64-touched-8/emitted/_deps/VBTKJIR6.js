import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model069.ts
m("model-init:model069");
var l = o("model069", e(32));

export {
  l as a
};
//# sourceMappingURL=VBTKJIR6.js.map
