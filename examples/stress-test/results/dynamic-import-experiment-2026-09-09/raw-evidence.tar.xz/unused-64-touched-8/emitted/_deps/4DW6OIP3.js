import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model070.ts
m("model-init:model070");
var l = o("model070", e(32));

export {
  l as a
};
//# sourceMappingURL=4DW6OIP3.js.map
