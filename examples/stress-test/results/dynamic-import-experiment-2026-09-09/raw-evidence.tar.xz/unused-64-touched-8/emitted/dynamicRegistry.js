import {
  a,
  b
} from "./_deps/BY77U3HP.js";
import "./_deps/5B5TEMMX.js";
export {
  a as load,
  b as retainedChecksum
};
//# sourceMappingURL=dynamicRegistry.js.map
