import { defineZodModel } from 'zodvex'
import { makeFields } from '../shared/shape'
import { recordModuleInit } from '../shared/observation'
recordModuleInit('model-init:model033')
export const model = defineZodModel('model033', makeFields(32))
