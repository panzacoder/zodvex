import { defineZodModel } from 'zodvex'
import { makeFields } from '../shared/shape'
import { recordModuleInit } from '../shared/observation'
recordModuleInit('model-init:model063')
export const model = defineZodModel('model063', makeFields(32))
