import { defineZodModel } from 'zodvex'
import { makeFields } from '../shared/shape'
import { recordModuleInit } from '../shared/observation'
recordModuleInit('model-init:model046')
export const model = defineZodModel('model046', makeFields(32))
