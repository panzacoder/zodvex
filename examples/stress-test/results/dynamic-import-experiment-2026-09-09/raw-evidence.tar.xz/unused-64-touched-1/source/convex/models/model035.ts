import { defineZodModel } from 'zodvex'
import { makeFields } from '../shared/shape'
import { recordModuleInit } from '../shared/observation'
recordModuleInit('model-init:model035')
export const model = defineZodModel('model035', makeFields(32))
