import { query } from './_generated/server'
import { v } from 'convex/values'
export const ready = query({ args: { nonce: v.string() },
  returns: v.object({ nonce: v.string(), unused: v.number(), touched: v.number(), width: v.number() }),
  handler: (_ctx, args) => ({ nonce: args.nonce, unused: 64, touched: 1, width: 32 }) })
