/* eslint-disable */
/**
 * Generated `api` utility.
 *
 * THIS CODE IS AUTOMATICALLY GENERATED.
 *
 * To regenerate, run `npx convex dev`.
 * @module
 */

import type * as canary from "../canary.js";
import type * as dynamic from "../dynamic.js";
import type * as dynamicRegistry from "../dynamicRegistry.js";
import type * as helpers from "../helpers.js";
import type * as models_model000 from "../models/model000.js";
import type * as models_model001 from "../models/model001.js";
import type * as models_model002 from "../models/model002.js";
import type * as models_model003 from "../models/model003.js";
import type * as models_model004 from "../models/model004.js";
import type * as models_model005 from "../models/model005.js";
import type * as models_model006 from "../models/model006.js";
import type * as models_model007 from "../models/model007.js";
import type * as models_model008 from "../models/model008.js";
import type * as models_model009 from "../models/model009.js";
import type * as models_model010 from "../models/model010.js";
import type * as models_model011 from "../models/model011.js";
import type * as models_model012 from "../models/model012.js";
import type * as models_model013 from "../models/model013.js";
import type * as models_model014 from "../models/model014.js";
import type * as models_model015 from "../models/model015.js";
import type * as models_model016 from "../models/model016.js";
import type * as models_model017 from "../models/model017.js";
import type * as models_model018 from "../models/model018.js";
import type * as models_model019 from "../models/model019.js";
import type * as models_model020 from "../models/model020.js";
import type * as models_model021 from "../models/model021.js";
import type * as models_model022 from "../models/model022.js";
import type * as models_model023 from "../models/model023.js";
import type * as models_model024 from "../models/model024.js";
import type * as models_model025 from "../models/model025.js";
import type * as models_model026 from "../models/model026.js";
import type * as models_model027 from "../models/model027.js";
import type * as models_model028 from "../models/model028.js";
import type * as models_model029 from "../models/model029.js";
import type * as models_model030 from "../models/model030.js";
import type * as models_model031 from "../models/model031.js";
import type * as models_model032 from "../models/model032.js";
import type * as models_model033 from "../models/model033.js";
import type * as models_model034 from "../models/model034.js";
import type * as models_model035 from "../models/model035.js";
import type * as models_model036 from "../models/model036.js";
import type * as models_model037 from "../models/model037.js";
import type * as models_model038 from "../models/model038.js";
import type * as models_model039 from "../models/model039.js";
import type * as models_model040 from "../models/model040.js";
import type * as models_model041 from "../models/model041.js";
import type * as models_model042 from "../models/model042.js";
import type * as models_model043 from "../models/model043.js";
import type * as models_model044 from "../models/model044.js";
import type * as models_model045 from "../models/model045.js";
import type * as models_model046 from "../models/model046.js";
import type * as models_model047 from "../models/model047.js";
import type * as models_model048 from "../models/model048.js";
import type * as models_model049 from "../models/model049.js";
import type * as models_model050 from "../models/model050.js";
import type * as models_model051 from "../models/model051.js";
import type * as models_model052 from "../models/model052.js";
import type * as models_model053 from "../models/model053.js";
import type * as models_model054 from "../models/model054.js";
import type * as models_model055 from "../models/model055.js";
import type * as models_model056 from "../models/model056.js";
import type * as models_model057 from "../models/model057.js";
import type * as models_model058 from "../models/model058.js";
import type * as models_model059 from "../models/model059.js";
import type * as models_model060 from "../models/model060.js";
import type * as models_model061 from "../models/model061.js";
import type * as models_model062 from "../models/model062.js";
import type * as models_model063 from "../models/model063.js";
import type * as models_model064 from "../models/model064.js";
import type * as shared_observation from "../shared/observation.js";
import type * as shared_operation from "../shared/operation.js";
import type * as shared_result from "../shared/result.js";
import type * as shared_shape from "../shared/shape.js";
import type * as static_ from "../static.js";
import type * as staticRegistry from "../staticRegistry.js";

import type {
  ApiFromModules,
  FilterApi,
  FunctionReference,
} from "convex/server";

declare const fullApi: ApiFromModules<{
  canary: typeof canary;
  dynamic: typeof dynamic;
  dynamicRegistry: typeof dynamicRegistry;
  helpers: typeof helpers;
  "models/model000": typeof models_model000;
  "models/model001": typeof models_model001;
  "models/model002": typeof models_model002;
  "models/model003": typeof models_model003;
  "models/model004": typeof models_model004;
  "models/model005": typeof models_model005;
  "models/model006": typeof models_model006;
  "models/model007": typeof models_model007;
  "models/model008": typeof models_model008;
  "models/model009": typeof models_model009;
  "models/model010": typeof models_model010;
  "models/model011": typeof models_model011;
  "models/model012": typeof models_model012;
  "models/model013": typeof models_model013;
  "models/model014": typeof models_model014;
  "models/model015": typeof models_model015;
  "models/model016": typeof models_model016;
  "models/model017": typeof models_model017;
  "models/model018": typeof models_model018;
  "models/model019": typeof models_model019;
  "models/model020": typeof models_model020;
  "models/model021": typeof models_model021;
  "models/model022": typeof models_model022;
  "models/model023": typeof models_model023;
  "models/model024": typeof models_model024;
  "models/model025": typeof models_model025;
  "models/model026": typeof models_model026;
  "models/model027": typeof models_model027;
  "models/model028": typeof models_model028;
  "models/model029": typeof models_model029;
  "models/model030": typeof models_model030;
  "models/model031": typeof models_model031;
  "models/model032": typeof models_model032;
  "models/model033": typeof models_model033;
  "models/model034": typeof models_model034;
  "models/model035": typeof models_model035;
  "models/model036": typeof models_model036;
  "models/model037": typeof models_model037;
  "models/model038": typeof models_model038;
  "models/model039": typeof models_model039;
  "models/model040": typeof models_model040;
  "models/model041": typeof models_model041;
  "models/model042": typeof models_model042;
  "models/model043": typeof models_model043;
  "models/model044": typeof models_model044;
  "models/model045": typeof models_model045;
  "models/model046": typeof models_model046;
  "models/model047": typeof models_model047;
  "models/model048": typeof models_model048;
  "models/model049": typeof models_model049;
  "models/model050": typeof models_model050;
  "models/model051": typeof models_model051;
  "models/model052": typeof models_model052;
  "models/model053": typeof models_model053;
  "models/model054": typeof models_model054;
  "models/model055": typeof models_model055;
  "models/model056": typeof models_model056;
  "models/model057": typeof models_model057;
  "models/model058": typeof models_model058;
  "models/model059": typeof models_model059;
  "models/model060": typeof models_model060;
  "models/model061": typeof models_model061;
  "models/model062": typeof models_model062;
  "models/model063": typeof models_model063;
  "models/model064": typeof models_model064;
  "shared/observation": typeof shared_observation;
  "shared/operation": typeof shared_operation;
  "shared/result": typeof shared_result;
  "shared/shape": typeof shared_shape;
  static: typeof static_;
  staticRegistry: typeof staticRegistry;
}>;

/**
 * A utility for referencing Convex functions in your app's public API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = api.myModule.myFunction;
 * ```
 */
export declare const api: FilterApi<
  typeof fullApi,
  FunctionReference<any, "public">
>;

/**
 * A utility for referencing Convex functions in your app's internal API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = internal.myModule.myFunction;
 * ```
 */
export declare const internal: FilterApi<
  typeof fullApi,
  FunctionReference<any, "internal">
>;

export declare const components: {};
