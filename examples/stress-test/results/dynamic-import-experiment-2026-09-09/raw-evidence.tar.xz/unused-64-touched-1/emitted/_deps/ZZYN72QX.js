import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model059.ts
m("model-init:model059");
var l = o("model059", e(32));

export {
  l as a
};
//# sourceMappingURL=ZZYN72QX.js.map
