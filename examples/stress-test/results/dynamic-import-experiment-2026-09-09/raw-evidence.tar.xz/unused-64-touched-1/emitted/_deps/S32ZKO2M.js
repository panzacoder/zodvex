import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model038.ts
m("model-init:model038");
var l = o("model038", e(32));

export {
  l as a
};
//# sourceMappingURL=S32ZKO2M.js.map
