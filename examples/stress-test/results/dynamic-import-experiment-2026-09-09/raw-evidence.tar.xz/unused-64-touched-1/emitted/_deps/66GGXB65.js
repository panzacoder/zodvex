import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model033.ts
m("model-init:model033");
var l = o("model033", e(32));

export {
  l as a
};
//# sourceMappingURL=66GGXB65.js.map
