import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model037.ts
m("model-init:model037");
var l = o("model037", e(32));

export {
  l as a
};
//# sourceMappingURL=IUCJUUAJ.js.map
