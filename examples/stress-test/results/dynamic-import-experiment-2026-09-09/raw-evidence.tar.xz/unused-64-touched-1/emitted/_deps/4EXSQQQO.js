import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model026.ts
m("model-init:model026");
var l = o("model026", e(32));

export {
  l as a
};
//# sourceMappingURL=4EXSQQQO.js.map
