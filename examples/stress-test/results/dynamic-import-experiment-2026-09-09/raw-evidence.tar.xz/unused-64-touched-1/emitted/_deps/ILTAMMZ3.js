import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model028.ts
m("model-init:model028");
var l = o("model028", e(32));

export {
  l as a
};
//# sourceMappingURL=ILTAMMZ3.js.map
