import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model039.ts
m("model-init:model039");
var l = o("model039", e(32));

export {
  l as a
};
//# sourceMappingURL=H4FAQEJI.js.map
