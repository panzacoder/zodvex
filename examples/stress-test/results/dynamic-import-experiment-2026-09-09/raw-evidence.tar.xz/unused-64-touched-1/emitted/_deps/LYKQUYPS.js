import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model017.ts
m("model-init:model017");
var l = o("model017", e(32));

export {
  l as a
};
//# sourceMappingURL=LYKQUYPS.js.map
