import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model042.ts
m("model-init:model042");
var l = o("model042", e(32));

export {
  l as a
};
//# sourceMappingURL=MTWP54L7.js.map
