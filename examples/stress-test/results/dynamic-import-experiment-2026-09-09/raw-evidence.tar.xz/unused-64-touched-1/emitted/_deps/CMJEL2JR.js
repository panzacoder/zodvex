import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model054.ts
m("model-init:model054");
var l = o("model054", e(32));

export {
  l as a
};
//# sourceMappingURL=CMJEL2JR.js.map
