import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model044.ts
m("model-init:model044");
var l = o("model044", e(32));

export {
  l as a
};
//# sourceMappingURL=ARWF4E3E.js.map
