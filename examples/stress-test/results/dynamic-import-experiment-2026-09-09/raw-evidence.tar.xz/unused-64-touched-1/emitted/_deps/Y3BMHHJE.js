import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model050.ts
m("model-init:model050");
var l = o("model050", e(32));

export {
  l as a
};
//# sourceMappingURL=Y3BMHHJE.js.map
