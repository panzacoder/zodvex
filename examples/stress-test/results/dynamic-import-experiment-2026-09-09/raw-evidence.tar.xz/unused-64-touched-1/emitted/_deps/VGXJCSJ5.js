import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model032.ts
m("model-init:model032");
var l = o("model032", e(32));

export {
  l as a
};
//# sourceMappingURL=VGXJCSJ5.js.map
