import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model056.ts
m("model-init:model056");
var l = o("model056", e(32));

export {
  l as a
};
//# sourceMappingURL=Y4JIPGUV.js.map
