import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model058.ts
m("model-init:model058");
var l = o("model058", e(32));

export {
  l as a
};
//# sourceMappingURL=DZZ54JH7.js.map
