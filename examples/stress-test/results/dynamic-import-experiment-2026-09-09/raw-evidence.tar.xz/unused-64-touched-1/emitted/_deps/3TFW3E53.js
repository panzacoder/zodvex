import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model020.ts
m("model-init:model020");
var l = o("model020", e(32));

export {
  l as a
};
//# sourceMappingURL=3TFW3E53.js.map
