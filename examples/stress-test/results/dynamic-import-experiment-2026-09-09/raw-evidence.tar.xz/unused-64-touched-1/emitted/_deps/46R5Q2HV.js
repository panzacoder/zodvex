import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model021.ts
m("model-init:model021");
var l = o("model021", e(32));

export {
  l as a
};
//# sourceMappingURL=46R5Q2HV.js.map
