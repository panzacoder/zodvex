import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model036.ts
m("model-init:model036");
var l = o("model036", e(32));

export {
  l as a
};
//# sourceMappingURL=PZFQE7F2.js.map
