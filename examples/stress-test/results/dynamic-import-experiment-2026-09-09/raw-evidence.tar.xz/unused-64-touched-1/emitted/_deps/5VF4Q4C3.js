import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model043.ts
m("model-init:model043");
var l = o("model043", e(32));

export {
  l as a
};
//# sourceMappingURL=5VF4Q4C3.js.map
