import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model053.ts
m("model-init:model053");
var l = o("model053", e(32));

export {
  l as a
};
//# sourceMappingURL=M6QYKPKQ.js.map
