import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model025.ts
m("model-init:model025");
var l = o("model025", e(32));

export {
  l as a
};
//# sourceMappingURL=IX5QSF2C.js.map
