import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model064.ts
m("model-init:model064");
var l = o("model064", e(32));

export {
  l as a
};
//# sourceMappingURL=RT3KPP4N.js.map
