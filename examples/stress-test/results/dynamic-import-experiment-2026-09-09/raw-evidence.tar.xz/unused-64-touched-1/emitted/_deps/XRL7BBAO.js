import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model023.ts
m("model-init:model023");
var l = o("model023", e(32));

export {
  l as a
};
//# sourceMappingURL=XRL7BBAO.js.map
