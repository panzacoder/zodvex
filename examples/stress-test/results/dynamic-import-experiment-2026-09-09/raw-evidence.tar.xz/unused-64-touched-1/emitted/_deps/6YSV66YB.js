import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model048.ts
m("model-init:model048");
var l = o("model048", e(32));

export {
  l as a
};
//# sourceMappingURL=6YSV66YB.js.map
