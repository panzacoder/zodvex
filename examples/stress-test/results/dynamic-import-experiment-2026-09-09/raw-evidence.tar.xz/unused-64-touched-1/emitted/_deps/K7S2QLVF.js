import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model029.ts
m("model-init:model029");
var l = o("model029", e(32));

export {
  l as a
};
//# sourceMappingURL=K7S2QLVF.js.map
