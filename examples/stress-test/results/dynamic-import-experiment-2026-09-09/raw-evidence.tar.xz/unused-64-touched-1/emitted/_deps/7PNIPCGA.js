import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model035.ts
m("model-init:model035");
var l = o("model035", e(32));

export {
  l as a
};
//# sourceMappingURL=7PNIPCGA.js.map
