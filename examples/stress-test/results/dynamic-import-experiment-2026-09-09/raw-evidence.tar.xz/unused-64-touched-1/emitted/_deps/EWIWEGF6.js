import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model022.ts
m("model-init:model022");
var l = o("model022", e(32));

export {
  l as a
};
//# sourceMappingURL=EWIWEGF6.js.map
