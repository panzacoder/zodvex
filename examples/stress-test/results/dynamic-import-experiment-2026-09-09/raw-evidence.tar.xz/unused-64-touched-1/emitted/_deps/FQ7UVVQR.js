import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model049.ts
m("model-init:model049");
var l = o("model049", e(32));

export {
  l as a
};
//# sourceMappingURL=FQ7UVVQR.js.map
