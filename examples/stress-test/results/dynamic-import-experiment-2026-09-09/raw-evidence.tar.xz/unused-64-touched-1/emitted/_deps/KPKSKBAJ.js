import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model031.ts
m("model-init:model031");
var l = o("model031", e(32));

export {
  l as a
};
//# sourceMappingURL=KPKSKBAJ.js.map
