import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model040.ts
m("model-init:model040");
var l = o("model040", e(32));

export {
  l as a
};
//# sourceMappingURL=FPLAI6ZL.js.map
