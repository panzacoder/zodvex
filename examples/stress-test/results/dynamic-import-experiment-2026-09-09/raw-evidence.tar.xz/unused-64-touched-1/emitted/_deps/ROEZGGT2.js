import {
  a as o
} from "./5B5TEMMX.js";

// convex/dynamicRegistry.ts
var r = {
  model000: /* @__PURE__ */ o(() => import("../models/model000.js"), "model000"),
  model001: /* @__PURE__ */ o(() => import("../models/model001.js"), "model001"),
  model002: /* @__PURE__ */ o(() => import("../models/model002.js"), "model002"),
  model003: /* @__PURE__ */ o(() => import("../models/model003.js"), "model003"),
  model004: /* @__PURE__ */ o(() => import("../models/model004.js"), "model004"),
  model005: /* @__PURE__ */ o(() => import("../models/model005.js"), "model005"),
  model006: /* @__PURE__ */ o(() => import("../models/model006.js"), "model006"),
  model007: /* @__PURE__ */ o(() => import("../models/model007.js"), "model007"),
  model008: /* @__PURE__ */ o(() => import("../models/model008.js"), "model008"),
  model009: /* @__PURE__ */ o(() => import("../models/model009.js"), "model009"),
  model010: /* @__PURE__ */ o(() => import("../models/model010.js"), "model010"),
  model011: /* @__PURE__ */ o(() => import("../models/model011.js"), "model011"),
  model012: /* @__PURE__ */ o(() => import("../models/model012.js"), "model012"),
  model013: /* @__PURE__ */ o(() => import("../models/model013.js"), "model013"),
  model014: /* @__PURE__ */ o(() => import("../models/model014.js"), "model014"),
  model015: /* @__PURE__ */ o(() => import("../models/model015.js"), "model015"),
  model016: /* @__PURE__ */ o(() => import("../models/model016.js"), "model016"),
  model017: /* @__PURE__ */ o(() => import("../models/model017.js"), "model017"),
  model018: /* @__PURE__ */ o(() => import("../models/model018.js"), "model018"),
  model019: /* @__PURE__ */ o(() => import("../models/model019.js"), "model019"),
  model020: /* @__PURE__ */ o(() => import("../models/model020.js"), "model020"),
  model021: /* @__PURE__ */ o(() => import("../models/model021.js"), "model021"),
  model022: /* @__PURE__ */ o(() => import("../models/model022.js"), "model022"),
  model023: /* @__PURE__ */ o(() => import("../models/model023.js"), "model023"),
  model024: /* @__PURE__ */ o(() => import("../models/model024.js"), "model024"),
  model025: /* @__PURE__ */ o(() => import("../models/model025.js"), "model025"),
  model026: /* @__PURE__ */ o(() => import("../models/model026.js"), "model026"),
  model027: /* @__PURE__ */ o(() => import("../models/model027.js"), "model027"),
  model028: /* @__PURE__ */ o(() => import("../models/model028.js"), "model028"),
  model029: /* @__PURE__ */ o(() => import("../models/model029.js"), "model029"),
  model030: /* @__PURE__ */ o(() => import("../models/model030.js"), "model030"),
  model031: /* @__PURE__ */ o(() => import("../models/model031.js"), "model031"),
  model032: /* @__PURE__ */ o(() => import("../models/model032.js"), "model032"),
  model033: /* @__PURE__ */ o(() => import("../models/model033.js"), "model033"),
  model034: /* @__PURE__ */ o(() => import("../models/model034.js"), "model034"),
  model035: /* @__PURE__ */ o(() => import("../models/model035.js"), "model035"),
  model036: /* @__PURE__ */ o(() => import("../models/model036.js"), "model036"),
  model037: /* @__PURE__ */ o(() => import("../models/model037.js"), "model037"),
  model038: /* @__PURE__ */ o(() => import("../models/model038.js"), "model038"),
  model039: /* @__PURE__ */ o(() => import("../models/model039.js"), "model039"),
  model040: /* @__PURE__ */ o(() => import("../models/model040.js"), "model040"),
  model041: /* @__PURE__ */ o(() => import("../models/model041.js"), "model041"),
  model042: /* @__PURE__ */ o(() => import("../models/model042.js"), "model042"),
  model043: /* @__PURE__ */ o(() => import("../models/model043.js"), "model043"),
  model044: /* @__PURE__ */ o(() => import("../models/model044.js"), "model044"),
  model045: /* @__PURE__ */ o(() => import("../models/model045.js"), "model045"),
  model046: /* @__PURE__ */ o(() => import("../models/model046.js"), "model046"),
  model047: /* @__PURE__ */ o(() => import("../models/model047.js"), "model047"),
  model048: /* @__PURE__ */ o(() => import("../models/model048.js"), "model048"),
  model049: /* @__PURE__ */ o(() => import("../models/model049.js"), "model049"),
  model050: /* @__PURE__ */ o(() => import("../models/model050.js"), "model050"),
  model051: /* @__PURE__ */ o(() => import("../models/model051.js"), "model051"),
  model052: /* @__PURE__ */ o(() => import("../models/model052.js"), "model052"),
  model053: /* @__PURE__ */ o(() => import("../models/model053.js"), "model053"),
  model054: /* @__PURE__ */ o(() => import("../models/model054.js"), "model054"),
  model055: /* @__PURE__ */ o(() => import("../models/model055.js"), "model055"),
  model056: /* @__PURE__ */ o(() => import("../models/model056.js"), "model056"),
  model057: /* @__PURE__ */ o(() => import("../models/model057.js"), "model057"),
  model058: /* @__PURE__ */ o(() => import("../models/model058.js"), "model058"),
  model059: /* @__PURE__ */ o(() => import("../models/model059.js"), "model059"),
  model060: /* @__PURE__ */ o(() => import("../models/model060.js"), "model060"),
  model061: /* @__PURE__ */ o(() => import("../models/model061.js"), "model061"),
  model062: /* @__PURE__ */ o(() => import("../models/model062.js"), "model062"),
  model063: /* @__PURE__ */ o(() => import("../models/model063.js"), "model063"),
  model064: /* @__PURE__ */ o(() => import("../models/model064.js"), "model064")
};
async function t(e) {
  let m = r[e];
  if (!m) throw new Error("Unknown table key");
  return (await m()).model;
}
o(t, "load");
function d() {
  return Object.keys(r).reduce((e, m) => e + m.length, 0);
}
o(d, "retainedChecksum");

export {
  t as a,
  d as b
};
//# sourceMappingURL=ROEZGGT2.js.map
