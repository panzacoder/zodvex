import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model063.ts
m("model-init:model063");
var l = o("model063", e(32));

export {
  l as a
};
//# sourceMappingURL=4WI7T6FM.js.map
