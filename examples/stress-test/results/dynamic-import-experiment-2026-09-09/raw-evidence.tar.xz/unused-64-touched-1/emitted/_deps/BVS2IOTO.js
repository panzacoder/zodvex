import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model052.ts
m("model-init:model052");
var l = o("model052", e(32));

export {
  l as a
};
//# sourceMappingURL=BVS2IOTO.js.map
