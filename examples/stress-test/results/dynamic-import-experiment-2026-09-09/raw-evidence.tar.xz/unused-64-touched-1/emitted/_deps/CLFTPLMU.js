import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model055.ts
m("model-init:model055");
var l = o("model055", e(32));

export {
  l as a
};
//# sourceMappingURL=CLFTPLMU.js.map
