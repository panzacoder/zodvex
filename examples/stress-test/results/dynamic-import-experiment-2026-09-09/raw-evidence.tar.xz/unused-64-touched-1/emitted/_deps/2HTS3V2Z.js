import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model041.ts
m("model-init:model041");
var l = o("model041", e(32));

export {
  l as a
};
//# sourceMappingURL=2HTS3V2Z.js.map
