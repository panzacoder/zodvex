import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model062.ts
m("model-init:model062");
var l = o("model062", e(32));

export {
  l as a
};
//# sourceMappingURL=Y2AK6NEG.js.map
