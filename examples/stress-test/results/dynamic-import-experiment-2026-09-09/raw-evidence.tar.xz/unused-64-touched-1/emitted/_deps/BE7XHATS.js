import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model030.ts
m("model-init:model030");
var l = o("model030", e(32));

export {
  l as a
};
//# sourceMappingURL=BE7XHATS.js.map
