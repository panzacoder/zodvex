import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model057.ts
m("model-init:model057");
var l = o("model057", e(32));

export {
  l as a
};
//# sourceMappingURL=QHGYYOQ7.js.map
