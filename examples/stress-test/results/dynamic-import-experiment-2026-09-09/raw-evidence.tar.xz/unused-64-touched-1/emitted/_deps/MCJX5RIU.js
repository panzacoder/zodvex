import {
  c as o
} from "./IKXYHD27.js";
import {
  a as m
} from "./KY4JIOXG.js";
import {
  U as e
} from "./WWZ3L44K.js";

// convex/models/model046.ts
m("model-init:model046");
var l = o("model046", e(32));

export {
  l as a
};
//# sourceMappingURL=MCJX5RIU.js.map
