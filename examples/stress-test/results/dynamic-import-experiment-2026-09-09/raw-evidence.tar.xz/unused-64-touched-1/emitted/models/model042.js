import {
  a
} from "../_deps/MTWP54L7.js";
import "../_deps/IKXYHD27.js";
import "../_deps/KY4JIOXG.js";
import "../_deps/WWZ3L44K.js";
import "../_deps/W3VG7GIX.js";
import "../_deps/5B5TEMMX.js";
export {
  a as model
};
//# sourceMappingURL=model042.js.map
