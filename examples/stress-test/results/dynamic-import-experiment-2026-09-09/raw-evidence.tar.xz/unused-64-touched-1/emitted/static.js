import {
  b as g,
  c as w
} from "./_deps/3SMRMDLY.js";
import "./_deps/GZBSUFA2.js";
import "./_deps/ELCRTJKI.js";
import "./_deps/Y2AK6NEG.js";
import "./_deps/4WI7T6FM.js";
import "./_deps/RT3KPP4N.js";
import "./_deps/BVS2IOTO.js";
import "./_deps/M6QYKPKQ.js";
import "./_deps/CMJEL2JR.js";
import "./_deps/CLFTPLMU.js";
import "./_deps/Y4JIPGUV.js";
import "./_deps/QHGYYOQ7.js";
import "./_deps/DZZ54JH7.js";
import "./_deps/ZZYN72QX.js";
import "./_deps/ARWF4E3E.js";
import "./_deps/YVEBSYWO.js";
import "./_deps/MCJX5RIU.js";
import "./_deps/L5YZYL6Q.js";
import "./_deps/6YSV66YB.js";
import "./_deps/FQ7UVVQR.js";
import "./_deps/Y3BMHHJE.js";
import "./_deps/C3BNBPOE.js";
import "./_deps/PZFQE7F2.js";
import "./_deps/IUCJUUAJ.js";
import "./_deps/S32ZKO2M.js";
import "./_deps/H4FAQEJI.js";
import "./_deps/FPLAI6ZL.js";
import "./_deps/2HTS3V2Z.js";
import "./_deps/MTWP54L7.js";
import "./_deps/5VF4Q4C3.js";
import "./_deps/ILTAMMZ3.js";
import "./_deps/K7S2QLVF.js";
import "./_deps/BE7XHATS.js";
import "./_deps/KPKSKBAJ.js";
import "./_deps/VGXJCSJ5.js";
import "./_deps/66GGXB65.js";
import "./_deps/VIJVUKSB.js";
import "./_deps/7PNIPCGA.js";
import "./_deps/3TFW3E53.js";
import "./_deps/46R5Q2HV.js";
import "./_deps/EWIWEGF6.js";
import "./_deps/XRL7BBAO.js";
import "./_deps/QWKGAXLK.js";
import "./_deps/IX5QSF2C.js";
import "./_deps/4EXSQQQO.js";
import "./_deps/A7XLJVKU.js";
import "./_deps/V4JDGLX5.js";
import "./_deps/5PXKOPYO.js";
import "./_deps/3KKBOPCO.js";
import "./_deps/BEY6CV7L.js";
import "./_deps/TXG2FVAL.js";
import "./_deps/LYKQUYPS.js";
import "./_deps/UZ6HZCMS.js";
import "./_deps/ZTHTIARM.js";
import "./_deps/LMWUKZAL.js";
import "./_deps/GYUTJ3XM.js";
import "./_deps/VSKNOBMU.js";
import "./_deps/CM7PCYUA.js";
import "./_deps/JDYY7C4Q.js";
import "./_deps/IQ5EA24B.js";
import "./_deps/7Z2YKVKP.js";
import "./_deps/QNUBZY2S.js";
import {
  a as f
} from "./_deps/AQJ3QLJ2.js";
import {
  a as o,
  b as r,
  c as p
} from "./_deps/VNSRRA4A.js";
import {
  a as u,
  b as d,
  c as m
} from "./_deps/EYM35JYW.js";
import "./_deps/BZ3CEX4W.js";
import "./_deps/ZJW33SAG.js";
import "./_deps/O3FQPIRV.js";
import "./_deps/GZGXZGJY.js";
import {
  a as b,
  b as h
} from "./_deps/IKXYHD27.js";
import {
  b as s
} from "./_deps/KY4JIOXG.js";
import "./_deps/WWZ3L44K.js";
import "./_deps/W3VG7GIX.js";
import {
  a
} from "./_deps/5B5TEMMX.js";

// convex/static.ts
async function c(y, e) {
  if (e.tables.length < 1 || e.tables.length > 8 || new Set(e.tables).size !== e.tables.length)
    throw new Error("Invalid bounded table selection");
  let x = s(), i = [], l = [];
  for (let n of e.tables) {
    let t = await g(n);
    i.push(t), l.push(f(t.schema.insert, 32, b, h));
  }
  return p(e.gc), {
    nonce: e.nonce,
    before: x,
    after: s(),
    touched: e.tables,
    registryChecksum: w(),
    liveFields: i.reduce((n, t) => n + Object.keys(t.schema.insert.shape).length, 0),
    results: l
  };
}
a(c, "handler");
var P = m({ args: r, returns: o, handler: c }), V = u({ args: r, returns: o, handler: c }), j = d({ args: r, returns: o, handler: c });
export {
  j as mutationProbe,
  P as probe,
  V as queryProbe
};
//# sourceMappingURL=static.js.map
