var pa = Object.defineProperty;
var i = (e, t) => pa(e, "name", { value: t, configurable: !0 });
var nt = (e, t) => {
  for (var r in t)
    pa(e, r, { get: t[r], enumerable: !0 });
};

// graphProbe.ts
import { query as Ap } from "convex:/_system/repl/wrappers.js";

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/base64.js
var ue = [], re = [], md = Uint8Array, Cn = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
for (ze = 0, ga = Cn.length; ze < ga; ++ze)
  ue[ze] = Cn[ze], re[Cn.charCodeAt(ze)] = ze;
var ze, ga;
re[45] = 62;
re[95] = 63;
function pd(e) {
  var t = e.length;
  if (t % 4 > 0)
    throw new Error("Invalid string. Length must be a multiple of 4");
  var r = e.indexOf("=");
  r === -1 && (r = t);
  var n = r === t ? 0 : 4 - r % 4;
  return [r, n];
}
i(pd, "getLens");
function gd(e, t, r) {
  return (t + r) * 3 / 4 - r;
}
i(gd, "_byteLength");
function ot(e) {
  var t, r = pd(e), n = r[0], o = r[1], a = new md(gd(e, n, o)), c = 0, u = o > 0 ? n - 4 : n, s;
  for (s = 0; s < u; s += 4)
    t = re[e.charCodeAt(s)] << 18 | re[e.charCodeAt(s + 1)] << 12 | re[e.charCodeAt(s + 2)] << 6 | re[e.charCodeAt(s + 3)], a[c++] = t >> 16 & 255, a[c++] = t >> 8 & 255, a[c++] = t & 255;
  return o === 2 && (t = re[e.charCodeAt(s)] << 2 | re[e.charCodeAt(s + 1)] >> 4, a[c++] = t & 255), o === 1 && (t = re[e.charCodeAt(s)] << 10 | re[e.charCodeAt(s + 1)] << 4 | re[e.charCodeAt(s + 2)] >> 2, a[c++] = t >> 8 & 255, a[c++] = t & 255), a;
}
i(ot, "toByteArray");
function hd(e) {
  return ue[e >> 18 & 63] + ue[e >> 12 & 63] + ue[e >> 6 & 63] + ue[e & 63];
}
i(hd, "tripletToBase64");
function vd(e, t, r) {
  for (var n, o = [], a = t; a < r; a += 3)
    n = (e[a] << 16 & 16711680) + (e[a + 1] << 8 & 65280) + (e[a + 2] & 255), o.push(hd(n));
  return o.join("");
}
i(vd, "encodeChunk");
function it(e) {
  for (var t, r = e.length, n = r % 3, o = [], a = 16383, c = 0, u = r - n; c < u; c += a)
    o.push(
      vd(
        e,
        c,
        c + a > u ? u : c + a
      )
    );
  return n === 1 ? (t = e[r - 1], o.push(ue[t >> 2] + ue[t << 4 & 63] + "==")) : n === 2 && (t = (e[r - 2] << 8) + e[r - 1], o.push(
    ue[t >> 10] + ue[t >> 4 & 63] + ue[t << 2 & 63] + "="
  )), o.join("");
}
i(it, "fromByteArray");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/common/index.js
function ge(e) {
  if (e === void 0)
    return {};
  if (!qt(e))
    throw new Error(
      `The arguments to a Convex function must be an object. Received: ${e}`
    );
  return e;
}
i(ge, "parseArgs");
function qt(e) {
  let t = typeof e == "object", r = Object.getPrototypeOf(e), n = r === null || r === Object.prototype || // Objects generated from other contexts (e.g. across Node.js `vm` modules) will not satisfy the previous
  // conditions but are still simple objects.
  r?.constructor?.name === "Object";
  return t && n;
}
i(qt, "isSimpleObject");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/value.js
var ya = !0, Ne = BigInt("-9223372036854775808"), Jn = BigInt("9223372036854775807"), Fn = BigInt("0"), $d = BigInt("8"), yd = BigInt("256");
function ba(e) {
  return Number.isNaN(e) || !Number.isFinite(e) || Object.is(e, -0);
}
i(ba, "isSpecial");
function bd(e) {
  e < Fn && (e -= Ne + Ne);
  let t = e.toString(16);
  t.length % 2 === 1 && (t = "0" + t);
  let r = new Uint8Array(new ArrayBuffer(8)), n = 0;
  for (let o of t.match(/.{2}/g).reverse())
    r.set([parseInt(o, 16)], n++), e >>= $d;
  return it(r);
}
i(bd, "slowBigIntToBase64");
function xd(e) {
  let t = ot(e);
  if (t.byteLength !== 8)
    throw new Error(
      `Received ${t.byteLength} bytes, expected 8 for $integer`
    );
  let r = Fn, n = Fn;
  for (let o of t)
    r += BigInt(o) * yd ** n, n++;
  return r > Jn && (r += Ne + Ne), r;
}
i(xd, "slowBase64ToBigInt");
function _d(e) {
  if (e < Ne || Jn < e)
    throw new Error(
      `BigInt ${e} does not fit into a 64-bit signed integer.`
    );
  let t = new ArrayBuffer(8);
  return new DataView(t).setBigInt64(0, e, !0), it(new Uint8Array(t));
}
i(_d, "modernBigIntToBase64");
function kd(e) {
  let t = ot(e);
  if (t.byteLength !== 8)
    throw new Error(
      `Received ${t.byteLength} bytes, expected 8 for $integer`
    );
  return new DataView(t.buffer).getBigInt64(0, !0);
}
i(kd, "modernBase64ToBigInt");
var wd = DataView.prototype.setBigInt64 ? _d : bd, zd = DataView.prototype.getBigInt64 ? kd : xd, va = 1024;
function Ln(e) {
  if (e.length > va)
    throw new Error(
      `Field name ${e} exceeds maximum field name length ${va}.`
    );
  if (e.startsWith("$"))
    throw new Error(`Field name ${e} starts with a '$', which is reserved.`);
  for (let t = 0; t < e.length; t += 1) {
    let r = e.charCodeAt(t);
    if (r < 32 || r >= 127)
      throw new Error(
        `Field name ${e} has invalid character '${e[t]}': Field names can only contain non-control ASCII characters`
      );
  }
}
i(Ln, "validateObjectField");
function R(e) {
  if (e === null || typeof e == "boolean" || typeof e == "number" || typeof e == "string")
    return e;
  if (Array.isArray(e))
    return e.map((n) => R(n));
  if (typeof e != "object")
    throw new Error(`Unexpected type of ${e}`);
  let t = Object.entries(e);
  if (t.length === 1) {
    let n = t[0][0];
    if (n === "$bytes") {
      if (typeof e.$bytes != "string")
        throw new Error(`Malformed $bytes field on ${e}`);
      return ot(e.$bytes).buffer;
    }
    if (n === "$integer") {
      if (typeof e.$integer != "string")
        throw new Error(`Malformed $integer field on ${e}`);
      return zd(e.$integer);
    }
    if (n === "$float") {
      if (typeof e.$float != "string")
        throw new Error(`Malformed $float field on ${e}`);
      let o = ot(e.$float);
      if (o.byteLength !== 8)
        throw new Error(
          `Received ${o.byteLength} bytes, expected 8 for $float`
        );
      let c = new DataView(o.buffer).getFloat64(0, ya);
      if (!ba(c))
        throw new Error(`Float ${c} should be encoded as a number`);
      return c;
    }
    if (n === "$set")
      throw new Error(
        "Received a Set which is no longer supported as a Convex type."
      );
    if (n === "$map")
      throw new Error(
        "Received a Map which is no longer supported as a Convex type."
      );
  }
  let r = {};
  for (let [n, o] of Object.entries(e))
    Ln(n), r[n] = R(o);
  return r;
}
i(R, "jsonToConvex");
var $a = 16384;
function Ie(e) {
  let t = JSON.stringify(e, (r, n) => n === void 0 ? "undefined" : typeof n == "bigint" ? `${n.toString()}n` : n);
  if (t.length > $a) {
    let r = "[...truncated]", n = $a - r.length, o = t.codePointAt(n - 1);
    return o !== void 0 && o > 65535 && (n -= 1), t.substring(0, n) + r;
  }
  return t;
}
i(Ie, "stringifyValueForError");
function at(e, t, r, n) {
  if (e === void 0) {
    let c = r && ` (present at path ${r} in original object ${Ie(
      t
    )})`;
    throw new Error(
      `undefined is not a valid Convex value${c}. To learn about Convex's supported types, see https://docs.convex.dev/using/types.`
    );
  }
  if (e === null)
    return e;
  if (typeof e == "bigint") {
    if (e < Ne || Jn < e)
      throw new Error(
        `BigInt ${e} does not fit into a 64-bit signed integer.`
      );
    return { $integer: wd(e) };
  }
  if (typeof e == "number")
    if (ba(e)) {
      let c = new ArrayBuffer(8);
      return new DataView(c).setFloat64(0, e, ya), { $float: it(new Uint8Array(c)) };
    } else
      return e;
  if (typeof e == "boolean" || typeof e == "string")
    return e;
  if (e instanceof ArrayBuffer)
    return { $bytes: it(new Uint8Array(e)) };
  if (Array.isArray(e))
    return e.map(
      (c, u) => at(c, t, r + `[${u}]`, !1)
    );
  if (e instanceof Set)
    throw new Error(
      Rn(r, "Set", [...e], t)
    );
  if (e instanceof Map)
    throw new Error(
      Rn(r, "Map", [...e], t)
    );
  if (!qt(e)) {
    let c = e?.constructor?.name, u = c ? `${c} ` : "";
    throw new Error(
      Rn(r, u, e, t)
    );
  }
  let o = {}, a = Object.entries(e);
  a.sort(([c, u], [s, d]) => c === s ? 0 : c < s ? -1 : 1);
  for (let [c, u] of a)
    u !== void 0 ? (Ln(c), o[c] = at(u, t, r + `.${c}`, !1)) : n && (Ln(c), o[c] = xa(
      u,
      t,
      r + `.${c}`
    ));
  return o;
}
i(at, "convexToJsonInternal");
function Rn(e, t, r, n) {
  return e ? `${t}${Ie(
    r
  )} is not a supported Convex type (present at path ${e} in original object ${Ie(
    n
  )}). To learn about Convex's supported types, see https://docs.convex.dev/using/types.` : `${t}${Ie(
    r
  )} is not a supported Convex type.`;
}
i(Rn, "errorMessageForUnsupportedType");
function xa(e, t, r) {
  if (e === void 0)
    return { $undefined: null };
  if (t === void 0)
    throw new Error(
      `Programming error. Current value is ${Ie(
        e
      )} but original value is undefined`
    );
  return at(e, t, r, !1);
}
i(xa, "convexOrUndefinedToJsonInternal");
function D(e) {
  return at(e, e, "", !1);
}
i(D, "convexToJson");
function ne(e) {
  return xa(e, e, "");
}
i(ne, "convexOrUndefinedToJson");
function _a(e) {
  return at(e, e, "", !0);
}
i(_a, "patchValueToJson");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/validators.js
var Id = Object.defineProperty, Sd = /* @__PURE__ */ i((e, t, r) => t in e ? Id(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), A = /* @__PURE__ */ i((e, t, r) => Sd(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), jd = "https://docs.convex.dev/error#undefined-validator";
function ct(e, t) {
  let r = t !== void 0 ? ` for field "${t}"` : "";
  throw new Error(
    `A validator is undefined${r} in ${e}. This is often caused by circular imports. See ${jd} for details.`
  );
}
i(ct, "throwUndefinedValidatorError");
var G = class {
  static {
    i(this, "BaseValidator");
  }
  constructor({ isOptional: t }) {
    A(this, "type"), A(this, "fieldPaths"), A(this, "isOptional"), A(this, "isConvexValidator"), this.isOptional = t, this.isConvexValidator = !0;
  }
}, Gt = class e extends G {
  static {
    i(this, "VId");
  }
  /**
   * Usually you'd use `v.id(tableName)` instead.
   */
  constructor({
    isOptional: t,
    tableName: r
  }) {
    if (super({ isOptional: t }), A(this, "tableName"), A(this, "kind", "id"), typeof r != "string")
      throw new Error("v.id(tableName) requires a string");
    this.tableName = r;
  }
  /** @internal */
  get json() {
    return { type: "id", tableName: this.tableName };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      tableName: this.tableName
    });
  }
}, ut = class e extends G {
  static {
    i(this, "VFloat64");
  }
  constructor() {
    super(...arguments), A(this, "kind", "float64");
  }
  /** @internal */
  get json() {
    return { type: "number" };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, st = class e extends G {
  static {
    i(this, "VInt64");
  }
  constructor() {
    super(...arguments), A(this, "kind", "int64");
  }
  /** @internal */
  get json() {
    return { type: "bigint" };
  }
  /** @internal */
  asOptional() {
    return new e({ isOptional: "optional" });
  }
}, Wt = class e extends G {
  static {
    i(this, "VBoolean");
  }
  constructor() {
    super(...arguments), A(this, "kind", "boolean");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, Kt = class e extends G {
  static {
    i(this, "VBytes");
  }
  constructor() {
    super(...arguments), A(this, "kind", "bytes");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({ isOptional: "optional" });
  }
}, Xt = class e extends G {
  static {
    i(this, "VString");
  }
  constructor() {
    super(...arguments), A(this, "kind", "string");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, Ht = class e extends G {
  static {
    i(this, "VNull");
  }
  constructor() {
    super(...arguments), A(this, "kind", "null");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({ isOptional: "optional" });
  }
}, Qt = class e extends G {
  static {
    i(this, "VAny");
  }
  constructor() {
    super(...arguments), A(this, "kind", "any");
  }
  /** @internal */
  get json() {
    return {
      type: this.kind
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, Yt = class e extends G {
  static {
    i(this, "VObject");
  }
  /**
   * Usually you'd use `v.object({ ... })` instead.
   */
  constructor({
    isOptional: t,
    fields: r
  }) {
    super({ isOptional: t }), A(this, "fields"), A(this, "kind", "object"), globalThis.Object.entries(r).forEach(([n, o]) => {
      if (o === void 0 && ct("v.object()", n), !o.isConvexValidator)
        throw new Error("v.object() entries must be validators");
    }), this.fields = r;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: globalThis.Object.fromEntries(
        globalThis.Object.entries(this.fields).map(([t, r]) => [
          t,
          {
            fieldType: r.json,
            optional: r.isOptional === "optional"
          }
        ])
      )
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      fields: this.fields
    });
  }
  /**
   * Create a new VObject with the specified fields omitted.
   * @param fields The field names to omit from this VObject.
   */
  omit(...t) {
    let r = { ...this.fields };
    for (let n of t)
      delete r[n];
    return new e({
      isOptional: this.isOptional,
      fields: r
    });
  }
  /**
   * Create a new VObject with only the specified fields.
   * @param fields The field names to pick from this VObject.
   */
  pick(...t) {
    let r = {};
    for (let n of t)
      r[n] = this.fields[n];
    return new e({
      isOptional: this.isOptional,
      fields: r
    });
  }
  /**
   * Create a new VObject with all fields marked as optional.
   */
  partial() {
    let t = {};
    for (let [r, n] of globalThis.Object.entries(this.fields))
      t[r] = n.asOptional();
    return new e({
      isOptional: this.isOptional,
      fields: t
    });
  }
  /**
   * Create a new VObject with additional fields merged in.
   * @param fields An object with additional validators to merge into this VObject.
   */
  extend(t) {
    return new e({
      isOptional: this.isOptional,
      fields: { ...this.fields, ...t }
    });
  }
}, er = class e extends G {
  static {
    i(this, "VLiteral");
  }
  /**
   * Usually you'd use `v.literal(value)` instead.
   */
  constructor({ isOptional: t, value: r }) {
    if (super({ isOptional: t }), A(this, "value"), A(this, "kind", "literal"), typeof r != "string" && typeof r != "boolean" && typeof r != "number" && typeof r != "bigint")
      throw new Error("v.literal(value) must be a string, number, or boolean");
    this.value = r;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: D(this.value)
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      value: this.value
    });
  }
}, tr = class e extends G {
  static {
    i(this, "VArray");
  }
  /**
   * Usually you'd use `v.array(element)` instead.
   */
  constructor({
    isOptional: t,
    element: r
  }) {
    super({ isOptional: t }), A(this, "element"), A(this, "kind", "array"), r === void 0 && ct("v.array()"), this.element = r;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: this.element.json
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      element: this.element
    });
  }
}, rr = class e extends G {
  static {
    i(this, "VRecord");
  }
  /**
   * Usually you'd use `v.record(key, value)` instead.
   */
  constructor({
    isOptional: t,
    key: r,
    value: n
  }) {
    if (super({ isOptional: t }), A(this, "key"), A(this, "value"), A(this, "kind", "record"), r === void 0 && ct("v.record()", "key"), n === void 0 && ct("v.record()", "value"), r.isOptional === "optional")
      throw new Error("Record validator cannot have optional keys");
    if (n.isOptional === "optional")
      throw new Error("Record validator cannot have optional values");
    if (!r.isConvexValidator || !n.isConvexValidator)
      throw new Error("Key and value of v.record() but be validators");
    this.key = r, this.value = n;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      // This cast is needed because TypeScript thinks the key type is too wide
      keys: this.key.json,
      values: {
        fieldType: this.value.json,
        optional: !1
      }
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      key: this.key,
      value: this.value
    });
  }
}, nr = class e extends G {
  static {
    i(this, "VUnion");
  }
  /**
   * Usually you'd use `v.union(...members)` instead.
   */
  constructor({ isOptional: t, members: r }) {
    super({ isOptional: t }), A(this, "members"), A(this, "kind", "union"), r.forEach((n, o) => {
      if (n === void 0 && ct("v.union()", `member at index ${o}`), !n.isConvexValidator)
        throw new Error("All members of v.union() must be validators");
    }), this.members = r;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: this.members.map((t) => t.json)
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      members: this.members
    });
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/validator.js
function Vn(e) {
  return !!e.isConvexValidator;
}
i(Vn, "isValidator");
function De(e) {
  return Vn(e) ? e : m.object(e);
}
i(De, "asObjectValidator");
var m = {
  /**
   * Validates that the value is a document ID for the given table.
   *
   * IDs are strings at runtime but are typed as `Id<"tableName">` in
   * TypeScript for type safety.
   *
   * @example
   * ```typescript
   * args: { userId: v.id("users") }
   * ```
   *
   * @param tableName The name of the table.
   */
  id: /* @__PURE__ */ i((e) => new Gt({
    isOptional: "required",
    tableName: e
  }), "id"),
  /**
   * Validates that the value is `null`.
   *
   * Use `returns: v.null()` for functions that don't return a meaningful value.
   * JavaScript `undefined` is not a valid Convex value, it is automatically
   * converted to `null`.
   */
  null: /* @__PURE__ */ i(() => new Ht({ isOptional: "required" }), "null"),
  /**
   * Validates that the value is a JavaScript `number` (Convex Float64).
   *
   * Supports all IEEE-754 double-precision floating point numbers including
   * NaN and Infinity.
   *
   * Alias for `v.float64()`.
   */
  number: /* @__PURE__ */ i(() => new ut({ isOptional: "required" }), "number"),
  /**
   * Validates that the value is a JavaScript `number` (Convex Float64).
   *
   * Supports all IEEE-754 double-precision floating point numbers.
   */
  float64: /* @__PURE__ */ i(() => new ut({ isOptional: "required" }), "float64"),
  /**
   * @deprecated Use `v.int64()` instead.
   */
  bigint: /* @__PURE__ */ i(() => new st({ isOptional: "required" }), "bigint"),
  /**
   * Validates that the value is a JavaScript `bigint` (Convex Int64).
   *
   * Supports BigInts between -2^63 and 2^63-1.
   *
   * @example
   * ```typescript
   * args: { timestamp: v.int64() }
   * // Usage: createDoc({ timestamp: 1234567890n })
   * ```
   */
  int64: /* @__PURE__ */ i(() => new st({ isOptional: "required" }), "int64"),
  /**
   * Validates that the value is a `boolean`.
   */
  boolean: /* @__PURE__ */ i(() => new Wt({ isOptional: "required" }), "boolean"),
  /**
   * Validates that the value is a `string`.
   *
   * Strings are stored as UTF-8 and their storage size is calculated as their
   * UTF-8 encoded size.
   */
  string: /* @__PURE__ */ i(() => new Xt({ isOptional: "required" }), "string"),
  /**
   * Validates that the value is an `ArrayBuffer` (Convex Bytes).
   *
   * Use for binary data.
   */
  bytes: /* @__PURE__ */ i(() => new Kt({ isOptional: "required" }), "bytes"),
  /**
   * Validates that the value is exactly equal to the given literal.
   *
   * Useful for discriminated unions and enum-like patterns.
   *
   * @example
   * ```typescript
   * // Discriminated union pattern:
   * v.union(
   *   v.object({ kind: v.literal("error"), message: v.string() }),
   *   v.object({ kind: v.literal("success"), value: v.number() }),
   * )
   * ```
   *
   * @param literal The literal value to compare against.
   */
  literal: /* @__PURE__ */ i((e) => new er({ isOptional: "required", value: e }), "literal"),
  /**
   * Validates that the value is an `Array` where every element matches the
   * given validator.
   *
   * Arrays can have at most 8192 elements.
   *
   * @example
   * ```typescript
   * args: { tags: v.array(v.string()) }
   * args: { coordinates: v.array(v.number()) }
   * args: { items: v.array(v.object({ name: v.string(), qty: v.number() })) }
   * ```
   *
   * @param element The validator for the elements of the array.
   */
  array: /* @__PURE__ */ i((e) => new tr({ isOptional: "required", element: e }), "array"),
  /**
   * Validates that the value is an `Object` with the specified properties.
   *
   * Objects can have at most 1024 entries. Field names must be non-empty and
   * must not start with `"$"` or `"_"` (`_` is reserved for system fields
   * like `_id` and `_creationTime`; `$` is reserved for Convex internal use).
   *
   * @example
   * ```typescript
   * args: {
   *   user: v.object({
   *     name: v.string(),
   *     email: v.string(),
   *     age: v.optional(v.number()),
   *   })
   * }
   * ```
   *
   * @param fields An object mapping property names to their validators.
   */
  object: /* @__PURE__ */ i((e) => new Yt({ isOptional: "required", fields: e }), "object"),
  /**
   * Validates that the value is a `Record` (object with dynamic keys).
   *
   * Records are objects at runtime but allow dynamic keys, unlike `v.object()`
   * which requires known property names. Keys must be ASCII characters only,
   * non-empty, and not start with `"$"` or `"_"`.
   *
   * @example
   * ```typescript
   * // Map of user IDs to scores:
   * args: { scores: v.record(v.id("users"), v.number()) }
   *
   * // Map of string keys to string values:
   * args: { metadata: v.record(v.string(), v.string()) }
   * ```
   *
   * @param keys The validator for the keys of the record.
   * @param values The validator for the values of the record.
   */
  record: /* @__PURE__ */ i((e, t) => new rr({
    isOptional: "required",
    key: e,
    value: t
  }), "record"),
  /**
   * Validates that the value matches at least one of the given validators.
   *
   * @example
   * ```typescript
   * // Allow string or number:
   * args: { value: v.union(v.string(), v.number()) }
   *
   * // Discriminated union (recommended pattern):
   * v.union(
   *   v.object({ kind: v.literal("text"), body: v.string() }),
   *   v.object({ kind: v.literal("image"), url: v.string() }),
   * )
   *
   * // Nullable value:
   * returns: v.union(v.object({ ... }), v.null())
   * ```
   *
   * @param members The validators to match against.
   */
  union: /* @__PURE__ */ i((...e) => new nr({
    isOptional: "required",
    members: e
  }), "union"),
  /**
   * A validator that accepts any Convex value without validation.
   *
   * Prefer using specific validators when possible for better type safety
   * and runtime validation.
   */
  any: /* @__PURE__ */ i(() => new Qt({ isOptional: "required" }), "any"),
  /**
   * Makes a property optional in an object validator.
   *
   * An optional property can be omitted entirely when creating a document or
   * calling a function. This is different from `v.nullable()` which requires
   * the property to be present but allows `null`.
   *
   * @example
   * ```typescript
   * v.object({
   *   name: v.string(),              // required
   *   nickname: v.optional(v.string()), // can be omitted
   * })
   *
   * // Valid: { name: "Alice" }
   * // Valid: { name: "Alice", nickname: "Ali" }
   * // Invalid: { name: "Alice", nickname: null }  - use v.nullable() for this
   * ```
   *
   * @param value The property value validator to make optional.
   */
  optional: /* @__PURE__ */ i((e) => e.asOptional(), "optional"),
  /**
   * Allows a value to be either the given type or `null`.
   *
   * This is shorthand for `v.union(value, v.null())`. Unlike `v.optional()`,
   * the property must still be present, but may be `null`.
   *
   * @example
   * ```typescript
   * v.object({
   *   name: v.string(),
   *   deletedAt: v.nullable(v.number()), // must be present, can be null
   * })
   *
   * // Valid: { name: "Alice", deletedAt: null }
   * // Valid: { name: "Alice", deletedAt: 1234567890 }
   * // Invalid: { name: "Alice" }  - deletedAt is required
   * ```
   */
  nullable: /* @__PURE__ */ i((e) => m.union(e, m.null()), "nullable")
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/errors.js
var Od = Object.defineProperty, Pd = /* @__PURE__ */ i((e, t, r) => t in e ? Od(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), Mn = /* @__PURE__ */ i((e, t, r) => Pd(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), ka, wa, Td = Symbol.for("ConvexError"), Ae = class extends (wa = Error, ka = Td, wa) {
  static {
    i(this, "ConvexError");
  }
  constructor(t) {
    super(typeof t == "string" ? t : Ie(t)), Mn(this, "name", "ConvexError"), Mn(this, "data"), Mn(this, ka, !0), this.data = t;
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/compare_utf8.js
var za = /* @__PURE__ */ i(() => Array.from({ length: 4 }, () => 0), "arr"), ng = za(), og = za();

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/index.js
var J = "1.32.0";

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/syscall.js
function lt(e, t) {
  if (typeof Convex > "u" || Convex.syscall === void 0)
    throw new Error(
      "The Convex database and auth objects are being used outside of a Convex backend. Did you mean to use `useQuery` or `useMutation` to call a Convex function?"
    );
  let r = Convex.syscall(e, JSON.stringify(t));
  return JSON.parse(r);
}
i(lt, "performSyscall");
async function O(e, t) {
  if (typeof Convex > "u" || Convex.asyncSyscall === void 0)
    throw new Error(
      "The Convex database and auth objects are being used outside of a Convex backend. Did you mean to use `useQuery` or `useMutation` to call a Convex function?"
    );
  let r;
  try {
    r = await Convex.asyncSyscall(e, JSON.stringify(t));
  } catch (n) {
    if (n.data !== void 0) {
      let o = new Ae(n.message);
      throw o.data = R(n.data), o;
    }
    throw new Error(n.message);
  }
  return JSON.parse(r);
}
i(O, "performAsyncSyscall");
function or(e, t) {
  if (typeof Convex > "u" || Convex.jsSyscall === void 0)
    throw new Error(
      "The Convex database and auth objects are being used outside of a Convex backend. Did you mean to use `useQuery` or `useMutation` to call a Convex function?"
    );
  return Convex.jsSyscall(e, t);
}
i(or, "performJsSyscall");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/functionName.js
var dt = Symbol.for("functionName");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/components/paths.js
var Ia = Symbol.for("toReferencePath");
function Ud(e) {
  return e[Ia] ?? null;
}
i(Ud, "extractReferencePath");
function Zd(e) {
  return e.startsWith("function://");
}
i(Zd, "isFunctionHandle");
function ae(e) {
  let t;
  if (typeof e == "string")
    Zd(e) ? t = { functionHandle: e } : t = { name: e };
  else if (e[dt])
    t = { name: e[dt] };
  else {
    let r = Ud(e);
    if (!r)
      throw new Error(`${e} is not a functionReference`);
    t = { reference: r };
  }
  return t;
}
i(ae, "getFunctionAddress");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/actions_impl.js
function Bn(e, t, r) {
  return {
    ...ae(t),
    args: D(ge(r)),
    version: J,
    requestId: e
  };
}
i(Bn, "syscallArgs");
function Sa(e) {
  return {
    runQuery: /* @__PURE__ */ i(async (t, r) => {
      let n = await O(
        "1.0/actions/query",
        Bn(e, t, r)
      );
      return R(n);
    }, "runQuery"),
    runMutation: /* @__PURE__ */ i(async (t, r) => {
      let n = await O(
        "1.0/actions/mutation",
        Bn(e, t, r)
      );
      return R(n);
    }, "runMutation"),
    runAction: /* @__PURE__ */ i(async (t, r) => {
      let n = await O(
        "1.0/actions/action",
        Bn(e, t, r)
      );
      return R(n);
    }, "runAction")
  };
}
i(Sa, "setupActionCalls");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/vector_search.js
var Ed = Object.defineProperty, Nd = /* @__PURE__ */ i((e, t, r) => t in e ? Ed(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), ja = /* @__PURE__ */ i((e, t, r) => Nd(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), ir = class {
  static {
    i(this, "FilterExpression");
  }
  /**
   * @internal
   */
  constructor() {
    ja(this, "_isExpression"), ja(this, "_value");
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/validate.js
function j(e, t, r, n) {
  if (e === void 0)
    throw new TypeError(
      `Must provide arg ${t} \`${n}\` to \`${r}\``
    );
}
i(j, "validateArg");
function Oa(e, t, r, n) {
  if (!Number.isInteger(e) || e < 0)
    throw new TypeError(
      `Arg ${t} \`${n}\` to \`${r}\` must be a non-negative integer`
    );
}
i(Oa, "validateArgIsNonNegativeInteger");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/vector_search_impl.js
var Dd = Object.defineProperty, Ad = /* @__PURE__ */ i((e, t, r) => t in e ? Dd(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), qn = /* @__PURE__ */ i((e, t, r) => Ad(e, typeof t != "symbol" ? t + "" : t, r), "__publicField");
function Pa(e) {
  return async (t, r, n) => {
    if (j(t, 1, "vectorSearch", "tableName"), j(r, 2, "vectorSearch", "indexName"), j(n, 3, "vectorSearch", "query"), !n.vector || !Array.isArray(n.vector) || n.vector.length === 0)
      throw Error("`vector` must be a non-empty Array in vectorSearch");
    return await new Gn(
      e,
      t + "." + r,
      n
    ).collect();
  };
}
i(Pa, "setupActionVectorSearch");
var Gn = class {
  static {
    i(this, "VectorQueryImpl");
  }
  constructor(t, r, n) {
    qn(this, "requestId"), qn(this, "state"), this.requestId = t;
    let o = n.filter ? ar(n.filter(Cd)) : null;
    this.state = {
      type: "preparing",
      query: {
        indexName: r,
        limit: n.limit,
        vector: n.vector,
        expressions: o
      }
    };
  }
  async collect() {
    if (this.state.type === "consumed")
      throw new Error("This query is closed and can't emit any more values.");
    let t = this.state.query;
    this.state = { type: "consumed" };
    let { results: r } = await O("1.0/actions/vectorSearch", {
      requestId: this.requestId,
      version: J,
      query: t
    });
    return r;
  }
}, Ce = class extends ir {
  static {
    i(this, "ExpressionImpl");
  }
  constructor(t) {
    super(), qn(this, "inner"), this.inner = t;
  }
  serialize() {
    return this.inner;
  }
};
function ar(e) {
  return e instanceof Ce ? e.serialize() : { $literal: ne(e) };
}
i(ar, "serializeExpression");
var Cd = {
  //  Comparisons  /////////////////////////////////////////////////////////////
  eq(e, t) {
    if (typeof e != "string")
      throw new Error("The first argument to `q.eq` must be a field name.");
    return new Ce({
      $eq: [
        ar(new Ce({ $field: e })),
        ar(t)
      ]
    });
  },
  //  Logic  ///////////////////////////////////////////////////////////////////
  or(...e) {
    return new Ce({ $or: e.map(ar) });
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/authentication_impl.js
function cr(e) {
  return {
    getUserIdentity: /* @__PURE__ */ i(async () => await O("1.0/getUserIdentity", {
      requestId: e
    }), "getUserIdentity")
  };
}
i(cr, "setupAuth");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/filter_builder.js
var Rd = Object.defineProperty, Fd = /* @__PURE__ */ i((e, t, r) => t in e ? Rd(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), Ta = /* @__PURE__ */ i((e, t, r) => Fd(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), ur = class {
  static {
    i(this, "Expression");
  }
  /**
   * @internal
   */
  constructor() {
    Ta(this, "_isExpression"), Ta(this, "_value");
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/filter_builder_impl.js
var Ld = Object.defineProperty, Jd = /* @__PURE__ */ i((e, t, r) => t in e ? Ld(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), Vd = /* @__PURE__ */ i((e, t, r) => Jd(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), V = class extends ur {
  static {
    i(this, "ExpressionImpl");
  }
  constructor(t) {
    super(), Vd(this, "inner"), this.inner = t;
  }
  serialize() {
    return this.inner;
  }
};
function P(e) {
  return e instanceof V ? e.serialize() : { $literal: ne(e) };
}
i(P, "serializeExpression");
var Ua = {
  //  Comparisons  /////////////////////////////////////////////////////////////
  eq(e, t) {
    return new V({
      $eq: [P(e), P(t)]
    });
  },
  neq(e, t) {
    return new V({
      $neq: [P(e), P(t)]
    });
  },
  lt(e, t) {
    return new V({
      $lt: [P(e), P(t)]
    });
  },
  lte(e, t) {
    return new V({
      $lte: [P(e), P(t)]
    });
  },
  gt(e, t) {
    return new V({
      $gt: [P(e), P(t)]
    });
  },
  gte(e, t) {
    return new V({
      $gte: [P(e), P(t)]
    });
  },
  //  Arithmetic  //////////////////////////////////////////////////////////////
  add(e, t) {
    return new V({
      $add: [P(e), P(t)]
    });
  },
  sub(e, t) {
    return new V({
      $sub: [P(e), P(t)]
    });
  },
  mul(e, t) {
    return new V({
      $mul: [P(e), P(t)]
    });
  },
  div(e, t) {
    return new V({
      $div: [P(e), P(t)]
    });
  },
  mod(e, t) {
    return new V({
      $mod: [P(e), P(t)]
    });
  },
  neg(e) {
    return new V({ $neg: P(e) });
  },
  //  Logic  ///////////////////////////////////////////////////////////////////
  and(...e) {
    return new V({ $and: e.map(P) });
  },
  or(...e) {
    return new V({ $or: e.map(P) });
  },
  not(e) {
    return new V({ $not: P(e) });
  },
  //  Other  ///////////////////////////////////////////////////////////////////
  field(e) {
    return new V({ $field: e });
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/index_range_builder.js
var Md = Object.defineProperty, Bd = /* @__PURE__ */ i((e, t, r) => t in e ? Md(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), qd = /* @__PURE__ */ i((e, t, r) => Bd(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), sr = class {
  static {
    i(this, "IndexRange");
  }
  /**
   * @internal
   */
  constructor() {
    qd(this, "_isIndexRange");
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/index_range_builder_impl.js
var Gd = Object.defineProperty, Wd = /* @__PURE__ */ i((e, t, r) => t in e ? Gd(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), Za = /* @__PURE__ */ i((e, t, r) => Wd(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), lr = class e extends sr {
  static {
    i(this, "IndexRangeBuilderImpl");
  }
  constructor(t) {
    super(), Za(this, "rangeExpressions"), Za(this, "isConsumed"), this.rangeExpressions = t, this.isConsumed = !1;
  }
  static new() {
    return new e([]);
  }
  consume() {
    if (this.isConsumed)
      throw new Error(
        "IndexRangeBuilder has already been used! Chain your method calls like `q => q.eq(...).eq(...)`. See https://docs.convex.dev/using/indexes"
      );
    this.isConsumed = !0;
  }
  eq(t, r) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Eq",
        fieldPath: t,
        value: ne(r)
      })
    );
  }
  gt(t, r) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Gt",
        fieldPath: t,
        value: ne(r)
      })
    );
  }
  gte(t, r) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Gte",
        fieldPath: t,
        value: ne(r)
      })
    );
  }
  lt(t, r) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Lt",
        fieldPath: t,
        value: ne(r)
      })
    );
  }
  lte(t, r) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Lte",
        fieldPath: t,
        value: ne(r)
      })
    );
  }
  export() {
    return this.consume(), this.rangeExpressions;
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/search_filter_builder.js
var Kd = Object.defineProperty, Xd = /* @__PURE__ */ i((e, t, r) => t in e ? Kd(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), Hd = /* @__PURE__ */ i((e, t, r) => Xd(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), dr = class {
  static {
    i(this, "SearchFilter");
  }
  /**
   * @internal
   */
  constructor() {
    Hd(this, "_isSearchFilter");
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/search_filter_builder_impl.js
var Qd = Object.defineProperty, Yd = /* @__PURE__ */ i((e, t, r) => t in e ? Qd(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), Ea = /* @__PURE__ */ i((e, t, r) => Yd(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), fr = class e extends dr {
  static {
    i(this, "SearchFilterBuilderImpl");
  }
  constructor(t) {
    super(), Ea(this, "filters"), Ea(this, "isConsumed"), this.filters = t, this.isConsumed = !1;
  }
  static new() {
    return new e([]);
  }
  consume() {
    if (this.isConsumed)
      throw new Error(
        "SearchFilterBuilder has already been used! Chain your method calls like `q => q.search(...).eq(...)`."
      );
    this.isConsumed = !0;
  }
  search(t, r) {
    return j(t, 1, "search", "fieldName"), j(r, 2, "search", "query"), this.consume(), new e(
      this.filters.concat({
        type: "Search",
        fieldPath: t,
        value: r
      })
    );
  }
  eq(t, r) {
    return j(t, 1, "eq", "fieldName"), arguments.length !== 2 && j(r, 2, "search", "value"), this.consume(), new e(
      this.filters.concat({
        type: "Eq",
        fieldPath: t,
        value: ne(r)
      })
    );
  }
  export() {
    return this.consume(), this.filters;
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/query_impl.js
var ef = Object.defineProperty, tf = /* @__PURE__ */ i((e, t, r) => t in e ? ef(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), Wn = /* @__PURE__ */ i((e, t, r) => tf(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), Na = 256, Re = class {
  static {
    i(this, "QueryInitializerImpl");
  }
  constructor(t) {
    Wn(this, "tableName"), this.tableName = t;
  }
  withIndex(t, r) {
    j(t, 1, "withIndex", "indexName");
    let n = lr.new();
    return r !== void 0 && (n = r(n)), new Se({
      source: {
        type: "IndexRange",
        indexName: this.tableName + "." + t,
        range: n.export(),
        order: null
      },
      operators: []
    });
  }
  withSearchIndex(t, r) {
    j(t, 1, "withSearchIndex", "indexName"), j(r, 2, "withSearchIndex", "searchFilter");
    let n = fr.new();
    return new Se({
      source: {
        type: "Search",
        indexName: this.tableName + "." + t,
        filters: r(n).export()
      },
      operators: []
    });
  }
  fullTableScan() {
    return new Se({
      source: {
        type: "FullTableScan",
        tableName: this.tableName,
        order: null
      },
      operators: []
    });
  }
  order(t) {
    return this.fullTableScan().order(t);
  }
  // This is internal API and should not be exposed to developers yet.
  async count() {
    let t = await O("1.0/count", {
      table: this.tableName
    });
    return R(t);
  }
  filter(t) {
    return this.fullTableScan().filter(t);
  }
  limit(t) {
    return this.fullTableScan().limit(t);
  }
  collect() {
    return this.fullTableScan().collect();
  }
  take(t) {
    return this.fullTableScan().take(t);
  }
  paginate(t) {
    return this.fullTableScan().paginate(t);
  }
  first() {
    return this.fullTableScan().first();
  }
  unique() {
    return this.fullTableScan().unique();
  }
  [Symbol.asyncIterator]() {
    return this.fullTableScan()[Symbol.asyncIterator]();
  }
};
function Da(e) {
  throw new Error(
    e === "consumed" ? "This query is closed and can't emit any more values." : "This query has been chained with another operator and can't be reused."
  );
}
i(Da, "throwClosedError");
var Se = class e {
  static {
    i(this, "QueryImpl");
  }
  constructor(t) {
    Wn(this, "state"), Wn(this, "tableNameForErrorMessages"), this.state = { type: "preparing", query: t }, t.source.type === "FullTableScan" ? this.tableNameForErrorMessages = t.source.tableName : this.tableNameForErrorMessages = t.source.indexName.split(".")[0];
  }
  takeQuery() {
    if (this.state.type !== "preparing")
      throw new Error(
        "A query can only be chained once and can't be chained after iteration begins."
      );
    let t = this.state.query;
    return this.state = { type: "closed" }, t;
  }
  startQuery() {
    if (this.state.type === "executing")
      throw new Error("Iteration can only begin on a query once.");
    (this.state.type === "closed" || this.state.type === "consumed") && Da(this.state.type);
    let t = this.state.query, { queryId: r } = lt("1.0/queryStream", { query: t, version: J });
    return this.state = { type: "executing", queryId: r }, r;
  }
  closeQuery() {
    if (this.state.type === "executing") {
      let t = this.state.queryId;
      lt("1.0/queryCleanup", { queryId: t });
    }
    this.state = { type: "consumed" };
  }
  order(t) {
    j(t, 1, "order", "order");
    let r = this.takeQuery();
    if (r.source.type === "Search")
      throw new Error(
        "Search queries must always be in relevance order. Can not set order manually."
      );
    if (r.source.order !== null)
      throw new Error("Queries may only specify order at most once");
    return r.source.order = t, new e(r);
  }
  filter(t) {
    j(t, 1, "filter", "predicate");
    let r = this.takeQuery();
    if (r.operators.length >= Na)
      throw new Error(
        `Can't construct query with more than ${Na} operators`
      );
    return r.operators.push({
      filter: P(t(Ua))
    }), new e(r);
  }
  limit(t) {
    j(t, 1, "limit", "n");
    let r = this.takeQuery();
    return r.operators.push({ limit: t }), new e(r);
  }
  [Symbol.asyncIterator]() {
    return this.startQuery(), this;
  }
  async next() {
    (this.state.type === "closed" || this.state.type === "consumed") && Da(this.state.type);
    let t = this.state.type === "preparing" ? this.startQuery() : this.state.queryId, { value: r, done: n } = await O("1.0/queryStreamNext", {
      queryId: t
    });
    return n && this.closeQuery(), { value: R(r), done: n };
  }
  return() {
    return this.closeQuery(), Promise.resolve({ done: !0, value: void 0 });
  }
  async paginate(t) {
    if (j(t, 1, "paginate", "options"), typeof t?.numItems != "number" || t.numItems < 0)
      throw new Error(
        `\`options.numItems\` must be a positive number. Received \`${t?.numItems}\`.`
      );
    let r = this.takeQuery(), n = t.numItems, o = t.cursor, a = t?.endCursor ?? null, c = t.maximumRowsRead ?? null, { page: u, isDone: s, continueCursor: d, splitCursor: f, pageStatus: g } = await O("1.0/queryPage", {
      query: r,
      cursor: o,
      endCursor: a,
      pageSize: n,
      maximumRowsRead: c,
      maximumBytesRead: t.maximumBytesRead,
      version: J
    });
    return {
      page: u.map(($) => R($)),
      isDone: s,
      continueCursor: d,
      splitCursor: f,
      pageStatus: g
    };
  }
  async collect() {
    let t = [];
    for await (let r of this)
      t.push(r);
    return t;
  }
  async take(t) {
    return j(t, 1, "take", "n"), Oa(t, 1, "take", "n"), this.limit(t).collect();
  }
  async first() {
    let t = await this.take(1);
    return t.length === 0 ? null : t[0];
  }
  async unique() {
    let t = await this.take(2);
    if (t.length === 0)
      return null;
    if (t.length === 2)
      throw new Error(`unique() query returned more than one result from table ${this.tableNameForErrorMessages}:
 [${t[0]._id}, ${t[1]._id}, ...]`);
    return t[0];
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/database_impl.js
async function Kn(e, t, r) {
  if (j(t, 1, "get", "id"), typeof t != "string")
    throw new Error(
      `Invalid argument \`id\` for \`db.get\`, expected string but got '${typeof t}': ${t}`
    );
  let n = {
    id: D(t),
    isSystem: r,
    version: J,
    table: e
  }, o = await O("1.0/get", n);
  return R(o);
}
i(Kn, "get");
function eo() {
  let e = /* @__PURE__ */ i((o = !1) => ({
    get: /* @__PURE__ */ i(async (a, c) => c !== void 0 ? await Kn(a, c, o) : await Kn(void 0, a, o), "get"),
    query: /* @__PURE__ */ i((a) => new ft(a, o).query(), "query"),
    normalizeId: /* @__PURE__ */ i((a, c) => {
      j(a, 1, "normalizeId", "tableName"), j(c, 2, "normalizeId", "id");
      let u = a.startsWith("_");
      if (u !== o)
        throw new Error(
          `${u ? "System" : "User"} tables can only be accessed from db.${o ? "" : "system."}normalizeId().`
        );
      let s = lt("1.0/db/normalizeId", {
        table: a,
        idString: c
      });
      return R(s).id;
    }, "normalizeId"),
    // We set the system reader on the next line
    system: null,
    table: /* @__PURE__ */ i((a) => new ft(a, o), "table")
  }), "reader"), { system: t, ...r } = e(!0), n = e();
  return n.system = r, n;
}
i(eo, "setupReader");
async function Aa(e, t) {
  if (e.startsWith("_"))
    throw new Error("System tables (prefixed with `_`) are read-only.");
  j(e, 1, "insert", "table"), j(t, 2, "insert", "value");
  let r = await O("1.0/insert", {
    table: e,
    value: D(t)
  });
  return R(r)._id;
}
i(Aa, "insert");
async function Xn(e, t, r) {
  j(t, 1, "patch", "id"), j(r, 2, "patch", "value"), await O("1.0/shallowMerge", {
    id: D(t),
    value: _a(r),
    table: e
  });
}
i(Xn, "patch");
async function Hn(e, t, r) {
  j(t, 1, "replace", "id"), j(r, 2, "replace", "value"), await O("1.0/replace", {
    id: D(t),
    value: D(r),
    table: e
  });
}
i(Hn, "replace");
async function Qn(e, t) {
  j(t, 1, "delete", "id"), await O("1.0/remove", {
    id: D(t),
    table: e
  });
}
i(Qn, "delete_");
function Ca() {
  let e = eo();
  return {
    get: e.get,
    query: e.query,
    normalizeId: e.normalizeId,
    system: e.system,
    insert: /* @__PURE__ */ i(async (t, r) => await Aa(t, r), "insert"),
    patch: /* @__PURE__ */ i(async (t, r, n) => n !== void 0 ? await Xn(t, r, n) : await Xn(void 0, t, r), "patch"),
    replace: /* @__PURE__ */ i(async (t, r, n) => n !== void 0 ? await Hn(t, r, n) : await Hn(void 0, t, r), "replace"),
    delete: /* @__PURE__ */ i(async (t, r) => r !== void 0 ? await Qn(t, r) : await Qn(void 0, t), "delete"),
    table: /* @__PURE__ */ i((t) => new Yn(t, !1), "table")
  };
}
i(Ca, "setupWriter");
var ft = class {
  static {
    i(this, "TableReader");
  }
  constructor(t, r) {
    this.tableName = t, this.isSystem = r;
  }
  async get(t) {
    return Kn(this.tableName, t, this.isSystem);
  }
  query() {
    let t = this.tableName.startsWith("_");
    if (t !== this.isSystem)
      throw new Error(
        `${t ? "System" : "User"} tables can only be accessed from db.${this.isSystem ? "" : "system."}query().`
      );
    return new Re(this.tableName);
  }
}, Yn = class extends ft {
  static {
    i(this, "TableWriter");
  }
  async insert(t) {
    return Aa(this.tableName, t);
  }
  async patch(t, r) {
    return Xn(this.tableName, t, r);
  }
  async replace(t, r) {
    return Hn(this.tableName, t, r);
  }
  async delete(t) {
    return Qn(this.tableName, t);
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/scheduler_impl.js
function Ra() {
  return {
    runAfter: /* @__PURE__ */ i(async (e, t, r) => {
      let n = La(e, t, r);
      return await O("1.0/schedule", n);
    }, "runAfter"),
    runAt: /* @__PURE__ */ i(async (e, t, r) => {
      let n = Ja(
        e,
        t,
        r
      );
      return await O("1.0/schedule", n);
    }, "runAt"),
    cancel: /* @__PURE__ */ i(async (e) => {
      j(e, 1, "cancel", "id");
      let t = { id: D(e) };
      await O("1.0/cancel_job", t);
    }, "cancel")
  };
}
i(Ra, "setupMutationScheduler");
function Fa(e) {
  return {
    runAfter: /* @__PURE__ */ i(async (t, r, n) => {
      let o = {
        requestId: e,
        ...La(t, r, n)
      };
      return await O("1.0/actions/schedule", o);
    }, "runAfter"),
    runAt: /* @__PURE__ */ i(async (t, r, n) => {
      let o = {
        requestId: e,
        ...Ja(t, r, n)
      };
      return await O("1.0/actions/schedule", o);
    }, "runAt"),
    cancel: /* @__PURE__ */ i(async (t) => {
      j(t, 1, "cancel", "id");
      let r = {
        requestId: e,
        id: D(t)
      };
      return await O("1.0/actions/cancel_job", r);
    }, "cancel")
  };
}
i(Fa, "setupActionScheduler");
function La(e, t, r) {
  if (typeof e != "number")
    throw new Error("`delayMs` must be a number");
  if (!isFinite(e))
    throw new Error("`delayMs` must be a finite number");
  if (e < 0)
    throw new Error("`delayMs` must be non-negative");
  let n = ge(r), o = ae(t), a = (Date.now() + e) / 1e3;
  return {
    ...o,
    ts: a,
    args: D(n),
    version: J
  };
}
i(La, "runAfterSyscallArgs");
function Ja(e, t, r) {
  let n;
  if (e instanceof Date)
    n = e.valueOf() / 1e3;
  else if (typeof e == "number")
    n = e / 1e3;
  else
    throw new Error("The invoke time must a Date or a timestamp");
  let o = ae(t), a = ge(r);
  return {
    ...o,
    ts: n,
    args: D(a),
    version: J
  };
}
i(Ja, "runAtSyscallArgs");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/storage_impl.js
function to(e) {
  return {
    getUrl: /* @__PURE__ */ i(async (t) => (j(t, 1, "getUrl", "storageId"), await O("1.0/storageGetUrl", {
      requestId: e,
      version: J,
      storageId: t
    })), "getUrl"),
    getMetadata: /* @__PURE__ */ i(async (t) => await O("1.0/storageGetMetadata", {
      requestId: e,
      version: J,
      storageId: t
    }), "getMetadata")
  };
}
i(to, "setupStorageReader");
function ro(e) {
  let t = to(e);
  return {
    generateUploadUrl: /* @__PURE__ */ i(async () => await O("1.0/storageGenerateUploadUrl", {
      requestId: e,
      version: J
    }), "generateUploadUrl"),
    delete: /* @__PURE__ */ i(async (r) => {
      await O("1.0/storageDelete", {
        requestId: e,
        version: J,
        storageId: r
      });
    }, "delete"),
    getUrl: t.getUrl,
    getMetadata: t.getMetadata
  };
}
i(ro, "setupStorageWriter");
function Va(e) {
  return {
    ...ro(e),
    store: /* @__PURE__ */ i(async (r, n) => await or("storage/storeBlob", {
      requestId: e,
      version: J,
      blob: r,
      options: n
    }), "store"),
    get: /* @__PURE__ */ i(async (r) => await or("storage/getBlob", {
      requestId: e,
      version: J,
      storageId: r
    }), "get")
  };
}
i(Va, "setupStorageActionWriter");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/registration_impl.js
async function Ma(e, t) {
  let n = R(JSON.parse(t)), o = {
    db: Ca(),
    auth: cr(""),
    storage: ro(""),
    scheduler: Ra(),
    runQuery: /* @__PURE__ */ i((c, u) => no("query", c, u), "runQuery"),
    runMutation: /* @__PURE__ */ i((c, u) => no("mutation", c, u), "runMutation")
  }, a = await oo(e, o, n);
  return Ba(a), JSON.stringify(D(a === void 0 ? null : a));
}
i(Ma, "invokeMutation");
function Ba(e) {
  if (e instanceof Re || e instanceof Se)
    throw new Error(
      "Return value is a Query. Results must be retrieved with `.collect()`, `.take(n), `.unique()`, or `.first()`."
    );
}
i(Ba, "validateReturnValue");
async function oo(e, t, r) {
  let n;
  try {
    n = await Promise.resolve(e(t, ...r));
  } catch (o) {
    throw rf(o);
  }
  return n;
}
i(oo, "invokeFunction");
function Fe(e, t) {
  return (r, n) => (globalThis.console.warn(
    `Convex functions should not directly call other Convex functions. Consider calling a helper function instead. e.g. \`export const foo = ${e}(...); await foo(ctx);\` is not supported. See https://docs.convex.dev/production/best-practices/#use-helper-functions-to-write-shared-code`
  ), t(r, n));
}
i(Fe, "dontCallDirectly");
function rf(e) {
  if (typeof e == "object" && e !== null && Symbol.for("ConvexError") in e) {
    let t = e;
    return t.data = JSON.stringify(
      D(t.data === void 0 ? null : t.data)
    ), t.ConvexErrorSymbol = Symbol.for("ConvexError"), t;
  } else
    return e;
}
i(rf, "serializeConvexErrorData");
function Le() {
  if (typeof window > "u" || window.__convexAllowFunctionsInBrowser)
    return;
  (Object.getOwnPropertyDescriptor(globalThis, "window")?.get?.toString().includes("[native code]") ?? !1) && console.error(
    "Convex functions should not be imported in the browser. This will throw an error in future versions of `convex`. If this is a false negative, please report it to Convex support."
  );
}
i(Le, "assertNotBrowser");
function qa(e, t) {
  if (t === void 0)
    throw new Error(
      `A validator is undefined for field "${e}". This is often caused by circular imports. See https://docs.convex.dev/error#undefined-validator for details.`
    );
  return t;
}
i(qa, "strictReplacer");
function Je(e) {
  return () => {
    let t = m.any();
    return typeof e == "object" && e.args !== void 0 && (t = De(e.args)), JSON.stringify(t.json, qa);
  };
}
i(Je, "exportArgs");
function Ve(e) {
  return () => {
    let t;
    return typeof e == "object" && e.returns !== void 0 && (t = De(e.returns)), JSON.stringify(t ? t.json : null, qa);
  };
}
i(Ve, "exportReturns");
var io = /* @__PURE__ */ i(((e) => {
  let t = typeof e == "function" ? e : e.handler, r = Fe("mutation", t);
  return Le(), r.isMutation = !0, r.isPublic = !0, r.invokeMutation = (n) => Ma(t, n), r.exportArgs = Je(e), r.exportReturns = Ve(e), r._handler = t, r;
}), "mutationGeneric"), ao = /* @__PURE__ */ i(((e) => {
  let t = typeof e == "function" ? e : e.handler, r = Fe(
    "internalMutation",
    t
  );
  return Le(), r.isMutation = !0, r.isInternal = !0, r.invokeMutation = (n) => Ma(t, n), r.exportArgs = Je(e), r.exportReturns = Ve(e), r._handler = t, r;
}), "internalMutationGeneric");
async function Ga(e, t) {
  let n = R(JSON.parse(t)), o = {
    db: eo(),
    auth: cr(""),
    storage: to(""),
    runQuery: /* @__PURE__ */ i((c, u) => no("query", c, u), "runQuery")
  }, a = await oo(e, o, n);
  return Ba(a), JSON.stringify(D(a === void 0 ? null : a));
}
i(Ga, "invokeQuery");
var co = /* @__PURE__ */ i(((e) => {
  let t = typeof e == "function" ? e : e.handler, r = Fe("query", t);
  return Le(), r.isQuery = !0, r.isPublic = !0, r.invokeQuery = (n) => Ga(t, n), r.exportArgs = Je(e), r.exportReturns = Ve(e), r._handler = t, r;
}), "queryGeneric"), uo = /* @__PURE__ */ i(((e) => {
  let t = typeof e == "function" ? e : e.handler, r = Fe("internalQuery", t);
  return Le(), r.isQuery = !0, r.isInternal = !0, r.invokeQuery = (n) => Ga(t, n), r.exportArgs = Je(e), r.exportReturns = Ve(e), r._handler = t, r;
}), "internalQueryGeneric");
async function Wa(e, t, r) {
  let n = R(JSON.parse(r)), a = {
    ...Sa(t),
    auth: cr(t),
    scheduler: Fa(t),
    storage: Va(t),
    vectorSearch: Pa(t)
  }, c = await oo(e, a, n);
  return JSON.stringify(D(c === void 0 ? null : c));
}
i(Wa, "invokeAction");
var so = /* @__PURE__ */ i(((e) => {
  let t = typeof e == "function" ? e : e.handler, r = Fe("action", t);
  return Le(), r.isAction = !0, r.isPublic = !0, r.invokeAction = (n, o) => Wa(t, n, o), r.exportArgs = Je(e), r.exportReturns = Ve(e), r._handler = t, r;
}), "actionGeneric"), lo = /* @__PURE__ */ i(((e) => {
  let t = typeof e == "function" ? e : e.handler, r = Fe("internalAction", t);
  return Le(), r.isAction = !0, r.isInternal = !0, r.invokeAction = (n, o) => Wa(t, n, o), r.exportArgs = Je(e), r.exportReturns = Ve(e), r._handler = t, r;
}), "internalActionGeneric");
async function no(e, t, r) {
  let n = ge(r), o = {
    udfType: e,
    args: D(n),
    ...ae(t)
  }, a = await O("1.0/runUdf", o);
  return R(a);
}
i(no, "runUdf");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/pagination.js
var sv = m.object({
  numItems: m.number(),
  cursor: m.union(m.string(), m.null()),
  endCursor: m.optional(m.union(m.string(), m.null())),
  id: m.optional(m.number()),
  maximumRowsRead: m.optional(m.number()),
  maximumBytesRead: m.optional(m.number())
});

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/api.js
function Ka(e = []) {
  let t = {
    get(r, n) {
      if (typeof n == "string") {
        let o = [...e, n];
        return Ka(o);
      } else if (n === dt) {
        if (e.length < 2) {
          let c = ["api", ...e].join(".");
          throw new Error(
            `API path is expected to be of the form \`api.moduleName.functionName\`. Found: \`${c}\``
          );
        }
        let o = e.slice(0, -1).join("/"), a = e[e.length - 1];
        return a === "default" ? o : o + ":" + a;
      } else return n === Symbol.toStringTag ? "FunctionReference" : void 0;
    }
  };
  return new Proxy({}, t);
}
i(Ka, "createApi");
var nf = Ka();

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/schema.js
var af = Object.defineProperty, cf = /* @__PURE__ */ i((e, t, r) => t in e ? af(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), se = /* @__PURE__ */ i((e, t, r) => cf(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), mr = class {
  static {
    i(this, "TableDefinition");
  }
  /**
   * @internal
   */
  constructor(t) {
    se(this, "indexes"), se(this, "stagedDbIndexes"), se(this, "searchIndexes"), se(this, "stagedSearchIndexes"), se(this, "vectorIndexes"), se(this, "stagedVectorIndexes"), se(this, "validator"), this.indexes = [], this.stagedDbIndexes = [], this.searchIndexes = [], this.stagedSearchIndexes = [], this.vectorIndexes = [], this.stagedVectorIndexes = [], this.validator = t;
  }
  /**
   * This API is experimental: it may change or disappear.
   *
   * Returns indexes defined on this table.
   * Intended for the advanced use cases of dynamically deciding which index to use for a query.
   * If you think you need this, please chime in on ths issue in the Convex JS GitHub repo.
   * https://github.com/get-convex/convex-js/issues/49
   */
  " indexes"() {
    return this.indexes;
  }
  index(t, r) {
    return Array.isArray(r) ? this.indexes.push({
      indexDescriptor: t,
      fields: r
    }) : r.staged ? this.stagedDbIndexes.push({
      indexDescriptor: t,
      fields: r.fields
    }) : this.indexes.push({
      indexDescriptor: t,
      fields: r.fields
    }), this;
  }
  searchIndex(t, r) {
    return r.staged ? this.stagedSearchIndexes.push({
      indexDescriptor: t,
      searchField: r.searchField,
      filterFields: r.filterFields || []
    }) : this.searchIndexes.push({
      indexDescriptor: t,
      searchField: r.searchField,
      filterFields: r.filterFields || []
    }), this;
  }
  vectorIndex(t, r) {
    return r.staged ? this.stagedVectorIndexes.push({
      indexDescriptor: t,
      vectorField: r.vectorField,
      dimensions: r.dimensions,
      filterFields: r.filterFields || []
    }) : this.vectorIndexes.push({
      indexDescriptor: t,
      vectorField: r.vectorField,
      dimensions: r.dimensions,
      filterFields: r.filterFields || []
    }), this;
  }
  /**
   * Work around for https://github.com/microsoft/TypeScript/issues/57035
   */
  self() {
    return this;
  }
  /**
   * Export the contents of this definition.
   *
   * This is called internally by the Convex framework.
   * @internal
   */
  export() {
    let t = this.validator.json;
    if (typeof t != "object")
      throw new Error(
        "Invalid validator: please make sure that the parameter of `defineTable` is valid (see https://docs.convex.dev/database/schemas)"
      );
    return {
      indexes: this.indexes,
      stagedDbIndexes: this.stagedDbIndexes,
      searchIndexes: this.searchIndexes,
      stagedSearchIndexes: this.stagedSearchIndexes,
      vectorIndexes: this.vectorIndexes,
      stagedVectorIndexes: this.stagedVectorIndexes,
      documentType: t
    };
  }
};
function fo(e) {
  return Vn(e) ? new mr(e) : new mr(m.object(e));
}
i(fo, "defineTable");
var mo = class {
  static {
    i(this, "SchemaDefinition");
  }
  /**
   * @internal
   */
  constructor(t, r) {
    se(this, "tables"), se(this, "strictTableNameTypes"), se(this, "schemaValidation"), this.tables = t, this.schemaValidation = r?.schemaValidation === void 0 ? !0 : r.schemaValidation;
  }
  /**
   * Export the contents of this definition.
   *
   * This is called internally by the Convex framework.
   * @internal
   */
  export() {
    return JSON.stringify({
      tables: Object.entries(this.tables).map(([t, r]) => {
        let {
          indexes: n,
          stagedDbIndexes: o,
          searchIndexes: a,
          stagedSearchIndexes: c,
          vectorIndexes: u,
          stagedVectorIndexes: s,
          documentType: d
        } = r.export();
        return {
          tableName: t,
          indexes: n,
          stagedDbIndexes: o,
          searchIndexes: a,
          stagedSearchIndexes: c,
          vectorIndexes: u,
          stagedVectorIndexes: s,
          documentType: d
        };
      }),
      schemaValidation: this.schemaValidation
    });
  }
};
function Xa(e, t) {
  return new mo(e, t);
}
i(Xa, "defineSchema");
var Zv = Xa({
  _scheduled_functions: fo({
    name: m.string(),
    args: m.array(m.any()),
    scheduledTime: m.float64(),
    completedTime: m.optional(m.float64()),
    state: m.union(
      m.object({ kind: m.literal("pending") }),
      m.object({ kind: m.literal("inProgress") }),
      m.object({ kind: m.literal("success") }),
      m.object({ kind: m.literal("failed"), error: m.string() }),
      m.object({ kind: m.literal("canceled") })
    )
  }),
  _storage: fo({
    sha256: m.string(),
    size: m.float64(),
    contentType: m.optional(m.string())
  })
});

// memory/profile.mjs
var je = class {
  static {
    i(this, "SecretText");
  }
  constructor(t) {
    this.value = t;
  }
  toWire() {
    return this.value;
  }
}, po = {
  seq: 1,
  at: 17e11,
  secret: "capacity",
  payload: "tiny"
};
function Ha(e) {
  let t = e.kind === "native", r = e.kind === "full" || e.kind === "mini", n = t ? e.v : e.s;
  return /* @__PURE__ */ i(function({ count: a, width: c, profile: u, entries: s = 0 }) {
    if (!Number.isInteger(a) || a < 0 || !Number.isInteger(c) || c < 1 || !Number.isInteger(s) || s < 0 || !["fields-only", "codec-rich"].includes(u))
      throw new Error("Invalid graph fixture arguments");
    let d = {
      schemaConstructors: 0,
      fields: 0,
      codecSites: 0,
      allocatedCodecs: 0
    }, f = /* @__PURE__ */ i((k, ...S) => (d.schemaConstructors++, n[k](...S)), "make"), g = /* @__PURE__ */ i((k) => (d.fields += Object.keys(k).length, f("object", k)), "object"), $ = /* @__PURE__ */ i(() => (d.codecSites++, t ? f("number") : (d.allocatedCodecs++, f("codec", f("number"), f("date"), {
      decode: /* @__PURE__ */ i((k) => new Date(k), "decode"),
      encode: /* @__PURE__ */ i((k) => k.getTime(), "encode")
    }))), "date"), h = /* @__PURE__ */ i(() => (d.codecSites++, t ? f("string") : (d.allocatedCodecs++, f("codec", f("string"), f("instanceof", je), {
      decode: /* @__PURE__ */ i((k) => new je(k), "decode"),
      encode: /* @__PURE__ */ i((k) => k.toWire(), "encode")
    }))), "secret"), T = /* @__PURE__ */ i((k) => {
      if (u === "fields-only")
        switch (k % 4) {
          case 0:
            return f("string");
          case 1:
            return f("number");
          case 2:
            return f("boolean");
          case 3:
            return f("optional", f("string"));
        }
      switch (k % 4) {
        case 0:
          return $();
        case 1:
          return h();
        case 2:
          return g({ at: $(), tag: f("optional", f("string")) });
        case 3:
          return f(
            "array",
            t ? f("union", f("string"), f("number")) : f("union", [f("string"), f("number")])
          );
      }
    }, "field"), z = {}, F = {}, ie = /* @__PURE__ */ i((k, S) => {
      r ? (d.fields += Object.keys(S).length, z[k] = e.defineZodModel(k, S, e.schemaHelpers ? void 0 : { schemaHelpers: !1 })) : (F[k] = g(S), z[k] = t ? e.defineTable(F[k]) : F[k]);
    }, "add");
    ie("benchmarkRows", {
      seq: f("number"),
      at: $(),
      secret: h(),
      payload: f("string")
    });
    for (let k = 0; k < a; k++) {
      let S = {};
      for (let M = 0; M < c; M++) S[`f${M}`] = T(M);
      ie(`unused${k}`, S);
    }
    let H = r ? e.defineZodSchema(z) : t ? e.defineSchema(z) : null;
    if (r) for (let k of Object.keys(z)) F[k] = H.__zodTableMap[k].insert;
    let L = Object.keys(z), C = {};
    for (let k = 0; k < s; k++) {
      let S = L[k % L.length], M = r ? H.__zodTableMap[S].doc : F[S], dd = g({
        id: f("string"),
        label: f("optional", f("string"))
      }), fd = t ? f("union", M, f("null")) : f("nullable", M);
      C[`unused/fn${k}`] = { args: dd, returns: fd };
    }
    let q = r ? e.initZodvex(
      H,
      e.server,
      s ? { registry: /* @__PURE__ */ i(() => C, "registry") } : void 0
    ) : e.makeBuilders();
    return {
      kind: e.kind,
      options: { count: a, width: c, profile: u, entries: s },
      models: z,
      sourceSchemas: F,
      schema: H,
      registry: C,
      builders: q,
      manifest: {
        backgroundModels: a,
        totalModels: a + 1,
        backgroundTopLevelFields: a * c,
        fixedProbeFields: 4,
        profile: u,
        registryEntries: s,
        ...d,
        counterScope: "Explicit fixture constructor calls and source fields/codecs; excludes library-generated helper schemas and runtime heap objects."
      },
      operation() {
        let k = { ...po }, S = t ? {
          ...k,
          at: new Date(k.at),
          secret: new je(k.secret)
        } : e.s.parse(F.benchmarkRows, k);
        if (!(S.at instanceof Date) || !(S.secret instanceof je))
          throw new Error("Codec decode failed");
        S.at = new Date(S.at.getTime() + 1e3), S.secret = new je(S.secret.toWire().toUpperCase());
        let M = t ? {
          ...S,
          at: S.at.getTime(),
          secret: S.secret.toWire()
        } : e.s.encode(F.benchmarkRows, S);
        if (JSON.stringify(M) !== JSON.stringify({
          ...po,
          at: po.at + 1e3,
          secret: "CAPACITY"
        }))
          throw new Error("Codec round trip mismatch");
        return M;
      },
      // Call after the operation and after GC measurements. The retained graph
      // includes every model, table schema, registry entry and builder closure.
      checksum() {
        let k = 0;
        for (let [S, M] of Object.entries(z)) {
          if (!M || !F[S]) throw new Error("Missing model");
          if (k += S.length, r && H.__zodTableMap[S].insert !== F[S])
            throw new Error("Lost table-map alias");
        }
        for (let [S, M] of Object.entries(C)) {
          if (!M.args || !M.returns)
            throw new Error("Missing registry schema");
          k += S.length;
        }
        if (Object.keys(q).length === 0)
          throw new Error("Lost builders");
        return k;
      }
    };
  }, "buildGraph");
}
i(Ha, "createGraphFactory");

// versions/4.3.6/node_modules/zod/v4/core/core.js
var uf = Object.freeze({
  status: "aborted"
});
// @__NO_SIDE_EFFECTS__
function l(e, t, r) {
  function n(u, s) {
    if (u._zod || Object.defineProperty(u, "_zod", {
      value: {
        def: s,
        constr: c,
        traits: /* @__PURE__ */ new Set()
      },
      enumerable: !1
    }), u._zod.traits.has(e))
      return;
    u._zod.traits.add(e), t(u, s);
    let d = c.prototype, f = Object.keys(d);
    for (let g = 0; g < f.length; g++) {
      let $ = f[g];
      $ in u || (u[$] = d[$].bind(u));
    }
  }
  i(n, "init");
  let o = r?.Parent ?? Object;
  class a extends o {
    static {
      i(this, "Definition");
    }
  }
  Object.defineProperty(a, "name", { value: e });
  function c(u) {
    var s;
    let d = r?.Parent ? new a() : this;
    n(d, u), (s = d._zod).deferred ?? (s.deferred = []);
    for (let f of d._zod.deferred)
      f();
    return d;
  }
  return i(c, "_"), Object.defineProperty(c, "init", { value: n }), Object.defineProperty(c, Symbol.hasInstance, {
    value: /* @__PURE__ */ i((u) => r?.Parent && u instanceof r.Parent ? !0 : u?._zod?.traits?.has(e), "value")
  }), Object.defineProperty(c, "name", { value: e }), c;
}
i(l, "$constructor");
var Qa = Symbol("zod_brand"), le = class extends Error {
  static {
    i(this, "$ZodAsyncError");
  }
  constructor() {
    super("Encountered Promise during synchronous parse. Use .parseAsync() instead.");
  }
}, Oe = class extends Error {
  static {
    i(this, "$ZodEncodeError");
  }
  constructor(t) {
    super(`Encountered unidirectional transform during encode: ${t}`), this.name = "ZodEncodeError";
  }
}, pr = {};
function B(e) {
  return e && Object.assign(pr, e), pr;
}
i(B, "config");

// versions/4.3.6/node_modules/zod/v4/core/util.js
var p = {};
nt(p, {
  BIGINT_FORMAT_RANGES: () => ko,
  Class: () => ho,
  NUMBER_FORMAT_RANGES: () => _o,
  aborted: () => ye,
  allowsEval: () => yo,
  assert: () => mf,
  assertEqual: () => sf,
  assertIs: () => df,
  assertNever: () => ff,
  assertNotEqual: () => lf,
  assignProp: () => ve,
  base64ToUint8Array: () => tc,
  base64urlToUint8Array: () => Pf,
  cached: () => Be,
  captureStackTrace: () => hr,
  cleanEnum: () => Of,
  cleanRegex: () => gt,
  clone: () => Q,
  cloneDef: () => gf,
  createTransparentProxy: () => xf,
  defineLazy: () => I,
  esc: () => gr,
  escapeRegex: () => oe,
  extend: () => wf,
  finalizeIssue: () => K,
  floatSafeRemainder: () => vo,
  getElementAtPath: () => hf,
  getEnumValues: () => pt,
  getLengthableOrigin: () => $t,
  getParsedType: () => bf,
  getSizableOrigin: () => vt,
  hexToUint8Array: () => Uf,
  isObject: () => Pe,
  isPlainObject: () => $e,
  issue: () => qe,
  joinValues: () => y,
  jsonStringifyReplacer: () => Me,
  merge: () => If,
  mergeDefs: () => fe,
  normalizeParams: () => v,
  nullish: () => he,
  numKeys: () => yf,
  objectClone: () => pf,
  omit: () => kf,
  optionalKeys: () => xo,
  parsedType: () => x,
  partial: () => Sf,
  pick: () => _f,
  prefixIssues: () => Y,
  primitiveTypes: () => bo,
  promiseAllObject: () => vf,
  propertyKeyTypes: () => ht,
  randomString: () => $f,
  required: () => jf,
  safeExtend: () => zf,
  shallowClone: () => ec,
  slugify: () => $o,
  stringifyPrimitive: () => b,
  uint8ArrayToBase64: () => rc,
  uint8ArrayToBase64url: () => Tf,
  uint8ArrayToHex: () => Zf,
  unwrapMessage: () => mt
});
function sf(e) {
  return e;
}
i(sf, "assertEqual");
function lf(e) {
  return e;
}
i(lf, "assertNotEqual");
function df(e) {
}
i(df, "assertIs");
function ff(e) {
  throw new Error("Unexpected value in exhaustive check");
}
i(ff, "assertNever");
function mf(e) {
}
i(mf, "assert");
function pt(e) {
  let t = Object.values(e).filter((n) => typeof n == "number");
  return Object.entries(e).filter(([n, o]) => t.indexOf(+n) === -1).map(([n, o]) => o);
}
i(pt, "getEnumValues");
function y(e, t = "|") {
  return e.map((r) => b(r)).join(t);
}
i(y, "joinValues");
function Me(e, t) {
  return typeof t == "bigint" ? t.toString() : t;
}
i(Me, "jsonStringifyReplacer");
function Be(e) {
  return {
    get value() {
      {
        let r = e();
        return Object.defineProperty(this, "value", { value: r }), r;
      }
      throw new Error("cached value already set");
    }
  };
}
i(Be, "cached");
function he(e) {
  return e == null;
}
i(he, "nullish");
function gt(e) {
  let t = e.startsWith("^") ? 1 : 0, r = e.endsWith("$") ? e.length - 1 : e.length;
  return e.slice(t, r);
}
i(gt, "cleanRegex");
function vo(e, t) {
  let r = (e.toString().split(".")[1] || "").length, n = t.toString(), o = (n.split(".")[1] || "").length;
  if (o === 0 && /\d?e-\d?/.test(n)) {
    let s = n.match(/\d?e-(\d?)/);
    s?.[1] && (o = Number.parseInt(s[1]));
  }
  let a = r > o ? r : o, c = Number.parseInt(e.toFixed(a).replace(".", "")), u = Number.parseInt(t.toFixed(a).replace(".", ""));
  return c % u / 10 ** a;
}
i(vo, "floatSafeRemainder");
var Ya = Symbol("evaluating");
function I(e, t, r) {
  let n;
  Object.defineProperty(e, t, {
    get() {
      if (n !== Ya)
        return n === void 0 && (n = Ya, n = r()), n;
    },
    set(o) {
      Object.defineProperty(e, t, {
        value: o
        // configurable: true,
      });
    },
    configurable: !0
  });
}
i(I, "defineLazy");
function pf(e) {
  return Object.create(Object.getPrototypeOf(e), Object.getOwnPropertyDescriptors(e));
}
i(pf, "objectClone");
function ve(e, t, r) {
  Object.defineProperty(e, t, {
    value: r,
    writable: !0,
    enumerable: !0,
    configurable: !0
  });
}
i(ve, "assignProp");
function fe(...e) {
  let t = {};
  for (let r of e) {
    let n = Object.getOwnPropertyDescriptors(r);
    Object.assign(t, n);
  }
  return Object.defineProperties({}, t);
}
i(fe, "mergeDefs");
function gf(e) {
  return fe(e._zod.def);
}
i(gf, "cloneDef");
function hf(e, t) {
  return t ? t.reduce((r, n) => r?.[n], e) : e;
}
i(hf, "getElementAtPath");
function vf(e) {
  let t = Object.keys(e), r = t.map((n) => e[n]);
  return Promise.all(r).then((n) => {
    let o = {};
    for (let a = 0; a < t.length; a++)
      o[t[a]] = n[a];
    return o;
  });
}
i(vf, "promiseAllObject");
function $f(e = 10) {
  let t = "abcdefghijklmnopqrstuvwxyz", r = "";
  for (let n = 0; n < e; n++)
    r += t[Math.floor(Math.random() * t.length)];
  return r;
}
i($f, "randomString");
function gr(e) {
  return JSON.stringify(e);
}
i(gr, "esc");
function $o(e) {
  return e.toLowerCase().trim().replace(/[^\w\s-]/g, "").replace(/[\s_-]+/g, "-").replace(/^-+|-+$/g, "");
}
i($o, "slugify");
var hr = "captureStackTrace" in Error ? Error.captureStackTrace : (...e) => {
};
function Pe(e) {
  return typeof e == "object" && e !== null && !Array.isArray(e);
}
i(Pe, "isObject");
var yo = Be(() => {
  if (typeof navigator < "u" && navigator?.userAgent?.includes("Cloudflare"))
    return !1;
  try {
    let e = Function;
    return new e(""), !0;
  } catch {
    return !1;
  }
});
function $e(e) {
  if (Pe(e) === !1)
    return !1;
  let t = e.constructor;
  if (t === void 0 || typeof t != "function")
    return !0;
  let r = t.prototype;
  return !(Pe(r) === !1 || Object.prototype.hasOwnProperty.call(r, "isPrototypeOf") === !1);
}
i($e, "isPlainObject");
function ec(e) {
  return $e(e) ? { ...e } : Array.isArray(e) ? [...e] : e;
}
i(ec, "shallowClone");
function yf(e) {
  let t = 0;
  for (let r in e)
    Object.prototype.hasOwnProperty.call(e, r) && t++;
  return t;
}
i(yf, "numKeys");
var bf = /* @__PURE__ */ i((e) => {
  let t = typeof e;
  switch (t) {
    case "undefined":
      return "undefined";
    case "string":
      return "string";
    case "number":
      return Number.isNaN(e) ? "nan" : "number";
    case "boolean":
      return "boolean";
    case "function":
      return "function";
    case "bigint":
      return "bigint";
    case "symbol":
      return "symbol";
    case "object":
      return Array.isArray(e) ? "array" : e === null ? "null" : e.then && typeof e.then == "function" && e.catch && typeof e.catch == "function" ? "promise" : typeof Map < "u" && e instanceof Map ? "map" : typeof Set < "u" && e instanceof Set ? "set" : typeof Date < "u" && e instanceof Date ? "date" : typeof File < "u" && e instanceof File ? "file" : "object";
    default:
      throw new Error(`Unknown data type: ${t}`);
  }
}, "getParsedType"), ht = /* @__PURE__ */ new Set(["string", "number", "symbol"]), bo = /* @__PURE__ */ new Set(["string", "number", "bigint", "boolean", "symbol", "undefined"]);
function oe(e) {
  return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
i(oe, "escapeRegex");
function Q(e, t, r) {
  let n = new e._zod.constr(t ?? e._zod.def);
  return (!t || r?.parent) && (n._zod.parent = e), n;
}
i(Q, "clone");
function v(e) {
  let t = e;
  if (!t)
    return {};
  if (typeof t == "string")
    return { error: /* @__PURE__ */ i(() => t, "error") };
  if (t?.message !== void 0) {
    if (t?.error !== void 0)
      throw new Error("Cannot specify both `message` and `error` params");
    t.error = t.message;
  }
  return delete t.message, typeof t.error == "string" ? { ...t, error: /* @__PURE__ */ i(() => t.error, "error") } : t;
}
i(v, "normalizeParams");
function xf(e) {
  let t;
  return new Proxy({}, {
    get(r, n, o) {
      return t ?? (t = e()), Reflect.get(t, n, o);
    },
    set(r, n, o, a) {
      return t ?? (t = e()), Reflect.set(t, n, o, a);
    },
    has(r, n) {
      return t ?? (t = e()), Reflect.has(t, n);
    },
    deleteProperty(r, n) {
      return t ?? (t = e()), Reflect.deleteProperty(t, n);
    },
    ownKeys(r) {
      return t ?? (t = e()), Reflect.ownKeys(t);
    },
    getOwnPropertyDescriptor(r, n) {
      return t ?? (t = e()), Reflect.getOwnPropertyDescriptor(t, n);
    },
    defineProperty(r, n, o) {
      return t ?? (t = e()), Reflect.defineProperty(t, n, o);
    }
  });
}
i(xf, "createTransparentProxy");
function b(e) {
  return typeof e == "bigint" ? e.toString() + "n" : typeof e == "string" ? `"${e}"` : `${e}`;
}
i(b, "stringifyPrimitive");
function xo(e) {
  return Object.keys(e).filter((t) => e[t]._zod.optin === "optional" && e[t]._zod.optout === "optional");
}
i(xo, "optionalKeys");
var _o = {
  safeint: [Number.MIN_SAFE_INTEGER, Number.MAX_SAFE_INTEGER],
  int32: [-2147483648, 2147483647],
  uint32: [0, 4294967295],
  float32: [-34028234663852886e22, 34028234663852886e22],
  float64: [-Number.MAX_VALUE, Number.MAX_VALUE]
}, ko = {
  int64: [/* @__PURE__ */ BigInt("-9223372036854775808"), /* @__PURE__ */ BigInt("9223372036854775807")],
  uint64: [/* @__PURE__ */ BigInt(0), /* @__PURE__ */ BigInt("18446744073709551615")]
};
function _f(e, t) {
  let r = e._zod.def, n = r.checks;
  if (n && n.length > 0)
    throw new Error(".pick() cannot be used on object schemas containing refinements");
  let a = fe(e._zod.def, {
    get shape() {
      let c = {};
      for (let u in t) {
        if (!(u in r.shape))
          throw new Error(`Unrecognized key: "${u}"`);
        t[u] && (c[u] = r.shape[u]);
      }
      return ve(this, "shape", c), c;
    },
    checks: []
  });
  return Q(e, a);
}
i(_f, "pick");
function kf(e, t) {
  let r = e._zod.def, n = r.checks;
  if (n && n.length > 0)
    throw new Error(".omit() cannot be used on object schemas containing refinements");
  let a = fe(e._zod.def, {
    get shape() {
      let c = { ...e._zod.def.shape };
      for (let u in t) {
        if (!(u in r.shape))
          throw new Error(`Unrecognized key: "${u}"`);
        t[u] && delete c[u];
      }
      return ve(this, "shape", c), c;
    },
    checks: []
  });
  return Q(e, a);
}
i(kf, "omit");
function wf(e, t) {
  if (!$e(t))
    throw new Error("Invalid input to extend: expected a plain object");
  let r = e._zod.def.checks;
  if (r && r.length > 0) {
    let a = e._zod.def.shape;
    for (let c in t)
      if (Object.getOwnPropertyDescriptor(a, c) !== void 0)
        throw new Error("Cannot overwrite keys on object schemas containing refinements. Use `.safeExtend()` instead.");
  }
  let o = fe(e._zod.def, {
    get shape() {
      let a = { ...e._zod.def.shape, ...t };
      return ve(this, "shape", a), a;
    }
  });
  return Q(e, o);
}
i(wf, "extend");
function zf(e, t) {
  if (!$e(t))
    throw new Error("Invalid input to safeExtend: expected a plain object");
  let r = fe(e._zod.def, {
    get shape() {
      let n = { ...e._zod.def.shape, ...t };
      return ve(this, "shape", n), n;
    }
  });
  return Q(e, r);
}
i(zf, "safeExtend");
function If(e, t) {
  let r = fe(e._zod.def, {
    get shape() {
      let n = { ...e._zod.def.shape, ...t._zod.def.shape };
      return ve(this, "shape", n), n;
    },
    get catchall() {
      return t._zod.def.catchall;
    },
    checks: []
    // delete existing checks
  });
  return Q(e, r);
}
i(If, "merge");
function Sf(e, t, r) {
  let o = t._zod.def.checks;
  if (o && o.length > 0)
    throw new Error(".partial() cannot be used on object schemas containing refinements");
  let c = fe(t._zod.def, {
    get shape() {
      let u = t._zod.def.shape, s = { ...u };
      if (r)
        for (let d in r) {
          if (!(d in u))
            throw new Error(`Unrecognized key: "${d}"`);
          r[d] && (s[d] = e ? new e({
            type: "optional",
            innerType: u[d]
          }) : u[d]);
        }
      else
        for (let d in u)
          s[d] = e ? new e({
            type: "optional",
            innerType: u[d]
          }) : u[d];
      return ve(this, "shape", s), s;
    },
    checks: []
  });
  return Q(t, c);
}
i(Sf, "partial");
function jf(e, t, r) {
  let n = fe(t._zod.def, {
    get shape() {
      let o = t._zod.def.shape, a = { ...o };
      if (r)
        for (let c in r) {
          if (!(c in a))
            throw new Error(`Unrecognized key: "${c}"`);
          r[c] && (a[c] = new e({
            type: "nonoptional",
            innerType: o[c]
          }));
        }
      else
        for (let c in o)
          a[c] = new e({
            type: "nonoptional",
            innerType: o[c]
          });
      return ve(this, "shape", a), a;
    }
  });
  return Q(t, n);
}
i(jf, "required");
function ye(e, t = 0) {
  if (e.aborted === !0)
    return !0;
  for (let r = t; r < e.issues.length; r++)
    if (e.issues[r]?.continue !== !0)
      return !0;
  return !1;
}
i(ye, "aborted");
function Y(e, t) {
  return t.map((r) => {
    var n;
    return (n = r).path ?? (n.path = []), r.path.unshift(e), r;
  });
}
i(Y, "prefixIssues");
function mt(e) {
  return typeof e == "string" ? e : e?.message;
}
i(mt, "unwrapMessage");
function K(e, t, r) {
  let n = { ...e, path: e.path ?? [] };
  if (!e.message) {
    let o = mt(e.inst?._zod.def?.error?.(e)) ?? mt(t?.error?.(e)) ?? mt(r.customError?.(e)) ?? mt(r.localeError?.(e)) ?? "Invalid input";
    n.message = o;
  }
  return delete n.inst, delete n.continue, t?.reportInput || delete n.input, n;
}
i(K, "finalizeIssue");
function vt(e) {
  return e instanceof Set ? "set" : e instanceof Map ? "map" : e instanceof File ? "file" : "unknown";
}
i(vt, "getSizableOrigin");
function $t(e) {
  return Array.isArray(e) ? "array" : typeof e == "string" ? "string" : "unknown";
}
i($t, "getLengthableOrigin");
function x(e) {
  let t = typeof e;
  switch (t) {
    case "number":
      return Number.isNaN(e) ? "nan" : "number";
    case "object": {
      if (e === null)
        return "null";
      if (Array.isArray(e))
        return "array";
      let r = e;
      if (r && Object.getPrototypeOf(r) !== Object.prototype && "constructor" in r && r.constructor)
        return r.constructor.name;
    }
  }
  return t;
}
i(x, "parsedType");
function qe(...e) {
  let [t, r, n] = e;
  return typeof t == "string" ? {
    message: t,
    code: "custom",
    input: r,
    inst: n
  } : { ...t };
}
i(qe, "issue");
function Of(e) {
  return Object.entries(e).filter(([t, r]) => Number.isNaN(Number.parseInt(t, 10))).map((t) => t[1]);
}
i(Of, "cleanEnum");
function tc(e) {
  let t = atob(e), r = new Uint8Array(t.length);
  for (let n = 0; n < t.length; n++)
    r[n] = t.charCodeAt(n);
  return r;
}
i(tc, "base64ToUint8Array");
function rc(e) {
  let t = "";
  for (let r = 0; r < e.length; r++)
    t += String.fromCharCode(e[r]);
  return btoa(t);
}
i(rc, "uint8ArrayToBase64");
function Pf(e) {
  let t = e.replace(/-/g, "+").replace(/_/g, "/"), r = "=".repeat((4 - t.length % 4) % 4);
  return tc(t + r);
}
i(Pf, "base64urlToUint8Array");
function Tf(e) {
  return rc(e).replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, "");
}
i(Tf, "uint8ArrayToBase64url");
function Uf(e) {
  let t = e.replace(/^0x/, "");
  if (t.length % 2 !== 0)
    throw new Error("Invalid hex string length");
  let r = new Uint8Array(t.length / 2);
  for (let n = 0; n < t.length; n += 2)
    r[n / 2] = Number.parseInt(t.slice(n, n + 2), 16);
  return r;
}
i(Uf, "hexToUint8Array");
function Zf(e) {
  return Array.from(e).map((t) => t.toString(16).padStart(2, "0")).join("");
}
i(Zf, "uint8ArrayToHex");
var ho = class {
  static {
    i(this, "Class");
  }
  constructor(...t) {
  }
};

// versions/4.3.6/node_modules/zod/v4/core/errors.js
var nc = /* @__PURE__ */ i((e, t) => {
  e.name = "$ZodError", Object.defineProperty(e, "_zod", {
    value: e._zod,
    enumerable: !1
  }), Object.defineProperty(e, "issues", {
    value: t,
    enumerable: !1
  }), e.message = JSON.stringify(t, Me, 2), Object.defineProperty(e, "toString", {
    value: /* @__PURE__ */ i(() => e.message, "value"),
    enumerable: !1
  });
}, "initializer"), vr = l("$ZodError", nc), yt = l("$ZodError", nc, { Parent: Error });
function wo(e, t = (r) => r.message) {
  let r = {}, n = [];
  for (let o of e.issues)
    o.path.length > 0 ? (r[o.path[0]] = r[o.path[0]] || [], r[o.path[0]].push(t(o))) : n.push(t(o));
  return { formErrors: n, fieldErrors: r };
}
i(wo, "flattenError");
function zo(e, t = (r) => r.message) {
  let r = { _errors: [] }, n = /* @__PURE__ */ i((o) => {
    for (let a of o.issues)
      if (a.code === "invalid_union" && a.errors.length)
        a.errors.map((c) => n({ issues: c }));
      else if (a.code === "invalid_key")
        n({ issues: a.issues });
      else if (a.code === "invalid_element")
        n({ issues: a.issues });
      else if (a.path.length === 0)
        r._errors.push(t(a));
      else {
        let c = r, u = 0;
        for (; u < a.path.length; ) {
          let s = a.path[u];
          u === a.path.length - 1 ? (c[s] = c[s] || { _errors: [] }, c[s]._errors.push(t(a))) : c[s] = c[s] || { _errors: [] }, c = c[s], u++;
        }
      }
  }, "processError");
  return n(e), r;
}
i(zo, "formatError");

// versions/4.3.6/node_modules/zod/v4/core/parse.js
var bt = /* @__PURE__ */ i((e) => (t, r, n, o) => {
  let a = n ? Object.assign(n, { async: !1 }) : { async: !1 }, c = t._zod.run({ value: r, issues: [] }, a);
  if (c instanceof Promise)
    throw new le();
  if (c.issues.length) {
    let u = new (o?.Err ?? e)(c.issues.map((s) => K(s, a, B())));
    throw hr(u, o?.callee), u;
  }
  return c.value;
}, "_parse"), Io = /* @__PURE__ */ bt(yt), xt = /* @__PURE__ */ i((e) => async (t, r, n, o) => {
  let a = n ? Object.assign(n, { async: !0 }) : { async: !0 }, c = t._zod.run({ value: r, issues: [] }, a);
  if (c instanceof Promise && (c = await c), c.issues.length) {
    let u = new (o?.Err ?? e)(c.issues.map((s) => K(s, a, B())));
    throw hr(u, o?.callee), u;
  }
  return c.value;
}, "_parseAsync"), So = /* @__PURE__ */ xt(yt), _t = /* @__PURE__ */ i((e) => (t, r, n) => {
  let o = n ? { ...n, async: !1 } : { async: !1 }, a = t._zod.run({ value: r, issues: [] }, o);
  if (a instanceof Promise)
    throw new le();
  return a.issues.length ? {
    success: !1,
    error: new (e ?? vr)(a.issues.map((c) => K(c, o, B())))
  } : { success: !0, data: a.value };
}, "_safeParse"), oc = /* @__PURE__ */ _t(yt), kt = /* @__PURE__ */ i((e) => async (t, r, n) => {
  let o = n ? Object.assign(n, { async: !0 }) : { async: !0 }, a = t._zod.run({ value: r, issues: [] }, o);
  return a instanceof Promise && (a = await a), a.issues.length ? {
    success: !1,
    error: new e(a.issues.map((c) => K(c, o, B())))
  } : { success: !0, data: a.value };
}, "_safeParseAsync"), ic = /* @__PURE__ */ kt(yt), ac = /* @__PURE__ */ i((e) => (t, r, n) => {
  let o = n ? Object.assign(n, { direction: "backward" }) : { direction: "backward" };
  return bt(e)(t, r, o);
}, "_encode");
var cc = /* @__PURE__ */ i((e) => (t, r, n) => bt(e)(t, r, n), "_decode");
var uc = /* @__PURE__ */ i((e) => async (t, r, n) => {
  let o = n ? Object.assign(n, { direction: "backward" }) : { direction: "backward" };
  return xt(e)(t, r, o);
}, "_encodeAsync");
var sc = /* @__PURE__ */ i((e) => async (t, r, n) => xt(e)(t, r, n), "_decodeAsync");
var lc = /* @__PURE__ */ i((e) => (t, r, n) => {
  let o = n ? Object.assign(n, { direction: "backward" }) : { direction: "backward" };
  return _t(e)(t, r, o);
}, "_safeEncode");
var dc = /* @__PURE__ */ i((e) => (t, r, n) => _t(e)(t, r, n), "_safeDecode");
var fc = /* @__PURE__ */ i((e) => async (t, r, n) => {
  let o = n ? Object.assign(n, { direction: "backward" }) : { direction: "backward" };
  return kt(e)(t, r, o);
}, "_safeEncodeAsync");
var mc = /* @__PURE__ */ i((e) => async (t, r, n) => kt(e)(t, r, n), "_safeDecodeAsync");

// versions/4.3.6/node_modules/zod/v4/core/regexes.js
var de = {};
nt(de, {
  base64: () => Vo,
  base64url: () => $r,
  bigint: () => Ko,
  boolean: () => Ho,
  browserEmail: () => Jf,
  cidrv4: () => Lo,
  cidrv6: () => Jo,
  cuid: () => jo,
  cuid2: () => Oo,
  date: () => Bo,
  datetime: () => Go,
  domain: () => Bf,
  duration: () => Eo,
  e164: () => Mo,
  email: () => Do,
  emoji: () => Ao,
  extendedDuration: () => Nf,
  guid: () => No,
  hex: () => qf,
  hostname: () => Mf,
  html5Email: () => Rf,
  idnEmail: () => Lf,
  integer: () => Xo,
  ipv4: () => Co,
  ipv6: () => Ro,
  ksuid: () => Uo,
  lowercase: () => ei,
  mac: () => Fo,
  md5_base64: () => Wf,
  md5_base64url: () => Kf,
  md5_hex: () => Gf,
  nanoid: () => Zo,
  null: () => Qo,
  number: () => yr,
  rfc5322Email: () => Ff,
  sha1_base64: () => Hf,
  sha1_base64url: () => Qf,
  sha1_hex: () => Xf,
  sha256_base64: () => em,
  sha256_base64url: () => tm,
  sha256_hex: () => Yf,
  sha384_base64: () => nm,
  sha384_base64url: () => om,
  sha384_hex: () => rm,
  sha512_base64: () => am,
  sha512_base64url: () => cm,
  sha512_hex: () => im,
  string: () => Wo,
  time: () => qo,
  ulid: () => Po,
  undefined: () => Yo,
  unicodeEmail: () => pc,
  uppercase: () => ti,
  uuid: () => Te,
  uuid4: () => Df,
  uuid6: () => Af,
  uuid7: () => Cf,
  xid: () => To
});
var jo = /^[cC][^\s-]{8,}$/, Oo = /^[0-9a-z]+$/, Po = /^[0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{26}$/, To = /^[0-9a-vA-V]{20}$/, Uo = /^[A-Za-z0-9]{27}$/, Zo = /^[a-zA-Z0-9_-]{21}$/, Eo = /^P(?:(\d+W)|(?!.*W)(?=\d|T\d)(\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+([.,]\d+)?S)?)?)$/, Nf = /^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/, No = /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/, Te = /* @__PURE__ */ i((e) => e ? new RegExp(`^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${e}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`) : /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/, "uuid"), Df = /* @__PURE__ */ Te(4), Af = /* @__PURE__ */ Te(6), Cf = /* @__PURE__ */ Te(7), Do = /^(?!\.)(?!.*\.\.)([A-Za-z0-9_'+\-\.]*)[A-Za-z0-9_+-]@([A-Za-z0-9][A-Za-z0-9\-]*\.)+[A-Za-z]{2,}$/, Rf = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/, Ff = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/, pc = /^[^\s@"]{1,64}@[^\s@]{1,255}$/u, Lf = pc, Jf = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/, Vf = "^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$";
function Ao() {
  return new RegExp(Vf, "u");
}
i(Ao, "emoji");
var Co = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/, Ro = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))$/, Fo = /* @__PURE__ */ i((e) => {
  let t = oe(e ?? ":");
  return new RegExp(`^(?:[0-9A-F]{2}${t}){5}[0-9A-F]{2}$|^(?:[0-9a-f]{2}${t}){5}[0-9a-f]{2}$`);
}, "mac"), Lo = /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/([0-9]|[1-2][0-9]|3[0-2])$/, Jo = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|::|([0-9a-fA-F]{1,4})?::([0-9a-fA-F]{1,4}:?){0,6})\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/, Vo = /^$|^(?:[0-9a-zA-Z+/]{4})*(?:(?:[0-9a-zA-Z+/]{2}==)|(?:[0-9a-zA-Z+/]{3}=))?$/, $r = /^[A-Za-z0-9_-]*$/, Mf = /^(?=.{1,253}\.?$)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[-0-9a-zA-Z]{0,61}[0-9a-zA-Z])?)*\.?$/, Bf = /^([a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$/, Mo = /^\+[1-9]\d{6,14}$/, gc = "(?:(?:\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-(?:(?:0[13578]|1[02])-(?:0[1-9]|[12]\\d|3[01])|(?:0[469]|11)-(?:0[1-9]|[12]\\d|30)|(?:02)-(?:0[1-9]|1\\d|2[0-8])))", Bo = /* @__PURE__ */ new RegExp(`^${gc}$`);
function hc(e) {
  let t = "(?:[01]\\d|2[0-3]):[0-5]\\d";
  return typeof e.precision == "number" ? e.precision === -1 ? `${t}` : e.precision === 0 ? `${t}:[0-5]\\d` : `${t}:[0-5]\\d\\.\\d{${e.precision}}` : `${t}(?::[0-5]\\d(?:\\.\\d+)?)?`;
}
i(hc, "timeSource");
function qo(e) {
  return new RegExp(`^${hc(e)}$`);
}
i(qo, "time");
function Go(e) {
  let t = hc({ precision: e.precision }), r = ["Z"];
  e.local && r.push(""), e.offset && r.push("([+-](?:[01]\\d|2[0-3]):[0-5]\\d)");
  let n = `${t}(?:${r.join("|")})`;
  return new RegExp(`^${gc}T(?:${n})$`);
}
i(Go, "datetime");
var Wo = /* @__PURE__ */ i((e) => {
  let t = e ? `[\\s\\S]{${e?.minimum ?? 0},${e?.maximum ?? ""}}` : "[\\s\\S]*";
  return new RegExp(`^${t}$`);
}, "string"), Ko = /^-?\d+n?$/, Xo = /^-?\d+$/, yr = /^-?\d+(?:\.\d+)?$/, Ho = /^(?:true|false)$/i, Qo = /^null$/i;
var Yo = /^undefined$/i;
var ei = /^[^A-Z]*$/, ti = /^[^a-z]*$/, qf = /^[0-9a-fA-F]*$/;
function wt(e, t) {
  return new RegExp(`^[A-Za-z0-9+/]{${e}}${t}$`);
}
i(wt, "fixedBase64");
function zt(e) {
  return new RegExp(`^[A-Za-z0-9_-]{${e}}$`);
}
i(zt, "fixedBase64url");
var Gf = /^[0-9a-fA-F]{32}$/, Wf = /* @__PURE__ */ wt(22, "=="), Kf = /* @__PURE__ */ zt(22), Xf = /^[0-9a-fA-F]{40}$/, Hf = /* @__PURE__ */ wt(27, "="), Qf = /* @__PURE__ */ zt(27), Yf = /^[0-9a-fA-F]{64}$/, em = /* @__PURE__ */ wt(43, "="), tm = /* @__PURE__ */ zt(43), rm = /^[0-9a-fA-F]{96}$/, nm = /* @__PURE__ */ wt(64, ""), om = /* @__PURE__ */ zt(64), im = /^[0-9a-fA-F]{128}$/, am = /* @__PURE__ */ wt(86, "=="), cm = /* @__PURE__ */ zt(86);

// versions/4.3.6/node_modules/zod/v4/core/checks.js
var E = /* @__PURE__ */ l("$ZodCheck", (e, t) => {
  var r;
  e._zod ?? (e._zod = {}), e._zod.def = t, (r = e._zod).onattach ?? (r.onattach = []);
}), $c = {
  number: "number",
  bigint: "bigint",
  object: "date"
}, ri = /* @__PURE__ */ l("$ZodCheckLessThan", (e, t) => {
  E.init(e, t);
  let r = $c[typeof t.value];
  e._zod.onattach.push((n) => {
    let o = n._zod.bag, a = (t.inclusive ? o.maximum : o.exclusiveMaximum) ?? Number.POSITIVE_INFINITY;
    t.value < a && (t.inclusive ? o.maximum = t.value : o.exclusiveMaximum = t.value);
  }), e._zod.check = (n) => {
    (t.inclusive ? n.value <= t.value : n.value < t.value) || n.issues.push({
      origin: r,
      code: "too_big",
      maximum: typeof t.value == "object" ? t.value.getTime() : t.value,
      input: n.value,
      inclusive: t.inclusive,
      inst: e,
      continue: !t.abort
    });
  };
}), ni = /* @__PURE__ */ l("$ZodCheckGreaterThan", (e, t) => {
  E.init(e, t);
  let r = $c[typeof t.value];
  e._zod.onattach.push((n) => {
    let o = n._zod.bag, a = (t.inclusive ? o.minimum : o.exclusiveMinimum) ?? Number.NEGATIVE_INFINITY;
    t.value > a && (t.inclusive ? o.minimum = t.value : o.exclusiveMinimum = t.value);
  }), e._zod.check = (n) => {
    (t.inclusive ? n.value >= t.value : n.value > t.value) || n.issues.push({
      origin: r,
      code: "too_small",
      minimum: typeof t.value == "object" ? t.value.getTime() : t.value,
      input: n.value,
      inclusive: t.inclusive,
      inst: e,
      continue: !t.abort
    });
  };
}), yc = /* @__PURE__ */ l("$ZodCheckMultipleOf", (e, t) => {
  E.init(e, t), e._zod.onattach.push((r) => {
    var n;
    (n = r._zod.bag).multipleOf ?? (n.multipleOf = t.value);
  }), e._zod.check = (r) => {
    if (typeof r.value != typeof t.value)
      throw new Error("Cannot mix number and bigint in multiple_of check.");
    (typeof r.value == "bigint" ? r.value % t.value === BigInt(0) : vo(r.value, t.value) === 0) || r.issues.push({
      origin: typeof r.value,
      code: "not_multiple_of",
      divisor: t.value,
      input: r.value,
      inst: e,
      continue: !t.abort
    });
  };
}), bc = /* @__PURE__ */ l("$ZodCheckNumberFormat", (e, t) => {
  E.init(e, t), t.format = t.format || "float64";
  let r = t.format?.includes("int"), n = r ? "int" : "number", [o, a] = _o[t.format];
  e._zod.onattach.push((c) => {
    let u = c._zod.bag;
    u.format = t.format, u.minimum = o, u.maximum = a, r && (u.pattern = Xo);
  }), e._zod.check = (c) => {
    let u = c.value;
    if (r) {
      if (!Number.isInteger(u)) {
        c.issues.push({
          expected: n,
          format: t.format,
          code: "invalid_type",
          continue: !1,
          input: u,
          inst: e
        });
        return;
      }
      if (!Number.isSafeInteger(u)) {
        u > 0 ? c.issues.push({
          input: u,
          code: "too_big",
          maximum: Number.MAX_SAFE_INTEGER,
          note: "Integers must be within the safe integer range.",
          inst: e,
          origin: n,
          inclusive: !0,
          continue: !t.abort
        }) : c.issues.push({
          input: u,
          code: "too_small",
          minimum: Number.MIN_SAFE_INTEGER,
          note: "Integers must be within the safe integer range.",
          inst: e,
          origin: n,
          inclusive: !0,
          continue: !t.abort
        });
        return;
      }
    }
    u < o && c.issues.push({
      origin: "number",
      input: u,
      code: "too_small",
      minimum: o,
      inclusive: !0,
      inst: e,
      continue: !t.abort
    }), u > a && c.issues.push({
      origin: "number",
      input: u,
      code: "too_big",
      maximum: a,
      inclusive: !0,
      inst: e,
      continue: !t.abort
    });
  };
}), xc = /* @__PURE__ */ l("$ZodCheckBigIntFormat", (e, t) => {
  E.init(e, t);
  let [r, n] = ko[t.format];
  e._zod.onattach.push((o) => {
    let a = o._zod.bag;
    a.format = t.format, a.minimum = r, a.maximum = n;
  }), e._zod.check = (o) => {
    let a = o.value;
    a < r && o.issues.push({
      origin: "bigint",
      input: a,
      code: "too_small",
      minimum: r,
      inclusive: !0,
      inst: e,
      continue: !t.abort
    }), a > n && o.issues.push({
      origin: "bigint",
      input: a,
      code: "too_big",
      maximum: n,
      inclusive: !0,
      inst: e,
      continue: !t.abort
    });
  };
}), _c = /* @__PURE__ */ l("$ZodCheckMaxSize", (e, t) => {
  var r;
  E.init(e, t), (r = e._zod.def).when ?? (r.when = (n) => {
    let o = n.value;
    return !he(o) && o.size !== void 0;
  }), e._zod.onattach.push((n) => {
    let o = n._zod.bag.maximum ?? Number.POSITIVE_INFINITY;
    t.maximum < o && (n._zod.bag.maximum = t.maximum);
  }), e._zod.check = (n) => {
    let o = n.value;
    o.size <= t.maximum || n.issues.push({
      origin: vt(o),
      code: "too_big",
      maximum: t.maximum,
      inclusive: !0,
      input: o,
      inst: e,
      continue: !t.abort
    });
  };
}), kc = /* @__PURE__ */ l("$ZodCheckMinSize", (e, t) => {
  var r;
  E.init(e, t), (r = e._zod.def).when ?? (r.when = (n) => {
    let o = n.value;
    return !he(o) && o.size !== void 0;
  }), e._zod.onattach.push((n) => {
    let o = n._zod.bag.minimum ?? Number.NEGATIVE_INFINITY;
    t.minimum > o && (n._zod.bag.minimum = t.minimum);
  }), e._zod.check = (n) => {
    let o = n.value;
    o.size >= t.minimum || n.issues.push({
      origin: vt(o),
      code: "too_small",
      minimum: t.minimum,
      inclusive: !0,
      input: o,
      inst: e,
      continue: !t.abort
    });
  };
}), wc = /* @__PURE__ */ l("$ZodCheckSizeEquals", (e, t) => {
  var r;
  E.init(e, t), (r = e._zod.def).when ?? (r.when = (n) => {
    let o = n.value;
    return !he(o) && o.size !== void 0;
  }), e._zod.onattach.push((n) => {
    let o = n._zod.bag;
    o.minimum = t.size, o.maximum = t.size, o.size = t.size;
  }), e._zod.check = (n) => {
    let o = n.value, a = o.size;
    if (a === t.size)
      return;
    let c = a > t.size;
    n.issues.push({
      origin: vt(o),
      ...c ? { code: "too_big", maximum: t.size } : { code: "too_small", minimum: t.size },
      inclusive: !0,
      exact: !0,
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), zc = /* @__PURE__ */ l("$ZodCheckMaxLength", (e, t) => {
  var r;
  E.init(e, t), (r = e._zod.def).when ?? (r.when = (n) => {
    let o = n.value;
    return !he(o) && o.length !== void 0;
  }), e._zod.onattach.push((n) => {
    let o = n._zod.bag.maximum ?? Number.POSITIVE_INFINITY;
    t.maximum < o && (n._zod.bag.maximum = t.maximum);
  }), e._zod.check = (n) => {
    let o = n.value;
    if (o.length <= t.maximum)
      return;
    let c = $t(o);
    n.issues.push({
      origin: c,
      code: "too_big",
      maximum: t.maximum,
      inclusive: !0,
      input: o,
      inst: e,
      continue: !t.abort
    });
  };
}), Ic = /* @__PURE__ */ l("$ZodCheckMinLength", (e, t) => {
  var r;
  E.init(e, t), (r = e._zod.def).when ?? (r.when = (n) => {
    let o = n.value;
    return !he(o) && o.length !== void 0;
  }), e._zod.onattach.push((n) => {
    let o = n._zod.bag.minimum ?? Number.NEGATIVE_INFINITY;
    t.minimum > o && (n._zod.bag.minimum = t.minimum);
  }), e._zod.check = (n) => {
    let o = n.value;
    if (o.length >= t.minimum)
      return;
    let c = $t(o);
    n.issues.push({
      origin: c,
      code: "too_small",
      minimum: t.minimum,
      inclusive: !0,
      input: o,
      inst: e,
      continue: !t.abort
    });
  };
}), Sc = /* @__PURE__ */ l("$ZodCheckLengthEquals", (e, t) => {
  var r;
  E.init(e, t), (r = e._zod.def).when ?? (r.when = (n) => {
    let o = n.value;
    return !he(o) && o.length !== void 0;
  }), e._zod.onattach.push((n) => {
    let o = n._zod.bag;
    o.minimum = t.length, o.maximum = t.length, o.length = t.length;
  }), e._zod.check = (n) => {
    let o = n.value, a = o.length;
    if (a === t.length)
      return;
    let c = $t(o), u = a > t.length;
    n.issues.push({
      origin: c,
      ...u ? { code: "too_big", maximum: t.length } : { code: "too_small", minimum: t.length },
      inclusive: !0,
      exact: !0,
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), It = /* @__PURE__ */ l("$ZodCheckStringFormat", (e, t) => {
  var r, n;
  E.init(e, t), e._zod.onattach.push((o) => {
    let a = o._zod.bag;
    a.format = t.format, t.pattern && (a.patterns ?? (a.patterns = /* @__PURE__ */ new Set()), a.patterns.add(t.pattern));
  }), t.pattern ? (r = e._zod).check ?? (r.check = (o) => {
    t.pattern.lastIndex = 0, !t.pattern.test(o.value) && o.issues.push({
      origin: "string",
      code: "invalid_format",
      format: t.format,
      input: o.value,
      ...t.pattern ? { pattern: t.pattern.toString() } : {},
      inst: e,
      continue: !t.abort
    });
  }) : (n = e._zod).check ?? (n.check = () => {
  });
}), jc = /* @__PURE__ */ l("$ZodCheckRegex", (e, t) => {
  It.init(e, t), e._zod.check = (r) => {
    t.pattern.lastIndex = 0, !t.pattern.test(r.value) && r.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "regex",
      input: r.value,
      pattern: t.pattern.toString(),
      inst: e,
      continue: !t.abort
    });
  };
}), Oc = /* @__PURE__ */ l("$ZodCheckLowerCase", (e, t) => {
  t.pattern ?? (t.pattern = ei), It.init(e, t);
}), Pc = /* @__PURE__ */ l("$ZodCheckUpperCase", (e, t) => {
  t.pattern ?? (t.pattern = ti), It.init(e, t);
}), Tc = /* @__PURE__ */ l("$ZodCheckIncludes", (e, t) => {
  E.init(e, t);
  let r = oe(t.includes), n = new RegExp(typeof t.position == "number" ? `^.{${t.position}}${r}` : r);
  t.pattern = n, e._zod.onattach.push((o) => {
    let a = o._zod.bag;
    a.patterns ?? (a.patterns = /* @__PURE__ */ new Set()), a.patterns.add(n);
  }), e._zod.check = (o) => {
    o.value.includes(t.includes, t.position) || o.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "includes",
      includes: t.includes,
      input: o.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Uc = /* @__PURE__ */ l("$ZodCheckStartsWith", (e, t) => {
  E.init(e, t);
  let r = new RegExp(`^${oe(t.prefix)}.*`);
  t.pattern ?? (t.pattern = r), e._zod.onattach.push((n) => {
    let o = n._zod.bag;
    o.patterns ?? (o.patterns = /* @__PURE__ */ new Set()), o.patterns.add(r);
  }), e._zod.check = (n) => {
    n.value.startsWith(t.prefix) || n.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "starts_with",
      prefix: t.prefix,
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Zc = /* @__PURE__ */ l("$ZodCheckEndsWith", (e, t) => {
  E.init(e, t);
  let r = new RegExp(`.*${oe(t.suffix)}$`);
  t.pattern ?? (t.pattern = r), e._zod.onattach.push((n) => {
    let o = n._zod.bag;
    o.patterns ?? (o.patterns = /* @__PURE__ */ new Set()), o.patterns.add(r);
  }), e._zod.check = (n) => {
    n.value.endsWith(t.suffix) || n.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "ends_with",
      suffix: t.suffix,
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
});
function vc(e, t, r) {
  e.issues.length && t.issues.push(...Y(r, e.issues));
}
i(vc, "handleCheckPropertyResult");
var Ec = /* @__PURE__ */ l("$ZodCheckProperty", (e, t) => {
  E.init(e, t), e._zod.check = (r) => {
    let n = t.schema._zod.run({
      value: r.value[t.property],
      issues: []
    }, {});
    if (n instanceof Promise)
      return n.then((o) => vc(o, r, t.property));
    vc(n, r, t.property);
  };
}), Nc = /* @__PURE__ */ l("$ZodCheckMimeType", (e, t) => {
  E.init(e, t);
  let r = new Set(t.mime);
  e._zod.onattach.push((n) => {
    n._zod.bag.mime = t.mime;
  }), e._zod.check = (n) => {
    r.has(n.value.type) || n.issues.push({
      code: "invalid_value",
      values: t.mime,
      input: n.value.type,
      inst: e,
      continue: !t.abort
    });
  };
}), Dc = /* @__PURE__ */ l("$ZodCheckOverwrite", (e, t) => {
  E.init(e, t), e._zod.check = (r) => {
    r.value = t.tx(r.value);
  };
});

// versions/4.3.6/node_modules/zod/v4/core/doc.js
var br = class {
  static {
    i(this, "Doc");
  }
  constructor(t = []) {
    this.content = [], this.indent = 0, this && (this.args = t);
  }
  indented(t) {
    this.indent += 1, t(this), this.indent -= 1;
  }
  write(t) {
    if (typeof t == "function") {
      t(this, { execution: "sync" }), t(this, { execution: "async" });
      return;
    }
    let n = t.split(`
`).filter((c) => c), o = Math.min(...n.map((c) => c.length - c.trimStart().length)), a = n.map((c) => c.slice(o)).map((c) => " ".repeat(this.indent * 2) + c);
    for (let c of a)
      this.content.push(c);
  }
  compile() {
    let t = Function, r = this?.args, o = [...(this?.content ?? [""]).map((a) => `  ${a}`)];
    return new t(...r, o.join(`
`));
  }
};

// versions/4.3.6/node_modules/zod/v4/core/versions.js
var Cc = {
  major: 4,
  minor: 3,
  patch: 6
};

// versions/4.3.6/node_modules/zod/v4/core/schemas.js
var _ = /* @__PURE__ */ l("$ZodType", (e, t) => {
  var r;
  e ?? (e = {}), e._zod.def = t, e._zod.bag = e._zod.bag || {}, e._zod.version = Cc;
  let n = [...e._zod.def.checks ?? []];
  e._zod.traits.has("$ZodCheck") && n.unshift(e);
  for (let o of n)
    for (let a of o._zod.onattach)
      a(e);
  if (n.length === 0)
    (r = e._zod).deferred ?? (r.deferred = []), e._zod.deferred?.push(() => {
      e._zod.run = e._zod.parse;
    });
  else {
    let o = /* @__PURE__ */ i((c, u, s) => {
      let d = ye(c), f;
      for (let g of u) {
        if (g._zod.def.when) {
          if (!g._zod.def.when(c))
            continue;
        } else if (d)
          continue;
        let $ = c.issues.length, h = g._zod.check(c);
        if (h instanceof Promise && s?.async === !1)
          throw new le();
        if (f || h instanceof Promise)
          f = (f ?? Promise.resolve()).then(async () => {
            await h, c.issues.length !== $ && (d || (d = ye(c, $)));
          });
        else {
          if (c.issues.length === $)
            continue;
          d || (d = ye(c, $));
        }
      }
      return f ? f.then(() => c) : c;
    }, "runChecks"), a = /* @__PURE__ */ i((c, u, s) => {
      if (ye(c))
        return c.aborted = !0, c;
      let d = o(u, n, s);
      if (d instanceof Promise) {
        if (s.async === !1)
          throw new le();
        return d.then((f) => e._zod.parse(f, s));
      }
      return e._zod.parse(d, s);
    }, "handleCanaryResult");
    e._zod.run = (c, u) => {
      if (u.skipChecks)
        return e._zod.parse(c, u);
      if (u.direction === "backward") {
        let d = e._zod.parse({ value: c.value, issues: [] }, { ...u, skipChecks: !0 });
        return d instanceof Promise ? d.then((f) => a(f, c, u)) : a(d, c, u);
      }
      let s = e._zod.parse(c, u);
      if (s instanceof Promise) {
        if (u.async === !1)
          throw new le();
        return s.then((d) => o(d, n, u));
      }
      return o(s, n, u);
    };
  }
  I(e, "~standard", () => ({
    validate: /* @__PURE__ */ i((o) => {
      try {
        let a = oc(e, o);
        return a.success ? { value: a.data } : { issues: a.error?.issues };
      } catch {
        return ic(e, o).then((c) => c.success ? { value: c.data } : { issues: c.error?.issues });
      }
    }, "validate"),
    vendor: "zod",
    version: 1
  }));
}), be = /* @__PURE__ */ l("$ZodString", (e, t) => {
  _.init(e, t), e._zod.pattern = [...e?._zod.bag?.patterns ?? []].pop() ?? Wo(e._zod.bag), e._zod.parse = (r, n) => {
    if (t.coerce)
      try {
        r.value = String(r.value);
      } catch {
      }
    return typeof r.value == "string" || r.issues.push({
      expected: "string",
      code: "invalid_type",
      input: r.value,
      inst: e
    }), r;
  };
}), U = /* @__PURE__ */ l("$ZodStringFormat", (e, t) => {
  It.init(e, t), be.init(e, t);
}), Xc = /* @__PURE__ */ l("$ZodGUID", (e, t) => {
  t.pattern ?? (t.pattern = No), U.init(e, t);
}), Hc = /* @__PURE__ */ l("$ZodUUID", (e, t) => {
  if (t.version) {
    let n = {
      v1: 1,
      v2: 2,
      v3: 3,
      v4: 4,
      v5: 5,
      v6: 6,
      v7: 7,
      v8: 8
    }[t.version];
    if (n === void 0)
      throw new Error(`Invalid UUID version: "${t.version}"`);
    t.pattern ?? (t.pattern = Te(n));
  } else
    t.pattern ?? (t.pattern = Te());
  U.init(e, t);
}), Qc = /* @__PURE__ */ l("$ZodEmail", (e, t) => {
  t.pattern ?? (t.pattern = Do), U.init(e, t);
}), Yc = /* @__PURE__ */ l("$ZodURL", (e, t) => {
  U.init(e, t), e._zod.check = (r) => {
    try {
      let n = r.value.trim(), o = new URL(n);
      t.hostname && (t.hostname.lastIndex = 0, t.hostname.test(o.hostname) || r.issues.push({
        code: "invalid_format",
        format: "url",
        note: "Invalid hostname",
        pattern: t.hostname.source,
        input: r.value,
        inst: e,
        continue: !t.abort
      })), t.protocol && (t.protocol.lastIndex = 0, t.protocol.test(o.protocol.endsWith(":") ? o.protocol.slice(0, -1) : o.protocol) || r.issues.push({
        code: "invalid_format",
        format: "url",
        note: "Invalid protocol",
        pattern: t.protocol.source,
        input: r.value,
        inst: e,
        continue: !t.abort
      })), t.normalize ? r.value = o.href : r.value = n;
      return;
    } catch {
      r.issues.push({
        code: "invalid_format",
        format: "url",
        input: r.value,
        inst: e,
        continue: !t.abort
      });
    }
  };
}), eu = /* @__PURE__ */ l("$ZodEmoji", (e, t) => {
  t.pattern ?? (t.pattern = Ao()), U.init(e, t);
}), tu = /* @__PURE__ */ l("$ZodNanoID", (e, t) => {
  t.pattern ?? (t.pattern = Zo), U.init(e, t);
}), ru = /* @__PURE__ */ l("$ZodCUID", (e, t) => {
  t.pattern ?? (t.pattern = jo), U.init(e, t);
}), nu = /* @__PURE__ */ l("$ZodCUID2", (e, t) => {
  t.pattern ?? (t.pattern = Oo), U.init(e, t);
}), ou = /* @__PURE__ */ l("$ZodULID", (e, t) => {
  t.pattern ?? (t.pattern = Po), U.init(e, t);
}), iu = /* @__PURE__ */ l("$ZodXID", (e, t) => {
  t.pattern ?? (t.pattern = To), U.init(e, t);
}), au = /* @__PURE__ */ l("$ZodKSUID", (e, t) => {
  t.pattern ?? (t.pattern = Uo), U.init(e, t);
}), cu = /* @__PURE__ */ l("$ZodISODateTime", (e, t) => {
  t.pattern ?? (t.pattern = Go(t)), U.init(e, t);
}), uu = /* @__PURE__ */ l("$ZodISODate", (e, t) => {
  t.pattern ?? (t.pattern = Bo), U.init(e, t);
}), su = /* @__PURE__ */ l("$ZodISOTime", (e, t) => {
  t.pattern ?? (t.pattern = qo(t)), U.init(e, t);
}), lu = /* @__PURE__ */ l("$ZodISODuration", (e, t) => {
  t.pattern ?? (t.pattern = Eo), U.init(e, t);
}), du = /* @__PURE__ */ l("$ZodIPv4", (e, t) => {
  t.pattern ?? (t.pattern = Co), U.init(e, t), e._zod.bag.format = "ipv4";
}), fu = /* @__PURE__ */ l("$ZodIPv6", (e, t) => {
  t.pattern ?? (t.pattern = Ro), U.init(e, t), e._zod.bag.format = "ipv6", e._zod.check = (r) => {
    try {
      new URL(`http://[${r.value}]`);
    } catch {
      r.issues.push({
        code: "invalid_format",
        format: "ipv6",
        input: r.value,
        inst: e,
        continue: !t.abort
      });
    }
  };
}), mu = /* @__PURE__ */ l("$ZodMAC", (e, t) => {
  t.pattern ?? (t.pattern = Fo(t.delimiter)), U.init(e, t), e._zod.bag.format = "mac";
}), pu = /* @__PURE__ */ l("$ZodCIDRv4", (e, t) => {
  t.pattern ?? (t.pattern = Lo), U.init(e, t);
}), gu = /* @__PURE__ */ l("$ZodCIDRv6", (e, t) => {
  t.pattern ?? (t.pattern = Jo), U.init(e, t), e._zod.check = (r) => {
    let n = r.value.split("/");
    try {
      if (n.length !== 2)
        throw new Error();
      let [o, a] = n;
      if (!a)
        throw new Error();
      let c = Number(a);
      if (`${c}` !== a)
        throw new Error();
      if (c < 0 || c > 128)
        throw new Error();
      new URL(`http://[${o}]`);
    } catch {
      r.issues.push({
        code: "invalid_format",
        format: "cidrv6",
        input: r.value,
        inst: e,
        continue: !t.abort
      });
    }
  };
});
function hu(e) {
  if (e === "")
    return !0;
  if (e.length % 4 !== 0)
    return !1;
  try {
    return atob(e), !0;
  } catch {
    return !1;
  }
}
i(hu, "isValidBase64");
var vu = /* @__PURE__ */ l("$ZodBase64", (e, t) => {
  t.pattern ?? (t.pattern = Vo), U.init(e, t), e._zod.bag.contentEncoding = "base64", e._zod.check = (r) => {
    hu(r.value) || r.issues.push({
      code: "invalid_format",
      format: "base64",
      input: r.value,
      inst: e,
      continue: !t.abort
    });
  };
});
function um(e) {
  if (!$r.test(e))
    return !1;
  let t = e.replace(/[-_]/g, (n) => n === "-" ? "+" : "/"), r = t.padEnd(Math.ceil(t.length / 4) * 4, "=");
  return hu(r);
}
i(um, "isValidBase64URL");
var $u = /* @__PURE__ */ l("$ZodBase64URL", (e, t) => {
  t.pattern ?? (t.pattern = $r), U.init(e, t), e._zod.bag.contentEncoding = "base64url", e._zod.check = (r) => {
    um(r.value) || r.issues.push({
      code: "invalid_format",
      format: "base64url",
      input: r.value,
      inst: e,
      continue: !t.abort
    });
  };
}), yu = /* @__PURE__ */ l("$ZodE164", (e, t) => {
  t.pattern ?? (t.pattern = Mo), U.init(e, t);
});
function sm(e, t = null) {
  try {
    let r = e.split(".");
    if (r.length !== 3)
      return !1;
    let [n] = r;
    if (!n)
      return !1;
    let o = JSON.parse(atob(n));
    return !("typ" in o && o?.typ !== "JWT" || !o.alg || t && (!("alg" in o) || o.alg !== t));
  } catch {
    return !1;
  }
}
i(sm, "isValidJWT");
var bu = /* @__PURE__ */ l("$ZodJWT", (e, t) => {
  U.init(e, t), e._zod.check = (r) => {
    sm(r.value, t.alg) || r.issues.push({
      code: "invalid_format",
      format: "jwt",
      input: r.value,
      inst: e,
      continue: !t.abort
    });
  };
}), xu = /* @__PURE__ */ l("$ZodCustomStringFormat", (e, t) => {
  U.init(e, t), e._zod.check = (r) => {
    t.fn(r.value) || r.issues.push({
      code: "invalid_format",
      format: t.format,
      input: r.value,
      inst: e,
      continue: !t.abort
    });
  };
}), St = /* @__PURE__ */ l("$ZodNumber", (e, t) => {
  _.init(e, t), e._zod.pattern = e._zod.bag.pattern ?? yr, e._zod.parse = (r, n) => {
    if (t.coerce)
      try {
        r.value = Number(r.value);
      } catch {
      }
    let o = r.value;
    if (typeof o == "number" && !Number.isNaN(o) && Number.isFinite(o))
      return r;
    let a = typeof o == "number" ? Number.isNaN(o) ? "NaN" : Number.isFinite(o) ? void 0 : "Infinity" : void 0;
    return r.issues.push({
      expected: "number",
      code: "invalid_type",
      input: o,
      inst: e,
      ...a ? { received: a } : {}
    }), r;
  };
}), _u = /* @__PURE__ */ l("$ZodNumberFormat", (e, t) => {
  bc.init(e, t), St.init(e, t);
}), Ge = /* @__PURE__ */ l("$ZodBoolean", (e, t) => {
  _.init(e, t), e._zod.pattern = Ho, e._zod.parse = (r, n) => {
    if (t.coerce)
      try {
        r.value = !!r.value;
      } catch {
      }
    let o = r.value;
    return typeof o == "boolean" || r.issues.push({
      expected: "boolean",
      code: "invalid_type",
      input: o,
      inst: e
    }), r;
  };
}), jt = /* @__PURE__ */ l("$ZodBigInt", (e, t) => {
  _.init(e, t), e._zod.pattern = Ko, e._zod.parse = (r, n) => {
    if (t.coerce)
      try {
        r.value = BigInt(r.value);
      } catch {
      }
    return typeof r.value == "bigint" || r.issues.push({
      expected: "bigint",
      code: "invalid_type",
      input: r.value,
      inst: e
    }), r;
  };
}), ku = /* @__PURE__ */ l("$ZodBigIntFormat", (e, t) => {
  xc.init(e, t), jt.init(e, t);
}), Ir = /* @__PURE__ */ l("$ZodSymbol", (e, t) => {
  _.init(e, t), e._zod.parse = (r, n) => {
    let o = r.value;
    return typeof o == "symbol" || r.issues.push({
      expected: "symbol",
      code: "invalid_type",
      input: o,
      inst: e
    }), r;
  };
}), Sr = /* @__PURE__ */ l("$ZodUndefined", (e, t) => {
  _.init(e, t), e._zod.pattern = Yo, e._zod.values = /* @__PURE__ */ new Set([void 0]), e._zod.optin = "optional", e._zod.optout = "optional", e._zod.parse = (r, n) => {
    let o = r.value;
    return typeof o > "u" || r.issues.push({
      expected: "undefined",
      code: "invalid_type",
      input: o,
      inst: e
    }), r;
  };
}), jr = /* @__PURE__ */ l("$ZodNull", (e, t) => {
  _.init(e, t), e._zod.pattern = Qo, e._zod.values = /* @__PURE__ */ new Set([null]), e._zod.parse = (r, n) => {
    let o = r.value;
    return o === null || r.issues.push({
      expected: "null",
      code: "invalid_type",
      input: o,
      inst: e
    }), r;
  };
}), Or = /* @__PURE__ */ l("$ZodAny", (e, t) => {
  _.init(e, t), e._zod.parse = (r) => r;
}), Pr = /* @__PURE__ */ l("$ZodUnknown", (e, t) => {
  _.init(e, t), e._zod.parse = (r) => r;
}), Tr = /* @__PURE__ */ l("$ZodNever", (e, t) => {
  _.init(e, t), e._zod.parse = (r, n) => (r.issues.push({
    expected: "never",
    code: "invalid_type",
    input: r.value,
    inst: e
  }), r);
}), Ur = /* @__PURE__ */ l("$ZodVoid", (e, t) => {
  _.init(e, t), e._zod.parse = (r, n) => {
    let o = r.value;
    return typeof o > "u" || r.issues.push({
      expected: "void",
      code: "invalid_type",
      input: o,
      inst: e
    }), r;
  };
}), Zr = /* @__PURE__ */ l("$ZodDate", (e, t) => {
  _.init(e, t), e._zod.parse = (r, n) => {
    if (t.coerce)
      try {
        r.value = new Date(r.value);
      } catch {
      }
    let o = r.value, a = o instanceof Date;
    return a && !Number.isNaN(o.getTime()) || r.issues.push({
      expected: "date",
      code: "invalid_type",
      input: o,
      ...a ? { received: "Invalid Date" } : {},
      inst: e
    }), r;
  };
});
function Rc(e, t, r) {
  e.issues.length && t.issues.push(...Y(r, e.issues)), t.value[r] = e.value;
}
i(Rc, "handleArrayResult");
var Er = /* @__PURE__ */ l("$ZodArray", (e, t) => {
  _.init(e, t), e._zod.parse = (r, n) => {
    let o = r.value;
    if (!Array.isArray(o))
      return r.issues.push({
        expected: "array",
        code: "invalid_type",
        input: o,
        inst: e
      }), r;
    r.value = Array(o.length);
    let a = [];
    for (let c = 0; c < o.length; c++) {
      let u = o[c], s = t.element._zod.run({
        value: u,
        issues: []
      }, n);
      s instanceof Promise ? a.push(s.then((d) => Rc(d, r, c))) : Rc(s, r, c);
    }
    return a.length ? Promise.all(a).then(() => r) : r;
  };
});
function zr(e, t, r, n, o) {
  if (e.issues.length) {
    if (o && !(r in n))
      return;
    t.issues.push(...Y(r, e.issues));
  }
  e.value === void 0 ? r in n && (t.value[r] = void 0) : t.value[r] = e.value;
}
i(zr, "handlePropertyResult");
function wu(e) {
  let t = Object.keys(e.shape);
  for (let n of t)
    if (!e.shape?.[n]?._zod?.traits?.has("$ZodType"))
      throw new Error(`Invalid element at key "${n}": expected a Zod schema`);
  let r = xo(e.shape);
  return {
    ...e,
    keys: t,
    keySet: new Set(t),
    numKeys: t.length,
    optionalKeys: new Set(r)
  };
}
i(wu, "normalizeDef");
function zu(e, t, r, n, o, a) {
  let c = [], u = o.keySet, s = o.catchall._zod, d = s.def.type, f = s.optout === "optional";
  for (let g in t) {
    if (u.has(g))
      continue;
    if (d === "never") {
      c.push(g);
      continue;
    }
    let $ = s.run({ value: t[g], issues: [] }, n);
    $ instanceof Promise ? e.push($.then((h) => zr(h, r, g, t, f))) : zr($, r, g, t, f);
  }
  return c.length && r.issues.push({
    code: "unrecognized_keys",
    keys: c,
    input: t,
    inst: a
  }), e.length ? Promise.all(e).then(() => r) : r;
}
i(zu, "handleCatchall");
var Nr = /* @__PURE__ */ l("$ZodObject", (e, t) => {
  if (_.init(e, t), !Object.getOwnPropertyDescriptor(t, "shape")?.get) {
    let u = t.shape;
    Object.defineProperty(t, "shape", {
      get: /* @__PURE__ */ i(() => {
        let s = { ...u };
        return Object.defineProperty(t, "shape", {
          value: s
        }), s;
      }, "get")
    });
  }
  let n = Be(() => wu(t));
  I(e._zod, "propValues", () => {
    let u = t.shape, s = {};
    for (let d in u) {
      let f = u[d]._zod;
      if (f.values) {
        s[d] ?? (s[d] = /* @__PURE__ */ new Set());
        for (let g of f.values)
          s[d].add(g);
      }
    }
    return s;
  });
  let o = Pe, a = t.catchall, c;
  e._zod.parse = (u, s) => {
    c ?? (c = n.value);
    let d = u.value;
    if (!o(d))
      return u.issues.push({
        expected: "object",
        code: "invalid_type",
        input: d,
        inst: e
      }), u;
    u.value = {};
    let f = [], g = c.shape;
    for (let $ of c.keys) {
      let h = g[$], T = h._zod.optout === "optional", z = h._zod.run({ value: d[$], issues: [] }, s);
      z instanceof Promise ? f.push(z.then((F) => zr(F, u, $, d, T))) : zr(z, u, $, d, T);
    }
    return a ? zu(f, d, u, s, n.value, e) : f.length ? Promise.all(f).then(() => u) : u;
  };
}), Iu = /* @__PURE__ */ l("$ZodObjectJIT", (e, t) => {
  Nr.init(e, t);
  let r = e._zod.parse, n = Be(() => wu(t)), o = /* @__PURE__ */ i(($) => {
    let h = new br(["shape", "payload", "ctx"]), T = n.value, z = /* @__PURE__ */ i((L) => {
      let C = gr(L);
      return `shape[${C}]._zod.run({ value: input[${C}], issues: [] }, ctx)`;
    }, "parseStr");
    h.write("const input = payload.value;");
    let F = /* @__PURE__ */ Object.create(null), ie = 0;
    for (let L of T.keys)
      F[L] = `key_${ie++}`;
    h.write("const newResult = {};");
    for (let L of T.keys) {
      let C = F[L], q = gr(L), S = $[L]?._zod?.optout === "optional";
      h.write(`const ${C} = ${z(L)};`), S ? h.write(`
        if (${C}.issues.length) {
          if (${q} in input) {
            payload.issues = payload.issues.concat(${C}.issues.map(iss => ({
              ...iss,
              path: iss.path ? [${q}, ...iss.path] : [${q}]
            })));
          }
        }
        
        if (${C}.value === undefined) {
          if (${q} in input) {
            newResult[${q}] = undefined;
          }
        } else {
          newResult[${q}] = ${C}.value;
        }
        
      `) : h.write(`
        if (${C}.issues.length) {
          payload.issues = payload.issues.concat(${C}.issues.map(iss => ({
            ...iss,
            path: iss.path ? [${q}, ...iss.path] : [${q}]
          })));
        }
        
        if (${C}.value === undefined) {
          if (${q} in input) {
            newResult[${q}] = undefined;
          }
        } else {
          newResult[${q}] = ${C}.value;
        }
        
      `);
    }
    h.write("payload.value = newResult;"), h.write("return payload;");
    let H = h.compile();
    return (L, C) => H($, L, C);
  }, "generateFastpass"), a, c = Pe, u = !pr.jitless, d = u && yo.value, f = t.catchall, g;
  e._zod.parse = ($, h) => {
    g ?? (g = n.value);
    let T = $.value;
    return c(T) ? u && d && h?.async === !1 && h.jitless !== !0 ? (a || (a = o(t.shape)), $ = a($, h), f ? zu([], T, $, h, g, e) : $) : r($, h) : ($.issues.push({
      expected: "object",
      code: "invalid_type",
      input: T,
      inst: e
    }), $);
  };
});
function Fc(e, t, r, n) {
  for (let a of e)
    if (a.issues.length === 0)
      return t.value = a.value, t;
  let o = e.filter((a) => !ye(a));
  return o.length === 1 ? (t.value = o[0].value, o[0]) : (t.issues.push({
    code: "invalid_union",
    input: t.value,
    inst: r,
    errors: e.map((a) => a.issues.map((c) => K(c, n, B())))
  }), t);
}
i(Fc, "handleUnionResults");
var We = /* @__PURE__ */ l("$ZodUnion", (e, t) => {
  _.init(e, t), I(e._zod, "optin", () => t.options.some((o) => o._zod.optin === "optional") ? "optional" : void 0), I(e._zod, "optout", () => t.options.some((o) => o._zod.optout === "optional") ? "optional" : void 0), I(e._zod, "values", () => {
    if (t.options.every((o) => o._zod.values))
      return new Set(t.options.flatMap((o) => Array.from(o._zod.values)));
  }), I(e._zod, "pattern", () => {
    if (t.options.every((o) => o._zod.pattern)) {
      let o = t.options.map((a) => a._zod.pattern);
      return new RegExp(`^(${o.map((a) => gt(a.source)).join("|")})$`);
    }
  });
  let r = t.options.length === 1, n = t.options[0]._zod.run;
  e._zod.parse = (o, a) => {
    if (r)
      return n(o, a);
    let c = !1, u = [];
    for (let s of t.options) {
      let d = s._zod.run({
        value: o.value,
        issues: []
      }, a);
      if (d instanceof Promise)
        u.push(d), c = !0;
      else {
        if (d.issues.length === 0)
          return d;
        u.push(d);
      }
    }
    return c ? Promise.all(u).then((s) => Fc(s, o, e, a)) : Fc(u, o, e, a);
  };
});
function Lc(e, t, r, n) {
  let o = e.filter((a) => a.issues.length === 0);
  return o.length === 1 ? (t.value = o[0].value, t) : (o.length === 0 ? t.issues.push({
    code: "invalid_union",
    input: t.value,
    inst: r,
    errors: e.map((a) => a.issues.map((c) => K(c, n, B())))
  }) : t.issues.push({
    code: "invalid_union",
    input: t.value,
    inst: r,
    errors: [],
    inclusive: !1
  }), t);
}
i(Lc, "handleExclusiveUnionResults");
var Su = /* @__PURE__ */ l("$ZodXor", (e, t) => {
  We.init(e, t), t.inclusive = !1;
  let r = t.options.length === 1, n = t.options[0]._zod.run;
  e._zod.parse = (o, a) => {
    if (r)
      return n(o, a);
    let c = !1, u = [];
    for (let s of t.options) {
      let d = s._zod.run({
        value: o.value,
        issues: []
      }, a);
      d instanceof Promise ? (u.push(d), c = !0) : u.push(d);
    }
    return c ? Promise.all(u).then((s) => Lc(s, o, e, a)) : Lc(u, o, e, a);
  };
}), ju = /* @__PURE__ */ l("$ZodDiscriminatedUnion", (e, t) => {
  t.inclusive = !1, We.init(e, t);
  let r = e._zod.parse;
  I(e._zod, "propValues", () => {
    let o = {};
    for (let a of t.options) {
      let c = a._zod.propValues;
      if (!c || Object.keys(c).length === 0)
        throw new Error(`Invalid discriminated union option at index "${t.options.indexOf(a)}"`);
      for (let [u, s] of Object.entries(c)) {
        o[u] || (o[u] = /* @__PURE__ */ new Set());
        for (let d of s)
          o[u].add(d);
      }
    }
    return o;
  });
  let n = Be(() => {
    let o = t.options, a = /* @__PURE__ */ new Map();
    for (let c of o) {
      let u = c._zod.propValues?.[t.discriminator];
      if (!u || u.size === 0)
        throw new Error(`Invalid discriminated union option at index "${t.options.indexOf(c)}"`);
      for (let s of u) {
        if (a.has(s))
          throw new Error(`Duplicate discriminator value "${String(s)}"`);
        a.set(s, c);
      }
    }
    return a;
  });
  e._zod.parse = (o, a) => {
    let c = o.value;
    if (!Pe(c))
      return o.issues.push({
        code: "invalid_type",
        expected: "object",
        input: c,
        inst: e
      }), o;
    let u = n.value.get(c?.[t.discriminator]);
    return u ? u._zod.run(o, a) : t.unionFallback ? r(o, a) : (o.issues.push({
      code: "invalid_union",
      errors: [],
      note: "No matching discriminator",
      discriminator: t.discriminator,
      input: c,
      path: [t.discriminator],
      inst: e
    }), o);
  };
}), Dr = /* @__PURE__ */ l("$ZodIntersection", (e, t) => {
  _.init(e, t), e._zod.parse = (r, n) => {
    let o = r.value, a = t.left._zod.run({ value: o, issues: [] }, n), c = t.right._zod.run({ value: o, issues: [] }, n);
    return a instanceof Promise || c instanceof Promise ? Promise.all([a, c]).then(([s, d]) => Jc(r, s, d)) : Jc(r, a, c);
  };
});
function oi(e, t) {
  if (e === t)
    return { valid: !0, data: e };
  if (e instanceof Date && t instanceof Date && +e == +t)
    return { valid: !0, data: e };
  if ($e(e) && $e(t)) {
    let r = Object.keys(t), n = Object.keys(e).filter((a) => r.indexOf(a) !== -1), o = { ...e, ...t };
    for (let a of n) {
      let c = oi(e[a], t[a]);
      if (!c.valid)
        return {
          valid: !1,
          mergeErrorPath: [a, ...c.mergeErrorPath]
        };
      o[a] = c.data;
    }
    return { valid: !0, data: o };
  }
  if (Array.isArray(e) && Array.isArray(t)) {
    if (e.length !== t.length)
      return { valid: !1, mergeErrorPath: [] };
    let r = [];
    for (let n = 0; n < e.length; n++) {
      let o = e[n], a = t[n], c = oi(o, a);
      if (!c.valid)
        return {
          valid: !1,
          mergeErrorPath: [n, ...c.mergeErrorPath]
        };
      r.push(c.data);
    }
    return { valid: !0, data: r };
  }
  return { valid: !1, mergeErrorPath: [] };
}
i(oi, "mergeValues");
function Jc(e, t, r) {
  let n = /* @__PURE__ */ new Map(), o;
  for (let u of t.issues)
    if (u.code === "unrecognized_keys") {
      o ?? (o = u);
      for (let s of u.keys)
        n.has(s) || n.set(s, {}), n.get(s).l = !0;
    } else
      e.issues.push(u);
  for (let u of r.issues)
    if (u.code === "unrecognized_keys")
      for (let s of u.keys)
        n.has(s) || n.set(s, {}), n.get(s).r = !0;
    else
      e.issues.push(u);
  let a = [...n].filter(([, u]) => u.l && u.r).map(([u]) => u);
  if (a.length && o && e.issues.push({ ...o, keys: a }), ye(e))
    return e;
  let c = oi(t.value, r.value);
  if (!c.valid)
    throw new Error(`Unmergable intersection. Error path: ${JSON.stringify(c.mergeErrorPath)}`);
  return e.value = c.data, e;
}
i(Jc, "handleIntersectionResults");
var Ot = /* @__PURE__ */ l("$ZodTuple", (e, t) => {
  _.init(e, t);
  let r = t.items;
  e._zod.parse = (n, o) => {
    let a = n.value;
    if (!Array.isArray(a))
      return n.issues.push({
        input: a,
        inst: e,
        expected: "tuple",
        code: "invalid_type"
      }), n;
    n.value = [];
    let c = [], u = [...r].reverse().findIndex((f) => f._zod.optin !== "optional"), s = u === -1 ? 0 : r.length - u;
    if (!t.rest) {
      let f = a.length > r.length, g = a.length < s - 1;
      if (f || g)
        return n.issues.push({
          ...f ? { code: "too_big", maximum: r.length, inclusive: !0 } : { code: "too_small", minimum: r.length },
          input: a,
          inst: e,
          origin: "array"
        }), n;
    }
    let d = -1;
    for (let f of r) {
      if (d++, d >= a.length && d >= s)
        continue;
      let g = f._zod.run({
        value: a[d],
        issues: []
      }, o);
      g instanceof Promise ? c.push(g.then(($) => xr($, n, d))) : xr(g, n, d);
    }
    if (t.rest) {
      let f = a.slice(r.length);
      for (let g of f) {
        d++;
        let $ = t.rest._zod.run({
          value: g,
          issues: []
        }, o);
        $ instanceof Promise ? c.push($.then((h) => xr(h, n, d))) : xr($, n, d);
      }
    }
    return c.length ? Promise.all(c).then(() => n) : n;
  };
});
function xr(e, t, r) {
  e.issues.length && t.issues.push(...Y(r, e.issues)), t.value[r] = e.value;
}
i(xr, "handleTupleResult");
var Ar = /* @__PURE__ */ l("$ZodRecord", (e, t) => {
  _.init(e, t), e._zod.parse = (r, n) => {
    let o = r.value;
    if (!$e(o))
      return r.issues.push({
        expected: "record",
        code: "invalid_type",
        input: o,
        inst: e
      }), r;
    let a = [], c = t.keyType._zod.values;
    if (c) {
      r.value = {};
      let u = /* @__PURE__ */ new Set();
      for (let d of c)
        if (typeof d == "string" || typeof d == "number" || typeof d == "symbol") {
          u.add(typeof d == "number" ? d.toString() : d);
          let f = t.valueType._zod.run({ value: o[d], issues: [] }, n);
          f instanceof Promise ? a.push(f.then((g) => {
            g.issues.length && r.issues.push(...Y(d, g.issues)), r.value[d] = g.value;
          })) : (f.issues.length && r.issues.push(...Y(d, f.issues)), r.value[d] = f.value);
        }
      let s;
      for (let d in o)
        u.has(d) || (s = s ?? [], s.push(d));
      s && s.length > 0 && r.issues.push({
        code: "unrecognized_keys",
        input: o,
        inst: e,
        keys: s
      });
    } else {
      r.value = {};
      for (let u of Reflect.ownKeys(o)) {
        if (u === "__proto__")
          continue;
        let s = t.keyType._zod.run({ value: u, issues: [] }, n);
        if (s instanceof Promise)
          throw new Error("Async schemas not supported in object keys currently");
        if (typeof u == "string" && yr.test(u) && s.issues.length) {
          let g = t.keyType._zod.run({ value: Number(u), issues: [] }, n);
          if (g instanceof Promise)
            throw new Error("Async schemas not supported in object keys currently");
          g.issues.length === 0 && (s = g);
        }
        if (s.issues.length) {
          t.mode === "loose" ? r.value[u] = o[u] : r.issues.push({
            code: "invalid_key",
            origin: "record",
            issues: s.issues.map((g) => K(g, n, B())),
            input: u,
            path: [u],
            inst: e
          });
          continue;
        }
        let f = t.valueType._zod.run({ value: o[u], issues: [] }, n);
        f instanceof Promise ? a.push(f.then((g) => {
          g.issues.length && r.issues.push(...Y(u, g.issues)), r.value[s.value] = g.value;
        })) : (f.issues.length && r.issues.push(...Y(u, f.issues)), r.value[s.value] = f.value);
      }
    }
    return a.length ? Promise.all(a).then(() => r) : r;
  };
}), Cr = /* @__PURE__ */ l("$ZodMap", (e, t) => {
  _.init(e, t), e._zod.parse = (r, n) => {
    let o = r.value;
    if (!(o instanceof Map))
      return r.issues.push({
        expected: "map",
        code: "invalid_type",
        input: o,
        inst: e
      }), r;
    let a = [];
    r.value = /* @__PURE__ */ new Map();
    for (let [c, u] of o) {
      let s = t.keyType._zod.run({ value: c, issues: [] }, n), d = t.valueType._zod.run({ value: u, issues: [] }, n);
      s instanceof Promise || d instanceof Promise ? a.push(Promise.all([s, d]).then(([f, g]) => {
        Vc(f, g, r, c, o, e, n);
      })) : Vc(s, d, r, c, o, e, n);
    }
    return a.length ? Promise.all(a).then(() => r) : r;
  };
});
function Vc(e, t, r, n, o, a, c) {
  e.issues.length && (ht.has(typeof n) ? r.issues.push(...Y(n, e.issues)) : r.issues.push({
    code: "invalid_key",
    origin: "map",
    input: o,
    inst: a,
    issues: e.issues.map((u) => K(u, c, B()))
  })), t.issues.length && (ht.has(typeof n) ? r.issues.push(...Y(n, t.issues)) : r.issues.push({
    origin: "map",
    code: "invalid_element",
    input: o,
    inst: a,
    key: n,
    issues: t.issues.map((u) => K(u, c, B()))
  })), r.value.set(e.value, t.value);
}
i(Vc, "handleMapResult");
var Rr = /* @__PURE__ */ l("$ZodSet", (e, t) => {
  _.init(e, t), e._zod.parse = (r, n) => {
    let o = r.value;
    if (!(o instanceof Set))
      return r.issues.push({
        input: o,
        inst: e,
        expected: "set",
        code: "invalid_type"
      }), r;
    let a = [];
    r.value = /* @__PURE__ */ new Set();
    for (let c of o) {
      let u = t.valueType._zod.run({ value: c, issues: [] }, n);
      u instanceof Promise ? a.push(u.then((s) => Mc(s, r))) : Mc(u, r);
    }
    return a.length ? Promise.all(a).then(() => r) : r;
  };
});
function Mc(e, t) {
  e.issues.length && t.issues.push(...e.issues), t.value.add(e.value);
}
i(Mc, "handleSetResult");
var Fr = /* @__PURE__ */ l("$ZodEnum", (e, t) => {
  _.init(e, t);
  let r = pt(t.entries), n = new Set(r);
  e._zod.values = n, e._zod.pattern = new RegExp(`^(${r.filter((o) => ht.has(typeof o)).map((o) => typeof o == "string" ? oe(o) : o.toString()).join("|")})$`), e._zod.parse = (o, a) => {
    let c = o.value;
    return n.has(c) || o.issues.push({
      code: "invalid_value",
      values: r,
      input: c,
      inst: e
    }), o;
  };
}), Lr = /* @__PURE__ */ l("$ZodLiteral", (e, t) => {
  if (_.init(e, t), t.values.length === 0)
    throw new Error("Cannot create literal schema with no valid values");
  let r = new Set(t.values);
  e._zod.values = r, e._zod.pattern = new RegExp(`^(${t.values.map((n) => typeof n == "string" ? oe(n) : n ? oe(n.toString()) : String(n)).join("|")})$`), e._zod.parse = (n, o) => {
    let a = n.value;
    return r.has(a) || n.issues.push({
      code: "invalid_value",
      values: t.values,
      input: a,
      inst: e
    }), n;
  };
}), Jr = /* @__PURE__ */ l("$ZodFile", (e, t) => {
  _.init(e, t), e._zod.parse = (r, n) => {
    let o = r.value;
    return o instanceof File || r.issues.push({
      expected: "file",
      code: "invalid_type",
      input: o,
      inst: e
    }), r;
  };
}), Vr = /* @__PURE__ */ l("$ZodTransform", (e, t) => {
  _.init(e, t), e._zod.parse = (r, n) => {
    if (n.direction === "backward")
      throw new Oe(e.constructor.name);
    let o = t.transform(r.value, r);
    if (n.async)
      return (o instanceof Promise ? o : Promise.resolve(o)).then((c) => (r.value = c, r));
    if (o instanceof Promise)
      throw new le();
    return r.value = o, r;
  };
});
function Bc(e, t) {
  return e.issues.length && t === void 0 ? { issues: [], value: void 0 } : e;
}
i(Bc, "handleOptionalResult");
var Pt = /* @__PURE__ */ l("$ZodOptional", (e, t) => {
  _.init(e, t), e._zod.optin = "optional", e._zod.optout = "optional", I(e._zod, "values", () => t.innerType._zod.values ? /* @__PURE__ */ new Set([...t.innerType._zod.values, void 0]) : void 0), I(e._zod, "pattern", () => {
    let r = t.innerType._zod.pattern;
    return r ? new RegExp(`^(${gt(r.source)})?$`) : void 0;
  }), e._zod.parse = (r, n) => {
    if (t.innerType._zod.optin === "optional") {
      let o = t.innerType._zod.run(r, n);
      return o instanceof Promise ? o.then((a) => Bc(a, r.value)) : Bc(o, r.value);
    }
    return r.value === void 0 ? r : t.innerType._zod.run(r, n);
  };
}), Ou = /* @__PURE__ */ l("$ZodExactOptional", (e, t) => {
  Pt.init(e, t), I(e._zod, "values", () => t.innerType._zod.values), I(e._zod, "pattern", () => t.innerType._zod.pattern), e._zod.parse = (r, n) => t.innerType._zod.run(r, n);
}), Mr = /* @__PURE__ */ l("$ZodNullable", (e, t) => {
  _.init(e, t), I(e._zod, "optin", () => t.innerType._zod.optin), I(e._zod, "optout", () => t.innerType._zod.optout), I(e._zod, "pattern", () => {
    let r = t.innerType._zod.pattern;
    return r ? new RegExp(`^(${gt(r.source)}|null)$`) : void 0;
  }), I(e._zod, "values", () => t.innerType._zod.values ? /* @__PURE__ */ new Set([...t.innerType._zod.values, null]) : void 0), e._zod.parse = (r, n) => r.value === null ? r : t.innerType._zod.run(r, n);
}), Tt = /* @__PURE__ */ l("$ZodDefault", (e, t) => {
  _.init(e, t), e._zod.optin = "optional", I(e._zod, "values", () => t.innerType._zod.values), e._zod.parse = (r, n) => {
    if (n.direction === "backward")
      return t.innerType._zod.run(r, n);
    if (r.value === void 0)
      return r.value = t.defaultValue, r;
    let o = t.innerType._zod.run(r, n);
    return o instanceof Promise ? o.then((a) => qc(a, t)) : qc(o, t);
  };
});
function qc(e, t) {
  return e.value === void 0 && (e.value = t.defaultValue), e;
}
i(qc, "handleDefaultResult");
var Pu = /* @__PURE__ */ l("$ZodPrefault", (e, t) => {
  _.init(e, t), e._zod.optin = "optional", I(e._zod, "values", () => t.innerType._zod.values), e._zod.parse = (r, n) => (n.direction === "backward" || r.value === void 0 && (r.value = t.defaultValue), t.innerType._zod.run(r, n));
}), Br = /* @__PURE__ */ l("$ZodNonOptional", (e, t) => {
  _.init(e, t), I(e._zod, "values", () => {
    let r = t.innerType._zod.values;
    return r ? new Set([...r].filter((n) => n !== void 0)) : void 0;
  }), e._zod.parse = (r, n) => {
    let o = t.innerType._zod.run(r, n);
    return o instanceof Promise ? o.then((a) => Gc(a, e)) : Gc(o, e);
  };
});
function Gc(e, t) {
  return !e.issues.length && e.value === void 0 && e.issues.push({
    code: "invalid_type",
    expected: "nonoptional",
    input: e.value,
    inst: t
  }), e;
}
i(Gc, "handleNonOptionalResult");
var Tu = /* @__PURE__ */ l("$ZodSuccess", (e, t) => {
  _.init(e, t), e._zod.parse = (r, n) => {
    if (n.direction === "backward")
      throw new Oe("ZodSuccess");
    let o = t.innerType._zod.run(r, n);
    return o instanceof Promise ? o.then((a) => (r.value = a.issues.length === 0, r)) : (r.value = o.issues.length === 0, r);
  };
}), qr = /* @__PURE__ */ l("$ZodCatch", (e, t) => {
  _.init(e, t), I(e._zod, "optin", () => t.innerType._zod.optin), I(e._zod, "optout", () => t.innerType._zod.optout), I(e._zod, "values", () => t.innerType._zod.values), e._zod.parse = (r, n) => {
    if (n.direction === "backward")
      return t.innerType._zod.run(r, n);
    let o = t.innerType._zod.run(r, n);
    return o instanceof Promise ? o.then((a) => (r.value = a.value, a.issues.length && (r.value = t.catchValue({
      ...r,
      error: {
        issues: a.issues.map((c) => K(c, n, B()))
      },
      input: r.value
    }), r.issues = []), r)) : (r.value = o.value, o.issues.length && (r.value = t.catchValue({
      ...r,
      error: {
        issues: o.issues.map((a) => K(a, n, B()))
      },
      input: r.value
    }), r.issues = []), r);
  };
}), Gr = /* @__PURE__ */ l("$ZodNaN", (e, t) => {
  _.init(e, t), e._zod.parse = (r, n) => ((typeof r.value != "number" || !Number.isNaN(r.value)) && r.issues.push({
    input: r.value,
    inst: e,
    expected: "nan",
    code: "invalid_type"
  }), r);
}), Ut = /* @__PURE__ */ l("$ZodPipe", (e, t) => {
  _.init(e, t), I(e._zod, "values", () => t.in._zod.values), I(e._zod, "optin", () => t.in._zod.optin), I(e._zod, "optout", () => t.out._zod.optout), I(e._zod, "propValues", () => t.in._zod.propValues), e._zod.parse = (r, n) => {
    if (n.direction === "backward") {
      let a = t.out._zod.run(r, n);
      return a instanceof Promise ? a.then((c) => _r(c, t.in, n)) : _r(a, t.in, n);
    }
    let o = t.in._zod.run(r, n);
    return o instanceof Promise ? o.then((a) => _r(a, t.out, n)) : _r(o, t.out, n);
  };
});
function _r(e, t, r) {
  return e.issues.length ? (e.aborted = !0, e) : t._zod.run({ value: e.value, issues: e.issues }, r);
}
i(_r, "handlePipeResult");
var Wr = /* @__PURE__ */ l("$ZodCodec", (e, t) => {
  _.init(e, t), I(e._zod, "values", () => t.in._zod.values), I(e._zod, "optin", () => t.in._zod.optin), I(e._zod, "optout", () => t.out._zod.optout), I(e._zod, "propValues", () => t.in._zod.propValues), e._zod.parse = (r, n) => {
    if ((n.direction || "forward") === "forward") {
      let a = t.in._zod.run(r, n);
      return a instanceof Promise ? a.then((c) => kr(c, t, n)) : kr(a, t, n);
    } else {
      let a = t.out._zod.run(r, n);
      return a instanceof Promise ? a.then((c) => kr(c, t, n)) : kr(a, t, n);
    }
  };
});
function kr(e, t, r) {
  if (e.issues.length)
    return e.aborted = !0, e;
  if ((r.direction || "forward") === "forward") {
    let o = t.transform(e.value, e);
    return o instanceof Promise ? o.then((a) => wr(e, a, t.out, r)) : wr(e, o, t.out, r);
  } else {
    let o = t.reverseTransform(e.value, e);
    return o instanceof Promise ? o.then((a) => wr(e, a, t.in, r)) : wr(e, o, t.in, r);
  }
}
i(kr, "handleCodecAResult");
function wr(e, t, r, n) {
  return e.issues.length ? (e.aborted = !0, e) : r._zod.run({ value: t, issues: e.issues }, n);
}
i(wr, "handleCodecTxResult");
var Kr = /* @__PURE__ */ l("$ZodReadonly", (e, t) => {
  _.init(e, t), I(e._zod, "propValues", () => t.innerType._zod.propValues), I(e._zod, "values", () => t.innerType._zod.values), I(e._zod, "optin", () => t.innerType?._zod?.optin), I(e._zod, "optout", () => t.innerType?._zod?.optout), e._zod.parse = (r, n) => {
    if (n.direction === "backward")
      return t.innerType._zod.run(r, n);
    let o = t.innerType._zod.run(r, n);
    return o instanceof Promise ? o.then(Wc) : Wc(o);
  };
});
function Wc(e) {
  return e.value = Object.freeze(e.value), e;
}
i(Wc, "handleReadonlyResult");
var Xr = /* @__PURE__ */ l("$ZodTemplateLiteral", (e, t) => {
  _.init(e, t);
  let r = [];
  for (let n of t.parts)
    if (typeof n == "object" && n !== null) {
      if (!n._zod.pattern)
        throw new Error(`Invalid template literal part, no pattern found: ${[...n._zod.traits].shift()}`);
      let o = n._zod.pattern instanceof RegExp ? n._zod.pattern.source : n._zod.pattern;
      if (!o)
        throw new Error(`Invalid template literal part: ${n._zod.traits}`);
      let a = o.startsWith("^") ? 1 : 0, c = o.endsWith("$") ? o.length - 1 : o.length;
      r.push(o.slice(a, c));
    } else if (n === null || bo.has(typeof n))
      r.push(oe(`${n}`));
    else
      throw new Error(`Invalid template literal part: ${n}`);
  e._zod.pattern = new RegExp(`^${r.join("")}$`), e._zod.parse = (n, o) => typeof n.value != "string" ? (n.issues.push({
    input: n.value,
    inst: e,
    expected: "string",
    code: "invalid_type"
  }), n) : (e._zod.pattern.lastIndex = 0, e._zod.pattern.test(n.value) || n.issues.push({
    input: n.value,
    inst: e,
    code: "invalid_format",
    format: t.format ?? "template_literal",
    pattern: e._zod.pattern.source
  }), n);
}), Hr = /* @__PURE__ */ l("$ZodFunction", (e, t) => (_.init(e, t), e._def = t, e._zod.def = t, e.implement = (r) => {
  if (typeof r != "function")
    throw new Error("implement() must be called with a function");
  return function(...n) {
    let o = e._def.input ? Io(e._def.input, n) : n, a = Reflect.apply(r, this, o);
    return e._def.output ? Io(e._def.output, a) : a;
  };
}, e.implementAsync = (r) => {
  if (typeof r != "function")
    throw new Error("implementAsync() must be called with a function");
  return async function(...n) {
    let o = e._def.input ? await So(e._def.input, n) : n, a = await Reflect.apply(r, this, o);
    return e._def.output ? await So(e._def.output, a) : a;
  };
}, e._zod.parse = (r, n) => typeof r.value != "function" ? (r.issues.push({
  code: "invalid_type",
  expected: "function",
  input: r.value,
  inst: e
}), r) : (e._def.output && e._def.output._zod.def.type === "promise" ? r.value = e.implementAsync(r.value) : r.value = e.implement(r.value), r), e.input = (...r) => {
  let n = e.constructor;
  return Array.isArray(r[0]) ? new n({
    type: "function",
    input: new Ot({
      type: "tuple",
      items: r[0],
      rest: r[1]
    }),
    output: e._def.output
  }) : new n({
    type: "function",
    input: r[0],
    output: e._def.output
  });
}, e.output = (r) => {
  let n = e.constructor;
  return new n({
    type: "function",
    input: e._def.input,
    output: r
  });
}, e)), Qr = /* @__PURE__ */ l("$ZodPromise", (e, t) => {
  _.init(e, t), e._zod.parse = (r, n) => Promise.resolve(r.value).then((o) => t.innerType._zod.run({ value: o, issues: [] }, n));
}), Yr = /* @__PURE__ */ l("$ZodLazy", (e, t) => {
  _.init(e, t), I(e._zod, "innerType", () => t.getter()), I(e._zod, "pattern", () => e._zod.innerType?._zod?.pattern), I(e._zod, "propValues", () => e._zod.innerType?._zod?.propValues), I(e._zod, "optin", () => e._zod.innerType?._zod?.optin ?? void 0), I(e._zod, "optout", () => e._zod.innerType?._zod?.optout ?? void 0), e._zod.parse = (r, n) => e._zod.innerType._zod.run(r, n);
}), en = /* @__PURE__ */ l("$ZodCustom", (e, t) => {
  E.init(e, t), _.init(e, t), e._zod.parse = (r, n) => r, e._zod.check = (r) => {
    let n = r.value, o = t.fn(n);
    if (o instanceof Promise)
      return o.then((a) => Kc(a, r, n, e));
    Kc(o, r, n, e);
  };
});
function Kc(e, t, r, n) {
  if (!e) {
    let o = {
      code: "custom",
      input: r,
      inst: n,
      // incorporates params.error into issue reporting
      path: [...n._zod.def.path ?? []],
      // incorporates params.error into issue reporting
      continue: !n._zod.def.abort
      // params: inst._zod.def.params,
    };
    n._zod.def.params && (o.params = n._zod.def.params), t.issues.push(qe(o));
  }
}
i(Kc, "handleRefineResult");

// versions/4.3.6/node_modules/zod/v4/locales/en.js
var dm = /* @__PURE__ */ i(() => {
  let e = {
    string: { unit: "characters", verb: "to have" },
    file: { unit: "bytes", verb: "to have" },
    array: { unit: "items", verb: "to have" },
    set: { unit: "items", verb: "to have" },
    map: { unit: "entries", verb: "to have" }
  };
  function t(o) {
    return e[o] ?? null;
  }
  i(t, "getSizing");
  let r = {
    regex: "input",
    email: "email address",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datetime",
    date: "ISO date",
    time: "ISO time",
    duration: "ISO duration",
    ipv4: "IPv4 address",
    ipv6: "IPv6 address",
    mac: "MAC address",
    cidrv4: "IPv4 range",
    cidrv6: "IPv6 range",
    base64: "base64-encoded string",
    base64url: "base64url-encoded string",
    json_string: "JSON string",
    e164: "E.164 number",
    jwt: "JWT",
    template_literal: "input"
  }, n = {
    // Compatibility: "nan" -> "NaN" for display
    nan: "NaN"
    // All other type names omitted - they fall back to raw values via ?? operator
  };
  return (o) => {
    switch (o.code) {
      case "invalid_type": {
        let a = n[o.expected] ?? o.expected, c = x(o.input), u = n[c] ?? c;
        return `Invalid input: expected ${a}, received ${u}`;
      }
      case "invalid_value":
        return o.values.length === 1 ? `Invalid input: expected ${b(o.values[0])}` : `Invalid option: expected one of ${y(o.values, "|")}`;
      case "too_big": {
        let a = o.inclusive ? "<=" : "<", c = t(o.origin);
        return c ? `Too big: expected ${o.origin ?? "value"} to have ${a}${o.maximum.toString()} ${c.unit ?? "elements"}` : `Too big: expected ${o.origin ?? "value"} to be ${a}${o.maximum.toString()}`;
      }
      case "too_small": {
        let a = o.inclusive ? ">=" : ">", c = t(o.origin);
        return c ? `Too small: expected ${o.origin} to have ${a}${o.minimum.toString()} ${c.unit}` : `Too small: expected ${o.origin} to be ${a}${o.minimum.toString()}`;
      }
      case "invalid_format": {
        let a = o;
        return a.format === "starts_with" ? `Invalid string: must start with "${a.prefix}"` : a.format === "ends_with" ? `Invalid string: must end with "${a.suffix}"` : a.format === "includes" ? `Invalid string: must include "${a.includes}"` : a.format === "regex" ? `Invalid string: must match pattern ${a.pattern}` : `Invalid ${r[a.format] ?? o.format}`;
      }
      case "not_multiple_of":
        return `Invalid number: must be a multiple of ${o.divisor}`;
      case "unrecognized_keys":
        return `Unrecognized key${o.keys.length > 1 ? "s" : ""}: ${y(o.keys, ", ")}`;
      case "invalid_key":
        return `Invalid key in ${o.origin}`;
      case "invalid_union":
        return "Invalid input";
      case "invalid_element":
        return `Invalid value in ${o.origin}`;
      default:
        return "Invalid input";
    }
  };
}, "error");
function tn() {
  return {
    localeError: dm()
  };
}
i(tn, "default");

// versions/4.3.6/node_modules/zod/v4/core/registries.js
var Zu, pm = Symbol("ZodOutput"), gm = Symbol("ZodInput"), ii = class {
  static {
    i(this, "$ZodRegistry");
  }
  constructor() {
    this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map();
  }
  add(t, ...r) {
    let n = r[0];
    return this._map.set(t, n), n && typeof n == "object" && "id" in n && this._idmap.set(n.id, t), this;
  }
  clear() {
    return this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map(), this;
  }
  remove(t) {
    let r = this._map.get(t);
    return r && typeof r == "object" && "id" in r && this._idmap.delete(r.id), this._map.delete(t), this;
  }
  get(t) {
    let r = t._zod.parent;
    if (r) {
      let n = { ...this.get(r) ?? {} };
      delete n.id;
      let o = { ...n, ...this._map.get(t) };
      return Object.keys(o).length ? o : void 0;
    }
    return this._map.get(t);
  }
  has(t) {
    return this._map.has(t);
  }
};
function rn() {
  return new ii();
}
i(rn, "registry");
(Zu = globalThis).__zod_globalRegistry ?? (Zu.__zod_globalRegistry = rn());
var X = globalThis.__zod_globalRegistry;

// versions/4.3.6/node_modules/zod/v4/core/api.js
// @__NO_SIDE_EFFECTS__
function Eu(e, t) {
  return new e({
    type: "string",
    ...v(t)
  });
}
i(Eu, "_string");
// @__NO_SIDE_EFFECTS__
function ai(e, t) {
  return new e({
    type: "string",
    format: "email",
    check: "string_format",
    abort: !1,
    ...v(t)
  });
}
i(ai, "_email");
// @__NO_SIDE_EFFECTS__
function nn(e, t) {
  return new e({
    type: "string",
    format: "guid",
    check: "string_format",
    abort: !1,
    ...v(t)
  });
}
i(nn, "_guid");
// @__NO_SIDE_EFFECTS__
function ci(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    ...v(t)
  });
}
i(ci, "_uuid");
// @__NO_SIDE_EFFECTS__
function ui(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v4",
    ...v(t)
  });
}
i(ui, "_uuidv4");
// @__NO_SIDE_EFFECTS__
function si(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v6",
    ...v(t)
  });
}
i(si, "_uuidv6");
// @__NO_SIDE_EFFECTS__
function li(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v7",
    ...v(t)
  });
}
i(li, "_uuidv7");
// @__NO_SIDE_EFFECTS__
function on(e, t) {
  return new e({
    type: "string",
    format: "url",
    check: "string_format",
    abort: !1,
    ...v(t)
  });
}
i(on, "_url");
// @__NO_SIDE_EFFECTS__
function di(e, t) {
  return new e({
    type: "string",
    format: "emoji",
    check: "string_format",
    abort: !1,
    ...v(t)
  });
}
i(di, "_emoji");
// @__NO_SIDE_EFFECTS__
function fi(e, t) {
  return new e({
    type: "string",
    format: "nanoid",
    check: "string_format",
    abort: !1,
    ...v(t)
  });
}
i(fi, "_nanoid");
// @__NO_SIDE_EFFECTS__
function mi(e, t) {
  return new e({
    type: "string",
    format: "cuid",
    check: "string_format",
    abort: !1,
    ...v(t)
  });
}
i(mi, "_cuid");
// @__NO_SIDE_EFFECTS__
function pi(e, t) {
  return new e({
    type: "string",
    format: "cuid2",
    check: "string_format",
    abort: !1,
    ...v(t)
  });
}
i(pi, "_cuid2");
// @__NO_SIDE_EFFECTS__
function gi(e, t) {
  return new e({
    type: "string",
    format: "ulid",
    check: "string_format",
    abort: !1,
    ...v(t)
  });
}
i(gi, "_ulid");
// @__NO_SIDE_EFFECTS__
function hi(e, t) {
  return new e({
    type: "string",
    format: "xid",
    check: "string_format",
    abort: !1,
    ...v(t)
  });
}
i(hi, "_xid");
// @__NO_SIDE_EFFECTS__
function vi(e, t) {
  return new e({
    type: "string",
    format: "ksuid",
    check: "string_format",
    abort: !1,
    ...v(t)
  });
}
i(vi, "_ksuid");
// @__NO_SIDE_EFFECTS__
function $i(e, t) {
  return new e({
    type: "string",
    format: "ipv4",
    check: "string_format",
    abort: !1,
    ...v(t)
  });
}
i($i, "_ipv4");
// @__NO_SIDE_EFFECTS__
function yi(e, t) {
  return new e({
    type: "string",
    format: "ipv6",
    check: "string_format",
    abort: !1,
    ...v(t)
  });
}
i(yi, "_ipv6");
// @__NO_SIDE_EFFECTS__
function Nu(e, t) {
  return new e({
    type: "string",
    format: "mac",
    check: "string_format",
    abort: !1,
    ...v(t)
  });
}
i(Nu, "_mac");
// @__NO_SIDE_EFFECTS__
function bi(e, t) {
  return new e({
    type: "string",
    format: "cidrv4",
    check: "string_format",
    abort: !1,
    ...v(t)
  });
}
i(bi, "_cidrv4");
// @__NO_SIDE_EFFECTS__
function xi(e, t) {
  return new e({
    type: "string",
    format: "cidrv6",
    check: "string_format",
    abort: !1,
    ...v(t)
  });
}
i(xi, "_cidrv6");
// @__NO_SIDE_EFFECTS__
function _i(e, t) {
  return new e({
    type: "string",
    format: "base64",
    check: "string_format",
    abort: !1,
    ...v(t)
  });
}
i(_i, "_base64");
// @__NO_SIDE_EFFECTS__
function ki(e, t) {
  return new e({
    type: "string",
    format: "base64url",
    check: "string_format",
    abort: !1,
    ...v(t)
  });
}
i(ki, "_base64url");
// @__NO_SIDE_EFFECTS__
function wi(e, t) {
  return new e({
    type: "string",
    format: "e164",
    check: "string_format",
    abort: !1,
    ...v(t)
  });
}
i(wi, "_e164");
// @__NO_SIDE_EFFECTS__
function zi(e, t) {
  return new e({
    type: "string",
    format: "jwt",
    check: "string_format",
    abort: !1,
    ...v(t)
  });
}
i(zi, "_jwt");
// @__NO_SIDE_EFFECTS__
function Du(e, t) {
  return new e({
    type: "string",
    format: "datetime",
    check: "string_format",
    offset: !1,
    local: !1,
    precision: null,
    ...v(t)
  });
}
i(Du, "_isoDateTime");
// @__NO_SIDE_EFFECTS__
function Au(e, t) {
  return new e({
    type: "string",
    format: "date",
    check: "string_format",
    ...v(t)
  });
}
i(Au, "_isoDate");
// @__NO_SIDE_EFFECTS__
function Cu(e, t) {
  return new e({
    type: "string",
    format: "time",
    check: "string_format",
    precision: null,
    ...v(t)
  });
}
i(Cu, "_isoTime");
// @__NO_SIDE_EFFECTS__
function Ru(e, t) {
  return new e({
    type: "string",
    format: "duration",
    check: "string_format",
    ...v(t)
  });
}
i(Ru, "_isoDuration");
// @__NO_SIDE_EFFECTS__
function Fu(e, t) {
  return new e({
    type: "number",
    checks: [],
    ...v(t)
  });
}
i(Fu, "_number");
// @__NO_SIDE_EFFECTS__
function Lu(e, t) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "safeint",
    ...v(t)
  });
}
i(Lu, "_int");
// @__NO_SIDE_EFFECTS__
function Ju(e, t) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "float32",
    ...v(t)
  });
}
i(Ju, "_float32");
// @__NO_SIDE_EFFECTS__
function Vu(e, t) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "float64",
    ...v(t)
  });
}
i(Vu, "_float64");
// @__NO_SIDE_EFFECTS__
function Mu(e, t) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "int32",
    ...v(t)
  });
}
i(Mu, "_int32");
// @__NO_SIDE_EFFECTS__
function Bu(e, t) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "uint32",
    ...v(t)
  });
}
i(Bu, "_uint32");
// @__NO_SIDE_EFFECTS__
function qu(e, t) {
  return new e({
    type: "boolean",
    ...v(t)
  });
}
i(qu, "_boolean");
// @__NO_SIDE_EFFECTS__
function Gu(e, t) {
  return new e({
    type: "bigint",
    ...v(t)
  });
}
i(Gu, "_bigint");
// @__NO_SIDE_EFFECTS__
function Wu(e, t) {
  return new e({
    type: "bigint",
    check: "bigint_format",
    abort: !1,
    format: "int64",
    ...v(t)
  });
}
i(Wu, "_int64");
// @__NO_SIDE_EFFECTS__
function Ku(e, t) {
  return new e({
    type: "bigint",
    check: "bigint_format",
    abort: !1,
    format: "uint64",
    ...v(t)
  });
}
i(Ku, "_uint64");
// @__NO_SIDE_EFFECTS__
function Xu(e, t) {
  return new e({
    type: "symbol",
    ...v(t)
  });
}
i(Xu, "_symbol");
// @__NO_SIDE_EFFECTS__
function Hu(e, t) {
  return new e({
    type: "undefined",
    ...v(t)
  });
}
i(Hu, "_undefined");
// @__NO_SIDE_EFFECTS__
function Qu(e, t) {
  return new e({
    type: "null",
    ...v(t)
  });
}
i(Qu, "_null");
// @__NO_SIDE_EFFECTS__
function Yu(e) {
  return new e({
    type: "any"
  });
}
i(Yu, "_any");
// @__NO_SIDE_EFFECTS__
function es(e) {
  return new e({
    type: "unknown"
  });
}
i(es, "_unknown");
// @__NO_SIDE_EFFECTS__
function ts(e, t) {
  return new e({
    type: "never",
    ...v(t)
  });
}
i(ts, "_never");
// @__NO_SIDE_EFFECTS__
function rs(e, t) {
  return new e({
    type: "void",
    ...v(t)
  });
}
i(rs, "_void");
// @__NO_SIDE_EFFECTS__
function ns(e, t) {
  return new e({
    type: "date",
    ...v(t)
  });
}
i(ns, "_date");
// @__NO_SIDE_EFFECTS__
function os(e, t) {
  return new e({
    type: "nan",
    ...v(t)
  });
}
i(os, "_nan");
// @__NO_SIDE_EFFECTS__
function xe(e, t) {
  return new ri({
    check: "less_than",
    ...v(t),
    value: e,
    inclusive: !1
  });
}
i(xe, "_lt");
// @__NO_SIDE_EFFECTS__
function ce(e, t) {
  return new ri({
    check: "less_than",
    ...v(t),
    value: e,
    inclusive: !0
  });
}
i(ce, "_lte");
// @__NO_SIDE_EFFECTS__
function _e(e, t) {
  return new ni({
    check: "greater_than",
    ...v(t),
    value: e,
    inclusive: !1
  });
}
i(_e, "_gt");
// @__NO_SIDE_EFFECTS__
function ee(e, t) {
  return new ni({
    check: "greater_than",
    ...v(t),
    value: e,
    inclusive: !0
  });
}
i(ee, "_gte");
// @__NO_SIDE_EFFECTS__
function is(e) {
  return /* @__PURE__ */ _e(0, e);
}
i(is, "_positive");
// @__NO_SIDE_EFFECTS__
function as(e) {
  return /* @__PURE__ */ xe(0, e);
}
i(as, "_negative");
// @__NO_SIDE_EFFECTS__
function cs(e) {
  return /* @__PURE__ */ ce(0, e);
}
i(cs, "_nonpositive");
// @__NO_SIDE_EFFECTS__
function us(e) {
  return /* @__PURE__ */ ee(0, e);
}
i(us, "_nonnegative");
// @__NO_SIDE_EFFECTS__
function Ke(e, t) {
  return new yc({
    check: "multiple_of",
    ...v(t),
    value: e
  });
}
i(Ke, "_multipleOf");
// @__NO_SIDE_EFFECTS__
function Xe(e, t) {
  return new _c({
    check: "max_size",
    ...v(t),
    maximum: e
  });
}
i(Xe, "_maxSize");
// @__NO_SIDE_EFFECTS__
function ke(e, t) {
  return new kc({
    check: "min_size",
    ...v(t),
    minimum: e
  });
}
i(ke, "_minSize");
// @__NO_SIDE_EFFECTS__
function Zt(e, t) {
  return new wc({
    check: "size_equals",
    ...v(t),
    size: e
  });
}
i(Zt, "_size");
// @__NO_SIDE_EFFECTS__
function Et(e, t) {
  return new zc({
    check: "max_length",
    ...v(t),
    maximum: e
  });
}
i(Et, "_maxLength");
// @__NO_SIDE_EFFECTS__
function Ue(e, t) {
  return new Ic({
    check: "min_length",
    ...v(t),
    minimum: e
  });
}
i(Ue, "_minLength");
// @__NO_SIDE_EFFECTS__
function Nt(e, t) {
  return new Sc({
    check: "length_equals",
    ...v(t),
    length: e
  });
}
i(Nt, "_length");
// @__NO_SIDE_EFFECTS__
function an(e, t) {
  return new jc({
    check: "string_format",
    format: "regex",
    ...v(t),
    pattern: e
  });
}
i(an, "_regex");
// @__NO_SIDE_EFFECTS__
function cn(e) {
  return new Oc({
    check: "string_format",
    format: "lowercase",
    ...v(e)
  });
}
i(cn, "_lowercase");
// @__NO_SIDE_EFFECTS__
function un(e) {
  return new Pc({
    check: "string_format",
    format: "uppercase",
    ...v(e)
  });
}
i(un, "_uppercase");
// @__NO_SIDE_EFFECTS__
function sn(e, t) {
  return new Tc({
    check: "string_format",
    format: "includes",
    ...v(t),
    includes: e
  });
}
i(sn, "_includes");
// @__NO_SIDE_EFFECTS__
function ln(e, t) {
  return new Uc({
    check: "string_format",
    format: "starts_with",
    ...v(t),
    prefix: e
  });
}
i(ln, "_startsWith");
// @__NO_SIDE_EFFECTS__
function dn(e, t) {
  return new Zc({
    check: "string_format",
    format: "ends_with",
    ...v(t),
    suffix: e
  });
}
i(dn, "_endsWith");
// @__NO_SIDE_EFFECTS__
function ss(e, t, r) {
  return new Ec({
    check: "property",
    property: e,
    schema: t,
    ...v(r)
  });
}
i(ss, "_property");
// @__NO_SIDE_EFFECTS__
function fn(e, t) {
  return new Nc({
    check: "mime_type",
    mime: e,
    ...v(t)
  });
}
i(fn, "_mime");
// @__NO_SIDE_EFFECTS__
function me(e) {
  return new Dc({
    check: "overwrite",
    tx: e
  });
}
i(me, "_overwrite");
// @__NO_SIDE_EFFECTS__
function mn(e) {
  return /* @__PURE__ */ me((t) => t.normalize(e));
}
i(mn, "_normalize");
// @__NO_SIDE_EFFECTS__
function pn() {
  return /* @__PURE__ */ me((e) => e.trim());
}
i(pn, "_trim");
// @__NO_SIDE_EFFECTS__
function gn() {
  return /* @__PURE__ */ me((e) => e.toLowerCase());
}
i(gn, "_toLowerCase");
// @__NO_SIDE_EFFECTS__
function hn() {
  return /* @__PURE__ */ me((e) => e.toUpperCase());
}
i(hn, "_toUpperCase");
// @__NO_SIDE_EFFECTS__
function vn() {
  return /* @__PURE__ */ me((e) => $o(e));
}
i(vn, "_slugify");
// @__NO_SIDE_EFFECTS__
function ls(e, t, r) {
  return new e({
    type: "array",
    element: t,
    // get element() {
    //   return element;
    // },
    ...v(r)
  });
}
i(ls, "_array");
// @__NO_SIDE_EFFECTS__
function ds(e, t) {
  return new e({
    type: "file",
    ...v(t)
  });
}
i(ds, "_file");
// @__NO_SIDE_EFFECTS__
function fs(e, t, r) {
  let n = v(r);
  return n.abort ?? (n.abort = !0), new e({
    type: "custom",
    check: "custom",
    fn: t,
    ...n
  });
}
i(fs, "_custom");
// @__NO_SIDE_EFFECTS__
function ms(e, t, r) {
  return new e({
    type: "custom",
    check: "custom",
    fn: t,
    ...v(r)
  });
}
i(ms, "_refine");
// @__NO_SIDE_EFFECTS__
function ps(e) {
  let t = /* @__PURE__ */ vm((r) => (r.addIssue = (n) => {
    if (typeof n == "string")
      r.issues.push(qe(n, r.value, t._zod.def));
    else {
      let o = n;
      o.fatal && (o.continue = !1), o.code ?? (o.code = "custom"), o.input ?? (o.input = r.value), o.inst ?? (o.inst = t), o.continue ?? (o.continue = !t._zod.def.abort), r.issues.push(qe(o));
    }
  }, e(r.value, r)));
  return t;
}
i(ps, "_superRefine");
// @__NO_SIDE_EFFECTS__
function vm(e, t) {
  let r = new E({
    check: "custom",
    ...v(t)
  });
  return r._zod.check = e, r;
}
i(vm, "_check");
// @__NO_SIDE_EFFECTS__
function gs(e) {
  let t = new E({ check: "describe" });
  return t._zod.onattach = [
    (r) => {
      let n = X.get(r) ?? {};
      X.add(r, { ...n, description: e });
    }
  ], t._zod.check = () => {
  }, t;
}
i(gs, "describe");
// @__NO_SIDE_EFFECTS__
function hs(e) {
  let t = new E({ check: "meta" });
  return t._zod.onattach = [
    (r) => {
      let n = X.get(r) ?? {};
      X.add(r, { ...n, ...e });
    }
  ], t._zod.check = () => {
  }, t;
}
i(hs, "meta");
// @__NO_SIDE_EFFECTS__
function vs(e, t) {
  let r = v(t), n = r.truthy ?? ["true", "1", "yes", "on", "y", "enabled"], o = r.falsy ?? ["false", "0", "no", "off", "n", "disabled"];
  r.case !== "sensitive" && (n = n.map((h) => typeof h == "string" ? h.toLowerCase() : h), o = o.map((h) => typeof h == "string" ? h.toLowerCase() : h));
  let a = new Set(n), c = new Set(o), u = e.Codec ?? Wr, s = e.Boolean ?? Ge, d = e.String ?? be, f = new d({ type: "string", error: r.error }), g = new s({ type: "boolean", error: r.error }), $ = new u({
    type: "pipe",
    in: f,
    out: g,
    transform: /* @__PURE__ */ i(((h, T) => {
      let z = h;
      return r.case !== "sensitive" && (z = z.toLowerCase()), a.has(z) ? !0 : c.has(z) ? !1 : (T.issues.push({
        code: "invalid_value",
        expected: "stringbool",
        values: [...a, ...c],
        input: T.value,
        inst: $,
        continue: !1
      }), {});
    }), "transform"),
    reverseTransform: /* @__PURE__ */ i(((h, T) => h === !0 ? n[0] || "true" : o[0] || "false"), "reverseTransform"),
    error: r.error
  });
  return $;
}
i(vs, "_stringbool");
// @__NO_SIDE_EFFECTS__
function Dt(e, t, r, n = {}) {
  let o = v(n), a = {
    ...v(n),
    check: "string_format",
    type: "string",
    format: t,
    fn: typeof r == "function" ? r : (u) => r.test(u),
    ...o
  };
  return r instanceof RegExp && (a.pattern = r), new e(a);
}
i(Dt, "_stringFormat");

// versions/4.3.6/node_modules/zod/v4/core/to-json-schema.js
function $n(e) {
  let t = e?.target ?? "draft-2020-12";
  return t === "draft-4" && (t = "draft-04"), t === "draft-7" && (t = "draft-07"), {
    processors: e.processors ?? {},
    metadataRegistry: e?.metadata ?? X,
    target: t,
    unrepresentable: e?.unrepresentable ?? "throw",
    override: e?.override ?? (() => {
    }),
    io: e?.io ?? "output",
    counter: 0,
    seen: /* @__PURE__ */ new Map(),
    cycles: e?.cycles ?? "ref",
    reused: e?.reused ?? "inline",
    external: e?.external ?? void 0
  };
}
i($n, "initializeContext");
function N(e, t, r = { path: [], schemaPath: [] }) {
  var n;
  let o = e._zod.def, a = t.seen.get(e);
  if (a)
    return a.count++, r.schemaPath.includes(e) && (a.cycle = r.path), a.schema;
  let c = { schema: {}, count: 1, cycle: void 0, path: r.path };
  t.seen.set(e, c);
  let u = e._zod.toJSONSchema?.();
  if (u)
    c.schema = u;
  else {
    let f = {
      ...r,
      schemaPath: [...r.schemaPath, e],
      path: r.path
    };
    if (e._zod.processJSONSchema)
      e._zod.processJSONSchema(t, c.schema, f);
    else {
      let $ = c.schema, h = t.processors[o.type];
      if (!h)
        throw new Error(`[toJSONSchema]: Non-representable type encountered: ${o.type}`);
      h(e, t, $, f);
    }
    let g = e._zod.parent;
    g && (c.ref || (c.ref = g), N(g, t, f), t.seen.get(g).isParent = !0);
  }
  let s = t.metadataRegistry.get(e);
  return s && Object.assign(c.schema, s), t.io === "input" && W(e) && (delete c.schema.examples, delete c.schema.default), t.io === "input" && c.schema._prefault && ((n = c.schema).default ?? (n.default = c.schema._prefault)), delete c.schema._prefault, t.seen.get(e).schema;
}
i(N, "process");
function yn(e, t) {
  let r = e.seen.get(t);
  if (!r)
    throw new Error("Unprocessed schema. This is a bug in Zod.");
  let n = /* @__PURE__ */ new Map();
  for (let c of e.seen.entries()) {
    let u = e.metadataRegistry.get(c[0])?.id;
    if (u) {
      let s = n.get(u);
      if (s && s !== c[0])
        throw new Error(`Duplicate schema id "${u}" detected during JSON Schema conversion. Two different schemas cannot share the same id when converted together.`);
      n.set(u, c[0]);
    }
  }
  let o = /* @__PURE__ */ i((c) => {
    let u = e.target === "draft-2020-12" ? "$defs" : "definitions";
    if (e.external) {
      let g = e.external.registry.get(c[0])?.id, $ = e.external.uri ?? ((T) => T);
      if (g)
        return { ref: $(g) };
      let h = c[1].defId ?? c[1].schema.id ?? `schema${e.counter++}`;
      return c[1].defId = h, { defId: h, ref: `${$("__shared")}#/${u}/${h}` };
    }
    if (c[1] === r)
      return { ref: "#" };
    let d = `#/${u}/`, f = c[1].schema.id ?? `__schema${e.counter++}`;
    return { defId: f, ref: d + f };
  }, "makeURI"), a = /* @__PURE__ */ i((c) => {
    if (c[1].schema.$ref)
      return;
    let u = c[1], { ref: s, defId: d } = o(c);
    u.def = { ...u.schema }, d && (u.defId = d);
    let f = u.schema;
    for (let g in f)
      delete f[g];
    f.$ref = s;
  }, "extractToDef");
  if (e.cycles === "throw")
    for (let c of e.seen.entries()) {
      let u = c[1];
      if (u.cycle)
        throw new Error(`Cycle detected: #/${u.cycle?.join("/")}/<root>

Set the \`cycles\` parameter to \`"ref"\` to resolve cyclical schemas with defs.`);
    }
  for (let c of e.seen.entries()) {
    let u = c[1];
    if (t === c[0]) {
      a(c);
      continue;
    }
    if (e.external) {
      let d = e.external.registry.get(c[0])?.id;
      if (t !== c[0] && d) {
        a(c);
        continue;
      }
    }
    if (e.metadataRegistry.get(c[0])?.id) {
      a(c);
      continue;
    }
    if (u.cycle) {
      a(c);
      continue;
    }
    if (u.count > 1 && e.reused === "ref") {
      a(c);
      continue;
    }
  }
}
i(yn, "extractDefs");
function bn(e, t) {
  let r = e.seen.get(t);
  if (!r)
    throw new Error("Unprocessed schema. This is a bug in Zod.");
  let n = /* @__PURE__ */ i((c) => {
    let u = e.seen.get(c);
    if (u.ref === null)
      return;
    let s = u.def ?? u.schema, d = { ...s }, f = u.ref;
    if (u.ref = null, f) {
      n(f);
      let $ = e.seen.get(f), h = $.schema;
      if (h.$ref && (e.target === "draft-07" || e.target === "draft-04" || e.target === "openapi-3.0") ? (s.allOf = s.allOf ?? [], s.allOf.push(h)) : Object.assign(s, h), Object.assign(s, d), c._zod.parent === f)
        for (let z in s)
          z === "$ref" || z === "allOf" || z in d || delete s[z];
      if (h.$ref && $.def)
        for (let z in s)
          z === "$ref" || z === "allOf" || z in $.def && JSON.stringify(s[z]) === JSON.stringify($.def[z]) && delete s[z];
    }
    let g = c._zod.parent;
    if (g && g !== f) {
      n(g);
      let $ = e.seen.get(g);
      if ($?.schema.$ref && (s.$ref = $.schema.$ref, $.def))
        for (let h in s)
          h === "$ref" || h === "allOf" || h in $.def && JSON.stringify(s[h]) === JSON.stringify($.def[h]) && delete s[h];
    }
    e.override({
      zodSchema: c,
      jsonSchema: s,
      path: u.path ?? []
    });
  }, "flattenRef");
  for (let c of [...e.seen.entries()].reverse())
    n(c[0]);
  let o = {};
  if (e.target === "draft-2020-12" ? o.$schema = "https://json-schema.org/draft/2020-12/schema" : e.target === "draft-07" ? o.$schema = "http://json-schema.org/draft-07/schema#" : e.target === "draft-04" ? o.$schema = "http://json-schema.org/draft-04/schema#" : e.target, e.external?.uri) {
    let c = e.external.registry.get(t)?.id;
    if (!c)
      throw new Error("Schema is missing an `id` property");
    o.$id = e.external.uri(c);
  }
  Object.assign(o, r.def ?? r.schema);
  let a = e.external?.defs ?? {};
  for (let c of e.seen.entries()) {
    let u = c[1];
    u.def && u.defId && (a[u.defId] = u.def);
  }
  e.external || Object.keys(a).length > 0 && (e.target === "draft-2020-12" ? o.$defs = a : o.definitions = a);
  try {
    let c = JSON.parse(JSON.stringify(o));
    return Object.defineProperty(c, "~standard", {
      value: {
        ...t["~standard"],
        jsonSchema: {
          input: At(t, "input", e.processors),
          output: At(t, "output", e.processors)
        }
      },
      enumerable: !1,
      writable: !1
    }), c;
  } catch {
    throw new Error("Error converting schema to JSON.");
  }
}
i(bn, "finalize");
function W(e, t) {
  let r = t ?? { seen: /* @__PURE__ */ new Set() };
  if (r.seen.has(e))
    return !1;
  r.seen.add(e);
  let n = e._zod.def;
  if (n.type === "transform")
    return !0;
  if (n.type === "array")
    return W(n.element, r);
  if (n.type === "set")
    return W(n.valueType, r);
  if (n.type === "lazy")
    return W(n.getter(), r);
  if (n.type === "promise" || n.type === "optional" || n.type === "nonoptional" || n.type === "nullable" || n.type === "readonly" || n.type === "default" || n.type === "prefault")
    return W(n.innerType, r);
  if (n.type === "intersection")
    return W(n.left, r) || W(n.right, r);
  if (n.type === "record" || n.type === "map")
    return W(n.keyType, r) || W(n.valueType, r);
  if (n.type === "pipe")
    return W(n.in, r) || W(n.out, r);
  if (n.type === "object") {
    for (let o in n.shape)
      if (W(n.shape[o], r))
        return !0;
    return !1;
  }
  if (n.type === "union") {
    for (let o of n.options)
      if (W(o, r))
        return !0;
    return !1;
  }
  if (n.type === "tuple") {
    for (let o of n.items)
      if (W(o, r))
        return !0;
    return !!(n.rest && W(n.rest, r));
  }
  return !1;
}
i(W, "isTransforming");
var $s = /* @__PURE__ */ i((e, t = {}) => (r) => {
  let n = $n({ ...r, processors: t });
  return N(e, n), yn(n, e), bn(n, e);
}, "createToJSONSchemaMethod"), At = /* @__PURE__ */ i((e, t, r = {}) => (n) => {
  let { libraryOptions: o, target: a } = n ?? {}, c = $n({ ...o ?? {}, target: a, io: t, processors: r });
  return N(e, c), yn(c, e), bn(c, e);
}, "createStandardJSONSchemaMethod");

// versions/4.3.6/node_modules/zod/v4/core/json-schema-processors.js
var $m = {
  guid: "uuid",
  url: "uri",
  datetime: "date-time",
  json_string: "json-string",
  regex: ""
  // do not set
}, ys = /* @__PURE__ */ i((e, t, r, n) => {
  let o = r;
  o.type = "string";
  let { minimum: a, maximum: c, format: u, patterns: s, contentEncoding: d } = e._zod.bag;
  if (typeof a == "number" && (o.minLength = a), typeof c == "number" && (o.maxLength = c), u && (o.format = $m[u] ?? u, o.format === "" && delete o.format, u === "time" && delete o.format), d && (o.contentEncoding = d), s && s.size > 0) {
    let f = [...s];
    f.length === 1 ? o.pattern = f[0].source : f.length > 1 && (o.allOf = [
      ...f.map((g) => ({
        ...t.target === "draft-07" || t.target === "draft-04" || t.target === "openapi-3.0" ? { type: "string" } : {},
        pattern: g.source
      }))
    ]);
  }
}, "stringProcessor"), bs = /* @__PURE__ */ i((e, t, r, n) => {
  let o = r, { minimum: a, maximum: c, format: u, multipleOf: s, exclusiveMaximum: d, exclusiveMinimum: f } = e._zod.bag;
  typeof u == "string" && u.includes("int") ? o.type = "integer" : o.type = "number", typeof f == "number" && (t.target === "draft-04" || t.target === "openapi-3.0" ? (o.minimum = f, o.exclusiveMinimum = !0) : o.exclusiveMinimum = f), typeof a == "number" && (o.minimum = a, typeof f == "number" && t.target !== "draft-04" && (f >= a ? delete o.minimum : delete o.exclusiveMinimum)), typeof d == "number" && (t.target === "draft-04" || t.target === "openapi-3.0" ? (o.maximum = d, o.exclusiveMaximum = !0) : o.exclusiveMaximum = d), typeof c == "number" && (o.maximum = c, typeof d == "number" && t.target !== "draft-04" && (d <= c ? delete o.maximum : delete o.exclusiveMaximum)), typeof s == "number" && (o.multipleOf = s);
}, "numberProcessor"), xs = /* @__PURE__ */ i((e, t, r, n) => {
  r.type = "boolean";
}, "booleanProcessor"), _s = /* @__PURE__ */ i((e, t, r, n) => {
  if (t.unrepresentable === "throw")
    throw new Error("BigInt cannot be represented in JSON Schema");
}, "bigintProcessor"), ks = /* @__PURE__ */ i((e, t, r, n) => {
  if (t.unrepresentable === "throw")
    throw new Error("Symbols cannot be represented in JSON Schema");
}, "symbolProcessor"), ws = /* @__PURE__ */ i((e, t, r, n) => {
  t.target === "openapi-3.0" ? (r.type = "string", r.nullable = !0, r.enum = [null]) : r.type = "null";
}, "nullProcessor"), zs = /* @__PURE__ */ i((e, t, r, n) => {
  if (t.unrepresentable === "throw")
    throw new Error("Undefined cannot be represented in JSON Schema");
}, "undefinedProcessor"), Is = /* @__PURE__ */ i((e, t, r, n) => {
  if (t.unrepresentable === "throw")
    throw new Error("Void cannot be represented in JSON Schema");
}, "voidProcessor"), Ss = /* @__PURE__ */ i((e, t, r, n) => {
  r.not = {};
}, "neverProcessor"), js = /* @__PURE__ */ i((e, t, r, n) => {
}, "anyProcessor"), Os = /* @__PURE__ */ i((e, t, r, n) => {
}, "unknownProcessor"), Ps = /* @__PURE__ */ i((e, t, r, n) => {
  if (t.unrepresentable === "throw")
    throw new Error("Date cannot be represented in JSON Schema");
}, "dateProcessor"), Ts = /* @__PURE__ */ i((e, t, r, n) => {
  let o = e._zod.def, a = pt(o.entries);
  a.every((c) => typeof c == "number") && (r.type = "number"), a.every((c) => typeof c == "string") && (r.type = "string"), r.enum = a;
}, "enumProcessor"), Us = /* @__PURE__ */ i((e, t, r, n) => {
  let o = e._zod.def, a = [];
  for (let c of o.values)
    if (c === void 0) {
      if (t.unrepresentable === "throw")
        throw new Error("Literal `undefined` cannot be represented in JSON Schema");
    } else if (typeof c == "bigint") {
      if (t.unrepresentable === "throw")
        throw new Error("BigInt literals cannot be represented in JSON Schema");
      a.push(Number(c));
    } else
      a.push(c);
  if (a.length !== 0)
    if (a.length === 1) {
      let c = a[0];
      r.type = c === null ? "null" : typeof c, t.target === "draft-04" || t.target === "openapi-3.0" ? r.enum = [c] : r.const = c;
    } else
      a.every((c) => typeof c == "number") && (r.type = "number"), a.every((c) => typeof c == "string") && (r.type = "string"), a.every((c) => typeof c == "boolean") && (r.type = "boolean"), a.every((c) => c === null) && (r.type = "null"), r.enum = a;
}, "literalProcessor"), Zs = /* @__PURE__ */ i((e, t, r, n) => {
  if (t.unrepresentable === "throw")
    throw new Error("NaN cannot be represented in JSON Schema");
}, "nanProcessor"), Es = /* @__PURE__ */ i((e, t, r, n) => {
  let o = r, a = e._zod.pattern;
  if (!a)
    throw new Error("Pattern not found in template literal");
  o.type = "string", o.pattern = a.source;
}, "templateLiteralProcessor"), Ns = /* @__PURE__ */ i((e, t, r, n) => {
  let o = r, a = {
    type: "string",
    format: "binary",
    contentEncoding: "binary"
  }, { minimum: c, maximum: u, mime: s } = e._zod.bag;
  c !== void 0 && (a.minLength = c), u !== void 0 && (a.maxLength = u), s ? s.length === 1 ? (a.contentMediaType = s[0], Object.assign(o, a)) : (Object.assign(o, a), o.anyOf = s.map((d) => ({ contentMediaType: d }))) : Object.assign(o, a);
}, "fileProcessor"), Ds = /* @__PURE__ */ i((e, t, r, n) => {
  r.type = "boolean";
}, "successProcessor"), As = /* @__PURE__ */ i((e, t, r, n) => {
  if (t.unrepresentable === "throw")
    throw new Error("Custom types cannot be represented in JSON Schema");
}, "customProcessor"), Cs = /* @__PURE__ */ i((e, t, r, n) => {
  if (t.unrepresentable === "throw")
    throw new Error("Function types cannot be represented in JSON Schema");
}, "functionProcessor"), Rs = /* @__PURE__ */ i((e, t, r, n) => {
  if (t.unrepresentable === "throw")
    throw new Error("Transforms cannot be represented in JSON Schema");
}, "transformProcessor"), Fs = /* @__PURE__ */ i((e, t, r, n) => {
  if (t.unrepresentable === "throw")
    throw new Error("Map cannot be represented in JSON Schema");
}, "mapProcessor"), Ls = /* @__PURE__ */ i((e, t, r, n) => {
  if (t.unrepresentable === "throw")
    throw new Error("Set cannot be represented in JSON Schema");
}, "setProcessor"), Js = /* @__PURE__ */ i((e, t, r, n) => {
  let o = r, a = e._zod.def, { minimum: c, maximum: u } = e._zod.bag;
  typeof c == "number" && (o.minItems = c), typeof u == "number" && (o.maxItems = u), o.type = "array", o.items = N(a.element, t, { ...n, path: [...n.path, "items"] });
}, "arrayProcessor"), Vs = /* @__PURE__ */ i((e, t, r, n) => {
  let o = r, a = e._zod.def;
  o.type = "object", o.properties = {};
  let c = a.shape;
  for (let d in c)
    o.properties[d] = N(c[d], t, {
      ...n,
      path: [...n.path, "properties", d]
    });
  let u = new Set(Object.keys(c)), s = new Set([...u].filter((d) => {
    let f = a.shape[d]._zod;
    return t.io === "input" ? f.optin === void 0 : f.optout === void 0;
  }));
  s.size > 0 && (o.required = Array.from(s)), a.catchall?._zod.def.type === "never" ? o.additionalProperties = !1 : a.catchall ? a.catchall && (o.additionalProperties = N(a.catchall, t, {
    ...n,
    path: [...n.path, "additionalProperties"]
  })) : t.io === "output" && (o.additionalProperties = !1);
}, "objectProcessor"), Ii = /* @__PURE__ */ i((e, t, r, n) => {
  let o = e._zod.def, a = o.inclusive === !1, c = o.options.map((u, s) => N(u, t, {
    ...n,
    path: [...n.path, a ? "oneOf" : "anyOf", s]
  }));
  a ? r.oneOf = c : r.anyOf = c;
}, "unionProcessor"), Ms = /* @__PURE__ */ i((e, t, r, n) => {
  let o = e._zod.def, a = N(o.left, t, {
    ...n,
    path: [...n.path, "allOf", 0]
  }), c = N(o.right, t, {
    ...n,
    path: [...n.path, "allOf", 1]
  }), u = /* @__PURE__ */ i((d) => "allOf" in d && Object.keys(d).length === 1, "isSimpleIntersection"), s = [
    ...u(a) ? a.allOf : [a],
    ...u(c) ? c.allOf : [c]
  ];
  r.allOf = s;
}, "intersectionProcessor"), Bs = /* @__PURE__ */ i((e, t, r, n) => {
  let o = r, a = e._zod.def;
  o.type = "array";
  let c = t.target === "draft-2020-12" ? "prefixItems" : "items", u = t.target === "draft-2020-12" || t.target === "openapi-3.0" ? "items" : "additionalItems", s = a.items.map(($, h) => N($, t, {
    ...n,
    path: [...n.path, c, h]
  })), d = a.rest ? N(a.rest, t, {
    ...n,
    path: [...n.path, u, ...t.target === "openapi-3.0" ? [a.items.length] : []]
  }) : null;
  t.target === "draft-2020-12" ? (o.prefixItems = s, d && (o.items = d)) : t.target === "openapi-3.0" ? (o.items = {
    anyOf: s
  }, d && o.items.anyOf.push(d), o.minItems = s.length, d || (o.maxItems = s.length)) : (o.items = s, d && (o.additionalItems = d));
  let { minimum: f, maximum: g } = e._zod.bag;
  typeof f == "number" && (o.minItems = f), typeof g == "number" && (o.maxItems = g);
}, "tupleProcessor"), qs = /* @__PURE__ */ i((e, t, r, n) => {
  let o = r, a = e._zod.def;
  o.type = "object";
  let c = a.keyType, s = c._zod.bag?.patterns;
  if (a.mode === "loose" && s && s.size > 0) {
    let f = N(a.valueType, t, {
      ...n,
      path: [...n.path, "patternProperties", "*"]
    });
    o.patternProperties = {};
    for (let g of s)
      o.patternProperties[g.source] = f;
  } else
    (t.target === "draft-07" || t.target === "draft-2020-12") && (o.propertyNames = N(a.keyType, t, {
      ...n,
      path: [...n.path, "propertyNames"]
    })), o.additionalProperties = N(a.valueType, t, {
      ...n,
      path: [...n.path, "additionalProperties"]
    });
  let d = c._zod.values;
  if (d) {
    let f = [...d].filter((g) => typeof g == "string" || typeof g == "number");
    f.length > 0 && (o.required = f);
  }
}, "recordProcessor"), Gs = /* @__PURE__ */ i((e, t, r, n) => {
  let o = e._zod.def, a = N(o.innerType, t, n), c = t.seen.get(e);
  t.target === "openapi-3.0" ? (c.ref = o.innerType, r.nullable = !0) : r.anyOf = [a, { type: "null" }];
}, "nullableProcessor"), Ws = /* @__PURE__ */ i((e, t, r, n) => {
  let o = e._zod.def;
  N(o.innerType, t, n);
  let a = t.seen.get(e);
  a.ref = o.innerType;
}, "nonoptionalProcessor"), Ks = /* @__PURE__ */ i((e, t, r, n) => {
  let o = e._zod.def;
  N(o.innerType, t, n);
  let a = t.seen.get(e);
  a.ref = o.innerType, r.default = JSON.parse(JSON.stringify(o.defaultValue));
}, "defaultProcessor"), Xs = /* @__PURE__ */ i((e, t, r, n) => {
  let o = e._zod.def;
  N(o.innerType, t, n);
  let a = t.seen.get(e);
  a.ref = o.innerType, t.io === "input" && (r._prefault = JSON.parse(JSON.stringify(o.defaultValue)));
}, "prefaultProcessor"), Hs = /* @__PURE__ */ i((e, t, r, n) => {
  let o = e._zod.def;
  N(o.innerType, t, n);
  let a = t.seen.get(e);
  a.ref = o.innerType;
  let c;
  try {
    c = o.catchValue(void 0);
  } catch {
    throw new Error("Dynamic catch values are not supported in JSON Schema");
  }
  r.default = c;
}, "catchProcessor"), Qs = /* @__PURE__ */ i((e, t, r, n) => {
  let o = e._zod.def, a = t.io === "input" ? o.in._zod.def.type === "transform" ? o.out : o.in : o.out;
  N(a, t, n);
  let c = t.seen.get(e);
  c.ref = a;
}, "pipeProcessor"), Ys = /* @__PURE__ */ i((e, t, r, n) => {
  let o = e._zod.def;
  N(o.innerType, t, n);
  let a = t.seen.get(e);
  a.ref = o.innerType, r.readOnly = !0;
}, "readonlyProcessor"), el = /* @__PURE__ */ i((e, t, r, n) => {
  let o = e._zod.def;
  N(o.innerType, t, n);
  let a = t.seen.get(e);
  a.ref = o.innerType;
}, "promiseProcessor"), Si = /* @__PURE__ */ i((e, t, r, n) => {
  let o = e._zod.def;
  N(o.innerType, t, n);
  let a = t.seen.get(e);
  a.ref = o.innerType;
}, "optionalProcessor"), tl = /* @__PURE__ */ i((e, t, r, n) => {
  let o = e._zod.innerType;
  N(o, t, n);
  let a = t.seen.get(e);
  a.ref = o;
}, "lazyProcessor");

// versions/4.3.6/node_modules/zod/v4/classic/schemas.js
var Rt = {};
nt(Rt, {
  ZodAny: () => $l,
  ZodArray: () => kl,
  ZodBase64: () => Xi,
  ZodBase64URL: () => Hi,
  ZodBigInt: () => Pn,
  ZodBigIntFormat: () => ea,
  ZodBoolean: () => On,
  ZodCIDRv4: () => Wi,
  ZodCIDRv6: () => Ki,
  ZodCUID: () => Li,
  ZodCUID2: () => Ji,
  ZodCatch: () => Bl,
  ZodCodec: () => la,
  ZodCustom: () => Nn,
  ZodCustomStringFormat: () => Lt,
  ZodDate: () => ra,
  ZodDefault: () => Rl,
  ZodDiscriminatedUnion: () => zl,
  ZodE164: () => Qi,
  ZodEmail: () => Ci,
  ZodEmoji: () => Ri,
  ZodEnum: () => Ft,
  ZodExactOptional: () => Dl,
  ZodFile: () => El,
  ZodFunction: () => ed,
  ZodGUID: () => wn,
  ZodIPv4: () => qi,
  ZodIPv6: () => Gi,
  ZodIntersection: () => Il,
  ZodJWT: () => Yi,
  ZodKSUID: () => Bi,
  ZodLazy: () => Hl,
  ZodLiteral: () => Ul,
  ZodMAC: () => ml,
  ZodMap: () => Pl,
  ZodNaN: () => Gl,
  ZodNanoID: () => Fi,
  ZodNever: () => xl,
  ZodNonOptional: () => ua,
  ZodNull: () => vl,
  ZodNullable: () => Cl,
  ZodNumber: () => jn,
  ZodNumberFormat: () => et,
  ZodObject: () => Un,
  ZodOptional: () => ca,
  ZodPipe: () => sa,
  ZodPrefault: () => Ll,
  ZodPromise: () => Yl,
  ZodReadonly: () => Wl,
  ZodRecord: () => En,
  ZodSet: () => Tl,
  ZodString: () => In,
  ZodStringFormat: () => Z,
  ZodSuccess: () => Ml,
  ZodSymbol: () => gl,
  ZodTemplateLiteral: () => Xl,
  ZodTransform: () => Nl,
  ZodTuple: () => jl,
  ZodType: () => w,
  ZodULID: () => Vi,
  ZodURL: () => Sn,
  ZodUUID: () => pe,
  ZodUndefined: () => hl,
  ZodUnion: () => Zn,
  ZodUnknown: () => bl,
  ZodVoid: () => _l,
  ZodXID: () => Mi,
  ZodXor: () => wl,
  _ZodString: () => Ai,
  _default: () => Fl,
  _function: () => xp,
  any: () => yl,
  array: () => Ee,
  base64: () => Jm,
  base64url: () => Vm,
  bigint: () => pl,
  boolean: () => Vt,
  catch: () => ql,
  check: () => _p,
  cidrv4: () => Fm,
  cidrv6: () => Lm,
  codec: () => da,
  cuid: () => Um,
  cuid2: () => Zm,
  custom: () => td,
  date: () => na,
  describe: () => kp,
  discriminatedUnion: () => sp,
  e164: () => Mm,
  email: () => _m,
  emoji: () => Pm,
  enum: () => ia,
  exactOptional: () => Al,
  file: () => gp,
  float32: () => Xm,
  float64: () => Hm,
  function: () => xp,
  guid: () => km,
  hash: () => Km,
  hex: () => Wm,
  hostname: () => Gm,
  httpUrl: () => Om,
  instanceof: () => fa,
  int: () => Di,
  int32: () => Qm,
  int64: () => ep,
  intersection: () => Sl,
  ipv4: () => Am,
  ipv6: () => Rm,
  json: () => Ip,
  jwt: () => Bm,
  keyof: () => ip,
  ksuid: () => Dm,
  lazy: () => Ql,
  literal: () => Zl,
  looseObject: () => cp,
  looseRecord: () => dp,
  mac: () => Cm,
  map: () => fp,
  meta: () => wp,
  nan: () => $p,
  nanoid: () => Tm,
  nativeEnum: () => pp,
  never: () => Tn,
  nonoptional: () => Vl,
  null: () => ta,
  nullable: () => Ye,
  nullish: () => hp,
  number: () => Jt,
  object: () => tt,
  optional: () => Ze,
  partialRecord: () => lp,
  pipe: () => zn,
  prefault: () => Jl,
  preprocess: () => Sp,
  promise: () => bp,
  readonly: () => Kl,
  record: () => oa,
  refine: () => rd,
  set: () => mp,
  strictObject: () => ap,
  string: () => He,
  stringFormat: () => qm,
  stringbool: () => zp,
  success: () => vp,
  superRefine: () => nd,
  symbol: () => rp,
  templateLiteral: () => yp,
  transform: () => aa,
  tuple: () => Ol,
  uint32: () => Ym,
  uint64: () => tp,
  ulid: () => Em,
  undefined: () => np,
  union: () => rt,
  unknown: () => Qe,
  url: () => jm,
  uuid: () => wm,
  uuidv4: () => zm,
  uuidv6: () => Im,
  uuidv7: () => Sm,
  void: () => op,
  xid: () => Nm,
  xor: () => up
});

// versions/4.3.6/node_modules/zod/v4/classic/checks.js
var xn = {};
nt(xn, {
  endsWith: () => dn,
  gt: () => _e,
  gte: () => ee,
  includes: () => sn,
  length: () => Nt,
  lowercase: () => cn,
  lt: () => xe,
  lte: () => ce,
  maxLength: () => Et,
  maxSize: () => Xe,
  mime: () => fn,
  minLength: () => Ue,
  minSize: () => ke,
  multipleOf: () => Ke,
  negative: () => as,
  nonnegative: () => us,
  nonpositive: () => cs,
  normalize: () => mn,
  overwrite: () => me,
  positive: () => is,
  property: () => ss,
  regex: () => an,
  size: () => Zt,
  slugify: () => vn,
  startsWith: () => ln,
  toLowerCase: () => gn,
  toUpperCase: () => hn,
  trim: () => pn,
  uppercase: () => un
});

// versions/4.3.6/node_modules/zod/v4/classic/iso.js
var Ct = {};
nt(Ct, {
  ZodISODate: () => Pi,
  ZodISODateTime: () => ji,
  ZodISODuration: () => Ei,
  ZodISOTime: () => Ui,
  date: () => Ti,
  datetime: () => Oi,
  duration: () => Ni,
  time: () => Zi
});
var ji = /* @__PURE__ */ l("ZodISODateTime", (e, t) => {
  cu.init(e, t), Z.init(e, t);
});
function Oi(e) {
  return Du(ji, e);
}
i(Oi, "datetime");
var Pi = /* @__PURE__ */ l("ZodISODate", (e, t) => {
  uu.init(e, t), Z.init(e, t);
});
function Ti(e) {
  return Au(Pi, e);
}
i(Ti, "date");
var Ui = /* @__PURE__ */ l("ZodISOTime", (e, t) => {
  su.init(e, t), Z.init(e, t);
});
function Zi(e) {
  return Cu(Ui, e);
}
i(Zi, "time");
var Ei = /* @__PURE__ */ l("ZodISODuration", (e, t) => {
  lu.init(e, t), Z.init(e, t);
});
function Ni(e) {
  return Ru(Ei, e);
}
i(Ni, "duration");

// versions/4.3.6/node_modules/zod/v4/classic/errors.js
var rl = /* @__PURE__ */ i((e, t) => {
  vr.init(e, t), e.name = "ZodError", Object.defineProperties(e, {
    format: {
      value: /* @__PURE__ */ i((r) => zo(e, r), "value")
      // enumerable: false,
    },
    flatten: {
      value: /* @__PURE__ */ i((r) => wo(e, r), "value")
      // enumerable: false,
    },
    addIssue: {
      value: /* @__PURE__ */ i((r) => {
        e.issues.push(r), e.message = JSON.stringify(e.issues, Me, 2);
      }, "value")
      // enumerable: false,
    },
    addIssues: {
      value: /* @__PURE__ */ i((r) => {
        e.issues.push(...r), e.message = JSON.stringify(e.issues, Me, 2);
      }, "value")
      // enumerable: false,
    },
    isEmpty: {
      get() {
        return e.issues.length === 0;
      }
      // enumerable: false,
    }
  });
}, "initializer"), N_ = l("ZodError", rl), te = l("ZodError", rl, {
  Parent: Error
});

// versions/4.3.6/node_modules/zod/v4/classic/parse.js
var _n = /* @__PURE__ */ bt(te), nl = /* @__PURE__ */ xt(te), ol = /* @__PURE__ */ _t(te), il = /* @__PURE__ */ kt(te), kn = /* @__PURE__ */ ac(te), al = /* @__PURE__ */ cc(te), cl = /* @__PURE__ */ uc(te), ul = /* @__PURE__ */ sc(te), sl = /* @__PURE__ */ lc(te), ll = /* @__PURE__ */ dc(te), dl = /* @__PURE__ */ fc(te), fl = /* @__PURE__ */ mc(te);

// versions/4.3.6/node_modules/zod/v4/classic/schemas.js
var w = /* @__PURE__ */ l("ZodType", (e, t) => (_.init(e, t), Object.assign(e["~standard"], {
  jsonSchema: {
    input: At(e, "input"),
    output: At(e, "output")
  }
}), e.toJSONSchema = $s(e, {}), e.def = t, e.type = t.type, Object.defineProperty(e, "_def", { value: t }), e.check = (...r) => e.clone(p.mergeDefs(t, {
  checks: [
    ...t.checks ?? [],
    ...r.map((n) => typeof n == "function" ? { _zod: { check: n, def: { check: "custom" }, onattach: [] } } : n)
  ]
}), {
  parent: !0
}), e.with = e.check, e.clone = (r, n) => Q(e, r, n), e.brand = () => e, e.register = ((r, n) => (r.add(e, n), e)), e.parse = (r, n) => _n(e, r, n, { callee: e.parse }), e.safeParse = (r, n) => ol(e, r, n), e.parseAsync = async (r, n) => nl(e, r, n, { callee: e.parseAsync }), e.safeParseAsync = async (r, n) => il(e, r, n), e.spa = e.safeParseAsync, e.encode = (r, n) => kn(e, r, n), e.decode = (r, n) => al(e, r, n), e.encodeAsync = async (r, n) => cl(e, r, n), e.decodeAsync = async (r, n) => ul(e, r, n), e.safeEncode = (r, n) => sl(e, r, n), e.safeDecode = (r, n) => ll(e, r, n), e.safeEncodeAsync = async (r, n) => dl(e, r, n), e.safeDecodeAsync = async (r, n) => fl(e, r, n), e.refine = (r, n) => e.check(rd(r, n)), e.superRefine = (r) => e.check(nd(r)), e.overwrite = (r) => e.check(me(r)), e.optional = () => Ze(e), e.exactOptional = () => Al(e), e.nullable = () => Ye(e), e.nullish = () => Ze(Ye(e)), e.nonoptional = (r) => Vl(e, r), e.array = () => Ee(e), e.or = (r) => rt([e, r]), e.and = (r) => Sl(e, r), e.transform = (r) => zn(e, aa(r)), e.default = (r) => Fl(e, r), e.prefault = (r) => Jl(e, r), e.catch = (r) => ql(e, r), e.pipe = (r) => zn(e, r), e.readonly = () => Kl(e), e.describe = (r) => {
  let n = e.clone();
  return X.add(n, { description: r }), n;
}, Object.defineProperty(e, "description", {
  get() {
    return X.get(e)?.description;
  },
  configurable: !0
}), e.meta = (...r) => {
  if (r.length === 0)
    return X.get(e);
  let n = e.clone();
  return X.add(n, r[0]), n;
}, e.isOptional = () => e.safeParse(void 0).success, e.isNullable = () => e.safeParse(null).success, e.apply = (r) => r(e), e)), Ai = /* @__PURE__ */ l("_ZodString", (e, t) => {
  be.init(e, t), w.init(e, t), e._zod.processJSONSchema = (n, o, a) => ys(e, n, o, a);
  let r = e._zod.bag;
  e.format = r.format ?? null, e.minLength = r.minimum ?? null, e.maxLength = r.maximum ?? null, e.regex = (...n) => e.check(an(...n)), e.includes = (...n) => e.check(sn(...n)), e.startsWith = (...n) => e.check(ln(...n)), e.endsWith = (...n) => e.check(dn(...n)), e.min = (...n) => e.check(Ue(...n)), e.max = (...n) => e.check(Et(...n)), e.length = (...n) => e.check(Nt(...n)), e.nonempty = (...n) => e.check(Ue(1, ...n)), e.lowercase = (n) => e.check(cn(n)), e.uppercase = (n) => e.check(un(n)), e.trim = () => e.check(pn()), e.normalize = (...n) => e.check(mn(...n)), e.toLowerCase = () => e.check(gn()), e.toUpperCase = () => e.check(hn()), e.slugify = () => e.check(vn());
}), In = /* @__PURE__ */ l("ZodString", (e, t) => {
  be.init(e, t), Ai.init(e, t), e.email = (r) => e.check(ai(Ci, r)), e.url = (r) => e.check(on(Sn, r)), e.jwt = (r) => e.check(zi(Yi, r)), e.emoji = (r) => e.check(di(Ri, r)), e.guid = (r) => e.check(nn(wn, r)), e.uuid = (r) => e.check(ci(pe, r)), e.uuidv4 = (r) => e.check(ui(pe, r)), e.uuidv6 = (r) => e.check(si(pe, r)), e.uuidv7 = (r) => e.check(li(pe, r)), e.nanoid = (r) => e.check(fi(Fi, r)), e.guid = (r) => e.check(nn(wn, r)), e.cuid = (r) => e.check(mi(Li, r)), e.cuid2 = (r) => e.check(pi(Ji, r)), e.ulid = (r) => e.check(gi(Vi, r)), e.base64 = (r) => e.check(_i(Xi, r)), e.base64url = (r) => e.check(ki(Hi, r)), e.xid = (r) => e.check(hi(Mi, r)), e.ksuid = (r) => e.check(vi(Bi, r)), e.ipv4 = (r) => e.check($i(qi, r)), e.ipv6 = (r) => e.check(yi(Gi, r)), e.cidrv4 = (r) => e.check(bi(Wi, r)), e.cidrv6 = (r) => e.check(xi(Ki, r)), e.e164 = (r) => e.check(wi(Qi, r)), e.datetime = (r) => e.check(Oi(r)), e.date = (r) => e.check(Ti(r)), e.time = (r) => e.check(Zi(r)), e.duration = (r) => e.check(Ni(r));
});
function He(e) {
  return Eu(In, e);
}
i(He, "string");
var Z = /* @__PURE__ */ l("ZodStringFormat", (e, t) => {
  U.init(e, t), Ai.init(e, t);
}), Ci = /* @__PURE__ */ l("ZodEmail", (e, t) => {
  Qc.init(e, t), Z.init(e, t);
});
function _m(e) {
  return ai(Ci, e);
}
i(_m, "email");
var wn = /* @__PURE__ */ l("ZodGUID", (e, t) => {
  Xc.init(e, t), Z.init(e, t);
});
function km(e) {
  return nn(wn, e);
}
i(km, "guid");
var pe = /* @__PURE__ */ l("ZodUUID", (e, t) => {
  Hc.init(e, t), Z.init(e, t);
});
function wm(e) {
  return ci(pe, e);
}
i(wm, "uuid");
function zm(e) {
  return ui(pe, e);
}
i(zm, "uuidv4");
function Im(e) {
  return si(pe, e);
}
i(Im, "uuidv6");
function Sm(e) {
  return li(pe, e);
}
i(Sm, "uuidv7");
var Sn = /* @__PURE__ */ l("ZodURL", (e, t) => {
  Yc.init(e, t), Z.init(e, t);
});
function jm(e) {
  return on(Sn, e);
}
i(jm, "url");
function Om(e) {
  return on(Sn, {
    protocol: /^https?$/,
    hostname: de.domain,
    ...p.normalizeParams(e)
  });
}
i(Om, "httpUrl");
var Ri = /* @__PURE__ */ l("ZodEmoji", (e, t) => {
  eu.init(e, t), Z.init(e, t);
});
function Pm(e) {
  return di(Ri, e);
}
i(Pm, "emoji");
var Fi = /* @__PURE__ */ l("ZodNanoID", (e, t) => {
  tu.init(e, t), Z.init(e, t);
});
function Tm(e) {
  return fi(Fi, e);
}
i(Tm, "nanoid");
var Li = /* @__PURE__ */ l("ZodCUID", (e, t) => {
  ru.init(e, t), Z.init(e, t);
});
function Um(e) {
  return mi(Li, e);
}
i(Um, "cuid");
var Ji = /* @__PURE__ */ l("ZodCUID2", (e, t) => {
  nu.init(e, t), Z.init(e, t);
});
function Zm(e) {
  return pi(Ji, e);
}
i(Zm, "cuid2");
var Vi = /* @__PURE__ */ l("ZodULID", (e, t) => {
  ou.init(e, t), Z.init(e, t);
});
function Em(e) {
  return gi(Vi, e);
}
i(Em, "ulid");
var Mi = /* @__PURE__ */ l("ZodXID", (e, t) => {
  iu.init(e, t), Z.init(e, t);
});
function Nm(e) {
  return hi(Mi, e);
}
i(Nm, "xid");
var Bi = /* @__PURE__ */ l("ZodKSUID", (e, t) => {
  au.init(e, t), Z.init(e, t);
});
function Dm(e) {
  return vi(Bi, e);
}
i(Dm, "ksuid");
var qi = /* @__PURE__ */ l("ZodIPv4", (e, t) => {
  du.init(e, t), Z.init(e, t);
});
function Am(e) {
  return $i(qi, e);
}
i(Am, "ipv4");
var ml = /* @__PURE__ */ l("ZodMAC", (e, t) => {
  mu.init(e, t), Z.init(e, t);
});
function Cm(e) {
  return Nu(ml, e);
}
i(Cm, "mac");
var Gi = /* @__PURE__ */ l("ZodIPv6", (e, t) => {
  fu.init(e, t), Z.init(e, t);
});
function Rm(e) {
  return yi(Gi, e);
}
i(Rm, "ipv6");
var Wi = /* @__PURE__ */ l("ZodCIDRv4", (e, t) => {
  pu.init(e, t), Z.init(e, t);
});
function Fm(e) {
  return bi(Wi, e);
}
i(Fm, "cidrv4");
var Ki = /* @__PURE__ */ l("ZodCIDRv6", (e, t) => {
  gu.init(e, t), Z.init(e, t);
});
function Lm(e) {
  return xi(Ki, e);
}
i(Lm, "cidrv6");
var Xi = /* @__PURE__ */ l("ZodBase64", (e, t) => {
  vu.init(e, t), Z.init(e, t);
});
function Jm(e) {
  return _i(Xi, e);
}
i(Jm, "base64");
var Hi = /* @__PURE__ */ l("ZodBase64URL", (e, t) => {
  $u.init(e, t), Z.init(e, t);
});
function Vm(e) {
  return ki(Hi, e);
}
i(Vm, "base64url");
var Qi = /* @__PURE__ */ l("ZodE164", (e, t) => {
  yu.init(e, t), Z.init(e, t);
});
function Mm(e) {
  return wi(Qi, e);
}
i(Mm, "e164");
var Yi = /* @__PURE__ */ l("ZodJWT", (e, t) => {
  bu.init(e, t), Z.init(e, t);
});
function Bm(e) {
  return zi(Yi, e);
}
i(Bm, "jwt");
var Lt = /* @__PURE__ */ l("ZodCustomStringFormat", (e, t) => {
  xu.init(e, t), Z.init(e, t);
});
function qm(e, t, r = {}) {
  return Dt(Lt, e, t, r);
}
i(qm, "stringFormat");
function Gm(e) {
  return Dt(Lt, "hostname", de.hostname, e);
}
i(Gm, "hostname");
function Wm(e) {
  return Dt(Lt, "hex", de.hex, e);
}
i(Wm, "hex");
function Km(e, t) {
  let r = t?.enc ?? "hex", n = `${e}_${r}`, o = de[n];
  if (!o)
    throw new Error(`Unrecognized hash format: ${n}`);
  return Dt(Lt, n, o, t);
}
i(Km, "hash");
var jn = /* @__PURE__ */ l("ZodNumber", (e, t) => {
  St.init(e, t), w.init(e, t), e._zod.processJSONSchema = (n, o, a) => bs(e, n, o, a), e.gt = (n, o) => e.check(_e(n, o)), e.gte = (n, o) => e.check(ee(n, o)), e.min = (n, o) => e.check(ee(n, o)), e.lt = (n, o) => e.check(xe(n, o)), e.lte = (n, o) => e.check(ce(n, o)), e.max = (n, o) => e.check(ce(n, o)), e.int = (n) => e.check(Di(n)), e.safe = (n) => e.check(Di(n)), e.positive = (n) => e.check(_e(0, n)), e.nonnegative = (n) => e.check(ee(0, n)), e.negative = (n) => e.check(xe(0, n)), e.nonpositive = (n) => e.check(ce(0, n)), e.multipleOf = (n, o) => e.check(Ke(n, o)), e.step = (n, o) => e.check(Ke(n, o)), e.finite = () => e;
  let r = e._zod.bag;
  e.minValue = Math.max(r.minimum ?? Number.NEGATIVE_INFINITY, r.exclusiveMinimum ?? Number.NEGATIVE_INFINITY) ?? null, e.maxValue = Math.min(r.maximum ?? Number.POSITIVE_INFINITY, r.exclusiveMaximum ?? Number.POSITIVE_INFINITY) ?? null, e.isInt = (r.format ?? "").includes("int") || Number.isSafeInteger(r.multipleOf ?? 0.5), e.isFinite = !0, e.format = r.format ?? null;
});
function Jt(e) {
  return Fu(jn, e);
}
i(Jt, "number");
var et = /* @__PURE__ */ l("ZodNumberFormat", (e, t) => {
  _u.init(e, t), jn.init(e, t);
});
function Di(e) {
  return Lu(et, e);
}
i(Di, "int");
function Xm(e) {
  return Ju(et, e);
}
i(Xm, "float32");
function Hm(e) {
  return Vu(et, e);
}
i(Hm, "float64");
function Qm(e) {
  return Mu(et, e);
}
i(Qm, "int32");
function Ym(e) {
  return Bu(et, e);
}
i(Ym, "uint32");
var On = /* @__PURE__ */ l("ZodBoolean", (e, t) => {
  Ge.init(e, t), w.init(e, t), e._zod.processJSONSchema = (r, n, o) => xs(e, r, n, o);
});
function Vt(e) {
  return qu(On, e);
}
i(Vt, "boolean");
var Pn = /* @__PURE__ */ l("ZodBigInt", (e, t) => {
  jt.init(e, t), w.init(e, t), e._zod.processJSONSchema = (n, o, a) => _s(e, n, o, a), e.gte = (n, o) => e.check(ee(n, o)), e.min = (n, o) => e.check(ee(n, o)), e.gt = (n, o) => e.check(_e(n, o)), e.gte = (n, o) => e.check(ee(n, o)), e.min = (n, o) => e.check(ee(n, o)), e.lt = (n, o) => e.check(xe(n, o)), e.lte = (n, o) => e.check(ce(n, o)), e.max = (n, o) => e.check(ce(n, o)), e.positive = (n) => e.check(_e(BigInt(0), n)), e.negative = (n) => e.check(xe(BigInt(0), n)), e.nonpositive = (n) => e.check(ce(BigInt(0), n)), e.nonnegative = (n) => e.check(ee(BigInt(0), n)), e.multipleOf = (n, o) => e.check(Ke(n, o));
  let r = e._zod.bag;
  e.minValue = r.minimum ?? null, e.maxValue = r.maximum ?? null, e.format = r.format ?? null;
});
function pl(e) {
  return Gu(Pn, e);
}
i(pl, "bigint");
var ea = /* @__PURE__ */ l("ZodBigIntFormat", (e, t) => {
  ku.init(e, t), Pn.init(e, t);
});
function ep(e) {
  return Wu(ea, e);
}
i(ep, "int64");
function tp(e) {
  return Ku(ea, e);
}
i(tp, "uint64");
var gl = /* @__PURE__ */ l("ZodSymbol", (e, t) => {
  Ir.init(e, t), w.init(e, t), e._zod.processJSONSchema = (r, n, o) => ks(e, r, n, o);
});
function rp(e) {
  return Xu(gl, e);
}
i(rp, "symbol");
var hl = /* @__PURE__ */ l("ZodUndefined", (e, t) => {
  Sr.init(e, t), w.init(e, t), e._zod.processJSONSchema = (r, n, o) => zs(e, r, n, o);
});
function np(e) {
  return Hu(hl, e);
}
i(np, "_undefined");
var vl = /* @__PURE__ */ l("ZodNull", (e, t) => {
  jr.init(e, t), w.init(e, t), e._zod.processJSONSchema = (r, n, o) => ws(e, r, n, o);
});
function ta(e) {
  return Qu(vl, e);
}
i(ta, "_null");
var $l = /* @__PURE__ */ l("ZodAny", (e, t) => {
  Or.init(e, t), w.init(e, t), e._zod.processJSONSchema = (r, n, o) => js(e, r, n, o);
});
function yl() {
  return Yu($l);
}
i(yl, "any");
var bl = /* @__PURE__ */ l("ZodUnknown", (e, t) => {
  Pr.init(e, t), w.init(e, t), e._zod.processJSONSchema = (r, n, o) => Os(e, r, n, o);
});
function Qe() {
  return es(bl);
}
i(Qe, "unknown");
var xl = /* @__PURE__ */ l("ZodNever", (e, t) => {
  Tr.init(e, t), w.init(e, t), e._zod.processJSONSchema = (r, n, o) => Ss(e, r, n, o);
});
function Tn(e) {
  return ts(xl, e);
}
i(Tn, "never");
var _l = /* @__PURE__ */ l("ZodVoid", (e, t) => {
  Ur.init(e, t), w.init(e, t), e._zod.processJSONSchema = (r, n, o) => Is(e, r, n, o);
});
function op(e) {
  return rs(_l, e);
}
i(op, "_void");
var ra = /* @__PURE__ */ l("ZodDate", (e, t) => {
  Zr.init(e, t), w.init(e, t), e._zod.processJSONSchema = (n, o, a) => Ps(e, n, o, a), e.min = (n, o) => e.check(ee(n, o)), e.max = (n, o) => e.check(ce(n, o));
  let r = e._zod.bag;
  e.minDate = r.minimum ? new Date(r.minimum) : null, e.maxDate = r.maximum ? new Date(r.maximum) : null;
});
function na(e) {
  return ns(ra, e);
}
i(na, "date");
var kl = /* @__PURE__ */ l("ZodArray", (e, t) => {
  Er.init(e, t), w.init(e, t), e._zod.processJSONSchema = (r, n, o) => Js(e, r, n, o), e.element = t.element, e.min = (r, n) => e.check(Ue(r, n)), e.nonempty = (r) => e.check(Ue(1, r)), e.max = (r, n) => e.check(Et(r, n)), e.length = (r, n) => e.check(Nt(r, n)), e.unwrap = () => e.element;
});
function Ee(e, t) {
  return ls(kl, e, t);
}
i(Ee, "array");
function ip(e) {
  let t = e._zod.def.shape;
  return ia(Object.keys(t));
}
i(ip, "keyof");
var Un = /* @__PURE__ */ l("ZodObject", (e, t) => {
  Iu.init(e, t), w.init(e, t), e._zod.processJSONSchema = (r, n, o) => Vs(e, r, n, o), p.defineLazy(e, "shape", () => t.shape), e.keyof = () => ia(Object.keys(e._zod.def.shape)), e.catchall = (r) => e.clone({ ...e._zod.def, catchall: r }), e.passthrough = () => e.clone({ ...e._zod.def, catchall: Qe() }), e.loose = () => e.clone({ ...e._zod.def, catchall: Qe() }), e.strict = () => e.clone({ ...e._zod.def, catchall: Tn() }), e.strip = () => e.clone({ ...e._zod.def, catchall: void 0 }), e.extend = (r) => p.extend(e, r), e.safeExtend = (r) => p.safeExtend(e, r), e.merge = (r) => p.merge(e, r), e.pick = (r) => p.pick(e, r), e.omit = (r) => p.omit(e, r), e.partial = (...r) => p.partial(ca, e, r[0]), e.required = (...r) => p.required(ua, e, r[0]);
});
function tt(e, t) {
  let r = {
    type: "object",
    shape: e ?? {},
    ...p.normalizeParams(t)
  };
  return new Un(r);
}
i(tt, "object");
function ap(e, t) {
  return new Un({
    type: "object",
    shape: e,
    catchall: Tn(),
    ...p.normalizeParams(t)
  });
}
i(ap, "strictObject");
function cp(e, t) {
  return new Un({
    type: "object",
    shape: e,
    catchall: Qe(),
    ...p.normalizeParams(t)
  });
}
i(cp, "looseObject");
var Zn = /* @__PURE__ */ l("ZodUnion", (e, t) => {
  We.init(e, t), w.init(e, t), e._zod.processJSONSchema = (r, n, o) => Ii(e, r, n, o), e.options = t.options;
});
function rt(e, t) {
  return new Zn({
    type: "union",
    options: e,
    ...p.normalizeParams(t)
  });
}
i(rt, "union");
var wl = /* @__PURE__ */ l("ZodXor", (e, t) => {
  Zn.init(e, t), Su.init(e, t), e._zod.processJSONSchema = (r, n, o) => Ii(e, r, n, o), e.options = t.options;
});
function up(e, t) {
  return new wl({
    type: "union",
    options: e,
    inclusive: !1,
    ...p.normalizeParams(t)
  });
}
i(up, "xor");
var zl = /* @__PURE__ */ l("ZodDiscriminatedUnion", (e, t) => {
  Zn.init(e, t), ju.init(e, t);
});
function sp(e, t, r) {
  return new zl({
    type: "union",
    options: t,
    discriminator: e,
    ...p.normalizeParams(r)
  });
}
i(sp, "discriminatedUnion");
var Il = /* @__PURE__ */ l("ZodIntersection", (e, t) => {
  Dr.init(e, t), w.init(e, t), e._zod.processJSONSchema = (r, n, o) => Ms(e, r, n, o);
});
function Sl(e, t) {
  return new Il({
    type: "intersection",
    left: e,
    right: t
  });
}
i(Sl, "intersection");
var jl = /* @__PURE__ */ l("ZodTuple", (e, t) => {
  Ot.init(e, t), w.init(e, t), e._zod.processJSONSchema = (r, n, o) => Bs(e, r, n, o), e.rest = (r) => e.clone({
    ...e._zod.def,
    rest: r
  });
});
function Ol(e, t, r) {
  let n = t instanceof _, o = n ? r : t, a = n ? t : null;
  return new jl({
    type: "tuple",
    items: e,
    rest: a,
    ...p.normalizeParams(o)
  });
}
i(Ol, "tuple");
var En = /* @__PURE__ */ l("ZodRecord", (e, t) => {
  Ar.init(e, t), w.init(e, t), e._zod.processJSONSchema = (r, n, o) => qs(e, r, n, o), e.keyType = t.keyType, e.valueType = t.valueType;
});
function oa(e, t, r) {
  return new En({
    type: "record",
    keyType: e,
    valueType: t,
    ...p.normalizeParams(r)
  });
}
i(oa, "record");
function lp(e, t, r) {
  let n = Q(e);
  return n._zod.values = void 0, new En({
    type: "record",
    keyType: n,
    valueType: t,
    ...p.normalizeParams(r)
  });
}
i(lp, "partialRecord");
function dp(e, t, r) {
  return new En({
    type: "record",
    keyType: e,
    valueType: t,
    mode: "loose",
    ...p.normalizeParams(r)
  });
}
i(dp, "looseRecord");
var Pl = /* @__PURE__ */ l("ZodMap", (e, t) => {
  Cr.init(e, t), w.init(e, t), e._zod.processJSONSchema = (r, n, o) => Fs(e, r, n, o), e.keyType = t.keyType, e.valueType = t.valueType, e.min = (...r) => e.check(ke(...r)), e.nonempty = (r) => e.check(ke(1, r)), e.max = (...r) => e.check(Xe(...r)), e.size = (...r) => e.check(Zt(...r));
});
function fp(e, t, r) {
  return new Pl({
    type: "map",
    keyType: e,
    valueType: t,
    ...p.normalizeParams(r)
  });
}
i(fp, "map");
var Tl = /* @__PURE__ */ l("ZodSet", (e, t) => {
  Rr.init(e, t), w.init(e, t), e._zod.processJSONSchema = (r, n, o) => Ls(e, r, n, o), e.min = (...r) => e.check(ke(...r)), e.nonempty = (r) => e.check(ke(1, r)), e.max = (...r) => e.check(Xe(...r)), e.size = (...r) => e.check(Zt(...r));
});
function mp(e, t) {
  return new Tl({
    type: "set",
    valueType: e,
    ...p.normalizeParams(t)
  });
}
i(mp, "set");
var Ft = /* @__PURE__ */ l("ZodEnum", (e, t) => {
  Fr.init(e, t), w.init(e, t), e._zod.processJSONSchema = (n, o, a) => Ts(e, n, o, a), e.enum = t.entries, e.options = Object.values(t.entries);
  let r = new Set(Object.keys(t.entries));
  e.extract = (n, o) => {
    let a = {};
    for (let c of n)
      if (r.has(c))
        a[c] = t.entries[c];
      else
        throw new Error(`Key ${c} not found in enum`);
    return new Ft({
      ...t,
      checks: [],
      ...p.normalizeParams(o),
      entries: a
    });
  }, e.exclude = (n, o) => {
    let a = { ...t.entries };
    for (let c of n)
      if (r.has(c))
        delete a[c];
      else
        throw new Error(`Key ${c} not found in enum`);
    return new Ft({
      ...t,
      checks: [],
      ...p.normalizeParams(o),
      entries: a
    });
  };
});
function ia(e, t) {
  let r = Array.isArray(e) ? Object.fromEntries(e.map((n) => [n, n])) : e;
  return new Ft({
    type: "enum",
    entries: r,
    ...p.normalizeParams(t)
  });
}
i(ia, "_enum");
function pp(e, t) {
  return new Ft({
    type: "enum",
    entries: e,
    ...p.normalizeParams(t)
  });
}
i(pp, "nativeEnum");
var Ul = /* @__PURE__ */ l("ZodLiteral", (e, t) => {
  Lr.init(e, t), w.init(e, t), e._zod.processJSONSchema = (r, n, o) => Us(e, r, n, o), e.values = new Set(t.values), Object.defineProperty(e, "value", {
    get() {
      if (t.values.length > 1)
        throw new Error("This schema contains multiple valid literal values. Use `.values` instead.");
      return t.values[0];
    }
  });
});
function Zl(e, t) {
  return new Ul({
    type: "literal",
    values: Array.isArray(e) ? e : [e],
    ...p.normalizeParams(t)
  });
}
i(Zl, "literal");
var El = /* @__PURE__ */ l("ZodFile", (e, t) => {
  Jr.init(e, t), w.init(e, t), e._zod.processJSONSchema = (r, n, o) => Ns(e, r, n, o), e.min = (r, n) => e.check(ke(r, n)), e.max = (r, n) => e.check(Xe(r, n)), e.mime = (r, n) => e.check(fn(Array.isArray(r) ? r : [r], n));
});
function gp(e) {
  return ds(El, e);
}
i(gp, "file");
var Nl = /* @__PURE__ */ l("ZodTransform", (e, t) => {
  Vr.init(e, t), w.init(e, t), e._zod.processJSONSchema = (r, n, o) => Rs(e, r, n, o), e._zod.parse = (r, n) => {
    if (n.direction === "backward")
      throw new Oe(e.constructor.name);
    r.addIssue = (a) => {
      if (typeof a == "string")
        r.issues.push(p.issue(a, r.value, t));
      else {
        let c = a;
        c.fatal && (c.continue = !1), c.code ?? (c.code = "custom"), c.input ?? (c.input = r.value), c.inst ?? (c.inst = e), r.issues.push(p.issue(c));
      }
    };
    let o = t.transform(r.value, r);
    return o instanceof Promise ? o.then((a) => (r.value = a, r)) : (r.value = o, r);
  };
});
function aa(e) {
  return new Nl({
    type: "transform",
    transform: e
  });
}
i(aa, "transform");
var ca = /* @__PURE__ */ l("ZodOptional", (e, t) => {
  Pt.init(e, t), w.init(e, t), e._zod.processJSONSchema = (r, n, o) => Si(e, r, n, o), e.unwrap = () => e._zod.def.innerType;
});
function Ze(e) {
  return new ca({
    type: "optional",
    innerType: e
  });
}
i(Ze, "optional");
var Dl = /* @__PURE__ */ l("ZodExactOptional", (e, t) => {
  Ou.init(e, t), w.init(e, t), e._zod.processJSONSchema = (r, n, o) => Si(e, r, n, o), e.unwrap = () => e._zod.def.innerType;
});
function Al(e) {
  return new Dl({
    type: "optional",
    innerType: e
  });
}
i(Al, "exactOptional");
var Cl = /* @__PURE__ */ l("ZodNullable", (e, t) => {
  Mr.init(e, t), w.init(e, t), e._zod.processJSONSchema = (r, n, o) => Gs(e, r, n, o), e.unwrap = () => e._zod.def.innerType;
});
function Ye(e) {
  return new Cl({
    type: "nullable",
    innerType: e
  });
}
i(Ye, "nullable");
function hp(e) {
  return Ze(Ye(e));
}
i(hp, "nullish");
var Rl = /* @__PURE__ */ l("ZodDefault", (e, t) => {
  Tt.init(e, t), w.init(e, t), e._zod.processJSONSchema = (r, n, o) => Ks(e, r, n, o), e.unwrap = () => e._zod.def.innerType, e.removeDefault = e.unwrap;
});
function Fl(e, t) {
  return new Rl({
    type: "default",
    innerType: e,
    get defaultValue() {
      return typeof t == "function" ? t() : p.shallowClone(t);
    }
  });
}
i(Fl, "_default");
var Ll = /* @__PURE__ */ l("ZodPrefault", (e, t) => {
  Pu.init(e, t), w.init(e, t), e._zod.processJSONSchema = (r, n, o) => Xs(e, r, n, o), e.unwrap = () => e._zod.def.innerType;
});
function Jl(e, t) {
  return new Ll({
    type: "prefault",
    innerType: e,
    get defaultValue() {
      return typeof t == "function" ? t() : p.shallowClone(t);
    }
  });
}
i(Jl, "prefault");
var ua = /* @__PURE__ */ l("ZodNonOptional", (e, t) => {
  Br.init(e, t), w.init(e, t), e._zod.processJSONSchema = (r, n, o) => Ws(e, r, n, o), e.unwrap = () => e._zod.def.innerType;
});
function Vl(e, t) {
  return new ua({
    type: "nonoptional",
    innerType: e,
    ...p.normalizeParams(t)
  });
}
i(Vl, "nonoptional");
var Ml = /* @__PURE__ */ l("ZodSuccess", (e, t) => {
  Tu.init(e, t), w.init(e, t), e._zod.processJSONSchema = (r, n, o) => Ds(e, r, n, o), e.unwrap = () => e._zod.def.innerType;
});
function vp(e) {
  return new Ml({
    type: "success",
    innerType: e
  });
}
i(vp, "success");
var Bl = /* @__PURE__ */ l("ZodCatch", (e, t) => {
  qr.init(e, t), w.init(e, t), e._zod.processJSONSchema = (r, n, o) => Hs(e, r, n, o), e.unwrap = () => e._zod.def.innerType, e.removeCatch = e.unwrap;
});
function ql(e, t) {
  return new Bl({
    type: "catch",
    innerType: e,
    catchValue: typeof t == "function" ? t : () => t
  });
}
i(ql, "_catch");
var Gl = /* @__PURE__ */ l("ZodNaN", (e, t) => {
  Gr.init(e, t), w.init(e, t), e._zod.processJSONSchema = (r, n, o) => Zs(e, r, n, o);
});
function $p(e) {
  return os(Gl, e);
}
i($p, "nan");
var sa = /* @__PURE__ */ l("ZodPipe", (e, t) => {
  Ut.init(e, t), w.init(e, t), e._zod.processJSONSchema = (r, n, o) => Qs(e, r, n, o), e.in = t.in, e.out = t.out;
});
function zn(e, t) {
  return new sa({
    type: "pipe",
    in: e,
    out: t
    // ...util.normalizeParams(params),
  });
}
i(zn, "pipe");
var la = /* @__PURE__ */ l("ZodCodec", (e, t) => {
  sa.init(e, t), Wr.init(e, t);
});
function da(e, t, r) {
  return new la({
    type: "pipe",
    in: e,
    out: t,
    transform: r.decode,
    reverseTransform: r.encode
  });
}
i(da, "codec");
var Wl = /* @__PURE__ */ l("ZodReadonly", (e, t) => {
  Kr.init(e, t), w.init(e, t), e._zod.processJSONSchema = (r, n, o) => Ys(e, r, n, o), e.unwrap = () => e._zod.def.innerType;
});
function Kl(e) {
  return new Wl({
    type: "readonly",
    innerType: e
  });
}
i(Kl, "readonly");
var Xl = /* @__PURE__ */ l("ZodTemplateLiteral", (e, t) => {
  Xr.init(e, t), w.init(e, t), e._zod.processJSONSchema = (r, n, o) => Es(e, r, n, o);
});
function yp(e, t) {
  return new Xl({
    type: "template_literal",
    parts: e,
    ...p.normalizeParams(t)
  });
}
i(yp, "templateLiteral");
var Hl = /* @__PURE__ */ l("ZodLazy", (e, t) => {
  Yr.init(e, t), w.init(e, t), e._zod.processJSONSchema = (r, n, o) => tl(e, r, n, o), e.unwrap = () => e._zod.def.getter();
});
function Ql(e) {
  return new Hl({
    type: "lazy",
    getter: e
  });
}
i(Ql, "lazy");
var Yl = /* @__PURE__ */ l("ZodPromise", (e, t) => {
  Qr.init(e, t), w.init(e, t), e._zod.processJSONSchema = (r, n, o) => el(e, r, n, o), e.unwrap = () => e._zod.def.innerType;
});
function bp(e) {
  return new Yl({
    type: "promise",
    innerType: e
  });
}
i(bp, "promise");
var ed = /* @__PURE__ */ l("ZodFunction", (e, t) => {
  Hr.init(e, t), w.init(e, t), e._zod.processJSONSchema = (r, n, o) => Cs(e, r, n, o);
});
function xp(e) {
  return new ed({
    type: "function",
    input: Array.isArray(e?.input) ? Ol(e?.input) : e?.input ?? Ee(Qe()),
    output: e?.output ?? Qe()
  });
}
i(xp, "_function");
var Nn = /* @__PURE__ */ l("ZodCustom", (e, t) => {
  en.init(e, t), w.init(e, t), e._zod.processJSONSchema = (r, n, o) => As(e, r, n, o);
});
function _p(e) {
  let t = new E({
    check: "custom"
    // ...util.normalizeParams(params),
  });
  return t._zod.check = e, t;
}
i(_p, "check");
function td(e, t) {
  return fs(Nn, e ?? (() => !0), t);
}
i(td, "custom");
function rd(e, t = {}) {
  return ms(Nn, e, t);
}
i(rd, "refine");
function nd(e) {
  return ps(e);
}
i(nd, "superRefine");
var kp = gs, wp = hs;
function fa(e, t = {}) {
  let r = new Nn({
    type: "custom",
    check: "custom",
    fn: /* @__PURE__ */ i((n) => n instanceof e, "fn"),
    abort: !0,
    ...p.normalizeParams(t)
  });
  return r._zod.bag.Class = e, r._zod.check = (n) => {
    n.value instanceof e || n.issues.push({
      code: "invalid_type",
      expected: e.name,
      input: n.value,
      inst: r,
      path: [...r._zod.def.path ?? []]
    });
  }, r;
}
i(fa, "_instanceof");
var zp = /* @__PURE__ */ i((...e) => vs({
  Codec: la,
  Boolean: On,
  String: In
}, ...e), "stringbool");
function Ip(e) {
  let t = Ql(() => rt([He(e), Jt(), Vt(), ta(), Ee(t), oa(He(), t)]));
  return t;
}
i(Ip, "json");
function Sp(e, t) {
  return zn(aa(e), t);
}
i(Sp, "preprocess");

// versions/4.3.6/node_modules/zod/v4/classic/compat.js
var od;
od || (od = {});

// versions/4.3.6/node_modules/zod/v4/classic/from-json-schema.js
var q_ = {
  ...Rt,
  ...xn,
  iso: Ct
};

// versions/4.3.6/node_modules/zod/v4/classic/external.js
B(tn());

// ../zodvex-triage-20260909/node_modules/.bun/convex-helpers@0.1.113+b9ed8f5244cf7f28/node_modules/convex-helpers/index.js
function Dn(e, t) {
  return Object.fromEntries(Object.entries(e).filter(([r]) => t.includes(r)));
}
i(Dn, "pick");
var xk = Symbol();

// ../zodvex-triage-20260909/node_modules/.bun/convex-helpers@0.1.113+b9ed8f5244cf7f28/node_modules/convex-helpers/validators.js
var Sk = m.string(), jk = m.float64(), Ok = m.float64(), Pk = m.boolean(), Tk = m.int64(), Uk = m.int64(), Zk = m.any(), Ek = m.null(), { id: Nk, object: Dk, array: Ak, bytes: Ck, literal: Rk, optional: Fk, union: Lk } = m, Jk = m.bytes();
function An(e, t) {
  let r = De(e);
  if (Object.keys(t).length === 0)
    return r;
  switch (r.kind) {
    case "object":
      return m.object(Tp(r.fields, t));
    case "union":
      return m.union(...r.members.map((n) => An(n, t)));
    default:
      throw new Error("Cannot add arguments to a validator that is not an object or union.");
  }
}
i(An, "addFieldsToValidator");
function Tp(e, t) {
  let r = { ...e };
  for (let [n, o] of Object.entries(t)) {
    let a = r[n];
    if (a) {
      if (a.kind !== o.kind)
        throw new Error(`Cannot intersect validators with different kinds: ${a.kind} and ${o.kind}`);
      a.isOptional !== o.isOptional && a.isOptional === "optional" && (r[n] = o);
    } else
      r[n] = o;
  }
  return r;
}
i(Tp, "intersectValidators");
var Vk = m.optional(m.any());
function Mt(e) {
  let { kind: t, isOptional: r } = e;
  if (r === "required")
    return e;
  switch (t) {
    case "id":
      return m.id(e.tableName);
    case "string":
      return m.string();
    case "float64":
      return m.float64();
    case "int64":
      return m.int64();
    case "boolean":
      return m.boolean();
    case "null":
      return m.null();
    case "any":
      return m.any();
    case "literal":
      return m.literal(e.value);
    case "bytes":
      return m.bytes();
    case "object":
      return m.object(e.fields);
    case "array":
      return m.array(e.element);
    case "record":
      return m.record(e.key, e.value);
    case "union":
      return m.union(...e.members);
    default:
      throw new Error("Unknown Convex validator type: " + t);
  }
}
i(Mt, "vRequired");

// ../zodvex-triage-20260909/node_modules/.bun/convex-helpers@0.1.113+b9ed8f5244cf7f28/node_modules/convex-helpers/server/customFunctions.js
var Bt = {
  args: {},
  input() {
    return { args: {}, ctx: {} };
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex-helpers@0.1.113+b9ed8f5244cf7f28/node_modules/convex-helpers/server/zod4.js
function ad(e, t) {
  return Np(e, t);
}
i(ad, "zCustomQuery");
function Up(e) {
  let t = /* @__PURE__ */ new WeakSet();
  function r(n) {
    if (t.has(n))
      return m.any();
    t.add(n);
    let o = n instanceof Tt ? m.optional(r(n._zod.def.innerType)) : n instanceof Ut ? r(n._zod.def.in) : cd(n, r);
    return t.delete(n), o;
  }
  return i(r, "zodToConvexInner"), r(e);
}
i(Up, "zodToConvex");
function Zp(e) {
  let t = /* @__PURE__ */ new WeakSet();
  function r(n) {
    if (t.has(n))
      return m.any();
    t.add(n);
    let o = n instanceof Tt ? r(n._zod.def.innerType) : n instanceof Ut ? r(n._zod.def.out) : n instanceof Vr ? m.any() : cd(n, r);
    return t.delete(n), o;
  }
  return i(r, "zodOutputToConvexInner"), r(e);
}
i(Zp, "zodOutputToConvex");
function Ep(e) {
  return Object.fromEntries(Object.entries(e).map(([t, r]) => [t, Up(r)]));
}
i(Ep, "zodToConvexFields");
function Np(e, t) {
  let r = t.input ?? Bt.input, n = t.args ?? Bt.args;
  return /* @__PURE__ */ i(function(a) {
    let { args: c, handler: u = a, skipConvexValidation: s = !1, returns: d, ...f } = a, g = d && !(d instanceof _) ? tt(d) : d, $ = g && !s ? { returns: Zp(g) } : null;
    if (c) {
      let h = c;
      if (h instanceof _)
        if (h instanceof Nr)
          h = h._zod.def.shape;
        else
          throw new Error("Unsupported zod type as args validator: " + h.constructor.name);
      let T = Ep(h);
      return e({
        args: s ? void 0 : An(T, n),
        ...$,
        handler: /* @__PURE__ */ i(async (z, F) => {
          let ie = await r(z, Dn(F, Object.keys(n)), f), H = Dn(F, Object.keys(h)), L = await tt(h).safeParseAsync(H);
          if (!L.success)
            throw new Ae({
              ZodError: JSON.parse(JSON.stringify(L.error.issues, null, 2))
            });
          let C = L.data, q = { ...z, ...ie.ctx }, k = { ...C, ...ie.args }, S = await u(q, k), M = g ? await g.parseAsync(S === void 0 ? null : S) : S;
          return ie.onSuccess && await ie.onSuccess({ ctx: z, args: C, result: M }), M;
        }, "handler")
      });
    }
    if (s && Object.keys(n).length > 0)
      throw new Error("If you're using a custom function with arguments for the input customization, you cannot skip convex validation.");
    return e({
      ...$,
      handler: /* @__PURE__ */ i(async (h, T) => {
        let z = await r(h, T, f), F = { ...h, ...z.ctx }, ie = { ...T, ...z.args }, H = await u(F, ie), L = g ? await g.parseAsync(H === void 0 ? null : H) : H;
        return z.onSuccess && await z.onSuccess({ ctx: h, args: T, result: L }), L;
      }, "handler")
    });
  }, "customBuilder");
}
i(Np, "customFnBuilder");
function cd(e, t) {
  if (e instanceof be)
    return m.string();
  if (e instanceof St || e instanceof Gr)
    return m.number();
  if (e instanceof jt)
    return m.int64();
  if (e instanceof Ge)
    return m.boolean();
  if (e instanceof jr)
    return m.null();
  if (e instanceof Or || e instanceof Pr)
    return m.any();
  if (e instanceof Er) {
    let r = t(e._zod.def.element);
    if (r.isOptional === "optional")
      throw new Error("Arrays of optional values are not supported");
    return m.array(r);
  }
  if (e instanceof Nr)
    return m.object(Object.fromEntries(Object.entries(e._zod.def.shape).map(([r, n]) => [
      r,
      t(n)
    ])));
  if (e instanceof We)
    return m.union(...e._zod.def.options.map(t));
  if (e instanceof Tr)
    return m.union();
  if (e instanceof Ot) {
    let { items: r, rest: n } = e._zod.def;
    return m.array(m.union(...[
      ...r,
      // + rest if set
      ...n !== null ? [n] : []
    ].map(t)));
  }
  if (e instanceof Lr) {
    let { values: r } = e._zod.def;
    return r.length === 1 ? id(r[0]) : m.union(...r.map(id));
  }
  if (e instanceof Fr)
    return m.union(...Object.entries(e._zod.def.entries).filter(([r, n]) => r === n || isNaN(Number(r))).map(([r, n]) => m.literal(n)));
  if (e instanceof Pt)
    return m.optional(t(e._zod.def.innerType));
  if (e instanceof Br)
    return Mt(t(e._zod.def.innerType));
  if (e instanceof Mr) {
    let r = t(e._zod.def.innerType);
    return r.isOptional === "optional" ? m.optional(m.union(Mt(r), m.null())) : m.union(r, m.null());
  }
  if (e instanceof Ar) {
    let { keyType: r, valueType: n } = e._zod.def, o = r._zod.values === void 0, a = t(n), c = t(r), u = ud(c);
    if (u !== null) {
      let s = o || a.isOptional === "optional" ? m.optional(a) : Mt(a), d = {};
      for (let f of u)
        d[f] = s;
      return m.object(d);
    }
    return m.record(sd(c) ? c : m.string(), Mt(a));
  }
  if (e instanceof Kr)
    return t(e._zod.def.innerType);
  if (e instanceof Yr)
    return t(e._zod.def.getter());
  if (e instanceof Xr)
    return m.string();
  if (e instanceof en) {
    let r = Dp.get(e);
    return r !== void 0 && typeof r.tableName == "string" ? m.id(r.tableName) : m.any();
  }
  if (e instanceof Dr)
    return m.any();
  if (e instanceof qr)
    return t(e._zod.def.innerType);
  if (e instanceof Zr || e instanceof Ir || e instanceof Cr || e instanceof Rr || e instanceof Qr || e instanceof Jr || e instanceof Hr || e instanceof Ur || e instanceof Sr)
    throw new Error(`Validator ${e.constructor.name} is not supported in Convex`);
  return m.any();
}
i(cd, "zodToConvexCommon");
function id(e) {
  if (e === void 0)
    throw new Error("undefined is not a valid Convex value");
  return e === null ? m.null() : m.literal(e);
}
i(id, "convexToZodLiteral");
function ud(e) {
  if (e.kind === "literal") {
    let t = e;
    return typeof t.value == "string" ? [t.value] : null;
  }
  if (e.kind === "union") {
    let t = e, r = [];
    for (let n of t.members) {
      let o = ud(n);
      if (o === null)
        return null;
      r.push(...o);
    }
    return r;
  }
  return null;
}
i(ud, "extractStringLiterals");
function sd(e) {
  return e.kind === "string" || e.kind === "id" ? !0 : e.kind === "union" ? e.members.every(sd) : !1;
}
i(sd, "isValidRecordKey");
var Dp = rn();

// graphProbe.ts
var ld = { query: co, mutation: io, action: so, internalQuery: uo, internalMutation: ao, internalAction: lo }, Cp = { kind: "helpers", schemaHelpers: !0, server: ld, s: { number: Jt, string: He, boolean: Vt, optional: Ze, nullable: Ye, object: tt, array: Ee, union: rt, date: na, codec: da, instanceof: fa, parse: _n, encode: kn }, makeBuilders: /* @__PURE__ */ i(() => ({ query: ad(ld.query, Bt) }), "makeBuilders") }, Rp = Ha(Cp), Fp = { count: 0, width: 32, profile: "codec-rich", entries: 0 }, ma = Rp(Fp), fw = Ap({ args: {}, returns: m.object({ checksum: m.number(), output: m.object({ seq: m.number(), at: m.number(), secret: m.string(), payload: m.string() }), manifest: m.any(), nonce: m.string() }), handler: /* @__PURE__ */ i(() => {
  let e = ma.operation();
  return globalThis.gc(), globalThis.gc(), { checksum: ma.checksum(), output: e, manifest: ma.manifest, nonce: "48a119c4-5d8c-47a6-aa5e-845ebcf68aca" };
}, "handler") });
export {
  fw as default
};
