var Cd = Object.defineProperty;
var s = (e, t) => Cd(e, "name", { value: t, configurable: !0 });
var Oe = (e, t) => {
  for (var n in t)
    Cd(e, n, { get: t[n], enumerable: !0 });
};

// graphProbe.ts
import { query as ox } from "convex:/_system/repl/wrappers.js";

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/base64.js
var we = [], de = [], _g = Uint8Array, bi = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
for (Xe = 0, Rd = bi.length; Xe < Rd; ++Xe)
  we[Xe] = bi[Xe], de[bi.charCodeAt(Xe)] = Xe;
var Xe, Rd;
de[45] = 62;
de[95] = 63;
function wg(e) {
  var t = e.length;
  if (t % 4 > 0)
    throw new Error("Invalid string. Length must be a multiple of 4");
  var n = e.indexOf("=");
  n === -1 && (n = t);
  var o = n === t ? 0 : 4 - n % 4;
  return [n, o];
}
s(wg, "getLens");
function kg(e, t, n) {
  return (t + n) * 3 / 4 - n;
}
s(kg, "_byteLength");
function sr(e) {
  var t, n = wg(e), o = n[0], r = n[1], i = new _g(kg(e, o, r)), a = 0, c = r > 0 ? o - 4 : o, u;
  for (u = 0; u < c; u += 4)
    t = de[e.charCodeAt(u)] << 18 | de[e.charCodeAt(u + 1)] << 12 | de[e.charCodeAt(u + 2)] << 6 | de[e.charCodeAt(u + 3)], i[a++] = t >> 16 & 255, i[a++] = t >> 8 & 255, i[a++] = t & 255;
  return r === 2 && (t = de[e.charCodeAt(u)] << 2 | de[e.charCodeAt(u + 1)] >> 4, i[a++] = t & 255), r === 1 && (t = de[e.charCodeAt(u)] << 10 | de[e.charCodeAt(u + 1)] << 4 | de[e.charCodeAt(u + 2)] >> 2, i[a++] = t >> 8 & 255, i[a++] = t & 255), i;
}
s(sr, "toByteArray");
function zg(e) {
  return we[e >> 18 & 63] + we[e >> 12 & 63] + we[e >> 6 & 63] + we[e & 63];
}
s(zg, "tripletToBase64");
function Ig(e, t, n) {
  for (var o, r = [], i = t; i < n; i += 3)
    o = (e[i] << 16 & 16711680) + (e[i + 1] << 8 & 65280) + (e[i + 2] & 255), r.push(zg(o));
  return r.join("");
}
s(Ig, "encodeChunk");
function cr(e) {
  for (var t, n = e.length, o = n % 3, r = [], i = 16383, a = 0, c = n - o; a < c; a += i)
    r.push(
      Ig(
        e,
        a,
        a + i > c ? c : a + i
      )
    );
  return o === 1 ? (t = e[n - 1], r.push(we[t >> 2] + we[t << 4 & 63] + "==")) : o === 2 && (t = (e[n - 2] << 8) + e[n - 1], r.push(
    we[t >> 10] + we[t >> 4 & 63] + we[t << 2 & 63] + "="
  )), r.join("");
}
s(cr, "fromByteArray");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/common/index.js
function Ue(e) {
  if (e === void 0)
    return {};
  if (!tn(e))
    throw new Error(
      `The arguments to a Convex function must be an object. Received: ${e}`
    );
  return e;
}
s(Ue, "parseArgs");
function tn(e) {
  let t = typeof e == "object", n = Object.getPrototypeOf(e), o = n === null || n === Object.prototype || // Objects generated from other contexts (e.g. across Node.js `vm` modules) will not satisfy the previous
  // conditions but are still simple objects.
  n?.constructor?.name === "Object";
  return t && o;
}
s(tn, "isSimpleObject");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/value.js
var Bd = !0, ht = BigInt("-9223372036854775808"), wi = BigInt("9223372036854775807"), $i = BigInt("0"), Sg = BigInt("8"), jg = BigInt("256");
function Jd(e) {
  return Number.isNaN(e) || !Number.isFinite(e) || Object.is(e, -0);
}
s(Jd, "isSpecial");
function Og(e) {
  e < $i && (e -= ht + ht);
  let t = e.toString(16);
  t.length % 2 === 1 && (t = "0" + t);
  let n = new Uint8Array(new ArrayBuffer(8)), o = 0;
  for (let r of t.match(/.{2}/g).reverse())
    n.set([parseInt(r, 16)], o++), e >>= Sg;
  return cr(n);
}
s(Og, "slowBigIntToBase64");
function Pg(e) {
  let t = sr(e);
  if (t.byteLength !== 8)
    throw new Error(
      `Received ${t.byteLength} bytes, expected 8 for $integer`
    );
  let n = $i, o = $i;
  for (let r of t)
    n += BigInt(r) * jg ** o, o++;
  return n > wi && (n += ht + ht), n;
}
s(Pg, "slowBase64ToBigInt");
function Tg(e) {
  if (e < ht || wi < e)
    throw new Error(
      `BigInt ${e} does not fit into a 64-bit signed integer.`
    );
  let t = new ArrayBuffer(8);
  return new DataView(t).setBigInt64(0, e, !0), cr(new Uint8Array(t));
}
s(Tg, "modernBigIntToBase64");
function Eg(e) {
  let t = sr(e);
  if (t.byteLength !== 8)
    throw new Error(
      `Received ${t.byteLength} bytes, expected 8 for $integer`
    );
  return new DataView(t.buffer).getBigInt64(0, !0);
}
s(Eg, "modernBase64ToBigInt");
var Ug = DataView.prototype.setBigInt64 ? Tg : Og, Dg = DataView.prototype.getBigInt64 ? Eg : Pg, Ld = 1024;
function _i(e) {
  if (e.length > Ld)
    throw new Error(
      `Field name ${e} exceeds maximum field name length ${Ld}.`
    );
  if (e.startsWith("$"))
    throw new Error(`Field name ${e} starts with a '$', which is reserved.`);
  for (let t = 0; t < e.length; t += 1) {
    let n = e.charCodeAt(t);
    if (n < 32 || n >= 127)
      throw new Error(
        `Field name ${e} has invalid character '${e[t]}': Field names can only contain non-control ASCII characters`
      );
  }
}
s(_i, "validateObjectField");
function L(e) {
  if (e === null || typeof e == "boolean" || typeof e == "number" || typeof e == "string")
    return e;
  if (Array.isArray(e))
    return e.map((o) => L(o));
  if (typeof e != "object")
    throw new Error(`Unexpected type of ${e}`);
  let t = Object.entries(e);
  if (t.length === 1) {
    let o = t[0][0];
    if (o === "$bytes") {
      if (typeof e.$bytes != "string")
        throw new Error(`Malformed $bytes field on ${e}`);
      return sr(e.$bytes).buffer;
    }
    if (o === "$integer") {
      if (typeof e.$integer != "string")
        throw new Error(`Malformed $integer field on ${e}`);
      return Dg(e.$integer);
    }
    if (o === "$float") {
      if (typeof e.$float != "string")
        throw new Error(`Malformed $float field on ${e}`);
      let r = sr(e.$float);
      if (r.byteLength !== 8)
        throw new Error(
          `Received ${r.byteLength} bytes, expected 8 for $float`
        );
      let a = new DataView(r.buffer).getFloat64(0, Bd);
      if (!Jd(a))
        throw new Error(`Float ${a} should be encoded as a number`);
      return a;
    }
    if (o === "$set")
      throw new Error(
        "Received a Set which is no longer supported as a Convex type."
      );
    if (o === "$map")
      throw new Error(
        "Received a Map which is no longer supported as a Convex type."
      );
  }
  let n = {};
  for (let [o, r] of Object.entries(e))
    _i(o), n[o] = L(r);
  return n;
}
s(L, "jsonToConvex");
var Md = 16384;
function Qe(e) {
  let t = JSON.stringify(e, (n, o) => o === void 0 ? "undefined" : typeof o == "bigint" ? `${o.toString()}n` : o);
  if (t.length > Md) {
    let n = "[...truncated]", o = Md - n.length, r = t.codePointAt(o - 1);
    return r !== void 0 && r > 65535 && (o -= 1), t.substring(0, o) + n;
  }
  return t;
}
s(Qe, "stringifyValueForError");
function ur(e, t, n, o) {
  if (e === void 0) {
    let a = n && ` (present at path ${n} in original object ${Qe(
      t
    )})`;
    throw new Error(
      `undefined is not a valid Convex value${a}. To learn about Convex's supported types, see https://docs.convex.dev/using/types.`
    );
  }
  if (e === null)
    return e;
  if (typeof e == "bigint") {
    if (e < ht || wi < e)
      throw new Error(
        `BigInt ${e} does not fit into a 64-bit signed integer.`
      );
    return { $integer: Ug(e) };
  }
  if (typeof e == "number")
    if (Jd(e)) {
      let a = new ArrayBuffer(8);
      return new DataView(a).setFloat64(0, e, Bd), { $float: cr(new Uint8Array(a)) };
    } else
      return e;
  if (typeof e == "boolean" || typeof e == "string")
    return e;
  if (e instanceof ArrayBuffer)
    return { $bytes: cr(new Uint8Array(e)) };
  if (Array.isArray(e))
    return e.map(
      (a, c) => ur(a, t, n + `[${c}]`, !1)
    );
  if (e instanceof Set)
    throw new Error(
      xi(n, "Set", [...e], t)
    );
  if (e instanceof Map)
    throw new Error(
      xi(n, "Map", [...e], t)
    );
  if (!tn(e)) {
    let a = e?.constructor?.name, c = a ? `${a} ` : "";
    throw new Error(
      xi(n, c, e, t)
    );
  }
  let r = {}, i = Object.entries(e);
  i.sort(([a, c], [u, l]) => a === u ? 0 : a < u ? -1 : 1);
  for (let [a, c] of i)
    c !== void 0 ? (_i(a), r[a] = ur(c, t, n + `.${a}`, !1)) : o && (_i(a), r[a] = Vd(
      c,
      t,
      n + `.${a}`
    ));
  return r;
}
s(ur, "convexToJsonInternal");
function xi(e, t, n, o) {
  return e ? `${t}${Qe(
    n
  )} is not a supported Convex type (present at path ${e} in original object ${Qe(
    o
  )}). To learn about Convex's supported types, see https://docs.convex.dev/using/types.` : `${t}${Qe(
    n
  )} is not a supported Convex type.`;
}
s(xi, "errorMessageForUnsupportedType");
function Vd(e, t, n) {
  if (e === void 0)
    return { $undefined: null };
  if (t === void 0)
    throw new Error(
      `Programming error. Current value is ${Qe(
        e
      )} but original value is undefined`
    );
  return ur(e, t, n, !1);
}
s(Vd, "convexOrUndefinedToJsonInternal");
function R(e) {
  return ur(e, e, "", !1);
}
s(R, "convexToJson");
function fe(e) {
  return Vd(e, e, "");
}
s(fe, "convexOrUndefinedToJson");
function qd(e) {
  return ur(e, e, "", !0);
}
s(qd, "patchValueToJson");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/validators.js
var Ng = Object.defineProperty, Zg = /* @__PURE__ */ s((e, t, n) => t in e ? Ng(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), F = /* @__PURE__ */ s((e, t, n) => Zg(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), Ag = "https://docs.convex.dev/error#undefined-validator";
function lr(e, t) {
  let n = t !== void 0 ? ` for field "${t}"` : "";
  throw new Error(
    `A validator is undefined${n} in ${e}. This is often caused by circular imports. See ${Ag} for details.`
  );
}
s(lr, "throwUndefinedValidatorError");
var ee = class {
  static {
    s(this, "BaseValidator");
  }
  constructor({ isOptional: t }) {
    F(this, "type"), F(this, "fieldPaths"), F(this, "isOptional"), F(this, "isConvexValidator"), this.isOptional = t, this.isConvexValidator = !0;
  }
}, rn = class e extends ee {
  static {
    s(this, "VId");
  }
  /**
   * Usually you'd use `v.id(tableName)` instead.
   */
  constructor({
    isOptional: t,
    tableName: n
  }) {
    if (super({ isOptional: t }), F(this, "tableName"), F(this, "kind", "id"), typeof n != "string")
      throw new Error("v.id(tableName) requires a string");
    this.tableName = n;
  }
  /** @internal */
  get json() {
    return { type: "id", tableName: this.tableName };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      tableName: this.tableName
    });
  }
}, dr = class e extends ee {
  static {
    s(this, "VFloat64");
  }
  constructor() {
    super(...arguments), F(this, "kind", "float64");
  }
  /** @internal */
  get json() {
    return { type: "number" };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, fr = class e extends ee {
  static {
    s(this, "VInt64");
  }
  constructor() {
    super(...arguments), F(this, "kind", "int64");
  }
  /** @internal */
  get json() {
    return { type: "bigint" };
  }
  /** @internal */
  asOptional() {
    return new e({ isOptional: "optional" });
  }
}, nn = class e extends ee {
  static {
    s(this, "VBoolean");
  }
  constructor() {
    super(...arguments), F(this, "kind", "boolean");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, on = class e extends ee {
  static {
    s(this, "VBytes");
  }
  constructor() {
    super(...arguments), F(this, "kind", "bytes");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({ isOptional: "optional" });
  }
}, an = class e extends ee {
  static {
    s(this, "VString");
  }
  constructor() {
    super(...arguments), F(this, "kind", "string");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, sn = class e extends ee {
  static {
    s(this, "VNull");
  }
  constructor() {
    super(...arguments), F(this, "kind", "null");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({ isOptional: "optional" });
  }
}, cn = class e extends ee {
  static {
    s(this, "VAny");
  }
  constructor() {
    super(...arguments), F(this, "kind", "any");
  }
  /** @internal */
  get json() {
    return {
      type: this.kind
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, un = class e extends ee {
  static {
    s(this, "VObject");
  }
  /**
   * Usually you'd use `v.object({ ... })` instead.
   */
  constructor({
    isOptional: t,
    fields: n
  }) {
    super({ isOptional: t }), F(this, "fields"), F(this, "kind", "object"), globalThis.Object.entries(n).forEach(([o, r]) => {
      if (r === void 0 && lr("v.object()", o), !r.isConvexValidator)
        throw new Error("v.object() entries must be validators");
    }), this.fields = n;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: globalThis.Object.fromEntries(
        globalThis.Object.entries(this.fields).map(([t, n]) => [
          t,
          {
            fieldType: n.json,
            optional: n.isOptional === "optional"
          }
        ])
      )
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      fields: this.fields
    });
  }
  /**
   * Create a new VObject with the specified fields omitted.
   * @param fields The field names to omit from this VObject.
   */
  omit(...t) {
    let n = { ...this.fields };
    for (let o of t)
      delete n[o];
    return new e({
      isOptional: this.isOptional,
      fields: n
    });
  }
  /**
   * Create a new VObject with only the specified fields.
   * @param fields The field names to pick from this VObject.
   */
  pick(...t) {
    let n = {};
    for (let o of t)
      n[o] = this.fields[o];
    return new e({
      isOptional: this.isOptional,
      fields: n
    });
  }
  /**
   * Create a new VObject with all fields marked as optional.
   */
  partial() {
    let t = {};
    for (let [n, o] of globalThis.Object.entries(this.fields))
      t[n] = o.asOptional();
    return new e({
      isOptional: this.isOptional,
      fields: t
    });
  }
  /**
   * Create a new VObject with additional fields merged in.
   * @param fields An object with additional validators to merge into this VObject.
   */
  extend(t) {
    return new e({
      isOptional: this.isOptional,
      fields: { ...this.fields, ...t }
    });
  }
}, ln = class e extends ee {
  static {
    s(this, "VLiteral");
  }
  /**
   * Usually you'd use `v.literal(value)` instead.
   */
  constructor({ isOptional: t, value: n }) {
    if (super({ isOptional: t }), F(this, "value"), F(this, "kind", "literal"), typeof n != "string" && typeof n != "boolean" && typeof n != "number" && typeof n != "bigint")
      throw new Error("v.literal(value) must be a string, number, or boolean");
    this.value = n;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: R(this.value)
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      value: this.value
    });
  }
}, dn = class e extends ee {
  static {
    s(this, "VArray");
  }
  /**
   * Usually you'd use `v.array(element)` instead.
   */
  constructor({
    isOptional: t,
    element: n
  }) {
    super({ isOptional: t }), F(this, "element"), F(this, "kind", "array"), n === void 0 && lr("v.array()"), this.element = n;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: this.element.json
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      element: this.element
    });
  }
}, fn = class e extends ee {
  static {
    s(this, "VRecord");
  }
  /**
   * Usually you'd use `v.record(key, value)` instead.
   */
  constructor({
    isOptional: t,
    key: n,
    value: o
  }) {
    if (super({ isOptional: t }), F(this, "key"), F(this, "value"), F(this, "kind", "record"), n === void 0 && lr("v.record()", "key"), o === void 0 && lr("v.record()", "value"), n.isOptional === "optional")
      throw new Error("Record validator cannot have optional keys");
    if (o.isOptional === "optional")
      throw new Error("Record validator cannot have optional values");
    if (!n.isConvexValidator || !o.isConvexValidator)
      throw new Error("Key and value of v.record() but be validators");
    this.key = n, this.value = o;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      // This cast is needed because TypeScript thinks the key type is too wide
      keys: this.key.json,
      values: {
        fieldType: this.value.json,
        optional: !1
      }
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      key: this.key,
      value: this.value
    });
  }
}, pn = class e extends ee {
  static {
    s(this, "VUnion");
  }
  /**
   * Usually you'd use `v.union(...members)` instead.
   */
  constructor({ isOptional: t, members: n }) {
    super({ isOptional: t }), F(this, "members"), F(this, "kind", "union"), n.forEach((o, r) => {
      if (o === void 0 && lr("v.union()", `member at index ${r}`), !o.isConvexValidator)
        throw new Error("All members of v.union() must be validators");
    }), this.members = n;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: this.members.map((t) => t.json)
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      members: this.members
    });
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/validator.js
function ki(e) {
  return !!e.isConvexValidator;
}
s(ki, "isValidator");
function pr(e) {
  return ki(e) ? e : g.object(e);
}
s(pr, "asObjectValidator");
var g = {
  /**
   * Validates that the value is a document ID for the given table.
   *
   * IDs are strings at runtime but are typed as `Id<"tableName">` in
   * TypeScript for type safety.
   *
   * @example
   * ```typescript
   * args: { userId: v.id("users") }
   * ```
   *
   * @param tableName The name of the table.
   */
  id: /* @__PURE__ */ s((e) => new rn({
    isOptional: "required",
    tableName: e
  }), "id"),
  /**
   * Validates that the value is `null`.
   *
   * Use `returns: v.null()` for functions that don't return a meaningful value.
   * JavaScript `undefined` is not a valid Convex value, it is automatically
   * converted to `null`.
   */
  null: /* @__PURE__ */ s(() => new sn({ isOptional: "required" }), "null"),
  /**
   * Validates that the value is a JavaScript `number` (Convex Float64).
   *
   * Supports all IEEE-754 double-precision floating point numbers including
   * NaN and Infinity.
   *
   * Alias for `v.float64()`.
   */
  number: /* @__PURE__ */ s(() => new dr({ isOptional: "required" }), "number"),
  /**
   * Validates that the value is a JavaScript `number` (Convex Float64).
   *
   * Supports all IEEE-754 double-precision floating point numbers.
   */
  float64: /* @__PURE__ */ s(() => new dr({ isOptional: "required" }), "float64"),
  /**
   * @deprecated Use `v.int64()` instead.
   */
  bigint: /* @__PURE__ */ s(() => new fr({ isOptional: "required" }), "bigint"),
  /**
   * Validates that the value is a JavaScript `bigint` (Convex Int64).
   *
   * Supports BigInts between -2^63 and 2^63-1.
   *
   * @example
   * ```typescript
   * args: { timestamp: v.int64() }
   * // Usage: createDoc({ timestamp: 1234567890n })
   * ```
   */
  int64: /* @__PURE__ */ s(() => new fr({ isOptional: "required" }), "int64"),
  /**
   * Validates that the value is a `boolean`.
   */
  boolean: /* @__PURE__ */ s(() => new nn({ isOptional: "required" }), "boolean"),
  /**
   * Validates that the value is a `string`.
   *
   * Strings are stored as UTF-8 and their storage size is calculated as their
   * UTF-8 encoded size.
   */
  string: /* @__PURE__ */ s(() => new an({ isOptional: "required" }), "string"),
  /**
   * Validates that the value is an `ArrayBuffer` (Convex Bytes).
   *
   * Use for binary data.
   */
  bytes: /* @__PURE__ */ s(() => new on({ isOptional: "required" }), "bytes"),
  /**
   * Validates that the value is exactly equal to the given literal.
   *
   * Useful for discriminated unions and enum-like patterns.
   *
   * @example
   * ```typescript
   * // Discriminated union pattern:
   * v.union(
   *   v.object({ kind: v.literal("error"), message: v.string() }),
   *   v.object({ kind: v.literal("success"), value: v.number() }),
   * )
   * ```
   *
   * @param literal The literal value to compare against.
   */
  literal: /* @__PURE__ */ s((e) => new ln({ isOptional: "required", value: e }), "literal"),
  /**
   * Validates that the value is an `Array` where every element matches the
   * given validator.
   *
   * Arrays can have at most 8192 elements.
   *
   * @example
   * ```typescript
   * args: { tags: v.array(v.string()) }
   * args: { coordinates: v.array(v.number()) }
   * args: { items: v.array(v.object({ name: v.string(), qty: v.number() })) }
   * ```
   *
   * @param element The validator for the elements of the array.
   */
  array: /* @__PURE__ */ s((e) => new dn({ isOptional: "required", element: e }), "array"),
  /**
   * Validates that the value is an `Object` with the specified properties.
   *
   * Objects can have at most 1024 entries. Field names must be non-empty and
   * must not start with `"$"` or `"_"` (`_` is reserved for system fields
   * like `_id` and `_creationTime`; `$` is reserved for Convex internal use).
   *
   * @example
   * ```typescript
   * args: {
   *   user: v.object({
   *     name: v.string(),
   *     email: v.string(),
   *     age: v.optional(v.number()),
   *   })
   * }
   * ```
   *
   * @param fields An object mapping property names to their validators.
   */
  object: /* @__PURE__ */ s((e) => new un({ isOptional: "required", fields: e }), "object"),
  /**
   * Validates that the value is a `Record` (object with dynamic keys).
   *
   * Records are objects at runtime but allow dynamic keys, unlike `v.object()`
   * which requires known property names. Keys must be ASCII characters only,
   * non-empty, and not start with `"$"` or `"_"`.
   *
   * @example
   * ```typescript
   * // Map of user IDs to scores:
   * args: { scores: v.record(v.id("users"), v.number()) }
   *
   * // Map of string keys to string values:
   * args: { metadata: v.record(v.string(), v.string()) }
   * ```
   *
   * @param keys The validator for the keys of the record.
   * @param values The validator for the values of the record.
   */
  record: /* @__PURE__ */ s((e, t) => new fn({
    isOptional: "required",
    key: e,
    value: t
  }), "record"),
  /**
   * Validates that the value matches at least one of the given validators.
   *
   * @example
   * ```typescript
   * // Allow string or number:
   * args: { value: v.union(v.string(), v.number()) }
   *
   * // Discriminated union (recommended pattern):
   * v.union(
   *   v.object({ kind: v.literal("text"), body: v.string() }),
   *   v.object({ kind: v.literal("image"), url: v.string() }),
   * )
   *
   * // Nullable value:
   * returns: v.union(v.object({ ... }), v.null())
   * ```
   *
   * @param members The validators to match against.
   */
  union: /* @__PURE__ */ s((...e) => new pn({
    isOptional: "required",
    members: e
  }), "union"),
  /**
   * A validator that accepts any Convex value without validation.
   *
   * Prefer using specific validators when possible for better type safety
   * and runtime validation.
   */
  any: /* @__PURE__ */ s(() => new cn({ isOptional: "required" }), "any"),
  /**
   * Makes a property optional in an object validator.
   *
   * An optional property can be omitted entirely when creating a document or
   * calling a function. This is different from `v.nullable()` which requires
   * the property to be present but allows `null`.
   *
   * @example
   * ```typescript
   * v.object({
   *   name: v.string(),              // required
   *   nickname: v.optional(v.string()), // can be omitted
   * })
   *
   * // Valid: { name: "Alice" }
   * // Valid: { name: "Alice", nickname: "Ali" }
   * // Invalid: { name: "Alice", nickname: null }  - use v.nullable() for this
   * ```
   *
   * @param value The property value validator to make optional.
   */
  optional: /* @__PURE__ */ s((e) => e.asOptional(), "optional"),
  /**
   * Allows a value to be either the given type or `null`.
   *
   * This is shorthand for `v.union(value, v.null())`. Unlike `v.optional()`,
   * the property must still be present, but may be `null`.
   *
   * @example
   * ```typescript
   * v.object({
   *   name: v.string(),
   *   deletedAt: v.nullable(v.number()), // must be present, can be null
   * })
   *
   * // Valid: { name: "Alice", deletedAt: null }
   * // Valid: { name: "Alice", deletedAt: 1234567890 }
   * // Invalid: { name: "Alice" }  - deletedAt is required
   * ```
   */
  nullable: /* @__PURE__ */ s((e) => g.union(e, g.null()), "nullable")
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/errors.js
var Cg = Object.defineProperty, Rg = /* @__PURE__ */ s((e, t, n) => t in e ? Cg(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), zi = /* @__PURE__ */ s((e, t, n) => Rg(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), Wd, Kd, Fg = Symbol.for("ConvexError"), vt = class extends (Kd = Error, Wd = Fg, Kd) {
  static {
    s(this, "ConvexError");
  }
  constructor(t) {
    super(typeof t == "string" ? t : Qe(t)), zi(this, "name", "ConvexError"), zi(this, "data"), zi(this, Wd, !0), this.data = t;
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/compare_utf8.js
var Gd = /* @__PURE__ */ s(() => Array.from({ length: 4 }, () => 0), "arr"), zx = Gd(), Ix = Gd();

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/index.js
var G = "1.32.0";

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/syscall.js
function mr(e, t) {
  if (typeof Convex > "u" || Convex.syscall === void 0)
    throw new Error(
      "The Convex database and auth objects are being used outside of a Convex backend. Did you mean to use `useQuery` or `useMutation` to call a Convex function?"
    );
  let n = Convex.syscall(e, JSON.stringify(t));
  return JSON.parse(n);
}
s(mr, "performSyscall");
async function E(e, t) {
  if (typeof Convex > "u" || Convex.asyncSyscall === void 0)
    throw new Error(
      "The Convex database and auth objects are being used outside of a Convex backend. Did you mean to use `useQuery` or `useMutation` to call a Convex function?"
    );
  let n;
  try {
    n = await Convex.asyncSyscall(e, JSON.stringify(t));
  } catch (o) {
    if (o.data !== void 0) {
      let r = new vt(o.message);
      throw r.data = L(o.data), r;
    }
    throw new Error(o.message);
  }
  return JSON.parse(n);
}
s(E, "performAsyncSyscall");
function mn(e, t) {
  if (typeof Convex > "u" || Convex.jsSyscall === void 0)
    throw new Error(
      "The Convex database and auth objects are being used outside of a Convex backend. Did you mean to use `useQuery` or `useMutation` to call a Convex function?"
    );
  return Convex.jsSyscall(e, t);
}
s(mn, "performJsSyscall");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/functionName.js
var gr = Symbol.for("functionName");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/components/paths.js
var Xd = Symbol.for("toReferencePath");
function Mg(e) {
  return e[Xd] ?? null;
}
s(Mg, "extractReferencePath");
function Bg(e) {
  return e.startsWith("function://");
}
s(Bg, "isFunctionHandle");
function ge(e) {
  let t;
  if (typeof e == "string")
    Bg(e) ? t = { functionHandle: e } : t = { name: e };
  else if (e[gr])
    t = { name: e[gr] };
  else {
    let n = Mg(e);
    if (!n)
      throw new Error(`${e} is not a functionReference`);
    t = { reference: n };
  }
  return t;
}
s(ge, "getFunctionAddress");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/actions_impl.js
function Ii(e, t, n) {
  return {
    ...ge(t),
    args: R(Ue(n)),
    version: G,
    requestId: e
  };
}
s(Ii, "syscallArgs");
function Qd(e) {
  return {
    runQuery: /* @__PURE__ */ s(async (t, n) => {
      let o = await E(
        "1.0/actions/query",
        Ii(e, t, n)
      );
      return L(o);
    }, "runQuery"),
    runMutation: /* @__PURE__ */ s(async (t, n) => {
      let o = await E(
        "1.0/actions/mutation",
        Ii(e, t, n)
      );
      return L(o);
    }, "runMutation"),
    runAction: /* @__PURE__ */ s(async (t, n) => {
      let o = await E(
        "1.0/actions/action",
        Ii(e, t, n)
      );
      return L(o);
    }, "runAction")
  };
}
s(Qd, "setupActionCalls");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/vector_search.js
var Jg = Object.defineProperty, Vg = /* @__PURE__ */ s((e, t, n) => t in e ? Jg(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), Hd = /* @__PURE__ */ s((e, t, n) => Vg(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), gn = class {
  static {
    s(this, "FilterExpression");
  }
  /**
   * @internal
   */
  constructor() {
    Hd(this, "_isExpression"), Hd(this, "_value");
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/validate.js
function T(e, t, n, o) {
  if (e === void 0)
    throw new TypeError(
      `Must provide arg ${t} \`${o}\` to \`${n}\``
    );
}
s(T, "validateArg");
function Yd(e, t, n, o) {
  if (!Number.isInteger(e) || e < 0)
    throw new TypeError(
      `Arg ${t} \`${o}\` to \`${n}\` must be a non-negative integer`
    );
}
s(Yd, "validateArgIsNonNegativeInteger");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/vector_search_impl.js
var qg = Object.defineProperty, Wg = /* @__PURE__ */ s((e, t, n) => t in e ? qg(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), Si = /* @__PURE__ */ s((e, t, n) => Wg(e, typeof t != "symbol" ? t + "" : t, n), "__publicField");
function ef(e) {
  return async (t, n, o) => {
    if (T(t, 1, "vectorSearch", "tableName"), T(n, 2, "vectorSearch", "indexName"), T(o, 3, "vectorSearch", "query"), !o.vector || !Array.isArray(o.vector) || o.vector.length === 0)
      throw Error("`vector` must be a non-empty Array in vectorSearch");
    return await new ji(
      e,
      t + "." + n,
      o
    ).collect();
  };
}
s(ef, "setupActionVectorSearch");
var ji = class {
  static {
    s(this, "VectorQueryImpl");
  }
  constructor(t, n, o) {
    Si(this, "requestId"), Si(this, "state"), this.requestId = t;
    let r = o.filter ? hn(o.filter(Kg)) : null;
    this.state = {
      type: "preparing",
      query: {
        indexName: n,
        limit: o.limit,
        vector: o.vector,
        expressions: r
      }
    };
  }
  async collect() {
    if (this.state.type === "consumed")
      throw new Error("This query is closed and can't emit any more values.");
    let t = this.state.query;
    this.state = { type: "consumed" };
    let { results: n } = await E("1.0/actions/vectorSearch", {
      requestId: this.requestId,
      version: G,
      query: t
    });
    return n;
  }
}, yt = class extends gn {
  static {
    s(this, "ExpressionImpl");
  }
  constructor(t) {
    super(), Si(this, "inner"), this.inner = t;
  }
  serialize() {
    return this.inner;
  }
};
function hn(e) {
  return e instanceof yt ? e.serialize() : { $literal: fe(e) };
}
s(hn, "serializeExpression");
var Kg = {
  //  Comparisons  /////////////////////////////////////////////////////////////
  eq(e, t) {
    if (typeof e != "string")
      throw new Error("The first argument to `q.eq` must be a field name.");
    return new yt({
      $eq: [
        hn(new yt({ $field: e })),
        hn(t)
      ]
    });
  },
  //  Logic  ///////////////////////////////////////////////////////////////////
  or(...e) {
    return new yt({ $or: e.map(hn) });
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/authentication_impl.js
function vn(e) {
  return {
    getUserIdentity: /* @__PURE__ */ s(async () => await E("1.0/getUserIdentity", {
      requestId: e
    }), "getUserIdentity")
  };
}
s(vn, "setupAuth");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/filter_builder.js
var Gg = Object.defineProperty, Xg = /* @__PURE__ */ s((e, t, n) => t in e ? Gg(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), tf = /* @__PURE__ */ s((e, t, n) => Xg(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), yn = class {
  static {
    s(this, "Expression");
  }
  /**
   * @internal
   */
  constructor() {
    tf(this, "_isExpression"), tf(this, "_value");
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/filter_builder_impl.js
var Qg = Object.defineProperty, Hg = /* @__PURE__ */ s((e, t, n) => t in e ? Qg(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), Yg = /* @__PURE__ */ s((e, t, n) => Hg(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), Q = class extends yn {
  static {
    s(this, "ExpressionImpl");
  }
  constructor(t) {
    super(), Yg(this, "inner"), this.inner = t;
  }
  serialize() {
    return this.inner;
  }
};
function D(e) {
  return e instanceof Q ? e.serialize() : { $literal: fe(e) };
}
s(D, "serializeExpression");
var rf = {
  //  Comparisons  /////////////////////////////////////////////////////////////
  eq(e, t) {
    return new Q({
      $eq: [D(e), D(t)]
    });
  },
  neq(e, t) {
    return new Q({
      $neq: [D(e), D(t)]
    });
  },
  lt(e, t) {
    return new Q({
      $lt: [D(e), D(t)]
    });
  },
  lte(e, t) {
    return new Q({
      $lte: [D(e), D(t)]
    });
  },
  gt(e, t) {
    return new Q({
      $gt: [D(e), D(t)]
    });
  },
  gte(e, t) {
    return new Q({
      $gte: [D(e), D(t)]
    });
  },
  //  Arithmetic  //////////////////////////////////////////////////////////////
  add(e, t) {
    return new Q({
      $add: [D(e), D(t)]
    });
  },
  sub(e, t) {
    return new Q({
      $sub: [D(e), D(t)]
    });
  },
  mul(e, t) {
    return new Q({
      $mul: [D(e), D(t)]
    });
  },
  div(e, t) {
    return new Q({
      $div: [D(e), D(t)]
    });
  },
  mod(e, t) {
    return new Q({
      $mod: [D(e), D(t)]
    });
  },
  neg(e) {
    return new Q({ $neg: D(e) });
  },
  //  Logic  ///////////////////////////////////////////////////////////////////
  and(...e) {
    return new Q({ $and: e.map(D) });
  },
  or(...e) {
    return new Q({ $or: e.map(D) });
  },
  not(e) {
    return new Q({ $not: D(e) });
  },
  //  Other  ///////////////////////////////////////////////////////////////////
  field(e) {
    return new Q({ $field: e });
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/index_range_builder.js
var eh = Object.defineProperty, th = /* @__PURE__ */ s((e, t, n) => t in e ? eh(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), rh = /* @__PURE__ */ s((e, t, n) => th(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), bn = class {
  static {
    s(this, "IndexRange");
  }
  /**
   * @internal
   */
  constructor() {
    rh(this, "_isIndexRange");
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/index_range_builder_impl.js
var nh = Object.defineProperty, oh = /* @__PURE__ */ s((e, t, n) => t in e ? nh(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), nf = /* @__PURE__ */ s((e, t, n) => oh(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), xn = class e extends bn {
  static {
    s(this, "IndexRangeBuilderImpl");
  }
  constructor(t) {
    super(), nf(this, "rangeExpressions"), nf(this, "isConsumed"), this.rangeExpressions = t, this.isConsumed = !1;
  }
  static new() {
    return new e([]);
  }
  consume() {
    if (this.isConsumed)
      throw new Error(
        "IndexRangeBuilder has already been used! Chain your method calls like `q => q.eq(...).eq(...)`. See https://docs.convex.dev/using/indexes"
      );
    this.isConsumed = !0;
  }
  eq(t, n) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Eq",
        fieldPath: t,
        value: fe(n)
      })
    );
  }
  gt(t, n) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Gt",
        fieldPath: t,
        value: fe(n)
      })
    );
  }
  gte(t, n) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Gte",
        fieldPath: t,
        value: fe(n)
      })
    );
  }
  lt(t, n) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Lt",
        fieldPath: t,
        value: fe(n)
      })
    );
  }
  lte(t, n) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Lte",
        fieldPath: t,
        value: fe(n)
      })
    );
  }
  export() {
    return this.consume(), this.rangeExpressions;
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/search_filter_builder.js
var ih = Object.defineProperty, ah = /* @__PURE__ */ s((e, t, n) => t in e ? ih(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), sh = /* @__PURE__ */ s((e, t, n) => ah(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), $n = class {
  static {
    s(this, "SearchFilter");
  }
  /**
   * @internal
   */
  constructor() {
    sh(this, "_isSearchFilter");
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/search_filter_builder_impl.js
var ch = Object.defineProperty, uh = /* @__PURE__ */ s((e, t, n) => t in e ? ch(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), of = /* @__PURE__ */ s((e, t, n) => uh(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), _n = class e extends $n {
  static {
    s(this, "SearchFilterBuilderImpl");
  }
  constructor(t) {
    super(), of(this, "filters"), of(this, "isConsumed"), this.filters = t, this.isConsumed = !1;
  }
  static new() {
    return new e([]);
  }
  consume() {
    if (this.isConsumed)
      throw new Error(
        "SearchFilterBuilder has already been used! Chain your method calls like `q => q.search(...).eq(...)`."
      );
    this.isConsumed = !0;
  }
  search(t, n) {
    return T(t, 1, "search", "fieldName"), T(n, 2, "search", "query"), this.consume(), new e(
      this.filters.concat({
        type: "Search",
        fieldPath: t,
        value: n
      })
    );
  }
  eq(t, n) {
    return T(t, 1, "eq", "fieldName"), arguments.length !== 2 && T(n, 2, "search", "value"), this.consume(), new e(
      this.filters.concat({
        type: "Eq",
        fieldPath: t,
        value: fe(n)
      })
    );
  }
  export() {
    return this.consume(), this.filters;
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/query_impl.js
var lh = Object.defineProperty, dh = /* @__PURE__ */ s((e, t, n) => t in e ? lh(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), Oi = /* @__PURE__ */ s((e, t, n) => dh(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), af = 256, bt = class {
  static {
    s(this, "QueryInitializerImpl");
  }
  constructor(t) {
    Oi(this, "tableName"), this.tableName = t;
  }
  withIndex(t, n) {
    T(t, 1, "withIndex", "indexName");
    let o = xn.new();
    return n !== void 0 && (o = n(o)), new He({
      source: {
        type: "IndexRange",
        indexName: this.tableName + "." + t,
        range: o.export(),
        order: null
      },
      operators: []
    });
  }
  withSearchIndex(t, n) {
    T(t, 1, "withSearchIndex", "indexName"), T(n, 2, "withSearchIndex", "searchFilter");
    let o = _n.new();
    return new He({
      source: {
        type: "Search",
        indexName: this.tableName + "." + t,
        filters: n(o).export()
      },
      operators: []
    });
  }
  fullTableScan() {
    return new He({
      source: {
        type: "FullTableScan",
        tableName: this.tableName,
        order: null
      },
      operators: []
    });
  }
  order(t) {
    return this.fullTableScan().order(t);
  }
  // This is internal API and should not be exposed to developers yet.
  async count() {
    let t = await E("1.0/count", {
      table: this.tableName
    });
    return L(t);
  }
  filter(t) {
    return this.fullTableScan().filter(t);
  }
  limit(t) {
    return this.fullTableScan().limit(t);
  }
  collect() {
    return this.fullTableScan().collect();
  }
  take(t) {
    return this.fullTableScan().take(t);
  }
  paginate(t) {
    return this.fullTableScan().paginate(t);
  }
  first() {
    return this.fullTableScan().first();
  }
  unique() {
    return this.fullTableScan().unique();
  }
  [Symbol.asyncIterator]() {
    return this.fullTableScan()[Symbol.asyncIterator]();
  }
};
function sf(e) {
  throw new Error(
    e === "consumed" ? "This query is closed and can't emit any more values." : "This query has been chained with another operator and can't be reused."
  );
}
s(sf, "throwClosedError");
var He = class e {
  static {
    s(this, "QueryImpl");
  }
  constructor(t) {
    Oi(this, "state"), Oi(this, "tableNameForErrorMessages"), this.state = { type: "preparing", query: t }, t.source.type === "FullTableScan" ? this.tableNameForErrorMessages = t.source.tableName : this.tableNameForErrorMessages = t.source.indexName.split(".")[0];
  }
  takeQuery() {
    if (this.state.type !== "preparing")
      throw new Error(
        "A query can only be chained once and can't be chained after iteration begins."
      );
    let t = this.state.query;
    return this.state = { type: "closed" }, t;
  }
  startQuery() {
    if (this.state.type === "executing")
      throw new Error("Iteration can only begin on a query once.");
    (this.state.type === "closed" || this.state.type === "consumed") && sf(this.state.type);
    let t = this.state.query, { queryId: n } = mr("1.0/queryStream", { query: t, version: G });
    return this.state = { type: "executing", queryId: n }, n;
  }
  closeQuery() {
    if (this.state.type === "executing") {
      let t = this.state.queryId;
      mr("1.0/queryCleanup", { queryId: t });
    }
    this.state = { type: "consumed" };
  }
  order(t) {
    T(t, 1, "order", "order");
    let n = this.takeQuery();
    if (n.source.type === "Search")
      throw new Error(
        "Search queries must always be in relevance order. Can not set order manually."
      );
    if (n.source.order !== null)
      throw new Error("Queries may only specify order at most once");
    return n.source.order = t, new e(n);
  }
  filter(t) {
    T(t, 1, "filter", "predicate");
    let n = this.takeQuery();
    if (n.operators.length >= af)
      throw new Error(
        `Can't construct query with more than ${af} operators`
      );
    return n.operators.push({
      filter: D(t(rf))
    }), new e(n);
  }
  limit(t) {
    T(t, 1, "limit", "n");
    let n = this.takeQuery();
    return n.operators.push({ limit: t }), new e(n);
  }
  [Symbol.asyncIterator]() {
    return this.startQuery(), this;
  }
  async next() {
    (this.state.type === "closed" || this.state.type === "consumed") && sf(this.state.type);
    let t = this.state.type === "preparing" ? this.startQuery() : this.state.queryId, { value: n, done: o } = await E("1.0/queryStreamNext", {
      queryId: t
    });
    return o && this.closeQuery(), { value: L(n), done: o };
  }
  return() {
    return this.closeQuery(), Promise.resolve({ done: !0, value: void 0 });
  }
  async paginate(t) {
    if (T(t, 1, "paginate", "options"), typeof t?.numItems != "number" || t.numItems < 0)
      throw new Error(
        `\`options.numItems\` must be a positive number. Received \`${t?.numItems}\`.`
      );
    let n = this.takeQuery(), o = t.numItems, r = t.cursor, i = t?.endCursor ?? null, a = t.maximumRowsRead ?? null, { page: c, isDone: u, continueCursor: l, splitCursor: d, pageStatus: p } = await E("1.0/queryPage", {
      query: n,
      cursor: r,
      endCursor: i,
      pageSize: o,
      maximumRowsRead: a,
      maximumBytesRead: t.maximumBytesRead,
      version: G
    });
    return {
      page: c.map((h) => L(h)),
      isDone: u,
      continueCursor: l,
      splitCursor: d,
      pageStatus: p
    };
  }
  async collect() {
    let t = [];
    for await (let n of this)
      t.push(n);
    return t;
  }
  async take(t) {
    return T(t, 1, "take", "n"), Yd(t, 1, "take", "n"), this.limit(t).collect();
  }
  async first() {
    let t = await this.take(1);
    return t.length === 0 ? null : t[0];
  }
  async unique() {
    let t = await this.take(2);
    if (t.length === 0)
      return null;
    if (t.length === 2)
      throw new Error(`unique() query returned more than one result from table ${this.tableNameForErrorMessages}:
 [${t[0]._id}, ${t[1]._id}, ...]`);
    return t[0];
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/database_impl.js
async function Pi(e, t, n) {
  if (T(t, 1, "get", "id"), typeof t != "string")
    throw new Error(
      `Invalid argument \`id\` for \`db.get\`, expected string but got '${typeof t}': ${t}`
    );
  let o = {
    id: R(t),
    isSystem: n,
    version: G,
    table: e
  }, r = await E("1.0/get", o);
  return L(r);
}
s(Pi, "get");
function Ni() {
  let e = /* @__PURE__ */ s((r = !1) => ({
    get: /* @__PURE__ */ s(async (i, a) => a !== void 0 ? await Pi(i, a, r) : await Pi(void 0, i, r), "get"),
    query: /* @__PURE__ */ s((i) => new hr(i, r).query(), "query"),
    normalizeId: /* @__PURE__ */ s((i, a) => {
      T(i, 1, "normalizeId", "tableName"), T(a, 2, "normalizeId", "id");
      let c = i.startsWith("_");
      if (c !== r)
        throw new Error(
          `${c ? "System" : "User"} tables can only be accessed from db.${r ? "" : "system."}normalizeId().`
        );
      let u = mr("1.0/db/normalizeId", {
        table: i,
        idString: a
      });
      return L(u).id;
    }, "normalizeId"),
    // We set the system reader on the next line
    system: null,
    table: /* @__PURE__ */ s((i) => new hr(i, r), "table")
  }), "reader"), { system: t, ...n } = e(!0), o = e();
  return o.system = n, o;
}
s(Ni, "setupReader");
async function cf(e, t) {
  if (e.startsWith("_"))
    throw new Error("System tables (prefixed with `_`) are read-only.");
  T(e, 1, "insert", "table"), T(t, 2, "insert", "value");
  let n = await E("1.0/insert", {
    table: e,
    value: R(t)
  });
  return L(n)._id;
}
s(cf, "insert");
async function Ti(e, t, n) {
  T(t, 1, "patch", "id"), T(n, 2, "patch", "value"), await E("1.0/shallowMerge", {
    id: R(t),
    value: qd(n),
    table: e
  });
}
s(Ti, "patch");
async function Ei(e, t, n) {
  T(t, 1, "replace", "id"), T(n, 2, "replace", "value"), await E("1.0/replace", {
    id: R(t),
    value: R(n),
    table: e
  });
}
s(Ei, "replace");
async function Ui(e, t) {
  T(t, 1, "delete", "id"), await E("1.0/remove", {
    id: R(t),
    table: e
  });
}
s(Ui, "delete_");
function uf() {
  let e = Ni();
  return {
    get: e.get,
    query: e.query,
    normalizeId: e.normalizeId,
    system: e.system,
    insert: /* @__PURE__ */ s(async (t, n) => await cf(t, n), "insert"),
    patch: /* @__PURE__ */ s(async (t, n, o) => o !== void 0 ? await Ti(t, n, o) : await Ti(void 0, t, n), "patch"),
    replace: /* @__PURE__ */ s(async (t, n, o) => o !== void 0 ? await Ei(t, n, o) : await Ei(void 0, t, n), "replace"),
    delete: /* @__PURE__ */ s(async (t, n) => n !== void 0 ? await Ui(t, n) : await Ui(void 0, t), "delete"),
    table: /* @__PURE__ */ s((t) => new Di(t, !1), "table")
  };
}
s(uf, "setupWriter");
var hr = class {
  static {
    s(this, "TableReader");
  }
  constructor(t, n) {
    this.tableName = t, this.isSystem = n;
  }
  async get(t) {
    return Pi(this.tableName, t, this.isSystem);
  }
  query() {
    let t = this.tableName.startsWith("_");
    if (t !== this.isSystem)
      throw new Error(
        `${t ? "System" : "User"} tables can only be accessed from db.${this.isSystem ? "" : "system."}query().`
      );
    return new bt(this.tableName);
  }
}, Di = class extends hr {
  static {
    s(this, "TableWriter");
  }
  async insert(t) {
    return cf(this.tableName, t);
  }
  async patch(t, n) {
    return Ti(this.tableName, t, n);
  }
  async replace(t, n) {
    return Ei(this.tableName, t, n);
  }
  async delete(t) {
    return Ui(this.tableName, t);
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/scheduler_impl.js
function lf() {
  return {
    runAfter: /* @__PURE__ */ s(async (e, t, n) => {
      let o = ff(e, t, n);
      return await E("1.0/schedule", o);
    }, "runAfter"),
    runAt: /* @__PURE__ */ s(async (e, t, n) => {
      let o = pf(
        e,
        t,
        n
      );
      return await E("1.0/schedule", o);
    }, "runAt"),
    cancel: /* @__PURE__ */ s(async (e) => {
      T(e, 1, "cancel", "id");
      let t = { id: R(e) };
      await E("1.0/cancel_job", t);
    }, "cancel")
  };
}
s(lf, "setupMutationScheduler");
function df(e) {
  return {
    runAfter: /* @__PURE__ */ s(async (t, n, o) => {
      let r = {
        requestId: e,
        ...ff(t, n, o)
      };
      return await E("1.0/actions/schedule", r);
    }, "runAfter"),
    runAt: /* @__PURE__ */ s(async (t, n, o) => {
      let r = {
        requestId: e,
        ...pf(t, n, o)
      };
      return await E("1.0/actions/schedule", r);
    }, "runAt"),
    cancel: /* @__PURE__ */ s(async (t) => {
      T(t, 1, "cancel", "id");
      let n = {
        requestId: e,
        id: R(t)
      };
      return await E("1.0/actions/cancel_job", n);
    }, "cancel")
  };
}
s(df, "setupActionScheduler");
function ff(e, t, n) {
  if (typeof e != "number")
    throw new Error("`delayMs` must be a number");
  if (!isFinite(e))
    throw new Error("`delayMs` must be a finite number");
  if (e < 0)
    throw new Error("`delayMs` must be non-negative");
  let o = Ue(n), r = ge(t), i = (Date.now() + e) / 1e3;
  return {
    ...r,
    ts: i,
    args: R(o),
    version: G
  };
}
s(ff, "runAfterSyscallArgs");
function pf(e, t, n) {
  let o;
  if (e instanceof Date)
    o = e.valueOf() / 1e3;
  else if (typeof e == "number")
    o = e / 1e3;
  else
    throw new Error("The invoke time must a Date or a timestamp");
  let r = ge(t), i = Ue(n);
  return {
    ...r,
    ts: o,
    args: R(i),
    version: G
  };
}
s(pf, "runAtSyscallArgs");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/storage_impl.js
function Zi(e) {
  return {
    getUrl: /* @__PURE__ */ s(async (t) => (T(t, 1, "getUrl", "storageId"), await E("1.0/storageGetUrl", {
      requestId: e,
      version: G,
      storageId: t
    })), "getUrl"),
    getMetadata: /* @__PURE__ */ s(async (t) => await E("1.0/storageGetMetadata", {
      requestId: e,
      version: G,
      storageId: t
    }), "getMetadata")
  };
}
s(Zi, "setupStorageReader");
function Ai(e) {
  let t = Zi(e);
  return {
    generateUploadUrl: /* @__PURE__ */ s(async () => await E("1.0/storageGenerateUploadUrl", {
      requestId: e,
      version: G
    }), "generateUploadUrl"),
    delete: /* @__PURE__ */ s(async (n) => {
      await E("1.0/storageDelete", {
        requestId: e,
        version: G,
        storageId: n
      });
    }, "delete"),
    getUrl: t.getUrl,
    getMetadata: t.getMetadata
  };
}
s(Ai, "setupStorageWriter");
function mf(e) {
  return {
    ...Ai(e),
    store: /* @__PURE__ */ s(async (n, o) => await mn("storage/storeBlob", {
      requestId: e,
      version: G,
      blob: n,
      options: o
    }), "store"),
    get: /* @__PURE__ */ s(async (n) => await mn("storage/getBlob", {
      requestId: e,
      version: G,
      storageId: n
    }), "get")
  };
}
s(mf, "setupStorageActionWriter");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/registration_impl.js
async function gf(e, t) {
  let o = L(JSON.parse(t)), r = {
    db: uf(),
    auth: vn(""),
    storage: Ai(""),
    scheduler: lf(),
    runQuery: /* @__PURE__ */ s((a, c) => Ci("query", a, c), "runQuery"),
    runMutation: /* @__PURE__ */ s((a, c) => Ci("mutation", a, c), "runMutation")
  }, i = await Ri(e, r, o);
  return hf(i), JSON.stringify(R(i === void 0 ? null : i));
}
s(gf, "invokeMutation");
function hf(e) {
  if (e instanceof bt || e instanceof He)
    throw new Error(
      "Return value is a Query. Results must be retrieved with `.collect()`, `.take(n), `.unique()`, or `.first()`."
    );
}
s(hf, "validateReturnValue");
async function Ri(e, t, n) {
  let o;
  try {
    o = await Promise.resolve(e(t, ...n));
  } catch (r) {
    throw fh(r);
  }
  return o;
}
s(Ri, "invokeFunction");
function xt(e, t) {
  return (n, o) => (globalThis.console.warn(
    `Convex functions should not directly call other Convex functions. Consider calling a helper function instead. e.g. \`export const foo = ${e}(...); await foo(ctx);\` is not supported. See https://docs.convex.dev/production/best-practices/#use-helper-functions-to-write-shared-code`
  ), t(n, o));
}
s(xt, "dontCallDirectly");
function fh(e) {
  if (typeof e == "object" && e !== null && Symbol.for("ConvexError") in e) {
    let t = e;
    return t.data = JSON.stringify(
      R(t.data === void 0 ? null : t.data)
    ), t.ConvexErrorSymbol = Symbol.for("ConvexError"), t;
  } else
    return e;
}
s(fh, "serializeConvexErrorData");
function $t() {
  if (typeof window > "u" || window.__convexAllowFunctionsInBrowser)
    return;
  (Object.getOwnPropertyDescriptor(globalThis, "window")?.get?.toString().includes("[native code]") ?? !1) && console.error(
    "Convex functions should not be imported in the browser. This will throw an error in future versions of `convex`. If this is a false negative, please report it to Convex support."
  );
}
s($t, "assertNotBrowser");
function vf(e, t) {
  if (t === void 0)
    throw new Error(
      `A validator is undefined for field "${e}". This is often caused by circular imports. See https://docs.convex.dev/error#undefined-validator for details.`
    );
  return t;
}
s(vf, "strictReplacer");
function _t(e) {
  return () => {
    let t = g.any();
    return typeof e == "object" && e.args !== void 0 && (t = pr(e.args)), JSON.stringify(t.json, vf);
  };
}
s(_t, "exportArgs");
function wt(e) {
  return () => {
    let t;
    return typeof e == "object" && e.returns !== void 0 && (t = pr(e.returns)), JSON.stringify(t ? t.json : null, vf);
  };
}
s(wt, "exportReturns");
var Fi = /* @__PURE__ */ s(((e) => {
  let t = typeof e == "function" ? e : e.handler, n = xt("mutation", t);
  return $t(), n.isMutation = !0, n.isPublic = !0, n.invokeMutation = (o) => gf(t, o), n.exportArgs = _t(e), n.exportReturns = wt(e), n._handler = t, n;
}), "mutationGeneric"), Li = /* @__PURE__ */ s(((e) => {
  let t = typeof e == "function" ? e : e.handler, n = xt(
    "internalMutation",
    t
  );
  return $t(), n.isMutation = !0, n.isInternal = !0, n.invokeMutation = (o) => gf(t, o), n.exportArgs = _t(e), n.exportReturns = wt(e), n._handler = t, n;
}), "internalMutationGeneric");
async function yf(e, t) {
  let o = L(JSON.parse(t)), r = {
    db: Ni(),
    auth: vn(""),
    storage: Zi(""),
    runQuery: /* @__PURE__ */ s((a, c) => Ci("query", a, c), "runQuery")
  }, i = await Ri(e, r, o);
  return hf(i), JSON.stringify(R(i === void 0 ? null : i));
}
s(yf, "invokeQuery");
var Mi = /* @__PURE__ */ s(((e) => {
  let t = typeof e == "function" ? e : e.handler, n = xt("query", t);
  return $t(), n.isQuery = !0, n.isPublic = !0, n.invokeQuery = (o) => yf(t, o), n.exportArgs = _t(e), n.exportReturns = wt(e), n._handler = t, n;
}), "queryGeneric"), Bi = /* @__PURE__ */ s(((e) => {
  let t = typeof e == "function" ? e : e.handler, n = xt("internalQuery", t);
  return $t(), n.isQuery = !0, n.isInternal = !0, n.invokeQuery = (o) => yf(t, o), n.exportArgs = _t(e), n.exportReturns = wt(e), n._handler = t, n;
}), "internalQueryGeneric");
async function bf(e, t, n) {
  let o = L(JSON.parse(n)), i = {
    ...Qd(t),
    auth: vn(t),
    scheduler: df(t),
    storage: mf(t),
    vectorSearch: ef(t)
  }, a = await Ri(e, i, o);
  return JSON.stringify(R(a === void 0 ? null : a));
}
s(bf, "invokeAction");
var Ji = /* @__PURE__ */ s(((e) => {
  let t = typeof e == "function" ? e : e.handler, n = xt("action", t);
  return $t(), n.isAction = !0, n.isPublic = !0, n.invokeAction = (o, r) => bf(t, o, r), n.exportArgs = _t(e), n.exportReturns = wt(e), n._handler = t, n;
}), "actionGeneric"), Vi = /* @__PURE__ */ s(((e) => {
  let t = typeof e == "function" ? e : e.handler, n = xt("internalAction", t);
  return $t(), n.isAction = !0, n.isInternal = !0, n.invokeAction = (o, r) => bf(t, o, r), n.exportArgs = _t(e), n.exportReturns = wt(e), n._handler = t, n;
}), "internalActionGeneric");
async function Ci(e, t, n) {
  let o = Ue(n), r = {
    udfType: e,
    args: R(o),
    ...ge(t)
  }, i = await E("1.0/runUdf", r);
  return L(i);
}
s(Ci, "runUdf");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/pagination.js
var ph = g.object({
  numItems: g.number(),
  cursor: g.union(g.string(), g.null()),
  endCursor: g.optional(g.union(g.string(), g.null())),
  id: g.optional(g.number()),
  maximumRowsRead: g.optional(g.number()),
  maximumBytesRead: g.optional(g.number())
});

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/api.js
function xf(e = []) {
  let t = {
    get(n, o) {
      if (typeof o == "string") {
        let r = [...e, o];
        return xf(r);
      } else if (o === gr) {
        if (e.length < 2) {
          let a = ["api", ...e].join(".");
          throw new Error(
            `API path is expected to be of the form \`api.moduleName.functionName\`. Found: \`${a}\``
          );
        }
        let r = e.slice(0, -1).join("/"), i = e[e.length - 1];
        return i === "default" ? r : r + ":" + i;
      } else return o === Symbol.toStringTag ? "FunctionReference" : void 0;
    }
  };
  return new Proxy({}, t);
}
s(xf, "createApi");
var mh = xf();

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/schema.js
var hh = Object.defineProperty, vh = /* @__PURE__ */ s((e, t, n) => t in e ? hh(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), ke = /* @__PURE__ */ s((e, t, n) => vh(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), wn = class {
  static {
    s(this, "TableDefinition");
  }
  /**
   * @internal
   */
  constructor(t) {
    ke(this, "indexes"), ke(this, "stagedDbIndexes"), ke(this, "searchIndexes"), ke(this, "stagedSearchIndexes"), ke(this, "vectorIndexes"), ke(this, "stagedVectorIndexes"), ke(this, "validator"), this.indexes = [], this.stagedDbIndexes = [], this.searchIndexes = [], this.stagedSearchIndexes = [], this.vectorIndexes = [], this.stagedVectorIndexes = [], this.validator = t;
  }
  /**
   * This API is experimental: it may change or disappear.
   *
   * Returns indexes defined on this table.
   * Intended for the advanced use cases of dynamically deciding which index to use for a query.
   * If you think you need this, please chime in on ths issue in the Convex JS GitHub repo.
   * https://github.com/get-convex/convex-js/issues/49
   */
  " indexes"() {
    return this.indexes;
  }
  index(t, n) {
    return Array.isArray(n) ? this.indexes.push({
      indexDescriptor: t,
      fields: n
    }) : n.staged ? this.stagedDbIndexes.push({
      indexDescriptor: t,
      fields: n.fields
    }) : this.indexes.push({
      indexDescriptor: t,
      fields: n.fields
    }), this;
  }
  searchIndex(t, n) {
    return n.staged ? this.stagedSearchIndexes.push({
      indexDescriptor: t,
      searchField: n.searchField,
      filterFields: n.filterFields || []
    }) : this.searchIndexes.push({
      indexDescriptor: t,
      searchField: n.searchField,
      filterFields: n.filterFields || []
    }), this;
  }
  vectorIndex(t, n) {
    return n.staged ? this.stagedVectorIndexes.push({
      indexDescriptor: t,
      vectorField: n.vectorField,
      dimensions: n.dimensions,
      filterFields: n.filterFields || []
    }) : this.vectorIndexes.push({
      indexDescriptor: t,
      vectorField: n.vectorField,
      dimensions: n.dimensions,
      filterFields: n.filterFields || []
    }), this;
  }
  /**
   * Work around for https://github.com/microsoft/TypeScript/issues/57035
   */
  self() {
    return this;
  }
  /**
   * Export the contents of this definition.
   *
   * This is called internally by the Convex framework.
   * @internal
   */
  export() {
    let t = this.validator.json;
    if (typeof t != "object")
      throw new Error(
        "Invalid validator: please make sure that the parameter of `defineTable` is valid (see https://docs.convex.dev/database/schemas)"
      );
    return {
      indexes: this.indexes,
      stagedDbIndexes: this.stagedDbIndexes,
      searchIndexes: this.searchIndexes,
      stagedSearchIndexes: this.stagedSearchIndexes,
      vectorIndexes: this.vectorIndexes,
      stagedVectorIndexes: this.stagedVectorIndexes,
      documentType: t
    };
  }
};
function Ye(e) {
  return ki(e) ? new wn(e) : new wn(g.object(e));
}
s(Ye, "defineTable");
var qi = class {
  static {
    s(this, "SchemaDefinition");
  }
  /**
   * @internal
   */
  constructor(t, n) {
    ke(this, "tables"), ke(this, "strictTableNameTypes"), ke(this, "schemaValidation"), this.tables = t, this.schemaValidation = n?.schemaValidation === void 0 ? !0 : n.schemaValidation;
  }
  /**
   * Export the contents of this definition.
   *
   * This is called internally by the Convex framework.
   * @internal
   */
  export() {
    return JSON.stringify({
      tables: Object.entries(this.tables).map(([t, n]) => {
        let {
          indexes: o,
          stagedDbIndexes: r,
          searchIndexes: i,
          stagedSearchIndexes: a,
          vectorIndexes: c,
          stagedVectorIndexes: u,
          documentType: l
        } = n.export();
        return {
          tableName: t,
          indexes: o,
          stagedDbIndexes: r,
          searchIndexes: i,
          stagedSearchIndexes: a,
          vectorIndexes: c,
          stagedVectorIndexes: u,
          documentType: l
        };
      }),
      schemaValidation: this.schemaValidation
    });
  }
};
function kn(e, t) {
  return new qi(e, t);
}
s(kn, "defineSchema");
var Y_ = kn({
  _scheduled_functions: Ye({
    name: g.string(),
    args: g.array(g.any()),
    scheduledTime: g.float64(),
    completedTime: g.optional(g.float64()),
    state: g.union(
      g.object({ kind: g.literal("pending") }),
      g.object({ kind: g.literal("inProgress") }),
      g.object({ kind: g.literal("success") }),
      g.object({ kind: g.literal("failed"), error: g.string() }),
      g.object({ kind: g.literal("canceled") })
    )
  }),
  _storage: Ye({
    sha256: g.string(),
    size: g.float64(),
    contentType: g.optional(g.string())
  })
});

// memory/profile.mjs
var et = class {
  static {
    s(this, "SecretText");
  }
  constructor(t) {
    this.value = t;
  }
  toWire() {
    return this.value;
  }
}, Wi = {
  seq: 1,
  at: 17e11,
  secret: "capacity",
  payload: "tiny"
};
function $f(e) {
  let t = e.kind === "native", n = e.kind === "full" || e.kind === "mini", o = t ? e.v : e.s;
  return /* @__PURE__ */ s(function({ count: i, width: a, profile: c, entries: u = 0 }) {
    if (!Number.isInteger(i) || i < 0 || !Number.isInteger(a) || a < 1 || !Number.isInteger(u) || u < 0 || !["fields-only", "codec-rich"].includes(c))
      throw new Error("Invalid graph fixture arguments");
    let l = {
      schemaConstructors: 0,
      fields: 0,
      codecSites: 0,
      allocatedCodecs: 0
    }, d = /* @__PURE__ */ s((z, ...P) => (l.schemaConstructors++, o[z](...P)), "make"), p = /* @__PURE__ */ s((z) => (l.fields += Object.keys(z).length, d("object", z)), "object"), h = /* @__PURE__ */ s(() => (l.codecSites++, t ? d("number") : (l.allocatedCodecs++, d("codec", d("number"), d("date"), {
      decode: /* @__PURE__ */ s((z) => new Date(z), "decode"),
      encode: /* @__PURE__ */ s((z) => z.getTime(), "encode")
    }))), "date"), v = /* @__PURE__ */ s(() => (l.codecSites++, t ? d("string") : (l.allocatedCodecs++, d("codec", d("string"), d("instanceof", et), {
      decode: /* @__PURE__ */ s((z) => new et(z), "decode"),
      encode: /* @__PURE__ */ s((z) => z.toWire(), "encode")
    }))), "secret"), O = /* @__PURE__ */ s((z) => {
      if (c === "fields-only")
        switch (z % 4) {
          case 0:
            return d("string");
          case 1:
            return d("number");
          case 2:
            return d("boolean");
          case 3:
            return d("optional", d("string"));
        }
      switch (z % 4) {
        case 0:
          return h();
        case 1:
          return v();
        case 2:
          return p({ at: h(), tag: d("optional", d("string")) });
        case 3:
          return d(
            "array",
            t ? d("union", d("string"), d("number")) : d("union", [d("string"), d("number")])
          );
      }
    }, "field"), I = {}, W = {}, Ge = /* @__PURE__ */ s((z, P) => {
      n ? (l.fields += Object.keys(P).length, I[z] = e.defineZodModel(z, P, e.schemaHelpers ? void 0 : { schemaHelpers: !1 })) : (W[z] = p(P), I[z] = t ? e.defineTable(W[z]) : W[z]);
    }, "add");
    Ge("benchmarkRows", {
      seq: d("number"),
      at: h(),
      secret: v(),
      payload: d("string")
    });
    for (let z = 0; z < i; z++) {
      let P = {};
      for (let J = 0; J < a; J++) P[`f${J}`] = O(J);
      Ge(`unused${z}`, P);
    }
    let _e = n ? e.defineZodSchema(I) : t ? e.defineSchema(I) : null;
    if (n) for (let z of Object.keys(I)) W[z] = _e.__zodTableMap[z].insert;
    let K = Object.keys(I), A = {};
    for (let z = 0; z < u; z++) {
      let P = K[z % K.length], J = n ? _e.__zodTableMap[P].doc : W[P], gt = p({
        id: d("string"),
        label: d("optional", d("string"))
      }), en = t ? d("union", J, d("null")) : d("nullable", J);
      A[`unused/fn${z}`] = { args: gt, returns: en };
    }
    let X = n ? e.initZodvex(
      _e,
      e.server,
      u ? { registry: /* @__PURE__ */ s(() => A, "registry") } : void 0
    ) : e.makeBuilders();
    return {
      kind: e.kind,
      options: { count: i, width: a, profile: c, entries: u },
      models: I,
      sourceSchemas: W,
      schema: _e,
      registry: A,
      builders: X,
      manifest: {
        backgroundModels: i,
        totalModels: i + 1,
        backgroundTopLevelFields: i * a,
        fixedProbeFields: 4,
        profile: c,
        registryEntries: u,
        ...l,
        counterScope: "Explicit fixture constructor calls and source fields/codecs; excludes library-generated helper schemas and runtime heap objects."
      },
      operation() {
        let z = { ...Wi }, P = t ? {
          ...z,
          at: new Date(z.at),
          secret: new et(z.secret)
        } : e.s.parse(W.benchmarkRows, z);
        if (!(P.at instanceof Date) || !(P.secret instanceof et))
          throw new Error("Codec decode failed");
        P.at = new Date(P.at.getTime() + 1e3), P.secret = new et(P.secret.toWire().toUpperCase());
        let J = t ? {
          ...P,
          at: P.at.getTime(),
          secret: P.secret.toWire()
        } : e.s.encode(W.benchmarkRows, P);
        if (JSON.stringify(J) !== JSON.stringify({
          ...Wi,
          at: Wi.at + 1e3,
          secret: "CAPACITY"
        }))
          throw new Error("Codec round trip mismatch");
        return J;
      },
      // Call after the operation and after GC measurements. The retained graph
      // includes every model, table schema, registry entry and builder closure.
      checksum() {
        let z = 0;
        for (let [P, J] of Object.entries(I)) {
          if (!J || !W[P]) throw new Error("Missing model");
          if (z += P.length, n && _e.__zodTableMap[P].insert !== W[P])
            throw new Error("Lost table-map alias");
        }
        for (let [P, J] of Object.entries(A)) {
          if (!J.args || !J.returns)
            throw new Error("Missing registry schema");
          z += P.length;
        }
        if (Object.keys(X).length === 0)
          throw new Error("Lost builders");
        return z;
      }
    };
  }, "buildGraph");
}
s($f, "createGraphFactory");

// versions/4.3.6/node_modules/zod/v4/classic/external.js
var w = {};
Oe(w, {
  $brand: () => zn,
  $input: () => Kc,
  $output: () => Wc,
  NEVER: () => Ki,
  TimePrecision: () => Hc,
  ZodAny: () => Al,
  ZodArray: () => Ll,
  ZodBase64: () => qo,
  ZodBase64URL: () => Wo,
  ZodBigInt: () => or,
  ZodBigIntFormat: () => Xo,
  ZodBoolean: () => nr,
  ZodCIDRv4: () => Jo,
  ZodCIDRv6: () => Vo,
  ZodCUID: () => Ao,
  ZodCUID2: () => Co,
  ZodCatch: () => ud,
  ZodCodec: () => ii,
  ZodCustom: () => Xr,
  ZodCustomStringFormat: () => tr,
  ZodDate: () => qr,
  ZodDefault: () => nd,
  ZodDiscriminatedUnion: () => Bl,
  ZodE164: () => Ko,
  ZodEmail: () => Do,
  ZodEmoji: () => No,
  ZodEnum: () => Yt,
  ZodError: () => Jy,
  ZodExactOptional: () => ed,
  ZodFile: () => Hl,
  ZodFirstPartyTypeKind: () => $d,
  ZodFunction: () => yd,
  ZodGUID: () => Lr,
  ZodIPv4: () => Mo,
  ZodIPv6: () => Bo,
  ZodISODate: () => Oo,
  ZodISODateTime: () => jo,
  ZodISODuration: () => To,
  ZodISOTime: () => Po,
  ZodIntersection: () => Jl,
  ZodIssueCode: () => qy,
  ZodJWT: () => Go,
  ZodKSUID: () => Lo,
  ZodLazy: () => gd,
  ZodLiteral: () => Ql,
  ZodMAC: () => El,
  ZodMap: () => Gl,
  ZodNaN: () => dd,
  ZodNanoID: () => Zo,
  ZodNever: () => Rl,
  ZodNonOptional: () => ni,
  ZodNull: () => Nl,
  ZodNullable: () => rd,
  ZodNumber: () => rr,
  ZodNumberFormat: () => ft,
  ZodObject: () => Wr,
  ZodOptional: () => ri,
  ZodPipe: () => oi,
  ZodPrefault: () => id,
  ZodPromise: () => vd,
  ZodReadonly: () => fd,
  ZodRealError: () => ae,
  ZodRecord: () => Gr,
  ZodSet: () => Xl,
  ZodString: () => er,
  ZodStringFormat: () => Z,
  ZodSuccess: () => cd,
  ZodSymbol: () => Ul,
  ZodTemplateLiteral: () => md,
  ZodTransform: () => Yl,
  ZodTuple: () => ql,
  ZodType: () => S,
  ZodULID: () => Ro,
  ZodURL: () => Br,
  ZodUUID: () => je,
  ZodUndefined: () => Dl,
  ZodUnion: () => Kr,
  ZodUnknown: () => Cl,
  ZodVoid: () => Fl,
  ZodXID: () => Fo,
  ZodXor: () => Ml,
  _ZodString: () => Uo,
  _default: () => od,
  _function: () => om,
  any: () => Rp,
  array: () => pt,
  base64: () => _p,
  base64url: () => wp,
  bigint: () => Dp,
  boolean: () => Vr,
  catch: () => ld,
  check: () => im,
  cidrv4: () => xp,
  cidrv6: () => $p,
  clone: () => V,
  codec: () => ai,
  coerce: () => _d,
  config: () => B,
  core: () => Ee,
  cuid: () => fp,
  cuid2: () => pp,
  custom: () => am,
  date: () => Ho,
  decode: () => zl,
  decodeAsync: () => Sl,
  describe: () => sm,
  discriminatedUnion: () => Vp,
  e164: () => kp,
  email: () => rp,
  emoji: () => lp,
  encode: () => Fr,
  encodeAsync: () => Il,
  endsWith: () => Mt,
  enum: () => ei,
  exactOptional: () => td,
  file: () => Hp,
  flattenError: () => kr,
  float32: () => Pp,
  float64: () => Tp,
  formatError: () => zr,
  fromJSONSchema: () => pm,
  function: () => om,
  getErrorMap: () => Ky,
  globalRegistry: () => H,
  gt: () => Ie,
  gte: () => re,
  guid: () => np,
  hash: () => Op,
  hex: () => jp,
  hostname: () => Sp,
  httpUrl: () => up,
  includes: () => Ft,
  instanceof: () => si,
  int: () => Eo,
  int32: () => Ep,
  int64: () => Np,
  intersection: () => Vl,
  ipv4: () => vp,
  ipv6: () => bp,
  iso: () => Qt,
  json: () => lm,
  jwt: () => zp,
  keyof: () => Lp,
  ksuid: () => hp,
  lazy: () => hd,
  length: () => ct,
  literal: () => Qp,
  locales: () => Nr,
  looseObject: () => Bp,
  looseRecord: () => Wp,
  lowercase: () => Ct,
  lt: () => ze,
  lte: () => le,
  mac: () => yp,
  map: () => Kp,
  maxLength: () => st,
  maxSize: () => Je,
  meta: () => cm,
  mime: () => Bt,
  minLength: () => Te,
  minSize: () => Se,
  multipleOf: () => Be,
  nan: () => tm,
  nanoid: () => dp,
  nativeEnum: () => Xp,
  negative: () => yo,
  never: () => Qo,
  nonnegative: () => xo,
  nonoptional: () => sd,
  nonpositive: () => bo,
  normalize: () => Jt,
  null: () => Zl,
  nullable: () => dt,
  nullish: () => Yp,
  number: () => Jr,
  object: () => Yo,
  optional: () => lt,
  overwrite: () => $e,
  parse: () => Rr,
  parseAsync: () => _l,
  partialRecord: () => qp,
  pipe: () => Mr,
  positive: () => vo,
  prefault: () => ad,
  preprocess: () => dm,
  prettifyError: () => aa,
  promise: () => nm,
  property: () => $o,
  readonly: () => pd,
  record: () => Kl,
  refine: () => bd,
  regex: () => At,
  regexes: () => me,
  registry: () => Gn,
  safeDecode: () => Ol,
  safeDecodeAsync: () => Tl,
  safeEncode: () => jl,
  safeEncodeAsync: () => Pl,
  safeParse: () => wl,
  safeParseAsync: () => kl,
  set: () => Gp,
  setErrorMap: () => Wy,
  size: () => at,
  slugify: () => Kt,
  startsWith: () => Lt,
  strictObject: () => Mp,
  string: () => Ht,
  stringFormat: () => Ip,
  stringbool: () => um,
  success: () => em,
  superRefine: () => xd,
  symbol: () => Ap,
  templateLiteral: () => rm,
  toJSONSchema: () => zo,
  toLowerCase: () => qt,
  toUpperCase: () => Wt,
  transform: () => ti,
  treeifyError: () => ia,
  trim: () => Vt,
  tuple: () => Wl,
  uint32: () => Up,
  uint64: () => Zp,
  ulid: () => mp,
  undefined: () => Cp,
  union: () => ir,
  unknown: () => ut,
  uppercase: () => Rt,
  url: () => cp,
  util: () => x,
  uuid: () => op,
  uuidv4: () => ip,
  uuidv6: () => ap,
  uuidv7: () => sp,
  void: () => Fp,
  xid: () => gp,
  xor: () => Jp
});

// versions/4.3.6/node_modules/zod/v4/core/index.js
var Ee = {};
Oe(Ee, {
  $ZodAny: () => Us,
  $ZodArray: () => Fe,
  $ZodAsyncError: () => he,
  $ZodBase64: () => ws,
  $ZodBase64URL: () => ks,
  $ZodBigInt: () => Wn,
  $ZodBigIntFormat: () => Os,
  $ZodBoolean: () => Or,
  $ZodCIDRv4: () => xs,
  $ZodCIDRv6: () => $s,
  $ZodCUID: () => cs,
  $ZodCUID2: () => us,
  $ZodCatch: () => Ks,
  $ZodCheck: () => C,
  $ZodCheckBigIntFormat: () => Ca,
  $ZodCheckEndsWith: () => Xa,
  $ZodCheckGreaterThan: () => Fn,
  $ZodCheckIncludes: () => Ka,
  $ZodCheckLengthEquals: () => Ja,
  $ZodCheckLessThan: () => Rn,
  $ZodCheckLowerCase: () => qa,
  $ZodCheckMaxLength: () => Ma,
  $ZodCheckMaxSize: () => Ra,
  $ZodCheckMimeType: () => Ha,
  $ZodCheckMinLength: () => Ba,
  $ZodCheckMinSize: () => Fa,
  $ZodCheckMultipleOf: () => Za,
  $ZodCheckNumberFormat: () => Aa,
  $ZodCheckOverwrite: () => Ya,
  $ZodCheckProperty: () => Qa,
  $ZodCheckRegex: () => Va,
  $ZodCheckSizeEquals: () => La,
  $ZodCheckStartsWith: () => Ga,
  $ZodCheckStringFormat: () => Tt,
  $ZodCheckUpperCase: () => Wa,
  $ZodCodec: () => xe,
  $ZodCustom: () => Pr,
  $ZodCustomStringFormat: () => Ss,
  $ZodDate: () => Et,
  $ZodDefault: () => ue,
  $ZodDiscriminatedUnion: () => Le,
  $ZodE164: () => zs,
  $ZodEmail: () => os,
  $ZodEmoji: () => as,
  $ZodEncodeError: () => De,
  $ZodEnum: () => Ut,
  $ZodError: () => ve,
  $ZodExactOptional: () => Js,
  $ZodFile: () => Ms,
  $ZodFunction: () => Ys,
  $ZodGUID: () => rs,
  $ZodIPv4: () => vs,
  $ZodIPv6: () => ys,
  $ZodISODate: () => ms,
  $ZodISODateTime: () => ps,
  $ZodISODuration: () => hs,
  $ZodISOTime: () => gs,
  $ZodIntersection: () => Rs,
  $ZodJWT: () => Is,
  $ZodKSUID: () => fs,
  $ZodLazy: () => Nt,
  $ZodLiteral: () => Dt,
  $ZodMAC: () => bs,
  $ZodMap: () => Fs,
  $ZodNaN: () => Gs,
  $ZodNanoID: () => ss,
  $ZodNever: () => Ns,
  $ZodNonOptional: () => qs,
  $ZodNull: () => Es,
  $ZodNullable: () => be,
  $ZodNumber: () => qn,
  $ZodNumberFormat: () => js,
  $ZodObject: () => q,
  $ZodObjectJIT: () => As,
  $ZodOptional: () => M,
  $ZodPipe: () => Xs,
  $ZodPrefault: () => Vs,
  $ZodPromise: () => ec,
  $ZodReadonly: () => Qs,
  $ZodRealError: () => ie,
  $ZodRecord: () => it,
  $ZodRegistry: () => Kn,
  $ZodSet: () => Ls,
  $ZodString: () => ot,
  $ZodStringFormat: () => N,
  $ZodSuccess: () => Ws,
  $ZodSymbol: () => Ps,
  $ZodTemplateLiteral: () => Hs,
  $ZodTransform: () => Bs,
  $ZodTuple: () => Me,
  $ZodType: () => k,
  $ZodULID: () => ls,
  $ZodURL: () => is,
  $ZodUUID: () => ns,
  $ZodUndefined: () => Ts,
  $ZodUnion: () => te,
  $ZodUnknown: () => Ds,
  $ZodVoid: () => Zs,
  $ZodXID: () => ds,
  $ZodXor: () => Cs,
  $brand: () => zn,
  $constructor: () => f,
  $input: () => Kc,
  $output: () => Wc,
  Doc: () => jr,
  JSONSchema: () => ep,
  JSONSchemaGenerator: () => Io,
  NEVER: () => Ki,
  TimePrecision: () => Hc,
  _any: () => bu,
  _array: () => Iu,
  _base64: () => po,
  _base64url: () => mo,
  _bigint: () => fu,
  _boolean: () => lu,
  _catch: () => Zy,
  _check: () => Yf,
  _cidrv4: () => lo,
  _cidrv6: () => fo,
  _coercedBigint: () => pu,
  _coercedBoolean: () => du,
  _coercedDate: () => ku,
  _coercedNumber: () => ou,
  _coercedString: () => Xc,
  _cuid: () => no,
  _cuid2: () => oo,
  _custom: () => ju,
  _date: () => wu,
  _decode: () => Pn,
  _decodeAsync: () => En,
  _default: () => Uy,
  _discriminatedUnion: () => $y,
  _e164: () => go,
  _email: () => Xn,
  _emoji: () => to,
  _encode: () => On,
  _encodeAsync: () => Tn,
  _endsWith: () => Mt,
  _enum: () => Sy,
  _file: () => Su,
  _float32: () => au,
  _float64: () => su,
  _gt: () => Ie,
  _gte: () => re,
  _guid: () => Zr,
  _includes: () => Ft,
  _int: () => iu,
  _int32: () => cu,
  _int64: () => mu,
  _intersection: () => _y,
  _ipv4: () => co,
  _ipv6: () => uo,
  _isoDate: () => eu,
  _isoDateTime: () => Yc,
  _isoDuration: () => ru,
  _isoTime: () => tu,
  _jwt: () => ho,
  _ksuid: () => so,
  _lazy: () => Fy,
  _length: () => ct,
  _literal: () => Oy,
  _lowercase: () => Ct,
  _lt: () => ze,
  _lte: () => le,
  _mac: () => Qc,
  _map: () => zy,
  _max: () => le,
  _maxLength: () => st,
  _maxSize: () => Je,
  _mime: () => Bt,
  _min: () => re,
  _minLength: () => Te,
  _minSize: () => Se,
  _multipleOf: () => Be,
  _nan: () => zu,
  _nanoid: () => ro,
  _nativeEnum: () => jy,
  _negative: () => yo,
  _never: () => $u,
  _nonnegative: () => xo,
  _nonoptional: () => Dy,
  _nonpositive: () => bo,
  _normalize: () => Jt,
  _null: () => yu,
  _nullable: () => Ey,
  _number: () => nu,
  _optional: () => Ty,
  _overwrite: () => $e,
  _parse: () => St,
  _parseAsync: () => jt,
  _pipe: () => Ay,
  _positive: () => vo,
  _promise: () => Ly,
  _property: () => $o,
  _readonly: () => Cy,
  _record: () => ky,
  _refine: () => Ou,
  _regex: () => At,
  _safeDecode: () => Dn,
  _safeDecodeAsync: () => Zn,
  _safeEncode: () => Un,
  _safeEncodeAsync: () => Nn,
  _safeParse: () => Ot,
  _safeParseAsync: () => Pt,
  _set: () => Iy,
  _size: () => at,
  _slugify: () => Kt,
  _startsWith: () => Lt,
  _string: () => Gc,
  _stringFormat: () => Gt,
  _stringbool: () => Uu,
  _success: () => Ny,
  _superRefine: () => Pu,
  _symbol: () => hu,
  _templateLiteral: () => Ry,
  _toLowerCase: () => qt,
  _toUpperCase: () => Wt,
  _transform: () => Py,
  _trim: () => Vt,
  _tuple: () => wy,
  _uint32: () => uu,
  _uint64: () => gu,
  _ulid: () => io,
  _undefined: () => vu,
  _union: () => by,
  _unknown: () => xu,
  _uppercase: () => Rt,
  _url: () => Ar,
  _uuid: () => Qn,
  _uuidv4: () => Hn,
  _uuidv6: () => Yn,
  _uuidv7: () => eo,
  _void: () => _u,
  _xid: () => ao,
  _xor: () => xy,
  clone: () => V,
  config: () => B,
  createStandardJSONSchemaMethod: () => Xt,
  createToJSONSchemaMethod: () => Du,
  decode: () => Jh,
  decodeAsync: () => qh,
  describe: () => Tu,
  encode: () => ye,
  encodeAsync: () => Vh,
  extractDefs: () => qe,
  finalize: () => We,
  flattenError: () => kr,
  formatError: () => zr,
  globalConfig: () => vr,
  globalRegistry: () => H,
  initializeContext: () => Ve,
  isValidBase64: () => _s,
  isValidBase64URL: () => Jf,
  isValidJWT: () => Vf,
  locales: () => Nr,
  meta: () => Eu,
  parse: () => Re,
  parseAsync: () => jn,
  prettifyError: () => aa,
  process: () => U,
  regexes: () => me,
  registry: () => Gn,
  safeDecode: () => Kh,
  safeDecodeAsync: () => Xh,
  safeEncode: () => Wh,
  safeEncodeAsync: () => Gh,
  safeParse: () => rt,
  safeParseAsync: () => sa,
  toDotPath: () => If,
  toJSONSchema: () => zo,
  treeifyError: () => ia,
  util: () => x,
  version: () => es
});

// versions/4.3.6/node_modules/zod/v4/core/core.js
var Ki = Object.freeze({
  status: "aborted"
});
// @__NO_SIDE_EFFECTS__
function f(e, t, n) {
  function o(c, u) {
    if (c._zod || Object.defineProperty(c, "_zod", {
      value: {
        def: u,
        constr: a,
        traits: /* @__PURE__ */ new Set()
      },
      enumerable: !1
    }), c._zod.traits.has(e))
      return;
    c._zod.traits.add(e), t(c, u);
    let l = a.prototype, d = Object.keys(l);
    for (let p = 0; p < d.length; p++) {
      let h = d[p];
      h in c || (c[h] = l[h].bind(c));
    }
  }
  s(o, "init");
  let r = n?.Parent ?? Object;
  class i extends r {
    static {
      s(this, "Definition");
    }
  }
  Object.defineProperty(i, "name", { value: e });
  function a(c) {
    var u;
    let l = n?.Parent ? new i() : this;
    o(l, c), (u = l._zod).deferred ?? (u.deferred = []);
    for (let d of l._zod.deferred)
      d();
    return l;
  }
  return s(a, "_"), Object.defineProperty(a, "init", { value: o }), Object.defineProperty(a, Symbol.hasInstance, {
    value: /* @__PURE__ */ s((c) => n?.Parent && c instanceof n.Parent ? !0 : c?._zod?.traits?.has(e), "value")
  }), Object.defineProperty(a, "name", { value: e }), a;
}
s(f, "$constructor");
var zn = Symbol("zod_brand"), he = class extends Error {
  static {
    s(this, "$ZodAsyncError");
  }
  constructor() {
    super("Encountered Promise during synchronous parse. Use .parseAsync() instead.");
  }
}, De = class extends Error {
  static {
    s(this, "$ZodEncodeError");
  }
  constructor(t) {
    super(`Encountered unidirectional transform during encode: ${t}`), this.name = "ZodEncodeError";
  }
}, vr = {};
function B(e) {
  return e && Object.assign(vr, e), vr;
}
s(B, "config");

// versions/4.3.6/node_modules/zod/v4/core/util.js
var x = {};
Oe(x, {
  BIGINT_FORMAT_RANGES: () => oa,
  Class: () => Xi,
  NUMBER_FORMAT_RANGES: () => na,
  aborted: () => Ce,
  allowsEval: () => Yi,
  assert: () => _h,
  assertEqual: () => yh,
  assertIs: () => xh,
  assertNever: () => $h,
  assertNotEqual: () => bh,
  assignProp: () => Ze,
  base64ToUint8Array: () => wf,
  base64urlToUint8Array: () => Rh,
  cached: () => zt,
  captureStackTrace: () => Sn,
  cleanEnum: () => Ch,
  cleanRegex: () => xr,
  clone: () => V,
  cloneDef: () => kh,
  createTransparentProxy: () => Ph,
  defineLazy: () => j,
  esc: () => In,
  escapeRegex: () => pe,
  extend: () => Uh,
  finalizeIssue: () => oe,
  floatSafeRemainder: () => Qi,
  getElementAtPath: () => zh,
  getEnumValues: () => br,
  getLengthableOrigin: () => wr,
  getParsedType: () => Oh,
  getSizableOrigin: () => _r,
  hexToUint8Array: () => Lh,
  isObject: () => tt,
  isPlainObject: () => Ae,
  issue: () => It,
  joinValues: () => m,
  jsonStringifyReplacer: () => kt,
  merge: () => Nh,
  mergeDefs: () => Pe,
  normalizeParams: () => $,
  nullish: () => Ne,
  numKeys: () => jh,
  objectClone: () => wh,
  omit: () => Eh,
  optionalKeys: () => ra,
  parsedType: () => b,
  partial: () => Zh,
  pick: () => Th,
  prefixIssues: () => ce,
  primitiveTypes: () => ta,
  promiseAllObject: () => Ih,
  propertyKeyTypes: () => $r,
  randomString: () => Sh,
  required: () => Ah,
  safeExtend: () => Dh,
  shallowClone: () => ea,
  slugify: () => Hi,
  stringifyPrimitive: () => y,
  uint8ArrayToBase64: () => kf,
  uint8ArrayToBase64url: () => Fh,
  uint8ArrayToHex: () => Mh,
  unwrapMessage: () => yr
});
function yh(e) {
  return e;
}
s(yh, "assertEqual");
function bh(e) {
  return e;
}
s(bh, "assertNotEqual");
function xh(e) {
}
s(xh, "assertIs");
function $h(e) {
  throw new Error("Unexpected value in exhaustive check");
}
s($h, "assertNever");
function _h(e) {
}
s(_h, "assert");
function br(e) {
  let t = Object.values(e).filter((o) => typeof o == "number");
  return Object.entries(e).filter(([o, r]) => t.indexOf(+o) === -1).map(([o, r]) => r);
}
s(br, "getEnumValues");
function m(e, t = "|") {
  return e.map((n) => y(n)).join(t);
}
s(m, "joinValues");
function kt(e, t) {
  return typeof t == "bigint" ? t.toString() : t;
}
s(kt, "jsonStringifyReplacer");
function zt(e) {
  return {
    get value() {
      {
        let n = e();
        return Object.defineProperty(this, "value", { value: n }), n;
      }
      throw new Error("cached value already set");
    }
  };
}
s(zt, "cached");
function Ne(e) {
  return e == null;
}
s(Ne, "nullish");
function xr(e) {
  let t = e.startsWith("^") ? 1 : 0, n = e.endsWith("$") ? e.length - 1 : e.length;
  return e.slice(t, n);
}
s(xr, "cleanRegex");
function Qi(e, t) {
  let n = (e.toString().split(".")[1] || "").length, o = t.toString(), r = (o.split(".")[1] || "").length;
  if (r === 0 && /\d?e-\d?/.test(o)) {
    let u = o.match(/\d?e-(\d?)/);
    u?.[1] && (r = Number.parseInt(u[1]));
  }
  let i = n > r ? n : r, a = Number.parseInt(e.toFixed(i).replace(".", "")), c = Number.parseInt(t.toFixed(i).replace(".", ""));
  return a % c / 10 ** i;
}
s(Qi, "floatSafeRemainder");
var _f = Symbol("evaluating");
function j(e, t, n) {
  let o;
  Object.defineProperty(e, t, {
    get() {
      if (o !== _f)
        return o === void 0 && (o = _f, o = n()), o;
    },
    set(r) {
      Object.defineProperty(e, t, {
        value: r
        // configurable: true,
      });
    },
    configurable: !0
  });
}
s(j, "defineLazy");
function wh(e) {
  return Object.create(Object.getPrototypeOf(e), Object.getOwnPropertyDescriptors(e));
}
s(wh, "objectClone");
function Ze(e, t, n) {
  Object.defineProperty(e, t, {
    value: n,
    writable: !0,
    enumerable: !0,
    configurable: !0
  });
}
s(Ze, "assignProp");
function Pe(...e) {
  let t = {};
  for (let n of e) {
    let o = Object.getOwnPropertyDescriptors(n);
    Object.assign(t, o);
  }
  return Object.defineProperties({}, t);
}
s(Pe, "mergeDefs");
function kh(e) {
  return Pe(e._zod.def);
}
s(kh, "cloneDef");
function zh(e, t) {
  return t ? t.reduce((n, o) => n?.[o], e) : e;
}
s(zh, "getElementAtPath");
function Ih(e) {
  let t = Object.keys(e), n = t.map((o) => e[o]);
  return Promise.all(n).then((o) => {
    let r = {};
    for (let i = 0; i < t.length; i++)
      r[t[i]] = o[i];
    return r;
  });
}
s(Ih, "promiseAllObject");
function Sh(e = 10) {
  let t = "abcdefghijklmnopqrstuvwxyz", n = "";
  for (let o = 0; o < e; o++)
    n += t[Math.floor(Math.random() * t.length)];
  return n;
}
s(Sh, "randomString");
function In(e) {
  return JSON.stringify(e);
}
s(In, "esc");
function Hi(e) {
  return e.toLowerCase().trim().replace(/[^\w\s-]/g, "").replace(/[\s_-]+/g, "-").replace(/^-+|-+$/g, "");
}
s(Hi, "slugify");
var Sn = "captureStackTrace" in Error ? Error.captureStackTrace : (...e) => {
};
function tt(e) {
  return typeof e == "object" && e !== null && !Array.isArray(e);
}
s(tt, "isObject");
var Yi = zt(() => {
  if (typeof navigator < "u" && navigator?.userAgent?.includes("Cloudflare"))
    return !1;
  try {
    let e = Function;
    return new e(""), !0;
  } catch {
    return !1;
  }
});
function Ae(e) {
  if (tt(e) === !1)
    return !1;
  let t = e.constructor;
  if (t === void 0 || typeof t != "function")
    return !0;
  let n = t.prototype;
  return !(tt(n) === !1 || Object.prototype.hasOwnProperty.call(n, "isPrototypeOf") === !1);
}
s(Ae, "isPlainObject");
function ea(e) {
  return Ae(e) ? { ...e } : Array.isArray(e) ? [...e] : e;
}
s(ea, "shallowClone");
function jh(e) {
  let t = 0;
  for (let n in e)
    Object.prototype.hasOwnProperty.call(e, n) && t++;
  return t;
}
s(jh, "numKeys");
var Oh = /* @__PURE__ */ s((e) => {
  let t = typeof e;
  switch (t) {
    case "undefined":
      return "undefined";
    case "string":
      return "string";
    case "number":
      return Number.isNaN(e) ? "nan" : "number";
    case "boolean":
      return "boolean";
    case "function":
      return "function";
    case "bigint":
      return "bigint";
    case "symbol":
      return "symbol";
    case "object":
      return Array.isArray(e) ? "array" : e === null ? "null" : e.then && typeof e.then == "function" && e.catch && typeof e.catch == "function" ? "promise" : typeof Map < "u" && e instanceof Map ? "map" : typeof Set < "u" && e instanceof Set ? "set" : typeof Date < "u" && e instanceof Date ? "date" : typeof File < "u" && e instanceof File ? "file" : "object";
    default:
      throw new Error(`Unknown data type: ${t}`);
  }
}, "getParsedType"), $r = /* @__PURE__ */ new Set(["string", "number", "symbol"]), ta = /* @__PURE__ */ new Set(["string", "number", "bigint", "boolean", "symbol", "undefined"]);
function pe(e) {
  return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
s(pe, "escapeRegex");
function V(e, t, n) {
  let o = new e._zod.constr(t ?? e._zod.def);
  return (!t || n?.parent) && (o._zod.parent = e), o;
}
s(V, "clone");
function $(e) {
  let t = e;
  if (!t)
    return {};
  if (typeof t == "string")
    return { error: /* @__PURE__ */ s(() => t, "error") };
  if (t?.message !== void 0) {
    if (t?.error !== void 0)
      throw new Error("Cannot specify both `message` and `error` params");
    t.error = t.message;
  }
  return delete t.message, typeof t.error == "string" ? { ...t, error: /* @__PURE__ */ s(() => t.error, "error") } : t;
}
s($, "normalizeParams");
function Ph(e) {
  let t;
  return new Proxy({}, {
    get(n, o, r) {
      return t ?? (t = e()), Reflect.get(t, o, r);
    },
    set(n, o, r, i) {
      return t ?? (t = e()), Reflect.set(t, o, r, i);
    },
    has(n, o) {
      return t ?? (t = e()), Reflect.has(t, o);
    },
    deleteProperty(n, o) {
      return t ?? (t = e()), Reflect.deleteProperty(t, o);
    },
    ownKeys(n) {
      return t ?? (t = e()), Reflect.ownKeys(t);
    },
    getOwnPropertyDescriptor(n, o) {
      return t ?? (t = e()), Reflect.getOwnPropertyDescriptor(t, o);
    },
    defineProperty(n, o, r) {
      return t ?? (t = e()), Reflect.defineProperty(t, o, r);
    }
  });
}
s(Ph, "createTransparentProxy");
function y(e) {
  return typeof e == "bigint" ? e.toString() + "n" : typeof e == "string" ? `"${e}"` : `${e}`;
}
s(y, "stringifyPrimitive");
function ra(e) {
  return Object.keys(e).filter((t) => e[t]._zod.optin === "optional" && e[t]._zod.optout === "optional");
}
s(ra, "optionalKeys");
var na = {
  safeint: [Number.MIN_SAFE_INTEGER, Number.MAX_SAFE_INTEGER],
  int32: [-2147483648, 2147483647],
  uint32: [0, 4294967295],
  float32: [-34028234663852886e22, 34028234663852886e22],
  float64: [-Number.MAX_VALUE, Number.MAX_VALUE]
}, oa = {
  int64: [/* @__PURE__ */ BigInt("-9223372036854775808"), /* @__PURE__ */ BigInt("9223372036854775807")],
  uint64: [/* @__PURE__ */ BigInt(0), /* @__PURE__ */ BigInt("18446744073709551615")]
};
function Th(e, t) {
  let n = e._zod.def, o = n.checks;
  if (o && o.length > 0)
    throw new Error(".pick() cannot be used on object schemas containing refinements");
  let i = Pe(e._zod.def, {
    get shape() {
      let a = {};
      for (let c in t) {
        if (!(c in n.shape))
          throw new Error(`Unrecognized key: "${c}"`);
        t[c] && (a[c] = n.shape[c]);
      }
      return Ze(this, "shape", a), a;
    },
    checks: []
  });
  return V(e, i);
}
s(Th, "pick");
function Eh(e, t) {
  let n = e._zod.def, o = n.checks;
  if (o && o.length > 0)
    throw new Error(".omit() cannot be used on object schemas containing refinements");
  let i = Pe(e._zod.def, {
    get shape() {
      let a = { ...e._zod.def.shape };
      for (let c in t) {
        if (!(c in n.shape))
          throw new Error(`Unrecognized key: "${c}"`);
        t[c] && delete a[c];
      }
      return Ze(this, "shape", a), a;
    },
    checks: []
  });
  return V(e, i);
}
s(Eh, "omit");
function Uh(e, t) {
  if (!Ae(t))
    throw new Error("Invalid input to extend: expected a plain object");
  let n = e._zod.def.checks;
  if (n && n.length > 0) {
    let i = e._zod.def.shape;
    for (let a in t)
      if (Object.getOwnPropertyDescriptor(i, a) !== void 0)
        throw new Error("Cannot overwrite keys on object schemas containing refinements. Use `.safeExtend()` instead.");
  }
  let r = Pe(e._zod.def, {
    get shape() {
      let i = { ...e._zod.def.shape, ...t };
      return Ze(this, "shape", i), i;
    }
  });
  return V(e, r);
}
s(Uh, "extend");
function Dh(e, t) {
  if (!Ae(t))
    throw new Error("Invalid input to safeExtend: expected a plain object");
  let n = Pe(e._zod.def, {
    get shape() {
      let o = { ...e._zod.def.shape, ...t };
      return Ze(this, "shape", o), o;
    }
  });
  return V(e, n);
}
s(Dh, "safeExtend");
function Nh(e, t) {
  let n = Pe(e._zod.def, {
    get shape() {
      let o = { ...e._zod.def.shape, ...t._zod.def.shape };
      return Ze(this, "shape", o), o;
    },
    get catchall() {
      return t._zod.def.catchall;
    },
    checks: []
    // delete existing checks
  });
  return V(e, n);
}
s(Nh, "merge");
function Zh(e, t, n) {
  let r = t._zod.def.checks;
  if (r && r.length > 0)
    throw new Error(".partial() cannot be used on object schemas containing refinements");
  let a = Pe(t._zod.def, {
    get shape() {
      let c = t._zod.def.shape, u = { ...c };
      if (n)
        for (let l in n) {
          if (!(l in c))
            throw new Error(`Unrecognized key: "${l}"`);
          n[l] && (u[l] = e ? new e({
            type: "optional",
            innerType: c[l]
          }) : c[l]);
        }
      else
        for (let l in c)
          u[l] = e ? new e({
            type: "optional",
            innerType: c[l]
          }) : c[l];
      return Ze(this, "shape", u), u;
    },
    checks: []
  });
  return V(t, a);
}
s(Zh, "partial");
function Ah(e, t, n) {
  let o = Pe(t._zod.def, {
    get shape() {
      let r = t._zod.def.shape, i = { ...r };
      if (n)
        for (let a in n) {
          if (!(a in i))
            throw new Error(`Unrecognized key: "${a}"`);
          n[a] && (i[a] = new e({
            type: "nonoptional",
            innerType: r[a]
          }));
        }
      else
        for (let a in r)
          i[a] = new e({
            type: "nonoptional",
            innerType: r[a]
          });
      return Ze(this, "shape", i), i;
    }
  });
  return V(t, o);
}
s(Ah, "required");
function Ce(e, t = 0) {
  if (e.aborted === !0)
    return !0;
  for (let n = t; n < e.issues.length; n++)
    if (e.issues[n]?.continue !== !0)
      return !0;
  return !1;
}
s(Ce, "aborted");
function ce(e, t) {
  return t.map((n) => {
    var o;
    return (o = n).path ?? (o.path = []), n.path.unshift(e), n;
  });
}
s(ce, "prefixIssues");
function yr(e) {
  return typeof e == "string" ? e : e?.message;
}
s(yr, "unwrapMessage");
function oe(e, t, n) {
  let o = { ...e, path: e.path ?? [] };
  if (!e.message) {
    let r = yr(e.inst?._zod.def?.error?.(e)) ?? yr(t?.error?.(e)) ?? yr(n.customError?.(e)) ?? yr(n.localeError?.(e)) ?? "Invalid input";
    o.message = r;
  }
  return delete o.inst, delete o.continue, t?.reportInput || delete o.input, o;
}
s(oe, "finalizeIssue");
function _r(e) {
  return e instanceof Set ? "set" : e instanceof Map ? "map" : e instanceof File ? "file" : "unknown";
}
s(_r, "getSizableOrigin");
function wr(e) {
  return Array.isArray(e) ? "array" : typeof e == "string" ? "string" : "unknown";
}
s(wr, "getLengthableOrigin");
function b(e) {
  let t = typeof e;
  switch (t) {
    case "number":
      return Number.isNaN(e) ? "nan" : "number";
    case "object": {
      if (e === null)
        return "null";
      if (Array.isArray(e))
        return "array";
      let n = e;
      if (n && Object.getPrototypeOf(n) !== Object.prototype && "constructor" in n && n.constructor)
        return n.constructor.name;
    }
  }
  return t;
}
s(b, "parsedType");
function It(...e) {
  let [t, n, o] = e;
  return typeof t == "string" ? {
    message: t,
    code: "custom",
    input: n,
    inst: o
  } : { ...t };
}
s(It, "issue");
function Ch(e) {
  return Object.entries(e).filter(([t, n]) => Number.isNaN(Number.parseInt(t, 10))).map((t) => t[1]);
}
s(Ch, "cleanEnum");
function wf(e) {
  let t = atob(e), n = new Uint8Array(t.length);
  for (let o = 0; o < t.length; o++)
    n[o] = t.charCodeAt(o);
  return n;
}
s(wf, "base64ToUint8Array");
function kf(e) {
  let t = "";
  for (let n = 0; n < e.length; n++)
    t += String.fromCharCode(e[n]);
  return btoa(t);
}
s(kf, "uint8ArrayToBase64");
function Rh(e) {
  let t = e.replace(/-/g, "+").replace(/_/g, "/"), n = "=".repeat((4 - t.length % 4) % 4);
  return wf(t + n);
}
s(Rh, "base64urlToUint8Array");
function Fh(e) {
  return kf(e).replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, "");
}
s(Fh, "uint8ArrayToBase64url");
function Lh(e) {
  let t = e.replace(/^0x/, "");
  if (t.length % 2 !== 0)
    throw new Error("Invalid hex string length");
  let n = new Uint8Array(t.length / 2);
  for (let o = 0; o < t.length; o += 2)
    n[o / 2] = Number.parseInt(t.slice(o, o + 2), 16);
  return n;
}
s(Lh, "hexToUint8Array");
function Mh(e) {
  return Array.from(e).map((t) => t.toString(16).padStart(2, "0")).join("");
}
s(Mh, "uint8ArrayToHex");
var Xi = class {
  static {
    s(this, "Class");
  }
  constructor(...t) {
  }
};

// versions/4.3.6/node_modules/zod/v4/core/errors.js
var zf = /* @__PURE__ */ s((e, t) => {
  e.name = "$ZodError", Object.defineProperty(e, "_zod", {
    value: e._zod,
    enumerable: !1
  }), Object.defineProperty(e, "issues", {
    value: t,
    enumerable: !1
  }), e.message = JSON.stringify(t, kt, 2), Object.defineProperty(e, "toString", {
    value: /* @__PURE__ */ s(() => e.message, "value"),
    enumerable: !1
  });
}, "initializer"), ve = f("$ZodError", zf), ie = f("$ZodError", zf, { Parent: Error });
function kr(e, t = (n) => n.message) {
  let n = {}, o = [];
  for (let r of e.issues)
    r.path.length > 0 ? (n[r.path[0]] = n[r.path[0]] || [], n[r.path[0]].push(t(r))) : o.push(t(r));
  return { formErrors: o, fieldErrors: n };
}
s(kr, "flattenError");
function zr(e, t = (n) => n.message) {
  let n = { _errors: [] }, o = /* @__PURE__ */ s((r) => {
    for (let i of r.issues)
      if (i.code === "invalid_union" && i.errors.length)
        i.errors.map((a) => o({ issues: a }));
      else if (i.code === "invalid_key")
        o({ issues: i.issues });
      else if (i.code === "invalid_element")
        o({ issues: i.issues });
      else if (i.path.length === 0)
        n._errors.push(t(i));
      else {
        let a = n, c = 0;
        for (; c < i.path.length; ) {
          let u = i.path[c];
          c === i.path.length - 1 ? (a[u] = a[u] || { _errors: [] }, a[u]._errors.push(t(i))) : a[u] = a[u] || { _errors: [] }, a = a[u], c++;
        }
      }
  }, "processError");
  return o(e), n;
}
s(zr, "formatError");
function ia(e, t = (n) => n.message) {
  let n = { errors: [] }, o = /* @__PURE__ */ s((r, i = []) => {
    var a, c;
    for (let u of r.issues)
      if (u.code === "invalid_union" && u.errors.length)
        u.errors.map((l) => o({ issues: l }, u.path));
      else if (u.code === "invalid_key")
        o({ issues: u.issues }, u.path);
      else if (u.code === "invalid_element")
        o({ issues: u.issues }, u.path);
      else {
        let l = [...i, ...u.path];
        if (l.length === 0) {
          n.errors.push(t(u));
          continue;
        }
        let d = n, p = 0;
        for (; p < l.length; ) {
          let h = l[p], v = p === l.length - 1;
          typeof h == "string" ? (d.properties ?? (d.properties = {}), (a = d.properties)[h] ?? (a[h] = { errors: [] }), d = d.properties[h]) : (d.items ?? (d.items = []), (c = d.items)[h] ?? (c[h] = { errors: [] }), d = d.items[h]), v && d.errors.push(t(u)), p++;
        }
      }
  }, "processError");
  return o(e), n;
}
s(ia, "treeifyError");
function If(e) {
  let t = [], n = e.map((o) => typeof o == "object" ? o.key : o);
  for (let o of n)
    typeof o == "number" ? t.push(`[${o}]`) : typeof o == "symbol" ? t.push(`[${JSON.stringify(String(o))}]`) : /[^\w$]/.test(o) ? t.push(`[${JSON.stringify(o)}]`) : (t.length && t.push("."), t.push(o));
  return t.join("");
}
s(If, "toDotPath");
function aa(e) {
  let t = [], n = [...e.issues].sort((o, r) => (o.path ?? []).length - (r.path ?? []).length);
  for (let o of n)
    t.push(`\u2716 ${o.message}`), o.path?.length && t.push(`  \u2192 at ${If(o.path)}`);
  return t.join(`
`);
}
s(aa, "prettifyError");

// versions/4.3.6/node_modules/zod/v4/core/parse.js
var St = /* @__PURE__ */ s((e) => (t, n, o, r) => {
  let i = o ? Object.assign(o, { async: !1 }) : { async: !1 }, a = t._zod.run({ value: n, issues: [] }, i);
  if (a instanceof Promise)
    throw new he();
  if (a.issues.length) {
    let c = new (r?.Err ?? e)(a.issues.map((u) => oe(u, i, B())));
    throw Sn(c, r?.callee), c;
  }
  return a.value;
}, "_parse"), Re = /* @__PURE__ */ St(ie), jt = /* @__PURE__ */ s((e) => async (t, n, o, r) => {
  let i = o ? Object.assign(o, { async: !0 }) : { async: !0 }, a = t._zod.run({ value: n, issues: [] }, i);
  if (a instanceof Promise && (a = await a), a.issues.length) {
    let c = new (r?.Err ?? e)(a.issues.map((u) => oe(u, i, B())));
    throw Sn(c, r?.callee), c;
  }
  return a.value;
}, "_parseAsync"), jn = /* @__PURE__ */ jt(ie), Ot = /* @__PURE__ */ s((e) => (t, n, o) => {
  let r = o ? { ...o, async: !1 } : { async: !1 }, i = t._zod.run({ value: n, issues: [] }, r);
  if (i instanceof Promise)
    throw new he();
  return i.issues.length ? {
    success: !1,
    error: new (e ?? ve)(i.issues.map((a) => oe(a, r, B())))
  } : { success: !0, data: i.value };
}, "_safeParse"), rt = /* @__PURE__ */ Ot(ie), Pt = /* @__PURE__ */ s((e) => async (t, n, o) => {
  let r = o ? Object.assign(o, { async: !0 }) : { async: !0 }, i = t._zod.run({ value: n, issues: [] }, r);
  return i instanceof Promise && (i = await i), i.issues.length ? {
    success: !1,
    error: new e(i.issues.map((a) => oe(a, r, B())))
  } : { success: !0, data: i.value };
}, "_safeParseAsync"), sa = /* @__PURE__ */ Pt(ie), On = /* @__PURE__ */ s((e) => (t, n, o) => {
  let r = o ? Object.assign(o, { direction: "backward" }) : { direction: "backward" };
  return St(e)(t, n, r);
}, "_encode"), ye = /* @__PURE__ */ On(ie), Pn = /* @__PURE__ */ s((e) => (t, n, o) => St(e)(t, n, o), "_decode"), Jh = /* @__PURE__ */ Pn(ie), Tn = /* @__PURE__ */ s((e) => async (t, n, o) => {
  let r = o ? Object.assign(o, { direction: "backward" }) : { direction: "backward" };
  return jt(e)(t, n, r);
}, "_encodeAsync"), Vh = /* @__PURE__ */ Tn(ie), En = /* @__PURE__ */ s((e) => async (t, n, o) => jt(e)(t, n, o), "_decodeAsync"), qh = /* @__PURE__ */ En(ie), Un = /* @__PURE__ */ s((e) => (t, n, o) => {
  let r = o ? Object.assign(o, { direction: "backward" }) : { direction: "backward" };
  return Ot(e)(t, n, r);
}, "_safeEncode"), Wh = /* @__PURE__ */ Un(ie), Dn = /* @__PURE__ */ s((e) => (t, n, o) => Ot(e)(t, n, o), "_safeDecode"), Kh = /* @__PURE__ */ Dn(ie), Nn = /* @__PURE__ */ s((e) => async (t, n, o) => {
  let r = o ? Object.assign(o, { direction: "backward" }) : { direction: "backward" };
  return Pt(e)(t, n, r);
}, "_safeEncodeAsync"), Gh = /* @__PURE__ */ Nn(ie), Zn = /* @__PURE__ */ s((e) => async (t, n, o) => Pt(e)(t, n, o), "_safeDecodeAsync"), Xh = /* @__PURE__ */ Zn(ie);

// versions/4.3.6/node_modules/zod/v4/core/regexes.js
var me = {};
Oe(me, {
  base64: () => wa,
  base64url: () => An,
  bigint: () => Oa,
  boolean: () => Ta,
  browserEmail: () => ov,
  cidrv4: () => $a,
  cidrv6: () => _a,
  cuid: () => ca,
  cuid2: () => ua,
  date: () => za,
  datetime: () => Sa,
  domain: () => sv,
  duration: () => ma,
  e164: () => ka,
  email: () => ha,
  emoji: () => va,
  extendedDuration: () => Qh,
  guid: () => ga,
  hex: () => cv,
  hostname: () => av,
  html5Email: () => tv,
  idnEmail: () => nv,
  integer: () => Pa,
  ipv4: () => ya,
  ipv6: () => ba,
  ksuid: () => fa,
  lowercase: () => Da,
  mac: () => xa,
  md5_base64: () => lv,
  md5_base64url: () => dv,
  md5_hex: () => uv,
  nanoid: () => pa,
  null: () => Ea,
  number: () => Cn,
  rfc5322Email: () => rv,
  sha1_base64: () => pv,
  sha1_base64url: () => mv,
  sha1_hex: () => fv,
  sha256_base64: () => hv,
  sha256_base64url: () => vv,
  sha256_hex: () => gv,
  sha384_base64: () => bv,
  sha384_base64url: () => xv,
  sha384_hex: () => yv,
  sha512_base64: () => _v,
  sha512_base64url: () => wv,
  sha512_hex: () => $v,
  string: () => ja,
  time: () => Ia,
  ulid: () => la,
  undefined: () => Ua,
  unicodeEmail: () => Sf,
  uppercase: () => Na,
  uuid: () => nt,
  uuid4: () => Hh,
  uuid6: () => Yh,
  uuid7: () => ev,
  xid: () => da
});
var ca = /^[cC][^\s-]{8,}$/, ua = /^[0-9a-z]+$/, la = /^[0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{26}$/, da = /^[0-9a-vA-V]{20}$/, fa = /^[A-Za-z0-9]{27}$/, pa = /^[a-zA-Z0-9_-]{21}$/, ma = /^P(?:(\d+W)|(?!.*W)(?=\d|T\d)(\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+([.,]\d+)?S)?)?)$/, Qh = /^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/, ga = /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/, nt = /* @__PURE__ */ s((e) => e ? new RegExp(`^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${e}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`) : /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/, "uuid"), Hh = /* @__PURE__ */ nt(4), Yh = /* @__PURE__ */ nt(6), ev = /* @__PURE__ */ nt(7), ha = /^(?!\.)(?!.*\.\.)([A-Za-z0-9_'+\-\.]*)[A-Za-z0-9_+-]@([A-Za-z0-9][A-Za-z0-9\-]*\.)+[A-Za-z]{2,}$/, tv = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/, rv = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/, Sf = /^[^\s@"]{1,64}@[^\s@]{1,255}$/u, nv = Sf, ov = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/, iv = "^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$";
function va() {
  return new RegExp(iv, "u");
}
s(va, "emoji");
var ya = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/, ba = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))$/, xa = /* @__PURE__ */ s((e) => {
  let t = pe(e ?? ":");
  return new RegExp(`^(?:[0-9A-F]{2}${t}){5}[0-9A-F]{2}$|^(?:[0-9a-f]{2}${t}){5}[0-9a-f]{2}$`);
}, "mac"), $a = /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/([0-9]|[1-2][0-9]|3[0-2])$/, _a = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|::|([0-9a-fA-F]{1,4})?::([0-9a-fA-F]{1,4}:?){0,6})\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/, wa = /^$|^(?:[0-9a-zA-Z+/]{4})*(?:(?:[0-9a-zA-Z+/]{2}==)|(?:[0-9a-zA-Z+/]{3}=))?$/, An = /^[A-Za-z0-9_-]*$/, av = /^(?=.{1,253}\.?$)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[-0-9a-zA-Z]{0,61}[0-9a-zA-Z])?)*\.?$/, sv = /^([a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$/, ka = /^\+[1-9]\d{6,14}$/, jf = "(?:(?:\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-(?:(?:0[13578]|1[02])-(?:0[1-9]|[12]\\d|3[01])|(?:0[469]|11)-(?:0[1-9]|[12]\\d|30)|(?:02)-(?:0[1-9]|1\\d|2[0-8])))", za = /* @__PURE__ */ new RegExp(`^${jf}$`);
function Of(e) {
  let t = "(?:[01]\\d|2[0-3]):[0-5]\\d";
  return typeof e.precision == "number" ? e.precision === -1 ? `${t}` : e.precision === 0 ? `${t}:[0-5]\\d` : `${t}:[0-5]\\d\\.\\d{${e.precision}}` : `${t}(?::[0-5]\\d(?:\\.\\d+)?)?`;
}
s(Of, "timeSource");
function Ia(e) {
  return new RegExp(`^${Of(e)}$`);
}
s(Ia, "time");
function Sa(e) {
  let t = Of({ precision: e.precision }), n = ["Z"];
  e.local && n.push(""), e.offset && n.push("([+-](?:[01]\\d|2[0-3]):[0-5]\\d)");
  let o = `${t}(?:${n.join("|")})`;
  return new RegExp(`^${jf}T(?:${o})$`);
}
s(Sa, "datetime");
var ja = /* @__PURE__ */ s((e) => {
  let t = e ? `[\\s\\S]{${e?.minimum ?? 0},${e?.maximum ?? ""}}` : "[\\s\\S]*";
  return new RegExp(`^${t}$`);
}, "string"), Oa = /^-?\d+n?$/, Pa = /^-?\d+$/, Cn = /^-?\d+(?:\.\d+)?$/, Ta = /^(?:true|false)$/i, Ea = /^null$/i;
var Ua = /^undefined$/i;
var Da = /^[^A-Z]*$/, Na = /^[^a-z]*$/, cv = /^[0-9a-fA-F]*$/;
function Ir(e, t) {
  return new RegExp(`^[A-Za-z0-9+/]{${e}}${t}$`);
}
s(Ir, "fixedBase64");
function Sr(e) {
  return new RegExp(`^[A-Za-z0-9_-]{${e}}$`);
}
s(Sr, "fixedBase64url");
var uv = /^[0-9a-fA-F]{32}$/, lv = /* @__PURE__ */ Ir(22, "=="), dv = /* @__PURE__ */ Sr(22), fv = /^[0-9a-fA-F]{40}$/, pv = /* @__PURE__ */ Ir(27, "="), mv = /* @__PURE__ */ Sr(27), gv = /^[0-9a-fA-F]{64}$/, hv = /* @__PURE__ */ Ir(43, "="), vv = /* @__PURE__ */ Sr(43), yv = /^[0-9a-fA-F]{96}$/, bv = /* @__PURE__ */ Ir(64, ""), xv = /* @__PURE__ */ Sr(64), $v = /^[0-9a-fA-F]{128}$/, _v = /* @__PURE__ */ Ir(86, "=="), wv = /* @__PURE__ */ Sr(86);

// versions/4.3.6/node_modules/zod/v4/core/checks.js
var C = /* @__PURE__ */ f("$ZodCheck", (e, t) => {
  var n;
  e._zod ?? (e._zod = {}), e._zod.def = t, (n = e._zod).onattach ?? (n.onattach = []);
}), Tf = {
  number: "number",
  bigint: "bigint",
  object: "date"
}, Rn = /* @__PURE__ */ f("$ZodCheckLessThan", (e, t) => {
  C.init(e, t);
  let n = Tf[typeof t.value];
  e._zod.onattach.push((o) => {
    let r = o._zod.bag, i = (t.inclusive ? r.maximum : r.exclusiveMaximum) ?? Number.POSITIVE_INFINITY;
    t.value < i && (t.inclusive ? r.maximum = t.value : r.exclusiveMaximum = t.value);
  }), e._zod.check = (o) => {
    (t.inclusive ? o.value <= t.value : o.value < t.value) || o.issues.push({
      origin: n,
      code: "too_big",
      maximum: typeof t.value == "object" ? t.value.getTime() : t.value,
      input: o.value,
      inclusive: t.inclusive,
      inst: e,
      continue: !t.abort
    });
  };
}), Fn = /* @__PURE__ */ f("$ZodCheckGreaterThan", (e, t) => {
  C.init(e, t);
  let n = Tf[typeof t.value];
  e._zod.onattach.push((o) => {
    let r = o._zod.bag, i = (t.inclusive ? r.minimum : r.exclusiveMinimum) ?? Number.NEGATIVE_INFINITY;
    t.value > i && (t.inclusive ? r.minimum = t.value : r.exclusiveMinimum = t.value);
  }), e._zod.check = (o) => {
    (t.inclusive ? o.value >= t.value : o.value > t.value) || o.issues.push({
      origin: n,
      code: "too_small",
      minimum: typeof t.value == "object" ? t.value.getTime() : t.value,
      input: o.value,
      inclusive: t.inclusive,
      inst: e,
      continue: !t.abort
    });
  };
}), Za = /* @__PURE__ */ f("$ZodCheckMultipleOf", (e, t) => {
  C.init(e, t), e._zod.onattach.push((n) => {
    var o;
    (o = n._zod.bag).multipleOf ?? (o.multipleOf = t.value);
  }), e._zod.check = (n) => {
    if (typeof n.value != typeof t.value)
      throw new Error("Cannot mix number and bigint in multiple_of check.");
    (typeof n.value == "bigint" ? n.value % t.value === BigInt(0) : Qi(n.value, t.value) === 0) || n.issues.push({
      origin: typeof n.value,
      code: "not_multiple_of",
      divisor: t.value,
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Aa = /* @__PURE__ */ f("$ZodCheckNumberFormat", (e, t) => {
  C.init(e, t), t.format = t.format || "float64";
  let n = t.format?.includes("int"), o = n ? "int" : "number", [r, i] = na[t.format];
  e._zod.onattach.push((a) => {
    let c = a._zod.bag;
    c.format = t.format, c.minimum = r, c.maximum = i, n && (c.pattern = Pa);
  }), e._zod.check = (a) => {
    let c = a.value;
    if (n) {
      if (!Number.isInteger(c)) {
        a.issues.push({
          expected: o,
          format: t.format,
          code: "invalid_type",
          continue: !1,
          input: c,
          inst: e
        });
        return;
      }
      if (!Number.isSafeInteger(c)) {
        c > 0 ? a.issues.push({
          input: c,
          code: "too_big",
          maximum: Number.MAX_SAFE_INTEGER,
          note: "Integers must be within the safe integer range.",
          inst: e,
          origin: o,
          inclusive: !0,
          continue: !t.abort
        }) : a.issues.push({
          input: c,
          code: "too_small",
          minimum: Number.MIN_SAFE_INTEGER,
          note: "Integers must be within the safe integer range.",
          inst: e,
          origin: o,
          inclusive: !0,
          continue: !t.abort
        });
        return;
      }
    }
    c < r && a.issues.push({
      origin: "number",
      input: c,
      code: "too_small",
      minimum: r,
      inclusive: !0,
      inst: e,
      continue: !t.abort
    }), c > i && a.issues.push({
      origin: "number",
      input: c,
      code: "too_big",
      maximum: i,
      inclusive: !0,
      inst: e,
      continue: !t.abort
    });
  };
}), Ca = /* @__PURE__ */ f("$ZodCheckBigIntFormat", (e, t) => {
  C.init(e, t);
  let [n, o] = oa[t.format];
  e._zod.onattach.push((r) => {
    let i = r._zod.bag;
    i.format = t.format, i.minimum = n, i.maximum = o;
  }), e._zod.check = (r) => {
    let i = r.value;
    i < n && r.issues.push({
      origin: "bigint",
      input: i,
      code: "too_small",
      minimum: n,
      inclusive: !0,
      inst: e,
      continue: !t.abort
    }), i > o && r.issues.push({
      origin: "bigint",
      input: i,
      code: "too_big",
      maximum: o,
      inclusive: !0,
      inst: e,
      continue: !t.abort
    });
  };
}), Ra = /* @__PURE__ */ f("$ZodCheckMaxSize", (e, t) => {
  var n;
  C.init(e, t), (n = e._zod.def).when ?? (n.when = (o) => {
    let r = o.value;
    return !Ne(r) && r.size !== void 0;
  }), e._zod.onattach.push((o) => {
    let r = o._zod.bag.maximum ?? Number.POSITIVE_INFINITY;
    t.maximum < r && (o._zod.bag.maximum = t.maximum);
  }), e._zod.check = (o) => {
    let r = o.value;
    r.size <= t.maximum || o.issues.push({
      origin: _r(r),
      code: "too_big",
      maximum: t.maximum,
      inclusive: !0,
      input: r,
      inst: e,
      continue: !t.abort
    });
  };
}), Fa = /* @__PURE__ */ f("$ZodCheckMinSize", (e, t) => {
  var n;
  C.init(e, t), (n = e._zod.def).when ?? (n.when = (o) => {
    let r = o.value;
    return !Ne(r) && r.size !== void 0;
  }), e._zod.onattach.push((o) => {
    let r = o._zod.bag.minimum ?? Number.NEGATIVE_INFINITY;
    t.minimum > r && (o._zod.bag.minimum = t.minimum);
  }), e._zod.check = (o) => {
    let r = o.value;
    r.size >= t.minimum || o.issues.push({
      origin: _r(r),
      code: "too_small",
      minimum: t.minimum,
      inclusive: !0,
      input: r,
      inst: e,
      continue: !t.abort
    });
  };
}), La = /* @__PURE__ */ f("$ZodCheckSizeEquals", (e, t) => {
  var n;
  C.init(e, t), (n = e._zod.def).when ?? (n.when = (o) => {
    let r = o.value;
    return !Ne(r) && r.size !== void 0;
  }), e._zod.onattach.push((o) => {
    let r = o._zod.bag;
    r.minimum = t.size, r.maximum = t.size, r.size = t.size;
  }), e._zod.check = (o) => {
    let r = o.value, i = r.size;
    if (i === t.size)
      return;
    let a = i > t.size;
    o.issues.push({
      origin: _r(r),
      ...a ? { code: "too_big", maximum: t.size } : { code: "too_small", minimum: t.size },
      inclusive: !0,
      exact: !0,
      input: o.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Ma = /* @__PURE__ */ f("$ZodCheckMaxLength", (e, t) => {
  var n;
  C.init(e, t), (n = e._zod.def).when ?? (n.when = (o) => {
    let r = o.value;
    return !Ne(r) && r.length !== void 0;
  }), e._zod.onattach.push((o) => {
    let r = o._zod.bag.maximum ?? Number.POSITIVE_INFINITY;
    t.maximum < r && (o._zod.bag.maximum = t.maximum);
  }), e._zod.check = (o) => {
    let r = o.value;
    if (r.length <= t.maximum)
      return;
    let a = wr(r);
    o.issues.push({
      origin: a,
      code: "too_big",
      maximum: t.maximum,
      inclusive: !0,
      input: r,
      inst: e,
      continue: !t.abort
    });
  };
}), Ba = /* @__PURE__ */ f("$ZodCheckMinLength", (e, t) => {
  var n;
  C.init(e, t), (n = e._zod.def).when ?? (n.when = (o) => {
    let r = o.value;
    return !Ne(r) && r.length !== void 0;
  }), e._zod.onattach.push((o) => {
    let r = o._zod.bag.minimum ?? Number.NEGATIVE_INFINITY;
    t.minimum > r && (o._zod.bag.minimum = t.minimum);
  }), e._zod.check = (o) => {
    let r = o.value;
    if (r.length >= t.minimum)
      return;
    let a = wr(r);
    o.issues.push({
      origin: a,
      code: "too_small",
      minimum: t.minimum,
      inclusive: !0,
      input: r,
      inst: e,
      continue: !t.abort
    });
  };
}), Ja = /* @__PURE__ */ f("$ZodCheckLengthEquals", (e, t) => {
  var n;
  C.init(e, t), (n = e._zod.def).when ?? (n.when = (o) => {
    let r = o.value;
    return !Ne(r) && r.length !== void 0;
  }), e._zod.onattach.push((o) => {
    let r = o._zod.bag;
    r.minimum = t.length, r.maximum = t.length, r.length = t.length;
  }), e._zod.check = (o) => {
    let r = o.value, i = r.length;
    if (i === t.length)
      return;
    let a = wr(r), c = i > t.length;
    o.issues.push({
      origin: a,
      ...c ? { code: "too_big", maximum: t.length } : { code: "too_small", minimum: t.length },
      inclusive: !0,
      exact: !0,
      input: o.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Tt = /* @__PURE__ */ f("$ZodCheckStringFormat", (e, t) => {
  var n, o;
  C.init(e, t), e._zod.onattach.push((r) => {
    let i = r._zod.bag;
    i.format = t.format, t.pattern && (i.patterns ?? (i.patterns = /* @__PURE__ */ new Set()), i.patterns.add(t.pattern));
  }), t.pattern ? (n = e._zod).check ?? (n.check = (r) => {
    t.pattern.lastIndex = 0, !t.pattern.test(r.value) && r.issues.push({
      origin: "string",
      code: "invalid_format",
      format: t.format,
      input: r.value,
      ...t.pattern ? { pattern: t.pattern.toString() } : {},
      inst: e,
      continue: !t.abort
    });
  }) : (o = e._zod).check ?? (o.check = () => {
  });
}), Va = /* @__PURE__ */ f("$ZodCheckRegex", (e, t) => {
  Tt.init(e, t), e._zod.check = (n) => {
    t.pattern.lastIndex = 0, !t.pattern.test(n.value) && n.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "regex",
      input: n.value,
      pattern: t.pattern.toString(),
      inst: e,
      continue: !t.abort
    });
  };
}), qa = /* @__PURE__ */ f("$ZodCheckLowerCase", (e, t) => {
  t.pattern ?? (t.pattern = Da), Tt.init(e, t);
}), Wa = /* @__PURE__ */ f("$ZodCheckUpperCase", (e, t) => {
  t.pattern ?? (t.pattern = Na), Tt.init(e, t);
}), Ka = /* @__PURE__ */ f("$ZodCheckIncludes", (e, t) => {
  C.init(e, t);
  let n = pe(t.includes), o = new RegExp(typeof t.position == "number" ? `^.{${t.position}}${n}` : n);
  t.pattern = o, e._zod.onattach.push((r) => {
    let i = r._zod.bag;
    i.patterns ?? (i.patterns = /* @__PURE__ */ new Set()), i.patterns.add(o);
  }), e._zod.check = (r) => {
    r.value.includes(t.includes, t.position) || r.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "includes",
      includes: t.includes,
      input: r.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Ga = /* @__PURE__ */ f("$ZodCheckStartsWith", (e, t) => {
  C.init(e, t);
  let n = new RegExp(`^${pe(t.prefix)}.*`);
  t.pattern ?? (t.pattern = n), e._zod.onattach.push((o) => {
    let r = o._zod.bag;
    r.patterns ?? (r.patterns = /* @__PURE__ */ new Set()), r.patterns.add(n);
  }), e._zod.check = (o) => {
    o.value.startsWith(t.prefix) || o.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "starts_with",
      prefix: t.prefix,
      input: o.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Xa = /* @__PURE__ */ f("$ZodCheckEndsWith", (e, t) => {
  C.init(e, t);
  let n = new RegExp(`.*${pe(t.suffix)}$`);
  t.pattern ?? (t.pattern = n), e._zod.onattach.push((o) => {
    let r = o._zod.bag;
    r.patterns ?? (r.patterns = /* @__PURE__ */ new Set()), r.patterns.add(n);
  }), e._zod.check = (o) => {
    o.value.endsWith(t.suffix) || o.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "ends_with",
      suffix: t.suffix,
      input: o.value,
      inst: e,
      continue: !t.abort
    });
  };
});
function Pf(e, t, n) {
  e.issues.length && t.issues.push(...ce(n, e.issues));
}
s(Pf, "handleCheckPropertyResult");
var Qa = /* @__PURE__ */ f("$ZodCheckProperty", (e, t) => {
  C.init(e, t), e._zod.check = (n) => {
    let o = t.schema._zod.run({
      value: n.value[t.property],
      issues: []
    }, {});
    if (o instanceof Promise)
      return o.then((r) => Pf(r, n, t.property));
    Pf(o, n, t.property);
  };
}), Ha = /* @__PURE__ */ f("$ZodCheckMimeType", (e, t) => {
  C.init(e, t);
  let n = new Set(t.mime);
  e._zod.onattach.push((o) => {
    o._zod.bag.mime = t.mime;
  }), e._zod.check = (o) => {
    n.has(o.value.type) || o.issues.push({
      code: "invalid_value",
      values: t.mime,
      input: o.value.type,
      inst: e,
      continue: !t.abort
    });
  };
}), Ya = /* @__PURE__ */ f("$ZodCheckOverwrite", (e, t) => {
  C.init(e, t), e._zod.check = (n) => {
    n.value = t.tx(n.value);
  };
});

// versions/4.3.6/node_modules/zod/v4/core/doc.js
var jr = class {
  static {
    s(this, "Doc");
  }
  constructor(t = []) {
    this.content = [], this.indent = 0, this && (this.args = t);
  }
  indented(t) {
    this.indent += 1, t(this), this.indent -= 1;
  }
  write(t) {
    if (typeof t == "function") {
      t(this, { execution: "sync" }), t(this, { execution: "async" });
      return;
    }
    let o = t.split(`
`).filter((a) => a), r = Math.min(...o.map((a) => a.length - a.trimStart().length)), i = o.map((a) => a.slice(r)).map((a) => " ".repeat(this.indent * 2) + a);
    for (let a of i)
      this.content.push(a);
  }
  compile() {
    let t = Function, n = this?.args, r = [...(this?.content ?? [""]).map((i) => `  ${i}`)];
    return new t(...n, r.join(`
`));
  }
};

// versions/4.3.6/node_modules/zod/v4/core/versions.js
var es = {
  major: 4,
  minor: 3,
  patch: 6
};

// versions/4.3.6/node_modules/zod/v4/core/schemas.js
var k = /* @__PURE__ */ f("$ZodType", (e, t) => {
  var n;
  e ?? (e = {}), e._zod.def = t, e._zod.bag = e._zod.bag || {}, e._zod.version = es;
  let o = [...e._zod.def.checks ?? []];
  e._zod.traits.has("$ZodCheck") && o.unshift(e);
  for (let r of o)
    for (let i of r._zod.onattach)
      i(e);
  if (o.length === 0)
    (n = e._zod).deferred ?? (n.deferred = []), e._zod.deferred?.push(() => {
      e._zod.run = e._zod.parse;
    });
  else {
    let r = /* @__PURE__ */ s((a, c, u) => {
      let l = Ce(a), d;
      for (let p of c) {
        if (p._zod.def.when) {
          if (!p._zod.def.when(a))
            continue;
        } else if (l)
          continue;
        let h = a.issues.length, v = p._zod.check(a);
        if (v instanceof Promise && u?.async === !1)
          throw new he();
        if (d || v instanceof Promise)
          d = (d ?? Promise.resolve()).then(async () => {
            await v, a.issues.length !== h && (l || (l = Ce(a, h)));
          });
        else {
          if (a.issues.length === h)
            continue;
          l || (l = Ce(a, h));
        }
      }
      return d ? d.then(() => a) : a;
    }, "runChecks"), i = /* @__PURE__ */ s((a, c, u) => {
      if (Ce(a))
        return a.aborted = !0, a;
      let l = r(c, o, u);
      if (l instanceof Promise) {
        if (u.async === !1)
          throw new he();
        return l.then((d) => e._zod.parse(d, u));
      }
      return e._zod.parse(l, u);
    }, "handleCanaryResult");
    e._zod.run = (a, c) => {
      if (c.skipChecks)
        return e._zod.parse(a, c);
      if (c.direction === "backward") {
        let l = e._zod.parse({ value: a.value, issues: [] }, { ...c, skipChecks: !0 });
        return l instanceof Promise ? l.then((d) => i(d, a, c)) : i(l, a, c);
      }
      let u = e._zod.parse(a, c);
      if (u instanceof Promise) {
        if (c.async === !1)
          throw new he();
        return u.then((l) => r(l, o, c));
      }
      return r(u, o, c);
    };
  }
  j(e, "~standard", () => ({
    validate: /* @__PURE__ */ s((r) => {
      try {
        let i = rt(e, r);
        return i.success ? { value: i.data } : { issues: i.error?.issues };
      } catch {
        return sa(e, r).then((a) => a.success ? { value: a.data } : { issues: a.error?.issues });
      }
    }, "validate"),
    vendor: "zod",
    version: 1
  }));
}), ot = /* @__PURE__ */ f("$ZodString", (e, t) => {
  k.init(e, t), e._zod.pattern = [...e?._zod.bag?.patterns ?? []].pop() ?? ja(e._zod.bag), e._zod.parse = (n, o) => {
    if (t.coerce)
      try {
        n.value = String(n.value);
      } catch {
      }
    return typeof n.value == "string" || n.issues.push({
      expected: "string",
      code: "invalid_type",
      input: n.value,
      inst: e
    }), n;
  };
}), N = /* @__PURE__ */ f("$ZodStringFormat", (e, t) => {
  Tt.init(e, t), ot.init(e, t);
}), rs = /* @__PURE__ */ f("$ZodGUID", (e, t) => {
  t.pattern ?? (t.pattern = ga), N.init(e, t);
}), ns = /* @__PURE__ */ f("$ZodUUID", (e, t) => {
  if (t.version) {
    let o = {
      v1: 1,
      v2: 2,
      v3: 3,
      v4: 4,
      v5: 5,
      v6: 6,
      v7: 7,
      v8: 8
    }[t.version];
    if (o === void 0)
      throw new Error(`Invalid UUID version: "${t.version}"`);
    t.pattern ?? (t.pattern = nt(o));
  } else
    t.pattern ?? (t.pattern = nt());
  N.init(e, t);
}), os = /* @__PURE__ */ f("$ZodEmail", (e, t) => {
  t.pattern ?? (t.pattern = ha), N.init(e, t);
}), is = /* @__PURE__ */ f("$ZodURL", (e, t) => {
  N.init(e, t), e._zod.check = (n) => {
    try {
      let o = n.value.trim(), r = new URL(o);
      t.hostname && (t.hostname.lastIndex = 0, t.hostname.test(r.hostname) || n.issues.push({
        code: "invalid_format",
        format: "url",
        note: "Invalid hostname",
        pattern: t.hostname.source,
        input: n.value,
        inst: e,
        continue: !t.abort
      })), t.protocol && (t.protocol.lastIndex = 0, t.protocol.test(r.protocol.endsWith(":") ? r.protocol.slice(0, -1) : r.protocol) || n.issues.push({
        code: "invalid_format",
        format: "url",
        note: "Invalid protocol",
        pattern: t.protocol.source,
        input: n.value,
        inst: e,
        continue: !t.abort
      })), t.normalize ? n.value = r.href : n.value = o;
      return;
    } catch {
      n.issues.push({
        code: "invalid_format",
        format: "url",
        input: n.value,
        inst: e,
        continue: !t.abort
      });
    }
  };
}), as = /* @__PURE__ */ f("$ZodEmoji", (e, t) => {
  t.pattern ?? (t.pattern = va()), N.init(e, t);
}), ss = /* @__PURE__ */ f("$ZodNanoID", (e, t) => {
  t.pattern ?? (t.pattern = pa), N.init(e, t);
}), cs = /* @__PURE__ */ f("$ZodCUID", (e, t) => {
  t.pattern ?? (t.pattern = ca), N.init(e, t);
}), us = /* @__PURE__ */ f("$ZodCUID2", (e, t) => {
  t.pattern ?? (t.pattern = ua), N.init(e, t);
}), ls = /* @__PURE__ */ f("$ZodULID", (e, t) => {
  t.pattern ?? (t.pattern = la), N.init(e, t);
}), ds = /* @__PURE__ */ f("$ZodXID", (e, t) => {
  t.pattern ?? (t.pattern = da), N.init(e, t);
}), fs = /* @__PURE__ */ f("$ZodKSUID", (e, t) => {
  t.pattern ?? (t.pattern = fa), N.init(e, t);
}), ps = /* @__PURE__ */ f("$ZodISODateTime", (e, t) => {
  t.pattern ?? (t.pattern = Sa(t)), N.init(e, t);
}), ms = /* @__PURE__ */ f("$ZodISODate", (e, t) => {
  t.pattern ?? (t.pattern = za), N.init(e, t);
}), gs = /* @__PURE__ */ f("$ZodISOTime", (e, t) => {
  t.pattern ?? (t.pattern = Ia(t)), N.init(e, t);
}), hs = /* @__PURE__ */ f("$ZodISODuration", (e, t) => {
  t.pattern ?? (t.pattern = ma), N.init(e, t);
}), vs = /* @__PURE__ */ f("$ZodIPv4", (e, t) => {
  t.pattern ?? (t.pattern = ya), N.init(e, t), e._zod.bag.format = "ipv4";
}), ys = /* @__PURE__ */ f("$ZodIPv6", (e, t) => {
  t.pattern ?? (t.pattern = ba), N.init(e, t), e._zod.bag.format = "ipv6", e._zod.check = (n) => {
    try {
      new URL(`http://[${n.value}]`);
    } catch {
      n.issues.push({
        code: "invalid_format",
        format: "ipv6",
        input: n.value,
        inst: e,
        continue: !t.abort
      });
    }
  };
}), bs = /* @__PURE__ */ f("$ZodMAC", (e, t) => {
  t.pattern ?? (t.pattern = xa(t.delimiter)), N.init(e, t), e._zod.bag.format = "mac";
}), xs = /* @__PURE__ */ f("$ZodCIDRv4", (e, t) => {
  t.pattern ?? (t.pattern = $a), N.init(e, t);
}), $s = /* @__PURE__ */ f("$ZodCIDRv6", (e, t) => {
  t.pattern ?? (t.pattern = _a), N.init(e, t), e._zod.check = (n) => {
    let o = n.value.split("/");
    try {
      if (o.length !== 2)
        throw new Error();
      let [r, i] = o;
      if (!i)
        throw new Error();
      let a = Number(i);
      if (`${a}` !== i)
        throw new Error();
      if (a < 0 || a > 128)
        throw new Error();
      new URL(`http://[${r}]`);
    } catch {
      n.issues.push({
        code: "invalid_format",
        format: "cidrv6",
        input: n.value,
        inst: e,
        continue: !t.abort
      });
    }
  };
});
function _s(e) {
  if (e === "")
    return !0;
  if (e.length % 4 !== 0)
    return !1;
  try {
    return atob(e), !0;
  } catch {
    return !1;
  }
}
s(_s, "isValidBase64");
var ws = /* @__PURE__ */ f("$ZodBase64", (e, t) => {
  t.pattern ?? (t.pattern = wa), N.init(e, t), e._zod.bag.contentEncoding = "base64", e._zod.check = (n) => {
    _s(n.value) || n.issues.push({
      code: "invalid_format",
      format: "base64",
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
});
function Jf(e) {
  if (!An.test(e))
    return !1;
  let t = e.replace(/[-_]/g, (o) => o === "-" ? "+" : "/"), n = t.padEnd(Math.ceil(t.length / 4) * 4, "=");
  return _s(n);
}
s(Jf, "isValidBase64URL");
var ks = /* @__PURE__ */ f("$ZodBase64URL", (e, t) => {
  t.pattern ?? (t.pattern = An), N.init(e, t), e._zod.bag.contentEncoding = "base64url", e._zod.check = (n) => {
    Jf(n.value) || n.issues.push({
      code: "invalid_format",
      format: "base64url",
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), zs = /* @__PURE__ */ f("$ZodE164", (e, t) => {
  t.pattern ?? (t.pattern = ka), N.init(e, t);
});
function Vf(e, t = null) {
  try {
    let n = e.split(".");
    if (n.length !== 3)
      return !1;
    let [o] = n;
    if (!o)
      return !1;
    let r = JSON.parse(atob(o));
    return !("typ" in r && r?.typ !== "JWT" || !r.alg || t && (!("alg" in r) || r.alg !== t));
  } catch {
    return !1;
  }
}
s(Vf, "isValidJWT");
var Is = /* @__PURE__ */ f("$ZodJWT", (e, t) => {
  N.init(e, t), e._zod.check = (n) => {
    Vf(n.value, t.alg) || n.issues.push({
      code: "invalid_format",
      format: "jwt",
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Ss = /* @__PURE__ */ f("$ZodCustomStringFormat", (e, t) => {
  N.init(e, t), e._zod.check = (n) => {
    t.fn(n.value) || n.issues.push({
      code: "invalid_format",
      format: t.format,
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), qn = /* @__PURE__ */ f("$ZodNumber", (e, t) => {
  k.init(e, t), e._zod.pattern = e._zod.bag.pattern ?? Cn, e._zod.parse = (n, o) => {
    if (t.coerce)
      try {
        n.value = Number(n.value);
      } catch {
      }
    let r = n.value;
    if (typeof r == "number" && !Number.isNaN(r) && Number.isFinite(r))
      return n;
    let i = typeof r == "number" ? Number.isNaN(r) ? "NaN" : Number.isFinite(r) ? void 0 : "Infinity" : void 0;
    return n.issues.push({
      expected: "number",
      code: "invalid_type",
      input: r,
      inst: e,
      ...i ? { received: i } : {}
    }), n;
  };
}), js = /* @__PURE__ */ f("$ZodNumberFormat", (e, t) => {
  Aa.init(e, t), qn.init(e, t);
}), Or = /* @__PURE__ */ f("$ZodBoolean", (e, t) => {
  k.init(e, t), e._zod.pattern = Ta, e._zod.parse = (n, o) => {
    if (t.coerce)
      try {
        n.value = !!n.value;
      } catch {
      }
    let r = n.value;
    return typeof r == "boolean" || n.issues.push({
      expected: "boolean",
      code: "invalid_type",
      input: r,
      inst: e
    }), n;
  };
}), Wn = /* @__PURE__ */ f("$ZodBigInt", (e, t) => {
  k.init(e, t), e._zod.pattern = Oa, e._zod.parse = (n, o) => {
    if (t.coerce)
      try {
        n.value = BigInt(n.value);
      } catch {
      }
    return typeof n.value == "bigint" || n.issues.push({
      expected: "bigint",
      code: "invalid_type",
      input: n.value,
      inst: e
    }), n;
  };
}), Os = /* @__PURE__ */ f("$ZodBigIntFormat", (e, t) => {
  Ca.init(e, t), Wn.init(e, t);
}), Ps = /* @__PURE__ */ f("$ZodSymbol", (e, t) => {
  k.init(e, t), e._zod.parse = (n, o) => {
    let r = n.value;
    return typeof r == "symbol" || n.issues.push({
      expected: "symbol",
      code: "invalid_type",
      input: r,
      inst: e
    }), n;
  };
}), Ts = /* @__PURE__ */ f("$ZodUndefined", (e, t) => {
  k.init(e, t), e._zod.pattern = Ua, e._zod.values = /* @__PURE__ */ new Set([void 0]), e._zod.optin = "optional", e._zod.optout = "optional", e._zod.parse = (n, o) => {
    let r = n.value;
    return typeof r > "u" || n.issues.push({
      expected: "undefined",
      code: "invalid_type",
      input: r,
      inst: e
    }), n;
  };
}), Es = /* @__PURE__ */ f("$ZodNull", (e, t) => {
  k.init(e, t), e._zod.pattern = Ea, e._zod.values = /* @__PURE__ */ new Set([null]), e._zod.parse = (n, o) => {
    let r = n.value;
    return r === null || n.issues.push({
      expected: "null",
      code: "invalid_type",
      input: r,
      inst: e
    }), n;
  };
}), Us = /* @__PURE__ */ f("$ZodAny", (e, t) => {
  k.init(e, t), e._zod.parse = (n) => n;
}), Ds = /* @__PURE__ */ f("$ZodUnknown", (e, t) => {
  k.init(e, t), e._zod.parse = (n) => n;
}), Ns = /* @__PURE__ */ f("$ZodNever", (e, t) => {
  k.init(e, t), e._zod.parse = (n, o) => (n.issues.push({
    expected: "never",
    code: "invalid_type",
    input: n.value,
    inst: e
  }), n);
}), Zs = /* @__PURE__ */ f("$ZodVoid", (e, t) => {
  k.init(e, t), e._zod.parse = (n, o) => {
    let r = n.value;
    return typeof r > "u" || n.issues.push({
      expected: "void",
      code: "invalid_type",
      input: r,
      inst: e
    }), n;
  };
}), Et = /* @__PURE__ */ f("$ZodDate", (e, t) => {
  k.init(e, t), e._zod.parse = (n, o) => {
    if (t.coerce)
      try {
        n.value = new Date(n.value);
      } catch {
      }
    let r = n.value, i = r instanceof Date;
    return i && !Number.isNaN(r.getTime()) || n.issues.push({
      expected: "date",
      code: "invalid_type",
      input: r,
      ...i ? { received: "Invalid Date" } : {},
      inst: e
    }), n;
  };
});
function Uf(e, t, n) {
  e.issues.length && t.issues.push(...ce(n, e.issues)), t.value[n] = e.value;
}
s(Uf, "handleArrayResult");
var Fe = /* @__PURE__ */ f("$ZodArray", (e, t) => {
  k.init(e, t), e._zod.parse = (n, o) => {
    let r = n.value;
    if (!Array.isArray(r))
      return n.issues.push({
        expected: "array",
        code: "invalid_type",
        input: r,
        inst: e
      }), n;
    n.value = Array(r.length);
    let i = [];
    for (let a = 0; a < r.length; a++) {
      let c = r[a], u = t.element._zod.run({
        value: c,
        issues: []
      }, o);
      u instanceof Promise ? i.push(u.then((l) => Uf(l, n, a))) : Uf(u, n, a);
    }
    return i.length ? Promise.all(i).then(() => n) : n;
  };
});
function Vn(e, t, n, o, r) {
  if (e.issues.length) {
    if (r && !(n in o))
      return;
    t.issues.push(...ce(n, e.issues));
  }
  e.value === void 0 ? n in o && (t.value[n] = void 0) : t.value[n] = e.value;
}
s(Vn, "handlePropertyResult");
function qf(e) {
  let t = Object.keys(e.shape);
  for (let o of t)
    if (!e.shape?.[o]?._zod?.traits?.has("$ZodType"))
      throw new Error(`Invalid element at key "${o}": expected a Zod schema`);
  let n = ra(e.shape);
  return {
    ...e,
    keys: t,
    keySet: new Set(t),
    numKeys: t.length,
    optionalKeys: new Set(n)
  };
}
s(qf, "normalizeDef");
function Wf(e, t, n, o, r, i) {
  let a = [], c = r.keySet, u = r.catchall._zod, l = u.def.type, d = u.optout === "optional";
  for (let p in t) {
    if (c.has(p))
      continue;
    if (l === "never") {
      a.push(p);
      continue;
    }
    let h = u.run({ value: t[p], issues: [] }, o);
    h instanceof Promise ? e.push(h.then((v) => Vn(v, n, p, t, d))) : Vn(h, n, p, t, d);
  }
  return a.length && n.issues.push({
    code: "unrecognized_keys",
    keys: a,
    input: t,
    inst: i
  }), e.length ? Promise.all(e).then(() => n) : n;
}
s(Wf, "handleCatchall");
var q = /* @__PURE__ */ f("$ZodObject", (e, t) => {
  if (k.init(e, t), !Object.getOwnPropertyDescriptor(t, "shape")?.get) {
    let c = t.shape;
    Object.defineProperty(t, "shape", {
      get: /* @__PURE__ */ s(() => {
        let u = { ...c };
        return Object.defineProperty(t, "shape", {
          value: u
        }), u;
      }, "get")
    });
  }
  let o = zt(() => qf(t));
  j(e._zod, "propValues", () => {
    let c = t.shape, u = {};
    for (let l in c) {
      let d = c[l]._zod;
      if (d.values) {
        u[l] ?? (u[l] = /* @__PURE__ */ new Set());
        for (let p of d.values)
          u[l].add(p);
      }
    }
    return u;
  });
  let r = tt, i = t.catchall, a;
  e._zod.parse = (c, u) => {
    a ?? (a = o.value);
    let l = c.value;
    if (!r(l))
      return c.issues.push({
        expected: "object",
        code: "invalid_type",
        input: l,
        inst: e
      }), c;
    c.value = {};
    let d = [], p = a.shape;
    for (let h of a.keys) {
      let v = p[h], O = v._zod.optout === "optional", I = v._zod.run({ value: l[h], issues: [] }, u);
      I instanceof Promise ? d.push(I.then((W) => Vn(W, c, h, l, O))) : Vn(I, c, h, l, O);
    }
    return i ? Wf(d, l, c, u, o.value, e) : d.length ? Promise.all(d).then(() => c) : c;
  };
}), As = /* @__PURE__ */ f("$ZodObjectJIT", (e, t) => {
  q.init(e, t);
  let n = e._zod.parse, o = zt(() => qf(t)), r = /* @__PURE__ */ s((h) => {
    let v = new jr(["shape", "payload", "ctx"]), O = o.value, I = /* @__PURE__ */ s((K) => {
      let A = In(K);
      return `shape[${A}]._zod.run({ value: input[${A}], issues: [] }, ctx)`;
    }, "parseStr");
    v.write("const input = payload.value;");
    let W = /* @__PURE__ */ Object.create(null), Ge = 0;
    for (let K of O.keys)
      W[K] = `key_${Ge++}`;
    v.write("const newResult = {};");
    for (let K of O.keys) {
      let A = W[K], X = In(K), P = h[K]?._zod?.optout === "optional";
      v.write(`const ${A} = ${I(K)};`), P ? v.write(`
        if (${A}.issues.length) {
          if (${X} in input) {
            payload.issues = payload.issues.concat(${A}.issues.map(iss => ({
              ...iss,
              path: iss.path ? [${X}, ...iss.path] : [${X}]
            })));
          }
        }
        
        if (${A}.value === undefined) {
          if (${X} in input) {
            newResult[${X}] = undefined;
          }
        } else {
          newResult[${X}] = ${A}.value;
        }
        
      `) : v.write(`
        if (${A}.issues.length) {
          payload.issues = payload.issues.concat(${A}.issues.map(iss => ({
            ...iss,
            path: iss.path ? [${X}, ...iss.path] : [${X}]
          })));
        }
        
        if (${A}.value === undefined) {
          if (${X} in input) {
            newResult[${X}] = undefined;
          }
        } else {
          newResult[${X}] = ${A}.value;
        }
        
      `);
    }
    v.write("payload.value = newResult;"), v.write("return payload;");
    let _e = v.compile();
    return (K, A) => _e(h, K, A);
  }, "generateFastpass"), i, a = tt, c = !vr.jitless, l = c && Yi.value, d = t.catchall, p;
  e._zod.parse = (h, v) => {
    p ?? (p = o.value);
    let O = h.value;
    return a(O) ? c && l && v?.async === !1 && v.jitless !== !0 ? (i || (i = r(t.shape)), h = i(h, v), d ? Wf([], O, h, v, p, e) : h) : n(h, v) : (h.issues.push({
      expected: "object",
      code: "invalid_type",
      input: O,
      inst: e
    }), h);
  };
});
function Df(e, t, n, o) {
  for (let i of e)
    if (i.issues.length === 0)
      return t.value = i.value, t;
  let r = e.filter((i) => !Ce(i));
  return r.length === 1 ? (t.value = r[0].value, r[0]) : (t.issues.push({
    code: "invalid_union",
    input: t.value,
    inst: n,
    errors: e.map((i) => i.issues.map((a) => oe(a, o, B())))
  }), t);
}
s(Df, "handleUnionResults");
var te = /* @__PURE__ */ f("$ZodUnion", (e, t) => {
  k.init(e, t), j(e._zod, "optin", () => t.options.some((r) => r._zod.optin === "optional") ? "optional" : void 0), j(e._zod, "optout", () => t.options.some((r) => r._zod.optout === "optional") ? "optional" : void 0), j(e._zod, "values", () => {
    if (t.options.every((r) => r._zod.values))
      return new Set(t.options.flatMap((r) => Array.from(r._zod.values)));
  }), j(e._zod, "pattern", () => {
    if (t.options.every((r) => r._zod.pattern)) {
      let r = t.options.map((i) => i._zod.pattern);
      return new RegExp(`^(${r.map((i) => xr(i.source)).join("|")})$`);
    }
  });
  let n = t.options.length === 1, o = t.options[0]._zod.run;
  e._zod.parse = (r, i) => {
    if (n)
      return o(r, i);
    let a = !1, c = [];
    for (let u of t.options) {
      let l = u._zod.run({
        value: r.value,
        issues: []
      }, i);
      if (l instanceof Promise)
        c.push(l), a = !0;
      else {
        if (l.issues.length === 0)
          return l;
        c.push(l);
      }
    }
    return a ? Promise.all(c).then((u) => Df(u, r, e, i)) : Df(c, r, e, i);
  };
});
function Nf(e, t, n, o) {
  let r = e.filter((i) => i.issues.length === 0);
  return r.length === 1 ? (t.value = r[0].value, t) : (r.length === 0 ? t.issues.push({
    code: "invalid_union",
    input: t.value,
    inst: n,
    errors: e.map((i) => i.issues.map((a) => oe(a, o, B())))
  }) : t.issues.push({
    code: "invalid_union",
    input: t.value,
    inst: n,
    errors: [],
    inclusive: !1
  }), t);
}
s(Nf, "handleExclusiveUnionResults");
var Cs = /* @__PURE__ */ f("$ZodXor", (e, t) => {
  te.init(e, t), t.inclusive = !1;
  let n = t.options.length === 1, o = t.options[0]._zod.run;
  e._zod.parse = (r, i) => {
    if (n)
      return o(r, i);
    let a = !1, c = [];
    for (let u of t.options) {
      let l = u._zod.run({
        value: r.value,
        issues: []
      }, i);
      l instanceof Promise ? (c.push(l), a = !0) : c.push(l);
    }
    return a ? Promise.all(c).then((u) => Nf(u, r, e, i)) : Nf(c, r, e, i);
  };
}), Le = /* @__PURE__ */ f("$ZodDiscriminatedUnion", (e, t) => {
  t.inclusive = !1, te.init(e, t);
  let n = e._zod.parse;
  j(e._zod, "propValues", () => {
    let r = {};
    for (let i of t.options) {
      let a = i._zod.propValues;
      if (!a || Object.keys(a).length === 0)
        throw new Error(`Invalid discriminated union option at index "${t.options.indexOf(i)}"`);
      for (let [c, u] of Object.entries(a)) {
        r[c] || (r[c] = /* @__PURE__ */ new Set());
        for (let l of u)
          r[c].add(l);
      }
    }
    return r;
  });
  let o = zt(() => {
    let r = t.options, i = /* @__PURE__ */ new Map();
    for (let a of r) {
      let c = a._zod.propValues?.[t.discriminator];
      if (!c || c.size === 0)
        throw new Error(`Invalid discriminated union option at index "${t.options.indexOf(a)}"`);
      for (let u of c) {
        if (i.has(u))
          throw new Error(`Duplicate discriminator value "${String(u)}"`);
        i.set(u, a);
      }
    }
    return i;
  });
  e._zod.parse = (r, i) => {
    let a = r.value;
    if (!tt(a))
      return r.issues.push({
        code: "invalid_type",
        expected: "object",
        input: a,
        inst: e
      }), r;
    let c = o.value.get(a?.[t.discriminator]);
    return c ? c._zod.run(r, i) : t.unionFallback ? n(r, i) : (r.issues.push({
      code: "invalid_union",
      errors: [],
      note: "No matching discriminator",
      discriminator: t.discriminator,
      input: a,
      path: [t.discriminator],
      inst: e
    }), r);
  };
}), Rs = /* @__PURE__ */ f("$ZodIntersection", (e, t) => {
  k.init(e, t), e._zod.parse = (n, o) => {
    let r = n.value, i = t.left._zod.run({ value: r, issues: [] }, o), a = t.right._zod.run({ value: r, issues: [] }, o);
    return i instanceof Promise || a instanceof Promise ? Promise.all([i, a]).then(([u, l]) => Zf(n, u, l)) : Zf(n, i, a);
  };
});
function ts(e, t) {
  if (e === t)
    return { valid: !0, data: e };
  if (e instanceof Date && t instanceof Date && +e == +t)
    return { valid: !0, data: e };
  if (Ae(e) && Ae(t)) {
    let n = Object.keys(t), o = Object.keys(e).filter((i) => n.indexOf(i) !== -1), r = { ...e, ...t };
    for (let i of o) {
      let a = ts(e[i], t[i]);
      if (!a.valid)
        return {
          valid: !1,
          mergeErrorPath: [i, ...a.mergeErrorPath]
        };
      r[i] = a.data;
    }
    return { valid: !0, data: r };
  }
  if (Array.isArray(e) && Array.isArray(t)) {
    if (e.length !== t.length)
      return { valid: !1, mergeErrorPath: [] };
    let n = [];
    for (let o = 0; o < e.length; o++) {
      let r = e[o], i = t[o], a = ts(r, i);
      if (!a.valid)
        return {
          valid: !1,
          mergeErrorPath: [o, ...a.mergeErrorPath]
        };
      n.push(a.data);
    }
    return { valid: !0, data: n };
  }
  return { valid: !1, mergeErrorPath: [] };
}
s(ts, "mergeValues");
function Zf(e, t, n) {
  let o = /* @__PURE__ */ new Map(), r;
  for (let c of t.issues)
    if (c.code === "unrecognized_keys") {
      r ?? (r = c);
      for (let u of c.keys)
        o.has(u) || o.set(u, {}), o.get(u).l = !0;
    } else
      e.issues.push(c);
  for (let c of n.issues)
    if (c.code === "unrecognized_keys")
      for (let u of c.keys)
        o.has(u) || o.set(u, {}), o.get(u).r = !0;
    else
      e.issues.push(c);
  let i = [...o].filter(([, c]) => c.l && c.r).map(([c]) => c);
  if (i.length && r && e.issues.push({ ...r, keys: i }), Ce(e))
    return e;
  let a = ts(t.value, n.value);
  if (!a.valid)
    throw new Error(`Unmergable intersection. Error path: ${JSON.stringify(a.mergeErrorPath)}`);
  return e.value = a.data, e;
}
s(Zf, "handleIntersectionResults");
var Me = /* @__PURE__ */ f("$ZodTuple", (e, t) => {
  k.init(e, t);
  let n = t.items;
  e._zod.parse = (o, r) => {
    let i = o.value;
    if (!Array.isArray(i))
      return o.issues.push({
        input: i,
        inst: e,
        expected: "tuple",
        code: "invalid_type"
      }), o;
    o.value = [];
    let a = [], c = [...n].reverse().findIndex((d) => d._zod.optin !== "optional"), u = c === -1 ? 0 : n.length - c;
    if (!t.rest) {
      let d = i.length > n.length, p = i.length < u - 1;
      if (d || p)
        return o.issues.push({
          ...d ? { code: "too_big", maximum: n.length, inclusive: !0 } : { code: "too_small", minimum: n.length },
          input: i,
          inst: e,
          origin: "array"
        }), o;
    }
    let l = -1;
    for (let d of n) {
      if (l++, l >= i.length && l >= u)
        continue;
      let p = d._zod.run({
        value: i[l],
        issues: []
      }, r);
      p instanceof Promise ? a.push(p.then((h) => Ln(h, o, l))) : Ln(p, o, l);
    }
    if (t.rest) {
      let d = i.slice(n.length);
      for (let p of d) {
        l++;
        let h = t.rest._zod.run({
          value: p,
          issues: []
        }, r);
        h instanceof Promise ? a.push(h.then((v) => Ln(v, o, l))) : Ln(h, o, l);
      }
    }
    return a.length ? Promise.all(a).then(() => o) : o;
  };
});
function Ln(e, t, n) {
  e.issues.length && t.issues.push(...ce(n, e.issues)), t.value[n] = e.value;
}
s(Ln, "handleTupleResult");
var it = /* @__PURE__ */ f("$ZodRecord", (e, t) => {
  k.init(e, t), e._zod.parse = (n, o) => {
    let r = n.value;
    if (!Ae(r))
      return n.issues.push({
        expected: "record",
        code: "invalid_type",
        input: r,
        inst: e
      }), n;
    let i = [], a = t.keyType._zod.values;
    if (a) {
      n.value = {};
      let c = /* @__PURE__ */ new Set();
      for (let l of a)
        if (typeof l == "string" || typeof l == "number" || typeof l == "symbol") {
          c.add(typeof l == "number" ? l.toString() : l);
          let d = t.valueType._zod.run({ value: r[l], issues: [] }, o);
          d instanceof Promise ? i.push(d.then((p) => {
            p.issues.length && n.issues.push(...ce(l, p.issues)), n.value[l] = p.value;
          })) : (d.issues.length && n.issues.push(...ce(l, d.issues)), n.value[l] = d.value);
        }
      let u;
      for (let l in r)
        c.has(l) || (u = u ?? [], u.push(l));
      u && u.length > 0 && n.issues.push({
        code: "unrecognized_keys",
        input: r,
        inst: e,
        keys: u
      });
    } else {
      n.value = {};
      for (let c of Reflect.ownKeys(r)) {
        if (c === "__proto__")
          continue;
        let u = t.keyType._zod.run({ value: c, issues: [] }, o);
        if (u instanceof Promise)
          throw new Error("Async schemas not supported in object keys currently");
        if (typeof c == "string" && Cn.test(c) && u.issues.length) {
          let p = t.keyType._zod.run({ value: Number(c), issues: [] }, o);
          if (p instanceof Promise)
            throw new Error("Async schemas not supported in object keys currently");
          p.issues.length === 0 && (u = p);
        }
        if (u.issues.length) {
          t.mode === "loose" ? n.value[c] = r[c] : n.issues.push({
            code: "invalid_key",
            origin: "record",
            issues: u.issues.map((p) => oe(p, o, B())),
            input: c,
            path: [c],
            inst: e
          });
          continue;
        }
        let d = t.valueType._zod.run({ value: r[c], issues: [] }, o);
        d instanceof Promise ? i.push(d.then((p) => {
          p.issues.length && n.issues.push(...ce(c, p.issues)), n.value[u.value] = p.value;
        })) : (d.issues.length && n.issues.push(...ce(c, d.issues)), n.value[u.value] = d.value);
      }
    }
    return i.length ? Promise.all(i).then(() => n) : n;
  };
}), Fs = /* @__PURE__ */ f("$ZodMap", (e, t) => {
  k.init(e, t), e._zod.parse = (n, o) => {
    let r = n.value;
    if (!(r instanceof Map))
      return n.issues.push({
        expected: "map",
        code: "invalid_type",
        input: r,
        inst: e
      }), n;
    let i = [];
    n.value = /* @__PURE__ */ new Map();
    for (let [a, c] of r) {
      let u = t.keyType._zod.run({ value: a, issues: [] }, o), l = t.valueType._zod.run({ value: c, issues: [] }, o);
      u instanceof Promise || l instanceof Promise ? i.push(Promise.all([u, l]).then(([d, p]) => {
        Af(d, p, n, a, r, e, o);
      })) : Af(u, l, n, a, r, e, o);
    }
    return i.length ? Promise.all(i).then(() => n) : n;
  };
});
function Af(e, t, n, o, r, i, a) {
  e.issues.length && ($r.has(typeof o) ? n.issues.push(...ce(o, e.issues)) : n.issues.push({
    code: "invalid_key",
    origin: "map",
    input: r,
    inst: i,
    issues: e.issues.map((c) => oe(c, a, B()))
  })), t.issues.length && ($r.has(typeof o) ? n.issues.push(...ce(o, t.issues)) : n.issues.push({
    origin: "map",
    code: "invalid_element",
    input: r,
    inst: i,
    key: o,
    issues: t.issues.map((c) => oe(c, a, B()))
  })), n.value.set(e.value, t.value);
}
s(Af, "handleMapResult");
var Ls = /* @__PURE__ */ f("$ZodSet", (e, t) => {
  k.init(e, t), e._zod.parse = (n, o) => {
    let r = n.value;
    if (!(r instanceof Set))
      return n.issues.push({
        input: r,
        inst: e,
        expected: "set",
        code: "invalid_type"
      }), n;
    let i = [];
    n.value = /* @__PURE__ */ new Set();
    for (let a of r) {
      let c = t.valueType._zod.run({ value: a, issues: [] }, o);
      c instanceof Promise ? i.push(c.then((u) => Cf(u, n))) : Cf(c, n);
    }
    return i.length ? Promise.all(i).then(() => n) : n;
  };
});
function Cf(e, t) {
  e.issues.length && t.issues.push(...e.issues), t.value.add(e.value);
}
s(Cf, "handleSetResult");
var Ut = /* @__PURE__ */ f("$ZodEnum", (e, t) => {
  k.init(e, t);
  let n = br(t.entries), o = new Set(n);
  e._zod.values = o, e._zod.pattern = new RegExp(`^(${n.filter((r) => $r.has(typeof r)).map((r) => typeof r == "string" ? pe(r) : r.toString()).join("|")})$`), e._zod.parse = (r, i) => {
    let a = r.value;
    return o.has(a) || r.issues.push({
      code: "invalid_value",
      values: n,
      input: a,
      inst: e
    }), r;
  };
}), Dt = /* @__PURE__ */ f("$ZodLiteral", (e, t) => {
  if (k.init(e, t), t.values.length === 0)
    throw new Error("Cannot create literal schema with no valid values");
  let n = new Set(t.values);
  e._zod.values = n, e._zod.pattern = new RegExp(`^(${t.values.map((o) => typeof o == "string" ? pe(o) : o ? pe(o.toString()) : String(o)).join("|")})$`), e._zod.parse = (o, r) => {
    let i = o.value;
    return n.has(i) || o.issues.push({
      code: "invalid_value",
      values: t.values,
      input: i,
      inst: e
    }), o;
  };
}), Ms = /* @__PURE__ */ f("$ZodFile", (e, t) => {
  k.init(e, t), e._zod.parse = (n, o) => {
    let r = n.value;
    return r instanceof File || n.issues.push({
      expected: "file",
      code: "invalid_type",
      input: r,
      inst: e
    }), n;
  };
}), Bs = /* @__PURE__ */ f("$ZodTransform", (e, t) => {
  k.init(e, t), e._zod.parse = (n, o) => {
    if (o.direction === "backward")
      throw new De(e.constructor.name);
    let r = t.transform(n.value, n);
    if (o.async)
      return (r instanceof Promise ? r : Promise.resolve(r)).then((a) => (n.value = a, n));
    if (r instanceof Promise)
      throw new he();
    return n.value = r, n;
  };
});
function Rf(e, t) {
  return e.issues.length && t === void 0 ? { issues: [], value: void 0 } : e;
}
s(Rf, "handleOptionalResult");
var M = /* @__PURE__ */ f("$ZodOptional", (e, t) => {
  k.init(e, t), e._zod.optin = "optional", e._zod.optout = "optional", j(e._zod, "values", () => t.innerType._zod.values ? /* @__PURE__ */ new Set([...t.innerType._zod.values, void 0]) : void 0), j(e._zod, "pattern", () => {
    let n = t.innerType._zod.pattern;
    return n ? new RegExp(`^(${xr(n.source)})?$`) : void 0;
  }), e._zod.parse = (n, o) => {
    if (t.innerType._zod.optin === "optional") {
      let r = t.innerType._zod.run(n, o);
      return r instanceof Promise ? r.then((i) => Rf(i, n.value)) : Rf(r, n.value);
    }
    return n.value === void 0 ? n : t.innerType._zod.run(n, o);
  };
}), Js = /* @__PURE__ */ f("$ZodExactOptional", (e, t) => {
  M.init(e, t), j(e._zod, "values", () => t.innerType._zod.values), j(e._zod, "pattern", () => t.innerType._zod.pattern), e._zod.parse = (n, o) => t.innerType._zod.run(n, o);
}), be = /* @__PURE__ */ f("$ZodNullable", (e, t) => {
  k.init(e, t), j(e._zod, "optin", () => t.innerType._zod.optin), j(e._zod, "optout", () => t.innerType._zod.optout), j(e._zod, "pattern", () => {
    let n = t.innerType._zod.pattern;
    return n ? new RegExp(`^(${xr(n.source)}|null)$`) : void 0;
  }), j(e._zod, "values", () => t.innerType._zod.values ? /* @__PURE__ */ new Set([...t.innerType._zod.values, null]) : void 0), e._zod.parse = (n, o) => n.value === null ? n : t.innerType._zod.run(n, o);
}), ue = /* @__PURE__ */ f("$ZodDefault", (e, t) => {
  k.init(e, t), e._zod.optin = "optional", j(e._zod, "values", () => t.innerType._zod.values), e._zod.parse = (n, o) => {
    if (o.direction === "backward")
      return t.innerType._zod.run(n, o);
    if (n.value === void 0)
      return n.value = t.defaultValue, n;
    let r = t.innerType._zod.run(n, o);
    return r instanceof Promise ? r.then((i) => Ff(i, t)) : Ff(r, t);
  };
});
function Ff(e, t) {
  return e.value === void 0 && (e.value = t.defaultValue), e;
}
s(Ff, "handleDefaultResult");
var Vs = /* @__PURE__ */ f("$ZodPrefault", (e, t) => {
  k.init(e, t), e._zod.optin = "optional", j(e._zod, "values", () => t.innerType._zod.values), e._zod.parse = (n, o) => (o.direction === "backward" || n.value === void 0 && (n.value = t.defaultValue), t.innerType._zod.run(n, o));
}), qs = /* @__PURE__ */ f("$ZodNonOptional", (e, t) => {
  k.init(e, t), j(e._zod, "values", () => {
    let n = t.innerType._zod.values;
    return n ? new Set([...n].filter((o) => o !== void 0)) : void 0;
  }), e._zod.parse = (n, o) => {
    let r = t.innerType._zod.run(n, o);
    return r instanceof Promise ? r.then((i) => Lf(i, e)) : Lf(r, e);
  };
});
function Lf(e, t) {
  return !e.issues.length && e.value === void 0 && e.issues.push({
    code: "invalid_type",
    expected: "nonoptional",
    input: e.value,
    inst: t
  }), e;
}
s(Lf, "handleNonOptionalResult");
var Ws = /* @__PURE__ */ f("$ZodSuccess", (e, t) => {
  k.init(e, t), e._zod.parse = (n, o) => {
    if (o.direction === "backward")
      throw new De("ZodSuccess");
    let r = t.innerType._zod.run(n, o);
    return r instanceof Promise ? r.then((i) => (n.value = i.issues.length === 0, n)) : (n.value = r.issues.length === 0, n);
  };
}), Ks = /* @__PURE__ */ f("$ZodCatch", (e, t) => {
  k.init(e, t), j(e._zod, "optin", () => t.innerType._zod.optin), j(e._zod, "optout", () => t.innerType._zod.optout), j(e._zod, "values", () => t.innerType._zod.values), e._zod.parse = (n, o) => {
    if (o.direction === "backward")
      return t.innerType._zod.run(n, o);
    let r = t.innerType._zod.run(n, o);
    return r instanceof Promise ? r.then((i) => (n.value = i.value, i.issues.length && (n.value = t.catchValue({
      ...n,
      error: {
        issues: i.issues.map((a) => oe(a, o, B()))
      },
      input: n.value
    }), n.issues = []), n)) : (n.value = r.value, r.issues.length && (n.value = t.catchValue({
      ...n,
      error: {
        issues: r.issues.map((i) => oe(i, o, B()))
      },
      input: n.value
    }), n.issues = []), n);
  };
}), Gs = /* @__PURE__ */ f("$ZodNaN", (e, t) => {
  k.init(e, t), e._zod.parse = (n, o) => ((typeof n.value != "number" || !Number.isNaN(n.value)) && n.issues.push({
    input: n.value,
    inst: e,
    expected: "nan",
    code: "invalid_type"
  }), n);
}), Xs = /* @__PURE__ */ f("$ZodPipe", (e, t) => {
  k.init(e, t), j(e._zod, "values", () => t.in._zod.values), j(e._zod, "optin", () => t.in._zod.optin), j(e._zod, "optout", () => t.out._zod.optout), j(e._zod, "propValues", () => t.in._zod.propValues), e._zod.parse = (n, o) => {
    if (o.direction === "backward") {
      let i = t.out._zod.run(n, o);
      return i instanceof Promise ? i.then((a) => Mn(a, t.in, o)) : Mn(i, t.in, o);
    }
    let r = t.in._zod.run(n, o);
    return r instanceof Promise ? r.then((i) => Mn(i, t.out, o)) : Mn(r, t.out, o);
  };
});
function Mn(e, t, n) {
  return e.issues.length ? (e.aborted = !0, e) : t._zod.run({ value: e.value, issues: e.issues }, n);
}
s(Mn, "handlePipeResult");
var xe = /* @__PURE__ */ f("$ZodCodec", (e, t) => {
  k.init(e, t), j(e._zod, "values", () => t.in._zod.values), j(e._zod, "optin", () => t.in._zod.optin), j(e._zod, "optout", () => t.out._zod.optout), j(e._zod, "propValues", () => t.in._zod.propValues), e._zod.parse = (n, o) => {
    if ((o.direction || "forward") === "forward") {
      let i = t.in._zod.run(n, o);
      return i instanceof Promise ? i.then((a) => Bn(a, t, o)) : Bn(i, t, o);
    } else {
      let i = t.out._zod.run(n, o);
      return i instanceof Promise ? i.then((a) => Bn(a, t, o)) : Bn(i, t, o);
    }
  };
});
function Bn(e, t, n) {
  if (e.issues.length)
    return e.aborted = !0, e;
  if ((n.direction || "forward") === "forward") {
    let r = t.transform(e.value, e);
    return r instanceof Promise ? r.then((i) => Jn(e, i, t.out, n)) : Jn(e, r, t.out, n);
  } else {
    let r = t.reverseTransform(e.value, e);
    return r instanceof Promise ? r.then((i) => Jn(e, i, t.in, n)) : Jn(e, r, t.in, n);
  }
}
s(Bn, "handleCodecAResult");
function Jn(e, t, n, o) {
  return e.issues.length ? (e.aborted = !0, e) : n._zod.run({ value: t, issues: e.issues }, o);
}
s(Jn, "handleCodecTxResult");
var Qs = /* @__PURE__ */ f("$ZodReadonly", (e, t) => {
  k.init(e, t), j(e._zod, "propValues", () => t.innerType._zod.propValues), j(e._zod, "values", () => t.innerType._zod.values), j(e._zod, "optin", () => t.innerType?._zod?.optin), j(e._zod, "optout", () => t.innerType?._zod?.optout), e._zod.parse = (n, o) => {
    if (o.direction === "backward")
      return t.innerType._zod.run(n, o);
    let r = t.innerType._zod.run(n, o);
    return r instanceof Promise ? r.then(Mf) : Mf(r);
  };
});
function Mf(e) {
  return e.value = Object.freeze(e.value), e;
}
s(Mf, "handleReadonlyResult");
var Hs = /* @__PURE__ */ f("$ZodTemplateLiteral", (e, t) => {
  k.init(e, t);
  let n = [];
  for (let o of t.parts)
    if (typeof o == "object" && o !== null) {
      if (!o._zod.pattern)
        throw new Error(`Invalid template literal part, no pattern found: ${[...o._zod.traits].shift()}`);
      let r = o._zod.pattern instanceof RegExp ? o._zod.pattern.source : o._zod.pattern;
      if (!r)
        throw new Error(`Invalid template literal part: ${o._zod.traits}`);
      let i = r.startsWith("^") ? 1 : 0, a = r.endsWith("$") ? r.length - 1 : r.length;
      n.push(r.slice(i, a));
    } else if (o === null || ta.has(typeof o))
      n.push(pe(`${o}`));
    else
      throw new Error(`Invalid template literal part: ${o}`);
  e._zod.pattern = new RegExp(`^${n.join("")}$`), e._zod.parse = (o, r) => typeof o.value != "string" ? (o.issues.push({
    input: o.value,
    inst: e,
    expected: "string",
    code: "invalid_type"
  }), o) : (e._zod.pattern.lastIndex = 0, e._zod.pattern.test(o.value) || o.issues.push({
    input: o.value,
    inst: e,
    code: "invalid_format",
    format: t.format ?? "template_literal",
    pattern: e._zod.pattern.source
  }), o);
}), Ys = /* @__PURE__ */ f("$ZodFunction", (e, t) => (k.init(e, t), e._def = t, e._zod.def = t, e.implement = (n) => {
  if (typeof n != "function")
    throw new Error("implement() must be called with a function");
  return function(...o) {
    let r = e._def.input ? Re(e._def.input, o) : o, i = Reflect.apply(n, this, r);
    return e._def.output ? Re(e._def.output, i) : i;
  };
}, e.implementAsync = (n) => {
  if (typeof n != "function")
    throw new Error("implementAsync() must be called with a function");
  return async function(...o) {
    let r = e._def.input ? await jn(e._def.input, o) : o, i = await Reflect.apply(n, this, r);
    return e._def.output ? await jn(e._def.output, i) : i;
  };
}, e._zod.parse = (n, o) => typeof n.value != "function" ? (n.issues.push({
  code: "invalid_type",
  expected: "function",
  input: n.value,
  inst: e
}), n) : (e._def.output && e._def.output._zod.def.type === "promise" ? n.value = e.implementAsync(n.value) : n.value = e.implement(n.value), n), e.input = (...n) => {
  let o = e.constructor;
  return Array.isArray(n[0]) ? new o({
    type: "function",
    input: new Me({
      type: "tuple",
      items: n[0],
      rest: n[1]
    }),
    output: e._def.output
  }) : new o({
    type: "function",
    input: n[0],
    output: e._def.output
  });
}, e.output = (n) => {
  let o = e.constructor;
  return new o({
    type: "function",
    input: e._def.input,
    output: n
  });
}, e)), ec = /* @__PURE__ */ f("$ZodPromise", (e, t) => {
  k.init(e, t), e._zod.parse = (n, o) => Promise.resolve(n.value).then((r) => t.innerType._zod.run({ value: r, issues: [] }, o));
}), Nt = /* @__PURE__ */ f("$ZodLazy", (e, t) => {
  k.init(e, t), j(e._zod, "innerType", () => t.getter()), j(e._zod, "pattern", () => e._zod.innerType?._zod?.pattern), j(e._zod, "propValues", () => e._zod.innerType?._zod?.propValues), j(e._zod, "optin", () => e._zod.innerType?._zod?.optin ?? void 0), j(e._zod, "optout", () => e._zod.innerType?._zod?.optout ?? void 0), e._zod.parse = (n, o) => e._zod.innerType._zod.run(n, o);
}), Pr = /* @__PURE__ */ f("$ZodCustom", (e, t) => {
  C.init(e, t), k.init(e, t), e._zod.parse = (n, o) => n, e._zod.check = (n) => {
    let o = n.value, r = t.fn(o);
    if (r instanceof Promise)
      return r.then((i) => Bf(i, n, o, e));
    Bf(r, n, o, e);
  };
});
function Bf(e, t, n, o) {
  if (!e) {
    let r = {
      code: "custom",
      input: n,
      inst: o,
      // incorporates params.error into issue reporting
      path: [...o._zod.def.path ?? []],
      // incorporates params.error into issue reporting
      continue: !o._zod.def.abort
      // params: inst._zod.def.params,
    };
    o._zod.def.params && (r.params = o._zod.def.params), t.issues.push(It(r));
  }
}
s(Bf, "handleRefineResult");

// versions/4.3.6/node_modules/zod/v4/locales/index.js
var Nr = {};
Oe(Nr, {
  ar: () => tc,
  az: () => rc,
  be: () => nc,
  bg: () => oc,
  ca: () => ic,
  cs: () => ac,
  da: () => sc,
  de: () => cc,
  en: () => Tr,
  eo: () => uc,
  es: () => lc,
  fa: () => dc,
  fi: () => fc,
  fr: () => pc,
  frCA: () => mc,
  he: () => gc,
  hu: () => hc,
  hy: () => vc,
  id: () => yc,
  is: () => bc,
  it: () => xc,
  ja: () => $c,
  ka: () => _c,
  kh: () => wc,
  km: () => Er,
  ko: () => kc,
  lt: () => zc,
  mk: () => Ic,
  ms: () => Sc,
  nl: () => jc,
  no: () => Oc,
  ota: () => Pc,
  pl: () => Ec,
  ps: () => Tc,
  pt: () => Uc,
  ru: () => Dc,
  sl: () => Nc,
  sv: () => Zc,
  ta: () => Ac,
  th: () => Cc,
  tr: () => Rc,
  ua: () => Fc,
  uk: () => Dr,
  ur: () => Lc,
  uz: () => Mc,
  vi: () => Bc,
  yo: () => qc,
  zhCN: () => Jc,
  zhTW: () => Vc
});

// versions/4.3.6/node_modules/zod/v4/locales/ar.js
var zv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u062D\u0631\u0641", verb: "\u0623\u0646 \u064A\u062D\u0648\u064A" },
    file: { unit: "\u0628\u0627\u064A\u062A", verb: "\u0623\u0646 \u064A\u062D\u0648\u064A" },
    array: { unit: "\u0639\u0646\u0635\u0631", verb: "\u0623\u0646 \u064A\u062D\u0648\u064A" },
    set: { unit: "\u0639\u0646\u0635\u0631", verb: "\u0623\u0646 \u064A\u062D\u0648\u064A" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u0645\u062F\u062E\u0644",
    email: "\u0628\u0631\u064A\u062F \u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A",
    url: "\u0631\u0627\u0628\u0637",
    emoji: "\u0625\u064A\u0645\u0648\u062C\u064A",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u062A\u0627\u0631\u064A\u062E \u0648\u0648\u0642\u062A \u0628\u0645\u0639\u064A\u0627\u0631 ISO",
    date: "\u062A\u0627\u0631\u064A\u062E \u0628\u0645\u0639\u064A\u0627\u0631 ISO",
    time: "\u0648\u0642\u062A \u0628\u0645\u0639\u064A\u0627\u0631 ISO",
    duration: "\u0645\u062F\u0629 \u0628\u0645\u0639\u064A\u0627\u0631 ISO",
    ipv4: "\u0639\u0646\u0648\u0627\u0646 IPv4",
    ipv6: "\u0639\u0646\u0648\u0627\u0646 IPv6",
    cidrv4: "\u0645\u062F\u0649 \u0639\u0646\u0627\u0648\u064A\u0646 \u0628\u0635\u064A\u063A\u0629 IPv4",
    cidrv6: "\u0645\u062F\u0649 \u0639\u0646\u0627\u0648\u064A\u0646 \u0628\u0635\u064A\u063A\u0629 IPv6",
    base64: "\u0646\u064E\u0635 \u0628\u062A\u0631\u0645\u064A\u0632 base64-encoded",
    base64url: "\u0646\u064E\u0635 \u0628\u062A\u0631\u0645\u064A\u0632 base64url-encoded",
    json_string: "\u0646\u064E\u0635 \u0639\u0644\u0649 \u0647\u064A\u0626\u0629 JSON",
    e164: "\u0631\u0642\u0645 \u0647\u0627\u062A\u0641 \u0628\u0645\u0639\u064A\u0627\u0631 E.164",
    jwt: "JWT",
    template_literal: "\u0645\u062F\u062E\u0644"
  }, o = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), c = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u0645\u062F\u062E\u0644\u0627\u062A \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644\u0629: \u064A\u0641\u062A\u0631\u0636 \u0625\u062F\u062E\u0627\u0644 instanceof ${r.expected}\u060C \u0648\u0644\u0643\u0646 \u062A\u0645 \u0625\u062F\u062E\u0627\u0644 ${c}` : `\u0645\u062F\u062E\u0644\u0627\u062A \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644\u0629: \u064A\u0641\u062A\u0631\u0636 \u0625\u062F\u062E\u0627\u0644 ${i}\u060C \u0648\u0644\u0643\u0646 \u062A\u0645 \u0625\u062F\u062E\u0627\u0644 ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u0645\u062F\u062E\u0644\u0627\u062A \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644\u0629: \u064A\u0641\u062A\u0631\u0636 \u0625\u062F\u062E\u0627\u0644 ${y(r.values[0])}` : `\u0627\u062E\u062A\u064A\u0627\u0631 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062A\u0648\u0642\u0639 \u0627\u0646\u062A\u0642\u0627\u0621 \u0623\u062D\u062F \u0647\u0630\u0647 \u0627\u0644\u062E\u064A\u0627\u0631\u0627\u062A: ${m(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? ` \u0623\u0643\u0628\u0631 \u0645\u0646 \u0627\u0644\u0644\u0627\u0632\u0645: \u064A\u0641\u062A\u0631\u0636 \u0623\u0646 \u062A\u0643\u0648\u0646 ${r.origin ?? "\u0627\u0644\u0642\u064A\u0645\u0629"} ${i} ${r.maximum.toString()} ${a.unit ?? "\u0639\u0646\u0635\u0631"}` : `\u0623\u0643\u0628\u0631 \u0645\u0646 \u0627\u0644\u0644\u0627\u0632\u0645: \u064A\u0641\u062A\u0631\u0636 \u0623\u0646 \u062A\u0643\u0648\u0646 ${r.origin ?? "\u0627\u0644\u0642\u064A\u0645\u0629"} ${i} ${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\u0623\u0635\u063A\u0631 \u0645\u0646 \u0627\u0644\u0644\u0627\u0632\u0645: \u064A\u0641\u062A\u0631\u0636 \u0644\u0640 ${r.origin} \u0623\u0646 \u064A\u0643\u0648\u0646 ${i} ${r.minimum.toString()} ${a.unit}` : `\u0623\u0635\u063A\u0631 \u0645\u0646 \u0627\u0644\u0644\u0627\u0632\u0645: \u064A\u0641\u062A\u0631\u0636 \u0644\u0640 ${r.origin} \u0623\u0646 \u064A\u0643\u0648\u0646 ${i} ${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u0646\u064E\u0635 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u0628\u062F\u0623 \u0628\u0640 "${r.prefix}"` : i.format === "ends_with" ? `\u0646\u064E\u0635 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u0646\u062A\u0647\u064A \u0628\u0640 "${i.suffix}"` : i.format === "includes" ? `\u0646\u064E\u0635 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u062A\u0636\u0645\u0651\u064E\u0646 "${i.includes}"` : i.format === "regex" ? `\u0646\u064E\u0635 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u0637\u0627\u0628\u0642 \u0627\u0644\u0646\u0645\u0637 ${i.pattern}` : `${n[i.format] ?? r.format} \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644`;
      }
      case "not_multiple_of":
        return `\u0631\u0642\u0645 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u0643\u0648\u0646 \u0645\u0646 \u0645\u0636\u0627\u0639\u0641\u0627\u062A ${r.divisor}`;
      case "unrecognized_keys":
        return `\u0645\u0639\u0631\u0641${r.keys.length > 1 ? "\u0627\u062A" : ""} \u063A\u0631\u064A\u0628${r.keys.length > 1 ? "\u0629" : ""}: ${m(r.keys, "\u060C ")}`;
      case "invalid_key":
        return `\u0645\u0639\u0631\u0641 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644 \u0641\u064A ${r.origin}`;
      case "invalid_union":
        return "\u0645\u062F\u062E\u0644 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644";
      case "invalid_element":
        return `\u0645\u062F\u062E\u0644 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644 \u0641\u064A ${r.origin}`;
      default:
        return "\u0645\u062F\u062E\u0644 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644";
    }
  };
}, "error");
function tc() {
  return {
    localeError: zv()
  };
}
s(tc, "default");

// versions/4.3.6/node_modules/zod/v4/locales/az.js
var Iv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "simvol", verb: "olmal\u0131d\u0131r" },
    file: { unit: "bayt", verb: "olmal\u0131d\u0131r" },
    array: { unit: "element", verb: "olmal\u0131d\u0131r" },
    set: { unit: "element", verb: "olmal\u0131d\u0131r" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "input",
    email: "email address",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datetime",
    date: "ISO date",
    time: "ISO time",
    duration: "ISO duration",
    ipv4: "IPv4 address",
    ipv6: "IPv6 address",
    cidrv4: "IPv4 range",
    cidrv6: "IPv6 range",
    base64: "base64-encoded string",
    base64url: "base64url-encoded string",
    json_string: "JSON string",
    e164: "E.164 number",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), c = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Yanl\u0131\u015F d\u0259y\u0259r: g\xF6zl\u0259nil\u0259n instanceof ${r.expected}, daxil olan ${c}` : `Yanl\u0131\u015F d\u0259y\u0259r: g\xF6zl\u0259nil\u0259n ${i}, daxil olan ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Yanl\u0131\u015F d\u0259y\u0259r: g\xF6zl\u0259nil\u0259n ${y(r.values[0])}` : `Yanl\u0131\u015F se\xE7im: a\u015Fa\u011F\u0131dak\u0131lardan biri olmal\u0131d\u0131r: ${m(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `\xC7ox b\xF6y\xFCk: g\xF6zl\u0259nil\u0259n ${r.origin ?? "d\u0259y\u0259r"} ${i}${r.maximum.toString()} ${a.unit ?? "element"}` : `\xC7ox b\xF6y\xFCk: g\xF6zl\u0259nil\u0259n ${r.origin ?? "d\u0259y\u0259r"} ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\xC7ox ki\xE7ik: g\xF6zl\u0259nil\u0259n ${r.origin} ${i}${r.minimum.toString()} ${a.unit}` : `\xC7ox ki\xE7ik: g\xF6zl\u0259nil\u0259n ${r.origin} ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Yanl\u0131\u015F m\u0259tn: "${i.prefix}" il\u0259 ba\u015Flamal\u0131d\u0131r` : i.format === "ends_with" ? `Yanl\u0131\u015F m\u0259tn: "${i.suffix}" il\u0259 bitm\u0259lidir` : i.format === "includes" ? `Yanl\u0131\u015F m\u0259tn: "${i.includes}" daxil olmal\u0131d\u0131r` : i.format === "regex" ? `Yanl\u0131\u015F m\u0259tn: ${i.pattern} \u015Fablonuna uy\u011Fun olmal\u0131d\u0131r` : `Yanl\u0131\u015F ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Yanl\u0131\u015F \u0259d\u0259d: ${r.divisor} il\u0259 b\xF6l\xFCn\u0259 bil\u0259n olmal\u0131d\u0131r`;
      case "unrecognized_keys":
        return `Tan\u0131nmayan a\xE7ar${r.keys.length > 1 ? "lar" : ""}: ${m(r.keys, ", ")}`;
      case "invalid_key":
        return `${r.origin} daxilind\u0259 yanl\u0131\u015F a\xE7ar`;
      case "invalid_union":
        return "Yanl\u0131\u015F d\u0259y\u0259r";
      case "invalid_element":
        return `${r.origin} daxilind\u0259 yanl\u0131\u015F d\u0259y\u0259r`;
      default:
        return "Yanl\u0131\u015F d\u0259y\u0259r";
    }
  };
}, "error");
function rc() {
  return {
    localeError: Iv()
  };
}
s(rc, "default");

// versions/4.3.6/node_modules/zod/v4/locales/be.js
function Kf(e, t, n, o) {
  let r = Math.abs(e), i = r % 10, a = r % 100;
  return a >= 11 && a <= 19 ? o : i === 1 ? t : i >= 2 && i <= 4 ? n : o;
}
s(Kf, "getBelarusianPlural");
var Sv = /* @__PURE__ */ s(() => {
  let e = {
    string: {
      unit: {
        one: "\u0441\u0456\u043C\u0432\u0430\u043B",
        few: "\u0441\u0456\u043C\u0432\u0430\u043B\u044B",
        many: "\u0441\u0456\u043C\u0432\u0430\u043B\u0430\u045E"
      },
      verb: "\u043C\u0435\u0446\u044C"
    },
    array: {
      unit: {
        one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
        few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u044B",
        many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430\u045E"
      },
      verb: "\u043C\u0435\u0446\u044C"
    },
    set: {
      unit: {
        one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
        few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u044B",
        many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430\u045E"
      },
      verb: "\u043C\u0435\u0446\u044C"
    },
    file: {
      unit: {
        one: "\u0431\u0430\u0439\u0442",
        few: "\u0431\u0430\u0439\u0442\u044B",
        many: "\u0431\u0430\u0439\u0442\u0430\u045E"
      },
      verb: "\u043C\u0435\u0446\u044C"
    }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u0443\u0432\u043E\u0434",
    email: "email \u0430\u0434\u0440\u0430\u0441",
    url: "URL",
    emoji: "\u044D\u043C\u043E\u0434\u0437\u0456",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0434\u0430\u0442\u0430 \u0456 \u0447\u0430\u0441",
    date: "ISO \u0434\u0430\u0442\u0430",
    time: "ISO \u0447\u0430\u0441",
    duration: "ISO \u043F\u0440\u0430\u0446\u044F\u0433\u043B\u0430\u0441\u0446\u044C",
    ipv4: "IPv4 \u0430\u0434\u0440\u0430\u0441",
    ipv6: "IPv6 \u0430\u0434\u0440\u0430\u0441",
    cidrv4: "IPv4 \u0434\u044B\u044F\u043F\u0430\u0437\u043E\u043D",
    cidrv6: "IPv6 \u0434\u044B\u044F\u043F\u0430\u0437\u043E\u043D",
    base64: "\u0440\u0430\u0434\u043E\u043A \u0443 \u0444\u0430\u0440\u043C\u0430\u0446\u0435 base64",
    base64url: "\u0440\u0430\u0434\u043E\u043A \u0443 \u0444\u0430\u0440\u043C\u0430\u0446\u0435 base64url",
    json_string: "JSON \u0440\u0430\u0434\u043E\u043A",
    e164: "\u043D\u0443\u043C\u0430\u0440 E.164",
    jwt: "JWT",
    template_literal: "\u0443\u0432\u043E\u0434"
  }, o = {
    nan: "NaN",
    number: "\u043B\u0456\u043A",
    array: "\u043C\u0430\u0441\u0456\u045E"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), c = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434: \u0447\u0430\u043A\u0430\u045E\u0441\u044F instanceof ${r.expected}, \u0430\u0442\u0440\u044B\u043C\u0430\u043D\u0430 ${c}` : `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434: \u0447\u0430\u043A\u0430\u045E\u0441\u044F ${i}, \u0430\u0442\u0440\u044B\u043C\u0430\u043D\u0430 ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F ${y(r.values[0])}` : `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0432\u0430\u0440\u044B\u044F\u043D\u0442: \u0447\u0430\u043A\u0430\u045E\u0441\u044F \u0430\u0434\u0437\u0456\u043D \u0437 ${m(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        if (a) {
          let c = Number(r.maximum), u = Kf(c, a.unit.one, a.unit.few, a.unit.many);
          return `\u0417\u0430\u043D\u0430\u0434\u0442\u0430 \u0432\u044F\u043B\u0456\u043A\u0456: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F, \u0448\u0442\u043E ${r.origin ?? "\u0437\u043D\u0430\u0447\u044D\u043D\u043D\u0435"} \u043F\u0430\u0432\u0456\u043D\u043D\u0430 ${a.verb} ${i}${r.maximum.toString()} ${u}`;
        }
        return `\u0417\u0430\u043D\u0430\u0434\u0442\u0430 \u0432\u044F\u043B\u0456\u043A\u0456: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F, \u0448\u0442\u043E ${r.origin ?? "\u0437\u043D\u0430\u0447\u044D\u043D\u043D\u0435"} \u043F\u0430\u0432\u0456\u043D\u043D\u0430 \u0431\u044B\u0446\u044C ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        if (a) {
          let c = Number(r.minimum), u = Kf(c, a.unit.one, a.unit.few, a.unit.many);
          return `\u0417\u0430\u043D\u0430\u0434\u0442\u0430 \u043C\u0430\u043B\u044B: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F, \u0448\u0442\u043E ${r.origin} \u043F\u0430\u0432\u0456\u043D\u043D\u0430 ${a.verb} ${i}${r.minimum.toString()} ${u}`;
        }
        return `\u0417\u0430\u043D\u0430\u0434\u0442\u0430 \u043C\u0430\u043B\u044B: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F, \u0448\u0442\u043E ${r.origin} \u043F\u0430\u0432\u0456\u043D\u043D\u0430 \u0431\u044B\u0446\u044C ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0440\u0430\u0434\u043E\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u043F\u0430\u0447\u044B\u043D\u0430\u0446\u0446\u0430 \u0437 "${i.prefix}"` : i.format === "ends_with" ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0440\u0430\u0434\u043E\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u0437\u0430\u043A\u0430\u043D\u0447\u0432\u0430\u0446\u0446\u0430 \u043D\u0430 "${i.suffix}"` : i.format === "includes" ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0440\u0430\u0434\u043E\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u0437\u043C\u044F\u0448\u0447\u0430\u0446\u044C "${i.includes}"` : i.format === "regex" ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0440\u0430\u0434\u043E\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u0430\u0434\u043F\u0430\u0432\u044F\u0434\u0430\u0446\u044C \u0448\u0430\u0431\u043B\u043E\u043D\u0443 ${i.pattern}` : `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u043B\u0456\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u0431\u044B\u0446\u044C \u043A\u0440\u0430\u0442\u043D\u044B\u043C ${r.divisor}`;
      case "unrecognized_keys":
        return `\u041D\u0435\u0440\u0430\u0441\u043F\u0430\u0437\u043D\u0430\u043D\u044B ${r.keys.length > 1 ? "\u043A\u043B\u044E\u0447\u044B" : "\u043A\u043B\u044E\u0447"}: ${m(r.keys, ", ")}`;
      case "invalid_key":
        return `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u043A\u043B\u044E\u0447 \u0443 ${r.origin}`;
      case "invalid_union":
        return "\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434";
      case "invalid_element":
        return `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u0430\u0435 \u0437\u043D\u0430\u0447\u044D\u043D\u043D\u0435 \u045E ${r.origin}`;
      default:
        return "\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434";
    }
  };
}, "error");
function nc() {
  return {
    localeError: Sv()
  };
}
s(nc, "default");

// versions/4.3.6/node_modules/zod/v4/locales/bg.js
var jv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0441\u0438\u043C\u0432\u043E\u043B\u0430", verb: "\u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430" },
    file: { unit: "\u0431\u0430\u0439\u0442\u0430", verb: "\u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430" },
    array: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0430", verb: "\u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430" },
    set: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0430", verb: "\u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u0432\u0445\u043E\u0434",
    email: "\u0438\u043C\u0435\u0439\u043B \u0430\u0434\u0440\u0435\u0441",
    url: "URL",
    emoji: "\u0435\u043C\u043E\u0434\u0436\u0438",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0432\u0440\u0435\u043C\u0435",
    date: "ISO \u0434\u0430\u0442\u0430",
    time: "ISO \u0432\u0440\u0435\u043C\u0435",
    duration: "ISO \u043F\u0440\u043E\u0434\u044A\u043B\u0436\u0438\u0442\u0435\u043B\u043D\u043E\u0441\u0442",
    ipv4: "IPv4 \u0430\u0434\u0440\u0435\u0441",
    ipv6: "IPv6 \u0430\u0434\u0440\u0435\u0441",
    cidrv4: "IPv4 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D",
    cidrv6: "IPv6 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D",
    base64: "base64-\u043A\u043E\u0434\u0438\u0440\u0430\u043D \u043D\u0438\u0437",
    base64url: "base64url-\u043A\u043E\u0434\u0438\u0440\u0430\u043D \u043D\u0438\u0437",
    json_string: "JSON \u043D\u0438\u0437",
    e164: "E.164 \u043D\u043E\u043C\u0435\u0440",
    jwt: "JWT",
    template_literal: "\u0432\u0445\u043E\u0434"
  }, o = {
    nan: "NaN",
    number: "\u0447\u0438\u0441\u043B\u043E",
    array: "\u043C\u0430\u0441\u0438\u0432"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), c = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434: \u043E\u0447\u0430\u043A\u0432\u0430\u043D instanceof ${r.expected}, \u043F\u043E\u043B\u0443\u0447\u0435\u043D ${c}` : `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434: \u043E\u0447\u0430\u043A\u0432\u0430\u043D ${i}, \u043F\u043E\u043B\u0443\u0447\u0435\u043D ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434: \u043E\u0447\u0430\u043A\u0432\u0430\u043D ${y(r.values[0])}` : `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u0430 \u043E\u043F\u0446\u0438\u044F: \u043E\u0447\u0430\u043A\u0432\u0430\u043D\u043E \u0435\u0434\u043D\u043E \u043E\u0442 ${m(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `\u0422\u0432\u044A\u0440\u0434\u0435 \u0433\u043E\u043B\u044F\u043C\u043E: \u043E\u0447\u0430\u043A\u0432\u0430 \u0441\u0435 ${r.origin ?? "\u0441\u0442\u043E\u0439\u043D\u043E\u0441\u0442"} \u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430 ${i}${r.maximum.toString()} ${a.unit ?? "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0430"}` : `\u0422\u0432\u044A\u0440\u0434\u0435 \u0433\u043E\u043B\u044F\u043C\u043E: \u043E\u0447\u0430\u043A\u0432\u0430 \u0441\u0435 ${r.origin ?? "\u0441\u0442\u043E\u0439\u043D\u043E\u0441\u0442"} \u0434\u0430 \u0431\u044A\u0434\u0435 ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\u0422\u0432\u044A\u0440\u0434\u0435 \u043C\u0430\u043B\u043A\u043E: \u043E\u0447\u0430\u043A\u0432\u0430 \u0441\u0435 ${r.origin} \u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430 ${i}${r.minimum.toString()} ${a.unit}` : `\u0422\u0432\u044A\u0440\u0434\u0435 \u043C\u0430\u043B\u043A\u043E: \u043E\u0447\u0430\u043A\u0432\u0430 \u0441\u0435 ${r.origin} \u0434\u0430 \u0431\u044A\u0434\u0435 ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        if (i.format === "starts_with")
          return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043D\u0438\u0437: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0437\u0430\u043F\u043E\u0447\u0432\u0430 \u0441 "${i.prefix}"`;
        if (i.format === "ends_with")
          return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043D\u0438\u0437: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0437\u0430\u0432\u044A\u0440\u0448\u0432\u0430 \u0441 "${i.suffix}"`;
        if (i.format === "includes")
          return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043D\u0438\u0437: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0432\u043A\u043B\u044E\u0447\u0432\u0430 "${i.includes}"`;
        if (i.format === "regex")
          return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043D\u0438\u0437: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0441\u044A\u0432\u043F\u0430\u0434\u0430 \u0441 ${i.pattern}`;
        let a = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D";
        return i.format === "emoji" && (a = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u043E"), i.format === "datetime" && (a = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u043E"), i.format === "date" && (a = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u0430"), i.format === "time" && (a = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u043E"), i.format === "duration" && (a = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u0430"), `${a} ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u043E \u0447\u0438\u0441\u043B\u043E: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0431\u044A\u0434\u0435 \u043A\u0440\u0430\u0442\u043D\u043E \u043D\u0430 ${r.divisor}`;
      case "unrecognized_keys":
        return `\u041D\u0435\u0440\u0430\u0437\u043F\u043E\u0437\u043D\u0430\u0442${r.keys.length > 1 ? "\u0438" : ""} \u043A\u043B\u044E\u0447${r.keys.length > 1 ? "\u043E\u0432\u0435" : ""}: ${m(r.keys, ", ")}`;
      case "invalid_key":
        return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043A\u043B\u044E\u0447 \u0432 ${r.origin}`;
      case "invalid_union":
        return "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434";
      case "invalid_element":
        return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u0430 \u0441\u0442\u043E\u0439\u043D\u043E\u0441\u0442 \u0432 ${r.origin}`;
      default:
        return "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434";
    }
  };
}, "error");
function oc() {
  return {
    localeError: jv()
  };
}
s(oc, "default");

// versions/4.3.6/node_modules/zod/v4/locales/ca.js
var Ov = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "car\xE0cters", verb: "contenir" },
    file: { unit: "bytes", verb: "contenir" },
    array: { unit: "elements", verb: "contenir" },
    set: { unit: "elements", verb: "contenir" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "entrada",
    email: "adre\xE7a electr\xF2nica",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "data i hora ISO",
    date: "data ISO",
    time: "hora ISO",
    duration: "durada ISO",
    ipv4: "adre\xE7a IPv4",
    ipv6: "adre\xE7a IPv6",
    cidrv4: "rang IPv4",
    cidrv6: "rang IPv6",
    base64: "cadena codificada en base64",
    base64url: "cadena codificada en base64url",
    json_string: "cadena JSON",
    e164: "n\xFAmero E.164",
    jwt: "JWT",
    template_literal: "entrada"
  }, o = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), c = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Tipus inv\xE0lid: s'esperava instanceof ${r.expected}, s'ha rebut ${c}` : `Tipus inv\xE0lid: s'esperava ${i}, s'ha rebut ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Valor inv\xE0lid: s'esperava ${y(r.values[0])}` : `Opci\xF3 inv\xE0lida: s'esperava una de ${m(r.values, " o ")}`;
      case "too_big": {
        let i = r.inclusive ? "com a m\xE0xim" : "menys de", a = t(r.origin);
        return a ? `Massa gran: s'esperava que ${r.origin ?? "el valor"} contingu\xE9s ${i} ${r.maximum.toString()} ${a.unit ?? "elements"}` : `Massa gran: s'esperava que ${r.origin ?? "el valor"} fos ${i} ${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? "com a m\xEDnim" : "m\xE9s de", a = t(r.origin);
        return a ? `Massa petit: s'esperava que ${r.origin} contingu\xE9s ${i} ${r.minimum.toString()} ${a.unit}` : `Massa petit: s'esperava que ${r.origin} fos ${i} ${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Format inv\xE0lid: ha de comen\xE7ar amb "${i.prefix}"` : i.format === "ends_with" ? `Format inv\xE0lid: ha d'acabar amb "${i.suffix}"` : i.format === "includes" ? `Format inv\xE0lid: ha d'incloure "${i.includes}"` : i.format === "regex" ? `Format inv\xE0lid: ha de coincidir amb el patr\xF3 ${i.pattern}` : `Format inv\xE0lid per a ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `N\xFAmero inv\xE0lid: ha de ser m\xFAltiple de ${r.divisor}`;
      case "unrecognized_keys":
        return `Clau${r.keys.length > 1 ? "s" : ""} no reconeguda${r.keys.length > 1 ? "s" : ""}: ${m(r.keys, ", ")}`;
      case "invalid_key":
        return `Clau inv\xE0lida a ${r.origin}`;
      case "invalid_union":
        return "Entrada inv\xE0lida";
      // Could also be "Tipus d'unió invàlid" but "Entrada invàlida" is more general
      case "invalid_element":
        return `Element inv\xE0lid a ${r.origin}`;
      default:
        return "Entrada inv\xE0lida";
    }
  };
}, "error");
function ic() {
  return {
    localeError: Ov()
  };
}
s(ic, "default");

// versions/4.3.6/node_modules/zod/v4/locales/cs.js
var Pv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "znak\u016F", verb: "m\xEDt" },
    file: { unit: "bajt\u016F", verb: "m\xEDt" },
    array: { unit: "prvk\u016F", verb: "m\xEDt" },
    set: { unit: "prvk\u016F", verb: "m\xEDt" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "regul\xE1rn\xED v\xFDraz",
    email: "e-mailov\xE1 adresa",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "datum a \u010Das ve form\xE1tu ISO",
    date: "datum ve form\xE1tu ISO",
    time: "\u010Das ve form\xE1tu ISO",
    duration: "doba trv\xE1n\xED ISO",
    ipv4: "IPv4 adresa",
    ipv6: "IPv6 adresa",
    cidrv4: "rozsah IPv4",
    cidrv6: "rozsah IPv6",
    base64: "\u0159et\u011Bzec zak\xF3dovan\xFD ve form\xE1tu base64",
    base64url: "\u0159et\u011Bzec zak\xF3dovan\xFD ve form\xE1tu base64url",
    json_string: "\u0159et\u011Bzec ve form\xE1tu JSON",
    e164: "\u010D\xEDslo E.164",
    jwt: "JWT",
    template_literal: "vstup"
  }, o = {
    nan: "NaN",
    number: "\u010D\xEDslo",
    string: "\u0159et\u011Bzec",
    function: "funkce",
    array: "pole"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), c = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Neplatn\xFD vstup: o\u010Dek\xE1v\xE1no instanceof ${r.expected}, obdr\u017Eeno ${c}` : `Neplatn\xFD vstup: o\u010Dek\xE1v\xE1no ${i}, obdr\u017Eeno ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Neplatn\xFD vstup: o\u010Dek\xE1v\xE1no ${y(r.values[0])}` : `Neplatn\xE1 mo\u017Enost: o\u010Dek\xE1v\xE1na jedna z hodnot ${m(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Hodnota je p\u0159\xEDli\u0161 velk\xE1: ${r.origin ?? "hodnota"} mus\xED m\xEDt ${i}${r.maximum.toString()} ${a.unit ?? "prvk\u016F"}` : `Hodnota je p\u0159\xEDli\u0161 velk\xE1: ${r.origin ?? "hodnota"} mus\xED b\xFDt ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Hodnota je p\u0159\xEDli\u0161 mal\xE1: ${r.origin ?? "hodnota"} mus\xED m\xEDt ${i}${r.minimum.toString()} ${a.unit ?? "prvk\u016F"}` : `Hodnota je p\u0159\xEDli\u0161 mal\xE1: ${r.origin ?? "hodnota"} mus\xED b\xFDt ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Neplatn\xFD \u0159et\u011Bzec: mus\xED za\u010D\xEDnat na "${i.prefix}"` : i.format === "ends_with" ? `Neplatn\xFD \u0159et\u011Bzec: mus\xED kon\u010Dit na "${i.suffix}"` : i.format === "includes" ? `Neplatn\xFD \u0159et\u011Bzec: mus\xED obsahovat "${i.includes}"` : i.format === "regex" ? `Neplatn\xFD \u0159et\u011Bzec: mus\xED odpov\xEDdat vzoru ${i.pattern}` : `Neplatn\xFD form\xE1t ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Neplatn\xE9 \u010D\xEDslo: mus\xED b\xFDt n\xE1sobkem ${r.divisor}`;
      case "unrecognized_keys":
        return `Nezn\xE1m\xE9 kl\xED\u010De: ${m(r.keys, ", ")}`;
      case "invalid_key":
        return `Neplatn\xFD kl\xED\u010D v ${r.origin}`;
      case "invalid_union":
        return "Neplatn\xFD vstup";
      case "invalid_element":
        return `Neplatn\xE1 hodnota v ${r.origin}`;
      default:
        return "Neplatn\xFD vstup";
    }
  };
}, "error");
function ac() {
  return {
    localeError: Pv()
  };
}
s(ac, "default");

// versions/4.3.6/node_modules/zod/v4/locales/da.js
var Tv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "tegn", verb: "havde" },
    file: { unit: "bytes", verb: "havde" },
    array: { unit: "elementer", verb: "indeholdt" },
    set: { unit: "elementer", verb: "indeholdt" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "input",
    email: "e-mailadresse",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO dato- og klokkesl\xE6t",
    date: "ISO-dato",
    time: "ISO-klokkesl\xE6t",
    duration: "ISO-varighed",
    ipv4: "IPv4-omr\xE5de",
    ipv6: "IPv6-omr\xE5de",
    cidrv4: "IPv4-spektrum",
    cidrv6: "IPv6-spektrum",
    base64: "base64-kodet streng",
    base64url: "base64url-kodet streng",
    json_string: "JSON-streng",
    e164: "E.164-nummer",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN",
    string: "streng",
    number: "tal",
    boolean: "boolean",
    array: "liste",
    object: "objekt",
    set: "s\xE6t",
    file: "fil"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), c = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Ugyldigt input: forventede instanceof ${r.expected}, fik ${c}` : `Ugyldigt input: forventede ${i}, fik ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Ugyldig v\xE6rdi: forventede ${y(r.values[0])}` : `Ugyldigt valg: forventede en af f\xF8lgende ${m(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin), c = o[r.origin] ?? r.origin;
        return a ? `For stor: forventede ${c ?? "value"} ${a.verb} ${i} ${r.maximum.toString()} ${a.unit ?? "elementer"}` : `For stor: forventede ${c ?? "value"} havde ${i} ${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin), c = o[r.origin] ?? r.origin;
        return a ? `For lille: forventede ${c} ${a.verb} ${i} ${r.minimum.toString()} ${a.unit}` : `For lille: forventede ${c} havde ${i} ${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Ugyldig streng: skal starte med "${i.prefix}"` : i.format === "ends_with" ? `Ugyldig streng: skal ende med "${i.suffix}"` : i.format === "includes" ? `Ugyldig streng: skal indeholde "${i.includes}"` : i.format === "regex" ? `Ugyldig streng: skal matche m\xF8nsteret ${i.pattern}` : `Ugyldig ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Ugyldigt tal: skal v\xE6re deleligt med ${r.divisor}`;
      case "unrecognized_keys":
        return `${r.keys.length > 1 ? "Ukendte n\xF8gler" : "Ukendt n\xF8gle"}: ${m(r.keys, ", ")}`;
      case "invalid_key":
        return `Ugyldig n\xF8gle i ${r.origin}`;
      case "invalid_union":
        return "Ugyldigt input: matcher ingen af de tilladte typer";
      case "invalid_element":
        return `Ugyldig v\xE6rdi i ${r.origin}`;
      default:
        return "Ugyldigt input";
    }
  };
}, "error");
function sc() {
  return {
    localeError: Tv()
  };
}
s(sc, "default");

// versions/4.3.6/node_modules/zod/v4/locales/de.js
var Ev = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "Zeichen", verb: "zu haben" },
    file: { unit: "Bytes", verb: "zu haben" },
    array: { unit: "Elemente", verb: "zu haben" },
    set: { unit: "Elemente", verb: "zu haben" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "Eingabe",
    email: "E-Mail-Adresse",
    url: "URL",
    emoji: "Emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO-Datum und -Uhrzeit",
    date: "ISO-Datum",
    time: "ISO-Uhrzeit",
    duration: "ISO-Dauer",
    ipv4: "IPv4-Adresse",
    ipv6: "IPv6-Adresse",
    cidrv4: "IPv4-Bereich",
    cidrv6: "IPv6-Bereich",
    base64: "Base64-codierter String",
    base64url: "Base64-URL-codierter String",
    json_string: "JSON-String",
    e164: "E.164-Nummer",
    jwt: "JWT",
    template_literal: "Eingabe"
  }, o = {
    nan: "NaN",
    number: "Zahl",
    array: "Array"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), c = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Ung\xFCltige Eingabe: erwartet instanceof ${r.expected}, erhalten ${c}` : `Ung\xFCltige Eingabe: erwartet ${i}, erhalten ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Ung\xFCltige Eingabe: erwartet ${y(r.values[0])}` : `Ung\xFCltige Option: erwartet eine von ${m(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Zu gro\xDF: erwartet, dass ${r.origin ?? "Wert"} ${i}${r.maximum.toString()} ${a.unit ?? "Elemente"} hat` : `Zu gro\xDF: erwartet, dass ${r.origin ?? "Wert"} ${i}${r.maximum.toString()} ist`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Zu klein: erwartet, dass ${r.origin} ${i}${r.minimum.toString()} ${a.unit} hat` : `Zu klein: erwartet, dass ${r.origin} ${i}${r.minimum.toString()} ist`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Ung\xFCltiger String: muss mit "${i.prefix}" beginnen` : i.format === "ends_with" ? `Ung\xFCltiger String: muss mit "${i.suffix}" enden` : i.format === "includes" ? `Ung\xFCltiger String: muss "${i.includes}" enthalten` : i.format === "regex" ? `Ung\xFCltiger String: muss dem Muster ${i.pattern} entsprechen` : `Ung\xFCltig: ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Ung\xFCltige Zahl: muss ein Vielfaches von ${r.divisor} sein`;
      case "unrecognized_keys":
        return `${r.keys.length > 1 ? "Unbekannte Schl\xFCssel" : "Unbekannter Schl\xFCssel"}: ${m(r.keys, ", ")}`;
      case "invalid_key":
        return `Ung\xFCltiger Schl\xFCssel in ${r.origin}`;
      case "invalid_union":
        return "Ung\xFCltige Eingabe";
      case "invalid_element":
        return `Ung\xFCltiger Wert in ${r.origin}`;
      default:
        return "Ung\xFCltige Eingabe";
    }
  };
}, "error");
function cc() {
  return {
    localeError: Ev()
  };
}
s(cc, "default");

// versions/4.3.6/node_modules/zod/v4/locales/en.js
var Uv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "characters", verb: "to have" },
    file: { unit: "bytes", verb: "to have" },
    array: { unit: "items", verb: "to have" },
    set: { unit: "items", verb: "to have" },
    map: { unit: "entries", verb: "to have" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "input",
    email: "email address",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datetime",
    date: "ISO date",
    time: "ISO time",
    duration: "ISO duration",
    ipv4: "IPv4 address",
    ipv6: "IPv6 address",
    mac: "MAC address",
    cidrv4: "IPv4 range",
    cidrv6: "IPv6 range",
    base64: "base64-encoded string",
    base64url: "base64url-encoded string",
    json_string: "JSON string",
    e164: "E.164 number",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    // Compatibility: "nan" -> "NaN" for display
    nan: "NaN"
    // All other type names omitted - they fall back to raw values via ?? operator
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), c = o[a] ?? a;
        return `Invalid input: expected ${i}, received ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Invalid input: expected ${y(r.values[0])}` : `Invalid option: expected one of ${m(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Too big: expected ${r.origin ?? "value"} to have ${i}${r.maximum.toString()} ${a.unit ?? "elements"}` : `Too big: expected ${r.origin ?? "value"} to be ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Too small: expected ${r.origin} to have ${i}${r.minimum.toString()} ${a.unit}` : `Too small: expected ${r.origin} to be ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Invalid string: must start with "${i.prefix}"` : i.format === "ends_with" ? `Invalid string: must end with "${i.suffix}"` : i.format === "includes" ? `Invalid string: must include "${i.includes}"` : i.format === "regex" ? `Invalid string: must match pattern ${i.pattern}` : `Invalid ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Invalid number: must be a multiple of ${r.divisor}`;
      case "unrecognized_keys":
        return `Unrecognized key${r.keys.length > 1 ? "s" : ""}: ${m(r.keys, ", ")}`;
      case "invalid_key":
        return `Invalid key in ${r.origin}`;
      case "invalid_union":
        return "Invalid input";
      case "invalid_element":
        return `Invalid value in ${r.origin}`;
      default:
        return "Invalid input";
    }
  };
}, "error");
function Tr() {
  return {
    localeError: Uv()
  };
}
s(Tr, "default");

// versions/4.3.6/node_modules/zod/v4/locales/eo.js
var Dv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "karaktrojn", verb: "havi" },
    file: { unit: "bajtojn", verb: "havi" },
    array: { unit: "elementojn", verb: "havi" },
    set: { unit: "elementojn", verb: "havi" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "enigo",
    email: "retadreso",
    url: "URL",
    emoji: "emo\u011Dio",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO-datotempo",
    date: "ISO-dato",
    time: "ISO-tempo",
    duration: "ISO-da\u016Dro",
    ipv4: "IPv4-adreso",
    ipv6: "IPv6-adreso",
    cidrv4: "IPv4-rango",
    cidrv6: "IPv6-rango",
    base64: "64-ume kodita karaktraro",
    base64url: "URL-64-ume kodita karaktraro",
    json_string: "JSON-karaktraro",
    e164: "E.164-nombro",
    jwt: "JWT",
    template_literal: "enigo"
  }, o = {
    nan: "NaN",
    number: "nombro",
    array: "tabelo",
    null: "senvalora"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), c = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Nevalida enigo: atendi\u011Dis instanceof ${r.expected}, ricevi\u011Dis ${c}` : `Nevalida enigo: atendi\u011Dis ${i}, ricevi\u011Dis ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Nevalida enigo: atendi\u011Dis ${y(r.values[0])}` : `Nevalida opcio: atendi\u011Dis unu el ${m(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Tro granda: atendi\u011Dis ke ${r.origin ?? "valoro"} havu ${i}${r.maximum.toString()} ${a.unit ?? "elementojn"}` : `Tro granda: atendi\u011Dis ke ${r.origin ?? "valoro"} havu ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Tro malgranda: atendi\u011Dis ke ${r.origin} havu ${i}${r.minimum.toString()} ${a.unit}` : `Tro malgranda: atendi\u011Dis ke ${r.origin} estu ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Nevalida karaktraro: devas komenci\u011Di per "${i.prefix}"` : i.format === "ends_with" ? `Nevalida karaktraro: devas fini\u011Di per "${i.suffix}"` : i.format === "includes" ? `Nevalida karaktraro: devas inkluzivi "${i.includes}"` : i.format === "regex" ? `Nevalida karaktraro: devas kongrui kun la modelo ${i.pattern}` : `Nevalida ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Nevalida nombro: devas esti oblo de ${r.divisor}`;
      case "unrecognized_keys":
        return `Nekonata${r.keys.length > 1 ? "j" : ""} \u015Dlosilo${r.keys.length > 1 ? "j" : ""}: ${m(r.keys, ", ")}`;
      case "invalid_key":
        return `Nevalida \u015Dlosilo en ${r.origin}`;
      case "invalid_union":
        return "Nevalida enigo";
      case "invalid_element":
        return `Nevalida valoro en ${r.origin}`;
      default:
        return "Nevalida enigo";
    }
  };
}, "error");
function uc() {
  return {
    localeError: Dv()
  };
}
s(uc, "default");

// versions/4.3.6/node_modules/zod/v4/locales/es.js
var Nv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "caracteres", verb: "tener" },
    file: { unit: "bytes", verb: "tener" },
    array: { unit: "elementos", verb: "tener" },
    set: { unit: "elementos", verb: "tener" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "entrada",
    email: "direcci\xF3n de correo electr\xF3nico",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "fecha y hora ISO",
    date: "fecha ISO",
    time: "hora ISO",
    duration: "duraci\xF3n ISO",
    ipv4: "direcci\xF3n IPv4",
    ipv6: "direcci\xF3n IPv6",
    cidrv4: "rango IPv4",
    cidrv6: "rango IPv6",
    base64: "cadena codificada en base64",
    base64url: "URL codificada en base64",
    json_string: "cadena JSON",
    e164: "n\xFAmero E.164",
    jwt: "JWT",
    template_literal: "entrada"
  }, o = {
    nan: "NaN",
    string: "texto",
    number: "n\xFAmero",
    boolean: "booleano",
    array: "arreglo",
    object: "objeto",
    set: "conjunto",
    file: "archivo",
    date: "fecha",
    bigint: "n\xFAmero grande",
    symbol: "s\xEDmbolo",
    undefined: "indefinido",
    null: "nulo",
    function: "funci\xF3n",
    map: "mapa",
    record: "registro",
    tuple: "tupla",
    enum: "enumeraci\xF3n",
    union: "uni\xF3n",
    literal: "literal",
    promise: "promesa",
    void: "vac\xEDo",
    never: "nunca",
    unknown: "desconocido",
    any: "cualquiera"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), c = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Entrada inv\xE1lida: se esperaba instanceof ${r.expected}, recibido ${c}` : `Entrada inv\xE1lida: se esperaba ${i}, recibido ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Entrada inv\xE1lida: se esperaba ${y(r.values[0])}` : `Opci\xF3n inv\xE1lida: se esperaba una de ${m(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin), c = o[r.origin] ?? r.origin;
        return a ? `Demasiado grande: se esperaba que ${c ?? "valor"} tuviera ${i}${r.maximum.toString()} ${a.unit ?? "elementos"}` : `Demasiado grande: se esperaba que ${c ?? "valor"} fuera ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin), c = o[r.origin] ?? r.origin;
        return a ? `Demasiado peque\xF1o: se esperaba que ${c} tuviera ${i}${r.minimum.toString()} ${a.unit}` : `Demasiado peque\xF1o: se esperaba que ${c} fuera ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Cadena inv\xE1lida: debe comenzar con "${i.prefix}"` : i.format === "ends_with" ? `Cadena inv\xE1lida: debe terminar en "${i.suffix}"` : i.format === "includes" ? `Cadena inv\xE1lida: debe incluir "${i.includes}"` : i.format === "regex" ? `Cadena inv\xE1lida: debe coincidir con el patr\xF3n ${i.pattern}` : `Inv\xE1lido ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `N\xFAmero inv\xE1lido: debe ser m\xFAltiplo de ${r.divisor}`;
      case "unrecognized_keys":
        return `Llave${r.keys.length > 1 ? "s" : ""} desconocida${r.keys.length > 1 ? "s" : ""}: ${m(r.keys, ", ")}`;
      case "invalid_key":
        return `Llave inv\xE1lida en ${o[r.origin] ?? r.origin}`;
      case "invalid_union":
        return "Entrada inv\xE1lida";
      case "invalid_element":
        return `Valor inv\xE1lido en ${o[r.origin] ?? r.origin}`;
      default:
        return "Entrada inv\xE1lida";
    }
  };
}, "error");
function lc() {
  return {
    localeError: Nv()
  };
}
s(lc, "default");

// versions/4.3.6/node_modules/zod/v4/locales/fa.js
var Zv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u06A9\u0627\u0631\u0627\u06A9\u062A\u0631", verb: "\u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F" },
    file: { unit: "\u0628\u0627\u06CC\u062A", verb: "\u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F" },
    array: { unit: "\u0622\u06CC\u062A\u0645", verb: "\u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F" },
    set: { unit: "\u0622\u06CC\u062A\u0645", verb: "\u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u0648\u0631\u0648\u062F\u06CC",
    email: "\u0622\u062F\u0631\u0633 \u0627\u06CC\u0645\u06CC\u0644",
    url: "URL",
    emoji: "\u0627\u06CC\u0645\u0648\u062C\u06CC",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u062A\u0627\u0631\u06CC\u062E \u0648 \u0632\u0645\u0627\u0646 \u0627\u06CC\u0632\u0648",
    date: "\u062A\u0627\u0631\u06CC\u062E \u0627\u06CC\u0632\u0648",
    time: "\u0632\u0645\u0627\u0646 \u0627\u06CC\u0632\u0648",
    duration: "\u0645\u062F\u062A \u0632\u0645\u0627\u0646 \u0627\u06CC\u0632\u0648",
    ipv4: "IPv4 \u0622\u062F\u0631\u0633",
    ipv6: "IPv6 \u0622\u062F\u0631\u0633",
    cidrv4: "IPv4 \u062F\u0627\u0645\u0646\u0647",
    cidrv6: "IPv6 \u062F\u0627\u0645\u0646\u0647",
    base64: "base64-encoded \u0631\u0634\u062A\u0647",
    base64url: "base64url-encoded \u0631\u0634\u062A\u0647",
    json_string: "JSON \u0631\u0634\u062A\u0647",
    e164: "E.164 \u0639\u062F\u062F",
    jwt: "JWT",
    template_literal: "\u0648\u0631\u0648\u062F\u06CC"
  }, o = {
    nan: "NaN",
    number: "\u0639\u062F\u062F",
    array: "\u0622\u0631\u0627\u06CC\u0647"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), c = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0645\u06CC\u200C\u0628\u0627\u06CC\u0633\u062A instanceof ${r.expected} \u0645\u06CC\u200C\u0628\u0648\u062F\u060C ${c} \u062F\u0631\u06CC\u0627\u0641\u062A \u0634\u062F` : `\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0645\u06CC\u200C\u0628\u0627\u06CC\u0633\u062A ${i} \u0645\u06CC\u200C\u0628\u0648\u062F\u060C ${c} \u062F\u0631\u06CC\u0627\u0641\u062A \u0634\u062F`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0645\u06CC\u200C\u0628\u0627\u06CC\u0633\u062A ${y(r.values[0])} \u0645\u06CC\u200C\u0628\u0648\u062F` : `\u06AF\u0632\u06CC\u0646\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0645\u06CC\u200C\u0628\u0627\u06CC\u0633\u062A \u06CC\u06A9\u06CC \u0627\u0632 ${m(r.values, "|")} \u0645\u06CC\u200C\u0628\u0648\u062F`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `\u062E\u06CC\u0644\u06CC \u0628\u0632\u0631\u06AF: ${r.origin ?? "\u0645\u0642\u062F\u0627\u0631"} \u0628\u0627\u06CC\u062F ${i}${r.maximum.toString()} ${a.unit ?? "\u0639\u0646\u0635\u0631"} \u0628\u0627\u0634\u062F` : `\u062E\u06CC\u0644\u06CC \u0628\u0632\u0631\u06AF: ${r.origin ?? "\u0645\u0642\u062F\u0627\u0631"} \u0628\u0627\u06CC\u062F ${i}${r.maximum.toString()} \u0628\u0627\u0634\u062F`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\u062E\u06CC\u0644\u06CC \u06A9\u0648\u0686\u06A9: ${r.origin} \u0628\u0627\u06CC\u062F ${i}${r.minimum.toString()} ${a.unit} \u0628\u0627\u0634\u062F` : `\u062E\u06CC\u0644\u06CC \u06A9\u0648\u0686\u06A9: ${r.origin} \u0628\u0627\u06CC\u062F ${i}${r.minimum.toString()} \u0628\u0627\u0634\u062F`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u0631\u0634\u062A\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0628\u0627 "${i.prefix}" \u0634\u0631\u0648\u0639 \u0634\u0648\u062F` : i.format === "ends_with" ? `\u0631\u0634\u062A\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0628\u0627 "${i.suffix}" \u062A\u0645\u0627\u0645 \u0634\u0648\u062F` : i.format === "includes" ? `\u0631\u0634\u062A\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0634\u0627\u0645\u0644 "${i.includes}" \u0628\u0627\u0634\u062F` : i.format === "regex" ? `\u0631\u0634\u062A\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0628\u0627 \u0627\u0644\u06AF\u0648\u06CC ${i.pattern} \u0645\u0637\u0627\u0628\u0642\u062A \u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F` : `${n[i.format] ?? r.format} \u0646\u0627\u0645\u0639\u062A\u0628\u0631`;
      }
      case "not_multiple_of":
        return `\u0639\u062F\u062F \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0645\u0636\u0631\u0628 ${r.divisor} \u0628\u0627\u0634\u062F`;
      case "unrecognized_keys":
        return `\u06A9\u0644\u06CC\u062F${r.keys.length > 1 ? "\u0647\u0627\u06CC" : ""} \u0646\u0627\u0634\u0646\u0627\u0633: ${m(r.keys, ", ")}`;
      case "invalid_key":
        return `\u06A9\u0644\u06CC\u062F \u0646\u0627\u0634\u0646\u0627\u0633 \u062F\u0631 ${r.origin}`;
      case "invalid_union":
        return "\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631";
      case "invalid_element":
        return `\u0645\u0642\u062F\u0627\u0631 \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u062F\u0631 ${r.origin}`;
      default:
        return "\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631";
    }
  };
}, "error");
function dc() {
  return {
    localeError: Zv()
  };
}
s(dc, "default");

// versions/4.3.6/node_modules/zod/v4/locales/fi.js
var Av = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "merkki\xE4", subject: "merkkijonon" },
    file: { unit: "tavua", subject: "tiedoston" },
    array: { unit: "alkiota", subject: "listan" },
    set: { unit: "alkiota", subject: "joukon" },
    number: { unit: "", subject: "luvun" },
    bigint: { unit: "", subject: "suuren kokonaisluvun" },
    int: { unit: "", subject: "kokonaisluvun" },
    date: { unit: "", subject: "p\xE4iv\xE4m\xE4\xE4r\xE4n" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "s\xE4\xE4nn\xF6llinen lauseke",
    email: "s\xE4hk\xF6postiosoite",
    url: "URL-osoite",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO-aikaleima",
    date: "ISO-p\xE4iv\xE4m\xE4\xE4r\xE4",
    time: "ISO-aika",
    duration: "ISO-kesto",
    ipv4: "IPv4-osoite",
    ipv6: "IPv6-osoite",
    cidrv4: "IPv4-alue",
    cidrv6: "IPv6-alue",
    base64: "base64-koodattu merkkijono",
    base64url: "base64url-koodattu merkkijono",
    json_string: "JSON-merkkijono",
    e164: "E.164-luku",
    jwt: "JWT",
    template_literal: "templaattimerkkijono"
  }, o = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), c = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Virheellinen tyyppi: odotettiin instanceof ${r.expected}, oli ${c}` : `Virheellinen tyyppi: odotettiin ${i}, oli ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Virheellinen sy\xF6te: t\xE4ytyy olla ${y(r.values[0])}` : `Virheellinen valinta: t\xE4ytyy olla yksi seuraavista: ${m(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Liian suuri: ${a.subject} t\xE4ytyy olla ${i}${r.maximum.toString()} ${a.unit}`.trim() : `Liian suuri: arvon t\xE4ytyy olla ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Liian pieni: ${a.subject} t\xE4ytyy olla ${i}${r.minimum.toString()} ${a.unit}`.trim() : `Liian pieni: arvon t\xE4ytyy olla ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Virheellinen sy\xF6te: t\xE4ytyy alkaa "${i.prefix}"` : i.format === "ends_with" ? `Virheellinen sy\xF6te: t\xE4ytyy loppua "${i.suffix}"` : i.format === "includes" ? `Virheellinen sy\xF6te: t\xE4ytyy sis\xE4lt\xE4\xE4 "${i.includes}"` : i.format === "regex" ? `Virheellinen sy\xF6te: t\xE4ytyy vastata s\xE4\xE4nn\xF6llist\xE4 lauseketta ${i.pattern}` : `Virheellinen ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Virheellinen luku: t\xE4ytyy olla luvun ${r.divisor} monikerta`;
      case "unrecognized_keys":
        return `${r.keys.length > 1 ? "Tuntemattomat avaimet" : "Tuntematon avain"}: ${m(r.keys, ", ")}`;
      case "invalid_key":
        return "Virheellinen avain tietueessa";
      case "invalid_union":
        return "Virheellinen unioni";
      case "invalid_element":
        return "Virheellinen arvo joukossa";
      default:
        return "Virheellinen sy\xF6te";
    }
  };
}, "error");
function fc() {
  return {
    localeError: Av()
  };
}
s(fc, "default");

// versions/4.3.6/node_modules/zod/v4/locales/fr.js
var Cv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "caract\xE8res", verb: "avoir" },
    file: { unit: "octets", verb: "avoir" },
    array: { unit: "\xE9l\xE9ments", verb: "avoir" },
    set: { unit: "\xE9l\xE9ments", verb: "avoir" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "entr\xE9e",
    email: "adresse e-mail",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "date et heure ISO",
    date: "date ISO",
    time: "heure ISO",
    duration: "dur\xE9e ISO",
    ipv4: "adresse IPv4",
    ipv6: "adresse IPv6",
    cidrv4: "plage IPv4",
    cidrv6: "plage IPv6",
    base64: "cha\xEEne encod\xE9e en base64",
    base64url: "cha\xEEne encod\xE9e en base64url",
    json_string: "cha\xEEne JSON",
    e164: "num\xE9ro E.164",
    jwt: "JWT",
    template_literal: "entr\xE9e"
  }, o = {
    nan: "NaN",
    number: "nombre",
    array: "tableau"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), c = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Entr\xE9e invalide : instanceof ${r.expected} attendu, ${c} re\xE7u` : `Entr\xE9e invalide : ${i} attendu, ${c} re\xE7u`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Entr\xE9e invalide : ${y(r.values[0])} attendu` : `Option invalide : une valeur parmi ${m(r.values, "|")} attendue`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Trop grand : ${r.origin ?? "valeur"} doit ${a.verb} ${i}${r.maximum.toString()} ${a.unit ?? "\xE9l\xE9ment(s)"}` : `Trop grand : ${r.origin ?? "valeur"} doit \xEAtre ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Trop petit : ${r.origin} doit ${a.verb} ${i}${r.minimum.toString()} ${a.unit}` : `Trop petit : ${r.origin} doit \xEAtre ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Cha\xEEne invalide : doit commencer par "${i.prefix}"` : i.format === "ends_with" ? `Cha\xEEne invalide : doit se terminer par "${i.suffix}"` : i.format === "includes" ? `Cha\xEEne invalide : doit inclure "${i.includes}"` : i.format === "regex" ? `Cha\xEEne invalide : doit correspondre au mod\xE8le ${i.pattern}` : `${n[i.format] ?? r.format} invalide`;
      }
      case "not_multiple_of":
        return `Nombre invalide : doit \xEAtre un multiple de ${r.divisor}`;
      case "unrecognized_keys":
        return `Cl\xE9${r.keys.length > 1 ? "s" : ""} non reconnue${r.keys.length > 1 ? "s" : ""} : ${m(r.keys, ", ")}`;
      case "invalid_key":
        return `Cl\xE9 invalide dans ${r.origin}`;
      case "invalid_union":
        return "Entr\xE9e invalide";
      case "invalid_element":
        return `Valeur invalide dans ${r.origin}`;
      default:
        return "Entr\xE9e invalide";
    }
  };
}, "error");
function pc() {
  return {
    localeError: Cv()
  };
}
s(pc, "default");

// versions/4.3.6/node_modules/zod/v4/locales/fr-CA.js
var Rv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "caract\xE8res", verb: "avoir" },
    file: { unit: "octets", verb: "avoir" },
    array: { unit: "\xE9l\xE9ments", verb: "avoir" },
    set: { unit: "\xE9l\xE9ments", verb: "avoir" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "entr\xE9e",
    email: "adresse courriel",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "date-heure ISO",
    date: "date ISO",
    time: "heure ISO",
    duration: "dur\xE9e ISO",
    ipv4: "adresse IPv4",
    ipv6: "adresse IPv6",
    cidrv4: "plage IPv4",
    cidrv6: "plage IPv6",
    base64: "cha\xEEne encod\xE9e en base64",
    base64url: "cha\xEEne encod\xE9e en base64url",
    json_string: "cha\xEEne JSON",
    e164: "num\xE9ro E.164",
    jwt: "JWT",
    template_literal: "entr\xE9e"
  }, o = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), c = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Entr\xE9e invalide : attendu instanceof ${r.expected}, re\xE7u ${c}` : `Entr\xE9e invalide : attendu ${i}, re\xE7u ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Entr\xE9e invalide : attendu ${y(r.values[0])}` : `Option invalide : attendu l'une des valeurs suivantes ${m(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "\u2264" : "<", a = t(r.origin);
        return a ? `Trop grand : attendu que ${r.origin ?? "la valeur"} ait ${i}${r.maximum.toString()} ${a.unit}` : `Trop grand : attendu que ${r.origin ?? "la valeur"} soit ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? "\u2265" : ">", a = t(r.origin);
        return a ? `Trop petit : attendu que ${r.origin} ait ${i}${r.minimum.toString()} ${a.unit}` : `Trop petit : attendu que ${r.origin} soit ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Cha\xEEne invalide : doit commencer par "${i.prefix}"` : i.format === "ends_with" ? `Cha\xEEne invalide : doit se terminer par "${i.suffix}"` : i.format === "includes" ? `Cha\xEEne invalide : doit inclure "${i.includes}"` : i.format === "regex" ? `Cha\xEEne invalide : doit correspondre au motif ${i.pattern}` : `${n[i.format] ?? r.format} invalide`;
      }
      case "not_multiple_of":
        return `Nombre invalide : doit \xEAtre un multiple de ${r.divisor}`;
      case "unrecognized_keys":
        return `Cl\xE9${r.keys.length > 1 ? "s" : ""} non reconnue${r.keys.length > 1 ? "s" : ""} : ${m(r.keys, ", ")}`;
      case "invalid_key":
        return `Cl\xE9 invalide dans ${r.origin}`;
      case "invalid_union":
        return "Entr\xE9e invalide";
      case "invalid_element":
        return `Valeur invalide dans ${r.origin}`;
      default:
        return "Entr\xE9e invalide";
    }
  };
}, "error");
function mc() {
  return {
    localeError: Rv()
  };
}
s(mc, "default");

// versions/4.3.6/node_modules/zod/v4/locales/he.js
var Fv = /* @__PURE__ */ s(() => {
  let e = {
    string: { label: "\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA", gender: "f" },
    number: { label: "\u05DE\u05E1\u05E4\u05E8", gender: "m" },
    boolean: { label: "\u05E2\u05E8\u05DA \u05D1\u05D5\u05DC\u05D9\u05D0\u05E0\u05D9", gender: "m" },
    bigint: { label: "BigInt", gender: "m" },
    date: { label: "\u05EA\u05D0\u05E8\u05D9\u05DA", gender: "m" },
    array: { label: "\u05DE\u05E2\u05E8\u05DA", gender: "m" },
    object: { label: "\u05D0\u05D5\u05D1\u05D9\u05D9\u05E7\u05D8", gender: "m" },
    null: { label: "\u05E2\u05E8\u05DA \u05E8\u05D9\u05E7 (null)", gender: "m" },
    undefined: { label: "\u05E2\u05E8\u05DA \u05DC\u05D0 \u05DE\u05D5\u05D2\u05D3\u05E8 (undefined)", gender: "m" },
    symbol: { label: "\u05E1\u05D9\u05DE\u05D1\u05D5\u05DC (Symbol)", gender: "m" },
    function: { label: "\u05E4\u05D5\u05E0\u05E7\u05E6\u05D9\u05D4", gender: "f" },
    map: { label: "\u05DE\u05E4\u05D4 (Map)", gender: "f" },
    set: { label: "\u05E7\u05D1\u05D5\u05E6\u05D4 (Set)", gender: "f" },
    file: { label: "\u05E7\u05D5\u05D1\u05E5", gender: "m" },
    promise: { label: "Promise", gender: "m" },
    NaN: { label: "NaN", gender: "m" },
    unknown: { label: "\u05E2\u05E8\u05DA \u05DC\u05D0 \u05D9\u05D3\u05D5\u05E2", gender: "m" },
    value: { label: "\u05E2\u05E8\u05DA", gender: "m" }
  }, t = {
    string: { unit: "\u05EA\u05D5\u05D5\u05D9\u05DD", shortLabel: "\u05E7\u05E6\u05E8", longLabel: "\u05D0\u05E8\u05D5\u05DA" },
    file: { unit: "\u05D1\u05D9\u05D9\u05D8\u05D9\u05DD", shortLabel: "\u05E7\u05D8\u05DF", longLabel: "\u05D2\u05D3\u05D5\u05DC" },
    array: { unit: "\u05E4\u05E8\u05D9\u05D8\u05D9\u05DD", shortLabel: "\u05E7\u05D8\u05DF", longLabel: "\u05D2\u05D3\u05D5\u05DC" },
    set: { unit: "\u05E4\u05E8\u05D9\u05D8\u05D9\u05DD", shortLabel: "\u05E7\u05D8\u05DF", longLabel: "\u05D2\u05D3\u05D5\u05DC" },
    number: { unit: "", shortLabel: "\u05E7\u05D8\u05DF", longLabel: "\u05D2\u05D3\u05D5\u05DC" }
    // no unit
  }, n = /* @__PURE__ */ s((l) => l ? e[l] : void 0, "typeEntry"), o = /* @__PURE__ */ s((l) => {
    let d = n(l);
    return d ? d.label : l ?? e.unknown.label;
  }, "typeLabel"), r = /* @__PURE__ */ s((l) => `\u05D4${o(l)}`, "withDefinite"), i = /* @__PURE__ */ s((l) => (n(l)?.gender ?? "m") === "f" ? "\u05E6\u05E8\u05D9\u05DB\u05D4 \u05DC\u05D4\u05D9\u05D5\u05EA" : "\u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA", "verbFor"), a = /* @__PURE__ */ s((l) => l ? t[l] ?? null : null, "getSizing"), c = {
    regex: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    email: { label: "\u05DB\u05EA\u05D5\u05D1\u05EA \u05D0\u05D9\u05DE\u05D9\u05D9\u05DC", gender: "f" },
    url: { label: "\u05DB\u05EA\u05D5\u05D1\u05EA \u05E8\u05E9\u05EA", gender: "f" },
    emoji: { label: "\u05D0\u05D9\u05DE\u05D5\u05D2'\u05D9", gender: "m" },
    uuid: { label: "UUID", gender: "m" },
    nanoid: { label: "nanoid", gender: "m" },
    guid: { label: "GUID", gender: "m" },
    cuid: { label: "cuid", gender: "m" },
    cuid2: { label: "cuid2", gender: "m" },
    ulid: { label: "ULID", gender: "m" },
    xid: { label: "XID", gender: "m" },
    ksuid: { label: "KSUID", gender: "m" },
    datetime: { label: "\u05EA\u05D0\u05E8\u05D9\u05DA \u05D5\u05D6\u05DE\u05DF ISO", gender: "m" },
    date: { label: "\u05EA\u05D0\u05E8\u05D9\u05DA ISO", gender: "m" },
    time: { label: "\u05D6\u05DE\u05DF ISO", gender: "m" },
    duration: { label: "\u05DE\u05E9\u05DA \u05D6\u05DE\u05DF ISO", gender: "m" },
    ipv4: { label: "\u05DB\u05EA\u05D5\u05D1\u05EA IPv4", gender: "f" },
    ipv6: { label: "\u05DB\u05EA\u05D5\u05D1\u05EA IPv6", gender: "f" },
    cidrv4: { label: "\u05D8\u05D5\u05D5\u05D7 IPv4", gender: "m" },
    cidrv6: { label: "\u05D8\u05D5\u05D5\u05D7 IPv6", gender: "m" },
    base64: { label: "\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D1\u05D1\u05E1\u05D9\u05E1 64", gender: "f" },
    base64url: { label: "\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D1\u05D1\u05E1\u05D9\u05E1 64 \u05DC\u05DB\u05EA\u05D5\u05D1\u05D5\u05EA \u05E8\u05E9\u05EA", gender: "f" },
    json_string: { label: "\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA JSON", gender: "f" },
    e164: { label: "\u05DE\u05E1\u05E4\u05E8 E.164", gender: "m" },
    jwt: { label: "JWT", gender: "m" },
    ends_with: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    includes: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    lowercase: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    starts_with: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    uppercase: { label: "\u05E7\u05DC\u05D8", gender: "m" }
  }, u = {
    nan: "NaN"
  };
  return (l) => {
    switch (l.code) {
      case "invalid_type": {
        let d = l.expected, p = u[d ?? ""] ?? o(d), h = b(l.input), v = u[h] ?? e[h]?.label ?? h;
        return /^[A-Z]/.test(l.expected) ? `\u05E7\u05DC\u05D8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA instanceof ${l.expected}, \u05D4\u05EA\u05E7\u05D1\u05DC ${v}` : `\u05E7\u05DC\u05D8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA ${p}, \u05D4\u05EA\u05E7\u05D1\u05DC ${v}`;
      }
      case "invalid_value": {
        if (l.values.length === 1)
          return `\u05E2\u05E8\u05DA \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05D4\u05E2\u05E8\u05DA \u05D7\u05D9\u05D9\u05D1 \u05DC\u05D4\u05D9\u05D5\u05EA ${y(l.values[0])}`;
        let d = l.values.map((v) => y(v));
        if (l.values.length === 2)
          return `\u05E2\u05E8\u05DA \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05D4\u05D0\u05E4\u05E9\u05E8\u05D5\u05D9\u05D5\u05EA \u05D4\u05DE\u05EA\u05D0\u05D9\u05DE\u05D5\u05EA \u05D4\u05DF ${d[0]} \u05D0\u05D5 ${d[1]}`;
        let p = d[d.length - 1];
        return `\u05E2\u05E8\u05DA \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05D4\u05D0\u05E4\u05E9\u05E8\u05D5\u05D9\u05D5\u05EA \u05D4\u05DE\u05EA\u05D0\u05D9\u05DE\u05D5\u05EA \u05D4\u05DF ${d.slice(0, -1).join(", ")} \u05D0\u05D5 ${p}`;
      }
      case "too_big": {
        let d = a(l.origin), p = r(l.origin ?? "value");
        if (l.origin === "string")
          return `${d?.longLabel ?? "\u05D0\u05E8\u05D5\u05DA"} \u05DE\u05D3\u05D9: ${p} \u05E6\u05E8\u05D9\u05DB\u05D4 \u05DC\u05D4\u05DB\u05D9\u05DC ${l.maximum.toString()} ${d?.unit ?? ""} ${l.inclusive ? "\u05D0\u05D5 \u05E4\u05D7\u05D5\u05EA" : "\u05DC\u05DB\u05DC \u05D4\u05D9\u05D5\u05EA\u05E8"}`.trim();
        if (l.origin === "number") {
          let O = l.inclusive ? `\u05E7\u05D8\u05DF \u05D0\u05D5 \u05E9\u05D5\u05D5\u05D4 \u05DC-${l.maximum}` : `\u05E7\u05D8\u05DF \u05DE-${l.maximum}`;
          return `\u05D2\u05D3\u05D5\u05DC \u05DE\u05D3\u05D9: ${p} \u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA ${O}`;
        }
        if (l.origin === "array" || l.origin === "set") {
          let O = l.origin === "set" ? "\u05E6\u05E8\u05D9\u05DB\u05D4" : "\u05E6\u05E8\u05D9\u05DA", I = l.inclusive ? `${l.maximum} ${d?.unit ?? ""} \u05D0\u05D5 \u05E4\u05D7\u05D5\u05EA` : `\u05E4\u05D7\u05D5\u05EA \u05DE-${l.maximum} ${d?.unit ?? ""}`;
          return `\u05D2\u05D3\u05D5\u05DC \u05DE\u05D3\u05D9: ${p} ${O} \u05DC\u05D4\u05DB\u05D9\u05DC ${I}`.trim();
        }
        let h = l.inclusive ? "<=" : "<", v = i(l.origin ?? "value");
        return d?.unit ? `${d.longLabel} \u05DE\u05D3\u05D9: ${p} ${v} ${h}${l.maximum.toString()} ${d.unit}` : `${d?.longLabel ?? "\u05D2\u05D3\u05D5\u05DC"} \u05DE\u05D3\u05D9: ${p} ${v} ${h}${l.maximum.toString()}`;
      }
      case "too_small": {
        let d = a(l.origin), p = r(l.origin ?? "value");
        if (l.origin === "string")
          return `${d?.shortLabel ?? "\u05E7\u05E6\u05E8"} \u05DE\u05D3\u05D9: ${p} \u05E6\u05E8\u05D9\u05DB\u05D4 \u05DC\u05D4\u05DB\u05D9\u05DC ${l.minimum.toString()} ${d?.unit ?? ""} ${l.inclusive ? "\u05D0\u05D5 \u05D9\u05D5\u05EA\u05E8" : "\u05DC\u05E4\u05D7\u05D5\u05EA"}`.trim();
        if (l.origin === "number") {
          let O = l.inclusive ? `\u05D2\u05D3\u05D5\u05DC \u05D0\u05D5 \u05E9\u05D5\u05D5\u05D4 \u05DC-${l.minimum}` : `\u05D2\u05D3\u05D5\u05DC \u05DE-${l.minimum}`;
          return `\u05E7\u05D8\u05DF \u05DE\u05D3\u05D9: ${p} \u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA ${O}`;
        }
        if (l.origin === "array" || l.origin === "set") {
          let O = l.origin === "set" ? "\u05E6\u05E8\u05D9\u05DB\u05D4" : "\u05E6\u05E8\u05D9\u05DA";
          if (l.minimum === 1 && l.inclusive) {
            let W = (l.origin === "set", "\u05DC\u05E4\u05D7\u05D5\u05EA \u05E4\u05E8\u05D9\u05D8 \u05D0\u05D7\u05D3");
            return `\u05E7\u05D8\u05DF \u05DE\u05D3\u05D9: ${p} ${O} \u05DC\u05D4\u05DB\u05D9\u05DC ${W}`;
          }
          let I = l.inclusive ? `${l.minimum} ${d?.unit ?? ""} \u05D0\u05D5 \u05D9\u05D5\u05EA\u05E8` : `\u05D9\u05D5\u05EA\u05E8 \u05DE-${l.minimum} ${d?.unit ?? ""}`;
          return `\u05E7\u05D8\u05DF \u05DE\u05D3\u05D9: ${p} ${O} \u05DC\u05D4\u05DB\u05D9\u05DC ${I}`.trim();
        }
        let h = l.inclusive ? ">=" : ">", v = i(l.origin ?? "value");
        return d?.unit ? `${d.shortLabel} \u05DE\u05D3\u05D9: ${p} ${v} ${h}${l.minimum.toString()} ${d.unit}` : `${d?.shortLabel ?? "\u05E7\u05D8\u05DF"} \u05DE\u05D3\u05D9: ${p} ${v} ${h}${l.minimum.toString()}`;
      }
      case "invalid_format": {
        let d = l;
        if (d.format === "starts_with")
          return `\u05D4\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D7\u05D9\u05D9\u05D1\u05EA \u05DC\u05D4\u05EA\u05D7\u05D9\u05DC \u05D1 "${d.prefix}"`;
        if (d.format === "ends_with")
          return `\u05D4\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D7\u05D9\u05D9\u05D1\u05EA \u05DC\u05D4\u05E1\u05EA\u05D9\u05D9\u05DD \u05D1 "${d.suffix}"`;
        if (d.format === "includes")
          return `\u05D4\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D7\u05D9\u05D9\u05D1\u05EA \u05DC\u05DB\u05DC\u05D5\u05DC "${d.includes}"`;
        if (d.format === "regex")
          return `\u05D4\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D7\u05D9\u05D9\u05D1\u05EA \u05DC\u05D4\u05EA\u05D0\u05D9\u05DD \u05DC\u05EA\u05D1\u05E0\u05D9\u05EA ${d.pattern}`;
        let p = c[d.format], h = p?.label ?? d.format, O = (p?.gender ?? "m") === "f" ? "\u05EA\u05E7\u05D9\u05E0\u05D4" : "\u05EA\u05E7\u05D9\u05DF";
        return `${h} \u05DC\u05D0 ${O}`;
      }
      case "not_multiple_of":
        return `\u05DE\u05E1\u05E4\u05E8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05D7\u05D9\u05D9\u05D1 \u05DC\u05D4\u05D9\u05D5\u05EA \u05DE\u05DB\u05E4\u05DC\u05D4 \u05E9\u05DC ${l.divisor}`;
      case "unrecognized_keys":
        return `\u05DE\u05E4\u05EA\u05D7${l.keys.length > 1 ? "\u05D5\u05EA" : ""} \u05DC\u05D0 \u05DE\u05D6\u05D5\u05D4${l.keys.length > 1 ? "\u05D9\u05DD" : "\u05D4"}: ${m(l.keys, ", ")}`;
      case "invalid_key":
        return "\u05E9\u05D3\u05D4 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF \u05D1\u05D0\u05D5\u05D1\u05D9\u05D9\u05E7\u05D8";
      case "invalid_union":
        return "\u05E7\u05DC\u05D8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF";
      case "invalid_element":
        return `\u05E2\u05E8\u05DA \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF \u05D1${r(l.origin ?? "array")}`;
      default:
        return "\u05E7\u05DC\u05D8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF";
    }
  };
}, "error");
function gc() {
  return {
    localeError: Fv()
  };
}
s(gc, "default");

// versions/4.3.6/node_modules/zod/v4/locales/hu.js
var Lv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "karakter", verb: "legyen" },
    file: { unit: "byte", verb: "legyen" },
    array: { unit: "elem", verb: "legyen" },
    set: { unit: "elem", verb: "legyen" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "bemenet",
    email: "email c\xEDm",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO id\u0151b\xE9lyeg",
    date: "ISO d\xE1tum",
    time: "ISO id\u0151",
    duration: "ISO id\u0151intervallum",
    ipv4: "IPv4 c\xEDm",
    ipv6: "IPv6 c\xEDm",
    cidrv4: "IPv4 tartom\xE1ny",
    cidrv6: "IPv6 tartom\xE1ny",
    base64: "base64-k\xF3dolt string",
    base64url: "base64url-k\xF3dolt string",
    json_string: "JSON string",
    e164: "E.164 sz\xE1m",
    jwt: "JWT",
    template_literal: "bemenet"
  }, o = {
    nan: "NaN",
    number: "sz\xE1m",
    array: "t\xF6mb"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), c = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\xC9rv\xE9nytelen bemenet: a v\xE1rt \xE9rt\xE9k instanceof ${r.expected}, a kapott \xE9rt\xE9k ${c}` : `\xC9rv\xE9nytelen bemenet: a v\xE1rt \xE9rt\xE9k ${i}, a kapott \xE9rt\xE9k ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\xC9rv\xE9nytelen bemenet: a v\xE1rt \xE9rt\xE9k ${y(r.values[0])}` : `\xC9rv\xE9nytelen opci\xF3: valamelyik \xE9rt\xE9k v\xE1rt ${m(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `T\xFAl nagy: ${r.origin ?? "\xE9rt\xE9k"} m\xE9rete t\xFAl nagy ${i}${r.maximum.toString()} ${a.unit ?? "elem"}` : `T\xFAl nagy: a bemeneti \xE9rt\xE9k ${r.origin ?? "\xE9rt\xE9k"} t\xFAl nagy: ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `T\xFAl kicsi: a bemeneti \xE9rt\xE9k ${r.origin} m\xE9rete t\xFAl kicsi ${i}${r.minimum.toString()} ${a.unit}` : `T\xFAl kicsi: a bemeneti \xE9rt\xE9k ${r.origin} t\xFAl kicsi ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\xC9rv\xE9nytelen string: "${i.prefix}" \xE9rt\xE9kkel kell kezd\u0151dnie` : i.format === "ends_with" ? `\xC9rv\xE9nytelen string: "${i.suffix}" \xE9rt\xE9kkel kell v\xE9gz\u0151dnie` : i.format === "includes" ? `\xC9rv\xE9nytelen string: "${i.includes}" \xE9rt\xE9ket kell tartalmaznia` : i.format === "regex" ? `\xC9rv\xE9nytelen string: ${i.pattern} mint\xE1nak kell megfelelnie` : `\xC9rv\xE9nytelen ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\xC9rv\xE9nytelen sz\xE1m: ${r.divisor} t\xF6bbsz\xF6r\xF6s\xE9nek kell lennie`;
      case "unrecognized_keys":
        return `Ismeretlen kulcs${r.keys.length > 1 ? "s" : ""}: ${m(r.keys, ", ")}`;
      case "invalid_key":
        return `\xC9rv\xE9nytelen kulcs ${r.origin}`;
      case "invalid_union":
        return "\xC9rv\xE9nytelen bemenet";
      case "invalid_element":
        return `\xC9rv\xE9nytelen \xE9rt\xE9k: ${r.origin}`;
      default:
        return "\xC9rv\xE9nytelen bemenet";
    }
  };
}, "error");
function hc() {
  return {
    localeError: Lv()
  };
}
s(hc, "default");

// versions/4.3.6/node_modules/zod/v4/locales/hy.js
function Gf(e, t, n) {
  return Math.abs(e) === 1 ? t : n;
}
s(Gf, "getArmenianPlural");
function Zt(e) {
  if (!e)
    return "";
  let t = ["\u0561", "\u0565", "\u0568", "\u056B", "\u0578", "\u0578\u0582", "\u0585"], n = e[e.length - 1];
  return e + (t.includes(n) ? "\u0576" : "\u0568");
}
s(Zt, "withDefiniteArticle");
var Mv = /* @__PURE__ */ s(() => {
  let e = {
    string: {
      unit: {
        one: "\u0576\u0577\u0561\u0576",
        many: "\u0576\u0577\u0561\u0576\u0576\u0565\u0580"
      },
      verb: "\u0578\u0582\u0576\u0565\u0576\u0561\u056C"
    },
    file: {
      unit: {
        one: "\u0562\u0561\u0575\u0569",
        many: "\u0562\u0561\u0575\u0569\u0565\u0580"
      },
      verb: "\u0578\u0582\u0576\u0565\u0576\u0561\u056C"
    },
    array: {
      unit: {
        one: "\u057F\u0561\u0580\u0580",
        many: "\u057F\u0561\u0580\u0580\u0565\u0580"
      },
      verb: "\u0578\u0582\u0576\u0565\u0576\u0561\u056C"
    },
    set: {
      unit: {
        one: "\u057F\u0561\u0580\u0580",
        many: "\u057F\u0561\u0580\u0580\u0565\u0580"
      },
      verb: "\u0578\u0582\u0576\u0565\u0576\u0561\u056C"
    }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u0574\u0578\u0582\u057F\u0584",
    email: "\u0567\u056C. \u0570\u0561\u057D\u0581\u0565",
    url: "URL",
    emoji: "\u0567\u0574\u0578\u057B\u056B",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0561\u0574\u057D\u0561\u0569\u056B\u057E \u0587 \u056A\u0561\u0574",
    date: "ISO \u0561\u0574\u057D\u0561\u0569\u056B\u057E",
    time: "ISO \u056A\u0561\u0574",
    duration: "ISO \u057F\u0587\u0578\u0572\u0578\u0582\u0569\u0575\u0578\u0582\u0576",
    ipv4: "IPv4 \u0570\u0561\u057D\u0581\u0565",
    ipv6: "IPv6 \u0570\u0561\u057D\u0581\u0565",
    cidrv4: "IPv4 \u0574\u056B\u057B\u0561\u056F\u0561\u0575\u0584",
    cidrv6: "IPv6 \u0574\u056B\u057B\u0561\u056F\u0561\u0575\u0584",
    base64: "base64 \u0571\u0587\u0561\u0579\u0561\u0583\u0578\u057E \u057F\u0578\u0572",
    base64url: "base64url \u0571\u0587\u0561\u0579\u0561\u0583\u0578\u057E \u057F\u0578\u0572",
    json_string: "JSON \u057F\u0578\u0572",
    e164: "E.164 \u0570\u0561\u0574\u0561\u0580",
    jwt: "JWT",
    template_literal: "\u0574\u0578\u0582\u057F\u0584"
  }, o = {
    nan: "NaN",
    number: "\u0569\u056B\u057E",
    array: "\u0566\u0561\u0576\u0563\u057E\u0561\u056E"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), c = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567\u0580 instanceof ${r.expected}, \u057D\u057F\u0561\u0581\u057E\u0565\u056C \u0567 ${c}` : `\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567\u0580 ${i}, \u057D\u057F\u0561\u0581\u057E\u0565\u056C \u0567 ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567\u0580 ${y(r.values[1])}` : `\u054D\u056D\u0561\u056C \u057F\u0561\u0580\u0562\u0565\u0580\u0561\u056F\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567\u0580 \u0570\u0565\u057F\u0587\u0575\u0561\u056C\u0576\u0565\u0580\u056B\u0581 \u0574\u0565\u056F\u0568\u055D ${m(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        if (a) {
          let c = Number(r.maximum), u = Gf(c, a.unit.one, a.unit.many);
          return `\u0549\u0561\u0583\u0561\u0566\u0561\u0576\u0581 \u0574\u0565\u056E \u0561\u0580\u056A\u0565\u0584\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567, \u0578\u0580 ${Zt(r.origin ?? "\u0561\u0580\u056A\u0565\u0584")} \u056F\u0578\u0582\u0576\u0565\u0576\u0561 ${i}${r.maximum.toString()} ${u}`;
        }
        return `\u0549\u0561\u0583\u0561\u0566\u0561\u0576\u0581 \u0574\u0565\u056E \u0561\u0580\u056A\u0565\u0584\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567, \u0578\u0580 ${Zt(r.origin ?? "\u0561\u0580\u056A\u0565\u0584")} \u056C\u056B\u0576\u056B ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        if (a) {
          let c = Number(r.minimum), u = Gf(c, a.unit.one, a.unit.many);
          return `\u0549\u0561\u0583\u0561\u0566\u0561\u0576\u0581 \u0583\u0578\u0584\u0580 \u0561\u0580\u056A\u0565\u0584\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567, \u0578\u0580 ${Zt(r.origin)} \u056F\u0578\u0582\u0576\u0565\u0576\u0561 ${i}${r.minimum.toString()} ${u}`;
        }
        return `\u0549\u0561\u0583\u0561\u0566\u0561\u0576\u0581 \u0583\u0578\u0584\u0580 \u0561\u0580\u056A\u0565\u0584\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567, \u0578\u0580 ${Zt(r.origin)} \u056C\u056B\u0576\u056B ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u054D\u056D\u0561\u056C \u057F\u0578\u0572\u2024 \u057A\u0565\u057F\u0584 \u0567 \u057D\u056F\u057D\u057E\u056B "${i.prefix}"-\u0578\u057E` : i.format === "ends_with" ? `\u054D\u056D\u0561\u056C \u057F\u0578\u0572\u2024 \u057A\u0565\u057F\u0584 \u0567 \u0561\u057E\u0561\u0580\u057F\u057E\u056B "${i.suffix}"-\u0578\u057E` : i.format === "includes" ? `\u054D\u056D\u0561\u056C \u057F\u0578\u0572\u2024 \u057A\u0565\u057F\u0584 \u0567 \u057A\u0561\u0580\u0578\u0582\u0576\u0561\u056F\u056B "${i.includes}"` : i.format === "regex" ? `\u054D\u056D\u0561\u056C \u057F\u0578\u0572\u2024 \u057A\u0565\u057F\u0584 \u0567 \u0570\u0561\u0574\u0561\u057A\u0561\u057F\u0561\u057D\u056D\u0561\u0576\u056B ${i.pattern} \u0571\u0587\u0561\u0579\u0561\u0583\u056B\u0576` : `\u054D\u056D\u0561\u056C ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u054D\u056D\u0561\u056C \u0569\u056B\u057E\u2024 \u057A\u0565\u057F\u0584 \u0567 \u0562\u0561\u0566\u0574\u0561\u057A\u0561\u057F\u056B\u056F \u056C\u056B\u0576\u056B ${r.divisor}-\u056B`;
      case "unrecognized_keys":
        return `\u0549\u0573\u0561\u0576\u0561\u0579\u057E\u0561\u056E \u0562\u0561\u0576\u0561\u056C\u056B${r.keys.length > 1 ? "\u0576\u0565\u0580" : ""}. ${m(r.keys, ", ")}`;
      case "invalid_key":
        return `\u054D\u056D\u0561\u056C \u0562\u0561\u0576\u0561\u056C\u056B ${Zt(r.origin)}-\u0578\u0582\u0574`;
      case "invalid_union":
        return "\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574";
      case "invalid_element":
        return `\u054D\u056D\u0561\u056C \u0561\u0580\u056A\u0565\u0584 ${Zt(r.origin)}-\u0578\u0582\u0574`;
      default:
        return "\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574";
    }
  };
}, "error");
function vc() {
  return {
    localeError: Mv()
  };
}
s(vc, "default");

// versions/4.3.6/node_modules/zod/v4/locales/id.js
var Bv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "karakter", verb: "memiliki" },
    file: { unit: "byte", verb: "memiliki" },
    array: { unit: "item", verb: "memiliki" },
    set: { unit: "item", verb: "memiliki" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "input",
    email: "alamat email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "tanggal dan waktu format ISO",
    date: "tanggal format ISO",
    time: "jam format ISO",
    duration: "durasi format ISO",
    ipv4: "alamat IPv4",
    ipv6: "alamat IPv6",
    cidrv4: "rentang alamat IPv4",
    cidrv6: "rentang alamat IPv6",
    base64: "string dengan enkode base64",
    base64url: "string dengan enkode base64url",
    json_string: "string JSON",
    e164: "angka E.164",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), c = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Input tidak valid: diharapkan instanceof ${r.expected}, diterima ${c}` : `Input tidak valid: diharapkan ${i}, diterima ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Input tidak valid: diharapkan ${y(r.values[0])}` : `Pilihan tidak valid: diharapkan salah satu dari ${m(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Terlalu besar: diharapkan ${r.origin ?? "value"} memiliki ${i}${r.maximum.toString()} ${a.unit ?? "elemen"}` : `Terlalu besar: diharapkan ${r.origin ?? "value"} menjadi ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Terlalu kecil: diharapkan ${r.origin} memiliki ${i}${r.minimum.toString()} ${a.unit}` : `Terlalu kecil: diharapkan ${r.origin} menjadi ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `String tidak valid: harus dimulai dengan "${i.prefix}"` : i.format === "ends_with" ? `String tidak valid: harus berakhir dengan "${i.suffix}"` : i.format === "includes" ? `String tidak valid: harus menyertakan "${i.includes}"` : i.format === "regex" ? `String tidak valid: harus sesuai pola ${i.pattern}` : `${n[i.format] ?? r.format} tidak valid`;
      }
      case "not_multiple_of":
        return `Angka tidak valid: harus kelipatan dari ${r.divisor}`;
      case "unrecognized_keys":
        return `Kunci tidak dikenali ${r.keys.length > 1 ? "s" : ""}: ${m(r.keys, ", ")}`;
      case "invalid_key":
        return `Kunci tidak valid di ${r.origin}`;
      case "invalid_union":
        return "Input tidak valid";
      case "invalid_element":
        return `Nilai tidak valid di ${r.origin}`;
      default:
        return "Input tidak valid";
    }
  };
}, "error");
function yc() {
  return {
    localeError: Bv()
  };
}
s(yc, "default");

// versions/4.3.6/node_modules/zod/v4/locales/is.js
var Jv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "stafi", verb: "a\xF0 hafa" },
    file: { unit: "b\xE6ti", verb: "a\xF0 hafa" },
    array: { unit: "hluti", verb: "a\xF0 hafa" },
    set: { unit: "hluti", verb: "a\xF0 hafa" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "gildi",
    email: "netfang",
    url: "vefsl\xF3\xF0",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO dagsetning og t\xEDmi",
    date: "ISO dagsetning",
    time: "ISO t\xEDmi",
    duration: "ISO t\xEDmalengd",
    ipv4: "IPv4 address",
    ipv6: "IPv6 address",
    cidrv4: "IPv4 range",
    cidrv6: "IPv6 range",
    base64: "base64-encoded strengur",
    base64url: "base64url-encoded strengur",
    json_string: "JSON strengur",
    e164: "E.164 t\xF6lugildi",
    jwt: "JWT",
    template_literal: "gildi"
  }, o = {
    nan: "NaN",
    number: "n\xFAmer",
    array: "fylki"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), c = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Rangt gildi: \xDE\xFA sl\xF3st inn ${c} \xFEar sem \xE1 a\xF0 vera instanceof ${r.expected}` : `Rangt gildi: \xDE\xFA sl\xF3st inn ${c} \xFEar sem \xE1 a\xF0 vera ${i}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Rangt gildi: gert r\xE1\xF0 fyrir ${y(r.values[0])}` : `\xD3gilt val: m\xE1 vera eitt af eftirfarandi ${m(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Of st\xF3rt: gert er r\xE1\xF0 fyrir a\xF0 ${r.origin ?? "gildi"} hafi ${i}${r.maximum.toString()} ${a.unit ?? "hluti"}` : `Of st\xF3rt: gert er r\xE1\xF0 fyrir a\xF0 ${r.origin ?? "gildi"} s\xE9 ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Of l\xEDti\xF0: gert er r\xE1\xF0 fyrir a\xF0 ${r.origin} hafi ${i}${r.minimum.toString()} ${a.unit}` : `Of l\xEDti\xF0: gert er r\xE1\xF0 fyrir a\xF0 ${r.origin} s\xE9 ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\xD3gildur strengur: ver\xF0ur a\xF0 byrja \xE1 "${i.prefix}"` : i.format === "ends_with" ? `\xD3gildur strengur: ver\xF0ur a\xF0 enda \xE1 "${i.suffix}"` : i.format === "includes" ? `\xD3gildur strengur: ver\xF0ur a\xF0 innihalda "${i.includes}"` : i.format === "regex" ? `\xD3gildur strengur: ver\xF0ur a\xF0 fylgja mynstri ${i.pattern}` : `Rangt ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `R\xF6ng tala: ver\xF0ur a\xF0 vera margfeldi af ${r.divisor}`;
      case "unrecognized_keys":
        return `\xD3\xFEekkt ${r.keys.length > 1 ? "ir lyklar" : "ur lykill"}: ${m(r.keys, ", ")}`;
      case "invalid_key":
        return `Rangur lykill \xED ${r.origin}`;
      case "invalid_union":
        return "Rangt gildi";
      case "invalid_element":
        return `Rangt gildi \xED ${r.origin}`;
      default:
        return "Rangt gildi";
    }
  };
}, "error");
function bc() {
  return {
    localeError: Jv()
  };
}
s(bc, "default");

// versions/4.3.6/node_modules/zod/v4/locales/it.js
var Vv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "caratteri", verb: "avere" },
    file: { unit: "byte", verb: "avere" },
    array: { unit: "elementi", verb: "avere" },
    set: { unit: "elementi", verb: "avere" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "input",
    email: "indirizzo email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "data e ora ISO",
    date: "data ISO",
    time: "ora ISO",
    duration: "durata ISO",
    ipv4: "indirizzo IPv4",
    ipv6: "indirizzo IPv6",
    cidrv4: "intervallo IPv4",
    cidrv6: "intervallo IPv6",
    base64: "stringa codificata in base64",
    base64url: "URL codificata in base64",
    json_string: "stringa JSON",
    e164: "numero E.164",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN",
    number: "numero",
    array: "vettore"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), c = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Input non valido: atteso instanceof ${r.expected}, ricevuto ${c}` : `Input non valido: atteso ${i}, ricevuto ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Input non valido: atteso ${y(r.values[0])}` : `Opzione non valida: atteso uno tra ${m(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Troppo grande: ${r.origin ?? "valore"} deve avere ${i}${r.maximum.toString()} ${a.unit ?? "elementi"}` : `Troppo grande: ${r.origin ?? "valore"} deve essere ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Troppo piccolo: ${r.origin} deve avere ${i}${r.minimum.toString()} ${a.unit}` : `Troppo piccolo: ${r.origin} deve essere ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Stringa non valida: deve iniziare con "${i.prefix}"` : i.format === "ends_with" ? `Stringa non valida: deve terminare con "${i.suffix}"` : i.format === "includes" ? `Stringa non valida: deve includere "${i.includes}"` : i.format === "regex" ? `Stringa non valida: deve corrispondere al pattern ${i.pattern}` : `Invalid ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Numero non valido: deve essere un multiplo di ${r.divisor}`;
      case "unrecognized_keys":
        return `Chiav${r.keys.length > 1 ? "i" : "e"} non riconosciut${r.keys.length > 1 ? "e" : "a"}: ${m(r.keys, ", ")}`;
      case "invalid_key":
        return `Chiave non valida in ${r.origin}`;
      case "invalid_union":
        return "Input non valido";
      case "invalid_element":
        return `Valore non valido in ${r.origin}`;
      default:
        return "Input non valido";
    }
  };
}, "error");
function xc() {
  return {
    localeError: Vv()
  };
}
s(xc, "default");

// versions/4.3.6/node_modules/zod/v4/locales/ja.js
var qv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u6587\u5B57", verb: "\u3067\u3042\u308B" },
    file: { unit: "\u30D0\u30A4\u30C8", verb: "\u3067\u3042\u308B" },
    array: { unit: "\u8981\u7D20", verb: "\u3067\u3042\u308B" },
    set: { unit: "\u8981\u7D20", verb: "\u3067\u3042\u308B" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u5165\u529B\u5024",
    email: "\u30E1\u30FC\u30EB\u30A2\u30C9\u30EC\u30B9",
    url: "URL",
    emoji: "\u7D75\u6587\u5B57",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO\u65E5\u6642",
    date: "ISO\u65E5\u4ED8",
    time: "ISO\u6642\u523B",
    duration: "ISO\u671F\u9593",
    ipv4: "IPv4\u30A2\u30C9\u30EC\u30B9",
    ipv6: "IPv6\u30A2\u30C9\u30EC\u30B9",
    cidrv4: "IPv4\u7BC4\u56F2",
    cidrv6: "IPv6\u7BC4\u56F2",
    base64: "base64\u30A8\u30F3\u30B3\u30FC\u30C9\u6587\u5B57\u5217",
    base64url: "base64url\u30A8\u30F3\u30B3\u30FC\u30C9\u6587\u5B57\u5217",
    json_string: "JSON\u6587\u5B57\u5217",
    e164: "E.164\u756A\u53F7",
    jwt: "JWT",
    template_literal: "\u5165\u529B\u5024"
  }, o = {
    nan: "NaN",
    number: "\u6570\u5024",
    array: "\u914D\u5217"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), c = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u7121\u52B9\u306A\u5165\u529B: instanceof ${r.expected}\u304C\u671F\u5F85\u3055\u308C\u307E\u3057\u305F\u304C\u3001${c}\u304C\u5165\u529B\u3055\u308C\u307E\u3057\u305F` : `\u7121\u52B9\u306A\u5165\u529B: ${i}\u304C\u671F\u5F85\u3055\u308C\u307E\u3057\u305F\u304C\u3001${c}\u304C\u5165\u529B\u3055\u308C\u307E\u3057\u305F`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u7121\u52B9\u306A\u5165\u529B: ${y(r.values[0])}\u304C\u671F\u5F85\u3055\u308C\u307E\u3057\u305F` : `\u7121\u52B9\u306A\u9078\u629E: ${m(r.values, "\u3001")}\u306E\u3044\u305A\u308C\u304B\u3067\u3042\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`;
      case "too_big": {
        let i = r.inclusive ? "\u4EE5\u4E0B\u3067\u3042\u308B" : "\u3088\u308A\u5C0F\u3055\u3044", a = t(r.origin);
        return a ? `\u5927\u304D\u3059\u304E\u308B\u5024: ${r.origin ?? "\u5024"}\u306F${r.maximum.toString()}${a.unit ?? "\u8981\u7D20"}${i}\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : `\u5927\u304D\u3059\u304E\u308B\u5024: ${r.origin ?? "\u5024"}\u306F${r.maximum.toString()}${i}\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`;
      }
      case "too_small": {
        let i = r.inclusive ? "\u4EE5\u4E0A\u3067\u3042\u308B" : "\u3088\u308A\u5927\u304D\u3044", a = t(r.origin);
        return a ? `\u5C0F\u3055\u3059\u304E\u308B\u5024: ${r.origin}\u306F${r.minimum.toString()}${a.unit}${i}\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : `\u5C0F\u3055\u3059\u304E\u308B\u5024: ${r.origin}\u306F${r.minimum.toString()}${i}\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u7121\u52B9\u306A\u6587\u5B57\u5217: "${i.prefix}"\u3067\u59CB\u307E\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : i.format === "ends_with" ? `\u7121\u52B9\u306A\u6587\u5B57\u5217: "${i.suffix}"\u3067\u7D42\u308F\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : i.format === "includes" ? `\u7121\u52B9\u306A\u6587\u5B57\u5217: "${i.includes}"\u3092\u542B\u3080\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : i.format === "regex" ? `\u7121\u52B9\u306A\u6587\u5B57\u5217: \u30D1\u30BF\u30FC\u30F3${i.pattern}\u306B\u4E00\u81F4\u3059\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : `\u7121\u52B9\u306A${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u7121\u52B9\u306A\u6570\u5024: ${r.divisor}\u306E\u500D\u6570\u3067\u3042\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`;
      case "unrecognized_keys":
        return `\u8A8D\u8B58\u3055\u308C\u3066\u3044\u306A\u3044\u30AD\u30FC${r.keys.length > 1 ? "\u7FA4" : ""}: ${m(r.keys, "\u3001")}`;
      case "invalid_key":
        return `${r.origin}\u5185\u306E\u7121\u52B9\u306A\u30AD\u30FC`;
      case "invalid_union":
        return "\u7121\u52B9\u306A\u5165\u529B";
      case "invalid_element":
        return `${r.origin}\u5185\u306E\u7121\u52B9\u306A\u5024`;
      default:
        return "\u7121\u52B9\u306A\u5165\u529B";
    }
  };
}, "error");
function $c() {
  return {
    localeError: qv()
  };
}
s($c, "default");

// versions/4.3.6/node_modules/zod/v4/locales/ka.js
var Wv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u10E1\u10D8\u10DB\u10D1\u10DD\u10DA\u10DD", verb: "\u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1" },
    file: { unit: "\u10D1\u10D0\u10D8\u10E2\u10D8", verb: "\u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1" },
    array: { unit: "\u10D4\u10DA\u10D4\u10DB\u10D4\u10DC\u10E2\u10D8", verb: "\u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1" },
    set: { unit: "\u10D4\u10DA\u10D4\u10DB\u10D4\u10DC\u10E2\u10D8", verb: "\u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0",
    email: "\u10D4\u10DA-\u10E4\u10DD\u10E1\u10E2\u10D8\u10E1 \u10DB\u10D8\u10E1\u10D0\u10DB\u10D0\u10E0\u10D7\u10D8",
    url: "URL",
    emoji: "\u10D4\u10DB\u10DD\u10EF\u10D8",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u10D7\u10D0\u10E0\u10D8\u10E6\u10D8-\u10D3\u10E0\u10DD",
    date: "\u10D7\u10D0\u10E0\u10D8\u10E6\u10D8",
    time: "\u10D3\u10E0\u10DD",
    duration: "\u10EE\u10D0\u10DC\u10D2\u10E0\u10EB\u10DA\u10D8\u10D5\u10DD\u10D1\u10D0",
    ipv4: "IPv4 \u10DB\u10D8\u10E1\u10D0\u10DB\u10D0\u10E0\u10D7\u10D8",
    ipv6: "IPv6 \u10DB\u10D8\u10E1\u10D0\u10DB\u10D0\u10E0\u10D7\u10D8",
    cidrv4: "IPv4 \u10D3\u10D8\u10D0\u10DE\u10D0\u10D6\u10DD\u10DC\u10D8",
    cidrv6: "IPv6 \u10D3\u10D8\u10D0\u10DE\u10D0\u10D6\u10DD\u10DC\u10D8",
    base64: "base64-\u10D9\u10DD\u10D3\u10D8\u10E0\u10D4\u10D1\u10E3\u10DA\u10D8 \u10E1\u10E2\u10E0\u10D8\u10DC\u10D2\u10D8",
    base64url: "base64url-\u10D9\u10DD\u10D3\u10D8\u10E0\u10D4\u10D1\u10E3\u10DA\u10D8 \u10E1\u10E2\u10E0\u10D8\u10DC\u10D2\u10D8",
    json_string: "JSON \u10E1\u10E2\u10E0\u10D8\u10DC\u10D2\u10D8",
    e164: "E.164 \u10DC\u10DD\u10DB\u10D4\u10E0\u10D8",
    jwt: "JWT",
    template_literal: "\u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0"
  }, o = {
    nan: "NaN",
    number: "\u10E0\u10D8\u10EA\u10EE\u10D5\u10D8",
    string: "\u10E1\u10E2\u10E0\u10D8\u10DC\u10D2\u10D8",
    boolean: "\u10D1\u10E3\u10DA\u10D4\u10D0\u10DC\u10D8",
    function: "\u10E4\u10E3\u10DC\u10E5\u10EA\u10D8\u10D0",
    array: "\u10DB\u10D0\u10E1\u10D8\u10D5\u10D8"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), c = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 instanceof ${r.expected}, \u10DB\u10D8\u10E6\u10D4\u10D1\u10E3\u10DA\u10D8 ${c}` : `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${i}, \u10DB\u10D8\u10E6\u10D4\u10D1\u10E3\u10DA\u10D8 ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${y(r.values[0])}` : `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D5\u10D0\u10E0\u10D8\u10D0\u10DC\u10E2\u10D8: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8\u10D0 \u10D4\u10E0\u10D7-\u10D4\u10E0\u10D7\u10D8 ${m(r.values, "|")}-\u10D3\u10D0\u10DC`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `\u10D6\u10D4\u10D3\u10DB\u10D4\u10E2\u10D0\u10D3 \u10D3\u10D8\u10D3\u10D8: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${r.origin ?? "\u10DB\u10DC\u10D8\u10E8\u10D5\u10DC\u10D4\u10DA\u10DD\u10D1\u10D0"} ${a.verb} ${i}${r.maximum.toString()} ${a.unit}` : `\u10D6\u10D4\u10D3\u10DB\u10D4\u10E2\u10D0\u10D3 \u10D3\u10D8\u10D3\u10D8: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${r.origin ?? "\u10DB\u10DC\u10D8\u10E8\u10D5\u10DC\u10D4\u10DA\u10DD\u10D1\u10D0"} \u10D8\u10E7\u10DD\u10E1 ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\u10D6\u10D4\u10D3\u10DB\u10D4\u10E2\u10D0\u10D3 \u10DE\u10D0\u10E2\u10D0\u10E0\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${r.origin} ${a.verb} ${i}${r.minimum.toString()} ${a.unit}` : `\u10D6\u10D4\u10D3\u10DB\u10D4\u10E2\u10D0\u10D3 \u10DE\u10D0\u10E2\u10D0\u10E0\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${r.origin} \u10D8\u10E7\u10DD\u10E1 ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E1\u10E2\u10E0\u10D8\u10DC\u10D2\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10D8\u10EC\u10E7\u10D4\u10D1\u10DD\u10D3\u10D4\u10E1 "${i.prefix}"-\u10D8\u10D7` : i.format === "ends_with" ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E1\u10E2\u10E0\u10D8\u10DC\u10D2\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10DB\u10D7\u10D0\u10D5\u10E0\u10D3\u10D4\u10D1\u10DD\u10D3\u10D4\u10E1 "${i.suffix}"-\u10D8\u10D7` : i.format === "includes" ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E1\u10E2\u10E0\u10D8\u10DC\u10D2\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1 "${i.includes}"-\u10E1` : i.format === "regex" ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E1\u10E2\u10E0\u10D8\u10DC\u10D2\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D4\u10E1\u10D0\u10D1\u10D0\u10DB\u10D4\u10D1\u10DD\u10D3\u10D4\u10E1 \u10E8\u10D0\u10D1\u10DA\u10DD\u10DC\u10E1 ${i.pattern}` : `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E0\u10D8\u10EA\u10EE\u10D5\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10D8\u10E7\u10DD\u10E1 ${r.divisor}-\u10D8\u10E1 \u10EF\u10D4\u10E0\u10D0\u10D3\u10D8`;
      case "unrecognized_keys":
        return `\u10E3\u10EA\u10DC\u10DD\u10D1\u10D8 \u10D2\u10D0\u10E1\u10D0\u10E6\u10D4\u10D1${r.keys.length > 1 ? "\u10D4\u10D1\u10D8" : "\u10D8"}: ${m(r.keys, ", ")}`;
      case "invalid_key":
        return `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D2\u10D0\u10E1\u10D0\u10E6\u10D4\u10D1\u10D8 ${r.origin}-\u10E8\u10D8`;
      case "invalid_union":
        return "\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0";
      case "invalid_element":
        return `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10DB\u10DC\u10D8\u10E8\u10D5\u10DC\u10D4\u10DA\u10DD\u10D1\u10D0 ${r.origin}-\u10E8\u10D8`;
      default:
        return "\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0";
    }
  };
}, "error");
function _c() {
  return {
    localeError: Wv()
  };
}
s(_c, "default");

// versions/4.3.6/node_modules/zod/v4/locales/km.js
var Kv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u178F\u17BD\u17A2\u1780\u17D2\u179F\u179A", verb: "\u1782\u17BD\u179A\u1798\u17B6\u1793" },
    file: { unit: "\u1794\u17C3", verb: "\u1782\u17BD\u179A\u1798\u17B6\u1793" },
    array: { unit: "\u1792\u17B6\u178F\u17BB", verb: "\u1782\u17BD\u179A\u1798\u17B6\u1793" },
    set: { unit: "\u1792\u17B6\u178F\u17BB", verb: "\u1782\u17BD\u179A\u1798\u17B6\u1793" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B",
    email: "\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793\u17A2\u17CA\u17B8\u1798\u17C2\u179B",
    url: "URL",
    emoji: "\u179F\u1789\u17D2\u1789\u17B6\u17A2\u17B6\u179A\u1798\u17D2\u1798\u178E\u17CD",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u1780\u17B6\u179B\u1794\u179A\u17B7\u1785\u17D2\u1786\u17C1\u1791 \u1793\u17B7\u1784\u1798\u17C9\u17C4\u1784 ISO",
    date: "\u1780\u17B6\u179B\u1794\u179A\u17B7\u1785\u17D2\u1786\u17C1\u1791 ISO",
    time: "\u1798\u17C9\u17C4\u1784 ISO",
    duration: "\u179A\u1799\u17C8\u1796\u17C1\u179B ISO",
    ipv4: "\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793 IPv4",
    ipv6: "\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793 IPv6",
    cidrv4: "\u178A\u17C2\u1793\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793 IPv4",
    cidrv6: "\u178A\u17C2\u1793\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793 IPv6",
    base64: "\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u17A2\u17CA\u17B7\u1780\u17BC\u178A base64",
    base64url: "\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u17A2\u17CA\u17B7\u1780\u17BC\u178A base64url",
    json_string: "\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A JSON",
    e164: "\u179B\u17C1\u1781 E.164",
    jwt: "JWT",
    template_literal: "\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B"
  }, o = {
    nan: "NaN",
    number: "\u179B\u17C1\u1781",
    array: "\u17A2\u17B6\u179A\u17C1 (Array)",
    null: "\u1782\u17D2\u1798\u17B6\u1793\u178F\u1798\u17D2\u179B\u17C3 (null)"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), c = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A instanceof ${r.expected} \u1794\u17C9\u17BB\u1793\u17D2\u178F\u17C2\u1791\u1791\u17BD\u179B\u1794\u17B6\u1793 ${c}` : `\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${i} \u1794\u17C9\u17BB\u1793\u17D2\u178F\u17C2\u1791\u1791\u17BD\u179B\u1794\u17B6\u1793 ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${y(r.values[0])}` : `\u1787\u1798\u17D2\u179A\u17BE\u179F\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1787\u17B6\u1798\u17BD\u1799\u1780\u17D2\u1793\u17BB\u1784\u1785\u17C6\u178E\u17C4\u1798 ${m(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `\u1792\u17C6\u1796\u17C1\u1780\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${r.origin ?? "\u178F\u1798\u17D2\u179B\u17C3"} ${i} ${r.maximum.toString()} ${a.unit ?? "\u1792\u17B6\u178F\u17BB"}` : `\u1792\u17C6\u1796\u17C1\u1780\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${r.origin ?? "\u178F\u1798\u17D2\u179B\u17C3"} ${i} ${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\u178F\u17BC\u1785\u1796\u17C1\u1780\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${r.origin} ${i} ${r.minimum.toString()} ${a.unit}` : `\u178F\u17BC\u1785\u1796\u17C1\u1780\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${r.origin} ${i} ${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1785\u17B6\u1794\u17CB\u1795\u17D2\u178F\u17BE\u1798\u178A\u17C4\u1799 "${i.prefix}"` : i.format === "ends_with" ? `\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1794\u1789\u17D2\u1785\u1794\u17CB\u178A\u17C4\u1799 "${i.suffix}"` : i.format === "includes" ? `\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1798\u17B6\u1793 "${i.includes}"` : i.format === "regex" ? `\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u178F\u17C2\u1795\u17D2\u1782\u17BC\u1795\u17D2\u1782\u1784\u1793\u17B9\u1784\u1791\u1798\u17D2\u179A\u1784\u17CB\u178A\u17C2\u179B\u1794\u17B6\u1793\u1780\u17C6\u178E\u178F\u17CB ${i.pattern}` : `\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u179B\u17C1\u1781\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u178F\u17C2\u1787\u17B6\u1796\u17A0\u17BB\u1782\u17BB\u178E\u1793\u17C3 ${r.divisor}`;
      case "unrecognized_keys":
        return `\u179A\u1780\u1783\u17BE\u1789\u179F\u17C4\u1798\u17B7\u1793\u179F\u17D2\u1782\u17B6\u179B\u17CB\u17D6 ${m(r.keys, ", ")}`;
      case "invalid_key":
        return `\u179F\u17C4\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u1793\u17C5\u1780\u17D2\u1793\u17BB\u1784 ${r.origin}`;
      case "invalid_union":
        return "\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C";
      case "invalid_element":
        return `\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u1793\u17C5\u1780\u17D2\u1793\u17BB\u1784 ${r.origin}`;
      default:
        return "\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C";
    }
  };
}, "error");
function Er() {
  return {
    localeError: Kv()
  };
}
s(Er, "default");

// versions/4.3.6/node_modules/zod/v4/locales/kh.js
function wc() {
  return Er();
}
s(wc, "default");

// versions/4.3.6/node_modules/zod/v4/locales/ko.js
var Gv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\uBB38\uC790", verb: "to have" },
    file: { unit: "\uBC14\uC774\uD2B8", verb: "to have" },
    array: { unit: "\uAC1C", verb: "to have" },
    set: { unit: "\uAC1C", verb: "to have" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\uC785\uB825",
    email: "\uC774\uBA54\uC77C \uC8FC\uC18C",
    url: "URL",
    emoji: "\uC774\uBAA8\uC9C0",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \uB0A0\uC9DC\uC2DC\uAC04",
    date: "ISO \uB0A0\uC9DC",
    time: "ISO \uC2DC\uAC04",
    duration: "ISO \uAE30\uAC04",
    ipv4: "IPv4 \uC8FC\uC18C",
    ipv6: "IPv6 \uC8FC\uC18C",
    cidrv4: "IPv4 \uBC94\uC704",
    cidrv6: "IPv6 \uBC94\uC704",
    base64: "base64 \uC778\uCF54\uB529 \uBB38\uC790\uC5F4",
    base64url: "base64url \uC778\uCF54\uB529 \uBB38\uC790\uC5F4",
    json_string: "JSON \uBB38\uC790\uC5F4",
    e164: "E.164 \uBC88\uD638",
    jwt: "JWT",
    template_literal: "\uC785\uB825"
  }, o = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), c = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\uC798\uBABB\uB41C \uC785\uB825: \uC608\uC0C1 \uD0C0\uC785\uC740 instanceof ${r.expected}, \uBC1B\uC740 \uD0C0\uC785\uC740 ${c}\uC785\uB2C8\uB2E4` : `\uC798\uBABB\uB41C \uC785\uB825: \uC608\uC0C1 \uD0C0\uC785\uC740 ${i}, \uBC1B\uC740 \uD0C0\uC785\uC740 ${c}\uC785\uB2C8\uB2E4`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\uC798\uBABB\uB41C \uC785\uB825: \uAC12\uC740 ${y(r.values[0])} \uC774\uC5B4\uC57C \uD569\uB2C8\uB2E4` : `\uC798\uBABB\uB41C \uC635\uC158: ${m(r.values, "\uB610\uB294 ")} \uC911 \uD558\uB098\uC5EC\uC57C \uD569\uB2C8\uB2E4`;
      case "too_big": {
        let i = r.inclusive ? "\uC774\uD558" : "\uBBF8\uB9CC", a = i === "\uBBF8\uB9CC" ? "\uC774\uC5B4\uC57C \uD569\uB2C8\uB2E4" : "\uC5EC\uC57C \uD569\uB2C8\uB2E4", c = t(r.origin), u = c?.unit ?? "\uC694\uC18C";
        return c ? `${r.origin ?? "\uAC12"}\uC774 \uB108\uBB34 \uD07D\uB2C8\uB2E4: ${r.maximum.toString()}${u} ${i}${a}` : `${r.origin ?? "\uAC12"}\uC774 \uB108\uBB34 \uD07D\uB2C8\uB2E4: ${r.maximum.toString()} ${i}${a}`;
      }
      case "too_small": {
        let i = r.inclusive ? "\uC774\uC0C1" : "\uCD08\uACFC", a = i === "\uC774\uC0C1" ? "\uC774\uC5B4\uC57C \uD569\uB2C8\uB2E4" : "\uC5EC\uC57C \uD569\uB2C8\uB2E4", c = t(r.origin), u = c?.unit ?? "\uC694\uC18C";
        return c ? `${r.origin ?? "\uAC12"}\uC774 \uB108\uBB34 \uC791\uC2B5\uB2C8\uB2E4: ${r.minimum.toString()}${u} ${i}${a}` : `${r.origin ?? "\uAC12"}\uC774 \uB108\uBB34 \uC791\uC2B5\uB2C8\uB2E4: ${r.minimum.toString()} ${i}${a}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\uC798\uBABB\uB41C \uBB38\uC790\uC5F4: "${i.prefix}"(\uC73C)\uB85C \uC2DC\uC791\uD574\uC57C \uD569\uB2C8\uB2E4` : i.format === "ends_with" ? `\uC798\uBABB\uB41C \uBB38\uC790\uC5F4: "${i.suffix}"(\uC73C)\uB85C \uB05D\uB098\uC57C \uD569\uB2C8\uB2E4` : i.format === "includes" ? `\uC798\uBABB\uB41C \uBB38\uC790\uC5F4: "${i.includes}"\uC744(\uB97C) \uD3EC\uD568\uD574\uC57C \uD569\uB2C8\uB2E4` : i.format === "regex" ? `\uC798\uBABB\uB41C \uBB38\uC790\uC5F4: \uC815\uADDC\uC2DD ${i.pattern} \uD328\uD134\uACFC \uC77C\uCE58\uD574\uC57C \uD569\uB2C8\uB2E4` : `\uC798\uBABB\uB41C ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\uC798\uBABB\uB41C \uC22B\uC790: ${r.divisor}\uC758 \uBC30\uC218\uC5EC\uC57C \uD569\uB2C8\uB2E4`;
      case "unrecognized_keys":
        return `\uC778\uC2DD\uD560 \uC218 \uC5C6\uB294 \uD0A4: ${m(r.keys, ", ")}`;
      case "invalid_key":
        return `\uC798\uBABB\uB41C \uD0A4: ${r.origin}`;
      case "invalid_union":
        return "\uC798\uBABB\uB41C \uC785\uB825";
      case "invalid_element":
        return `\uC798\uBABB\uB41C \uAC12: ${r.origin}`;
      default:
        return "\uC798\uBABB\uB41C \uC785\uB825";
    }
  };
}, "error");
function kc() {
  return {
    localeError: Gv()
  };
}
s(kc, "default");

// versions/4.3.6/node_modules/zod/v4/locales/lt.js
var Ur = /* @__PURE__ */ s((e) => e.charAt(0).toUpperCase() + e.slice(1), "capitalizeFirstCharacter");
function Xf(e) {
  let t = Math.abs(e), n = t % 10, o = t % 100;
  return o >= 11 && o <= 19 || n === 0 ? "many" : n === 1 ? "one" : "few";
}
s(Xf, "getUnitTypeFromNumber");
var Xv = /* @__PURE__ */ s(() => {
  let e = {
    string: {
      unit: {
        one: "simbolis",
        few: "simboliai",
        many: "simboli\u0173"
      },
      verb: {
        smaller: {
          inclusive: "turi b\u016Bti ne ilgesn\u0117 kaip",
          notInclusive: "turi b\u016Bti trumpesn\u0117 kaip"
        },
        bigger: {
          inclusive: "turi b\u016Bti ne trumpesn\u0117 kaip",
          notInclusive: "turi b\u016Bti ilgesn\u0117 kaip"
        }
      }
    },
    file: {
      unit: {
        one: "baitas",
        few: "baitai",
        many: "bait\u0173"
      },
      verb: {
        smaller: {
          inclusive: "turi b\u016Bti ne didesnis kaip",
          notInclusive: "turi b\u016Bti ma\u017Eesnis kaip"
        },
        bigger: {
          inclusive: "turi b\u016Bti ne ma\u017Eesnis kaip",
          notInclusive: "turi b\u016Bti didesnis kaip"
        }
      }
    },
    array: {
      unit: {
        one: "element\u0105",
        few: "elementus",
        many: "element\u0173"
      },
      verb: {
        smaller: {
          inclusive: "turi tur\u0117ti ne daugiau kaip",
          notInclusive: "turi tur\u0117ti ma\u017Eiau kaip"
        },
        bigger: {
          inclusive: "turi tur\u0117ti ne ma\u017Eiau kaip",
          notInclusive: "turi tur\u0117ti daugiau kaip"
        }
      }
    },
    set: {
      unit: {
        one: "element\u0105",
        few: "elementus",
        many: "element\u0173"
      },
      verb: {
        smaller: {
          inclusive: "turi tur\u0117ti ne daugiau kaip",
          notInclusive: "turi tur\u0117ti ma\u017Eiau kaip"
        },
        bigger: {
          inclusive: "turi tur\u0117ti ne ma\u017Eiau kaip",
          notInclusive: "turi tur\u0117ti daugiau kaip"
        }
      }
    }
  };
  function t(r, i, a, c) {
    let u = e[r] ?? null;
    return u === null ? u : {
      unit: u.unit[i],
      verb: u.verb[c][a ? "inclusive" : "notInclusive"]
    };
  }
  s(t, "getSizing");
  let n = {
    regex: "\u012Fvestis",
    email: "el. pa\u0161to adresas",
    url: "URL",
    emoji: "jaustukas",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO data ir laikas",
    date: "ISO data",
    time: "ISO laikas",
    duration: "ISO trukm\u0117",
    ipv4: "IPv4 adresas",
    ipv6: "IPv6 adresas",
    cidrv4: "IPv4 tinklo prefiksas (CIDR)",
    cidrv6: "IPv6 tinklo prefiksas (CIDR)",
    base64: "base64 u\u017Ekoduota eilut\u0117",
    base64url: "base64url u\u017Ekoduota eilut\u0117",
    json_string: "JSON eilut\u0117",
    e164: "E.164 numeris",
    jwt: "JWT",
    template_literal: "\u012Fvestis"
  }, o = {
    nan: "NaN",
    number: "skai\u010Dius",
    bigint: "sveikasis skai\u010Dius",
    string: "eilut\u0117",
    boolean: "login\u0117 reik\u0161m\u0117",
    undefined: "neapibr\u0117\u017Eta reik\u0161m\u0117",
    function: "funkcija",
    symbol: "simbolis",
    array: "masyvas",
    object: "objektas",
    null: "nulin\u0117 reik\u0161m\u0117"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), c = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Gautas tipas ${c}, o tik\u0117tasi - instanceof ${r.expected}` : `Gautas tipas ${c}, o tik\u0117tasi - ${i}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Privalo b\u016Bti ${y(r.values[0])}` : `Privalo b\u016Bti vienas i\u0161 ${m(r.values, "|")} pasirinkim\u0173`;
      case "too_big": {
        let i = o[r.origin] ?? r.origin, a = t(r.origin, Xf(Number(r.maximum)), r.inclusive ?? !1, "smaller");
        if (a?.verb)
          return `${Ur(i ?? r.origin ?? "reik\u0161m\u0117")} ${a.verb} ${r.maximum.toString()} ${a.unit ?? "element\u0173"}`;
        let c = r.inclusive ? "ne didesnis kaip" : "ma\u017Eesnis kaip";
        return `${Ur(i ?? r.origin ?? "reik\u0161m\u0117")} turi b\u016Bti ${c} ${r.maximum.toString()} ${a?.unit}`;
      }
      case "too_small": {
        let i = o[r.origin] ?? r.origin, a = t(r.origin, Xf(Number(r.minimum)), r.inclusive ?? !1, "bigger");
        if (a?.verb)
          return `${Ur(i ?? r.origin ?? "reik\u0161m\u0117")} ${a.verb} ${r.minimum.toString()} ${a.unit ?? "element\u0173"}`;
        let c = r.inclusive ? "ne ma\u017Eesnis kaip" : "didesnis kaip";
        return `${Ur(i ?? r.origin ?? "reik\u0161m\u0117")} turi b\u016Bti ${c} ${r.minimum.toString()} ${a?.unit}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Eilut\u0117 privalo prasid\u0117ti "${i.prefix}"` : i.format === "ends_with" ? `Eilut\u0117 privalo pasibaigti "${i.suffix}"` : i.format === "includes" ? `Eilut\u0117 privalo \u012Ftraukti "${i.includes}"` : i.format === "regex" ? `Eilut\u0117 privalo atitikti ${i.pattern}` : `Neteisingas ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Skai\u010Dius privalo b\u016Bti ${r.divisor} kartotinis.`;
      case "unrecognized_keys":
        return `Neatpa\u017Eint${r.keys.length > 1 ? "i" : "as"} rakt${r.keys.length > 1 ? "ai" : "as"}: ${m(r.keys, ", ")}`;
      case "invalid_key":
        return "Rastas klaidingas raktas";
      case "invalid_union":
        return "Klaidinga \u012Fvestis";
      case "invalid_element": {
        let i = o[r.origin] ?? r.origin;
        return `${Ur(i ?? r.origin ?? "reik\u0161m\u0117")} turi klaiding\u0105 \u012Fvest\u012F`;
      }
      default:
        return "Klaidinga \u012Fvestis";
    }
  };
}, "error");
function zc() {
  return {
    localeError: Xv()
  };
}
s(zc, "default");

// versions/4.3.6/node_modules/zod/v4/locales/mk.js
var Qv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0437\u043D\u0430\u0446\u0438", verb: "\u0434\u0430 \u0438\u043C\u0430\u0430\u0442" },
    file: { unit: "\u0431\u0430\u0458\u0442\u0438", verb: "\u0434\u0430 \u0438\u043C\u0430\u0430\u0442" },
    array: { unit: "\u0441\u0442\u0430\u0432\u043A\u0438", verb: "\u0434\u0430 \u0438\u043C\u0430\u0430\u0442" },
    set: { unit: "\u0441\u0442\u0430\u0432\u043A\u0438", verb: "\u0434\u0430 \u0438\u043C\u0430\u0430\u0442" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u0432\u043D\u0435\u0441",
    email: "\u0430\u0434\u0440\u0435\u0441\u0430 \u043D\u0430 \u0435-\u043F\u043E\u0448\u0442\u0430",
    url: "URL",
    emoji: "\u0435\u043C\u043E\u045F\u0438",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0434\u0430\u0442\u0443\u043C \u0438 \u0432\u0440\u0435\u043C\u0435",
    date: "ISO \u0434\u0430\u0442\u0443\u043C",
    time: "ISO \u0432\u0440\u0435\u043C\u0435",
    duration: "ISO \u0432\u0440\u0435\u043C\u0435\u0442\u0440\u0430\u0435\u045A\u0435",
    ipv4: "IPv4 \u0430\u0434\u0440\u0435\u0441\u0430",
    ipv6: "IPv6 \u0430\u0434\u0440\u0435\u0441\u0430",
    cidrv4: "IPv4 \u043E\u043F\u0441\u0435\u0433",
    cidrv6: "IPv6 \u043E\u043F\u0441\u0435\u0433",
    base64: "base64-\u0435\u043D\u043A\u043E\u0434\u0438\u0440\u0430\u043D\u0430 \u043D\u0438\u0437\u0430",
    base64url: "base64url-\u0435\u043D\u043A\u043E\u0434\u0438\u0440\u0430\u043D\u0430 \u043D\u0438\u0437\u0430",
    json_string: "JSON \u043D\u0438\u0437\u0430",
    e164: "E.164 \u0431\u0440\u043E\u0458",
    jwt: "JWT",
    template_literal: "\u0432\u043D\u0435\u0441"
  }, o = {
    nan: "NaN",
    number: "\u0431\u0440\u043E\u0458",
    array: "\u043D\u0438\u0437\u0430"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), c = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u0413\u0440\u0435\u0448\u0435\u043D \u0432\u043D\u0435\u0441: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 instanceof ${r.expected}, \u043F\u0440\u0438\u043C\u0435\u043D\u043E ${c}` : `\u0413\u0440\u0435\u0448\u0435\u043D \u0432\u043D\u0435\u0441: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${i}, \u043F\u0440\u0438\u043C\u0435\u043D\u043E ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Invalid input: expected ${y(r.values[0])}` : `\u0413\u0440\u0435\u0448\u0430\u043D\u0430 \u043E\u043F\u0446\u0438\u0458\u0430: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 \u0435\u0434\u043D\u0430 ${m(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `\u041F\u0440\u0435\u043C\u043D\u043E\u0433\u0443 \u0433\u043E\u043B\u0435\u043C: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${r.origin ?? "\u0432\u0440\u0435\u0434\u043D\u043E\u0441\u0442\u0430"} \u0434\u0430 \u0438\u043C\u0430 ${i}${r.maximum.toString()} ${a.unit ?? "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0438"}` : `\u041F\u0440\u0435\u043C\u043D\u043E\u0433\u0443 \u0433\u043E\u043B\u0435\u043C: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${r.origin ?? "\u0432\u0440\u0435\u0434\u043D\u043E\u0441\u0442\u0430"} \u0434\u0430 \u0431\u0438\u0434\u0435 ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\u041F\u0440\u0435\u043C\u043D\u043E\u0433\u0443 \u043C\u0430\u043B: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${r.origin} \u0434\u0430 \u0438\u043C\u0430 ${i}${r.minimum.toString()} ${a.unit}` : `\u041F\u0440\u0435\u043C\u043D\u043E\u0433\u0443 \u043C\u0430\u043B: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${r.origin} \u0434\u0430 \u0431\u0438\u0434\u0435 ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u041D\u0435\u0432\u0430\u0436\u0435\u0447\u043A\u0430 \u043D\u0438\u0437\u0430: \u043C\u043E\u0440\u0430 \u0434\u0430 \u0437\u0430\u043F\u043E\u0447\u043D\u0443\u0432\u0430 \u0441\u043E "${i.prefix}"` : i.format === "ends_with" ? `\u041D\u0435\u0432\u0430\u0436\u0435\u0447\u043A\u0430 \u043D\u0438\u0437\u0430: \u043C\u043E\u0440\u0430 \u0434\u0430 \u0437\u0430\u0432\u0440\u0448\u0443\u0432\u0430 \u0441\u043E "${i.suffix}"` : i.format === "includes" ? `\u041D\u0435\u0432\u0430\u0436\u0435\u0447\u043A\u0430 \u043D\u0438\u0437\u0430: \u043C\u043E\u0440\u0430 \u0434\u0430 \u0432\u043A\u043B\u0443\u0447\u0443\u0432\u0430 "${i.includes}"` : i.format === "regex" ? `\u041D\u0435\u0432\u0430\u0436\u0435\u0447\u043A\u0430 \u043D\u0438\u0437\u0430: \u043C\u043E\u0440\u0430 \u0434\u0430 \u043E\u0434\u0433\u043E\u0430\u0440\u0430 \u043D\u0430 \u043F\u0430\u0442\u0435\u0440\u043D\u043E\u0442 ${i.pattern}` : `Invalid ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u0413\u0440\u0435\u0448\u0435\u043D \u0431\u0440\u043E\u0458: \u043C\u043E\u0440\u0430 \u0434\u0430 \u0431\u0438\u0434\u0435 \u0434\u0435\u043B\u0438\u0432 \u0441\u043E ${r.divisor}`;
      case "unrecognized_keys":
        return `${r.keys.length > 1 ? "\u041D\u0435\u043F\u0440\u0435\u043F\u043E\u0437\u043D\u0430\u0435\u043D\u0438 \u043A\u043B\u0443\u0447\u0435\u0432\u0438" : "\u041D\u0435\u043F\u0440\u0435\u043F\u043E\u0437\u043D\u0430\u0435\u043D \u043A\u043B\u0443\u0447"}: ${m(r.keys, ", ")}`;
      case "invalid_key":
        return `\u0413\u0440\u0435\u0448\u0435\u043D \u043A\u043B\u0443\u0447 \u0432\u043E ${r.origin}`;
      case "invalid_union":
        return "\u0413\u0440\u0435\u0448\u0435\u043D \u0432\u043D\u0435\u0441";
      case "invalid_element":
        return `\u0413\u0440\u0435\u0448\u043D\u0430 \u0432\u0440\u0435\u0434\u043D\u043E\u0441\u0442 \u0432\u043E ${r.origin}`;
      default:
        return "\u0413\u0440\u0435\u0448\u0435\u043D \u0432\u043D\u0435\u0441";
    }
  };
}, "error");
function Ic() {
  return {
    localeError: Qv()
  };
}
s(Ic, "default");

// versions/4.3.6/node_modules/zod/v4/locales/ms.js
var Hv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "aksara", verb: "mempunyai" },
    file: { unit: "bait", verb: "mempunyai" },
    array: { unit: "elemen", verb: "mempunyai" },
    set: { unit: "elemen", verb: "mempunyai" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "input",
    email: "alamat e-mel",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "tarikh masa ISO",
    date: "tarikh ISO",
    time: "masa ISO",
    duration: "tempoh ISO",
    ipv4: "alamat IPv4",
    ipv6: "alamat IPv6",
    cidrv4: "julat IPv4",
    cidrv6: "julat IPv6",
    base64: "string dikodkan base64",
    base64url: "string dikodkan base64url",
    json_string: "string JSON",
    e164: "nombor E.164",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN",
    number: "nombor"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), c = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Input tidak sah: dijangka instanceof ${r.expected}, diterima ${c}` : `Input tidak sah: dijangka ${i}, diterima ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Input tidak sah: dijangka ${y(r.values[0])}` : `Pilihan tidak sah: dijangka salah satu daripada ${m(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Terlalu besar: dijangka ${r.origin ?? "nilai"} ${a.verb} ${i}${r.maximum.toString()} ${a.unit ?? "elemen"}` : `Terlalu besar: dijangka ${r.origin ?? "nilai"} adalah ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Terlalu kecil: dijangka ${r.origin} ${a.verb} ${i}${r.minimum.toString()} ${a.unit}` : `Terlalu kecil: dijangka ${r.origin} adalah ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `String tidak sah: mesti bermula dengan "${i.prefix}"` : i.format === "ends_with" ? `String tidak sah: mesti berakhir dengan "${i.suffix}"` : i.format === "includes" ? `String tidak sah: mesti mengandungi "${i.includes}"` : i.format === "regex" ? `String tidak sah: mesti sepadan dengan corak ${i.pattern}` : `${n[i.format] ?? r.format} tidak sah`;
      }
      case "not_multiple_of":
        return `Nombor tidak sah: perlu gandaan ${r.divisor}`;
      case "unrecognized_keys":
        return `Kunci tidak dikenali: ${m(r.keys, ", ")}`;
      case "invalid_key":
        return `Kunci tidak sah dalam ${r.origin}`;
      case "invalid_union":
        return "Input tidak sah";
      case "invalid_element":
        return `Nilai tidak sah dalam ${r.origin}`;
      default:
        return "Input tidak sah";
    }
  };
}, "error");
function Sc() {
  return {
    localeError: Hv()
  };
}
s(Sc, "default");

// versions/4.3.6/node_modules/zod/v4/locales/nl.js
var Yv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "tekens", verb: "heeft" },
    file: { unit: "bytes", verb: "heeft" },
    array: { unit: "elementen", verb: "heeft" },
    set: { unit: "elementen", verb: "heeft" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "invoer",
    email: "emailadres",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datum en tijd",
    date: "ISO datum",
    time: "ISO tijd",
    duration: "ISO duur",
    ipv4: "IPv4-adres",
    ipv6: "IPv6-adres",
    cidrv4: "IPv4-bereik",
    cidrv6: "IPv6-bereik",
    base64: "base64-gecodeerde tekst",
    base64url: "base64 URL-gecodeerde tekst",
    json_string: "JSON string",
    e164: "E.164-nummer",
    jwt: "JWT",
    template_literal: "invoer"
  }, o = {
    nan: "NaN",
    number: "getal"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), c = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Ongeldige invoer: verwacht instanceof ${r.expected}, ontving ${c}` : `Ongeldige invoer: verwacht ${i}, ontving ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Ongeldige invoer: verwacht ${y(r.values[0])}` : `Ongeldige optie: verwacht \xE9\xE9n van ${m(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin), c = r.origin === "date" ? "laat" : r.origin === "string" ? "lang" : "groot";
        return a ? `Te ${c}: verwacht dat ${r.origin ?? "waarde"} ${i}${r.maximum.toString()} ${a.unit ?? "elementen"} ${a.verb}` : `Te ${c}: verwacht dat ${r.origin ?? "waarde"} ${i}${r.maximum.toString()} is`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin), c = r.origin === "date" ? "vroeg" : r.origin === "string" ? "kort" : "klein";
        return a ? `Te ${c}: verwacht dat ${r.origin} ${i}${r.minimum.toString()} ${a.unit} ${a.verb}` : `Te ${c}: verwacht dat ${r.origin} ${i}${r.minimum.toString()} is`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Ongeldige tekst: moet met "${i.prefix}" beginnen` : i.format === "ends_with" ? `Ongeldige tekst: moet op "${i.suffix}" eindigen` : i.format === "includes" ? `Ongeldige tekst: moet "${i.includes}" bevatten` : i.format === "regex" ? `Ongeldige tekst: moet overeenkomen met patroon ${i.pattern}` : `Ongeldig: ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Ongeldig getal: moet een veelvoud van ${r.divisor} zijn`;
      case "unrecognized_keys":
        return `Onbekende key${r.keys.length > 1 ? "s" : ""}: ${m(r.keys, ", ")}`;
      case "invalid_key":
        return `Ongeldige key in ${r.origin}`;
      case "invalid_union":
        return "Ongeldige invoer";
      case "invalid_element":
        return `Ongeldige waarde in ${r.origin}`;
      default:
        return "Ongeldige invoer";
    }
  };
}, "error");
function jc() {
  return {
    localeError: Yv()
  };
}
s(jc, "default");

// versions/4.3.6/node_modules/zod/v4/locales/no.js
var ey = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "tegn", verb: "\xE5 ha" },
    file: { unit: "bytes", verb: "\xE5 ha" },
    array: { unit: "elementer", verb: "\xE5 inneholde" },
    set: { unit: "elementer", verb: "\xE5 inneholde" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "input",
    email: "e-postadresse",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO dato- og klokkeslett",
    date: "ISO-dato",
    time: "ISO-klokkeslett",
    duration: "ISO-varighet",
    ipv4: "IPv4-omr\xE5de",
    ipv6: "IPv6-omr\xE5de",
    cidrv4: "IPv4-spekter",
    cidrv6: "IPv6-spekter",
    base64: "base64-enkodet streng",
    base64url: "base64url-enkodet streng",
    json_string: "JSON-streng",
    e164: "E.164-nummer",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN",
    number: "tall",
    array: "liste"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), c = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Ugyldig input: forventet instanceof ${r.expected}, fikk ${c}` : `Ugyldig input: forventet ${i}, fikk ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Ugyldig verdi: forventet ${y(r.values[0])}` : `Ugyldig valg: forventet en av ${m(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `For stor(t): forventet ${r.origin ?? "value"} til \xE5 ha ${i}${r.maximum.toString()} ${a.unit ?? "elementer"}` : `For stor(t): forventet ${r.origin ?? "value"} til \xE5 ha ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `For lite(n): forventet ${r.origin} til \xE5 ha ${i}${r.minimum.toString()} ${a.unit}` : `For lite(n): forventet ${r.origin} til \xE5 ha ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Ugyldig streng: m\xE5 starte med "${i.prefix}"` : i.format === "ends_with" ? `Ugyldig streng: m\xE5 ende med "${i.suffix}"` : i.format === "includes" ? `Ugyldig streng: m\xE5 inneholde "${i.includes}"` : i.format === "regex" ? `Ugyldig streng: m\xE5 matche m\xF8nsteret ${i.pattern}` : `Ugyldig ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Ugyldig tall: m\xE5 v\xE6re et multiplum av ${r.divisor}`;
      case "unrecognized_keys":
        return `${r.keys.length > 1 ? "Ukjente n\xF8kler" : "Ukjent n\xF8kkel"}: ${m(r.keys, ", ")}`;
      case "invalid_key":
        return `Ugyldig n\xF8kkel i ${r.origin}`;
      case "invalid_union":
        return "Ugyldig input";
      case "invalid_element":
        return `Ugyldig verdi i ${r.origin}`;
      default:
        return "Ugyldig input";
    }
  };
}, "error");
function Oc() {
  return {
    localeError: ey()
  };
}
s(Oc, "default");

// versions/4.3.6/node_modules/zod/v4/locales/ota.js
var ty = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "harf", verb: "olmal\u0131d\u0131r" },
    file: { unit: "bayt", verb: "olmal\u0131d\u0131r" },
    array: { unit: "unsur", verb: "olmal\u0131d\u0131r" },
    set: { unit: "unsur", verb: "olmal\u0131d\u0131r" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "giren",
    email: "epostag\xE2h",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO heng\xE2m\u0131",
    date: "ISO tarihi",
    time: "ISO zaman\u0131",
    duration: "ISO m\xFCddeti",
    ipv4: "IPv4 ni\u015F\xE2n\u0131",
    ipv6: "IPv6 ni\u015F\xE2n\u0131",
    cidrv4: "IPv4 menzili",
    cidrv6: "IPv6 menzili",
    base64: "base64-\u015Fifreli metin",
    base64url: "base64url-\u015Fifreli metin",
    json_string: "JSON metin",
    e164: "E.164 say\u0131s\u0131",
    jwt: "JWT",
    template_literal: "giren"
  }, o = {
    nan: "NaN",
    number: "numara",
    array: "saf",
    null: "gayb"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), c = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `F\xE2sit giren: umulan instanceof ${r.expected}, al\u0131nan ${c}` : `F\xE2sit giren: umulan ${i}, al\u0131nan ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `F\xE2sit giren: umulan ${y(r.values[0])}` : `F\xE2sit tercih: m\xFBteberler ${m(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Fazla b\xFCy\xFCk: ${r.origin ?? "value"}, ${i}${r.maximum.toString()} ${a.unit ?? "elements"} sahip olmal\u0131yd\u0131.` : `Fazla b\xFCy\xFCk: ${r.origin ?? "value"}, ${i}${r.maximum.toString()} olmal\u0131yd\u0131.`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Fazla k\xFC\xE7\xFCk: ${r.origin}, ${i}${r.minimum.toString()} ${a.unit} sahip olmal\u0131yd\u0131.` : `Fazla k\xFC\xE7\xFCk: ${r.origin}, ${i}${r.minimum.toString()} olmal\u0131yd\u0131.`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `F\xE2sit metin: "${i.prefix}" ile ba\u015Flamal\u0131.` : i.format === "ends_with" ? `F\xE2sit metin: "${i.suffix}" ile bitmeli.` : i.format === "includes" ? `F\xE2sit metin: "${i.includes}" ihtiv\xE2 etmeli.` : i.format === "regex" ? `F\xE2sit metin: ${i.pattern} nak\u015F\u0131na uymal\u0131.` : `F\xE2sit ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `F\xE2sit say\u0131: ${r.divisor} kat\u0131 olmal\u0131yd\u0131.`;
      case "unrecognized_keys":
        return `Tan\u0131nmayan anahtar ${r.keys.length > 1 ? "s" : ""}: ${m(r.keys, ", ")}`;
      case "invalid_key":
        return `${r.origin} i\xE7in tan\u0131nmayan anahtar var.`;
      case "invalid_union":
        return "Giren tan\u0131namad\u0131.";
      case "invalid_element":
        return `${r.origin} i\xE7in tan\u0131nmayan k\u0131ymet var.`;
      default:
        return "K\u0131ymet tan\u0131namad\u0131.";
    }
  };
}, "error");
function Pc() {
  return {
    localeError: ty()
  };
}
s(Pc, "default");

// versions/4.3.6/node_modules/zod/v4/locales/ps.js
var ry = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u062A\u0648\u06A9\u064A", verb: "\u0648\u0644\u0631\u064A" },
    file: { unit: "\u0628\u0627\u06CC\u067C\u0633", verb: "\u0648\u0644\u0631\u064A" },
    array: { unit: "\u062A\u0648\u06A9\u064A", verb: "\u0648\u0644\u0631\u064A" },
    set: { unit: "\u062A\u0648\u06A9\u064A", verb: "\u0648\u0644\u0631\u064A" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u0648\u0631\u0648\u062F\u064A",
    email: "\u0628\u0631\u06CC\u069A\u0646\u0627\u0644\u06CC\u06A9",
    url: "\u06CC\u0648 \u0622\u0631 \u0627\u0644",
    emoji: "\u0627\u06CC\u0645\u0648\u062C\u064A",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u0646\u06CC\u067C\u0647 \u0627\u0648 \u0648\u062E\u062A",
    date: "\u0646\u06D0\u067C\u0647",
    time: "\u0648\u062E\u062A",
    duration: "\u0645\u0648\u062F\u0647",
    ipv4: "\u062F IPv4 \u067E\u062A\u0647",
    ipv6: "\u062F IPv6 \u067E\u062A\u0647",
    cidrv4: "\u062F IPv4 \u0633\u0627\u062D\u0647",
    cidrv6: "\u062F IPv6 \u0633\u0627\u062D\u0647",
    base64: "base64-encoded \u0645\u062A\u0646",
    base64url: "base64url-encoded \u0645\u062A\u0646",
    json_string: "JSON \u0645\u062A\u0646",
    e164: "\u062F E.164 \u0634\u0645\u06D0\u0631\u0647",
    jwt: "JWT",
    template_literal: "\u0648\u0631\u0648\u062F\u064A"
  }, o = {
    nan: "NaN",
    number: "\u0639\u062F\u062F",
    array: "\u0627\u0631\u06D0"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), c = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u0646\u0627\u0633\u0645 \u0648\u0631\u0648\u062F\u064A: \u0628\u0627\u06CC\u062F instanceof ${r.expected} \u0648\u0627\u06CC, \u0645\u06AB\u0631 ${c} \u062A\u0631\u0644\u0627\u0633\u0647 \u0634\u0648` : `\u0646\u0627\u0633\u0645 \u0648\u0631\u0648\u062F\u064A: \u0628\u0627\u06CC\u062F ${i} \u0648\u0627\u06CC, \u0645\u06AB\u0631 ${c} \u062A\u0631\u0644\u0627\u0633\u0647 \u0634\u0648`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u0646\u0627\u0633\u0645 \u0648\u0631\u0648\u062F\u064A: \u0628\u0627\u06CC\u062F ${y(r.values[0])} \u0648\u0627\u06CC` : `\u0646\u0627\u0633\u0645 \u0627\u0646\u062A\u062E\u0627\u0628: \u0628\u0627\u06CC\u062F \u06CC\u0648 \u0644\u0647 ${m(r.values, "|")} \u0685\u062E\u0647 \u0648\u0627\u06CC`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `\u0689\u06CC\u0631 \u0644\u0648\u06CC: ${r.origin ?? "\u0627\u0631\u0632\u069A\u062A"} \u0628\u0627\u06CC\u062F ${i}${r.maximum.toString()} ${a.unit ?? "\u0639\u0646\u0635\u0631\u0648\u0646\u0647"} \u0648\u0644\u0631\u064A` : `\u0689\u06CC\u0631 \u0644\u0648\u06CC: ${r.origin ?? "\u0627\u0631\u0632\u069A\u062A"} \u0628\u0627\u06CC\u062F ${i}${r.maximum.toString()} \u0648\u064A`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\u0689\u06CC\u0631 \u06A9\u0648\u0686\u0646\u06CC: ${r.origin} \u0628\u0627\u06CC\u062F ${i}${r.minimum.toString()} ${a.unit} \u0648\u0644\u0631\u064A` : `\u0689\u06CC\u0631 \u06A9\u0648\u0686\u0646\u06CC: ${r.origin} \u0628\u0627\u06CC\u062F ${i}${r.minimum.toString()} \u0648\u064A`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u0646\u0627\u0633\u0645 \u0645\u062A\u0646: \u0628\u0627\u06CC\u062F \u062F "${i.prefix}" \u0633\u0631\u0647 \u067E\u06CC\u0644 \u0634\u064A` : i.format === "ends_with" ? `\u0646\u0627\u0633\u0645 \u0645\u062A\u0646: \u0628\u0627\u06CC\u062F \u062F "${i.suffix}" \u0633\u0631\u0647 \u067E\u0627\u06CC \u062A\u0647 \u0648\u0631\u0633\u064A\u0696\u064A` : i.format === "includes" ? `\u0646\u0627\u0633\u0645 \u0645\u062A\u0646: \u0628\u0627\u06CC\u062F "${i.includes}" \u0648\u0644\u0631\u064A` : i.format === "regex" ? `\u0646\u0627\u0633\u0645 \u0645\u062A\u0646: \u0628\u0627\u06CC\u062F \u062F ${i.pattern} \u0633\u0631\u0647 \u0645\u0637\u0627\u0628\u0642\u062A \u0648\u0644\u0631\u064A` : `${n[i.format] ?? r.format} \u0646\u0627\u0633\u0645 \u062F\u06CC`;
      }
      case "not_multiple_of":
        return `\u0646\u0627\u0633\u0645 \u0639\u062F\u062F: \u0628\u0627\u06CC\u062F \u062F ${r.divisor} \u0645\u0636\u0631\u0628 \u0648\u064A`;
      case "unrecognized_keys":
        return `\u0646\u0627\u0633\u0645 ${r.keys.length > 1 ? "\u06A9\u0644\u06CC\u0689\u0648\u0646\u0647" : "\u06A9\u0644\u06CC\u0689"}: ${m(r.keys, ", ")}`;
      case "invalid_key":
        return `\u0646\u0627\u0633\u0645 \u06A9\u0644\u06CC\u0689 \u067E\u0647 ${r.origin} \u06A9\u06D0`;
      case "invalid_union":
        return "\u0646\u0627\u0633\u0645\u0647 \u0648\u0631\u0648\u062F\u064A";
      case "invalid_element":
        return `\u0646\u0627\u0633\u0645 \u0639\u0646\u0635\u0631 \u067E\u0647 ${r.origin} \u06A9\u06D0`;
      default:
        return "\u0646\u0627\u0633\u0645\u0647 \u0648\u0631\u0648\u062F\u064A";
    }
  };
}, "error");
function Tc() {
  return {
    localeError: ry()
  };
}
s(Tc, "default");

// versions/4.3.6/node_modules/zod/v4/locales/pl.js
var ny = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "znak\xF3w", verb: "mie\u0107" },
    file: { unit: "bajt\xF3w", verb: "mie\u0107" },
    array: { unit: "element\xF3w", verb: "mie\u0107" },
    set: { unit: "element\xF3w", verb: "mie\u0107" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "wyra\u017Cenie",
    email: "adres email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "data i godzina w formacie ISO",
    date: "data w formacie ISO",
    time: "godzina w formacie ISO",
    duration: "czas trwania ISO",
    ipv4: "adres IPv4",
    ipv6: "adres IPv6",
    cidrv4: "zakres IPv4",
    cidrv6: "zakres IPv6",
    base64: "ci\u0105g znak\xF3w zakodowany w formacie base64",
    base64url: "ci\u0105g znak\xF3w zakodowany w formacie base64url",
    json_string: "ci\u0105g znak\xF3w w formacie JSON",
    e164: "liczba E.164",
    jwt: "JWT",
    template_literal: "wej\u015Bcie"
  }, o = {
    nan: "NaN",
    number: "liczba",
    array: "tablica"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), c = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Nieprawid\u0142owe dane wej\u015Bciowe: oczekiwano instanceof ${r.expected}, otrzymano ${c}` : `Nieprawid\u0142owe dane wej\u015Bciowe: oczekiwano ${i}, otrzymano ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Nieprawid\u0142owe dane wej\u015Bciowe: oczekiwano ${y(r.values[0])}` : `Nieprawid\u0142owa opcja: oczekiwano jednej z warto\u015Bci ${m(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Za du\u017Ca warto\u015B\u0107: oczekiwano, \u017Ce ${r.origin ?? "warto\u015B\u0107"} b\u0119dzie mie\u0107 ${i}${r.maximum.toString()} ${a.unit ?? "element\xF3w"}` : `Zbyt du\u017C(y/a/e): oczekiwano, \u017Ce ${r.origin ?? "warto\u015B\u0107"} b\u0119dzie wynosi\u0107 ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Za ma\u0142a warto\u015B\u0107: oczekiwano, \u017Ce ${r.origin ?? "warto\u015B\u0107"} b\u0119dzie mie\u0107 ${i}${r.minimum.toString()} ${a.unit ?? "element\xF3w"}` : `Zbyt ma\u0142(y/a/e): oczekiwano, \u017Ce ${r.origin ?? "warto\u015B\u0107"} b\u0119dzie wynosi\u0107 ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Nieprawid\u0142owy ci\u0105g znak\xF3w: musi zaczyna\u0107 si\u0119 od "${i.prefix}"` : i.format === "ends_with" ? `Nieprawid\u0142owy ci\u0105g znak\xF3w: musi ko\u0144czy\u0107 si\u0119 na "${i.suffix}"` : i.format === "includes" ? `Nieprawid\u0142owy ci\u0105g znak\xF3w: musi zawiera\u0107 "${i.includes}"` : i.format === "regex" ? `Nieprawid\u0142owy ci\u0105g znak\xF3w: musi odpowiada\u0107 wzorcowi ${i.pattern}` : `Nieprawid\u0142ow(y/a/e) ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Nieprawid\u0142owa liczba: musi by\u0107 wielokrotno\u015Bci\u0105 ${r.divisor}`;
      case "unrecognized_keys":
        return `Nierozpoznane klucze${r.keys.length > 1 ? "s" : ""}: ${m(r.keys, ", ")}`;
      case "invalid_key":
        return `Nieprawid\u0142owy klucz w ${r.origin}`;
      case "invalid_union":
        return "Nieprawid\u0142owe dane wej\u015Bciowe";
      case "invalid_element":
        return `Nieprawid\u0142owa warto\u015B\u0107 w ${r.origin}`;
      default:
        return "Nieprawid\u0142owe dane wej\u015Bciowe";
    }
  };
}, "error");
function Ec() {
  return {
    localeError: ny()
  };
}
s(Ec, "default");

// versions/4.3.6/node_modules/zod/v4/locales/pt.js
var oy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "caracteres", verb: "ter" },
    file: { unit: "bytes", verb: "ter" },
    array: { unit: "itens", verb: "ter" },
    set: { unit: "itens", verb: "ter" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "padr\xE3o",
    email: "endere\xE7o de e-mail",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "data e hora ISO",
    date: "data ISO",
    time: "hora ISO",
    duration: "dura\xE7\xE3o ISO",
    ipv4: "endere\xE7o IPv4",
    ipv6: "endere\xE7o IPv6",
    cidrv4: "faixa de IPv4",
    cidrv6: "faixa de IPv6",
    base64: "texto codificado em base64",
    base64url: "URL codificada em base64",
    json_string: "texto JSON",
    e164: "n\xFAmero E.164",
    jwt: "JWT",
    template_literal: "entrada"
  }, o = {
    nan: "NaN",
    number: "n\xFAmero",
    null: "nulo"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), c = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Tipo inv\xE1lido: esperado instanceof ${r.expected}, recebido ${c}` : `Tipo inv\xE1lido: esperado ${i}, recebido ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Entrada inv\xE1lida: esperado ${y(r.values[0])}` : `Op\xE7\xE3o inv\xE1lida: esperada uma das ${m(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Muito grande: esperado que ${r.origin ?? "valor"} tivesse ${i}${r.maximum.toString()} ${a.unit ?? "elementos"}` : `Muito grande: esperado que ${r.origin ?? "valor"} fosse ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Muito pequeno: esperado que ${r.origin} tivesse ${i}${r.minimum.toString()} ${a.unit}` : `Muito pequeno: esperado que ${r.origin} fosse ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Texto inv\xE1lido: deve come\xE7ar com "${i.prefix}"` : i.format === "ends_with" ? `Texto inv\xE1lido: deve terminar com "${i.suffix}"` : i.format === "includes" ? `Texto inv\xE1lido: deve incluir "${i.includes}"` : i.format === "regex" ? `Texto inv\xE1lido: deve corresponder ao padr\xE3o ${i.pattern}` : `${n[i.format] ?? r.format} inv\xE1lido`;
      }
      case "not_multiple_of":
        return `N\xFAmero inv\xE1lido: deve ser m\xFAltiplo de ${r.divisor}`;
      case "unrecognized_keys":
        return `Chave${r.keys.length > 1 ? "s" : ""} desconhecida${r.keys.length > 1 ? "s" : ""}: ${m(r.keys, ", ")}`;
      case "invalid_key":
        return `Chave inv\xE1lida em ${r.origin}`;
      case "invalid_union":
        return "Entrada inv\xE1lida";
      case "invalid_element":
        return `Valor inv\xE1lido em ${r.origin}`;
      default:
        return "Campo inv\xE1lido";
    }
  };
}, "error");
function Uc() {
  return {
    localeError: oy()
  };
}
s(Uc, "default");

// versions/4.3.6/node_modules/zod/v4/locales/ru.js
function Qf(e, t, n, o) {
  let r = Math.abs(e), i = r % 10, a = r % 100;
  return a >= 11 && a <= 19 ? o : i === 1 ? t : i >= 2 && i <= 4 ? n : o;
}
s(Qf, "getRussianPlural");
var iy = /* @__PURE__ */ s(() => {
  let e = {
    string: {
      unit: {
        one: "\u0441\u0438\u043C\u0432\u043E\u043B",
        few: "\u0441\u0438\u043C\u0432\u043E\u043B\u0430",
        many: "\u0441\u0438\u043C\u0432\u043E\u043B\u043E\u0432"
      },
      verb: "\u0438\u043C\u0435\u0442\u044C"
    },
    file: {
      unit: {
        one: "\u0431\u0430\u0439\u0442",
        few: "\u0431\u0430\u0439\u0442\u0430",
        many: "\u0431\u0430\u0439\u0442"
      },
      verb: "\u0438\u043C\u0435\u0442\u044C"
    },
    array: {
      unit: {
        one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
        few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430",
        many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u043E\u0432"
      },
      verb: "\u0438\u043C\u0435\u0442\u044C"
    },
    set: {
      unit: {
        one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
        few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430",
        many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u043E\u0432"
      },
      verb: "\u0438\u043C\u0435\u0442\u044C"
    }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u0432\u0432\u043E\u0434",
    email: "email \u0430\u0434\u0440\u0435\u0441",
    url: "URL",
    emoji: "\u044D\u043C\u043E\u0434\u0437\u0438",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0434\u0430\u0442\u0430 \u0438 \u0432\u0440\u0435\u043C\u044F",
    date: "ISO \u0434\u0430\u0442\u0430",
    time: "ISO \u0432\u0440\u0435\u043C\u044F",
    duration: "ISO \u0434\u043B\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C",
    ipv4: "IPv4 \u0430\u0434\u0440\u0435\u0441",
    ipv6: "IPv6 \u0430\u0434\u0440\u0435\u0441",
    cidrv4: "IPv4 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D",
    cidrv6: "IPv6 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D",
    base64: "\u0441\u0442\u0440\u043E\u043A\u0430 \u0432 \u0444\u043E\u0440\u043C\u0430\u0442\u0435 base64",
    base64url: "\u0441\u0442\u0440\u043E\u043A\u0430 \u0432 \u0444\u043E\u0440\u043C\u0430\u0442\u0435 base64url",
    json_string: "JSON \u0441\u0442\u0440\u043E\u043A\u0430",
    e164: "\u043D\u043E\u043C\u0435\u0440 E.164",
    jwt: "JWT",
    template_literal: "\u0432\u0432\u043E\u0434"
  }, o = {
    nan: "NaN",
    number: "\u0447\u0438\u0441\u043B\u043E",
    array: "\u043C\u0430\u0441\u0441\u0438\u0432"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), c = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0432\u0432\u043E\u0434: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C instanceof ${r.expected}, \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u043E ${c}` : `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0432\u0432\u043E\u0434: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C ${i}, \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u043E ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0432\u0432\u043E\u0434: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C ${y(r.values[0])}` : `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0432\u0430\u0440\u0438\u0430\u043D\u0442: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C \u043E\u0434\u043D\u043E \u0438\u0437 ${m(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        if (a) {
          let c = Number(r.maximum), u = Qf(c, a.unit.one, a.unit.few, a.unit.many);
          return `\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C, \u0447\u0442\u043E ${r.origin ?? "\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435"} \u0431\u0443\u0434\u0435\u0442 \u0438\u043C\u0435\u0442\u044C ${i}${r.maximum.toString()} ${u}`;
        }
        return `\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C, \u0447\u0442\u043E ${r.origin ?? "\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435"} \u0431\u0443\u0434\u0435\u0442 ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        if (a) {
          let c = Number(r.minimum), u = Qf(c, a.unit.one, a.unit.few, a.unit.many);
          return `\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u043C\u0430\u043B\u0435\u043D\u044C\u043A\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C, \u0447\u0442\u043E ${r.origin} \u0431\u0443\u0434\u0435\u0442 \u0438\u043C\u0435\u0442\u044C ${i}${r.minimum.toString()} ${u}`;
        }
        return `\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u043C\u0430\u043B\u0435\u043D\u044C\u043A\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C, \u0447\u0442\u043E ${r.origin} \u0431\u0443\u0434\u0435\u0442 ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u0441\u0442\u0440\u043E\u043A\u0430: \u0434\u043E\u043B\u0436\u043D\u0430 \u043D\u0430\u0447\u0438\u043D\u0430\u0442\u044C\u0441\u044F \u0441 "${i.prefix}"` : i.format === "ends_with" ? `\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u0441\u0442\u0440\u043E\u043A\u0430: \u0434\u043E\u043B\u0436\u043D\u0430 \u0437\u0430\u043A\u0430\u043D\u0447\u0438\u0432\u0430\u0442\u044C\u0441\u044F \u043D\u0430 "${i.suffix}"` : i.format === "includes" ? `\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u0441\u0442\u0440\u043E\u043A\u0430: \u0434\u043E\u043B\u0436\u043D\u0430 \u0441\u043E\u0434\u0435\u0440\u0436\u0430\u0442\u044C "${i.includes}"` : i.format === "regex" ? `\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u0441\u0442\u0440\u043E\u043A\u0430: \u0434\u043E\u043B\u0436\u043D\u0430 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u043E\u0432\u0430\u0442\u044C \u0448\u0430\u0431\u043B\u043E\u043D\u0443 ${i.pattern}` : `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u041D\u0435\u0432\u0435\u0440\u043D\u043E\u0435 \u0447\u0438\u0441\u043B\u043E: \u0434\u043E\u043B\u0436\u043D\u043E \u0431\u044B\u0442\u044C \u043A\u0440\u0430\u0442\u043D\u044B\u043C ${r.divisor}`;
      case "unrecognized_keys":
        return `\u041D\u0435\u0440\u0430\u0441\u043F\u043E\u0437\u043D\u0430\u043D\u043D${r.keys.length > 1 ? "\u044B\u0435" : "\u044B\u0439"} \u043A\u043B\u044E\u0447${r.keys.length > 1 ? "\u0438" : ""}: ${m(r.keys, ", ")}`;
      case "invalid_key":
        return `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u043A\u043B\u044E\u0447 \u0432 ${r.origin}`;
      case "invalid_union":
        return "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0435 \u0432\u0445\u043E\u0434\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435";
      case "invalid_element":
        return `\u041D\u0435\u0432\u0435\u0440\u043D\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u0432 ${r.origin}`;
      default:
        return "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0435 \u0432\u0445\u043E\u0434\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435";
    }
  };
}, "error");
function Dc() {
  return {
    localeError: iy()
  };
}
s(Dc, "default");

// versions/4.3.6/node_modules/zod/v4/locales/sl.js
var ay = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "znakov", verb: "imeti" },
    file: { unit: "bajtov", verb: "imeti" },
    array: { unit: "elementov", verb: "imeti" },
    set: { unit: "elementov", verb: "imeti" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "vnos",
    email: "e-po\u0161tni naslov",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datum in \u010Das",
    date: "ISO datum",
    time: "ISO \u010Das",
    duration: "ISO trajanje",
    ipv4: "IPv4 naslov",
    ipv6: "IPv6 naslov",
    cidrv4: "obseg IPv4",
    cidrv6: "obseg IPv6",
    base64: "base64 kodiran niz",
    base64url: "base64url kodiran niz",
    json_string: "JSON niz",
    e164: "E.164 \u0161tevilka",
    jwt: "JWT",
    template_literal: "vnos"
  }, o = {
    nan: "NaN",
    number: "\u0161tevilo",
    array: "tabela"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), c = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Neveljaven vnos: pri\u010Dakovano instanceof ${r.expected}, prejeto ${c}` : `Neveljaven vnos: pri\u010Dakovano ${i}, prejeto ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Neveljaven vnos: pri\u010Dakovano ${y(r.values[0])}` : `Neveljavna mo\u017Enost: pri\u010Dakovano eno izmed ${m(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Preveliko: pri\u010Dakovano, da bo ${r.origin ?? "vrednost"} imelo ${i}${r.maximum.toString()} ${a.unit ?? "elementov"}` : `Preveliko: pri\u010Dakovano, da bo ${r.origin ?? "vrednost"} ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Premajhno: pri\u010Dakovano, da bo ${r.origin} imelo ${i}${r.minimum.toString()} ${a.unit}` : `Premajhno: pri\u010Dakovano, da bo ${r.origin} ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Neveljaven niz: mora se za\u010Deti z "${i.prefix}"` : i.format === "ends_with" ? `Neveljaven niz: mora se kon\u010Dati z "${i.suffix}"` : i.format === "includes" ? `Neveljaven niz: mora vsebovati "${i.includes}"` : i.format === "regex" ? `Neveljaven niz: mora ustrezati vzorcu ${i.pattern}` : `Neveljaven ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Neveljavno \u0161tevilo: mora biti ve\u010Dkratnik ${r.divisor}`;
      case "unrecognized_keys":
        return `Neprepoznan${r.keys.length > 1 ? "i klju\u010Di" : " klju\u010D"}: ${m(r.keys, ", ")}`;
      case "invalid_key":
        return `Neveljaven klju\u010D v ${r.origin}`;
      case "invalid_union":
        return "Neveljaven vnos";
      case "invalid_element":
        return `Neveljavna vrednost v ${r.origin}`;
      default:
        return "Neveljaven vnos";
    }
  };
}, "error");
function Nc() {
  return {
    localeError: ay()
  };
}
s(Nc, "default");

// versions/4.3.6/node_modules/zod/v4/locales/sv.js
var sy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "tecken", verb: "att ha" },
    file: { unit: "bytes", verb: "att ha" },
    array: { unit: "objekt", verb: "att inneh\xE5lla" },
    set: { unit: "objekt", verb: "att inneh\xE5lla" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "regulj\xE4rt uttryck",
    email: "e-postadress",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO-datum och tid",
    date: "ISO-datum",
    time: "ISO-tid",
    duration: "ISO-varaktighet",
    ipv4: "IPv4-intervall",
    ipv6: "IPv6-intervall",
    cidrv4: "IPv4-spektrum",
    cidrv6: "IPv6-spektrum",
    base64: "base64-kodad str\xE4ng",
    base64url: "base64url-kodad str\xE4ng",
    json_string: "JSON-str\xE4ng",
    e164: "E.164-nummer",
    jwt: "JWT",
    template_literal: "mall-literal"
  }, o = {
    nan: "NaN",
    number: "antal",
    array: "lista"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), c = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Ogiltig inmatning: f\xF6rv\xE4ntat instanceof ${r.expected}, fick ${c}` : `Ogiltig inmatning: f\xF6rv\xE4ntat ${i}, fick ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Ogiltig inmatning: f\xF6rv\xE4ntat ${y(r.values[0])}` : `Ogiltigt val: f\xF6rv\xE4ntade en av ${m(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `F\xF6r stor(t): f\xF6rv\xE4ntade ${r.origin ?? "v\xE4rdet"} att ha ${i}${r.maximum.toString()} ${a.unit ?? "element"}` : `F\xF6r stor(t): f\xF6rv\xE4ntat ${r.origin ?? "v\xE4rdet"} att ha ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `F\xF6r lite(t): f\xF6rv\xE4ntade ${r.origin ?? "v\xE4rdet"} att ha ${i}${r.minimum.toString()} ${a.unit}` : `F\xF6r lite(t): f\xF6rv\xE4ntade ${r.origin ?? "v\xE4rdet"} att ha ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Ogiltig str\xE4ng: m\xE5ste b\xF6rja med "${i.prefix}"` : i.format === "ends_with" ? `Ogiltig str\xE4ng: m\xE5ste sluta med "${i.suffix}"` : i.format === "includes" ? `Ogiltig str\xE4ng: m\xE5ste inneh\xE5lla "${i.includes}"` : i.format === "regex" ? `Ogiltig str\xE4ng: m\xE5ste matcha m\xF6nstret "${i.pattern}"` : `Ogiltig(t) ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Ogiltigt tal: m\xE5ste vara en multipel av ${r.divisor}`;
      case "unrecognized_keys":
        return `${r.keys.length > 1 ? "Ok\xE4nda nycklar" : "Ok\xE4nd nyckel"}: ${m(r.keys, ", ")}`;
      case "invalid_key":
        return `Ogiltig nyckel i ${r.origin ?? "v\xE4rdet"}`;
      case "invalid_union":
        return "Ogiltig input";
      case "invalid_element":
        return `Ogiltigt v\xE4rde i ${r.origin ?? "v\xE4rdet"}`;
      default:
        return "Ogiltig input";
    }
  };
}, "error");
function Zc() {
  return {
    localeError: sy()
  };
}
s(Zc, "default");

// versions/4.3.6/node_modules/zod/v4/locales/ta.js
var cy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0B8E\u0BB4\u0BC1\u0BA4\u0BCD\u0BA4\u0BC1\u0B95\u0BCD\u0B95\u0BB3\u0BCD", verb: "\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD" },
    file: { unit: "\u0BAA\u0BC8\u0B9F\u0BCD\u0B9F\u0BC1\u0B95\u0BB3\u0BCD", verb: "\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD" },
    array: { unit: "\u0B89\u0BB1\u0BC1\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD", verb: "\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD" },
    set: { unit: "\u0B89\u0BB1\u0BC1\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD", verb: "\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1",
    email: "\u0BAE\u0BBF\u0BA9\u0BCD\u0BA9\u0B9E\u0BCD\u0B9A\u0BB2\u0BCD \u0BAE\u0BC1\u0B95\u0BB5\u0BB0\u0BBF",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0BA4\u0BC7\u0BA4\u0BBF \u0BA8\u0BC7\u0BB0\u0BAE\u0BCD",
    date: "ISO \u0BA4\u0BC7\u0BA4\u0BBF",
    time: "ISO \u0BA8\u0BC7\u0BB0\u0BAE\u0BCD",
    duration: "ISO \u0B95\u0BBE\u0BB2 \u0B85\u0BB3\u0BB5\u0BC1",
    ipv4: "IPv4 \u0BAE\u0BC1\u0B95\u0BB5\u0BB0\u0BBF",
    ipv6: "IPv6 \u0BAE\u0BC1\u0B95\u0BB5\u0BB0\u0BBF",
    cidrv4: "IPv4 \u0BB5\u0BB0\u0BAE\u0BCD\u0BAA\u0BC1",
    cidrv6: "IPv6 \u0BB5\u0BB0\u0BAE\u0BCD\u0BAA\u0BC1",
    base64: "base64-encoded \u0B9A\u0BB0\u0BAE\u0BCD",
    base64url: "base64url-encoded \u0B9A\u0BB0\u0BAE\u0BCD",
    json_string: "JSON \u0B9A\u0BB0\u0BAE\u0BCD",
    e164: "E.164 \u0B8E\u0BA3\u0BCD",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN",
    number: "\u0B8E\u0BA3\u0BCD",
    array: "\u0B85\u0BA3\u0BBF",
    null: "\u0BB5\u0BC6\u0BB1\u0BC1\u0BAE\u0BC8"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), c = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 instanceof ${r.expected}, \u0BAA\u0BC6\u0BB1\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${c}` : `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${i}, \u0BAA\u0BC6\u0BB1\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${y(r.values[0])}` : `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0BB5\u0BBF\u0BB0\u0BC1\u0BAA\u0BCD\u0BAA\u0BAE\u0BCD: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${m(r.values, "|")} \u0B87\u0BB2\u0BCD \u0B92\u0BA9\u0BCD\u0BB1\u0BC1`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `\u0BAE\u0BBF\u0B95 \u0BAA\u0BC6\u0BB0\u0BBF\u0BAF\u0BA4\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${r.origin ?? "\u0BAE\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1"} ${i}${r.maximum.toString()} ${a.unit ?? "\u0B89\u0BB1\u0BC1\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD"} \u0B86\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : `\u0BAE\u0BBF\u0B95 \u0BAA\u0BC6\u0BB0\u0BBF\u0BAF\u0BA4\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${r.origin ?? "\u0BAE\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1"} ${i}${r.maximum.toString()} \u0B86\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\u0BAE\u0BBF\u0B95\u0B9A\u0BCD \u0B9A\u0BBF\u0BB1\u0BBF\u0BAF\u0BA4\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${r.origin} ${i}${r.minimum.toString()} ${a.unit} \u0B86\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : `\u0BAE\u0BBF\u0B95\u0B9A\u0BCD \u0B9A\u0BBF\u0BB1\u0BBF\u0BAF\u0BA4\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${r.origin} ${i}${r.minimum.toString()} \u0B86\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B9A\u0BB0\u0BAE\u0BCD: "${i.prefix}" \u0B87\u0BB2\u0BCD \u0BA4\u0BCA\u0B9F\u0B99\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : i.format === "ends_with" ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B9A\u0BB0\u0BAE\u0BCD: "${i.suffix}" \u0B87\u0BB2\u0BCD \u0BAE\u0BC1\u0B9F\u0BBF\u0BB5\u0B9F\u0BC8\u0BAF \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : i.format === "includes" ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B9A\u0BB0\u0BAE\u0BCD: "${i.includes}" \u0B90 \u0B89\u0BB3\u0BCD\u0BB3\u0B9F\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : i.format === "regex" ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B9A\u0BB0\u0BAE\u0BCD: ${i.pattern} \u0BAE\u0BC1\u0BB1\u0BC8\u0BAA\u0BBE\u0B9F\u0BCD\u0B9F\u0BC1\u0B9F\u0BA9\u0BCD \u0BAA\u0BCA\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B8E\u0BA3\u0BCD: ${r.divisor} \u0B87\u0BA9\u0BCD \u0BAA\u0BB2\u0BAE\u0BBE\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD`;
      case "unrecognized_keys":
        return `\u0B85\u0B9F\u0BC8\u0BAF\u0BBE\u0BB3\u0BAE\u0BCD \u0BA4\u0BC6\u0BB0\u0BBF\u0BAF\u0BBE\u0BA4 \u0BB5\u0BBF\u0B9A\u0BC8${r.keys.length > 1 ? "\u0B95\u0BB3\u0BCD" : ""}: ${m(r.keys, ", ")}`;
      case "invalid_key":
        return `${r.origin} \u0B87\u0BB2\u0BCD \u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0BB5\u0BBF\u0B9A\u0BC8`;
      case "invalid_union":
        return "\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1";
      case "invalid_element":
        return `${r.origin} \u0B87\u0BB2\u0BCD \u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0BAE\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1`;
      default:
        return "\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1";
    }
  };
}, "error");
function Ac() {
  return {
    localeError: cy()
  };
}
s(Ac, "default");

// versions/4.3.6/node_modules/zod/v4/locales/th.js
var uy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0E15\u0E31\u0E27\u0E2D\u0E31\u0E01\u0E29\u0E23", verb: "\u0E04\u0E27\u0E23\u0E21\u0E35" },
    file: { unit: "\u0E44\u0E1A\u0E15\u0E4C", verb: "\u0E04\u0E27\u0E23\u0E21\u0E35" },
    array: { unit: "\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23", verb: "\u0E04\u0E27\u0E23\u0E21\u0E35" },
    set: { unit: "\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23", verb: "\u0E04\u0E27\u0E23\u0E21\u0E35" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E17\u0E35\u0E48\u0E1B\u0E49\u0E2D\u0E19",
    email: "\u0E17\u0E35\u0E48\u0E2D\u0E22\u0E39\u0E48\u0E2D\u0E35\u0E40\u0E21\u0E25",
    url: "URL",
    emoji: "\u0E2D\u0E34\u0E42\u0E21\u0E08\u0E34",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48\u0E40\u0E27\u0E25\u0E32\u0E41\u0E1A\u0E1A ISO",
    date: "\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48\u0E41\u0E1A\u0E1A ISO",
    time: "\u0E40\u0E27\u0E25\u0E32\u0E41\u0E1A\u0E1A ISO",
    duration: "\u0E0A\u0E48\u0E27\u0E07\u0E40\u0E27\u0E25\u0E32\u0E41\u0E1A\u0E1A ISO",
    ipv4: "\u0E17\u0E35\u0E48\u0E2D\u0E22\u0E39\u0E48 IPv4",
    ipv6: "\u0E17\u0E35\u0E48\u0E2D\u0E22\u0E39\u0E48 IPv6",
    cidrv4: "\u0E0A\u0E48\u0E27\u0E07 IP \u0E41\u0E1A\u0E1A IPv4",
    cidrv6: "\u0E0A\u0E48\u0E27\u0E07 IP \u0E41\u0E1A\u0E1A IPv6",
    base64: "\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E41\u0E1A\u0E1A Base64",
    base64url: "\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E41\u0E1A\u0E1A Base64 \u0E2A\u0E33\u0E2B\u0E23\u0E31\u0E1A URL",
    json_string: "\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E41\u0E1A\u0E1A JSON",
    e164: "\u0E40\u0E1A\u0E2D\u0E23\u0E4C\u0E42\u0E17\u0E23\u0E28\u0E31\u0E1E\u0E17\u0E4C\u0E23\u0E30\u0E2B\u0E27\u0E48\u0E32\u0E07\u0E1B\u0E23\u0E30\u0E40\u0E17\u0E28 (E.164)",
    jwt: "\u0E42\u0E17\u0E40\u0E04\u0E19 JWT",
    template_literal: "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E17\u0E35\u0E48\u0E1B\u0E49\u0E2D\u0E19"
  }, o = {
    nan: "NaN",
    number: "\u0E15\u0E31\u0E27\u0E40\u0E25\u0E02",
    array: "\u0E2D\u0E32\u0E23\u0E4C\u0E40\u0E23\u0E22\u0E4C (Array)",
    null: "\u0E44\u0E21\u0E48\u0E21\u0E35\u0E04\u0E48\u0E32 (null)"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), c = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u0E1B\u0E23\u0E30\u0E40\u0E20\u0E17\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E04\u0E27\u0E23\u0E40\u0E1B\u0E47\u0E19 instanceof ${r.expected} \u0E41\u0E15\u0E48\u0E44\u0E14\u0E49\u0E23\u0E31\u0E1A ${c}` : `\u0E1B\u0E23\u0E30\u0E40\u0E20\u0E17\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E04\u0E27\u0E23\u0E40\u0E1B\u0E47\u0E19 ${i} \u0E41\u0E15\u0E48\u0E44\u0E14\u0E49\u0E23\u0E31\u0E1A ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u0E04\u0E48\u0E32\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E04\u0E27\u0E23\u0E40\u0E1B\u0E47\u0E19 ${y(r.values[0])}` : `\u0E15\u0E31\u0E27\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E04\u0E27\u0E23\u0E40\u0E1B\u0E47\u0E19\u0E2B\u0E19\u0E36\u0E48\u0E07\u0E43\u0E19 ${m(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "\u0E44\u0E21\u0E48\u0E40\u0E01\u0E34\u0E19" : "\u0E19\u0E49\u0E2D\u0E22\u0E01\u0E27\u0E48\u0E32", a = t(r.origin);
        return a ? `\u0E40\u0E01\u0E34\u0E19\u0E01\u0E33\u0E2B\u0E19\u0E14: ${r.origin ?? "\u0E04\u0E48\u0E32"} \u0E04\u0E27\u0E23\u0E21\u0E35${i} ${r.maximum.toString()} ${a.unit ?? "\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23"}` : `\u0E40\u0E01\u0E34\u0E19\u0E01\u0E33\u0E2B\u0E19\u0E14: ${r.origin ?? "\u0E04\u0E48\u0E32"} \u0E04\u0E27\u0E23\u0E21\u0E35${i} ${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? "\u0E2D\u0E22\u0E48\u0E32\u0E07\u0E19\u0E49\u0E2D\u0E22" : "\u0E21\u0E32\u0E01\u0E01\u0E27\u0E48\u0E32", a = t(r.origin);
        return a ? `\u0E19\u0E49\u0E2D\u0E22\u0E01\u0E27\u0E48\u0E32\u0E01\u0E33\u0E2B\u0E19\u0E14: ${r.origin} \u0E04\u0E27\u0E23\u0E21\u0E35${i} ${r.minimum.toString()} ${a.unit}` : `\u0E19\u0E49\u0E2D\u0E22\u0E01\u0E27\u0E48\u0E32\u0E01\u0E33\u0E2B\u0E19\u0E14: ${r.origin} \u0E04\u0E27\u0E23\u0E21\u0E35${i} ${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E15\u0E49\u0E2D\u0E07\u0E02\u0E36\u0E49\u0E19\u0E15\u0E49\u0E19\u0E14\u0E49\u0E27\u0E22 "${i.prefix}"` : i.format === "ends_with" ? `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E15\u0E49\u0E2D\u0E07\u0E25\u0E07\u0E17\u0E49\u0E32\u0E22\u0E14\u0E49\u0E27\u0E22 "${i.suffix}"` : i.format === "includes" ? `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E15\u0E49\u0E2D\u0E07\u0E21\u0E35 "${i.includes}" \u0E2D\u0E22\u0E39\u0E48\u0E43\u0E19\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21` : i.format === "regex" ? `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E15\u0E49\u0E2D\u0E07\u0E15\u0E23\u0E07\u0E01\u0E31\u0E1A\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E17\u0E35\u0E48\u0E01\u0E33\u0E2B\u0E19\u0E14 ${i.pattern}` : `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u0E15\u0E31\u0E27\u0E40\u0E25\u0E02\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E15\u0E49\u0E2D\u0E07\u0E40\u0E1B\u0E47\u0E19\u0E08\u0E33\u0E19\u0E27\u0E19\u0E17\u0E35\u0E48\u0E2B\u0E32\u0E23\u0E14\u0E49\u0E27\u0E22 ${r.divisor} \u0E44\u0E14\u0E49\u0E25\u0E07\u0E15\u0E31\u0E27`;
      case "unrecognized_keys":
        return `\u0E1E\u0E1A\u0E04\u0E35\u0E22\u0E4C\u0E17\u0E35\u0E48\u0E44\u0E21\u0E48\u0E23\u0E39\u0E49\u0E08\u0E31\u0E01: ${m(r.keys, ", ")}`;
      case "invalid_key":
        return `\u0E04\u0E35\u0E22\u0E4C\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07\u0E43\u0E19 ${r.origin}`;
      case "invalid_union":
        return "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E44\u0E21\u0E48\u0E15\u0E23\u0E07\u0E01\u0E31\u0E1A\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E22\u0E39\u0E40\u0E19\u0E35\u0E22\u0E19\u0E17\u0E35\u0E48\u0E01\u0E33\u0E2B\u0E19\u0E14\u0E44\u0E27\u0E49";
      case "invalid_element":
        return `\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07\u0E43\u0E19 ${r.origin}`;
      default:
        return "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07";
    }
  };
}, "error");
function Cc() {
  return {
    localeError: uy()
  };
}
s(Cc, "default");

// versions/4.3.6/node_modules/zod/v4/locales/tr.js
var ly = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "karakter", verb: "olmal\u0131" },
    file: { unit: "bayt", verb: "olmal\u0131" },
    array: { unit: "\xF6\u011Fe", verb: "olmal\u0131" },
    set: { unit: "\xF6\u011Fe", verb: "olmal\u0131" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "girdi",
    email: "e-posta adresi",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO tarih ve saat",
    date: "ISO tarih",
    time: "ISO saat",
    duration: "ISO s\xFCre",
    ipv4: "IPv4 adresi",
    ipv6: "IPv6 adresi",
    cidrv4: "IPv4 aral\u0131\u011F\u0131",
    cidrv6: "IPv6 aral\u0131\u011F\u0131",
    base64: "base64 ile \u015Fifrelenmi\u015F metin",
    base64url: "base64url ile \u015Fifrelenmi\u015F metin",
    json_string: "JSON dizesi",
    e164: "E.164 say\u0131s\u0131",
    jwt: "JWT",
    template_literal: "\u015Eablon dizesi"
  }, o = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), c = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Ge\xE7ersiz de\u011Fer: beklenen instanceof ${r.expected}, al\u0131nan ${c}` : `Ge\xE7ersiz de\u011Fer: beklenen ${i}, al\u0131nan ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Ge\xE7ersiz de\u011Fer: beklenen ${y(r.values[0])}` : `Ge\xE7ersiz se\xE7enek: a\u015Fa\u011F\u0131dakilerden biri olmal\u0131: ${m(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `\xC7ok b\xFCy\xFCk: beklenen ${r.origin ?? "de\u011Fer"} ${i}${r.maximum.toString()} ${a.unit ?? "\xF6\u011Fe"}` : `\xC7ok b\xFCy\xFCk: beklenen ${r.origin ?? "de\u011Fer"} ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\xC7ok k\xFC\xE7\xFCk: beklenen ${r.origin} ${i}${r.minimum.toString()} ${a.unit}` : `\xC7ok k\xFC\xE7\xFCk: beklenen ${r.origin} ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Ge\xE7ersiz metin: "${i.prefix}" ile ba\u015Flamal\u0131` : i.format === "ends_with" ? `Ge\xE7ersiz metin: "${i.suffix}" ile bitmeli` : i.format === "includes" ? `Ge\xE7ersiz metin: "${i.includes}" i\xE7ermeli` : i.format === "regex" ? `Ge\xE7ersiz metin: ${i.pattern} desenine uymal\u0131` : `Ge\xE7ersiz ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Ge\xE7ersiz say\u0131: ${r.divisor} ile tam b\xF6l\xFCnebilmeli`;
      case "unrecognized_keys":
        return `Tan\u0131nmayan anahtar${r.keys.length > 1 ? "lar" : ""}: ${m(r.keys, ", ")}`;
      case "invalid_key":
        return `${r.origin} i\xE7inde ge\xE7ersiz anahtar`;
      case "invalid_union":
        return "Ge\xE7ersiz de\u011Fer";
      case "invalid_element":
        return `${r.origin} i\xE7inde ge\xE7ersiz de\u011Fer`;
      default:
        return "Ge\xE7ersiz de\u011Fer";
    }
  };
}, "error");
function Rc() {
  return {
    localeError: ly()
  };
}
s(Rc, "default");

// versions/4.3.6/node_modules/zod/v4/locales/uk.js
var dy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0441\u0438\u043C\u0432\u043E\u043B\u0456\u0432", verb: "\u043C\u0430\u0442\u0438\u043C\u0435" },
    file: { unit: "\u0431\u0430\u0439\u0442\u0456\u0432", verb: "\u043C\u0430\u0442\u0438\u043C\u0435" },
    array: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0456\u0432", verb: "\u043C\u0430\u0442\u0438\u043C\u0435" },
    set: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0456\u0432", verb: "\u043C\u0430\u0442\u0438\u043C\u0435" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456",
    email: "\u0430\u0434\u0440\u0435\u0441\u0430 \u0435\u043B\u0435\u043A\u0442\u0440\u043E\u043D\u043D\u043E\u0457 \u043F\u043E\u0448\u0442\u0438",
    url: "URL",
    emoji: "\u0435\u043C\u043E\u0434\u0437\u0456",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u0434\u0430\u0442\u0430 \u0442\u0430 \u0447\u0430\u0441 ISO",
    date: "\u0434\u0430\u0442\u0430 ISO",
    time: "\u0447\u0430\u0441 ISO",
    duration: "\u0442\u0440\u0438\u0432\u0430\u043B\u0456\u0441\u0442\u044C ISO",
    ipv4: "\u0430\u0434\u0440\u0435\u0441\u0430 IPv4",
    ipv6: "\u0430\u0434\u0440\u0435\u0441\u0430 IPv6",
    cidrv4: "\u0434\u0456\u0430\u043F\u0430\u0437\u043E\u043D IPv4",
    cidrv6: "\u0434\u0456\u0430\u043F\u0430\u0437\u043E\u043D IPv6",
    base64: "\u0440\u044F\u0434\u043E\u043A \u0443 \u043A\u043E\u0434\u0443\u0432\u0430\u043D\u043D\u0456 base64",
    base64url: "\u0440\u044F\u0434\u043E\u043A \u0443 \u043A\u043E\u0434\u0443\u0432\u0430\u043D\u043D\u0456 base64url",
    json_string: "\u0440\u044F\u0434\u043E\u043A JSON",
    e164: "\u043D\u043E\u043C\u0435\u0440 E.164",
    jwt: "JWT",
    template_literal: "\u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456"
  }, o = {
    nan: "NaN",
    number: "\u0447\u0438\u0441\u043B\u043E",
    array: "\u043C\u0430\u0441\u0438\u0432"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), c = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F instanceof ${r.expected}, \u043E\u0442\u0440\u0438\u043C\u0430\u043D\u043E ${c}` : `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F ${i}, \u043E\u0442\u0440\u0438\u043C\u0430\u043D\u043E ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F ${y(r.values[0])}` : `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0430 \u043E\u043F\u0446\u0456\u044F: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F \u043E\u0434\u043D\u0435 \u0437 ${m(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `\u0417\u0430\u043D\u0430\u0434\u0442\u043E \u0432\u0435\u043B\u0438\u043A\u0435: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F, \u0449\u043E ${r.origin ?? "\u0437\u043D\u0430\u0447\u0435\u043D\u043D\u044F"} ${a.verb} ${i}${r.maximum.toString()} ${a.unit ?? "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0456\u0432"}` : `\u0417\u0430\u043D\u0430\u0434\u0442\u043E \u0432\u0435\u043B\u0438\u043A\u0435: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F, \u0449\u043E ${r.origin ?? "\u0437\u043D\u0430\u0447\u0435\u043D\u043D\u044F"} \u0431\u0443\u0434\u0435 ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\u0417\u0430\u043D\u0430\u0434\u0442\u043E \u043C\u0430\u043B\u0435: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F, \u0449\u043E ${r.origin} ${a.verb} ${i}${r.minimum.toString()} ${a.unit}` : `\u0417\u0430\u043D\u0430\u0434\u0442\u043E \u043C\u0430\u043B\u0435: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F, \u0449\u043E ${r.origin} \u0431\u0443\u0434\u0435 ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u0440\u044F\u0434\u043E\u043A: \u043F\u043E\u0432\u0438\u043D\u0435\u043D \u043F\u043E\u0447\u0438\u043D\u0430\u0442\u0438\u0441\u044F \u0437 "${i.prefix}"` : i.format === "ends_with" ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u0440\u044F\u0434\u043E\u043A: \u043F\u043E\u0432\u0438\u043D\u0435\u043D \u0437\u0430\u043A\u0456\u043D\u0447\u0443\u0432\u0430\u0442\u0438\u0441\u044F \u043D\u0430 "${i.suffix}"` : i.format === "includes" ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u0440\u044F\u0434\u043E\u043A: \u043F\u043E\u0432\u0438\u043D\u0435\u043D \u043C\u0456\u0441\u0442\u0438\u0442\u0438 "${i.includes}"` : i.format === "regex" ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u0440\u044F\u0434\u043E\u043A: \u043F\u043E\u0432\u0438\u043D\u0435\u043D \u0432\u0456\u0434\u043F\u043E\u0432\u0456\u0434\u0430\u0442\u0438 \u0448\u0430\u0431\u043B\u043E\u043D\u0443 ${i.pattern}` : `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0435 \u0447\u0438\u0441\u043B\u043E: \u043F\u043E\u0432\u0438\u043D\u043D\u043E \u0431\u0443\u0442\u0438 \u043A\u0440\u0430\u0442\u043D\u0438\u043C ${r.divisor}`;
      case "unrecognized_keys":
        return `\u041D\u0435\u0440\u043E\u0437\u043F\u0456\u0437\u043D\u0430\u043D\u0438\u0439 \u043A\u043B\u044E\u0447${r.keys.length > 1 ? "\u0456" : ""}: ${m(r.keys, ", ")}`;
      case "invalid_key":
        return `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u043A\u043B\u044E\u0447 \u0443 ${r.origin}`;
      case "invalid_union":
        return "\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456";
      case "invalid_element":
        return `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u043D\u044F \u0443 ${r.origin}`;
      default:
        return "\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456";
    }
  };
}, "error");
function Dr() {
  return {
    localeError: dy()
  };
}
s(Dr, "default");

// versions/4.3.6/node_modules/zod/v4/locales/ua.js
function Fc() {
  return Dr();
}
s(Fc, "default");

// versions/4.3.6/node_modules/zod/v4/locales/ur.js
var fy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u062D\u0631\u0648\u0641", verb: "\u06C1\u0648\u0646\u0627" },
    file: { unit: "\u0628\u0627\u0626\u0679\u0633", verb: "\u06C1\u0648\u0646\u0627" },
    array: { unit: "\u0622\u0626\u0679\u0645\u0632", verb: "\u06C1\u0648\u0646\u0627" },
    set: { unit: "\u0622\u0626\u0679\u0645\u0632", verb: "\u06C1\u0648\u0646\u0627" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u0627\u0646 \u067E\u0679",
    email: "\u0627\u06CC \u0645\u06CC\u0644 \u0627\u06CC\u0688\u0631\u06CC\u0633",
    url: "\u06CC\u0648 \u0622\u0631 \u0627\u06CC\u0644",
    emoji: "\u0627\u06CC\u0645\u0648\u062C\u06CC",
    uuid: "\u06CC\u0648 \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC",
    uuidv4: "\u06CC\u0648 \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC \u0648\u06CC 4",
    uuidv6: "\u06CC\u0648 \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC \u0648\u06CC 6",
    nanoid: "\u0646\u06CC\u0646\u0648 \u0622\u0626\u06CC \u0688\u06CC",
    guid: "\u062C\u06CC \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC",
    cuid: "\u0633\u06CC \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC",
    cuid2: "\u0633\u06CC \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC 2",
    ulid: "\u06CC\u0648 \u0627\u06CC\u0644 \u0622\u0626\u06CC \u0688\u06CC",
    xid: "\u0627\u06CC\u06A9\u0633 \u0622\u0626\u06CC \u0688\u06CC",
    ksuid: "\u06A9\u06D2 \u0627\u06CC\u0633 \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC",
    datetime: "\u0622\u0626\u06CC \u0627\u06CC\u0633 \u0627\u0648 \u0688\u06CC\u0679 \u0679\u0627\u0626\u0645",
    date: "\u0622\u0626\u06CC \u0627\u06CC\u0633 \u0627\u0648 \u062A\u0627\u0631\u06CC\u062E",
    time: "\u0622\u0626\u06CC \u0627\u06CC\u0633 \u0627\u0648 \u0648\u0642\u062A",
    duration: "\u0622\u0626\u06CC \u0627\u06CC\u0633 \u0627\u0648 \u0645\u062F\u062A",
    ipv4: "\u0622\u0626\u06CC \u067E\u06CC \u0648\u06CC 4 \u0627\u06CC\u0688\u0631\u06CC\u0633",
    ipv6: "\u0622\u0626\u06CC \u067E\u06CC \u0648\u06CC 6 \u0627\u06CC\u0688\u0631\u06CC\u0633",
    cidrv4: "\u0622\u0626\u06CC \u067E\u06CC \u0648\u06CC 4 \u0631\u06CC\u0646\u062C",
    cidrv6: "\u0622\u0626\u06CC \u067E\u06CC \u0648\u06CC 6 \u0631\u06CC\u0646\u062C",
    base64: "\u0628\u06CC\u0633 64 \u0627\u0646 \u06A9\u0648\u0688\u0688 \u0633\u0679\u0631\u0646\u06AF",
    base64url: "\u0628\u06CC\u0633 64 \u06CC\u0648 \u0622\u0631 \u0627\u06CC\u0644 \u0627\u0646 \u06A9\u0648\u0688\u0688 \u0633\u0679\u0631\u0646\u06AF",
    json_string: "\u062C\u06D2 \u0627\u06CC\u0633 \u0627\u0648 \u0627\u06CC\u0646 \u0633\u0679\u0631\u0646\u06AF",
    e164: "\u0627\u06CC 164 \u0646\u0645\u0628\u0631",
    jwt: "\u062C\u06D2 \u0688\u0628\u0644\u06CC\u0648 \u0679\u06CC",
    template_literal: "\u0627\u0646 \u067E\u0679"
  }, o = {
    nan: "NaN",
    number: "\u0646\u0645\u0628\u0631",
    array: "\u0622\u0631\u06D2",
    null: "\u0646\u0644"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), c = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679: instanceof ${r.expected} \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627\u060C ${c} \u0645\u0648\u0635\u0648\u0644 \u06C1\u0648\u0627` : `\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679: ${i} \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627\u060C ${c} \u0645\u0648\u0635\u0648\u0644 \u06C1\u0648\u0627`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679: ${y(r.values[0])} \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627` : `\u063A\u0644\u0637 \u0622\u067E\u0634\u0646: ${m(r.values, "|")} \u0645\u06CC\u06BA \u0633\u06D2 \u0627\u06CC\u06A9 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `\u0628\u06C1\u062A \u0628\u0691\u0627: ${r.origin ?? "\u0648\u06CC\u0644\u06CC\u0648"} \u06A9\u06D2 ${i}${r.maximum.toString()} ${a.unit ?? "\u0639\u0646\u0627\u0635\u0631"} \u06C1\u0648\u0646\u06D2 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u06D2` : `\u0628\u06C1\u062A \u0628\u0691\u0627: ${r.origin ?? "\u0648\u06CC\u0644\u06CC\u0648"} \u06A9\u0627 ${i}${r.maximum.toString()} \u06C1\u0648\u0646\u0627 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\u0628\u06C1\u062A \u0686\u06BE\u0648\u0679\u0627: ${r.origin} \u06A9\u06D2 ${i}${r.minimum.toString()} ${a.unit} \u06C1\u0648\u0646\u06D2 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u06D2` : `\u0628\u06C1\u062A \u0686\u06BE\u0648\u0679\u0627: ${r.origin} \u06A9\u0627 ${i}${r.minimum.toString()} \u06C1\u0648\u0646\u0627 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u063A\u0644\u0637 \u0633\u0679\u0631\u0646\u06AF: "${i.prefix}" \u0633\u06D2 \u0634\u0631\u0648\u0639 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2` : i.format === "ends_with" ? `\u063A\u0644\u0637 \u0633\u0679\u0631\u0646\u06AF: "${i.suffix}" \u067E\u0631 \u062E\u062A\u0645 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2` : i.format === "includes" ? `\u063A\u0644\u0637 \u0633\u0679\u0631\u0646\u06AF: "${i.includes}" \u0634\u0627\u0645\u0644 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2` : i.format === "regex" ? `\u063A\u0644\u0637 \u0633\u0679\u0631\u0646\u06AF: \u067E\u06CC\u0679\u0631\u0646 ${i.pattern} \u0633\u06D2 \u0645\u06CC\u0686 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2` : `\u063A\u0644\u0637 ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u063A\u0644\u0637 \u0646\u0645\u0628\u0631: ${r.divisor} \u06A9\u0627 \u0645\u0636\u0627\u0639\u0641 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2`;
      case "unrecognized_keys":
        return `\u063A\u06CC\u0631 \u062A\u0633\u0644\u06CC\u0645 \u0634\u062F\u06C1 \u06A9\u06CC${r.keys.length > 1 ? "\u0632" : ""}: ${m(r.keys, "\u060C ")}`;
      case "invalid_key":
        return `${r.origin} \u0645\u06CC\u06BA \u063A\u0644\u0637 \u06A9\u06CC`;
      case "invalid_union":
        return "\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679";
      case "invalid_element":
        return `${r.origin} \u0645\u06CC\u06BA \u063A\u0644\u0637 \u0648\u06CC\u0644\u06CC\u0648`;
      default:
        return "\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679";
    }
  };
}, "error");
function Lc() {
  return {
    localeError: fy()
  };
}
s(Lc, "default");

// versions/4.3.6/node_modules/zod/v4/locales/uz.js
var py = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "belgi", verb: "bo\u2018lishi kerak" },
    file: { unit: "bayt", verb: "bo\u2018lishi kerak" },
    array: { unit: "element", verb: "bo\u2018lishi kerak" },
    set: { unit: "element", verb: "bo\u2018lishi kerak" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "kirish",
    email: "elektron pochta manzili",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO sana va vaqti",
    date: "ISO sana",
    time: "ISO vaqt",
    duration: "ISO davomiylik",
    ipv4: "IPv4 manzil",
    ipv6: "IPv6 manzil",
    mac: "MAC manzil",
    cidrv4: "IPv4 diapazon",
    cidrv6: "IPv6 diapazon",
    base64: "base64 kodlangan satr",
    base64url: "base64url kodlangan satr",
    json_string: "JSON satr",
    e164: "E.164 raqam",
    jwt: "JWT",
    template_literal: "kirish"
  }, o = {
    nan: "NaN",
    number: "raqam",
    array: "massiv"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), c = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Noto\u2018g\u2018ri kirish: kutilgan instanceof ${r.expected}, qabul qilingan ${c}` : `Noto\u2018g\u2018ri kirish: kutilgan ${i}, qabul qilingan ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Noto\u2018g\u2018ri kirish: kutilgan ${y(r.values[0])}` : `Noto\u2018g\u2018ri variant: quyidagilardan biri kutilgan ${m(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Juda katta: kutilgan ${r.origin ?? "qiymat"} ${i}${r.maximum.toString()} ${a.unit} ${a.verb}` : `Juda katta: kutilgan ${r.origin ?? "qiymat"} ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Juda kichik: kutilgan ${r.origin} ${i}${r.minimum.toString()} ${a.unit} ${a.verb}` : `Juda kichik: kutilgan ${r.origin} ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Noto\u2018g\u2018ri satr: "${i.prefix}" bilan boshlanishi kerak` : i.format === "ends_with" ? `Noto\u2018g\u2018ri satr: "${i.suffix}" bilan tugashi kerak` : i.format === "includes" ? `Noto\u2018g\u2018ri satr: "${i.includes}" ni o\u2018z ichiga olishi kerak` : i.format === "regex" ? `Noto\u2018g\u2018ri satr: ${i.pattern} shabloniga mos kelishi kerak` : `Noto\u2018g\u2018ri ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Noto\u2018g\u2018ri raqam: ${r.divisor} ning karralisi bo\u2018lishi kerak`;
      case "unrecognized_keys":
        return `Noma\u2019lum kalit${r.keys.length > 1 ? "lar" : ""}: ${m(r.keys, ", ")}`;
      case "invalid_key":
        return `${r.origin} dagi kalit noto\u2018g\u2018ri`;
      case "invalid_union":
        return "Noto\u2018g\u2018ri kirish";
      case "invalid_element":
        return `${r.origin} da noto\u2018g\u2018ri qiymat`;
      default:
        return "Noto\u2018g\u2018ri kirish";
    }
  };
}, "error");
function Mc() {
  return {
    localeError: py()
  };
}
s(Mc, "default");

// versions/4.3.6/node_modules/zod/v4/locales/vi.js
var my = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "k\xFD t\u1EF1", verb: "c\xF3" },
    file: { unit: "byte", verb: "c\xF3" },
    array: { unit: "ph\u1EA7n t\u1EED", verb: "c\xF3" },
    set: { unit: "ph\u1EA7n t\u1EED", verb: "c\xF3" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u0111\u1EA7u v\xE0o",
    email: "\u0111\u1ECBa ch\u1EC9 email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ng\xE0y gi\u1EDD ISO",
    date: "ng\xE0y ISO",
    time: "gi\u1EDD ISO",
    duration: "kho\u1EA3ng th\u1EDDi gian ISO",
    ipv4: "\u0111\u1ECBa ch\u1EC9 IPv4",
    ipv6: "\u0111\u1ECBa ch\u1EC9 IPv6",
    cidrv4: "d\u1EA3i IPv4",
    cidrv6: "d\u1EA3i IPv6",
    base64: "chu\u1ED7i m\xE3 h\xF3a base64",
    base64url: "chu\u1ED7i m\xE3 h\xF3a base64url",
    json_string: "chu\u1ED7i JSON",
    e164: "s\u1ED1 E.164",
    jwt: "JWT",
    template_literal: "\u0111\u1EA7u v\xE0o"
  }, o = {
    nan: "NaN",
    number: "s\u1ED1",
    array: "m\u1EA3ng"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), c = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7: mong \u0111\u1EE3i instanceof ${r.expected}, nh\u1EADn \u0111\u01B0\u1EE3c ${c}` : `\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7: mong \u0111\u1EE3i ${i}, nh\u1EADn \u0111\u01B0\u1EE3c ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7: mong \u0111\u1EE3i ${y(r.values[0])}` : `T\xF9y ch\u1ECDn kh\xF4ng h\u1EE3p l\u1EC7: mong \u0111\u1EE3i m\u1ED9t trong c\xE1c gi\xE1 tr\u1ECB ${m(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Qu\xE1 l\u1EDBn: mong \u0111\u1EE3i ${r.origin ?? "gi\xE1 tr\u1ECB"} ${a.verb} ${i}${r.maximum.toString()} ${a.unit ?? "ph\u1EA7n t\u1EED"}` : `Qu\xE1 l\u1EDBn: mong \u0111\u1EE3i ${r.origin ?? "gi\xE1 tr\u1ECB"} ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Qu\xE1 nh\u1ECF: mong \u0111\u1EE3i ${r.origin} ${a.verb} ${i}${r.minimum.toString()} ${a.unit}` : `Qu\xE1 nh\u1ECF: mong \u0111\u1EE3i ${r.origin} ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Chu\u1ED7i kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i b\u1EAFt \u0111\u1EA7u b\u1EB1ng "${i.prefix}"` : i.format === "ends_with" ? `Chu\u1ED7i kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i k\u1EBFt th\xFAc b\u1EB1ng "${i.suffix}"` : i.format === "includes" ? `Chu\u1ED7i kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i bao g\u1ED3m "${i.includes}"` : i.format === "regex" ? `Chu\u1ED7i kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i kh\u1EDBp v\u1EDBi m\u1EABu ${i.pattern}` : `${n[i.format] ?? r.format} kh\xF4ng h\u1EE3p l\u1EC7`;
      }
      case "not_multiple_of":
        return `S\u1ED1 kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i l\xE0 b\u1ED9i s\u1ED1 c\u1EE7a ${r.divisor}`;
      case "unrecognized_keys":
        return `Kh\xF3a kh\xF4ng \u0111\u01B0\u1EE3c nh\u1EADn d\u1EA1ng: ${m(r.keys, ", ")}`;
      case "invalid_key":
        return `Kh\xF3a kh\xF4ng h\u1EE3p l\u1EC7 trong ${r.origin}`;
      case "invalid_union":
        return "\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7";
      case "invalid_element":
        return `Gi\xE1 tr\u1ECB kh\xF4ng h\u1EE3p l\u1EC7 trong ${r.origin}`;
      default:
        return "\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7";
    }
  };
}, "error");
function Bc() {
  return {
    localeError: my()
  };
}
s(Bc, "default");

// versions/4.3.6/node_modules/zod/v4/locales/zh-CN.js
var gy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u5B57\u7B26", verb: "\u5305\u542B" },
    file: { unit: "\u5B57\u8282", verb: "\u5305\u542B" },
    array: { unit: "\u9879", verb: "\u5305\u542B" },
    set: { unit: "\u9879", verb: "\u5305\u542B" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u8F93\u5165",
    email: "\u7535\u5B50\u90AE\u4EF6",
    url: "URL",
    emoji: "\u8868\u60C5\u7B26\u53F7",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO\u65E5\u671F\u65F6\u95F4",
    date: "ISO\u65E5\u671F",
    time: "ISO\u65F6\u95F4",
    duration: "ISO\u65F6\u957F",
    ipv4: "IPv4\u5730\u5740",
    ipv6: "IPv6\u5730\u5740",
    cidrv4: "IPv4\u7F51\u6BB5",
    cidrv6: "IPv6\u7F51\u6BB5",
    base64: "base64\u7F16\u7801\u5B57\u7B26\u4E32",
    base64url: "base64url\u7F16\u7801\u5B57\u7B26\u4E32",
    json_string: "JSON\u5B57\u7B26\u4E32",
    e164: "E.164\u53F7\u7801",
    jwt: "JWT",
    template_literal: "\u8F93\u5165"
  }, o = {
    nan: "NaN",
    number: "\u6570\u5B57",
    array: "\u6570\u7EC4",
    null: "\u7A7A\u503C(null)"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), c = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u65E0\u6548\u8F93\u5165\uFF1A\u671F\u671B instanceof ${r.expected}\uFF0C\u5B9E\u9645\u63A5\u6536 ${c}` : `\u65E0\u6548\u8F93\u5165\uFF1A\u671F\u671B ${i}\uFF0C\u5B9E\u9645\u63A5\u6536 ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u65E0\u6548\u8F93\u5165\uFF1A\u671F\u671B ${y(r.values[0])}` : `\u65E0\u6548\u9009\u9879\uFF1A\u671F\u671B\u4EE5\u4E0B\u4E4B\u4E00 ${m(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `\u6570\u503C\u8FC7\u5927\uFF1A\u671F\u671B ${r.origin ?? "\u503C"} ${i}${r.maximum.toString()} ${a.unit ?? "\u4E2A\u5143\u7D20"}` : `\u6570\u503C\u8FC7\u5927\uFF1A\u671F\u671B ${r.origin ?? "\u503C"} ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\u6570\u503C\u8FC7\u5C0F\uFF1A\u671F\u671B ${r.origin} ${i}${r.minimum.toString()} ${a.unit}` : `\u6570\u503C\u8FC7\u5C0F\uFF1A\u671F\u671B ${r.origin} ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u65E0\u6548\u5B57\u7B26\u4E32\uFF1A\u5FC5\u987B\u4EE5 "${i.prefix}" \u5F00\u5934` : i.format === "ends_with" ? `\u65E0\u6548\u5B57\u7B26\u4E32\uFF1A\u5FC5\u987B\u4EE5 "${i.suffix}" \u7ED3\u5C3E` : i.format === "includes" ? `\u65E0\u6548\u5B57\u7B26\u4E32\uFF1A\u5FC5\u987B\u5305\u542B "${i.includes}"` : i.format === "regex" ? `\u65E0\u6548\u5B57\u7B26\u4E32\uFF1A\u5FC5\u987B\u6EE1\u8DB3\u6B63\u5219\u8868\u8FBE\u5F0F ${i.pattern}` : `\u65E0\u6548${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u65E0\u6548\u6570\u5B57\uFF1A\u5FC5\u987B\u662F ${r.divisor} \u7684\u500D\u6570`;
      case "unrecognized_keys":
        return `\u51FA\u73B0\u672A\u77E5\u7684\u952E(key): ${m(r.keys, ", ")}`;
      case "invalid_key":
        return `${r.origin} \u4E2D\u7684\u952E(key)\u65E0\u6548`;
      case "invalid_union":
        return "\u65E0\u6548\u8F93\u5165";
      case "invalid_element":
        return `${r.origin} \u4E2D\u5305\u542B\u65E0\u6548\u503C(value)`;
      default:
        return "\u65E0\u6548\u8F93\u5165";
    }
  };
}, "error");
function Jc() {
  return {
    localeError: gy()
  };
}
s(Jc, "default");

// versions/4.3.6/node_modules/zod/v4/locales/zh-TW.js
var hy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u5B57\u5143", verb: "\u64C1\u6709" },
    file: { unit: "\u4F4D\u5143\u7D44", verb: "\u64C1\u6709" },
    array: { unit: "\u9805\u76EE", verb: "\u64C1\u6709" },
    set: { unit: "\u9805\u76EE", verb: "\u64C1\u6709" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u8F38\u5165",
    email: "\u90F5\u4EF6\u5730\u5740",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u65E5\u671F\u6642\u9593",
    date: "ISO \u65E5\u671F",
    time: "ISO \u6642\u9593",
    duration: "ISO \u671F\u9593",
    ipv4: "IPv4 \u4F4D\u5740",
    ipv6: "IPv6 \u4F4D\u5740",
    cidrv4: "IPv4 \u7BC4\u570D",
    cidrv6: "IPv6 \u7BC4\u570D",
    base64: "base64 \u7DE8\u78BC\u5B57\u4E32",
    base64url: "base64url \u7DE8\u78BC\u5B57\u4E32",
    json_string: "JSON \u5B57\u4E32",
    e164: "E.164 \u6578\u503C",
    jwt: "JWT",
    template_literal: "\u8F38\u5165"
  }, o = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), c = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u7121\u6548\u7684\u8F38\u5165\u503C\uFF1A\u9810\u671F\u70BA instanceof ${r.expected}\uFF0C\u4F46\u6536\u5230 ${c}` : `\u7121\u6548\u7684\u8F38\u5165\u503C\uFF1A\u9810\u671F\u70BA ${i}\uFF0C\u4F46\u6536\u5230 ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u7121\u6548\u7684\u8F38\u5165\u503C\uFF1A\u9810\u671F\u70BA ${y(r.values[0])}` : `\u7121\u6548\u7684\u9078\u9805\uFF1A\u9810\u671F\u70BA\u4EE5\u4E0B\u5176\u4E2D\u4E4B\u4E00 ${m(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `\u6578\u503C\u904E\u5927\uFF1A\u9810\u671F ${r.origin ?? "\u503C"} \u61C9\u70BA ${i}${r.maximum.toString()} ${a.unit ?? "\u500B\u5143\u7D20"}` : `\u6578\u503C\u904E\u5927\uFF1A\u9810\u671F ${r.origin ?? "\u503C"} \u61C9\u70BA ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\u6578\u503C\u904E\u5C0F\uFF1A\u9810\u671F ${r.origin} \u61C9\u70BA ${i}${r.minimum.toString()} ${a.unit}` : `\u6578\u503C\u904E\u5C0F\uFF1A\u9810\u671F ${r.origin} \u61C9\u70BA ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u7121\u6548\u7684\u5B57\u4E32\uFF1A\u5FC5\u9808\u4EE5 "${i.prefix}" \u958B\u982D` : i.format === "ends_with" ? `\u7121\u6548\u7684\u5B57\u4E32\uFF1A\u5FC5\u9808\u4EE5 "${i.suffix}" \u7D50\u5C3E` : i.format === "includes" ? `\u7121\u6548\u7684\u5B57\u4E32\uFF1A\u5FC5\u9808\u5305\u542B "${i.includes}"` : i.format === "regex" ? `\u7121\u6548\u7684\u5B57\u4E32\uFF1A\u5FC5\u9808\u7B26\u5408\u683C\u5F0F ${i.pattern}` : `\u7121\u6548\u7684 ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u7121\u6548\u7684\u6578\u5B57\uFF1A\u5FC5\u9808\u70BA ${r.divisor} \u7684\u500D\u6578`;
      case "unrecognized_keys":
        return `\u7121\u6CD5\u8B58\u5225\u7684\u9375\u503C${r.keys.length > 1 ? "\u5011" : ""}\uFF1A${m(r.keys, "\u3001")}`;
      case "invalid_key":
        return `${r.origin} \u4E2D\u6709\u7121\u6548\u7684\u9375\u503C`;
      case "invalid_union":
        return "\u7121\u6548\u7684\u8F38\u5165\u503C";
      case "invalid_element":
        return `${r.origin} \u4E2D\u6709\u7121\u6548\u7684\u503C`;
      default:
        return "\u7121\u6548\u7684\u8F38\u5165\u503C";
    }
  };
}, "error");
function Vc() {
  return {
    localeError: hy()
  };
}
s(Vc, "default");

// versions/4.3.6/node_modules/zod/v4/locales/yo.js
var vy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\xE0mi", verb: "n\xED" },
    file: { unit: "bytes", verb: "n\xED" },
    array: { unit: "nkan", verb: "n\xED" },
    set: { unit: "nkan", verb: "n\xED" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u1EB9\u0300r\u1ECD \xECb\xE1w\u1ECDl\xE9",
    email: "\xE0d\xEDr\u1EB9\u0301s\xEC \xECm\u1EB9\u0301l\xEC",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\xE0k\xF3k\xF2 ISO",
    date: "\u1ECDj\u1ECD\u0301 ISO",
    time: "\xE0k\xF3k\xF2 ISO",
    duration: "\xE0k\xF3k\xF2 t\xF3 p\xE9 ISO",
    ipv4: "\xE0d\xEDr\u1EB9\u0301s\xEC IPv4",
    ipv6: "\xE0d\xEDr\u1EB9\u0301s\xEC IPv6",
    cidrv4: "\xE0gb\xE8gb\xE8 IPv4",
    cidrv6: "\xE0gb\xE8gb\xE8 IPv6",
    base64: "\u1ECD\u0300r\u1ECD\u0300 t\xED a k\u1ECD\u0301 n\xED base64",
    base64url: "\u1ECD\u0300r\u1ECD\u0300 base64url",
    json_string: "\u1ECD\u0300r\u1ECD\u0300 JSON",
    e164: "n\u1ECD\u0301mb\xE0 E.164",
    jwt: "JWT",
    template_literal: "\u1EB9\u0300r\u1ECD \xECb\xE1w\u1ECDl\xE9"
  }, o = {
    nan: "NaN",
    number: "n\u1ECD\u0301mb\xE0",
    array: "akop\u1ECD"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), c = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e: a n\xED l\xE1ti fi instanceof ${r.expected}, \xE0m\u1ECD\u0300 a r\xED ${c}` : `\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e: a n\xED l\xE1ti fi ${i}, \xE0m\u1ECD\u0300 a r\xED ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e: a n\xED l\xE1ti fi ${y(r.values[0])}` : `\xC0\u1E63\xE0y\xE0n a\u1E63\xEC\u1E63e: yan \u1ECD\u0300kan l\xE1ra ${m(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `T\xF3 p\u1ECD\u0300 j\xF9: a n\xED l\xE1ti j\u1EB9\u0301 p\xE9 ${r.origin ?? "iye"} ${a.verb} ${i}${r.maximum} ${a.unit}` : `T\xF3 p\u1ECD\u0300 j\xF9: a n\xED l\xE1ti j\u1EB9\u0301 ${i}${r.maximum}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `K\xE9r\xE9 ju: a n\xED l\xE1ti j\u1EB9\u0301 p\xE9 ${r.origin} ${a.verb} ${i}${r.minimum} ${a.unit}` : `K\xE9r\xE9 ju: a n\xED l\xE1ti j\u1EB9\u0301 ${i}${r.minimum}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u1ECC\u0300r\u1ECD\u0300 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 b\u1EB9\u0300r\u1EB9\u0300 p\u1EB9\u0300l\xFA "${i.prefix}"` : i.format === "ends_with" ? `\u1ECC\u0300r\u1ECD\u0300 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 par\xED p\u1EB9\u0300l\xFA "${i.suffix}"` : i.format === "includes" ? `\u1ECC\u0300r\u1ECD\u0300 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 n\xED "${i.includes}"` : i.format === "regex" ? `\u1ECC\u0300r\u1ECD\u0300 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 b\xE1 \xE0p\u1EB9\u1EB9r\u1EB9 mu ${i.pattern}` : `A\u1E63\xEC\u1E63e: ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `N\u1ECD\u0301mb\xE0 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 j\u1EB9\u0301 \xE8y\xE0 p\xEDp\xEDn ti ${r.divisor}`;
      case "unrecognized_keys":
        return `B\u1ECDt\xECn\xEC \xE0\xECm\u1ECD\u0300: ${m(r.keys, ", ")}`;
      case "invalid_key":
        return `B\u1ECDt\xECn\xEC a\u1E63\xEC\u1E63e n\xEDn\xFA ${r.origin}`;
      case "invalid_union":
        return "\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e";
      case "invalid_element":
        return `Iye a\u1E63\xEC\u1E63e n\xEDn\xFA ${r.origin}`;
      default:
        return "\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e";
    }
  };
}, "error");
function qc() {
  return {
    localeError: vy()
  };
}
s(qc, "default");

// versions/4.3.6/node_modules/zod/v4/core/registries.js
var Hf, Wc = Symbol("ZodOutput"), Kc = Symbol("ZodInput"), Kn = class {
  static {
    s(this, "$ZodRegistry");
  }
  constructor() {
    this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map();
  }
  add(t, ...n) {
    let o = n[0];
    return this._map.set(t, o), o && typeof o == "object" && "id" in o && this._idmap.set(o.id, t), this;
  }
  clear() {
    return this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map(), this;
  }
  remove(t) {
    let n = this._map.get(t);
    return n && typeof n == "object" && "id" in n && this._idmap.delete(n.id), this._map.delete(t), this;
  }
  get(t) {
    let n = t._zod.parent;
    if (n) {
      let o = { ...this.get(n) ?? {} };
      delete o.id;
      let r = { ...o, ...this._map.get(t) };
      return Object.keys(r).length ? r : void 0;
    }
    return this._map.get(t);
  }
  has(t) {
    return this._map.has(t);
  }
};
function Gn() {
  return new Kn();
}
s(Gn, "registry");
(Hf = globalThis).__zod_globalRegistry ?? (Hf.__zod_globalRegistry = Gn());
var H = globalThis.__zod_globalRegistry;

// versions/4.3.6/node_modules/zod/v4/core/api.js
// @__NO_SIDE_EFFECTS__
function Gc(e, t) {
  return new e({
    type: "string",
    ...$(t)
  });
}
s(Gc, "_string");
// @__NO_SIDE_EFFECTS__
function Xc(e, t) {
  return new e({
    type: "string",
    coerce: !0,
    ...$(t)
  });
}
s(Xc, "_coercedString");
// @__NO_SIDE_EFFECTS__
function Xn(e, t) {
  return new e({
    type: "string",
    format: "email",
    check: "string_format",
    abort: !1,
    ...$(t)
  });
}
s(Xn, "_email");
// @__NO_SIDE_EFFECTS__
function Zr(e, t) {
  return new e({
    type: "string",
    format: "guid",
    check: "string_format",
    abort: !1,
    ...$(t)
  });
}
s(Zr, "_guid");
// @__NO_SIDE_EFFECTS__
function Qn(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    ...$(t)
  });
}
s(Qn, "_uuid");
// @__NO_SIDE_EFFECTS__
function Hn(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v4",
    ...$(t)
  });
}
s(Hn, "_uuidv4");
// @__NO_SIDE_EFFECTS__
function Yn(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v6",
    ...$(t)
  });
}
s(Yn, "_uuidv6");
// @__NO_SIDE_EFFECTS__
function eo(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v7",
    ...$(t)
  });
}
s(eo, "_uuidv7");
// @__NO_SIDE_EFFECTS__
function Ar(e, t) {
  return new e({
    type: "string",
    format: "url",
    check: "string_format",
    abort: !1,
    ...$(t)
  });
}
s(Ar, "_url");
// @__NO_SIDE_EFFECTS__
function to(e, t) {
  return new e({
    type: "string",
    format: "emoji",
    check: "string_format",
    abort: !1,
    ...$(t)
  });
}
s(to, "_emoji");
// @__NO_SIDE_EFFECTS__
function ro(e, t) {
  return new e({
    type: "string",
    format: "nanoid",
    check: "string_format",
    abort: !1,
    ...$(t)
  });
}
s(ro, "_nanoid");
// @__NO_SIDE_EFFECTS__
function no(e, t) {
  return new e({
    type: "string",
    format: "cuid",
    check: "string_format",
    abort: !1,
    ...$(t)
  });
}
s(no, "_cuid");
// @__NO_SIDE_EFFECTS__
function oo(e, t) {
  return new e({
    type: "string",
    format: "cuid2",
    check: "string_format",
    abort: !1,
    ...$(t)
  });
}
s(oo, "_cuid2");
// @__NO_SIDE_EFFECTS__
function io(e, t) {
  return new e({
    type: "string",
    format: "ulid",
    check: "string_format",
    abort: !1,
    ...$(t)
  });
}
s(io, "_ulid");
// @__NO_SIDE_EFFECTS__
function ao(e, t) {
  return new e({
    type: "string",
    format: "xid",
    check: "string_format",
    abort: !1,
    ...$(t)
  });
}
s(ao, "_xid");
// @__NO_SIDE_EFFECTS__
function so(e, t) {
  return new e({
    type: "string",
    format: "ksuid",
    check: "string_format",
    abort: !1,
    ...$(t)
  });
}
s(so, "_ksuid");
// @__NO_SIDE_EFFECTS__
function co(e, t) {
  return new e({
    type: "string",
    format: "ipv4",
    check: "string_format",
    abort: !1,
    ...$(t)
  });
}
s(co, "_ipv4");
// @__NO_SIDE_EFFECTS__
function uo(e, t) {
  return new e({
    type: "string",
    format: "ipv6",
    check: "string_format",
    abort: !1,
    ...$(t)
  });
}
s(uo, "_ipv6");
// @__NO_SIDE_EFFECTS__
function Qc(e, t) {
  return new e({
    type: "string",
    format: "mac",
    check: "string_format",
    abort: !1,
    ...$(t)
  });
}
s(Qc, "_mac");
// @__NO_SIDE_EFFECTS__
function lo(e, t) {
  return new e({
    type: "string",
    format: "cidrv4",
    check: "string_format",
    abort: !1,
    ...$(t)
  });
}
s(lo, "_cidrv4");
// @__NO_SIDE_EFFECTS__
function fo(e, t) {
  return new e({
    type: "string",
    format: "cidrv6",
    check: "string_format",
    abort: !1,
    ...$(t)
  });
}
s(fo, "_cidrv6");
// @__NO_SIDE_EFFECTS__
function po(e, t) {
  return new e({
    type: "string",
    format: "base64",
    check: "string_format",
    abort: !1,
    ...$(t)
  });
}
s(po, "_base64");
// @__NO_SIDE_EFFECTS__
function mo(e, t) {
  return new e({
    type: "string",
    format: "base64url",
    check: "string_format",
    abort: !1,
    ...$(t)
  });
}
s(mo, "_base64url");
// @__NO_SIDE_EFFECTS__
function go(e, t) {
  return new e({
    type: "string",
    format: "e164",
    check: "string_format",
    abort: !1,
    ...$(t)
  });
}
s(go, "_e164");
// @__NO_SIDE_EFFECTS__
function ho(e, t) {
  return new e({
    type: "string",
    format: "jwt",
    check: "string_format",
    abort: !1,
    ...$(t)
  });
}
s(ho, "_jwt");
var Hc = {
  Any: null,
  Minute: -1,
  Second: 0,
  Millisecond: 3,
  Microsecond: 6
};
// @__NO_SIDE_EFFECTS__
function Yc(e, t) {
  return new e({
    type: "string",
    format: "datetime",
    check: "string_format",
    offset: !1,
    local: !1,
    precision: null,
    ...$(t)
  });
}
s(Yc, "_isoDateTime");
// @__NO_SIDE_EFFECTS__
function eu(e, t) {
  return new e({
    type: "string",
    format: "date",
    check: "string_format",
    ...$(t)
  });
}
s(eu, "_isoDate");
// @__NO_SIDE_EFFECTS__
function tu(e, t) {
  return new e({
    type: "string",
    format: "time",
    check: "string_format",
    precision: null,
    ...$(t)
  });
}
s(tu, "_isoTime");
// @__NO_SIDE_EFFECTS__
function ru(e, t) {
  return new e({
    type: "string",
    format: "duration",
    check: "string_format",
    ...$(t)
  });
}
s(ru, "_isoDuration");
// @__NO_SIDE_EFFECTS__
function nu(e, t) {
  return new e({
    type: "number",
    checks: [],
    ...$(t)
  });
}
s(nu, "_number");
// @__NO_SIDE_EFFECTS__
function ou(e, t) {
  return new e({
    type: "number",
    coerce: !0,
    checks: [],
    ...$(t)
  });
}
s(ou, "_coercedNumber");
// @__NO_SIDE_EFFECTS__
function iu(e, t) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "safeint",
    ...$(t)
  });
}
s(iu, "_int");
// @__NO_SIDE_EFFECTS__
function au(e, t) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "float32",
    ...$(t)
  });
}
s(au, "_float32");
// @__NO_SIDE_EFFECTS__
function su(e, t) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "float64",
    ...$(t)
  });
}
s(su, "_float64");
// @__NO_SIDE_EFFECTS__
function cu(e, t) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "int32",
    ...$(t)
  });
}
s(cu, "_int32");
// @__NO_SIDE_EFFECTS__
function uu(e, t) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "uint32",
    ...$(t)
  });
}
s(uu, "_uint32");
// @__NO_SIDE_EFFECTS__
function lu(e, t) {
  return new e({
    type: "boolean",
    ...$(t)
  });
}
s(lu, "_boolean");
// @__NO_SIDE_EFFECTS__
function du(e, t) {
  return new e({
    type: "boolean",
    coerce: !0,
    ...$(t)
  });
}
s(du, "_coercedBoolean");
// @__NO_SIDE_EFFECTS__
function fu(e, t) {
  return new e({
    type: "bigint",
    ...$(t)
  });
}
s(fu, "_bigint");
// @__NO_SIDE_EFFECTS__
function pu(e, t) {
  return new e({
    type: "bigint",
    coerce: !0,
    ...$(t)
  });
}
s(pu, "_coercedBigint");
// @__NO_SIDE_EFFECTS__
function mu(e, t) {
  return new e({
    type: "bigint",
    check: "bigint_format",
    abort: !1,
    format: "int64",
    ...$(t)
  });
}
s(mu, "_int64");
// @__NO_SIDE_EFFECTS__
function gu(e, t) {
  return new e({
    type: "bigint",
    check: "bigint_format",
    abort: !1,
    format: "uint64",
    ...$(t)
  });
}
s(gu, "_uint64");
// @__NO_SIDE_EFFECTS__
function hu(e, t) {
  return new e({
    type: "symbol",
    ...$(t)
  });
}
s(hu, "_symbol");
// @__NO_SIDE_EFFECTS__
function vu(e, t) {
  return new e({
    type: "undefined",
    ...$(t)
  });
}
s(vu, "_undefined");
// @__NO_SIDE_EFFECTS__
function yu(e, t) {
  return new e({
    type: "null",
    ...$(t)
  });
}
s(yu, "_null");
// @__NO_SIDE_EFFECTS__
function bu(e) {
  return new e({
    type: "any"
  });
}
s(bu, "_any");
// @__NO_SIDE_EFFECTS__
function xu(e) {
  return new e({
    type: "unknown"
  });
}
s(xu, "_unknown");
// @__NO_SIDE_EFFECTS__
function $u(e, t) {
  return new e({
    type: "never",
    ...$(t)
  });
}
s($u, "_never");
// @__NO_SIDE_EFFECTS__
function _u(e, t) {
  return new e({
    type: "void",
    ...$(t)
  });
}
s(_u, "_void");
// @__NO_SIDE_EFFECTS__
function wu(e, t) {
  return new e({
    type: "date",
    ...$(t)
  });
}
s(wu, "_date");
// @__NO_SIDE_EFFECTS__
function ku(e, t) {
  return new e({
    type: "date",
    coerce: !0,
    ...$(t)
  });
}
s(ku, "_coercedDate");
// @__NO_SIDE_EFFECTS__
function zu(e, t) {
  return new e({
    type: "nan",
    ...$(t)
  });
}
s(zu, "_nan");
// @__NO_SIDE_EFFECTS__
function ze(e, t) {
  return new Rn({
    check: "less_than",
    ...$(t),
    value: e,
    inclusive: !1
  });
}
s(ze, "_lt");
// @__NO_SIDE_EFFECTS__
function le(e, t) {
  return new Rn({
    check: "less_than",
    ...$(t),
    value: e,
    inclusive: !0
  });
}
s(le, "_lte");
// @__NO_SIDE_EFFECTS__
function Ie(e, t) {
  return new Fn({
    check: "greater_than",
    ...$(t),
    value: e,
    inclusive: !1
  });
}
s(Ie, "_gt");
// @__NO_SIDE_EFFECTS__
function re(e, t) {
  return new Fn({
    check: "greater_than",
    ...$(t),
    value: e,
    inclusive: !0
  });
}
s(re, "_gte");
// @__NO_SIDE_EFFECTS__
function vo(e) {
  return /* @__PURE__ */ Ie(0, e);
}
s(vo, "_positive");
// @__NO_SIDE_EFFECTS__
function yo(e) {
  return /* @__PURE__ */ ze(0, e);
}
s(yo, "_negative");
// @__NO_SIDE_EFFECTS__
function bo(e) {
  return /* @__PURE__ */ le(0, e);
}
s(bo, "_nonpositive");
// @__NO_SIDE_EFFECTS__
function xo(e) {
  return /* @__PURE__ */ re(0, e);
}
s(xo, "_nonnegative");
// @__NO_SIDE_EFFECTS__
function Be(e, t) {
  return new Za({
    check: "multiple_of",
    ...$(t),
    value: e
  });
}
s(Be, "_multipleOf");
// @__NO_SIDE_EFFECTS__
function Je(e, t) {
  return new Ra({
    check: "max_size",
    ...$(t),
    maximum: e
  });
}
s(Je, "_maxSize");
// @__NO_SIDE_EFFECTS__
function Se(e, t) {
  return new Fa({
    check: "min_size",
    ...$(t),
    minimum: e
  });
}
s(Se, "_minSize");
// @__NO_SIDE_EFFECTS__
function at(e, t) {
  return new La({
    check: "size_equals",
    ...$(t),
    size: e
  });
}
s(at, "_size");
// @__NO_SIDE_EFFECTS__
function st(e, t) {
  return new Ma({
    check: "max_length",
    ...$(t),
    maximum: e
  });
}
s(st, "_maxLength");
// @__NO_SIDE_EFFECTS__
function Te(e, t) {
  return new Ba({
    check: "min_length",
    ...$(t),
    minimum: e
  });
}
s(Te, "_minLength");
// @__NO_SIDE_EFFECTS__
function ct(e, t) {
  return new Ja({
    check: "length_equals",
    ...$(t),
    length: e
  });
}
s(ct, "_length");
// @__NO_SIDE_EFFECTS__
function At(e, t) {
  return new Va({
    check: "string_format",
    format: "regex",
    ...$(t),
    pattern: e
  });
}
s(At, "_regex");
// @__NO_SIDE_EFFECTS__
function Ct(e) {
  return new qa({
    check: "string_format",
    format: "lowercase",
    ...$(e)
  });
}
s(Ct, "_lowercase");
// @__NO_SIDE_EFFECTS__
function Rt(e) {
  return new Wa({
    check: "string_format",
    format: "uppercase",
    ...$(e)
  });
}
s(Rt, "_uppercase");
// @__NO_SIDE_EFFECTS__
function Ft(e, t) {
  return new Ka({
    check: "string_format",
    format: "includes",
    ...$(t),
    includes: e
  });
}
s(Ft, "_includes");
// @__NO_SIDE_EFFECTS__
function Lt(e, t) {
  return new Ga({
    check: "string_format",
    format: "starts_with",
    ...$(t),
    prefix: e
  });
}
s(Lt, "_startsWith");
// @__NO_SIDE_EFFECTS__
function Mt(e, t) {
  return new Xa({
    check: "string_format",
    format: "ends_with",
    ...$(t),
    suffix: e
  });
}
s(Mt, "_endsWith");
// @__NO_SIDE_EFFECTS__
function $o(e, t, n) {
  return new Qa({
    check: "property",
    property: e,
    schema: t,
    ...$(n)
  });
}
s($o, "_property");
// @__NO_SIDE_EFFECTS__
function Bt(e, t) {
  return new Ha({
    check: "mime_type",
    mime: e,
    ...$(t)
  });
}
s(Bt, "_mime");
// @__NO_SIDE_EFFECTS__
function $e(e) {
  return new Ya({
    check: "overwrite",
    tx: e
  });
}
s($e, "_overwrite");
// @__NO_SIDE_EFFECTS__
function Jt(e) {
  return /* @__PURE__ */ $e((t) => t.normalize(e));
}
s(Jt, "_normalize");
// @__NO_SIDE_EFFECTS__
function Vt() {
  return /* @__PURE__ */ $e((e) => e.trim());
}
s(Vt, "_trim");
// @__NO_SIDE_EFFECTS__
function qt() {
  return /* @__PURE__ */ $e((e) => e.toLowerCase());
}
s(qt, "_toLowerCase");
// @__NO_SIDE_EFFECTS__
function Wt() {
  return /* @__PURE__ */ $e((e) => e.toUpperCase());
}
s(Wt, "_toUpperCase");
// @__NO_SIDE_EFFECTS__
function Kt() {
  return /* @__PURE__ */ $e((e) => Hi(e));
}
s(Kt, "_slugify");
// @__NO_SIDE_EFFECTS__
function Iu(e, t, n) {
  return new e({
    type: "array",
    element: t,
    // get element() {
    //   return element;
    // },
    ...$(n)
  });
}
s(Iu, "_array");
// @__NO_SIDE_EFFECTS__
function by(e, t, n) {
  return new e({
    type: "union",
    options: t,
    ...$(n)
  });
}
s(by, "_union");
function xy(e, t, n) {
  return new e({
    type: "union",
    options: t,
    inclusive: !1,
    ...$(n)
  });
}
s(xy, "_xor");
// @__NO_SIDE_EFFECTS__
function $y(e, t, n, o) {
  return new e({
    type: "union",
    options: n,
    discriminator: t,
    ...$(o)
  });
}
s($y, "_discriminatedUnion");
// @__NO_SIDE_EFFECTS__
function _y(e, t, n) {
  return new e({
    type: "intersection",
    left: t,
    right: n
  });
}
s(_y, "_intersection");
// @__NO_SIDE_EFFECTS__
function wy(e, t, n, o) {
  let r = n instanceof k, i = r ? o : n, a = r ? n : null;
  return new e({
    type: "tuple",
    items: t,
    rest: a,
    ...$(i)
  });
}
s(wy, "_tuple");
// @__NO_SIDE_EFFECTS__
function ky(e, t, n, o) {
  return new e({
    type: "record",
    keyType: t,
    valueType: n,
    ...$(o)
  });
}
s(ky, "_record");
// @__NO_SIDE_EFFECTS__
function zy(e, t, n, o) {
  return new e({
    type: "map",
    keyType: t,
    valueType: n,
    ...$(o)
  });
}
s(zy, "_map");
// @__NO_SIDE_EFFECTS__
function Iy(e, t, n) {
  return new e({
    type: "set",
    valueType: t,
    ...$(n)
  });
}
s(Iy, "_set");
// @__NO_SIDE_EFFECTS__
function Sy(e, t, n) {
  let o = Array.isArray(t) ? Object.fromEntries(t.map((r) => [r, r])) : t;
  return new e({
    type: "enum",
    entries: o,
    ...$(n)
  });
}
s(Sy, "_enum");
// @__NO_SIDE_EFFECTS__
function jy(e, t, n) {
  return new e({
    type: "enum",
    entries: t,
    ...$(n)
  });
}
s(jy, "_nativeEnum");
// @__NO_SIDE_EFFECTS__
function Oy(e, t, n) {
  return new e({
    type: "literal",
    values: Array.isArray(t) ? t : [t],
    ...$(n)
  });
}
s(Oy, "_literal");
// @__NO_SIDE_EFFECTS__
function Su(e, t) {
  return new e({
    type: "file",
    ...$(t)
  });
}
s(Su, "_file");
// @__NO_SIDE_EFFECTS__
function Py(e, t) {
  return new e({
    type: "transform",
    transform: t
  });
}
s(Py, "_transform");
// @__NO_SIDE_EFFECTS__
function Ty(e, t) {
  return new e({
    type: "optional",
    innerType: t
  });
}
s(Ty, "_optional");
// @__NO_SIDE_EFFECTS__
function Ey(e, t) {
  return new e({
    type: "nullable",
    innerType: t
  });
}
s(Ey, "_nullable");
// @__NO_SIDE_EFFECTS__
function Uy(e, t, n) {
  return new e({
    type: "default",
    innerType: t,
    get defaultValue() {
      return typeof n == "function" ? n() : ea(n);
    }
  });
}
s(Uy, "_default");
// @__NO_SIDE_EFFECTS__
function Dy(e, t, n) {
  return new e({
    type: "nonoptional",
    innerType: t,
    ...$(n)
  });
}
s(Dy, "_nonoptional");
// @__NO_SIDE_EFFECTS__
function Ny(e, t) {
  return new e({
    type: "success",
    innerType: t
  });
}
s(Ny, "_success");
// @__NO_SIDE_EFFECTS__
function Zy(e, t, n) {
  return new e({
    type: "catch",
    innerType: t,
    catchValue: typeof n == "function" ? n : () => n
  });
}
s(Zy, "_catch");
// @__NO_SIDE_EFFECTS__
function Ay(e, t, n) {
  return new e({
    type: "pipe",
    in: t,
    out: n
  });
}
s(Ay, "_pipe");
// @__NO_SIDE_EFFECTS__
function Cy(e, t) {
  return new e({
    type: "readonly",
    innerType: t
  });
}
s(Cy, "_readonly");
// @__NO_SIDE_EFFECTS__
function Ry(e, t, n) {
  return new e({
    type: "template_literal",
    parts: t,
    ...$(n)
  });
}
s(Ry, "_templateLiteral");
// @__NO_SIDE_EFFECTS__
function Fy(e, t) {
  return new e({
    type: "lazy",
    getter: t
  });
}
s(Fy, "_lazy");
// @__NO_SIDE_EFFECTS__
function Ly(e, t) {
  return new e({
    type: "promise",
    innerType: t
  });
}
s(Ly, "_promise");
// @__NO_SIDE_EFFECTS__
function ju(e, t, n) {
  let o = $(n);
  return o.abort ?? (o.abort = !0), new e({
    type: "custom",
    check: "custom",
    fn: t,
    ...o
  });
}
s(ju, "_custom");
// @__NO_SIDE_EFFECTS__
function Ou(e, t, n) {
  return new e({
    type: "custom",
    check: "custom",
    fn: t,
    ...$(n)
  });
}
s(Ou, "_refine");
// @__NO_SIDE_EFFECTS__
function Pu(e) {
  let t = /* @__PURE__ */ Yf((n) => (n.addIssue = (o) => {
    if (typeof o == "string")
      n.issues.push(It(o, n.value, t._zod.def));
    else {
      let r = o;
      r.fatal && (r.continue = !1), r.code ?? (r.code = "custom"), r.input ?? (r.input = n.value), r.inst ?? (r.inst = t), r.continue ?? (r.continue = !t._zod.def.abort), n.issues.push(It(r));
    }
  }, e(n.value, n)));
  return t;
}
s(Pu, "_superRefine");
// @__NO_SIDE_EFFECTS__
function Yf(e, t) {
  let n = new C({
    check: "custom",
    ...$(t)
  });
  return n._zod.check = e, n;
}
s(Yf, "_check");
// @__NO_SIDE_EFFECTS__
function Tu(e) {
  let t = new C({ check: "describe" });
  return t._zod.onattach = [
    (n) => {
      let o = H.get(n) ?? {};
      H.add(n, { ...o, description: e });
    }
  ], t._zod.check = () => {
  }, t;
}
s(Tu, "describe");
// @__NO_SIDE_EFFECTS__
function Eu(e) {
  let t = new C({ check: "meta" });
  return t._zod.onattach = [
    (n) => {
      let o = H.get(n) ?? {};
      H.add(n, { ...o, ...e });
    }
  ], t._zod.check = () => {
  }, t;
}
s(Eu, "meta");
// @__NO_SIDE_EFFECTS__
function Uu(e, t) {
  let n = $(t), o = n.truthy ?? ["true", "1", "yes", "on", "y", "enabled"], r = n.falsy ?? ["false", "0", "no", "off", "n", "disabled"];
  n.case !== "sensitive" && (o = o.map((v) => typeof v == "string" ? v.toLowerCase() : v), r = r.map((v) => typeof v == "string" ? v.toLowerCase() : v));
  let i = new Set(o), a = new Set(r), c = e.Codec ?? xe, u = e.Boolean ?? Or, l = e.String ?? ot, d = new l({ type: "string", error: n.error }), p = new u({ type: "boolean", error: n.error }), h = new c({
    type: "pipe",
    in: d,
    out: p,
    transform: /* @__PURE__ */ s(((v, O) => {
      let I = v;
      return n.case !== "sensitive" && (I = I.toLowerCase()), i.has(I) ? !0 : a.has(I) ? !1 : (O.issues.push({
        code: "invalid_value",
        expected: "stringbool",
        values: [...i, ...a],
        input: O.value,
        inst: h,
        continue: !1
      }), {});
    }), "transform"),
    reverseTransform: /* @__PURE__ */ s(((v, O) => v === !0 ? o[0] || "true" : r[0] || "false"), "reverseTransform"),
    error: n.error
  });
  return h;
}
s(Uu, "_stringbool");
// @__NO_SIDE_EFFECTS__
function Gt(e, t, n, o = {}) {
  let r = $(o), i = {
    ...$(o),
    check: "string_format",
    type: "string",
    format: t,
    fn: typeof n == "function" ? n : (c) => n.test(c),
    ...r
  };
  return n instanceof RegExp && (i.pattern = n), new e(i);
}
s(Gt, "_stringFormat");

// versions/4.3.6/node_modules/zod/v4/core/to-json-schema.js
function Ve(e) {
  let t = e?.target ?? "draft-2020-12";
  return t === "draft-4" && (t = "draft-04"), t === "draft-7" && (t = "draft-07"), {
    processors: e.processors ?? {},
    metadataRegistry: e?.metadata ?? H,
    target: t,
    unrepresentable: e?.unrepresentable ?? "throw",
    override: e?.override ?? (() => {
    }),
    io: e?.io ?? "output",
    counter: 0,
    seen: /* @__PURE__ */ new Map(),
    cycles: e?.cycles ?? "ref",
    reused: e?.reused ?? "inline",
    external: e?.external ?? void 0
  };
}
s(Ve, "initializeContext");
function U(e, t, n = { path: [], schemaPath: [] }) {
  var o;
  let r = e._zod.def, i = t.seen.get(e);
  if (i)
    return i.count++, n.schemaPath.includes(e) && (i.cycle = n.path), i.schema;
  let a = { schema: {}, count: 1, cycle: void 0, path: n.path };
  t.seen.set(e, a);
  let c = e._zod.toJSONSchema?.();
  if (c)
    a.schema = c;
  else {
    let d = {
      ...n,
      schemaPath: [...n.schemaPath, e],
      path: n.path
    };
    if (e._zod.processJSONSchema)
      e._zod.processJSONSchema(t, a.schema, d);
    else {
      let h = a.schema, v = t.processors[r.type];
      if (!v)
        throw new Error(`[toJSONSchema]: Non-representable type encountered: ${r.type}`);
      v(e, t, h, d);
    }
    let p = e._zod.parent;
    p && (a.ref || (a.ref = p), U(p, t, d), t.seen.get(p).isParent = !0);
  }
  let u = t.metadataRegistry.get(e);
  return u && Object.assign(a.schema, u), t.io === "input" && ne(e) && (delete a.schema.examples, delete a.schema.default), t.io === "input" && a.schema._prefault && ((o = a.schema).default ?? (o.default = a.schema._prefault)), delete a.schema._prefault, t.seen.get(e).schema;
}
s(U, "process");
function qe(e, t) {
  let n = e.seen.get(t);
  if (!n)
    throw new Error("Unprocessed schema. This is a bug in Zod.");
  let o = /* @__PURE__ */ new Map();
  for (let a of e.seen.entries()) {
    let c = e.metadataRegistry.get(a[0])?.id;
    if (c) {
      let u = o.get(c);
      if (u && u !== a[0])
        throw new Error(`Duplicate schema id "${c}" detected during JSON Schema conversion. Two different schemas cannot share the same id when converted together.`);
      o.set(c, a[0]);
    }
  }
  let r = /* @__PURE__ */ s((a) => {
    let c = e.target === "draft-2020-12" ? "$defs" : "definitions";
    if (e.external) {
      let p = e.external.registry.get(a[0])?.id, h = e.external.uri ?? ((O) => O);
      if (p)
        return { ref: h(p) };
      let v = a[1].defId ?? a[1].schema.id ?? `schema${e.counter++}`;
      return a[1].defId = v, { defId: v, ref: `${h("__shared")}#/${c}/${v}` };
    }
    if (a[1] === n)
      return { ref: "#" };
    let l = `#/${c}/`, d = a[1].schema.id ?? `__schema${e.counter++}`;
    return { defId: d, ref: l + d };
  }, "makeURI"), i = /* @__PURE__ */ s((a) => {
    if (a[1].schema.$ref)
      return;
    let c = a[1], { ref: u, defId: l } = r(a);
    c.def = { ...c.schema }, l && (c.defId = l);
    let d = c.schema;
    for (let p in d)
      delete d[p];
    d.$ref = u;
  }, "extractToDef");
  if (e.cycles === "throw")
    for (let a of e.seen.entries()) {
      let c = a[1];
      if (c.cycle)
        throw new Error(`Cycle detected: #/${c.cycle?.join("/")}/<root>

Set the \`cycles\` parameter to \`"ref"\` to resolve cyclical schemas with defs.`);
    }
  for (let a of e.seen.entries()) {
    let c = a[1];
    if (t === a[0]) {
      i(a);
      continue;
    }
    if (e.external) {
      let l = e.external.registry.get(a[0])?.id;
      if (t !== a[0] && l) {
        i(a);
        continue;
      }
    }
    if (e.metadataRegistry.get(a[0])?.id) {
      i(a);
      continue;
    }
    if (c.cycle) {
      i(a);
      continue;
    }
    if (c.count > 1 && e.reused === "ref") {
      i(a);
      continue;
    }
  }
}
s(qe, "extractDefs");
function We(e, t) {
  let n = e.seen.get(t);
  if (!n)
    throw new Error("Unprocessed schema. This is a bug in Zod.");
  let o = /* @__PURE__ */ s((a) => {
    let c = e.seen.get(a);
    if (c.ref === null)
      return;
    let u = c.def ?? c.schema, l = { ...u }, d = c.ref;
    if (c.ref = null, d) {
      o(d);
      let h = e.seen.get(d), v = h.schema;
      if (v.$ref && (e.target === "draft-07" || e.target === "draft-04" || e.target === "openapi-3.0") ? (u.allOf = u.allOf ?? [], u.allOf.push(v)) : Object.assign(u, v), Object.assign(u, l), a._zod.parent === d)
        for (let I in u)
          I === "$ref" || I === "allOf" || I in l || delete u[I];
      if (v.$ref && h.def)
        for (let I in u)
          I === "$ref" || I === "allOf" || I in h.def && JSON.stringify(u[I]) === JSON.stringify(h.def[I]) && delete u[I];
    }
    let p = a._zod.parent;
    if (p && p !== d) {
      o(p);
      let h = e.seen.get(p);
      if (h?.schema.$ref && (u.$ref = h.schema.$ref, h.def))
        for (let v in u)
          v === "$ref" || v === "allOf" || v in h.def && JSON.stringify(u[v]) === JSON.stringify(h.def[v]) && delete u[v];
    }
    e.override({
      zodSchema: a,
      jsonSchema: u,
      path: c.path ?? []
    });
  }, "flattenRef");
  for (let a of [...e.seen.entries()].reverse())
    o(a[0]);
  let r = {};
  if (e.target === "draft-2020-12" ? r.$schema = "https://json-schema.org/draft/2020-12/schema" : e.target === "draft-07" ? r.$schema = "http://json-schema.org/draft-07/schema#" : e.target === "draft-04" ? r.$schema = "http://json-schema.org/draft-04/schema#" : e.target, e.external?.uri) {
    let a = e.external.registry.get(t)?.id;
    if (!a)
      throw new Error("Schema is missing an `id` property");
    r.$id = e.external.uri(a);
  }
  Object.assign(r, n.def ?? n.schema);
  let i = e.external?.defs ?? {};
  for (let a of e.seen.entries()) {
    let c = a[1];
    c.def && c.defId && (i[c.defId] = c.def);
  }
  e.external || Object.keys(i).length > 0 && (e.target === "draft-2020-12" ? r.$defs = i : r.definitions = i);
  try {
    let a = JSON.parse(JSON.stringify(r));
    return Object.defineProperty(a, "~standard", {
      value: {
        ...t["~standard"],
        jsonSchema: {
          input: Xt(t, "input", e.processors),
          output: Xt(t, "output", e.processors)
        }
      },
      enumerable: !1,
      writable: !1
    }), a;
  } catch {
    throw new Error("Error converting schema to JSON.");
  }
}
s(We, "finalize");
function ne(e, t) {
  let n = t ?? { seen: /* @__PURE__ */ new Set() };
  if (n.seen.has(e))
    return !1;
  n.seen.add(e);
  let o = e._zod.def;
  if (o.type === "transform")
    return !0;
  if (o.type === "array")
    return ne(o.element, n);
  if (o.type === "set")
    return ne(o.valueType, n);
  if (o.type === "lazy")
    return ne(o.getter(), n);
  if (o.type === "promise" || o.type === "optional" || o.type === "nonoptional" || o.type === "nullable" || o.type === "readonly" || o.type === "default" || o.type === "prefault")
    return ne(o.innerType, n);
  if (o.type === "intersection")
    return ne(o.left, n) || ne(o.right, n);
  if (o.type === "record" || o.type === "map")
    return ne(o.keyType, n) || ne(o.valueType, n);
  if (o.type === "pipe")
    return ne(o.in, n) || ne(o.out, n);
  if (o.type === "object") {
    for (let r in o.shape)
      if (ne(o.shape[r], n))
        return !0;
    return !1;
  }
  if (o.type === "union") {
    for (let r of o.options)
      if (ne(r, n))
        return !0;
    return !1;
  }
  if (o.type === "tuple") {
    for (let r of o.items)
      if (ne(r, n))
        return !0;
    return !!(o.rest && ne(o.rest, n));
  }
  return !1;
}
s(ne, "isTransforming");
var Du = /* @__PURE__ */ s((e, t = {}) => (n) => {
  let o = Ve({ ...n, processors: t });
  return U(e, o), qe(o, e), We(o, e);
}, "createToJSONSchemaMethod"), Xt = /* @__PURE__ */ s((e, t, n = {}) => (o) => {
  let { libraryOptions: r, target: i } = o ?? {}, a = Ve({ ...r ?? {}, target: i, io: t, processors: n });
  return U(e, a), qe(a, e), We(a, e);
}, "createStandardJSONSchemaMethod");

// versions/4.3.6/node_modules/zod/v4/core/json-schema-processors.js
var My = {
  guid: "uuid",
  url: "uri",
  datetime: "date-time",
  json_string: "json-string",
  regex: ""
  // do not set
}, Nu = /* @__PURE__ */ s((e, t, n, o) => {
  let r = n;
  r.type = "string";
  let { minimum: i, maximum: a, format: c, patterns: u, contentEncoding: l } = e._zod.bag;
  if (typeof i == "number" && (r.minLength = i), typeof a == "number" && (r.maxLength = a), c && (r.format = My[c] ?? c, r.format === "" && delete r.format, c === "time" && delete r.format), l && (r.contentEncoding = l), u && u.size > 0) {
    let d = [...u];
    d.length === 1 ? r.pattern = d[0].source : d.length > 1 && (r.allOf = [
      ...d.map((p) => ({
        ...t.target === "draft-07" || t.target === "draft-04" || t.target === "openapi-3.0" ? { type: "string" } : {},
        pattern: p.source
      }))
    ]);
  }
}, "stringProcessor"), Zu = /* @__PURE__ */ s((e, t, n, o) => {
  let r = n, { minimum: i, maximum: a, format: c, multipleOf: u, exclusiveMaximum: l, exclusiveMinimum: d } = e._zod.bag;
  typeof c == "string" && c.includes("int") ? r.type = "integer" : r.type = "number", typeof d == "number" && (t.target === "draft-04" || t.target === "openapi-3.0" ? (r.minimum = d, r.exclusiveMinimum = !0) : r.exclusiveMinimum = d), typeof i == "number" && (r.minimum = i, typeof d == "number" && t.target !== "draft-04" && (d >= i ? delete r.minimum : delete r.exclusiveMinimum)), typeof l == "number" && (t.target === "draft-04" || t.target === "openapi-3.0" ? (r.maximum = l, r.exclusiveMaximum = !0) : r.exclusiveMaximum = l), typeof a == "number" && (r.maximum = a, typeof l == "number" && t.target !== "draft-04" && (l <= a ? delete r.maximum : delete r.exclusiveMaximum)), typeof u == "number" && (r.multipleOf = u);
}, "numberProcessor"), Au = /* @__PURE__ */ s((e, t, n, o) => {
  n.type = "boolean";
}, "booleanProcessor"), Cu = /* @__PURE__ */ s((e, t, n, o) => {
  if (t.unrepresentable === "throw")
    throw new Error("BigInt cannot be represented in JSON Schema");
}, "bigintProcessor"), Ru = /* @__PURE__ */ s((e, t, n, o) => {
  if (t.unrepresentable === "throw")
    throw new Error("Symbols cannot be represented in JSON Schema");
}, "symbolProcessor"), Fu = /* @__PURE__ */ s((e, t, n, o) => {
  t.target === "openapi-3.0" ? (n.type = "string", n.nullable = !0, n.enum = [null]) : n.type = "null";
}, "nullProcessor"), Lu = /* @__PURE__ */ s((e, t, n, o) => {
  if (t.unrepresentable === "throw")
    throw new Error("Undefined cannot be represented in JSON Schema");
}, "undefinedProcessor"), Mu = /* @__PURE__ */ s((e, t, n, o) => {
  if (t.unrepresentable === "throw")
    throw new Error("Void cannot be represented in JSON Schema");
}, "voidProcessor"), Bu = /* @__PURE__ */ s((e, t, n, o) => {
  n.not = {};
}, "neverProcessor"), Ju = /* @__PURE__ */ s((e, t, n, o) => {
}, "anyProcessor"), Vu = /* @__PURE__ */ s((e, t, n, o) => {
}, "unknownProcessor"), qu = /* @__PURE__ */ s((e, t, n, o) => {
  if (t.unrepresentable === "throw")
    throw new Error("Date cannot be represented in JSON Schema");
}, "dateProcessor"), Wu = /* @__PURE__ */ s((e, t, n, o) => {
  let r = e._zod.def, i = br(r.entries);
  i.every((a) => typeof a == "number") && (n.type = "number"), i.every((a) => typeof a == "string") && (n.type = "string"), n.enum = i;
}, "enumProcessor"), Ku = /* @__PURE__ */ s((e, t, n, o) => {
  let r = e._zod.def, i = [];
  for (let a of r.values)
    if (a === void 0) {
      if (t.unrepresentable === "throw")
        throw new Error("Literal `undefined` cannot be represented in JSON Schema");
    } else if (typeof a == "bigint") {
      if (t.unrepresentable === "throw")
        throw new Error("BigInt literals cannot be represented in JSON Schema");
      i.push(Number(a));
    } else
      i.push(a);
  if (i.length !== 0)
    if (i.length === 1) {
      let a = i[0];
      n.type = a === null ? "null" : typeof a, t.target === "draft-04" || t.target === "openapi-3.0" ? n.enum = [a] : n.const = a;
    } else
      i.every((a) => typeof a == "number") && (n.type = "number"), i.every((a) => typeof a == "string") && (n.type = "string"), i.every((a) => typeof a == "boolean") && (n.type = "boolean"), i.every((a) => a === null) && (n.type = "null"), n.enum = i;
}, "literalProcessor"), Gu = /* @__PURE__ */ s((e, t, n, o) => {
  if (t.unrepresentable === "throw")
    throw new Error("NaN cannot be represented in JSON Schema");
}, "nanProcessor"), Xu = /* @__PURE__ */ s((e, t, n, o) => {
  let r = n, i = e._zod.pattern;
  if (!i)
    throw new Error("Pattern not found in template literal");
  r.type = "string", r.pattern = i.source;
}, "templateLiteralProcessor"), Qu = /* @__PURE__ */ s((e, t, n, o) => {
  let r = n, i = {
    type: "string",
    format: "binary",
    contentEncoding: "binary"
  }, { minimum: a, maximum: c, mime: u } = e._zod.bag;
  a !== void 0 && (i.minLength = a), c !== void 0 && (i.maxLength = c), u ? u.length === 1 ? (i.contentMediaType = u[0], Object.assign(r, i)) : (Object.assign(r, i), r.anyOf = u.map((l) => ({ contentMediaType: l }))) : Object.assign(r, i);
}, "fileProcessor"), Hu = /* @__PURE__ */ s((e, t, n, o) => {
  n.type = "boolean";
}, "successProcessor"), Yu = /* @__PURE__ */ s((e, t, n, o) => {
  if (t.unrepresentable === "throw")
    throw new Error("Custom types cannot be represented in JSON Schema");
}, "customProcessor"), el = /* @__PURE__ */ s((e, t, n, o) => {
  if (t.unrepresentable === "throw")
    throw new Error("Function types cannot be represented in JSON Schema");
}, "functionProcessor"), tl = /* @__PURE__ */ s((e, t, n, o) => {
  if (t.unrepresentable === "throw")
    throw new Error("Transforms cannot be represented in JSON Schema");
}, "transformProcessor"), rl = /* @__PURE__ */ s((e, t, n, o) => {
  if (t.unrepresentable === "throw")
    throw new Error("Map cannot be represented in JSON Schema");
}, "mapProcessor"), nl = /* @__PURE__ */ s((e, t, n, o) => {
  if (t.unrepresentable === "throw")
    throw new Error("Set cannot be represented in JSON Schema");
}, "setProcessor"), ol = /* @__PURE__ */ s((e, t, n, o) => {
  let r = n, i = e._zod.def, { minimum: a, maximum: c } = e._zod.bag;
  typeof a == "number" && (r.minItems = a), typeof c == "number" && (r.maxItems = c), r.type = "array", r.items = U(i.element, t, { ...o, path: [...o.path, "items"] });
}, "arrayProcessor"), il = /* @__PURE__ */ s((e, t, n, o) => {
  let r = n, i = e._zod.def;
  r.type = "object", r.properties = {};
  let a = i.shape;
  for (let l in a)
    r.properties[l] = U(a[l], t, {
      ...o,
      path: [...o.path, "properties", l]
    });
  let c = new Set(Object.keys(a)), u = new Set([...c].filter((l) => {
    let d = i.shape[l]._zod;
    return t.io === "input" ? d.optin === void 0 : d.optout === void 0;
  }));
  u.size > 0 && (r.required = Array.from(u)), i.catchall?._zod.def.type === "never" ? r.additionalProperties = !1 : i.catchall ? i.catchall && (r.additionalProperties = U(i.catchall, t, {
    ...o,
    path: [...o.path, "additionalProperties"]
  })) : t.io === "output" && (r.additionalProperties = !1);
}, "objectProcessor"), wo = /* @__PURE__ */ s((e, t, n, o) => {
  let r = e._zod.def, i = r.inclusive === !1, a = r.options.map((c, u) => U(c, t, {
    ...o,
    path: [...o.path, i ? "oneOf" : "anyOf", u]
  }));
  i ? n.oneOf = a : n.anyOf = a;
}, "unionProcessor"), al = /* @__PURE__ */ s((e, t, n, o) => {
  let r = e._zod.def, i = U(r.left, t, {
    ...o,
    path: [...o.path, "allOf", 0]
  }), a = U(r.right, t, {
    ...o,
    path: [...o.path, "allOf", 1]
  }), c = /* @__PURE__ */ s((l) => "allOf" in l && Object.keys(l).length === 1, "isSimpleIntersection"), u = [
    ...c(i) ? i.allOf : [i],
    ...c(a) ? a.allOf : [a]
  ];
  n.allOf = u;
}, "intersectionProcessor"), sl = /* @__PURE__ */ s((e, t, n, o) => {
  let r = n, i = e._zod.def;
  r.type = "array";
  let a = t.target === "draft-2020-12" ? "prefixItems" : "items", c = t.target === "draft-2020-12" || t.target === "openapi-3.0" ? "items" : "additionalItems", u = i.items.map((h, v) => U(h, t, {
    ...o,
    path: [...o.path, a, v]
  })), l = i.rest ? U(i.rest, t, {
    ...o,
    path: [...o.path, c, ...t.target === "openapi-3.0" ? [i.items.length] : []]
  }) : null;
  t.target === "draft-2020-12" ? (r.prefixItems = u, l && (r.items = l)) : t.target === "openapi-3.0" ? (r.items = {
    anyOf: u
  }, l && r.items.anyOf.push(l), r.minItems = u.length, l || (r.maxItems = u.length)) : (r.items = u, l && (r.additionalItems = l));
  let { minimum: d, maximum: p } = e._zod.bag;
  typeof d == "number" && (r.minItems = d), typeof p == "number" && (r.maxItems = p);
}, "tupleProcessor"), cl = /* @__PURE__ */ s((e, t, n, o) => {
  let r = n, i = e._zod.def;
  r.type = "object";
  let a = i.keyType, u = a._zod.bag?.patterns;
  if (i.mode === "loose" && u && u.size > 0) {
    let d = U(i.valueType, t, {
      ...o,
      path: [...o.path, "patternProperties", "*"]
    });
    r.patternProperties = {};
    for (let p of u)
      r.patternProperties[p.source] = d;
  } else
    (t.target === "draft-07" || t.target === "draft-2020-12") && (r.propertyNames = U(i.keyType, t, {
      ...o,
      path: [...o.path, "propertyNames"]
    })), r.additionalProperties = U(i.valueType, t, {
      ...o,
      path: [...o.path, "additionalProperties"]
    });
  let l = a._zod.values;
  if (l) {
    let d = [...l].filter((p) => typeof p == "string" || typeof p == "number");
    d.length > 0 && (r.required = d);
  }
}, "recordProcessor"), ul = /* @__PURE__ */ s((e, t, n, o) => {
  let r = e._zod.def, i = U(r.innerType, t, o), a = t.seen.get(e);
  t.target === "openapi-3.0" ? (a.ref = r.innerType, n.nullable = !0) : n.anyOf = [i, { type: "null" }];
}, "nullableProcessor"), ll = /* @__PURE__ */ s((e, t, n, o) => {
  let r = e._zod.def;
  U(r.innerType, t, o);
  let i = t.seen.get(e);
  i.ref = r.innerType;
}, "nonoptionalProcessor"), dl = /* @__PURE__ */ s((e, t, n, o) => {
  let r = e._zod.def;
  U(r.innerType, t, o);
  let i = t.seen.get(e);
  i.ref = r.innerType, n.default = JSON.parse(JSON.stringify(r.defaultValue));
}, "defaultProcessor"), fl = /* @__PURE__ */ s((e, t, n, o) => {
  let r = e._zod.def;
  U(r.innerType, t, o);
  let i = t.seen.get(e);
  i.ref = r.innerType, t.io === "input" && (n._prefault = JSON.parse(JSON.stringify(r.defaultValue)));
}, "prefaultProcessor"), pl = /* @__PURE__ */ s((e, t, n, o) => {
  let r = e._zod.def;
  U(r.innerType, t, o);
  let i = t.seen.get(e);
  i.ref = r.innerType;
  let a;
  try {
    a = r.catchValue(void 0);
  } catch {
    throw new Error("Dynamic catch values are not supported in JSON Schema");
  }
  n.default = a;
}, "catchProcessor"), ml = /* @__PURE__ */ s((e, t, n, o) => {
  let r = e._zod.def, i = t.io === "input" ? r.in._zod.def.type === "transform" ? r.out : r.in : r.out;
  U(i, t, o);
  let a = t.seen.get(e);
  a.ref = i;
}, "pipeProcessor"), gl = /* @__PURE__ */ s((e, t, n, o) => {
  let r = e._zod.def;
  U(r.innerType, t, o);
  let i = t.seen.get(e);
  i.ref = r.innerType, n.readOnly = !0;
}, "readonlyProcessor"), hl = /* @__PURE__ */ s((e, t, n, o) => {
  let r = e._zod.def;
  U(r.innerType, t, o);
  let i = t.seen.get(e);
  i.ref = r.innerType;
}, "promiseProcessor"), ko = /* @__PURE__ */ s((e, t, n, o) => {
  let r = e._zod.def;
  U(r.innerType, t, o);
  let i = t.seen.get(e);
  i.ref = r.innerType;
}, "optionalProcessor"), vl = /* @__PURE__ */ s((e, t, n, o) => {
  let r = e._zod.innerType;
  U(r, t, o);
  let i = t.seen.get(e);
  i.ref = r;
}, "lazyProcessor"), _o = {
  string: Nu,
  number: Zu,
  boolean: Au,
  bigint: Cu,
  symbol: Ru,
  null: Fu,
  undefined: Lu,
  void: Mu,
  never: Bu,
  any: Ju,
  unknown: Vu,
  date: qu,
  enum: Wu,
  literal: Ku,
  nan: Gu,
  template_literal: Xu,
  file: Qu,
  success: Hu,
  custom: Yu,
  function: el,
  transform: tl,
  map: rl,
  set: nl,
  array: ol,
  object: il,
  union: wo,
  intersection: al,
  tuple: sl,
  record: cl,
  nullable: ul,
  nonoptional: ll,
  default: dl,
  prefault: fl,
  catch: pl,
  pipe: ml,
  readonly: gl,
  promise: hl,
  optional: ko,
  lazy: vl
};
function zo(e, t) {
  if ("_idmap" in e) {
    let o = e, r = Ve({ ...t, processors: _o }), i = {};
    for (let u of o._idmap.entries()) {
      let [l, d] = u;
      U(d, r);
    }
    let a = {}, c = {
      registry: o,
      uri: t?.uri,
      defs: i
    };
    r.external = c;
    for (let u of o._idmap.entries()) {
      let [l, d] = u;
      qe(r, d), a[l] = We(r, d);
    }
    if (Object.keys(i).length > 0) {
      let u = r.target === "draft-2020-12" ? "$defs" : "definitions";
      a.__shared = {
        [u]: i
      };
    }
    return { schemas: a };
  }
  let n = Ve({ ...t, processors: _o });
  return U(e, n), qe(n, e), We(n, e);
}
s(zo, "toJSONSchema");

// versions/4.3.6/node_modules/zod/v4/core/json-schema-generator.js
var Io = class {
  static {
    s(this, "JSONSchemaGenerator");
  }
  /** @deprecated Access via ctx instead */
  get metadataRegistry() {
    return this.ctx.metadataRegistry;
  }
  /** @deprecated Access via ctx instead */
  get target() {
    return this.ctx.target;
  }
  /** @deprecated Access via ctx instead */
  get unrepresentable() {
    return this.ctx.unrepresentable;
  }
  /** @deprecated Access via ctx instead */
  get override() {
    return this.ctx.override;
  }
  /** @deprecated Access via ctx instead */
  get io() {
    return this.ctx.io;
  }
  /** @deprecated Access via ctx instead */
  get counter() {
    return this.ctx.counter;
  }
  set counter(t) {
    this.ctx.counter = t;
  }
  /** @deprecated Access via ctx instead */
  get seen() {
    return this.ctx.seen;
  }
  constructor(t) {
    let n = t?.target ?? "draft-2020-12";
    n === "draft-4" && (n = "draft-04"), n === "draft-7" && (n = "draft-07"), this.ctx = Ve({
      processors: _o,
      target: n,
      ...t?.metadata && { metadata: t.metadata },
      ...t?.unrepresentable && { unrepresentable: t.unrepresentable },
      ...t?.override && { override: t.override },
      ...t?.io && { io: t.io }
    });
  }
  /**
   * Process a schema to prepare it for JSON Schema generation.
   * This must be called before emit().
   */
  process(t, n = { path: [], schemaPath: [] }) {
    return U(t, this.ctx, n);
  }
  /**
   * Emit the final JSON Schema after processing.
   * Must call process() first.
   */
  emit(t, n) {
    n && (n.cycles && (this.ctx.cycles = n.cycles), n.reused && (this.ctx.reused = n.reused), n.external && (this.ctx.external = n.external)), qe(this.ctx, t);
    let o = We(this.ctx, t), { "~standard": r, ...i } = o;
    return i;
  }
};

// versions/4.3.6/node_modules/zod/v4/core/json-schema.js
var ep = {};

// versions/4.3.6/node_modules/zod/v4/classic/schemas.js
var Cr = {};
Oe(Cr, {
  ZodAny: () => Al,
  ZodArray: () => Ll,
  ZodBase64: () => qo,
  ZodBase64URL: () => Wo,
  ZodBigInt: () => or,
  ZodBigIntFormat: () => Xo,
  ZodBoolean: () => nr,
  ZodCIDRv4: () => Jo,
  ZodCIDRv6: () => Vo,
  ZodCUID: () => Ao,
  ZodCUID2: () => Co,
  ZodCatch: () => ud,
  ZodCodec: () => ii,
  ZodCustom: () => Xr,
  ZodCustomStringFormat: () => tr,
  ZodDate: () => qr,
  ZodDefault: () => nd,
  ZodDiscriminatedUnion: () => Bl,
  ZodE164: () => Ko,
  ZodEmail: () => Do,
  ZodEmoji: () => No,
  ZodEnum: () => Yt,
  ZodExactOptional: () => ed,
  ZodFile: () => Hl,
  ZodFunction: () => yd,
  ZodGUID: () => Lr,
  ZodIPv4: () => Mo,
  ZodIPv6: () => Bo,
  ZodIntersection: () => Jl,
  ZodJWT: () => Go,
  ZodKSUID: () => Lo,
  ZodLazy: () => gd,
  ZodLiteral: () => Ql,
  ZodMAC: () => El,
  ZodMap: () => Gl,
  ZodNaN: () => dd,
  ZodNanoID: () => Zo,
  ZodNever: () => Rl,
  ZodNonOptional: () => ni,
  ZodNull: () => Nl,
  ZodNullable: () => rd,
  ZodNumber: () => rr,
  ZodNumberFormat: () => ft,
  ZodObject: () => Wr,
  ZodOptional: () => ri,
  ZodPipe: () => oi,
  ZodPrefault: () => id,
  ZodPromise: () => vd,
  ZodReadonly: () => fd,
  ZodRecord: () => Gr,
  ZodSet: () => Xl,
  ZodString: () => er,
  ZodStringFormat: () => Z,
  ZodSuccess: () => cd,
  ZodSymbol: () => Ul,
  ZodTemplateLiteral: () => md,
  ZodTransform: () => Yl,
  ZodTuple: () => ql,
  ZodType: () => S,
  ZodULID: () => Ro,
  ZodURL: () => Br,
  ZodUUID: () => je,
  ZodUndefined: () => Dl,
  ZodUnion: () => Kr,
  ZodUnknown: () => Cl,
  ZodVoid: () => Fl,
  ZodXID: () => Fo,
  ZodXor: () => Ml,
  _ZodString: () => Uo,
  _default: () => od,
  _function: () => om,
  any: () => Rp,
  array: () => pt,
  base64: () => _p,
  base64url: () => wp,
  bigint: () => Dp,
  boolean: () => Vr,
  catch: () => ld,
  check: () => im,
  cidrv4: () => xp,
  cidrv6: () => $p,
  codec: () => ai,
  cuid: () => fp,
  cuid2: () => pp,
  custom: () => am,
  date: () => Ho,
  describe: () => sm,
  discriminatedUnion: () => Vp,
  e164: () => kp,
  email: () => rp,
  emoji: () => lp,
  enum: () => ei,
  exactOptional: () => td,
  file: () => Hp,
  float32: () => Pp,
  float64: () => Tp,
  function: () => om,
  guid: () => np,
  hash: () => Op,
  hex: () => jp,
  hostname: () => Sp,
  httpUrl: () => up,
  instanceof: () => si,
  int: () => Eo,
  int32: () => Ep,
  int64: () => Np,
  intersection: () => Vl,
  ipv4: () => vp,
  ipv6: () => bp,
  json: () => lm,
  jwt: () => zp,
  keyof: () => Lp,
  ksuid: () => hp,
  lazy: () => hd,
  literal: () => Qp,
  looseObject: () => Bp,
  looseRecord: () => Wp,
  mac: () => yp,
  map: () => Kp,
  meta: () => cm,
  nan: () => tm,
  nanoid: () => dp,
  nativeEnum: () => Xp,
  never: () => Qo,
  nonoptional: () => sd,
  null: () => Zl,
  nullable: () => dt,
  nullish: () => Yp,
  number: () => Jr,
  object: () => Yo,
  optional: () => lt,
  partialRecord: () => qp,
  pipe: () => Mr,
  prefault: () => ad,
  preprocess: () => dm,
  promise: () => nm,
  readonly: () => pd,
  record: () => Kl,
  refine: () => bd,
  set: () => Gp,
  strictObject: () => Mp,
  string: () => Ht,
  stringFormat: () => Ip,
  stringbool: () => um,
  success: () => em,
  superRefine: () => xd,
  symbol: () => Ap,
  templateLiteral: () => rm,
  transform: () => ti,
  tuple: () => Wl,
  uint32: () => Up,
  uint64: () => Zp,
  ulid: () => mp,
  undefined: () => Cp,
  union: () => ir,
  unknown: () => ut,
  url: () => cp,
  uuid: () => op,
  uuidv4: () => ip,
  uuidv6: () => ap,
  uuidv7: () => sp,
  void: () => Fp,
  xid: () => gp,
  xor: () => Jp
});

// versions/4.3.6/node_modules/zod/v4/classic/checks.js
var So = {};
Oe(So, {
  endsWith: () => Mt,
  gt: () => Ie,
  gte: () => re,
  includes: () => Ft,
  length: () => ct,
  lowercase: () => Ct,
  lt: () => ze,
  lte: () => le,
  maxLength: () => st,
  maxSize: () => Je,
  mime: () => Bt,
  minLength: () => Te,
  minSize: () => Se,
  multipleOf: () => Be,
  negative: () => yo,
  nonnegative: () => xo,
  nonpositive: () => bo,
  normalize: () => Jt,
  overwrite: () => $e,
  positive: () => vo,
  property: () => $o,
  regex: () => At,
  size: () => at,
  slugify: () => Kt,
  startsWith: () => Lt,
  toLowerCase: () => qt,
  toUpperCase: () => Wt,
  trim: () => Vt,
  uppercase: () => Rt
});

// versions/4.3.6/node_modules/zod/v4/classic/iso.js
var Qt = {};
Oe(Qt, {
  ZodISODate: () => Oo,
  ZodISODateTime: () => jo,
  ZodISODuration: () => To,
  ZodISOTime: () => Po,
  date: () => bl,
  datetime: () => yl,
  duration: () => $l,
  time: () => xl
});
var jo = /* @__PURE__ */ f("ZodISODateTime", (e, t) => {
  ps.init(e, t), Z.init(e, t);
});
function yl(e) {
  return Yc(jo, e);
}
s(yl, "datetime");
var Oo = /* @__PURE__ */ f("ZodISODate", (e, t) => {
  ms.init(e, t), Z.init(e, t);
});
function bl(e) {
  return eu(Oo, e);
}
s(bl, "date");
var Po = /* @__PURE__ */ f("ZodISOTime", (e, t) => {
  gs.init(e, t), Z.init(e, t);
});
function xl(e) {
  return tu(Po, e);
}
s(xl, "time");
var To = /* @__PURE__ */ f("ZodISODuration", (e, t) => {
  hs.init(e, t), Z.init(e, t);
});
function $l(e) {
  return ru(To, e);
}
s($l, "duration");

// versions/4.3.6/node_modules/zod/v4/classic/errors.js
var tp = /* @__PURE__ */ s((e, t) => {
  ve.init(e, t), e.name = "ZodError", Object.defineProperties(e, {
    format: {
      value: /* @__PURE__ */ s((n) => zr(e, n), "value")
      // enumerable: false,
    },
    flatten: {
      value: /* @__PURE__ */ s((n) => kr(e, n), "value")
      // enumerable: false,
    },
    addIssue: {
      value: /* @__PURE__ */ s((n) => {
        e.issues.push(n), e.message = JSON.stringify(e.issues, kt, 2);
      }, "value")
      // enumerable: false,
    },
    addIssues: {
      value: /* @__PURE__ */ s((n) => {
        e.issues.push(...n), e.message = JSON.stringify(e.issues, kt, 2);
      }, "value")
      // enumerable: false,
    },
    isEmpty: {
      get() {
        return e.issues.length === 0;
      }
      // enumerable: false,
    }
  });
}, "initializer"), Jy = f("ZodError", tp), ae = f("ZodError", tp, {
  Parent: Error
});

// versions/4.3.6/node_modules/zod/v4/classic/parse.js
var Rr = /* @__PURE__ */ St(ae), _l = /* @__PURE__ */ jt(ae), wl = /* @__PURE__ */ Ot(ae), kl = /* @__PURE__ */ Pt(ae), Fr = /* @__PURE__ */ On(ae), zl = /* @__PURE__ */ Pn(ae), Il = /* @__PURE__ */ Tn(ae), Sl = /* @__PURE__ */ En(ae), jl = /* @__PURE__ */ Un(ae), Ol = /* @__PURE__ */ Dn(ae), Pl = /* @__PURE__ */ Nn(ae), Tl = /* @__PURE__ */ Zn(ae);

// versions/4.3.6/node_modules/zod/v4/classic/schemas.js
var S = /* @__PURE__ */ f("ZodType", (e, t) => (k.init(e, t), Object.assign(e["~standard"], {
  jsonSchema: {
    input: Xt(e, "input"),
    output: Xt(e, "output")
  }
}), e.toJSONSchema = Du(e, {}), e.def = t, e.type = t.type, Object.defineProperty(e, "_def", { value: t }), e.check = (...n) => e.clone(x.mergeDefs(t, {
  checks: [
    ...t.checks ?? [],
    ...n.map((o) => typeof o == "function" ? { _zod: { check: o, def: { check: "custom" }, onattach: [] } } : o)
  ]
}), {
  parent: !0
}), e.with = e.check, e.clone = (n, o) => V(e, n, o), e.brand = () => e, e.register = ((n, o) => (n.add(e, o), e)), e.parse = (n, o) => Rr(e, n, o, { callee: e.parse }), e.safeParse = (n, o) => wl(e, n, o), e.parseAsync = async (n, o) => _l(e, n, o, { callee: e.parseAsync }), e.safeParseAsync = async (n, o) => kl(e, n, o), e.spa = e.safeParseAsync, e.encode = (n, o) => Fr(e, n, o), e.decode = (n, o) => zl(e, n, o), e.encodeAsync = async (n, o) => Il(e, n, o), e.decodeAsync = async (n, o) => Sl(e, n, o), e.safeEncode = (n, o) => jl(e, n, o), e.safeDecode = (n, o) => Ol(e, n, o), e.safeEncodeAsync = async (n, o) => Pl(e, n, o), e.safeDecodeAsync = async (n, o) => Tl(e, n, o), e.refine = (n, o) => e.check(bd(n, o)), e.superRefine = (n) => e.check(xd(n)), e.overwrite = (n) => e.check($e(n)), e.optional = () => lt(e), e.exactOptional = () => td(e), e.nullable = () => dt(e), e.nullish = () => lt(dt(e)), e.nonoptional = (n) => sd(e, n), e.array = () => pt(e), e.or = (n) => ir([e, n]), e.and = (n) => Vl(e, n), e.transform = (n) => Mr(e, ti(n)), e.default = (n) => od(e, n), e.prefault = (n) => ad(e, n), e.catch = (n) => ld(e, n), e.pipe = (n) => Mr(e, n), e.readonly = () => pd(e), e.describe = (n) => {
  let o = e.clone();
  return H.add(o, { description: n }), o;
}, Object.defineProperty(e, "description", {
  get() {
    return H.get(e)?.description;
  },
  configurable: !0
}), e.meta = (...n) => {
  if (n.length === 0)
    return H.get(e);
  let o = e.clone();
  return H.add(o, n[0]), o;
}, e.isOptional = () => e.safeParse(void 0).success, e.isNullable = () => e.safeParse(null).success, e.apply = (n) => n(e), e)), Uo = /* @__PURE__ */ f("_ZodString", (e, t) => {
  ot.init(e, t), S.init(e, t), e._zod.processJSONSchema = (o, r, i) => Nu(e, o, r, i);
  let n = e._zod.bag;
  e.format = n.format ?? null, e.minLength = n.minimum ?? null, e.maxLength = n.maximum ?? null, e.regex = (...o) => e.check(At(...o)), e.includes = (...o) => e.check(Ft(...o)), e.startsWith = (...o) => e.check(Lt(...o)), e.endsWith = (...o) => e.check(Mt(...o)), e.min = (...o) => e.check(Te(...o)), e.max = (...o) => e.check(st(...o)), e.length = (...o) => e.check(ct(...o)), e.nonempty = (...o) => e.check(Te(1, ...o)), e.lowercase = (o) => e.check(Ct(o)), e.uppercase = (o) => e.check(Rt(o)), e.trim = () => e.check(Vt()), e.normalize = (...o) => e.check(Jt(...o)), e.toLowerCase = () => e.check(qt()), e.toUpperCase = () => e.check(Wt()), e.slugify = () => e.check(Kt());
}), er = /* @__PURE__ */ f("ZodString", (e, t) => {
  ot.init(e, t), Uo.init(e, t), e.email = (n) => e.check(Xn(Do, n)), e.url = (n) => e.check(Ar(Br, n)), e.jwt = (n) => e.check(ho(Go, n)), e.emoji = (n) => e.check(to(No, n)), e.guid = (n) => e.check(Zr(Lr, n)), e.uuid = (n) => e.check(Qn(je, n)), e.uuidv4 = (n) => e.check(Hn(je, n)), e.uuidv6 = (n) => e.check(Yn(je, n)), e.uuidv7 = (n) => e.check(eo(je, n)), e.nanoid = (n) => e.check(ro(Zo, n)), e.guid = (n) => e.check(Zr(Lr, n)), e.cuid = (n) => e.check(no(Ao, n)), e.cuid2 = (n) => e.check(oo(Co, n)), e.ulid = (n) => e.check(io(Ro, n)), e.base64 = (n) => e.check(po(qo, n)), e.base64url = (n) => e.check(mo(Wo, n)), e.xid = (n) => e.check(ao(Fo, n)), e.ksuid = (n) => e.check(so(Lo, n)), e.ipv4 = (n) => e.check(co(Mo, n)), e.ipv6 = (n) => e.check(uo(Bo, n)), e.cidrv4 = (n) => e.check(lo(Jo, n)), e.cidrv6 = (n) => e.check(fo(Vo, n)), e.e164 = (n) => e.check(go(Ko, n)), e.datetime = (n) => e.check(yl(n)), e.date = (n) => e.check(bl(n)), e.time = (n) => e.check(xl(n)), e.duration = (n) => e.check($l(n));
});
function Ht(e) {
  return Gc(er, e);
}
s(Ht, "string");
var Z = /* @__PURE__ */ f("ZodStringFormat", (e, t) => {
  N.init(e, t), Uo.init(e, t);
}), Do = /* @__PURE__ */ f("ZodEmail", (e, t) => {
  os.init(e, t), Z.init(e, t);
});
function rp(e) {
  return Xn(Do, e);
}
s(rp, "email");
var Lr = /* @__PURE__ */ f("ZodGUID", (e, t) => {
  rs.init(e, t), Z.init(e, t);
});
function np(e) {
  return Zr(Lr, e);
}
s(np, "guid");
var je = /* @__PURE__ */ f("ZodUUID", (e, t) => {
  ns.init(e, t), Z.init(e, t);
});
function op(e) {
  return Qn(je, e);
}
s(op, "uuid");
function ip(e) {
  return Hn(je, e);
}
s(ip, "uuidv4");
function ap(e) {
  return Yn(je, e);
}
s(ap, "uuidv6");
function sp(e) {
  return eo(je, e);
}
s(sp, "uuidv7");
var Br = /* @__PURE__ */ f("ZodURL", (e, t) => {
  is.init(e, t), Z.init(e, t);
});
function cp(e) {
  return Ar(Br, e);
}
s(cp, "url");
function up(e) {
  return Ar(Br, {
    protocol: /^https?$/,
    hostname: me.domain,
    ...x.normalizeParams(e)
  });
}
s(up, "httpUrl");
var No = /* @__PURE__ */ f("ZodEmoji", (e, t) => {
  as.init(e, t), Z.init(e, t);
});
function lp(e) {
  return to(No, e);
}
s(lp, "emoji");
var Zo = /* @__PURE__ */ f("ZodNanoID", (e, t) => {
  ss.init(e, t), Z.init(e, t);
});
function dp(e) {
  return ro(Zo, e);
}
s(dp, "nanoid");
var Ao = /* @__PURE__ */ f("ZodCUID", (e, t) => {
  cs.init(e, t), Z.init(e, t);
});
function fp(e) {
  return no(Ao, e);
}
s(fp, "cuid");
var Co = /* @__PURE__ */ f("ZodCUID2", (e, t) => {
  us.init(e, t), Z.init(e, t);
});
function pp(e) {
  return oo(Co, e);
}
s(pp, "cuid2");
var Ro = /* @__PURE__ */ f("ZodULID", (e, t) => {
  ls.init(e, t), Z.init(e, t);
});
function mp(e) {
  return io(Ro, e);
}
s(mp, "ulid");
var Fo = /* @__PURE__ */ f("ZodXID", (e, t) => {
  ds.init(e, t), Z.init(e, t);
});
function gp(e) {
  return ao(Fo, e);
}
s(gp, "xid");
var Lo = /* @__PURE__ */ f("ZodKSUID", (e, t) => {
  fs.init(e, t), Z.init(e, t);
});
function hp(e) {
  return so(Lo, e);
}
s(hp, "ksuid");
var Mo = /* @__PURE__ */ f("ZodIPv4", (e, t) => {
  vs.init(e, t), Z.init(e, t);
});
function vp(e) {
  return co(Mo, e);
}
s(vp, "ipv4");
var El = /* @__PURE__ */ f("ZodMAC", (e, t) => {
  bs.init(e, t), Z.init(e, t);
});
function yp(e) {
  return Qc(El, e);
}
s(yp, "mac");
var Bo = /* @__PURE__ */ f("ZodIPv6", (e, t) => {
  ys.init(e, t), Z.init(e, t);
});
function bp(e) {
  return uo(Bo, e);
}
s(bp, "ipv6");
var Jo = /* @__PURE__ */ f("ZodCIDRv4", (e, t) => {
  xs.init(e, t), Z.init(e, t);
});
function xp(e) {
  return lo(Jo, e);
}
s(xp, "cidrv4");
var Vo = /* @__PURE__ */ f("ZodCIDRv6", (e, t) => {
  $s.init(e, t), Z.init(e, t);
});
function $p(e) {
  return fo(Vo, e);
}
s($p, "cidrv6");
var qo = /* @__PURE__ */ f("ZodBase64", (e, t) => {
  ws.init(e, t), Z.init(e, t);
});
function _p(e) {
  return po(qo, e);
}
s(_p, "base64");
var Wo = /* @__PURE__ */ f("ZodBase64URL", (e, t) => {
  ks.init(e, t), Z.init(e, t);
});
function wp(e) {
  return mo(Wo, e);
}
s(wp, "base64url");
var Ko = /* @__PURE__ */ f("ZodE164", (e, t) => {
  zs.init(e, t), Z.init(e, t);
});
function kp(e) {
  return go(Ko, e);
}
s(kp, "e164");
var Go = /* @__PURE__ */ f("ZodJWT", (e, t) => {
  Is.init(e, t), Z.init(e, t);
});
function zp(e) {
  return ho(Go, e);
}
s(zp, "jwt");
var tr = /* @__PURE__ */ f("ZodCustomStringFormat", (e, t) => {
  Ss.init(e, t), Z.init(e, t);
});
function Ip(e, t, n = {}) {
  return Gt(tr, e, t, n);
}
s(Ip, "stringFormat");
function Sp(e) {
  return Gt(tr, "hostname", me.hostname, e);
}
s(Sp, "hostname");
function jp(e) {
  return Gt(tr, "hex", me.hex, e);
}
s(jp, "hex");
function Op(e, t) {
  let n = t?.enc ?? "hex", o = `${e}_${n}`, r = me[o];
  if (!r)
    throw new Error(`Unrecognized hash format: ${o}`);
  return Gt(tr, o, r, t);
}
s(Op, "hash");
var rr = /* @__PURE__ */ f("ZodNumber", (e, t) => {
  qn.init(e, t), S.init(e, t), e._zod.processJSONSchema = (o, r, i) => Zu(e, o, r, i), e.gt = (o, r) => e.check(Ie(o, r)), e.gte = (o, r) => e.check(re(o, r)), e.min = (o, r) => e.check(re(o, r)), e.lt = (o, r) => e.check(ze(o, r)), e.lte = (o, r) => e.check(le(o, r)), e.max = (o, r) => e.check(le(o, r)), e.int = (o) => e.check(Eo(o)), e.safe = (o) => e.check(Eo(o)), e.positive = (o) => e.check(Ie(0, o)), e.nonnegative = (o) => e.check(re(0, o)), e.negative = (o) => e.check(ze(0, o)), e.nonpositive = (o) => e.check(le(0, o)), e.multipleOf = (o, r) => e.check(Be(o, r)), e.step = (o, r) => e.check(Be(o, r)), e.finite = () => e;
  let n = e._zod.bag;
  e.minValue = Math.max(n.minimum ?? Number.NEGATIVE_INFINITY, n.exclusiveMinimum ?? Number.NEGATIVE_INFINITY) ?? null, e.maxValue = Math.min(n.maximum ?? Number.POSITIVE_INFINITY, n.exclusiveMaximum ?? Number.POSITIVE_INFINITY) ?? null, e.isInt = (n.format ?? "").includes("int") || Number.isSafeInteger(n.multipleOf ?? 0.5), e.isFinite = !0, e.format = n.format ?? null;
});
function Jr(e) {
  return nu(rr, e);
}
s(Jr, "number");
var ft = /* @__PURE__ */ f("ZodNumberFormat", (e, t) => {
  js.init(e, t), rr.init(e, t);
});
function Eo(e) {
  return iu(ft, e);
}
s(Eo, "int");
function Pp(e) {
  return au(ft, e);
}
s(Pp, "float32");
function Tp(e) {
  return su(ft, e);
}
s(Tp, "float64");
function Ep(e) {
  return cu(ft, e);
}
s(Ep, "int32");
function Up(e) {
  return uu(ft, e);
}
s(Up, "uint32");
var nr = /* @__PURE__ */ f("ZodBoolean", (e, t) => {
  Or.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, o, r) => Au(e, n, o, r);
});
function Vr(e) {
  return lu(nr, e);
}
s(Vr, "boolean");
var or = /* @__PURE__ */ f("ZodBigInt", (e, t) => {
  Wn.init(e, t), S.init(e, t), e._zod.processJSONSchema = (o, r, i) => Cu(e, o, r, i), e.gte = (o, r) => e.check(re(o, r)), e.min = (o, r) => e.check(re(o, r)), e.gt = (o, r) => e.check(Ie(o, r)), e.gte = (o, r) => e.check(re(o, r)), e.min = (o, r) => e.check(re(o, r)), e.lt = (o, r) => e.check(ze(o, r)), e.lte = (o, r) => e.check(le(o, r)), e.max = (o, r) => e.check(le(o, r)), e.positive = (o) => e.check(Ie(BigInt(0), o)), e.negative = (o) => e.check(ze(BigInt(0), o)), e.nonpositive = (o) => e.check(le(BigInt(0), o)), e.nonnegative = (o) => e.check(re(BigInt(0), o)), e.multipleOf = (o, r) => e.check(Be(o, r));
  let n = e._zod.bag;
  e.minValue = n.minimum ?? null, e.maxValue = n.maximum ?? null, e.format = n.format ?? null;
});
function Dp(e) {
  return fu(or, e);
}
s(Dp, "bigint");
var Xo = /* @__PURE__ */ f("ZodBigIntFormat", (e, t) => {
  Os.init(e, t), or.init(e, t);
});
function Np(e) {
  return mu(Xo, e);
}
s(Np, "int64");
function Zp(e) {
  return gu(Xo, e);
}
s(Zp, "uint64");
var Ul = /* @__PURE__ */ f("ZodSymbol", (e, t) => {
  Ps.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, o, r) => Ru(e, n, o, r);
});
function Ap(e) {
  return hu(Ul, e);
}
s(Ap, "symbol");
var Dl = /* @__PURE__ */ f("ZodUndefined", (e, t) => {
  Ts.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, o, r) => Lu(e, n, o, r);
});
function Cp(e) {
  return vu(Dl, e);
}
s(Cp, "_undefined");
var Nl = /* @__PURE__ */ f("ZodNull", (e, t) => {
  Es.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, o, r) => Fu(e, n, o, r);
});
function Zl(e) {
  return yu(Nl, e);
}
s(Zl, "_null");
var Al = /* @__PURE__ */ f("ZodAny", (e, t) => {
  Us.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, o, r) => Ju(e, n, o, r);
});
function Rp() {
  return bu(Al);
}
s(Rp, "any");
var Cl = /* @__PURE__ */ f("ZodUnknown", (e, t) => {
  Ds.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, o, r) => Vu(e, n, o, r);
});
function ut() {
  return xu(Cl);
}
s(ut, "unknown");
var Rl = /* @__PURE__ */ f("ZodNever", (e, t) => {
  Ns.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, o, r) => Bu(e, n, o, r);
});
function Qo(e) {
  return $u(Rl, e);
}
s(Qo, "never");
var Fl = /* @__PURE__ */ f("ZodVoid", (e, t) => {
  Zs.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, o, r) => Mu(e, n, o, r);
});
function Fp(e) {
  return _u(Fl, e);
}
s(Fp, "_void");
var qr = /* @__PURE__ */ f("ZodDate", (e, t) => {
  Et.init(e, t), S.init(e, t), e._zod.processJSONSchema = (o, r, i) => qu(e, o, r, i), e.min = (o, r) => e.check(re(o, r)), e.max = (o, r) => e.check(le(o, r));
  let n = e._zod.bag;
  e.minDate = n.minimum ? new Date(n.minimum) : null, e.maxDate = n.maximum ? new Date(n.maximum) : null;
});
function Ho(e) {
  return wu(qr, e);
}
s(Ho, "date");
var Ll = /* @__PURE__ */ f("ZodArray", (e, t) => {
  Fe.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, o, r) => ol(e, n, o, r), e.element = t.element, e.min = (n, o) => e.check(Te(n, o)), e.nonempty = (n) => e.check(Te(1, n)), e.max = (n, o) => e.check(st(n, o)), e.length = (n, o) => e.check(ct(n, o)), e.unwrap = () => e.element;
});
function pt(e, t) {
  return Iu(Ll, e, t);
}
s(pt, "array");
function Lp(e) {
  let t = e._zod.def.shape;
  return ei(Object.keys(t));
}
s(Lp, "keyof");
var Wr = /* @__PURE__ */ f("ZodObject", (e, t) => {
  As.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, o, r) => il(e, n, o, r), x.defineLazy(e, "shape", () => t.shape), e.keyof = () => ei(Object.keys(e._zod.def.shape)), e.catchall = (n) => e.clone({ ...e._zod.def, catchall: n }), e.passthrough = () => e.clone({ ...e._zod.def, catchall: ut() }), e.loose = () => e.clone({ ...e._zod.def, catchall: ut() }), e.strict = () => e.clone({ ...e._zod.def, catchall: Qo() }), e.strip = () => e.clone({ ...e._zod.def, catchall: void 0 }), e.extend = (n) => x.extend(e, n), e.safeExtend = (n) => x.safeExtend(e, n), e.merge = (n) => x.merge(e, n), e.pick = (n) => x.pick(e, n), e.omit = (n) => x.omit(e, n), e.partial = (...n) => x.partial(ri, e, n[0]), e.required = (...n) => x.required(ni, e, n[0]);
});
function Yo(e, t) {
  let n = {
    type: "object",
    shape: e ?? {},
    ...x.normalizeParams(t)
  };
  return new Wr(n);
}
s(Yo, "object");
function Mp(e, t) {
  return new Wr({
    type: "object",
    shape: e,
    catchall: Qo(),
    ...x.normalizeParams(t)
  });
}
s(Mp, "strictObject");
function Bp(e, t) {
  return new Wr({
    type: "object",
    shape: e,
    catchall: ut(),
    ...x.normalizeParams(t)
  });
}
s(Bp, "looseObject");
var Kr = /* @__PURE__ */ f("ZodUnion", (e, t) => {
  te.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, o, r) => wo(e, n, o, r), e.options = t.options;
});
function ir(e, t) {
  return new Kr({
    type: "union",
    options: e,
    ...x.normalizeParams(t)
  });
}
s(ir, "union");
var Ml = /* @__PURE__ */ f("ZodXor", (e, t) => {
  Kr.init(e, t), Cs.init(e, t), e._zod.processJSONSchema = (n, o, r) => wo(e, n, o, r), e.options = t.options;
});
function Jp(e, t) {
  return new Ml({
    type: "union",
    options: e,
    inclusive: !1,
    ...x.normalizeParams(t)
  });
}
s(Jp, "xor");
var Bl = /* @__PURE__ */ f("ZodDiscriminatedUnion", (e, t) => {
  Kr.init(e, t), Le.init(e, t);
});
function Vp(e, t, n) {
  return new Bl({
    type: "union",
    options: t,
    discriminator: e,
    ...x.normalizeParams(n)
  });
}
s(Vp, "discriminatedUnion");
var Jl = /* @__PURE__ */ f("ZodIntersection", (e, t) => {
  Rs.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, o, r) => al(e, n, o, r);
});
function Vl(e, t) {
  return new Jl({
    type: "intersection",
    left: e,
    right: t
  });
}
s(Vl, "intersection");
var ql = /* @__PURE__ */ f("ZodTuple", (e, t) => {
  Me.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, o, r) => sl(e, n, o, r), e.rest = (n) => e.clone({
    ...e._zod.def,
    rest: n
  });
});
function Wl(e, t, n) {
  let o = t instanceof k, r = o ? n : t, i = o ? t : null;
  return new ql({
    type: "tuple",
    items: e,
    rest: i,
    ...x.normalizeParams(r)
  });
}
s(Wl, "tuple");
var Gr = /* @__PURE__ */ f("ZodRecord", (e, t) => {
  it.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, o, r) => cl(e, n, o, r), e.keyType = t.keyType, e.valueType = t.valueType;
});
function Kl(e, t, n) {
  return new Gr({
    type: "record",
    keyType: e,
    valueType: t,
    ...x.normalizeParams(n)
  });
}
s(Kl, "record");
function qp(e, t, n) {
  let o = V(e);
  return o._zod.values = void 0, new Gr({
    type: "record",
    keyType: o,
    valueType: t,
    ...x.normalizeParams(n)
  });
}
s(qp, "partialRecord");
function Wp(e, t, n) {
  return new Gr({
    type: "record",
    keyType: e,
    valueType: t,
    mode: "loose",
    ...x.normalizeParams(n)
  });
}
s(Wp, "looseRecord");
var Gl = /* @__PURE__ */ f("ZodMap", (e, t) => {
  Fs.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, o, r) => rl(e, n, o, r), e.keyType = t.keyType, e.valueType = t.valueType, e.min = (...n) => e.check(Se(...n)), e.nonempty = (n) => e.check(Se(1, n)), e.max = (...n) => e.check(Je(...n)), e.size = (...n) => e.check(at(...n));
});
function Kp(e, t, n) {
  return new Gl({
    type: "map",
    keyType: e,
    valueType: t,
    ...x.normalizeParams(n)
  });
}
s(Kp, "map");
var Xl = /* @__PURE__ */ f("ZodSet", (e, t) => {
  Ls.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, o, r) => nl(e, n, o, r), e.min = (...n) => e.check(Se(...n)), e.nonempty = (n) => e.check(Se(1, n)), e.max = (...n) => e.check(Je(...n)), e.size = (...n) => e.check(at(...n));
});
function Gp(e, t) {
  return new Xl({
    type: "set",
    valueType: e,
    ...x.normalizeParams(t)
  });
}
s(Gp, "set");
var Yt = /* @__PURE__ */ f("ZodEnum", (e, t) => {
  Ut.init(e, t), S.init(e, t), e._zod.processJSONSchema = (o, r, i) => Wu(e, o, r, i), e.enum = t.entries, e.options = Object.values(t.entries);
  let n = new Set(Object.keys(t.entries));
  e.extract = (o, r) => {
    let i = {};
    for (let a of o)
      if (n.has(a))
        i[a] = t.entries[a];
      else
        throw new Error(`Key ${a} not found in enum`);
    return new Yt({
      ...t,
      checks: [],
      ...x.normalizeParams(r),
      entries: i
    });
  }, e.exclude = (o, r) => {
    let i = { ...t.entries };
    for (let a of o)
      if (n.has(a))
        delete i[a];
      else
        throw new Error(`Key ${a} not found in enum`);
    return new Yt({
      ...t,
      checks: [],
      ...x.normalizeParams(r),
      entries: i
    });
  };
});
function ei(e, t) {
  let n = Array.isArray(e) ? Object.fromEntries(e.map((o) => [o, o])) : e;
  return new Yt({
    type: "enum",
    entries: n,
    ...x.normalizeParams(t)
  });
}
s(ei, "_enum");
function Xp(e, t) {
  return new Yt({
    type: "enum",
    entries: e,
    ...x.normalizeParams(t)
  });
}
s(Xp, "nativeEnum");
var Ql = /* @__PURE__ */ f("ZodLiteral", (e, t) => {
  Dt.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, o, r) => Ku(e, n, o, r), e.values = new Set(t.values), Object.defineProperty(e, "value", {
    get() {
      if (t.values.length > 1)
        throw new Error("This schema contains multiple valid literal values. Use `.values` instead.");
      return t.values[0];
    }
  });
});
function Qp(e, t) {
  return new Ql({
    type: "literal",
    values: Array.isArray(e) ? e : [e],
    ...x.normalizeParams(t)
  });
}
s(Qp, "literal");
var Hl = /* @__PURE__ */ f("ZodFile", (e, t) => {
  Ms.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, o, r) => Qu(e, n, o, r), e.min = (n, o) => e.check(Se(n, o)), e.max = (n, o) => e.check(Je(n, o)), e.mime = (n, o) => e.check(Bt(Array.isArray(n) ? n : [n], o));
});
function Hp(e) {
  return Su(Hl, e);
}
s(Hp, "file");
var Yl = /* @__PURE__ */ f("ZodTransform", (e, t) => {
  Bs.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, o, r) => tl(e, n, o, r), e._zod.parse = (n, o) => {
    if (o.direction === "backward")
      throw new De(e.constructor.name);
    n.addIssue = (i) => {
      if (typeof i == "string")
        n.issues.push(x.issue(i, n.value, t));
      else {
        let a = i;
        a.fatal && (a.continue = !1), a.code ?? (a.code = "custom"), a.input ?? (a.input = n.value), a.inst ?? (a.inst = e), n.issues.push(x.issue(a));
      }
    };
    let r = t.transform(n.value, n);
    return r instanceof Promise ? r.then((i) => (n.value = i, n)) : (n.value = r, n);
  };
});
function ti(e) {
  return new Yl({
    type: "transform",
    transform: e
  });
}
s(ti, "transform");
var ri = /* @__PURE__ */ f("ZodOptional", (e, t) => {
  M.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, o, r) => ko(e, n, o, r), e.unwrap = () => e._zod.def.innerType;
});
function lt(e) {
  return new ri({
    type: "optional",
    innerType: e
  });
}
s(lt, "optional");
var ed = /* @__PURE__ */ f("ZodExactOptional", (e, t) => {
  Js.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, o, r) => ko(e, n, o, r), e.unwrap = () => e._zod.def.innerType;
});
function td(e) {
  return new ed({
    type: "optional",
    innerType: e
  });
}
s(td, "exactOptional");
var rd = /* @__PURE__ */ f("ZodNullable", (e, t) => {
  be.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, o, r) => ul(e, n, o, r), e.unwrap = () => e._zod.def.innerType;
});
function dt(e) {
  return new rd({
    type: "nullable",
    innerType: e
  });
}
s(dt, "nullable");
function Yp(e) {
  return lt(dt(e));
}
s(Yp, "nullish");
var nd = /* @__PURE__ */ f("ZodDefault", (e, t) => {
  ue.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, o, r) => dl(e, n, o, r), e.unwrap = () => e._zod.def.innerType, e.removeDefault = e.unwrap;
});
function od(e, t) {
  return new nd({
    type: "default",
    innerType: e,
    get defaultValue() {
      return typeof t == "function" ? t() : x.shallowClone(t);
    }
  });
}
s(od, "_default");
var id = /* @__PURE__ */ f("ZodPrefault", (e, t) => {
  Vs.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, o, r) => fl(e, n, o, r), e.unwrap = () => e._zod.def.innerType;
});
function ad(e, t) {
  return new id({
    type: "prefault",
    innerType: e,
    get defaultValue() {
      return typeof t == "function" ? t() : x.shallowClone(t);
    }
  });
}
s(ad, "prefault");
var ni = /* @__PURE__ */ f("ZodNonOptional", (e, t) => {
  qs.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, o, r) => ll(e, n, o, r), e.unwrap = () => e._zod.def.innerType;
});
function sd(e, t) {
  return new ni({
    type: "nonoptional",
    innerType: e,
    ...x.normalizeParams(t)
  });
}
s(sd, "nonoptional");
var cd = /* @__PURE__ */ f("ZodSuccess", (e, t) => {
  Ws.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, o, r) => Hu(e, n, o, r), e.unwrap = () => e._zod.def.innerType;
});
function em(e) {
  return new cd({
    type: "success",
    innerType: e
  });
}
s(em, "success");
var ud = /* @__PURE__ */ f("ZodCatch", (e, t) => {
  Ks.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, o, r) => pl(e, n, o, r), e.unwrap = () => e._zod.def.innerType, e.removeCatch = e.unwrap;
});
function ld(e, t) {
  return new ud({
    type: "catch",
    innerType: e,
    catchValue: typeof t == "function" ? t : () => t
  });
}
s(ld, "_catch");
var dd = /* @__PURE__ */ f("ZodNaN", (e, t) => {
  Gs.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, o, r) => Gu(e, n, o, r);
});
function tm(e) {
  return zu(dd, e);
}
s(tm, "nan");
var oi = /* @__PURE__ */ f("ZodPipe", (e, t) => {
  Xs.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, o, r) => ml(e, n, o, r), e.in = t.in, e.out = t.out;
});
function Mr(e, t) {
  return new oi({
    type: "pipe",
    in: e,
    out: t
    // ...util.normalizeParams(params),
  });
}
s(Mr, "pipe");
var ii = /* @__PURE__ */ f("ZodCodec", (e, t) => {
  oi.init(e, t), xe.init(e, t);
});
function ai(e, t, n) {
  return new ii({
    type: "pipe",
    in: e,
    out: t,
    transform: n.decode,
    reverseTransform: n.encode
  });
}
s(ai, "codec");
var fd = /* @__PURE__ */ f("ZodReadonly", (e, t) => {
  Qs.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, o, r) => gl(e, n, o, r), e.unwrap = () => e._zod.def.innerType;
});
function pd(e) {
  return new fd({
    type: "readonly",
    innerType: e
  });
}
s(pd, "readonly");
var md = /* @__PURE__ */ f("ZodTemplateLiteral", (e, t) => {
  Hs.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, o, r) => Xu(e, n, o, r);
});
function rm(e, t) {
  return new md({
    type: "template_literal",
    parts: e,
    ...x.normalizeParams(t)
  });
}
s(rm, "templateLiteral");
var gd = /* @__PURE__ */ f("ZodLazy", (e, t) => {
  Nt.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, o, r) => vl(e, n, o, r), e.unwrap = () => e._zod.def.getter();
});
function hd(e) {
  return new gd({
    type: "lazy",
    getter: e
  });
}
s(hd, "lazy");
var vd = /* @__PURE__ */ f("ZodPromise", (e, t) => {
  ec.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, o, r) => hl(e, n, o, r), e.unwrap = () => e._zod.def.innerType;
});
function nm(e) {
  return new vd({
    type: "promise",
    innerType: e
  });
}
s(nm, "promise");
var yd = /* @__PURE__ */ f("ZodFunction", (e, t) => {
  Ys.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, o, r) => el(e, n, o, r);
});
function om(e) {
  return new yd({
    type: "function",
    input: Array.isArray(e?.input) ? Wl(e?.input) : e?.input ?? pt(ut()),
    output: e?.output ?? ut()
  });
}
s(om, "_function");
var Xr = /* @__PURE__ */ f("ZodCustom", (e, t) => {
  Pr.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, o, r) => Yu(e, n, o, r);
});
function im(e) {
  let t = new C({
    check: "custom"
    // ...util.normalizeParams(params),
  });
  return t._zod.check = e, t;
}
s(im, "check");
function am(e, t) {
  return ju(Xr, e ?? (() => !0), t);
}
s(am, "custom");
function bd(e, t = {}) {
  return Ou(Xr, e, t);
}
s(bd, "refine");
function xd(e) {
  return Pu(e);
}
s(xd, "superRefine");
var sm = Tu, cm = Eu;
function si(e, t = {}) {
  let n = new Xr({
    type: "custom",
    check: "custom",
    fn: /* @__PURE__ */ s((o) => o instanceof e, "fn"),
    abort: !0,
    ...x.normalizeParams(t)
  });
  return n._zod.bag.Class = e, n._zod.check = (o) => {
    o.value instanceof e || o.issues.push({
      code: "invalid_type",
      expected: e.name,
      input: o.value,
      inst: n,
      path: [...n._zod.def.path ?? []]
    });
  }, n;
}
s(si, "_instanceof");
var um = /* @__PURE__ */ s((...e) => Uu({
  Codec: ii,
  Boolean: nr,
  String: er
}, ...e), "stringbool");
function lm(e) {
  let t = hd(() => ir([Ht(e), Jr(), Vr(), Zl(), pt(t), Kl(Ht(), t)]));
  return t;
}
s(lm, "json");
function dm(e, t) {
  return Mr(ti(e), t);
}
s(dm, "preprocess");

// versions/4.3.6/node_modules/zod/v4/classic/compat.js
var qy = {
  invalid_type: "invalid_type",
  too_big: "too_big",
  too_small: "too_small",
  invalid_format: "invalid_format",
  not_multiple_of: "not_multiple_of",
  unrecognized_keys: "unrecognized_keys",
  invalid_union: "invalid_union",
  invalid_key: "invalid_key",
  invalid_element: "invalid_element",
  invalid_value: "invalid_value",
  custom: "custom"
};
function Wy(e) {
  B({
    customError: e
  });
}
s(Wy, "setErrorMap");
function Ky() {
  return B().customError;
}
s(Ky, "getErrorMap");
var $d;
$d || ($d = {});

// versions/4.3.6/node_modules/zod/v4/classic/from-json-schema.js
var _ = {
  ...Cr,
  ...So,
  iso: Qt
}, Gy = /* @__PURE__ */ new Set([
  // Schema identification
  "$schema",
  "$ref",
  "$defs",
  "definitions",
  // Core schema keywords
  "$id",
  "id",
  "$comment",
  "$anchor",
  "$vocabulary",
  "$dynamicRef",
  "$dynamicAnchor",
  // Type
  "type",
  "enum",
  "const",
  // Composition
  "anyOf",
  "oneOf",
  "allOf",
  "not",
  // Object
  "properties",
  "required",
  "additionalProperties",
  "patternProperties",
  "propertyNames",
  "minProperties",
  "maxProperties",
  // Array
  "items",
  "prefixItems",
  "additionalItems",
  "minItems",
  "maxItems",
  "uniqueItems",
  "contains",
  "minContains",
  "maxContains",
  // String
  "minLength",
  "maxLength",
  "pattern",
  "format",
  // Number
  "minimum",
  "maximum",
  "exclusiveMinimum",
  "exclusiveMaximum",
  "multipleOf",
  // Already handled metadata
  "description",
  "default",
  // Content
  "contentEncoding",
  "contentMediaType",
  "contentSchema",
  // Unsupported (error-throwing)
  "unevaluatedItems",
  "unevaluatedProperties",
  "if",
  "then",
  "else",
  "dependentSchemas",
  "dependentRequired",
  // OpenAPI
  "nullable",
  "readOnly"
]);
function Xy(e, t) {
  let n = e.$schema;
  return n === "https://json-schema.org/draft/2020-12/schema" ? "draft-2020-12" : n === "http://json-schema.org/draft-07/schema#" ? "draft-7" : n === "http://json-schema.org/draft-04/schema#" ? "draft-4" : t ?? "draft-2020-12";
}
s(Xy, "detectVersion");
function Qy(e, t) {
  if (!e.startsWith("#"))
    throw new Error("External $ref is not supported, only local refs (#/...) are allowed");
  let n = e.slice(1).split("/").filter(Boolean);
  if (n.length === 0)
    return t.rootSchema;
  let o = t.version === "draft-2020-12" ? "$defs" : "definitions";
  if (n[0] === o) {
    let r = n[1];
    if (!r || !t.defs[r])
      throw new Error(`Reference not found: ${e}`);
    return t.defs[r];
  }
  throw new Error(`Reference not found: ${e}`);
}
s(Qy, "resolveRef");
function fm(e, t) {
  if (e.not !== void 0) {
    if (typeof e.not == "object" && Object.keys(e.not).length === 0)
      return _.never();
    throw new Error("not is not supported in Zod (except { not: {} } for never)");
  }
  if (e.unevaluatedItems !== void 0)
    throw new Error("unevaluatedItems is not supported");
  if (e.unevaluatedProperties !== void 0)
    throw new Error("unevaluatedProperties is not supported");
  if (e.if !== void 0 || e.then !== void 0 || e.else !== void 0)
    throw new Error("Conditional schemas (if/then/else) are not supported");
  if (e.dependentSchemas !== void 0 || e.dependentRequired !== void 0)
    throw new Error("dependentSchemas and dependentRequired are not supported");
  if (e.$ref) {
    let r = e.$ref;
    if (t.refs.has(r))
      return t.refs.get(r);
    if (t.processing.has(r))
      return _.lazy(() => {
        if (!t.refs.has(r))
          throw new Error(`Circular reference not resolved: ${r}`);
        return t.refs.get(r);
      });
    t.processing.add(r);
    let i = Qy(r, t), a = Y(i, t);
    return t.refs.set(r, a), t.processing.delete(r), a;
  }
  if (e.enum !== void 0) {
    let r = e.enum;
    if (t.version === "openapi-3.0" && e.nullable === !0 && r.length === 1 && r[0] === null)
      return _.null();
    if (r.length === 0)
      return _.never();
    if (r.length === 1)
      return _.literal(r[0]);
    if (r.every((a) => typeof a == "string"))
      return _.enum(r);
    let i = r.map((a) => _.literal(a));
    return i.length < 2 ? i[0] : _.union([i[0], i[1], ...i.slice(2)]);
  }
  if (e.const !== void 0)
    return _.literal(e.const);
  let n = e.type;
  if (Array.isArray(n)) {
    let r = n.map((i) => {
      let a = { ...e, type: i };
      return fm(a, t);
    });
    return r.length === 0 ? _.never() : r.length === 1 ? r[0] : _.union(r);
  }
  if (!n)
    return _.any();
  let o;
  switch (n) {
    case "string": {
      let r = _.string();
      if (e.format) {
        let i = e.format;
        i === "email" ? r = r.check(_.email()) : i === "uri" || i === "uri-reference" ? r = r.check(_.url()) : i === "uuid" || i === "guid" ? r = r.check(_.uuid()) : i === "date-time" ? r = r.check(_.iso.datetime()) : i === "date" ? r = r.check(_.iso.date()) : i === "time" ? r = r.check(_.iso.time()) : i === "duration" ? r = r.check(_.iso.duration()) : i === "ipv4" ? r = r.check(_.ipv4()) : i === "ipv6" ? r = r.check(_.ipv6()) : i === "mac" ? r = r.check(_.mac()) : i === "cidr" ? r = r.check(_.cidrv4()) : i === "cidr-v6" ? r = r.check(_.cidrv6()) : i === "base64" ? r = r.check(_.base64()) : i === "base64url" ? r = r.check(_.base64url()) : i === "e164" ? r = r.check(_.e164()) : i === "jwt" ? r = r.check(_.jwt()) : i === "emoji" ? r = r.check(_.emoji()) : i === "nanoid" ? r = r.check(_.nanoid()) : i === "cuid" ? r = r.check(_.cuid()) : i === "cuid2" ? r = r.check(_.cuid2()) : i === "ulid" ? r = r.check(_.ulid()) : i === "xid" ? r = r.check(_.xid()) : i === "ksuid" && (r = r.check(_.ksuid()));
      }
      typeof e.minLength == "number" && (r = r.min(e.minLength)), typeof e.maxLength == "number" && (r = r.max(e.maxLength)), e.pattern && (r = r.regex(new RegExp(e.pattern))), o = r;
      break;
    }
    case "number":
    case "integer": {
      let r = n === "integer" ? _.number().int() : _.number();
      typeof e.minimum == "number" && (r = r.min(e.minimum)), typeof e.maximum == "number" && (r = r.max(e.maximum)), typeof e.exclusiveMinimum == "number" ? r = r.gt(e.exclusiveMinimum) : e.exclusiveMinimum === !0 && typeof e.minimum == "number" && (r = r.gt(e.minimum)), typeof e.exclusiveMaximum == "number" ? r = r.lt(e.exclusiveMaximum) : e.exclusiveMaximum === !0 && typeof e.maximum == "number" && (r = r.lt(e.maximum)), typeof e.multipleOf == "number" && (r = r.multipleOf(e.multipleOf)), o = r;
      break;
    }
    case "boolean": {
      o = _.boolean();
      break;
    }
    case "null": {
      o = _.null();
      break;
    }
    case "object": {
      let r = {}, i = e.properties || {}, a = new Set(e.required || []);
      for (let [u, l] of Object.entries(i)) {
        let d = Y(l, t);
        r[u] = a.has(u) ? d : d.optional();
      }
      if (e.propertyNames) {
        let u = Y(e.propertyNames, t), l = e.additionalProperties && typeof e.additionalProperties == "object" ? Y(e.additionalProperties, t) : _.any();
        if (Object.keys(r).length === 0) {
          o = _.record(u, l);
          break;
        }
        let d = _.object(r).passthrough(), p = _.looseRecord(u, l);
        o = _.intersection(d, p);
        break;
      }
      if (e.patternProperties) {
        let u = e.patternProperties, l = Object.keys(u), d = [];
        for (let h of l) {
          let v = Y(u[h], t), O = _.string().regex(new RegExp(h));
          d.push(_.looseRecord(O, v));
        }
        let p = [];
        if (Object.keys(r).length > 0 && p.push(_.object(r).passthrough()), p.push(...d), p.length === 0)
          o = _.object({}).passthrough();
        else if (p.length === 1)
          o = p[0];
        else {
          let h = _.intersection(p[0], p[1]);
          for (let v = 2; v < p.length; v++)
            h = _.intersection(h, p[v]);
          o = h;
        }
        break;
      }
      let c = _.object(r);
      e.additionalProperties === !1 ? o = c.strict() : typeof e.additionalProperties == "object" ? o = c.catchall(Y(e.additionalProperties, t)) : o = c.passthrough();
      break;
    }
    case "array": {
      let r = e.prefixItems, i = e.items;
      if (r && Array.isArray(r)) {
        let a = r.map((u) => Y(u, t)), c = i && typeof i == "object" && !Array.isArray(i) ? Y(i, t) : void 0;
        c ? o = _.tuple(a).rest(c) : o = _.tuple(a), typeof e.minItems == "number" && (o = o.check(_.minLength(e.minItems))), typeof e.maxItems == "number" && (o = o.check(_.maxLength(e.maxItems)));
      } else if (Array.isArray(i)) {
        let a = i.map((u) => Y(u, t)), c = e.additionalItems && typeof e.additionalItems == "object" ? Y(e.additionalItems, t) : void 0;
        c ? o = _.tuple(a).rest(c) : o = _.tuple(a), typeof e.minItems == "number" && (o = o.check(_.minLength(e.minItems))), typeof e.maxItems == "number" && (o = o.check(_.maxLength(e.maxItems)));
      } else if (i !== void 0) {
        let a = Y(i, t), c = _.array(a);
        typeof e.minItems == "number" && (c = c.min(e.minItems)), typeof e.maxItems == "number" && (c = c.max(e.maxItems)), o = c;
      } else
        o = _.array(_.any());
      break;
    }
    default:
      throw new Error(`Unsupported type: ${n}`);
  }
  return e.description && (o = o.describe(e.description)), e.default !== void 0 && (o = o.default(e.default)), o;
}
s(fm, "convertBaseSchema");
function Y(e, t) {
  if (typeof e == "boolean")
    return e ? _.any() : _.never();
  let n = fm(e, t), o = e.type || e.enum !== void 0 || e.const !== void 0;
  if (e.anyOf && Array.isArray(e.anyOf)) {
    let c = e.anyOf.map((l) => Y(l, t)), u = _.union(c);
    n = o ? _.intersection(n, u) : u;
  }
  if (e.oneOf && Array.isArray(e.oneOf)) {
    let c = e.oneOf.map((l) => Y(l, t)), u = _.xor(c);
    n = o ? _.intersection(n, u) : u;
  }
  if (e.allOf && Array.isArray(e.allOf))
    if (e.allOf.length === 0)
      n = o ? n : _.any();
    else {
      let c = o ? n : Y(e.allOf[0], t), u = o ? 0 : 1;
      for (let l = u; l < e.allOf.length; l++)
        c = _.intersection(c, Y(e.allOf[l], t));
      n = c;
    }
  e.nullable === !0 && t.version === "openapi-3.0" && (n = _.nullable(n)), e.readOnly === !0 && (n = _.readonly(n));
  let r = {}, i = ["$id", "id", "$comment", "$anchor", "$vocabulary", "$dynamicRef", "$dynamicAnchor"];
  for (let c of i)
    c in e && (r[c] = e[c]);
  let a = ["contentEncoding", "contentMediaType", "contentSchema"];
  for (let c of a)
    c in e && (r[c] = e[c]);
  for (let c of Object.keys(e))
    Gy.has(c) || (r[c] = e[c]);
  return Object.keys(r).length > 0 && t.registry.add(n, r), n;
}
s(Y, "convertSchema");
function pm(e, t) {
  if (typeof e == "boolean")
    return e ? _.any() : _.never();
  let n = Xy(e, t?.defaultTarget), o = e.$defs || e.definitions || {}, r = {
    version: n,
    defs: o,
    refs: /* @__PURE__ */ new Map(),
    processing: /* @__PURE__ */ new Set(),
    rootSchema: e,
    registry: t?.registry ?? H
  };
  return Y(e, r);
}
s(pm, "fromJSONSchema");

// versions/4.3.6/node_modules/zod/v4/classic/coerce.js
var _d = {};
Oe(_d, {
  bigint: () => tb,
  boolean: () => eb,
  date: () => rb,
  number: () => Yy,
  string: () => Hy
});
function Hy(e) {
  return Xc(er, e);
}
s(Hy, "string");
function Yy(e) {
  return ou(rr, e);
}
s(Yy, "number");
function eb(e) {
  return du(nr, e);
}
s(eb, "boolean");
function tb(e) {
  return pu(or, e);
}
s(tb, "bigint");
function rb(e) {
  return ku(qr, e);
}
s(rb, "date");

// versions/4.3.6/node_modules/zod/v4/classic/external.js
B(Tr());

// node_modules/zodvex/dist/index.js
var mm = /* @__PURE__ */ new WeakMap(), ob = {
  getMetadata: /* @__PURE__ */ s((e) => mm.get(e), "getMetadata"),
  setMetadata: /* @__PURE__ */ s((e, t) => mm.set(e, t), "setMetadata")
};
var DS = w.discriminatedUnion("success", [
  w.object({ success: w.literal(!0) }),
  w.object({ success: w.literal(!1), error: w.string() })
]), NS = w.object({
  formErrors: w.array(w.string()),
  fieldErrors: w.record(w.string(), w.array(w.string()))
});
var ib = "__zodvexMeta";
function vm(e, t) {
  Object.defineProperty(e, ib, {
    value: t,
    enumerable: !1,
    writable: !1,
    configurable: !1
  });
}
s(vm, "attachMeta");
function wd(e) {
  let t = w.string().check(
    w.refine((o) => typeof o == "string" && o.length > 0, {
      message: `Invalid ID for table "${e}"`
    }),
    w.describe(`convexId:${e}`)
  );
  ob.setMetadata(t, {
    isConvexId: !0,
    tableName: e
  });
  let n = t;
  return n._tableName = e, n;
}
s(wd, "id");
function ym(e) {
  return e instanceof te || e instanceof Le;
}
s(ym, "isZodUnion");
function bm(e) {
  return e instanceof te, e._zod.def.options;
}
s(bm, "getUnionOptions");
function ab(e) {
  if (e.length < 2)
    throw new Error(
      `z.union() requires at least 2 options, but received ${e.length}. This indicates an invalid union schema was passed to zodTable().`
    );
}
s(ab, "assertUnionOptions");
function xm(e) {
  return ab(e), w.union(e);
}
s(xm, "createUnionFromOptions");
function $m(e, t) {
  if (ym(t)) {
    let o = bm(t).map((r) => {
      if (r instanceof q) {
        let i = {
          ...r._zod.def.shape,
          _id: wd(e),
          _creationTime: w.number()
        };
        return V(r, { ...r._zod.def, shape: i });
      }
      return r;
    });
    return xm(o);
  }
  if (t instanceof q) {
    let n = { ...t._zod.def.shape, _id: wd(e), _creationTime: w.number() };
    return V(t, { ...t._zod.def, shape: n });
  }
  return t;
}
s($m, "addSystemFields");
function sb(e) {
  return e instanceof M ? e : new M({ type: "optional", innerType: e });
}
s(sb, "ensureOptional");
function gm(e) {
  return new M({
    type: "optional",
    innerType: new be({ type: "nullable", innerType: e })
  });
}
s(gm, "nullableOptional2");
function cb(e) {
  let t = {};
  for (let [n, o] of Object.entries(e))
    t[n] = sb(o);
  return t;
}
s(cb, "createPartialShape");
function kd(e, t) {
  return w.object({
    _id: wd(e),
    _creationTime: w.optional(w.number()),
    ...cb(t)
  });
}
s(kd, "createUpdateObjectSchema");
function _m(e) {
  return w.object({
    page: w.array(e),
    isDone: w.boolean(),
    continueCursor: w.string(),
    splitCursor: gm(w.string()),
    pageStatus: gm(w.enum(["SplitRecommended", "SplitRequired"]))
  });
}
s(_m, "createPaginatedDocSchema");
function ub(e, t, n = w.object(t)) {
  let o = $m(e, n);
  return {
    doc: o,
    base: n,
    insert: n,
    update: kd(e, t),
    docArray: w.array(o),
    paginatedDoc: _m(o)
  };
}
s(ub, "createObjectSchemaBundle");
function lb(e, t) {
  if (ym(t)) {
    let n = bm(t).map((o) => o instanceof q ? kd(e, o._zod.def.shape) : o);
    return xm(n);
  }
  return t instanceof q ? kd(e, t._zod.def.shape) : t;
}
s(lb, "createSchemaUpdateSchema");
function db(e, t) {
  let n = $m(e, t);
  return {
    doc: n,
    base: t,
    insert: t,
    update: lb(e, t),
    docArray: w.array(n),
    paginatedDoc: _m(n)
  };
}
s(db, "createSchemaBundle");
function wm(e, t) {
  let n;
  return {
    get: /* @__PURE__ */ s(() => n || (n = t ?? w.object(e), n), "get")
  };
}
s(wm, "lazyValidator");
function Qr(e, t, n, o, r = {}, i = {}, a = {}, c = null) {
  let u = wm(t, c), l = {
    name: e,
    fields: t,
    schema: n,
    indexes: r,
    searchIndexes: i,
    vectorIndexes: a,
    get validator() {
      return u.get();
    },
    index(d, p) {
      return Qr(
        e,
        t,
        n,
        o,
        { ...r, [d]: [...p, "_creationTime"] },
        i,
        a,
        c
      );
    },
    searchIndex(d, p) {
      return Qr(
        e,
        t,
        n,
        o,
        r,
        { ...i, [d]: p },
        a,
        c
      );
    },
    vectorIndex(d, p) {
      return Qr(
        e,
        t,
        n,
        o,
        r,
        i,
        { ...a, [d]: p },
        c
      );
    }
  };
  return vm(l, { type: "model", tableName: e, definitionSource: o, schemas: n }), l;
}
s(Qr, "createModel");
function Hr(e, t, n, o, r = {}, i = {}, a = {}) {
  let c = wm(t, n), u = {
    name: e,
    fields: t,
    indexes: r,
    searchIndexes: i,
    vectorIndexes: a,
    get validator() {
      return c.get();
    },
    index(l, d) {
      return Hr(
        e,
        t,
        n,
        o,
        { ...r, [l]: [...d, "_creationTime"] },
        i,
        a
      );
    },
    searchIndex(l, d) {
      return Hr(
        e,
        t,
        n,
        o,
        r,
        { ...i, [l]: d },
        a
      );
    },
    vectorIndex(l, d) {
      return Hr(e, t, n, o, r, i, {
        ...a,
        [l]: d
      });
    }
  };
  return n !== null && (u.schema = n), vm(u, { type: "model", tableName: e, definitionSource: o }), u;
}
s(Hr, "createSlimModel");
function hm(e, t, n) {
  let o = n?.schemaHelpers === !1;
  if (t instanceof k)
    return o ? Hr(e, {}, t, "schema") : Qr(
      e,
      {},
      db(e, t),
      "schema",
      void 0,
      void 0,
      void 0,
      t
    );
  let r = t;
  return o ? Hr(e, r, null, "shape") : Qr(e, r, ub(e, r), "shape");
}
s(hm, "defineZodModel");
function km(e, t, n) {
  return t instanceof k, hm(e, t, n);
}
s(km, "defineZodModel2");
function ci(e) {
  let t = /* @__PURE__ */ Symbol.for(`zodvex.zx.cache.${e}`), n = globalThis, o = n[t];
  if (o) return o;
  let r = /* @__PURE__ */ new WeakMap();
  return n[t] = r, r;
}
s(ci, "sharedWeakMap");
var ZS = ci("base"), AS = ci("doc"), CS = ci("update"), RS = ci("docArray");

// ../zodvex-triage-20260909/node_modules/.bun/convex-helpers@0.1.113+b9ed8f5244cf7f28/node_modules/convex-helpers/index.js
var MS = Symbol();

// ../zodvex-triage-20260909/node_modules/.bun/convex-helpers@0.1.113+b9ed8f5244cf7f28/node_modules/convex-helpers/validators.js
var KS = g.string(), GS = g.float64(), XS = g.float64(), QS = g.boolean(), HS = g.int64(), YS = g.int64(), ej = g.any(), tj = g.null(), { id: rj, object: nj, array: oj, bytes: ij, literal: aj, optional: sj, union: cj } = g, uj = g.bytes();
var lj = g.optional(g.any());

// ../zodvex-triage-20260909/node_modules/.bun/convex-helpers@0.1.113+b9ed8f5244cf7f28/node_modules/convex-helpers/server/customFunctions.js
var ui = {
  args: {},
  input() {
    return { args: {}, ctx: {} };
  }
};

// node_modules/zodvex/dist/server/index.js
function zm(e) {
  let t = e;
  for (let n = 0; n < 10; n++) {
    if (t instanceof M || t instanceof be || t instanceof ue) {
      t = t._zod.def.innerType;
      continue;
    }
    break;
  }
  return t;
}
s(zm, "unwrapOuter");
function fb(e, t) {
  let n = [], o = t;
  for (let r of e) {
    if (o = zm(o), o instanceof xe)
      break;
    if (o instanceof q && typeof r == "string") {
      let i = o._zod.def.shape[r];
      if (!i) {
        n.push(r);
        break;
      }
      if (n.push(r), zm(i) instanceof xe)
        break;
      o = i;
      continue;
    }
    if (o instanceof Fe && typeof r == "number") {
      n.push(r), o = o._zod.def.element;
      continue;
    }
    n.push(r);
  }
  return n;
}
s(fb, "truncateAtCodecBoundary");
function pb(e, t) {
  let n = e.issues.map((o) => ({
    ...o,
    path: fb(o.path, t)
  }));
  return new ve(n);
}
s(pb, "normalizeCodecPaths");
function mb(e, t) {
  try {
    return ye(e, t);
  } catch (n) {
    throw n instanceof ve ? pb(n, e) : n;
  }
}
s(mb, "safeEncode");
function Ke(e) {
  if (e == null)
    return e;
  if (Array.isArray(e))
    return e.map(Ke);
  if (typeof e == "object" && e.constructor === Object) {
    let t = {};
    for (let [n, o] of Object.entries(e))
      o !== void 0 && (t[n] = Ke(o));
    return t;
  }
  return e;
}
s(Ke, "stripUndefined");
var gb = /* @__PURE__ */ Symbol.for("functionName");
function Im(e) {
  if (typeof e == "string") return e;
  let t = e[gb];
  return t || null;
}
s(Im, "resolveFunctionPath");
var hb = class extends ve {
  static {
    s(this, "ZodvexDecodeError");
  }
  functionPath;
  wireData;
  constructor(e, t, n) {
    super(t), this.functionPath = e, this.wireData = n, this.name = "ZodvexDecodeError";
  }
}, Sm = /* @__PURE__ */ new Set();
function vb(e, t) {
  let n = t?.onDecodeError ?? "warn", o = t?.warnWirePreview === !0;
  function r(a, c) {
    if (c == null) return c;
    let u = Im(a);
    if (u == null) return c;
    let l = e[u];
    return l?.args ? Ke(mb(l.args, c)) : (l === void 0 && !Sm.has(u) && (Sm.add(u), console.debug(
      `[zodvex] No registry entry for "${u}" \u2014 args/returns pass through unencoded. This is expected when the target is a raw (non-zodvex) function; if it should be codec-aware, run \`zodvex generate\` to update the registry.`
    )), c);
  }
  s(r, "encodeArgs");
  function i(a, c) {
    let u = Im(a);
    if (u == null) return c;
    let l = e[u];
    if (!l?.returns) return c;
    let d = rt(l.returns, c);
    if (d.success) return d.data;
    if (n === "throw")
      throw new hb(u, d.error.issues, c);
    let p = d.error.issues.map((v) => `${v.path.join(".")}: ${v.message}`).join(", "), h = `[zodvex] Decode failed for ${u}: ${p}. Returning raw wire data.`;
    if (o) {
      let v = "[unavailable]";
      try {
        v = JSON.stringify(c) ?? "[unavailable]";
      } catch {
      }
      let O = v.length > 200 ? `${v.slice(0, 200)}...` : v;
      h += ` Preview: ${O}`;
    }
    return console.warn(h), c;
  }
  return s(i, "decodeResult"), { encodeArgs: r, decodeResult: i };
}
s(vb, "createBoundaryHelpers");
function jm(e, t) {
  return async (n, ...o) => {
    let r = t.encodeArgs(n, o[0]), i = await e(n, r);
    return t.decodeResult(n, i);
  };
}
s(jm, "wrapRun");
function yb(e, t) {
  let n = { ...e };
  return n.runAfter = (o, r, ...i) => {
    let a = t.encodeArgs(r, i[0]);
    return e.runAfter(o, r, ...i.length ? [a] : []);
  }, n.runAt = (o, r, ...i) => {
    let a = t.encodeArgs(r, i[0]);
    return e.runAt(o, r, ...i.length ? [a] : []);
  }, n;
}
s(yb, "wrapScheduler");
function Gm(e, t, n) {
  let o = vb(e, n), r = {};
  return typeof t.runQuery == "function" && (r.runQuery = jm(t.runQuery, o)), typeof t.runMutation == "function" && (r.runMutation = jm(t.runMutation, o)), t.scheduler && (r.scheduler = yb(t.scheduler, o)), r;
}
s(Gm, "createCodecCallOverrides");
var Om = /* @__PURE__ */ new WeakMap(), pi = {
  getMetadata: /* @__PURE__ */ s((e) => Om.get(e), "getMetadata"),
  setMetadata: /* @__PURE__ */ s((e, t) => Om.set(e, t), "setMetadata")
};
function bb(e) {
  let t = e._zod.def.entries, n = Object.keys(t);
  if (n && Array.isArray(n) && n.length > 0) {
    let o = n.filter((r) => r != null).map((r) => g.literal(r));
    if (o.length === 1) {
      let [r] = o;
      return r;
    } else if (o.length >= 2) {
      let [r, i, ...a] = o;
      return g.union(
        r,
        i,
        ...a
      );
    } else
      return g.any();
  } else
    return g.any();
}
s(bb, "convertEnumType");
function xb(e, t, n) {
  let o = e._zod.def.innerType;
  if (o && o instanceof k)
    if (o instanceof M) {
      let r = o._zod.def.innerType, i = n(r, t);
      return {
        validator: g.union(i, g.null()),
        isOptional: !0
        // Mark as optional so it gets wrapped later
      };
    } else {
      let r = n(o, t);
      return {
        validator: g.union(r, g.null()),
        isOptional: !1
      };
    }
  else
    return {
      validator: g.any(),
      isOptional: !1
    };
}
s(xb, "convertNullableType");
function $b(e, t, n) {
  let o = e._zod.def.valueType;
  if (o || (o = e._zod.def.keyType), o && o instanceof k)
    if (o instanceof M || o instanceof ue || o instanceof ue && o._zod.def.innerType instanceof M) {
      let i, a, c = !1;
      if (o instanceof ue) {
        c = !0, a = o._zod.def.defaultValue;
        let d = o._zod.def.innerType;
        d instanceof M ? i = d._zod.def.innerType : i = d;
      } else o instanceof M ? i = o._zod.def.innerType : i = o;
      let u = n(i, t), l = g.union(u, g.null());
      return c && (l._zodDefault = a), g.record(g.string(), l);
    } else
      return g.record(g.string(), n(o, t));
  else
    return g.record(g.string(), g.any());
}
s($b, "convertRecordType");
function _b(e, t, n) {
  let o = e instanceof Le ? e._zod.def.options : (
    // cast: fallback for non-standard discriminated union variants
    e._zod?.def?.options
  );
  if (o) {
    let r = Array.isArray(o) ? o : Array.from(o);
    if (r.length >= 2) {
      let i = r.map((l) => {
        let d = new Set(t);
        return n(l, d);
      }), [a, c, ...u] = i;
      return g.union(
        a,
        c,
        ...u
      );
    } else
      return g.any();
  } else
    return g.any();
}
s(_b, "convertDiscriminatedUnionType");
function wb(e, t, n) {
  let o = e._zod.def.options;
  if (o && Array.isArray(o) && o.length > 0) {
    if (o.length === 1)
      return n(o[0], t);
    {
      let r = o.map((i) => {
        let a = new Set(t);
        return n(i, a);
      });
      if (r.length >= 2) {
        let [i, a, ...c] = r;
        return g.union(
          i,
          a,
          ...c
        );
      } else
        return g.any();
    }
  } else
    return g.any();
}
s(wb, "convertUnionType");
function kb(e) {
  let t = pi.getMetadata(e);
  return t?.isConvexId === !0 && t?.tableName && typeof t.tableName == "string";
}
s(kb, "isZid");
var Pm = /* @__PURE__ */ new WeakMap();
function se(e, t = /* @__PURE__ */ new Set()) {
  if (!e)
    return g.any();
  let n = Pm.get(e);
  if (n)
    return n;
  if (t.has(e))
    return g.any();
  t.add(e);
  let o = e, r = !1, i, a = !1;
  e instanceof ue && (a = !0, i = e._zod.def.defaultValue, o = e._zod.def.innerType), o instanceof M && (r = !0, o = o._zod.def.innerType, o instanceof ue && (a = !0, i = o._zod.def.defaultValue, o = o._zod.def.innerType));
  let c;
  if (kb(o)) {
    let d = pi.getMetadata(o)?.tableName || "unknown";
    c = g.id(d);
  } else
    switch (o._zod.def.type) {
      case "string":
        c = g.string();
        break;
      case "number":
        c = g.float64();
        break;
      case "bigint":
        c = g.int64();
        break;
      case "boolean":
        c = g.boolean();
        break;
      case "date":
        c = g.float64();
        break;
      case "null":
        c = g.null();
        break;
      case "nan":
        c = g.float64();
        break;
      case "array": {
        if (o instanceof Fe) {
          let d = o._zod.def.element;
          c = g.array(se(d, t));
        } else
          c = g.array(g.any());
        break;
      }
      case "object": {
        if (o instanceof q) {
          let d = o._zod.def.shape, p = {};
          for (let [h, v] of Object.entries(d))
            v && v instanceof k && (p[h] = se(v, t));
          c = g.object(p);
        } else
          c = g.object({});
        break;
      }
      case "union": {
        o instanceof te ? c = wb(o, t, se) : c = g.any();
        break;
      }
      case "discriminatedUnion": {
        c = _b(
          o,
          t,
          se
        );
        break;
      }
      case "literal": {
        if (o instanceof Dt) {
          let p = o._zod.def.values.values().next().value;
          p != null ? c = g.literal(p) : c = g.any();
        } else
          c = g.any();
        break;
      }
      case "enum": {
        o instanceof Ut ? c = bb(o) : c = g.any();
        break;
      }
      case "record": {
        o instanceof it ? c = $b(o, t, se) : c = g.record(g.string(), g.any());
        break;
      }
      case "transform":
      case "pipe": {
        if (o instanceof xe) {
          let d = o._zod.def.in;
          d && d instanceof k ? c = se(d, t) : c = g.any();
        } else {
          let d = pi.getMetadata(o);
          if (d?.brand && d?.originalSchema)
            c = se(d.originalSchema, t);
          else {
            let p = o._zod?.def?.in;
            p && p instanceof k ? c = se(p, t) : c = g.any();
          }
        }
        break;
      }
      case "nullable": {
        if (o instanceof be) {
          let d = xb(o, t, se);
          c = d.validator, d.isOptional && (r = !0);
        } else
          c = g.any();
        break;
      }
      case "tuple": {
        if (o instanceof Me) {
          let d = o._zod.def.items;
          if (d && d.length > 0) {
            let p = {};
            d.forEach((h, v) => {
              p[`_${v}`] = se(h, t);
            }), c = g.object(p);
          } else
            c = g.object({});
        } else
          c = g.object({});
        break;
      }
      case "lazy": {
        if (o instanceof Nt)
          try {
            let d = o._zod.def.getter;
            if (d) {
              let p = d();
              p && p instanceof k ? c = se(p, t) : c = g.any();
            } else
              c = g.any();
          } catch {
            c = g.any();
          }
        else
          c = g.any();
        break;
      }
      case "any":
        c = g.any();
        break;
      case "unknown":
        c = g.any();
        break;
      case "undefined":
      case "void":
      case "never":
        c = g.any();
        break;
      case "intersection":
        c = g.any();
        break;
      case "optional": {
        let d = o._zod?.def?.innerType;
        d && d instanceof k ? (c = se(d, t), r = !0) : (c = g.any(), r = !0);
        break;
      }
      default:
        c = g.any();
        break;
    }
  let u = r || a ? g.optional(c) : c;
  return a && typeof u == "object" && u !== null && (u._zodDefault = i), Pm.set(e, u), u;
}
s(se, "zodToConvexInternal");
function Xm(e) {
  return typeof e == "object" && e !== null && !(e instanceof k) ? mi(e) : se(e);
}
s(Xm, "zodToConvex");
function mi(e) {
  let t = e instanceof q ? e._zod.def.shape : e, n = {};
  for (let [o, r] of Object.entries(t))
    n[o] = se(r);
  return n;
}
s(mi, "zodToConvexFields");
function mt(e) {
  if (e instanceof Et) return !0;
  if (e instanceof xe) return !1;
  if (e instanceof M || e instanceof be || e instanceof ue)
    return mt(e._zod.def.innerType);
  if (e instanceof q)
    return Object.values(e._zod.def.shape).some((t) => mt(t));
  if (e instanceof Fe)
    return mt(e._zod.def.element);
  if (e instanceof te)
    return e._zod.def.options.some((t) => mt(t));
  if (e instanceof it)
    return mt(e._zod.def.valueType);
  if (e instanceof Me) {
    let t = e._zod.def.items;
    return t ? t.some((n) => mt(n)) : !1;
  }
  return !1;
}
s(mt, "containsNativeZodDate");
function Tm(e, t) {
  if (mt(e))
    throw new Error(
      `[zodvex] Native z.date() found in ${t}. Convex stores dates as timestamps (numbers), which z.date() cannot parse.

Fix: Replace z.date() with zx.date()

Before: { createdAt: z.date() }
After:  { createdAt: zx.date() }

zx.date() is a codec that handles timestamp \u2194 Date conversion automatically.`
    );
}
s(Tm, "assertNoNativeZodDate");
function Qm(e, t) {
  return Re(e, t);
}
s(Qm, "decodeDoc");
function Em(e, t) {
  return Ke(ye(e, t));
}
s(Em, "encodeDoc");
function Um(e) {
  let t = {};
  for (let [n, o] of Object.entries(e))
    t[n] = o === void 0 ? void 0 : Ke(o);
  return t;
}
s(Um, "stripUndefinedPreservingTopLevel");
function zb(e, t) {
  if (!(e instanceof q)) {
    let a = ye(e, t);
    return a !== null && typeof a == "object" && !Array.isArray(a) ? Um(a) : Ke(a);
  }
  let n = e._zod.def.shape, o = {};
  for (let [a, c] of Object.entries(n))
    o[a] = c instanceof M ? c : new M({ type: "optional", innerType: c });
  let r = w.object(o), i = ye(r, t);
  return Um(i);
}
s(zb, "encodePartialDoc");
function Hm(e, t, n) {
  return w.codec(e, t, n);
}
s(Hm, "zodvexCodec");
function zd(e, t, n) {
  if (t.includes(".")) return n;
  if (e instanceof q) {
    let o = e.shape[t];
    if (o) return ye(o, n);
  }
  if (e instanceof te) {
    let r = e._zod.def.options.filter((i) => i instanceof q).map((i) => i.shape[t]).filter(Boolean);
    if (r.length === 1) return ye(r[0], n);
    if (r.length > 1)
      return ye(w.union(r), n);
  }
  return n;
}
s(zd, "encodeIndexValue");
function gi(e, t) {
  return new Proxy(e, {
    get(n, o, r) {
      return typeof o == "string" && ["eq", "gt", "gte", "lt", "lte"].includes(o) ? (i, a) => {
        let c = zd(t, i, a), u = n[o](i, c);
        return gi(u, t);
      } : o === "search" ? (...i) => {
        let a = n.search(...i);
        return gi(a, t);
      } : Reflect.get(n, o, r);
    }
  });
}
s(gi, "wrapIndexRangeBuilder");
function Id(e, t) {
  return e != null && Object.prototype.isPrototypeOf.call(t, e);
}
s(Id, "isFilterExpression");
function Dm(e, t) {
  if (Id(e, t)) {
    let n = e.serialize();
    if (n && typeof n == "object" && "$field" in n)
      return n.$field;
  }
  return null;
}
s(Dm, "extractFieldPath");
function Ib(e, t) {
  let n = Object.getPrototypeOf(e.field("_id"));
  return new Proxy(e, {
    get(o, r, i) {
      return typeof r == "string" && ["eq", "neq", "lt", "lte", "gt", "gte"].includes(r) ? (a, c) => {
        let u = Dm(a, n), l = Dm(c, n);
        return u && !Id(c, n) ? c = zd(t, u, c) : l && !Id(a, n) && (a = zd(t, l, a)), o[r](a, c);
      } : Reflect.get(o, r, i);
    }
  });
}
s(Ib, "wrapFilterBuilder");
var Td = class Ym {
  static {
    s(this, "_ZodvexQueryChain");
  }
  constructor(t, n) {
    this.inner = t, this.schema = n;
  }
  /** Factory method for intermediate methods. Subclasses override to return their own type. */
  createChain(t) {
    return new Ym(t, this.schema);
  }
  /** Decode a wire-format doc and cast to the decoded document type. */
  decode(t) {
    return Qm(this.schema, t);
  }
  // --- Intermediate methods: wire-typed TableInfo for Convex machinery ---
  fullTableScan() {
    return this.createChain(this.inner.fullTableScan());
  }
  withIndex(t, n) {
    let o = n ? (r) => n(gi(r, this.schema)) : void 0;
    return this.createChain(this.inner.withIndex(t, o));
  }
  withSearchIndex(t, n) {
    let o = /* @__PURE__ */ s((r) => n(gi(r, this.schema)), "wrappedFilter");
    return this.createChain(this.inner.withSearchIndex(t, o));
  }
  order(t) {
    return this.createChain(this.inner.order(t));
  }
  // Implementation
  filter(t) {
    let n = /* @__PURE__ */ s((o) => t(Ib(o, this.schema)), "wrappedPredicate");
    return this.createChain(this.inner.filter(n));
  }
  limit(t) {
    return this.createChain(this.inner.limit(t));
  }
  count() {
    return this.inner.count();
  }
  // --- Terminal methods: return decoded Doc type ---
  async first() {
    let t = await this.inner.first();
    return t ? this.decode(t) : null;
  }
  async unique() {
    let t = await this.inner.unique();
    return t ? this.decode(t) : null;
  }
  async collect() {
    return (await this.inner.collect()).map((n) => this.decode(n));
  }
  async take(t) {
    return (await this.inner.take(t)).map((o) => this.decode(o));
  }
  async paginate(t) {
    let n = await this.inner.paginate(t);
    return {
      ...n,
      page: n.page.map((o) => this.decode(o))
    };
  }
  // --- AsyncIterable: decode each yielded document ---
  async *[Symbol.asyncIterator]() {
    for await (let t of this.inner)
      yield this.decode(t);
  }
};
function Sd(e, t, n) {
  for (let o of Object.keys(t))
    if (e.normalizeId(o, n))
      return o;
  return null;
}
s(Sd, "resolveTableName");
var vi = class {
  static {
    s(this, "ZodvexDatabaseReader");
  }
  constructor(e, t) {
    this.db = e, this.tableMap = t, this.system = e.system;
  }
  system;
  /** @internal Expose for wrapper construction (rule/audit subclasses) */
  get _internals() {
    return { db: this.db, tableMap: this.tableMap };
  }
  /**
   * Escape hatch (#85/#92): returns the database this codec wrapper delegates
   * to — the composed underlying stack when `underlyingDb` is configured (e.g.
   * a trigger-wrapped writer), the bare Convex db otherwise.
   *
   * The returned db is native-shape: reads are undecoded wire documents and it
   * bypasses codec, `.withRules()`, and `.audit()` layers entirely.
   */
  unwrap() {
    return this.db;
  }
  normalizeId(e, t) {
    return this.db.normalizeId(e, t);
  }
  async get(e, t) {
    let n, o;
    if (t !== void 0 ? (n = e, o = await this.db.get(e, t)) : (o = await this.db.get(e), n = o ? Sd(this.db, this.tableMap, e) : null), !o) return null;
    let r = n ? this.tableMap[n] : void 0;
    return r ? Qm(r.doc, o) : o;
  }
  query(e) {
    let t = this.tableMap[e], n = this.db.query(e);
    return t ? new Td(n, t.doc) : n;
  }
  /**
   * Returns a new ZodvexDatabaseReader that applies per-table read rules.
   * The returned reader is also a ZodvexDatabaseReader, so `.withRules()` can be chained.
   */
  withRules(e, t, n) {
    return new tg(this, e, t, n ?? {});
  }
  /**
   * Returns a new ZodvexDatabaseReader that fires audit callbacks on reads.
   * The returned reader is also a ZodvexDatabaseReader, so `.audit()` can be chained
   * with `.withRules()`.
   */
  audit(e) {
    return new ng(this, e);
  }
}, Ed = class extends vi {
  static {
    s(this, "ZodvexDatabaseWriter");
  }
  // Narrows the inherited `protected db` to the writer-typed view without
  // shadowing the underlying instance. Used by the write methods below.
  get writerDb() {
    return this.db;
  }
  constructor(e, t) {
    super(e, t), this.system = e.system;
  }
  /**
   * @internal Expose writer-typed internals for rules / audit subclasses.
   * Includes a `reader` field that aliases `this` (writer IS-A reader after
   * the #64 refactor) so callers expecting `_internals.reader` still work.
   */
  get _internals() {
    return { db: this.writerDb, tableMap: this.tableMap, reader: this };
  }
  /**
   * Escape hatch (#85/#92): returns the writer this codec wrapper delegates
   * to — the composed underlying stack when `underlyingDb` is configured (e.g.
   * a trigger-wrapped writer), the bare Convex db otherwise.
   *
   * The returned db is native-shape: writes must be wire-format and it
   * bypasses codec, `.withRules()`, and `.audit()` layers entirely.
   */
  unwrap() {
    return this.writerDb;
  }
  async insert(e, t) {
    let n = this.tableMap[e], o = n ? Em(n.insert, t) : t;
    return this.writerDb.insert(e, o);
  }
  async patch(e, t, n) {
    let o, r, i;
    n !== void 0 ? (o = e, r = t, i = n) : (r = e, i = t, o = Sd(this.db, this.tableMap, r));
    let a = o ? this.tableMap[o] : void 0, c = a ? zb(a.insert, i) : i;
    return n !== void 0 ? this.writerDb.patch(e, r, c) : this.writerDb.patch(r, c);
  }
  async replace(e, t, n) {
    let o, r, i;
    n !== void 0 ? (o = e, r = t, i = n) : (r = e, i = t, o = Sd(this.db, this.tableMap, r));
    let a = o ? this.tableMap[o] : void 0, c = a ? Em(a.insert, i) : i;
    return n !== void 0 ? this.writerDb.replace(e, r, c) : this.writerDb.replace(r, c);
  }
  async delete(e, t) {
    return t !== void 0 ? this.writerDb.delete(e, t) : this.writerDb.delete(e);
  }
  /**
   * Returns a new ZodvexDatabaseWriter that applies per-table read and write rules.
   * The returned writer is also a ZodvexDatabaseWriter, so `.withRules()` can be chained.
   *
   * Overrides Reader's signature so a writer chained call returns a writer.
   */
  withRules(e, t, n) {
    return new jb(this, e, t, n ?? {});
  }
  /**
   * Returns a new ZodvexDatabaseWriter that fires audit callbacks on reads and writes.
   * The returned writer is also a ZodvexDatabaseWriter, so `.audit()` can be chained
   * with `.withRules()`.
   *
   * Overrides Reader's signature so a writer chained call returns a writer.
   */
  audit(e) {
    return new Pb(this, e);
  }
};
function li(e, t) {
  return e === !0 ? t : e === !1 ? null : e;
}
s(li, "normalizeReadResult");
var Sb = class eg extends Td {
  static {
    s(this, "_RulesQueryChain");
  }
  readRule;
  rulesConfig;
  ctx;
  constructor(t, n, o, r, i = {}) {
    super(t, n), this.readRule = o, this.rulesConfig = r, this.ctx = i;
  }
  createChain(t) {
    return new eg(t, this.schema, this.readRule, this.rulesConfig, this.ctx);
  }
  async first() {
    for await (let t of this)
      return t;
    return null;
  }
  async unique() {
    let t = await super.unique();
    return t === null ? null : li(await this.readRule(this.ctx, t), t);
  }
  async collect() {
    let t = [];
    for await (let n of this)
      t.push(n);
    return t;
  }
  async take(t) {
    if (!Number.isInteger(t) || t < 0)
      throw new Error("take requires a non-negative integer");
    let n = [];
    if (t === 0) return n;
    for await (let o of this)
      if (n.push(o), n.length >= t) break;
    return n;
  }
  async paginate(t) {
    let n = await super.paginate(t), o = [];
    for (let r of n.page) {
      let i = li(await this.readRule(this.ctx, r), r);
      i !== null && o.push(i);
    }
    return { ...n, page: o };
  }
  async count() {
    if (!this.rulesConfig.allowCounting)
      throw new Error("count is not allowed with rules");
    return super.count();
  }
  async *[Symbol.asyncIterator]() {
    for await (let t of super[Symbol.asyncIterator]()) {
      let n = li(await this.readRule(this.ctx, t), t);
      n !== null && (yield n);
    }
  }
};
function di(e, t, n, o) {
  for (let r of Object.keys(n))
    if (e.normalizeId(r, t))
      return r;
  if ((o.defaultPolicy ?? "allow") === "deny") {
    for (let r of Object.keys(e._internals.tableMap))
      if (e.normalizeId(r, t))
        return r;
  }
  return null;
}
s(di, "resolveRulesTableName");
var tg = class extends vi {
  static {
    s(this, "RulesDatabaseReader");
  }
  constructor(e, t, n, o) {
    let { db: r, tableMap: i } = e._internals;
    super(r, i), this.inner = e, this.ctx = t, this.rules = n, this.rulesConfig = o, this.system = e.system;
  }
  async get(e, t) {
    let n = await this.inner.get(e, t);
    if (n === null) return null;
    let o = t !== void 0 ? e : di(this.inner, e, this.rules, this.rulesConfig);
    return o ? this.applyReadRule(o, n) : n;
  }
  query(e) {
    let t = this.rules[e];
    if (!t?.read && (this.rulesConfig.defaultPolicy ?? "allow") === "allow")
      return this.inner.query(e);
    let n = this.inner.query(e), o = t?.read ?? (async () => null), r = w.any();
    return new Sb(n, r, o, this.rulesConfig, this.ctx);
  }
  async applyReadRule(e, t) {
    let n = this.rules[e];
    if (!n?.read)
      return (this.rulesConfig.defaultPolicy ?? "allow") === "deny" ? null : t;
    let o = await n.read(this.ctx, t);
    return li(o, t);
  }
}, jb = class extends Ed {
  static {
    s(this, "RulesDatabaseWriter");
  }
  constructor(e, t, n, o) {
    let { db: r, tableMap: i, reader: a } = e._internals;
    super(r, i), this.inner = e, this.ctx = t, this.rules = n, this.rulesConfig = o, this.rulesReader = new tg(a, t, n, o), this.system = e.system;
  }
  rulesReader;
  normalizeId(e, t) {
    return this.rulesReader.normalizeId(e, t);
  }
  async get(e, t) {
    return this.rulesReader.get(e, t);
  }
  query(e) {
    return this.rulesReader.query(e);
  }
  async insert(e, t) {
    let n = e, o = this.rules[n];
    if (o?.insert) {
      let r = await o.insert(this.ctx, t);
      return this.inner.insert(
        e,
        r
      );
    }
    if ((this.rulesConfig.defaultPolicy ?? "allow") === "deny")
      throw new Error(`insert not allowed on ${n}`);
    return this.inner.insert(e, t);
  }
  async patch(e, t, n) {
    let o, r;
    n !== void 0 ? (o = t, r = n) : (o = e, r = t);
    let i = await this.rulesReader.get(o);
    if (i === null)
      throw new Error("no read access or doc does not exist");
    let a = di(this.inner, o, this.rules, this.rulesConfig), c = a ? this.rules[a] : void 0;
    if (c?.patch) {
      let u = await c.patch(this.ctx, i, r);
      return this.inner.patch(
        o,
        u
      );
    }
    if ((this.rulesConfig.defaultPolicy ?? "allow") === "deny")
      throw new Error(`patch not allowed on ${a}`);
    return this.inner.patch(o, r);
  }
  async replace(e, t, n) {
    let o, r;
    n !== void 0 ? (o = t, r = n) : (o = e, r = t);
    let i = await this.rulesReader.get(o);
    if (i === null)
      throw new Error("no read access or doc does not exist");
    let a = di(this.inner, o, this.rules, this.rulesConfig), c = a ? this.rules[a] : void 0;
    if (c?.replace) {
      let u = await c.replace(this.ctx, i, r);
      return this.inner.replace(o, u);
    }
    if ((this.rulesConfig.defaultPolicy ?? "allow") === "deny")
      throw new Error(`replace not allowed on ${a}`);
    return this.inner.replace(o, r);
  }
  async delete(e, t) {
    let n;
    t !== void 0 ? n = t : n = e;
    let o = await this.rulesReader.get(n);
    if (o === null)
      throw new Error("no read access or doc does not exist");
    let r = di(this.inner, n, this.rules, this.rulesConfig), i = r ? this.rules[r] : void 0;
    if (i?.delete)
      return await i.delete(this.ctx, o), this.inner.delete(n);
    if ((this.rulesConfig.defaultPolicy ?? "allow") === "deny")
      throw new Error(`delete not allowed on ${r}`);
    return this.inner.delete(n);
  }
}, Ob = class rg extends Td {
  static {
    s(this, "_AuditQueryChain");
  }
  afterRead;
  tableName;
  constructor(t, n, o, r) {
    super(t, n), this.afterRead = o, this.tableName = r;
  }
  createChain(t) {
    return new rg(t, this.schema, this.afterRead, this.tableName);
  }
  async first() {
    let t = await super.first();
    return t !== null && await this.afterRead(this.tableName, t), t;
  }
  async unique() {
    let t = await super.unique();
    return t !== null && await this.afterRead(this.tableName, t), t;
  }
  async collect() {
    let t = await super.collect();
    for (let n of t)
      await this.afterRead(this.tableName, n);
    return t;
  }
  async take(t) {
    let n = await super.take(t);
    for (let o of n)
      await this.afterRead(this.tableName, o);
    return n;
  }
  async paginate(t) {
    let n = await super.paginate(t);
    for (let o of n.page)
      await this.afterRead(this.tableName, o);
    return n;
  }
  async *[Symbol.asyncIterator]() {
    for await (let t of super[Symbol.asyncIterator]())
      await this.afterRead(this.tableName, t), yield t;
  }
}, ng = class extends vi {
  static {
    s(this, "AuditDatabaseReader");
  }
  inner;
  afterRead;
  constructor(e, t) {
    let { db: n, tableMap: o } = e._internals;
    super(n, o), this.inner = e, this.afterRead = t.afterRead ?? (() => {
    }), this.system = e.system;
  }
  async get(e, t) {
    let n = await this.inner.get(e, t);
    if (n !== null) {
      let o = this.resolveTableFromId(
        t !== void 0 ? t : e,
        t !== void 0 ? e : void 0
      );
      o && await this.afterRead(o, n);
    }
    return n;
  }
  query(e) {
    let t = this.inner.query(e), n = w.any();
    return new Ob(t, n, this.afterRead, e);
  }
  resolveTableFromId(e, t) {
    if (t) return t;
    for (let n of Object.keys(this.tableMap))
      if (this.inner.normalizeId(n, e))
        return n;
    return null;
  }
}, Pb = class extends Ed {
  static {
    s(this, "AuditDatabaseWriter");
  }
  inner;
  auditReader;
  afterWrite;
  constructor(e, t) {
    let { db: n, tableMap: o, reader: r } = e._internals;
    super(n, o), this.inner = e, this.afterWrite = t.afterWrite, this.auditReader = t.afterRead ? new ng(r, { afterRead: t.afterRead }) : r, this.system = e.system;
  }
  normalizeId(e, t) {
    return this.auditReader.normalizeId(e, t);
  }
  async get(e, t) {
    return this.auditReader.get(e, t);
  }
  query(e) {
    return this.auditReader.query(e);
  }
  async insert(e, t) {
    let n = await this.inner.insert(e, t);
    return this.afterWrite && await this.afterWrite(e, { type: "insert", id: n, value: t }), n;
  }
  async patch(e, t, n) {
    let o, r;
    n !== void 0 ? (o = t, r = n) : (o = e, r = t);
    let i = await this.inner.get(o);
    if (n !== void 0 ? await this.inner.patch(e, t, n) : await this.inner.patch(o, r), this.afterWrite) {
      let a = this.resolveTableFromId(o);
      a && await this.afterWrite(a, { type: "patch", id: o, doc: i, value: r });
    }
  }
  async replace(e, t, n) {
    let o, r;
    n !== void 0 ? (o = t, r = n) : (o = e, r = t);
    let i = await this.inner.get(o);
    if (n !== void 0 ? await this.inner.replace(e, t, n) : await this.inner.replace(o, r), this.afterWrite) {
      let a = this.resolveTableFromId(o);
      a && await this.afterWrite(a, { type: "replace", id: o, doc: i, value: r });
    }
  }
  async delete(e, t) {
    let n;
    t !== void 0 ? n = t : n = e;
    let o = await this.inner.get(n);
    if (t !== void 0 ? await this.inner.delete(e, t) : await this.inner.delete(n), this.afterWrite) {
      let r = this.resolveTableFromId(n);
      r && await this.afterWrite(r, { type: "delete", id: n, doc: o });
    }
  }
  resolveTableFromId(e) {
    for (let t of Object.keys(this.inner._internals.tableMap))
      if (this.inner.normalizeId(t, e))
        return t;
    return null;
  }
};
function Tb(e, t) {
  let n = t?.underlyingDb?.query, o = t?.underlyingDb?.mutation;
  return {
    query: {
      args: {},
      input: /* @__PURE__ */ s(async (r, i, a) => ({
        ctx: {
          db: new vi(n ? n(r) : r.db, e)
        },
        args: {}
      }), "input")
    },
    mutation: {
      args: {},
      input: /* @__PURE__ */ s(async (r, i, a) => ({
        ctx: {
          db: new Ed(o ? o(r) : r.db, e)
        },
        args: {}
      }), "input")
    }
  };
}
s(Tb, "createZodvexCustomization");
function og(e, t) {
  let n = {};
  for (let o of t)
    o in e && (n[o] = e[o]);
  return n;
}
s(og, "pick");
var ig = "__zodvexMeta";
function Eb(e, t) {
  Object.defineProperty(e, ig, {
    value: t,
    enumerable: !1,
    writable: !1,
    configurable: !1
  });
}
s(Eb, "attachMeta");
function ag(e) {
  if (!(e == null || typeof e != "object" && typeof e != "function"))
    return e[ig];
}
s(ag, "readMeta");
var Ub = "__zodvexCodecBrand";
function Db(e, t) {
  Object.defineProperty(e, Ub, {
    value: t,
    enumerable: !1,
    writable: !1,
    configurable: !1
  });
}
s(Db, "attachCodecBrand");
function Nb(e, t) {
  return {
    error: "ZodValidationError",
    context: t,
    issues: e.issues.map((n) => ({
      path: Array.isArray(n.path) ? n.path.join(".") : String(n.path ?? ""),
      code: n.code,
      message: n.message
    })),
    // Keep a flattened snapshot for easier debugging without cyclic refs
    flatten: JSON.parse(JSON.stringify(e.flatten?.() ?? {}))
  };
}
s(Nb, "formatZodIssues");
function jd(e, t) {
  throw e instanceof ve ? new vt(Nb(e, t)) : e;
}
s(jd, "handleZodValidationError");
function Zb(e, t) {
  try {
    return ye(e, t);
  } catch (n) {
    if (n?.message?.includes("unidirectional transform"))
      try {
        return Re(e, t);
      } catch (o) {
        jd(o, "returns");
      }
    jd(n, "returns");
  }
  throw new Error("Unreachable");
}
s(Zb, "validateReturns");
function sg(e) {
  if (e)
    return e instanceof k ? e : w.object(e);
}
s(sg, "normalizeFunctionSchema");
function Ab(e) {
  if (e) {
    if (e instanceof q)
      return e;
    if (!(e instanceof k))
      return w.object(e);
  }
}
s(Ab, "normalizeFunctionMetaArgs");
function Nm(e, t, n) {
  Eb(e, {
    type: "function",
    zodArgs: Ab(t),
    zodReturns: sg(n)
  });
}
s(Nm, "attachFunctionMeta");
var Zm = /* @__PURE__ */ new WeakMap();
function Yr(e, t = 50, n = 0) {
  let o = Zm.get(e);
  if (o !== void 0)
    return o;
  if (n > t)
    return !1;
  let r = !1;
  return e instanceof Pr ? r = !0 : e instanceof te ? r = e._zod.def.options.some((i) => Yr(i, t, n + 1)) : (e instanceof M || e instanceof be || e instanceof ue) && (r = Yr(e._zod.def.innerType, t, n + 1)), Zm.set(e, r), r;
}
s(Yr, "containsCustom");
function Cb(e) {
  if (e instanceof k) {
    if (e instanceof q)
      return {
        argsSchema: e,
        argsValidator: e._zod.def.shape
      };
    throw new Error(
      "Unsupported non-object Zod schema for args; please provide an args schema using z.object({...}), e.g. z.object({ foo: z.string() })"
    );
  }
  return {
    argsValidator: e,
    argsSchema: w.object(e)
  };
}
s(Cb, "normalizeCustomArgsValidator");
function Rb(e, t) {
  if (!(!e || t?.skipConvexValidation) && !(t?.skipCustomSchemas && Yr(e)))
    return Xm(e);
}
s(Rb, "createConvexReturnsValidator");
function cg(e, t) {
  let n = rt(e, t);
  return n.success || jd(n.error, "args"), n.data;
}
s(cg, "parseObjectArgsOrThrow");
async function Am(e, t, n, o, r, i) {
  let a = og(n, Object.keys(o)), c = i ? cg(i, a) : a;
  return await e(t, c, r);
}
s(Am, "runCustomizationInput");
function Cm(e, t, n) {
  let o = { ...e, ...n?.ctx ?? {} }, r = n?.args ?? {};
  return {
    finalCtx: o,
    finalArgs: { ...t, ...r }
  };
}
s(Cm, "applyCustomizationResult");
async function Rm(e, t) {
  if (t?.added?.onSuccess && await t.added.onSuccess({
    ctx: t.ctx,
    args: t.args,
    result: e
  }), t?.returns) {
    let n = Zb(t.returns, e);
    return Ke(n);
  }
  return Ke(e);
}
s(Rm, "finalizeFunctionReturn");
function Ud(e, t) {
  let n = t.input ?? ui.input, o = t.args ?? ui.args, r = Object.entries(o), i = r.length > 0 && r.every(([, u]) => u instanceof k), a = i ? mi(o) : o, c = i ? w.object(o) : void 0;
  return /* @__PURE__ */ s(function(l) {
    let { args: d, handler: p = l, returns: h, ...v } = l, O = l.skipConvexValidation ?? !1, I = sg(h), W = Rb(I, { skipConvexValidation: O }), Ge = W ? { returns: W } : void 0;
    if (I && Tm(I, "returns"), d) {
      let { argsValidator: K, argsSchema: A } = Cb(d), X = O ? a : { ...mi(K), ...a };
      Tm(A, "args");
      let z = e({
        args: X,
        ...Ge,
        handler: /* @__PURE__ */ s(async (J, gt) => {
          let en = await Am(
            n,
            J,
            gt,
            a,
            v,
            c
          ), vg = Object.keys(K), yg = og(gt, vg), Ad = cg(A, yg), { finalCtx: bg, finalArgs: xg } = Cm(J, Ad, en), $g = await p(bg, xg);
          return Rm($g, { ctx: J, args: Ad, added: en, returns: I });
        }, "handler")
      }), P = c ? w.object({
        ...A._zod.def.shape,
        ...c._zod.def.shape
      }) : A;
      return Nm(z, P, I), z;
    }
    let _e = e({
      args: a,
      ...Ge,
      handler: /* @__PURE__ */ s(async (K, A) => {
        let X = A, z = await Am(
          n,
          K,
          A,
          a,
          v,
          c
        ), { finalCtx: P, finalArgs: J } = Cm(K, X, z), gt = await p(P, J);
        return Rm(gt, { ctx: K, args: X, added: z, returns: I });
      }, "handler")
    });
    return Nm(_e, c ?? void 0, I), _e;
  }, "customBuilder");
}
s(Ud, "customFnBuilder");
function Fm(e, t) {
  return Ud(e, t);
}
s(Fm, "zCustomQuery");
function Lm(e, t) {
  return Ud(
    e,
    t
  );
}
s(Lm, "zCustomMutation");
function Mm(e, t) {
  return Ud(
    e,
    t
  );
}
s(Mm, "zCustomAction");
function ug(e, t, n) {
  let o = n?.wrapDb !== !1;
  if (!o && n?.underlyingDb)
    throw new Error(
      "[zodvex] initZodvex: `underlyingDb` requires the codec db wrapper \u2014 remove `wrapDb: false` or drop `underlyingDb`."
    );
  let r = Tb(e.__zodTableMap, {
    underlyingDb: n?.underlyingDb
  }), i = Fb(), a = n?.registry, c = Lb(a, i), u = {
    query: o ? r.query : i,
    mutation: Mb(o ? r.mutation : i, a),
    action: c
  };
  return {
    zq: ar(t.query, u.query, Fm),
    zm: ar(t.mutation, u.mutation, Lm),
    za: ar(t.action, u.action, Mm),
    ziq: ar(t.internalQuery, u.query, Fm),
    zim: ar(t.internalMutation, u.mutation, Lm),
    zia: ar(t.internalAction, u.action, Mm)
  };
}
s(ug, "initZodvex");
function Fb() {
  return { args: {}, input: ui.input };
}
s(Fb, "createNoOpCustomization");
function Lb(e, t) {
  return e ? {
    args: {},
    input: /* @__PURE__ */ s(async (n) => ({
      // Auto-encode codec args at outbound call sites: runQuery/runMutation
      // (encode args, decode result) and scheduler.runAfter/runAt (encode args).
      ctx: Gm(e(), n),
      args: {}
    }), "input")
  } : t;
}
s(Lb, "createActionCustomization");
function Mb(e, t) {
  return t ? {
    args: {},
    input: /* @__PURE__ */ s(async (n, o, r) => {
      let i = await e.input(n, {}, r), a = Gm(t(), n);
      return {
        ctx: { ...i.ctx, ...a },
        args: {}
      };
    }, "input")
  } : e;
}
s(Mb, "createMutationCustomization");
function Bb(e, t) {
  return {
    args: t.args ?? {},
    input: /* @__PURE__ */ s(async (n, o, r) => {
      let i = await e.input(n, {}, r), a = { ...n, ...i.ctx };
      if (!t.input)
        return { ctx: i.ctx, args: {} };
      let c = await t.input(a, o, r);
      return {
        ctx: { ...i.ctx, ...c.ctx ?? {} },
        args: c.args ?? {},
        ...c.onSuccess && { onSuccess: c.onSuccess }
      };
    }, "input")
  };
}
s(Bb, "composeCustomizations");
function ar(e, t, n) {
  let o = n(e, t);
  return o.withContext = (r) => {
    let i = Bb(t, r);
    return n(e, i);
  }, o;
}
s(ar, "createZodvexBuilder");
function hi(e) {
  let t = w.string().check(
    w.refine((o) => typeof o == "string" && o.length > 0, {
      message: `Invalid ID for table "${e}"`
    }),
    w.describe(`convexId:${e}`)
  );
  pi.setMetadata(t, {
    isConvexId: !0,
    tableName: e
  });
  let n = t;
  return n._tableName = e, n;
}
s(hi, "id");
function lg(e) {
  return e instanceof te || e instanceof Le;
}
s(lg, "isZodUnion");
function dg(e) {
  return e instanceof te, e._zod.def.options;
}
s(dg, "getUnionOptions");
function Jb(e) {
  if (e.length < 2)
    throw new Error(
      `z.union() requires at least 2 options, but received ${e.length}. This indicates an invalid union schema was passed to zodTable().`
    );
}
s(Jb, "assertUnionOptions");
function fg(e) {
  return Jb(e), w.union(e);
}
s(fg, "createUnionFromOptions");
function Vb(e, t) {
  if (lg(t)) {
    let o = dg(t).map((r) => {
      if (r instanceof q) {
        let i = {
          ...r._zod.def.shape,
          _id: hi(e),
          _creationTime: w.number()
        };
        return V(r, { ...r._zod.def, shape: i });
      }
      return r;
    });
    return fg(o);
  }
  if (t instanceof q) {
    let n = { ...t._zod.def.shape, _id: hi(e), _creationTime: w.number() };
    return V(t, { ...t._zod.def, shape: n });
  }
  return t;
}
s(Vb, "addSystemFields");
function qb(e) {
  return e instanceof M ? e : new M({ type: "optional", innerType: e });
}
s(qb, "ensureOptional");
function Wb(e) {
  let t = {};
  for (let [n, o] of Object.entries(e))
    t[n] = qb(o);
  return t;
}
s(Wb, "createPartialShape");
function Bm(e, t) {
  return w.object({
    _id: hi(e),
    _creationTime: w.optional(w.number()),
    ...Wb(t)
  });
}
s(Bm, "createUpdateObjectSchema");
function Kb(e, t) {
  if (lg(t)) {
    let n = dg(t).map((o) => o instanceof q ? Bm(e, o._zod.def.shape) : o);
    return fg(n);
  }
  return t instanceof q ? Bm(e, t._zod.def.shape) : t;
}
s(Kb, "createSchemaUpdateSchema");
var Jm = /* @__PURE__ */ Symbol.for("zodvex.zxDate");
function Gb(e) {
  e[Jm] = !0;
  let t = e._zod?.def;
  return t && (t[Jm] = !0), e;
}
s(Gb, "brandZxDate");
function Xb() {
  return Gb(
    Hm(
      w.number(),
      // Wire: timestamp
      w.custom((e) => e instanceof Date, {
        message: "Expected Date instance"
      }),
      {
        decode: /* @__PURE__ */ s((e) => new Date(e), "decode"),
        encode: /* @__PURE__ */ s((e) => e.getTime(), "encode")
      }
    )
  );
}
s(Xb, "date");
function Qb(e, t, n, o) {
  let r = Hm(e, t, n);
  return o?.brand && Db(r, o.brand), r;
}
s(Qb, "codec");
function yi(e) {
  let t = /* @__PURE__ */ Symbol.for(`zodvex.zx.cache.${e}`), n = globalThis, o = n[t];
  if (o) return o;
  let r = /* @__PURE__ */ new WeakMap();
  return n[t] = r, r;
}
s(yi, "sharedWeakMap");
var Vm = yi("base"), qm = yi("doc"), Wm = yi("update"), Km = yi("docArray");
function Dd(e) {
  let t = e.schema;
  return t instanceof k ? t : e.fields;
}
s(Dd, "slimCacheKey");
function Nd(e) {
  let t = e.schema;
  if (t?.base instanceof k) return t.base;
  if (t instanceof k) return t;
  let n = Vm.get(e.fields);
  if (n) return n;
  if (Object.keys(e.fields).length === 0)
    throw new Error(`[zodvex] Cannot derive base schema for model '${e.name}'`);
  let o = w.object(e.fields);
  return Vm.set(e.fields, o), o;
}
s(Nd, "base");
function pg(e) {
  let t = e.schema;
  if (t?.doc instanceof k) return t.doc;
  let n = Dd(e), o = qm.get(n);
  if (o) return o;
  let r = Vb(e.name, Nd(e));
  return qm.set(n, r), r;
}
s(pg, "doc");
function Hb(e) {
  let t = e.schema;
  if (t?.update instanceof k) return t.update;
  let n = Dd(e), o = Wm.get(n);
  if (o) return o;
  let r = Kb(e.name, Nd(e));
  return Wm.set(n, r), r;
}
s(Hb, "update");
function Yb(e) {
  let t = e.schema;
  if (t?.docArray instanceof k) return t.docArray;
  let n = Dd(e), o = Km.get(n);
  if (o) return o;
  let r = w.array(pg(e));
  return Km.set(n, r), r;
}
s(Yb, "docArray");
function mg(e) {
  return new be({ type: "nullable", innerType: e });
}
s(mg, "nullable");
function fi(e) {
  return new M({ type: "optional", innerType: e });
}
s(fi, "optional");
function Od(e) {
  return fi(mg(e));
}
s(Od, "nullableOptional2");
function ex() {
  return w.object({
    numItems: w.number(),
    cursor: mg(w.string()),
    endCursor: Od(w.string()),
    id: fi(w.number()),
    maximumRowsRead: fi(w.number()),
    maximumBytesRead: fi(w.number())
  });
}
s(ex, "paginationOpts");
function tx(e) {
  return w.object({
    page: w.array(e),
    isDone: w.boolean(),
    continueCursor: w.string(),
    splitCursor: Od(w.string()),
    pageStatus: Od(w.enum(["SplitRecommended", "SplitRequired"]))
  });
}
s(tx, "paginationResult");
var Pd = {
  /**
   * Date ↔ timestamp codec
   * @see {@link date}
   */
  date: Xb,
  /**
   * Convex ID validator
   * @see {@link id}
   */
  id: hi,
  /**
   * Custom codec builder
   * @see {@link codec}
   */
  codec: Qb,
  /**
   * Pagination options schema matching Convex's PaginationOptions type
   * @see {@link paginationOpts}
   */
  paginationOpts: ex,
  /**
   * Paginated result schema wrapping any item schema in Convex's PaginationResult shape
   * @see {@link paginationResult}
   */
  paginationResult: tx,
  /**
   * Base schema for a model (user fields only; no system fields).
   * For object models reconstructs from fields; for union models returns the
   * user-supplied union. Cached per-model.
   * @see {@link base}
   */
  base: Nd,
  /**
   * Doc schema: model fields + _id + _creationTime
   * @see {@link doc}
   */
  doc: pg,
  /**
   * Update schema: _id required, all other fields optional
   * @see {@link update}
   */
  update: Hb,
  /**
   * Doc array schema: z.array(doc(model))
   * @see {@link docArray}
   */
  docArray: Yb
};
function rx(e) {
  return ag(e)?.type === "model";
}
s(rx, "isZodModelEntry");
function gg(e) {
  let t = ag(e);
  if (!t || t.type !== "model")
    throw new Error(`Model '${e.name}' is missing zodvex model metadata.`);
  return t;
}
s(gg, "getZodModelMeta");
function nx(e) {
  let t = gg(e), o = t.definitionSource === "schema" || t.definitionSource == null && Object.keys(e.fields).length === 0 ? Ye(Xm(Pd.base(e))) : Ye(mi(e.fields));
  for (let [r, i] of Object.entries(e.indexes)) {
    let a = i.filter((c) => c !== "_creationTime");
    o = o.index(r, a);
  }
  for (let [r, i] of Object.entries(e.searchIndexes))
    o = o.searchIndex(r, i);
  for (let [r, i] of Object.entries(e.vectorIndexes))
    o = o.vectorIndex(r, i);
  return o;
}
s(nx, "tableFromModel");
function hg(e) {
  let t = {}, n = {};
  for (let [i, a] of Object.entries(e))
    if (rx(a)) {
      if (a.name !== i)
        throw new Error(
          `Model name '${a.name}' does not match key '${i}'. The model name must match the key in the schema definition.`
        );
      t[i] = nx(a);
      let c = gg(a);
      c.schemas ? n[i] = {
        doc: c.schemas.doc,
        insert: c.schemas.insert
      } : n[i] = {
        doc: Pd.doc(a),
        insert: Pd.base(a)
      };
    } else
      t[i] = a.table, n[i] = {
        doc: a.schema.doc,
        insert: a.schema.insert
      };
  let o = kn(t);
  return Object.assign(o, { __zodTableMap: n });
}
s(hg, "defineZodSchema");

// graphProbe.ts
var ix = { query: Mi, mutation: Fi, action: Ji, internalQuery: Bi, internalMutation: Li, internalAction: Vi }, ax = { kind: "full", schemaHelpers: !0, server: ix, s: { number: Jr, string: Ht, boolean: Vr, optional: lt, nullable: dt, object: Yo, array: pt, union: ir, date: Ho, codec: ai, instanceof: si, parse: Rr, encode: Fr }, defineZodModel: km, defineZodSchema: hg, initZodvex: ug }, sx = $f(ax), cx = { count: 0, width: 32, profile: "codec-rich", entries: 0 }, Zd = sx(cx), oO = ox({ args: {}, returns: g.object({ checksum: g.number(), output: g.object({ seq: g.number(), at: g.number(), secret: g.string(), payload: g.string() }), manifest: g.any(), nonce: g.string() }), handler: /* @__PURE__ */ s(() => {
  let e = Zd.operation();
  return globalThis.gc(), globalThis.gc(), { checksum: Zd.checksum(), output: e, manifest: Zd.manifest, nonce: "fd24ede5-99de-4a1d-a08c-54dc045da7a3" };
}, "handler") });
export {
  oO as default
};
