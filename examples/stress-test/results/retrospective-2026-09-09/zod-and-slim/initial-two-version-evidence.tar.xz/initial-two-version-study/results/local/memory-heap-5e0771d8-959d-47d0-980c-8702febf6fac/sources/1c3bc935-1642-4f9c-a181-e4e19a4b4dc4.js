var Wt = Object.defineProperty;
var n = (e, t) => Wt(e, "name", { value: t, configurable: !0 });

// graphProbe.ts
import { query as Dr } from "convex:/_system/repl/wrappers.js";

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/base64.js
var C = [], I = [], Yt = Uint8Array, Ce = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
for (F = 0, ut = Ce.length; F < ut; ++F)
  C[F] = Ce[F], I[Ce.charCodeAt(F)] = F;
var F, ut;
I[45] = 62;
I[95] = 63;
function Xt(e) {
  var t = e.length;
  if (t % 4 > 0)
    throw new Error("Invalid string. Length must be a multiple of 4");
  var r = e.indexOf("=");
  r === -1 && (r = t);
  var o = r === t ? 0 : 4 - r % 4;
  return [r, o];
}
n(Xt, "getLens");
function Zt(e, t, r) {
  return (t + r) * 3 / 4 - r;
}
n(Zt, "_byteLength");
function Q(e) {
  var t, r = Xt(e), o = r[0], s = r[1], i = new Yt(Zt(e, o, s)), a = 0, p = s > 0 ? o - 4 : o, m;
  for (m = 0; m < p; m += 4)
    t = I[e.charCodeAt(m)] << 18 | I[e.charCodeAt(m + 1)] << 12 | I[e.charCodeAt(m + 2)] << 6 | I[e.charCodeAt(m + 3)], i[a++] = t >> 16 & 255, i[a++] = t >> 8 & 255, i[a++] = t & 255;
  return s === 2 && (t = I[e.charCodeAt(m)] << 2 | I[e.charCodeAt(m + 1)] >> 4, i[a++] = t & 255), s === 1 && (t = I[e.charCodeAt(m)] << 10 | I[e.charCodeAt(m + 1)] << 4 | I[e.charCodeAt(m + 2)] >> 2, i[a++] = t >> 8 & 255, i[a++] = t & 255), i;
}
n(Q, "toByteArray");
function Kt(e) {
  return C[e >> 18 & 63] + C[e >> 12 & 63] + C[e >> 6 & 63] + C[e & 63];
}
n(Kt, "tripletToBase64");
function er(e, t, r) {
  for (var o, s = [], i = t; i < r; i += 3)
    o = (e[i] << 16 & 16711680) + (e[i + 1] << 8 & 65280) + (e[i + 2] & 255), s.push(Kt(o));
  return s.join("");
}
n(er, "encodeChunk");
function z(e) {
  for (var t, r = e.length, o = r % 3, s = [], i = 16383, a = 0, p = r - o; a < p; a += i)
    s.push(
      er(
        e,
        a,
        a + i > p ? p : a + i
      )
    );
  return o === 1 ? (t = e[r - 1], s.push(C[t >> 2] + C[t << 4 & 63] + "==")) : o === 2 && (t = (e[r - 2] << 8) + e[r - 1], s.push(
    C[t >> 10] + C[t >> 4 & 63] + C[t << 2 & 63] + "="
  )), s.join("");
}
n(z, "fromByteArray");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/common/index.js
function P(e) {
  if (e === void 0)
    return {};
  if (!oe(e))
    throw new Error(
      `The arguments to a Convex function must be an object. Received: ${e}`
    );
  return e;
}
n(P, "parseArgs");
function oe(e) {
  let t = typeof e == "object", r = Object.getPrototypeOf(e), o = r === null || r === Object.prototype || // Objects generated from other contexts (e.g. across Node.js `vm` modules) will not satisfy the previous
  // conditions but are still simple objects.
  r?.constructor?.name === "Object";
  return t && o;
}
n(oe, "isSimpleObject");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/value.js
var pt = !0, B = BigInt("-9223372036854775808"), Fe = BigInt("9223372036854775807"), Ne = BigInt("0"), tr = BigInt("8"), rr = BigInt("256");
function ht(e) {
  return Number.isNaN(e) || !Number.isFinite(e) || Object.is(e, -0);
}
n(ht, "isSpecial");
function nr(e) {
  e < Ne && (e -= B + B);
  let t = e.toString(16);
  t.length % 2 === 1 && (t = "0" + t);
  let r = new Uint8Array(new ArrayBuffer(8)), o = 0;
  for (let s of t.match(/.{2}/g).reverse())
    r.set([parseInt(s, 16)], o++), e >>= tr;
  return z(r);
}
n(nr, "slowBigIntToBase64");
function or(e) {
  let t = Q(e);
  if (t.byteLength !== 8)
    throw new Error(
      `Received ${t.byteLength} bytes, expected 8 for $integer`
    );
  let r = Ne, o = Ne;
  for (let s of t)
    r += BigInt(s) * rr ** o, o++;
  return r > Fe && (r += B + B), r;
}
n(or, "slowBase64ToBigInt");
function sr(e) {
  if (e < B || Fe < e)
    throw new Error(
      `BigInt ${e} does not fit into a 64-bit signed integer.`
    );
  let t = new ArrayBuffer(8);
  return new DataView(t).setBigInt64(0, e, !0), z(new Uint8Array(t));
}
n(sr, "modernBigIntToBase64");
function ir(e) {
  let t = Q(e);
  if (t.byteLength !== 8)
    throw new Error(
      `Received ${t.byteLength} bytes, expected 8 for $integer`
    );
  return new DataView(t.buffer).getBigInt64(0, !0);
}
n(ir, "modernBase64ToBigInt");
var ar = DataView.prototype.setBigInt64 ? sr : nr, cr = DataView.prototype.getBigInt64 ? ir : or, ft = 1024;
function Pe(e) {
  if (e.length > ft)
    throw new Error(
      `Field name ${e} exceeds maximum field name length ${ft}.`
    );
  if (e.startsWith("$"))
    throw new Error(`Field name ${e} starts with a '$', which is reserved.`);
  for (let t = 0; t < e.length; t += 1) {
    let r = e.charCodeAt(t);
    if (r < 32 || r >= 127)
      throw new Error(
        `Field name ${e} has invalid character '${e[t]}': Field names can only contain non-control ASCII characters`
      );
  }
}
n(Pe, "validateObjectField");
function x(e) {
  if (e === null || typeof e == "boolean" || typeof e == "number" || typeof e == "string")
    return e;
  if (Array.isArray(e))
    return e.map((o) => x(o));
  if (typeof e != "object")
    throw new Error(`Unexpected type of ${e}`);
  let t = Object.entries(e);
  if (t.length === 1) {
    let o = t[0][0];
    if (o === "$bytes") {
      if (typeof e.$bytes != "string")
        throw new Error(`Malformed $bytes field on ${e}`);
      return Q(e.$bytes).buffer;
    }
    if (o === "$integer") {
      if (typeof e.$integer != "string")
        throw new Error(`Malformed $integer field on ${e}`);
      return cr(e.$integer);
    }
    if (o === "$float") {
      if (typeof e.$float != "string")
        throw new Error(`Malformed $float field on ${e}`);
      let s = Q(e.$float);
      if (s.byteLength !== 8)
        throw new Error(
          `Received ${s.byteLength} bytes, expected 8 for $float`
        );
      let a = new DataView(s.buffer).getFloat64(0, pt);
      if (!ht(a))
        throw new Error(`Float ${a} should be encoded as a number`);
      return a;
    }
    if (o === "$set")
      throw new Error(
        "Received a Set which is no longer supported as a Convex type."
      );
    if (o === "$map")
      throw new Error(
        "Received a Map which is no longer supported as a Convex type."
      );
  }
  let r = {};
  for (let [o, s] of Object.entries(e))
    Pe(o), r[o] = x(s);
  return r;
}
n(x, "jsonToConvex");
var dt = 16384;
function j(e) {
  let t = JSON.stringify(e, (r, o) => o === void 0 ? "undefined" : typeof o == "bigint" ? `${o.toString()}n` : o);
  if (t.length > dt) {
    let r = "[...truncated]", o = dt - r.length, s = t.codePointAt(o - 1);
    return s !== void 0 && s > 65535 && (o -= 1), t.substring(0, o) + r;
  }
  return t;
}
n(j, "stringifyValueForError");
function W(e, t, r, o) {
  if (e === void 0) {
    let a = r && ` (present at path ${r} in original object ${j(
      t
    )})`;
    throw new Error(
      `undefined is not a valid Convex value${a}. To learn about Convex's supported types, see https://docs.convex.dev/using/types.`
    );
  }
  if (e === null)
    return e;
  if (typeof e == "bigint") {
    if (e < B || Fe < e)
      throw new Error(
        `BigInt ${e} does not fit into a 64-bit signed integer.`
      );
    return { $integer: ar(e) };
  }
  if (typeof e == "number")
    if (ht(e)) {
      let a = new ArrayBuffer(8);
      return new DataView(a).setFloat64(0, e, pt), { $float: z(new Uint8Array(a)) };
    } else
      return e;
  if (typeof e == "boolean" || typeof e == "string")
    return e;
  if (e instanceof ArrayBuffer)
    return { $bytes: z(new Uint8Array(e)) };
  if (Array.isArray(e))
    return e.map(
      (a, p) => W(a, t, r + `[${p}]`, !1)
    );
  if (e instanceof Set)
    throw new Error(
      $e(r, "Set", [...e], t)
    );
  if (e instanceof Map)
    throw new Error(
      $e(r, "Map", [...e], t)
    );
  if (!oe(e)) {
    let a = e?.constructor?.name, p = a ? `${a} ` : "";
    throw new Error(
      $e(r, p, e, t)
    );
  }
  let s = {}, i = Object.entries(e);
  i.sort(([a, p], [m, S]) => a === m ? 0 : a < m ? -1 : 1);
  for (let [a, p] of i)
    p !== void 0 ? (Pe(a), s[a] = W(p, t, r + `.${a}`, !1)) : o && (Pe(a), s[a] = mt(
      p,
      t,
      r + `.${a}`
    ));
  return s;
}
n(W, "convexToJsonInternal");
function $e(e, t, r, o) {
  return e ? `${t}${j(
    r
  )} is not a supported Convex type (present at path ${e} in original object ${j(
    o
  )}). To learn about Convex's supported types, see https://docs.convex.dev/using/types.` : `${t}${j(
    r
  )} is not a supported Convex type.`;
}
n($e, "errorMessageForUnsupportedType");
function mt(e, t, r) {
  if (e === void 0)
    return { $undefined: null };
  if (t === void 0)
    throw new Error(
      `Programming error. Current value is ${j(
        e
      )} but original value is undefined`
    );
  return W(e, t, r, !1);
}
n(mt, "convexOrUndefinedToJsonInternal");
function w(e) {
  return W(e, e, "", !1);
}
n(w, "convexToJson");
function T(e) {
  return mt(e, e, "");
}
n(T, "convexOrUndefinedToJson");
function yt(e) {
  return W(e, e, "", !0);
}
n(yt, "patchValueToJson");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/validators.js
var ur = Object.defineProperty, lr = /* @__PURE__ */ n((e, t, r) => t in e ? ur(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), g = /* @__PURE__ */ n((e, t, r) => lr(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), fr = "https://docs.convex.dev/error#undefined-validator";
function Y(e, t) {
  let r = t !== void 0 ? ` for field "${t}"` : "";
  throw new Error(
    `A validator is undefined${r} in ${e}. This is often caused by circular imports. See ${fr} for details.`
  );
}
n(Y, "throwUndefinedValidatorError");
var E = class {
  static {
    n(this, "BaseValidator");
  }
  constructor({ isOptional: t }) {
    g(this, "type"), g(this, "fieldPaths"), g(this, "isOptional"), g(this, "isConvexValidator"), this.isOptional = t, this.isConvexValidator = !0;
  }
}, se = class e extends E {
  static {
    n(this, "VId");
  }
  /**
   * Usually you'd use `v.id(tableName)` instead.
   */
  constructor({
    isOptional: t,
    tableName: r
  }) {
    if (super({ isOptional: t }), g(this, "tableName"), g(this, "kind", "id"), typeof r != "string")
      throw new Error("v.id(tableName) requires a string");
    this.tableName = r;
  }
  /** @internal */
  get json() {
    return { type: "id", tableName: this.tableName };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      tableName: this.tableName
    });
  }
}, X = class e extends E {
  static {
    n(this, "VFloat64");
  }
  constructor() {
    super(...arguments), g(this, "kind", "float64");
  }
  /** @internal */
  get json() {
    return { type: "number" };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, Z = class e extends E {
  static {
    n(this, "VInt64");
  }
  constructor() {
    super(...arguments), g(this, "kind", "int64");
  }
  /** @internal */
  get json() {
    return { type: "bigint" };
  }
  /** @internal */
  asOptional() {
    return new e({ isOptional: "optional" });
  }
}, ie = class e extends E {
  static {
    n(this, "VBoolean");
  }
  constructor() {
    super(...arguments), g(this, "kind", "boolean");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, ae = class e extends E {
  static {
    n(this, "VBytes");
  }
  constructor() {
    super(...arguments), g(this, "kind", "bytes");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({ isOptional: "optional" });
  }
}, ce = class e extends E {
  static {
    n(this, "VString");
  }
  constructor() {
    super(...arguments), g(this, "kind", "string");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, ue = class e extends E {
  static {
    n(this, "VNull");
  }
  constructor() {
    super(...arguments), g(this, "kind", "null");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({ isOptional: "optional" });
  }
}, le = class e extends E {
  static {
    n(this, "VAny");
  }
  constructor() {
    super(...arguments), g(this, "kind", "any");
  }
  /** @internal */
  get json() {
    return {
      type: this.kind
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, fe = class e extends E {
  static {
    n(this, "VObject");
  }
  /**
   * Usually you'd use `v.object({ ... })` instead.
   */
  constructor({
    isOptional: t,
    fields: r
  }) {
    super({ isOptional: t }), g(this, "fields"), g(this, "kind", "object"), globalThis.Object.entries(r).forEach(([o, s]) => {
      if (s === void 0 && Y("v.object()", o), !s.isConvexValidator)
        throw new Error("v.object() entries must be validators");
    }), this.fields = r;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: globalThis.Object.fromEntries(
        globalThis.Object.entries(this.fields).map(([t, r]) => [
          t,
          {
            fieldType: r.json,
            optional: r.isOptional === "optional"
          }
        ])
      )
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      fields: this.fields
    });
  }
  /**
   * Create a new VObject with the specified fields omitted.
   * @param fields The field names to omit from this VObject.
   */
  omit(...t) {
    let r = { ...this.fields };
    for (let o of t)
      delete r[o];
    return new e({
      isOptional: this.isOptional,
      fields: r
    });
  }
  /**
   * Create a new VObject with only the specified fields.
   * @param fields The field names to pick from this VObject.
   */
  pick(...t) {
    let r = {};
    for (let o of t)
      r[o] = this.fields[o];
    return new e({
      isOptional: this.isOptional,
      fields: r
    });
  }
  /**
   * Create a new VObject with all fields marked as optional.
   */
  partial() {
    let t = {};
    for (let [r, o] of globalThis.Object.entries(this.fields))
      t[r] = o.asOptional();
    return new e({
      isOptional: this.isOptional,
      fields: t
    });
  }
  /**
   * Create a new VObject with additional fields merged in.
   * @param fields An object with additional validators to merge into this VObject.
   */
  extend(t) {
    return new e({
      isOptional: this.isOptional,
      fields: { ...this.fields, ...t }
    });
  }
}, de = class e extends E {
  static {
    n(this, "VLiteral");
  }
  /**
   * Usually you'd use `v.literal(value)` instead.
   */
  constructor({ isOptional: t, value: r }) {
    if (super({ isOptional: t }), g(this, "value"), g(this, "kind", "literal"), typeof r != "string" && typeof r != "boolean" && typeof r != "number" && typeof r != "bigint")
      throw new Error("v.literal(value) must be a string, number, or boolean");
    this.value = r;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: w(this.value)
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      value: this.value
    });
  }
}, pe = class e extends E {
  static {
    n(this, "VArray");
  }
  /**
   * Usually you'd use `v.array(element)` instead.
   */
  constructor({
    isOptional: t,
    element: r
  }) {
    super({ isOptional: t }), g(this, "element"), g(this, "kind", "array"), r === void 0 && Y("v.array()"), this.element = r;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: this.element.json
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      element: this.element
    });
  }
}, he = class e extends E {
  static {
    n(this, "VRecord");
  }
  /**
   * Usually you'd use `v.record(key, value)` instead.
   */
  constructor({
    isOptional: t,
    key: r,
    value: o
  }) {
    if (super({ isOptional: t }), g(this, "key"), g(this, "value"), g(this, "kind", "record"), r === void 0 && Y("v.record()", "key"), o === void 0 && Y("v.record()", "value"), r.isOptional === "optional")
      throw new Error("Record validator cannot have optional keys");
    if (o.isOptional === "optional")
      throw new Error("Record validator cannot have optional values");
    if (!r.isConvexValidator || !o.isConvexValidator)
      throw new Error("Key and value of v.record() but be validators");
    this.key = r, this.value = o;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      // This cast is needed because TypeScript thinks the key type is too wide
      keys: this.key.json,
      values: {
        fieldType: this.value.json,
        optional: !1
      }
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      key: this.key,
      value: this.value
    });
  }
}, me = class e extends E {
  static {
    n(this, "VUnion");
  }
  /**
   * Usually you'd use `v.union(...members)` instead.
   */
  constructor({ isOptional: t, members: r }) {
    super({ isOptional: t }), g(this, "members"), g(this, "kind", "union"), r.forEach((o, s) => {
      if (o === void 0 && Y("v.union()", `member at index ${s}`), !o.isConvexValidator)
        throw new Error("All members of v.union() must be validators");
    }), this.members = r;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: this.members.map((t) => t.json)
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      members: this.members
    });
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/validator.js
function je(e) {
  return !!e.isConvexValidator;
}
n(je, "isValidator");
function ye(e) {
  return je(e) ? e : c.object(e);
}
n(ye, "asObjectValidator");
var c = {
  /**
   * Validates that the value is a document ID for the given table.
   *
   * IDs are strings at runtime but are typed as `Id<"tableName">` in
   * TypeScript for type safety.
   *
   * @example
   * ```typescript
   * args: { userId: v.id("users") }
   * ```
   *
   * @param tableName The name of the table.
   */
  id: /* @__PURE__ */ n((e) => new se({
    isOptional: "required",
    tableName: e
  }), "id"),
  /**
   * Validates that the value is `null`.
   *
   * Use `returns: v.null()` for functions that don't return a meaningful value.
   * JavaScript `undefined` is not a valid Convex value, it is automatically
   * converted to `null`.
   */
  null: /* @__PURE__ */ n(() => new ue({ isOptional: "required" }), "null"),
  /**
   * Validates that the value is a JavaScript `number` (Convex Float64).
   *
   * Supports all IEEE-754 double-precision floating point numbers including
   * NaN and Infinity.
   *
   * Alias for `v.float64()`.
   */
  number: /* @__PURE__ */ n(() => new X({ isOptional: "required" }), "number"),
  /**
   * Validates that the value is a JavaScript `number` (Convex Float64).
   *
   * Supports all IEEE-754 double-precision floating point numbers.
   */
  float64: /* @__PURE__ */ n(() => new X({ isOptional: "required" }), "float64"),
  /**
   * @deprecated Use `v.int64()` instead.
   */
  bigint: /* @__PURE__ */ n(() => new Z({ isOptional: "required" }), "bigint"),
  /**
   * Validates that the value is a JavaScript `bigint` (Convex Int64).
   *
   * Supports BigInts between -2^63 and 2^63-1.
   *
   * @example
   * ```typescript
   * args: { timestamp: v.int64() }
   * // Usage: createDoc({ timestamp: 1234567890n })
   * ```
   */
  int64: /* @__PURE__ */ n(() => new Z({ isOptional: "required" }), "int64"),
  /**
   * Validates that the value is a `boolean`.
   */
  boolean: /* @__PURE__ */ n(() => new ie({ isOptional: "required" }), "boolean"),
  /**
   * Validates that the value is a `string`.
   *
   * Strings are stored as UTF-8 and their storage size is calculated as their
   * UTF-8 encoded size.
   */
  string: /* @__PURE__ */ n(() => new ce({ isOptional: "required" }), "string"),
  /**
   * Validates that the value is an `ArrayBuffer` (Convex Bytes).
   *
   * Use for binary data.
   */
  bytes: /* @__PURE__ */ n(() => new ae({ isOptional: "required" }), "bytes"),
  /**
   * Validates that the value is exactly equal to the given literal.
   *
   * Useful for discriminated unions and enum-like patterns.
   *
   * @example
   * ```typescript
   * // Discriminated union pattern:
   * v.union(
   *   v.object({ kind: v.literal("error"), message: v.string() }),
   *   v.object({ kind: v.literal("success"), value: v.number() }),
   * )
   * ```
   *
   * @param literal The literal value to compare against.
   */
  literal: /* @__PURE__ */ n((e) => new de({ isOptional: "required", value: e }), "literal"),
  /**
   * Validates that the value is an `Array` where every element matches the
   * given validator.
   *
   * Arrays can have at most 8192 elements.
   *
   * @example
   * ```typescript
   * args: { tags: v.array(v.string()) }
   * args: { coordinates: v.array(v.number()) }
   * args: { items: v.array(v.object({ name: v.string(), qty: v.number() })) }
   * ```
   *
   * @param element The validator for the elements of the array.
   */
  array: /* @__PURE__ */ n((e) => new pe({ isOptional: "required", element: e }), "array"),
  /**
   * Validates that the value is an `Object` with the specified properties.
   *
   * Objects can have at most 1024 entries. Field names must be non-empty and
   * must not start with `"$"` or `"_"` (`_` is reserved for system fields
   * like `_id` and `_creationTime`; `$` is reserved for Convex internal use).
   *
   * @example
   * ```typescript
   * args: {
   *   user: v.object({
   *     name: v.string(),
   *     email: v.string(),
   *     age: v.optional(v.number()),
   *   })
   * }
   * ```
   *
   * @param fields An object mapping property names to their validators.
   */
  object: /* @__PURE__ */ n((e) => new fe({ isOptional: "required", fields: e }), "object"),
  /**
   * Validates that the value is a `Record` (object with dynamic keys).
   *
   * Records are objects at runtime but allow dynamic keys, unlike `v.object()`
   * which requires known property names. Keys must be ASCII characters only,
   * non-empty, and not start with `"$"` or `"_"`.
   *
   * @example
   * ```typescript
   * // Map of user IDs to scores:
   * args: { scores: v.record(v.id("users"), v.number()) }
   *
   * // Map of string keys to string values:
   * args: { metadata: v.record(v.string(), v.string()) }
   * ```
   *
   * @param keys The validator for the keys of the record.
   * @param values The validator for the values of the record.
   */
  record: /* @__PURE__ */ n((e, t) => new he({
    isOptional: "required",
    key: e,
    value: t
  }), "record"),
  /**
   * Validates that the value matches at least one of the given validators.
   *
   * @example
   * ```typescript
   * // Allow string or number:
   * args: { value: v.union(v.string(), v.number()) }
   *
   * // Discriminated union (recommended pattern):
   * v.union(
   *   v.object({ kind: v.literal("text"), body: v.string() }),
   *   v.object({ kind: v.literal("image"), url: v.string() }),
   * )
   *
   * // Nullable value:
   * returns: v.union(v.object({ ... }), v.null())
   * ```
   *
   * @param members The validators to match against.
   */
  union: /* @__PURE__ */ n((...e) => new me({
    isOptional: "required",
    members: e
  }), "union"),
  /**
   * A validator that accepts any Convex value without validation.
   *
   * Prefer using specific validators when possible for better type safety
   * and runtime validation.
   */
  any: /* @__PURE__ */ n(() => new le({ isOptional: "required" }), "any"),
  /**
   * Makes a property optional in an object validator.
   *
   * An optional property can be omitted entirely when creating a document or
   * calling a function. This is different from `v.nullable()` which requires
   * the property to be present but allows `null`.
   *
   * @example
   * ```typescript
   * v.object({
   *   name: v.string(),              // required
   *   nickname: v.optional(v.string()), // can be omitted
   * })
   *
   * // Valid: { name: "Alice" }
   * // Valid: { name: "Alice", nickname: "Ali" }
   * // Invalid: { name: "Alice", nickname: null }  - use v.nullable() for this
   * ```
   *
   * @param value The property value validator to make optional.
   */
  optional: /* @__PURE__ */ n((e) => e.asOptional(), "optional"),
  /**
   * Allows a value to be either the given type or `null`.
   *
   * This is shorthand for `v.union(value, v.null())`. Unlike `v.optional()`,
   * the property must still be present, but may be `null`.
   *
   * @example
   * ```typescript
   * v.object({
   *   name: v.string(),
   *   deletedAt: v.nullable(v.number()), // must be present, can be null
   * })
   *
   * // Valid: { name: "Alice", deletedAt: null }
   * // Valid: { name: "Alice", deletedAt: 1234567890 }
   * // Invalid: { name: "Alice" }  - deletedAt is required
   * ```
   */
  nullable: /* @__PURE__ */ n((e) => c.union(e, c.null()), "nullable")
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/errors.js
var dr = Object.defineProperty, pr = /* @__PURE__ */ n((e, t, r) => t in e ? dr(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), Re = /* @__PURE__ */ n((e, t, r) => pr(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), wt, gt, hr = Symbol.for("ConvexError"), we = class extends (gt = Error, wt = hr, gt) {
  static {
    n(this, "ConvexError");
  }
  constructor(t) {
    super(typeof t == "string" ? t : j(t)), Re(this, "name", "ConvexError"), Re(this, "data"), Re(this, wt, !0), this.data = t;
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/compare_utf8.js
var xt = /* @__PURE__ */ n(() => Array.from({ length: 4 }, () => 0), "arr"), fn = xt(), dn = xt();

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/index.js
var b = "1.32.0";

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/syscall.js
function K(e, t) {
  if (typeof Convex > "u" || Convex.syscall === void 0)
    throw new Error(
      "The Convex database and auth objects are being used outside of a Convex backend. Did you mean to use `useQuery` or `useMutation` to call a Convex function?"
    );
  let r = Convex.syscall(e, JSON.stringify(t));
  return JSON.parse(r);
}
n(K, "performSyscall");
async function d(e, t) {
  if (typeof Convex > "u" || Convex.asyncSyscall === void 0)
    throw new Error(
      "The Convex database and auth objects are being used outside of a Convex backend. Did you mean to use `useQuery` or `useMutation` to call a Convex function?"
    );
  let r;
  try {
    r = await Convex.asyncSyscall(e, JSON.stringify(t));
  } catch (o) {
    if (o.data !== void 0) {
      let s = new we(o.message);
      throw s.data = x(o.data), s;
    }
    throw new Error(o.message);
  }
  return JSON.parse(r);
}
n(d, "performAsyncSyscall");
function ge(e, t) {
  if (typeof Convex > "u" || Convex.jsSyscall === void 0)
    throw new Error(
      "The Convex database and auth objects are being used outside of a Convex backend. Did you mean to use `useQuery` or `useMutation` to call a Convex function?"
    );
  return Convex.jsSyscall(e, t);
}
n(ge, "performJsSyscall");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/functionName.js
var ee = Symbol.for("functionName");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/components/paths.js
var bt = Symbol.for("toReferencePath");
function mr(e) {
  return e[bt] ?? null;
}
n(mr, "extractReferencePath");
function yr(e) {
  return e.startsWith("function://");
}
n(yr, "isFunctionHandle");
function O(e) {
  let t;
  if (typeof e == "string")
    yr(e) ? t = { functionHandle: e } : t = { name: e };
  else if (e[ee])
    t = { name: e[ee] };
  else {
    let r = mr(e);
    if (!r)
      throw new Error(`${e} is not a functionReference`);
    t = { reference: r };
  }
  return t;
}
n(O, "getFunctionAddress");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/actions_impl.js
function qe(e, t, r) {
  return {
    ...O(t),
    args: w(P(r)),
    version: b,
    requestId: e
  };
}
n(qe, "syscallArgs");
function vt(e) {
  return {
    runQuery: /* @__PURE__ */ n(async (t, r) => {
      let o = await d(
        "1.0/actions/query",
        qe(e, t, r)
      );
      return x(o);
    }, "runQuery"),
    runMutation: /* @__PURE__ */ n(async (t, r) => {
      let o = await d(
        "1.0/actions/mutation",
        qe(e, t, r)
      );
      return x(o);
    }, "runMutation"),
    runAction: /* @__PURE__ */ n(async (t, r) => {
      let o = await d(
        "1.0/actions/action",
        qe(e, t, r)
      );
      return x(o);
    }, "runAction")
  };
}
n(vt, "setupActionCalls");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/vector_search.js
var wr = Object.defineProperty, gr = /* @__PURE__ */ n((e, t, r) => t in e ? wr(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), At = /* @__PURE__ */ n((e, t, r) => gr(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), xe = class {
  static {
    n(this, "FilterExpression");
  }
  /**
   * @internal
   */
  constructor() {
    At(this, "_isExpression"), At(this, "_value");
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/validate.js
function l(e, t, r, o) {
  if (e === void 0)
    throw new TypeError(
      `Must provide arg ${t} \`${o}\` to \`${r}\``
    );
}
n(l, "validateArg");
function Et(e, t, r, o) {
  if (!Number.isInteger(e) || e < 0)
    throw new TypeError(
      `Arg ${t} \`${o}\` to \`${r}\` must be a non-negative integer`
    );
}
n(Et, "validateArgIsNonNegativeInteger");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/vector_search_impl.js
var xr = Object.defineProperty, br = /* @__PURE__ */ n((e, t, r) => t in e ? xr(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), Be = /* @__PURE__ */ n((e, t, r) => br(e, typeof t != "symbol" ? t + "" : t, r), "__publicField");
function St(e) {
  return async (t, r, o) => {
    if (l(t, 1, "vectorSearch", "tableName"), l(r, 2, "vectorSearch", "indexName"), l(o, 3, "vectorSearch", "query"), !o.vector || !Array.isArray(o.vector) || o.vector.length === 0)
      throw Error("`vector` must be a non-empty Array in vectorSearch");
    return await new Me(
      e,
      t + "." + r,
      o
    ).collect();
  };
}
n(St, "setupActionVectorSearch");
var Me = class {
  static {
    n(this, "VectorQueryImpl");
  }
  constructor(t, r, o) {
    Be(this, "requestId"), Be(this, "state"), this.requestId = t;
    let s = o.filter ? be(o.filter(vr)) : null;
    this.state = {
      type: "preparing",
      query: {
        indexName: r,
        limit: o.limit,
        vector: o.vector,
        expressions: s
      }
    };
  }
  async collect() {
    if (this.state.type === "consumed")
      throw new Error("This query is closed and can't emit any more values.");
    let t = this.state.query;
    this.state = { type: "consumed" };
    let { results: r } = await d("1.0/actions/vectorSearch", {
      requestId: this.requestId,
      version: b,
      query: t
    });
    return r;
  }
}, M = class extends xe {
  static {
    n(this, "ExpressionImpl");
  }
  constructor(t) {
    super(), Be(this, "inner"), this.inner = t;
  }
  serialize() {
    return this.inner;
  }
};
function be(e) {
  return e instanceof M ? e.serialize() : { $literal: T(e) };
}
n(be, "serializeExpression");
var vr = {
  //  Comparisons  /////////////////////////////////////////////////////////////
  eq(e, t) {
    if (typeof e != "string")
      throw new Error("The first argument to `q.eq` must be a field name.");
    return new M({
      $eq: [
        be(new M({ $field: e })),
        be(t)
      ]
    });
  },
  //  Logic  ///////////////////////////////////////////////////////////////////
  or(...e) {
    return new M({ $or: e.map(be) });
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/authentication_impl.js
function ve(e) {
  return {
    getUserIdentity: /* @__PURE__ */ n(async () => await d("1.0/getUserIdentity", {
      requestId: e
    }), "getUserIdentity")
  };
}
n(ve, "setupAuth");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/filter_builder.js
var Ar = Object.defineProperty, Er = /* @__PURE__ */ n((e, t, r) => t in e ? Ar(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), It = /* @__PURE__ */ n((e, t, r) => Er(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), Ae = class {
  static {
    n(this, "Expression");
  }
  /**
   * @internal
   */
  constructor() {
    It(this, "_isExpression"), It(this, "_value");
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/filter_builder_impl.js
var Sr = Object.defineProperty, Ir = /* @__PURE__ */ n((e, t, r) => t in e ? Sr(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), Tr = /* @__PURE__ */ n((e, t, r) => Ir(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), v = class extends Ae {
  static {
    n(this, "ExpressionImpl");
  }
  constructor(t) {
    super(), Tr(this, "inner"), this.inner = t;
  }
  serialize() {
    return this.inner;
  }
};
function y(e) {
  return e instanceof v ? e.serialize() : { $literal: T(e) };
}
n(y, "serializeExpression");
var Tt = {
  //  Comparisons  /////////////////////////////////////////////////////////////
  eq(e, t) {
    return new v({
      $eq: [y(e), y(t)]
    });
  },
  neq(e, t) {
    return new v({
      $neq: [y(e), y(t)]
    });
  },
  lt(e, t) {
    return new v({
      $lt: [y(e), y(t)]
    });
  },
  lte(e, t) {
    return new v({
      $lte: [y(e), y(t)]
    });
  },
  gt(e, t) {
    return new v({
      $gt: [y(e), y(t)]
    });
  },
  gte(e, t) {
    return new v({
      $gte: [y(e), y(t)]
    });
  },
  //  Arithmetic  //////////////////////////////////////////////////////////////
  add(e, t) {
    return new v({
      $add: [y(e), y(t)]
    });
  },
  sub(e, t) {
    return new v({
      $sub: [y(e), y(t)]
    });
  },
  mul(e, t) {
    return new v({
      $mul: [y(e), y(t)]
    });
  },
  div(e, t) {
    return new v({
      $div: [y(e), y(t)]
    });
  },
  mod(e, t) {
    return new v({
      $mod: [y(e), y(t)]
    });
  },
  neg(e) {
    return new v({ $neg: y(e) });
  },
  //  Logic  ///////////////////////////////////////////////////////////////////
  and(...e) {
    return new v({ $and: e.map(y) });
  },
  or(...e) {
    return new v({ $or: e.map(y) });
  },
  not(e) {
    return new v({ $not: y(e) });
  },
  //  Other  ///////////////////////////////////////////////////////////////////
  field(e) {
    return new v({ $field: e });
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/index_range_builder.js
var Or = Object.defineProperty, _r = /* @__PURE__ */ n((e, t, r) => t in e ? Or(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), Cr = /* @__PURE__ */ n((e, t, r) => _r(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), Ee = class {
  static {
    n(this, "IndexRange");
  }
  /**
   * @internal
   */
  constructor() {
    Cr(this, "_isIndexRange");
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/index_range_builder_impl.js
var $r = Object.defineProperty, Nr = /* @__PURE__ */ n((e, t, r) => t in e ? $r(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), Ot = /* @__PURE__ */ n((e, t, r) => Nr(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), Se = class e extends Ee {
  static {
    n(this, "IndexRangeBuilderImpl");
  }
  constructor(t) {
    super(), Ot(this, "rangeExpressions"), Ot(this, "isConsumed"), this.rangeExpressions = t, this.isConsumed = !1;
  }
  static new() {
    return new e([]);
  }
  consume() {
    if (this.isConsumed)
      throw new Error(
        "IndexRangeBuilder has already been used! Chain your method calls like `q => q.eq(...).eq(...)`. See https://docs.convex.dev/using/indexes"
      );
    this.isConsumed = !0;
  }
  eq(t, r) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Eq",
        fieldPath: t,
        value: T(r)
      })
    );
  }
  gt(t, r) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Gt",
        fieldPath: t,
        value: T(r)
      })
    );
  }
  gte(t, r) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Gte",
        fieldPath: t,
        value: T(r)
      })
    );
  }
  lt(t, r) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Lt",
        fieldPath: t,
        value: T(r)
      })
    );
  }
  lte(t, r) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Lte",
        fieldPath: t,
        value: T(r)
      })
    );
  }
  export() {
    return this.consume(), this.rangeExpressions;
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/search_filter_builder.js
var Pr = Object.defineProperty, Fr = /* @__PURE__ */ n((e, t, r) => t in e ? Pr(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), jr = /* @__PURE__ */ n((e, t, r) => Fr(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), Ie = class {
  static {
    n(this, "SearchFilter");
  }
  /**
   * @internal
   */
  constructor() {
    jr(this, "_isSearchFilter");
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/search_filter_builder_impl.js
var Rr = Object.defineProperty, qr = /* @__PURE__ */ n((e, t, r) => t in e ? Rr(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), _t = /* @__PURE__ */ n((e, t, r) => qr(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), Te = class e extends Ie {
  static {
    n(this, "SearchFilterBuilderImpl");
  }
  constructor(t) {
    super(), _t(this, "filters"), _t(this, "isConsumed"), this.filters = t, this.isConsumed = !1;
  }
  static new() {
    return new e([]);
  }
  consume() {
    if (this.isConsumed)
      throw new Error(
        "SearchFilterBuilder has already been used! Chain your method calls like `q => q.search(...).eq(...)`."
      );
    this.isConsumed = !0;
  }
  search(t, r) {
    return l(t, 1, "search", "fieldName"), l(r, 2, "search", "query"), this.consume(), new e(
      this.filters.concat({
        type: "Search",
        fieldPath: t,
        value: r
      })
    );
  }
  eq(t, r) {
    return l(t, 1, "eq", "fieldName"), arguments.length !== 2 && l(r, 2, "search", "value"), this.consume(), new e(
      this.filters.concat({
        type: "Eq",
        fieldPath: t,
        value: T(r)
      })
    );
  }
  export() {
    return this.consume(), this.filters;
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/query_impl.js
var Br = Object.defineProperty, Mr = /* @__PURE__ */ n((e, t, r) => t in e ? Br(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), Ue = /* @__PURE__ */ n((e, t, r) => Mr(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), Ct = 256, U = class {
  static {
    n(this, "QueryInitializerImpl");
  }
  constructor(t) {
    Ue(this, "tableName"), this.tableName = t;
  }
  withIndex(t, r) {
    l(t, 1, "withIndex", "indexName");
    let o = Se.new();
    return r !== void 0 && (o = r(o)), new R({
      source: {
        type: "IndexRange",
        indexName: this.tableName + "." + t,
        range: o.export(),
        order: null
      },
      operators: []
    });
  }
  withSearchIndex(t, r) {
    l(t, 1, "withSearchIndex", "indexName"), l(r, 2, "withSearchIndex", "searchFilter");
    let o = Te.new();
    return new R({
      source: {
        type: "Search",
        indexName: this.tableName + "." + t,
        filters: r(o).export()
      },
      operators: []
    });
  }
  fullTableScan() {
    return new R({
      source: {
        type: "FullTableScan",
        tableName: this.tableName,
        order: null
      },
      operators: []
    });
  }
  order(t) {
    return this.fullTableScan().order(t);
  }
  // This is internal API and should not be exposed to developers yet.
  async count() {
    let t = await d("1.0/count", {
      table: this.tableName
    });
    return x(t);
  }
  filter(t) {
    return this.fullTableScan().filter(t);
  }
  limit(t) {
    return this.fullTableScan().limit(t);
  }
  collect() {
    return this.fullTableScan().collect();
  }
  take(t) {
    return this.fullTableScan().take(t);
  }
  paginate(t) {
    return this.fullTableScan().paginate(t);
  }
  first() {
    return this.fullTableScan().first();
  }
  unique() {
    return this.fullTableScan().unique();
  }
  [Symbol.asyncIterator]() {
    return this.fullTableScan()[Symbol.asyncIterator]();
  }
};
function $t(e) {
  throw new Error(
    e === "consumed" ? "This query is closed and can't emit any more values." : "This query has been chained with another operator and can't be reused."
  );
}
n($t, "throwClosedError");
var R = class e {
  static {
    n(this, "QueryImpl");
  }
  constructor(t) {
    Ue(this, "state"), Ue(this, "tableNameForErrorMessages"), this.state = { type: "preparing", query: t }, t.source.type === "FullTableScan" ? this.tableNameForErrorMessages = t.source.tableName : this.tableNameForErrorMessages = t.source.indexName.split(".")[0];
  }
  takeQuery() {
    if (this.state.type !== "preparing")
      throw new Error(
        "A query can only be chained once and can't be chained after iteration begins."
      );
    let t = this.state.query;
    return this.state = { type: "closed" }, t;
  }
  startQuery() {
    if (this.state.type === "executing")
      throw new Error("Iteration can only begin on a query once.");
    (this.state.type === "closed" || this.state.type === "consumed") && $t(this.state.type);
    let t = this.state.query, { queryId: r } = K("1.0/queryStream", { query: t, version: b });
    return this.state = { type: "executing", queryId: r }, r;
  }
  closeQuery() {
    if (this.state.type === "executing") {
      let t = this.state.queryId;
      K("1.0/queryCleanup", { queryId: t });
    }
    this.state = { type: "consumed" };
  }
  order(t) {
    l(t, 1, "order", "order");
    let r = this.takeQuery();
    if (r.source.type === "Search")
      throw new Error(
        "Search queries must always be in relevance order. Can not set order manually."
      );
    if (r.source.order !== null)
      throw new Error("Queries may only specify order at most once");
    return r.source.order = t, new e(r);
  }
  filter(t) {
    l(t, 1, "filter", "predicate");
    let r = this.takeQuery();
    if (r.operators.length >= Ct)
      throw new Error(
        `Can't construct query with more than ${Ct} operators`
      );
    return r.operators.push({
      filter: y(t(Tt))
    }), new e(r);
  }
  limit(t) {
    l(t, 1, "limit", "n");
    let r = this.takeQuery();
    return r.operators.push({ limit: t }), new e(r);
  }
  [Symbol.asyncIterator]() {
    return this.startQuery(), this;
  }
  async next() {
    (this.state.type === "closed" || this.state.type === "consumed") && $t(this.state.type);
    let t = this.state.type === "preparing" ? this.startQuery() : this.state.queryId, { value: r, done: o } = await d("1.0/queryStreamNext", {
      queryId: t
    });
    return o && this.closeQuery(), { value: x(r), done: o };
  }
  return() {
    return this.closeQuery(), Promise.resolve({ done: !0, value: void 0 });
  }
  async paginate(t) {
    if (l(t, 1, "paginate", "options"), typeof t?.numItems != "number" || t.numItems < 0)
      throw new Error(
        `\`options.numItems\` must be a positive number. Received \`${t?.numItems}\`.`
      );
    let r = this.takeQuery(), o = t.numItems, s = t.cursor, i = t?.endCursor ?? null, a = t.maximumRowsRead ?? null, { page: p, isDone: m, continueCursor: S, splitCursor: f, pageStatus: D } = await d("1.0/queryPage", {
      query: r,
      cursor: s,
      endCursor: i,
      pageSize: o,
      maximumRowsRead: a,
      maximumBytesRead: t.maximumBytesRead,
      version: b
    });
    return {
      page: p.map((G) => x(G)),
      isDone: m,
      continueCursor: S,
      splitCursor: f,
      pageStatus: D
    };
  }
  async collect() {
    let t = [];
    for await (let r of this)
      t.push(r);
    return t;
  }
  async take(t) {
    return l(t, 1, "take", "n"), Et(t, 1, "take", "n"), this.limit(t).collect();
  }
  async first() {
    let t = await this.take(1);
    return t.length === 0 ? null : t[0];
  }
  async unique() {
    let t = await this.take(2);
    if (t.length === 0)
      return null;
    if (t.length === 2)
      throw new Error(`unique() query returned more than one result from table ${this.tableNameForErrorMessages}:
 [${t[0]._id}, ${t[1]._id}, ...]`);
    return t[0];
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/database_impl.js
async function ke(e, t, r) {
  if (l(t, 1, "get", "id"), typeof t != "string")
    throw new Error(
      `Invalid argument \`id\` for \`db.get\`, expected string but got '${typeof t}': ${t}`
    );
  let o = {
    id: w(t),
    isSystem: r,
    version: b,
    table: e
  }, s = await d("1.0/get", o);
  return x(s);
}
n(ke, "get");
function Ge() {
  let e = /* @__PURE__ */ n((s = !1) => ({
    get: /* @__PURE__ */ n(async (i, a) => a !== void 0 ? await ke(i, a, s) : await ke(void 0, i, s), "get"),
    query: /* @__PURE__ */ n((i) => new te(i, s).query(), "query"),
    normalizeId: /* @__PURE__ */ n((i, a) => {
      l(i, 1, "normalizeId", "tableName"), l(a, 2, "normalizeId", "id");
      let p = i.startsWith("_");
      if (p !== s)
        throw new Error(
          `${p ? "System" : "User"} tables can only be accessed from db.${s ? "" : "system."}normalizeId().`
        );
      let m = K("1.0/db/normalizeId", {
        table: i,
        idString: a
      });
      return x(m).id;
    }, "normalizeId"),
    // We set the system reader on the next line
    system: null,
    table: /* @__PURE__ */ n((i) => new te(i, s), "table")
  }), "reader"), { system: t, ...r } = e(!0), o = e();
  return o.system = r, o;
}
n(Ge, "setupReader");
async function Nt(e, t) {
  if (e.startsWith("_"))
    throw new Error("System tables (prefixed with `_`) are read-only.");
  l(e, 1, "insert", "table"), l(t, 2, "insert", "value");
  let r = await d("1.0/insert", {
    table: e,
    value: w(t)
  });
  return x(r)._id;
}
n(Nt, "insert");
async function Je(e, t, r) {
  l(t, 1, "patch", "id"), l(r, 2, "patch", "value"), await d("1.0/shallowMerge", {
    id: w(t),
    value: yt(r),
    table: e
  });
}
n(Je, "patch");
async function Le(e, t, r) {
  l(t, 1, "replace", "id"), l(r, 2, "replace", "value"), await d("1.0/replace", {
    id: w(t),
    value: w(r),
    table: e
  });
}
n(Le, "replace");
async function Ve(e, t) {
  l(t, 1, "delete", "id"), await d("1.0/remove", {
    id: w(t),
    table: e
  });
}
n(Ve, "delete_");
function Pt() {
  let e = Ge();
  return {
    get: e.get,
    query: e.query,
    normalizeId: e.normalizeId,
    system: e.system,
    insert: /* @__PURE__ */ n(async (t, r) => await Nt(t, r), "insert"),
    patch: /* @__PURE__ */ n(async (t, r, o) => o !== void 0 ? await Je(t, r, o) : await Je(void 0, t, r), "patch"),
    replace: /* @__PURE__ */ n(async (t, r, o) => o !== void 0 ? await Le(t, r, o) : await Le(void 0, t, r), "replace"),
    delete: /* @__PURE__ */ n(async (t, r) => r !== void 0 ? await Ve(t, r) : await Ve(void 0, t), "delete"),
    table: /* @__PURE__ */ n((t) => new De(t, !1), "table")
  };
}
n(Pt, "setupWriter");
var te = class {
  static {
    n(this, "TableReader");
  }
  constructor(t, r) {
    this.tableName = t, this.isSystem = r;
  }
  async get(t) {
    return ke(this.tableName, t, this.isSystem);
  }
  query() {
    let t = this.tableName.startsWith("_");
    if (t !== this.isSystem)
      throw new Error(
        `${t ? "System" : "User"} tables can only be accessed from db.${this.isSystem ? "" : "system."}query().`
      );
    return new U(this.tableName);
  }
}, De = class extends te {
  static {
    n(this, "TableWriter");
  }
  async insert(t) {
    return Nt(this.tableName, t);
  }
  async patch(t, r) {
    return Je(this.tableName, t, r);
  }
  async replace(t, r) {
    return Le(this.tableName, t, r);
  }
  async delete(t) {
    return Ve(this.tableName, t);
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/scheduler_impl.js
function Ft() {
  return {
    runAfter: /* @__PURE__ */ n(async (e, t, r) => {
      let o = Rt(e, t, r);
      return await d("1.0/schedule", o);
    }, "runAfter"),
    runAt: /* @__PURE__ */ n(async (e, t, r) => {
      let o = qt(
        e,
        t,
        r
      );
      return await d("1.0/schedule", o);
    }, "runAt"),
    cancel: /* @__PURE__ */ n(async (e) => {
      l(e, 1, "cancel", "id");
      let t = { id: w(e) };
      await d("1.0/cancel_job", t);
    }, "cancel")
  };
}
n(Ft, "setupMutationScheduler");
function jt(e) {
  return {
    runAfter: /* @__PURE__ */ n(async (t, r, o) => {
      let s = {
        requestId: e,
        ...Rt(t, r, o)
      };
      return await d("1.0/actions/schedule", s);
    }, "runAfter"),
    runAt: /* @__PURE__ */ n(async (t, r, o) => {
      let s = {
        requestId: e,
        ...qt(t, r, o)
      };
      return await d("1.0/actions/schedule", s);
    }, "runAt"),
    cancel: /* @__PURE__ */ n(async (t) => {
      l(t, 1, "cancel", "id");
      let r = {
        requestId: e,
        id: w(t)
      };
      return await d("1.0/actions/cancel_job", r);
    }, "cancel")
  };
}
n(jt, "setupActionScheduler");
function Rt(e, t, r) {
  if (typeof e != "number")
    throw new Error("`delayMs` must be a number");
  if (!isFinite(e))
    throw new Error("`delayMs` must be a finite number");
  if (e < 0)
    throw new Error("`delayMs` must be non-negative");
  let o = P(r), s = O(t), i = (Date.now() + e) / 1e3;
  return {
    ...s,
    ts: i,
    args: w(o),
    version: b
  };
}
n(Rt, "runAfterSyscallArgs");
function qt(e, t, r) {
  let o;
  if (e instanceof Date)
    o = e.valueOf() / 1e3;
  else if (typeof e == "number")
    o = e / 1e3;
  else
    throw new Error("The invoke time must a Date or a timestamp");
  let s = O(t), i = P(r);
  return {
    ...s,
    ts: o,
    args: w(i),
    version: b
  };
}
n(qt, "runAtSyscallArgs");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/storage_impl.js
function He(e) {
  return {
    getUrl: /* @__PURE__ */ n(async (t) => (l(t, 1, "getUrl", "storageId"), await d("1.0/storageGetUrl", {
      requestId: e,
      version: b,
      storageId: t
    })), "getUrl"),
    getMetadata: /* @__PURE__ */ n(async (t) => await d("1.0/storageGetMetadata", {
      requestId: e,
      version: b,
      storageId: t
    }), "getMetadata")
  };
}
n(He, "setupStorageReader");
function Qe(e) {
  let t = He(e);
  return {
    generateUploadUrl: /* @__PURE__ */ n(async () => await d("1.0/storageGenerateUploadUrl", {
      requestId: e,
      version: b
    }), "generateUploadUrl"),
    delete: /* @__PURE__ */ n(async (r) => {
      await d("1.0/storageDelete", {
        requestId: e,
        version: b,
        storageId: r
      });
    }, "delete"),
    getUrl: t.getUrl,
    getMetadata: t.getMetadata
  };
}
n(Qe, "setupStorageWriter");
function Bt(e) {
  return {
    ...Qe(e),
    store: /* @__PURE__ */ n(async (r, o) => await ge("storage/storeBlob", {
      requestId: e,
      version: b,
      blob: r,
      options: o
    }), "store"),
    get: /* @__PURE__ */ n(async (r) => await ge("storage/getBlob", {
      requestId: e,
      version: b,
      storageId: r
    }), "get")
  };
}
n(Bt, "setupStorageActionWriter");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/registration_impl.js
async function Mt(e, t) {
  let o = x(JSON.parse(t)), s = {
    db: Pt(),
    auth: ve(""),
    storage: Qe(""),
    scheduler: Ft(),
    runQuery: /* @__PURE__ */ n((a, p) => ze("query", a, p), "runQuery"),
    runMutation: /* @__PURE__ */ n((a, p) => ze("mutation", a, p), "runMutation")
  }, i = await We(e, s, o);
  return Ut(i), JSON.stringify(w(i === void 0 ? null : i));
}
n(Mt, "invokeMutation");
function Ut(e) {
  if (e instanceof U || e instanceof R)
    throw new Error(
      "Return value is a Query. Results must be retrieved with `.collect()`, `.take(n), `.unique()`, or `.first()`."
    );
}
n(Ut, "validateReturnValue");
async function We(e, t, r) {
  let o;
  try {
    o = await Promise.resolve(e(t, ...r));
  } catch (s) {
    throw Ur(s);
  }
  return o;
}
n(We, "invokeFunction");
function k(e, t) {
  return (r, o) => (globalThis.console.warn(
    `Convex functions should not directly call other Convex functions. Consider calling a helper function instead. e.g. \`export const foo = ${e}(...); await foo(ctx);\` is not supported. See https://docs.convex.dev/production/best-practices/#use-helper-functions-to-write-shared-code`
  ), t(r, o));
}
n(k, "dontCallDirectly");
function Ur(e) {
  if (typeof e == "object" && e !== null && Symbol.for("ConvexError") in e) {
    let t = e;
    return t.data = JSON.stringify(
      w(t.data === void 0 ? null : t.data)
    ), t.ConvexErrorSymbol = Symbol.for("ConvexError"), t;
  } else
    return e;
}
n(Ur, "serializeConvexErrorData");
function J() {
  if (typeof window > "u" || window.__convexAllowFunctionsInBrowser)
    return;
  (Object.getOwnPropertyDescriptor(globalThis, "window")?.get?.toString().includes("[native code]") ?? !1) && console.error(
    "Convex functions should not be imported in the browser. This will throw an error in future versions of `convex`. If this is a false negative, please report it to Convex support."
  );
}
n(J, "assertNotBrowser");
function kt(e, t) {
  if (t === void 0)
    throw new Error(
      `A validator is undefined for field "${e}". This is often caused by circular imports. See https://docs.convex.dev/error#undefined-validator for details.`
    );
  return t;
}
n(kt, "strictReplacer");
function L(e) {
  return () => {
    let t = c.any();
    return typeof e == "object" && e.args !== void 0 && (t = ye(e.args)), JSON.stringify(t.json, kt);
  };
}
n(L, "exportArgs");
function V(e) {
  return () => {
    let t;
    return typeof e == "object" && e.returns !== void 0 && (t = ye(e.returns)), JSON.stringify(t ? t.json : null, kt);
  };
}
n(V, "exportReturns");
var Ye = /* @__PURE__ */ n(((e) => {
  let t = typeof e == "function" ? e : e.handler, r = k("mutation", t);
  return J(), r.isMutation = !0, r.isPublic = !0, r.invokeMutation = (o) => Mt(t, o), r.exportArgs = L(e), r.exportReturns = V(e), r._handler = t, r;
}), "mutationGeneric"), Xe = /* @__PURE__ */ n(((e) => {
  let t = typeof e == "function" ? e : e.handler, r = k(
    "internalMutation",
    t
  );
  return J(), r.isMutation = !0, r.isInternal = !0, r.invokeMutation = (o) => Mt(t, o), r.exportArgs = L(e), r.exportReturns = V(e), r._handler = t, r;
}), "internalMutationGeneric");
async function Jt(e, t) {
  let o = x(JSON.parse(t)), s = {
    db: Ge(),
    auth: ve(""),
    storage: He(""),
    runQuery: /* @__PURE__ */ n((a, p) => ze("query", a, p), "runQuery")
  }, i = await We(e, s, o);
  return Ut(i), JSON.stringify(w(i === void 0 ? null : i));
}
n(Jt, "invokeQuery");
var Ze = /* @__PURE__ */ n(((e) => {
  let t = typeof e == "function" ? e : e.handler, r = k("query", t);
  return J(), r.isQuery = !0, r.isPublic = !0, r.invokeQuery = (o) => Jt(t, o), r.exportArgs = L(e), r.exportReturns = V(e), r._handler = t, r;
}), "queryGeneric"), Ke = /* @__PURE__ */ n(((e) => {
  let t = typeof e == "function" ? e : e.handler, r = k("internalQuery", t);
  return J(), r.isQuery = !0, r.isInternal = !0, r.invokeQuery = (o) => Jt(t, o), r.exportArgs = L(e), r.exportReturns = V(e), r._handler = t, r;
}), "internalQueryGeneric");
async function Lt(e, t, r) {
  let o = x(JSON.parse(r)), i = {
    ...vt(t),
    auth: ve(t),
    scheduler: jt(t),
    storage: Bt(t),
    vectorSearch: St(t)
  }, a = await We(e, i, o);
  return JSON.stringify(w(a === void 0 ? null : a));
}
n(Lt, "invokeAction");
var et = /* @__PURE__ */ n(((e) => {
  let t = typeof e == "function" ? e : e.handler, r = k("action", t);
  return J(), r.isAction = !0, r.isPublic = !0, r.invokeAction = (o, s) => Lt(t, o, s), r.exportArgs = L(e), r.exportReturns = V(e), r._handler = t, r;
}), "actionGeneric"), tt = /* @__PURE__ */ n(((e) => {
  let t = typeof e == "function" ? e : e.handler, r = k("internalAction", t);
  return J(), r.isAction = !0, r.isInternal = !0, r.invokeAction = (o, s) => Lt(t, o, s), r.exportArgs = L(e), r.exportReturns = V(e), r._handler = t, r;
}), "internalActionGeneric");
async function ze(e, t, r) {
  let o = P(r), s = {
    udfType: e,
    args: w(o),
    ...O(t)
  }, i = await d("1.0/runUdf", s);
  return x(i);
}
n(ze, "runUdf");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/pagination.js
var gs = c.object({
  numItems: c.number(),
  cursor: c.union(c.string(), c.null()),
  endCursor: c.optional(c.union(c.string(), c.null())),
  id: c.optional(c.number()),
  maximumRowsRead: c.optional(c.number()),
  maximumBytesRead: c.optional(c.number())
});

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/api.js
function Vt(e = []) {
  let t = {
    get(r, o) {
      if (typeof o == "string") {
        let s = [...e, o];
        return Vt(s);
      } else if (o === ee) {
        if (e.length < 2) {
          let a = ["api", ...e].join(".");
          throw new Error(
            `API path is expected to be of the form \`api.moduleName.functionName\`. Found: \`${a}\``
          );
        }
        let s = e.slice(0, -1).join("/"), i = e[e.length - 1];
        return i === "default" ? s : s + ":" + i;
      } else return o === Symbol.toStringTag ? "FunctionReference" : void 0;
    }
  };
  return new Proxy({}, t);
}
n(Vt, "createApi");
var kr = Vt();

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/schema.js
var Lr = Object.defineProperty, Vr = /* @__PURE__ */ n((e, t, r) => t in e ? Lr(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), $ = /* @__PURE__ */ n((e, t, r) => Vr(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), Oe = class {
  static {
    n(this, "TableDefinition");
  }
  /**
   * @internal
   */
  constructor(t) {
    $(this, "indexes"), $(this, "stagedDbIndexes"), $(this, "searchIndexes"), $(this, "stagedSearchIndexes"), $(this, "vectorIndexes"), $(this, "stagedVectorIndexes"), $(this, "validator"), this.indexes = [], this.stagedDbIndexes = [], this.searchIndexes = [], this.stagedSearchIndexes = [], this.vectorIndexes = [], this.stagedVectorIndexes = [], this.validator = t;
  }
  /**
   * This API is experimental: it may change or disappear.
   *
   * Returns indexes defined on this table.
   * Intended for the advanced use cases of dynamically deciding which index to use for a query.
   * If you think you need this, please chime in on ths issue in the Convex JS GitHub repo.
   * https://github.com/get-convex/convex-js/issues/49
   */
  " indexes"() {
    return this.indexes;
  }
  index(t, r) {
    return Array.isArray(r) ? this.indexes.push({
      indexDescriptor: t,
      fields: r
    }) : r.staged ? this.stagedDbIndexes.push({
      indexDescriptor: t,
      fields: r.fields
    }) : this.indexes.push({
      indexDescriptor: t,
      fields: r.fields
    }), this;
  }
  searchIndex(t, r) {
    return r.staged ? this.stagedSearchIndexes.push({
      indexDescriptor: t,
      searchField: r.searchField,
      filterFields: r.filterFields || []
    }) : this.searchIndexes.push({
      indexDescriptor: t,
      searchField: r.searchField,
      filterFields: r.filterFields || []
    }), this;
  }
  vectorIndex(t, r) {
    return r.staged ? this.stagedVectorIndexes.push({
      indexDescriptor: t,
      vectorField: r.vectorField,
      dimensions: r.dimensions,
      filterFields: r.filterFields || []
    }) : this.vectorIndexes.push({
      indexDescriptor: t,
      vectorField: r.vectorField,
      dimensions: r.dimensions,
      filterFields: r.filterFields || []
    }), this;
  }
  /**
   * Work around for https://github.com/microsoft/TypeScript/issues/57035
   */
  self() {
    return this;
  }
  /**
   * Export the contents of this definition.
   *
   * This is called internally by the Convex framework.
   * @internal
   */
  export() {
    let t = this.validator.json;
    if (typeof t != "object")
      throw new Error(
        "Invalid validator: please make sure that the parameter of `defineTable` is valid (see https://docs.convex.dev/database/schemas)"
      );
    return {
      indexes: this.indexes,
      stagedDbIndexes: this.stagedDbIndexes,
      searchIndexes: this.searchIndexes,
      stagedSearchIndexes: this.stagedSearchIndexes,
      vectorIndexes: this.vectorIndexes,
      stagedVectorIndexes: this.stagedVectorIndexes,
      documentType: t
    };
  }
};
function re(e) {
  return je(e) ? new Oe(e) : new Oe(c.object(e));
}
n(re, "defineTable");
var rt = class {
  static {
    n(this, "SchemaDefinition");
  }
  /**
   * @internal
   */
  constructor(t, r) {
    $(this, "tables"), $(this, "strictTableNameTypes"), $(this, "schemaValidation"), this.tables = t, this.schemaValidation = r?.schemaValidation === void 0 ? !0 : r.schemaValidation;
  }
  /**
   * Export the contents of this definition.
   *
   * This is called internally by the Convex framework.
   * @internal
   */
  export() {
    return JSON.stringify({
      tables: Object.entries(this.tables).map(([t, r]) => {
        let {
          indexes: o,
          stagedDbIndexes: s,
          searchIndexes: i,
          stagedSearchIndexes: a,
          vectorIndexes: p,
          stagedVectorIndexes: m,
          documentType: S
        } = r.export();
        return {
          tableName: t,
          indexes: o,
          stagedDbIndexes: s,
          searchIndexes: i,
          stagedSearchIndexes: a,
          vectorIndexes: p,
          stagedVectorIndexes: m,
          documentType: S
        };
      }),
      schemaValidation: this.schemaValidation
    });
  }
};
function _e(e, t) {
  return new rt(e, t);
}
n(_e, "defineSchema");
var Ls = _e({
  _scheduled_functions: re({
    name: c.string(),
    args: c.array(c.any()),
    scheduledTime: c.float64(),
    completedTime: c.optional(c.float64()),
    state: c.union(
      c.object({ kind: c.literal("pending") }),
      c.object({ kind: c.literal("inProgress") }),
      c.object({ kind: c.literal("success") }),
      c.object({ kind: c.literal("failed"), error: c.string() }),
      c.object({ kind: c.literal("canceled") })
    )
  }),
  _storage: re({
    sha256: c.string(),
    size: c.float64(),
    contentType: c.optional(c.string())
  })
});

// memory/profile.mjs
var q = class {
  static {
    n(this, "SecretText");
  }
  constructor(t) {
    this.value = t;
  }
  toWire() {
    return this.value;
  }
}, nt = {
  seq: 1,
  at: 17e11,
  secret: "capacity",
  payload: "tiny"
};
function Dt(e) {
  let t = e.kind === "native", r = e.kind === "full" || e.kind === "mini", o = t ? e.v : e.s;
  return /* @__PURE__ */ n(function({ count: i, width: a, profile: p, entries: m = 0 }) {
    if (!Number.isInteger(i) || i < 0 || !Number.isInteger(a) || a < 1 || !Number.isInteger(m) || m < 0 || !["fields-only", "codec-rich"].includes(p))
      throw new Error("Invalid graph fixture arguments");
    let S = {
      schemaConstructors: 0,
      fields: 0,
      codecSites: 0,
      allocatedCodecs: 0
    }, f = /* @__PURE__ */ n((u, ...h) => (S.schemaConstructors++, o[u](...h)), "make"), D = /* @__PURE__ */ n((u) => (S.fields += Object.keys(u).length, f("object", u)), "object"), G = /* @__PURE__ */ n(() => (S.codecSites++, t ? f("number") : (S.allocatedCodecs++, f("codec", f("number"), f("date"), {
      decode: /* @__PURE__ */ n((u) => new Date(u), "decode"),
      encode: /* @__PURE__ */ n((u) => u.getTime(), "encode")
    }))), "date"), st = /* @__PURE__ */ n(() => (S.codecSites++, t ? f("string") : (S.allocatedCodecs++, f("codec", f("string"), f("instanceof", q), {
      decode: /* @__PURE__ */ n((u) => new q(u), "decode"),
      encode: /* @__PURE__ */ n((u) => u.toWire(), "encode")
    }))), "secret"), Ht = /* @__PURE__ */ n((u) => {
      if (p === "fields-only")
        switch (u % 4) {
          case 0:
            return f("string");
          case 1:
            return f("number");
          case 2:
            return f("boolean");
          case 3:
            return f("optional", f("string"));
        }
      switch (u % 4) {
        case 0:
          return G();
        case 1:
          return st();
        case 2:
          return D({ at: G(), tag: f("optional", f("string")) });
        case 3:
          return f(
            "array",
            t ? f("union", f("string"), f("number")) : f("union", [f("string"), f("number")])
          );
      }
    }, "field"), N = {}, _ = {}, it = /* @__PURE__ */ n((u, h) => {
      r ? (S.fields += Object.keys(h).length, N[u] = e.defineZodModel(u, h, e.schemaHelpers ? void 0 : { schemaHelpers: !1 })) : (_[u] = D(h), N[u] = t ? e.defineTable(_[u]) : _[u]);
    }, "add");
    it("benchmarkRows", {
      seq: f("number"),
      at: G(),
      secret: st(),
      payload: f("string")
    });
    for (let u = 0; u < i; u++) {
      let h = {};
      for (let A = 0; A < a; A++) h[`f${A}`] = Ht(A);
      it(`unused${u}`, h);
    }
    let H = r ? e.defineZodSchema(N) : t ? e.defineSchema(N) : null;
    if (r) for (let u of Object.keys(N)) _[u] = H.__zodTableMap[u].insert;
    let at = Object.keys(N), ne = {};
    for (let u = 0; u < m; u++) {
      let h = at[u % at.length], A = r ? H.__zodTableMap[h].doc : _[h], Qt = D({
        id: f("string"),
        label: f("optional", f("string"))
      }), zt = t ? f("union", A, f("null")) : f("nullable", A);
      ne[`unused/fn${u}`] = { args: Qt, returns: zt };
    }
    let ct = r ? e.initZodvex(
      H,
      e.server,
      m ? { registry: /* @__PURE__ */ n(() => ne, "registry") } : void 0
    ) : e.makeBuilders();
    return {
      kind: e.kind,
      options: { count: i, width: a, profile: p, entries: m },
      models: N,
      sourceSchemas: _,
      schema: H,
      registry: ne,
      builders: ct,
      manifest: {
        backgroundModels: i,
        totalModels: i + 1,
        backgroundTopLevelFields: i * a,
        fixedProbeFields: 4,
        profile: p,
        registryEntries: m,
        ...S,
        counterScope: "Explicit fixture constructor calls and source fields/codecs; excludes library-generated helper schemas and runtime heap objects."
      },
      operation() {
        let u = { ...nt }, h = t ? {
          ...u,
          at: new Date(u.at),
          secret: new q(u.secret)
        } : e.s.parse(_.benchmarkRows, u);
        if (!(h.at instanceof Date) || !(h.secret instanceof q))
          throw new Error("Codec decode failed");
        h.at = new Date(h.at.getTime() + 1e3), h.secret = new q(h.secret.toWire().toUpperCase());
        let A = t ? {
          ...h,
          at: h.at.getTime(),
          secret: h.secret.toWire()
        } : e.s.encode(_.benchmarkRows, h);
        if (JSON.stringify(A) !== JSON.stringify({
          ...nt,
          at: nt.at + 1e3,
          secret: "CAPACITY"
        }))
          throw new Error("Codec round trip mismatch");
        return A;
      },
      // Call after the operation and after GC measurements. The retained graph
      // includes every model, table schema, registry entry and builder closure.
      checksum() {
        let u = 0;
        for (let [h, A] of Object.entries(N)) {
          if (!A || !_[h]) throw new Error("Missing model");
          if (u += h.length, r && H.__zodTableMap[h].insert !== _[h])
            throw new Error("Lost table-map alias");
        }
        for (let [h, A] of Object.entries(ne)) {
          if (!A.args || !A.returns)
            throw new Error("Missing registry schema");
          u += h.length;
        }
        if (Object.keys(ct).length === 0)
          throw new Error("Lost builders");
        return u;
      }
    };
  }, "buildGraph");
}
n(Dt, "createGraphFactory");

// graphProbe.ts
var Gt = { query: Ze, mutation: Ye, action: et, internalQuery: Ke, internalMutation: Xe, internalAction: tt }, Gr = { kind: "native", schemaHelpers: !1, server: Gt, v: c, defineTable: re, defineSchema: _e, makeBuilders: /* @__PURE__ */ n(() => Gt, "makeBuilders") }, Hr = Dt(Gr), Qr = { count: 16, width: 32, profile: "codec-rich", entries: 0 }, ot = Hr(Qr), Ai = Dr({ args: {}, returns: c.object({ checksum: c.number(), output: c.object({ seq: c.number(), at: c.number(), secret: c.string(), payload: c.string() }), manifest: c.any(), nonce: c.string() }), handler: /* @__PURE__ */ n(() => {
  let e = ot.operation();
  return globalThis.gc(), globalThis.gc(), { checksum: ot.checksum(), output: e, manifest: ot.manifest, nonce: "1c3bc935-1642-4f9c-a181-e4e19a4b4dc4" };
}, "handler") });
export {
  Ai as default
};
