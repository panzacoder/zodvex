var Ao = Object.defineProperty;
var s = (e, t) => Ao(e, "name", { value: t, configurable: !0 });
var bu = (e, t) => {
  for (var r in t)
    Ao(e, r, { get: t[r], enumerable: !0 });
};

// graphProbe.ts
import { query as Pf } from "convex:/_system/repl/wrappers.js";

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/base64.js
var re = [], Y = [], xu = Uint8Array, Er = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
for (me = 0, To = Er.length; me < To; ++me)
  re[me] = Er[me], Y[Er.charCodeAt(me)] = me;
var me, To;
Y[45] = 62;
Y[95] = 63;
function wu(e) {
  var t = e.length;
  if (t % 4 > 0)
    throw new Error("Invalid string. Length must be a multiple of 4");
  var r = e.indexOf("=");
  r === -1 && (r = t);
  var n = r === t ? 0 : 4 - r % 4;
  return [r, n];
}
s(wu, "getLens");
function vu(e, t, r) {
  return (t + r) * 3 / 4 - r;
}
s(vu, "_byteLength");
function Fe(e) {
  var t, r = wu(e), n = r[0], o = r[1], i = new xu(vu(e, n, o)), c = 0, a = o > 0 ? n - 4 : n, u;
  for (u = 0; u < a; u += 4)
    t = Y[e.charCodeAt(u)] << 18 | Y[e.charCodeAt(u + 1)] << 12 | Y[e.charCodeAt(u + 2)] << 6 | Y[e.charCodeAt(u + 3)], i[c++] = t >> 16 & 255, i[c++] = t >> 8 & 255, i[c++] = t & 255;
  return o === 2 && (t = Y[e.charCodeAt(u)] << 2 | Y[e.charCodeAt(u + 1)] >> 4, i[c++] = t & 255), o === 1 && (t = Y[e.charCodeAt(u)] << 10 | Y[e.charCodeAt(u + 1)] << 4 | Y[e.charCodeAt(u + 2)] >> 2, i[c++] = t >> 8 & 255, i[c++] = t & 255), i;
}
s(Fe, "toByteArray");
function zu(e) {
  return re[e >> 18 & 63] + re[e >> 12 & 63] + re[e >> 6 & 63] + re[e & 63];
}
s(zu, "tripletToBase64");
function $u(e, t, r) {
  for (var n, o = [], i = t; i < r; i += 3)
    n = (e[i] << 16 & 16711680) + (e[i + 1] << 8 & 65280) + (e[i + 2] & 255), o.push(zu(n));
  return o.join("");
}
s($u, "encodeChunk");
function Le(e) {
  for (var t, r = e.length, n = r % 3, o = [], i = 16383, c = 0, a = r - n; c < a; c += i)
    o.push(
      $u(
        e,
        c,
        c + i > a ? a : c + i
      )
    );
  return n === 1 ? (t = e[r - 1], o.push(re[t >> 2] + re[t << 4 & 63] + "==")) : n === 2 && (t = (e[r - 2] << 8) + e[r - 1], o.push(
    re[t >> 10] + re[t >> 4 & 63] + re[t << 2 & 63] + "="
  )), o.join("");
}
s(Le, "fromByteArray");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/common/index.js
function ae(e) {
  if (e === void 0)
    return {};
  if (!yt(e))
    throw new Error(
      `The arguments to a Convex function must be an object. Received: ${e}`
    );
  return e;
}
s(ae, "parseArgs");
function yt(e) {
  let t = typeof e == "object", r = Object.getPrototypeOf(e), n = r === null || r === Object.prototype || // Objects generated from other contexts (e.g. across Node.js `vm` modules) will not satisfy the previous
  // conditions but are still simple objects.
  r?.constructor?.name === "Object";
  return t && n;
}
s(yt, "isSimpleObject");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/value.js
var Ro = !0, be = BigInt("-9223372036854775808"), Nr = BigInt("9223372036854775807"), Tr = BigInt("0"), ku = BigInt("8"), Su = BigInt("256");
function Fo(e) {
  return Number.isNaN(e) || !Number.isFinite(e) || Object.is(e, -0);
}
s(Fo, "isSpecial");
function Ou(e) {
  e < Tr && (e -= be + be);
  let t = e.toString(16);
  t.length % 2 === 1 && (t = "0" + t);
  let r = new Uint8Array(new ArrayBuffer(8)), n = 0;
  for (let o of t.match(/.{2}/g).reverse())
    r.set([parseInt(o, 16)], n++), e >>= ku;
  return Le(r);
}
s(Ou, "slowBigIntToBase64");
function Pu(e) {
  let t = Fe(e);
  if (t.byteLength !== 8)
    throw new Error(
      `Received ${t.byteLength} bytes, expected 8 for $integer`
    );
  let r = Tr, n = Tr;
  for (let o of t)
    r += BigInt(o) * Su ** n, n++;
  return r > Nr && (r += be + be), r;
}
s(Pu, "slowBase64ToBigInt");
function Zu(e) {
  if (e < be || Nr < e)
    throw new Error(
      `BigInt ${e} does not fit into a 64-bit signed integer.`
    );
  let t = new ArrayBuffer(8);
  return new DataView(t).setBigInt64(0, e, !0), Le(new Uint8Array(t));
}
s(Zu, "modernBigIntToBase64");
function Iu(e) {
  let t = Fe(e);
  if (t.byteLength !== 8)
    throw new Error(
      `Received ${t.byteLength} bytes, expected 8 for $integer`
    );
  return new DataView(t.buffer).getBigInt64(0, !0);
}
s(Iu, "modernBase64ToBigInt");
var Eu = DataView.prototype.setBigInt64 ? Zu : Ou, Au = DataView.prototype.getBigInt64 ? Iu : Pu, No = 1024;
function Cr(e) {
  if (e.length > No)
    throw new Error(
      `Field name ${e} exceeds maximum field name length ${No}.`
    );
  if (e.startsWith("$"))
    throw new Error(`Field name ${e} starts with a '$', which is reserved.`);
  for (let t = 0; t < e.length; t += 1) {
    let r = e.charCodeAt(t);
    if (r < 32 || r >= 127)
      throw new Error(
        `Field name ${e} has invalid character '${e[t]}': Field names can only contain non-control ASCII characters`
      );
  }
}
s(Cr, "validateObjectField");
function C(e) {
  if (e === null || typeof e == "boolean" || typeof e == "number" || typeof e == "string")
    return e;
  if (Array.isArray(e))
    return e.map((n) => C(n));
  if (typeof e != "object")
    throw new Error(`Unexpected type of ${e}`);
  let t = Object.entries(e);
  if (t.length === 1) {
    let n = t[0][0];
    if (n === "$bytes") {
      if (typeof e.$bytes != "string")
        throw new Error(`Malformed $bytes field on ${e}`);
      return Fe(e.$bytes).buffer;
    }
    if (n === "$integer") {
      if (typeof e.$integer != "string")
        throw new Error(`Malformed $integer field on ${e}`);
      return Au(e.$integer);
    }
    if (n === "$float") {
      if (typeof e.$float != "string")
        throw new Error(`Malformed $float field on ${e}`);
      let o = Fe(e.$float);
      if (o.byteLength !== 8)
        throw new Error(
          `Received ${o.byteLength} bytes, expected 8 for $float`
        );
      let c = new DataView(o.buffer).getFloat64(0, Ro);
      if (!Fo(c))
        throw new Error(`Float ${c} should be encoded as a number`);
      return c;
    }
    if (n === "$set")
      throw new Error(
        "Received a Set which is no longer supported as a Convex type."
      );
    if (n === "$map")
      throw new Error(
        "Received a Map which is no longer supported as a Convex type."
      );
  }
  let r = {};
  for (let [n, o] of Object.entries(e))
    Cr(n), r[n] = C(o);
  return r;
}
s(C, "jsonToConvex");
var jo = 16384;
function he(e) {
  let t = JSON.stringify(e, (r, n) => n === void 0 ? "undefined" : typeof n == "bigint" ? `${n.toString()}n` : n);
  if (t.length > jo) {
    let r = "[...truncated]", n = jo - r.length, o = t.codePointAt(n - 1);
    return o !== void 0 && o > 65535 && (n -= 1), t.substring(0, n) + r;
  }
  return t;
}
s(he, "stringifyValueForError");
function De(e, t, r, n) {
  if (e === void 0) {
    let c = r && ` (present at path ${r} in original object ${he(
      t
    )})`;
    throw new Error(
      `undefined is not a valid Convex value${c}. To learn about Convex's supported types, see https://docs.convex.dev/using/types.`
    );
  }
  if (e === null)
    return e;
  if (typeof e == "bigint") {
    if (e < be || Nr < e)
      throw new Error(
        `BigInt ${e} does not fit into a 64-bit signed integer.`
      );
    return { $integer: Eu(e) };
  }
  if (typeof e == "number")
    if (Fo(e)) {
      let c = new ArrayBuffer(8);
      return new DataView(c).setFloat64(0, e, Ro), { $float: Le(new Uint8Array(c)) };
    } else
      return e;
  if (typeof e == "boolean" || typeof e == "string")
    return e;
  if (e instanceof ArrayBuffer)
    return { $bytes: Le(new Uint8Array(e)) };
  if (Array.isArray(e))
    return e.map(
      (c, a) => De(c, t, r + `[${a}]`, !1)
    );
  if (e instanceof Set)
    throw new Error(
      Ar(r, "Set", [...e], t)
    );
  if (e instanceof Map)
    throw new Error(
      Ar(r, "Map", [...e], t)
    );
  if (!yt(e)) {
    let c = e?.constructor?.name, a = c ? `${c} ` : "";
    throw new Error(
      Ar(r, a, e, t)
    );
  }
  let o = {}, i = Object.entries(e);
  i.sort(([c, a], [u, l]) => c === u ? 0 : c < u ? -1 : 1);
  for (let [c, a] of i)
    a !== void 0 ? (Cr(c), o[c] = De(a, t, r + `.${c}`, !1)) : n && (Cr(c), o[c] = Lo(
      a,
      t,
      r + `.${c}`
    ));
  return o;
}
s(De, "convexToJsonInternal");
function Ar(e, t, r, n) {
  return e ? `${t}${he(
    r
  )} is not a supported Convex type (present at path ${e} in original object ${he(
    n
  )}). To learn about Convex's supported types, see https://docs.convex.dev/using/types.` : `${t}${he(
    r
  )} is not a supported Convex type.`;
}
s(Ar, "errorMessageForUnsupportedType");
function Lo(e, t, r) {
  if (e === void 0)
    return { $undefined: null };
  if (t === void 0)
    throw new Error(
      `Programming error. Current value is ${he(
        e
      )} but original value is undefined`
    );
  return De(e, t, r, !1);
}
s(Lo, "convexOrUndefinedToJsonInternal");
function Z(e) {
  return De(e, e, "", !1);
}
s(Z, "convexToJson");
function X(e) {
  return Lo(e, e, "");
}
s(X, "convexOrUndefinedToJson");
function Do(e) {
  return De(e, e, "", !0);
}
s(Do, "patchValueToJson");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/validators.js
var Tu = Object.defineProperty, Cu = /* @__PURE__ */ s((e, t, r) => t in e ? Tu(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), E = /* @__PURE__ */ s((e, t, r) => Cu(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), Nu = "https://docs.convex.dev/error#undefined-validator";
function Me(e, t) {
  let r = t !== void 0 ? ` for field "${t}"` : "";
  throw new Error(
    `A validator is undefined${r} in ${e}. This is often caused by circular imports. See ${Nu} for details.`
  );
}
s(Me, "throwUndefinedValidatorError");
var V = class {
  static {
    s(this, "BaseValidator");
  }
  constructor({ isOptional: t }) {
    E(this, "type"), E(this, "fieldPaths"), E(this, "isOptional"), E(this, "isConvexValidator"), this.isOptional = t, this.isConvexValidator = !0;
  }
}, _t = class e extends V {
  static {
    s(this, "VId");
  }
  /**
   * Usually you'd use `v.id(tableName)` instead.
   */
  constructor({
    isOptional: t,
    tableName: r
  }) {
    if (super({ isOptional: t }), E(this, "tableName"), E(this, "kind", "id"), typeof r != "string")
      throw new Error("v.id(tableName) requires a string");
    this.tableName = r;
  }
  /** @internal */
  get json() {
    return { type: "id", tableName: this.tableName };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      tableName: this.tableName
    });
  }
}, Ue = class e extends V {
  static {
    s(this, "VFloat64");
  }
  constructor() {
    super(...arguments), E(this, "kind", "float64");
  }
  /** @internal */
  get json() {
    return { type: "number" };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, Be = class e extends V {
  static {
    s(this, "VInt64");
  }
  constructor() {
    super(...arguments), E(this, "kind", "int64");
  }
  /** @internal */
  get json() {
    return { type: "bigint" };
  }
  /** @internal */
  asOptional() {
    return new e({ isOptional: "optional" });
  }
}, bt = class e extends V {
  static {
    s(this, "VBoolean");
  }
  constructor() {
    super(...arguments), E(this, "kind", "boolean");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, xt = class e extends V {
  static {
    s(this, "VBytes");
  }
  constructor() {
    super(...arguments), E(this, "kind", "bytes");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({ isOptional: "optional" });
  }
}, wt = class e extends V {
  static {
    s(this, "VString");
  }
  constructor() {
    super(...arguments), E(this, "kind", "string");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, vt = class e extends V {
  static {
    s(this, "VNull");
  }
  constructor() {
    super(...arguments), E(this, "kind", "null");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({ isOptional: "optional" });
  }
}, zt = class e extends V {
  static {
    s(this, "VAny");
  }
  constructor() {
    super(...arguments), E(this, "kind", "any");
  }
  /** @internal */
  get json() {
    return {
      type: this.kind
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, $t = class e extends V {
  static {
    s(this, "VObject");
  }
  /**
   * Usually you'd use `v.object({ ... })` instead.
   */
  constructor({
    isOptional: t,
    fields: r
  }) {
    super({ isOptional: t }), E(this, "fields"), E(this, "kind", "object"), globalThis.Object.entries(r).forEach(([n, o]) => {
      if (o === void 0 && Me("v.object()", n), !o.isConvexValidator)
        throw new Error("v.object() entries must be validators");
    }), this.fields = r;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: globalThis.Object.fromEntries(
        globalThis.Object.entries(this.fields).map(([t, r]) => [
          t,
          {
            fieldType: r.json,
            optional: r.isOptional === "optional"
          }
        ])
      )
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      fields: this.fields
    });
  }
  /**
   * Create a new VObject with the specified fields omitted.
   * @param fields The field names to omit from this VObject.
   */
  omit(...t) {
    let r = { ...this.fields };
    for (let n of t)
      delete r[n];
    return new e({
      isOptional: this.isOptional,
      fields: r
    });
  }
  /**
   * Create a new VObject with only the specified fields.
   * @param fields The field names to pick from this VObject.
   */
  pick(...t) {
    let r = {};
    for (let n of t)
      r[n] = this.fields[n];
    return new e({
      isOptional: this.isOptional,
      fields: r
    });
  }
  /**
   * Create a new VObject with all fields marked as optional.
   */
  partial() {
    let t = {};
    for (let [r, n] of globalThis.Object.entries(this.fields))
      t[r] = n.asOptional();
    return new e({
      isOptional: this.isOptional,
      fields: t
    });
  }
  /**
   * Create a new VObject with additional fields merged in.
   * @param fields An object with additional validators to merge into this VObject.
   */
  extend(t) {
    return new e({
      isOptional: this.isOptional,
      fields: { ...this.fields, ...t }
    });
  }
}, kt = class e extends V {
  static {
    s(this, "VLiteral");
  }
  /**
   * Usually you'd use `v.literal(value)` instead.
   */
  constructor({ isOptional: t, value: r }) {
    if (super({ isOptional: t }), E(this, "value"), E(this, "kind", "literal"), typeof r != "string" && typeof r != "boolean" && typeof r != "number" && typeof r != "bigint")
      throw new Error("v.literal(value) must be a string, number, or boolean");
    this.value = r;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: Z(this.value)
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      value: this.value
    });
  }
}, St = class e extends V {
  static {
    s(this, "VArray");
  }
  /**
   * Usually you'd use `v.array(element)` instead.
   */
  constructor({
    isOptional: t,
    element: r
  }) {
    super({ isOptional: t }), E(this, "element"), E(this, "kind", "array"), r === void 0 && Me("v.array()"), this.element = r;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: this.element.json
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      element: this.element
    });
  }
}, Ot = class e extends V {
  static {
    s(this, "VRecord");
  }
  /**
   * Usually you'd use `v.record(key, value)` instead.
   */
  constructor({
    isOptional: t,
    key: r,
    value: n
  }) {
    if (super({ isOptional: t }), E(this, "key"), E(this, "value"), E(this, "kind", "record"), r === void 0 && Me("v.record()", "key"), n === void 0 && Me("v.record()", "value"), r.isOptional === "optional")
      throw new Error("Record validator cannot have optional keys");
    if (n.isOptional === "optional")
      throw new Error("Record validator cannot have optional values");
    if (!r.isConvexValidator || !n.isConvexValidator)
      throw new Error("Key and value of v.record() but be validators");
    this.key = r, this.value = n;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      // This cast is needed because TypeScript thinks the key type is too wide
      keys: this.key.json,
      values: {
        fieldType: this.value.json,
        optional: !1
      }
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      key: this.key,
      value: this.value
    });
  }
}, Pt = class e extends V {
  static {
    s(this, "VUnion");
  }
  /**
   * Usually you'd use `v.union(...members)` instead.
   */
  constructor({ isOptional: t, members: r }) {
    super({ isOptional: t }), E(this, "members"), E(this, "kind", "union"), r.forEach((n, o) => {
      if (n === void 0 && Me("v.union()", `member at index ${o}`), !n.isConvexValidator)
        throw new Error("All members of v.union() must be validators");
    }), this.members = r;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: this.members.map((t) => t.json)
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      members: this.members
    });
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/validator.js
function jr(e) {
  return !!e.isConvexValidator;
}
s(jr, "isValidator");
function xe(e) {
  return jr(e) ? e : d.object(e);
}
s(xe, "asObjectValidator");
var d = {
  /**
   * Validates that the value is a document ID for the given table.
   *
   * IDs are strings at runtime but are typed as `Id<"tableName">` in
   * TypeScript for type safety.
   *
   * @example
   * ```typescript
   * args: { userId: v.id("users") }
   * ```
   *
   * @param tableName The name of the table.
   */
  id: /* @__PURE__ */ s((e) => new _t({
    isOptional: "required",
    tableName: e
  }), "id"),
  /**
   * Validates that the value is `null`.
   *
   * Use `returns: v.null()` for functions that don't return a meaningful value.
   * JavaScript `undefined` is not a valid Convex value, it is automatically
   * converted to `null`.
   */
  null: /* @__PURE__ */ s(() => new vt({ isOptional: "required" }), "null"),
  /**
   * Validates that the value is a JavaScript `number` (Convex Float64).
   *
   * Supports all IEEE-754 double-precision floating point numbers including
   * NaN and Infinity.
   *
   * Alias for `v.float64()`.
   */
  number: /* @__PURE__ */ s(() => new Ue({ isOptional: "required" }), "number"),
  /**
   * Validates that the value is a JavaScript `number` (Convex Float64).
   *
   * Supports all IEEE-754 double-precision floating point numbers.
   */
  float64: /* @__PURE__ */ s(() => new Ue({ isOptional: "required" }), "float64"),
  /**
   * @deprecated Use `v.int64()` instead.
   */
  bigint: /* @__PURE__ */ s(() => new Be({ isOptional: "required" }), "bigint"),
  /**
   * Validates that the value is a JavaScript `bigint` (Convex Int64).
   *
   * Supports BigInts between -2^63 and 2^63-1.
   *
   * @example
   * ```typescript
   * args: { timestamp: v.int64() }
   * // Usage: createDoc({ timestamp: 1234567890n })
   * ```
   */
  int64: /* @__PURE__ */ s(() => new Be({ isOptional: "required" }), "int64"),
  /**
   * Validates that the value is a `boolean`.
   */
  boolean: /* @__PURE__ */ s(() => new bt({ isOptional: "required" }), "boolean"),
  /**
   * Validates that the value is a `string`.
   *
   * Strings are stored as UTF-8 and their storage size is calculated as their
   * UTF-8 encoded size.
   */
  string: /* @__PURE__ */ s(() => new wt({ isOptional: "required" }), "string"),
  /**
   * Validates that the value is an `ArrayBuffer` (Convex Bytes).
   *
   * Use for binary data.
   */
  bytes: /* @__PURE__ */ s(() => new xt({ isOptional: "required" }), "bytes"),
  /**
   * Validates that the value is exactly equal to the given literal.
   *
   * Useful for discriminated unions and enum-like patterns.
   *
   * @example
   * ```typescript
   * // Discriminated union pattern:
   * v.union(
   *   v.object({ kind: v.literal("error"), message: v.string() }),
   *   v.object({ kind: v.literal("success"), value: v.number() }),
   * )
   * ```
   *
   * @param literal The literal value to compare against.
   */
  literal: /* @__PURE__ */ s((e) => new kt({ isOptional: "required", value: e }), "literal"),
  /**
   * Validates that the value is an `Array` where every element matches the
   * given validator.
   *
   * Arrays can have at most 8192 elements.
   *
   * @example
   * ```typescript
   * args: { tags: v.array(v.string()) }
   * args: { coordinates: v.array(v.number()) }
   * args: { items: v.array(v.object({ name: v.string(), qty: v.number() })) }
   * ```
   *
   * @param element The validator for the elements of the array.
   */
  array: /* @__PURE__ */ s((e) => new St({ isOptional: "required", element: e }), "array"),
  /**
   * Validates that the value is an `Object` with the specified properties.
   *
   * Objects can have at most 1024 entries. Field names must be non-empty and
   * must not start with `"$"` or `"_"` (`_` is reserved for system fields
   * like `_id` and `_creationTime`; `$` is reserved for Convex internal use).
   *
   * @example
   * ```typescript
   * args: {
   *   user: v.object({
   *     name: v.string(),
   *     email: v.string(),
   *     age: v.optional(v.number()),
   *   })
   * }
   * ```
   *
   * @param fields An object mapping property names to their validators.
   */
  object: /* @__PURE__ */ s((e) => new $t({ isOptional: "required", fields: e }), "object"),
  /**
   * Validates that the value is a `Record` (object with dynamic keys).
   *
   * Records are objects at runtime but allow dynamic keys, unlike `v.object()`
   * which requires known property names. Keys must be ASCII characters only,
   * non-empty, and not start with `"$"` or `"_"`.
   *
   * @example
   * ```typescript
   * // Map of user IDs to scores:
   * args: { scores: v.record(v.id("users"), v.number()) }
   *
   * // Map of string keys to string values:
   * args: { metadata: v.record(v.string(), v.string()) }
   * ```
   *
   * @param keys The validator for the keys of the record.
   * @param values The validator for the values of the record.
   */
  record: /* @__PURE__ */ s((e, t) => new Ot({
    isOptional: "required",
    key: e,
    value: t
  }), "record"),
  /**
   * Validates that the value matches at least one of the given validators.
   *
   * @example
   * ```typescript
   * // Allow string or number:
   * args: { value: v.union(v.string(), v.number()) }
   *
   * // Discriminated union (recommended pattern):
   * v.union(
   *   v.object({ kind: v.literal("text"), body: v.string() }),
   *   v.object({ kind: v.literal("image"), url: v.string() }),
   * )
   *
   * // Nullable value:
   * returns: v.union(v.object({ ... }), v.null())
   * ```
   *
   * @param members The validators to match against.
   */
  union: /* @__PURE__ */ s((...e) => new Pt({
    isOptional: "required",
    members: e
  }), "union"),
  /**
   * A validator that accepts any Convex value without validation.
   *
   * Prefer using specific validators when possible for better type safety
   * and runtime validation.
   */
  any: /* @__PURE__ */ s(() => new zt({ isOptional: "required" }), "any"),
  /**
   * Makes a property optional in an object validator.
   *
   * An optional property can be omitted entirely when creating a document or
   * calling a function. This is different from `v.nullable()` which requires
   * the property to be present but allows `null`.
   *
   * @example
   * ```typescript
   * v.object({
   *   name: v.string(),              // required
   *   nickname: v.optional(v.string()), // can be omitted
   * })
   *
   * // Valid: { name: "Alice" }
   * // Valid: { name: "Alice", nickname: "Ali" }
   * // Invalid: { name: "Alice", nickname: null }  - use v.nullable() for this
   * ```
   *
   * @param value The property value validator to make optional.
   */
  optional: /* @__PURE__ */ s((e) => e.asOptional(), "optional"),
  /**
   * Allows a value to be either the given type or `null`.
   *
   * This is shorthand for `v.union(value, v.null())`. Unlike `v.optional()`,
   * the property must still be present, but may be `null`.
   *
   * @example
   * ```typescript
   * v.object({
   *   name: v.string(),
   *   deletedAt: v.nullable(v.number()), // must be present, can be null
   * })
   *
   * // Valid: { name: "Alice", deletedAt: null }
   * // Valid: { name: "Alice", deletedAt: 1234567890 }
   * // Invalid: { name: "Alice" }  - deletedAt is required
   * ```
   */
  nullable: /* @__PURE__ */ s((e) => d.union(e, d.null()), "nullable")
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/errors.js
var ju = Object.defineProperty, Ru = /* @__PURE__ */ s((e, t, r) => t in e ? ju(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), Rr = /* @__PURE__ */ s((e, t, r) => Ru(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), Mo, Uo, Fu = Symbol.for("ConvexError"), we = class extends (Uo = Error, Mo = Fu, Uo) {
  static {
    s(this, "ConvexError");
  }
  constructor(t) {
    super(typeof t == "string" ? t : he(t)), Rr(this, "name", "ConvexError"), Rr(this, "data"), Rr(this, Mo, !0), this.data = t;
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/compare_utf8.js
var Bo = /* @__PURE__ */ s(() => Array.from({ length: 4 }, () => 0), "arr"), Gf = Bo(), Kf = Bo();

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/index.js
var F = "1.32.0";

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/syscall.js
function Je(e, t) {
  if (typeof Convex > "u" || Convex.syscall === void 0)
    throw new Error(
      "The Convex database and auth objects are being used outside of a Convex backend. Did you mean to use `useQuery` or `useMutation` to call a Convex function?"
    );
  let r = Convex.syscall(e, JSON.stringify(t));
  return JSON.parse(r);
}
s(Je, "performSyscall");
async function O(e, t) {
  if (typeof Convex > "u" || Convex.asyncSyscall === void 0)
    throw new Error(
      "The Convex database and auth objects are being used outside of a Convex backend. Did you mean to use `useQuery` or `useMutation` to call a Convex function?"
    );
  let r;
  try {
    r = await Convex.asyncSyscall(e, JSON.stringify(t));
  } catch (n) {
    if (n.data !== void 0) {
      let o = new we(n.message);
      throw o.data = C(n.data), o;
    }
    throw new Error(n.message);
  }
  return JSON.parse(r);
}
s(O, "performAsyncSyscall");
function Zt(e, t) {
  if (typeof Convex > "u" || Convex.jsSyscall === void 0)
    throw new Error(
      "The Convex database and auth objects are being used outside of a Convex backend. Did you mean to use `useQuery` or `useMutation` to call a Convex function?"
    );
  return Convex.jsSyscall(e, t);
}
s(Zt, "performJsSyscall");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/functionName.js
var Ve = Symbol.for("functionName");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/components/paths.js
var Jo = Symbol.for("toReferencePath");
function Lu(e) {
  return e[Jo] ?? null;
}
s(Lu, "extractReferencePath");
function Du(e) {
  return e.startsWith("function://");
}
s(Du, "isFunctionHandle");
function ee(e) {
  let t;
  if (typeof e == "string")
    Du(e) ? t = { functionHandle: e } : t = { name: e };
  else if (e[Ve])
    t = { name: e[Ve] };
  else {
    let r = Lu(e);
    if (!r)
      throw new Error(`${e} is not a functionReference`);
    t = { reference: r };
  }
  return t;
}
s(ee, "getFunctionAddress");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/actions_impl.js
function Fr(e, t, r) {
  return {
    ...ee(t),
    args: Z(ae(r)),
    version: F,
    requestId: e
  };
}
s(Fr, "syscallArgs");
function Vo(e) {
  return {
    runQuery: /* @__PURE__ */ s(async (t, r) => {
      let n = await O(
        "1.0/actions/query",
        Fr(e, t, r)
      );
      return C(n);
    }, "runQuery"),
    runMutation: /* @__PURE__ */ s(async (t, r) => {
      let n = await O(
        "1.0/actions/mutation",
        Fr(e, t, r)
      );
      return C(n);
    }, "runMutation"),
    runAction: /* @__PURE__ */ s(async (t, r) => {
      let n = await O(
        "1.0/actions/action",
        Fr(e, t, r)
      );
      return C(n);
    }, "runAction")
  };
}
s(Vo, "setupActionCalls");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/vector_search.js
var Mu = Object.defineProperty, Uu = /* @__PURE__ */ s((e, t, r) => t in e ? Mu(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), qo = /* @__PURE__ */ s((e, t, r) => Uu(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), It = class {
  static {
    s(this, "FilterExpression");
  }
  /**
   * @internal
   */
  constructor() {
    qo(this, "_isExpression"), qo(this, "_value");
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/validate.js
function S(e, t, r, n) {
  if (e === void 0)
    throw new TypeError(
      `Must provide arg ${t} \`${n}\` to \`${r}\``
    );
}
s(S, "validateArg");
function Wo(e, t, r, n) {
  if (!Number.isInteger(e) || e < 0)
    throw new TypeError(
      `Arg ${t} \`${n}\` to \`${r}\` must be a non-negative integer`
    );
}
s(Wo, "validateArgIsNonNegativeInteger");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/vector_search_impl.js
var Bu = Object.defineProperty, Ju = /* @__PURE__ */ s((e, t, r) => t in e ? Bu(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), Lr = /* @__PURE__ */ s((e, t, r) => Ju(e, typeof t != "symbol" ? t + "" : t, r), "__publicField");
function Go(e) {
  return async (t, r, n) => {
    if (S(t, 1, "vectorSearch", "tableName"), S(r, 2, "vectorSearch", "indexName"), S(n, 3, "vectorSearch", "query"), !n.vector || !Array.isArray(n.vector) || n.vector.length === 0)
      throw Error("`vector` must be a non-empty Array in vectorSearch");
    return await new Dr(
      e,
      t + "." + r,
      n
    ).collect();
  };
}
s(Go, "setupActionVectorSearch");
var Dr = class {
  static {
    s(this, "VectorQueryImpl");
  }
  constructor(t, r, n) {
    Lr(this, "requestId"), Lr(this, "state"), this.requestId = t;
    let o = n.filter ? Et(n.filter(Vu)) : null;
    this.state = {
      type: "preparing",
      query: {
        indexName: r,
        limit: n.limit,
        vector: n.vector,
        expressions: o
      }
    };
  }
  async collect() {
    if (this.state.type === "consumed")
      throw new Error("This query is closed and can't emit any more values.");
    let t = this.state.query;
    this.state = { type: "consumed" };
    let { results: r } = await O("1.0/actions/vectorSearch", {
      requestId: this.requestId,
      version: F,
      query: t
    });
    return r;
  }
}, ve = class extends It {
  static {
    s(this, "ExpressionImpl");
  }
  constructor(t) {
    super(), Lr(this, "inner"), this.inner = t;
  }
  serialize() {
    return this.inner;
  }
};
function Et(e) {
  return e instanceof ve ? e.serialize() : { $literal: X(e) };
}
s(Et, "serializeExpression");
var Vu = {
  //  Comparisons  /////////////////////////////////////////////////////////////
  eq(e, t) {
    if (typeof e != "string")
      throw new Error("The first argument to `q.eq` must be a field name.");
    return new ve({
      $eq: [
        Et(new ve({ $field: e })),
        Et(t)
      ]
    });
  },
  //  Logic  ///////////////////////////////////////////////////////////////////
  or(...e) {
    return new ve({ $or: e.map(Et) });
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/authentication_impl.js
function At(e) {
  return {
    getUserIdentity: /* @__PURE__ */ s(async () => await O("1.0/getUserIdentity", {
      requestId: e
    }), "getUserIdentity")
  };
}
s(At, "setupAuth");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/filter_builder.js
var qu = Object.defineProperty, Wu = /* @__PURE__ */ s((e, t, r) => t in e ? qu(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), Ko = /* @__PURE__ */ s((e, t, r) => Wu(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), Tt = class {
  static {
    s(this, "Expression");
  }
  /**
   * @internal
   */
  constructor() {
    Ko(this, "_isExpression"), Ko(this, "_value");
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/filter_builder_impl.js
var Gu = Object.defineProperty, Ku = /* @__PURE__ */ s((e, t, r) => t in e ? Gu(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), Hu = /* @__PURE__ */ s((e, t, r) => Ku(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), D = class extends Tt {
  static {
    s(this, "ExpressionImpl");
  }
  constructor(t) {
    super(), Hu(this, "inner"), this.inner = t;
  }
  serialize() {
    return this.inner;
  }
};
function P(e) {
  return e instanceof D ? e.serialize() : { $literal: X(e) };
}
s(P, "serializeExpression");
var Ho = {
  //  Comparisons  /////////////////////////////////////////////////////////////
  eq(e, t) {
    return new D({
      $eq: [P(e), P(t)]
    });
  },
  neq(e, t) {
    return new D({
      $neq: [P(e), P(t)]
    });
  },
  lt(e, t) {
    return new D({
      $lt: [P(e), P(t)]
    });
  },
  lte(e, t) {
    return new D({
      $lte: [P(e), P(t)]
    });
  },
  gt(e, t) {
    return new D({
      $gt: [P(e), P(t)]
    });
  },
  gte(e, t) {
    return new D({
      $gte: [P(e), P(t)]
    });
  },
  //  Arithmetic  //////////////////////////////////////////////////////////////
  add(e, t) {
    return new D({
      $add: [P(e), P(t)]
    });
  },
  sub(e, t) {
    return new D({
      $sub: [P(e), P(t)]
    });
  },
  mul(e, t) {
    return new D({
      $mul: [P(e), P(t)]
    });
  },
  div(e, t) {
    return new D({
      $div: [P(e), P(t)]
    });
  },
  mod(e, t) {
    return new D({
      $mod: [P(e), P(t)]
    });
  },
  neg(e) {
    return new D({ $neg: P(e) });
  },
  //  Logic  ///////////////////////////////////////////////////////////////////
  and(...e) {
    return new D({ $and: e.map(P) });
  },
  or(...e) {
    return new D({ $or: e.map(P) });
  },
  not(e) {
    return new D({ $not: P(e) });
  },
  //  Other  ///////////////////////////////////////////////////////////////////
  field(e) {
    return new D({ $field: e });
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/index_range_builder.js
var Qu = Object.defineProperty, Yu = /* @__PURE__ */ s((e, t, r) => t in e ? Qu(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), Xu = /* @__PURE__ */ s((e, t, r) => Yu(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), Ct = class {
  static {
    s(this, "IndexRange");
  }
  /**
   * @internal
   */
  constructor() {
    Xu(this, "_isIndexRange");
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/index_range_builder_impl.js
var el = Object.defineProperty, tl = /* @__PURE__ */ s((e, t, r) => t in e ? el(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), Qo = /* @__PURE__ */ s((e, t, r) => tl(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), Nt = class e extends Ct {
  static {
    s(this, "IndexRangeBuilderImpl");
  }
  constructor(t) {
    super(), Qo(this, "rangeExpressions"), Qo(this, "isConsumed"), this.rangeExpressions = t, this.isConsumed = !1;
  }
  static new() {
    return new e([]);
  }
  consume() {
    if (this.isConsumed)
      throw new Error(
        "IndexRangeBuilder has already been used! Chain your method calls like `q => q.eq(...).eq(...)`. See https://docs.convex.dev/using/indexes"
      );
    this.isConsumed = !0;
  }
  eq(t, r) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Eq",
        fieldPath: t,
        value: X(r)
      })
    );
  }
  gt(t, r) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Gt",
        fieldPath: t,
        value: X(r)
      })
    );
  }
  gte(t, r) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Gte",
        fieldPath: t,
        value: X(r)
      })
    );
  }
  lt(t, r) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Lt",
        fieldPath: t,
        value: X(r)
      })
    );
  }
  lte(t, r) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Lte",
        fieldPath: t,
        value: X(r)
      })
    );
  }
  export() {
    return this.consume(), this.rangeExpressions;
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/search_filter_builder.js
var rl = Object.defineProperty, nl = /* @__PURE__ */ s((e, t, r) => t in e ? rl(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), ol = /* @__PURE__ */ s((e, t, r) => nl(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), jt = class {
  static {
    s(this, "SearchFilter");
  }
  /**
   * @internal
   */
  constructor() {
    ol(this, "_isSearchFilter");
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/search_filter_builder_impl.js
var sl = Object.defineProperty, il = /* @__PURE__ */ s((e, t, r) => t in e ? sl(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), Yo = /* @__PURE__ */ s((e, t, r) => il(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), Rt = class e extends jt {
  static {
    s(this, "SearchFilterBuilderImpl");
  }
  constructor(t) {
    super(), Yo(this, "filters"), Yo(this, "isConsumed"), this.filters = t, this.isConsumed = !1;
  }
  static new() {
    return new e([]);
  }
  consume() {
    if (this.isConsumed)
      throw new Error(
        "SearchFilterBuilder has already been used! Chain your method calls like `q => q.search(...).eq(...)`."
      );
    this.isConsumed = !0;
  }
  search(t, r) {
    return S(t, 1, "search", "fieldName"), S(r, 2, "search", "query"), this.consume(), new e(
      this.filters.concat({
        type: "Search",
        fieldPath: t,
        value: r
      })
    );
  }
  eq(t, r) {
    return S(t, 1, "eq", "fieldName"), arguments.length !== 2 && S(r, 2, "search", "value"), this.consume(), new e(
      this.filters.concat({
        type: "Eq",
        fieldPath: t,
        value: X(r)
      })
    );
  }
  export() {
    return this.consume(), this.filters;
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/query_impl.js
var cl = Object.defineProperty, al = /* @__PURE__ */ s((e, t, r) => t in e ? cl(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), Mr = /* @__PURE__ */ s((e, t, r) => al(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), Xo = 256, ze = class {
  static {
    s(this, "QueryInitializerImpl");
  }
  constructor(t) {
    Mr(this, "tableName"), this.tableName = t;
  }
  withIndex(t, r) {
    S(t, 1, "withIndex", "indexName");
    let n = Nt.new();
    return r !== void 0 && (n = r(n)), new ge({
      source: {
        type: "IndexRange",
        indexName: this.tableName + "." + t,
        range: n.export(),
        order: null
      },
      operators: []
    });
  }
  withSearchIndex(t, r) {
    S(t, 1, "withSearchIndex", "indexName"), S(r, 2, "withSearchIndex", "searchFilter");
    let n = Rt.new();
    return new ge({
      source: {
        type: "Search",
        indexName: this.tableName + "." + t,
        filters: r(n).export()
      },
      operators: []
    });
  }
  fullTableScan() {
    return new ge({
      source: {
        type: "FullTableScan",
        tableName: this.tableName,
        order: null
      },
      operators: []
    });
  }
  order(t) {
    return this.fullTableScan().order(t);
  }
  // This is internal API and should not be exposed to developers yet.
  async count() {
    let t = await O("1.0/count", {
      table: this.tableName
    });
    return C(t);
  }
  filter(t) {
    return this.fullTableScan().filter(t);
  }
  limit(t) {
    return this.fullTableScan().limit(t);
  }
  collect() {
    return this.fullTableScan().collect();
  }
  take(t) {
    return this.fullTableScan().take(t);
  }
  paginate(t) {
    return this.fullTableScan().paginate(t);
  }
  first() {
    return this.fullTableScan().first();
  }
  unique() {
    return this.fullTableScan().unique();
  }
  [Symbol.asyncIterator]() {
    return this.fullTableScan()[Symbol.asyncIterator]();
  }
};
function es(e) {
  throw new Error(
    e === "consumed" ? "This query is closed and can't emit any more values." : "This query has been chained with another operator and can't be reused."
  );
}
s(es, "throwClosedError");
var ge = class e {
  static {
    s(this, "QueryImpl");
  }
  constructor(t) {
    Mr(this, "state"), Mr(this, "tableNameForErrorMessages"), this.state = { type: "preparing", query: t }, t.source.type === "FullTableScan" ? this.tableNameForErrorMessages = t.source.tableName : this.tableNameForErrorMessages = t.source.indexName.split(".")[0];
  }
  takeQuery() {
    if (this.state.type !== "preparing")
      throw new Error(
        "A query can only be chained once and can't be chained after iteration begins."
      );
    let t = this.state.query;
    return this.state = { type: "closed" }, t;
  }
  startQuery() {
    if (this.state.type === "executing")
      throw new Error("Iteration can only begin on a query once.");
    (this.state.type === "closed" || this.state.type === "consumed") && es(this.state.type);
    let t = this.state.query, { queryId: r } = Je("1.0/queryStream", { query: t, version: F });
    return this.state = { type: "executing", queryId: r }, r;
  }
  closeQuery() {
    if (this.state.type === "executing") {
      let t = this.state.queryId;
      Je("1.0/queryCleanup", { queryId: t });
    }
    this.state = { type: "consumed" };
  }
  order(t) {
    S(t, 1, "order", "order");
    let r = this.takeQuery();
    if (r.source.type === "Search")
      throw new Error(
        "Search queries must always be in relevance order. Can not set order manually."
      );
    if (r.source.order !== null)
      throw new Error("Queries may only specify order at most once");
    return r.source.order = t, new e(r);
  }
  filter(t) {
    S(t, 1, "filter", "predicate");
    let r = this.takeQuery();
    if (r.operators.length >= Xo)
      throw new Error(
        `Can't construct query with more than ${Xo} operators`
      );
    return r.operators.push({
      filter: P(t(Ho))
    }), new e(r);
  }
  limit(t) {
    S(t, 1, "limit", "n");
    let r = this.takeQuery();
    return r.operators.push({ limit: t }), new e(r);
  }
  [Symbol.asyncIterator]() {
    return this.startQuery(), this;
  }
  async next() {
    (this.state.type === "closed" || this.state.type === "consumed") && es(this.state.type);
    let t = this.state.type === "preparing" ? this.startQuery() : this.state.queryId, { value: r, done: n } = await O("1.0/queryStreamNext", {
      queryId: t
    });
    return n && this.closeQuery(), { value: C(r), done: n };
  }
  return() {
    return this.closeQuery(), Promise.resolve({ done: !0, value: void 0 });
  }
  async paginate(t) {
    if (S(t, 1, "paginate", "options"), typeof t?.numItems != "number" || t.numItems < 0)
      throw new Error(
        `\`options.numItems\` must be a positive number. Received \`${t?.numItems}\`.`
      );
    let r = this.takeQuery(), n = t.numItems, o = t.cursor, i = t?.endCursor ?? null, c = t.maximumRowsRead ?? null, { page: a, isDone: u, continueCursor: l, splitCursor: p, pageStatus: m } = await O("1.0/queryPage", {
      query: r,
      cursor: o,
      endCursor: i,
      pageSize: n,
      maximumRowsRead: c,
      maximumBytesRead: t.maximumBytesRead,
      version: F
    });
    return {
      page: a.map((h) => C(h)),
      isDone: u,
      continueCursor: l,
      splitCursor: p,
      pageStatus: m
    };
  }
  async collect() {
    let t = [];
    for await (let r of this)
      t.push(r);
    return t;
  }
  async take(t) {
    return S(t, 1, "take", "n"), Wo(t, 1, "take", "n"), this.limit(t).collect();
  }
  async first() {
    let t = await this.take(1);
    return t.length === 0 ? null : t[0];
  }
  async unique() {
    let t = await this.take(2);
    if (t.length === 0)
      return null;
    if (t.length === 2)
      throw new Error(`unique() query returned more than one result from table ${this.tableNameForErrorMessages}:
 [${t[0]._id}, ${t[1]._id}, ...]`);
    return t[0];
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/database_impl.js
async function Ur(e, t, r) {
  if (S(t, 1, "get", "id"), typeof t != "string")
    throw new Error(
      `Invalid argument \`id\` for \`db.get\`, expected string but got '${typeof t}': ${t}`
    );
  let n = {
    id: Z(t),
    isSystem: r,
    version: F,
    table: e
  }, o = await O("1.0/get", n);
  return C(o);
}
s(Ur, "get");
function Wr() {
  let e = /* @__PURE__ */ s((o = !1) => ({
    get: /* @__PURE__ */ s(async (i, c) => c !== void 0 ? await Ur(i, c, o) : await Ur(void 0, i, o), "get"),
    query: /* @__PURE__ */ s((i) => new qe(i, o).query(), "query"),
    normalizeId: /* @__PURE__ */ s((i, c) => {
      S(i, 1, "normalizeId", "tableName"), S(c, 2, "normalizeId", "id");
      let a = i.startsWith("_");
      if (a !== o)
        throw new Error(
          `${a ? "System" : "User"} tables can only be accessed from db.${o ? "" : "system."}normalizeId().`
        );
      let u = Je("1.0/db/normalizeId", {
        table: i,
        idString: c
      });
      return C(u).id;
    }, "normalizeId"),
    // We set the system reader on the next line
    system: null,
    table: /* @__PURE__ */ s((i) => new qe(i, o), "table")
  }), "reader"), { system: t, ...r } = e(!0), n = e();
  return n.system = r, n;
}
s(Wr, "setupReader");
async function ts(e, t) {
  if (e.startsWith("_"))
    throw new Error("System tables (prefixed with `_`) are read-only.");
  S(e, 1, "insert", "table"), S(t, 2, "insert", "value");
  let r = await O("1.0/insert", {
    table: e,
    value: Z(t)
  });
  return C(r)._id;
}
s(ts, "insert");
async function Br(e, t, r) {
  S(t, 1, "patch", "id"), S(r, 2, "patch", "value"), await O("1.0/shallowMerge", {
    id: Z(t),
    value: Do(r),
    table: e
  });
}
s(Br, "patch");
async function Jr(e, t, r) {
  S(t, 1, "replace", "id"), S(r, 2, "replace", "value"), await O("1.0/replace", {
    id: Z(t),
    value: Z(r),
    table: e
  });
}
s(Jr, "replace");
async function Vr(e, t) {
  S(t, 1, "delete", "id"), await O("1.0/remove", {
    id: Z(t),
    table: e
  });
}
s(Vr, "delete_");
function rs() {
  let e = Wr();
  return {
    get: e.get,
    query: e.query,
    normalizeId: e.normalizeId,
    system: e.system,
    insert: /* @__PURE__ */ s(async (t, r) => await ts(t, r), "insert"),
    patch: /* @__PURE__ */ s(async (t, r, n) => n !== void 0 ? await Br(t, r, n) : await Br(void 0, t, r), "patch"),
    replace: /* @__PURE__ */ s(async (t, r, n) => n !== void 0 ? await Jr(t, r, n) : await Jr(void 0, t, r), "replace"),
    delete: /* @__PURE__ */ s(async (t, r) => r !== void 0 ? await Vr(t, r) : await Vr(void 0, t), "delete"),
    table: /* @__PURE__ */ s((t) => new qr(t, !1), "table")
  };
}
s(rs, "setupWriter");
var qe = class {
  static {
    s(this, "TableReader");
  }
  constructor(t, r) {
    this.tableName = t, this.isSystem = r;
  }
  async get(t) {
    return Ur(this.tableName, t, this.isSystem);
  }
  query() {
    let t = this.tableName.startsWith("_");
    if (t !== this.isSystem)
      throw new Error(
        `${t ? "System" : "User"} tables can only be accessed from db.${this.isSystem ? "" : "system."}query().`
      );
    return new ze(this.tableName);
  }
}, qr = class extends qe {
  static {
    s(this, "TableWriter");
  }
  async insert(t) {
    return ts(this.tableName, t);
  }
  async patch(t, r) {
    return Br(this.tableName, t, r);
  }
  async replace(t, r) {
    return Jr(this.tableName, t, r);
  }
  async delete(t) {
    return Vr(this.tableName, t);
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/scheduler_impl.js
function ns() {
  return {
    runAfter: /* @__PURE__ */ s(async (e, t, r) => {
      let n = ss(e, t, r);
      return await O("1.0/schedule", n);
    }, "runAfter"),
    runAt: /* @__PURE__ */ s(async (e, t, r) => {
      let n = is(
        e,
        t,
        r
      );
      return await O("1.0/schedule", n);
    }, "runAt"),
    cancel: /* @__PURE__ */ s(async (e) => {
      S(e, 1, "cancel", "id");
      let t = { id: Z(e) };
      await O("1.0/cancel_job", t);
    }, "cancel")
  };
}
s(ns, "setupMutationScheduler");
function os(e) {
  return {
    runAfter: /* @__PURE__ */ s(async (t, r, n) => {
      let o = {
        requestId: e,
        ...ss(t, r, n)
      };
      return await O("1.0/actions/schedule", o);
    }, "runAfter"),
    runAt: /* @__PURE__ */ s(async (t, r, n) => {
      let o = {
        requestId: e,
        ...is(t, r, n)
      };
      return await O("1.0/actions/schedule", o);
    }, "runAt"),
    cancel: /* @__PURE__ */ s(async (t) => {
      S(t, 1, "cancel", "id");
      let r = {
        requestId: e,
        id: Z(t)
      };
      return await O("1.0/actions/cancel_job", r);
    }, "cancel")
  };
}
s(os, "setupActionScheduler");
function ss(e, t, r) {
  if (typeof e != "number")
    throw new Error("`delayMs` must be a number");
  if (!isFinite(e))
    throw new Error("`delayMs` must be a finite number");
  if (e < 0)
    throw new Error("`delayMs` must be non-negative");
  let n = ae(r), o = ee(t), i = (Date.now() + e) / 1e3;
  return {
    ...o,
    ts: i,
    args: Z(n),
    version: F
  };
}
s(ss, "runAfterSyscallArgs");
function is(e, t, r) {
  let n;
  if (e instanceof Date)
    n = e.valueOf() / 1e3;
  else if (typeof e == "number")
    n = e / 1e3;
  else
    throw new Error("The invoke time must a Date or a timestamp");
  let o = ee(t), i = ae(r);
  return {
    ...o,
    ts: n,
    args: Z(i),
    version: F
  };
}
s(is, "runAtSyscallArgs");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/storage_impl.js
function Gr(e) {
  return {
    getUrl: /* @__PURE__ */ s(async (t) => (S(t, 1, "getUrl", "storageId"), await O("1.0/storageGetUrl", {
      requestId: e,
      version: F,
      storageId: t
    })), "getUrl"),
    getMetadata: /* @__PURE__ */ s(async (t) => await O("1.0/storageGetMetadata", {
      requestId: e,
      version: F,
      storageId: t
    }), "getMetadata")
  };
}
s(Gr, "setupStorageReader");
function Kr(e) {
  let t = Gr(e);
  return {
    generateUploadUrl: /* @__PURE__ */ s(async () => await O("1.0/storageGenerateUploadUrl", {
      requestId: e,
      version: F
    }), "generateUploadUrl"),
    delete: /* @__PURE__ */ s(async (r) => {
      await O("1.0/storageDelete", {
        requestId: e,
        version: F,
        storageId: r
      });
    }, "delete"),
    getUrl: t.getUrl,
    getMetadata: t.getMetadata
  };
}
s(Kr, "setupStorageWriter");
function cs(e) {
  return {
    ...Kr(e),
    store: /* @__PURE__ */ s(async (r, n) => await Zt("storage/storeBlob", {
      requestId: e,
      version: F,
      blob: r,
      options: n
    }), "store"),
    get: /* @__PURE__ */ s(async (r) => await Zt("storage/getBlob", {
      requestId: e,
      version: F,
      storageId: r
    }), "get")
  };
}
s(cs, "setupStorageActionWriter");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/registration_impl.js
async function as(e, t) {
  let n = C(JSON.parse(t)), o = {
    db: rs(),
    auth: At(""),
    storage: Kr(""),
    scheduler: ns(),
    runQuery: /* @__PURE__ */ s((c, a) => Hr("query", c, a), "runQuery"),
    runMutation: /* @__PURE__ */ s((c, a) => Hr("mutation", c, a), "runMutation")
  }, i = await Qr(e, o, n);
  return us(i), JSON.stringify(Z(i === void 0 ? null : i));
}
s(as, "invokeMutation");
function us(e) {
  if (e instanceof ze || e instanceof ge)
    throw new Error(
      "Return value is a Query. Results must be retrieved with `.collect()`, `.take(n), `.unique()`, or `.first()`."
    );
}
s(us, "validateReturnValue");
async function Qr(e, t, r) {
  let n;
  try {
    n = await Promise.resolve(e(t, ...r));
  } catch (o) {
    throw ul(o);
  }
  return n;
}
s(Qr, "invokeFunction");
function $e(e, t) {
  return (r, n) => (globalThis.console.warn(
    `Convex functions should not directly call other Convex functions. Consider calling a helper function instead. e.g. \`export const foo = ${e}(...); await foo(ctx);\` is not supported. See https://docs.convex.dev/production/best-practices/#use-helper-functions-to-write-shared-code`
  ), t(r, n));
}
s($e, "dontCallDirectly");
function ul(e) {
  if (typeof e == "object" && e !== null && Symbol.for("ConvexError") in e) {
    let t = e;
    return t.data = JSON.stringify(
      Z(t.data === void 0 ? null : t.data)
    ), t.ConvexErrorSymbol = Symbol.for("ConvexError"), t;
  } else
    return e;
}
s(ul, "serializeConvexErrorData");
function ke() {
  if (typeof window > "u" || window.__convexAllowFunctionsInBrowser)
    return;
  (Object.getOwnPropertyDescriptor(globalThis, "window")?.get?.toString().includes("[native code]") ?? !1) && console.error(
    "Convex functions should not be imported in the browser. This will throw an error in future versions of `convex`. If this is a false negative, please report it to Convex support."
  );
}
s(ke, "assertNotBrowser");
function ls(e, t) {
  if (t === void 0)
    throw new Error(
      `A validator is undefined for field "${e}". This is often caused by circular imports. See https://docs.convex.dev/error#undefined-validator for details.`
    );
  return t;
}
s(ls, "strictReplacer");
function Se(e) {
  return () => {
    let t = d.any();
    return typeof e == "object" && e.args !== void 0 && (t = xe(e.args)), JSON.stringify(t.json, ls);
  };
}
s(Se, "exportArgs");
function Oe(e) {
  return () => {
    let t;
    return typeof e == "object" && e.returns !== void 0 && (t = xe(e.returns)), JSON.stringify(t ? t.json : null, ls);
  };
}
s(Oe, "exportReturns");
var Yr = /* @__PURE__ */ s(((e) => {
  let t = typeof e == "function" ? e : e.handler, r = $e("mutation", t);
  return ke(), r.isMutation = !0, r.isPublic = !0, r.invokeMutation = (n) => as(t, n), r.exportArgs = Se(e), r.exportReturns = Oe(e), r._handler = t, r;
}), "mutationGeneric"), Xr = /* @__PURE__ */ s(((e) => {
  let t = typeof e == "function" ? e : e.handler, r = $e(
    "internalMutation",
    t
  );
  return ke(), r.isMutation = !0, r.isInternal = !0, r.invokeMutation = (n) => as(t, n), r.exportArgs = Se(e), r.exportReturns = Oe(e), r._handler = t, r;
}), "internalMutationGeneric");
async function ps(e, t) {
  let n = C(JSON.parse(t)), o = {
    db: Wr(),
    auth: At(""),
    storage: Gr(""),
    runQuery: /* @__PURE__ */ s((c, a) => Hr("query", c, a), "runQuery")
  }, i = await Qr(e, o, n);
  return us(i), JSON.stringify(Z(i === void 0 ? null : i));
}
s(ps, "invokeQuery");
var en = /* @__PURE__ */ s(((e) => {
  let t = typeof e == "function" ? e : e.handler, r = $e("query", t);
  return ke(), r.isQuery = !0, r.isPublic = !0, r.invokeQuery = (n) => ps(t, n), r.exportArgs = Se(e), r.exportReturns = Oe(e), r._handler = t, r;
}), "queryGeneric"), tn = /* @__PURE__ */ s(((e) => {
  let t = typeof e == "function" ? e : e.handler, r = $e("internalQuery", t);
  return ke(), r.isQuery = !0, r.isInternal = !0, r.invokeQuery = (n) => ps(t, n), r.exportArgs = Se(e), r.exportReturns = Oe(e), r._handler = t, r;
}), "internalQueryGeneric");
async function fs(e, t, r) {
  let n = C(JSON.parse(r)), i = {
    ...Vo(t),
    auth: At(t),
    scheduler: os(t),
    storage: cs(t),
    vectorSearch: Go(t)
  }, c = await Qr(e, i, n);
  return JSON.stringify(Z(c === void 0 ? null : c));
}
s(fs, "invokeAction");
var rn = /* @__PURE__ */ s(((e) => {
  let t = typeof e == "function" ? e : e.handler, r = $e("action", t);
  return ke(), r.isAction = !0, r.isPublic = !0, r.invokeAction = (n, o) => fs(t, n, o), r.exportArgs = Se(e), r.exportReturns = Oe(e), r._handler = t, r;
}), "actionGeneric"), nn = /* @__PURE__ */ s(((e) => {
  let t = typeof e == "function" ? e : e.handler, r = $e("internalAction", t);
  return ke(), r.isAction = !0, r.isInternal = !0, r.invokeAction = (n, o) => fs(t, n, o), r.exportArgs = Se(e), r.exportReturns = Oe(e), r._handler = t, r;
}), "internalActionGeneric");
async function Hr(e, t, r) {
  let n = ae(r), o = {
    udfType: e,
    args: Z(n),
    ...ee(t)
  }, i = await O("1.0/runUdf", o);
  return C(i);
}
s(Hr, "runUdf");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/pagination.js
var eh = d.object({
  numItems: d.number(),
  cursor: d.union(d.string(), d.null()),
  endCursor: d.optional(d.union(d.string(), d.null())),
  id: d.optional(d.number()),
  maximumRowsRead: d.optional(d.number()),
  maximumBytesRead: d.optional(d.number())
});

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/api.js
function ds(e = []) {
  let t = {
    get(r, n) {
      if (typeof n == "string") {
        let o = [...e, n];
        return ds(o);
      } else if (n === Ve) {
        if (e.length < 2) {
          let c = ["api", ...e].join(".");
          throw new Error(
            `API path is expected to be of the form \`api.moduleName.functionName\`. Found: \`${c}\``
          );
        }
        let o = e.slice(0, -1).join("/"), i = e[e.length - 1];
        return i === "default" ? o : o + ":" + i;
      } else return n === Symbol.toStringTag ? "FunctionReference" : void 0;
    }
  };
  return new Proxy({}, t);
}
s(ds, "createApi");
var ll = ds();

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/schema.js
var fl = Object.defineProperty, dl = /* @__PURE__ */ s((e, t, r) => t in e ? fl(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), ne = /* @__PURE__ */ s((e, t, r) => dl(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), Ft = class {
  static {
    s(this, "TableDefinition");
  }
  /**
   * @internal
   */
  constructor(t) {
    ne(this, "indexes"), ne(this, "stagedDbIndexes"), ne(this, "searchIndexes"), ne(this, "stagedSearchIndexes"), ne(this, "vectorIndexes"), ne(this, "stagedVectorIndexes"), ne(this, "validator"), this.indexes = [], this.stagedDbIndexes = [], this.searchIndexes = [], this.stagedSearchIndexes = [], this.vectorIndexes = [], this.stagedVectorIndexes = [], this.validator = t;
  }
  /**
   * This API is experimental: it may change or disappear.
   *
   * Returns indexes defined on this table.
   * Intended for the advanced use cases of dynamically deciding which index to use for a query.
   * If you think you need this, please chime in on ths issue in the Convex JS GitHub repo.
   * https://github.com/get-convex/convex-js/issues/49
   */
  " indexes"() {
    return this.indexes;
  }
  index(t, r) {
    return Array.isArray(r) ? this.indexes.push({
      indexDescriptor: t,
      fields: r
    }) : r.staged ? this.stagedDbIndexes.push({
      indexDescriptor: t,
      fields: r.fields
    }) : this.indexes.push({
      indexDescriptor: t,
      fields: r.fields
    }), this;
  }
  searchIndex(t, r) {
    return r.staged ? this.stagedSearchIndexes.push({
      indexDescriptor: t,
      searchField: r.searchField,
      filterFields: r.filterFields || []
    }) : this.searchIndexes.push({
      indexDescriptor: t,
      searchField: r.searchField,
      filterFields: r.filterFields || []
    }), this;
  }
  vectorIndex(t, r) {
    return r.staged ? this.stagedVectorIndexes.push({
      indexDescriptor: t,
      vectorField: r.vectorField,
      dimensions: r.dimensions,
      filterFields: r.filterFields || []
    }) : this.vectorIndexes.push({
      indexDescriptor: t,
      vectorField: r.vectorField,
      dimensions: r.dimensions,
      filterFields: r.filterFields || []
    }), this;
  }
  /**
   * Work around for https://github.com/microsoft/TypeScript/issues/57035
   */
  self() {
    return this;
  }
  /**
   * Export the contents of this definition.
   *
   * This is called internally by the Convex framework.
   * @internal
   */
  export() {
    let t = this.validator.json;
    if (typeof t != "object")
      throw new Error(
        "Invalid validator: please make sure that the parameter of `defineTable` is valid (see https://docs.convex.dev/database/schemas)"
      );
    return {
      indexes: this.indexes,
      stagedDbIndexes: this.stagedDbIndexes,
      searchIndexes: this.searchIndexes,
      stagedSearchIndexes: this.stagedSearchIndexes,
      vectorIndexes: this.vectorIndexes,
      stagedVectorIndexes: this.stagedVectorIndexes,
      documentType: t
    };
  }
};
function on(e) {
  return jr(e) ? new Ft(e) : new Ft(d.object(e));
}
s(on, "defineTable");
var sn = class {
  static {
    s(this, "SchemaDefinition");
  }
  /**
   * @internal
   */
  constructor(t, r) {
    ne(this, "tables"), ne(this, "strictTableNameTypes"), ne(this, "schemaValidation"), this.tables = t, this.schemaValidation = r?.schemaValidation === void 0 ? !0 : r.schemaValidation;
  }
  /**
   * Export the contents of this definition.
   *
   * This is called internally by the Convex framework.
   * @internal
   */
  export() {
    return JSON.stringify({
      tables: Object.entries(this.tables).map(([t, r]) => {
        let {
          indexes: n,
          stagedDbIndexes: o,
          searchIndexes: i,
          stagedSearchIndexes: c,
          vectorIndexes: a,
          stagedVectorIndexes: u,
          documentType: l
        } = r.export();
        return {
          tableName: t,
          indexes: n,
          stagedDbIndexes: o,
          searchIndexes: i,
          stagedSearchIndexes: c,
          vectorIndexes: a,
          stagedVectorIndexes: u,
          documentType: l
        };
      }),
      schemaValidation: this.schemaValidation
    });
  }
};
function ms(e, t) {
  return new sn(e, t);
}
s(ms, "defineSchema");
var $h = ms({
  _scheduled_functions: on({
    name: d.string(),
    args: d.array(d.any()),
    scheduledTime: d.float64(),
    completedTime: d.optional(d.float64()),
    state: d.union(
      d.object({ kind: d.literal("pending") }),
      d.object({ kind: d.literal("inProgress") }),
      d.object({ kind: d.literal("success") }),
      d.object({ kind: d.literal("failed"), error: d.string() }),
      d.object({ kind: d.literal("canceled") })
    )
  }),
  _storage: on({
    sha256: d.string(),
    size: d.float64(),
    contentType: d.optional(d.string())
  })
});

// memory/profile.mjs
var ye = class {
  static {
    s(this, "SecretText");
  }
  constructor(t) {
    this.value = t;
  }
  toWire() {
    return this.value;
  }
}, cn = {
  seq: 1,
  at: 17e11,
  secret: "capacity",
  payload: "tiny"
};
function hs(e) {
  let t = e.kind === "native", r = e.kind === "full" || e.kind === "mini", n = t ? e.v : e.s;
  return /* @__PURE__ */ s(function({ count: i, width: c, profile: a, entries: u = 0 }) {
    if (!Number.isInteger(i) || i < 0 || !Number.isInteger(c) || c < 1 || !Number.isInteger(u) || u < 0 || !["fields-only", "codec-rich"].includes(a))
      throw new Error("Invalid graph fixture arguments");
    let l = {
      schemaConstructors: 0,
      fields: 0,
      codecSites: 0,
      allocatedCodecs: 0
    }, p = /* @__PURE__ */ s((_, ...v) => (l.schemaConstructors++, n[_](...v)), "make"), m = /* @__PURE__ */ s((_) => (l.fields += Object.keys(_).length, p("object", _)), "object"), h = /* @__PURE__ */ s(() => (l.codecSites++, t ? p("number") : (l.allocatedCodecs++, p("codec", p("number"), p("date"), {
      decode: /* @__PURE__ */ s((_) => new Date(_), "decode"),
      encode: /* @__PURE__ */ s((_) => _.getTime(), "encode")
    }))), "date"), g = /* @__PURE__ */ s(() => (l.codecSites++, t ? p("string") : (l.allocatedCodecs++, p("codec", p("string"), p("instanceof", ye), {
      decode: /* @__PURE__ */ s((_) => new ye(_), "decode"),
      encode: /* @__PURE__ */ s((_) => _.toWire(), "encode")
    }))), "secret"), y = /* @__PURE__ */ s((_) => {
      if (a === "fields-only")
        switch (_ % 4) {
          case 0:
            return p("string");
          case 1:
            return p("number");
          case 2:
            return p("boolean");
          case 3:
            return p("optional", p("string"));
        }
      switch (_ % 4) {
        case 0:
          return h();
        case 1:
          return g();
        case 2:
          return m({ at: h(), tag: p("optional", p("string")) });
        case 3:
          return p(
            "array",
            t ? p("union", p("string"), p("number")) : p("union", [p("string"), p("number")])
          );
      }
    }, "field"), x = {}, w = {}, j = /* @__PURE__ */ s((_, v) => {
      r ? (l.fields += Object.keys(v).length, x[_] = e.defineZodModel(_, v, e.schemaHelpers ? void 0 : { schemaHelpers: !1 })) : (w[_] = m(v), x[_] = t ? e.defineTable(w[_]) : w[_]);
    }, "add");
    j("benchmarkRows", {
      seq: p("number"),
      at: h(),
      secret: g(),
      payload: p("string")
    });
    for (let _ = 0; _ < i; _++) {
      let v = {};
      for (let T = 0; T < c; T++) v[`f${T}`] = y(T);
      j(`unused${_}`, v);
    }
    let R = r ? e.defineZodSchema(x) : t ? e.defineSchema(x) : null;
    if (r) for (let _ of Object.keys(x)) w[_] = R.__zodTableMap[_].insert;
    let Q = Object.keys(x), ie = {};
    for (let _ = 0; _ < u; _++) {
      let v = Q[_ % Q.length], T = r ? R.__zodTableMap[v].doc : w[v], ht = m({
        id: p("string"),
        label: p("optional", p("string"))
      }), gt = t ? p("union", T, p("null")) : p("nullable", T);
      ie[`unused/fn${_}`] = { args: ht, returns: gt };
    }
    let L = r ? e.initZodvex(
      R,
      e.server,
      u ? { registry: /* @__PURE__ */ s(() => ie, "registry") } : void 0
    ) : e.makeBuilders();
    return {
      kind: e.kind,
      options: { count: i, width: c, profile: a, entries: u },
      models: x,
      sourceSchemas: w,
      schema: R,
      registry: ie,
      builders: L,
      manifest: {
        backgroundModels: i,
        totalModels: i + 1,
        backgroundTopLevelFields: i * c,
        fixedProbeFields: 4,
        profile: a,
        registryEntries: u,
        ...l,
        counterScope: "Explicit fixture constructor calls and source fields/codecs; excludes library-generated helper schemas and runtime heap objects."
      },
      operation() {
        let _ = { ...cn }, v = t ? {
          ..._,
          at: new Date(_.at),
          secret: new ye(_.secret)
        } : e.s.parse(w.benchmarkRows, _);
        if (!(v.at instanceof Date) || !(v.secret instanceof ye))
          throw new Error("Codec decode failed");
        v.at = new Date(v.at.getTime() + 1e3), v.secret = new ye(v.secret.toWire().toUpperCase());
        let T = t ? {
          ...v,
          at: v.at.getTime(),
          secret: v.secret.toWire()
        } : e.s.encode(w.benchmarkRows, v);
        if (JSON.stringify(T) !== JSON.stringify({
          ...cn,
          at: cn.at + 1e3,
          secret: "CAPACITY"
        }))
          throw new Error("Codec round trip mismatch");
        return T;
      },
      // Call after the operation and after GC measurements. The retained graph
      // includes every model, table schema, registry entry and builder closure.
      checksum() {
        let _ = 0;
        for (let [v, T] of Object.entries(x)) {
          if (!T || !w[v]) throw new Error("Missing model");
          if (_ += v.length, r && R.__zodTableMap[v].insert !== w[v])
            throw new Error("Lost table-map alias");
        }
        for (let [v, T] of Object.entries(ie)) {
          if (!T.args || !T.returns)
            throw new Error("Missing registry schema");
          _ += v.length;
        }
        if (Object.keys(L).length === 0)
          throw new Error("Lost builders");
        return _;
      }
    };
  }, "buildGraph");
}
s(hs, "createGraphFactory");

// versions/4.5.4/node_modules/zod/v4/core/util.js
var k = {};
bu(k, {
  BIGINT_FORMAT_RANGES: () => _s,
  CONSTANT_CATCH: () => vs,
  Class: () => un,
  NUMBER_FORMAT_RANGES: () => _n,
  aborted: () => pe,
  allowsEval: () => hn,
  assert: () => bl,
  assertEqual: () => ml,
  assertIs: () => yl,
  assertNever: () => _l,
  assertNotEqual: () => hl,
  assignProp: () => U,
  attachSchema: () => Ut,
  base64ToUint8Array: () => xs,
  base64urlToUint8Array: () => Rl,
  cached: () => Ge,
  captureStackTrace: () => Dt,
  cleanEnum: () => jl,
  cleanRegex: () => Ke,
  clone: () => te,
  cloneDef: () => wl,
  codePointLength: () => Qe,
  constantCatch: () => zs,
  createTransparentProxy: () => Ol,
  defineLazy: () => fn,
  defineLazyInternal: () => $,
  esc: () => dn,
  escapeRegex: () => oe,
  explicitlyAborted: () => bn,
  extend: () => Il,
  finalizeIssue: () => K,
  floatSafeRemainder: () => pn,
  getElementAtPath: () => vl,
  getEnumValues: () => We,
  getLengthableOrigin: () => Ye,
  getParsedType: () => Sl,
  getSizableOrigin: () => bs,
  hexToUint8Array: () => Ll,
  hide: () => vn,
  installLazyProp: () => Jl,
  isObject: () => Ze,
  isPlainObject: () => le,
  issue: () => Ae,
  joinValues: () => Lt,
  jsonStringifyReplacer: () => Ee,
  members: () => wn,
  merge: () => Al,
  mergeDefs: () => ce,
  normalizeParams: () => b,
  nullish: () => ln,
  numKeys: () => kl,
  objectClone: () => xl,
  omit: () => Zl,
  optionalKeys: () => yn,
  own: () => Ie,
  parsedType: () => xn,
  partial: () => Tl,
  pick: () => Pl,
  prefixIssues: () => G,
  primitiveTypes: () => gn,
  promiseAllObject: () => zl,
  propertyKeyTypes: () => He,
  randomString: () => $l,
  required: () => Cl,
  safeExtend: () => El,
  shallowClone: () => ys,
  slugify: () => mn,
  stringifyPrimitive: () => Mt,
  toZod: () => gl,
  uint8ArrayToBase64: () => ws,
  uint8ArrayToBase64url: () => Fl,
  uint8ArrayToHex: () => Dl,
  unwrapMessage: () => Pe
});
function ml(e) {
  return e;
}
s(ml, "assertEqual");
function hl(e) {
  return e;
}
s(hl, "assertNotEqual");
function gl() {
  return (e) => e;
}
s(gl, "toZod");
function yl(e) {
}
s(yl, "assertIs");
function _l(e) {
  throw new Error("Unexpected value in exhaustive check");
}
s(_l, "assertNever");
function bl(e) {
}
s(bl, "assert");
function We(e) {
  let t = Object.values(e).filter((n) => typeof n == "number");
  return Object.entries(e).filter(([n, o]) => t.indexOf(+n) === -1).map(([n, o]) => o);
}
s(We, "getEnumValues");
function Lt(e, t = "|") {
  return e.map((r) => Mt(r)).join(t);
}
s(Lt, "joinValues");
function Ee(e, t) {
  return typeof t == "bigint" ? t.toString() : t;
}
s(Ee, "jsonStringifyReplacer");
function Ge(e) {
  return {
    get value() {
      {
        let r = e();
        return Object.defineProperty(this, "value", { value: r }), r;
      }
      throw new Error("cached value already set");
    }
  };
}
s(Ge, "cached");
function ln(e) {
  return e == null;
}
s(ln, "nullish");
function Ke(e) {
  let t = e.startsWith("^") ? 1 : 0, r = e.endsWith("$") ? e.length - 1 : e.length;
  return e.slice(t, r);
}
s(Ke, "cleanRegex");
function pn(e, t) {
  let r = e / t, n = Math.round(r), o = 4 * Number.EPSILON * Math.max(Math.abs(r), 1);
  return Math.abs(r - n) < o ? 0 : r - n;
}
s(pn, "floatSafeRemainder");
var gs = /* @__PURE__ */ Symbol("evaluating");
function fn(e, t, r) {
  let n;
  Object.defineProperty(e, t, {
    get() {
      if (n !== gs)
        return n === void 0 && (n = gs, n = r()), n;
    },
    set(o) {
      Object.defineProperty(e, t, {
        value: o
        // configurable: true,
      });
    },
    configurable: !0
  });
}
s(fn, "defineLazy");
function xl(e) {
  return Object.create(Object.getPrototypeOf(e), Object.getOwnPropertyDescriptors(e));
}
s(xl, "objectClone");
function U(e, t, r) {
  Object.defineProperty(e, t, {
    value: r,
    writable: !0,
    enumerable: !0,
    configurable: !0
  });
}
s(U, "assignProp");
function ce(...e) {
  let t = {};
  for (let r of e) {
    let n = Object.getOwnPropertyDescriptors(r);
    Object.assign(t, n);
  }
  return Object.defineProperties({}, t);
}
s(ce, "mergeDefs");
function wl(e) {
  return ce(e._zod.def);
}
s(wl, "cloneDef");
function vl(e, t) {
  return t ? t.reduce((r, n) => r?.[n], e) : e;
}
s(vl, "getElementAtPath");
function zl(e) {
  let t = Object.keys(e), r = t.map((n) => e[n]);
  return Promise.all(r).then((n) => {
    let o = {};
    for (let i = 0; i < t.length; i++)
      o[t[i]] = n[i];
    return o;
  });
}
s(zl, "promiseAllObject");
function $l(e = 10) {
  let t = "abcdefghijklmnopqrstuvwxyz", r = "";
  for (let n = 0; n < e; n++)
    r += t[Math.floor(Math.random() * t.length)];
  return r;
}
s($l, "randomString");
function dn(e) {
  return JSON.stringify(e);
}
s(dn, "esc");
function mn(e) {
  return e.toLowerCase().trim().replace(/[^\w\s-]/g, "").replace(/[\s_-]+/g, "-").replace(/^-+|-+$/g, "");
}
s(mn, "slugify");
var Dt = "captureStackTrace" in Error ? Error.captureStackTrace : (...e) => {
};
function Ze(e) {
  return typeof e == "object" && e !== null && !Array.isArray(e);
}
s(Ze, "isObject");
var hn = /* @__PURE__ */ Ge(() => {
  if (B.jitless || typeof navigator < "u" && navigator?.userAgent?.includes("Cloudflare"))
    return !1;
  try {
    let e = Function;
    return new e(""), !0;
  } catch {
    return !1;
  }
});
function le(e) {
  if (Ze(e) === !1)
    return !1;
  let t = e.constructor;
  if (t === void 0 || typeof t != "function")
    return !0;
  let r = t.prototype;
  return !(Ze(r) === !1 || Object.prototype.hasOwnProperty.call(r, "isPrototypeOf") === !1);
}
s(le, "isPlainObject");
function ys(e) {
  return le(e) ? { ...e } : Array.isArray(e) ? [...e] : e instanceof Map ? new Map(e) : e instanceof Set ? new Set(e) : e;
}
s(ys, "shallowClone");
function kl(e) {
  let t = 0;
  for (let r in e)
    Object.prototype.hasOwnProperty.call(e, r) && t++;
  return t;
}
s(kl, "numKeys");
var Sl = /* @__PURE__ */ s((e) => {
  let t = typeof e;
  switch (t) {
    case "undefined":
      return "undefined";
    case "string":
      return "string";
    case "number":
      return Number.isNaN(e) ? "nan" : "number";
    case "boolean":
      return "boolean";
    case "function":
      return "function";
    case "bigint":
      return "bigint";
    case "symbol":
      return "symbol";
    case "object":
      return Array.isArray(e) ? "array" : e === null ? "null" : e.then && typeof e.then == "function" && e.catch && typeof e.catch == "function" ? "promise" : typeof Map < "u" && e instanceof Map ? "map" : typeof Set < "u" && e instanceof Set ? "set" : typeof Date < "u" && e instanceof Date ? "date" : typeof File < "u" && e instanceof File ? "file" : "object";
    default:
      throw new Error(`Unknown data type: ${t}`);
  }
}, "getParsedType"), He = /* @__PURE__ */ new Set(["string", "number", "symbol"]), gn = /* @__PURE__ */ new Set([
  "string",
  "number",
  "bigint",
  "boolean",
  "symbol",
  "undefined"
]);
function oe(e) {
  return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
s(oe, "escapeRegex");
function te(e, t, r) {
  let n = new e._zod.constr(t ?? e._zod.def);
  return (!t || r?.parent) && (n._zod.parent = e), n;
}
s(te, "clone");
function b(e) {
  let t = e;
  if (!t)
    return {};
  if (typeof t == "string")
    return { error: /* @__PURE__ */ s(() => t, "error") };
  if (t?.message !== void 0) {
    if (t?.error !== void 0)
      throw new Error("Cannot specify both `message` and `error` params");
    t.error = t.message;
  }
  return delete t.message, typeof t.error == "string" ? { ...t, error: /* @__PURE__ */ s(() => t.error, "error") } : t;
}
s(b, "normalizeParams");
function Ol(e) {
  let t;
  return new Proxy({}, {
    get(r, n, o) {
      return t ?? (t = e()), Reflect.get(t, n, o);
    },
    set(r, n, o, i) {
      return t ?? (t = e()), Reflect.set(t, n, o, i);
    },
    has(r, n) {
      return t ?? (t = e()), Reflect.has(t, n);
    },
    deleteProperty(r, n) {
      return t ?? (t = e()), Reflect.deleteProperty(t, n);
    },
    ownKeys(r) {
      return t ?? (t = e()), Reflect.ownKeys(t);
    },
    getOwnPropertyDescriptor(r, n) {
      return t ?? (t = e()), Reflect.getOwnPropertyDescriptor(t, n);
    },
    defineProperty(r, n, o) {
      return t ?? (t = e()), Reflect.defineProperty(t, n, o);
    }
  });
}
s(Ol, "createTransparentProxy");
function Mt(e) {
  return typeof e == "bigint" ? e.toString() + "n" : typeof e == "string" ? `"${e}"` : `${e}`;
}
s(Mt, "stringifyPrimitive");
function yn(e) {
  return Object.keys(e).filter((t) => e[t]._zod.optin !== void 0 && e[t]._zod.optout === "optional");
}
s(yn, "optionalKeys");
var _n = {
  safeint: [Number.MIN_SAFE_INTEGER, Number.MAX_SAFE_INTEGER],
  int32: [-2147483648, 2147483647],
  uint32: [0, 4294967295],
  float32: [-34028234663852886e22, 34028234663852886e22],
  float64: [-Number.MAX_VALUE, Number.MAX_VALUE]
}, _s = {
  int64: [/* @__PURE__ */ BigInt("-9223372036854775808"), /* @__PURE__ */ BigInt("9223372036854775807")],
  uint64: [/* @__PURE__ */ BigInt(0), /* @__PURE__ */ BigInt("18446744073709551615")]
};
function Pl(e, t) {
  let r = e._zod.def, n = r.checks;
  if (n && n.length > 0)
    throw new Error(".pick() cannot be used on object schemas containing refinements");
  let i = ce(e._zod.def, {
    get shape() {
      let c = {};
      for (let a of Reflect.ownKeys(t)) {
        if (!Object.prototype.hasOwnProperty.call(r.shape, a))
          throw new Error(`Unrecognized key: "${String(a)}"`);
        t[a] && U(c, a, r.shape[a]);
      }
      return U(this, "shape", c), c;
    },
    checks: []
  });
  return te(e, i);
}
s(Pl, "pick");
function Zl(e, t) {
  let r = e._zod.def, n = r.checks;
  if (n && n.length > 0)
    throw new Error(".omit() cannot be used on object schemas containing refinements");
  let i = ce(e._zod.def, {
    get shape() {
      let c = { ...e._zod.def.shape };
      for (let a of Reflect.ownKeys(t)) {
        if (!Object.prototype.hasOwnProperty.call(r.shape, a))
          throw new Error(`Unrecognized key: "${String(a)}"`);
        t[a] && delete c[a];
      }
      return U(this, "shape", c), c;
    },
    checks: []
  });
  return te(e, i);
}
s(Zl, "omit");
function Il(e, t) {
  if (!le(t))
    throw new Error("Invalid input to extend: expected a plain object");
  let r = e._zod.def.checks;
  if (r && r.length > 0) {
    let i = e._zod.def.shape;
    for (let c of Reflect.ownKeys(t))
      if (Object.getOwnPropertyDescriptor(i, c) !== void 0)
        throw new Error("Cannot overwrite keys on object schemas containing refinements. Use `.safeExtend()` instead.");
  }
  let o = ce(e._zod.def, {
    get shape() {
      let i = { ...e._zod.def.shape, ...t };
      return U(this, "shape", i), i;
    }
  });
  return te(e, o);
}
s(Il, "extend");
function El(e, t) {
  if (!le(t))
    throw new Error("Invalid input to safeExtend: expected a plain object");
  let r = ce(e._zod.def, {
    get shape() {
      let n = { ...e._zod.def.shape, ...t };
      return U(this, "shape", n), n;
    }
  });
  return te(e, r);
}
s(El, "safeExtend");
function Al(e, t) {
  if (!t?._zod?.def)
    throw new Error("Invalid input to merge: expected an object schema. To merge a plain shape, use `.extend()`.");
  if (e._zod.def.checks?.length)
    throw new Error(".merge() cannot be used on object schemas containing refinements. Use .safeExtend() instead.");
  let r = ce(e._zod.def, {
    get shape() {
      let n = { ...e._zod.def.shape, ...t._zod.def.shape };
      return U(this, "shape", n), n;
    },
    get catchall() {
      return t._zod.def.catchall;
    },
    checks: t._zod.def.checks ?? []
  });
  return te(e, r);
}
s(Al, "merge");
function Tl(e, t, r, n = "partial") {
  let i = t._zod.def.checks;
  if (i && i.length > 0)
    throw new Error(`.${n}() cannot be used on object schemas containing refinements`);
  let a = ce(t._zod.def, {
    get shape() {
      let u = t._zod.def.shape, l = { ...u };
      if (r)
        for (let p of Reflect.ownKeys(r)) {
          if (!Object.prototype.hasOwnProperty.call(u, p))
            throw new Error(`Unrecognized key: "${String(p)}"`);
          r[p] && (l[p] = e ? new e({
            type: "optional",
            innerType: u[p]
          }) : u[p]);
        }
      else
        for (let p of Reflect.ownKeys(u))
          l[p] = e ? new e({
            type: "optional",
            innerType: u[p]
          }) : u[p];
      return U(this, "shape", l), l;
    },
    checks: []
  });
  return te(t, a);
}
s(Tl, "partial");
function Cl(e, t, r) {
  let n = ce(t._zod.def, {
    get shape() {
      let o = t._zod.def.shape, i = { ...o };
      if (r)
        for (let c of Reflect.ownKeys(r)) {
          if (!Object.prototype.hasOwnProperty.call(i, c))
            throw new Error(`Unrecognized key: "${String(c)}"`);
          r[c] && (i[c] = new e({
            type: "nonoptional",
            innerType: o[c]
          }));
        }
      else
        for (let c of Reflect.ownKeys(o))
          i[c] = new e({
            type: "nonoptional",
            innerType: o[c]
          });
      return U(this, "shape", i), i;
    }
  });
  return te(t, n);
}
s(Cl, "required");
function pe(e, t = 0) {
  if (e.aborted === !0)
    return !0;
  for (let r = t; r < e.issues.length; r++)
    if (e.issues[r]?.continue !== !0)
      return !0;
  return !1;
}
s(pe, "aborted");
function bn(e, t = 0) {
  if (e.aborted === !0)
    return !0;
  for (let r = t; r < e.issues.length; r++)
    if (e.issues[r]?.continue === !1)
      return !0;
  return !1;
}
s(bn, "explicitlyAborted");
function G(e, t) {
  return t.map((r) => {
    var n;
    return (n = r).path ?? (n.path = []), r.path.unshift(e), r;
  });
}
s(G, "prefixIssues");
function Pe(e) {
  return typeof e == "string" ? e : e?.message;
}
s(Pe, "unwrapMessage");
function Ut(e, t, r) {
  var n;
  for (let o = t; o < e.length; o++)
    (n = e[o]).schema ?? (n.schema = r);
}
s(Ut, "attachSchema");
function K(e, t, r) {
  var n;
  let o = e.inst?._zod?.traits;
  o?.has("$ZodType") && (o.has("$ZodCheck") ? (n = e).schema ?? (n.schema = e.inst) : e.schema = e.inst);
  let i = e.schema !== e.inst ? e.schema?._zod.def?.error : void 0, c = e.message ? e.message : Pe(e.inst?._zod.def?.error?.(e)) ?? Pe(i?.(e)) ?? Pe(t?.error?.(e)) ?? Pe(r.customError?.(e)) ?? Pe(r.localeError?.(e)) ?? "Invalid input", { inst: a, schema: u, continue: l, input: p, ...m } = e;
  return m.path ?? (m.path = []), m.message = c, t?.reportInput && (m.input = p), m;
}
s(K, "finalizeIssue");
function bs(e) {
  return e instanceof Set ? "set" : e instanceof Map ? "map" : e instanceof File ? "file" : "unknown";
}
s(bs, "getSizableOrigin");
var Nl = /[\uD800-\uDBFF]/;
function Qe(e) {
  let t = e.length;
  if (!Nl.test(e))
    return t;
  let r = t;
  for (let n = 0; n < t - 1; n++)
    (e.charCodeAt(n) & 64512) === 55296 && (e.charCodeAt(n + 1) & 64512) === 56320 && (r--, n++);
  return r;
}
s(Qe, "codePointLength");
function Ye(e) {
  return Array.isArray(e) ? "array" : typeof e == "string" ? "string" : "unknown";
}
s(Ye, "getLengthableOrigin");
function xn(e) {
  let t = typeof e;
  switch (t) {
    case "number":
      return Number.isNaN(e) ? "nan" : "number";
    case "object": {
      if (e === null)
        return "null";
      if (Array.isArray(e))
        return "array";
      let r = e;
      if (r && Object.getPrototypeOf(r) !== Object.prototype && "constructor" in r && r.constructor)
        return r.constructor.name;
    }
  }
  return t;
}
s(xn, "parsedType");
function Ae(...e) {
  let [t, r, n] = e;
  return typeof t == "string" ? {
    message: t,
    code: "custom",
    input: r,
    inst: n
  } : { ...t };
}
s(Ae, "issue");
function jl(e) {
  return Object.entries(e).filter(([t, r]) => Number.isNaN(Number.parseInt(t, 10))).map((t) => t[1]);
}
s(jl, "cleanEnum");
function xs(e) {
  let t = atob(e), r = new Uint8Array(t.length);
  for (let n = 0; n < t.length; n++)
    r[n] = t.charCodeAt(n);
  return r;
}
s(xs, "base64ToUint8Array");
function ws(e) {
  let t = "";
  for (let r = 0; r < e.length; r++)
    t += String.fromCharCode(e[r]);
  return btoa(t);
}
s(ws, "uint8ArrayToBase64");
function Rl(e) {
  let t = e.replace(/-/g, "+").replace(/_/g, "/"), r = "=".repeat((4 - t.length % 4) % 4);
  return xs(t + r);
}
s(Rl, "base64urlToUint8Array");
function Fl(e) {
  return ws(e).replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, "");
}
s(Fl, "uint8ArrayToBase64url");
function Ll(e) {
  let t = e.replace(/^0x/, "");
  if (t.length % 2 !== 0)
    throw new Error("Invalid hex string length");
  let r = new Uint8Array(t.length / 2);
  for (let n = 0; n < t.length; n += 2)
    r[n / 2] = Number.parseInt(t.slice(n, n + 2), 16);
  return r;
}
s(Ll, "hexToUint8Array");
function Dl(e) {
  return Array.from(e).map((t) => t.toString(16).padStart(2, "0")).join("");
}
s(Dl, "uint8ArrayToHex");
var un = class {
  static {
    s(this, "Class");
  }
  constructor(...t) {
  }
};
function wn(e, t) {
  for (let r in t) {
    let n = Object.getOwnPropertyDescriptor(t, r);
    n.get ? Object.defineProperty(e, r, { ...n, enumerable: !1 }) : Ml(e, r, n.value);
  }
}
s(wn, "members");
function Ie(e, t, r, n = !0) {
  return Object.defineProperty(e, t, { configurable: !0, writable: !0, enumerable: n, value: r }), r;
}
s(Ie, "own");
function vn(e, t, r) {
  return Ie(e, t, r, !1);
}
s(vn, "hide");
function Ml(e, t, r) {
  Object.defineProperty(e, t, {
    configurable: !0,
    get() {
      return this == null ? r : Ie(this, t, r.bind(this));
    },
    set(n) {
      Ie(this, t, n);
    }
  });
}
s(Ml, "defineBound");
function Ul(e, t) {
  let r = Object.getPrototypeOf(e);
  return t in r ? void 0 : r;
}
s(Ul, "claim");
var an, ue = !1, Bl = {
  configurable: !0,
  get() {
    ue = !0;
  }
};
function $(e, t, r) {
  let n = Object.getPrototypeOf(e._zod);
  if (t in n && an !== e._zod) {
    an = void 0;
    return;
  }
  an = e._zod, Object.defineProperty(n, t, {
    configurable: !0,
    get() {
      Object.defineProperty(this, t, Bl);
      let o = ue;
      ue = !1;
      try {
        let i = r(this);
        return ue ? delete this[t] : Object.defineProperty(this, t, { configurable: !0, writable: !0, value: i }), ue = ue || o, i;
      } catch (i) {
        throw delete this[t], ue = ue || o, i;
      }
    },
    set(o) {
      Object.defineProperty(this, t, { configurable: !0, writable: !0, value: o });
    }
  });
}
s($, "defineLazyInternal");
function Jl(e, t, r, n) {
  let o = Ul(e, t);
  o && Object.defineProperty(o, t, {
    configurable: !0,
    get() {
      let i = { configurable: !0, writable: !0, enumerable: n, value: void 0 };
      return Object.defineProperty(this, t, i), i.value = r(this), Object.defineProperty(this, t, i), i.value;
    },
    set(i) {
      Object.defineProperty(this, t, { configurable: !0, writable: !0, enumerable: n, value: i });
    }
  });
}
s(Jl, "installLazyProp");
var vs = "~constantCatch";
function zs(e) {
  let t = /* @__PURE__ */ s(() => e, "fn");
  return t[vs] = !0, t;
}
s(zs, "constantCatch");

// versions/4.5.4/node_modules/zod/v4/core/core.js
var $s;
var zn = { value: void 0, enumerable: !1 }, ks = "captureStackTrace" in Error ? Error : null;
function Vl(e) {
  let t = ks;
  if (t) {
    let r = t.stackTraceLimit;
    if (typeof r == "number") {
      try {
        t.stackTraceLimit = 0;
      } catch {
        return ks = null, new e();
      }
      try {
        return new e();
      } finally {
        t.stackTraceLimit = r;
      }
    }
  }
  return new e();
}
s(Vl, "newError");
// @__NO_SIDE_EFFECTS__
function f(e, t, r, n) {
  let o = {};
  function i(h) {
    this.def = h, this.constr = m, this.traits = /* @__PURE__ */ new Set();
  }
  s(i, "Internals"), i.prototype = o;
  let c = r, a = c && /* @__PURE__ */ new WeakSet();
  function u(h, g) {
    if (!h._zod) {
      zn.value = new i(g);
      try {
        Object.defineProperty(h, "_zod", zn);
      } finally {
        zn.value = void 0;
      }
    }
    if (h._zod.traits.has(e))
      return;
    if (h._zod.traits.add(e), t(h, g), a) {
      let x = Object.getPrototypeOf(h), w = h._zod.constr.prototype, j = x;
      for (; j && j !== w; )
        j = Object.getPrototypeOf(j);
      let R = j ?? x;
      a.has(R) || (a.add(R), wn(R, c));
    }
    let y = m.prototype;
    for (let x in y)
      Object.prototype.hasOwnProperty.call(y, x) && (x in h || (h[x] = y[x].bind(h)));
  }
  s(u, "init");
  let l = n?.Parent ?? Object;
  class p extends l {
    static {
      s(this, "Definition");
    }
  }
  Object.defineProperty(p, "name", { value: e });
  function m(h) {
    let g = n?.Parent ? Vl(p) : this;
    u(g, h);
    let y = g._zod.deferred;
    if (y) {
      for (let w of y)
        w();
      g._zod.deferred = void 0;
    }
    let x = globalThis.__zod_globalConfig?.postProcessor;
    return x && x(g), g;
  }
  return s(m, "_"), Object.defineProperty(m, "init", { value: u }), Object.defineProperty(m, Symbol.hasInstance, {
    value: /* @__PURE__ */ s((h) => n?.Parent && h instanceof n.Parent ? !0 : h?._zod?.traits?.has(e), "value")
  }), Object.defineProperty(m, "name", { value: e }), m;
}
s(f, "$constructor");
var se = class extends Error {
  static {
    s(this, "$ZodAsyncError");
  }
  constructor() {
    super("Encountered Promise during synchronous parse. Use .parseAsync() instead.");
  }
}, Te = class extends Error {
  static {
    s(this, "$ZodEncodeError");
  }
  constructor(t) {
    super(`Encountered unidirectional transform during encode: ${t}`), this.name = "ZodEncodeError";
  }
};
($s = globalThis).__zod_globalConfig ?? ($s.__zod_globalConfig = {});
var B = globalThis.__zod_globalConfig;
function q(e) {
  return e && Object.assign(B, e), B;
}
s(q, "config");

// versions/4.5.4/node_modules/zod/v4/core/errors.js
function ql() {
  let e = this._zod;
  return e.message ?? (e.message = JSON.stringify(e.def, Ee, 2)), e.message;
}
s(ql, "_getMessage");
function Wl(e) {
  this._zod.message = e;
}
s(Wl, "_setMessage");
var Gl = {
  get: ql,
  set: Wl,
  enumerable: !0,
  configurable: !0
}, kn = { value: void 0, enumerable: !1 }, Sn = { value: void 0, enumerable: !1 }, Ss = /* @__PURE__ */ new WeakSet([Object.prototype, Error.prototype]), Os = /* @__PURE__ */ s((e, t) => {
  e.name = "$ZodError", kn.value = e._zod, Object.defineProperty(e, "_zod", kn), Sn.value = t, Object.defineProperty(e, "issues", Sn), kn.value = void 0, Sn.value = void 0, Object.defineProperty(e, "message", Gl);
  let r = Object.getPrototypeOf(e);
  Ss.has(r) || (Ss.add(r), Object.defineProperty(r, "toString", {
    configurable: !0,
    enumerable: !1,
    get() {
      let n = /* @__PURE__ */ s(() => this.message, "value");
      return Object.defineProperty(this, "toString", { value: n, configurable: !0, writable: !0 }), n;
    },
    set(n) {
      Object.defineProperty(this, "toString", { value: n, configurable: !0, writable: !0 });
    }
  }));
}, "initializer"), Bt = f("$ZodError", Os), Xe = f("$ZodError", Os, void 0, {
  Parent: Error
});
function Kl(e, t, r) {
  return Object.prototype.hasOwnProperty.call(e, t) || (t === "__proto__" ? Object.defineProperty(e, t, { value: r(), writable: !0, enumerable: !0, configurable: !0 }) : e[t] = r()), e[t];
}
s(Kl, "node");
function Ps(e, t = (r) => r.message) {
  let r = {}, n = [];
  for (let o of e.issues)
    o.path.length > 0 ? Kl(r, o.path[0], () => []).push(t(o)) : n.push(t(o));
  return { formErrors: n, fieldErrors: r };
}
s(Ps, "flattenError");
function Zs(e, t = (r) => r.message) {
  let r = { _errors: [] }, n = /* @__PURE__ */ s((o, i = []) => {
    for (let c of o.issues)
      if (c.code === "invalid_union" && c.errors.length)
        c.errors.map((a) => n({ issues: a }, [...i, ...c.path]));
      else if (c.code === "invalid_key")
        n({ issues: c.issues }, [...i, ...c.path]);
      else if (c.code === "invalid_element")
        n({ issues: c.issues }, [...i, ...c.path]);
      else {
        let a = [...i, ...c.path];
        if (a.length === 0)
          r._errors.push(t(c));
        else {
          let u = r, l = 0;
          for (; l < a.length; ) {
            let p = a[l], m = l === a.length - 1;
            if (p === "_errors") {
              m && u._errors.push(t(c)), l++;
              continue;
            }
            Object.prototype.hasOwnProperty.call(u, p) || Object.defineProperty(u, p, {
              value: { _errors: [] },
              enumerable: !0,
              writable: !0,
              configurable: !0
            });
            let h = u[p];
            m && h._errors.push(t(c)), u = h, l++;
          }
        }
      }
  }, "processError");
  return n(e), r;
}
s(Zs, "formatError");

// versions/4.5.4/node_modules/zod/v4/core/parse.js
function Jt(e, t) {
  return { callee: t?.callee ?? e, Err: t?.Err };
}
s(Jt, "finalizeParams");
var et = /* @__PURE__ */ s((e) => {
  let t = /* @__PURE__ */ s((r, n, o, i) => {
    let c = o ? { ...o, async: !1 } : { async: !1 }, a = r._zod.run({ value: n, issues: [] }, c);
    if (a instanceof Promise)
      throw new se();
    if (a.issues.length) {
      let u = new (i?.Err ?? e)(a.issues.map((l) => K(l, c, q())));
      throw Dt(u, i?.callee ?? t), u;
    }
    return a.value;
  }, "fn");
  return t;
}, "_parse"), On = /* @__PURE__ */ et(Xe), tt = /* @__PURE__ */ s((e) => {
  let t = /* @__PURE__ */ s(async (r, n, o, i) => {
    let c = o ? { ...o, async: !0 } : { async: !0 }, a = r._zod.run({ value: n, issues: [] }, c);
    if (a instanceof Promise && (a = await a), a.issues.length) {
      let u = new (i?.Err ?? e)(a.issues.map((l) => K(l, c, q())));
      throw Dt(u, i?.callee ?? t), u;
    }
    return a.value;
  }, "fn");
  return t;
}, "_parseAsync"), Pn = /* @__PURE__ */ tt(Xe), rt = /* @__PURE__ */ s((e) => (t, r, n) => {
  let o = n ? { ...n, async: !1 } : { async: !1 }, i = t._zod.run({ value: r, issues: [] }, o);
  if (i instanceof Promise)
    throw new se();
  return i.issues.length ? {
    success: !1,
    error: new (e ?? Bt)(i.issues.map((c) => K(c, o, q())))
  } : { success: !0, data: i.value };
}, "_safeParse"), Is = /* @__PURE__ */ rt(Xe), nt = /* @__PURE__ */ s((e) => async (t, r, n) => {
  let o = n ? { ...n, async: !0 } : { async: !0 }, i = t._zod.run({ value: r, issues: [] }, o);
  return i instanceof Promise && (i = await i), i.issues.length ? {
    success: !1,
    error: new e(i.issues.map((c) => K(c, o, q())))
  } : { success: !0, data: i.value };
}, "_safeParseAsync"), Es = /* @__PURE__ */ nt(Xe);
var As = /* @__PURE__ */ s((e) => {
  let t = et(e), r = /* @__PURE__ */ s((n, o, i, c) => {
    let a = i ? { ...i, direction: "backward" } : { direction: "backward" };
    return t(n, o, a, Jt(r, c));
  }, "fn");
  return r;
}, "_encode");
var Ts = /* @__PURE__ */ s((e) => {
  let t = et(e), r = /* @__PURE__ */ s((n, o, i, c) => t(n, o, i, Jt(r, c)), "fn");
  return r;
}, "_decode");
var Cs = /* @__PURE__ */ s((e) => {
  let t = tt(e), r = /* @__PURE__ */ s(async (n, o, i, c) => {
    let a = i ? { ...i, direction: "backward" } : { direction: "backward" };
    return await t(n, o, a, Jt(r, c));
  }, "fn");
  return r;
}, "_encodeAsync");
var Ns = /* @__PURE__ */ s((e) => {
  let t = tt(e), r = /* @__PURE__ */ s(async (n, o, i, c) => await t(n, o, i, Jt(r, c)), "fn");
  return r;
}, "_decodeAsync");
var js = /* @__PURE__ */ s((e) => (t, r, n) => {
  let o = n ? { ...n, direction: "backward" } : { direction: "backward" };
  return rt(e)(t, r, o);
}, "_safeEncode");
var Rs = /* @__PURE__ */ s((e) => (t, r, n) => rt(e)(t, r, n), "_safeDecode");
var Fs = /* @__PURE__ */ s((e) => async (t, r, n) => {
  let o = n ? { ...n, direction: "backward" } : { direction: "backward" };
  return nt(e)(t, r, o);
}, "_safeEncodeAsync");
var Ls = /* @__PURE__ */ s((e) => async (t, r, n) => nt(e)(t, r, n), "_safeDecodeAsync");

// versions/4.5.4/node_modules/zod/v4/core/regexes.js
var Ds = /^[cC][0-9a-z]{6,}$/, Ms = /^[0-9a-z]+$/, Us = /^[0-7][0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{25}$/, Bs = /^[0-9a-vA-V]{20}$/, Js = /^[A-Za-z0-9]{27}$/, Vs = /^[a-zA-Z0-9_-]{21}$/;
function qs(e) {
  return new RegExp(`^[a-zA-Z0-9_-]{${e}}$`);
}
s(qs, "nanoidOfLength");
var Ws = /^P(?:(\d+W)|(?!.*W)(?=\d|T\d)(\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+([.,]\d+)?S)?)?)$/;
var Gs = /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/, In = /* @__PURE__ */ s((e) => e ? new RegExp(`^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${e}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`) : /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/, "uuid");
var Ks = /^(?!\.)(?!.*\.\.)([A-Za-z0-9_'+\-\.]*)[A-Za-z0-9_+-]@([A-Za-z0-9][A-Za-z0-9\-]*\.)+[A-Za-z]{2,}$/;
var Ql = "^[\\p{Extended_Pictographic}\\p{Emoji_Component}]+$";
function Hs() {
  return new RegExp(Ql, "u");
}
s(Hs, "emoji");
var Qs = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/, Ys = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))$/;
var Xs = /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/([0-9]|[1-2][0-9]|3[0-2])$/, ei = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/, ti = /^$|^(?:[0-9a-zA-Z+/]{4})*(?:(?:[0-9a-zA-Z+/]{2}==)|(?:[0-9a-zA-Z+/]{3}=))?$/, En = /^[A-Za-z0-9_-]*$/;
var ri = /^https?$/, ni = /^\+[1-9]\d{6,14}$/;
var oi = "(?:(?:\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-(?:(?:0[13578]|1[02])-(?:0[1-9]|[12]\\d|3[01])|(?:0[469]|11)-(?:0[1-9]|[12]\\d|30)|(?:02)-(?:0[1-9]|1\\d|2[0-8])))";
function Yl(e) {
  return new RegExp(`^${e}$`);
}
s(Yl, "anchor");
var si = /* @__PURE__ */ Yl(oi);
function Zn(e) {
  let t = "(?:[01]\\d|2[0-3]):[0-5]\\d";
  return typeof e.precision == "number" ? e.precision === -1 ? `${t}` : e.precision === 0 ? `${t}:[0-5]\\d` : `${t}:[0-5]\\d\\.\\d{${e.precision}}` : e.seconds ? `${t}:[0-5]\\d(?:\\.\\d+)?` : `${t}(?::[0-5]\\d(?:\\.\\d+)?)?`;
}
s(Zn, "timeSource");
function ii(e) {
  return new RegExp(`^${Zn(e)}$`);
}
s(ii, "time");
function ci(e) {
  let t = ["Z"];
  e.offset && t.push("([+-](?:[01]\\d|2[0-3]):[0-5]\\d)");
  let r = `${Zn({ precision: e.precision, seconds: !0 })}(?:${t.join("|")})`, n = e.local ? `${r}|${Zn({ precision: e.precision })}` : r;
  return new RegExp(`^${oi}T(?:${n})$`);
}
s(ci, "datetime");
var ai = /* @__PURE__ */ s((e) => {
  let t = e ? `[\\s\\S]{${e?.minimum ?? 0},${e?.maximum ?? ""}}` : "[\\s\\S]*";
  return new RegExp(`^${t}$`);
}, "string"), ui = /^-?\d+n?$/, li = /^-?\d+$/, An = /^-?\d+(?:\.\d+)?$/, pi = /^(?:true|false)$/i, fi = /^null$/i;
var di = /^undefined$/i;
var mi = /^[^A-Z]*$/, hi = /^[^a-z]*$/;

// versions/4.5.4/node_modules/zod/v4/core/checks.js
var J = /* @__PURE__ */ f("$ZodCheck", (e, t) => {
  var r;
  e._zod ?? (e._zod = {}), e._zod.def = t, (r = e._zod).onattach ?? (r.onattach = []);
});
var Tn = /* @__PURE__ */ s((e) => {
  let t = e.value;
  return !ln(t) && t.length !== void 0;
}, "_whenHasLength"), qt = {
  number: "number",
  bigint: "bigint",
  object: "date"
}, Cn = /* @__PURE__ */ f("$ZodCheckLessThan", (e, t) => {
  J.init(e, t);
  let r = qt[typeof t.value];
  e._zod.onattach.push((n) => {
    let o = n._zod.bag, i = (t.inclusive ? o.maximum : o.exclusiveMaximum) ?? Number.POSITIVE_INFINITY;
    t.value < i && (t.inclusive ? o.maximum = t.value : o.exclusiveMaximum = t.value);
  }), e._zod.check = (n) => {
    (t.inclusive ? n.value <= t.value : n.value < t.value) || n.issues.push({
      origin: qt[typeof n.value] ?? r,
      code: "too_big",
      maximum: typeof t.value == "object" ? t.value.getTime() : t.value,
      input: n.value,
      inclusive: t.inclusive,
      inst: e,
      continue: !t.abort
    });
  };
}), Nn = /* @__PURE__ */ f("$ZodCheckGreaterThan", (e, t) => {
  J.init(e, t);
  let r = qt[typeof t.value];
  e._zod.onattach.push((n) => {
    let o = n._zod.bag, i = (t.inclusive ? o.minimum : o.exclusiveMinimum) ?? Number.NEGATIVE_INFINITY;
    t.value > i && (t.inclusive ? o.minimum = t.value : o.exclusiveMinimum = t.value);
  }), e._zod.check = (n) => {
    (t.inclusive ? n.value >= t.value : n.value > t.value) || n.issues.push({
      origin: qt[typeof n.value] ?? r,
      code: "too_small",
      minimum: typeof t.value == "object" ? t.value.getTime() : t.value,
      input: n.value,
      inclusive: t.inclusive,
      inst: e,
      continue: !t.abort
    });
  };
}), gi = /* @__PURE__ */ f("$ZodCheckMultipleOf", (e, t) => {
  J.init(e, t), e._zod.onattach.push((r) => {
    var n;
    (n = r._zod.bag).multipleOf ?? (n.multipleOf = t.value);
  }), e._zod.check = (r) => {
    if (typeof r.value != typeof t.value)
      throw new Error("Cannot mix number and bigint in multiple_of check.");
    (typeof r.value == "bigint" ? (
      // `value % 0n` throws, and nothing is a multiple of zero — the number branch already fails this way via NaN
      t.value !== BigInt(0) && r.value % t.value === BigInt(0)
    ) : pn(r.value, t.value) === 0) || r.issues.push({
      origin: typeof r.value,
      code: "not_multiple_of",
      divisor: t.value,
      input: r.value,
      inst: e,
      continue: !t.abort
    });
  };
}), yi = /* @__PURE__ */ f("$ZodCheckNumberFormat", (e, t) => {
  J.init(e, t), t.format = t.format || "float64";
  let r = t.format?.includes("int"), n = r ? "int" : "number", [o, i] = _n[t.format];
  e._zod.onattach.push((c) => {
    let a = c._zod.bag;
    a.format = t.format, a.minimum = o, a.maximum = i, r && (a.pattern = li);
  }), e._zod.check = (c) => {
    let a = c.value;
    if (r) {
      if (!Number.isInteger(a)) {
        c.issues.push({
          expected: n,
          format: t.format,
          code: "invalid_type",
          continue: !1,
          input: a,
          inst: e
        });
        return;
      }
      if (!Number.isSafeInteger(a)) {
        a > 0 ? c.issues.push({
          input: a,
          code: "too_big",
          maximum: Number.MAX_SAFE_INTEGER,
          note: "Integers must be within the safe integer range.",
          inst: e,
          origin: n,
          inclusive: !0,
          continue: !t.abort
        }) : c.issues.push({
          input: a,
          code: "too_small",
          minimum: Number.MIN_SAFE_INTEGER,
          note: "Integers must be within the safe integer range.",
          inst: e,
          origin: n,
          inclusive: !0,
          continue: !t.abort
        });
        return;
      }
    }
    a < o && c.issues.push({
      origin: "number",
      input: a,
      code: "too_small",
      minimum: o,
      inclusive: !0,
      inst: e,
      continue: !t.abort
    }), a > i && c.issues.push({
      origin: "number",
      input: a,
      code: "too_big",
      maximum: i,
      inclusive: !0,
      inst: e,
      continue: !t.abort
    });
  };
});
var _i = /* @__PURE__ */ f("$ZodCheckMaxLength", (e, t) => {
  var r;
  J.init(e, t), (r = e._zod.def).when ?? (r.when = Tn), e._zod.onattach.push((n) => {
    let o = n._zod.bag.maximum ?? Number.POSITIVE_INFINITY;
    t.maximum < o && (n._zod.bag.maximum = t.maximum);
  }), e._zod.check = (n) => {
    let o = n.value, i = o.length;
    if ((typeof o == "string" && i > t.maximum ? Qe(o) : i) <= t.maximum)
      return;
    let a = Ye(o);
    n.issues.push({
      origin: a,
      code: "too_big",
      maximum: t.maximum,
      inclusive: !0,
      input: o,
      inst: e,
      continue: !t.abort
    });
  };
}), bi = /* @__PURE__ */ f("$ZodCheckMinLength", (e, t) => {
  var r;
  J.init(e, t), (r = e._zod.def).when ?? (r.when = Tn), e._zod.onattach.push((n) => {
    let o = n._zod.bag.minimum ?? Number.NEGATIVE_INFINITY;
    t.minimum > o && (n._zod.bag.minimum = t.minimum);
  }), e._zod.check = (n) => {
    let o = n.value, i = o.length;
    if ((typeof o == "string" && i >= t.minimum && i < t.minimum * 2 ? Qe(o) : i) >= t.minimum)
      return;
    let a = Ye(o);
    n.issues.push({
      origin: a,
      code: "too_small",
      minimum: t.minimum,
      inclusive: !0,
      input: o,
      inst: e,
      continue: !t.abort
    });
  };
}), xi = /* @__PURE__ */ f("$ZodCheckLengthEquals", (e, t) => {
  var r;
  J.init(e, t), (r = e._zod.def).when ?? (r.when = Tn), e._zod.onattach.push((n) => {
    let o = n._zod.bag;
    o.minimum = t.length, o.maximum = t.length, o.length = t.length;
  }), e._zod.check = (n) => {
    let o = n.value, i = o.length, c = typeof o == "string" && i >= t.length && i <= t.length * 2 ? Qe(o) : i;
    if (c === t.length)
      return;
    let a = Ye(o), u = c > t.length;
    n.issues.push({
      origin: a,
      ...u ? { code: "too_big", maximum: t.length } : { code: "too_small", minimum: t.length },
      inclusive: !0,
      exact: !0,
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), ot = /* @__PURE__ */ f("$ZodCheckStringFormat", (e, t) => {
  var r, n;
  J.init(e, t), e._zod.onattach.push((o) => {
    let i = o._zod.bag;
    i.format = t.format, t.pattern && (i.patterns ?? (i.patterns = /* @__PURE__ */ new Set()), i.patterns.add(t.pattern));
  }), t.pattern ? (r = e._zod).check ?? (r.check = (o) => {
    t.pattern.lastIndex = 0, !t.pattern.test(o.value) && o.issues.push({
      origin: "string",
      code: "invalid_format",
      format: t.format,
      input: o.value,
      ...t.pattern ? { pattern: t.pattern.toString() } : {},
      inst: e,
      continue: !t.abort
    });
  }) : (n = e._zod).check ?? (n.check = () => {
  });
}), wi = /* @__PURE__ */ f("$ZodCheckRegex", (e, t) => {
  ot.init(e, t), e._zod.check = (r) => {
    t.pattern.lastIndex = 0, !t.pattern.test(r.value) && r.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "regex",
      input: r.value,
      pattern: t.pattern.toString(),
      inst: e,
      continue: !t.abort
    });
  };
}), vi = /* @__PURE__ */ f("$ZodCheckLowerCase", (e, t) => {
  t.pattern ?? (t.pattern = mi), ot.init(e, t);
}), zi = /* @__PURE__ */ f("$ZodCheckUpperCase", (e, t) => {
  t.pattern ?? (t.pattern = hi), ot.init(e, t);
}), $i = /* @__PURE__ */ f("$ZodCheckIncludes", (e, t) => {
  J.init(e, t);
  let r = oe(t.includes), n = new RegExp(typeof t.position == "number" ? `^.{${t.position},}${r}` : r);
  t.pattern = n, e._zod.onattach.push((o) => {
    let i = o._zod.bag;
    i.patterns ?? (i.patterns = /* @__PURE__ */ new Set()), i.patterns.add(n);
  }), e._zod.check = (o) => {
    o.value.includes(t.includes, t.position) || o.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "includes",
      includes: t.includes,
      input: o.value,
      inst: e,
      continue: !t.abort
    });
  };
}), ki = /* @__PURE__ */ f("$ZodCheckStartsWith", (e, t) => {
  J.init(e, t);
  let r = new RegExp(`^${oe(t.prefix)}.*`);
  t.pattern ?? (t.pattern = r), e._zod.onattach.push((n) => {
    let o = n._zod.bag;
    o.patterns ?? (o.patterns = /* @__PURE__ */ new Set()), o.patterns.add(r);
  }), e._zod.check = (n) => {
    n.value.startsWith(t.prefix) || n.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "starts_with",
      prefix: t.prefix,
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Si = /* @__PURE__ */ f("$ZodCheckEndsWith", (e, t) => {
  J.init(e, t);
  let r = new RegExp(`.*${oe(t.suffix)}$`);
  t.pattern ?? (t.pattern = r), e._zod.onattach.push((n) => {
    let o = n._zod.bag;
    o.patterns ?? (o.patterns = /* @__PURE__ */ new Set()), o.patterns.add(r);
  }), e._zod.check = (n) => {
    n.value.endsWith(t.suffix) || n.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "ends_with",
      suffix: t.suffix,
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
});
var Oi = /* @__PURE__ */ f("$ZodCheckOverwrite", (e, t) => {
  J.init(e, t), e._zod.check = (r) => {
    r.value = t.tx(r.value);
  };
});

// versions/4.5.4/node_modules/zod/v4/core/doc.js
var Wt = class {
  static {
    s(this, "Doc");
  }
  constructor(t = [], r = {}) {
    this.content = [], this.indent = 0, this.args = t, this.closed = r;
  }
  indented(t) {
    this.indent += 1, t(this), this.indent -= 1;
  }
  write(t) {
    if (typeof t == "function") {
      t(this, { execution: "sync" }), t(this, { execution: "async" });
      return;
    }
    let n = t.split(`
`).filter((c) => c), o = Math.min(...n.map((c) => c.length - c.trimStart().length)), i = n.map((c) => c.slice(o)).map((c) => " ".repeat(this.indent * 2) + c);
    for (let c of i)
      this.content.push(c);
  }
  compile() {
    let t = Function, r = this?.content ?? [""];
    return new t(...Object.keys(this.closed), `return function (${this.args.join(", ")}) {
${r.join(`
`)}
};`)(...Object.values(this.closed));
  }
};

// versions/4.5.4/node_modules/zod/v4/core/versions.js
var Zi = {
  major: 4,
  minor: 5,
  patch: 4
};

// versions/4.5.4/node_modules/zod/v4/core/schemas.js
var z = /* @__PURE__ */ f("$ZodType", (e, t) => {
  var r;
  e ?? (e = {}), e._zod.def = t, e._zod.bag = e._zod.bag || {}, e._zod.version = Zi;
  let n = e._zod.def.checks, o = e._zod.traits.has("$ZodCheck") ? [e, ...n ?? []] : n?.length ? [...n] : [];
  for (let i of o)
    for (let c of i._zod.onattach)
      c(e);
  if (o.length === 0)
    (r = e._zod).deferred ?? (r.deferred = []), e._zod.deferred?.push(() => {
      e._zod.run = e._zod.parse;
    });
  else {
    let i = /* @__PURE__ */ s((a, u, l) => {
      if (a.memo)
        return a;
      let p = pe(a), m;
      for (let h of u) {
        if (h._zod.def.when) {
          if (bn(a) || !h._zod.def.when(a))
            continue;
        } else if (p)
          continue;
        let g = a.issues.length, y = h._zod.check(a);
        if (y instanceof Promise && l?.async === !1)
          throw new se();
        if (m || y instanceof Promise)
          m = (m ?? Promise.resolve()).then(async () => {
            await y, a.issues.length !== g && (Ut(a.issues, g, e), p || (p = pe(a, g)));
          });
        else {
          if (a.issues.length === g)
            continue;
          Ut(a.issues, g, e), p || (p = pe(a, g));
        }
      }
      return m ? m.then(() => a) : a;
    }, "runChecks"), c = /* @__PURE__ */ s((a, u, l) => {
      if (pe(a))
        return a.aborted = !0, a;
      let p = i(u, o, l);
      if (p instanceof Promise) {
        if (l.async === !1)
          throw new se();
        return p.then((m) => e._zod.parse(m, l));
      }
      return e._zod.parse(p, l);
    }, "handleCanaryResult");
    e._zod.run = (a, u) => {
      if (u.skipChecks)
        return e._zod.parse(a, u);
      if (u.direction === "backward") {
        let p = e._zod.parse({ value: a.value, issues: [] }, { ...u, skipChecks: !0 });
        return p instanceof Promise ? p.then((m) => c(m, a, u)) : c(p, a, u);
      }
      let l = e._zod.parse(a, u);
      if (l instanceof Promise) {
        if (u.async === !1)
          throw new se();
        return l.then((p) => i(p, o, u));
      }
      return i(l, o, u);
    };
  }
}, {
  // Wrappers extend this by installing a richer factory over it; reading it eagerly would defeat the laziness.
  get "~standard"() {
    return vn(this, "~standard", Rn(this));
  },
  set "~standard"(e) {
    Ie(this, "~standard", e);
  }
}), Ii = /* @__PURE__ */ s((e) => e.success ? { value: e.data } : { issues: e.error?.issues }, "toStandardResult");
function Rn(e) {
  return {
    validate: /* @__PURE__ */ s((t) => {
      try {
        return Ii(Is(e, t));
      } catch {
        return Es(e, t).then(Ii);
      }
    }, "validate"),
    vendor: "zod",
    version: 1
  };
}
s(Rn, "standardProps");
var Ce = /* @__PURE__ */ f("$ZodString", (e, t) => {
  z.init(e, t), e._zod.pattern = [...e?._zod.bag?.patterns ?? []].pop() ?? ai(e._zod.bag), e._zod.parse = (r, n) => {
    if (t.coerce)
      try {
        r.value = String(r.value);
      } catch {
      }
    return typeof r.value == "string" || r.issues.push({
      expected: "string",
      code: "invalid_type",
      input: r.value,
      inst: e
    }), r;
  };
}), I = /* @__PURE__ */ f("$ZodStringFormat", (e, t) => {
  ot.init(e, t), Ce.init(e, t);
}), qi = /* @__PURE__ */ f("$ZodGUID", (e, t) => {
  t.pattern ?? (t.pattern = Gs), I.init(e, t);
}), Wi = /* @__PURE__ */ f("$ZodUUID", (e, t) => {
  if (t.version) {
    let n = {
      v1: 1,
      v2: 2,
      v3: 3,
      v4: 4,
      v5: 5,
      v6: 6,
      v7: 7,
      v8: 8
    }[t.version];
    if (n === void 0)
      throw new Error(`Invalid UUID version: "${t.version}"`);
    t.pattern ?? (t.pattern = In(n));
  } else
    t.pattern ?? (t.pattern = In());
  I.init(e, t);
}), Gi = /* @__PURE__ */ f("$ZodEmail", (e, t) => {
  t.pattern ?? (t.pattern = Ks), I.init(e, t);
}), Ki = 1, Hi = 2;
function Xl(e, t) {
  if (!t.normalize && t.protocol?.source === ri.source && !/^https?:\/\//i.test(e))
    return Ki;
  try {
    return new URL(e);
  } catch {
    return Hi;
  }
}
s(Xl, "parseURLObject");
var ep = /[\t\n\r]/g;
function tp(e) {
  return e.replace(ep, "");
}
s(tp, "stripTabAndNewline");
function rp(e, t) {
  return t.lastIndex = 0, t.test(e.hostname);
}
s(rp, "urlHostnameOk");
function np(e, t) {
  return t.lastIndex = 0, t.test(e.protocol.endsWith(":") ? e.protocol.slice(0, -1) : e.protocol);
}
s(np, "urlProtocolOk");
var Qi = /* @__PURE__ */ f("$ZodURL", (e, t) => {
  I.init(e, t), e._zod.check = (r) => {
    try {
      let n = r.value.trim(), o = Xl(n, t);
      if (o === Ki) {
        r.issues.push({
          code: "invalid_format",
          format: "url",
          note: "Invalid URL format",
          input: r.value,
          inst: e,
          continue: !t.abort
        });
        return;
      }
      if (o === Hi) {
        r.issues.push({
          code: "invalid_format",
          format: "url",
          input: r.value,
          inst: e,
          continue: !t.abort
        });
        return;
      }
      t.hostname && !rp(o, t.hostname) && r.issues.push({
        code: "invalid_format",
        format: "url",
        note: "Invalid hostname",
        pattern: t.hostname.source,
        input: r.value,
        inst: e,
        continue: !t.abort
      }), t.protocol && !np(o, t.protocol) && r.issues.push({
        code: "invalid_format",
        format: "url",
        note: "Invalid protocol",
        pattern: t.protocol.source,
        input: r.value,
        inst: e,
        continue: !t.abort
      }), r.value = t.normalize ? o.href : tp(n);
      return;
    } catch {
      r.issues.push({
        code: "invalid_format",
        format: "url",
        input: r.value,
        inst: e,
        continue: !t.abort
      });
    }
  };
}), Yi = /* @__PURE__ */ f("$ZodEmoji", (e, t) => {
  t.pattern ?? (t.pattern = Hs()), I.init(e, t);
}), Xi = /* @__PURE__ */ f("$ZodNanoID", (e, t) => {
  if (t.length !== void 0 && (!Number.isInteger(t.length) || t.length < 1))
    throw new Error(`Invalid nanoid length: ${t.length}`);
  t.pattern ?? (t.pattern = t.length === void 0 ? Vs : qs(t.length)), I.init(e, t);
}), ec = /* @__PURE__ */ f("$ZodCUID", (e, t) => {
  t.pattern ?? (t.pattern = Ds), I.init(e, t);
}), tc = /* @__PURE__ */ f("$ZodCUID2", (e, t) => {
  t.pattern ?? (t.pattern = Ms), I.init(e, t);
}), rc = /* @__PURE__ */ f("$ZodULID", (e, t) => {
  t.pattern ?? (t.pattern = Us), I.init(e, t);
}), nc = /* @__PURE__ */ f("$ZodXID", (e, t) => {
  t.pattern ?? (t.pattern = Bs), I.init(e, t);
}), oc = /* @__PURE__ */ f("$ZodKSUID", (e, t) => {
  t.pattern ?? (t.pattern = Js), I.init(e, t);
}), sc = /* @__PURE__ */ f("$ZodISODateTime", (e, t) => {
  t.pattern ?? (t.pattern = ci(t)), I.init(e, t), (t.local || t.precision === -1) && (e._zod.bag.laxFormat = !0, e._zod.onattach.push((r) => {
    r._zod.bag.laxFormat = !0;
  }));
}), ic = /* @__PURE__ */ f("$ZodISODate", (e, t) => {
  t.pattern ?? (t.pattern = si), I.init(e, t);
}), cc = /* @__PURE__ */ f("$ZodISOTime", (e, t) => {
  t.pattern ?? (t.pattern = ii(t)), I.init(e, t);
}), ac = /* @__PURE__ */ f("$ZodISODuration", (e, t) => {
  t.pattern ?? (t.pattern = Ws), I.init(e, t);
}), uc = /* @__PURE__ */ f("$ZodIPv4", (e, t) => {
  t.pattern ?? (t.pattern = Qs), I.init(e, t), e._zod.bag.format = "ipv4";
}), op = /^[0-9a-fA-F:.]+$/;
function lc(e) {
  if (!op.test(e))
    return !1;
  try {
    return new URL(`http://[${e}]`), !0;
  } catch {
    return !1;
  }
}
s(lc, "isValidIPv6");
var pc = /* @__PURE__ */ f("$ZodIPv6", (e, t) => {
  t.pattern ?? (t.pattern = Ys), I.init(e, t), e._zod.bag.format = "ipv6", e._zod.check = (r) => {
    lc(r.value) || r.issues.push({
      code: "invalid_format",
      format: "ipv6",
      input: r.value,
      inst: e,
      continue: !t.abort
    });
  };
});
var fc = /* @__PURE__ */ f("$ZodCIDRv4", (e, t) => {
  t.pattern ?? (t.pattern = Xs), I.init(e, t);
});
function sp(e) {
  let t = e.split("/");
  if (t.length !== 2)
    return !1;
  let [r, n] = t;
  if (!n)
    return !1;
  let o = Number(n);
  return `${o}` !== n || o < 0 || o > 128 ? !1 : lc(r);
}
s(sp, "isValidCIDRv6");
var dc = /* @__PURE__ */ f("$ZodCIDRv6", (e, t) => {
  t.pattern ?? (t.pattern = ei), I.init(e, t), e._zod.check = (r) => {
    sp(r.value) || r.issues.push({
      code: "invalid_format",
      format: "cidrv6",
      input: r.value,
      inst: e,
      continue: !t.abort
    });
  };
});
function mc(e) {
  if (e === "")
    return !0;
  if (/\s/.test(e) || e.length % 4 !== 0)
    return !1;
  try {
    return atob(e), !0;
  } catch {
    return !1;
  }
}
s(mc, "isValidBase64");
var hc = /* @__PURE__ */ f("$ZodBase64", (e, t) => {
  t.pattern ?? (t.pattern = ti), I.init(e, t), e._zod.bag.contentEncoding = "base64", e._zod.check = (r) => {
    mc(r.value) || r.issues.push({
      code: "invalid_format",
      format: "base64",
      input: r.value,
      inst: e,
      continue: !t.abort
    });
  };
});
function ip(e) {
  if (!En.test(e))
    return !1;
  let t = e.replace(/[-_]/g, (n) => n === "-" ? "+" : "/"), r = t.padEnd(Math.ceil(t.length / 4) * 4, "=");
  return mc(r);
}
s(ip, "isValidBase64URL");
var gc = /* @__PURE__ */ f("$ZodBase64URL", (e, t) => {
  t.pattern ?? (t.pattern = En), I.init(e, t), e._zod.bag.contentEncoding = "base64url", e._zod.check = (r) => {
    ip(r.value) || r.issues.push({
      code: "invalid_format",
      format: "base64url",
      input: r.value,
      inst: e,
      continue: !t.abort
    });
  };
}), yc = /* @__PURE__ */ f("$ZodE164", (e, t) => {
  t.pattern ?? (t.pattern = ni), I.init(e, t);
});
function cp(e, t = null) {
  try {
    let r = e.split(".");
    if (r.length !== 3)
      return !1;
    let [n] = r;
    if (!n)
      return !1;
    let o = JSON.parse(atob(n));
    return !("typ" in o && o?.typ !== "JWT" || !o.alg || t && (!("alg" in o) || o.alg !== t));
  } catch {
    return !1;
  }
}
s(cp, "isValidJWT");
var _c = /* @__PURE__ */ f("$ZodJWT", (e, t) => {
  I.init(e, t), e._zod.check = (r) => {
    cp(r.value, t.alg) || r.issues.push({
      code: "invalid_format",
      format: "jwt",
      input: r.value,
      inst: e,
      continue: !t.abort
    });
  };
});
var st = /* @__PURE__ */ f("$ZodNumber", (e, t) => {
  z.init(e, t), e._zod.pattern = e._zod.bag.pattern ?? An, e._zod.parse = (r, n) => {
    if (t.coerce)
      try {
        r.value = Number(r.value);
      } catch {
      }
    let o = r.value;
    if (typeof o == "number" && !Number.isNaN(o) && Number.isFinite(o))
      return r;
    let i = typeof o == "number" ? Number.isNaN(o) ? "NaN" : Number.isFinite(o) ? void 0 : String(o) : void 0;
    return r.issues.push({
      expected: "number",
      code: "invalid_type",
      input: o,
      inst: e,
      ...i ? { received: i } : {}
    }), r;
  };
}), bc = /* @__PURE__ */ f("$ZodNumberFormat", (e, t) => {
  yi.init(e, t), st.init(e, t);
}), Yt = /* @__PURE__ */ f("$ZodBoolean", (e, t) => {
  z.init(e, t), e._zod.pattern = pi, e._zod.parse = (r, n) => {
    if (t.coerce)
      try {
        r.value = !!r.value;
      } catch {
      }
    let o = r.value;
    return typeof o == "boolean" || r.issues.push({
      expected: "boolean",
      code: "invalid_type",
      input: o,
      inst: e
    }), r;
  };
}), Fn = /* @__PURE__ */ f("$ZodBigInt", (e, t) => {
  z.init(e, t), e._zod.pattern = ui, e._zod.parse = (r, n) => {
    if (t.coerce)
      try {
        r.value = BigInt(r.value);
      } catch {
      }
    return typeof r.value == "bigint" || r.issues.push({
      expected: "bigint",
      code: "invalid_type",
      input: r.value,
      inst: e
    }), r;
  };
});
var Ln = /* @__PURE__ */ f("$ZodSymbol", (e, t) => {
  z.init(e, t), e._zod.parse = (r, n) => {
    let o = r.value;
    return typeof o == "symbol" || r.issues.push({
      expected: "symbol",
      code: "invalid_type",
      input: o,
      inst: e
    }), r;
  };
}), Dn = /* @__PURE__ */ f("$ZodUndefined", (e, t) => {
  z.init(e, t), e._zod.pattern = di, e._zod.values = /* @__PURE__ */ new Set([void 0]), e._zod.parse = (r, n) => {
    let o = r.value;
    return typeof o > "u" || r.issues.push({
      expected: "undefined",
      code: "invalid_type",
      input: o,
      inst: e
    }), r;
  };
}), Mn = /* @__PURE__ */ f("$ZodNull", (e, t) => {
  z.init(e, t), e._zod.pattern = fi, e._zod.values = /* @__PURE__ */ new Set([null]), e._zod.parse = (r, n) => {
    let o = r.value;
    return o === null || r.issues.push({
      expected: "null",
      code: "invalid_type",
      input: o,
      inst: e
    }), r;
  };
}), Un = /* @__PURE__ */ f("$ZodAny", (e, t) => {
  z.init(e, t), e._zod.parse = (r) => r;
}), Xt = /* @__PURE__ */ f("$ZodUnknown", (e, t) => {
  z.init(e, t), e._zod.parse = (r) => r;
}), er = /* @__PURE__ */ f("$ZodNever", (e, t) => {
  z.init(e, t), e._zod.parse = (r, n) => (r.issues.push({
    expected: "never",
    code: "invalid_type",
    input: r.value,
    inst: e
  }), r);
}), Bn = /* @__PURE__ */ f("$ZodVoid", (e, t) => {
  z.init(e, t), e._zod.parse = (r, n) => {
    let o = r.value;
    return typeof o > "u" || r.issues.push({
      expected: "void",
      code: "invalid_type",
      input: o,
      inst: e
    }), r;
  };
}), tr = /* @__PURE__ */ f("$ZodDate", (e, t) => {
  z.init(e, t), e._zod.parse = (r, n) => {
    if (t.coerce)
      try {
        r.value = new Date(r.value);
      } catch {
      }
    let o = r.value, i = o instanceof Date;
    return i && !Number.isNaN(o.getTime()) || r.issues.push({
      expected: "date",
      code: "invalid_type",
      input: o,
      ...i ? { received: "Invalid Date" } : {},
      inst: e
    }), r;
  };
});
function Ei(e, t, r) {
  e.issues.length && t.issues.push(...G(r, e.issues)), t.value[r] = e.value;
}
s(Ei, "handleArrayResult");
var rr = /* @__PURE__ */ f("$ZodArray", (e, t) => {
  z.init(e, t);
  let r = B.memoizer;
  r?.attach(e), e._zod.parse = (n, o) => {
    let i = n.value;
    if (!Array.isArray(i))
      return n.issues.push({
        expected: "array",
        code: "invalid_type",
        input: i,
        inst: e
      }), n;
    n.value = r ? r.alloc(e, n, Array(i.length), o) : Array(i.length);
    let c = [];
    for (let a = 0; a < i.length; a++) {
      let u = i[a], l = t.element._zod.run({
        value: u,
        issues: []
      }, o);
      l instanceof Promise ? c.push(l.then((p) => Ei(p, n, a))) : Ei(l, n, a);
    }
    return c.length ? Promise.all(c).then(() => n) : n;
  };
});
function Qt(e, t, r, n, o, i) {
  let c = r in n, a = i === "optional";
  if (!(!c && a && o === "optional")) {
    if (e.issues.length) {
      if (o !== void 0 && a && !c)
        return;
      t.issues.push(...G(r, e.issues));
    }
    if (!c && o === void 0) {
      e.issues.length || t.issues.push({
        code: "invalid_type",
        expected: "nonoptional",
        input: void 0,
        path: [r]
      });
      return;
    }
    e.value === void 0 ? c && (t.value[r] = void 0) : t.value[r] = e.value;
  }
}
s(Qt, "handlePropertyResult");
var ap = [];
function xc(e) {
  let t = Object.keys(e.shape), r = Object.getOwnPropertySymbols(e.shape), n = r.length ? r : ap, o = n.length ? [...t, ...n] : t;
  for (let c of o)
    if (!e.shape?.[c]?._zod?.traits?.has("$ZodType"))
      throw new Error(`Invalid element at key "${String(c)}": expected a Zod schema`);
  let i = yn(e.shape);
  return {
    ...e,
    allKeys: o,
    symbolKeys: n,
    // string-only: handleCatchall matches it against `for...in`, which never yields a symbol
    keySet: new Set(t),
    numKeys: t.length,
    optionalKeys: new Set(i)
  };
}
s(xc, "normalizeDef");
function wc(e, t, r, n, o, i) {
  let c = [], a = o.keySet, u = o.catchall._zod, l = u.def.type, p = u.optin, m = u.optout;
  for (let h in t) {
    if (a.has(h))
      continue;
    if (h === "__proto__") {
      l === "never" && c.push(h);
      continue;
    }
    if (l === "never") {
      c.push(h);
      continue;
    }
    let g = u.run({ value: t[h], issues: [] }, n);
    g instanceof Promise ? e.push(g.then((y) => Qt(y, r, h, t, p, m))) : Qt(g, r, h, t, p, m);
  }
  return c.length && r.issues.push({
    code: "unrecognized_keys",
    keys: c,
    input: t,
    inst: i,
    // Describes the shape of the input, not the validity of the parsed value, so it never aborts. The parse still fails; the schema's own checks just get to run first, and an enclosing intersection can reconcile the key against a sibling operand.
    continue: !0
  }), e.length ? Promise.all(e).then(() => r) : r;
}
s(wc, "handleCatchall");
var Ai = /* @__PURE__ */ new WeakMap(), nr = /* @__PURE__ */ f("$ZodObject", (e, t) => {
  if (z.init(e, t), !Object.getOwnPropertyDescriptor(t, "shape")?.get) {
    let u = t.shape;
    Ai.set(t, u), Object.defineProperty(t, "shape", {
      get: /* @__PURE__ */ s(() => {
        let l = { ...u };
        return Object.defineProperty(t, "shape", {
          value: l
        }), Ai.set(t, l), l;
      }, "get")
    });
  }
  let n = Ge(() => xc(t));
  $(e, "propValues", (u) => {
    let l = u.def.shape, p = {};
    for (let m in l) {
      let h = l[m]._zod;
      if (h.values) {
        Object.prototype.hasOwnProperty.call(p, m) || U(p, m, /* @__PURE__ */ new Set());
        for (let g of h.values)
          p[m].add(g);
        h.optin !== void 0 && p[m].add(void 0);
      }
    }
    return p;
  });
  let o = Ze, i = t.catchall, c, a = B.memoizer;
  a?.attach(e), e._zod.parse = (u, l) => {
    c ?? (c = n.value);
    let p = u.value;
    if (!o(p))
      return u.issues.push({
        expected: "object",
        code: "invalid_type",
        input: p,
        inst: e
      }), u;
    u.value = a ? a.alloc(e, u, {}, l) : {};
    let m = [], h = c.shape;
    for (let g of c.allKeys) {
      if (g === "__proto__")
        continue;
      let y = h[g], x = y._zod.optin, w = y._zod.optout, j = y._zod.run({ value: p[g], issues: [] }, l);
      j instanceof Promise ? m.push(j.then((R) => Qt(R, u, g, p, x, w))) : Qt(j, u, g, p, x, w);
    }
    return i ? wc(m, p, u, l, n.value, e) : m.length ? Promise.all(m).then(() => u) : u;
  };
}), vc = /* @__PURE__ */ f("$ZodObjectJIT", (e, t) => {
  nr.init(e, t);
  let r = e._zod.parse, n = Ge(() => xc(t)), o = B.memoizer, i = /* @__PURE__ */ s((g) => {
    let y = n.value, x = y.symbolKeys, w = new Wt(["payload", "ctx"], { shape: g, inst: e, memo: o, syms: x }), j = /* @__PURE__ */ s((L) => `shape[${L}]._zod.run({ value: input[${L}], issues: [] }, ctx)`, "parseStr"), R = /* @__PURE__ */ s((L, _) => `
          for (let i = 0; i < ${L}.issues.length; i++) {
            const iss = ${L}.issues[i];
            iss.path = iss.path ? [${_}, ...iss.path] : [${_}];
            payload.issues.push(iss);
          }`, "prefixStr");
    w.write("const input = payload.value;");
    let Q = /* @__PURE__ */ Object.create(null), ie = 0;
    for (let L of y.allKeys)
      Q[L] = `key_${ie++}`;
    w.write(o ? "const newResult = memo.alloc(inst, payload, {}, ctx);" : "const newResult = {};");
    for (let L of y.allKeys) {
      if (L === "__proto__")
        continue;
      let _ = Q[L], v = typeof L == "symbol" ? `syms[${x.indexOf(L)}]` : dn(L), T = `${v} in input`, ht = g[L], gt = ht?._zod?.optin, Eo = gt !== void 0, yu = ht?._zod?.optout === "optional";
      if (w.write(`const ${_} = ${j(v)};`), Eo && yu) {
        let _u = gt === "optional" ? `${_}_present` : `${_}.value !== undefined || ${_}_present`;
        w.write(`
        const ${_}_present = ${T};
        if (!${_}.issues.length || ${_}_present) {
          if (${_}.issues.length) {${R(_, v)}
          }

          if (${_u}) {
            newResult[${v}] = ${_}.value;
          }
        }

      `);
      } else Eo ? w.write(`
        if (${_}.issues.length) {${R(_, v)}
        }
        
        if (${_}.value === undefined) {
          if (${T}) {
            newResult[${v}] = undefined;
          }
        } else {
          newResult[${v}] = ${_}.value;
        }

      `) : w.write(`
        const ${_}_present = ${T};
        if (${_}.issues.length) {${R(_, v)}
        }
        if (!${_}_present && !${_}.issues.length) {
          payload.issues.push({
            code: "invalid_type",
            expected: "nonoptional",
            input: undefined,
            path: [${v}]
          });
        }

        if (${_}_present) {
          newResult[${v}] = ${_}.value;
        }

      `);
    }
    return w.write("payload.value = newResult;"), w.write("return payload;"), w.compile();
  }, "generateFastpass"), c, a = Ze, u = !B.jitless, p = u && hn.value, m = t.catchall, h;
  e._zod.parse = (g, y) => {
    h ?? (h = n.value);
    let x = g.value;
    return a(x) ? u && p && y?.async === !1 && y.jitless !== !0 ? (c || (c = i(t.shape)), g = c(g, y), m ? wc([], x, g, y, h, e) : g) : r(g, y) : (g.issues.push({
      expected: "object",
      code: "invalid_type",
      input: x,
      inst: e
    }), g);
  };
});
function Ti(e, t, r, n) {
  for (let i of e)
    if (i.issues.length === 0)
      return t.value = i.value, t;
  let o = e.filter((i) => !pe(i));
  return o.length === 1 ? (t.value = o[0].value, o[0]) : (t.issues.push({
    code: "invalid_union",
    input: t.value,
    inst: r,
    errors: e.map((i) => i.issues.map((c) => K(c, n, q())))
  }), t);
}
s(Ti, "handleUnionResults");
var or = /* @__PURE__ */ f("$ZodUnion", (e, t) => {
  z.init(e, t), $(e, "optin", (n) => n.def.options.some((o) => o._zod.optin === "defaulted") ? "defaulted" : n.def.options.some((o) => o._zod.optin !== void 0) ? "optional" : void 0), $(e, "optout", (n) => n.def.options.some((o) => o._zod.optout === "optional") ? "optional" : void 0), $(e, "values", (n) => {
    if (n.def.options.every((o) => o._zod.values))
      return new Set(n.def.options.flatMap((o) => Array.from(o._zod.values)));
  }), $(e, "pattern", (n) => {
    if (n.def.options.every((o) => o._zod.pattern)) {
      let o = n.def.options.map((i) => i._zod.pattern);
      return new RegExp(`^(${o.map((i) => Ke(i.source)).join("|")})$`);
    }
  });
  let r = t.options.length === 1 ? t.options[0]._zod.run : null;
  e._zod.parse = (n, o) => {
    if (r)
      return r(n, o);
    let i = !1, c = [];
    for (let a of t.options) {
      let u = a._zod.run({
        value: n.value,
        issues: []
      }, o);
      if (u instanceof Promise)
        c.push(u), i = !0;
      else {
        if (u.issues.length === 0)
          return u;
        c.push(u);
      }
    }
    return i ? Promise.all(c).then((a) => Ti(a, n, e, o)) : Ti(c, n, e, o);
  };
});
var sr = /* @__PURE__ */ f("$ZodIntersection", (e, t) => {
  z.init(e, t), e._zod.parse = (r, n) => {
    let o = r.value, i = t.left._zod.run({ value: o, issues: [] }, n), c = t.right._zod.run({ value: o, issues: [] }, n);
    return i instanceof Promise || c instanceof Promise ? Promise.all([i, c]).then(([u, l]) => Ci(r, u, l)) : Ci(r, i, c);
  };
});
function jn(e, t) {
  if (e === t)
    return { valid: !0, data: e };
  if (e instanceof Date && t instanceof Date && +e == +t)
    return { valid: !0, data: e };
  if (le(e) && le(t)) {
    let r = Object.keys(t), n = Object.keys(e).filter((i) => r.indexOf(i) !== -1), o = { ...e, ...t };
    Object.prototype.hasOwnProperty.call(o, "__proto__") && delete o.__proto__;
    for (let i of n) {
      if (i === "__proto__")
        continue;
      let c = jn(e[i], t[i]);
      if (!c.valid)
        return {
          valid: !1,
          mergeErrorPath: [i, ...c.mergeErrorPath]
        };
      o[i] = c.data;
    }
    return { valid: !0, data: o };
  }
  if (Array.isArray(e) && Array.isArray(t)) {
    if (e.length !== t.length)
      return { valid: !1, mergeErrorPath: [] };
    let r = [];
    for (let n = 0; n < e.length; n++) {
      let o = e[n], i = t[n], c = jn(o, i);
      if (!c.valid)
        return {
          valid: !1,
          mergeErrorPath: [n, ...c.mergeErrorPath]
        };
      r.push(c.data);
    }
    return { valid: !0, data: r };
  }
  return { valid: !1, mergeErrorPath: [] };
}
s(jn, "mergeValues");
function Ci(e, t, r) {
  let n = /* @__PURE__ */ new Map(), o, i = /* @__PURE__ */ new Map(), c = /* @__PURE__ */ s((l, p) => {
    let m;
    if (l.code === "unrecognized_keys" && !l.path?.length)
      o ?? (o = l), m = l.keys;
    else if (l.code === "invalid_key" && l.origin === "record" && l.path?.length === 1) {
      let h = String(l.path[0]);
      i.has(h) || i.set(h, l), m = [h];
    } else
      return !1;
    for (let h of m)
      n.has(h) || n.set(h, {}), n.get(h)[p] = !0;
    return !0;
  }, "collect");
  for (let l of t.issues)
    c(l, "l") || e.issues.push(l);
  for (let l of r.issues)
    c(l, "r") || e.issues.push(l);
  let a = [...n].filter(([, l]) => l.l && l.r).map(([l]) => l);
  if (a.length) {
    let l = o ? a.filter((p) => o.keys.includes(p)) : [];
    l.length && e.issues.push({ ...o, keys: l });
    for (let p of a)
      !l.includes(p) && i.has(p) && e.issues.push(i.get(p));
  }
  let u = jn(t.value, r.value);
  if (!u.valid) {
    if (pe(e))
      return e;
    throw new Error(`Unmergable intersection. Error path: ${JSON.stringify(u.mergeErrorPath)}`);
  }
  return e.value = u.data, e;
}
s(Ci, "handleIntersectionResults");
var ir = /* @__PURE__ */ f("$ZodTuple", (e, t) => {
  z.init(e, t);
  let r = t.items, n = B.memoizer;
  n?.attach(e), e._zod.parse = (o, i) => {
    let c = o.value;
    if (!Array.isArray(c))
      return o.issues.push({
        input: c,
        inst: e,
        expected: "tuple",
        code: "invalid_type"
      }), o;
    o.value = n ? n.alloc(e, o, [], i) : [];
    let a = [], u = Ni(r, "optin"), l = Ni(r, "optout");
    if (!t.rest) {
      if (c.length < u)
        return o.issues.push({
          code: "too_small",
          minimum: u,
          inclusive: !0,
          input: c,
          inst: e,
          origin: "array"
        }), o;
      c.length > r.length && o.issues.push({
        code: "too_big",
        maximum: r.length,
        inclusive: !0,
        input: c,
        inst: e,
        origin: "array"
      });
    }
    let p = new Array(r.length);
    for (let m = 0; m < r.length; m++) {
      let h = r[m]._zod.run({ value: c[m], issues: [] }, i);
      h instanceof Promise ? a.push(h.then((g) => {
        p[m] = g;
      })) : p[m] = h;
    }
    if (t.rest) {
      let m = r.length - 1, h = c.slice(r.length);
      for (let g of h) {
        m++;
        let y = t.rest._zod.run({ value: g, issues: [] }, i);
        y instanceof Promise ? a.push(y.then((x) => ji(x, o, m))) : ji(y, o, m);
      }
    }
    return a.length ? Promise.all(a).then(() => Ri(p, o, r, c, l)) : Ri(p, o, r, c, l);
  };
});
function Ni(e, t) {
  for (let r = e.length - 1; r >= 0; r--)
    if (!(t === "optin" ? e[r]._zod.optin !== void 0 : e[r]._zod.optout === "optional"))
      return r + 1;
  return 0;
}
s(Ni, "getTupleOptStart");
function ji(e, t, r) {
  e.issues.length && t.issues.push(...G(r, e.issues)), t.value[r] = e.value;
}
s(ji, "handleTupleResult");
function Ri(e, t, r, n, o) {
  for (let i = 0; i < r.length; i++) {
    let c = e[i], a = i < n.length;
    if (!a && i >= o && r[i]._zod.optin === "optional") {
      t.value.length = i;
      break;
    }
    if (c.issues.length) {
      if (!a && i >= o) {
        t.value.length = i;
        break;
      }
      t.issues.push(...G(i, c.issues));
    }
    t.value[i] = c.value;
  }
  for (let i = t.value.length - 1; i >= n.length && (r[i]._zod.optout === "optional" && t.value[i] === void 0); i--)
    t.value.length = i;
  return t;
}
s(Ri, "handleTupleResults");
var Jn = /* @__PURE__ */ f("$ZodRecord", (e, t) => {
  z.init(e, t);
  let r = B.memoizer;
  r?.attach(e), e._zod.parse = (n, o) => {
    let i = n.value;
    if (!le(i))
      return n.issues.push({
        expected: "record",
        code: "invalid_type",
        input: i,
        inst: e
      }), n;
    let c = [], a = t.keyType._zod.values;
    if (a && !t.partial) {
      n.value = r ? r.alloc(e, n, {}, o) : {};
      let u = /* @__PURE__ */ new Set();
      for (let p of a)
        if (typeof p == "string" || typeof p == "number" || typeof p == "symbol") {
          if (u.add(typeof p == "number" ? p.toString() : p), p === "__proto__")
            continue;
          let m = t.keyType._zod.run({ value: p, issues: [] }, o);
          if (m instanceof Promise)
            throw new Error("Async schemas not supported in object keys currently");
          if (m.issues.length) {
            n.issues.push({
              code: "invalid_key",
              origin: "record",
              issues: m.issues.map((y) => K(y, o, q())),
              input: p,
              path: [p],
              inst: e
            });
            continue;
          }
          let h = m.value;
          if (h === "__proto__")
            continue;
          let g = t.valueType._zod.run({ value: i[p], issues: [] }, o);
          g instanceof Promise ? c.push(g.then((y) => {
            y.issues.length && n.issues.push(...G(p, y.issues)), n.value[h] = y.value;
          })) : (g.issues.length && n.issues.push(...G(p, g.issues)), n.value[h] = g.value);
        }
      let l;
      for (let p in i)
        if (!u.has(p))
          if (t.mode === "loose") {
            if (p === "__proto__")
              continue;
            n.value[p] = i[p];
          } else
            l = l ?? [], l.push(p);
      l && l.length > 0 && n.issues.push({
        code: "unrecognized_keys",
        input: i,
        inst: e,
        keys: l,
        continue: !0
      });
    } else {
      n.value = r ? r.alloc(e, n, {}, o) : {};
      let u;
      for (let l of Reflect.ownKeys(i)) {
        if (l === "__proto__" || !Object.prototype.propertyIsEnumerable.call(i, l))
          continue;
        let p = t.keyType._zod.run({ value: l, issues: [] }, o);
        if (p instanceof Promise)
          throw new Error("Async schemas not supported in object keys currently");
        if (typeof l == "string" && An.test(l) && p.issues.length) {
          let y = t.keyType._zod.run({ value: Number(l), issues: [] }, o);
          if (y instanceof Promise)
            throw new Error("Async schemas not supported in object keys currently");
          y.issues.length === 0 && (p = y);
        }
        if (p.issues.length) {
          t.mode === "loose" ? n.value[l] = i[l] : a ? (u = u ?? [], u.push(l)) : n.issues.push({
            code: "invalid_key",
            origin: "record",
            issues: p.issues.map((y) => K(y, o, q())),
            input: l,
            path: [l],
            inst: e
          });
          continue;
        }
        let h = p.value;
        if (h === "__proto__")
          continue;
        let g = t.valueType._zod.run({ value: i[l], issues: [] }, o);
        g instanceof Promise ? c.push(g.then((y) => {
          y.issues.length && n.issues.push(...G(l, y.issues)), n.value[h] = y.value;
        })) : (g.issues.length && n.issues.push(...G(l, g.issues)), n.value[h] = g.value);
      }
      u && u.length > 0 && n.issues.push({
        code: "unrecognized_keys",
        input: i,
        inst: e,
        keys: u,
        continue: !0
      });
    }
    return c.length ? Promise.all(c).then(() => n) : n;
  };
}), Vn = /* @__PURE__ */ f("$ZodMap", (e, t) => {
  z.init(e, t);
  let r = B.memoizer;
  r?.attach(e), e._zod.parse = (n, o) => {
    let i = n.value;
    if (!(i instanceof Map))
      return n.issues.push({
        expected: "map",
        code: "invalid_type",
        input: i,
        inst: e
      }), n;
    let c = [];
    n.value = r ? r.alloc(e, n, /* @__PURE__ */ new Map(), o) : /* @__PURE__ */ new Map();
    for (let [a, u] of i) {
      let l = t.keyType._zod.run({ value: a, issues: [] }, o), p = t.valueType._zod.run({ value: u, issues: [] }, o);
      l instanceof Promise || p instanceof Promise ? c.push(Promise.all([l, p]).then(([m, h]) => {
        Fi(m, h, n, a, i, e, o);
      })) : Fi(l, p, n, a, i, e, o);
    }
    return c.length ? Promise.all(c).then(() => n) : n;
  };
});
function Fi(e, t, r, n, o, i, c) {
  e.issues.length && (He.has(typeof n) ? r.issues.push(...G(n, e.issues)) : r.issues.push({
    code: "invalid_key",
    origin: "map",
    input: o,
    inst: i,
    issues: e.issues.map((a) => K(a, c, q()))
  })), t.issues.length && (He.has(typeof n) ? r.issues.push(...G(n, t.issues)) : r.issues.push({
    origin: "map",
    code: "invalid_element",
    input: o,
    inst: i,
    key: n,
    issues: t.issues.map((a) => K(a, c, q()))
  })), r.value.set(e.value, t.value);
}
s(Fi, "handleMapResult");
var qn = /* @__PURE__ */ f("$ZodSet", (e, t) => {
  z.init(e, t);
  let r = B.memoizer;
  r?.attach(e), e._zod.parse = (n, o) => {
    let i = n.value;
    if (!(i instanceof Set))
      return n.issues.push({
        input: i,
        inst: e,
        expected: "set",
        code: "invalid_type"
      }), n;
    let c = [];
    n.value = r ? r.alloc(e, n, /* @__PURE__ */ new Set(), o) : /* @__PURE__ */ new Set();
    for (let a of i) {
      let u = t.valueType._zod.run({ value: a, issues: [] }, o);
      u instanceof Promise ? c.push(u.then((l) => Li(l, n))) : Li(u, n);
    }
    return c.length ? Promise.all(c).then(() => n) : n;
  };
});
function Li(e, t) {
  e.issues.length && t.issues.push(...e.issues), t.value.add(e.value);
}
s(Li, "handleSetResult");
var cr = /* @__PURE__ */ f("$ZodEnum", (e, t) => {
  z.init(e, t);
  let r = We(t.entries), n = new Set(r);
  e._zod.values = n;
  let o = r.filter((i) => He.has(typeof i));
  e._zod.pattern = new RegExp(o.length ? `^(${o.map((i) => oe(i.toString())).join("|")})$` : "^[^\\s\\S]$"), e._zod.parse = (i, c) => {
    let a = i.value;
    return n.has(a) || i.issues.push({
      code: "invalid_value",
      values: r,
      input: a,
      inst: e
    }), i;
  };
}), Wn = /* @__PURE__ */ f("$ZodLiteral", (e, t) => {
  z.init(e, t);
  let r = new Set(t.values);
  e._zod.values = r, e._zod.pattern = new RegExp(t.values.length ? `^(${t.values.map((n) => typeof n == "string" ? oe(n) : n ? oe(n.toString()) : String(n)).join("|")})$` : "^[^\\s\\S]$"), e._zod.parse = (n, o) => {
    let i = n.value;
    return r.has(i) || n.issues.push({
      code: "invalid_value",
      values: t.values,
      input: i,
      inst: e
    }), n;
  };
}), Gn = /* @__PURE__ */ f("$ZodFile", (e, t) => {
  z.init(e, t), e._zod.parse = (r, n) => {
    let o = r.value;
    return o instanceof File || r.issues.push({
      expected: "file",
      code: "invalid_type",
      input: o,
      inst: e
    }), r;
  };
}), ar = /* @__PURE__ */ f("$ZodTransform", (e, t) => {
  z.init(e, t), e._zod.optin = "optional", B.memoizer?.guard(e), e._zod.parse = (r, n) => {
    if (n.direction === "backward")
      throw new Te(e.constructor.name);
    let o = t.transform(r.value, r);
    if (n.async)
      return (o instanceof Promise ? o : Promise.resolve(o)).then((c) => (r.value = c, r));
    if (o instanceof Promise)
      throw new se();
    return r.value = o, r;
  };
});
function Di(e, t) {
  return e.value = t.issues.length ? void 0 : t.value, e;
}
s(Di, "handleOptionalResult");
var it = /* @__PURE__ */ f("$ZodOptional", (e, t) => {
  z.init(e, t), $(e, "optin", (r) => r.def.innerType._zod.optin === "defaulted" ? "defaulted" : "optional"), e._zod.optout = "optional", $(e, "values", (r) => {
    let n = r.def.innerType._zod.values;
    return n ? /* @__PURE__ */ new Set([...n, void 0]) : void 0;
  }), $(e, "pattern", (r) => {
    let n = r.def.innerType._zod.pattern;
    return n ? new RegExp(`^(${Ke(n.source)})?$`) : void 0;
  }), e._zod.parse = (r, n) => {
    if (r.value === void 0) {
      if (t.innerType._zod.optin !== "defaulted")
        return r;
      let o = t.innerType._zod.run({ value: r.value, issues: [] }, n);
      return o instanceof Promise ? o.then((i) => Di(r, i)) : Di(r, o);
    }
    return t.innerType._zod.run(r, n);
  };
}), zc = /* @__PURE__ */ f("$ZodExactOptional", (e, t) => {
  it.init(e, t), $(e, "values", (r) => r.def.innerType._zod.values), $(e, "pattern", (r) => r.def.innerType._zod.pattern), e._zod.parse = (r, n) => t.innerType._zod.run(r, n);
}), ur = /* @__PURE__ */ f("$ZodNullable", (e, t) => {
  z.init(e, t), $(e, "optin", (r) => r.def.innerType._zod.optin), $(e, "optout", (r) => r.def.innerType._zod.optout), $(e, "pattern", (r) => {
    let n = r.def.innerType._zod.pattern;
    return n ? new RegExp(`^(${Ke(n.source)}|null)$`) : void 0;
  }), $(e, "values", (r) => r.def.innerType._zod.values ? /* @__PURE__ */ new Set([...r.def.innerType._zod.values, null]) : void 0), e._zod.parse = (r, n) => r.value === null ? r : t.innerType._zod.run(r, n);
}), ct = /* @__PURE__ */ f("$ZodDefault", (e, t) => {
  z.init(e, t), e._zod.optin = "defaulted", $(e, "values", (r) => r.def.innerType._zod.values), e._zod.parse = (r, n) => {
    if (n.direction === "backward")
      return t.innerType._zod.run(r, n);
    if (r.value === void 0)
      return r.value = t.defaultValue, r;
    let o = t.innerType._zod.run(r, n);
    return o instanceof Promise ? o.then((i) => Mi(i, t)) : Mi(o, t);
  };
});
function Mi(e, t) {
  return e.value === void 0 && (e.value = t.defaultValue), e;
}
s(Mi, "handleDefaultResult");
var $c = /* @__PURE__ */ f("$ZodPrefault", (e, t) => {
  z.init(e, t), e._zod.optin = "defaulted", $(e, "values", (r) => r.def.innerType._zod.values), e._zod.parse = (r, n) => (n.direction === "backward" || r.value === void 0 && (r.value = t.defaultValue), t.innerType._zod.run(r, n));
}), lr = /* @__PURE__ */ f("$ZodNonOptional", (e, t) => {
  z.init(e, t), $(e, "values", (r) => {
    let n = r.def.innerType._zod.values;
    return n ? new Set([...n].filter((o) => o !== void 0)) : void 0;
  }), e._zod.parse = (r, n) => {
    let o = t.innerType._zod.run(r, n);
    return o instanceof Promise ? o.then((i) => Ui(i, e)) : Ui(o, e);
  };
});
function Ui(e, t) {
  return !e.issues.length && e.value === void 0 && e.issues.push({
    code: "invalid_type",
    expected: "nonoptional",
    input: e.value,
    inst: t
  }), e;
}
s(Ui, "handleNonOptionalResult");
function Bi(e, t, r, n) {
  return t.issues.length ? (e.value = r.catchValue({
    ...t,
    value: e.value,
    error: {
      issues: t.issues.map((o) => K(o, n, q()))
    },
    input: e.value
  }), e) : (e.value = t.value, t.memo && (e.memo = !0), e);
}
s(Bi, "handleCatchResult");
var pr = /* @__PURE__ */ f("$ZodCatch", (e, t) => {
  z.init(e, t), $(e, "optin", (r) => r.def.innerType._zod.optin === "defaulted" ? "defaulted" : "optional"), $(e, "optout", (r) => r.def.innerType._zod.optout), $(e, "values", (r) => r.def.innerType._zod.values), e._zod.parse = (r, n) => {
    if (n.direction === "backward")
      return t.innerType._zod.run(r, n);
    let o = t.innerType._zod.run({ value: r.value, issues: [] }, n);
    return o instanceof Promise ? o.then((i) => Bi(r, i, t, n)) : Bi(r, o, t, n);
  };
}), Kn = /* @__PURE__ */ f("$ZodNaN", (e, t) => {
  z.init(e, t), e._zod.parse = (r, n) => ((typeof r.value != "number" || !Number.isNaN(r.value)) && r.issues.push({
    input: r.value,
    inst: e,
    expected: "nan",
    code: "invalid_type"
  }), r);
}), at = /* @__PURE__ */ f("$ZodPipe", (e, t) => {
  z.init(e, t), $(e, "values", (r) => r.def.in._zod.values), $(e, "optin", (r) => r.def.in._zod.optin), $(e, "optout", (r) => r.def.out._zod.optout), $(e, "propValues", (r) => r.def.in._zod.propValues), e._zod.parse = (r, n) => {
    if (n.direction === "backward") {
      let i = t.out._zod.run(r, n);
      return i instanceof Promise ? i.then((c) => Gt(c, t.in, n)) : Gt(i, t.in, n);
    }
    let o = t.in._zod.run(r, n);
    return o instanceof Promise ? o.then((i) => Gt(i, t.out, n)) : Gt(o, t.out, n);
  };
});
function Gt(e, t, r) {
  return e.issues.some((n) => n.code !== "unrecognized_keys") ? (e.aborted = !0, e) : t._zod.run({ value: e.value, issues: e.issues }, r);
}
s(Gt, "handlePipeResult");
var kc = /* @__PURE__ */ f("$ZodCodec", (e, t) => {
  z.init(e, t), $(e, "values", (r) => r.def.in._zod.values), $(e, "optin", (r) => r.def.in._zod.optin), $(e, "optout", (r) => r.def.out._zod.optout), $(e, "propValues", (r) => r.def.in._zod.propValues), e._zod.parse = (r, n) => {
    if ((n.direction || "forward") === "forward") {
      let i = t.in._zod.run(r, n);
      return i instanceof Promise ? i.then((c) => Kt(c, t, n)) : Kt(i, t, n);
    } else {
      let i = t.out._zod.run(r, n);
      return i instanceof Promise ? i.then((c) => Kt(c, t, n)) : Kt(i, t, n);
    }
  };
});
function Kt(e, t, r) {
  if (e.issues.length)
    return e.aborted = !0, e;
  if ((r.direction || "forward") === "forward") {
    let o = t.transform(e.value, e);
    return o instanceof Promise ? o.then((i) => Ht(e, i, t.out, r)) : Ht(e, o, t.out, r);
  } else {
    let o = t.reverseTransform(e.value, e);
    return o instanceof Promise ? o.then((i) => Ht(e, i, t.in, r)) : Ht(e, o, t.in, r);
  }
}
s(Kt, "handleCodecAResult");
function Ht(e, t, r, n) {
  return e.issues.length ? (e.aborted = !0, e) : r._zod.run({ value: t, issues: e.issues }, n);
}
s(Ht, "handleCodecTxResult");
var fr = /* @__PURE__ */ f("$ZodReadonly", (e, t) => {
  z.init(e, t), $(e, "propValues", (r) => r.def.innerType._zod.propValues), $(e, "values", (r) => r.def.innerType._zod.values), $(e, "optin", (r) => r.def.innerType?._zod?.optin), $(e, "optout", (r) => r.def.innerType?._zod?.optout), e._zod.parse = (r, n) => {
    if (n.direction === "backward")
      return t.innerType._zod.run(r, n);
    let o = t.innerType._zod.run(r, n);
    return o instanceof Promise ? o.then(Ji) : Ji(o);
  };
});
function Ji(e) {
  return e.memo || (e.value = Object.freeze(e.value)), e;
}
s(Ji, "handleReadonlyResult");
var Hn = /* @__PURE__ */ f("$ZodTemplateLiteral", (e, t) => {
  z.init(e, t);
  let r = [];
  for (let n of t.parts)
    if (typeof n == "object" && n !== null) {
      if (!n._zod.pattern)
        throw new Error(`Invalid template literal part, no pattern found: ${[...n._zod.traits].shift()}`);
      let o = n._zod.pattern instanceof RegExp ? n._zod.pattern.source : n._zod.pattern;
      if (!o)
        throw new Error(`Invalid template literal part: ${n._zod.traits}`);
      let i = o.startsWith("^") ? 1 : 0, c = o.endsWith("$") ? o.length - 1 : o.length;
      r.push(o.slice(i, c));
    } else if (n === null || gn.has(typeof n))
      r.push(oe(`${n}`));
    else
      throw new Error(`Invalid template literal part: ${n}`);
  e._zod.pattern = new RegExp(`^${r.join("")}$`), e._zod.parse = (n, o) => typeof n.value != "string" ? (n.issues.push({
    input: n.value,
    inst: e,
    expected: "string",
    code: "invalid_type"
  }), n) : (e._zod.pattern.lastIndex = 0, e._zod.pattern.test(n.value) || n.issues.push({
    input: n.value,
    inst: e,
    code: "invalid_format",
    format: t.format ?? "template_literal",
    pattern: e._zod.pattern.source
  }), n);
}), Qn = /* @__PURE__ */ f("$ZodFunction", (e, t) => (z.init(e, t), Object.defineProperty(e, "_def", { value: t }), e._zod.def = t, e.implement = (r) => {
  if (typeof r != "function")
    throw new Error("implement() must be called with a function");
  return Object.defineProperty(function(...n) {
    let o = e._def.input ? On(e._def.input, n) : n, i = Reflect.apply(r, this, o);
    return e._def.output ? On(e._def.output, i) : i;
  }, "_zod", { value: e._zod, enumerable: !1 });
}, e.implementAsync = (r) => {
  if (typeof r != "function")
    throw new Error("implementAsync() must be called with a function");
  return Object.defineProperty(async function(...n) {
    let o = e._def.input ? await Pn(e._def.input, n) : n, i = await Reflect.apply(r, this, o);
    return e._def.output ? await Pn(e._def.output, i) : i;
  }, "_zod", { value: e._zod, enumerable: !1 });
}, e._zod.parse = (r, n) => typeof r.value != "function" ? (r.issues.push({
  code: "invalid_type",
  expected: "function",
  input: r.value,
  inst: e
}), r) : (e._def.output && e._def.output._zod.def.type === "promise" ? r.value = e.implementAsync(r.value) : r.value = e.implement(r.value), r), e.input = (...r) => {
  let n = e.constructor;
  return Array.isArray(r[0]) ? new n({
    type: "function",
    input: new ir({
      type: "tuple",
      items: r[0],
      rest: r[1]
    }),
    output: e._def.output
  }) : new n({
    type: "function",
    input: r[0],
    output: e._def.output
  });
}, e.output = (r) => {
  let n = e.constructor;
  return new n({
    type: "function",
    input: e._def.input,
    output: r
  });
}, e)), Yn = /* @__PURE__ */ f("$ZodPromise", (e, t) => {
  z.init(e, t), e._zod.parse = (r, n) => Promise.resolve(r.value).then((o) => t.innerType._zod.run({ value: o, issues: [] }, n));
}), Xn = /* @__PURE__ */ f("$ZodLazy", (e, t) => {
  z.init(e, t), fn(e._zod, "innerType", () => {
    let r = t;
    return r._cachedInner || (r._cachedInner = t.getter()), r._cachedInner;
  }), $(e, "pattern", (r) => r.innerType?._zod?.pattern), $(e, "propValues", (r) => r.innerType?._zod?.propValues), $(e, "optin", (r) => r.innerType?._zod?.optin ?? void 0), $(e, "optout", (r) => r.innerType?._zod?.optout ?? void 0), e._zod.parse = (r, n) => e._zod.innerType._zod.run(r, n);
}), dr = /* @__PURE__ */ f("$ZodCustom", (e, t) => {
  J.init(e, t), z.init(e, t), e._zod.parse = (r, n) => r, e._zod.check = (r) => {
    let n = r.value, o = t.fn(n);
    if (o instanceof Promise)
      return o.then((i) => Vi(i, r, n, e));
    Vi(o, r, n, e);
  };
});
function Vi(e, t, r, n) {
  if (!e) {
    let o = {
      code: "custom",
      input: r,
      inst: n,
      // incorporates params.error into issue reporting
      path: [...n._zod.def.path ?? []],
      // incorporates params.error into issue reporting
      continue: !n._zod.def.abort
      // params: inst._zod.def.params,
    };
    n._zod.def.params && (o.params = n._zod.def.params), t.issues.push(Ae(o));
  }
}
s(Vi, "handleRefineResult");

// versions/4.5.4/node_modules/zod/v4/core/memoizer.js
var to = class extends Error {
  static {
    s(this, "$ZodCyclicError");
  }
  constructor() {
    super("Cannot parse a reference cycle that closes through a transform"), this.name = "ZodCyclicError";
  }
}, ro = "~memo", Sc = [];
function eo(e) {
  return e.map((t) => t.path ? { ...t, path: t.path.slice() } : { ...t });
}
s(eo, "cloneIssues");
var Oc = /* @__PURE__ */ new WeakMap();
function Pc(e, t) {
  let r = Oc.get(e);
  if (r !== void 0)
    return r;
  if (t.has(e))
    return !0;
  t.add(e);
  let n = !1, o = /* @__PURE__ */ s((a) => {
    !n && a?._zod && Pc(a, t) && (n = !0);
  }, "check"), i = e._zod.def, c = i.type;
  switch (c) {
    case "object": {
      for (let a of Reflect.ownKeys(i.shape))
        o(i.shape[a]);
      o(i.catchall);
      break;
    }
    case "array":
      o(i.element);
      break;
    case "tuple":
      for (let a of i.items)
        o(a);
      o(i.rest);
      break;
    case "record":
    case "map":
      o(i.keyType), o(i.valueType);
      break;
    case "set":
      o(i.valueType);
      break;
    case "union":
      for (let a of i.options)
        o(a);
      break;
    case "intersection":
      o(i.left), o(i.right);
      break;
    case "optional":
    case "nullable":
    case "default":
    case "prefault":
    case "catch":
    case "readonly":
    case "nonoptional":
    case "promise":
    case "success":
      o(i.innerType);
      break;
    case "pipe":
      o(i.in), o(i.out);
      break;
    case "function":
      o(i.input), o(i.output);
      break;
    // reading `_zod.innerType` resolves the getter once and caches it
    case "lazy":
      o(e._zod.innerType);
      break;
    // a leaf by choice: `parts` are regex fragments, not data positions
    case "template_literal":
    // leaves
    case "string":
    case "number":
    case "int":
    case "boolean":
    case "bigint":
    case "symbol":
    case "undefined":
    case "null":
    case "void":
    case "never":
    case "any":
    case "unknown":
    case "date":
    case "nan":
    case "enum":
    case "literal":
    case "file":
    case "transform":
    case "custom":
      break;
    default:
      for (let a in i) {
        let u = Object.getOwnPropertyDescriptor(i, a);
        if (!u || u.get)
          continue;
        let l = u.value;
        if (!(!l || typeof l != "object")) {
          if (l._zod)
            o(l);
          else if (Array.isArray(l))
            for (let p of l)
              o(p);
        }
      }
  }
  return t.delete(e), Oc.set(e, n), n;
}
s(Pc, "isRecursive");
function up(e, t) {
  let r = e.buckets.get(t);
  return r || (r = /* @__PURE__ */ new Map(), e.buckets.set(t, r)), r;
}
s(up, "bucketFor");
var mr, hr = [], lp = {
  alloc(e, t, r) {
    let n = mr;
    if (!n)
      return r;
    mr = void 0;
    let o = { value: r, issues: null };
    return n.set(t.value, o), hr.push(o), r;
  },
  guard(e) {
    var t;
    (t = e._zod).deferred ?? (t.deferred = []), e._zod.deferred.push(() => {
      let r = e._zod.parse, n = /* @__PURE__ */ s((o, i) => {
        if (i.direction !== "backward" && pp(i, o.value))
          throw new to();
        return r(o, i);
      }, "wrapped");
      e._zod.parse = n, e._zod.run === r && (e._zod.run = n);
    });
  },
  attach(e) {
    var t;
    let r, n, o;
    (t = e._zod).deferred ?? (t.deferred = []), e._zod.deferred.push(() => {
      let i = e._zod.parse, c = /* @__PURE__ */ s((a, u) => {
        if (r === void 0 && (r = Pc(e, /* @__PURE__ */ new Set()), !r))
          return e._zod.parse = i, e._zod.run === c && (e._zod.run = i), i(a, u);
        let l = a.value;
        if (l === null || typeof l != "object")
          return i(a, u);
        let p = u[ro];
        p || (p = { buckets: /* @__PURE__ */ new Map(), backEdges: void 0 }, u[ro] = p);
        let m;
        n === u ? m = o : (m = up(p, e), n = u, o = m);
        let h = m.get(l);
        if (h)
          return a.value = h.value, h.issues ? h.issues.length && a.issues.push(...eo(h.issues)) : (a.memo = !0, p.backEdges ?? (p.backEdges = /* @__PURE__ */ new Set()), p.backEdges.add(h.value)), a;
        mr = m;
        let g = hr.length, y = i(a, u);
        mr = void 0;
        let x = hr.length > g ? hr.pop() : void 0;
        return y instanceof Promise ? y.then((w) => (x && (x.issues = w.issues.length ? eo(w.issues) : Sc), w)) : (x && (x.issues = y.issues.length ? eo(y.issues) : Sc), y);
      }, "wrapped");
      e._zod.parse = c, e._zod.run === i && (e._zod.run = c);
    });
  }
};
function Zc() {
  return lp;
}
s(Zc, "memoizer");
function pp(e, t) {
  let r = e[ro]?.backEdges;
  return r !== void 0 && t !== null && typeof t == "object" && r.has(t);
}
s(pp, "isBackEdge");

// versions/4.5.4/node_modules/zod/v4/locales/en.js
var fp = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "characters", verb: "to have" },
    file: { unit: "bytes", verb: "to have" },
    array: { unit: "items", verb: "to have" },
    set: { unit: "items", verb: "to have" },
    map: { unit: "entries", verb: "to have" }
  };
  function t(i) {
    return e[i] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "input",
    email: "email address",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datetime",
    date: "ISO date",
    time: "ISO time",
    duration: "ISO duration",
    ipv4: "IPv4 address",
    ipv6: "IPv6 address",
    mac: "MAC address",
    cidrv4: "IPv4 range",
    cidrv6: "IPv6 range",
    base64: "base64-encoded string",
    base64url: "base64url-encoded string",
    json_string: "JSON string",
    e164: "E.164 number",
    credit_card: "credit card number",
    jwt: "JWT",
    template_literal: "input"
  }, n = {
    // Compatibility: "nan" -> "NaN" for display
    nan: "NaN"
    // All other type names omitted - they fall back to raw values via ?? operator
  };
  function o(i, c) {
    return i === "number" && typeof c == "number" && !Number.isFinite(c) ? String(c) : n[i] ?? i;
  }
  return s(o, "getTypeName"), (i) => {
    switch (i.code) {
      case "invalid_type": {
        let c = o(i.expected), a = xn(i.input), u = o(a, i.input);
        return `Invalid input: expected ${c}, received ${u}`;
      }
      case "invalid_value":
        return i.values.length === 1 ? `Invalid input: expected ${Mt(i.values[0])}` : `Invalid option: expected one of ${Lt(i.values, "|")}`;
      case "too_big": {
        let c = i.exact ? "exactly " : i.inclusive ? "<=" : "<", a = t(i.origin);
        return a ? `Too big: expected ${i.origin ?? "value"} to have ${c}${i.maximum.toString()} ${a.unit ?? "elements"}` : `Too big: expected ${i.origin ?? "value"} to be ${c}${i.maximum.toString()}`;
      }
      case "too_small": {
        let c = i.exact ? "exactly " : i.inclusive ? ">=" : ">", a = t(i.origin);
        return a ? `Too small: expected ${i.origin} to have ${c}${i.minimum.toString()} ${a.unit}` : `Too small: expected ${i.origin} to be ${c}${i.minimum.toString()}`;
      }
      case "invalid_format": {
        let c = i;
        return c.format === "starts_with" ? `Invalid string: must start with "${c.prefix}"` : c.format === "ends_with" ? `Invalid string: must end with "${c.suffix}"` : c.format === "includes" ? `Invalid string: must include "${c.includes}"` : c.format === "regex" ? `Invalid string: must match pattern ${c.pattern}` : `Invalid ${r[c.format] ?? i.format}`;
      }
      case "not_multiple_of":
        return `Invalid number: must be a multiple of ${i.divisor}`;
      case "unrecognized_keys":
        return `Unrecognized key${i.keys.length > 1 ? "s" : ""}: ${Lt(i.keys, ", ")}`;
      case "invalid_key":
        return `Invalid key in ${i.origin}`;
      case "invalid_union":
        return i.options && Array.isArray(i.options) && i.options.length > 0 ? `Invalid discriminator value. Expected ${i.options.map((a) => `'${a}'`).join(" | ")}` : i.inclusive === !1 ? "Invalid input: more than one option matched" : "Invalid input";
      case "invalid_element":
        return `Invalid value in ${i.origin}`;
      default:
        return "Invalid input";
    }
  };
}, "error");
function no() {
  return {
    localeError: fp()
  };
}
s(no, "default");

// versions/4.5.4/node_modules/zod/v4/core/registries.js
var Ic;
var oo = class {
  static {
    s(this, "$ZodRegistry");
  }
  constructor() {
    this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map();
  }
  add(t, ...r) {
    let n = r[0];
    return this._map.set(t, n), n && typeof n == "object" && "id" in n && this._idmap.set(n.id, t), this;
  }
  clear() {
    return this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map(), this;
  }
  remove(t) {
    let r = this._map.get(t);
    return r && typeof r == "object" && "id" in r && this._idmap.delete(r.id), this._map.delete(t), this;
  }
  get(t) {
    let r = t._zod.parent;
    if (r) {
      let n = { ...this.get(r) ?? {} };
      delete n.id;
      let o = { ...n, ...this._map.get(t) };
      return Object.keys(o).length ? o : void 0;
    }
    return this._map.get(t);
  }
  has(t) {
    return this._map.has(t);
  }
};
function so() {
  return new oo();
}
s(so, "registry");
(Ic = globalThis).__zod_globalRegistry ?? (Ic.__zod_globalRegistry = so());
var _e = globalThis.__zod_globalRegistry;

// versions/4.5.4/node_modules/zod/v4/core/api.js
// @__NO_SIDE_EFFECTS__
function Ec(e, t) {
  return new e({
    type: "string",
    ...b(t)
  });
}
s(Ec, "_string");
// @__NO_SIDE_EFFECTS__
function Ac(e, t) {
  return new e({
    type: "string",
    format: "email",
    check: "string_format",
    abort: !1,
    ...b(t)
  });
}
s(Ac, "_email");
// @__NO_SIDE_EFFECTS__
function Tc(e, t) {
  return new e({
    type: "string",
    format: "guid",
    check: "string_format",
    abort: !1,
    ...b(t)
  });
}
s(Tc, "_guid");
// @__NO_SIDE_EFFECTS__
function Cc(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    ...b(t)
  });
}
s(Cc, "_uuid");
// @__NO_SIDE_EFFECTS__
function Nc(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v4",
    ...b(t)
  });
}
s(Nc, "_uuidv4");
// @__NO_SIDE_EFFECTS__
function jc(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v6",
    ...b(t)
  });
}
s(jc, "_uuidv6");
// @__NO_SIDE_EFFECTS__
function Rc(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v7",
    ...b(t)
  });
}
s(Rc, "_uuidv7");
// @__NO_SIDE_EFFECTS__
function Fc(e, t) {
  return new e({
    type: "string",
    format: "url",
    check: "string_format",
    abort: !1,
    ...b(t)
  });
}
s(Fc, "_url");
// @__NO_SIDE_EFFECTS__
function Lc(e, t) {
  return new e({
    type: "string",
    format: "emoji",
    check: "string_format",
    abort: !1,
    ...b(t)
  });
}
s(Lc, "_emoji");
// @__NO_SIDE_EFFECTS__
function Dc(e, t) {
  return new e({
    type: "string",
    format: "nanoid",
    check: "string_format",
    abort: !1,
    ...b(t)
  });
}
s(Dc, "_nanoid");
// @__NO_SIDE_EFFECTS__
function Mc(e, t) {
  return new e({
    type: "string",
    format: "cuid",
    check: "string_format",
    abort: !1,
    ...b(t)
  });
}
s(Mc, "_cuid");
// @__NO_SIDE_EFFECTS__
function Uc(e, t) {
  return new e({
    type: "string",
    format: "cuid2",
    check: "string_format",
    abort: !1,
    ...b(t)
  });
}
s(Uc, "_cuid2");
// @__NO_SIDE_EFFECTS__
function Bc(e, t) {
  return new e({
    type: "string",
    format: "ulid",
    check: "string_format",
    abort: !1,
    ...b(t)
  });
}
s(Bc, "_ulid");
// @__NO_SIDE_EFFECTS__
function Jc(e, t) {
  return new e({
    type: "string",
    format: "xid",
    check: "string_format",
    abort: !1,
    ...b(t)
  });
}
s(Jc, "_xid");
// @__NO_SIDE_EFFECTS__
function Vc(e, t) {
  return new e({
    type: "string",
    format: "ksuid",
    check: "string_format",
    abort: !1,
    ...b(t)
  });
}
s(Vc, "_ksuid");
// @__NO_SIDE_EFFECTS__
function qc(e, t) {
  return new e({
    type: "string",
    format: "ipv4",
    check: "string_format",
    abort: !1,
    ...b(t)
  });
}
s(qc, "_ipv4");
// @__NO_SIDE_EFFECTS__
function Wc(e, t) {
  return new e({
    type: "string",
    format: "ipv6",
    check: "string_format",
    abort: !1,
    ...b(t)
  });
}
s(Wc, "_ipv6");
// @__NO_SIDE_EFFECTS__
function Gc(e, t) {
  return new e({
    type: "string",
    format: "cidrv4",
    check: "string_format",
    abort: !1,
    ...b(t)
  });
}
s(Gc, "_cidrv4");
// @__NO_SIDE_EFFECTS__
function Kc(e, t) {
  return new e({
    type: "string",
    format: "cidrv6",
    check: "string_format",
    abort: !1,
    ...b(t)
  });
}
s(Kc, "_cidrv6");
// @__NO_SIDE_EFFECTS__
function Hc(e, t) {
  return new e({
    type: "string",
    format: "base64",
    check: "string_format",
    abort: !1,
    ...b(t)
  });
}
s(Hc, "_base64");
// @__NO_SIDE_EFFECTS__
function Qc(e, t) {
  return new e({
    type: "string",
    format: "base64url",
    check: "string_format",
    abort: !1,
    ...b(t)
  });
}
s(Qc, "_base64url");
// @__NO_SIDE_EFFECTS__
function Yc(e, t) {
  return new e({
    type: "string",
    format: "e164",
    check: "string_format",
    abort: !1,
    ...b(t)
  });
}
s(Yc, "_e164");
// @__NO_SIDE_EFFECTS__
function Xc(e, t) {
  return new e({
    type: "string",
    format: "jwt",
    check: "string_format",
    abort: !1,
    ...b(t)
  });
}
s(Xc, "_jwt");
// @__NO_SIDE_EFFECTS__
function ea(e, t) {
  return new e({
    type: "string",
    format: "datetime",
    check: "string_format",
    offset: !1,
    local: !1,
    precision: null,
    ...b(t)
  });
}
s(ea, "_isoDateTime");
// @__NO_SIDE_EFFECTS__
function ta(e, t) {
  return new e({
    type: "string",
    format: "date",
    check: "string_format",
    ...b(t)
  });
}
s(ta, "_isoDate");
// @__NO_SIDE_EFFECTS__
function ra(e, t) {
  return new e({
    type: "string",
    format: "time",
    check: "string_format",
    precision: null,
    ...b(t)
  });
}
s(ra, "_isoTime");
// @__NO_SIDE_EFFECTS__
function na(e, t) {
  return new e({
    type: "string",
    format: "duration",
    check: "string_format",
    ...b(t)
  });
}
s(na, "_isoDuration");
// @__NO_SIDE_EFFECTS__
function oa(e, t) {
  return new e({
    type: "number",
    checks: [],
    ...b(t)
  });
}
s(oa, "_number");
// @__NO_SIDE_EFFECTS__
function sa(e, t) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "safeint",
    ...b(t)
  });
}
s(sa, "_int");
// @__NO_SIDE_EFFECTS__
function ia(e, t) {
  return new e({
    type: "boolean",
    ...b(t)
  });
}
s(ia, "_boolean");
// @__NO_SIDE_EFFECTS__
function ca(e) {
  return new e({
    type: "unknown"
  });
}
s(ca, "_unknown");
// @__NO_SIDE_EFFECTS__
function aa(e, t) {
  return new e({
    type: "never",
    ...b(t)
  });
}
s(aa, "_never");
// @__NO_SIDE_EFFECTS__
function ua(e, t) {
  return new e({
    type: "date",
    ...b(t)
  });
}
s(ua, "_date");
// @__NO_SIDE_EFFECTS__
function gr(e, t) {
  return new Cn({
    check: "less_than",
    ...b(t),
    value: e,
    inclusive: !1
  });
}
s(gr, "_lt");
// @__NO_SIDE_EFFECTS__
function Ne(e, t) {
  return new Cn({
    check: "less_than",
    ...b(t),
    value: e,
    inclusive: !0
  });
}
s(Ne, "_lte");
// @__NO_SIDE_EFFECTS__
function yr(e, t) {
  return new Nn({
    check: "greater_than",
    ...b(t),
    value: e,
    inclusive: !1
  });
}
s(yr, "_gt");
// @__NO_SIDE_EFFECTS__
function je(e, t) {
  return new Nn({
    check: "greater_than",
    ...b(t),
    value: e,
    inclusive: !0
  });
}
s(je, "_gte");
// @__NO_SIDE_EFFECTS__
function _r(e, t) {
  return new gi({
    check: "multiple_of",
    ...b(t),
    value: e
  });
}
s(_r, "_multipleOf");
// @__NO_SIDE_EFFECTS__
function br(e, t) {
  return new _i({
    check: "max_length",
    ...b(t),
    maximum: e
  });
}
s(br, "_maxLength");
// @__NO_SIDE_EFFECTS__
function Re(e, t) {
  return new bi({
    check: "min_length",
    ...b(t),
    minimum: e
  });
}
s(Re, "_minLength");
// @__NO_SIDE_EFFECTS__
function xr(e, t) {
  return new xi({
    check: "length_equals",
    ...b(t),
    length: e
  });
}
s(xr, "_length");
// @__NO_SIDE_EFFECTS__
function io(e, t) {
  return new wi({
    check: "string_format",
    format: "regex",
    ...b(t),
    pattern: e
  });
}
s(io, "_regex");
// @__NO_SIDE_EFFECTS__
function co(e) {
  return new vi({
    check: "string_format",
    format: "lowercase",
    ...b(e)
  });
}
s(co, "_lowercase");
// @__NO_SIDE_EFFECTS__
function ao(e) {
  return new zi({
    check: "string_format",
    format: "uppercase",
    ...b(e)
  });
}
s(ao, "_uppercase");
// @__NO_SIDE_EFFECTS__
function uo(e, t) {
  return new $i({
    check: "string_format",
    format: "includes",
    ...b(t),
    includes: e
  });
}
s(uo, "_includes");
// @__NO_SIDE_EFFECTS__
function lo(e, t) {
  return new ki({
    check: "string_format",
    format: "starts_with",
    ...b(t),
    prefix: e
  });
}
s(lo, "_startsWith");
// @__NO_SIDE_EFFECTS__
function po(e, t) {
  return new Si({
    check: "string_format",
    format: "ends_with",
    ...b(t),
    suffix: e
  });
}
s(po, "_endsWith");
// @__NO_SIDE_EFFECTS__
function fe(e) {
  return new Oi({
    check: "overwrite",
    tx: e
  });
}
s(fe, "_overwrite");
// @__NO_SIDE_EFFECTS__
function fo(e) {
  return /* @__PURE__ */ fe((t) => t.normalize(e));
}
s(fo, "_normalize");
// @__NO_SIDE_EFFECTS__
function mo() {
  return /* @__PURE__ */ fe((e) => e.trim());
}
s(mo, "_trim");
// @__NO_SIDE_EFFECTS__
function ho() {
  return /* @__PURE__ */ fe((e) => e.toLowerCase());
}
s(ho, "_toLowerCase");
// @__NO_SIDE_EFFECTS__
function go() {
  return /* @__PURE__ */ fe((e) => e.toUpperCase());
}
s(go, "_toUpperCase");
// @__NO_SIDE_EFFECTS__
function yo() {
  return /* @__PURE__ */ fe((e) => mn(e));
}
s(yo, "_slugify");
// @__NO_SIDE_EFFECTS__
function la(e, t, r) {
  return new e({
    type: "array",
    element: t,
    // get element() {
    //   return element;
    // },
    ...b(r)
  });
}
s(la, "_array");
// @__NO_SIDE_EFFECTS__
function pa(e, t, r) {
  return new e({
    type: "custom",
    check: "custom",
    fn: t,
    ...b(r)
  });
}
s(pa, "_refine");
// @__NO_SIDE_EFFECTS__
function fa(e, t) {
  let r = /* @__PURE__ */ dp((n) => (n.addIssue = (o) => {
    if (typeof o == "string")
      n.issues.push(Ae(o, n.value, r._zod.def));
    else {
      let i = o;
      i.fatal && (i.continue = !1), i.code ?? (i.code = "custom"), "input" in i || (i.input = n.value), i.inst ?? (i.inst = r), i.continue ?? (i.continue = !r._zod.def.abort), n.issues.push(Ae(i));
    }
  }, e(n.value, n)), t);
  return r;
}
s(fa, "_superRefine");
// @__NO_SIDE_EFFECTS__
function dp(e, t) {
  let r = new J({
    check: "custom",
    ...b(t)
  });
  return r._zod.check = e, r;
}
s(dp, "_check");

// versions/4.5.4/node_modules/zod/v4/core/to-json-schema.js
function ut(e, ...t) {
  for (let r of t)
    for (let n of Reflect.ownKeys(r))
      Object.prototype.propertyIsEnumerable.call(r, n) && U(e, n, r[n]);
  return e;
}
s(ut, "assignProps");
function bo(e) {
  let t = e?.target ?? "draft-2020-12";
  return t === "draft-4" && (t = "draft-04"), t === "draft-7" && (t = "draft-07"), {
    processors: e.processors ?? {},
    metadataRegistry: e?.metadata ?? _e,
    target: t,
    unrepresentable: e?.unrepresentable ?? "throw",
    override: e?.override ?? (() => {
    }),
    io: e?.io ?? "output",
    counter: 0,
    seen: /* @__PURE__ */ new Map(),
    sharedDefsExtractedFor: void 0,
    sharedEmitDoneFor: void 0,
    cycles: e?.cycles ?? "ref",
    reused: e?.reused ?? "inline",
    intersections: [],
    deferred: [],
    external: e?.external ?? void 0
  };
}
s(bo, "initializeContext");
function de(e, t, r, n, o) {
  let i = typeof t.unrepresentable == "function" ? t.unrepresentable({ zodSchema: e, path: n.path, message: o }) : t.unrepresentable;
  if (i === "any")
    return !1;
  if (i === void 0 || i === "throw")
    throw new Error(o);
  return Object.assign(r, i), !0;
}
s(de, "handleUnrepresentable");
function M(e, t, r = { path: [], schemaPath: [] }) {
  var n;
  let o = e._zod.def, i = t.seen.get(e);
  if (i)
    return i.count++, r.schemaPath.includes(e) && (i.cycle = r.path), i.schema;
  let c = { schema: {}, count: 1, cycle: void 0, path: r.path };
  t.seen.set(e, c), t.sharedDefsExtractedFor = void 0, t.sharedEmitDoneFor = void 0;
  let a = e._zod.toJSONSchema?.();
  if (a)
    c.schema = a;
  else {
    let p = {
      ...r,
      schemaPath: [...r.schemaPath, e],
      path: r.path
    };
    if (e._zod.processJSONSchema)
      e._zod.processJSONSchema(t, c.schema, p);
    else {
      let h = c.schema, g = t.processors[o.type];
      if (!g)
        throw new Error(`[toJSONSchema]: Non-representable type encountered: ${o.type}`);
      g(e, t, h, p);
    }
    let m = e._zod.parent;
    m && (c.ref || (c.ref = m), M(m, t, p), t.seen.get(m).isParent = !0);
  }
  let u = t.metadataRegistry.get(e);
  return u && ut(c.schema, u), t.io === "input" && W(e) && (delete c.schema.examples, delete c.schema.default), t.io === "input" && "_prefault" in c.schema && ((n = c.schema).default ?? (n.default = c.schema._prefault)), delete c.schema._prefault, t.seen.get(e).schema;
}
s(M, "process");
function da(e) {
  return e.replace(/~/g, "~0").replace(/\//g, "~1");
}
s(da, "encodeJSONPointerSegment");
function xo(e, t) {
  let r = e.seen.get(t);
  if (!r)
    throw new Error("Unprocessed schema. This is a bug in Zod.");
  if (e.external && e.sharedDefsExtractedFor === e.external)
    return;
  let n = /* @__PURE__ */ new Map();
  for (let c of e.seen.entries()) {
    let a = e.metadataRegistry.get(c[0])?.id;
    if (a) {
      let u = n.get(a);
      if (u && u !== c[0])
        throw new Error(`Duplicate schema id "${a}" detected during JSON Schema conversion. Two different schemas cannot share the same id when converted together.`);
      n.set(a, c[0]);
    }
  }
  let o = /* @__PURE__ */ s((c) => {
    let a = e.target === "draft-2020-12" ? "$defs" : "definitions";
    if (e.external) {
      let m = e.external.registry.get(c[0])?.id, h = e.external.uri ?? ((y) => y);
      if (m)
        return { ref: h(m) };
      let g = c[1].defId ?? c[1].schema.id ?? `schema${e.counter++}`;
      return c[1].defId = g, { defId: g, ref: `${h("__shared")}#/${a}/${da(g)}` };
    }
    let u = "#", l = `${u}/${a}/`;
    if (c[1] === r && !c[1].schema.id)
      return { ref: u };
    let p = c[1].schema.id ?? `__schema${e.counter++}`;
    return { defId: p, ref: l + da(p) };
  }, "makeURI"), i = /* @__PURE__ */ s((c) => {
    if (c[1].schema.$ref)
      return;
    let a = c[1], { ref: u, defId: l } = o(c);
    a.def = { ...a.schema }, l && (a.defId = l);
    let p = a.schema;
    for (let m in p)
      delete p[m];
    p.$ref = u;
  }, "extractToDef");
  if (e.cycles === "throw")
    for (let c of e.seen.entries()) {
      let a = c[1];
      if (a.cycle)
        throw new Error(`Cycle detected: #/${a.cycle?.join("/")}/<root>

Set the \`cycles\` parameter to \`"ref"\` to resolve cyclical schemas with defs.`);
    }
  for (let c of e.seen.entries()) {
    let a = c[1];
    if (t === c[0]) {
      i(c);
      continue;
    }
    if (e.external) {
      let l = e.external.registry.get(c[0])?.id;
      if (t !== c[0] && l) {
        i(c);
        continue;
      }
    }
    if (e.metadataRegistry.get(c[0])?.id) {
      i(c);
      continue;
    }
    if (a.cycle) {
      i(c);
      continue;
    }
    if (a.count > 1 && e.reused === "ref") {
      i(c);
      continue;
    }
  }
  e.external && (e.sharedDefsExtractedFor = e.external);
}
s(xo, "extractDefs");
function ga(e) {
  let t = e.anyOf;
  if (!Array.isArray(t) || t.length === 0 || e.type !== void 0)
    return;
  let r = [];
  for (let n of t) {
    if (!n || typeof n != "object")
      return;
    ga(n);
    let o = Object.keys(n);
    if (o.length !== 1 || o[0] !== "type")
      return;
    let i = n.type;
    for (let c of Array.isArray(i) ? i : [i]) {
      if (typeof c != "string")
        return;
      r.includes(c) || r.push(c);
    }
  }
  delete e.anyOf, e.type = r.length === 1 ? r[0] : r;
}
s(ga, "compactTypeUnion");
var ya = /* @__PURE__ */ new Set(["type", "properties", "required", "additionalProperties"]), ma = ["oneOf", "anyOf"];
function ha(e) {
  let t = e.additionalProperties;
  return t === void 0 || t === !1 || typeof t != "object" || t === null ? null : Object.keys(t).length ? t : null;
}
s(ha, "undeclaredConstraint");
function _o(e) {
  let t = [];
  for (let i of e) {
    if (typeof i != "object" || i.type !== "object")
      return null;
    for (let c in i)
      if (!ya.has(c))
        return null;
    t.push(i);
  }
  let r = {}, n = /* @__PURE__ */ new Set();
  for (let i of t) {
    for (let c in i.properties) {
      if (Object.prototype.hasOwnProperty.call(r, c))
        continue;
      let a = [];
      for (let l of t) {
        let p = l.properties?.[c] ?? ha(l);
        p != null && (a.some((m) => JSON.stringify(m) === JSON.stringify(p)) || a.push(p));
      }
      let u = a.length === 1 ? a[0] : _o(a) ?? { allOf: a };
      U(r, c, u);
    }
    for (let c of i.required ?? [])
      n.add(c);
  }
  let o = { type: "object", properties: r };
  if (n.size && (o.required = [...n]), t.every((i) => i.additionalProperties === !1))
    o.additionalProperties = !1;
  else {
    let i = [];
    for (let c of t) {
      let a = ha(c);
      a && !i.some((u) => JSON.stringify(u) === JSON.stringify(a)) && i.push(a);
    }
    i.length === 1 ? o.additionalProperties = i[0] : i.length > 1 && (o.additionalProperties = { allOf: i });
  }
  return o;
}
s(_o, "foldObjects");
function mp(e) {
  let t = e.allOf;
  if (!Array.isArray(t) || t.length < 2)
    return;
  for (let o of ya)
    if (o in e)
      return;
  let r = t.filter((o) => ma.some((i) => Array.isArray(o[i]))), n = null;
  if (!r.length)
    n = _o(t);
  else {
    let o = r[0], i = ma.find((u) => Array.isArray(o[u]));
    if (Object.keys(o).length !== 1)
      return;
    let c = t.filter((u) => u !== o), a = o[i].map((u) => _o([...c, u]));
    if (a.some((u) => !u))
      return;
    n = { [i]: a };
  }
  n && (delete e.allOf, ut(e, n));
}
s(mp, "foldIntersection");
function wo(e, t) {
  let r = e.seen.get(t);
  if (!r)
    throw new Error("Unprocessed schema. This is a bug in Zod.");
  let n = /* @__PURE__ */ s((a) => {
    let u = e.seen.get(a);
    if (u.ref === null)
      return;
    let l = u.def ?? u.schema, p = { ...l }, m = u.ref;
    if (u.ref = null, m) {
      n(m);
      let g = e.seen.get(m), y = g.schema;
      if (y.$ref && (e.target === "draft-07" || e.target === "draft-04" || e.target === "openapi-3.0") ? (l.allOf = l.allOf ?? [], l.allOf.push(y)) : ut(l, y), ut(l, p), a._zod.parent === m)
        for (let w in l)
          w === "$ref" || w === "allOf" || w in p || delete l[w];
      if (y.$ref && g.def)
        for (let w in l)
          w === "$ref" || w === "allOf" || w in g.def && JSON.stringify(l[w]) === JSON.stringify(g.def[w]) && delete l[w];
    }
    let h = a._zod.parent;
    if (h && h !== m) {
      n(h);
      let g = e.seen.get(h);
      if (g?.schema.$ref && (l.$ref = g.schema.$ref, g.def))
        for (let y in l)
          y === "$ref" || y === "allOf" || y in g.def && JSON.stringify(l[y]) === JSON.stringify(g.def[y]) && delete l[y];
    }
    e.override({
      zodSchema: a,
      jsonSchema: l,
      path: u.path ?? []
    });
  }, "flattenRef");
  if (!e.external || e.sharedEmitDoneFor !== e.external) {
    for (let a of [...e.seen.entries()].reverse())
      n(a[0]);
    if (e.target !== "openapi-3.0")
      for (let a of e.seen.entries())
        ga(a[1].def ?? a[1].schema);
    for (let a of e.deferred)
      a();
    if (e.intersections.length) {
      let a = /* @__PURE__ */ new Map();
      for (let u of e.seen.values())
        for (let l of [u.schema, u.def]) {
          let p = l?.allOf;
          if (!Array.isArray(p))
            continue;
          let m = a.get(p);
          m ? m.push(l) : a.set(p, [l]);
        }
      for (let u of e.intersections)
        for (let l of a.get(u) ?? [])
          mp(l);
    }
  }
  let o = {};
  if (e.target === "draft-2020-12" ? o.$schema = "https://json-schema.org/draft/2020-12/schema" : e.target === "draft-07" ? o.$schema = "http://json-schema.org/draft-07/schema#" : e.target === "draft-04" ? o.$schema = "http://json-schema.org/draft-04/schema#" : e.target, e.external?.uri) {
    let a = e.external.registry.get(t)?.id;
    if (!a)
      throw new Error("Schema is missing an `id` property");
    o.$id = e.external.uri(a);
  }
  ut(o, r.defId ? r.schema : r.def ?? r.schema);
  let i = e.metadataRegistry.get(t)?.id;
  i !== void 0 && o.id === i && delete o.id;
  let c = e.external?.defs ?? {};
  if (!e.external || e.sharedEmitDoneFor !== e.external)
    for (let a of e.seen.entries()) {
      let u = a[1];
      u.def && u.defId && (u.def.id === u.defId && delete u.def.id, U(c, u.defId, u.def));
    }
  e.external && (e.sharedEmitDoneFor = e.external), e.external || Object.keys(c).length > 0 && (e.target === "draft-2020-12" ? o.$defs = c : o.definitions = c);
  try {
    let a = JSON.parse(JSON.stringify(o));
    return Object.defineProperty(a, "~standard", {
      value: {
        ...t["~standard"],
        jsonSchema: {
          input: lt(t, "input", e.processors),
          output: lt(t, "output", e.processors)
        }
      },
      enumerable: !1,
      writable: !1
    }), a;
  } catch {
    throw new Error("Error converting schema to JSON.");
  }
}
s(wo, "finalize");
function W(e, t) {
  let r = t ?? { seen: /* @__PURE__ */ new Set() };
  if (r.seen.has(e))
    return !1;
  r.seen.add(e);
  let n = e._zod.def;
  if (n.type === "transform")
    return !0;
  if (n.type === "array")
    return W(n.element, r);
  if (n.type === "set")
    return W(n.valueType, r);
  if (n.type === "lazy")
    return W(n.getter(), r);
  if (n.type === "promise" || n.type === "optional" || n.type === "nonoptional" || n.type === "nullable" || n.type === "readonly" || n.type === "default" || n.type === "prefault" || n.type === "catch")
    return W(n.innerType, r);
  if (n.type === "intersection")
    return W(n.left, r) || W(n.right, r);
  if (n.type === "record" || n.type === "map")
    return W(n.keyType, r) || W(n.valueType, r);
  if (n.type === "pipe")
    return e._zod.traits.has("$ZodCodec") ? !0 : W(n.in, r) || W(n.out, r);
  if (n.type === "object") {
    for (let o in n.shape)
      if (W(n.shape[o], r))
        return !0;
    return !1;
  }
  if (n.type === "union") {
    for (let o of n.options)
      if (W(o, r))
        return !0;
    return !1;
  }
  if (n.type === "tuple") {
    for (let o of n.items)
      if (W(o, r))
        return !0;
    return !!(n.rest && W(n.rest, r));
  }
  return !1;
}
s(W, "isTransforming");
var _a = /* @__PURE__ */ s((e, t = {}) => (r) => {
  let n = bo({ ...r, processors: t });
  return M(e, n), xo(n, e), wo(n, e);
}, "createToJSONSchemaMethod"), lt = /* @__PURE__ */ s((e, t, r = {}) => (n) => {
  let { libraryOptions: o, target: i } = n ?? {}, c = bo({ ...o ?? {}, target: i, io: t, processors: r });
  return M(e, c), xo(c, e), wo(c, e);
}, "createStandardJSONSchemaMethod");

// versions/4.5.4/node_modules/zod/v4/core/json-schema-processors.js
var hp = {
  guid: "uuid",
  url: "uri",
  datetime: "date-time",
  json_string: "json-string",
  regex: ""
  // do not set
}, ba = /* @__PURE__ */ s((e, t, r, n) => {
  let o = r;
  o.type = "string";
  let { minimum: i, maximum: c, format: a, patterns: u, contentEncoding: l, laxFormat: p } = e._zod.bag;
  if (typeof i == "number" && (o.minLength = i), typeof c == "number" && (o.maxLength = c), a && (o.format = hp[a] ?? a, o.format === "" && delete o.format, (a === "time" || p) && delete o.format), l && (o.contentEncoding = l), u && u.size > 0) {
    let m = [...u];
    m.length === 1 ? o.pattern = m[0].source : m.length > 1 && (o.allOf = [
      ...m.map((h) => ({
        ...t.target === "draft-07" || t.target === "draft-04" || t.target === "openapi-3.0" ? { type: "string" } : {},
        pattern: h.source
      }))
    ]);
  }
}, "stringProcessor"), xa = /* @__PURE__ */ s((e, t, r, n) => {
  let o = r, { minimum: i, maximum: c, format: a, multipleOf: u, exclusiveMaximum: l, exclusiveMinimum: p } = e._zod.bag;
  typeof a == "string" && a.includes("int") ? o.type = "integer" : o.type = "number";
  let m = typeof p == "number" && p >= (i ?? Number.NEGATIVE_INFINITY), h = typeof l == "number" && l <= (c ?? Number.POSITIVE_INFINITY), g = t.target === "draft-04" || t.target === "openapi-3.0";
  m ? g ? (o.minimum = p, o.exclusiveMinimum = !0) : o.exclusiveMinimum = p : typeof i == "number" && (o.minimum = i), h ? g ? (o.maximum = l, o.exclusiveMaximum = !0) : o.exclusiveMaximum = l : typeof c == "number" && (o.maximum = c), typeof u == "number" && (Number.isFinite(u) && u !== 0 ? o.multipleOf = Math.abs(u) : de(e, t, o, n, `A multipleOf divisor of ${u} cannot be represented in JSON Schema`));
}, "numberProcessor"), wa = /* @__PURE__ */ s((e, t, r, n) => {
  r.type = "boolean";
}, "booleanProcessor");
var va = /* @__PURE__ */ s((e, t, r, n) => {
  r.not = {};
}, "neverProcessor");
var za = /* @__PURE__ */ s((e, t, r, n) => {
}, "unknownProcessor"), $a = /* @__PURE__ */ s((e, t, r, n) => {
  de(e, t, r, n, "Date cannot be represented in JSON Schema");
}, "dateProcessor"), ka = /* @__PURE__ */ s((e, t, r, n) => {
  let o = e._zod.def, i = We(o.entries);
  if (i.length === 0) {
    r.not = {};
    return;
  }
  i.every((c) => typeof c == "number") && (r.type = "number"), i.every((c) => typeof c == "string") && (r.type = "string"), r.enum = i;
}, "enumProcessor");
var Sa = /* @__PURE__ */ s((e, t, r, n) => {
  de(e, t, r, n, "Custom types cannot be represented in JSON Schema");
}, "customProcessor");
var Oa = /* @__PURE__ */ s((e, t, r, n) => {
  de(e, t, r, n, "Transforms cannot be represented in JSON Schema");
}, "transformProcessor");
var Pa = /* @__PURE__ */ s((e, t, r, n) => {
  let o = r, i = e._zod.def, { minimum: c, maximum: a } = e._zod.bag;
  typeof c == "number" && (o.minItems = c), typeof a == "number" && (o.maxItems = a), o.type = "array", o.items = M(i.element, t, {
    ...n,
    path: [...n.path, "items"]
  });
}, "arrayProcessor");
function vo(e) {
  let t = e._zod.def;
  return t.type === "pipe" && t.in._zod.traits.has("$ZodTransform") ? vo(t.out) : t.type === "catch" ? vo(t.innerType) : e._zod.optin;
}
s(vo, "inputOptin");
var Za = /* @__PURE__ */ s((e, t, r, n) => {
  let o = r, i = e._zod.def, c = i.shape;
  if (Object.getOwnPropertySymbols(c).length && de(e, t, o, n, "Symbol keys cannot be represented in JSON Schema"))
    return;
  o.type = "object", o.properties = {};
  for (let p in c)
    U(o.properties, p, M(c[p], t, {
      ...n,
      path: [...n.path, "properties", p]
    }));
  let u = new Set(Object.keys(c)), l = new Set([...u].filter((p) => {
    let m = i.shape[p];
    return t.io === "input" ? vo(m) === void 0 : m._zod.optout === void 0;
  }));
  l.size > 0 && (o.required = Array.from(l)), i.catchall?._zod.def.type === "never" ? o.additionalProperties = !1 : i.catchall ? i.catchall && (o.additionalProperties = M(i.catchall, t, {
    ...n,
    path: [...n.path, "additionalProperties"]
  })) : t.io === "output" && (o.additionalProperties = !1);
}, "objectProcessor"), Ia = /* @__PURE__ */ s((e, t, r, n) => {
  let o = e._zod.def, i = o.inclusive === !1, c = o.options.map((a, u) => M(a, t, {
    ...n,
    path: [...n.path, i ? "oneOf" : "anyOf", u]
  }));
  i ? r.oneOf = c : r.anyOf = c;
}, "unionProcessor"), Ea = /* @__PURE__ */ s((e, t, r, n) => {
  let o = e._zod.def, i = M(o.left, t, {
    ...n,
    path: [...n.path, "allOf", 0]
  }), c = M(o.right, t, {
    ...n,
    path: [...n.path, "allOf", 1]
  }), a = /* @__PURE__ */ s((l) => "allOf" in l && Object.keys(l).length === 1, "isSimpleIntersection"), u = [
    ...a(i) ? i.allOf : [i],
    ...a(c) ? c.allOf : [c]
  ];
  r.allOf = u, t.intersections.push(u);
}, "intersectionProcessor");
var Aa = /* @__PURE__ */ s((e, t, r, n) => {
  let o = e._zod.def, i = M(o.innerType, t, n), c = t.seen.get(e);
  t.target === "openapi-3.0" ? (c.ref = o.innerType, r.nullable = !0) : r.anyOf = [i, { type: "null" }];
}, "nullableProcessor"), Ta = /* @__PURE__ */ s((e, t, r, n) => {
  let o = e._zod.def;
  M(o.innerType, t, n);
  let i = t.seen.get(e);
  i.ref = o.innerType;
}, "nonoptionalProcessor"), zo = Symbol();
function Ca(e, t, r, n, o) {
  let i = !1, c = JSON.stringify(e, (a, u) => typeof u != "bigint" ? u : (i = !0, null));
  return i ? (de(t, r, n, o, "BigInt defaults cannot be represented in JSON Schema"), zo) : JSON.parse(c);
}
s(Ca, "serializeDefaultValue");
var Na = /* @__PURE__ */ s((e, t, r, n) => {
  let o = e._zod.def;
  M(o.innerType, t, n);
  let i = t.seen.get(e);
  i.ref = o.innerType;
  let c = Ca(o.defaultValue, e, t, r, n);
  c !== zo && (r.default = c);
}, "defaultProcessor"), ja = /* @__PURE__ */ s((e, t, r, n) => {
  let o = e._zod.def;
  M(o.innerType, t, n);
  let i = t.seen.get(e);
  if (i.ref = o.innerType, t.io !== "input")
    return;
  let c = Ca(o.defaultValue, e, t, r, n);
  c !== zo && (r._prefault = c);
}, "prefaultProcessor"), Ra = /* @__PURE__ */ s((e, t, r, n) => {
  let o = e._zod.def;
  M(o.innerType, t, n);
  let i = t.seen.get(e);
  i.ref = o.innerType;
  let c;
  try {
    c = o.catchValue(void 0);
  } catch {
    de(e, t, r, n, "Dynamic catch values are not supported in JSON Schema");
    return;
  }
  r.default = c;
}, "catchProcessor"), Fa = /* @__PURE__ */ s((e, t, r, n) => {
  let o = e._zod.def, i = o.in._zod.traits.has("$ZodTransform"), c = t.io === "input" ? i ? o.out : o.in : o.out;
  M(c, t, n);
  let a = t.seen.get(e);
  a.ref = c;
}, "pipeProcessor"), La = /* @__PURE__ */ s((e, t, r, n) => {
  let o = e._zod.def;
  M(o.innerType, t, n);
  let i = t.seen.get(e);
  i.ref = o.innerType, r.readOnly = !0;
}, "readonlyProcessor");
var $o = /* @__PURE__ */ s((e, t, r, n) => {
  let o = e._zod.def;
  M(o.innerType, t, n);
  let i = t.seen.get(e);
  i.ref = o.innerType;
}, "optionalProcessor");

// versions/4.5.4/node_modules/zod/v4/classic/errors.js
var Da = /* @__PURE__ */ new WeakSet([Object.prototype, Error.prototype]);
function vr(e, t, r) {
  Object.defineProperty(e, t, {
    configurable: !0,
    enumerable: !1,
    get() {
      let n = r(this);
      return Object.defineProperty(this, t, { value: n, configurable: !0, writable: !0 }), n;
    },
    set(n) {
      Object.defineProperty(this, t, { value: n, configurable: !0, writable: !0 });
    }
  });
}
s(vr, "_lazyMethod");
var vp = /* @__PURE__ */ s((e, t) => {
  Bt.init(e, t), e.name = "ZodError";
  let r = Object.getPrototypeOf(e);
  Da.has(r) || (Da.add(r), vr(r, "format", (n) => (o) => Zs(n, o)), vr(r, "flatten", (n) => (o) => Ps(n, o)), vr(r, "addIssue", (n) => (o) => {
    n.issues.push(o), n.message = JSON.stringify(n.issues, Ee, 2);
  }), vr(r, "addIssues", (n) => (o) => {
    n.issues.push(...o), n.message = JSON.stringify(n.issues, Ee, 2);
  }), Object.defineProperty(r, "isEmpty", {
    configurable: !0,
    enumerable: !1,
    get() {
      return this.issues.length === 0;
    }
  }));
}, "initializer");
var H = /* @__PURE__ */ f("ZodError", vp, void 0, {
  Parent: Error
});

// versions/4.5.4/node_modules/zod/v4/classic/parse.js
var zr = /* @__PURE__ */ et(H), Ma = /* @__PURE__ */ tt(H), Ua = /* @__PURE__ */ rt(H), Ba = /* @__PURE__ */ nt(H), $r = /* @__PURE__ */ As(H), Ja = /* @__PURE__ */ Ts(H), Va = /* @__PURE__ */ Cs(H), qa = /* @__PURE__ */ Ns(H), Wa = /* @__PURE__ */ js(H), Ga = /* @__PURE__ */ Rs(H), Ka = /* @__PURE__ */ Fs(H), Ha = /* @__PURE__ */ Ls(H);

// versions/4.5.4/node_modules/zod/v4/classic/schemas.js
function $p() {
  B.localeError || q(no());
}
s($p, "_ensureDefaultLocale");
function So() {
  B.memoizer || q({ memoizer: Zc() });
}
s(So, "_ensureDefaultMemoizer");
var N = /* @__PURE__ */ f("ZodType", (e, t) => ($p(), z.init(e, t), e.def = t, e.type = t.type, e), {
  check(...e) {
    let t = this.def;
    return this.clone(k.mergeDefs(t, {
      checks: [
        ...t.checks ?? [],
        ...e.map((r) => typeof r == "function" ? { _zod: { check: r, def: { check: "custom" }, onattach: [] } } : r)
      ]
    }), { parent: !0 });
  },
  with(...e) {
    return this.check(...e);
  },
  clone(e, t) {
    return te(this, e, t);
  },
  brand() {
    return this;
  },
  register(e, t) {
    return e.add(this, t), this;
  },
  refine(e, t) {
    return this.check(xf(e, t));
  },
  superRefine(e, t) {
    return this.check(wf(e, t));
  },
  overwrite(e) {
    return this.check(fe(e));
  },
  optional() {
    return pt(this);
  },
  exactOptional() {
    return af(this);
  },
  nullable() {
    return Sr(this);
  },
  nullish() {
    return pt(Sr(this));
  },
  nonoptional(e) {
    return mf(this, e);
  },
  array() {
    return Or(this);
  },
  or(e) {
    return Pr([this, e]);
  },
  and(e) {
    return nf(this, e);
  },
  transform(e) {
    return Xa(this, cf(e));
  },
  default(e) {
    return pf(this, e);
  },
  prefault(e) {
    return df(this, e);
  },
  catch(e) {
    return gf(this, e);
  },
  pipe(e) {
    return Xa(this, e);
  },
  readonly() {
    return bf(this);
  },
  describe(e) {
    let t = this.clone();
    return _e.add(t, { description: e }), t;
  },
  meta(...e) {
    if (e.length === 0)
      return _e.get(this);
    let t = this.clone();
    return _e.add(t, e[0]), t;
  },
  isOptional() {
    return this.safeParse(void 0).success;
  },
  isNullable() {
    return this.safeParse(null).success;
  },
  apply(e, ...t) {
    return t.length === 0 ? e(this) : e(this, ...t);
  },
  // Overrides core's `~standard` to add `jsonSchema`. Must stay a prototype entry: redefining it per instance demotes instances to dictionary mode.
  get "~standard"() {
    return k.hide(this, "~standard", {
      ...Rn(this),
      jsonSchema: {
        input: lt(this, "input"),
        output: lt(this, "output")
      }
    });
  },
  set "~standard"(e) {
    k.own(this, "~standard", e);
  },
  parse: /* @__PURE__ */ s(function e(t, r) {
    return zr(this, t, r, { callee: e });
  }, "_parse"),
  parseAsync: /* @__PURE__ */ s(async function e(t, r) {
    return await Ma(this, t, r, { callee: e });
  }, "_parseAsync"),
  safeParse(e, t) {
    return Ua(this, e, t);
  },
  async safeParseAsync(e, t) {
    return Ba(this, e, t);
  },
  // `spa` is an alias: same function object as `safeParseAsync`, as before.
  get spa() {
    return this?.safeParseAsync;
  },
  set spa(e) {
    k.own(this, "spa", e);
  },
  encode: /* @__PURE__ */ s(function e(t, r) {
    return $r(this, t, r, { callee: e });
  }, "_encode"),
  decode: /* @__PURE__ */ s(function e(t, r) {
    return Ja(this, t, r, { callee: e });
  }, "_decode"),
  encodeAsync: /* @__PURE__ */ s(async function e(t, r) {
    return await Va(this, t, r, { callee: e });
  }, "_encodeAsync"),
  decodeAsync: /* @__PURE__ */ s(async function e(t, r) {
    return await qa(this, t, r, { callee: e });
  }, "_decodeAsync"),
  safeEncode(e, t) {
    return Wa(this, e, t);
  },
  safeDecode(e, t) {
    return Ga(this, e, t);
  },
  async safeEncodeAsync(e, t) {
    return Ka(this, e, t);
  },
  async safeDecodeAsync(e, t) {
    return Ha(this, e, t);
  },
  toJSONSchema(e) {
    return _a(this, {})(e);
  },
  // Reads through to the registry on every access, so it must not cache.
  get description() {
    return _e.get(this)?.description;
  },
  // No setter: `schema._def = x` throws, as it did when `_def` was a non-writable own property.
  get _def() {
    return this._zod.def;
  }
}), eu = /* @__PURE__ */ f("_ZodString", (e, t) => {
  Ce.init(e, t), N.init(e, t), e._zod.processJSONSchema = (n, o, i) => ba(e, n, o, i);
  let r = e._zod.bag;
  e.format = r.format ?? null, e.minLength = r.minimum ?? null, e.maxLength = r.maximum ?? null;
}, {
  regex(...e) {
    return this.check(io(...e));
  },
  includes(...e) {
    return this.check(uo(...e));
  },
  startsWith(...e) {
    return this.check(lo(...e));
  },
  endsWith(...e) {
    return this.check(po(...e));
  },
  min(...e) {
    return this.check(Re(...e));
  },
  max(...e) {
    return this.check(br(...e));
  },
  length(...e) {
    return this.check(xr(...e));
  },
  nonempty(...e) {
    return this.check(Re(1, ...e));
  },
  lowercase(e) {
    return this.check(co(e));
  },
  uppercase(e) {
    return this.check(ao(e));
  },
  trim() {
    return this.check(mo());
  },
  normalize(...e) {
    return this.check(fo(...e));
  },
  toLowerCase() {
    return this.check(ho());
  },
  toUpperCase() {
    return this.check(go());
  },
  slugify() {
    return this.check(yo());
  }
}), kp = /* @__PURE__ */ f("ZodString", (e, t) => {
  Ce.init(e, t), eu.init(e, t);
}, {
  email(e) {
    return this.check(Ac(Ip, e));
  },
  url(e) {
    return this.check(Fc(Ap, e));
  },
  jwt(e) {
    return this.check(Xc(Wp, e));
  },
  emoji(e) {
    return this.check(Lc(Tp, e));
  },
  guid(e) {
    return this.check(Tc(Ep, e));
  },
  uuid(e) {
    return this.check(Cc(kr, e));
  },
  uuidv4(e) {
    return this.check(Nc(kr, e));
  },
  uuidv6(e) {
    return this.check(jc(kr, e));
  },
  uuidv7(e) {
    return this.check(Rc(kr, e));
  },
  nanoid(e) {
    return this.check(Dc(Cp, e));
  },
  cuid(e) {
    return this.check(Mc(Np, e));
  },
  cuid2(e) {
    return this.check(Uc(jp, e));
  },
  ulid(e) {
    return this.check(Bc(Rp, e));
  },
  base64(e) {
    return this.check(Hc(Jp, e));
  },
  base64url(e) {
    return this.check(Qc(Vp, e));
  },
  xid(e) {
    return this.check(Jc(Fp, e));
  },
  ksuid(e) {
    return this.check(Vc(Lp, e));
  },
  ipv4(e) {
    return this.check(qc(Dp, e));
  },
  ipv6(e) {
    return this.check(Wc(Mp, e));
  },
  cidrv4(e) {
    return this.check(Gc(Up, e));
  },
  cidrv6(e) {
    return this.check(Kc(Bp, e));
  },
  e164(e) {
    return this.check(Yc(qp, e));
  },
  datetime(e) {
    return this.check(ea(Sp, e));
  },
  date(e) {
    return this.check(ta(Op, e));
  },
  time(e) {
    return this.check(ra(Pp, e));
  },
  duration(e) {
    return this.check(na(Zp, e));
  }
});
function Oo(e) {
  return Ec(kp, e);
}
s(Oo, "string");
var A = /* @__PURE__ */ f("ZodStringFormat", (e, t) => {
  I.init(e, t), eu.init(e, t);
}), Sp = /* @__PURE__ */ f("ZodISODateTime", (e, t) => {
  sc.init(e, t), A.init(e, t);
}), Op = /* @__PURE__ */ f("ZodISODate", (e, t) => {
  ic.init(e, t), A.init(e, t);
}), Pp = /* @__PURE__ */ f("ZodISOTime", (e, t) => {
  cc.init(e, t), A.init(e, t);
}), Zp = /* @__PURE__ */ f("ZodISODuration", (e, t) => {
  ac.init(e, t), A.init(e, t);
}), Ip = /* @__PURE__ */ f("ZodEmail", (e, t) => {
  Gi.init(e, t), A.init(e, t);
});
var Ep = /* @__PURE__ */ f("ZodGUID", (e, t) => {
  qi.init(e, t), A.init(e, t);
});
var kr = /* @__PURE__ */ f("ZodUUID", (e, t) => {
  Wi.init(e, t), A.init(e, t);
});
var Ap = /* @__PURE__ */ f("ZodURL", (e, t) => {
  Qi.init(e, t), A.init(e, t);
});
var Tp = /* @__PURE__ */ f("ZodEmoji", (e, t) => {
  Yi.init(e, t), A.init(e, t);
});
var Cp = /* @__PURE__ */ f("ZodNanoID", (e, t) => {
  Xi.init(e, t), A.init(e, t);
});
var Np = /* @__PURE__ */ f("ZodCUID", (e, t) => {
  ec.init(e, t), A.init(e, t);
});
var jp = /* @__PURE__ */ f("ZodCUID2", (e, t) => {
  tc.init(e, t), A.init(e, t);
});
var Rp = /* @__PURE__ */ f("ZodULID", (e, t) => {
  rc.init(e, t), A.init(e, t);
});
var Fp = /* @__PURE__ */ f("ZodXID", (e, t) => {
  nc.init(e, t), A.init(e, t);
});
var Lp = /* @__PURE__ */ f("ZodKSUID", (e, t) => {
  oc.init(e, t), A.init(e, t);
});
var Dp = /* @__PURE__ */ f("ZodIPv4", (e, t) => {
  uc.init(e, t), A.init(e, t);
});
var Mp = /* @__PURE__ */ f("ZodIPv6", (e, t) => {
  pc.init(e, t), A.init(e, t);
});
var Up = /* @__PURE__ */ f("ZodCIDRv4", (e, t) => {
  fc.init(e, t), A.init(e, t);
});
var Bp = /* @__PURE__ */ f("ZodCIDRv6", (e, t) => {
  dc.init(e, t), A.init(e, t);
});
var Jp = /* @__PURE__ */ f("ZodBase64", (e, t) => {
  hc.init(e, t), A.init(e, t);
});
var Vp = /* @__PURE__ */ f("ZodBase64URL", (e, t) => {
  gc.init(e, t), A.init(e, t);
});
var qp = /* @__PURE__ */ f("ZodE164", (e, t) => {
  yc.init(e, t), A.init(e, t);
});
var Wp = /* @__PURE__ */ f("ZodJWT", (e, t) => {
  _c.init(e, t), A.init(e, t);
});
var tu = /* @__PURE__ */ f("ZodNumber", (e, t) => {
  st.init(e, t), N.init(e, t), e._zod.processJSONSchema = (n, o, i) => xa(e, n, o, i);
  let r = e._zod.bag;
  e.minValue = Math.max(r.minimum ?? Number.NEGATIVE_INFINITY, r.exclusiveMinimum ?? Number.NEGATIVE_INFINITY) ?? null, e.maxValue = Math.min(r.maximum ?? Number.POSITIVE_INFINITY, r.exclusiveMaximum ?? Number.POSITIVE_INFINITY) ?? null, e.isInt = (r.format ?? "").includes("int") || Number.isSafeInteger(r.multipleOf ?? 0.5), e.isFinite = !0, e.format = r.format ?? null;
}, {
  gt(e, t) {
    return this.check(yr(e, t));
  },
  gte(e, t) {
    return this.check(je(e, t));
  },
  min(e, t) {
    return this.check(je(e, t));
  },
  lt(e, t) {
    return this.check(gr(e, t));
  },
  lte(e, t) {
    return this.check(Ne(e, t));
  },
  max(e, t) {
    return this.check(Ne(e, t));
  },
  int(e) {
    return this.check(Qa(e));
  },
  safe(e) {
    return this.check(Qa(e));
  },
  positive(e) {
    return this.check(yr(0, e));
  },
  nonnegative(e) {
    return this.check(je(0, e));
  },
  negative(e) {
    return this.check(gr(0, e));
  },
  nonpositive(e) {
    return this.check(Ne(0, e));
  },
  multipleOf(e, t) {
    return this.check(_r(e, t));
  },
  step(e, t) {
    return this.check(_r(e, t));
  },
  finite() {
    return this;
  }
});
function Po(e) {
  return oa(tu, e);
}
s(Po, "number");
var Gp = /* @__PURE__ */ f("ZodNumberFormat", (e, t) => {
  bc.init(e, t), tu.init(e, t);
});
function Qa(e) {
  return sa(Gp, e);
}
s(Qa, "int");
var Kp = /* @__PURE__ */ f("ZodBoolean", (e, t) => {
  Yt.init(e, t), N.init(e, t), e._zod.processJSONSchema = (r, n, o) => wa(e, r, n, o);
});
function Zo(e) {
  return ia(Kp, e);
}
s(Zo, "boolean");
var Hp = /* @__PURE__ */ f("ZodUnknown", (e, t) => {
  Xt.init(e, t), N.init(e, t), e._zod.processJSONSchema = (r, n, o) => za(e, r, n, o);
});
function Ya() {
  return ca(Hp);
}
s(Ya, "unknown");
var Qp = /* @__PURE__ */ f("ZodNever", (e, t) => {
  er.init(e, t), N.init(e, t), e._zod.processJSONSchema = (r, n, o) => va(e, r, n, o);
});
function ru(e) {
  return aa(Qp, e);
}
s(ru, "never");
var Yp = /* @__PURE__ */ f("ZodDate", (e, t) => {
  tr.init(e, t), N.init(e, t), e._zod.processJSONSchema = (n, o, i) => $a(e, n, o, i), e.min = (n, o) => e.check(je(n, o)), e.max = (n, o) => e.check(Ne(n, o));
  let r = e._zod.bag;
  e.minDate = r.minimum ? new Date(r.minimum) : null, e.maxDate = r.maximum ? new Date(r.maximum) : null;
});
function nu(e) {
  return ua(Yp, e);
}
s(nu, "date");
var Xp = /* @__PURE__ */ f("ZodArray", (e, t) => {
  So(), rr.init(e, t), N.init(e, t), e._zod.processJSONSchema = (r, n, o) => Pa(e, r, n, o), e.element = t.element;
}, {
  min(e, t) {
    return this.check(Re(e, t));
  },
  nonempty(e) {
    return this.check(Re(1, e));
  },
  max(e, t) {
    return this.check(br(e, t));
  },
  length(e, t) {
    return this.check(xr(e, t));
  },
  unwrap() {
    return this.element;
  }
});
function Or(e, t) {
  return la(Xp, e, t);
}
s(Or, "array");
var ef = /* @__PURE__ */ f("ZodObject", (e, t) => {
  So(), vc.init(e, t), N.init(e, t), e._zod.processJSONSchema = (r, n, o) => Za(e, r, n, o), k.installLazyProp(e, "shape", (r) => r._zod.def.shape, !1);
}, {
  keyof() {
    return of(Object.keys(this._zod.def.shape));
  },
  catchall(e) {
    return this.clone({ ...this._zod.def, catchall: e });
  },
  passthrough() {
    return this.clone({ ...this._zod.def, catchall: Ya() });
  },
  loose() {
    return this.clone({ ...this._zod.def, catchall: Ya() });
  },
  strict() {
    return this.clone({ ...this._zod.def, catchall: ru() });
  },
  strip() {
    return this.clone({ ...this._zod.def, catchall: void 0 });
  },
  extend(e) {
    return k.extend(this, e);
  },
  safeExtend(e) {
    return k.safeExtend(this, e);
  },
  merge(e) {
    return k.merge(this, e);
  },
  pick(e) {
    return k.pick(this, e);
  },
  omit(e) {
    return k.omit(this, e);
  },
  partial(...e) {
    return k.partial(ou, this, e[0]);
  },
  exactPartial(...e) {
    return k.partial(su, this, e[0], "exactPartial");
  },
  required(...e) {
    return k.required(iu, this, e[0]);
  }
});
function ft(e, t) {
  let r = {
    type: "object",
    shape: e ?? {},
    ...k.normalizeParams(t)
  };
  return new ef(r);
}
s(ft, "object");
var tf = /* @__PURE__ */ f("ZodUnion", (e, t) => {
  or.init(e, t), N.init(e, t), e._zod.processJSONSchema = (r, n, o) => Ia(e, r, n, o), e.options = t.options;
});
function Pr(e, t) {
  return new tf({
    type: "union",
    options: e,
    ...k.normalizeParams(t)
  });
}
s(Pr, "union");
var rf = /* @__PURE__ */ f("ZodIntersection", (e, t) => {
  sr.init(e, t), N.init(e, t), e._zod.processJSONSchema = (r, n, o) => Ea(e, r, n, o);
});
function nf(e, t) {
  return new rf({
    type: "intersection",
    left: e,
    right: t
  });
}
s(nf, "intersection");
var ko = /* @__PURE__ */ f("ZodEnum", (e, t) => {
  cr.init(e, t), N.init(e, t), e._zod.processJSONSchema = (n, o, i) => ka(e, n, o, i), e.enum = t.entries, e.options = Object.values(t.entries);
  let r = new Set(Object.keys(t.entries));
  e.extract = (n, o) => {
    let i = {};
    for (let c of n)
      if (r.has(c))
        i[c] = t.entries[c];
      else
        throw new Error(`Key ${c} not found in enum`);
    return new ko({
      ...t,
      checks: [],
      ...k.normalizeParams(o),
      entries: i
    });
  }, e.exclude = (n, o) => {
    let i = { ...t.entries };
    for (let c of n)
      if (r.has(c))
        delete i[c];
      else
        throw new Error(`Key ${c} not found in enum`);
    return new ko({
      ...t,
      checks: [],
      ...k.normalizeParams(o),
      entries: i
    });
  };
});
function of(e, t) {
  let r = Array.isArray(e) ? Object.fromEntries(e.map((n) => [n, n])) : e;
  return new ko({
    type: "enum",
    entries: r,
    ...k.normalizeParams(t)
  });
}
s(of, "_enum");
var sf = /* @__PURE__ */ f("ZodTransform", (e, t) => {
  So(), ar.init(e, t), N.init(e, t), e._zod.processJSONSchema = (r, n, o) => Oa(e, r, n, o), e._zod.parse = (r, n) => {
    if (n.direction === "backward")
      throw new Te(e.constructor.name);
    r.addIssue = (i) => {
      if (typeof i == "string")
        r.issues.push(k.issue(i, r.value, t));
      else {
        let c = i;
        c.fatal && (c.continue = !1), c.code ?? (c.code = "custom"), "input" in c || (c.input = r.value), c.inst ?? (c.inst = e), r.issues.push(k.issue(c));
      }
    };
    let o = t.transform(r.value, r);
    return o instanceof Promise ? o.then((i) => (r.value = i, r)) : (r.value = o, r);
  };
});
function cf(e) {
  return new sf({
    type: "transform",
    transform: e
  });
}
s(cf, "transform");
var ou = /* @__PURE__ */ f("ZodOptional", (e, t) => {
  it.init(e, t), N.init(e, t), e._zod.processJSONSchema = (r, n, o) => $o(e, r, n, o), e.unwrap = () => e._zod.def.innerType;
});
function pt(e) {
  return new ou({
    type: "optional",
    innerType: e
  });
}
s(pt, "optional");
var su = /* @__PURE__ */ f("ZodExactOptional", (e, t) => {
  zc.init(e, t), N.init(e, t), e._zod.processJSONSchema = (r, n, o) => $o(e, r, n, o), e.unwrap = () => e._zod.def.innerType;
});
function af(e) {
  return new su({
    type: "optional",
    innerType: e
  });
}
s(af, "exactOptional");
var uf = /* @__PURE__ */ f("ZodNullable", (e, t) => {
  ur.init(e, t), N.init(e, t), e._zod.processJSONSchema = (r, n, o) => Aa(e, r, n, o), e.unwrap = () => e._zod.def.innerType;
});
function Sr(e) {
  return new uf({
    type: "nullable",
    innerType: e
  });
}
s(Sr, "nullable");
var lf = /* @__PURE__ */ f("ZodDefault", (e, t) => {
  ct.init(e, t), N.init(e, t), e._zod.processJSONSchema = (r, n, o) => Na(e, r, n, o), e.unwrap = () => e._zod.def.innerType, e.removeDefault = e.unwrap;
});
function pf(e, t) {
  return new lf({
    type: "default",
    innerType: e,
    get defaultValue() {
      return typeof t == "function" ? t() : k.shallowClone(t);
    }
  });
}
s(pf, "_default");
var ff = /* @__PURE__ */ f("ZodPrefault", (e, t) => {
  $c.init(e, t), N.init(e, t), e._zod.processJSONSchema = (r, n, o) => ja(e, r, n, o), e.unwrap = () => e._zod.def.innerType;
});
function df(e, t) {
  return new ff({
    type: "prefault",
    innerType: e,
    get defaultValue() {
      return typeof t == "function" ? t() : k.shallowClone(t);
    }
  });
}
s(df, "prefault");
var iu = /* @__PURE__ */ f("ZodNonOptional", (e, t) => {
  lr.init(e, t), N.init(e, t), e._zod.processJSONSchema = (r, n, o) => Ta(e, r, n, o), e.unwrap = () => e._zod.def.innerType;
});
function mf(e, t) {
  return new iu({
    type: "nonoptional",
    innerType: e,
    ...k.normalizeParams(t)
  });
}
s(mf, "nonoptional");
var hf = /* @__PURE__ */ f("ZodCatch", (e, t) => {
  pr.init(e, t), N.init(e, t), e._zod.processJSONSchema = (r, n, o) => Ra(e, r, n, o), e.unwrap = () => e._zod.def.innerType, e.removeCatch = e.unwrap;
});
function gf(e, t) {
  return new hf({
    type: "catch",
    innerType: e,
    catchValue: typeof t == "function" ? t : k.constantCatch(t)
  });
}
s(gf, "_catch");
var cu = /* @__PURE__ */ f("ZodPipe", (e, t) => {
  at.init(e, t), N.init(e, t), e._zod.processJSONSchema = (r, n, o) => Fa(e, r, n, o), e.in = t.in, e.out = t.out;
});
function Xa(e, t) {
  return new cu({
    type: "pipe",
    in: e,
    out: t
    // ...util.normalizeParams(params),
  });
}
s(Xa, "pipe");
var yf = /* @__PURE__ */ f("ZodCodec", (e, t) => {
  cu.init(e, t), kc.init(e, t);
});
function au(e, t, r) {
  return new yf({
    type: "pipe",
    in: e,
    out: t,
    transform: r.decode,
    reverseTransform: r.encode
  });
}
s(au, "codec");
var _f = /* @__PURE__ */ f("ZodReadonly", (e, t) => {
  fr.init(e, t), N.init(e, t), e._zod.processJSONSchema = (r, n, o) => La(e, r, n, o), e.unwrap = () => e._zod.def.innerType;
});
function bf(e) {
  return new _f({
    type: "readonly",
    innerType: e
  });
}
s(bf, "readonly");
var uu = /* @__PURE__ */ f("ZodCustom", (e, t) => {
  dr.init(e, t), N.init(e, t), e._zod.processJSONSchema = (r, n, o) => Sa(e, r, n, o);
});
function xf(e, t = {}) {
  return pa(uu, e, t);
}
s(xf, "refine");
function wf(e, t) {
  return fa(e, t);
}
s(wf, "superRefine");
function lu(e, t = {}) {
  let r = new uu({
    type: "custom",
    check: "custom",
    fn: /* @__PURE__ */ s((n) => n instanceof e, "fn"),
    abort: !0,
    ...k.normalizeParams(t)
  });
  return r._zod.bag.Class = e, r._zod.check = (n) => {
    n.value instanceof e || n.issues.push({
      code: "invalid_type",
      expected: e.name,
      input: n.value,
      inst: r,
      path: [...r._zod.def.path ?? []]
    });
  }, r;
}
s(lu, "_instanceof");

// ../zodvex-triage-20260909/node_modules/.bun/convex-helpers@0.1.113+b9ed8f5244cf7f28/node_modules/convex-helpers/index.js
function Zr(e, t) {
  return Object.fromEntries(Object.entries(e).filter(([r]) => t.includes(r)));
}
s(Zr, "pick");
var p_ = Symbol();

// ../zodvex-triage-20260909/node_modules/.bun/convex-helpers@0.1.113+b9ed8f5244cf7f28/node_modules/convex-helpers/validators.js
var y_ = d.string(), __ = d.float64(), b_ = d.float64(), x_ = d.boolean(), w_ = d.int64(), v_ = d.int64(), z_ = d.any(), $_ = d.null(), { id: k_, object: S_, array: O_, bytes: P_, literal: Z_, optional: I_, union: E_ } = d, A_ = d.bytes();
function Ir(e, t) {
  let r = xe(e);
  if (Object.keys(t).length === 0)
    return r;
  switch (r.kind) {
    case "object":
      return d.object(vf(r.fields, t));
    case "union":
      return d.union(...r.members.map((n) => Ir(n, t)));
    default:
      throw new Error("Cannot add arguments to a validator that is not an object or union.");
  }
}
s(Ir, "addFieldsToValidator");
function vf(e, t) {
  let r = { ...e };
  for (let [n, o] of Object.entries(t)) {
    let i = r[n];
    if (i) {
      if (i.kind !== o.kind)
        throw new Error(`Cannot intersect validators with different kinds: ${i.kind} and ${o.kind}`);
      i.isOptional !== o.isOptional && i.isOptional === "optional" && (r[n] = o);
    } else
      r[n] = o;
  }
  return r;
}
s(vf, "intersectValidators");
var T_ = d.optional(d.any());
function dt(e) {
  let { kind: t, isOptional: r } = e;
  if (r === "required")
    return e;
  switch (t) {
    case "id":
      return d.id(e.tableName);
    case "string":
      return d.string();
    case "float64":
      return d.float64();
    case "int64":
      return d.int64();
    case "boolean":
      return d.boolean();
    case "null":
      return d.null();
    case "any":
      return d.any();
    case "literal":
      return d.literal(e.value);
    case "bytes":
      return d.bytes();
    case "object":
      return d.object(e.fields);
    case "array":
      return d.array(e.element);
    case "record":
      return d.record(e.key, e.value);
    case "union":
      return d.union(...e.members);
    default:
      throw new Error("Unknown Convex validator type: " + t);
  }
}
s(dt, "vRequired");

// ../zodvex-triage-20260909/node_modules/.bun/convex-helpers@0.1.113+b9ed8f5244cf7f28/node_modules/convex-helpers/server/customFunctions.js
var mt = {
  args: {},
  input() {
    return { args: {}, ctx: {} };
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex-helpers@0.1.113+b9ed8f5244cf7f28/node_modules/convex-helpers/server/zod4.js
function fu(e, t) {
  return Sf(e, t);
}
s(fu, "zCustomQuery");
function zf(e) {
  let t = /* @__PURE__ */ new WeakSet();
  function r(n) {
    if (t.has(n))
      return d.any();
    t.add(n);
    let o = n instanceof ct ? d.optional(r(n._zod.def.innerType)) : n instanceof at ? r(n._zod.def.in) : du(n, r);
    return t.delete(n), o;
  }
  return s(r, "zodToConvexInner"), r(e);
}
s(zf, "zodToConvex");
function $f(e) {
  let t = /* @__PURE__ */ new WeakSet();
  function r(n) {
    if (t.has(n))
      return d.any();
    t.add(n);
    let o = n instanceof ct ? r(n._zod.def.innerType) : n instanceof at ? r(n._zod.def.out) : n instanceof ar ? d.any() : du(n, r);
    return t.delete(n), o;
  }
  return s(r, "zodOutputToConvexInner"), r(e);
}
s($f, "zodOutputToConvex");
function kf(e) {
  return Object.fromEntries(Object.entries(e).map(([t, r]) => [t, zf(r)]));
}
s(kf, "zodToConvexFields");
function Sf(e, t) {
  let r = t.input ?? mt.input, n = t.args ?? mt.args;
  return /* @__PURE__ */ s(function(i) {
    let { args: c, handler: a = i, skipConvexValidation: u = !1, returns: l, ...p } = i, m = l && !(l instanceof z) ? ft(l) : l, h = m && !u ? { returns: $f(m) } : null;
    if (c) {
      let g = c;
      if (g instanceof z)
        if (g instanceof nr)
          g = g._zod.def.shape;
        else
          throw new Error("Unsupported zod type as args validator: " + g.constructor.name);
      let y = kf(g);
      return e({
        args: u ? void 0 : Ir(y, n),
        ...h,
        handler: /* @__PURE__ */ s(async (x, w) => {
          let j = await r(x, Zr(w, Object.keys(n)), p), R = Zr(w, Object.keys(g)), Q = await ft(g).safeParseAsync(R);
          if (!Q.success)
            throw new we({
              ZodError: JSON.parse(JSON.stringify(Q.error.issues, null, 2))
            });
          let ie = Q.data, L = { ...x, ...j.ctx }, _ = { ...ie, ...j.args }, v = await a(L, _), T = m ? await m.parseAsync(v === void 0 ? null : v) : v;
          return j.onSuccess && await j.onSuccess({ ctx: x, args: ie, result: T }), T;
        }, "handler")
      });
    }
    if (u && Object.keys(n).length > 0)
      throw new Error("If you're using a custom function with arguments for the input customization, you cannot skip convex validation.");
    return e({
      ...h,
      handler: /* @__PURE__ */ s(async (g, y) => {
        let x = await r(g, y, p), w = { ...g, ...x.ctx }, j = { ...y, ...x.args }, R = await a(w, j), Q = m ? await m.parseAsync(R === void 0 ? null : R) : R;
        return x.onSuccess && await x.onSuccess({ ctx: g, args: y, result: Q }), Q;
      }, "handler")
    });
  }, "customBuilder");
}
s(Sf, "customFnBuilder");
function du(e, t) {
  if (e instanceof Ce)
    return d.string();
  if (e instanceof st || e instanceof Kn)
    return d.number();
  if (e instanceof Fn)
    return d.int64();
  if (e instanceof Yt)
    return d.boolean();
  if (e instanceof Mn)
    return d.null();
  if (e instanceof Un || e instanceof Xt)
    return d.any();
  if (e instanceof rr) {
    let r = t(e._zod.def.element);
    if (r.isOptional === "optional")
      throw new Error("Arrays of optional values are not supported");
    return d.array(r);
  }
  if (e instanceof nr)
    return d.object(Object.fromEntries(Object.entries(e._zod.def.shape).map(([r, n]) => [
      r,
      t(n)
    ])));
  if (e instanceof or)
    return d.union(...e._zod.def.options.map(t));
  if (e instanceof er)
    return d.union();
  if (e instanceof ir) {
    let { items: r, rest: n } = e._zod.def;
    return d.array(d.union(...[
      ...r,
      // + rest if set
      ...n !== null ? [n] : []
    ].map(t)));
  }
  if (e instanceof Wn) {
    let { values: r } = e._zod.def;
    return r.length === 1 ? pu(r[0]) : d.union(...r.map(pu));
  }
  if (e instanceof cr)
    return d.union(...Object.entries(e._zod.def.entries).filter(([r, n]) => r === n || isNaN(Number(r))).map(([r, n]) => d.literal(n)));
  if (e instanceof it)
    return d.optional(t(e._zod.def.innerType));
  if (e instanceof lr)
    return dt(t(e._zod.def.innerType));
  if (e instanceof ur) {
    let r = t(e._zod.def.innerType);
    return r.isOptional === "optional" ? d.optional(d.union(dt(r), d.null())) : d.union(r, d.null());
  }
  if (e instanceof Jn) {
    let { keyType: r, valueType: n } = e._zod.def, o = r._zod.values === void 0, i = t(n), c = t(r), a = mu(c);
    if (a !== null) {
      let u = o || i.isOptional === "optional" ? d.optional(i) : dt(i), l = {};
      for (let p of a)
        l[p] = u;
      return d.object(l);
    }
    return d.record(hu(c) ? c : d.string(), dt(i));
  }
  if (e instanceof fr)
    return t(e._zod.def.innerType);
  if (e instanceof Xn)
    return t(e._zod.def.getter());
  if (e instanceof Hn)
    return d.string();
  if (e instanceof dr) {
    let r = Of.get(e);
    return r !== void 0 && typeof r.tableName == "string" ? d.id(r.tableName) : d.any();
  }
  if (e instanceof sr)
    return d.any();
  if (e instanceof pr)
    return t(e._zod.def.innerType);
  if (e instanceof tr || e instanceof Ln || e instanceof Vn || e instanceof qn || e instanceof Yn || e instanceof Gn || e instanceof Qn || e instanceof Bn || e instanceof Dn)
    throw new Error(`Validator ${e.constructor.name} is not supported in Convex`);
  return d.any();
}
s(du, "zodToConvexCommon");
function pu(e) {
  if (e === void 0)
    throw new Error("undefined is not a valid Convex value");
  return e === null ? d.null() : d.literal(e);
}
s(pu, "convexToZodLiteral");
function mu(e) {
  if (e.kind === "literal") {
    let t = e;
    return typeof t.value == "string" ? [t.value] : null;
  }
  if (e.kind === "union") {
    let t = e, r = [];
    for (let n of t.members) {
      let o = mu(n);
      if (o === null)
        return null;
      r.push(...o);
    }
    return r;
  }
  return null;
}
s(mu, "extractStringLiterals");
function hu(e) {
  return e.kind === "string" || e.kind === "id" ? !0 : e.kind === "union" ? e.members.every(hu) : !1;
}
s(hu, "isValidRecordKey");
var Of = so();

// graphProbe.ts
var gu = { query: en, mutation: Yr, action: rn, internalQuery: tn, internalMutation: Xr, internalAction: nn }, Zf = { kind: "helpers", schemaHelpers: !0, server: gu, s: { number: Po, string: Oo, boolean: Zo, optional: pt, nullable: Sr, object: ft, array: Or, union: Pr, date: nu, codec: au, instanceof: lu, parse: zr, encode: $r }, makeBuilders: /* @__PURE__ */ s(() => ({ query: fu(gu.query, mt) }), "makeBuilders") }, If = hs(Zf), Ef = { count: 0, width: 32, profile: "codec-rich", entries: 0 }, Io = If(Ef), ub = Pf({ args: {}, returns: d.object({ checksum: d.number(), output: d.object({ seq: d.number(), at: d.number(), secret: d.string(), payload: d.string() }), manifest: d.any(), nonce: d.string() }), handler: /* @__PURE__ */ s(() => {
  let e = Io.operation();
  return globalThis.gc(), globalThis.gc(), { checksum: Io.checksum(), output: e, manifest: Io.manifest, nonce: "e2099b37-2b08-4e4f-a3ee-e6f033980b6c" };
}, "handler") });
export {
  ub as default
};
