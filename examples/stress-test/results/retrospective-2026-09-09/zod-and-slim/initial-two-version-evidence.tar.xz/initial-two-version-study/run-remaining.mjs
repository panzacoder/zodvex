import { spawnSync } from 'node:child_process';
import { appendFileSync, writeFileSync } from 'node:fs';
const cells = [
 ['4.3.6','on',1], ['4.3.6','off',1], ['4.5.4','on',1], ['4.5.4','off',1],
 ['4.5.4','off',2], ['4.5.4','on',2], ['4.3.6','off',2], ['4.3.6','on',2],
 ['4.3.6','on',3], ['4.5.4','on',3], ['4.3.6','off',3], ['4.5.4','off',3],
];
writeFileSync('run-plan.json', JSON.stringify({ count:16,width:32,profile:'codec-rich',entries:0,cells,firstCollection:'memory-heap-876054cc-6bbc-49cc-b557-ff45d9ff3d34',order:'First cell completed manually; remaining cells collected sequentially in this order. Each collection uses eight fresh isolates.'},null,2));
for (const [version,helpers,round] of cells.slice(1)) {
 console.log('CELL',version,helpers,round);
 const result=spawnSync(process.execPath,['memory/local.mjs','/private/tmp/zodvex-retro-backend-20260909','16','32','codec-rich'],{env:{...process.env,ZOD_RETRO_VERSION:version,ZOD_RETRO_HELPERS:helpers,ZOD_RETRO_ROUND:String(round)},encoding:'utf8'});
 appendFileSync('collection-output.log',JSON.stringify({version,helpers,round,exitCode:result.status})+'\n'+result.stdout+result.stderr);
 console.log(result.stdout);
 if(result.status!==0) throw new Error(result.stderr);
}
