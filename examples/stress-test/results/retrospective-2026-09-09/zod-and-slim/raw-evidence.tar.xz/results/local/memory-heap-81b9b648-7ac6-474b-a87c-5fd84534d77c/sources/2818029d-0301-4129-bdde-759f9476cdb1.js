var Vd = Object.defineProperty;
var s = (e, t) => Vd(e, "name", { value: t, configurable: !0 });
var Pe = (e, t) => {
  for (var n in t)
    Vd(e, n, { get: t[n], enumerable: !0 });
};

// graphProbe.ts
import { query as $$ } from "convex:/_system/repl/wrappers.js";

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/base64.js
var we = [], fe = [], Ng = Uint8Array, bo = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
for (Xe = 0, qd = bo.length; Xe < qd; ++Xe)
  we[Xe] = bo[Xe], fe[bo.charCodeAt(Xe)] = Xe;
var Xe, qd;
fe[45] = 62;
fe[95] = 63;
function Zg(e) {
  var t = e.length;
  if (t % 4 > 0)
    throw new Error("Invalid string. Length must be a multiple of 4");
  var n = e.indexOf("=");
  n === -1 && (n = t);
  var i = n === t ? 0 : 4 - n % 4;
  return [n, i];
}
s(Zg, "getLens");
function Ag(e, t, n) {
  return (t + n) * 3 / 4 - n;
}
s(Ag, "_byteLength");
function ur(e) {
  var t, n = Zg(e), i = n[0], r = n[1], o = new Ng(Ag(e, i, r)), a = 0, c = r > 0 ? i - 4 : i, u;
  for (u = 0; u < c; u += 4)
    t = fe[e.charCodeAt(u)] << 18 | fe[e.charCodeAt(u + 1)] << 12 | fe[e.charCodeAt(u + 2)] << 6 | fe[e.charCodeAt(u + 3)], o[a++] = t >> 16 & 255, o[a++] = t >> 8 & 255, o[a++] = t & 255;
  return r === 2 && (t = fe[e.charCodeAt(u)] << 2 | fe[e.charCodeAt(u + 1)] >> 4, o[a++] = t & 255), r === 1 && (t = fe[e.charCodeAt(u)] << 10 | fe[e.charCodeAt(u + 1)] << 4 | fe[e.charCodeAt(u + 2)] >> 2, o[a++] = t >> 8 & 255, o[a++] = t & 255), o;
}
s(ur, "toByteArray");
function Cg(e) {
  return we[e >> 18 & 63] + we[e >> 12 & 63] + we[e >> 6 & 63] + we[e & 63];
}
s(Cg, "tripletToBase64");
function Rg(e, t, n) {
  for (var i, r = [], o = t; o < n; o += 3)
    i = (e[o] << 16 & 16711680) + (e[o + 1] << 8 & 65280) + (e[o + 2] & 255), r.push(Cg(i));
  return r.join("");
}
s(Rg, "encodeChunk");
function lr(e) {
  for (var t, n = e.length, i = n % 3, r = [], o = 16383, a = 0, c = n - i; a < c; a += o)
    r.push(
      Rg(
        e,
        a,
        a + o > c ? c : a + o
      )
    );
  return i === 1 ? (t = e[n - 1], r.push(we[t >> 2] + we[t << 4 & 63] + "==")) : i === 2 && (t = (e[n - 2] << 8) + e[n - 1], r.push(
    we[t >> 10] + we[t >> 4 & 63] + we[t << 2 & 63] + "="
  )), r.join("");
}
s(lr, "fromByteArray");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/common/index.js
function De(e) {
  if (e === void 0)
    return {};
  if (!nn(e))
    throw new Error(
      `The arguments to a Convex function must be an object. Received: ${e}`
    );
  return e;
}
s(De, "parseArgs");
function nn(e) {
  let t = typeof e == "object", n = Object.getPrototypeOf(e), i = n === null || n === Object.prototype || // Objects generated from other contexts (e.g. across Node.js `vm` modules) will not satisfy the previous
  // conditions but are still simple objects.
  n?.constructor?.name === "Object";
  return t && i;
}
s(nn, "isSimpleObject");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/value.js
var Xd = !0, yt = BigInt("-9223372036854775808"), wo = BigInt("9223372036854775807"), xo = BigInt("0"), Fg = BigInt("8"), Lg = BigInt("256");
function Qd(e) {
  return Number.isNaN(e) || !Number.isFinite(e) || Object.is(e, -0);
}
s(Qd, "isSpecial");
function Mg(e) {
  e < xo && (e -= yt + yt);
  let t = e.toString(16);
  t.length % 2 === 1 && (t = "0" + t);
  let n = new Uint8Array(new ArrayBuffer(8)), i = 0;
  for (let r of t.match(/.{2}/g).reverse())
    n.set([parseInt(r, 16)], i++), e >>= Fg;
  return lr(n);
}
s(Mg, "slowBigIntToBase64");
function Bg(e) {
  let t = ur(e);
  if (t.byteLength !== 8)
    throw new Error(
      `Received ${t.byteLength} bytes, expected 8 for $integer`
    );
  let n = xo, i = xo;
  for (let r of t)
    n += BigInt(r) * Lg ** i, i++;
  return n > wo && (n += yt + yt), n;
}
s(Bg, "slowBase64ToBigInt");
function Jg(e) {
  if (e < yt || wo < e)
    throw new Error(
      `BigInt ${e} does not fit into a 64-bit signed integer.`
    );
  let t = new ArrayBuffer(8);
  return new DataView(t).setBigInt64(0, e, !0), lr(new Uint8Array(t));
}
s(Jg, "modernBigIntToBase64");
function Vg(e) {
  let t = ur(e);
  if (t.byteLength !== 8)
    throw new Error(
      `Received ${t.byteLength} bytes, expected 8 for $integer`
    );
  return new DataView(t.buffer).getBigInt64(0, !0);
}
s(Vg, "modernBase64ToBigInt");
var qg = DataView.prototype.setBigInt64 ? Jg : Mg, Wg = DataView.prototype.getBigInt64 ? Vg : Bg, Kd = 1024;
function _o(e) {
  if (e.length > Kd)
    throw new Error(
      `Field name ${e} exceeds maximum field name length ${Kd}.`
    );
  if (e.startsWith("$"))
    throw new Error(`Field name ${e} starts with a '$', which is reserved.`);
  for (let t = 0; t < e.length; t += 1) {
    let n = e.charCodeAt(t);
    if (n < 32 || n >= 127)
      throw new Error(
        `Field name ${e} has invalid character '${e[t]}': Field names can only contain non-control ASCII characters`
      );
  }
}
s(_o, "validateObjectField");
function J(e) {
  if (e === null || typeof e == "boolean" || typeof e == "number" || typeof e == "string")
    return e;
  if (Array.isArray(e))
    return e.map((i) => J(i));
  if (typeof e != "object")
    throw new Error(`Unexpected type of ${e}`);
  let t = Object.entries(e);
  if (t.length === 1) {
    let i = t[0][0];
    if (i === "$bytes") {
      if (typeof e.$bytes != "string")
        throw new Error(`Malformed $bytes field on ${e}`);
      return ur(e.$bytes).buffer;
    }
    if (i === "$integer") {
      if (typeof e.$integer != "string")
        throw new Error(`Malformed $integer field on ${e}`);
      return Wg(e.$integer);
    }
    if (i === "$float") {
      if (typeof e.$float != "string")
        throw new Error(`Malformed $float field on ${e}`);
      let r = ur(e.$float);
      if (r.byteLength !== 8)
        throw new Error(
          `Received ${r.byteLength} bytes, expected 8 for $float`
        );
      let a = new DataView(r.buffer).getFloat64(0, Xd);
      if (!Qd(a))
        throw new Error(`Float ${a} should be encoded as a number`);
      return a;
    }
    if (i === "$set")
      throw new Error(
        "Received a Set which is no longer supported as a Convex type."
      );
    if (i === "$map")
      throw new Error(
        "Received a Map which is no longer supported as a Convex type."
      );
  }
  let n = {};
  for (let [i, r] of Object.entries(e))
    _o(i), n[i] = J(r);
  return n;
}
s(J, "jsonToConvex");
var Gd = 16384;
function Qe(e) {
  let t = JSON.stringify(e, (n, i) => i === void 0 ? "undefined" : typeof i == "bigint" ? `${i.toString()}n` : i);
  if (t.length > Gd) {
    let n = "[...truncated]", i = Gd - n.length, r = t.codePointAt(i - 1);
    return r !== void 0 && r > 65535 && (i -= 1), t.substring(0, i) + n;
  }
  return t;
}
s(Qe, "stringifyValueForError");
function dr(e, t, n, i) {
  if (e === void 0) {
    let a = n && ` (present at path ${n} in original object ${Qe(
      t
    )})`;
    throw new Error(
      `undefined is not a valid Convex value${a}. To learn about Convex's supported types, see https://docs.convex.dev/using/types.`
    );
  }
  if (e === null)
    return e;
  if (typeof e == "bigint") {
    if (e < yt || wo < e)
      throw new Error(
        `BigInt ${e} does not fit into a 64-bit signed integer.`
      );
    return { $integer: qg(e) };
  }
  if (typeof e == "number")
    if (Qd(e)) {
      let a = new ArrayBuffer(8);
      return new DataView(a).setFloat64(0, e, Xd), { $float: lr(new Uint8Array(a)) };
    } else
      return e;
  if (typeof e == "boolean" || typeof e == "string")
    return e;
  if (e instanceof ArrayBuffer)
    return { $bytes: lr(new Uint8Array(e)) };
  if (Array.isArray(e))
    return e.map(
      (a, c) => dr(a, t, n + `[${c}]`, !1)
    );
  if (e instanceof Set)
    throw new Error(
      $o(n, "Set", [...e], t)
    );
  if (e instanceof Map)
    throw new Error(
      $o(n, "Map", [...e], t)
    );
  if (!nn(e)) {
    let a = e?.constructor?.name, c = a ? `${a} ` : "";
    throw new Error(
      $o(n, c, e, t)
    );
  }
  let r = {}, o = Object.entries(e);
  o.sort(([a, c], [u, l]) => a === u ? 0 : a < u ? -1 : 1);
  for (let [a, c] of o)
    c !== void 0 ? (_o(a), r[a] = dr(c, t, n + `.${a}`, !1)) : i && (_o(a), r[a] = Hd(
      c,
      t,
      n + `.${a}`
    ));
  return r;
}
s(dr, "convexToJsonInternal");
function $o(e, t, n, i) {
  return e ? `${t}${Qe(
    n
  )} is not a supported Convex type (present at path ${e} in original object ${Qe(
    i
  )}). To learn about Convex's supported types, see https://docs.convex.dev/using/types.` : `${t}${Qe(
    n
  )} is not a supported Convex type.`;
}
s($o, "errorMessageForUnsupportedType");
function Hd(e, t, n) {
  if (e === void 0)
    return { $undefined: null };
  if (t === void 0)
    throw new Error(
      `Programming error. Current value is ${Qe(
        e
      )} but original value is undefined`
    );
  return dr(e, t, n, !1);
}
s(Hd, "convexOrUndefinedToJsonInternal");
function F(e) {
  return dr(e, e, "", !1);
}
s(F, "convexToJson");
function pe(e) {
  return Hd(e, e, "");
}
s(pe, "convexOrUndefinedToJson");
function Yd(e) {
  return dr(e, e, "", !0);
}
s(Yd, "patchValueToJson");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/validators.js
var Kg = Object.defineProperty, Gg = /* @__PURE__ */ s((e, t, n) => t in e ? Kg(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), M = /* @__PURE__ */ s((e, t, n) => Gg(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), Xg = "https://docs.convex.dev/error#undefined-validator";
function fr(e, t) {
  let n = t !== void 0 ? ` for field "${t}"` : "";
  throw new Error(
    `A validator is undefined${n} in ${e}. This is often caused by circular imports. See ${Xg} for details.`
  );
}
s(fr, "throwUndefinedValidatorError");
var ee = class {
  static {
    s(this, "BaseValidator");
  }
  constructor({ isOptional: t }) {
    M(this, "type"), M(this, "fieldPaths"), M(this, "isOptional"), M(this, "isConvexValidator"), this.isOptional = t, this.isConvexValidator = !0;
  }
}, on = class e extends ee {
  static {
    s(this, "VId");
  }
  /**
   * Usually you'd use `v.id(tableName)` instead.
   */
  constructor({
    isOptional: t,
    tableName: n
  }) {
    if (super({ isOptional: t }), M(this, "tableName"), M(this, "kind", "id"), typeof n != "string")
      throw new Error("v.id(tableName) requires a string");
    this.tableName = n;
  }
  /** @internal */
  get json() {
    return { type: "id", tableName: this.tableName };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      tableName: this.tableName
    });
  }
}, pr = class e extends ee {
  static {
    s(this, "VFloat64");
  }
  constructor() {
    super(...arguments), M(this, "kind", "float64");
  }
  /** @internal */
  get json() {
    return { type: "number" };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, mr = class e extends ee {
  static {
    s(this, "VInt64");
  }
  constructor() {
    super(...arguments), M(this, "kind", "int64");
  }
  /** @internal */
  get json() {
    return { type: "bigint" };
  }
  /** @internal */
  asOptional() {
    return new e({ isOptional: "optional" });
  }
}, an = class e extends ee {
  static {
    s(this, "VBoolean");
  }
  constructor() {
    super(...arguments), M(this, "kind", "boolean");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, sn = class e extends ee {
  static {
    s(this, "VBytes");
  }
  constructor() {
    super(...arguments), M(this, "kind", "bytes");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({ isOptional: "optional" });
  }
}, cn = class e extends ee {
  static {
    s(this, "VString");
  }
  constructor() {
    super(...arguments), M(this, "kind", "string");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, un = class e extends ee {
  static {
    s(this, "VNull");
  }
  constructor() {
    super(...arguments), M(this, "kind", "null");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({ isOptional: "optional" });
  }
}, ln = class e extends ee {
  static {
    s(this, "VAny");
  }
  constructor() {
    super(...arguments), M(this, "kind", "any");
  }
  /** @internal */
  get json() {
    return {
      type: this.kind
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, dn = class e extends ee {
  static {
    s(this, "VObject");
  }
  /**
   * Usually you'd use `v.object({ ... })` instead.
   */
  constructor({
    isOptional: t,
    fields: n
  }) {
    super({ isOptional: t }), M(this, "fields"), M(this, "kind", "object"), globalThis.Object.entries(n).forEach(([i, r]) => {
      if (r === void 0 && fr("v.object()", i), !r.isConvexValidator)
        throw new Error("v.object() entries must be validators");
    }), this.fields = n;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: globalThis.Object.fromEntries(
        globalThis.Object.entries(this.fields).map(([t, n]) => [
          t,
          {
            fieldType: n.json,
            optional: n.isOptional === "optional"
          }
        ])
      )
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      fields: this.fields
    });
  }
  /**
   * Create a new VObject with the specified fields omitted.
   * @param fields The field names to omit from this VObject.
   */
  omit(...t) {
    let n = { ...this.fields };
    for (let i of t)
      delete n[i];
    return new e({
      isOptional: this.isOptional,
      fields: n
    });
  }
  /**
   * Create a new VObject with only the specified fields.
   * @param fields The field names to pick from this VObject.
   */
  pick(...t) {
    let n = {};
    for (let i of t)
      n[i] = this.fields[i];
    return new e({
      isOptional: this.isOptional,
      fields: n
    });
  }
  /**
   * Create a new VObject with all fields marked as optional.
   */
  partial() {
    let t = {};
    for (let [n, i] of globalThis.Object.entries(this.fields))
      t[n] = i.asOptional();
    return new e({
      isOptional: this.isOptional,
      fields: t
    });
  }
  /**
   * Create a new VObject with additional fields merged in.
   * @param fields An object with additional validators to merge into this VObject.
   */
  extend(t) {
    return new e({
      isOptional: this.isOptional,
      fields: { ...this.fields, ...t }
    });
  }
}, fn = class e extends ee {
  static {
    s(this, "VLiteral");
  }
  /**
   * Usually you'd use `v.literal(value)` instead.
   */
  constructor({ isOptional: t, value: n }) {
    if (super({ isOptional: t }), M(this, "value"), M(this, "kind", "literal"), typeof n != "string" && typeof n != "boolean" && typeof n != "number" && typeof n != "bigint")
      throw new Error("v.literal(value) must be a string, number, or boolean");
    this.value = n;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: F(this.value)
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      value: this.value
    });
  }
}, pn = class e extends ee {
  static {
    s(this, "VArray");
  }
  /**
   * Usually you'd use `v.array(element)` instead.
   */
  constructor({
    isOptional: t,
    element: n
  }) {
    super({ isOptional: t }), M(this, "element"), M(this, "kind", "array"), n === void 0 && fr("v.array()"), this.element = n;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: this.element.json
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      element: this.element
    });
  }
}, mn = class e extends ee {
  static {
    s(this, "VRecord");
  }
  /**
   * Usually you'd use `v.record(key, value)` instead.
   */
  constructor({
    isOptional: t,
    key: n,
    value: i
  }) {
    if (super({ isOptional: t }), M(this, "key"), M(this, "value"), M(this, "kind", "record"), n === void 0 && fr("v.record()", "key"), i === void 0 && fr("v.record()", "value"), n.isOptional === "optional")
      throw new Error("Record validator cannot have optional keys");
    if (i.isOptional === "optional")
      throw new Error("Record validator cannot have optional values");
    if (!n.isConvexValidator || !i.isConvexValidator)
      throw new Error("Key and value of v.record() but be validators");
    this.key = n, this.value = i;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      // This cast is needed because TypeScript thinks the key type is too wide
      keys: this.key.json,
      values: {
        fieldType: this.value.json,
        optional: !1
      }
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      key: this.key,
      value: this.value
    });
  }
}, gn = class e extends ee {
  static {
    s(this, "VUnion");
  }
  /**
   * Usually you'd use `v.union(...members)` instead.
   */
  constructor({ isOptional: t, members: n }) {
    super({ isOptional: t }), M(this, "members"), M(this, "kind", "union"), n.forEach((i, r) => {
      if (i === void 0 && fr("v.union()", `member at index ${r}`), !i.isConvexValidator)
        throw new Error("All members of v.union() must be validators");
    }), this.members = n;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: this.members.map((t) => t.json)
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      members: this.members
    });
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/validator.js
function ko(e) {
  return !!e.isConvexValidator;
}
s(ko, "isValidator");
function gr(e) {
  return ko(e) ? e : g.object(e);
}
s(gr, "asObjectValidator");
var g = {
  /**
   * Validates that the value is a document ID for the given table.
   *
   * IDs are strings at runtime but are typed as `Id<"tableName">` in
   * TypeScript for type safety.
   *
   * @example
   * ```typescript
   * args: { userId: v.id("users") }
   * ```
   *
   * @param tableName The name of the table.
   */
  id: /* @__PURE__ */ s((e) => new on({
    isOptional: "required",
    tableName: e
  }), "id"),
  /**
   * Validates that the value is `null`.
   *
   * Use `returns: v.null()` for functions that don't return a meaningful value.
   * JavaScript `undefined` is not a valid Convex value, it is automatically
   * converted to `null`.
   */
  null: /* @__PURE__ */ s(() => new un({ isOptional: "required" }), "null"),
  /**
   * Validates that the value is a JavaScript `number` (Convex Float64).
   *
   * Supports all IEEE-754 double-precision floating point numbers including
   * NaN and Infinity.
   *
   * Alias for `v.float64()`.
   */
  number: /* @__PURE__ */ s(() => new pr({ isOptional: "required" }), "number"),
  /**
   * Validates that the value is a JavaScript `number` (Convex Float64).
   *
   * Supports all IEEE-754 double-precision floating point numbers.
   */
  float64: /* @__PURE__ */ s(() => new pr({ isOptional: "required" }), "float64"),
  /**
   * @deprecated Use `v.int64()` instead.
   */
  bigint: /* @__PURE__ */ s(() => new mr({ isOptional: "required" }), "bigint"),
  /**
   * Validates that the value is a JavaScript `bigint` (Convex Int64).
   *
   * Supports BigInts between -2^63 and 2^63-1.
   *
   * @example
   * ```typescript
   * args: { timestamp: v.int64() }
   * // Usage: createDoc({ timestamp: 1234567890n })
   * ```
   */
  int64: /* @__PURE__ */ s(() => new mr({ isOptional: "required" }), "int64"),
  /**
   * Validates that the value is a `boolean`.
   */
  boolean: /* @__PURE__ */ s(() => new an({ isOptional: "required" }), "boolean"),
  /**
   * Validates that the value is a `string`.
   *
   * Strings are stored as UTF-8 and their storage size is calculated as their
   * UTF-8 encoded size.
   */
  string: /* @__PURE__ */ s(() => new cn({ isOptional: "required" }), "string"),
  /**
   * Validates that the value is an `ArrayBuffer` (Convex Bytes).
   *
   * Use for binary data.
   */
  bytes: /* @__PURE__ */ s(() => new sn({ isOptional: "required" }), "bytes"),
  /**
   * Validates that the value is exactly equal to the given literal.
   *
   * Useful for discriminated unions and enum-like patterns.
   *
   * @example
   * ```typescript
   * // Discriminated union pattern:
   * v.union(
   *   v.object({ kind: v.literal("error"), message: v.string() }),
   *   v.object({ kind: v.literal("success"), value: v.number() }),
   * )
   * ```
   *
   * @param literal The literal value to compare against.
   */
  literal: /* @__PURE__ */ s((e) => new fn({ isOptional: "required", value: e }), "literal"),
  /**
   * Validates that the value is an `Array` where every element matches the
   * given validator.
   *
   * Arrays can have at most 8192 elements.
   *
   * @example
   * ```typescript
   * args: { tags: v.array(v.string()) }
   * args: { coordinates: v.array(v.number()) }
   * args: { items: v.array(v.object({ name: v.string(), qty: v.number() })) }
   * ```
   *
   * @param element The validator for the elements of the array.
   */
  array: /* @__PURE__ */ s((e) => new pn({ isOptional: "required", element: e }), "array"),
  /**
   * Validates that the value is an `Object` with the specified properties.
   *
   * Objects can have at most 1024 entries. Field names must be non-empty and
   * must not start with `"$"` or `"_"` (`_` is reserved for system fields
   * like `_id` and `_creationTime`; `$` is reserved for Convex internal use).
   *
   * @example
   * ```typescript
   * args: {
   *   user: v.object({
   *     name: v.string(),
   *     email: v.string(),
   *     age: v.optional(v.number()),
   *   })
   * }
   * ```
   *
   * @param fields An object mapping property names to their validators.
   */
  object: /* @__PURE__ */ s((e) => new dn({ isOptional: "required", fields: e }), "object"),
  /**
   * Validates that the value is a `Record` (object with dynamic keys).
   *
   * Records are objects at runtime but allow dynamic keys, unlike `v.object()`
   * which requires known property names. Keys must be ASCII characters only,
   * non-empty, and not start with `"$"` or `"_"`.
   *
   * @example
   * ```typescript
   * // Map of user IDs to scores:
   * args: { scores: v.record(v.id("users"), v.number()) }
   *
   * // Map of string keys to string values:
   * args: { metadata: v.record(v.string(), v.string()) }
   * ```
   *
   * @param keys The validator for the keys of the record.
   * @param values The validator for the values of the record.
   */
  record: /* @__PURE__ */ s((e, t) => new mn({
    isOptional: "required",
    key: e,
    value: t
  }), "record"),
  /**
   * Validates that the value matches at least one of the given validators.
   *
   * @example
   * ```typescript
   * // Allow string or number:
   * args: { value: v.union(v.string(), v.number()) }
   *
   * // Discriminated union (recommended pattern):
   * v.union(
   *   v.object({ kind: v.literal("text"), body: v.string() }),
   *   v.object({ kind: v.literal("image"), url: v.string() }),
   * )
   *
   * // Nullable value:
   * returns: v.union(v.object({ ... }), v.null())
   * ```
   *
   * @param members The validators to match against.
   */
  union: /* @__PURE__ */ s((...e) => new gn({
    isOptional: "required",
    members: e
  }), "union"),
  /**
   * A validator that accepts any Convex value without validation.
   *
   * Prefer using specific validators when possible for better type safety
   * and runtime validation.
   */
  any: /* @__PURE__ */ s(() => new ln({ isOptional: "required" }), "any"),
  /**
   * Makes a property optional in an object validator.
   *
   * An optional property can be omitted entirely when creating a document or
   * calling a function. This is different from `v.nullable()` which requires
   * the property to be present but allows `null`.
   *
   * @example
   * ```typescript
   * v.object({
   *   name: v.string(),              // required
   *   nickname: v.optional(v.string()), // can be omitted
   * })
   *
   * // Valid: { name: "Alice" }
   * // Valid: { name: "Alice", nickname: "Ali" }
   * // Invalid: { name: "Alice", nickname: null }  - use v.nullable() for this
   * ```
   *
   * @param value The property value validator to make optional.
   */
  optional: /* @__PURE__ */ s((e) => e.asOptional(), "optional"),
  /**
   * Allows a value to be either the given type or `null`.
   *
   * This is shorthand for `v.union(value, v.null())`. Unlike `v.optional()`,
   * the property must still be present, but may be `null`.
   *
   * @example
   * ```typescript
   * v.object({
   *   name: v.string(),
   *   deletedAt: v.nullable(v.number()), // must be present, can be null
   * })
   *
   * // Valid: { name: "Alice", deletedAt: null }
   * // Valid: { name: "Alice", deletedAt: 1234567890 }
   * // Invalid: { name: "Alice" }  - deletedAt is required
   * ```
   */
  nullable: /* @__PURE__ */ s((e) => g.union(e, g.null()), "nullable")
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/errors.js
var Qg = Object.defineProperty, Hg = /* @__PURE__ */ s((e, t, n) => t in e ? Qg(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), zo = /* @__PURE__ */ s((e, t, n) => Hg(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), ef, tf, Yg = Symbol.for("ConvexError"), bt = class extends (tf = Error, ef = Yg, tf) {
  static {
    s(this, "ConvexError");
  }
  constructor(t) {
    super(typeof t == "string" ? t : Qe(t)), zo(this, "name", "ConvexError"), zo(this, "data"), zo(this, ef, !0), this.data = t;
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/compare_utf8.js
var rf = /* @__PURE__ */ s(() => Array.from({ length: 4 }, () => 0), "arr"), L$ = rf(), M$ = rf();

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/index.js
var X = "1.32.0";

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/syscall.js
function hr(e, t) {
  if (typeof Convex > "u" || Convex.syscall === void 0)
    throw new Error(
      "The Convex database and auth objects are being used outside of a Convex backend. Did you mean to use `useQuery` or `useMutation` to call a Convex function?"
    );
  let n = Convex.syscall(e, JSON.stringify(t));
  return JSON.parse(n);
}
s(hr, "performSyscall");
async function U(e, t) {
  if (typeof Convex > "u" || Convex.asyncSyscall === void 0)
    throw new Error(
      "The Convex database and auth objects are being used outside of a Convex backend. Did you mean to use `useQuery` or `useMutation` to call a Convex function?"
    );
  let n;
  try {
    n = await Convex.asyncSyscall(e, JSON.stringify(t));
  } catch (i) {
    if (i.data !== void 0) {
      let r = new bt(i.message);
      throw r.data = J(i.data), r;
    }
    throw new Error(i.message);
  }
  return JSON.parse(n);
}
s(U, "performAsyncSyscall");
function hn(e, t) {
  if (typeof Convex > "u" || Convex.jsSyscall === void 0)
    throw new Error(
      "The Convex database and auth objects are being used outside of a Convex backend. Did you mean to use `useQuery` or `useMutation` to call a Convex function?"
    );
  return Convex.jsSyscall(e, t);
}
s(hn, "performJsSyscall");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/functionName.js
var vr = Symbol.for("functionName");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/components/paths.js
var nf = Symbol.for("toReferencePath");
function th(e) {
  return e[nf] ?? null;
}
s(th, "extractReferencePath");
function rh(e) {
  return e.startsWith("function://");
}
s(rh, "isFunctionHandle");
function ge(e) {
  let t;
  if (typeof e == "string")
    rh(e) ? t = { functionHandle: e } : t = { name: e };
  else if (e[vr])
    t = { name: e[vr] };
  else {
    let n = th(e);
    if (!n)
      throw new Error(`${e} is not a functionReference`);
    t = { reference: n };
  }
  return t;
}
s(ge, "getFunctionAddress");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/actions_impl.js
function Io(e, t, n) {
  return {
    ...ge(t),
    args: F(De(n)),
    version: X,
    requestId: e
  };
}
s(Io, "syscallArgs");
function of(e) {
  return {
    runQuery: /* @__PURE__ */ s(async (t, n) => {
      let i = await U(
        "1.0/actions/query",
        Io(e, t, n)
      );
      return J(i);
    }, "runQuery"),
    runMutation: /* @__PURE__ */ s(async (t, n) => {
      let i = await U(
        "1.0/actions/mutation",
        Io(e, t, n)
      );
      return J(i);
    }, "runMutation"),
    runAction: /* @__PURE__ */ s(async (t, n) => {
      let i = await U(
        "1.0/actions/action",
        Io(e, t, n)
      );
      return J(i);
    }, "runAction")
  };
}
s(of, "setupActionCalls");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/vector_search.js
var nh = Object.defineProperty, ih = /* @__PURE__ */ s((e, t, n) => t in e ? nh(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), af = /* @__PURE__ */ s((e, t, n) => ih(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), vn = class {
  static {
    s(this, "FilterExpression");
  }
  /**
   * @internal
   */
  constructor() {
    af(this, "_isExpression"), af(this, "_value");
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/validate.js
function E(e, t, n, i) {
  if (e === void 0)
    throw new TypeError(
      `Must provide arg ${t} \`${i}\` to \`${n}\``
    );
}
s(E, "validateArg");
function sf(e, t, n, i) {
  if (!Number.isInteger(e) || e < 0)
    throw new TypeError(
      `Arg ${t} \`${i}\` to \`${n}\` must be a non-negative integer`
    );
}
s(sf, "validateArgIsNonNegativeInteger");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/vector_search_impl.js
var oh = Object.defineProperty, ah = /* @__PURE__ */ s((e, t, n) => t in e ? oh(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), So = /* @__PURE__ */ s((e, t, n) => ah(e, typeof t != "symbol" ? t + "" : t, n), "__publicField");
function cf(e) {
  return async (t, n, i) => {
    if (E(t, 1, "vectorSearch", "tableName"), E(n, 2, "vectorSearch", "indexName"), E(i, 3, "vectorSearch", "query"), !i.vector || !Array.isArray(i.vector) || i.vector.length === 0)
      throw Error("`vector` must be a non-empty Array in vectorSearch");
    return await new jo(
      e,
      t + "." + n,
      i
    ).collect();
  };
}
s(cf, "setupActionVectorSearch");
var jo = class {
  static {
    s(this, "VectorQueryImpl");
  }
  constructor(t, n, i) {
    So(this, "requestId"), So(this, "state"), this.requestId = t;
    let r = i.filter ? yn(i.filter(sh)) : null;
    this.state = {
      type: "preparing",
      query: {
        indexName: n,
        limit: i.limit,
        vector: i.vector,
        expressions: r
      }
    };
  }
  async collect() {
    if (this.state.type === "consumed")
      throw new Error("This query is closed and can't emit any more values.");
    let t = this.state.query;
    this.state = { type: "consumed" };
    let { results: n } = await U("1.0/actions/vectorSearch", {
      requestId: this.requestId,
      version: X,
      query: t
    });
    return n;
  }
}, $t = class extends vn {
  static {
    s(this, "ExpressionImpl");
  }
  constructor(t) {
    super(), So(this, "inner"), this.inner = t;
  }
  serialize() {
    return this.inner;
  }
};
function yn(e) {
  return e instanceof $t ? e.serialize() : { $literal: pe(e) };
}
s(yn, "serializeExpression");
var sh = {
  //  Comparisons  /////////////////////////////////////////////////////////////
  eq(e, t) {
    if (typeof e != "string")
      throw new Error("The first argument to `q.eq` must be a field name.");
    return new $t({
      $eq: [
        yn(new $t({ $field: e })),
        yn(t)
      ]
    });
  },
  //  Logic  ///////////////////////////////////////////////////////////////////
  or(...e) {
    return new $t({ $or: e.map(yn) });
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/authentication_impl.js
function bn(e) {
  return {
    getUserIdentity: /* @__PURE__ */ s(async () => await U("1.0/getUserIdentity", {
      requestId: e
    }), "getUserIdentity")
  };
}
s(bn, "setupAuth");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/filter_builder.js
var ch = Object.defineProperty, uh = /* @__PURE__ */ s((e, t, n) => t in e ? ch(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), uf = /* @__PURE__ */ s((e, t, n) => uh(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), $n = class {
  static {
    s(this, "Expression");
  }
  /**
   * @internal
   */
  constructor() {
    uf(this, "_isExpression"), uf(this, "_value");
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/filter_builder_impl.js
var lh = Object.defineProperty, dh = /* @__PURE__ */ s((e, t, n) => t in e ? lh(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), fh = /* @__PURE__ */ s((e, t, n) => dh(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), Q = class extends $n {
  static {
    s(this, "ExpressionImpl");
  }
  constructor(t) {
    super(), fh(this, "inner"), this.inner = t;
  }
  serialize() {
    return this.inner;
  }
};
function Z(e) {
  return e instanceof Q ? e.serialize() : { $literal: pe(e) };
}
s(Z, "serializeExpression");
var lf = {
  //  Comparisons  /////////////////////////////////////////////////////////////
  eq(e, t) {
    return new Q({
      $eq: [Z(e), Z(t)]
    });
  },
  neq(e, t) {
    return new Q({
      $neq: [Z(e), Z(t)]
    });
  },
  lt(e, t) {
    return new Q({
      $lt: [Z(e), Z(t)]
    });
  },
  lte(e, t) {
    return new Q({
      $lte: [Z(e), Z(t)]
    });
  },
  gt(e, t) {
    return new Q({
      $gt: [Z(e), Z(t)]
    });
  },
  gte(e, t) {
    return new Q({
      $gte: [Z(e), Z(t)]
    });
  },
  //  Arithmetic  //////////////////////////////////////////////////////////////
  add(e, t) {
    return new Q({
      $add: [Z(e), Z(t)]
    });
  },
  sub(e, t) {
    return new Q({
      $sub: [Z(e), Z(t)]
    });
  },
  mul(e, t) {
    return new Q({
      $mul: [Z(e), Z(t)]
    });
  },
  div(e, t) {
    return new Q({
      $div: [Z(e), Z(t)]
    });
  },
  mod(e, t) {
    return new Q({
      $mod: [Z(e), Z(t)]
    });
  },
  neg(e) {
    return new Q({ $neg: Z(e) });
  },
  //  Logic  ///////////////////////////////////////////////////////////////////
  and(...e) {
    return new Q({ $and: e.map(Z) });
  },
  or(...e) {
    return new Q({ $or: e.map(Z) });
  },
  not(e) {
    return new Q({ $not: Z(e) });
  },
  //  Other  ///////////////////////////////////////////////////////////////////
  field(e) {
    return new Q({ $field: e });
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/index_range_builder.js
var ph = Object.defineProperty, mh = /* @__PURE__ */ s((e, t, n) => t in e ? ph(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), gh = /* @__PURE__ */ s((e, t, n) => mh(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), xn = class {
  static {
    s(this, "IndexRange");
  }
  /**
   * @internal
   */
  constructor() {
    gh(this, "_isIndexRange");
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/index_range_builder_impl.js
var hh = Object.defineProperty, vh = /* @__PURE__ */ s((e, t, n) => t in e ? hh(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), df = /* @__PURE__ */ s((e, t, n) => vh(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), _n = class e extends xn {
  static {
    s(this, "IndexRangeBuilderImpl");
  }
  constructor(t) {
    super(), df(this, "rangeExpressions"), df(this, "isConsumed"), this.rangeExpressions = t, this.isConsumed = !1;
  }
  static new() {
    return new e([]);
  }
  consume() {
    if (this.isConsumed)
      throw new Error(
        "IndexRangeBuilder has already been used! Chain your method calls like `q => q.eq(...).eq(...)`. See https://docs.convex.dev/using/indexes"
      );
    this.isConsumed = !0;
  }
  eq(t, n) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Eq",
        fieldPath: t,
        value: pe(n)
      })
    );
  }
  gt(t, n) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Gt",
        fieldPath: t,
        value: pe(n)
      })
    );
  }
  gte(t, n) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Gte",
        fieldPath: t,
        value: pe(n)
      })
    );
  }
  lt(t, n) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Lt",
        fieldPath: t,
        value: pe(n)
      })
    );
  }
  lte(t, n) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Lte",
        fieldPath: t,
        value: pe(n)
      })
    );
  }
  export() {
    return this.consume(), this.rangeExpressions;
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/search_filter_builder.js
var yh = Object.defineProperty, bh = /* @__PURE__ */ s((e, t, n) => t in e ? yh(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), $h = /* @__PURE__ */ s((e, t, n) => bh(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), wn = class {
  static {
    s(this, "SearchFilter");
  }
  /**
   * @internal
   */
  constructor() {
    $h(this, "_isSearchFilter");
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/search_filter_builder_impl.js
var xh = Object.defineProperty, _h = /* @__PURE__ */ s((e, t, n) => t in e ? xh(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), ff = /* @__PURE__ */ s((e, t, n) => _h(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), kn = class e extends wn {
  static {
    s(this, "SearchFilterBuilderImpl");
  }
  constructor(t) {
    super(), ff(this, "filters"), ff(this, "isConsumed"), this.filters = t, this.isConsumed = !1;
  }
  static new() {
    return new e([]);
  }
  consume() {
    if (this.isConsumed)
      throw new Error(
        "SearchFilterBuilder has already been used! Chain your method calls like `q => q.search(...).eq(...)`."
      );
    this.isConsumed = !0;
  }
  search(t, n) {
    return E(t, 1, "search", "fieldName"), E(n, 2, "search", "query"), this.consume(), new e(
      this.filters.concat({
        type: "Search",
        fieldPath: t,
        value: n
      })
    );
  }
  eq(t, n) {
    return E(t, 1, "eq", "fieldName"), arguments.length !== 2 && E(n, 2, "search", "value"), this.consume(), new e(
      this.filters.concat({
        type: "Eq",
        fieldPath: t,
        value: pe(n)
      })
    );
  }
  export() {
    return this.consume(), this.filters;
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/query_impl.js
var wh = Object.defineProperty, kh = /* @__PURE__ */ s((e, t, n) => t in e ? wh(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), Oo = /* @__PURE__ */ s((e, t, n) => kh(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), pf = 256, xt = class {
  static {
    s(this, "QueryInitializerImpl");
  }
  constructor(t) {
    Oo(this, "tableName"), this.tableName = t;
  }
  withIndex(t, n) {
    E(t, 1, "withIndex", "indexName");
    let i = _n.new();
    return n !== void 0 && (i = n(i)), new He({
      source: {
        type: "IndexRange",
        indexName: this.tableName + "." + t,
        range: i.export(),
        order: null
      },
      operators: []
    });
  }
  withSearchIndex(t, n) {
    E(t, 1, "withSearchIndex", "indexName"), E(n, 2, "withSearchIndex", "searchFilter");
    let i = kn.new();
    return new He({
      source: {
        type: "Search",
        indexName: this.tableName + "." + t,
        filters: n(i).export()
      },
      operators: []
    });
  }
  fullTableScan() {
    return new He({
      source: {
        type: "FullTableScan",
        tableName: this.tableName,
        order: null
      },
      operators: []
    });
  }
  order(t) {
    return this.fullTableScan().order(t);
  }
  // This is internal API and should not be exposed to developers yet.
  async count() {
    let t = await U("1.0/count", {
      table: this.tableName
    });
    return J(t);
  }
  filter(t) {
    return this.fullTableScan().filter(t);
  }
  limit(t) {
    return this.fullTableScan().limit(t);
  }
  collect() {
    return this.fullTableScan().collect();
  }
  take(t) {
    return this.fullTableScan().take(t);
  }
  paginate(t) {
    return this.fullTableScan().paginate(t);
  }
  first() {
    return this.fullTableScan().first();
  }
  unique() {
    return this.fullTableScan().unique();
  }
  [Symbol.asyncIterator]() {
    return this.fullTableScan()[Symbol.asyncIterator]();
  }
};
function mf(e) {
  throw new Error(
    e === "consumed" ? "This query is closed and can't emit any more values." : "This query has been chained with another operator and can't be reused."
  );
}
s(mf, "throwClosedError");
var He = class e {
  static {
    s(this, "QueryImpl");
  }
  constructor(t) {
    Oo(this, "state"), Oo(this, "tableNameForErrorMessages"), this.state = { type: "preparing", query: t }, t.source.type === "FullTableScan" ? this.tableNameForErrorMessages = t.source.tableName : this.tableNameForErrorMessages = t.source.indexName.split(".")[0];
  }
  takeQuery() {
    if (this.state.type !== "preparing")
      throw new Error(
        "A query can only be chained once and can't be chained after iteration begins."
      );
    let t = this.state.query;
    return this.state = { type: "closed" }, t;
  }
  startQuery() {
    if (this.state.type === "executing")
      throw new Error("Iteration can only begin on a query once.");
    (this.state.type === "closed" || this.state.type === "consumed") && mf(this.state.type);
    let t = this.state.query, { queryId: n } = hr("1.0/queryStream", { query: t, version: X });
    return this.state = { type: "executing", queryId: n }, n;
  }
  closeQuery() {
    if (this.state.type === "executing") {
      let t = this.state.queryId;
      hr("1.0/queryCleanup", { queryId: t });
    }
    this.state = { type: "consumed" };
  }
  order(t) {
    E(t, 1, "order", "order");
    let n = this.takeQuery();
    if (n.source.type === "Search")
      throw new Error(
        "Search queries must always be in relevance order. Can not set order manually."
      );
    if (n.source.order !== null)
      throw new Error("Queries may only specify order at most once");
    return n.source.order = t, new e(n);
  }
  filter(t) {
    E(t, 1, "filter", "predicate");
    let n = this.takeQuery();
    if (n.operators.length >= pf)
      throw new Error(
        `Can't construct query with more than ${pf} operators`
      );
    return n.operators.push({
      filter: Z(t(lf))
    }), new e(n);
  }
  limit(t) {
    E(t, 1, "limit", "n");
    let n = this.takeQuery();
    return n.operators.push({ limit: t }), new e(n);
  }
  [Symbol.asyncIterator]() {
    return this.startQuery(), this;
  }
  async next() {
    (this.state.type === "closed" || this.state.type === "consumed") && mf(this.state.type);
    let t = this.state.type === "preparing" ? this.startQuery() : this.state.queryId, { value: n, done: i } = await U("1.0/queryStreamNext", {
      queryId: t
    });
    return i && this.closeQuery(), { value: J(n), done: i };
  }
  return() {
    return this.closeQuery(), Promise.resolve({ done: !0, value: void 0 });
  }
  async paginate(t) {
    if (E(t, 1, "paginate", "options"), typeof t?.numItems != "number" || t.numItems < 0)
      throw new Error(
        `\`options.numItems\` must be a positive number. Received \`${t?.numItems}\`.`
      );
    let n = this.takeQuery(), i = t.numItems, r = t.cursor, o = t?.endCursor ?? null, a = t.maximumRowsRead ?? null, { page: c, isDone: u, continueCursor: l, splitCursor: d, pageStatus: m } = await U("1.0/queryPage", {
      query: n,
      cursor: r,
      endCursor: o,
      pageSize: i,
      maximumRowsRead: a,
      maximumBytesRead: t.maximumBytesRead,
      version: X
    });
    return {
      page: c.map((y) => J(y)),
      isDone: u,
      continueCursor: l,
      splitCursor: d,
      pageStatus: m
    };
  }
  async collect() {
    let t = [];
    for await (let n of this)
      t.push(n);
    return t;
  }
  async take(t) {
    return E(t, 1, "take", "n"), sf(t, 1, "take", "n"), this.limit(t).collect();
  }
  async first() {
    let t = await this.take(1);
    return t.length === 0 ? null : t[0];
  }
  async unique() {
    let t = await this.take(2);
    if (t.length === 0)
      return null;
    if (t.length === 2)
      throw new Error(`unique() query returned more than one result from table ${this.tableNameForErrorMessages}:
 [${t[0]._id}, ${t[1]._id}, ...]`);
    return t[0];
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/database_impl.js
async function Po(e, t, n) {
  if (E(t, 1, "get", "id"), typeof t != "string")
    throw new Error(
      `Invalid argument \`id\` for \`db.get\`, expected string but got '${typeof t}': ${t}`
    );
  let i = {
    id: F(t),
    isSystem: n,
    version: X,
    table: e
  }, r = await U("1.0/get", i);
  return J(r);
}
s(Po, "get");
function No() {
  let e = /* @__PURE__ */ s((r = !1) => ({
    get: /* @__PURE__ */ s(async (o, a) => a !== void 0 ? await Po(o, a, r) : await Po(void 0, o, r), "get"),
    query: /* @__PURE__ */ s((o) => new yr(o, r).query(), "query"),
    normalizeId: /* @__PURE__ */ s((o, a) => {
      E(o, 1, "normalizeId", "tableName"), E(a, 2, "normalizeId", "id");
      let c = o.startsWith("_");
      if (c !== r)
        throw new Error(
          `${c ? "System" : "User"} tables can only be accessed from db.${r ? "" : "system."}normalizeId().`
        );
      let u = hr("1.0/db/normalizeId", {
        table: o,
        idString: a
      });
      return J(u).id;
    }, "normalizeId"),
    // We set the system reader on the next line
    system: null,
    table: /* @__PURE__ */ s((o) => new yr(o, r), "table")
  }), "reader"), { system: t, ...n } = e(!0), i = e();
  return i.system = n, i;
}
s(No, "setupReader");
async function gf(e, t) {
  if (e.startsWith("_"))
    throw new Error("System tables (prefixed with `_`) are read-only.");
  E(e, 1, "insert", "table"), E(t, 2, "insert", "value");
  let n = await U("1.0/insert", {
    table: e,
    value: F(t)
  });
  return J(n)._id;
}
s(gf, "insert");
async function To(e, t, n) {
  E(t, 1, "patch", "id"), E(n, 2, "patch", "value"), await U("1.0/shallowMerge", {
    id: F(t),
    value: Yd(n),
    table: e
  });
}
s(To, "patch");
async function Eo(e, t, n) {
  E(t, 1, "replace", "id"), E(n, 2, "replace", "value"), await U("1.0/replace", {
    id: F(t),
    value: F(n),
    table: e
  });
}
s(Eo, "replace");
async function Uo(e, t) {
  E(t, 1, "delete", "id"), await U("1.0/remove", {
    id: F(t),
    table: e
  });
}
s(Uo, "delete_");
function hf() {
  let e = No();
  return {
    get: e.get,
    query: e.query,
    normalizeId: e.normalizeId,
    system: e.system,
    insert: /* @__PURE__ */ s(async (t, n) => await gf(t, n), "insert"),
    patch: /* @__PURE__ */ s(async (t, n, i) => i !== void 0 ? await To(t, n, i) : await To(void 0, t, n), "patch"),
    replace: /* @__PURE__ */ s(async (t, n, i) => i !== void 0 ? await Eo(t, n, i) : await Eo(void 0, t, n), "replace"),
    delete: /* @__PURE__ */ s(async (t, n) => n !== void 0 ? await Uo(t, n) : await Uo(void 0, t), "delete"),
    table: /* @__PURE__ */ s((t) => new Do(t, !1), "table")
  };
}
s(hf, "setupWriter");
var yr = class {
  static {
    s(this, "TableReader");
  }
  constructor(t, n) {
    this.tableName = t, this.isSystem = n;
  }
  async get(t) {
    return Po(this.tableName, t, this.isSystem);
  }
  query() {
    let t = this.tableName.startsWith("_");
    if (t !== this.isSystem)
      throw new Error(
        `${t ? "System" : "User"} tables can only be accessed from db.${this.isSystem ? "" : "system."}query().`
      );
    return new xt(this.tableName);
  }
}, Do = class extends yr {
  static {
    s(this, "TableWriter");
  }
  async insert(t) {
    return gf(this.tableName, t);
  }
  async patch(t, n) {
    return To(this.tableName, t, n);
  }
  async replace(t, n) {
    return Eo(this.tableName, t, n);
  }
  async delete(t) {
    return Uo(this.tableName, t);
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/scheduler_impl.js
function vf() {
  return {
    runAfter: /* @__PURE__ */ s(async (e, t, n) => {
      let i = bf(e, t, n);
      return await U("1.0/schedule", i);
    }, "runAfter"),
    runAt: /* @__PURE__ */ s(async (e, t, n) => {
      let i = $f(
        e,
        t,
        n
      );
      return await U("1.0/schedule", i);
    }, "runAt"),
    cancel: /* @__PURE__ */ s(async (e) => {
      E(e, 1, "cancel", "id");
      let t = { id: F(e) };
      await U("1.0/cancel_job", t);
    }, "cancel")
  };
}
s(vf, "setupMutationScheduler");
function yf(e) {
  return {
    runAfter: /* @__PURE__ */ s(async (t, n, i) => {
      let r = {
        requestId: e,
        ...bf(t, n, i)
      };
      return await U("1.0/actions/schedule", r);
    }, "runAfter"),
    runAt: /* @__PURE__ */ s(async (t, n, i) => {
      let r = {
        requestId: e,
        ...$f(t, n, i)
      };
      return await U("1.0/actions/schedule", r);
    }, "runAt"),
    cancel: /* @__PURE__ */ s(async (t) => {
      E(t, 1, "cancel", "id");
      let n = {
        requestId: e,
        id: F(t)
      };
      return await U("1.0/actions/cancel_job", n);
    }, "cancel")
  };
}
s(yf, "setupActionScheduler");
function bf(e, t, n) {
  if (typeof e != "number")
    throw new Error("`delayMs` must be a number");
  if (!isFinite(e))
    throw new Error("`delayMs` must be a finite number");
  if (e < 0)
    throw new Error("`delayMs` must be non-negative");
  let i = De(n), r = ge(t), o = (Date.now() + e) / 1e3;
  return {
    ...r,
    ts: o,
    args: F(i),
    version: X
  };
}
s(bf, "runAfterSyscallArgs");
function $f(e, t, n) {
  let i;
  if (e instanceof Date)
    i = e.valueOf() / 1e3;
  else if (typeof e == "number")
    i = e / 1e3;
  else
    throw new Error("The invoke time must a Date or a timestamp");
  let r = ge(t), o = De(n);
  return {
    ...r,
    ts: i,
    args: F(o),
    version: X
  };
}
s($f, "runAtSyscallArgs");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/storage_impl.js
function Zo(e) {
  return {
    getUrl: /* @__PURE__ */ s(async (t) => (E(t, 1, "getUrl", "storageId"), await U("1.0/storageGetUrl", {
      requestId: e,
      version: X,
      storageId: t
    })), "getUrl"),
    getMetadata: /* @__PURE__ */ s(async (t) => await U("1.0/storageGetMetadata", {
      requestId: e,
      version: X,
      storageId: t
    }), "getMetadata")
  };
}
s(Zo, "setupStorageReader");
function Ao(e) {
  let t = Zo(e);
  return {
    generateUploadUrl: /* @__PURE__ */ s(async () => await U("1.0/storageGenerateUploadUrl", {
      requestId: e,
      version: X
    }), "generateUploadUrl"),
    delete: /* @__PURE__ */ s(async (n) => {
      await U("1.0/storageDelete", {
        requestId: e,
        version: X,
        storageId: n
      });
    }, "delete"),
    getUrl: t.getUrl,
    getMetadata: t.getMetadata
  };
}
s(Ao, "setupStorageWriter");
function xf(e) {
  return {
    ...Ao(e),
    store: /* @__PURE__ */ s(async (n, i) => await hn("storage/storeBlob", {
      requestId: e,
      version: X,
      blob: n,
      options: i
    }), "store"),
    get: /* @__PURE__ */ s(async (n) => await hn("storage/getBlob", {
      requestId: e,
      version: X,
      storageId: n
    }), "get")
  };
}
s(xf, "setupStorageActionWriter");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/registration_impl.js
async function _f(e, t) {
  let i = J(JSON.parse(t)), r = {
    db: hf(),
    auth: bn(""),
    storage: Ao(""),
    scheduler: vf(),
    runQuery: /* @__PURE__ */ s((a, c) => Co("query", a, c), "runQuery"),
    runMutation: /* @__PURE__ */ s((a, c) => Co("mutation", a, c), "runMutation")
  }, o = await Ro(e, r, i);
  return wf(o), JSON.stringify(F(o === void 0 ? null : o));
}
s(_f, "invokeMutation");
function wf(e) {
  if (e instanceof xt || e instanceof He)
    throw new Error(
      "Return value is a Query. Results must be retrieved with `.collect()`, `.take(n), `.unique()`, or `.first()`."
    );
}
s(wf, "validateReturnValue");
async function Ro(e, t, n) {
  let i;
  try {
    i = await Promise.resolve(e(t, ...n));
  } catch (r) {
    throw zh(r);
  }
  return i;
}
s(Ro, "invokeFunction");
function _t(e, t) {
  return (n, i) => (globalThis.console.warn(
    `Convex functions should not directly call other Convex functions. Consider calling a helper function instead. e.g. \`export const foo = ${e}(...); await foo(ctx);\` is not supported. See https://docs.convex.dev/production/best-practices/#use-helper-functions-to-write-shared-code`
  ), t(n, i));
}
s(_t, "dontCallDirectly");
function zh(e) {
  if (typeof e == "object" && e !== null && Symbol.for("ConvexError") in e) {
    let t = e;
    return t.data = JSON.stringify(
      F(t.data === void 0 ? null : t.data)
    ), t.ConvexErrorSymbol = Symbol.for("ConvexError"), t;
  } else
    return e;
}
s(zh, "serializeConvexErrorData");
function wt() {
  if (typeof window > "u" || window.__convexAllowFunctionsInBrowser)
    return;
  (Object.getOwnPropertyDescriptor(globalThis, "window")?.get?.toString().includes("[native code]") ?? !1) && console.error(
    "Convex functions should not be imported in the browser. This will throw an error in future versions of `convex`. If this is a false negative, please report it to Convex support."
  );
}
s(wt, "assertNotBrowser");
function kf(e, t) {
  if (t === void 0)
    throw new Error(
      `A validator is undefined for field "${e}". This is often caused by circular imports. See https://docs.convex.dev/error#undefined-validator for details.`
    );
  return t;
}
s(kf, "strictReplacer");
function kt(e) {
  return () => {
    let t = g.any();
    return typeof e == "object" && e.args !== void 0 && (t = gr(e.args)), JSON.stringify(t.json, kf);
  };
}
s(kt, "exportArgs");
function zt(e) {
  return () => {
    let t;
    return typeof e == "object" && e.returns !== void 0 && (t = gr(e.returns)), JSON.stringify(t ? t.json : null, kf);
  };
}
s(zt, "exportReturns");
var Fo = /* @__PURE__ */ s(((e) => {
  let t = typeof e == "function" ? e : e.handler, n = _t("mutation", t);
  return wt(), n.isMutation = !0, n.isPublic = !0, n.invokeMutation = (i) => _f(t, i), n.exportArgs = kt(e), n.exportReturns = zt(e), n._handler = t, n;
}), "mutationGeneric"), Lo = /* @__PURE__ */ s(((e) => {
  let t = typeof e == "function" ? e : e.handler, n = _t(
    "internalMutation",
    t
  );
  return wt(), n.isMutation = !0, n.isInternal = !0, n.invokeMutation = (i) => _f(t, i), n.exportArgs = kt(e), n.exportReturns = zt(e), n._handler = t, n;
}), "internalMutationGeneric");
async function zf(e, t) {
  let i = J(JSON.parse(t)), r = {
    db: No(),
    auth: bn(""),
    storage: Zo(""),
    runQuery: /* @__PURE__ */ s((a, c) => Co("query", a, c), "runQuery")
  }, o = await Ro(e, r, i);
  return wf(o), JSON.stringify(F(o === void 0 ? null : o));
}
s(zf, "invokeQuery");
var Mo = /* @__PURE__ */ s(((e) => {
  let t = typeof e == "function" ? e : e.handler, n = _t("query", t);
  return wt(), n.isQuery = !0, n.isPublic = !0, n.invokeQuery = (i) => zf(t, i), n.exportArgs = kt(e), n.exportReturns = zt(e), n._handler = t, n;
}), "queryGeneric"), Bo = /* @__PURE__ */ s(((e) => {
  let t = typeof e == "function" ? e : e.handler, n = _t("internalQuery", t);
  return wt(), n.isQuery = !0, n.isInternal = !0, n.invokeQuery = (i) => zf(t, i), n.exportArgs = kt(e), n.exportReturns = zt(e), n._handler = t, n;
}), "internalQueryGeneric");
async function If(e, t, n) {
  let i = J(JSON.parse(n)), o = {
    ...of(t),
    auth: bn(t),
    scheduler: yf(t),
    storage: xf(t),
    vectorSearch: cf(t)
  }, a = await Ro(e, o, i);
  return JSON.stringify(F(a === void 0 ? null : a));
}
s(If, "invokeAction");
var Jo = /* @__PURE__ */ s(((e) => {
  let t = typeof e == "function" ? e : e.handler, n = _t("action", t);
  return wt(), n.isAction = !0, n.isPublic = !0, n.invokeAction = (i, r) => If(t, i, r), n.exportArgs = kt(e), n.exportReturns = zt(e), n._handler = t, n;
}), "actionGeneric"), Vo = /* @__PURE__ */ s(((e) => {
  let t = typeof e == "function" ? e : e.handler, n = _t("internalAction", t);
  return wt(), n.isAction = !0, n.isInternal = !0, n.invokeAction = (i, r) => If(t, i, r), n.exportArgs = kt(e), n.exportReturns = zt(e), n._handler = t, n;
}), "internalActionGeneric");
async function Co(e, t, n) {
  let i = De(n), r = {
    udfType: e,
    args: F(i),
    ...ge(t)
  }, o = await U("1.0/runUdf", r);
  return J(o);
}
s(Co, "runUdf");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/pagination.js
var Ih = g.object({
  numItems: g.number(),
  cursor: g.union(g.string(), g.null()),
  endCursor: g.optional(g.union(g.string(), g.null())),
  id: g.optional(g.number()),
  maximumRowsRead: g.optional(g.number()),
  maximumBytesRead: g.optional(g.number())
});

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/api.js
function Sf(e = []) {
  let t = {
    get(n, i) {
      if (typeof i == "string") {
        let r = [...e, i];
        return Sf(r);
      } else if (i === vr) {
        if (e.length < 2) {
          let a = ["api", ...e].join(".");
          throw new Error(
            `API path is expected to be of the form \`api.moduleName.functionName\`. Found: \`${a}\``
          );
        }
        let r = e.slice(0, -1).join("/"), o = e[e.length - 1];
        return o === "default" ? r : r + ":" + o;
      } else return i === Symbol.toStringTag ? "FunctionReference" : void 0;
    }
  };
  return new Proxy({}, t);
}
s(Sf, "createApi");
var Sh = Sf();

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/schema.js
var Oh = Object.defineProperty, Ph = /* @__PURE__ */ s((e, t, n) => t in e ? Oh(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), ke = /* @__PURE__ */ s((e, t, n) => Ph(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), zn = class {
  static {
    s(this, "TableDefinition");
  }
  /**
   * @internal
   */
  constructor(t) {
    ke(this, "indexes"), ke(this, "stagedDbIndexes"), ke(this, "searchIndexes"), ke(this, "stagedSearchIndexes"), ke(this, "vectorIndexes"), ke(this, "stagedVectorIndexes"), ke(this, "validator"), this.indexes = [], this.stagedDbIndexes = [], this.searchIndexes = [], this.stagedSearchIndexes = [], this.vectorIndexes = [], this.stagedVectorIndexes = [], this.validator = t;
  }
  /**
   * This API is experimental: it may change or disappear.
   *
   * Returns indexes defined on this table.
   * Intended for the advanced use cases of dynamically deciding which index to use for a query.
   * If you think you need this, please chime in on ths issue in the Convex JS GitHub repo.
   * https://github.com/get-convex/convex-js/issues/49
   */
  " indexes"() {
    return this.indexes;
  }
  index(t, n) {
    return Array.isArray(n) ? this.indexes.push({
      indexDescriptor: t,
      fields: n
    }) : n.staged ? this.stagedDbIndexes.push({
      indexDescriptor: t,
      fields: n.fields
    }) : this.indexes.push({
      indexDescriptor: t,
      fields: n.fields
    }), this;
  }
  searchIndex(t, n) {
    return n.staged ? this.stagedSearchIndexes.push({
      indexDescriptor: t,
      searchField: n.searchField,
      filterFields: n.filterFields || []
    }) : this.searchIndexes.push({
      indexDescriptor: t,
      searchField: n.searchField,
      filterFields: n.filterFields || []
    }), this;
  }
  vectorIndex(t, n) {
    return n.staged ? this.stagedVectorIndexes.push({
      indexDescriptor: t,
      vectorField: n.vectorField,
      dimensions: n.dimensions,
      filterFields: n.filterFields || []
    }) : this.vectorIndexes.push({
      indexDescriptor: t,
      vectorField: n.vectorField,
      dimensions: n.dimensions,
      filterFields: n.filterFields || []
    }), this;
  }
  /**
   * Work around for https://github.com/microsoft/TypeScript/issues/57035
   */
  self() {
    return this;
  }
  /**
   * Export the contents of this definition.
   *
   * This is called internally by the Convex framework.
   * @internal
   */
  export() {
    let t = this.validator.json;
    if (typeof t != "object")
      throw new Error(
        "Invalid validator: please make sure that the parameter of `defineTable` is valid (see https://docs.convex.dev/database/schemas)"
      );
    return {
      indexes: this.indexes,
      stagedDbIndexes: this.stagedDbIndexes,
      searchIndexes: this.searchIndexes,
      stagedSearchIndexes: this.stagedSearchIndexes,
      vectorIndexes: this.vectorIndexes,
      stagedVectorIndexes: this.stagedVectorIndexes,
      documentType: t
    };
  }
};
function Ye(e) {
  return ko(e) ? new zn(e) : new zn(g.object(e));
}
s(Ye, "defineTable");
var qo = class {
  static {
    s(this, "SchemaDefinition");
  }
  /**
   * @internal
   */
  constructor(t, n) {
    ke(this, "tables"), ke(this, "strictTableNameTypes"), ke(this, "schemaValidation"), this.tables = t, this.schemaValidation = n?.schemaValidation === void 0 ? !0 : n.schemaValidation;
  }
  /**
   * Export the contents of this definition.
   *
   * This is called internally by the Convex framework.
   * @internal
   */
  export() {
    return JSON.stringify({
      tables: Object.entries(this.tables).map(([t, n]) => {
        let {
          indexes: i,
          stagedDbIndexes: r,
          searchIndexes: o,
          stagedSearchIndexes: a,
          vectorIndexes: c,
          stagedVectorIndexes: u,
          documentType: l
        } = n.export();
        return {
          tableName: t,
          indexes: i,
          stagedDbIndexes: r,
          searchIndexes: o,
          stagedSearchIndexes: a,
          vectorIndexes: c,
          stagedVectorIndexes: u,
          documentType: l
        };
      }),
      schemaValidation: this.schemaValidation
    });
  }
};
function In(e, t) {
  return new qo(e, t);
}
s(In, "defineSchema");
var gw = In({
  _scheduled_functions: Ye({
    name: g.string(),
    args: g.array(g.any()),
    scheduledTime: g.float64(),
    completedTime: g.optional(g.float64()),
    state: g.union(
      g.object({ kind: g.literal("pending") }),
      g.object({ kind: g.literal("inProgress") }),
      g.object({ kind: g.literal("success") }),
      g.object({ kind: g.literal("failed"), error: g.string() }),
      g.object({ kind: g.literal("canceled") })
    )
  }),
  _storage: Ye({
    sha256: g.string(),
    size: g.float64(),
    contentType: g.optional(g.string())
  })
});

// memory/profile.mjs
var et = class {
  static {
    s(this, "SecretText");
  }
  constructor(t) {
    this.value = t;
  }
  toWire() {
    return this.value;
  }
}, Wo = {
  seq: 1,
  at: 17e11,
  secret: "capacity",
  payload: "tiny"
};
function jf(e) {
  let t = e.kind === "native", n = e.kind === "full" || e.kind === "mini", i = t ? e.v : e.s;
  return /* @__PURE__ */ s(function({ count: o, width: a, profile: c, entries: u = 0 }) {
    if (!Number.isInteger(o) || o < 0 || !Number.isInteger(a) || a < 1 || !Number.isInteger(u) || u < 0 || !["fields-only", "codec-rich"].includes(c))
      throw new Error("Invalid graph fixture arguments");
    let l = {
      schemaConstructors: 0,
      fields: 0,
      codecSites: 0,
      allocatedCodecs: 0
    }, d = /* @__PURE__ */ s((I, ...O) => (l.schemaConstructors++, i[I](...O)), "make"), m = /* @__PURE__ */ s((I) => (l.fields += Object.keys(I).length, d("object", I)), "object"), y = /* @__PURE__ */ s(() => (l.codecSites++, t ? d("number") : (l.allocatedCodecs++, d("codec", d("number"), d("date"), {
      decode: /* @__PURE__ */ s((I) => new Date(I), "decode"),
      encode: /* @__PURE__ */ s((I) => I.getTime(), "encode")
    }))), "date"), h = /* @__PURE__ */ s(() => (l.codecSites++, t ? d("string") : (l.allocatedCodecs++, d("codec", d("string"), d("instanceof", et), {
      decode: /* @__PURE__ */ s((I) => new et(I), "decode"),
      encode: /* @__PURE__ */ s((I) => I.toWire(), "encode")
    }))), "secret"), z = /* @__PURE__ */ s((I) => {
      if (c === "fields-only")
        switch (I % 4) {
          case 0:
            return d("string");
          case 1:
            return d("number");
          case 2:
            return d("boolean");
          case 3:
            return d("optional", d("string"));
        }
      switch (I % 4) {
        case 0:
          return y();
        case 1:
          return h();
        case 2:
          return m({ at: y(), tag: d("optional", d("string")) });
        case 3:
          return d(
            "array",
            t ? d("union", d("string"), d("number")) : d("union", [d("string"), d("number")])
          );
      }
    }, "field"), D = {}, T = {}, Oe = /* @__PURE__ */ s((I, O) => {
      n ? (l.fields += Object.keys(O).length, D[I] = e.defineZodModel(I, O, e.schemaHelpers ? void 0 : { schemaHelpers: !1 })) : (T[I] = m(O), D[I] = t ? e.defineTable(T[I]) : T[I]);
    }, "add");
    Oe("benchmarkRows", {
      seq: d("number"),
      at: y(),
      secret: h(),
      payload: d("string")
    });
    for (let I = 0; I < o; I++) {
      let O = {};
      for (let B = 0; B < a; B++) O[`f${B}`] = z(B);
      Oe(`unused${I}`, O);
    }
    let _e = n ? e.defineZodSchema(D) : t ? e.defineSchema(D) : null;
    if (n) for (let I of Object.keys(D)) T[I] = _e.__zodTableMap[I].insert;
    let G = Object.keys(D), P = {};
    for (let I = 0; I < u; I++) {
      let O = G[I % G.length], B = n ? _e.__zodTableMap[O].doc : T[O], vt = m({
        id: d("string"),
        label: d("optional", d("string"))
      }), rn = t ? d("union", B, d("null")) : d("nullable", B);
      P[`unused/fn${I}`] = { args: vt, returns: rn };
    }
    let L = n ? e.initZodvex(
      _e,
      e.server,
      u ? { registry: /* @__PURE__ */ s(() => P, "registry") } : void 0
    ) : e.makeBuilders();
    return {
      kind: e.kind,
      options: { count: o, width: a, profile: c, entries: u },
      models: D,
      sourceSchemas: T,
      schema: _e,
      registry: P,
      builders: L,
      manifest: {
        backgroundModels: o,
        totalModels: o + 1,
        backgroundTopLevelFields: o * a,
        fixedProbeFields: 4,
        profile: c,
        registryEntries: u,
        ...l,
        counterScope: "Explicit fixture constructor calls and source fields/codecs; excludes library-generated helper schemas and runtime heap objects."
      },
      operation() {
        let I = { ...Wo }, O = t ? {
          ...I,
          at: new Date(I.at),
          secret: new et(I.secret)
        } : e.s.parse(T.benchmarkRows, I);
        if (!(O.at instanceof Date) || !(O.secret instanceof et))
          throw new Error("Codec decode failed");
        O.at = new Date(O.at.getTime() + 1e3), O.secret = new et(O.secret.toWire().toUpperCase());
        let B = t ? {
          ...O,
          at: O.at.getTime(),
          secret: O.secret.toWire()
        } : e.s.encode(T.benchmarkRows, O);
        if (JSON.stringify(B) !== JSON.stringify({
          ...Wo,
          at: Wo.at + 1e3,
          secret: "CAPACITY"
        }))
          throw new Error("Codec round trip mismatch");
        return B;
      },
      // Call after the operation and after GC measurements. The retained graph
      // includes every model, table schema, registry entry and builder closure.
      checksum() {
        let I = 0;
        for (let [O, B] of Object.entries(D)) {
          if (!B || !T[O]) throw new Error("Missing model");
          if (I += O.length, n && _e.__zodTableMap[O].insert !== T[O])
            throw new Error("Lost table-map alias");
        }
        for (let [O, B] of Object.entries(P)) {
          if (!B.args || !B.returns)
            throw new Error("Missing registry schema");
          I += O.length;
        }
        if (Object.keys(L).length === 0)
          throw new Error("Lost builders");
        return I;
      }
    };
  }, "buildGraph");
}
s(jf, "createGraphFactory");

// versions/4.4.3/node_modules/zod/v4/classic/external.js
var w = {};
Pe(w, {
  $brand: () => Go,
  $input: () => eu,
  $output: () => Yc,
  NEVER: () => Ko,
  TimePrecision: () => iu,
  ZodAny: () => Bl,
  ZodArray: () => Wl,
  ZodBase64: () => Wi,
  ZodBase64URL: () => Ki,
  ZodBigInt: () => ar,
  ZodBigIntFormat: () => Qi,
  ZodBoolean: () => or,
  ZodCIDRv4: () => Vi,
  ZodCIDRv6: () => qi,
  ZodCUID: () => Ci,
  ZodCUID2: () => Ri,
  ZodCatch: () => gd,
  ZodCodec: () => Qr,
  ZodCustom: () => Hr,
  ZodCustomStringFormat: () => nr,
  ZodDate: () => Wr,
  ZodDefault: () => ud,
  ZodDiscriminatedUnion: () => Gl,
  ZodE164: () => Gi,
  ZodEmail: () => Ni,
  ZodEmoji: () => Zi,
  ZodEnum: () => tr,
  ZodError: () => ab,
  ZodExactOptional: () => ad,
  ZodFile: () => id,
  ZodFirstPartyTypeKind: () => jd,
  ZodFunction: () => zd,
  ZodGUID: () => Mr,
  ZodIPv4: () => Bi,
  ZodIPv6: () => Ji,
  ZodISODate: () => Oi,
  ZodISODateTime: () => ji,
  ZodISODuration: () => Ti,
  ZodISOTime: () => Pi,
  ZodIntersection: () => Xl,
  ZodIssueCode: () => cb,
  ZodJWT: () => Xi,
  ZodKSUID: () => Mi,
  ZodLazy: () => _d,
  ZodLiteral: () => nd,
  ZodMAC: () => Cl,
  ZodMap: () => td,
  ZodNaN: () => vd,
  ZodNanoID: () => Ai,
  ZodNever: () => Vl,
  ZodNonOptional: () => io,
  ZodNull: () => Ll,
  ZodNullable: () => cd,
  ZodNumber: () => ir,
  ZodNumberFormat: () => mt,
  ZodObject: () => Kr,
  ZodOptional: () => no,
  ZodPipe: () => Xr,
  ZodPrefault: () => dd,
  ZodPreprocess: () => yd,
  ZodPromise: () => kd,
  ZodReadonly: () => bd,
  ZodRealError: () => se,
  ZodRecord: () => er,
  ZodSet: () => rd,
  ZodString: () => rr,
  ZodStringFormat: () => C,
  ZodSuccess: () => md,
  ZodSymbol: () => Rl,
  ZodTemplateLiteral: () => xd,
  ZodTransform: () => od,
  ZodTuple: () => Hl,
  ZodType: () => S,
  ZodULID: () => Fi,
  ZodURL: () => Jr,
  ZodUUID: () => je,
  ZodUndefined: () => Fl,
  ZodUnion: () => Gr,
  ZodUnknown: () => Jl,
  ZodVoid: () => ql,
  ZodXID: () => Li,
  ZodXor: () => Kl,
  _ZodString: () => Di,
  _default: () => ld,
  _function: () => vm,
  any: () => Qp,
  array: () => gt,
  base64: () => Dp,
  base64url: () => Np,
  bigint: () => qp,
  boolean: () => qr,
  catch: () => hd,
  check: () => ym,
  cidrv4: () => Ep,
  cidrv6: () => Up,
  clone: () => W,
  codec: () => oo,
  coerce: () => Od,
  config: () => q,
  core: () => Ue,
  cuid: () => kp,
  cuid2: () => zp,
  custom: () => bm,
  date: () => Yi,
  decode: () => Tl,
  decodeAsync: () => Ul,
  describe: () => $m,
  discriminatedUnion: () => nm,
  e164: () => Zp,
  email: () => mp,
  emoji: () => _p,
  encode: () => Lr,
  encodeAsync: () => El,
  endsWith: () => Jt,
  enum: () => to,
  exactOptional: () => sd,
  file: () => lm,
  flattenError: () => zr,
  float32: () => Mp,
  float64: () => Bp,
  formatError: () => Ir,
  fromJSONSchema: () => Im,
  function: () => vm,
  getErrorMap: () => lb,
  globalRegistry: () => H,
  gt: () => Ie,
  gte: () => ne,
  guid: () => gp,
  hash: () => Lp,
  hex: () => Fp,
  hostname: () => Rp,
  httpUrl: () => xp,
  includes: () => Mt,
  instanceof: () => ao,
  int: () => Ei,
  int32: () => Jp,
  int64: () => Wp,
  intersection: () => Ql,
  invertCodec: () => mm,
  ipv4: () => Op,
  ipv6: () => Tp,
  iso: () => Yt,
  json: () => wm,
  jwt: () => Ap,
  keyof: () => Yp,
  ksuid: () => jp,
  lazy: () => wd,
  length: () => ut,
  literal: () => um,
  locales: () => Zr,
  looseObject: () => tm,
  looseRecord: () => om,
  lowercase: () => Ft,
  lt: () => ze,
  lte: () => de,
  mac: () => Pp,
  map: () => am,
  maxLength: () => ct,
  maxSize: () => Ve,
  meta: () => xm,
  mime: () => Vt,
  minLength: () => Ee,
  minSize: () => Se,
  multipleOf: () => Je,
  nan: () => pm,
  nanoid: () => wp,
  nativeEnum: () => cm,
  negative: () => yi,
  never: () => Hi,
  nonnegative: () => $i,
  nonoptional: () => pd,
  nonpositive: () => bi,
  normalize: () => qt,
  null: () => Ml,
  nullable: () => pt,
  nullish: () => dm,
  number: () => Vr,
  object: () => eo,
  optional: () => ft,
  overwrite: () => xe,
  parse: () => Fr,
  parseAsync: () => jl,
  partialRecord: () => im,
  pipe: () => Ui,
  positive: () => vi,
  prefault: () => fd,
  preprocess: () => km,
  prettifyError: () => ca,
  promise: () => hm,
  property: () => xi,
  readonly: () => $d,
  record: () => ed,
  refine: () => Id,
  regex: () => Rt,
  regexes: () => ue,
  registry: () => Xn,
  safeDecode: () => Nl,
  safeDecodeAsync: () => Al,
  safeEncode: () => Dl,
  safeEncodeAsync: () => Zl,
  safeParse: () => Ol,
  safeParseAsync: () => Pl,
  set: () => sm,
  setErrorMap: () => ub,
  size: () => st,
  slugify: () => Xt,
  startsWith: () => Bt,
  strictObject: () => em,
  string: () => lt,
  stringFormat: () => Cp,
  stringbool: () => _m,
  success: () => fm,
  superRefine: () => Sd,
  symbol: () => Gp,
  templateLiteral: () => gm,
  toJSONSchema: () => zi,
  toLowerCase: () => Kt,
  toUpperCase: () => Gt,
  transform: () => ro,
  treeifyError: () => sa,
  trim: () => Wt,
  tuple: () => Yl,
  uint32: () => Vp,
  uint64: () => Kp,
  ulid: () => Ip,
  undefined: () => Xp,
  union: () => sr,
  unknown: () => dt,
  uppercase: () => Lt,
  url: () => $p,
  util: () => $,
  uuid: () => hp,
  uuidv4: () => vp,
  uuidv6: () => yp,
  uuidv7: () => bp,
  void: () => Hp,
  xid: () => Sp,
  xor: () => rm
});

// versions/4.4.3/node_modules/zod/v4/core/index.js
var Ue = {};
Pe(Ue, {
  $ZodAny: () => Zs,
  $ZodArray: () => Le,
  $ZodAsyncError: () => he,
  $ZodBase64: () => Is,
  $ZodBase64URL: () => Ss,
  $ZodBigInt: () => Wn,
  $ZodBigIntFormat: () => Es,
  $ZodBoolean: () => Pr,
  $ZodCIDRv4: () => ws,
  $ZodCIDRv6: () => ks,
  $ZodCUID: () => ds,
  $ZodCUID2: () => fs,
  $ZodCatch: () => Qs,
  $ZodCheck: () => R,
  $ZodCheckBigIntFormat: () => La,
  $ZodCheckEndsWith: () => Ya,
  $ZodCheckGreaterThan: () => Ln,
  $ZodCheckIncludes: () => Qa,
  $ZodCheckLengthEquals: () => Wa,
  $ZodCheckLessThan: () => Fn,
  $ZodCheckLowerCase: () => Ga,
  $ZodCheckMaxLength: () => Va,
  $ZodCheckMaxSize: () => Ma,
  $ZodCheckMimeType: () => ts,
  $ZodCheckMinLength: () => qa,
  $ZodCheckMinSize: () => Ba,
  $ZodCheckMultipleOf: () => Ra,
  $ZodCheckNumberFormat: () => Fa,
  $ZodCheckOverwrite: () => rs,
  $ZodCheckProperty: () => es,
  $ZodCheckRegex: () => Ka,
  $ZodCheckSizeEquals: () => Ja,
  $ZodCheckStartsWith: () => Ha,
  $ZodCheckStringFormat: () => Ut,
  $ZodCheckUpperCase: () => Xa,
  $ZodCodec: () => $e,
  $ZodCustom: () => Tr,
  $ZodCustomStringFormat: () => Ps,
  $ZodDate: () => Dt,
  $ZodDefault: () => le,
  $ZodDiscriminatedUnion: () => Me,
  $ZodE164: () => js,
  $ZodEmail: () => ss,
  $ZodEmoji: () => us,
  $ZodEncodeError: () => Ne,
  $ZodEnum: () => Nt,
  $ZodError: () => ve,
  $ZodExactOptional: () => Ws,
  $ZodFile: () => Vs,
  $ZodFunction: () => rc,
  $ZodGUID: () => os,
  $ZodIPv4: () => $s,
  $ZodIPv6: () => xs,
  $ZodISODate: () => vs,
  $ZodISODateTime: () => hs,
  $ZodISODuration: () => bs,
  $ZodISOTime: () => ys,
  $ZodIntersection: () => Ms,
  $ZodJWT: () => Os,
  $ZodKSUID: () => gs,
  $ZodLazy: () => At,
  $ZodLiteral: () => Zt,
  $ZodMAC: () => _s,
  $ZodMap: () => Bs,
  $ZodNaN: () => Hs,
  $ZodNanoID: () => ls,
  $ZodNever: () => Cs,
  $ZodNonOptional: () => Gs,
  $ZodNull: () => Ns,
  $ZodNullable: () => be,
  $ZodNumber: () => qn,
  $ZodNumberFormat: () => Ts,
  $ZodObject: () => K,
  $ZodObjectJIT: () => Fs,
  $ZodOptional: () => V,
  $ZodPipe: () => Kn,
  $ZodPrefault: () => Ks,
  $ZodPreprocess: () => Ys,
  $ZodPromise: () => nc,
  $ZodReadonly: () => ec,
  $ZodRealError: () => ae,
  $ZodRecord: () => at,
  $ZodRegistry: () => Gn,
  $ZodSet: () => Js,
  $ZodString: () => ot,
  $ZodStringFormat: () => A,
  $ZodSuccess: () => Xs,
  $ZodSymbol: () => Us,
  $ZodTemplateLiteral: () => tc,
  $ZodTransform: () => qs,
  $ZodTuple: () => Be,
  $ZodType: () => k,
  $ZodULID: () => ps,
  $ZodURL: () => cs,
  $ZodUUID: () => as,
  $ZodUndefined: () => Ds,
  $ZodUnion: () => re,
  $ZodUnknown: () => As,
  $ZodVoid: () => Rs,
  $ZodXID: () => ms,
  $ZodXor: () => Ls,
  $brand: () => Go,
  $constructor: () => f,
  $input: () => eu,
  $output: () => Yc,
  Doc: () => Or,
  JSONSchema: () => dp,
  JSONSchemaGenerator: () => Ii,
  NEVER: () => Ko,
  TimePrecision: () => iu,
  _any: () => zu,
  _array: () => Eu,
  _base64: () => pi,
  _base64url: () => mi,
  _bigint: () => yu,
  _boolean: () => hu,
  _catch: () => Hy,
  _check: () => lp,
  _cidrv4: () => di,
  _cidrv6: () => fi,
  _coercedBigint: () => bu,
  _coercedBoolean: () => vu,
  _coercedDate: () => Pu,
  _coercedNumber: () => lu,
  _coercedString: () => ru,
  _cuid: () => ii,
  _cuid2: () => oi,
  _custom: () => Du,
  _date: () => Ou,
  _decode: () => Tn,
  _decodeAsync: () => Un,
  _default: () => Gy,
  _discriminatedUnion: () => Ay,
  _e164: () => gi,
  _email: () => Qn,
  _emoji: () => ri,
  _encode: () => Pn,
  _encodeAsync: () => En,
  _endsWith: () => Jt,
  _enum: () => By,
  _file: () => Uu,
  _float32: () => fu,
  _float64: () => pu,
  _gt: () => Ie,
  _gte: () => ne,
  _guid: () => Ar,
  _includes: () => Mt,
  _int: () => du,
  _int32: () => mu,
  _int64: () => $u,
  _intersection: () => Cy,
  _ipv4: () => ui,
  _ipv6: () => li,
  _isoDate: () => au,
  _isoDateTime: () => ou,
  _isoDuration: () => cu,
  _isoTime: () => su,
  _jwt: () => hi,
  _ksuid: () => ci,
  _lazy: () => rb,
  _length: () => ut,
  _literal: () => Vy,
  _lowercase: () => Ft,
  _lt: () => ze,
  _lte: () => de,
  _mac: () => nu,
  _map: () => Ly,
  _max: () => de,
  _maxLength: () => ct,
  _maxSize: () => Ve,
  _mime: () => Vt,
  _min: () => ne,
  _minLength: () => Ee,
  _minSize: () => Se,
  _multipleOf: () => Je,
  _nan: () => Tu,
  _nanoid: () => ni,
  _nativeEnum: () => Jy,
  _negative: () => yi,
  _never: () => Su,
  _nonnegative: () => $i,
  _nonoptional: () => Xy,
  _nonpositive: () => bi,
  _normalize: () => qt,
  _null: () => ku,
  _nullable: () => Ky,
  _number: () => uu,
  _optional: () => Wy,
  _overwrite: () => xe,
  _parse: () => Ot,
  _parseAsync: () => Pt,
  _pipe: () => Yy,
  _positive: () => vi,
  _promise: () => nb,
  _property: () => xi,
  _readonly: () => eb,
  _record: () => Fy,
  _refine: () => Nu,
  _regex: () => Rt,
  _safeDecode: () => Nn,
  _safeDecodeAsync: () => An,
  _safeEncode: () => Dn,
  _safeEncodeAsync: () => Zn,
  _safeParse: () => Tt,
  _safeParseAsync: () => Et,
  _set: () => My,
  _size: () => st,
  _slugify: () => Xt,
  _startsWith: () => Bt,
  _string: () => tu,
  _stringFormat: () => Qt,
  _stringbool: () => Ru,
  _success: () => Qy,
  _superRefine: () => Zu,
  _symbol: () => _u,
  _templateLiteral: () => tb,
  _toLowerCase: () => Kt,
  _toUpperCase: () => Gt,
  _transform: () => qy,
  _trim: () => Wt,
  _tuple: () => Ry,
  _uint32: () => gu,
  _uint64: () => xu,
  _ulid: () => ai,
  _undefined: () => wu,
  _union: () => Ny,
  _unknown: () => Iu,
  _uppercase: () => Lt,
  _url: () => Cr,
  _uuid: () => Hn,
  _uuidv4: () => Yn,
  _uuidv6: () => ei,
  _uuidv7: () => ti,
  _void: () => ju,
  _xid: () => si,
  _xor: () => Zy,
  clone: () => W,
  config: () => q,
  createStandardJSONSchemaMethod: () => Ht,
  createToJSONSchemaMethod: () => Fu,
  decode: () => nv,
  decodeAsync: () => ov,
  describe: () => Au,
  encode: () => ye,
  encodeAsync: () => iv,
  extractDefs: () => We,
  finalize: () => Ke,
  flattenError: () => zr,
  formatError: () => Ir,
  globalConfig: () => tt,
  globalRegistry: () => H,
  initializeContext: () => qe,
  isValidBase64: () => zs,
  isValidBase64URL: () => tp,
  isValidJWT: () => rp,
  locales: () => Zr,
  meta: () => Cu,
  parse: () => Fe,
  parseAsync: () => On,
  prettifyError: () => ca,
  process: () => N,
  regexes: () => ue,
  registry: () => Xn,
  safeDecode: () => sv,
  safeDecodeAsync: () => uv,
  safeEncode: () => av,
  safeEncodeAsync: () => cv,
  safeParse: () => nt,
  safeParseAsync: () => ua,
  toDotPath: () => Df,
  toJSONSchema: () => zi,
  treeifyError: () => sa,
  util: () => $,
  version: () => ns
});

// versions/4.4.3/node_modules/zod/v4/core/core.js
var Of, Ko = /* @__PURE__ */ Object.freeze({
  status: "aborted"
});
// @__NO_SIDE_EFFECTS__
function f(e, t, n) {
  function i(c, u) {
    if (c._zod || Object.defineProperty(c, "_zod", {
      value: {
        def: u,
        constr: a,
        traits: /* @__PURE__ */ new Set()
      },
      enumerable: !1
    }), c._zod.traits.has(e))
      return;
    c._zod.traits.add(e), t(c, u);
    let l = a.prototype, d = Object.keys(l);
    for (let m = 0; m < d.length; m++) {
      let y = d[m];
      y in c || (c[y] = l[y].bind(c));
    }
  }
  s(i, "init");
  let r = n?.Parent ?? Object;
  class o extends r {
    static {
      s(this, "Definition");
    }
  }
  Object.defineProperty(o, "name", { value: e });
  function a(c) {
    var u;
    let l = n?.Parent ? new o() : this;
    i(l, c), (u = l._zod).deferred ?? (u.deferred = []);
    for (let d of l._zod.deferred)
      d();
    return l;
  }
  return s(a, "_"), Object.defineProperty(a, "init", { value: i }), Object.defineProperty(a, Symbol.hasInstance, {
    value: /* @__PURE__ */ s((c) => n?.Parent && c instanceof n.Parent ? !0 : c?._zod?.traits?.has(e), "value")
  }), Object.defineProperty(a, "name", { value: e }), a;
}
s(f, "$constructor");
var Go = Symbol("zod_brand"), he = class extends Error {
  static {
    s(this, "$ZodAsyncError");
  }
  constructor() {
    super("Encountered Promise during synchronous parse. Use .parseAsync() instead.");
  }
}, Ne = class extends Error {
  static {
    s(this, "$ZodEncodeError");
  }
  constructor(t) {
    super(`Encountered unidirectional transform during encode: ${t}`), this.name = "ZodEncodeError";
  }
};
(Of = globalThis).__zod_globalConfig ?? (Of.__zod_globalConfig = {});
var tt = globalThis.__zod_globalConfig;
function q(e) {
  return e && Object.assign(tt, e), tt;
}
s(q, "config");

// versions/4.4.3/node_modules/zod/v4/core/util.js
var $ = {};
Pe($, {
  BIGINT_FORMAT_RANGES: () => oa,
  Class: () => Qo,
  NUMBER_FORMAT_RANGES: () => ia,
  aborted: () => Re,
  allowsEval: () => ea,
  assert: () => Nh,
  assertEqual: () => Th,
  assertIs: () => Uh,
  assertNever: () => Dh,
  assertNotEqual: () => Eh,
  assignProp: () => Ae,
  base64ToUint8Array: () => Tf,
  base64urlToUint8Array: () => Hh,
  cached: () => St,
  captureStackTrace: () => jn,
  cleanEnum: () => Qh,
  cleanRegex: () => xr,
  clone: () => W,
  cloneDef: () => Ah,
  createTransparentProxy: () => Bh,
  defineLazy: () => j,
  esc: () => Sn,
  escapeRegex: () => me,
  explicitlyAborted: () => aa,
  extend: () => qh,
  finalizeIssue: () => te,
  floatSafeRemainder: () => Ho,
  getElementAtPath: () => Ch,
  getEnumValues: () => $r,
  getLengthableOrigin: () => kr,
  getParsedType: () => Mh,
  getSizableOrigin: () => wr,
  hexToUint8Array: () => ev,
  isObject: () => rt,
  isPlainObject: () => Ce,
  issue: () => jt,
  joinValues: () => p,
  jsonStringifyReplacer: () => It,
  merge: () => Kh,
  mergeDefs: () => Te,
  normalizeParams: () => x,
  nullish: () => Ze,
  numKeys: () => Lh,
  objectClone: () => Zh,
  omit: () => Vh,
  optionalKeys: () => na,
  parsedType: () => b,
  partial: () => Gh,
  pick: () => Jh,
  prefixIssues: () => oe,
  primitiveTypes: () => ra,
  promiseAllObject: () => Rh,
  propertyKeyTypes: () => _r,
  randomString: () => Fh,
  required: () => Xh,
  safeExtend: () => Wh,
  shallowClone: () => ta,
  slugify: () => Yo,
  stringifyPrimitive: () => v,
  uint8ArrayToBase64: () => Ef,
  uint8ArrayToBase64url: () => Yh,
  uint8ArrayToHex: () => tv,
  unwrapMessage: () => br
});
function Th(e) {
  return e;
}
s(Th, "assertEqual");
function Eh(e) {
  return e;
}
s(Eh, "assertNotEqual");
function Uh(e) {
}
s(Uh, "assertIs");
function Dh(e) {
  throw new Error("Unexpected value in exhaustive check");
}
s(Dh, "assertNever");
function Nh(e) {
}
s(Nh, "assert");
function $r(e) {
  let t = Object.values(e).filter((i) => typeof i == "number");
  return Object.entries(e).filter(([i, r]) => t.indexOf(+i) === -1).map(([i, r]) => r);
}
s($r, "getEnumValues");
function p(e, t = "|") {
  return e.map((n) => v(n)).join(t);
}
s(p, "joinValues");
function It(e, t) {
  return typeof t == "bigint" ? t.toString() : t;
}
s(It, "jsonStringifyReplacer");
function St(e) {
  return {
    get value() {
      {
        let n = e();
        return Object.defineProperty(this, "value", { value: n }), n;
      }
      throw new Error("cached value already set");
    }
  };
}
s(St, "cached");
function Ze(e) {
  return e == null;
}
s(Ze, "nullish");
function xr(e) {
  let t = e.startsWith("^") ? 1 : 0, n = e.endsWith("$") ? e.length - 1 : e.length;
  return e.slice(t, n);
}
s(xr, "cleanRegex");
function Ho(e, t) {
  let n = e / t, i = Math.round(n), r = Number.EPSILON * Math.max(Math.abs(n), 1);
  return Math.abs(n - i) < r ? 0 : n - i;
}
s(Ho, "floatSafeRemainder");
var Pf = /* @__PURE__ */ Symbol("evaluating");
function j(e, t, n) {
  let i;
  Object.defineProperty(e, t, {
    get() {
      if (i !== Pf)
        return i === void 0 && (i = Pf, i = n()), i;
    },
    set(r) {
      Object.defineProperty(e, t, {
        value: r
        // configurable: true,
      });
    },
    configurable: !0
  });
}
s(j, "defineLazy");
function Zh(e) {
  return Object.create(Object.getPrototypeOf(e), Object.getOwnPropertyDescriptors(e));
}
s(Zh, "objectClone");
function Ae(e, t, n) {
  Object.defineProperty(e, t, {
    value: n,
    writable: !0,
    enumerable: !0,
    configurable: !0
  });
}
s(Ae, "assignProp");
function Te(...e) {
  let t = {};
  for (let n of e) {
    let i = Object.getOwnPropertyDescriptors(n);
    Object.assign(t, i);
  }
  return Object.defineProperties({}, t);
}
s(Te, "mergeDefs");
function Ah(e) {
  return Te(e._zod.def);
}
s(Ah, "cloneDef");
function Ch(e, t) {
  return t ? t.reduce((n, i) => n?.[i], e) : e;
}
s(Ch, "getElementAtPath");
function Rh(e) {
  let t = Object.keys(e), n = t.map((i) => e[i]);
  return Promise.all(n).then((i) => {
    let r = {};
    for (let o = 0; o < t.length; o++)
      r[t[o]] = i[o];
    return r;
  });
}
s(Rh, "promiseAllObject");
function Fh(e = 10) {
  let t = "abcdefghijklmnopqrstuvwxyz", n = "";
  for (let i = 0; i < e; i++)
    n += t[Math.floor(Math.random() * t.length)];
  return n;
}
s(Fh, "randomString");
function Sn(e) {
  return JSON.stringify(e);
}
s(Sn, "esc");
function Yo(e) {
  return e.toLowerCase().trim().replace(/[^\w\s-]/g, "").replace(/[\s_-]+/g, "-").replace(/^-+|-+$/g, "");
}
s(Yo, "slugify");
var jn = "captureStackTrace" in Error ? Error.captureStackTrace : (...e) => {
};
function rt(e) {
  return typeof e == "object" && e !== null && !Array.isArray(e);
}
s(rt, "isObject");
var ea = /* @__PURE__ */ St(() => {
  if (tt.jitless || typeof navigator < "u" && navigator?.userAgent?.includes("Cloudflare"))
    return !1;
  try {
    let e = Function;
    return new e(""), !0;
  } catch {
    return !1;
  }
});
function Ce(e) {
  if (rt(e) === !1)
    return !1;
  let t = e.constructor;
  if (t === void 0 || typeof t != "function")
    return !0;
  let n = t.prototype;
  return !(rt(n) === !1 || Object.prototype.hasOwnProperty.call(n, "isPrototypeOf") === !1);
}
s(Ce, "isPlainObject");
function ta(e) {
  return Ce(e) ? { ...e } : Array.isArray(e) ? [...e] : e instanceof Map ? new Map(e) : e instanceof Set ? new Set(e) : e;
}
s(ta, "shallowClone");
function Lh(e) {
  let t = 0;
  for (let n in e)
    Object.prototype.hasOwnProperty.call(e, n) && t++;
  return t;
}
s(Lh, "numKeys");
var Mh = /* @__PURE__ */ s((e) => {
  let t = typeof e;
  switch (t) {
    case "undefined":
      return "undefined";
    case "string":
      return "string";
    case "number":
      return Number.isNaN(e) ? "nan" : "number";
    case "boolean":
      return "boolean";
    case "function":
      return "function";
    case "bigint":
      return "bigint";
    case "symbol":
      return "symbol";
    case "object":
      return Array.isArray(e) ? "array" : e === null ? "null" : e.then && typeof e.then == "function" && e.catch && typeof e.catch == "function" ? "promise" : typeof Map < "u" && e instanceof Map ? "map" : typeof Set < "u" && e instanceof Set ? "set" : typeof Date < "u" && e instanceof Date ? "date" : typeof File < "u" && e instanceof File ? "file" : "object";
    default:
      throw new Error(`Unknown data type: ${t}`);
  }
}, "getParsedType"), _r = /* @__PURE__ */ new Set(["string", "number", "symbol"]), ra = /* @__PURE__ */ new Set([
  "string",
  "number",
  "bigint",
  "boolean",
  "symbol",
  "undefined"
]);
function me(e) {
  return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
s(me, "escapeRegex");
function W(e, t, n) {
  let i = new e._zod.constr(t ?? e._zod.def);
  return (!t || n?.parent) && (i._zod.parent = e), i;
}
s(W, "clone");
function x(e) {
  let t = e;
  if (!t)
    return {};
  if (typeof t == "string")
    return { error: /* @__PURE__ */ s(() => t, "error") };
  if (t?.message !== void 0) {
    if (t?.error !== void 0)
      throw new Error("Cannot specify both `message` and `error` params");
    t.error = t.message;
  }
  return delete t.message, typeof t.error == "string" ? { ...t, error: /* @__PURE__ */ s(() => t.error, "error") } : t;
}
s(x, "normalizeParams");
function Bh(e) {
  let t;
  return new Proxy({}, {
    get(n, i, r) {
      return t ?? (t = e()), Reflect.get(t, i, r);
    },
    set(n, i, r, o) {
      return t ?? (t = e()), Reflect.set(t, i, r, o);
    },
    has(n, i) {
      return t ?? (t = e()), Reflect.has(t, i);
    },
    deleteProperty(n, i) {
      return t ?? (t = e()), Reflect.deleteProperty(t, i);
    },
    ownKeys(n) {
      return t ?? (t = e()), Reflect.ownKeys(t);
    },
    getOwnPropertyDescriptor(n, i) {
      return t ?? (t = e()), Reflect.getOwnPropertyDescriptor(t, i);
    },
    defineProperty(n, i, r) {
      return t ?? (t = e()), Reflect.defineProperty(t, i, r);
    }
  });
}
s(Bh, "createTransparentProxy");
function v(e) {
  return typeof e == "bigint" ? e.toString() + "n" : typeof e == "string" ? `"${e}"` : `${e}`;
}
s(v, "stringifyPrimitive");
function na(e) {
  return Object.keys(e).filter((t) => e[t]._zod.optin === "optional" && e[t]._zod.optout === "optional");
}
s(na, "optionalKeys");
var ia = {
  safeint: [Number.MIN_SAFE_INTEGER, Number.MAX_SAFE_INTEGER],
  int32: [-2147483648, 2147483647],
  uint32: [0, 4294967295],
  float32: [-34028234663852886e22, 34028234663852886e22],
  float64: [-Number.MAX_VALUE, Number.MAX_VALUE]
}, oa = {
  int64: [/* @__PURE__ */ BigInt("-9223372036854775808"), /* @__PURE__ */ BigInt("9223372036854775807")],
  uint64: [/* @__PURE__ */ BigInt(0), /* @__PURE__ */ BigInt("18446744073709551615")]
};
function Jh(e, t) {
  let n = e._zod.def, i = n.checks;
  if (i && i.length > 0)
    throw new Error(".pick() cannot be used on object schemas containing refinements");
  let o = Te(e._zod.def, {
    get shape() {
      let a = {};
      for (let c in t) {
        if (!(c in n.shape))
          throw new Error(`Unrecognized key: "${c}"`);
        t[c] && (a[c] = n.shape[c]);
      }
      return Ae(this, "shape", a), a;
    },
    checks: []
  });
  return W(e, o);
}
s(Jh, "pick");
function Vh(e, t) {
  let n = e._zod.def, i = n.checks;
  if (i && i.length > 0)
    throw new Error(".omit() cannot be used on object schemas containing refinements");
  let o = Te(e._zod.def, {
    get shape() {
      let a = { ...e._zod.def.shape };
      for (let c in t) {
        if (!(c in n.shape))
          throw new Error(`Unrecognized key: "${c}"`);
        t[c] && delete a[c];
      }
      return Ae(this, "shape", a), a;
    },
    checks: []
  });
  return W(e, o);
}
s(Vh, "omit");
function qh(e, t) {
  if (!Ce(t))
    throw new Error("Invalid input to extend: expected a plain object");
  let n = e._zod.def.checks;
  if (n && n.length > 0) {
    let o = e._zod.def.shape;
    for (let a in t)
      if (Object.getOwnPropertyDescriptor(o, a) !== void 0)
        throw new Error("Cannot overwrite keys on object schemas containing refinements. Use `.safeExtend()` instead.");
  }
  let r = Te(e._zod.def, {
    get shape() {
      let o = { ...e._zod.def.shape, ...t };
      return Ae(this, "shape", o), o;
    }
  });
  return W(e, r);
}
s(qh, "extend");
function Wh(e, t) {
  if (!Ce(t))
    throw new Error("Invalid input to safeExtend: expected a plain object");
  let n = Te(e._zod.def, {
    get shape() {
      let i = { ...e._zod.def.shape, ...t };
      return Ae(this, "shape", i), i;
    }
  });
  return W(e, n);
}
s(Wh, "safeExtend");
function Kh(e, t) {
  if (e._zod.def.checks?.length)
    throw new Error(".merge() cannot be used on object schemas containing refinements. Use .safeExtend() instead.");
  let n = Te(e._zod.def, {
    get shape() {
      let i = { ...e._zod.def.shape, ...t._zod.def.shape };
      return Ae(this, "shape", i), i;
    },
    get catchall() {
      return t._zod.def.catchall;
    },
    checks: t._zod.def.checks ?? []
  });
  return W(e, n);
}
s(Kh, "merge");
function Gh(e, t, n) {
  let r = t._zod.def.checks;
  if (r && r.length > 0)
    throw new Error(".partial() cannot be used on object schemas containing refinements");
  let a = Te(t._zod.def, {
    get shape() {
      let c = t._zod.def.shape, u = { ...c };
      if (n)
        for (let l in n) {
          if (!(l in c))
            throw new Error(`Unrecognized key: "${l}"`);
          n[l] && (u[l] = e ? new e({
            type: "optional",
            innerType: c[l]
          }) : c[l]);
        }
      else
        for (let l in c)
          u[l] = e ? new e({
            type: "optional",
            innerType: c[l]
          }) : c[l];
      return Ae(this, "shape", u), u;
    },
    checks: []
  });
  return W(t, a);
}
s(Gh, "partial");
function Xh(e, t, n) {
  let i = Te(t._zod.def, {
    get shape() {
      let r = t._zod.def.shape, o = { ...r };
      if (n)
        for (let a in n) {
          if (!(a in o))
            throw new Error(`Unrecognized key: "${a}"`);
          n[a] && (o[a] = new e({
            type: "nonoptional",
            innerType: r[a]
          }));
        }
      else
        for (let a in r)
          o[a] = new e({
            type: "nonoptional",
            innerType: r[a]
          });
      return Ae(this, "shape", o), o;
    }
  });
  return W(t, i);
}
s(Xh, "required");
function Re(e, t = 0) {
  if (e.aborted === !0)
    return !0;
  for (let n = t; n < e.issues.length; n++)
    if (e.issues[n]?.continue !== !0)
      return !0;
  return !1;
}
s(Re, "aborted");
function aa(e, t = 0) {
  if (e.aborted === !0)
    return !0;
  for (let n = t; n < e.issues.length; n++)
    if (e.issues[n]?.continue === !1)
      return !0;
  return !1;
}
s(aa, "explicitlyAborted");
function oe(e, t) {
  return t.map((n) => {
    var i;
    return (i = n).path ?? (i.path = []), n.path.unshift(e), n;
  });
}
s(oe, "prefixIssues");
function br(e) {
  return typeof e == "string" ? e : e?.message;
}
s(br, "unwrapMessage");
function te(e, t, n) {
  let i = e.message ? e.message : br(e.inst?._zod.def?.error?.(e)) ?? br(t?.error?.(e)) ?? br(n.customError?.(e)) ?? br(n.localeError?.(e)) ?? "Invalid input", { inst: r, continue: o, input: a, ...c } = e;
  return c.path ?? (c.path = []), c.message = i, t?.reportInput && (c.input = a), c;
}
s(te, "finalizeIssue");
function wr(e) {
  return e instanceof Set ? "set" : e instanceof Map ? "map" : e instanceof File ? "file" : "unknown";
}
s(wr, "getSizableOrigin");
function kr(e) {
  return Array.isArray(e) ? "array" : typeof e == "string" ? "string" : "unknown";
}
s(kr, "getLengthableOrigin");
function b(e) {
  let t = typeof e;
  switch (t) {
    case "number":
      return Number.isNaN(e) ? "nan" : "number";
    case "object": {
      if (e === null)
        return "null";
      if (Array.isArray(e))
        return "array";
      let n = e;
      if (n && Object.getPrototypeOf(n) !== Object.prototype && "constructor" in n && n.constructor)
        return n.constructor.name;
    }
  }
  return t;
}
s(b, "parsedType");
function jt(...e) {
  let [t, n, i] = e;
  return typeof t == "string" ? {
    message: t,
    code: "custom",
    input: n,
    inst: i
  } : { ...t };
}
s(jt, "issue");
function Qh(e) {
  return Object.entries(e).filter(([t, n]) => Number.isNaN(Number.parseInt(t, 10))).map((t) => t[1]);
}
s(Qh, "cleanEnum");
function Tf(e) {
  let t = atob(e), n = new Uint8Array(t.length);
  for (let i = 0; i < t.length; i++)
    n[i] = t.charCodeAt(i);
  return n;
}
s(Tf, "base64ToUint8Array");
function Ef(e) {
  let t = "";
  for (let n = 0; n < e.length; n++)
    t += String.fromCharCode(e[n]);
  return btoa(t);
}
s(Ef, "uint8ArrayToBase64");
function Hh(e) {
  let t = e.replace(/-/g, "+").replace(/_/g, "/"), n = "=".repeat((4 - t.length % 4) % 4);
  return Tf(t + n);
}
s(Hh, "base64urlToUint8Array");
function Yh(e) {
  return Ef(e).replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, "");
}
s(Yh, "uint8ArrayToBase64url");
function ev(e) {
  let t = e.replace(/^0x/, "");
  if (t.length % 2 !== 0)
    throw new Error("Invalid hex string length");
  let n = new Uint8Array(t.length / 2);
  for (let i = 0; i < t.length; i += 2)
    n[i / 2] = Number.parseInt(t.slice(i, i + 2), 16);
  return n;
}
s(ev, "hexToUint8Array");
function tv(e) {
  return Array.from(e).map((t) => t.toString(16).padStart(2, "0")).join("");
}
s(tv, "uint8ArrayToHex");
var Qo = class {
  static {
    s(this, "Class");
  }
  constructor(...t) {
  }
};

// versions/4.4.3/node_modules/zod/v4/core/errors.js
var Uf = /* @__PURE__ */ s((e, t) => {
  e.name = "$ZodError", Object.defineProperty(e, "_zod", {
    value: e._zod,
    enumerable: !1
  }), Object.defineProperty(e, "issues", {
    value: t,
    enumerable: !1
  }), e.message = JSON.stringify(t, It, 2), Object.defineProperty(e, "toString", {
    value: /* @__PURE__ */ s(() => e.message, "value"),
    enumerable: !1
  });
}, "initializer"), ve = f("$ZodError", Uf), ae = f("$ZodError", Uf, { Parent: Error });
function zr(e, t = (n) => n.message) {
  let n = {}, i = [];
  for (let r of e.issues)
    r.path.length > 0 ? (n[r.path[0]] = n[r.path[0]] || [], n[r.path[0]].push(t(r))) : i.push(t(r));
  return { formErrors: i, fieldErrors: n };
}
s(zr, "flattenError");
function Ir(e, t = (n) => n.message) {
  let n = { _errors: [] }, i = /* @__PURE__ */ s((r, o = []) => {
    for (let a of r.issues)
      if (a.code === "invalid_union" && a.errors.length)
        a.errors.map((c) => i({ issues: c }, [...o, ...a.path]));
      else if (a.code === "invalid_key")
        i({ issues: a.issues }, [...o, ...a.path]);
      else if (a.code === "invalid_element")
        i({ issues: a.issues }, [...o, ...a.path]);
      else {
        let c = [...o, ...a.path];
        if (c.length === 0)
          n._errors.push(t(a));
        else {
          let u = n, l = 0;
          for (; l < c.length; ) {
            let d = c[l];
            l === c.length - 1 ? (u[d] = u[d] || { _errors: [] }, u[d]._errors.push(t(a))) : u[d] = u[d] || { _errors: [] }, u = u[d], l++;
          }
        }
      }
  }, "processError");
  return i(e), n;
}
s(Ir, "formatError");
function sa(e, t = (n) => n.message) {
  let n = { errors: [] }, i = /* @__PURE__ */ s((r, o = []) => {
    var a, c;
    for (let u of r.issues)
      if (u.code === "invalid_union" && u.errors.length)
        u.errors.map((l) => i({ issues: l }, [...o, ...u.path]));
      else if (u.code === "invalid_key")
        i({ issues: u.issues }, [...o, ...u.path]);
      else if (u.code === "invalid_element")
        i({ issues: u.issues }, [...o, ...u.path]);
      else {
        let l = [...o, ...u.path];
        if (l.length === 0) {
          n.errors.push(t(u));
          continue;
        }
        let d = n, m = 0;
        for (; m < l.length; ) {
          let y = l[m], h = m === l.length - 1;
          typeof y == "string" ? (d.properties ?? (d.properties = {}), (a = d.properties)[y] ?? (a[y] = { errors: [] }), d = d.properties[y]) : (d.items ?? (d.items = []), (c = d.items)[y] ?? (c[y] = { errors: [] }), d = d.items[y]), h && d.errors.push(t(u)), m++;
        }
      }
  }, "processError");
  return i(e), n;
}
s(sa, "treeifyError");
function Df(e) {
  let t = [], n = e.map((i) => typeof i == "object" ? i.key : i);
  for (let i of n)
    typeof i == "number" ? t.push(`[${i}]`) : typeof i == "symbol" ? t.push(`[${JSON.stringify(String(i))}]`) : /[^\w$]/.test(i) ? t.push(`[${JSON.stringify(i)}]`) : (t.length && t.push("."), t.push(i));
  return t.join("");
}
s(Df, "toDotPath");
function ca(e) {
  let t = [], n = [...e.issues].sort((i, r) => (i.path ?? []).length - (r.path ?? []).length);
  for (let i of n)
    t.push(`\u2716 ${i.message}`), i.path?.length && t.push(`  \u2192 at ${Df(i.path)}`);
  return t.join(`
`);
}
s(ca, "prettifyError");

// versions/4.4.3/node_modules/zod/v4/core/parse.js
var Ot = /* @__PURE__ */ s((e) => (t, n, i, r) => {
  let o = i ? { ...i, async: !1 } : { async: !1 }, a = t._zod.run({ value: n, issues: [] }, o);
  if (a instanceof Promise)
    throw new he();
  if (a.issues.length) {
    let c = new (r?.Err ?? e)(a.issues.map((u) => te(u, o, q())));
    throw jn(c, r?.callee), c;
  }
  return a.value;
}, "_parse"), Fe = /* @__PURE__ */ Ot(ae), Pt = /* @__PURE__ */ s((e) => async (t, n, i, r) => {
  let o = i ? { ...i, async: !0 } : { async: !0 }, a = t._zod.run({ value: n, issues: [] }, o);
  if (a instanceof Promise && (a = await a), a.issues.length) {
    let c = new (r?.Err ?? e)(a.issues.map((u) => te(u, o, q())));
    throw jn(c, r?.callee), c;
  }
  return a.value;
}, "_parseAsync"), On = /* @__PURE__ */ Pt(ae), Tt = /* @__PURE__ */ s((e) => (t, n, i) => {
  let r = i ? { ...i, async: !1 } : { async: !1 }, o = t._zod.run({ value: n, issues: [] }, r);
  if (o instanceof Promise)
    throw new he();
  return o.issues.length ? {
    success: !1,
    error: new (e ?? ve)(o.issues.map((a) => te(a, r, q())))
  } : { success: !0, data: o.value };
}, "_safeParse"), nt = /* @__PURE__ */ Tt(ae), Et = /* @__PURE__ */ s((e) => async (t, n, i) => {
  let r = i ? { ...i, async: !0 } : { async: !0 }, o = t._zod.run({ value: n, issues: [] }, r);
  return o instanceof Promise && (o = await o), o.issues.length ? {
    success: !1,
    error: new e(o.issues.map((a) => te(a, r, q())))
  } : { success: !0, data: o.value };
}, "_safeParseAsync"), ua = /* @__PURE__ */ Et(ae), Pn = /* @__PURE__ */ s((e) => (t, n, i) => {
  let r = i ? { ...i, direction: "backward" } : { direction: "backward" };
  return Ot(e)(t, n, r);
}, "_encode"), ye = /* @__PURE__ */ Pn(ae), Tn = /* @__PURE__ */ s((e) => (t, n, i) => Ot(e)(t, n, i), "_decode"), nv = /* @__PURE__ */ Tn(ae), En = /* @__PURE__ */ s((e) => async (t, n, i) => {
  let r = i ? { ...i, direction: "backward" } : { direction: "backward" };
  return Pt(e)(t, n, r);
}, "_encodeAsync"), iv = /* @__PURE__ */ En(ae), Un = /* @__PURE__ */ s((e) => async (t, n, i) => Pt(e)(t, n, i), "_decodeAsync"), ov = /* @__PURE__ */ Un(ae), Dn = /* @__PURE__ */ s((e) => (t, n, i) => {
  let r = i ? { ...i, direction: "backward" } : { direction: "backward" };
  return Tt(e)(t, n, r);
}, "_safeEncode"), av = /* @__PURE__ */ Dn(ae), Nn = /* @__PURE__ */ s((e) => (t, n, i) => Tt(e)(t, n, i), "_safeDecode"), sv = /* @__PURE__ */ Nn(ae), Zn = /* @__PURE__ */ s((e) => async (t, n, i) => {
  let r = i ? { ...i, direction: "backward" } : { direction: "backward" };
  return Et(e)(t, n, r);
}, "_safeEncodeAsync"), cv = /* @__PURE__ */ Zn(ae), An = /* @__PURE__ */ s((e) => async (t, n, i) => Et(e)(t, n, i), "_safeDecodeAsync"), uv = /* @__PURE__ */ An(ae);

// versions/4.4.3/node_modules/zod/v4/core/regexes.js
var ue = {};
Pe(ue, {
  base64: () => za,
  base64url: () => Cn,
  bigint: () => Ea,
  boolean: () => Da,
  browserEmail: () => vv,
  cidrv4: () => wa,
  cidrv6: () => ka,
  cuid: () => la,
  cuid2: () => da,
  date: () => ja,
  datetime: () => Pa,
  domain: () => $v,
  duration: () => ha,
  e164: () => Sa,
  email: () => ya,
  emoji: () => ba,
  extendedDuration: () => lv,
  guid: () => va,
  hex: () => xv,
  hostname: () => bv,
  html5Email: () => mv,
  httpProtocol: () => Ia,
  idnEmail: () => hv,
  integer: () => Ua,
  ipv4: () => $a,
  ipv6: () => xa,
  ksuid: () => ma,
  lowercase: () => Aa,
  mac: () => _a,
  md5_base64: () => wv,
  md5_base64url: () => kv,
  md5_hex: () => _v,
  nanoid: () => ga,
  null: () => Na,
  number: () => Rn,
  rfc5322Email: () => gv,
  sha1_base64: () => Iv,
  sha1_base64url: () => Sv,
  sha1_hex: () => zv,
  sha256_base64: () => Ov,
  sha256_base64url: () => Pv,
  sha256_hex: () => jv,
  sha384_base64: () => Ev,
  sha384_base64url: () => Uv,
  sha384_hex: () => Tv,
  sha512_base64: () => Nv,
  sha512_base64url: () => Zv,
  sha512_hex: () => Dv,
  string: () => Ta,
  time: () => Oa,
  ulid: () => fa,
  undefined: () => Za,
  unicodeEmail: () => Nf,
  uppercase: () => Ca,
  uuid: () => it,
  uuid4: () => dv,
  uuid6: () => fv,
  uuid7: () => pv,
  xid: () => pa
});
var la = /^[cC][0-9a-z]{6,}$/, da = /^[0-9a-z]+$/, fa = /^[0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{26}$/, pa = /^[0-9a-vA-V]{20}$/, ma = /^[A-Za-z0-9]{27}$/, ga = /^[a-zA-Z0-9_-]{21}$/, ha = /^P(?:(\d+W)|(?!.*W)(?=\d|T\d)(\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+([.,]\d+)?S)?)?)$/, lv = /^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/, va = /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/, it = /* @__PURE__ */ s((e) => e ? new RegExp(`^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${e}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`) : /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/, "uuid"), dv = /* @__PURE__ */ it(4), fv = /* @__PURE__ */ it(6), pv = /* @__PURE__ */ it(7), ya = /^(?!\.)(?!.*\.\.)([A-Za-z0-9_'+\-\.]*)[A-Za-z0-9_+-]@([A-Za-z0-9][A-Za-z0-9\-]*\.)+[A-Za-z]{2,}$/, mv = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/, gv = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/, Nf = /^[^\s@"]{1,64}@[^\s@]{1,255}$/u, hv = Nf, vv = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/, yv = "^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$";
function ba() {
  return new RegExp(yv, "u");
}
s(ba, "emoji");
var $a = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/, xa = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))$/, _a = /* @__PURE__ */ s((e) => {
  let t = me(e ?? ":");
  return new RegExp(`^(?:[0-9A-F]{2}${t}){5}[0-9A-F]{2}$|^(?:[0-9a-f]{2}${t}){5}[0-9a-f]{2}$`);
}, "mac"), wa = /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/([0-9]|[1-2][0-9]|3[0-2])$/, ka = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|::|([0-9a-fA-F]{1,4})?::([0-9a-fA-F]{1,4}:?){0,6})\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/, za = /^$|^(?:[0-9a-zA-Z+/]{4})*(?:(?:[0-9a-zA-Z+/]{2}==)|(?:[0-9a-zA-Z+/]{3}=))?$/, Cn = /^[A-Za-z0-9_-]*$/, bv = /^(?=.{1,253}\.?$)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[-0-9a-zA-Z]{0,61}[0-9a-zA-Z])?)*\.?$/, $v = /^([a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$/, Ia = /^https?$/, Sa = /^\+[1-9]\d{6,14}$/, Zf = "(?:(?:\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-(?:(?:0[13578]|1[02])-(?:0[1-9]|[12]\\d|3[01])|(?:0[469]|11)-(?:0[1-9]|[12]\\d|30)|(?:02)-(?:0[1-9]|1\\d|2[0-8])))", ja = /* @__PURE__ */ new RegExp(`^${Zf}$`);
function Af(e) {
  let t = "(?:[01]\\d|2[0-3]):[0-5]\\d";
  return typeof e.precision == "number" ? e.precision === -1 ? `${t}` : e.precision === 0 ? `${t}:[0-5]\\d` : `${t}:[0-5]\\d\\.\\d{${e.precision}}` : `${t}(?::[0-5]\\d(?:\\.\\d+)?)?`;
}
s(Af, "timeSource");
function Oa(e) {
  return new RegExp(`^${Af(e)}$`);
}
s(Oa, "time");
function Pa(e) {
  let t = Af({ precision: e.precision }), n = ["Z"];
  e.local && n.push(""), e.offset && n.push("([+-](?:[01]\\d|2[0-3]):[0-5]\\d)");
  let i = `${t}(?:${n.join("|")})`;
  return new RegExp(`^${Zf}T(?:${i})$`);
}
s(Pa, "datetime");
var Ta = /* @__PURE__ */ s((e) => {
  let t = e ? `[\\s\\S]{${e?.minimum ?? 0},${e?.maximum ?? ""}}` : "[\\s\\S]*";
  return new RegExp(`^${t}$`);
}, "string"), Ea = /^-?\d+n?$/, Ua = /^-?\d+$/, Rn = /^-?\d+(?:\.\d+)?$/, Da = /^(?:true|false)$/i, Na = /^null$/i;
var Za = /^undefined$/i;
var Aa = /^[^A-Z]*$/, Ca = /^[^a-z]*$/, xv = /^[0-9a-fA-F]*$/;
function Sr(e, t) {
  return new RegExp(`^[A-Za-z0-9+/]{${e}}${t}$`);
}
s(Sr, "fixedBase64");
function jr(e) {
  return new RegExp(`^[A-Za-z0-9_-]{${e}}$`);
}
s(jr, "fixedBase64url");
var _v = /^[0-9a-fA-F]{32}$/, wv = /* @__PURE__ */ Sr(22, "=="), kv = /* @__PURE__ */ jr(22), zv = /^[0-9a-fA-F]{40}$/, Iv = /* @__PURE__ */ Sr(27, "="), Sv = /* @__PURE__ */ jr(27), jv = /^[0-9a-fA-F]{64}$/, Ov = /* @__PURE__ */ Sr(43, "="), Pv = /* @__PURE__ */ jr(43), Tv = /^[0-9a-fA-F]{96}$/, Ev = /* @__PURE__ */ Sr(64, ""), Uv = /* @__PURE__ */ jr(64), Dv = /^[0-9a-fA-F]{128}$/, Nv = /* @__PURE__ */ Sr(86, "=="), Zv = /* @__PURE__ */ jr(86);

// versions/4.4.3/node_modules/zod/v4/core/checks.js
var R = /* @__PURE__ */ f("$ZodCheck", (e, t) => {
  var n;
  e._zod ?? (e._zod = {}), e._zod.def = t, (n = e._zod).onattach ?? (n.onattach = []);
}), Rf = {
  number: "number",
  bigint: "bigint",
  object: "date"
}, Fn = /* @__PURE__ */ f("$ZodCheckLessThan", (e, t) => {
  R.init(e, t);
  let n = Rf[typeof t.value];
  e._zod.onattach.push((i) => {
    let r = i._zod.bag, o = (t.inclusive ? r.maximum : r.exclusiveMaximum) ?? Number.POSITIVE_INFINITY;
    t.value < o && (t.inclusive ? r.maximum = t.value : r.exclusiveMaximum = t.value);
  }), e._zod.check = (i) => {
    (t.inclusive ? i.value <= t.value : i.value < t.value) || i.issues.push({
      origin: n,
      code: "too_big",
      maximum: typeof t.value == "object" ? t.value.getTime() : t.value,
      input: i.value,
      inclusive: t.inclusive,
      inst: e,
      continue: !t.abort
    });
  };
}), Ln = /* @__PURE__ */ f("$ZodCheckGreaterThan", (e, t) => {
  R.init(e, t);
  let n = Rf[typeof t.value];
  e._zod.onattach.push((i) => {
    let r = i._zod.bag, o = (t.inclusive ? r.minimum : r.exclusiveMinimum) ?? Number.NEGATIVE_INFINITY;
    t.value > o && (t.inclusive ? r.minimum = t.value : r.exclusiveMinimum = t.value);
  }), e._zod.check = (i) => {
    (t.inclusive ? i.value >= t.value : i.value > t.value) || i.issues.push({
      origin: n,
      code: "too_small",
      minimum: typeof t.value == "object" ? t.value.getTime() : t.value,
      input: i.value,
      inclusive: t.inclusive,
      inst: e,
      continue: !t.abort
    });
  };
}), Ra = /* @__PURE__ */ f("$ZodCheckMultipleOf", (e, t) => {
  R.init(e, t), e._zod.onattach.push((n) => {
    var i;
    (i = n._zod.bag).multipleOf ?? (i.multipleOf = t.value);
  }), e._zod.check = (n) => {
    if (typeof n.value != typeof t.value)
      throw new Error("Cannot mix number and bigint in multiple_of check.");
    (typeof n.value == "bigint" ? n.value % t.value === BigInt(0) : Ho(n.value, t.value) === 0) || n.issues.push({
      origin: typeof n.value,
      code: "not_multiple_of",
      divisor: t.value,
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Fa = /* @__PURE__ */ f("$ZodCheckNumberFormat", (e, t) => {
  R.init(e, t), t.format = t.format || "float64";
  let n = t.format?.includes("int"), i = n ? "int" : "number", [r, o] = ia[t.format];
  e._zod.onattach.push((a) => {
    let c = a._zod.bag;
    c.format = t.format, c.minimum = r, c.maximum = o, n && (c.pattern = Ua);
  }), e._zod.check = (a) => {
    let c = a.value;
    if (n) {
      if (!Number.isInteger(c)) {
        a.issues.push({
          expected: i,
          format: t.format,
          code: "invalid_type",
          continue: !1,
          input: c,
          inst: e
        });
        return;
      }
      if (!Number.isSafeInteger(c)) {
        c > 0 ? a.issues.push({
          input: c,
          code: "too_big",
          maximum: Number.MAX_SAFE_INTEGER,
          note: "Integers must be within the safe integer range.",
          inst: e,
          origin: i,
          inclusive: !0,
          continue: !t.abort
        }) : a.issues.push({
          input: c,
          code: "too_small",
          minimum: Number.MIN_SAFE_INTEGER,
          note: "Integers must be within the safe integer range.",
          inst: e,
          origin: i,
          inclusive: !0,
          continue: !t.abort
        });
        return;
      }
    }
    c < r && a.issues.push({
      origin: "number",
      input: c,
      code: "too_small",
      minimum: r,
      inclusive: !0,
      inst: e,
      continue: !t.abort
    }), c > o && a.issues.push({
      origin: "number",
      input: c,
      code: "too_big",
      maximum: o,
      inclusive: !0,
      inst: e,
      continue: !t.abort
    });
  };
}), La = /* @__PURE__ */ f("$ZodCheckBigIntFormat", (e, t) => {
  R.init(e, t);
  let [n, i] = oa[t.format];
  e._zod.onattach.push((r) => {
    let o = r._zod.bag;
    o.format = t.format, o.minimum = n, o.maximum = i;
  }), e._zod.check = (r) => {
    let o = r.value;
    o < n && r.issues.push({
      origin: "bigint",
      input: o,
      code: "too_small",
      minimum: n,
      inclusive: !0,
      inst: e,
      continue: !t.abort
    }), o > i && r.issues.push({
      origin: "bigint",
      input: o,
      code: "too_big",
      maximum: i,
      inclusive: !0,
      inst: e,
      continue: !t.abort
    });
  };
}), Ma = /* @__PURE__ */ f("$ZodCheckMaxSize", (e, t) => {
  var n;
  R.init(e, t), (n = e._zod.def).when ?? (n.when = (i) => {
    let r = i.value;
    return !Ze(r) && r.size !== void 0;
  }), e._zod.onattach.push((i) => {
    let r = i._zod.bag.maximum ?? Number.POSITIVE_INFINITY;
    t.maximum < r && (i._zod.bag.maximum = t.maximum);
  }), e._zod.check = (i) => {
    let r = i.value;
    r.size <= t.maximum || i.issues.push({
      origin: wr(r),
      code: "too_big",
      maximum: t.maximum,
      inclusive: !0,
      input: r,
      inst: e,
      continue: !t.abort
    });
  };
}), Ba = /* @__PURE__ */ f("$ZodCheckMinSize", (e, t) => {
  var n;
  R.init(e, t), (n = e._zod.def).when ?? (n.when = (i) => {
    let r = i.value;
    return !Ze(r) && r.size !== void 0;
  }), e._zod.onattach.push((i) => {
    let r = i._zod.bag.minimum ?? Number.NEGATIVE_INFINITY;
    t.minimum > r && (i._zod.bag.minimum = t.minimum);
  }), e._zod.check = (i) => {
    let r = i.value;
    r.size >= t.minimum || i.issues.push({
      origin: wr(r),
      code: "too_small",
      minimum: t.minimum,
      inclusive: !0,
      input: r,
      inst: e,
      continue: !t.abort
    });
  };
}), Ja = /* @__PURE__ */ f("$ZodCheckSizeEquals", (e, t) => {
  var n;
  R.init(e, t), (n = e._zod.def).when ?? (n.when = (i) => {
    let r = i.value;
    return !Ze(r) && r.size !== void 0;
  }), e._zod.onattach.push((i) => {
    let r = i._zod.bag;
    r.minimum = t.size, r.maximum = t.size, r.size = t.size;
  }), e._zod.check = (i) => {
    let r = i.value, o = r.size;
    if (o === t.size)
      return;
    let a = o > t.size;
    i.issues.push({
      origin: wr(r),
      ...a ? { code: "too_big", maximum: t.size } : { code: "too_small", minimum: t.size },
      inclusive: !0,
      exact: !0,
      input: i.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Va = /* @__PURE__ */ f("$ZodCheckMaxLength", (e, t) => {
  var n;
  R.init(e, t), (n = e._zod.def).when ?? (n.when = (i) => {
    let r = i.value;
    return !Ze(r) && r.length !== void 0;
  }), e._zod.onattach.push((i) => {
    let r = i._zod.bag.maximum ?? Number.POSITIVE_INFINITY;
    t.maximum < r && (i._zod.bag.maximum = t.maximum);
  }), e._zod.check = (i) => {
    let r = i.value;
    if (r.length <= t.maximum)
      return;
    let a = kr(r);
    i.issues.push({
      origin: a,
      code: "too_big",
      maximum: t.maximum,
      inclusive: !0,
      input: r,
      inst: e,
      continue: !t.abort
    });
  };
}), qa = /* @__PURE__ */ f("$ZodCheckMinLength", (e, t) => {
  var n;
  R.init(e, t), (n = e._zod.def).when ?? (n.when = (i) => {
    let r = i.value;
    return !Ze(r) && r.length !== void 0;
  }), e._zod.onattach.push((i) => {
    let r = i._zod.bag.minimum ?? Number.NEGATIVE_INFINITY;
    t.minimum > r && (i._zod.bag.minimum = t.minimum);
  }), e._zod.check = (i) => {
    let r = i.value;
    if (r.length >= t.minimum)
      return;
    let a = kr(r);
    i.issues.push({
      origin: a,
      code: "too_small",
      minimum: t.minimum,
      inclusive: !0,
      input: r,
      inst: e,
      continue: !t.abort
    });
  };
}), Wa = /* @__PURE__ */ f("$ZodCheckLengthEquals", (e, t) => {
  var n;
  R.init(e, t), (n = e._zod.def).when ?? (n.when = (i) => {
    let r = i.value;
    return !Ze(r) && r.length !== void 0;
  }), e._zod.onattach.push((i) => {
    let r = i._zod.bag;
    r.minimum = t.length, r.maximum = t.length, r.length = t.length;
  }), e._zod.check = (i) => {
    let r = i.value, o = r.length;
    if (o === t.length)
      return;
    let a = kr(r), c = o > t.length;
    i.issues.push({
      origin: a,
      ...c ? { code: "too_big", maximum: t.length } : { code: "too_small", minimum: t.length },
      inclusive: !0,
      exact: !0,
      input: i.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Ut = /* @__PURE__ */ f("$ZodCheckStringFormat", (e, t) => {
  var n, i;
  R.init(e, t), e._zod.onattach.push((r) => {
    let o = r._zod.bag;
    o.format = t.format, t.pattern && (o.patterns ?? (o.patterns = /* @__PURE__ */ new Set()), o.patterns.add(t.pattern));
  }), t.pattern ? (n = e._zod).check ?? (n.check = (r) => {
    t.pattern.lastIndex = 0, !t.pattern.test(r.value) && r.issues.push({
      origin: "string",
      code: "invalid_format",
      format: t.format,
      input: r.value,
      ...t.pattern ? { pattern: t.pattern.toString() } : {},
      inst: e,
      continue: !t.abort
    });
  }) : (i = e._zod).check ?? (i.check = () => {
  });
}), Ka = /* @__PURE__ */ f("$ZodCheckRegex", (e, t) => {
  Ut.init(e, t), e._zod.check = (n) => {
    t.pattern.lastIndex = 0, !t.pattern.test(n.value) && n.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "regex",
      input: n.value,
      pattern: t.pattern.toString(),
      inst: e,
      continue: !t.abort
    });
  };
}), Ga = /* @__PURE__ */ f("$ZodCheckLowerCase", (e, t) => {
  t.pattern ?? (t.pattern = Aa), Ut.init(e, t);
}), Xa = /* @__PURE__ */ f("$ZodCheckUpperCase", (e, t) => {
  t.pattern ?? (t.pattern = Ca), Ut.init(e, t);
}), Qa = /* @__PURE__ */ f("$ZodCheckIncludes", (e, t) => {
  R.init(e, t);
  let n = me(t.includes), i = new RegExp(typeof t.position == "number" ? `^.{${t.position}}${n}` : n);
  t.pattern = i, e._zod.onattach.push((r) => {
    let o = r._zod.bag;
    o.patterns ?? (o.patterns = /* @__PURE__ */ new Set()), o.patterns.add(i);
  }), e._zod.check = (r) => {
    r.value.includes(t.includes, t.position) || r.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "includes",
      includes: t.includes,
      input: r.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Ha = /* @__PURE__ */ f("$ZodCheckStartsWith", (e, t) => {
  R.init(e, t);
  let n = new RegExp(`^${me(t.prefix)}.*`);
  t.pattern ?? (t.pattern = n), e._zod.onattach.push((i) => {
    let r = i._zod.bag;
    r.patterns ?? (r.patterns = /* @__PURE__ */ new Set()), r.patterns.add(n);
  }), e._zod.check = (i) => {
    i.value.startsWith(t.prefix) || i.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "starts_with",
      prefix: t.prefix,
      input: i.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Ya = /* @__PURE__ */ f("$ZodCheckEndsWith", (e, t) => {
  R.init(e, t);
  let n = new RegExp(`.*${me(t.suffix)}$`);
  t.pattern ?? (t.pattern = n), e._zod.onattach.push((i) => {
    let r = i._zod.bag;
    r.patterns ?? (r.patterns = /* @__PURE__ */ new Set()), r.patterns.add(n);
  }), e._zod.check = (i) => {
    i.value.endsWith(t.suffix) || i.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "ends_with",
      suffix: t.suffix,
      input: i.value,
      inst: e,
      continue: !t.abort
    });
  };
});
function Cf(e, t, n) {
  e.issues.length && t.issues.push(...oe(n, e.issues));
}
s(Cf, "handleCheckPropertyResult");
var es = /* @__PURE__ */ f("$ZodCheckProperty", (e, t) => {
  R.init(e, t), e._zod.check = (n) => {
    let i = t.schema._zod.run({
      value: n.value[t.property],
      issues: []
    }, {});
    if (i instanceof Promise)
      return i.then((r) => Cf(r, n, t.property));
    Cf(i, n, t.property);
  };
}), ts = /* @__PURE__ */ f("$ZodCheckMimeType", (e, t) => {
  R.init(e, t);
  let n = new Set(t.mime);
  e._zod.onattach.push((i) => {
    i._zod.bag.mime = t.mime;
  }), e._zod.check = (i) => {
    n.has(i.value.type) || i.issues.push({
      code: "invalid_value",
      values: t.mime,
      input: i.value.type,
      inst: e,
      continue: !t.abort
    });
  };
}), rs = /* @__PURE__ */ f("$ZodCheckOverwrite", (e, t) => {
  R.init(e, t), e._zod.check = (n) => {
    n.value = t.tx(n.value);
  };
});

// versions/4.4.3/node_modules/zod/v4/core/doc.js
var Or = class {
  static {
    s(this, "Doc");
  }
  constructor(t = []) {
    this.content = [], this.indent = 0, this && (this.args = t);
  }
  indented(t) {
    this.indent += 1, t(this), this.indent -= 1;
  }
  write(t) {
    if (typeof t == "function") {
      t(this, { execution: "sync" }), t(this, { execution: "async" });
      return;
    }
    let i = t.split(`
`).filter((a) => a), r = Math.min(...i.map((a) => a.length - a.trimStart().length)), o = i.map((a) => a.slice(r)).map((a) => " ".repeat(this.indent * 2) + a);
    for (let a of o)
      this.content.push(a);
  }
  compile() {
    let t = Function, n = this?.args, r = [...(this?.content ?? [""]).map((o) => `  ${o}`)];
    return new t(...n, r.join(`
`));
  }
};

// versions/4.4.3/node_modules/zod/v4/core/versions.js
var ns = {
  major: 4,
  minor: 4,
  patch: 3
};

// versions/4.4.3/node_modules/zod/v4/core/schemas.js
var k = /* @__PURE__ */ f("$ZodType", (e, t) => {
  var n;
  e ?? (e = {}), e._zod.def = t, e._zod.bag = e._zod.bag || {}, e._zod.version = ns;
  let i = [...e._zod.def.checks ?? []];
  e._zod.traits.has("$ZodCheck") && i.unshift(e);
  for (let r of i)
    for (let o of r._zod.onattach)
      o(e);
  if (i.length === 0)
    (n = e._zod).deferred ?? (n.deferred = []), e._zod.deferred?.push(() => {
      e._zod.run = e._zod.parse;
    });
  else {
    let r = /* @__PURE__ */ s((a, c, u) => {
      let l = Re(a), d;
      for (let m of c) {
        if (m._zod.def.when) {
          if (aa(a) || !m._zod.def.when(a))
            continue;
        } else if (l)
          continue;
        let y = a.issues.length, h = m._zod.check(a);
        if (h instanceof Promise && u?.async === !1)
          throw new he();
        if (d || h instanceof Promise)
          d = (d ?? Promise.resolve()).then(async () => {
            await h, a.issues.length !== y && (l || (l = Re(a, y)));
          });
        else {
          if (a.issues.length === y)
            continue;
          l || (l = Re(a, y));
        }
      }
      return d ? d.then(() => a) : a;
    }, "runChecks"), o = /* @__PURE__ */ s((a, c, u) => {
      if (Re(a))
        return a.aborted = !0, a;
      let l = r(c, i, u);
      if (l instanceof Promise) {
        if (u.async === !1)
          throw new he();
        return l.then((d) => e._zod.parse(d, u));
      }
      return e._zod.parse(l, u);
    }, "handleCanaryResult");
    e._zod.run = (a, c) => {
      if (c.skipChecks)
        return e._zod.parse(a, c);
      if (c.direction === "backward") {
        let l = e._zod.parse({ value: a.value, issues: [] }, { ...c, skipChecks: !0 });
        return l instanceof Promise ? l.then((d) => o(d, a, c)) : o(l, a, c);
      }
      let u = e._zod.parse(a, c);
      if (u instanceof Promise) {
        if (c.async === !1)
          throw new he();
        return u.then((l) => r(l, i, c));
      }
      return r(u, i, c);
    };
  }
  j(e, "~standard", () => ({
    validate: /* @__PURE__ */ s((r) => {
      try {
        let o = nt(e, r);
        return o.success ? { value: o.data } : { issues: o.error?.issues };
      } catch {
        return ua(e, r).then((a) => a.success ? { value: a.data } : { issues: a.error?.issues });
      }
    }, "validate"),
    vendor: "zod",
    version: 1
  }));
}), ot = /* @__PURE__ */ f("$ZodString", (e, t) => {
  k.init(e, t), e._zod.pattern = [...e?._zod.bag?.patterns ?? []].pop() ?? Ta(e._zod.bag), e._zod.parse = (n, i) => {
    if (t.coerce)
      try {
        n.value = String(n.value);
      } catch {
      }
    return typeof n.value == "string" || n.issues.push({
      expected: "string",
      code: "invalid_type",
      input: n.value,
      inst: e
    }), n;
  };
}), A = /* @__PURE__ */ f("$ZodStringFormat", (e, t) => {
  Ut.init(e, t), ot.init(e, t);
}), os = /* @__PURE__ */ f("$ZodGUID", (e, t) => {
  t.pattern ?? (t.pattern = va), A.init(e, t);
}), as = /* @__PURE__ */ f("$ZodUUID", (e, t) => {
  if (t.version) {
    let i = {
      v1: 1,
      v2: 2,
      v3: 3,
      v4: 4,
      v5: 5,
      v6: 6,
      v7: 7,
      v8: 8
    }[t.version];
    if (i === void 0)
      throw new Error(`Invalid UUID version: "${t.version}"`);
    t.pattern ?? (t.pattern = it(i));
  } else
    t.pattern ?? (t.pattern = it());
  A.init(e, t);
}), ss = /* @__PURE__ */ f("$ZodEmail", (e, t) => {
  t.pattern ?? (t.pattern = ya), A.init(e, t);
}), cs = /* @__PURE__ */ f("$ZodURL", (e, t) => {
  A.init(e, t), e._zod.check = (n) => {
    try {
      let i = n.value.trim();
      if (!t.normalize && t.protocol?.source === Ia.source && !/^https?:\/\//i.test(i)) {
        n.issues.push({
          code: "invalid_format",
          format: "url",
          note: "Invalid URL format",
          input: n.value,
          inst: e,
          continue: !t.abort
        });
        return;
      }
      let r = new URL(i);
      t.hostname && (t.hostname.lastIndex = 0, t.hostname.test(r.hostname) || n.issues.push({
        code: "invalid_format",
        format: "url",
        note: "Invalid hostname",
        pattern: t.hostname.source,
        input: n.value,
        inst: e,
        continue: !t.abort
      })), t.protocol && (t.protocol.lastIndex = 0, t.protocol.test(r.protocol.endsWith(":") ? r.protocol.slice(0, -1) : r.protocol) || n.issues.push({
        code: "invalid_format",
        format: "url",
        note: "Invalid protocol",
        pattern: t.protocol.source,
        input: n.value,
        inst: e,
        continue: !t.abort
      })), t.normalize ? n.value = r.href : n.value = i;
      return;
    } catch {
      n.issues.push({
        code: "invalid_format",
        format: "url",
        input: n.value,
        inst: e,
        continue: !t.abort
      });
    }
  };
}), us = /* @__PURE__ */ f("$ZodEmoji", (e, t) => {
  t.pattern ?? (t.pattern = ba()), A.init(e, t);
}), ls = /* @__PURE__ */ f("$ZodNanoID", (e, t) => {
  t.pattern ?? (t.pattern = ga), A.init(e, t);
}), ds = /* @__PURE__ */ f("$ZodCUID", (e, t) => {
  t.pattern ?? (t.pattern = la), A.init(e, t);
}), fs = /* @__PURE__ */ f("$ZodCUID2", (e, t) => {
  t.pattern ?? (t.pattern = da), A.init(e, t);
}), ps = /* @__PURE__ */ f("$ZodULID", (e, t) => {
  t.pattern ?? (t.pattern = fa), A.init(e, t);
}), ms = /* @__PURE__ */ f("$ZodXID", (e, t) => {
  t.pattern ?? (t.pattern = pa), A.init(e, t);
}), gs = /* @__PURE__ */ f("$ZodKSUID", (e, t) => {
  t.pattern ?? (t.pattern = ma), A.init(e, t);
}), hs = /* @__PURE__ */ f("$ZodISODateTime", (e, t) => {
  t.pattern ?? (t.pattern = Pa(t)), A.init(e, t);
}), vs = /* @__PURE__ */ f("$ZodISODate", (e, t) => {
  t.pattern ?? (t.pattern = ja), A.init(e, t);
}), ys = /* @__PURE__ */ f("$ZodISOTime", (e, t) => {
  t.pattern ?? (t.pattern = Oa(t)), A.init(e, t);
}), bs = /* @__PURE__ */ f("$ZodISODuration", (e, t) => {
  t.pattern ?? (t.pattern = ha), A.init(e, t);
}), $s = /* @__PURE__ */ f("$ZodIPv4", (e, t) => {
  t.pattern ?? (t.pattern = $a), A.init(e, t), e._zod.bag.format = "ipv4";
}), xs = /* @__PURE__ */ f("$ZodIPv6", (e, t) => {
  t.pattern ?? (t.pattern = xa), A.init(e, t), e._zod.bag.format = "ipv6", e._zod.check = (n) => {
    try {
      new URL(`http://[${n.value}]`);
    } catch {
      n.issues.push({
        code: "invalid_format",
        format: "ipv6",
        input: n.value,
        inst: e,
        continue: !t.abort
      });
    }
  };
}), _s = /* @__PURE__ */ f("$ZodMAC", (e, t) => {
  t.pattern ?? (t.pattern = _a(t.delimiter)), A.init(e, t), e._zod.bag.format = "mac";
}), ws = /* @__PURE__ */ f("$ZodCIDRv4", (e, t) => {
  t.pattern ?? (t.pattern = wa), A.init(e, t);
}), ks = /* @__PURE__ */ f("$ZodCIDRv6", (e, t) => {
  t.pattern ?? (t.pattern = ka), A.init(e, t), e._zod.check = (n) => {
    let i = n.value.split("/");
    try {
      if (i.length !== 2)
        throw new Error();
      let [r, o] = i;
      if (!o)
        throw new Error();
      let a = Number(o);
      if (`${a}` !== o)
        throw new Error();
      if (a < 0 || a > 128)
        throw new Error();
      new URL(`http://[${r}]`);
    } catch {
      n.issues.push({
        code: "invalid_format",
        format: "cidrv6",
        input: n.value,
        inst: e,
        continue: !t.abort
      });
    }
  };
});
function zs(e) {
  if (e === "")
    return !0;
  if (/\s/.test(e) || e.length % 4 !== 0)
    return !1;
  try {
    return atob(e), !0;
  } catch {
    return !1;
  }
}
s(zs, "isValidBase64");
var Is = /* @__PURE__ */ f("$ZodBase64", (e, t) => {
  t.pattern ?? (t.pattern = za), A.init(e, t), e._zod.bag.contentEncoding = "base64", e._zod.check = (n) => {
    zs(n.value) || n.issues.push({
      code: "invalid_format",
      format: "base64",
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
});
function tp(e) {
  if (!Cn.test(e))
    return !1;
  let t = e.replace(/[-_]/g, (i) => i === "-" ? "+" : "/"), n = t.padEnd(Math.ceil(t.length / 4) * 4, "=");
  return zs(n);
}
s(tp, "isValidBase64URL");
var Ss = /* @__PURE__ */ f("$ZodBase64URL", (e, t) => {
  t.pattern ?? (t.pattern = Cn), A.init(e, t), e._zod.bag.contentEncoding = "base64url", e._zod.check = (n) => {
    tp(n.value) || n.issues.push({
      code: "invalid_format",
      format: "base64url",
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), js = /* @__PURE__ */ f("$ZodE164", (e, t) => {
  t.pattern ?? (t.pattern = Sa), A.init(e, t);
});
function rp(e, t = null) {
  try {
    let n = e.split(".");
    if (n.length !== 3)
      return !1;
    let [i] = n;
    if (!i)
      return !1;
    let r = JSON.parse(atob(i));
    return !("typ" in r && r?.typ !== "JWT" || !r.alg || t && (!("alg" in r) || r.alg !== t));
  } catch {
    return !1;
  }
}
s(rp, "isValidJWT");
var Os = /* @__PURE__ */ f("$ZodJWT", (e, t) => {
  A.init(e, t), e._zod.check = (n) => {
    rp(n.value, t.alg) || n.issues.push({
      code: "invalid_format",
      format: "jwt",
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Ps = /* @__PURE__ */ f("$ZodCustomStringFormat", (e, t) => {
  A.init(e, t), e._zod.check = (n) => {
    t.fn(n.value) || n.issues.push({
      code: "invalid_format",
      format: t.format,
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), qn = /* @__PURE__ */ f("$ZodNumber", (e, t) => {
  k.init(e, t), e._zod.pattern = e._zod.bag.pattern ?? Rn, e._zod.parse = (n, i) => {
    if (t.coerce)
      try {
        n.value = Number(n.value);
      } catch {
      }
    let r = n.value;
    if (typeof r == "number" && !Number.isNaN(r) && Number.isFinite(r))
      return n;
    let o = typeof r == "number" ? Number.isNaN(r) ? "NaN" : Number.isFinite(r) ? void 0 : "Infinity" : void 0;
    return n.issues.push({
      expected: "number",
      code: "invalid_type",
      input: r,
      inst: e,
      ...o ? { received: o } : {}
    }), n;
  };
}), Ts = /* @__PURE__ */ f("$ZodNumberFormat", (e, t) => {
  Fa.init(e, t), qn.init(e, t);
}), Pr = /* @__PURE__ */ f("$ZodBoolean", (e, t) => {
  k.init(e, t), e._zod.pattern = Da, e._zod.parse = (n, i) => {
    if (t.coerce)
      try {
        n.value = !!n.value;
      } catch {
      }
    let r = n.value;
    return typeof r == "boolean" || n.issues.push({
      expected: "boolean",
      code: "invalid_type",
      input: r,
      inst: e
    }), n;
  };
}), Wn = /* @__PURE__ */ f("$ZodBigInt", (e, t) => {
  k.init(e, t), e._zod.pattern = Ea, e._zod.parse = (n, i) => {
    if (t.coerce)
      try {
        n.value = BigInt(n.value);
      } catch {
      }
    return typeof n.value == "bigint" || n.issues.push({
      expected: "bigint",
      code: "invalid_type",
      input: n.value,
      inst: e
    }), n;
  };
}), Es = /* @__PURE__ */ f("$ZodBigIntFormat", (e, t) => {
  La.init(e, t), Wn.init(e, t);
}), Us = /* @__PURE__ */ f("$ZodSymbol", (e, t) => {
  k.init(e, t), e._zod.parse = (n, i) => {
    let r = n.value;
    return typeof r == "symbol" || n.issues.push({
      expected: "symbol",
      code: "invalid_type",
      input: r,
      inst: e
    }), n;
  };
}), Ds = /* @__PURE__ */ f("$ZodUndefined", (e, t) => {
  k.init(e, t), e._zod.pattern = Za, e._zod.values = /* @__PURE__ */ new Set([void 0]), e._zod.parse = (n, i) => {
    let r = n.value;
    return typeof r > "u" || n.issues.push({
      expected: "undefined",
      code: "invalid_type",
      input: r,
      inst: e
    }), n;
  };
}), Ns = /* @__PURE__ */ f("$ZodNull", (e, t) => {
  k.init(e, t), e._zod.pattern = Na, e._zod.values = /* @__PURE__ */ new Set([null]), e._zod.parse = (n, i) => {
    let r = n.value;
    return r === null || n.issues.push({
      expected: "null",
      code: "invalid_type",
      input: r,
      inst: e
    }), n;
  };
}), Zs = /* @__PURE__ */ f("$ZodAny", (e, t) => {
  k.init(e, t), e._zod.parse = (n) => n;
}), As = /* @__PURE__ */ f("$ZodUnknown", (e, t) => {
  k.init(e, t), e._zod.parse = (n) => n;
}), Cs = /* @__PURE__ */ f("$ZodNever", (e, t) => {
  k.init(e, t), e._zod.parse = (n, i) => (n.issues.push({
    expected: "never",
    code: "invalid_type",
    input: n.value,
    inst: e
  }), n);
}), Rs = /* @__PURE__ */ f("$ZodVoid", (e, t) => {
  k.init(e, t), e._zod.parse = (n, i) => {
    let r = n.value;
    return typeof r > "u" || n.issues.push({
      expected: "void",
      code: "invalid_type",
      input: r,
      inst: e
    }), n;
  };
}), Dt = /* @__PURE__ */ f("$ZodDate", (e, t) => {
  k.init(e, t), e._zod.parse = (n, i) => {
    if (t.coerce)
      try {
        n.value = new Date(n.value);
      } catch {
      }
    let r = n.value, o = r instanceof Date;
    return o && !Number.isNaN(r.getTime()) || n.issues.push({
      expected: "date",
      code: "invalid_type",
      input: r,
      ...o ? { received: "Invalid Date" } : {},
      inst: e
    }), n;
  };
});
function Lf(e, t, n) {
  e.issues.length && t.issues.push(...oe(n, e.issues)), t.value[n] = e.value;
}
s(Lf, "handleArrayResult");
var Le = /* @__PURE__ */ f("$ZodArray", (e, t) => {
  k.init(e, t), e._zod.parse = (n, i) => {
    let r = n.value;
    if (!Array.isArray(r))
      return n.issues.push({
        expected: "array",
        code: "invalid_type",
        input: r,
        inst: e
      }), n;
    n.value = Array(r.length);
    let o = [];
    for (let a = 0; a < r.length; a++) {
      let c = r[a], u = t.element._zod.run({
        value: c,
        issues: []
      }, i);
      u instanceof Promise ? o.push(u.then((l) => Lf(l, n, a))) : Lf(u, n, a);
    }
    return o.length ? Promise.all(o).then(() => n) : n;
  };
});
function Vn(e, t, n, i, r, o) {
  let a = n in i;
  if (e.issues.length) {
    if (r && o && !a)
      return;
    t.issues.push(...oe(n, e.issues));
  }
  if (!a && !r) {
    e.issues.length || t.issues.push({
      code: "invalid_type",
      expected: "nonoptional",
      input: void 0,
      path: [n]
    });
    return;
  }
  e.value === void 0 ? a && (t.value[n] = void 0) : t.value[n] = e.value;
}
s(Vn, "handlePropertyResult");
function np(e) {
  let t = Object.keys(e.shape);
  for (let i of t)
    if (!e.shape?.[i]?._zod?.traits?.has("$ZodType"))
      throw new Error(`Invalid element at key "${i}": expected a Zod schema`);
  let n = na(e.shape);
  return {
    ...e,
    keys: t,
    keySet: new Set(t),
    numKeys: t.length,
    optionalKeys: new Set(n)
  };
}
s(np, "normalizeDef");
function ip(e, t, n, i, r, o) {
  let a = [], c = r.keySet, u = r.catchall._zod, l = u.def.type, d = u.optin === "optional", m = u.optout === "optional";
  for (let y in t) {
    if (y === "__proto__" || c.has(y))
      continue;
    if (l === "never") {
      a.push(y);
      continue;
    }
    let h = u.run({ value: t[y], issues: [] }, i);
    h instanceof Promise ? e.push(h.then((z) => Vn(z, n, y, t, d, m))) : Vn(h, n, y, t, d, m);
  }
  return a.length && n.issues.push({
    code: "unrecognized_keys",
    keys: a,
    input: t,
    inst: o
  }), e.length ? Promise.all(e).then(() => n) : n;
}
s(ip, "handleCatchall");
var K = /* @__PURE__ */ f("$ZodObject", (e, t) => {
  if (k.init(e, t), !Object.getOwnPropertyDescriptor(t, "shape")?.get) {
    let c = t.shape;
    Object.defineProperty(t, "shape", {
      get: /* @__PURE__ */ s(() => {
        let u = { ...c };
        return Object.defineProperty(t, "shape", {
          value: u
        }), u;
      }, "get")
    });
  }
  let i = St(() => np(t));
  j(e._zod, "propValues", () => {
    let c = t.shape, u = {};
    for (let l in c) {
      let d = c[l]._zod;
      if (d.values) {
        u[l] ?? (u[l] = /* @__PURE__ */ new Set());
        for (let m of d.values)
          u[l].add(m);
      }
    }
    return u;
  });
  let r = rt, o = t.catchall, a;
  e._zod.parse = (c, u) => {
    a ?? (a = i.value);
    let l = c.value;
    if (!r(l))
      return c.issues.push({
        expected: "object",
        code: "invalid_type",
        input: l,
        inst: e
      }), c;
    c.value = {};
    let d = [], m = a.shape;
    for (let y of a.keys) {
      let h = m[y], z = h._zod.optin === "optional", D = h._zod.optout === "optional", T = h._zod.run({ value: l[y], issues: [] }, u);
      T instanceof Promise ? d.push(T.then((Oe) => Vn(Oe, c, y, l, z, D))) : Vn(T, c, y, l, z, D);
    }
    return o ? ip(d, l, c, u, i.value, e) : d.length ? Promise.all(d).then(() => c) : c;
  };
}), Fs = /* @__PURE__ */ f("$ZodObjectJIT", (e, t) => {
  K.init(e, t);
  let n = e._zod.parse, i = St(() => np(t)), r = /* @__PURE__ */ s((y) => {
    let h = new Or(["shape", "payload", "ctx"]), z = i.value, D = /* @__PURE__ */ s((G) => {
      let P = Sn(G);
      return `shape[${P}]._zod.run({ value: input[${P}], issues: [] }, ctx)`;
    }, "parseStr");
    h.write("const input = payload.value;");
    let T = /* @__PURE__ */ Object.create(null), Oe = 0;
    for (let G of z.keys)
      T[G] = `key_${Oe++}`;
    h.write("const newResult = {};");
    for (let G of z.keys) {
      let P = T[G], L = Sn(G), I = y[G], O = I?._zod?.optin === "optional", B = I?._zod?.optout === "optional";
      h.write(`const ${P} = ${D(G)};`), O && B ? h.write(`
        if (${P}.issues.length) {
          if (${L} in input) {
            payload.issues = payload.issues.concat(${P}.issues.map(iss => ({
              ...iss,
              path: iss.path ? [${L}, ...iss.path] : [${L}]
            })));
          }
        }
        
        if (${P}.value === undefined) {
          if (${L} in input) {
            newResult[${L}] = undefined;
          }
        } else {
          newResult[${L}] = ${P}.value;
        }
        
      `) : O ? h.write(`
        if (${P}.issues.length) {
          payload.issues = payload.issues.concat(${P}.issues.map(iss => ({
            ...iss,
            path: iss.path ? [${L}, ...iss.path] : [${L}]
          })));
        }
        
        if (${P}.value === undefined) {
          if (${L} in input) {
            newResult[${L}] = undefined;
          }
        } else {
          newResult[${L}] = ${P}.value;
        }
        
      `) : h.write(`
        const ${P}_present = ${L} in input;
        if (${P}.issues.length) {
          payload.issues = payload.issues.concat(${P}.issues.map(iss => ({
            ...iss,
            path: iss.path ? [${L}, ...iss.path] : [${L}]
          })));
        }
        if (!${P}_present && !${P}.issues.length) {
          payload.issues.push({
            code: "invalid_type",
            expected: "nonoptional",
            input: undefined,
            path: [${L}]
          });
        }

        if (${P}_present) {
          if (${P}.value === undefined) {
            newResult[${L}] = undefined;
          } else {
            newResult[${L}] = ${P}.value;
          }
        }

      `);
    }
    h.write("payload.value = newResult;"), h.write("return payload;");
    let _e = h.compile();
    return (G, P) => _e(y, G, P);
  }, "generateFastpass"), o, a = rt, c = !tt.jitless, l = c && ea.value, d = t.catchall, m;
  e._zod.parse = (y, h) => {
    m ?? (m = i.value);
    let z = y.value;
    return a(z) ? c && l && h?.async === !1 && h.jitless !== !0 ? (o || (o = r(t.shape)), y = o(y, h), d ? ip([], z, y, h, m, e) : y) : n(y, h) : (y.issues.push({
      expected: "object",
      code: "invalid_type",
      input: z,
      inst: e
    }), y);
  };
});
function Mf(e, t, n, i) {
  for (let o of e)
    if (o.issues.length === 0)
      return t.value = o.value, t;
  let r = e.filter((o) => !Re(o));
  return r.length === 1 ? (t.value = r[0].value, r[0]) : (t.issues.push({
    code: "invalid_union",
    input: t.value,
    inst: n,
    errors: e.map((o) => o.issues.map((a) => te(a, i, q())))
  }), t);
}
s(Mf, "handleUnionResults");
var re = /* @__PURE__ */ f("$ZodUnion", (e, t) => {
  k.init(e, t), j(e._zod, "optin", () => t.options.some((i) => i._zod.optin === "optional") ? "optional" : void 0), j(e._zod, "optout", () => t.options.some((i) => i._zod.optout === "optional") ? "optional" : void 0), j(e._zod, "values", () => {
    if (t.options.every((i) => i._zod.values))
      return new Set(t.options.flatMap((i) => Array.from(i._zod.values)));
  }), j(e._zod, "pattern", () => {
    if (t.options.every((i) => i._zod.pattern)) {
      let i = t.options.map((r) => r._zod.pattern);
      return new RegExp(`^(${i.map((r) => xr(r.source)).join("|")})$`);
    }
  });
  let n = t.options.length === 1 ? t.options[0]._zod.run : null;
  e._zod.parse = (i, r) => {
    if (n)
      return n(i, r);
    let o = !1, a = [];
    for (let c of t.options) {
      let u = c._zod.run({
        value: i.value,
        issues: []
      }, r);
      if (u instanceof Promise)
        a.push(u), o = !0;
      else {
        if (u.issues.length === 0)
          return u;
        a.push(u);
      }
    }
    return o ? Promise.all(a).then((c) => Mf(c, i, e, r)) : Mf(a, i, e, r);
  };
});
function Bf(e, t, n, i) {
  let r = e.filter((o) => o.issues.length === 0);
  return r.length === 1 ? (t.value = r[0].value, t) : (r.length === 0 ? t.issues.push({
    code: "invalid_union",
    input: t.value,
    inst: n,
    errors: e.map((o) => o.issues.map((a) => te(a, i, q())))
  }) : t.issues.push({
    code: "invalid_union",
    input: t.value,
    inst: n,
    errors: [],
    inclusive: !1
  }), t);
}
s(Bf, "handleExclusiveUnionResults");
var Ls = /* @__PURE__ */ f("$ZodXor", (e, t) => {
  re.init(e, t), t.inclusive = !1;
  let n = t.options.length === 1 ? t.options[0]._zod.run : null;
  e._zod.parse = (i, r) => {
    if (n)
      return n(i, r);
    let o = !1, a = [];
    for (let c of t.options) {
      let u = c._zod.run({
        value: i.value,
        issues: []
      }, r);
      u instanceof Promise ? (a.push(u), o = !0) : a.push(u);
    }
    return o ? Promise.all(a).then((c) => Bf(c, i, e, r)) : Bf(a, i, e, r);
  };
}), Me = /* @__PURE__ */ f("$ZodDiscriminatedUnion", (e, t) => {
  t.inclusive = !1, re.init(e, t);
  let n = e._zod.parse;
  j(e._zod, "propValues", () => {
    let r = {};
    for (let o of t.options) {
      let a = o._zod.propValues;
      if (!a || Object.keys(a).length === 0)
        throw new Error(`Invalid discriminated union option at index "${t.options.indexOf(o)}"`);
      for (let [c, u] of Object.entries(a)) {
        r[c] || (r[c] = /* @__PURE__ */ new Set());
        for (let l of u)
          r[c].add(l);
      }
    }
    return r;
  });
  let i = St(() => {
    let r = t.options, o = /* @__PURE__ */ new Map();
    for (let a of r) {
      let c = a._zod.propValues?.[t.discriminator];
      if (!c || c.size === 0)
        throw new Error(`Invalid discriminated union option at index "${t.options.indexOf(a)}"`);
      for (let u of c) {
        if (o.has(u))
          throw new Error(`Duplicate discriminator value "${String(u)}"`);
        o.set(u, a);
      }
    }
    return o;
  });
  e._zod.parse = (r, o) => {
    let a = r.value;
    if (!rt(a))
      return r.issues.push({
        code: "invalid_type",
        expected: "object",
        input: a,
        inst: e
      }), r;
    let c = i.value.get(a?.[t.discriminator]);
    return c ? c._zod.run(r, o) : t.unionFallback || o.direction === "backward" ? n(r, o) : (r.issues.push({
      code: "invalid_union",
      errors: [],
      note: "No matching discriminator",
      discriminator: t.discriminator,
      options: Array.from(i.value.keys()),
      input: a,
      path: [t.discriminator],
      inst: e
    }), r);
  };
}), Ms = /* @__PURE__ */ f("$ZodIntersection", (e, t) => {
  k.init(e, t), e._zod.parse = (n, i) => {
    let r = n.value, o = t.left._zod.run({ value: r, issues: [] }, i), a = t.right._zod.run({ value: r, issues: [] }, i);
    return o instanceof Promise || a instanceof Promise ? Promise.all([o, a]).then(([u, l]) => Jf(n, u, l)) : Jf(n, o, a);
  };
});
function is(e, t) {
  if (e === t)
    return { valid: !0, data: e };
  if (e instanceof Date && t instanceof Date && +e == +t)
    return { valid: !0, data: e };
  if (Ce(e) && Ce(t)) {
    let n = Object.keys(t), i = Object.keys(e).filter((o) => n.indexOf(o) !== -1), r = { ...e, ...t };
    for (let o of i) {
      let a = is(e[o], t[o]);
      if (!a.valid)
        return {
          valid: !1,
          mergeErrorPath: [o, ...a.mergeErrorPath]
        };
      r[o] = a.data;
    }
    return { valid: !0, data: r };
  }
  if (Array.isArray(e) && Array.isArray(t)) {
    if (e.length !== t.length)
      return { valid: !1, mergeErrorPath: [] };
    let n = [];
    for (let i = 0; i < e.length; i++) {
      let r = e[i], o = t[i], a = is(r, o);
      if (!a.valid)
        return {
          valid: !1,
          mergeErrorPath: [i, ...a.mergeErrorPath]
        };
      n.push(a.data);
    }
    return { valid: !0, data: n };
  }
  return { valid: !1, mergeErrorPath: [] };
}
s(is, "mergeValues");
function Jf(e, t, n) {
  let i = /* @__PURE__ */ new Map(), r;
  for (let c of t.issues)
    if (c.code === "unrecognized_keys") {
      r ?? (r = c);
      for (let u of c.keys)
        i.has(u) || i.set(u, {}), i.get(u).l = !0;
    } else
      e.issues.push(c);
  for (let c of n.issues)
    if (c.code === "unrecognized_keys")
      for (let u of c.keys)
        i.has(u) || i.set(u, {}), i.get(u).r = !0;
    else
      e.issues.push(c);
  let o = [...i].filter(([, c]) => c.l && c.r).map(([c]) => c);
  if (o.length && r && e.issues.push({ ...r, keys: o }), Re(e))
    return e;
  let a = is(t.value, n.value);
  if (!a.valid)
    throw new Error(`Unmergable intersection. Error path: ${JSON.stringify(a.mergeErrorPath)}`);
  return e.value = a.data, e;
}
s(Jf, "handleIntersectionResults");
var Be = /* @__PURE__ */ f("$ZodTuple", (e, t) => {
  k.init(e, t);
  let n = t.items;
  e._zod.parse = (i, r) => {
    let o = i.value;
    if (!Array.isArray(o))
      return i.issues.push({
        input: o,
        inst: e,
        expected: "tuple",
        code: "invalid_type"
      }), i;
    i.value = [];
    let a = [], c = Vf(n, "optin"), u = Vf(n, "optout");
    if (!t.rest) {
      if (o.length < c)
        return i.issues.push({
          code: "too_small",
          minimum: c,
          inclusive: !0,
          input: o,
          inst: e,
          origin: "array"
        }), i;
      o.length > n.length && i.issues.push({
        code: "too_big",
        maximum: n.length,
        inclusive: !0,
        input: o,
        inst: e,
        origin: "array"
      });
    }
    let l = new Array(n.length);
    for (let d = 0; d < n.length; d++) {
      let m = n[d]._zod.run({ value: o[d], issues: [] }, r);
      m instanceof Promise ? a.push(m.then((y) => {
        l[d] = y;
      })) : l[d] = m;
    }
    if (t.rest) {
      let d = n.length - 1, m = o.slice(n.length);
      for (let y of m) {
        d++;
        let h = t.rest._zod.run({ value: y, issues: [] }, r);
        h instanceof Promise ? a.push(h.then((z) => qf(z, i, d))) : qf(h, i, d);
      }
    }
    return a.length ? Promise.all(a).then(() => Wf(l, i, n, o, u)) : Wf(l, i, n, o, u);
  };
});
function Vf(e, t) {
  for (let n = e.length - 1; n >= 0; n--)
    if (e[n]._zod[t] !== "optional")
      return n + 1;
  return 0;
}
s(Vf, "getTupleOptStart");
function qf(e, t, n) {
  e.issues.length && t.issues.push(...oe(n, e.issues)), t.value[n] = e.value;
}
s(qf, "handleTupleResult");
function Wf(e, t, n, i, r) {
  for (let o = 0; o < n.length; o++) {
    let a = e[o], c = o < i.length;
    if (a.issues.length) {
      if (!c && o >= r) {
        t.value.length = o;
        break;
      }
      t.issues.push(...oe(o, a.issues));
    }
    t.value[o] = a.value;
  }
  for (let o = t.value.length - 1; o >= i.length && (n[o]._zod.optout === "optional" && t.value[o] === void 0); o--)
    t.value.length = o;
  return t;
}
s(Wf, "handleTupleResults");
var at = /* @__PURE__ */ f("$ZodRecord", (e, t) => {
  k.init(e, t), e._zod.parse = (n, i) => {
    let r = n.value;
    if (!Ce(r))
      return n.issues.push({
        expected: "record",
        code: "invalid_type",
        input: r,
        inst: e
      }), n;
    let o = [], a = t.keyType._zod.values;
    if (a) {
      n.value = {};
      let c = /* @__PURE__ */ new Set();
      for (let l of a)
        if (typeof l == "string" || typeof l == "number" || typeof l == "symbol") {
          c.add(typeof l == "number" ? l.toString() : l);
          let d = t.keyType._zod.run({ value: l, issues: [] }, i);
          if (d instanceof Promise)
            throw new Error("Async schemas not supported in object keys currently");
          if (d.issues.length) {
            n.issues.push({
              code: "invalid_key",
              origin: "record",
              issues: d.issues.map((h) => te(h, i, q())),
              input: l,
              path: [l],
              inst: e
            });
            continue;
          }
          let m = d.value, y = t.valueType._zod.run({ value: r[l], issues: [] }, i);
          y instanceof Promise ? o.push(y.then((h) => {
            h.issues.length && n.issues.push(...oe(l, h.issues)), n.value[m] = h.value;
          })) : (y.issues.length && n.issues.push(...oe(l, y.issues)), n.value[m] = y.value);
        }
      let u;
      for (let l in r)
        c.has(l) || (u = u ?? [], u.push(l));
      u && u.length > 0 && n.issues.push({
        code: "unrecognized_keys",
        input: r,
        inst: e,
        keys: u
      });
    } else {
      n.value = {};
      for (let c of Reflect.ownKeys(r)) {
        if (c === "__proto__" || !Object.prototype.propertyIsEnumerable.call(r, c))
          continue;
        let u = t.keyType._zod.run({ value: c, issues: [] }, i);
        if (u instanceof Promise)
          throw new Error("Async schemas not supported in object keys currently");
        if (typeof c == "string" && Rn.test(c) && u.issues.length) {
          let m = t.keyType._zod.run({ value: Number(c), issues: [] }, i);
          if (m instanceof Promise)
            throw new Error("Async schemas not supported in object keys currently");
          m.issues.length === 0 && (u = m);
        }
        if (u.issues.length) {
          t.mode === "loose" ? n.value[c] = r[c] : n.issues.push({
            code: "invalid_key",
            origin: "record",
            issues: u.issues.map((m) => te(m, i, q())),
            input: c,
            path: [c],
            inst: e
          });
          continue;
        }
        let d = t.valueType._zod.run({ value: r[c], issues: [] }, i);
        d instanceof Promise ? o.push(d.then((m) => {
          m.issues.length && n.issues.push(...oe(c, m.issues)), n.value[u.value] = m.value;
        })) : (d.issues.length && n.issues.push(...oe(c, d.issues)), n.value[u.value] = d.value);
      }
    }
    return o.length ? Promise.all(o).then(() => n) : n;
  };
}), Bs = /* @__PURE__ */ f("$ZodMap", (e, t) => {
  k.init(e, t), e._zod.parse = (n, i) => {
    let r = n.value;
    if (!(r instanceof Map))
      return n.issues.push({
        expected: "map",
        code: "invalid_type",
        input: r,
        inst: e
      }), n;
    let o = [];
    n.value = /* @__PURE__ */ new Map();
    for (let [a, c] of r) {
      let u = t.keyType._zod.run({ value: a, issues: [] }, i), l = t.valueType._zod.run({ value: c, issues: [] }, i);
      u instanceof Promise || l instanceof Promise ? o.push(Promise.all([u, l]).then(([d, m]) => {
        Kf(d, m, n, a, r, e, i);
      })) : Kf(u, l, n, a, r, e, i);
    }
    return o.length ? Promise.all(o).then(() => n) : n;
  };
});
function Kf(e, t, n, i, r, o, a) {
  e.issues.length && (_r.has(typeof i) ? n.issues.push(...oe(i, e.issues)) : n.issues.push({
    code: "invalid_key",
    origin: "map",
    input: r,
    inst: o,
    issues: e.issues.map((c) => te(c, a, q()))
  })), t.issues.length && (_r.has(typeof i) ? n.issues.push(...oe(i, t.issues)) : n.issues.push({
    origin: "map",
    code: "invalid_element",
    input: r,
    inst: o,
    key: i,
    issues: t.issues.map((c) => te(c, a, q()))
  })), n.value.set(e.value, t.value);
}
s(Kf, "handleMapResult");
var Js = /* @__PURE__ */ f("$ZodSet", (e, t) => {
  k.init(e, t), e._zod.parse = (n, i) => {
    let r = n.value;
    if (!(r instanceof Set))
      return n.issues.push({
        input: r,
        inst: e,
        expected: "set",
        code: "invalid_type"
      }), n;
    let o = [];
    n.value = /* @__PURE__ */ new Set();
    for (let a of r) {
      let c = t.valueType._zod.run({ value: a, issues: [] }, i);
      c instanceof Promise ? o.push(c.then((u) => Gf(u, n))) : Gf(c, n);
    }
    return o.length ? Promise.all(o).then(() => n) : n;
  };
});
function Gf(e, t) {
  e.issues.length && t.issues.push(...e.issues), t.value.add(e.value);
}
s(Gf, "handleSetResult");
var Nt = /* @__PURE__ */ f("$ZodEnum", (e, t) => {
  k.init(e, t);
  let n = $r(t.entries), i = new Set(n);
  e._zod.values = i, e._zod.pattern = new RegExp(`^(${n.filter((r) => _r.has(typeof r)).map((r) => typeof r == "string" ? me(r) : r.toString()).join("|")})$`), e._zod.parse = (r, o) => {
    let a = r.value;
    return i.has(a) || r.issues.push({
      code: "invalid_value",
      values: n,
      input: a,
      inst: e
    }), r;
  };
}), Zt = /* @__PURE__ */ f("$ZodLiteral", (e, t) => {
  if (k.init(e, t), t.values.length === 0)
    throw new Error("Cannot create literal schema with no valid values");
  let n = new Set(t.values);
  e._zod.values = n, e._zod.pattern = new RegExp(`^(${t.values.map((i) => typeof i == "string" ? me(i) : i ? me(i.toString()) : String(i)).join("|")})$`), e._zod.parse = (i, r) => {
    let o = i.value;
    return n.has(o) || i.issues.push({
      code: "invalid_value",
      values: t.values,
      input: o,
      inst: e
    }), i;
  };
}), Vs = /* @__PURE__ */ f("$ZodFile", (e, t) => {
  k.init(e, t), e._zod.parse = (n, i) => {
    let r = n.value;
    return r instanceof File || n.issues.push({
      expected: "file",
      code: "invalid_type",
      input: r,
      inst: e
    }), n;
  };
}), qs = /* @__PURE__ */ f("$ZodTransform", (e, t) => {
  k.init(e, t), e._zod.optin = "optional", e._zod.parse = (n, i) => {
    if (i.direction === "backward")
      throw new Ne(e.constructor.name);
    let r = t.transform(n.value, n);
    if (i.async)
      return (r instanceof Promise ? r : Promise.resolve(r)).then((a) => (n.value = a, n.fallback = !0, n));
    if (r instanceof Promise)
      throw new he();
    return n.value = r, n.fallback = !0, n;
  };
});
function Xf(e, t) {
  return t === void 0 && (e.issues.length || e.fallback) ? { issues: [], value: void 0 } : e;
}
s(Xf, "handleOptionalResult");
var V = /* @__PURE__ */ f("$ZodOptional", (e, t) => {
  k.init(e, t), e._zod.optin = "optional", e._zod.optout = "optional", j(e._zod, "values", () => t.innerType._zod.values ? /* @__PURE__ */ new Set([...t.innerType._zod.values, void 0]) : void 0), j(e._zod, "pattern", () => {
    let n = t.innerType._zod.pattern;
    return n ? new RegExp(`^(${xr(n.source)})?$`) : void 0;
  }), e._zod.parse = (n, i) => {
    if (t.innerType._zod.optin === "optional") {
      let r = n.value, o = t.innerType._zod.run(n, i);
      return o instanceof Promise ? o.then((a) => Xf(a, r)) : Xf(o, r);
    }
    return n.value === void 0 ? n : t.innerType._zod.run(n, i);
  };
}), Ws = /* @__PURE__ */ f("$ZodExactOptional", (e, t) => {
  V.init(e, t), j(e._zod, "values", () => t.innerType._zod.values), j(e._zod, "pattern", () => t.innerType._zod.pattern), e._zod.parse = (n, i) => t.innerType._zod.run(n, i);
}), be = /* @__PURE__ */ f("$ZodNullable", (e, t) => {
  k.init(e, t), j(e._zod, "optin", () => t.innerType._zod.optin), j(e._zod, "optout", () => t.innerType._zod.optout), j(e._zod, "pattern", () => {
    let n = t.innerType._zod.pattern;
    return n ? new RegExp(`^(${xr(n.source)}|null)$`) : void 0;
  }), j(e._zod, "values", () => t.innerType._zod.values ? /* @__PURE__ */ new Set([...t.innerType._zod.values, null]) : void 0), e._zod.parse = (n, i) => n.value === null ? n : t.innerType._zod.run(n, i);
}), le = /* @__PURE__ */ f("$ZodDefault", (e, t) => {
  k.init(e, t), e._zod.optin = "optional", j(e._zod, "values", () => t.innerType._zod.values), e._zod.parse = (n, i) => {
    if (i.direction === "backward")
      return t.innerType._zod.run(n, i);
    if (n.value === void 0)
      return n.value = t.defaultValue, n;
    let r = t.innerType._zod.run(n, i);
    return r instanceof Promise ? r.then((o) => Qf(o, t)) : Qf(r, t);
  };
});
function Qf(e, t) {
  return e.value === void 0 && (e.value = t.defaultValue), e;
}
s(Qf, "handleDefaultResult");
var Ks = /* @__PURE__ */ f("$ZodPrefault", (e, t) => {
  k.init(e, t), e._zod.optin = "optional", j(e._zod, "values", () => t.innerType._zod.values), e._zod.parse = (n, i) => (i.direction === "backward" || n.value === void 0 && (n.value = t.defaultValue), t.innerType._zod.run(n, i));
}), Gs = /* @__PURE__ */ f("$ZodNonOptional", (e, t) => {
  k.init(e, t), j(e._zod, "values", () => {
    let n = t.innerType._zod.values;
    return n ? new Set([...n].filter((i) => i !== void 0)) : void 0;
  }), e._zod.parse = (n, i) => {
    let r = t.innerType._zod.run(n, i);
    return r instanceof Promise ? r.then((o) => Hf(o, e)) : Hf(r, e);
  };
});
function Hf(e, t) {
  return !e.issues.length && e.value === void 0 && e.issues.push({
    code: "invalid_type",
    expected: "nonoptional",
    input: e.value,
    inst: t
  }), e;
}
s(Hf, "handleNonOptionalResult");
var Xs = /* @__PURE__ */ f("$ZodSuccess", (e, t) => {
  k.init(e, t), e._zod.parse = (n, i) => {
    if (i.direction === "backward")
      throw new Ne("ZodSuccess");
    let r = t.innerType._zod.run(n, i);
    return r instanceof Promise ? r.then((o) => (n.value = o.issues.length === 0, n)) : (n.value = r.issues.length === 0, n);
  };
}), Qs = /* @__PURE__ */ f("$ZodCatch", (e, t) => {
  k.init(e, t), e._zod.optin = "optional", j(e._zod, "optout", () => t.innerType._zod.optout), j(e._zod, "values", () => t.innerType._zod.values), e._zod.parse = (n, i) => {
    if (i.direction === "backward")
      return t.innerType._zod.run(n, i);
    let r = t.innerType._zod.run(n, i);
    return r instanceof Promise ? r.then((o) => (n.value = o.value, o.issues.length && (n.value = t.catchValue({
      ...n,
      error: {
        issues: o.issues.map((a) => te(a, i, q()))
      },
      input: n.value
    }), n.issues = [], n.fallback = !0), n)) : (n.value = r.value, r.issues.length && (n.value = t.catchValue({
      ...n,
      error: {
        issues: r.issues.map((o) => te(o, i, q()))
      },
      input: n.value
    }), n.issues = [], n.fallback = !0), n);
  };
}), Hs = /* @__PURE__ */ f("$ZodNaN", (e, t) => {
  k.init(e, t), e._zod.parse = (n, i) => ((typeof n.value != "number" || !Number.isNaN(n.value)) && n.issues.push({
    input: n.value,
    inst: e,
    expected: "nan",
    code: "invalid_type"
  }), n);
}), Kn = /* @__PURE__ */ f("$ZodPipe", (e, t) => {
  k.init(e, t), j(e._zod, "values", () => t.in._zod.values), j(e._zod, "optin", () => t.in._zod.optin), j(e._zod, "optout", () => t.out._zod.optout), j(e._zod, "propValues", () => t.in._zod.propValues), e._zod.parse = (n, i) => {
    if (i.direction === "backward") {
      let o = t.out._zod.run(n, i);
      return o instanceof Promise ? o.then((a) => Mn(a, t.in, i)) : Mn(o, t.in, i);
    }
    let r = t.in._zod.run(n, i);
    return r instanceof Promise ? r.then((o) => Mn(o, t.out, i)) : Mn(r, t.out, i);
  };
});
function Mn(e, t, n) {
  return e.issues.length ? (e.aborted = !0, e) : t._zod.run({ value: e.value, issues: e.issues, fallback: e.fallback }, n);
}
s(Mn, "handlePipeResult");
var $e = /* @__PURE__ */ f("$ZodCodec", (e, t) => {
  k.init(e, t), j(e._zod, "values", () => t.in._zod.values), j(e._zod, "optin", () => t.in._zod.optin), j(e._zod, "optout", () => t.out._zod.optout), j(e._zod, "propValues", () => t.in._zod.propValues), e._zod.parse = (n, i) => {
    if ((i.direction || "forward") === "forward") {
      let o = t.in._zod.run(n, i);
      return o instanceof Promise ? o.then((a) => Bn(a, t, i)) : Bn(o, t, i);
    } else {
      let o = t.out._zod.run(n, i);
      return o instanceof Promise ? o.then((a) => Bn(a, t, i)) : Bn(o, t, i);
    }
  };
});
function Bn(e, t, n) {
  if (e.issues.length)
    return e.aborted = !0, e;
  if ((n.direction || "forward") === "forward") {
    let r = t.transform(e.value, e);
    return r instanceof Promise ? r.then((o) => Jn(e, o, t.out, n)) : Jn(e, r, t.out, n);
  } else {
    let r = t.reverseTransform(e.value, e);
    return r instanceof Promise ? r.then((o) => Jn(e, o, t.in, n)) : Jn(e, r, t.in, n);
  }
}
s(Bn, "handleCodecAResult");
function Jn(e, t, n, i) {
  return e.issues.length ? (e.aborted = !0, e) : n._zod.run({ value: t, issues: e.issues }, i);
}
s(Jn, "handleCodecTxResult");
var Ys = /* @__PURE__ */ f("$ZodPreprocess", (e, t) => {
  Kn.init(e, t);
}), ec = /* @__PURE__ */ f("$ZodReadonly", (e, t) => {
  k.init(e, t), j(e._zod, "propValues", () => t.innerType._zod.propValues), j(e._zod, "values", () => t.innerType._zod.values), j(e._zod, "optin", () => t.innerType?._zod?.optin), j(e._zod, "optout", () => t.innerType?._zod?.optout), e._zod.parse = (n, i) => {
    if (i.direction === "backward")
      return t.innerType._zod.run(n, i);
    let r = t.innerType._zod.run(n, i);
    return r instanceof Promise ? r.then(Yf) : Yf(r);
  };
});
function Yf(e) {
  return e.value = Object.freeze(e.value), e;
}
s(Yf, "handleReadonlyResult");
var tc = /* @__PURE__ */ f("$ZodTemplateLiteral", (e, t) => {
  k.init(e, t);
  let n = [];
  for (let i of t.parts)
    if (typeof i == "object" && i !== null) {
      if (!i._zod.pattern)
        throw new Error(`Invalid template literal part, no pattern found: ${[...i._zod.traits].shift()}`);
      let r = i._zod.pattern instanceof RegExp ? i._zod.pattern.source : i._zod.pattern;
      if (!r)
        throw new Error(`Invalid template literal part: ${i._zod.traits}`);
      let o = r.startsWith("^") ? 1 : 0, a = r.endsWith("$") ? r.length - 1 : r.length;
      n.push(r.slice(o, a));
    } else if (i === null || ra.has(typeof i))
      n.push(me(`${i}`));
    else
      throw new Error(`Invalid template literal part: ${i}`);
  e._zod.pattern = new RegExp(`^${n.join("")}$`), e._zod.parse = (i, r) => typeof i.value != "string" ? (i.issues.push({
    input: i.value,
    inst: e,
    expected: "string",
    code: "invalid_type"
  }), i) : (e._zod.pattern.lastIndex = 0, e._zod.pattern.test(i.value) || i.issues.push({
    input: i.value,
    inst: e,
    code: "invalid_format",
    format: t.format ?? "template_literal",
    pattern: e._zod.pattern.source
  }), i);
}), rc = /* @__PURE__ */ f("$ZodFunction", (e, t) => (k.init(e, t), e._def = t, e._zod.def = t, e.implement = (n) => {
  if (typeof n != "function")
    throw new Error("implement() must be called with a function");
  return function(...i) {
    let r = e._def.input ? Fe(e._def.input, i) : i, o = Reflect.apply(n, this, r);
    return e._def.output ? Fe(e._def.output, o) : o;
  };
}, e.implementAsync = (n) => {
  if (typeof n != "function")
    throw new Error("implementAsync() must be called with a function");
  return async function(...i) {
    let r = e._def.input ? await On(e._def.input, i) : i, o = await Reflect.apply(n, this, r);
    return e._def.output ? await On(e._def.output, o) : o;
  };
}, e._zod.parse = (n, i) => typeof n.value != "function" ? (n.issues.push({
  code: "invalid_type",
  expected: "function",
  input: n.value,
  inst: e
}), n) : (e._def.output && e._def.output._zod.def.type === "promise" ? n.value = e.implementAsync(n.value) : n.value = e.implement(n.value), n), e.input = (...n) => {
  let i = e.constructor;
  return Array.isArray(n[0]) ? new i({
    type: "function",
    input: new Be({
      type: "tuple",
      items: n[0],
      rest: n[1]
    }),
    output: e._def.output
  }) : new i({
    type: "function",
    input: n[0],
    output: e._def.output
  });
}, e.output = (n) => {
  let i = e.constructor;
  return new i({
    type: "function",
    input: e._def.input,
    output: n
  });
}, e)), nc = /* @__PURE__ */ f("$ZodPromise", (e, t) => {
  k.init(e, t), e._zod.parse = (n, i) => Promise.resolve(n.value).then((r) => t.innerType._zod.run({ value: r, issues: [] }, i));
}), At = /* @__PURE__ */ f("$ZodLazy", (e, t) => {
  k.init(e, t), j(e._zod, "innerType", () => {
    let n = t;
    return n._cachedInner || (n._cachedInner = t.getter()), n._cachedInner;
  }), j(e._zod, "pattern", () => e._zod.innerType?._zod?.pattern), j(e._zod, "propValues", () => e._zod.innerType?._zod?.propValues), j(e._zod, "optin", () => e._zod.innerType?._zod?.optin ?? void 0), j(e._zod, "optout", () => e._zod.innerType?._zod?.optout ?? void 0), e._zod.parse = (n, i) => e._zod.innerType._zod.run(n, i);
}), Tr = /* @__PURE__ */ f("$ZodCustom", (e, t) => {
  R.init(e, t), k.init(e, t), e._zod.parse = (n, i) => n, e._zod.check = (n) => {
    let i = n.value, r = t.fn(i);
    if (r instanceof Promise)
      return r.then((o) => ep(o, n, i, e));
    ep(r, n, i, e);
  };
});
function ep(e, t, n, i) {
  if (!e) {
    let r = {
      code: "custom",
      input: n,
      inst: i,
      // incorporates params.error into issue reporting
      path: [...i._zod.def.path ?? []],
      // incorporates params.error into issue reporting
      continue: !i._zod.def.abort
      // params: inst._zod.def.params,
    };
    i._zod.def.params && (r.params = i._zod.def.params), t.issues.push(jt(r));
  }
}
s(ep, "handleRefineResult");

// versions/4.4.3/node_modules/zod/v4/locales/index.js
var Zr = {};
Pe(Zr, {
  ar: () => ic,
  az: () => oc,
  be: () => ac,
  bg: () => sc,
  ca: () => cc,
  cs: () => uc,
  da: () => lc,
  de: () => dc,
  el: () => fc,
  en: () => Er,
  eo: () => pc,
  es: () => mc,
  fa: () => gc,
  fi: () => hc,
  fr: () => vc,
  frCA: () => yc,
  he: () => bc,
  hr: () => $c,
  hu: () => xc,
  hy: () => _c,
  id: () => wc,
  is: () => kc,
  it: () => zc,
  ja: () => Ic,
  ka: () => Sc,
  kh: () => jc,
  km: () => Ur,
  ko: () => Oc,
  lt: () => Pc,
  mk: () => Tc,
  ms: () => Ec,
  nl: () => Uc,
  no: () => Dc,
  ota: () => Nc,
  pl: () => Ac,
  ps: () => Zc,
  pt: () => Cc,
  ro: () => Rc,
  ru: () => Fc,
  sl: () => Lc,
  sv: () => Mc,
  ta: () => Bc,
  th: () => Jc,
  tr: () => Vc,
  ua: () => qc,
  uk: () => Nr,
  ur: () => Wc,
  uz: () => Kc,
  vi: () => Gc,
  yo: () => Hc,
  zhCN: () => Xc,
  zhTW: () => Qc
});

// versions/4.4.3/node_modules/zod/v4/locales/ar.js
var Cv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u062D\u0631\u0641", verb: "\u0623\u0646 \u064A\u062D\u0648\u064A" },
    file: { unit: "\u0628\u0627\u064A\u062A", verb: "\u0623\u0646 \u064A\u062D\u0648\u064A" },
    array: { unit: "\u0639\u0646\u0635\u0631", verb: "\u0623\u0646 \u064A\u062D\u0648\u064A" },
    set: { unit: "\u0639\u0646\u0635\u0631", verb: "\u0623\u0646 \u064A\u062D\u0648\u064A" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u0645\u062F\u062E\u0644",
    email: "\u0628\u0631\u064A\u062F \u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A",
    url: "\u0631\u0627\u0628\u0637",
    emoji: "\u0625\u064A\u0645\u0648\u062C\u064A",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u062A\u0627\u0631\u064A\u062E \u0648\u0648\u0642\u062A \u0628\u0645\u0639\u064A\u0627\u0631 ISO",
    date: "\u062A\u0627\u0631\u064A\u062E \u0628\u0645\u0639\u064A\u0627\u0631 ISO",
    time: "\u0648\u0642\u062A \u0628\u0645\u0639\u064A\u0627\u0631 ISO",
    duration: "\u0645\u062F\u0629 \u0628\u0645\u0639\u064A\u0627\u0631 ISO",
    ipv4: "\u0639\u0646\u0648\u0627\u0646 IPv4",
    ipv6: "\u0639\u0646\u0648\u0627\u0646 IPv6",
    cidrv4: "\u0645\u062F\u0649 \u0639\u0646\u0627\u0648\u064A\u0646 \u0628\u0635\u064A\u063A\u0629 IPv4",
    cidrv6: "\u0645\u062F\u0649 \u0639\u0646\u0627\u0648\u064A\u0646 \u0628\u0635\u064A\u063A\u0629 IPv6",
    base64: "\u0646\u064E\u0635 \u0628\u062A\u0631\u0645\u064A\u0632 base64-encoded",
    base64url: "\u0646\u064E\u0635 \u0628\u062A\u0631\u0645\u064A\u0632 base64url-encoded",
    json_string: "\u0646\u064E\u0635 \u0639\u0644\u0649 \u0647\u064A\u0626\u0629 JSON",
    e164: "\u0631\u0642\u0645 \u0647\u0627\u062A\u0641 \u0628\u0645\u0639\u064A\u0627\u0631 E.164",
    jwt: "JWT",
    template_literal: "\u0645\u062F\u062E\u0644"
  }, i = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u0645\u062F\u062E\u0644\u0627\u062A \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644\u0629: \u064A\u0641\u062A\u0631\u0636 \u0625\u062F\u062E\u0627\u0644 instanceof ${r.expected}\u060C \u0648\u0644\u0643\u0646 \u062A\u0645 \u0625\u062F\u062E\u0627\u0644 ${c}` : `\u0645\u062F\u062E\u0644\u0627\u062A \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644\u0629: \u064A\u0641\u062A\u0631\u0636 \u0625\u062F\u062E\u0627\u0644 ${o}\u060C \u0648\u0644\u0643\u0646 \u062A\u0645 \u0625\u062F\u062E\u0627\u0644 ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u0645\u062F\u062E\u0644\u0627\u062A \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644\u0629: \u064A\u0641\u062A\u0631\u0636 \u0625\u062F\u062E\u0627\u0644 ${v(r.values[0])}` : `\u0627\u062E\u062A\u064A\u0627\u0631 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062A\u0648\u0642\u0639 \u0627\u0646\u062A\u0642\u0627\u0621 \u0623\u062D\u062F \u0647\u0630\u0647 \u0627\u0644\u062E\u064A\u0627\u0631\u0627\u062A: ${p(r.values, "|")}`;
      case "too_big": {
        let o = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? ` \u0623\u0643\u0628\u0631 \u0645\u0646 \u0627\u0644\u0644\u0627\u0632\u0645: \u064A\u0641\u062A\u0631\u0636 \u0623\u0646 \u062A\u0643\u0648\u0646 ${r.origin ?? "\u0627\u0644\u0642\u064A\u0645\u0629"} ${o} ${r.maximum.toString()} ${a.unit ?? "\u0639\u0646\u0635\u0631"}` : `\u0623\u0643\u0628\u0631 \u0645\u0646 \u0627\u0644\u0644\u0627\u0632\u0645: \u064A\u0641\u062A\u0631\u0636 \u0623\u0646 \u062A\u0643\u0648\u0646 ${r.origin ?? "\u0627\u0644\u0642\u064A\u0645\u0629"} ${o} ${r.maximum.toString()}`;
      }
      case "too_small": {
        let o = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\u0623\u0635\u063A\u0631 \u0645\u0646 \u0627\u0644\u0644\u0627\u0632\u0645: \u064A\u0641\u062A\u0631\u0636 \u0644\u0640 ${r.origin} \u0623\u0646 \u064A\u0643\u0648\u0646 ${o} ${r.minimum.toString()} ${a.unit}` : `\u0623\u0635\u063A\u0631 \u0645\u0646 \u0627\u0644\u0644\u0627\u0632\u0645: \u064A\u0641\u062A\u0631\u0636 \u0644\u0640 ${r.origin} \u0623\u0646 \u064A\u0643\u0648\u0646 ${o} ${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `\u0646\u064E\u0635 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u0628\u062F\u0623 \u0628\u0640 "${r.prefix}"` : o.format === "ends_with" ? `\u0646\u064E\u0635 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u0646\u062A\u0647\u064A \u0628\u0640 "${o.suffix}"` : o.format === "includes" ? `\u0646\u064E\u0635 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u062A\u0636\u0645\u0651\u064E\u0646 "${o.includes}"` : o.format === "regex" ? `\u0646\u064E\u0635 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u0637\u0627\u0628\u0642 \u0627\u0644\u0646\u0645\u0637 ${o.pattern}` : `${n[o.format] ?? r.format} \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644`;
      }
      case "not_multiple_of":
        return `\u0631\u0642\u0645 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u0643\u0648\u0646 \u0645\u0646 \u0645\u0636\u0627\u0639\u0641\u0627\u062A ${r.divisor}`;
      case "unrecognized_keys":
        return `\u0645\u0639\u0631\u0641${r.keys.length > 1 ? "\u0627\u062A" : ""} \u063A\u0631\u064A\u0628${r.keys.length > 1 ? "\u0629" : ""}: ${p(r.keys, "\u060C ")}`;
      case "invalid_key":
        return `\u0645\u0639\u0631\u0641 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644 \u0641\u064A ${r.origin}`;
      case "invalid_union":
        return "\u0645\u062F\u062E\u0644 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644";
      case "invalid_element":
        return `\u0645\u062F\u062E\u0644 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644 \u0641\u064A ${r.origin}`;
      default:
        return "\u0645\u062F\u062E\u0644 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644";
    }
  };
}, "error");
function ic() {
  return {
    localeError: Cv()
  };
}
s(ic, "default");

// versions/4.4.3/node_modules/zod/v4/locales/az.js
var Rv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "simvol", verb: "olmal\u0131d\u0131r" },
    file: { unit: "bayt", verb: "olmal\u0131d\u0131r" },
    array: { unit: "element", verb: "olmal\u0131d\u0131r" },
    set: { unit: "element", verb: "olmal\u0131d\u0131r" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "input",
    email: "email address",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datetime",
    date: "ISO date",
    time: "ISO time",
    duration: "ISO duration",
    ipv4: "IPv4 address",
    ipv6: "IPv6 address",
    cidrv4: "IPv4 range",
    cidrv6: "IPv6 range",
    base64: "base64-encoded string",
    base64url: "base64url-encoded string",
    json_string: "JSON string",
    e164: "E.164 number",
    jwt: "JWT",
    template_literal: "input"
  }, i = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Yanl\u0131\u015F d\u0259y\u0259r: g\xF6zl\u0259nil\u0259n instanceof ${r.expected}, daxil olan ${c}` : `Yanl\u0131\u015F d\u0259y\u0259r: g\xF6zl\u0259nil\u0259n ${o}, daxil olan ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Yanl\u0131\u015F d\u0259y\u0259r: g\xF6zl\u0259nil\u0259n ${v(r.values[0])}` : `Yanl\u0131\u015F se\xE7im: a\u015Fa\u011F\u0131dak\u0131lardan biri olmal\u0131d\u0131r: ${p(r.values, "|")}`;
      case "too_big": {
        let o = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `\xC7ox b\xF6y\xFCk: g\xF6zl\u0259nil\u0259n ${r.origin ?? "d\u0259y\u0259r"} ${o}${r.maximum.toString()} ${a.unit ?? "element"}` : `\xC7ox b\xF6y\xFCk: g\xF6zl\u0259nil\u0259n ${r.origin ?? "d\u0259y\u0259r"} ${o}${r.maximum.toString()}`;
      }
      case "too_small": {
        let o = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\xC7ox ki\xE7ik: g\xF6zl\u0259nil\u0259n ${r.origin} ${o}${r.minimum.toString()} ${a.unit}` : `\xC7ox ki\xE7ik: g\xF6zl\u0259nil\u0259n ${r.origin} ${o}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `Yanl\u0131\u015F m\u0259tn: "${o.prefix}" il\u0259 ba\u015Flamal\u0131d\u0131r` : o.format === "ends_with" ? `Yanl\u0131\u015F m\u0259tn: "${o.suffix}" il\u0259 bitm\u0259lidir` : o.format === "includes" ? `Yanl\u0131\u015F m\u0259tn: "${o.includes}" daxil olmal\u0131d\u0131r` : o.format === "regex" ? `Yanl\u0131\u015F m\u0259tn: ${o.pattern} \u015Fablonuna uy\u011Fun olmal\u0131d\u0131r` : `Yanl\u0131\u015F ${n[o.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Yanl\u0131\u015F \u0259d\u0259d: ${r.divisor} il\u0259 b\xF6l\xFCn\u0259 bil\u0259n olmal\u0131d\u0131r`;
      case "unrecognized_keys":
        return `Tan\u0131nmayan a\xE7ar${r.keys.length > 1 ? "lar" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `${r.origin} daxilind\u0259 yanl\u0131\u015F a\xE7ar`;
      case "invalid_union":
        return "Yanl\u0131\u015F d\u0259y\u0259r";
      case "invalid_element":
        return `${r.origin} daxilind\u0259 yanl\u0131\u015F d\u0259y\u0259r`;
      default:
        return "Yanl\u0131\u015F d\u0259y\u0259r";
    }
  };
}, "error");
function oc() {
  return {
    localeError: Rv()
  };
}
s(oc, "default");

// versions/4.4.3/node_modules/zod/v4/locales/be.js
function op(e, t, n, i) {
  let r = Math.abs(e), o = r % 10, a = r % 100;
  return a >= 11 && a <= 19 ? i : o === 1 ? t : o >= 2 && o <= 4 ? n : i;
}
s(op, "getBelarusianPlural");
var Fv = /* @__PURE__ */ s(() => {
  let e = {
    string: {
      unit: {
        one: "\u0441\u0456\u043C\u0432\u0430\u043B",
        few: "\u0441\u0456\u043C\u0432\u0430\u043B\u044B",
        many: "\u0441\u0456\u043C\u0432\u0430\u043B\u0430\u045E"
      },
      verb: "\u043C\u0435\u0446\u044C"
    },
    array: {
      unit: {
        one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
        few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u044B",
        many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430\u045E"
      },
      verb: "\u043C\u0435\u0446\u044C"
    },
    set: {
      unit: {
        one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
        few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u044B",
        many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430\u045E"
      },
      verb: "\u043C\u0435\u0446\u044C"
    },
    file: {
      unit: {
        one: "\u0431\u0430\u0439\u0442",
        few: "\u0431\u0430\u0439\u0442\u044B",
        many: "\u0431\u0430\u0439\u0442\u0430\u045E"
      },
      verb: "\u043C\u0435\u0446\u044C"
    }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u0443\u0432\u043E\u0434",
    email: "email \u0430\u0434\u0440\u0430\u0441",
    url: "URL",
    emoji: "\u044D\u043C\u043E\u0434\u0437\u0456",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0434\u0430\u0442\u0430 \u0456 \u0447\u0430\u0441",
    date: "ISO \u0434\u0430\u0442\u0430",
    time: "ISO \u0447\u0430\u0441",
    duration: "ISO \u043F\u0440\u0430\u0446\u044F\u0433\u043B\u0430\u0441\u0446\u044C",
    ipv4: "IPv4 \u0430\u0434\u0440\u0430\u0441",
    ipv6: "IPv6 \u0430\u0434\u0440\u0430\u0441",
    cidrv4: "IPv4 \u0434\u044B\u044F\u043F\u0430\u0437\u043E\u043D",
    cidrv6: "IPv6 \u0434\u044B\u044F\u043F\u0430\u0437\u043E\u043D",
    base64: "\u0440\u0430\u0434\u043E\u043A \u0443 \u0444\u0430\u0440\u043C\u0430\u0446\u0435 base64",
    base64url: "\u0440\u0430\u0434\u043E\u043A \u0443 \u0444\u0430\u0440\u043C\u0430\u0446\u0435 base64url",
    json_string: "JSON \u0440\u0430\u0434\u043E\u043A",
    e164: "\u043D\u0443\u043C\u0430\u0440 E.164",
    jwt: "JWT",
    template_literal: "\u0443\u0432\u043E\u0434"
  }, i = {
    nan: "NaN",
    number: "\u043B\u0456\u043A",
    array: "\u043C\u0430\u0441\u0456\u045E"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434: \u0447\u0430\u043A\u0430\u045E\u0441\u044F instanceof ${r.expected}, \u0430\u0442\u0440\u044B\u043C\u0430\u043D\u0430 ${c}` : `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434: \u0447\u0430\u043A\u0430\u045E\u0441\u044F ${o}, \u0430\u0442\u0440\u044B\u043C\u0430\u043D\u0430 ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F ${v(r.values[0])}` : `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0432\u0430\u0440\u044B\u044F\u043D\u0442: \u0447\u0430\u043A\u0430\u045E\u0441\u044F \u0430\u0434\u0437\u0456\u043D \u0437 ${p(r.values, "|")}`;
      case "too_big": {
        let o = r.inclusive ? "<=" : "<", a = t(r.origin);
        if (a) {
          let c = Number(r.maximum), u = op(c, a.unit.one, a.unit.few, a.unit.many);
          return `\u0417\u0430\u043D\u0430\u0434\u0442\u0430 \u0432\u044F\u043B\u0456\u043A\u0456: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F, \u0448\u0442\u043E ${r.origin ?? "\u0437\u043D\u0430\u0447\u044D\u043D\u043D\u0435"} \u043F\u0430\u0432\u0456\u043D\u043D\u0430 ${a.verb} ${o}${r.maximum.toString()} ${u}`;
        }
        return `\u0417\u0430\u043D\u0430\u0434\u0442\u0430 \u0432\u044F\u043B\u0456\u043A\u0456: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F, \u0448\u0442\u043E ${r.origin ?? "\u0437\u043D\u0430\u0447\u044D\u043D\u043D\u0435"} \u043F\u0430\u0432\u0456\u043D\u043D\u0430 \u0431\u044B\u0446\u044C ${o}${r.maximum.toString()}`;
      }
      case "too_small": {
        let o = r.inclusive ? ">=" : ">", a = t(r.origin);
        if (a) {
          let c = Number(r.minimum), u = op(c, a.unit.one, a.unit.few, a.unit.many);
          return `\u0417\u0430\u043D\u0430\u0434\u0442\u0430 \u043C\u0430\u043B\u044B: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F, \u0448\u0442\u043E ${r.origin} \u043F\u0430\u0432\u0456\u043D\u043D\u0430 ${a.verb} ${o}${r.minimum.toString()} ${u}`;
        }
        return `\u0417\u0430\u043D\u0430\u0434\u0442\u0430 \u043C\u0430\u043B\u044B: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F, \u0448\u0442\u043E ${r.origin} \u043F\u0430\u0432\u0456\u043D\u043D\u0430 \u0431\u044B\u0446\u044C ${o}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0440\u0430\u0434\u043E\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u043F\u0430\u0447\u044B\u043D\u0430\u0446\u0446\u0430 \u0437 "${o.prefix}"` : o.format === "ends_with" ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0440\u0430\u0434\u043E\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u0437\u0430\u043A\u0430\u043D\u0447\u0432\u0430\u0446\u0446\u0430 \u043D\u0430 "${o.suffix}"` : o.format === "includes" ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0440\u0430\u0434\u043E\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u0437\u043C\u044F\u0448\u0447\u0430\u0446\u044C "${o.includes}"` : o.format === "regex" ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0440\u0430\u0434\u043E\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u0430\u0434\u043F\u0430\u0432\u044F\u0434\u0430\u0446\u044C \u0448\u0430\u0431\u043B\u043E\u043D\u0443 ${o.pattern}` : `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B ${n[o.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u043B\u0456\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u0431\u044B\u0446\u044C \u043A\u0440\u0430\u0442\u043D\u044B\u043C ${r.divisor}`;
      case "unrecognized_keys":
        return `\u041D\u0435\u0440\u0430\u0441\u043F\u0430\u0437\u043D\u0430\u043D\u044B ${r.keys.length > 1 ? "\u043A\u043B\u044E\u0447\u044B" : "\u043A\u043B\u044E\u0447"}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u043A\u043B\u044E\u0447 \u0443 ${r.origin}`;
      case "invalid_union":
        return "\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434";
      case "invalid_element":
        return `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u0430\u0435 \u0437\u043D\u0430\u0447\u044D\u043D\u043D\u0435 \u045E ${r.origin}`;
      default:
        return "\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434";
    }
  };
}, "error");
function ac() {
  return {
    localeError: Fv()
  };
}
s(ac, "default");

// versions/4.4.3/node_modules/zod/v4/locales/bg.js
var Lv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0441\u0438\u043C\u0432\u043E\u043B\u0430", verb: "\u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430" },
    file: { unit: "\u0431\u0430\u0439\u0442\u0430", verb: "\u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430" },
    array: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0430", verb: "\u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430" },
    set: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0430", verb: "\u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u0432\u0445\u043E\u0434",
    email: "\u0438\u043C\u0435\u0439\u043B \u0430\u0434\u0440\u0435\u0441",
    url: "URL",
    emoji: "\u0435\u043C\u043E\u0434\u0436\u0438",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0432\u0440\u0435\u043C\u0435",
    date: "ISO \u0434\u0430\u0442\u0430",
    time: "ISO \u0432\u0440\u0435\u043C\u0435",
    duration: "ISO \u043F\u0440\u043E\u0434\u044A\u043B\u0436\u0438\u0442\u0435\u043B\u043D\u043E\u0441\u0442",
    ipv4: "IPv4 \u0430\u0434\u0440\u0435\u0441",
    ipv6: "IPv6 \u0430\u0434\u0440\u0435\u0441",
    cidrv4: "IPv4 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D",
    cidrv6: "IPv6 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D",
    base64: "base64-\u043A\u043E\u0434\u0438\u0440\u0430\u043D \u043D\u0438\u0437",
    base64url: "base64url-\u043A\u043E\u0434\u0438\u0440\u0430\u043D \u043D\u0438\u0437",
    json_string: "JSON \u043D\u0438\u0437",
    e164: "E.164 \u043D\u043E\u043C\u0435\u0440",
    jwt: "JWT",
    template_literal: "\u0432\u0445\u043E\u0434"
  }, i = {
    nan: "NaN",
    number: "\u0447\u0438\u0441\u043B\u043E",
    array: "\u043C\u0430\u0441\u0438\u0432"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434: \u043E\u0447\u0430\u043A\u0432\u0430\u043D instanceof ${r.expected}, \u043F\u043E\u043B\u0443\u0447\u0435\u043D ${c}` : `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434: \u043E\u0447\u0430\u043A\u0432\u0430\u043D ${o}, \u043F\u043E\u043B\u0443\u0447\u0435\u043D ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434: \u043E\u0447\u0430\u043A\u0432\u0430\u043D ${v(r.values[0])}` : `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u0430 \u043E\u043F\u0446\u0438\u044F: \u043E\u0447\u0430\u043A\u0432\u0430\u043D\u043E \u0435\u0434\u043D\u043E \u043E\u0442 ${p(r.values, "|")}`;
      case "too_big": {
        let o = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `\u0422\u0432\u044A\u0440\u0434\u0435 \u0433\u043E\u043B\u044F\u043C\u043E: \u043E\u0447\u0430\u043A\u0432\u0430 \u0441\u0435 ${r.origin ?? "\u0441\u0442\u043E\u0439\u043D\u043E\u0441\u0442"} \u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430 ${o}${r.maximum.toString()} ${a.unit ?? "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0430"}` : `\u0422\u0432\u044A\u0440\u0434\u0435 \u0433\u043E\u043B\u044F\u043C\u043E: \u043E\u0447\u0430\u043A\u0432\u0430 \u0441\u0435 ${r.origin ?? "\u0441\u0442\u043E\u0439\u043D\u043E\u0441\u0442"} \u0434\u0430 \u0431\u044A\u0434\u0435 ${o}${r.maximum.toString()}`;
      }
      case "too_small": {
        let o = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\u0422\u0432\u044A\u0440\u0434\u0435 \u043C\u0430\u043B\u043A\u043E: \u043E\u0447\u0430\u043A\u0432\u0430 \u0441\u0435 ${r.origin} \u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430 ${o}${r.minimum.toString()} ${a.unit}` : `\u0422\u0432\u044A\u0440\u0434\u0435 \u043C\u0430\u043B\u043A\u043E: \u043E\u0447\u0430\u043A\u0432\u0430 \u0441\u0435 ${r.origin} \u0434\u0430 \u0431\u044A\u0434\u0435 ${o}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let o = r;
        if (o.format === "starts_with")
          return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043D\u0438\u0437: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0437\u0430\u043F\u043E\u0447\u0432\u0430 \u0441 "${o.prefix}"`;
        if (o.format === "ends_with")
          return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043D\u0438\u0437: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0437\u0430\u0432\u044A\u0440\u0448\u0432\u0430 \u0441 "${o.suffix}"`;
        if (o.format === "includes")
          return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043D\u0438\u0437: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0432\u043A\u043B\u044E\u0447\u0432\u0430 "${o.includes}"`;
        if (o.format === "regex")
          return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043D\u0438\u0437: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0441\u044A\u0432\u043F\u0430\u0434\u0430 \u0441 ${o.pattern}`;
        let a = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D";
        return o.format === "emoji" && (a = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u043E"), o.format === "datetime" && (a = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u043E"), o.format === "date" && (a = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u0430"), o.format === "time" && (a = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u043E"), o.format === "duration" && (a = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u0430"), `${a} ${n[o.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u043E \u0447\u0438\u0441\u043B\u043E: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0431\u044A\u0434\u0435 \u043A\u0440\u0430\u0442\u043D\u043E \u043D\u0430 ${r.divisor}`;
      case "unrecognized_keys":
        return `\u041D\u0435\u0440\u0430\u0437\u043F\u043E\u0437\u043D\u0430\u0442${r.keys.length > 1 ? "\u0438" : ""} \u043A\u043B\u044E\u0447${r.keys.length > 1 ? "\u043E\u0432\u0435" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043A\u043B\u044E\u0447 \u0432 ${r.origin}`;
      case "invalid_union":
        return "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434";
      case "invalid_element":
        return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u0430 \u0441\u0442\u043E\u0439\u043D\u043E\u0441\u0442 \u0432 ${r.origin}`;
      default:
        return "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434";
    }
  };
}, "error");
function sc() {
  return {
    localeError: Lv()
  };
}
s(sc, "default");

// versions/4.4.3/node_modules/zod/v4/locales/ca.js
var Mv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "car\xE0cters", verb: "contenir" },
    file: { unit: "bytes", verb: "contenir" },
    array: { unit: "elements", verb: "contenir" },
    set: { unit: "elements", verb: "contenir" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "entrada",
    email: "adre\xE7a electr\xF2nica",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "data i hora ISO",
    date: "data ISO",
    time: "hora ISO",
    duration: "durada ISO",
    ipv4: "adre\xE7a IPv4",
    ipv6: "adre\xE7a IPv6",
    cidrv4: "rang IPv4",
    cidrv6: "rang IPv6",
    base64: "cadena codificada en base64",
    base64url: "cadena codificada en base64url",
    json_string: "cadena JSON",
    e164: "n\xFAmero E.164",
    jwt: "JWT",
    template_literal: "entrada"
  }, i = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Tipus inv\xE0lid: s'esperava instanceof ${r.expected}, s'ha rebut ${c}` : `Tipus inv\xE0lid: s'esperava ${o}, s'ha rebut ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Valor inv\xE0lid: s'esperava ${v(r.values[0])}` : `Opci\xF3 inv\xE0lida: s'esperava una de ${p(r.values, " o ")}`;
      case "too_big": {
        let o = r.inclusive ? "com a m\xE0xim" : "menys de", a = t(r.origin);
        return a ? `Massa gran: s'esperava que ${r.origin ?? "el valor"} contingu\xE9s ${o} ${r.maximum.toString()} ${a.unit ?? "elements"}` : `Massa gran: s'esperava que ${r.origin ?? "el valor"} fos ${o} ${r.maximum.toString()}`;
      }
      case "too_small": {
        let o = r.inclusive ? "com a m\xEDnim" : "m\xE9s de", a = t(r.origin);
        return a ? `Massa petit: s'esperava que ${r.origin} contingu\xE9s ${o} ${r.minimum.toString()} ${a.unit}` : `Massa petit: s'esperava que ${r.origin} fos ${o} ${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `Format inv\xE0lid: ha de comen\xE7ar amb "${o.prefix}"` : o.format === "ends_with" ? `Format inv\xE0lid: ha d'acabar amb "${o.suffix}"` : o.format === "includes" ? `Format inv\xE0lid: ha d'incloure "${o.includes}"` : o.format === "regex" ? `Format inv\xE0lid: ha de coincidir amb el patr\xF3 ${o.pattern}` : `Format inv\xE0lid per a ${n[o.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `N\xFAmero inv\xE0lid: ha de ser m\xFAltiple de ${r.divisor}`;
      case "unrecognized_keys":
        return `Clau${r.keys.length > 1 ? "s" : ""} no reconeguda${r.keys.length > 1 ? "s" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Clau inv\xE0lida a ${r.origin}`;
      case "invalid_union":
        return "Entrada inv\xE0lida";
      // Could also be "Tipus d'unió invàlid" but "Entrada invàlida" is more general
      case "invalid_element":
        return `Element inv\xE0lid a ${r.origin}`;
      default:
        return "Entrada inv\xE0lida";
    }
  };
}, "error");
function cc() {
  return {
    localeError: Mv()
  };
}
s(cc, "default");

// versions/4.4.3/node_modules/zod/v4/locales/cs.js
var Bv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "znak\u016F", verb: "m\xEDt" },
    file: { unit: "bajt\u016F", verb: "m\xEDt" },
    array: { unit: "prvk\u016F", verb: "m\xEDt" },
    set: { unit: "prvk\u016F", verb: "m\xEDt" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "regul\xE1rn\xED v\xFDraz",
    email: "e-mailov\xE1 adresa",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "datum a \u010Das ve form\xE1tu ISO",
    date: "datum ve form\xE1tu ISO",
    time: "\u010Das ve form\xE1tu ISO",
    duration: "doba trv\xE1n\xED ISO",
    ipv4: "IPv4 adresa",
    ipv6: "IPv6 adresa",
    cidrv4: "rozsah IPv4",
    cidrv6: "rozsah IPv6",
    base64: "\u0159et\u011Bzec zak\xF3dovan\xFD ve form\xE1tu base64",
    base64url: "\u0159et\u011Bzec zak\xF3dovan\xFD ve form\xE1tu base64url",
    json_string: "\u0159et\u011Bzec ve form\xE1tu JSON",
    e164: "\u010D\xEDslo E.164",
    jwt: "JWT",
    template_literal: "vstup"
  }, i = {
    nan: "NaN",
    number: "\u010D\xEDslo",
    string: "\u0159et\u011Bzec",
    function: "funkce",
    array: "pole"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Neplatn\xFD vstup: o\u010Dek\xE1v\xE1no instanceof ${r.expected}, obdr\u017Eeno ${c}` : `Neplatn\xFD vstup: o\u010Dek\xE1v\xE1no ${o}, obdr\u017Eeno ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Neplatn\xFD vstup: o\u010Dek\xE1v\xE1no ${v(r.values[0])}` : `Neplatn\xE1 mo\u017Enost: o\u010Dek\xE1v\xE1na jedna z hodnot ${p(r.values, "|")}`;
      case "too_big": {
        let o = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Hodnota je p\u0159\xEDli\u0161 velk\xE1: ${r.origin ?? "hodnota"} mus\xED m\xEDt ${o}${r.maximum.toString()} ${a.unit ?? "prvk\u016F"}` : `Hodnota je p\u0159\xEDli\u0161 velk\xE1: ${r.origin ?? "hodnota"} mus\xED b\xFDt ${o}${r.maximum.toString()}`;
      }
      case "too_small": {
        let o = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Hodnota je p\u0159\xEDli\u0161 mal\xE1: ${r.origin ?? "hodnota"} mus\xED m\xEDt ${o}${r.minimum.toString()} ${a.unit ?? "prvk\u016F"}` : `Hodnota je p\u0159\xEDli\u0161 mal\xE1: ${r.origin ?? "hodnota"} mus\xED b\xFDt ${o}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `Neplatn\xFD \u0159et\u011Bzec: mus\xED za\u010D\xEDnat na "${o.prefix}"` : o.format === "ends_with" ? `Neplatn\xFD \u0159et\u011Bzec: mus\xED kon\u010Dit na "${o.suffix}"` : o.format === "includes" ? `Neplatn\xFD \u0159et\u011Bzec: mus\xED obsahovat "${o.includes}"` : o.format === "regex" ? `Neplatn\xFD \u0159et\u011Bzec: mus\xED odpov\xEDdat vzoru ${o.pattern}` : `Neplatn\xFD form\xE1t ${n[o.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Neplatn\xE9 \u010D\xEDslo: mus\xED b\xFDt n\xE1sobkem ${r.divisor}`;
      case "unrecognized_keys":
        return `Nezn\xE1m\xE9 kl\xED\u010De: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Neplatn\xFD kl\xED\u010D v ${r.origin}`;
      case "invalid_union":
        return "Neplatn\xFD vstup";
      case "invalid_element":
        return `Neplatn\xE1 hodnota v ${r.origin}`;
      default:
        return "Neplatn\xFD vstup";
    }
  };
}, "error");
function uc() {
  return {
    localeError: Bv()
  };
}
s(uc, "default");

// versions/4.4.3/node_modules/zod/v4/locales/da.js
var Jv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "tegn", verb: "havde" },
    file: { unit: "bytes", verb: "havde" },
    array: { unit: "elementer", verb: "indeholdt" },
    set: { unit: "elementer", verb: "indeholdt" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "input",
    email: "e-mailadresse",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO dato- og klokkesl\xE6t",
    date: "ISO-dato",
    time: "ISO-klokkesl\xE6t",
    duration: "ISO-varighed",
    ipv4: "IPv4-omr\xE5de",
    ipv6: "IPv6-omr\xE5de",
    cidrv4: "IPv4-spektrum",
    cidrv6: "IPv6-spektrum",
    base64: "base64-kodet streng",
    base64url: "base64url-kodet streng",
    json_string: "JSON-streng",
    e164: "E.164-nummer",
    jwt: "JWT",
    template_literal: "input"
  }, i = {
    nan: "NaN",
    string: "streng",
    number: "tal",
    boolean: "boolean",
    array: "liste",
    object: "objekt",
    set: "s\xE6t",
    file: "fil"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Ugyldigt input: forventede instanceof ${r.expected}, fik ${c}` : `Ugyldigt input: forventede ${o}, fik ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Ugyldig v\xE6rdi: forventede ${v(r.values[0])}` : `Ugyldigt valg: forventede en af f\xF8lgende ${p(r.values, "|")}`;
      case "too_big": {
        let o = r.inclusive ? "<=" : "<", a = t(r.origin), c = i[r.origin] ?? r.origin;
        return a ? `For stor: forventede ${c ?? "value"} ${a.verb} ${o} ${r.maximum.toString()} ${a.unit ?? "elementer"}` : `For stor: forventede ${c ?? "value"} havde ${o} ${r.maximum.toString()}`;
      }
      case "too_small": {
        let o = r.inclusive ? ">=" : ">", a = t(r.origin), c = i[r.origin] ?? r.origin;
        return a ? `For lille: forventede ${c} ${a.verb} ${o} ${r.minimum.toString()} ${a.unit}` : `For lille: forventede ${c} havde ${o} ${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `Ugyldig streng: skal starte med "${o.prefix}"` : o.format === "ends_with" ? `Ugyldig streng: skal ende med "${o.suffix}"` : o.format === "includes" ? `Ugyldig streng: skal indeholde "${o.includes}"` : o.format === "regex" ? `Ugyldig streng: skal matche m\xF8nsteret ${o.pattern}` : `Ugyldig ${n[o.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Ugyldigt tal: skal v\xE6re deleligt med ${r.divisor}`;
      case "unrecognized_keys":
        return `${r.keys.length > 1 ? "Ukendte n\xF8gler" : "Ukendt n\xF8gle"}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Ugyldig n\xF8gle i ${r.origin}`;
      case "invalid_union":
        return "Ugyldigt input: matcher ingen af de tilladte typer";
      case "invalid_element":
        return `Ugyldig v\xE6rdi i ${r.origin}`;
      default:
        return "Ugyldigt input";
    }
  };
}, "error");
function lc() {
  return {
    localeError: Jv()
  };
}
s(lc, "default");

// versions/4.4.3/node_modules/zod/v4/locales/de.js
var Vv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "Zeichen", verb: "zu haben" },
    file: { unit: "Bytes", verb: "zu haben" },
    array: { unit: "Elemente", verb: "zu haben" },
    set: { unit: "Elemente", verb: "zu haben" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "Eingabe",
    email: "E-Mail-Adresse",
    url: "URL",
    emoji: "Emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO-Datum und -Uhrzeit",
    date: "ISO-Datum",
    time: "ISO-Uhrzeit",
    duration: "ISO-Dauer",
    ipv4: "IPv4-Adresse",
    ipv6: "IPv6-Adresse",
    cidrv4: "IPv4-Bereich",
    cidrv6: "IPv6-Bereich",
    base64: "Base64-codierter String",
    base64url: "Base64-URL-codierter String",
    json_string: "JSON-String",
    e164: "E.164-Nummer",
    jwt: "JWT",
    template_literal: "Eingabe"
  }, i = {
    nan: "NaN",
    number: "Zahl",
    array: "Array"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Ung\xFCltige Eingabe: erwartet instanceof ${r.expected}, erhalten ${c}` : `Ung\xFCltige Eingabe: erwartet ${o}, erhalten ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Ung\xFCltige Eingabe: erwartet ${v(r.values[0])}` : `Ung\xFCltige Option: erwartet eine von ${p(r.values, "|")}`;
      case "too_big": {
        let o = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Zu gro\xDF: erwartet, dass ${r.origin ?? "Wert"} ${o}${r.maximum.toString()} ${a.unit ?? "Elemente"} hat` : `Zu gro\xDF: erwartet, dass ${r.origin ?? "Wert"} ${o}${r.maximum.toString()} ist`;
      }
      case "too_small": {
        let o = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Zu klein: erwartet, dass ${r.origin} ${o}${r.minimum.toString()} ${a.unit} hat` : `Zu klein: erwartet, dass ${r.origin} ${o}${r.minimum.toString()} ist`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `Ung\xFCltiger String: muss mit "${o.prefix}" beginnen` : o.format === "ends_with" ? `Ung\xFCltiger String: muss mit "${o.suffix}" enden` : o.format === "includes" ? `Ung\xFCltiger String: muss "${o.includes}" enthalten` : o.format === "regex" ? `Ung\xFCltiger String: muss dem Muster ${o.pattern} entsprechen` : `Ung\xFCltig: ${n[o.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Ung\xFCltige Zahl: muss ein Vielfaches von ${r.divisor} sein`;
      case "unrecognized_keys":
        return `${r.keys.length > 1 ? "Unbekannte Schl\xFCssel" : "Unbekannter Schl\xFCssel"}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Ung\xFCltiger Schl\xFCssel in ${r.origin}`;
      case "invalid_union":
        return "Ung\xFCltige Eingabe";
      case "invalid_element":
        return `Ung\xFCltiger Wert in ${r.origin}`;
      default:
        return "Ung\xFCltige Eingabe";
    }
  };
}, "error");
function dc() {
  return {
    localeError: Vv()
  };
}
s(dc, "default");

// versions/4.4.3/node_modules/zod/v4/locales/el.js
var qv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u03C7\u03B1\u03C1\u03B1\u03BA\u03C4\u03AE\u03C1\u03B5\u03C2", verb: "\u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9" },
    file: { unit: "bytes", verb: "\u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9" },
    array: { unit: "\u03C3\u03C4\u03BF\u03B9\u03C7\u03B5\u03AF\u03B1", verb: "\u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9" },
    set: { unit: "\u03C3\u03C4\u03BF\u03B9\u03C7\u03B5\u03AF\u03B1", verb: "\u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9" },
    map: { unit: "\u03BA\u03B1\u03C4\u03B1\u03C7\u03C9\u03C1\u03AE\u03C3\u03B5\u03B9\u03C2", verb: "\u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2",
    email: "\u03B4\u03B9\u03B5\u03CD\u03B8\u03C5\u03BD\u03C3\u03B7 email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u03B7\u03BC\u03B5\u03C1\u03BF\u03BC\u03B7\u03BD\u03AF\u03B1 \u03BA\u03B1\u03B9 \u03CE\u03C1\u03B1",
    date: "ISO \u03B7\u03BC\u03B5\u03C1\u03BF\u03BC\u03B7\u03BD\u03AF\u03B1",
    time: "ISO \u03CE\u03C1\u03B1",
    duration: "ISO \u03B4\u03B9\u03AC\u03C1\u03BA\u03B5\u03B9\u03B1",
    ipv4: "\u03B4\u03B9\u03B5\u03CD\u03B8\u03C5\u03BD\u03C3\u03B7 IPv4",
    ipv6: "\u03B4\u03B9\u03B5\u03CD\u03B8\u03C5\u03BD\u03C3\u03B7 IPv6",
    mac: "\u03B4\u03B9\u03B5\u03CD\u03B8\u03C5\u03BD\u03C3\u03B7 MAC",
    cidrv4: "\u03B5\u03CD\u03C1\u03BF\u03C2 IPv4",
    cidrv6: "\u03B5\u03CD\u03C1\u03BF\u03C2 IPv6",
    base64: "\u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC \u03BA\u03C9\u03B4\u03B9\u03BA\u03BF\u03C0\u03BF\u03B9\u03B7\u03BC\u03AD\u03BD\u03B7 \u03C3\u03B5 base64",
    base64url: "\u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC \u03BA\u03C9\u03B4\u03B9\u03BA\u03BF\u03C0\u03BF\u03B9\u03B7\u03BC\u03AD\u03BD\u03B7 \u03C3\u03B5 base64url",
    json_string: "\u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC JSON",
    e164: "\u03B1\u03C1\u03B9\u03B8\u03BC\u03CC\u03C2 E.164",
    jwt: "JWT",
    template_literal: "\u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2"
  }, i = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return typeof r.expected == "string" && /^[A-Z]/.test(r.expected) ? `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD instanceof ${r.expected}, \u03BB\u03AE\u03C6\u03B8\u03B7\u03BA\u03B5 ${c}` : `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${o}, \u03BB\u03AE\u03C6\u03B8\u03B7\u03BA\u03B5 ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${v(r.values[0])}` : `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03C0\u03B9\u03BB\u03BF\u03B3\u03AE: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD \u03AD\u03BD\u03B1 \u03B1\u03C0\u03CC ${p(r.values, "|")}`;
      case "too_big": {
        let o = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `\u03A0\u03BF\u03BB\u03CD \u03BC\u03B5\u03B3\u03AC\u03BB\u03BF: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${r.origin ?? "\u03C4\u03B9\u03BC\u03AE"} \u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9 ${o}${r.maximum.toString()} ${a.unit ?? "\u03C3\u03C4\u03BF\u03B9\u03C7\u03B5\u03AF\u03B1"}` : `\u03A0\u03BF\u03BB\u03CD \u03BC\u03B5\u03B3\u03AC\u03BB\u03BF: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${r.origin ?? "\u03C4\u03B9\u03BC\u03AE"} \u03BD\u03B1 \u03B5\u03AF\u03BD\u03B1\u03B9 ${o}${r.maximum.toString()}`;
      }
      case "too_small": {
        let o = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\u03A0\u03BF\u03BB\u03CD \u03BC\u03B9\u03BA\u03C1\u03CC: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${r.origin} \u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9 ${o}${r.minimum.toString()} ${a.unit}` : `\u03A0\u03BF\u03BB\u03CD \u03BC\u03B9\u03BA\u03C1\u03CC: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${r.origin} \u03BD\u03B1 \u03B5\u03AF\u03BD\u03B1\u03B9 ${o}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC: \u03C0\u03C1\u03AD\u03C0\u03B5\u03B9 \u03BD\u03B1 \u03BE\u03B5\u03BA\u03B9\u03BD\u03AC \u03BC\u03B5 "${o.prefix}"` : o.format === "ends_with" ? `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC: \u03C0\u03C1\u03AD\u03C0\u03B5\u03B9 \u03BD\u03B1 \u03C4\u03B5\u03BB\u03B5\u03B9\u03CE\u03BD\u03B5\u03B9 \u03BC\u03B5 "${o.suffix}"` : o.format === "includes" ? `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC: \u03C0\u03C1\u03AD\u03C0\u03B5\u03B9 \u03BD\u03B1 \u03C0\u03B5\u03C1\u03B9\u03AD\u03C7\u03B5\u03B9 "${o.includes}"` : o.format === "regex" ? `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC: \u03C0\u03C1\u03AD\u03C0\u03B5\u03B9 \u03BD\u03B1 \u03C4\u03B1\u03B9\u03C1\u03B9\u03AC\u03B6\u03B5\u03B9 \u03BC\u03B5 \u03C4\u03BF \u03BC\u03BF\u03C4\u03AF\u03B2\u03BF ${o.pattern}` : `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03BF: ${n[o.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03BF\u03C2 \u03B1\u03C1\u03B9\u03B8\u03BC\u03CC\u03C2: \u03C0\u03C1\u03AD\u03C0\u03B5\u03B9 \u03BD\u03B1 \u03B5\u03AF\u03BD\u03B1\u03B9 \u03C0\u03BF\u03BB\u03BB\u03B1\u03C0\u03BB\u03AC\u03C3\u03B9\u03BF \u03C4\u03BF\u03C5 ${r.divisor}`;
      case "unrecognized_keys":
        return `\u0386\u03B3\u03BD\u03C9\u03C3\u03C4${r.keys.length > 1 ? "\u03B1" : "\u03BF"} \u03BA\u03BB\u03B5\u03B9\u03B4${r.keys.length > 1 ? "\u03B9\u03AC" : "\u03AF"}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03BF \u03BA\u03BB\u03B5\u03B9\u03B4\u03AF \u03C3\u03C4\u03BF ${r.origin}`;
      case "invalid_union":
        return "\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2";
      case "invalid_element":
        return `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03C4\u03B9\u03BC\u03AE \u03C3\u03C4\u03BF ${r.origin}`;
      default:
        return "\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2";
    }
  };
}, "error");
function fc() {
  return {
    localeError: qv()
  };
}
s(fc, "default");

// versions/4.4.3/node_modules/zod/v4/locales/en.js
var Wv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "characters", verb: "to have" },
    file: { unit: "bytes", verb: "to have" },
    array: { unit: "items", verb: "to have" },
    set: { unit: "items", verb: "to have" },
    map: { unit: "entries", verb: "to have" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "input",
    email: "email address",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datetime",
    date: "ISO date",
    time: "ISO time",
    duration: "ISO duration",
    ipv4: "IPv4 address",
    ipv6: "IPv6 address",
    mac: "MAC address",
    cidrv4: "IPv4 range",
    cidrv6: "IPv6 range",
    base64: "base64-encoded string",
    base64url: "base64url-encoded string",
    json_string: "JSON string",
    e164: "E.164 number",
    jwt: "JWT",
    template_literal: "input"
  }, i = {
    // Compatibility: "nan" -> "NaN" for display
    nan: "NaN"
    // All other type names omitted - they fall back to raw values via ?? operator
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return `Invalid input: expected ${o}, received ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Invalid input: expected ${v(r.values[0])}` : `Invalid option: expected one of ${p(r.values, "|")}`;
      case "too_big": {
        let o = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Too big: expected ${r.origin ?? "value"} to have ${o}${r.maximum.toString()} ${a.unit ?? "elements"}` : `Too big: expected ${r.origin ?? "value"} to be ${o}${r.maximum.toString()}`;
      }
      case "too_small": {
        let o = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Too small: expected ${r.origin} to have ${o}${r.minimum.toString()} ${a.unit}` : `Too small: expected ${r.origin} to be ${o}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `Invalid string: must start with "${o.prefix}"` : o.format === "ends_with" ? `Invalid string: must end with "${o.suffix}"` : o.format === "includes" ? `Invalid string: must include "${o.includes}"` : o.format === "regex" ? `Invalid string: must match pattern ${o.pattern}` : `Invalid ${n[o.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Invalid number: must be a multiple of ${r.divisor}`;
      case "unrecognized_keys":
        return `Unrecognized key${r.keys.length > 1 ? "s" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Invalid key in ${r.origin}`;
      case "invalid_union":
        return r.options && Array.isArray(r.options) && r.options.length > 0 ? `Invalid discriminator value. Expected ${r.options.map((a) => `'${a}'`).join(" | ")}` : "Invalid input";
      case "invalid_element":
        return `Invalid value in ${r.origin}`;
      default:
        return "Invalid input";
    }
  };
}, "error");
function Er() {
  return {
    localeError: Wv()
  };
}
s(Er, "default");

// versions/4.4.3/node_modules/zod/v4/locales/eo.js
var Kv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "karaktrojn", verb: "havi" },
    file: { unit: "bajtojn", verb: "havi" },
    array: { unit: "elementojn", verb: "havi" },
    set: { unit: "elementojn", verb: "havi" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "enigo",
    email: "retadreso",
    url: "URL",
    emoji: "emo\u011Dio",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO-datotempo",
    date: "ISO-dato",
    time: "ISO-tempo",
    duration: "ISO-da\u016Dro",
    ipv4: "IPv4-adreso",
    ipv6: "IPv6-adreso",
    cidrv4: "IPv4-rango",
    cidrv6: "IPv6-rango",
    base64: "64-ume kodita karaktraro",
    base64url: "URL-64-ume kodita karaktraro",
    json_string: "JSON-karaktraro",
    e164: "E.164-nombro",
    jwt: "JWT",
    template_literal: "enigo"
  }, i = {
    nan: "NaN",
    number: "nombro",
    array: "tabelo",
    null: "senvalora"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Nevalida enigo: atendi\u011Dis instanceof ${r.expected}, ricevi\u011Dis ${c}` : `Nevalida enigo: atendi\u011Dis ${o}, ricevi\u011Dis ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Nevalida enigo: atendi\u011Dis ${v(r.values[0])}` : `Nevalida opcio: atendi\u011Dis unu el ${p(r.values, "|")}`;
      case "too_big": {
        let o = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Tro granda: atendi\u011Dis ke ${r.origin ?? "valoro"} havu ${o}${r.maximum.toString()} ${a.unit ?? "elementojn"}` : `Tro granda: atendi\u011Dis ke ${r.origin ?? "valoro"} havu ${o}${r.maximum.toString()}`;
      }
      case "too_small": {
        let o = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Tro malgranda: atendi\u011Dis ke ${r.origin} havu ${o}${r.minimum.toString()} ${a.unit}` : `Tro malgranda: atendi\u011Dis ke ${r.origin} estu ${o}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `Nevalida karaktraro: devas komenci\u011Di per "${o.prefix}"` : o.format === "ends_with" ? `Nevalida karaktraro: devas fini\u011Di per "${o.suffix}"` : o.format === "includes" ? `Nevalida karaktraro: devas inkluzivi "${o.includes}"` : o.format === "regex" ? `Nevalida karaktraro: devas kongrui kun la modelo ${o.pattern}` : `Nevalida ${n[o.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Nevalida nombro: devas esti oblo de ${r.divisor}`;
      case "unrecognized_keys":
        return `Nekonata${r.keys.length > 1 ? "j" : ""} \u015Dlosilo${r.keys.length > 1 ? "j" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Nevalida \u015Dlosilo en ${r.origin}`;
      case "invalid_union":
        return "Nevalida enigo";
      case "invalid_element":
        return `Nevalida valoro en ${r.origin}`;
      default:
        return "Nevalida enigo";
    }
  };
}, "error");
function pc() {
  return {
    localeError: Kv()
  };
}
s(pc, "default");

// versions/4.4.3/node_modules/zod/v4/locales/es.js
var Gv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "caracteres", verb: "tener" },
    file: { unit: "bytes", verb: "tener" },
    array: { unit: "elementos", verb: "tener" },
    set: { unit: "elementos", verb: "tener" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "entrada",
    email: "direcci\xF3n de correo electr\xF3nico",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "fecha y hora ISO",
    date: "fecha ISO",
    time: "hora ISO",
    duration: "duraci\xF3n ISO",
    ipv4: "direcci\xF3n IPv4",
    ipv6: "direcci\xF3n IPv6",
    cidrv4: "rango IPv4",
    cidrv6: "rango IPv6",
    base64: "cadena codificada en base64",
    base64url: "URL codificada en base64",
    json_string: "cadena JSON",
    e164: "n\xFAmero E.164",
    jwt: "JWT",
    template_literal: "entrada"
  }, i = {
    nan: "NaN",
    string: "texto",
    number: "n\xFAmero",
    boolean: "booleano",
    array: "arreglo",
    object: "objeto",
    set: "conjunto",
    file: "archivo",
    date: "fecha",
    bigint: "n\xFAmero grande",
    symbol: "s\xEDmbolo",
    undefined: "indefinido",
    null: "nulo",
    function: "funci\xF3n",
    map: "mapa",
    record: "registro",
    tuple: "tupla",
    enum: "enumeraci\xF3n",
    union: "uni\xF3n",
    literal: "literal",
    promise: "promesa",
    void: "vac\xEDo",
    never: "nunca",
    unknown: "desconocido",
    any: "cualquiera"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Entrada inv\xE1lida: se esperaba instanceof ${r.expected}, recibido ${c}` : `Entrada inv\xE1lida: se esperaba ${o}, recibido ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Entrada inv\xE1lida: se esperaba ${v(r.values[0])}` : `Opci\xF3n inv\xE1lida: se esperaba una de ${p(r.values, "|")}`;
      case "too_big": {
        let o = r.inclusive ? "<=" : "<", a = t(r.origin), c = i[r.origin] ?? r.origin;
        return a ? `Demasiado grande: se esperaba que ${c ?? "valor"} tuviera ${o}${r.maximum.toString()} ${a.unit ?? "elementos"}` : `Demasiado grande: se esperaba que ${c ?? "valor"} fuera ${o}${r.maximum.toString()}`;
      }
      case "too_small": {
        let o = r.inclusive ? ">=" : ">", a = t(r.origin), c = i[r.origin] ?? r.origin;
        return a ? `Demasiado peque\xF1o: se esperaba que ${c} tuviera ${o}${r.minimum.toString()} ${a.unit}` : `Demasiado peque\xF1o: se esperaba que ${c} fuera ${o}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `Cadena inv\xE1lida: debe comenzar con "${o.prefix}"` : o.format === "ends_with" ? `Cadena inv\xE1lida: debe terminar en "${o.suffix}"` : o.format === "includes" ? `Cadena inv\xE1lida: debe incluir "${o.includes}"` : o.format === "regex" ? `Cadena inv\xE1lida: debe coincidir con el patr\xF3n ${o.pattern}` : `Inv\xE1lido ${n[o.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `N\xFAmero inv\xE1lido: debe ser m\xFAltiplo de ${r.divisor}`;
      case "unrecognized_keys":
        return `Llave${r.keys.length > 1 ? "s" : ""} desconocida${r.keys.length > 1 ? "s" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Llave inv\xE1lida en ${i[r.origin] ?? r.origin}`;
      case "invalid_union":
        return "Entrada inv\xE1lida";
      case "invalid_element":
        return `Valor inv\xE1lido en ${i[r.origin] ?? r.origin}`;
      default:
        return "Entrada inv\xE1lida";
    }
  };
}, "error");
function mc() {
  return {
    localeError: Gv()
  };
}
s(mc, "default");

// versions/4.4.3/node_modules/zod/v4/locales/fa.js
var Xv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u06A9\u0627\u0631\u0627\u06A9\u062A\u0631", verb: "\u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F" },
    file: { unit: "\u0628\u0627\u06CC\u062A", verb: "\u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F" },
    array: { unit: "\u0622\u06CC\u062A\u0645", verb: "\u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F" },
    set: { unit: "\u0622\u06CC\u062A\u0645", verb: "\u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u0648\u0631\u0648\u062F\u06CC",
    email: "\u0622\u062F\u0631\u0633 \u0627\u06CC\u0645\u06CC\u0644",
    url: "URL",
    emoji: "\u0627\u06CC\u0645\u0648\u062C\u06CC",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u062A\u0627\u0631\u06CC\u062E \u0648 \u0632\u0645\u0627\u0646 \u0627\u06CC\u0632\u0648",
    date: "\u062A\u0627\u0631\u06CC\u062E \u0627\u06CC\u0632\u0648",
    time: "\u0632\u0645\u0627\u0646 \u0627\u06CC\u0632\u0648",
    duration: "\u0645\u062F\u062A \u0632\u0645\u0627\u0646 \u0627\u06CC\u0632\u0648",
    ipv4: "IPv4 \u0622\u062F\u0631\u0633",
    ipv6: "IPv6 \u0622\u062F\u0631\u0633",
    cidrv4: "IPv4 \u062F\u0627\u0645\u0646\u0647",
    cidrv6: "IPv6 \u062F\u0627\u0645\u0646\u0647",
    base64: "base64-encoded \u0631\u0634\u062A\u0647",
    base64url: "base64url-encoded \u0631\u0634\u062A\u0647",
    json_string: "JSON \u0631\u0634\u062A\u0647",
    e164: "E.164 \u0639\u062F\u062F",
    jwt: "JWT",
    template_literal: "\u0648\u0631\u0648\u062F\u06CC"
  }, i = {
    nan: "NaN",
    number: "\u0639\u062F\u062F",
    array: "\u0622\u0631\u0627\u06CC\u0647"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0645\u06CC\u200C\u0628\u0627\u06CC\u0633\u062A instanceof ${r.expected} \u0645\u06CC\u200C\u0628\u0648\u062F\u060C ${c} \u062F\u0631\u06CC\u0627\u0641\u062A \u0634\u062F` : `\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0645\u06CC\u200C\u0628\u0627\u06CC\u0633\u062A ${o} \u0645\u06CC\u200C\u0628\u0648\u062F\u060C ${c} \u062F\u0631\u06CC\u0627\u0641\u062A \u0634\u062F`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0645\u06CC\u200C\u0628\u0627\u06CC\u0633\u062A ${v(r.values[0])} \u0645\u06CC\u200C\u0628\u0648\u062F` : `\u06AF\u0632\u06CC\u0646\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0645\u06CC\u200C\u0628\u0627\u06CC\u0633\u062A \u06CC\u06A9\u06CC \u0627\u0632 ${p(r.values, "|")} \u0645\u06CC\u200C\u0628\u0648\u062F`;
      case "too_big": {
        let o = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `\u062E\u06CC\u0644\u06CC \u0628\u0632\u0631\u06AF: ${r.origin ?? "\u0645\u0642\u062F\u0627\u0631"} \u0628\u0627\u06CC\u062F ${o}${r.maximum.toString()} ${a.unit ?? "\u0639\u0646\u0635\u0631"} \u0628\u0627\u0634\u062F` : `\u062E\u06CC\u0644\u06CC \u0628\u0632\u0631\u06AF: ${r.origin ?? "\u0645\u0642\u062F\u0627\u0631"} \u0628\u0627\u06CC\u062F ${o}${r.maximum.toString()} \u0628\u0627\u0634\u062F`;
      }
      case "too_small": {
        let o = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\u062E\u06CC\u0644\u06CC \u06A9\u0648\u0686\u06A9: ${r.origin} \u0628\u0627\u06CC\u062F ${o}${r.minimum.toString()} ${a.unit} \u0628\u0627\u0634\u062F` : `\u062E\u06CC\u0644\u06CC \u06A9\u0648\u0686\u06A9: ${r.origin} \u0628\u0627\u06CC\u062F ${o}${r.minimum.toString()} \u0628\u0627\u0634\u062F`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `\u0631\u0634\u062A\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0628\u0627 "${o.prefix}" \u0634\u0631\u0648\u0639 \u0634\u0648\u062F` : o.format === "ends_with" ? `\u0631\u0634\u062A\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0628\u0627 "${o.suffix}" \u062A\u0645\u0627\u0645 \u0634\u0648\u062F` : o.format === "includes" ? `\u0631\u0634\u062A\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0634\u0627\u0645\u0644 "${o.includes}" \u0628\u0627\u0634\u062F` : o.format === "regex" ? `\u0631\u0634\u062A\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0628\u0627 \u0627\u0644\u06AF\u0648\u06CC ${o.pattern} \u0645\u0637\u0627\u0628\u0642\u062A \u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F` : `${n[o.format] ?? r.format} \u0646\u0627\u0645\u0639\u062A\u0628\u0631`;
      }
      case "not_multiple_of":
        return `\u0639\u062F\u062F \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0645\u0636\u0631\u0628 ${r.divisor} \u0628\u0627\u0634\u062F`;
      case "unrecognized_keys":
        return `\u06A9\u0644\u06CC\u062F${r.keys.length > 1 ? "\u0647\u0627\u06CC" : ""} \u0646\u0627\u0634\u0646\u0627\u0633: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `\u06A9\u0644\u06CC\u062F \u0646\u0627\u0634\u0646\u0627\u0633 \u062F\u0631 ${r.origin}`;
      case "invalid_union":
        return "\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631";
      case "invalid_element":
        return `\u0645\u0642\u062F\u0627\u0631 \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u062F\u0631 ${r.origin}`;
      default:
        return "\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631";
    }
  };
}, "error");
function gc() {
  return {
    localeError: Xv()
  };
}
s(gc, "default");

// versions/4.4.3/node_modules/zod/v4/locales/fi.js
var Qv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "merkki\xE4", subject: "merkkijonon" },
    file: { unit: "tavua", subject: "tiedoston" },
    array: { unit: "alkiota", subject: "listan" },
    set: { unit: "alkiota", subject: "joukon" },
    number: { unit: "", subject: "luvun" },
    bigint: { unit: "", subject: "suuren kokonaisluvun" },
    int: { unit: "", subject: "kokonaisluvun" },
    date: { unit: "", subject: "p\xE4iv\xE4m\xE4\xE4r\xE4n" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "s\xE4\xE4nn\xF6llinen lauseke",
    email: "s\xE4hk\xF6postiosoite",
    url: "URL-osoite",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO-aikaleima",
    date: "ISO-p\xE4iv\xE4m\xE4\xE4r\xE4",
    time: "ISO-aika",
    duration: "ISO-kesto",
    ipv4: "IPv4-osoite",
    ipv6: "IPv6-osoite",
    cidrv4: "IPv4-alue",
    cidrv6: "IPv6-alue",
    base64: "base64-koodattu merkkijono",
    base64url: "base64url-koodattu merkkijono",
    json_string: "JSON-merkkijono",
    e164: "E.164-luku",
    jwt: "JWT",
    template_literal: "templaattimerkkijono"
  }, i = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Virheellinen tyyppi: odotettiin instanceof ${r.expected}, oli ${c}` : `Virheellinen tyyppi: odotettiin ${o}, oli ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Virheellinen sy\xF6te: t\xE4ytyy olla ${v(r.values[0])}` : `Virheellinen valinta: t\xE4ytyy olla yksi seuraavista: ${p(r.values, "|")}`;
      case "too_big": {
        let o = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Liian suuri: ${a.subject} t\xE4ytyy olla ${o}${r.maximum.toString()} ${a.unit}`.trim() : `Liian suuri: arvon t\xE4ytyy olla ${o}${r.maximum.toString()}`;
      }
      case "too_small": {
        let o = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Liian pieni: ${a.subject} t\xE4ytyy olla ${o}${r.minimum.toString()} ${a.unit}`.trim() : `Liian pieni: arvon t\xE4ytyy olla ${o}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `Virheellinen sy\xF6te: t\xE4ytyy alkaa "${o.prefix}"` : o.format === "ends_with" ? `Virheellinen sy\xF6te: t\xE4ytyy loppua "${o.suffix}"` : o.format === "includes" ? `Virheellinen sy\xF6te: t\xE4ytyy sis\xE4lt\xE4\xE4 "${o.includes}"` : o.format === "regex" ? `Virheellinen sy\xF6te: t\xE4ytyy vastata s\xE4\xE4nn\xF6llist\xE4 lauseketta ${o.pattern}` : `Virheellinen ${n[o.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Virheellinen luku: t\xE4ytyy olla luvun ${r.divisor} monikerta`;
      case "unrecognized_keys":
        return `${r.keys.length > 1 ? "Tuntemattomat avaimet" : "Tuntematon avain"}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return "Virheellinen avain tietueessa";
      case "invalid_union":
        return "Virheellinen unioni";
      case "invalid_element":
        return "Virheellinen arvo joukossa";
      default:
        return "Virheellinen sy\xF6te";
    }
  };
}, "error");
function hc() {
  return {
    localeError: Qv()
  };
}
s(hc, "default");

// versions/4.4.3/node_modules/zod/v4/locales/fr.js
var Hv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "caract\xE8res", verb: "avoir" },
    file: { unit: "octets", verb: "avoir" },
    array: { unit: "\xE9l\xE9ments", verb: "avoir" },
    set: { unit: "\xE9l\xE9ments", verb: "avoir" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "entr\xE9e",
    email: "adresse e-mail",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "date et heure ISO",
    date: "date ISO",
    time: "heure ISO",
    duration: "dur\xE9e ISO",
    ipv4: "adresse IPv4",
    ipv6: "adresse IPv6",
    cidrv4: "plage IPv4",
    cidrv6: "plage IPv6",
    base64: "cha\xEEne encod\xE9e en base64",
    base64url: "cha\xEEne encod\xE9e en base64url",
    json_string: "cha\xEEne JSON",
    e164: "num\xE9ro E.164",
    jwt: "JWT",
    template_literal: "entr\xE9e"
  }, i = {
    string: "cha\xEEne",
    number: "nombre",
    int: "entier",
    boolean: "bool\xE9en",
    bigint: "grand entier",
    symbol: "symbole",
    undefined: "ind\xE9fini",
    null: "null",
    never: "jamais",
    void: "vide",
    date: "date",
    array: "tableau",
    object: "objet",
    tuple: "tuple",
    record: "enregistrement",
    map: "carte",
    set: "ensemble",
    file: "fichier",
    nonoptional: "non-optionnel",
    nan: "NaN",
    function: "fonction"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Entr\xE9e invalide : instanceof ${r.expected} attendu, ${c} re\xE7u` : `Entr\xE9e invalide : ${o} attendu, ${c} re\xE7u`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Entr\xE9e invalide : ${v(r.values[0])} attendu` : `Option invalide : une valeur parmi ${p(r.values, "|")} attendue`;
      case "too_big": {
        let o = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Trop grand : ${i[r.origin] ?? "valeur"} doit ${a.verb} ${o}${r.maximum.toString()} ${a.unit ?? "\xE9l\xE9ment(s)"}` : `Trop grand : ${i[r.origin] ?? "valeur"} doit \xEAtre ${o}${r.maximum.toString()}`;
      }
      case "too_small": {
        let o = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Trop petit : ${i[r.origin] ?? "valeur"} doit ${a.verb} ${o}${r.minimum.toString()} ${a.unit}` : `Trop petit : ${i[r.origin] ?? "valeur"} doit \xEAtre ${o}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `Cha\xEEne invalide : doit commencer par "${o.prefix}"` : o.format === "ends_with" ? `Cha\xEEne invalide : doit se terminer par "${o.suffix}"` : o.format === "includes" ? `Cha\xEEne invalide : doit inclure "${o.includes}"` : o.format === "regex" ? `Cha\xEEne invalide : doit correspondre au mod\xE8le ${o.pattern}` : `${n[o.format] ?? r.format} invalide`;
      }
      case "not_multiple_of":
        return `Nombre invalide : doit \xEAtre un multiple de ${r.divisor}`;
      case "unrecognized_keys":
        return `Cl\xE9${r.keys.length > 1 ? "s" : ""} non reconnue${r.keys.length > 1 ? "s" : ""} : ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Cl\xE9 invalide dans ${r.origin}`;
      case "invalid_union":
        return "Entr\xE9e invalide";
      case "invalid_element":
        return `Valeur invalide dans ${r.origin}`;
      default:
        return "Entr\xE9e invalide";
    }
  };
}, "error");
function vc() {
  return {
    localeError: Hv()
  };
}
s(vc, "default");

// versions/4.4.3/node_modules/zod/v4/locales/fr-CA.js
var Yv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "caract\xE8res", verb: "avoir" },
    file: { unit: "octets", verb: "avoir" },
    array: { unit: "\xE9l\xE9ments", verb: "avoir" },
    set: { unit: "\xE9l\xE9ments", verb: "avoir" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "entr\xE9e",
    email: "adresse courriel",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "date-heure ISO",
    date: "date ISO",
    time: "heure ISO",
    duration: "dur\xE9e ISO",
    ipv4: "adresse IPv4",
    ipv6: "adresse IPv6",
    cidrv4: "plage IPv4",
    cidrv6: "plage IPv6",
    base64: "cha\xEEne encod\xE9e en base64",
    base64url: "cha\xEEne encod\xE9e en base64url",
    json_string: "cha\xEEne JSON",
    e164: "num\xE9ro E.164",
    jwt: "JWT",
    template_literal: "entr\xE9e"
  }, i = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Entr\xE9e invalide : attendu instanceof ${r.expected}, re\xE7u ${c}` : `Entr\xE9e invalide : attendu ${o}, re\xE7u ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Entr\xE9e invalide : attendu ${v(r.values[0])}` : `Option invalide : attendu l'une des valeurs suivantes ${p(r.values, "|")}`;
      case "too_big": {
        let o = r.inclusive ? "\u2264" : "<", a = t(r.origin);
        return a ? `Trop grand : attendu que ${r.origin ?? "la valeur"} ait ${o}${r.maximum.toString()} ${a.unit}` : `Trop grand : attendu que ${r.origin ?? "la valeur"} soit ${o}${r.maximum.toString()}`;
      }
      case "too_small": {
        let o = r.inclusive ? "\u2265" : ">", a = t(r.origin);
        return a ? `Trop petit : attendu que ${r.origin} ait ${o}${r.minimum.toString()} ${a.unit}` : `Trop petit : attendu que ${r.origin} soit ${o}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `Cha\xEEne invalide : doit commencer par "${o.prefix}"` : o.format === "ends_with" ? `Cha\xEEne invalide : doit se terminer par "${o.suffix}"` : o.format === "includes" ? `Cha\xEEne invalide : doit inclure "${o.includes}"` : o.format === "regex" ? `Cha\xEEne invalide : doit correspondre au motif ${o.pattern}` : `${n[o.format] ?? r.format} invalide`;
      }
      case "not_multiple_of":
        return `Nombre invalide : doit \xEAtre un multiple de ${r.divisor}`;
      case "unrecognized_keys":
        return `Cl\xE9${r.keys.length > 1 ? "s" : ""} non reconnue${r.keys.length > 1 ? "s" : ""} : ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Cl\xE9 invalide dans ${r.origin}`;
      case "invalid_union":
        return "Entr\xE9e invalide";
      case "invalid_element":
        return `Valeur invalide dans ${r.origin}`;
      default:
        return "Entr\xE9e invalide";
    }
  };
}, "error");
function yc() {
  return {
    localeError: Yv()
  };
}
s(yc, "default");

// versions/4.4.3/node_modules/zod/v4/locales/he.js
var ey = /* @__PURE__ */ s(() => {
  let e = {
    string: { label: "\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA", gender: "f" },
    number: { label: "\u05DE\u05E1\u05E4\u05E8", gender: "m" },
    boolean: { label: "\u05E2\u05E8\u05DA \u05D1\u05D5\u05DC\u05D9\u05D0\u05E0\u05D9", gender: "m" },
    bigint: { label: "BigInt", gender: "m" },
    date: { label: "\u05EA\u05D0\u05E8\u05D9\u05DA", gender: "m" },
    array: { label: "\u05DE\u05E2\u05E8\u05DA", gender: "m" },
    object: { label: "\u05D0\u05D5\u05D1\u05D9\u05D9\u05E7\u05D8", gender: "m" },
    null: { label: "\u05E2\u05E8\u05DA \u05E8\u05D9\u05E7 (null)", gender: "m" },
    undefined: { label: "\u05E2\u05E8\u05DA \u05DC\u05D0 \u05DE\u05D5\u05D2\u05D3\u05E8 (undefined)", gender: "m" },
    symbol: { label: "\u05E1\u05D9\u05DE\u05D1\u05D5\u05DC (Symbol)", gender: "m" },
    function: { label: "\u05E4\u05D5\u05E0\u05E7\u05E6\u05D9\u05D4", gender: "f" },
    map: { label: "\u05DE\u05E4\u05D4 (Map)", gender: "f" },
    set: { label: "\u05E7\u05D1\u05D5\u05E6\u05D4 (Set)", gender: "f" },
    file: { label: "\u05E7\u05D5\u05D1\u05E5", gender: "m" },
    promise: { label: "Promise", gender: "m" },
    NaN: { label: "NaN", gender: "m" },
    unknown: { label: "\u05E2\u05E8\u05DA \u05DC\u05D0 \u05D9\u05D3\u05D5\u05E2", gender: "m" },
    value: { label: "\u05E2\u05E8\u05DA", gender: "m" }
  }, t = {
    string: { unit: "\u05EA\u05D5\u05D5\u05D9\u05DD", shortLabel: "\u05E7\u05E6\u05E8", longLabel: "\u05D0\u05E8\u05D5\u05DA" },
    file: { unit: "\u05D1\u05D9\u05D9\u05D8\u05D9\u05DD", shortLabel: "\u05E7\u05D8\u05DF", longLabel: "\u05D2\u05D3\u05D5\u05DC" },
    array: { unit: "\u05E4\u05E8\u05D9\u05D8\u05D9\u05DD", shortLabel: "\u05E7\u05D8\u05DF", longLabel: "\u05D2\u05D3\u05D5\u05DC" },
    set: { unit: "\u05E4\u05E8\u05D9\u05D8\u05D9\u05DD", shortLabel: "\u05E7\u05D8\u05DF", longLabel: "\u05D2\u05D3\u05D5\u05DC" },
    number: { unit: "", shortLabel: "\u05E7\u05D8\u05DF", longLabel: "\u05D2\u05D3\u05D5\u05DC" }
    // no unit
  }, n = /* @__PURE__ */ s((l) => l ? e[l] : void 0, "typeEntry"), i = /* @__PURE__ */ s((l) => {
    let d = n(l);
    return d ? d.label : l ?? e.unknown.label;
  }, "typeLabel"), r = /* @__PURE__ */ s((l) => `\u05D4${i(l)}`, "withDefinite"), o = /* @__PURE__ */ s((l) => (n(l)?.gender ?? "m") === "f" ? "\u05E6\u05E8\u05D9\u05DB\u05D4 \u05DC\u05D4\u05D9\u05D5\u05EA" : "\u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA", "verbFor"), a = /* @__PURE__ */ s((l) => l ? t[l] ?? null : null, "getSizing"), c = {
    regex: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    email: { label: "\u05DB\u05EA\u05D5\u05D1\u05EA \u05D0\u05D9\u05DE\u05D9\u05D9\u05DC", gender: "f" },
    url: { label: "\u05DB\u05EA\u05D5\u05D1\u05EA \u05E8\u05E9\u05EA", gender: "f" },
    emoji: { label: "\u05D0\u05D9\u05DE\u05D5\u05D2'\u05D9", gender: "m" },
    uuid: { label: "UUID", gender: "m" },
    nanoid: { label: "nanoid", gender: "m" },
    guid: { label: "GUID", gender: "m" },
    cuid: { label: "cuid", gender: "m" },
    cuid2: { label: "cuid2", gender: "m" },
    ulid: { label: "ULID", gender: "m" },
    xid: { label: "XID", gender: "m" },
    ksuid: { label: "KSUID", gender: "m" },
    datetime: { label: "\u05EA\u05D0\u05E8\u05D9\u05DA \u05D5\u05D6\u05DE\u05DF ISO", gender: "m" },
    date: { label: "\u05EA\u05D0\u05E8\u05D9\u05DA ISO", gender: "m" },
    time: { label: "\u05D6\u05DE\u05DF ISO", gender: "m" },
    duration: { label: "\u05DE\u05E9\u05DA \u05D6\u05DE\u05DF ISO", gender: "m" },
    ipv4: { label: "\u05DB\u05EA\u05D5\u05D1\u05EA IPv4", gender: "f" },
    ipv6: { label: "\u05DB\u05EA\u05D5\u05D1\u05EA IPv6", gender: "f" },
    cidrv4: { label: "\u05D8\u05D5\u05D5\u05D7 IPv4", gender: "m" },
    cidrv6: { label: "\u05D8\u05D5\u05D5\u05D7 IPv6", gender: "m" },
    base64: { label: "\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D1\u05D1\u05E1\u05D9\u05E1 64", gender: "f" },
    base64url: { label: "\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D1\u05D1\u05E1\u05D9\u05E1 64 \u05DC\u05DB\u05EA\u05D5\u05D1\u05D5\u05EA \u05E8\u05E9\u05EA", gender: "f" },
    json_string: { label: "\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA JSON", gender: "f" },
    e164: { label: "\u05DE\u05E1\u05E4\u05E8 E.164", gender: "m" },
    jwt: { label: "JWT", gender: "m" },
    ends_with: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    includes: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    lowercase: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    starts_with: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    uppercase: { label: "\u05E7\u05DC\u05D8", gender: "m" }
  }, u = {
    nan: "NaN"
  };
  return (l) => {
    switch (l.code) {
      case "invalid_type": {
        let d = l.expected, m = u[d ?? ""] ?? i(d), y = b(l.input), h = u[y] ?? e[y]?.label ?? y;
        return /^[A-Z]/.test(l.expected) ? `\u05E7\u05DC\u05D8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA instanceof ${l.expected}, \u05D4\u05EA\u05E7\u05D1\u05DC ${h}` : `\u05E7\u05DC\u05D8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA ${m}, \u05D4\u05EA\u05E7\u05D1\u05DC ${h}`;
      }
      case "invalid_value": {
        if (l.values.length === 1)
          return `\u05E2\u05E8\u05DA \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05D4\u05E2\u05E8\u05DA \u05D7\u05D9\u05D9\u05D1 \u05DC\u05D4\u05D9\u05D5\u05EA ${v(l.values[0])}`;
        let d = l.values.map((h) => v(h));
        if (l.values.length === 2)
          return `\u05E2\u05E8\u05DA \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05D4\u05D0\u05E4\u05E9\u05E8\u05D5\u05D9\u05D5\u05EA \u05D4\u05DE\u05EA\u05D0\u05D9\u05DE\u05D5\u05EA \u05D4\u05DF ${d[0]} \u05D0\u05D5 ${d[1]}`;
        let m = d[d.length - 1];
        return `\u05E2\u05E8\u05DA \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05D4\u05D0\u05E4\u05E9\u05E8\u05D5\u05D9\u05D5\u05EA \u05D4\u05DE\u05EA\u05D0\u05D9\u05DE\u05D5\u05EA \u05D4\u05DF ${d.slice(0, -1).join(", ")} \u05D0\u05D5 ${m}`;
      }
      case "too_big": {
        let d = a(l.origin), m = r(l.origin ?? "value");
        if (l.origin === "string")
          return `${d?.longLabel ?? "\u05D0\u05E8\u05D5\u05DA"} \u05DE\u05D3\u05D9: ${m} \u05E6\u05E8\u05D9\u05DB\u05D4 \u05DC\u05D4\u05DB\u05D9\u05DC ${l.maximum.toString()} ${d?.unit ?? ""} ${l.inclusive ? "\u05D0\u05D5 \u05E4\u05D7\u05D5\u05EA" : "\u05DC\u05DB\u05DC \u05D4\u05D9\u05D5\u05EA\u05E8"}`.trim();
        if (l.origin === "number") {
          let z = l.inclusive ? `\u05E7\u05D8\u05DF \u05D0\u05D5 \u05E9\u05D5\u05D5\u05D4 \u05DC-${l.maximum}` : `\u05E7\u05D8\u05DF \u05DE-${l.maximum}`;
          return `\u05D2\u05D3\u05D5\u05DC \u05DE\u05D3\u05D9: ${m} \u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA ${z}`;
        }
        if (l.origin === "array" || l.origin === "set") {
          let z = l.origin === "set" ? "\u05E6\u05E8\u05D9\u05DB\u05D4" : "\u05E6\u05E8\u05D9\u05DA", D = l.inclusive ? `${l.maximum} ${d?.unit ?? ""} \u05D0\u05D5 \u05E4\u05D7\u05D5\u05EA` : `\u05E4\u05D7\u05D5\u05EA \u05DE-${l.maximum} ${d?.unit ?? ""}`;
          return `\u05D2\u05D3\u05D5\u05DC \u05DE\u05D3\u05D9: ${m} ${z} \u05DC\u05D4\u05DB\u05D9\u05DC ${D}`.trim();
        }
        let y = l.inclusive ? "<=" : "<", h = o(l.origin ?? "value");
        return d?.unit ? `${d.longLabel} \u05DE\u05D3\u05D9: ${m} ${h} ${y}${l.maximum.toString()} ${d.unit}` : `${d?.longLabel ?? "\u05D2\u05D3\u05D5\u05DC"} \u05DE\u05D3\u05D9: ${m} ${h} ${y}${l.maximum.toString()}`;
      }
      case "too_small": {
        let d = a(l.origin), m = r(l.origin ?? "value");
        if (l.origin === "string")
          return `${d?.shortLabel ?? "\u05E7\u05E6\u05E8"} \u05DE\u05D3\u05D9: ${m} \u05E6\u05E8\u05D9\u05DB\u05D4 \u05DC\u05D4\u05DB\u05D9\u05DC ${l.minimum.toString()} ${d?.unit ?? ""} ${l.inclusive ? "\u05D0\u05D5 \u05D9\u05D5\u05EA\u05E8" : "\u05DC\u05E4\u05D7\u05D5\u05EA"}`.trim();
        if (l.origin === "number") {
          let z = l.inclusive ? `\u05D2\u05D3\u05D5\u05DC \u05D0\u05D5 \u05E9\u05D5\u05D5\u05D4 \u05DC-${l.minimum}` : `\u05D2\u05D3\u05D5\u05DC \u05DE-${l.minimum}`;
          return `\u05E7\u05D8\u05DF \u05DE\u05D3\u05D9: ${m} \u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA ${z}`;
        }
        if (l.origin === "array" || l.origin === "set") {
          let z = l.origin === "set" ? "\u05E6\u05E8\u05D9\u05DB\u05D4" : "\u05E6\u05E8\u05D9\u05DA";
          if (l.minimum === 1 && l.inclusive) {
            let T = (l.origin === "set", "\u05DC\u05E4\u05D7\u05D5\u05EA \u05E4\u05E8\u05D9\u05D8 \u05D0\u05D7\u05D3");
            return `\u05E7\u05D8\u05DF \u05DE\u05D3\u05D9: ${m} ${z} \u05DC\u05D4\u05DB\u05D9\u05DC ${T}`;
          }
          let D = l.inclusive ? `${l.minimum} ${d?.unit ?? ""} \u05D0\u05D5 \u05D9\u05D5\u05EA\u05E8` : `\u05D9\u05D5\u05EA\u05E8 \u05DE-${l.minimum} ${d?.unit ?? ""}`;
          return `\u05E7\u05D8\u05DF \u05DE\u05D3\u05D9: ${m} ${z} \u05DC\u05D4\u05DB\u05D9\u05DC ${D}`.trim();
        }
        let y = l.inclusive ? ">=" : ">", h = o(l.origin ?? "value");
        return d?.unit ? `${d.shortLabel} \u05DE\u05D3\u05D9: ${m} ${h} ${y}${l.minimum.toString()} ${d.unit}` : `${d?.shortLabel ?? "\u05E7\u05D8\u05DF"} \u05DE\u05D3\u05D9: ${m} ${h} ${y}${l.minimum.toString()}`;
      }
      case "invalid_format": {
        let d = l;
        if (d.format === "starts_with")
          return `\u05D4\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D7\u05D9\u05D9\u05D1\u05EA \u05DC\u05D4\u05EA\u05D7\u05D9\u05DC \u05D1 "${d.prefix}"`;
        if (d.format === "ends_with")
          return `\u05D4\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D7\u05D9\u05D9\u05D1\u05EA \u05DC\u05D4\u05E1\u05EA\u05D9\u05D9\u05DD \u05D1 "${d.suffix}"`;
        if (d.format === "includes")
          return `\u05D4\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D7\u05D9\u05D9\u05D1\u05EA \u05DC\u05DB\u05DC\u05D5\u05DC "${d.includes}"`;
        if (d.format === "regex")
          return `\u05D4\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D7\u05D9\u05D9\u05D1\u05EA \u05DC\u05D4\u05EA\u05D0\u05D9\u05DD \u05DC\u05EA\u05D1\u05E0\u05D9\u05EA ${d.pattern}`;
        let m = c[d.format], y = m?.label ?? d.format, z = (m?.gender ?? "m") === "f" ? "\u05EA\u05E7\u05D9\u05E0\u05D4" : "\u05EA\u05E7\u05D9\u05DF";
        return `${y} \u05DC\u05D0 ${z}`;
      }
      case "not_multiple_of":
        return `\u05DE\u05E1\u05E4\u05E8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05D7\u05D9\u05D9\u05D1 \u05DC\u05D4\u05D9\u05D5\u05EA \u05DE\u05DB\u05E4\u05DC\u05D4 \u05E9\u05DC ${l.divisor}`;
      case "unrecognized_keys":
        return `\u05DE\u05E4\u05EA\u05D7${l.keys.length > 1 ? "\u05D5\u05EA" : ""} \u05DC\u05D0 \u05DE\u05D6\u05D5\u05D4${l.keys.length > 1 ? "\u05D9\u05DD" : "\u05D4"}: ${p(l.keys, ", ")}`;
      case "invalid_key":
        return "\u05E9\u05D3\u05D4 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF \u05D1\u05D0\u05D5\u05D1\u05D9\u05D9\u05E7\u05D8";
      case "invalid_union":
        return "\u05E7\u05DC\u05D8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF";
      case "invalid_element":
        return `\u05E2\u05E8\u05DA \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF \u05D1${r(l.origin ?? "array")}`;
      default:
        return "\u05E7\u05DC\u05D8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF";
    }
  };
}, "error");
function bc() {
  return {
    localeError: ey()
  };
}
s(bc, "default");

// versions/4.4.3/node_modules/zod/v4/locales/hr.js
var ty = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "znakova", verb: "imati" },
    file: { unit: "bajtova", verb: "imati" },
    array: { unit: "stavki", verb: "imati" },
    set: { unit: "stavki", verb: "imati" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "unos",
    email: "email adresa",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datum i vrijeme",
    date: "ISO datum",
    time: "ISO vrijeme",
    duration: "ISO trajanje",
    ipv4: "IPv4 adresa",
    ipv6: "IPv6 adresa",
    cidrv4: "IPv4 raspon",
    cidrv6: "IPv6 raspon",
    base64: "base64 kodirani tekst",
    base64url: "base64url kodirani tekst",
    json_string: "JSON tekst",
    e164: "E.164 broj",
    jwt: "JWT",
    template_literal: "unos"
  }, i = {
    nan: "NaN",
    string: "tekst",
    number: "broj",
    boolean: "boolean",
    array: "niz",
    object: "objekt",
    set: "skup",
    file: "datoteka",
    date: "datum",
    bigint: "bigint",
    symbol: "simbol",
    undefined: "undefined",
    null: "null",
    function: "funkcija",
    map: "mapa"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Neispravan unos: o\u010Dekuje se instanceof ${r.expected}, a primljeno je ${c}` : `Neispravan unos: o\u010Dekuje se ${o}, a primljeno je ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Neispravna vrijednost: o\u010Dekivano ${v(r.values[0])}` : `Neispravna opcija: o\u010Dekivano jedno od ${p(r.values, "|")}`;
      case "too_big": {
        let o = r.inclusive ? "<=" : "<", a = t(r.origin), c = i[r.origin] ?? r.origin;
        return a ? `Preveliko: o\u010Dekivano da ${c ?? "vrijednost"} ima ${o}${r.maximum.toString()} ${a.unit ?? "elemenata"}` : `Preveliko: o\u010Dekivano da ${c ?? "vrijednost"} bude ${o}${r.maximum.toString()}`;
      }
      case "too_small": {
        let o = r.inclusive ? ">=" : ">", a = t(r.origin), c = i[r.origin] ?? r.origin;
        return a ? `Premalo: o\u010Dekivano da ${c} ima ${o}${r.minimum.toString()} ${a.unit}` : `Premalo: o\u010Dekivano da ${c} bude ${o}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `Neispravan tekst: mora zapo\u010Dinjati s "${o.prefix}"` : o.format === "ends_with" ? `Neispravan tekst: mora zavr\u0161avati s "${o.suffix}"` : o.format === "includes" ? `Neispravan tekst: mora sadr\u017Eavati "${o.includes}"` : o.format === "regex" ? `Neispravan tekst: mora odgovarati uzorku ${o.pattern}` : `Neispravna ${n[o.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Neispravan broj: mora biti vi\u0161ekratnik od ${r.divisor}`;
      case "unrecognized_keys":
        return `Neprepoznat${r.keys.length > 1 ? "i klju\u010Devi" : " klju\u010D"}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Neispravan klju\u010D u ${i[r.origin] ?? r.origin}`;
      case "invalid_union":
        return "Neispravan unos";
      case "invalid_element":
        return `Neispravna vrijednost u ${i[r.origin] ?? r.origin}`;
      default:
        return "Neispravan unos";
    }
  };
}, "error");
function $c() {
  return {
    localeError: ty()
  };
}
s($c, "default");

// versions/4.4.3/node_modules/zod/v4/locales/hu.js
var ry = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "karakter", verb: "legyen" },
    file: { unit: "byte", verb: "legyen" },
    array: { unit: "elem", verb: "legyen" },
    set: { unit: "elem", verb: "legyen" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "bemenet",
    email: "email c\xEDm",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO id\u0151b\xE9lyeg",
    date: "ISO d\xE1tum",
    time: "ISO id\u0151",
    duration: "ISO id\u0151intervallum",
    ipv4: "IPv4 c\xEDm",
    ipv6: "IPv6 c\xEDm",
    cidrv4: "IPv4 tartom\xE1ny",
    cidrv6: "IPv6 tartom\xE1ny",
    base64: "base64-k\xF3dolt string",
    base64url: "base64url-k\xF3dolt string",
    json_string: "JSON string",
    e164: "E.164 sz\xE1m",
    jwt: "JWT",
    template_literal: "bemenet"
  }, i = {
    nan: "NaN",
    number: "sz\xE1m",
    array: "t\xF6mb"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\xC9rv\xE9nytelen bemenet: a v\xE1rt \xE9rt\xE9k instanceof ${r.expected}, a kapott \xE9rt\xE9k ${c}` : `\xC9rv\xE9nytelen bemenet: a v\xE1rt \xE9rt\xE9k ${o}, a kapott \xE9rt\xE9k ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\xC9rv\xE9nytelen bemenet: a v\xE1rt \xE9rt\xE9k ${v(r.values[0])}` : `\xC9rv\xE9nytelen opci\xF3: valamelyik \xE9rt\xE9k v\xE1rt ${p(r.values, "|")}`;
      case "too_big": {
        let o = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `T\xFAl nagy: ${r.origin ?? "\xE9rt\xE9k"} m\xE9rete t\xFAl nagy ${o}${r.maximum.toString()} ${a.unit ?? "elem"}` : `T\xFAl nagy: a bemeneti \xE9rt\xE9k ${r.origin ?? "\xE9rt\xE9k"} t\xFAl nagy: ${o}${r.maximum.toString()}`;
      }
      case "too_small": {
        let o = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `T\xFAl kicsi: a bemeneti \xE9rt\xE9k ${r.origin} m\xE9rete t\xFAl kicsi ${o}${r.minimum.toString()} ${a.unit}` : `T\xFAl kicsi: a bemeneti \xE9rt\xE9k ${r.origin} t\xFAl kicsi ${o}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `\xC9rv\xE9nytelen string: "${o.prefix}" \xE9rt\xE9kkel kell kezd\u0151dnie` : o.format === "ends_with" ? `\xC9rv\xE9nytelen string: "${o.suffix}" \xE9rt\xE9kkel kell v\xE9gz\u0151dnie` : o.format === "includes" ? `\xC9rv\xE9nytelen string: "${o.includes}" \xE9rt\xE9ket kell tartalmaznia` : o.format === "regex" ? `\xC9rv\xE9nytelen string: ${o.pattern} mint\xE1nak kell megfelelnie` : `\xC9rv\xE9nytelen ${n[o.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\xC9rv\xE9nytelen sz\xE1m: ${r.divisor} t\xF6bbsz\xF6r\xF6s\xE9nek kell lennie`;
      case "unrecognized_keys":
        return `Ismeretlen kulcs${r.keys.length > 1 ? "s" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `\xC9rv\xE9nytelen kulcs ${r.origin}`;
      case "invalid_union":
        return "\xC9rv\xE9nytelen bemenet";
      case "invalid_element":
        return `\xC9rv\xE9nytelen \xE9rt\xE9k: ${r.origin}`;
      default:
        return "\xC9rv\xE9nytelen bemenet";
    }
  };
}, "error");
function xc() {
  return {
    localeError: ry()
  };
}
s(xc, "default");

// versions/4.4.3/node_modules/zod/v4/locales/hy.js
function ap(e, t, n) {
  return Math.abs(e) === 1 ? t : n;
}
s(ap, "getArmenianPlural");
function Ct(e) {
  if (!e)
    return "";
  let t = ["\u0561", "\u0565", "\u0568", "\u056B", "\u0578", "\u0578\u0582", "\u0585"], n = e[e.length - 1];
  return e + (t.includes(n) ? "\u0576" : "\u0568");
}
s(Ct, "withDefiniteArticle");
var ny = /* @__PURE__ */ s(() => {
  let e = {
    string: {
      unit: {
        one: "\u0576\u0577\u0561\u0576",
        many: "\u0576\u0577\u0561\u0576\u0576\u0565\u0580"
      },
      verb: "\u0578\u0582\u0576\u0565\u0576\u0561\u056C"
    },
    file: {
      unit: {
        one: "\u0562\u0561\u0575\u0569",
        many: "\u0562\u0561\u0575\u0569\u0565\u0580"
      },
      verb: "\u0578\u0582\u0576\u0565\u0576\u0561\u056C"
    },
    array: {
      unit: {
        one: "\u057F\u0561\u0580\u0580",
        many: "\u057F\u0561\u0580\u0580\u0565\u0580"
      },
      verb: "\u0578\u0582\u0576\u0565\u0576\u0561\u056C"
    },
    set: {
      unit: {
        one: "\u057F\u0561\u0580\u0580",
        many: "\u057F\u0561\u0580\u0580\u0565\u0580"
      },
      verb: "\u0578\u0582\u0576\u0565\u0576\u0561\u056C"
    }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u0574\u0578\u0582\u057F\u0584",
    email: "\u0567\u056C. \u0570\u0561\u057D\u0581\u0565",
    url: "URL",
    emoji: "\u0567\u0574\u0578\u057B\u056B",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0561\u0574\u057D\u0561\u0569\u056B\u057E \u0587 \u056A\u0561\u0574",
    date: "ISO \u0561\u0574\u057D\u0561\u0569\u056B\u057E",
    time: "ISO \u056A\u0561\u0574",
    duration: "ISO \u057F\u0587\u0578\u0572\u0578\u0582\u0569\u0575\u0578\u0582\u0576",
    ipv4: "IPv4 \u0570\u0561\u057D\u0581\u0565",
    ipv6: "IPv6 \u0570\u0561\u057D\u0581\u0565",
    cidrv4: "IPv4 \u0574\u056B\u057B\u0561\u056F\u0561\u0575\u0584",
    cidrv6: "IPv6 \u0574\u056B\u057B\u0561\u056F\u0561\u0575\u0584",
    base64: "base64 \u0571\u0587\u0561\u0579\u0561\u0583\u0578\u057E \u057F\u0578\u0572",
    base64url: "base64url \u0571\u0587\u0561\u0579\u0561\u0583\u0578\u057E \u057F\u0578\u0572",
    json_string: "JSON \u057F\u0578\u0572",
    e164: "E.164 \u0570\u0561\u0574\u0561\u0580",
    jwt: "JWT",
    template_literal: "\u0574\u0578\u0582\u057F\u0584"
  }, i = {
    nan: "NaN",
    number: "\u0569\u056B\u057E",
    array: "\u0566\u0561\u0576\u0563\u057E\u0561\u056E"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567\u0580 instanceof ${r.expected}, \u057D\u057F\u0561\u0581\u057E\u0565\u056C \u0567 ${c}` : `\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567\u0580 ${o}, \u057D\u057F\u0561\u0581\u057E\u0565\u056C \u0567 ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567\u0580 ${v(r.values[1])}` : `\u054D\u056D\u0561\u056C \u057F\u0561\u0580\u0562\u0565\u0580\u0561\u056F\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567\u0580 \u0570\u0565\u057F\u0587\u0575\u0561\u056C\u0576\u0565\u0580\u056B\u0581 \u0574\u0565\u056F\u0568\u055D ${p(r.values, "|")}`;
      case "too_big": {
        let o = r.inclusive ? "<=" : "<", a = t(r.origin);
        if (a) {
          let c = Number(r.maximum), u = ap(c, a.unit.one, a.unit.many);
          return `\u0549\u0561\u0583\u0561\u0566\u0561\u0576\u0581 \u0574\u0565\u056E \u0561\u0580\u056A\u0565\u0584\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567, \u0578\u0580 ${Ct(r.origin ?? "\u0561\u0580\u056A\u0565\u0584")} \u056F\u0578\u0582\u0576\u0565\u0576\u0561 ${o}${r.maximum.toString()} ${u}`;
        }
        return `\u0549\u0561\u0583\u0561\u0566\u0561\u0576\u0581 \u0574\u0565\u056E \u0561\u0580\u056A\u0565\u0584\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567, \u0578\u0580 ${Ct(r.origin ?? "\u0561\u0580\u056A\u0565\u0584")} \u056C\u056B\u0576\u056B ${o}${r.maximum.toString()}`;
      }
      case "too_small": {
        let o = r.inclusive ? ">=" : ">", a = t(r.origin);
        if (a) {
          let c = Number(r.minimum), u = ap(c, a.unit.one, a.unit.many);
          return `\u0549\u0561\u0583\u0561\u0566\u0561\u0576\u0581 \u0583\u0578\u0584\u0580 \u0561\u0580\u056A\u0565\u0584\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567, \u0578\u0580 ${Ct(r.origin)} \u056F\u0578\u0582\u0576\u0565\u0576\u0561 ${o}${r.minimum.toString()} ${u}`;
        }
        return `\u0549\u0561\u0583\u0561\u0566\u0561\u0576\u0581 \u0583\u0578\u0584\u0580 \u0561\u0580\u056A\u0565\u0584\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567, \u0578\u0580 ${Ct(r.origin)} \u056C\u056B\u0576\u056B ${o}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `\u054D\u056D\u0561\u056C \u057F\u0578\u0572\u2024 \u057A\u0565\u057F\u0584 \u0567 \u057D\u056F\u057D\u057E\u056B "${o.prefix}"-\u0578\u057E` : o.format === "ends_with" ? `\u054D\u056D\u0561\u056C \u057F\u0578\u0572\u2024 \u057A\u0565\u057F\u0584 \u0567 \u0561\u057E\u0561\u0580\u057F\u057E\u056B "${o.suffix}"-\u0578\u057E` : o.format === "includes" ? `\u054D\u056D\u0561\u056C \u057F\u0578\u0572\u2024 \u057A\u0565\u057F\u0584 \u0567 \u057A\u0561\u0580\u0578\u0582\u0576\u0561\u056F\u056B "${o.includes}"` : o.format === "regex" ? `\u054D\u056D\u0561\u056C \u057F\u0578\u0572\u2024 \u057A\u0565\u057F\u0584 \u0567 \u0570\u0561\u0574\u0561\u057A\u0561\u057F\u0561\u057D\u056D\u0561\u0576\u056B ${o.pattern} \u0571\u0587\u0561\u0579\u0561\u0583\u056B\u0576` : `\u054D\u056D\u0561\u056C ${n[o.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u054D\u056D\u0561\u056C \u0569\u056B\u057E\u2024 \u057A\u0565\u057F\u0584 \u0567 \u0562\u0561\u0566\u0574\u0561\u057A\u0561\u057F\u056B\u056F \u056C\u056B\u0576\u056B ${r.divisor}-\u056B`;
      case "unrecognized_keys":
        return `\u0549\u0573\u0561\u0576\u0561\u0579\u057E\u0561\u056E \u0562\u0561\u0576\u0561\u056C\u056B${r.keys.length > 1 ? "\u0576\u0565\u0580" : ""}. ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `\u054D\u056D\u0561\u056C \u0562\u0561\u0576\u0561\u056C\u056B ${Ct(r.origin)}-\u0578\u0582\u0574`;
      case "invalid_union":
        return "\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574";
      case "invalid_element":
        return `\u054D\u056D\u0561\u056C \u0561\u0580\u056A\u0565\u0584 ${Ct(r.origin)}-\u0578\u0582\u0574`;
      default:
        return "\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574";
    }
  };
}, "error");
function _c() {
  return {
    localeError: ny()
  };
}
s(_c, "default");

// versions/4.4.3/node_modules/zod/v4/locales/id.js
var iy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "karakter", verb: "memiliki" },
    file: { unit: "byte", verb: "memiliki" },
    array: { unit: "item", verb: "memiliki" },
    set: { unit: "item", verb: "memiliki" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "input",
    email: "alamat email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "tanggal dan waktu format ISO",
    date: "tanggal format ISO",
    time: "jam format ISO",
    duration: "durasi format ISO",
    ipv4: "alamat IPv4",
    ipv6: "alamat IPv6",
    cidrv4: "rentang alamat IPv4",
    cidrv6: "rentang alamat IPv6",
    base64: "string dengan enkode base64",
    base64url: "string dengan enkode base64url",
    json_string: "string JSON",
    e164: "angka E.164",
    jwt: "JWT",
    template_literal: "input"
  }, i = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Input tidak valid: diharapkan instanceof ${r.expected}, diterima ${c}` : `Input tidak valid: diharapkan ${o}, diterima ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Input tidak valid: diharapkan ${v(r.values[0])}` : `Pilihan tidak valid: diharapkan salah satu dari ${p(r.values, "|")}`;
      case "too_big": {
        let o = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Terlalu besar: diharapkan ${r.origin ?? "value"} memiliki ${o}${r.maximum.toString()} ${a.unit ?? "elemen"}` : `Terlalu besar: diharapkan ${r.origin ?? "value"} menjadi ${o}${r.maximum.toString()}`;
      }
      case "too_small": {
        let o = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Terlalu kecil: diharapkan ${r.origin} memiliki ${o}${r.minimum.toString()} ${a.unit}` : `Terlalu kecil: diharapkan ${r.origin} menjadi ${o}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `String tidak valid: harus dimulai dengan "${o.prefix}"` : o.format === "ends_with" ? `String tidak valid: harus berakhir dengan "${o.suffix}"` : o.format === "includes" ? `String tidak valid: harus menyertakan "${o.includes}"` : o.format === "regex" ? `String tidak valid: harus sesuai pola ${o.pattern}` : `${n[o.format] ?? r.format} tidak valid`;
      }
      case "not_multiple_of":
        return `Angka tidak valid: harus kelipatan dari ${r.divisor}`;
      case "unrecognized_keys":
        return `Kunci tidak dikenali ${r.keys.length > 1 ? "s" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Kunci tidak valid di ${r.origin}`;
      case "invalid_union":
        return "Input tidak valid";
      case "invalid_element":
        return `Nilai tidak valid di ${r.origin}`;
      default:
        return "Input tidak valid";
    }
  };
}, "error");
function wc() {
  return {
    localeError: iy()
  };
}
s(wc, "default");

// versions/4.4.3/node_modules/zod/v4/locales/is.js
var oy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "stafi", verb: "a\xF0 hafa" },
    file: { unit: "b\xE6ti", verb: "a\xF0 hafa" },
    array: { unit: "hluti", verb: "a\xF0 hafa" },
    set: { unit: "hluti", verb: "a\xF0 hafa" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "gildi",
    email: "netfang",
    url: "vefsl\xF3\xF0",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO dagsetning og t\xEDmi",
    date: "ISO dagsetning",
    time: "ISO t\xEDmi",
    duration: "ISO t\xEDmalengd",
    ipv4: "IPv4 address",
    ipv6: "IPv6 address",
    cidrv4: "IPv4 range",
    cidrv6: "IPv6 range",
    base64: "base64-encoded strengur",
    base64url: "base64url-encoded strengur",
    json_string: "JSON strengur",
    e164: "E.164 t\xF6lugildi",
    jwt: "JWT",
    template_literal: "gildi"
  }, i = {
    nan: "NaN",
    number: "n\xFAmer",
    array: "fylki"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Rangt gildi: \xDE\xFA sl\xF3st inn ${c} \xFEar sem \xE1 a\xF0 vera instanceof ${r.expected}` : `Rangt gildi: \xDE\xFA sl\xF3st inn ${c} \xFEar sem \xE1 a\xF0 vera ${o}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Rangt gildi: gert r\xE1\xF0 fyrir ${v(r.values[0])}` : `\xD3gilt val: m\xE1 vera eitt af eftirfarandi ${p(r.values, "|")}`;
      case "too_big": {
        let o = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Of st\xF3rt: gert er r\xE1\xF0 fyrir a\xF0 ${r.origin ?? "gildi"} hafi ${o}${r.maximum.toString()} ${a.unit ?? "hluti"}` : `Of st\xF3rt: gert er r\xE1\xF0 fyrir a\xF0 ${r.origin ?? "gildi"} s\xE9 ${o}${r.maximum.toString()}`;
      }
      case "too_small": {
        let o = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Of l\xEDti\xF0: gert er r\xE1\xF0 fyrir a\xF0 ${r.origin} hafi ${o}${r.minimum.toString()} ${a.unit}` : `Of l\xEDti\xF0: gert er r\xE1\xF0 fyrir a\xF0 ${r.origin} s\xE9 ${o}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `\xD3gildur strengur: ver\xF0ur a\xF0 byrja \xE1 "${o.prefix}"` : o.format === "ends_with" ? `\xD3gildur strengur: ver\xF0ur a\xF0 enda \xE1 "${o.suffix}"` : o.format === "includes" ? `\xD3gildur strengur: ver\xF0ur a\xF0 innihalda "${o.includes}"` : o.format === "regex" ? `\xD3gildur strengur: ver\xF0ur a\xF0 fylgja mynstri ${o.pattern}` : `Rangt ${n[o.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `R\xF6ng tala: ver\xF0ur a\xF0 vera margfeldi af ${r.divisor}`;
      case "unrecognized_keys":
        return `\xD3\xFEekkt ${r.keys.length > 1 ? "ir lyklar" : "ur lykill"}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Rangur lykill \xED ${r.origin}`;
      case "invalid_union":
        return "Rangt gildi";
      case "invalid_element":
        return `Rangt gildi \xED ${r.origin}`;
      default:
        return "Rangt gildi";
    }
  };
}, "error");
function kc() {
  return {
    localeError: oy()
  };
}
s(kc, "default");

// versions/4.4.3/node_modules/zod/v4/locales/it.js
var ay = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "caratteri", verb: "avere" },
    file: { unit: "byte", verb: "avere" },
    array: { unit: "elementi", verb: "avere" },
    set: { unit: "elementi", verb: "avere" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "input",
    email: "indirizzo email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "data e ora ISO",
    date: "data ISO",
    time: "ora ISO",
    duration: "durata ISO",
    ipv4: "indirizzo IPv4",
    ipv6: "indirizzo IPv6",
    cidrv4: "intervallo IPv4",
    cidrv6: "intervallo IPv6",
    base64: "stringa codificata in base64",
    base64url: "URL codificata in base64",
    json_string: "stringa JSON",
    e164: "numero E.164",
    jwt: "JWT",
    template_literal: "input"
  }, i = {
    nan: "NaN",
    number: "numero",
    array: "vettore"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Input non valido: atteso instanceof ${r.expected}, ricevuto ${c}` : `Input non valido: atteso ${o}, ricevuto ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Input non valido: atteso ${v(r.values[0])}` : `Opzione non valida: atteso uno tra ${p(r.values, "|")}`;
      case "too_big": {
        let o = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Troppo grande: ${r.origin ?? "valore"} deve avere ${o}${r.maximum.toString()} ${a.unit ?? "elementi"}` : `Troppo grande: ${r.origin ?? "valore"} deve essere ${o}${r.maximum.toString()}`;
      }
      case "too_small": {
        let o = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Troppo piccolo: ${r.origin} deve avere ${o}${r.minimum.toString()} ${a.unit}` : `Troppo piccolo: ${r.origin} deve essere ${o}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `Stringa non valida: deve iniziare con "${o.prefix}"` : o.format === "ends_with" ? `Stringa non valida: deve terminare con "${o.suffix}"` : o.format === "includes" ? `Stringa non valida: deve includere "${o.includes}"` : o.format === "regex" ? `Stringa non valida: deve corrispondere al pattern ${o.pattern}` : `Input non valido: ${n[o.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Numero non valido: deve essere un multiplo di ${r.divisor}`;
      case "unrecognized_keys":
        return `Chiav${r.keys.length > 1 ? "i" : "e"} non riconosciut${r.keys.length > 1 ? "e" : "a"}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Chiave non valida in ${r.origin}`;
      case "invalid_union":
        return "Input non valido";
      case "invalid_element":
        return `Valore non valido in ${r.origin}`;
      default:
        return "Input non valido";
    }
  };
}, "error");
function zc() {
  return {
    localeError: ay()
  };
}
s(zc, "default");

// versions/4.4.3/node_modules/zod/v4/locales/ja.js
var sy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u6587\u5B57", verb: "\u3067\u3042\u308B" },
    file: { unit: "\u30D0\u30A4\u30C8", verb: "\u3067\u3042\u308B" },
    array: { unit: "\u8981\u7D20", verb: "\u3067\u3042\u308B" },
    set: { unit: "\u8981\u7D20", verb: "\u3067\u3042\u308B" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u5165\u529B\u5024",
    email: "\u30E1\u30FC\u30EB\u30A2\u30C9\u30EC\u30B9",
    url: "URL",
    emoji: "\u7D75\u6587\u5B57",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO\u65E5\u6642",
    date: "ISO\u65E5\u4ED8",
    time: "ISO\u6642\u523B",
    duration: "ISO\u671F\u9593",
    ipv4: "IPv4\u30A2\u30C9\u30EC\u30B9",
    ipv6: "IPv6\u30A2\u30C9\u30EC\u30B9",
    cidrv4: "IPv4\u7BC4\u56F2",
    cidrv6: "IPv6\u7BC4\u56F2",
    base64: "base64\u30A8\u30F3\u30B3\u30FC\u30C9\u6587\u5B57\u5217",
    base64url: "base64url\u30A8\u30F3\u30B3\u30FC\u30C9\u6587\u5B57\u5217",
    json_string: "JSON\u6587\u5B57\u5217",
    e164: "E.164\u756A\u53F7",
    jwt: "JWT",
    template_literal: "\u5165\u529B\u5024"
  }, i = {
    nan: "NaN",
    number: "\u6570\u5024",
    array: "\u914D\u5217"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u7121\u52B9\u306A\u5165\u529B: instanceof ${r.expected}\u304C\u671F\u5F85\u3055\u308C\u307E\u3057\u305F\u304C\u3001${c}\u304C\u5165\u529B\u3055\u308C\u307E\u3057\u305F` : `\u7121\u52B9\u306A\u5165\u529B: ${o}\u304C\u671F\u5F85\u3055\u308C\u307E\u3057\u305F\u304C\u3001${c}\u304C\u5165\u529B\u3055\u308C\u307E\u3057\u305F`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u7121\u52B9\u306A\u5165\u529B: ${v(r.values[0])}\u304C\u671F\u5F85\u3055\u308C\u307E\u3057\u305F` : `\u7121\u52B9\u306A\u9078\u629E: ${p(r.values, "\u3001")}\u306E\u3044\u305A\u308C\u304B\u3067\u3042\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`;
      case "too_big": {
        let o = r.inclusive ? "\u4EE5\u4E0B\u3067\u3042\u308B" : "\u3088\u308A\u5C0F\u3055\u3044", a = t(r.origin);
        return a ? `\u5927\u304D\u3059\u304E\u308B\u5024: ${r.origin ?? "\u5024"}\u306F${r.maximum.toString()}${a.unit ?? "\u8981\u7D20"}${o}\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : `\u5927\u304D\u3059\u304E\u308B\u5024: ${r.origin ?? "\u5024"}\u306F${r.maximum.toString()}${o}\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`;
      }
      case "too_small": {
        let o = r.inclusive ? "\u4EE5\u4E0A\u3067\u3042\u308B" : "\u3088\u308A\u5927\u304D\u3044", a = t(r.origin);
        return a ? `\u5C0F\u3055\u3059\u304E\u308B\u5024: ${r.origin}\u306F${r.minimum.toString()}${a.unit}${o}\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : `\u5C0F\u3055\u3059\u304E\u308B\u5024: ${r.origin}\u306F${r.minimum.toString()}${o}\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `\u7121\u52B9\u306A\u6587\u5B57\u5217: "${o.prefix}"\u3067\u59CB\u307E\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : o.format === "ends_with" ? `\u7121\u52B9\u306A\u6587\u5B57\u5217: "${o.suffix}"\u3067\u7D42\u308F\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : o.format === "includes" ? `\u7121\u52B9\u306A\u6587\u5B57\u5217: "${o.includes}"\u3092\u542B\u3080\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : o.format === "regex" ? `\u7121\u52B9\u306A\u6587\u5B57\u5217: \u30D1\u30BF\u30FC\u30F3${o.pattern}\u306B\u4E00\u81F4\u3059\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : `\u7121\u52B9\u306A${n[o.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u7121\u52B9\u306A\u6570\u5024: ${r.divisor}\u306E\u500D\u6570\u3067\u3042\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`;
      case "unrecognized_keys":
        return `\u8A8D\u8B58\u3055\u308C\u3066\u3044\u306A\u3044\u30AD\u30FC${r.keys.length > 1 ? "\u7FA4" : ""}: ${p(r.keys, "\u3001")}`;
      case "invalid_key":
        return `${r.origin}\u5185\u306E\u7121\u52B9\u306A\u30AD\u30FC`;
      case "invalid_union":
        return "\u7121\u52B9\u306A\u5165\u529B";
      case "invalid_element":
        return `${r.origin}\u5185\u306E\u7121\u52B9\u306A\u5024`;
      default:
        return "\u7121\u52B9\u306A\u5165\u529B";
    }
  };
}, "error");
function Ic() {
  return {
    localeError: sy()
  };
}
s(Ic, "default");

// versions/4.4.3/node_modules/zod/v4/locales/ka.js
var cy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u10E1\u10D8\u10DB\u10D1\u10DD\u10DA\u10DD", verb: "\u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1" },
    file: { unit: "\u10D1\u10D0\u10D8\u10E2\u10D8", verb: "\u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1" },
    array: { unit: "\u10D4\u10DA\u10D4\u10DB\u10D4\u10DC\u10E2\u10D8", verb: "\u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1" },
    set: { unit: "\u10D4\u10DA\u10D4\u10DB\u10D4\u10DC\u10E2\u10D8", verb: "\u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0",
    email: "\u10D4\u10DA-\u10E4\u10DD\u10E1\u10E2\u10D8\u10E1 \u10DB\u10D8\u10E1\u10D0\u10DB\u10D0\u10E0\u10D7\u10D8",
    url: "URL",
    emoji: "\u10D4\u10DB\u10DD\u10EF\u10D8",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u10D7\u10D0\u10E0\u10D8\u10E6\u10D8-\u10D3\u10E0\u10DD",
    date: "\u10D7\u10D0\u10E0\u10D8\u10E6\u10D8",
    time: "\u10D3\u10E0\u10DD",
    duration: "\u10EE\u10D0\u10DC\u10D2\u10E0\u10EB\u10DA\u10D8\u10D5\u10DD\u10D1\u10D0",
    ipv4: "IPv4 \u10DB\u10D8\u10E1\u10D0\u10DB\u10D0\u10E0\u10D7\u10D8",
    ipv6: "IPv6 \u10DB\u10D8\u10E1\u10D0\u10DB\u10D0\u10E0\u10D7\u10D8",
    cidrv4: "IPv4 \u10D3\u10D8\u10D0\u10DE\u10D0\u10D6\u10DD\u10DC\u10D8",
    cidrv6: "IPv6 \u10D3\u10D8\u10D0\u10DE\u10D0\u10D6\u10DD\u10DC\u10D8",
    base64: "base64-\u10D9\u10DD\u10D3\u10D8\u10E0\u10D4\u10D1\u10E3\u10DA\u10D8 \u10D5\u10D4\u10DA\u10D8",
    base64url: "base64url-\u10D9\u10DD\u10D3\u10D8\u10E0\u10D4\u10D1\u10E3\u10DA\u10D8 \u10D5\u10D4\u10DA\u10D8",
    json_string: "JSON \u10D5\u10D4\u10DA\u10D8",
    e164: "E.164 \u10DC\u10DD\u10DB\u10D4\u10E0\u10D8",
    jwt: "JWT",
    template_literal: "\u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0"
  }, i = {
    nan: "NaN",
    number: "\u10E0\u10D8\u10EA\u10EE\u10D5\u10D8",
    string: "\u10D5\u10D4\u10DA\u10D8",
    boolean: "\u10D1\u10E3\u10DA\u10D4\u10D0\u10DC\u10D8",
    function: "\u10E4\u10E3\u10DC\u10E5\u10EA\u10D8\u10D0",
    array: "\u10DB\u10D0\u10E1\u10D8\u10D5\u10D8"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 instanceof ${r.expected}, \u10DB\u10D8\u10E6\u10D4\u10D1\u10E3\u10DA\u10D8 ${c}` : `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${o}, \u10DB\u10D8\u10E6\u10D4\u10D1\u10E3\u10DA\u10D8 ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${v(r.values[0])}` : `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D5\u10D0\u10E0\u10D8\u10D0\u10DC\u10E2\u10D8: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8\u10D0 \u10D4\u10E0\u10D7-\u10D4\u10E0\u10D7\u10D8 ${p(r.values, "|")}-\u10D3\u10D0\u10DC`;
      case "too_big": {
        let o = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `\u10D6\u10D4\u10D3\u10DB\u10D4\u10E2\u10D0\u10D3 \u10D3\u10D8\u10D3\u10D8: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${r.origin ?? "\u10DB\u10DC\u10D8\u10E8\u10D5\u10DC\u10D4\u10DA\u10DD\u10D1\u10D0"} ${a.verb} ${o}${r.maximum.toString()} ${a.unit}` : `\u10D6\u10D4\u10D3\u10DB\u10D4\u10E2\u10D0\u10D3 \u10D3\u10D8\u10D3\u10D8: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${r.origin ?? "\u10DB\u10DC\u10D8\u10E8\u10D5\u10DC\u10D4\u10DA\u10DD\u10D1\u10D0"} \u10D8\u10E7\u10DD\u10E1 ${o}${r.maximum.toString()}`;
      }
      case "too_small": {
        let o = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\u10D6\u10D4\u10D3\u10DB\u10D4\u10E2\u10D0\u10D3 \u10DE\u10D0\u10E2\u10D0\u10E0\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${r.origin} ${a.verb} ${o}${r.minimum.toString()} ${a.unit}` : `\u10D6\u10D4\u10D3\u10DB\u10D4\u10E2\u10D0\u10D3 \u10DE\u10D0\u10E2\u10D0\u10E0\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${r.origin} \u10D8\u10E7\u10DD\u10E1 ${o}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D5\u10D4\u10DA\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10D8\u10EC\u10E7\u10D4\u10D1\u10DD\u10D3\u10D4\u10E1 "${o.prefix}"-\u10D8\u10D7` : o.format === "ends_with" ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D5\u10D4\u10DA\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10DB\u10D7\u10D0\u10D5\u10E0\u10D3\u10D4\u10D1\u10DD\u10D3\u10D4\u10E1 "${o.suffix}"-\u10D8\u10D7` : o.format === "includes" ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D5\u10D4\u10DA\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1 "${o.includes}"-\u10E1` : o.format === "regex" ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D5\u10D4\u10DA\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D4\u10E1\u10D0\u10D1\u10D0\u10DB\u10D4\u10D1\u10DD\u10D3\u10D4\u10E1 \u10E8\u10D0\u10D1\u10DA\u10DD\u10DC\u10E1 ${o.pattern}` : `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 ${n[o.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E0\u10D8\u10EA\u10EE\u10D5\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10D8\u10E7\u10DD\u10E1 ${r.divisor}-\u10D8\u10E1 \u10EF\u10D4\u10E0\u10D0\u10D3\u10D8`;
      case "unrecognized_keys":
        return `\u10E3\u10EA\u10DC\u10DD\u10D1\u10D8 \u10D2\u10D0\u10E1\u10D0\u10E6\u10D4\u10D1${r.keys.length > 1 ? "\u10D4\u10D1\u10D8" : "\u10D8"}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D2\u10D0\u10E1\u10D0\u10E6\u10D4\u10D1\u10D8 ${r.origin}-\u10E8\u10D8`;
      case "invalid_union":
        return "\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0";
      case "invalid_element":
        return `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10DB\u10DC\u10D8\u10E8\u10D5\u10DC\u10D4\u10DA\u10DD\u10D1\u10D0 ${r.origin}-\u10E8\u10D8`;
      default:
        return "\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0";
    }
  };
}, "error");
function Sc() {
  return {
    localeError: cy()
  };
}
s(Sc, "default");

// versions/4.4.3/node_modules/zod/v4/locales/km.js
var uy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u178F\u17BD\u17A2\u1780\u17D2\u179F\u179A", verb: "\u1782\u17BD\u179A\u1798\u17B6\u1793" },
    file: { unit: "\u1794\u17C3", verb: "\u1782\u17BD\u179A\u1798\u17B6\u1793" },
    array: { unit: "\u1792\u17B6\u178F\u17BB", verb: "\u1782\u17BD\u179A\u1798\u17B6\u1793" },
    set: { unit: "\u1792\u17B6\u178F\u17BB", verb: "\u1782\u17BD\u179A\u1798\u17B6\u1793" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B",
    email: "\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793\u17A2\u17CA\u17B8\u1798\u17C2\u179B",
    url: "URL",
    emoji: "\u179F\u1789\u17D2\u1789\u17B6\u17A2\u17B6\u179A\u1798\u17D2\u1798\u178E\u17CD",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u1780\u17B6\u179B\u1794\u179A\u17B7\u1785\u17D2\u1786\u17C1\u1791 \u1793\u17B7\u1784\u1798\u17C9\u17C4\u1784 ISO",
    date: "\u1780\u17B6\u179B\u1794\u179A\u17B7\u1785\u17D2\u1786\u17C1\u1791 ISO",
    time: "\u1798\u17C9\u17C4\u1784 ISO",
    duration: "\u179A\u1799\u17C8\u1796\u17C1\u179B ISO",
    ipv4: "\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793 IPv4",
    ipv6: "\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793 IPv6",
    cidrv4: "\u178A\u17C2\u1793\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793 IPv4",
    cidrv6: "\u178A\u17C2\u1793\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793 IPv6",
    base64: "\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u17A2\u17CA\u17B7\u1780\u17BC\u178A base64",
    base64url: "\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u17A2\u17CA\u17B7\u1780\u17BC\u178A base64url",
    json_string: "\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A JSON",
    e164: "\u179B\u17C1\u1781 E.164",
    jwt: "JWT",
    template_literal: "\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B"
  }, i = {
    nan: "NaN",
    number: "\u179B\u17C1\u1781",
    array: "\u17A2\u17B6\u179A\u17C1 (Array)",
    null: "\u1782\u17D2\u1798\u17B6\u1793\u178F\u1798\u17D2\u179B\u17C3 (null)"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A instanceof ${r.expected} \u1794\u17C9\u17BB\u1793\u17D2\u178F\u17C2\u1791\u1791\u17BD\u179B\u1794\u17B6\u1793 ${c}` : `\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${o} \u1794\u17C9\u17BB\u1793\u17D2\u178F\u17C2\u1791\u1791\u17BD\u179B\u1794\u17B6\u1793 ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${v(r.values[0])}` : `\u1787\u1798\u17D2\u179A\u17BE\u179F\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1787\u17B6\u1798\u17BD\u1799\u1780\u17D2\u1793\u17BB\u1784\u1785\u17C6\u178E\u17C4\u1798 ${p(r.values, "|")}`;
      case "too_big": {
        let o = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `\u1792\u17C6\u1796\u17C1\u1780\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${r.origin ?? "\u178F\u1798\u17D2\u179B\u17C3"} ${o} ${r.maximum.toString()} ${a.unit ?? "\u1792\u17B6\u178F\u17BB"}` : `\u1792\u17C6\u1796\u17C1\u1780\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${r.origin ?? "\u178F\u1798\u17D2\u179B\u17C3"} ${o} ${r.maximum.toString()}`;
      }
      case "too_small": {
        let o = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\u178F\u17BC\u1785\u1796\u17C1\u1780\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${r.origin} ${o} ${r.minimum.toString()} ${a.unit}` : `\u178F\u17BC\u1785\u1796\u17C1\u1780\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${r.origin} ${o} ${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1785\u17B6\u1794\u17CB\u1795\u17D2\u178F\u17BE\u1798\u178A\u17C4\u1799 "${o.prefix}"` : o.format === "ends_with" ? `\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1794\u1789\u17D2\u1785\u1794\u17CB\u178A\u17C4\u1799 "${o.suffix}"` : o.format === "includes" ? `\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1798\u17B6\u1793 "${o.includes}"` : o.format === "regex" ? `\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u178F\u17C2\u1795\u17D2\u1782\u17BC\u1795\u17D2\u1782\u1784\u1793\u17B9\u1784\u1791\u1798\u17D2\u179A\u1784\u17CB\u178A\u17C2\u179B\u1794\u17B6\u1793\u1780\u17C6\u178E\u178F\u17CB ${o.pattern}` : `\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 ${n[o.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u179B\u17C1\u1781\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u178F\u17C2\u1787\u17B6\u1796\u17A0\u17BB\u1782\u17BB\u178E\u1793\u17C3 ${r.divisor}`;
      case "unrecognized_keys":
        return `\u179A\u1780\u1783\u17BE\u1789\u179F\u17C4\u1798\u17B7\u1793\u179F\u17D2\u1782\u17B6\u179B\u17CB\u17D6 ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `\u179F\u17C4\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u1793\u17C5\u1780\u17D2\u1793\u17BB\u1784 ${r.origin}`;
      case "invalid_union":
        return "\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C";
      case "invalid_element":
        return `\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u1793\u17C5\u1780\u17D2\u1793\u17BB\u1784 ${r.origin}`;
      default:
        return "\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C";
    }
  };
}, "error");
function Ur() {
  return {
    localeError: uy()
  };
}
s(Ur, "default");

// versions/4.4.3/node_modules/zod/v4/locales/kh.js
function jc() {
  return Ur();
}
s(jc, "default");

// versions/4.4.3/node_modules/zod/v4/locales/ko.js
var ly = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\uBB38\uC790", verb: "to have" },
    file: { unit: "\uBC14\uC774\uD2B8", verb: "to have" },
    array: { unit: "\uAC1C", verb: "to have" },
    set: { unit: "\uAC1C", verb: "to have" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\uC785\uB825",
    email: "\uC774\uBA54\uC77C \uC8FC\uC18C",
    url: "URL",
    emoji: "\uC774\uBAA8\uC9C0",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \uB0A0\uC9DC\uC2DC\uAC04",
    date: "ISO \uB0A0\uC9DC",
    time: "ISO \uC2DC\uAC04",
    duration: "ISO \uAE30\uAC04",
    ipv4: "IPv4 \uC8FC\uC18C",
    ipv6: "IPv6 \uC8FC\uC18C",
    cidrv4: "IPv4 \uBC94\uC704",
    cidrv6: "IPv6 \uBC94\uC704",
    base64: "base64 \uC778\uCF54\uB529 \uBB38\uC790\uC5F4",
    base64url: "base64url \uC778\uCF54\uB529 \uBB38\uC790\uC5F4",
    json_string: "JSON \uBB38\uC790\uC5F4",
    e164: "E.164 \uBC88\uD638",
    jwt: "JWT",
    template_literal: "\uC785\uB825"
  }, i = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\uC798\uBABB\uB41C \uC785\uB825: \uC608\uC0C1 \uD0C0\uC785\uC740 instanceof ${r.expected}, \uBC1B\uC740 \uD0C0\uC785\uC740 ${c}\uC785\uB2C8\uB2E4` : `\uC798\uBABB\uB41C \uC785\uB825: \uC608\uC0C1 \uD0C0\uC785\uC740 ${o}, \uBC1B\uC740 \uD0C0\uC785\uC740 ${c}\uC785\uB2C8\uB2E4`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\uC798\uBABB\uB41C \uC785\uB825: \uAC12\uC740 ${v(r.values[0])} \uC774\uC5B4\uC57C \uD569\uB2C8\uB2E4` : `\uC798\uBABB\uB41C \uC635\uC158: ${p(r.values, "\uB610\uB294 ")} \uC911 \uD558\uB098\uC5EC\uC57C \uD569\uB2C8\uB2E4`;
      case "too_big": {
        let o = r.inclusive ? "\uC774\uD558" : "\uBBF8\uB9CC", a = o === "\uBBF8\uB9CC" ? "\uC774\uC5B4\uC57C \uD569\uB2C8\uB2E4" : "\uC5EC\uC57C \uD569\uB2C8\uB2E4", c = t(r.origin), u = c?.unit ?? "\uC694\uC18C";
        return c ? `${r.origin ?? "\uAC12"}\uC774 \uB108\uBB34 \uD07D\uB2C8\uB2E4: ${r.maximum.toString()}${u} ${o}${a}` : `${r.origin ?? "\uAC12"}\uC774 \uB108\uBB34 \uD07D\uB2C8\uB2E4: ${r.maximum.toString()} ${o}${a}`;
      }
      case "too_small": {
        let o = r.inclusive ? "\uC774\uC0C1" : "\uCD08\uACFC", a = o === "\uC774\uC0C1" ? "\uC774\uC5B4\uC57C \uD569\uB2C8\uB2E4" : "\uC5EC\uC57C \uD569\uB2C8\uB2E4", c = t(r.origin), u = c?.unit ?? "\uC694\uC18C";
        return c ? `${r.origin ?? "\uAC12"}\uC774 \uB108\uBB34 \uC791\uC2B5\uB2C8\uB2E4: ${r.minimum.toString()}${u} ${o}${a}` : `${r.origin ?? "\uAC12"}\uC774 \uB108\uBB34 \uC791\uC2B5\uB2C8\uB2E4: ${r.minimum.toString()} ${o}${a}`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `\uC798\uBABB\uB41C \uBB38\uC790\uC5F4: "${o.prefix}"(\uC73C)\uB85C \uC2DC\uC791\uD574\uC57C \uD569\uB2C8\uB2E4` : o.format === "ends_with" ? `\uC798\uBABB\uB41C \uBB38\uC790\uC5F4: "${o.suffix}"(\uC73C)\uB85C \uB05D\uB098\uC57C \uD569\uB2C8\uB2E4` : o.format === "includes" ? `\uC798\uBABB\uB41C \uBB38\uC790\uC5F4: "${o.includes}"\uC744(\uB97C) \uD3EC\uD568\uD574\uC57C \uD569\uB2C8\uB2E4` : o.format === "regex" ? `\uC798\uBABB\uB41C \uBB38\uC790\uC5F4: \uC815\uADDC\uC2DD ${o.pattern} \uD328\uD134\uACFC \uC77C\uCE58\uD574\uC57C \uD569\uB2C8\uB2E4` : `\uC798\uBABB\uB41C ${n[o.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\uC798\uBABB\uB41C \uC22B\uC790: ${r.divisor}\uC758 \uBC30\uC218\uC5EC\uC57C \uD569\uB2C8\uB2E4`;
      case "unrecognized_keys":
        return `\uC778\uC2DD\uD560 \uC218 \uC5C6\uB294 \uD0A4: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `\uC798\uBABB\uB41C \uD0A4: ${r.origin}`;
      case "invalid_union":
        return "\uC798\uBABB\uB41C \uC785\uB825";
      case "invalid_element":
        return `\uC798\uBABB\uB41C \uAC12: ${r.origin}`;
      default:
        return "\uC798\uBABB\uB41C \uC785\uB825";
    }
  };
}, "error");
function Oc() {
  return {
    localeError: ly()
  };
}
s(Oc, "default");

// versions/4.4.3/node_modules/zod/v4/locales/lt.js
var Dr = /* @__PURE__ */ s((e) => e.charAt(0).toUpperCase() + e.slice(1), "capitalizeFirstCharacter");
function sp(e) {
  let t = Math.abs(e), n = t % 10, i = t % 100;
  return i >= 11 && i <= 19 || n === 0 ? "many" : n === 1 ? "one" : "few";
}
s(sp, "getUnitTypeFromNumber");
var dy = /* @__PURE__ */ s(() => {
  let e = {
    string: {
      unit: {
        one: "simbolis",
        few: "simboliai",
        many: "simboli\u0173"
      },
      verb: {
        smaller: {
          inclusive: "turi b\u016Bti ne ilgesn\u0117 kaip",
          notInclusive: "turi b\u016Bti trumpesn\u0117 kaip"
        },
        bigger: {
          inclusive: "turi b\u016Bti ne trumpesn\u0117 kaip",
          notInclusive: "turi b\u016Bti ilgesn\u0117 kaip"
        }
      }
    },
    file: {
      unit: {
        one: "baitas",
        few: "baitai",
        many: "bait\u0173"
      },
      verb: {
        smaller: {
          inclusive: "turi b\u016Bti ne didesnis kaip",
          notInclusive: "turi b\u016Bti ma\u017Eesnis kaip"
        },
        bigger: {
          inclusive: "turi b\u016Bti ne ma\u017Eesnis kaip",
          notInclusive: "turi b\u016Bti didesnis kaip"
        }
      }
    },
    array: {
      unit: {
        one: "element\u0105",
        few: "elementus",
        many: "element\u0173"
      },
      verb: {
        smaller: {
          inclusive: "turi tur\u0117ti ne daugiau kaip",
          notInclusive: "turi tur\u0117ti ma\u017Eiau kaip"
        },
        bigger: {
          inclusive: "turi tur\u0117ti ne ma\u017Eiau kaip",
          notInclusive: "turi tur\u0117ti daugiau kaip"
        }
      }
    },
    set: {
      unit: {
        one: "element\u0105",
        few: "elementus",
        many: "element\u0173"
      },
      verb: {
        smaller: {
          inclusive: "turi tur\u0117ti ne daugiau kaip",
          notInclusive: "turi tur\u0117ti ma\u017Eiau kaip"
        },
        bigger: {
          inclusive: "turi tur\u0117ti ne ma\u017Eiau kaip",
          notInclusive: "turi tur\u0117ti daugiau kaip"
        }
      }
    }
  };
  function t(r, o, a, c) {
    let u = e[r] ?? null;
    return u === null ? u : {
      unit: u.unit[o],
      verb: u.verb[c][a ? "inclusive" : "notInclusive"]
    };
  }
  s(t, "getSizing");
  let n = {
    regex: "\u012Fvestis",
    email: "el. pa\u0161to adresas",
    url: "URL",
    emoji: "jaustukas",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO data ir laikas",
    date: "ISO data",
    time: "ISO laikas",
    duration: "ISO trukm\u0117",
    ipv4: "IPv4 adresas",
    ipv6: "IPv6 adresas",
    cidrv4: "IPv4 tinklo prefiksas (CIDR)",
    cidrv6: "IPv6 tinklo prefiksas (CIDR)",
    base64: "base64 u\u017Ekoduota eilut\u0117",
    base64url: "base64url u\u017Ekoduota eilut\u0117",
    json_string: "JSON eilut\u0117",
    e164: "E.164 numeris",
    jwt: "JWT",
    template_literal: "\u012Fvestis"
  }, i = {
    nan: "NaN",
    number: "skai\u010Dius",
    bigint: "sveikasis skai\u010Dius",
    string: "eilut\u0117",
    boolean: "login\u0117 reik\u0161m\u0117",
    undefined: "neapibr\u0117\u017Eta reik\u0161m\u0117",
    function: "funkcija",
    symbol: "simbolis",
    array: "masyvas",
    object: "objektas",
    null: "nulin\u0117 reik\u0161m\u0117"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Gautas tipas ${c}, o tik\u0117tasi - instanceof ${r.expected}` : `Gautas tipas ${c}, o tik\u0117tasi - ${o}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Privalo b\u016Bti ${v(r.values[0])}` : `Privalo b\u016Bti vienas i\u0161 ${p(r.values, "|")} pasirinkim\u0173`;
      case "too_big": {
        let o = i[r.origin] ?? r.origin, a = t(r.origin, sp(Number(r.maximum)), r.inclusive ?? !1, "smaller");
        if (a?.verb)
          return `${Dr(o ?? r.origin ?? "reik\u0161m\u0117")} ${a.verb} ${r.maximum.toString()} ${a.unit ?? "element\u0173"}`;
        let c = r.inclusive ? "ne didesnis kaip" : "ma\u017Eesnis kaip";
        return `${Dr(o ?? r.origin ?? "reik\u0161m\u0117")} turi b\u016Bti ${c} ${r.maximum.toString()} ${a?.unit}`;
      }
      case "too_small": {
        let o = i[r.origin] ?? r.origin, a = t(r.origin, sp(Number(r.minimum)), r.inclusive ?? !1, "bigger");
        if (a?.verb)
          return `${Dr(o ?? r.origin ?? "reik\u0161m\u0117")} ${a.verb} ${r.minimum.toString()} ${a.unit ?? "element\u0173"}`;
        let c = r.inclusive ? "ne ma\u017Eesnis kaip" : "didesnis kaip";
        return `${Dr(o ?? r.origin ?? "reik\u0161m\u0117")} turi b\u016Bti ${c} ${r.minimum.toString()} ${a?.unit}`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `Eilut\u0117 privalo prasid\u0117ti "${o.prefix}"` : o.format === "ends_with" ? `Eilut\u0117 privalo pasibaigti "${o.suffix}"` : o.format === "includes" ? `Eilut\u0117 privalo \u012Ftraukti "${o.includes}"` : o.format === "regex" ? `Eilut\u0117 privalo atitikti ${o.pattern}` : `Neteisingas ${n[o.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Skai\u010Dius privalo b\u016Bti ${r.divisor} kartotinis.`;
      case "unrecognized_keys":
        return `Neatpa\u017Eint${r.keys.length > 1 ? "i" : "as"} rakt${r.keys.length > 1 ? "ai" : "as"}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return "Rastas klaidingas raktas";
      case "invalid_union":
        return "Klaidinga \u012Fvestis";
      case "invalid_element": {
        let o = i[r.origin] ?? r.origin;
        return `${Dr(o ?? r.origin ?? "reik\u0161m\u0117")} turi klaiding\u0105 \u012Fvest\u012F`;
      }
      default:
        return "Klaidinga \u012Fvestis";
    }
  };
}, "error");
function Pc() {
  return {
    localeError: dy()
  };
}
s(Pc, "default");

// versions/4.4.3/node_modules/zod/v4/locales/mk.js
var fy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0437\u043D\u0430\u0446\u0438", verb: "\u0434\u0430 \u0438\u043C\u0430\u0430\u0442" },
    file: { unit: "\u0431\u0430\u0458\u0442\u0438", verb: "\u0434\u0430 \u0438\u043C\u0430\u0430\u0442" },
    array: { unit: "\u0441\u0442\u0430\u0432\u043A\u0438", verb: "\u0434\u0430 \u0438\u043C\u0430\u0430\u0442" },
    set: { unit: "\u0441\u0442\u0430\u0432\u043A\u0438", verb: "\u0434\u0430 \u0438\u043C\u0430\u0430\u0442" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u0432\u043D\u0435\u0441",
    email: "\u0430\u0434\u0440\u0435\u0441\u0430 \u043D\u0430 \u0435-\u043F\u043E\u0448\u0442\u0430",
    url: "URL",
    emoji: "\u0435\u043C\u043E\u045F\u0438",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0434\u0430\u0442\u0443\u043C \u0438 \u0432\u0440\u0435\u043C\u0435",
    date: "ISO \u0434\u0430\u0442\u0443\u043C",
    time: "ISO \u0432\u0440\u0435\u043C\u0435",
    duration: "ISO \u0432\u0440\u0435\u043C\u0435\u0442\u0440\u0430\u0435\u045A\u0435",
    ipv4: "IPv4 \u0430\u0434\u0440\u0435\u0441\u0430",
    ipv6: "IPv6 \u0430\u0434\u0440\u0435\u0441\u0430",
    cidrv4: "IPv4 \u043E\u043F\u0441\u0435\u0433",
    cidrv6: "IPv6 \u043E\u043F\u0441\u0435\u0433",
    base64: "base64-\u0435\u043D\u043A\u043E\u0434\u0438\u0440\u0430\u043D\u0430 \u043D\u0438\u0437\u0430",
    base64url: "base64url-\u0435\u043D\u043A\u043E\u0434\u0438\u0440\u0430\u043D\u0430 \u043D\u0438\u0437\u0430",
    json_string: "JSON \u043D\u0438\u0437\u0430",
    e164: "E.164 \u0431\u0440\u043E\u0458",
    jwt: "JWT",
    template_literal: "\u0432\u043D\u0435\u0441"
  }, i = {
    nan: "NaN",
    number: "\u0431\u0440\u043E\u0458",
    array: "\u043D\u0438\u0437\u0430"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u0413\u0440\u0435\u0448\u0435\u043D \u0432\u043D\u0435\u0441: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 instanceof ${r.expected}, \u043F\u0440\u0438\u043C\u0435\u043D\u043E ${c}` : `\u0413\u0440\u0435\u0448\u0435\u043D \u0432\u043D\u0435\u0441: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${o}, \u043F\u0440\u0438\u043C\u0435\u043D\u043E ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Invalid input: expected ${v(r.values[0])}` : `\u0413\u0440\u0435\u0448\u0430\u043D\u0430 \u043E\u043F\u0446\u0438\u0458\u0430: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 \u0435\u0434\u043D\u0430 ${p(r.values, "|")}`;
      case "too_big": {
        let o = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `\u041F\u0440\u0435\u043C\u043D\u043E\u0433\u0443 \u0433\u043E\u043B\u0435\u043C: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${r.origin ?? "\u0432\u0440\u0435\u0434\u043D\u043E\u0441\u0442\u0430"} \u0434\u0430 \u0438\u043C\u0430 ${o}${r.maximum.toString()} ${a.unit ?? "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0438"}` : `\u041F\u0440\u0435\u043C\u043D\u043E\u0433\u0443 \u0433\u043E\u043B\u0435\u043C: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${r.origin ?? "\u0432\u0440\u0435\u0434\u043D\u043E\u0441\u0442\u0430"} \u0434\u0430 \u0431\u0438\u0434\u0435 ${o}${r.maximum.toString()}`;
      }
      case "too_small": {
        let o = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\u041F\u0440\u0435\u043C\u043D\u043E\u0433\u0443 \u043C\u0430\u043B: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${r.origin} \u0434\u0430 \u0438\u043C\u0430 ${o}${r.minimum.toString()} ${a.unit}` : `\u041F\u0440\u0435\u043C\u043D\u043E\u0433\u0443 \u043C\u0430\u043B: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${r.origin} \u0434\u0430 \u0431\u0438\u0434\u0435 ${o}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `\u041D\u0435\u0432\u0430\u0436\u0435\u0447\u043A\u0430 \u043D\u0438\u0437\u0430: \u043C\u043E\u0440\u0430 \u0434\u0430 \u0437\u0430\u043F\u043E\u0447\u043D\u0443\u0432\u0430 \u0441\u043E "${o.prefix}"` : o.format === "ends_with" ? `\u041D\u0435\u0432\u0430\u0436\u0435\u0447\u043A\u0430 \u043D\u0438\u0437\u0430: \u043C\u043E\u0440\u0430 \u0434\u0430 \u0437\u0430\u0432\u0440\u0448\u0443\u0432\u0430 \u0441\u043E "${o.suffix}"` : o.format === "includes" ? `\u041D\u0435\u0432\u0430\u0436\u0435\u0447\u043A\u0430 \u043D\u0438\u0437\u0430: \u043C\u043E\u0440\u0430 \u0434\u0430 \u0432\u043A\u043B\u0443\u0447\u0443\u0432\u0430 "${o.includes}"` : o.format === "regex" ? `\u041D\u0435\u0432\u0430\u0436\u0435\u0447\u043A\u0430 \u043D\u0438\u0437\u0430: \u043C\u043E\u0440\u0430 \u0434\u0430 \u043E\u0434\u0433\u043E\u0430\u0440\u0430 \u043D\u0430 \u043F\u0430\u0442\u0435\u0440\u043D\u043E\u0442 ${o.pattern}` : `Invalid ${n[o.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u0413\u0440\u0435\u0448\u0435\u043D \u0431\u0440\u043E\u0458: \u043C\u043E\u0440\u0430 \u0434\u0430 \u0431\u0438\u0434\u0435 \u0434\u0435\u043B\u0438\u0432 \u0441\u043E ${r.divisor}`;
      case "unrecognized_keys":
        return `${r.keys.length > 1 ? "\u041D\u0435\u043F\u0440\u0435\u043F\u043E\u0437\u043D\u0430\u0435\u043D\u0438 \u043A\u043B\u0443\u0447\u0435\u0432\u0438" : "\u041D\u0435\u043F\u0440\u0435\u043F\u043E\u0437\u043D\u0430\u0435\u043D \u043A\u043B\u0443\u0447"}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `\u0413\u0440\u0435\u0448\u0435\u043D \u043A\u043B\u0443\u0447 \u0432\u043E ${r.origin}`;
      case "invalid_union":
        return "\u0413\u0440\u0435\u0448\u0435\u043D \u0432\u043D\u0435\u0441";
      case "invalid_element":
        return `\u0413\u0440\u0435\u0448\u043D\u0430 \u0432\u0440\u0435\u0434\u043D\u043E\u0441\u0442 \u0432\u043E ${r.origin}`;
      default:
        return "\u0413\u0440\u0435\u0448\u0435\u043D \u0432\u043D\u0435\u0441";
    }
  };
}, "error");
function Tc() {
  return {
    localeError: fy()
  };
}
s(Tc, "default");

// versions/4.4.3/node_modules/zod/v4/locales/ms.js
var py = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "aksara", verb: "mempunyai" },
    file: { unit: "bait", verb: "mempunyai" },
    array: { unit: "elemen", verb: "mempunyai" },
    set: { unit: "elemen", verb: "mempunyai" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "input",
    email: "alamat e-mel",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "tarikh masa ISO",
    date: "tarikh ISO",
    time: "masa ISO",
    duration: "tempoh ISO",
    ipv4: "alamat IPv4",
    ipv6: "alamat IPv6",
    cidrv4: "julat IPv4",
    cidrv6: "julat IPv6",
    base64: "string dikodkan base64",
    base64url: "string dikodkan base64url",
    json_string: "string JSON",
    e164: "nombor E.164",
    jwt: "JWT",
    template_literal: "input"
  }, i = {
    nan: "NaN",
    number: "nombor"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Input tidak sah: dijangka instanceof ${r.expected}, diterima ${c}` : `Input tidak sah: dijangka ${o}, diterima ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Input tidak sah: dijangka ${v(r.values[0])}` : `Pilihan tidak sah: dijangka salah satu daripada ${p(r.values, "|")}`;
      case "too_big": {
        let o = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Terlalu besar: dijangka ${r.origin ?? "nilai"} ${a.verb} ${o}${r.maximum.toString()} ${a.unit ?? "elemen"}` : `Terlalu besar: dijangka ${r.origin ?? "nilai"} adalah ${o}${r.maximum.toString()}`;
      }
      case "too_small": {
        let o = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Terlalu kecil: dijangka ${r.origin} ${a.verb} ${o}${r.minimum.toString()} ${a.unit}` : `Terlalu kecil: dijangka ${r.origin} adalah ${o}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `String tidak sah: mesti bermula dengan "${o.prefix}"` : o.format === "ends_with" ? `String tidak sah: mesti berakhir dengan "${o.suffix}"` : o.format === "includes" ? `String tidak sah: mesti mengandungi "${o.includes}"` : o.format === "regex" ? `String tidak sah: mesti sepadan dengan corak ${o.pattern}` : `${n[o.format] ?? r.format} tidak sah`;
      }
      case "not_multiple_of":
        return `Nombor tidak sah: perlu gandaan ${r.divisor}`;
      case "unrecognized_keys":
        return `Kunci tidak dikenali: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Kunci tidak sah dalam ${r.origin}`;
      case "invalid_union":
        return "Input tidak sah";
      case "invalid_element":
        return `Nilai tidak sah dalam ${r.origin}`;
      default:
        return "Input tidak sah";
    }
  };
}, "error");
function Ec() {
  return {
    localeError: py()
  };
}
s(Ec, "default");

// versions/4.4.3/node_modules/zod/v4/locales/nl.js
var my = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "tekens", verb: "heeft" },
    file: { unit: "bytes", verb: "heeft" },
    array: { unit: "elementen", verb: "heeft" },
    set: { unit: "elementen", verb: "heeft" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "invoer",
    email: "emailadres",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datum en tijd",
    date: "ISO datum",
    time: "ISO tijd",
    duration: "ISO duur",
    ipv4: "IPv4-adres",
    ipv6: "IPv6-adres",
    cidrv4: "IPv4-bereik",
    cidrv6: "IPv6-bereik",
    base64: "base64-gecodeerde tekst",
    base64url: "base64 URL-gecodeerde tekst",
    json_string: "JSON string",
    e164: "E.164-nummer",
    jwt: "JWT",
    template_literal: "invoer"
  }, i = {
    nan: "NaN",
    number: "getal"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Ongeldige invoer: verwacht instanceof ${r.expected}, ontving ${c}` : `Ongeldige invoer: verwacht ${o}, ontving ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Ongeldige invoer: verwacht ${v(r.values[0])}` : `Ongeldige optie: verwacht \xE9\xE9n van ${p(r.values, "|")}`;
      case "too_big": {
        let o = r.inclusive ? "<=" : "<", a = t(r.origin), c = r.origin === "date" ? "laat" : r.origin === "string" ? "lang" : "groot";
        return a ? `Te ${c}: verwacht dat ${r.origin ?? "waarde"} ${o}${r.maximum.toString()} ${a.unit ?? "elementen"} ${a.verb}` : `Te ${c}: verwacht dat ${r.origin ?? "waarde"} ${o}${r.maximum.toString()} is`;
      }
      case "too_small": {
        let o = r.inclusive ? ">=" : ">", a = t(r.origin), c = r.origin === "date" ? "vroeg" : r.origin === "string" ? "kort" : "klein";
        return a ? `Te ${c}: verwacht dat ${r.origin} ${o}${r.minimum.toString()} ${a.unit} ${a.verb}` : `Te ${c}: verwacht dat ${r.origin} ${o}${r.minimum.toString()} is`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `Ongeldige tekst: moet met "${o.prefix}" beginnen` : o.format === "ends_with" ? `Ongeldige tekst: moet op "${o.suffix}" eindigen` : o.format === "includes" ? `Ongeldige tekst: moet "${o.includes}" bevatten` : o.format === "regex" ? `Ongeldige tekst: moet overeenkomen met patroon ${o.pattern}` : `Ongeldig: ${n[o.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Ongeldig getal: moet een veelvoud van ${r.divisor} zijn`;
      case "unrecognized_keys":
        return `Onbekende key${r.keys.length > 1 ? "s" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Ongeldige key in ${r.origin}`;
      case "invalid_union":
        return "Ongeldige invoer";
      case "invalid_element":
        return `Ongeldige waarde in ${r.origin}`;
      default:
        return "Ongeldige invoer";
    }
  };
}, "error");
function Uc() {
  return {
    localeError: my()
  };
}
s(Uc, "default");

// versions/4.4.3/node_modules/zod/v4/locales/no.js
var gy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "tegn", verb: "\xE5 ha" },
    file: { unit: "bytes", verb: "\xE5 ha" },
    array: { unit: "elementer", verb: "\xE5 inneholde" },
    set: { unit: "elementer", verb: "\xE5 inneholde" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "input",
    email: "e-postadresse",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO dato- og klokkeslett",
    date: "ISO-dato",
    time: "ISO-klokkeslett",
    duration: "ISO-varighet",
    ipv4: "IPv4-omr\xE5de",
    ipv6: "IPv6-omr\xE5de",
    cidrv4: "IPv4-spekter",
    cidrv6: "IPv6-spekter",
    base64: "base64-enkodet streng",
    base64url: "base64url-enkodet streng",
    json_string: "JSON-streng",
    e164: "E.164-nummer",
    jwt: "JWT",
    template_literal: "input"
  }, i = {
    nan: "NaN",
    number: "tall",
    array: "liste"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Ugyldig input: forventet instanceof ${r.expected}, fikk ${c}` : `Ugyldig input: forventet ${o}, fikk ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Ugyldig verdi: forventet ${v(r.values[0])}` : `Ugyldig valg: forventet en av ${p(r.values, "|")}`;
      case "too_big": {
        let o = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `For stor(t): forventet ${r.origin ?? "value"} til \xE5 ha ${o}${r.maximum.toString()} ${a.unit ?? "elementer"}` : `For stor(t): forventet ${r.origin ?? "value"} til \xE5 ha ${o}${r.maximum.toString()}`;
      }
      case "too_small": {
        let o = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `For lite(n): forventet ${r.origin} til \xE5 ha ${o}${r.minimum.toString()} ${a.unit}` : `For lite(n): forventet ${r.origin} til \xE5 ha ${o}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `Ugyldig streng: m\xE5 starte med "${o.prefix}"` : o.format === "ends_with" ? `Ugyldig streng: m\xE5 ende med "${o.suffix}"` : o.format === "includes" ? `Ugyldig streng: m\xE5 inneholde "${o.includes}"` : o.format === "regex" ? `Ugyldig streng: m\xE5 matche m\xF8nsteret ${o.pattern}` : `Ugyldig ${n[o.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Ugyldig tall: m\xE5 v\xE6re et multiplum av ${r.divisor}`;
      case "unrecognized_keys":
        return `${r.keys.length > 1 ? "Ukjente n\xF8kler" : "Ukjent n\xF8kkel"}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Ugyldig n\xF8kkel i ${r.origin}`;
      case "invalid_union":
        return "Ugyldig input";
      case "invalid_element":
        return `Ugyldig verdi i ${r.origin}`;
      default:
        return "Ugyldig input";
    }
  };
}, "error");
function Dc() {
  return {
    localeError: gy()
  };
}
s(Dc, "default");

// versions/4.4.3/node_modules/zod/v4/locales/ota.js
var hy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "harf", verb: "olmal\u0131d\u0131r" },
    file: { unit: "bayt", verb: "olmal\u0131d\u0131r" },
    array: { unit: "unsur", verb: "olmal\u0131d\u0131r" },
    set: { unit: "unsur", verb: "olmal\u0131d\u0131r" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "giren",
    email: "epostag\xE2h",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO heng\xE2m\u0131",
    date: "ISO tarihi",
    time: "ISO zaman\u0131",
    duration: "ISO m\xFCddeti",
    ipv4: "IPv4 ni\u015F\xE2n\u0131",
    ipv6: "IPv6 ni\u015F\xE2n\u0131",
    cidrv4: "IPv4 menzili",
    cidrv6: "IPv6 menzili",
    base64: "base64-\u015Fifreli metin",
    base64url: "base64url-\u015Fifreli metin",
    json_string: "JSON metin",
    e164: "E.164 say\u0131s\u0131",
    jwt: "JWT",
    template_literal: "giren"
  }, i = {
    nan: "NaN",
    number: "numara",
    array: "saf",
    null: "gayb"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `F\xE2sit giren: umulan instanceof ${r.expected}, al\u0131nan ${c}` : `F\xE2sit giren: umulan ${o}, al\u0131nan ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `F\xE2sit giren: umulan ${v(r.values[0])}` : `F\xE2sit tercih: m\xFBteberler ${p(r.values, "|")}`;
      case "too_big": {
        let o = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Fazla b\xFCy\xFCk: ${r.origin ?? "value"}, ${o}${r.maximum.toString()} ${a.unit ?? "elements"} sahip olmal\u0131yd\u0131.` : `Fazla b\xFCy\xFCk: ${r.origin ?? "value"}, ${o}${r.maximum.toString()} olmal\u0131yd\u0131.`;
      }
      case "too_small": {
        let o = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Fazla k\xFC\xE7\xFCk: ${r.origin}, ${o}${r.minimum.toString()} ${a.unit} sahip olmal\u0131yd\u0131.` : `Fazla k\xFC\xE7\xFCk: ${r.origin}, ${o}${r.minimum.toString()} olmal\u0131yd\u0131.`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `F\xE2sit metin: "${o.prefix}" ile ba\u015Flamal\u0131.` : o.format === "ends_with" ? `F\xE2sit metin: "${o.suffix}" ile bitmeli.` : o.format === "includes" ? `F\xE2sit metin: "${o.includes}" ihtiv\xE2 etmeli.` : o.format === "regex" ? `F\xE2sit metin: ${o.pattern} nak\u015F\u0131na uymal\u0131.` : `F\xE2sit ${n[o.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `F\xE2sit say\u0131: ${r.divisor} kat\u0131 olmal\u0131yd\u0131.`;
      case "unrecognized_keys":
        return `Tan\u0131nmayan anahtar ${r.keys.length > 1 ? "s" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `${r.origin} i\xE7in tan\u0131nmayan anahtar var.`;
      case "invalid_union":
        return "Giren tan\u0131namad\u0131.";
      case "invalid_element":
        return `${r.origin} i\xE7in tan\u0131nmayan k\u0131ymet var.`;
      default:
        return "K\u0131ymet tan\u0131namad\u0131.";
    }
  };
}, "error");
function Nc() {
  return {
    localeError: hy()
  };
}
s(Nc, "default");

// versions/4.4.3/node_modules/zod/v4/locales/ps.js
var vy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u062A\u0648\u06A9\u064A", verb: "\u0648\u0644\u0631\u064A" },
    file: { unit: "\u0628\u0627\u06CC\u067C\u0633", verb: "\u0648\u0644\u0631\u064A" },
    array: { unit: "\u062A\u0648\u06A9\u064A", verb: "\u0648\u0644\u0631\u064A" },
    set: { unit: "\u062A\u0648\u06A9\u064A", verb: "\u0648\u0644\u0631\u064A" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u0648\u0631\u0648\u062F\u064A",
    email: "\u0628\u0631\u06CC\u069A\u0646\u0627\u0644\u06CC\u06A9",
    url: "\u06CC\u0648 \u0622\u0631 \u0627\u0644",
    emoji: "\u0627\u06CC\u0645\u0648\u062C\u064A",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u0646\u06CC\u067C\u0647 \u0627\u0648 \u0648\u062E\u062A",
    date: "\u0646\u06D0\u067C\u0647",
    time: "\u0648\u062E\u062A",
    duration: "\u0645\u0648\u062F\u0647",
    ipv4: "\u062F IPv4 \u067E\u062A\u0647",
    ipv6: "\u062F IPv6 \u067E\u062A\u0647",
    cidrv4: "\u062F IPv4 \u0633\u0627\u062D\u0647",
    cidrv6: "\u062F IPv6 \u0633\u0627\u062D\u0647",
    base64: "base64-encoded \u0645\u062A\u0646",
    base64url: "base64url-encoded \u0645\u062A\u0646",
    json_string: "JSON \u0645\u062A\u0646",
    e164: "\u062F E.164 \u0634\u0645\u06D0\u0631\u0647",
    jwt: "JWT",
    template_literal: "\u0648\u0631\u0648\u062F\u064A"
  }, i = {
    nan: "NaN",
    number: "\u0639\u062F\u062F",
    array: "\u0627\u0631\u06D0"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u0646\u0627\u0633\u0645 \u0648\u0631\u0648\u062F\u064A: \u0628\u0627\u06CC\u062F instanceof ${r.expected} \u0648\u0627\u06CC, \u0645\u06AB\u0631 ${c} \u062A\u0631\u0644\u0627\u0633\u0647 \u0634\u0648` : `\u0646\u0627\u0633\u0645 \u0648\u0631\u0648\u062F\u064A: \u0628\u0627\u06CC\u062F ${o} \u0648\u0627\u06CC, \u0645\u06AB\u0631 ${c} \u062A\u0631\u0644\u0627\u0633\u0647 \u0634\u0648`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u0646\u0627\u0633\u0645 \u0648\u0631\u0648\u062F\u064A: \u0628\u0627\u06CC\u062F ${v(r.values[0])} \u0648\u0627\u06CC` : `\u0646\u0627\u0633\u0645 \u0627\u0646\u062A\u062E\u0627\u0628: \u0628\u0627\u06CC\u062F \u06CC\u0648 \u0644\u0647 ${p(r.values, "|")} \u0685\u062E\u0647 \u0648\u0627\u06CC`;
      case "too_big": {
        let o = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `\u0689\u06CC\u0631 \u0644\u0648\u06CC: ${r.origin ?? "\u0627\u0631\u0632\u069A\u062A"} \u0628\u0627\u06CC\u062F ${o}${r.maximum.toString()} ${a.unit ?? "\u0639\u0646\u0635\u0631\u0648\u0646\u0647"} \u0648\u0644\u0631\u064A` : `\u0689\u06CC\u0631 \u0644\u0648\u06CC: ${r.origin ?? "\u0627\u0631\u0632\u069A\u062A"} \u0628\u0627\u06CC\u062F ${o}${r.maximum.toString()} \u0648\u064A`;
      }
      case "too_small": {
        let o = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\u0689\u06CC\u0631 \u06A9\u0648\u0686\u0646\u06CC: ${r.origin} \u0628\u0627\u06CC\u062F ${o}${r.minimum.toString()} ${a.unit} \u0648\u0644\u0631\u064A` : `\u0689\u06CC\u0631 \u06A9\u0648\u0686\u0646\u06CC: ${r.origin} \u0628\u0627\u06CC\u062F ${o}${r.minimum.toString()} \u0648\u064A`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `\u0646\u0627\u0633\u0645 \u0645\u062A\u0646: \u0628\u0627\u06CC\u062F \u062F "${o.prefix}" \u0633\u0631\u0647 \u067E\u06CC\u0644 \u0634\u064A` : o.format === "ends_with" ? `\u0646\u0627\u0633\u0645 \u0645\u062A\u0646: \u0628\u0627\u06CC\u062F \u062F "${o.suffix}" \u0633\u0631\u0647 \u067E\u0627\u06CC \u062A\u0647 \u0648\u0631\u0633\u064A\u0696\u064A` : o.format === "includes" ? `\u0646\u0627\u0633\u0645 \u0645\u062A\u0646: \u0628\u0627\u06CC\u062F "${o.includes}" \u0648\u0644\u0631\u064A` : o.format === "regex" ? `\u0646\u0627\u0633\u0645 \u0645\u062A\u0646: \u0628\u0627\u06CC\u062F \u062F ${o.pattern} \u0633\u0631\u0647 \u0645\u0637\u0627\u0628\u0642\u062A \u0648\u0644\u0631\u064A` : `${n[o.format] ?? r.format} \u0646\u0627\u0633\u0645 \u062F\u06CC`;
      }
      case "not_multiple_of":
        return `\u0646\u0627\u0633\u0645 \u0639\u062F\u062F: \u0628\u0627\u06CC\u062F \u062F ${r.divisor} \u0645\u0636\u0631\u0628 \u0648\u064A`;
      case "unrecognized_keys":
        return `\u0646\u0627\u0633\u0645 ${r.keys.length > 1 ? "\u06A9\u0644\u06CC\u0689\u0648\u0646\u0647" : "\u06A9\u0644\u06CC\u0689"}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `\u0646\u0627\u0633\u0645 \u06A9\u0644\u06CC\u0689 \u067E\u0647 ${r.origin} \u06A9\u06D0`;
      case "invalid_union":
        return "\u0646\u0627\u0633\u0645\u0647 \u0648\u0631\u0648\u062F\u064A";
      case "invalid_element":
        return `\u0646\u0627\u0633\u0645 \u0639\u0646\u0635\u0631 \u067E\u0647 ${r.origin} \u06A9\u06D0`;
      default:
        return "\u0646\u0627\u0633\u0645\u0647 \u0648\u0631\u0648\u062F\u064A";
    }
  };
}, "error");
function Zc() {
  return {
    localeError: vy()
  };
}
s(Zc, "default");

// versions/4.4.3/node_modules/zod/v4/locales/pl.js
var yy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "znak\xF3w", verb: "mie\u0107" },
    file: { unit: "bajt\xF3w", verb: "mie\u0107" },
    array: { unit: "element\xF3w", verb: "mie\u0107" },
    set: { unit: "element\xF3w", verb: "mie\u0107" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "wyra\u017Cenie",
    email: "adres email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "data i godzina w formacie ISO",
    date: "data w formacie ISO",
    time: "godzina w formacie ISO",
    duration: "czas trwania ISO",
    ipv4: "adres IPv4",
    ipv6: "adres IPv6",
    cidrv4: "zakres IPv4",
    cidrv6: "zakres IPv6",
    base64: "ci\u0105g znak\xF3w zakodowany w formacie base64",
    base64url: "ci\u0105g znak\xF3w zakodowany w formacie base64url",
    json_string: "ci\u0105g znak\xF3w w formacie JSON",
    e164: "liczba E.164",
    jwt: "JWT",
    template_literal: "wej\u015Bcie"
  }, i = {
    nan: "NaN",
    number: "liczba",
    array: "tablica"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Nieprawid\u0142owe dane wej\u015Bciowe: oczekiwano instanceof ${r.expected}, otrzymano ${c}` : `Nieprawid\u0142owe dane wej\u015Bciowe: oczekiwano ${o}, otrzymano ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Nieprawid\u0142owe dane wej\u015Bciowe: oczekiwano ${v(r.values[0])}` : `Nieprawid\u0142owa opcja: oczekiwano jednej z warto\u015Bci ${p(r.values, "|")}`;
      case "too_big": {
        let o = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Za du\u017Ca warto\u015B\u0107: oczekiwano, \u017Ce ${r.origin ?? "warto\u015B\u0107"} b\u0119dzie mie\u0107 ${o}${r.maximum.toString()} ${a.unit ?? "element\xF3w"}` : `Zbyt du\u017C(y/a/e): oczekiwano, \u017Ce ${r.origin ?? "warto\u015B\u0107"} b\u0119dzie wynosi\u0107 ${o}${r.maximum.toString()}`;
      }
      case "too_small": {
        let o = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Za ma\u0142a warto\u015B\u0107: oczekiwano, \u017Ce ${r.origin ?? "warto\u015B\u0107"} b\u0119dzie mie\u0107 ${o}${r.minimum.toString()} ${a.unit ?? "element\xF3w"}` : `Zbyt ma\u0142(y/a/e): oczekiwano, \u017Ce ${r.origin ?? "warto\u015B\u0107"} b\u0119dzie wynosi\u0107 ${o}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `Nieprawid\u0142owy ci\u0105g znak\xF3w: musi zaczyna\u0107 si\u0119 od "${o.prefix}"` : o.format === "ends_with" ? `Nieprawid\u0142owy ci\u0105g znak\xF3w: musi ko\u0144czy\u0107 si\u0119 na "${o.suffix}"` : o.format === "includes" ? `Nieprawid\u0142owy ci\u0105g znak\xF3w: musi zawiera\u0107 "${o.includes}"` : o.format === "regex" ? `Nieprawid\u0142owy ci\u0105g znak\xF3w: musi odpowiada\u0107 wzorcowi ${o.pattern}` : `Nieprawid\u0142ow(y/a/e) ${n[o.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Nieprawid\u0142owa liczba: musi by\u0107 wielokrotno\u015Bci\u0105 ${r.divisor}`;
      case "unrecognized_keys":
        return `Nierozpoznane klucze${r.keys.length > 1 ? "s" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Nieprawid\u0142owy klucz w ${r.origin}`;
      case "invalid_union":
        return "Nieprawid\u0142owe dane wej\u015Bciowe";
      case "invalid_element":
        return `Nieprawid\u0142owa warto\u015B\u0107 w ${r.origin}`;
      default:
        return "Nieprawid\u0142owe dane wej\u015Bciowe";
    }
  };
}, "error");
function Ac() {
  return {
    localeError: yy()
  };
}
s(Ac, "default");

// versions/4.4.3/node_modules/zod/v4/locales/pt.js
var by = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "caracteres", verb: "ter" },
    file: { unit: "bytes", verb: "ter" },
    array: { unit: "itens", verb: "ter" },
    set: { unit: "itens", verb: "ter" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "padr\xE3o",
    email: "endere\xE7o de e-mail",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "data e hora ISO",
    date: "data ISO",
    time: "hora ISO",
    duration: "dura\xE7\xE3o ISO",
    ipv4: "endere\xE7o IPv4",
    ipv6: "endere\xE7o IPv6",
    cidrv4: "faixa de IPv4",
    cidrv6: "faixa de IPv6",
    base64: "texto codificado em base64",
    base64url: "URL codificada em base64",
    json_string: "texto JSON",
    e164: "n\xFAmero E.164",
    jwt: "JWT",
    template_literal: "entrada"
  }, i = {
    nan: "NaN",
    number: "n\xFAmero",
    null: "nulo"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Tipo inv\xE1lido: esperado instanceof ${r.expected}, recebido ${c}` : `Tipo inv\xE1lido: esperado ${o}, recebido ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Entrada inv\xE1lida: esperado ${v(r.values[0])}` : `Op\xE7\xE3o inv\xE1lida: esperada uma das ${p(r.values, "|")}`;
      case "too_big": {
        let o = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Muito grande: esperado que ${r.origin ?? "valor"} tivesse ${o}${r.maximum.toString()} ${a.unit ?? "elementos"}` : `Muito grande: esperado que ${r.origin ?? "valor"} fosse ${o}${r.maximum.toString()}`;
      }
      case "too_small": {
        let o = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Muito pequeno: esperado que ${r.origin} tivesse ${o}${r.minimum.toString()} ${a.unit}` : `Muito pequeno: esperado que ${r.origin} fosse ${o}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `Texto inv\xE1lido: deve come\xE7ar com "${o.prefix}"` : o.format === "ends_with" ? `Texto inv\xE1lido: deve terminar com "${o.suffix}"` : o.format === "includes" ? `Texto inv\xE1lido: deve incluir "${o.includes}"` : o.format === "regex" ? `Texto inv\xE1lido: deve corresponder ao padr\xE3o ${o.pattern}` : `${n[o.format] ?? r.format} inv\xE1lido`;
      }
      case "not_multiple_of":
        return `N\xFAmero inv\xE1lido: deve ser m\xFAltiplo de ${r.divisor}`;
      case "unrecognized_keys":
        return `Chave${r.keys.length > 1 ? "s" : ""} desconhecida${r.keys.length > 1 ? "s" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Chave inv\xE1lida em ${r.origin}`;
      case "invalid_union":
        return "Entrada inv\xE1lida";
      case "invalid_element":
        return `Valor inv\xE1lido em ${r.origin}`;
      default:
        return "Campo inv\xE1lido";
    }
  };
}, "error");
function Cc() {
  return {
    localeError: by()
  };
}
s(Cc, "default");

// versions/4.4.3/node_modules/zod/v4/locales/ro.js
var $y = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "caractere", verb: "s\u0103 aib\u0103" },
    file: { unit: "octe\u021Bi", verb: "s\u0103 aib\u0103" },
    array: { unit: "elemente", verb: "s\u0103 aib\u0103" },
    set: { unit: "elemente", verb: "s\u0103 aib\u0103" },
    map: { unit: "intr\u0103ri", verb: "s\u0103 aib\u0103" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "intrare",
    email: "adres\u0103 de email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "dat\u0103 \u0219i or\u0103 ISO",
    date: "dat\u0103 ISO",
    time: "or\u0103 ISO",
    duration: "durat\u0103 ISO",
    ipv4: "adres\u0103 IPv4",
    ipv6: "adres\u0103 IPv6",
    mac: "adres\u0103 MAC",
    cidrv4: "interval IPv4",
    cidrv6: "interval IPv6",
    base64: "\u0219ir codat base64",
    base64url: "\u0219ir codat base64url",
    json_string: "\u0219ir JSON",
    e164: "num\u0103r E.164",
    jwt: "JWT",
    template_literal: "intrare"
  }, i = {
    nan: "NaN",
    string: "\u0219ir",
    number: "num\u0103r",
    boolean: "boolean",
    function: "func\u021Bie",
    array: "matrice",
    object: "obiect",
    undefined: "nedefinit",
    symbol: "simbol",
    bigint: "num\u0103r mare",
    void: "void",
    never: "never",
    map: "hart\u0103",
    set: "set"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return `Intrare invalid\u0103: a\u0219teptat ${o}, primit ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Intrare invalid\u0103: a\u0219teptat ${v(r.values[0])}` : `Op\u021Biune invalid\u0103: a\u0219teptat una dintre ${p(r.values, "|")}`;
      case "too_big": {
        let o = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Prea mare: a\u0219teptat ca ${r.origin ?? "valoarea"} ${a.verb} ${o}${r.maximum.toString()} ${a.unit ?? "elemente"}` : `Prea mare: a\u0219teptat ca ${r.origin ?? "valoarea"} s\u0103 fie ${o}${r.maximum.toString()}`;
      }
      case "too_small": {
        let o = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Prea mic: a\u0219teptat ca ${r.origin} ${a.verb} ${o}${r.minimum.toString()} ${a.unit}` : `Prea mic: a\u0219teptat ca ${r.origin} s\u0103 fie ${o}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `\u0218ir invalid: trebuie s\u0103 \xEEnceap\u0103 cu "${o.prefix}"` : o.format === "ends_with" ? `\u0218ir invalid: trebuie s\u0103 se termine cu "${o.suffix}"` : o.format === "includes" ? `\u0218ir invalid: trebuie s\u0103 includ\u0103 "${o.includes}"` : o.format === "regex" ? `\u0218ir invalid: trebuie s\u0103 se potriveasc\u0103 cu modelul ${o.pattern}` : `Format invalid: ${n[o.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Num\u0103r invalid: trebuie s\u0103 fie multiplu de ${r.divisor}`;
      case "unrecognized_keys":
        return `Chei nerecunoscute: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Cheie invalid\u0103 \xEEn ${r.origin}`;
      case "invalid_union":
        return "Intrare invalid\u0103";
      case "invalid_element":
        return `Valoare invalid\u0103 \xEEn ${r.origin}`;
      default:
        return "Intrare invalid\u0103";
    }
  };
}, "error");
function Rc() {
  return {
    localeError: $y()
  };
}
s(Rc, "default");

// versions/4.4.3/node_modules/zod/v4/locales/ru.js
function cp(e, t, n, i) {
  let r = Math.abs(e), o = r % 10, a = r % 100;
  return a >= 11 && a <= 19 ? i : o === 1 ? t : o >= 2 && o <= 4 ? n : i;
}
s(cp, "getRussianPlural");
var xy = /* @__PURE__ */ s(() => {
  let e = {
    string: {
      unit: {
        one: "\u0441\u0438\u043C\u0432\u043E\u043B",
        few: "\u0441\u0438\u043C\u0432\u043E\u043B\u0430",
        many: "\u0441\u0438\u043C\u0432\u043E\u043B\u043E\u0432"
      },
      verb: "\u0438\u043C\u0435\u0442\u044C"
    },
    file: {
      unit: {
        one: "\u0431\u0430\u0439\u0442",
        few: "\u0431\u0430\u0439\u0442\u0430",
        many: "\u0431\u0430\u0439\u0442"
      },
      verb: "\u0438\u043C\u0435\u0442\u044C"
    },
    array: {
      unit: {
        one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
        few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430",
        many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u043E\u0432"
      },
      verb: "\u0438\u043C\u0435\u0442\u044C"
    },
    set: {
      unit: {
        one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
        few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430",
        many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u043E\u0432"
      },
      verb: "\u0438\u043C\u0435\u0442\u044C"
    }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u0432\u0432\u043E\u0434",
    email: "email \u0430\u0434\u0440\u0435\u0441",
    url: "URL",
    emoji: "\u044D\u043C\u043E\u0434\u0437\u0438",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0434\u0430\u0442\u0430 \u0438 \u0432\u0440\u0435\u043C\u044F",
    date: "ISO \u0434\u0430\u0442\u0430",
    time: "ISO \u0432\u0440\u0435\u043C\u044F",
    duration: "ISO \u0434\u043B\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C",
    ipv4: "IPv4 \u0430\u0434\u0440\u0435\u0441",
    ipv6: "IPv6 \u0430\u0434\u0440\u0435\u0441",
    cidrv4: "IPv4 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D",
    cidrv6: "IPv6 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D",
    base64: "\u0441\u0442\u0440\u043E\u043A\u0430 \u0432 \u0444\u043E\u0440\u043C\u0430\u0442\u0435 base64",
    base64url: "\u0441\u0442\u0440\u043E\u043A\u0430 \u0432 \u0444\u043E\u0440\u043C\u0430\u0442\u0435 base64url",
    json_string: "JSON \u0441\u0442\u0440\u043E\u043A\u0430",
    e164: "\u043D\u043E\u043C\u0435\u0440 E.164",
    jwt: "JWT",
    template_literal: "\u0432\u0432\u043E\u0434"
  }, i = {
    nan: "NaN",
    number: "\u0447\u0438\u0441\u043B\u043E",
    array: "\u043C\u0430\u0441\u0441\u0438\u0432"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0432\u0432\u043E\u0434: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C instanceof ${r.expected}, \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u043E ${c}` : `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0432\u0432\u043E\u0434: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C ${o}, \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u043E ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0432\u0432\u043E\u0434: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C ${v(r.values[0])}` : `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0432\u0430\u0440\u0438\u0430\u043D\u0442: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C \u043E\u0434\u043D\u043E \u0438\u0437 ${p(r.values, "|")}`;
      case "too_big": {
        let o = r.inclusive ? "<=" : "<", a = t(r.origin);
        if (a) {
          let c = Number(r.maximum), u = cp(c, a.unit.one, a.unit.few, a.unit.many);
          return `\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C, \u0447\u0442\u043E ${r.origin ?? "\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435"} \u0431\u0443\u0434\u0435\u0442 \u0438\u043C\u0435\u0442\u044C ${o}${r.maximum.toString()} ${u}`;
        }
        return `\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C, \u0447\u0442\u043E ${r.origin ?? "\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435"} \u0431\u0443\u0434\u0435\u0442 ${o}${r.maximum.toString()}`;
      }
      case "too_small": {
        let o = r.inclusive ? ">=" : ">", a = t(r.origin);
        if (a) {
          let c = Number(r.minimum), u = cp(c, a.unit.one, a.unit.few, a.unit.many);
          return `\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u043C\u0430\u043B\u0435\u043D\u044C\u043A\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C, \u0447\u0442\u043E ${r.origin} \u0431\u0443\u0434\u0435\u0442 \u0438\u043C\u0435\u0442\u044C ${o}${r.minimum.toString()} ${u}`;
        }
        return `\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u043C\u0430\u043B\u0435\u043D\u044C\u043A\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C, \u0447\u0442\u043E ${r.origin} \u0431\u0443\u0434\u0435\u0442 ${o}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u0441\u0442\u0440\u043E\u043A\u0430: \u0434\u043E\u043B\u0436\u043D\u0430 \u043D\u0430\u0447\u0438\u043D\u0430\u0442\u044C\u0441\u044F \u0441 "${o.prefix}"` : o.format === "ends_with" ? `\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u0441\u0442\u0440\u043E\u043A\u0430: \u0434\u043E\u043B\u0436\u043D\u0430 \u0437\u0430\u043A\u0430\u043D\u0447\u0438\u0432\u0430\u0442\u044C\u0441\u044F \u043D\u0430 "${o.suffix}"` : o.format === "includes" ? `\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u0441\u0442\u0440\u043E\u043A\u0430: \u0434\u043E\u043B\u0436\u043D\u0430 \u0441\u043E\u0434\u0435\u0440\u0436\u0430\u0442\u044C "${o.includes}"` : o.format === "regex" ? `\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u0441\u0442\u0440\u043E\u043A\u0430: \u0434\u043E\u043B\u0436\u043D\u0430 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u043E\u0432\u0430\u0442\u044C \u0448\u0430\u0431\u043B\u043E\u043D\u0443 ${o.pattern}` : `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 ${n[o.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u041D\u0435\u0432\u0435\u0440\u043D\u043E\u0435 \u0447\u0438\u0441\u043B\u043E: \u0434\u043E\u043B\u0436\u043D\u043E \u0431\u044B\u0442\u044C \u043A\u0440\u0430\u0442\u043D\u044B\u043C ${r.divisor}`;
      case "unrecognized_keys":
        return `\u041D\u0435\u0440\u0430\u0441\u043F\u043E\u0437\u043D\u0430\u043D\u043D${r.keys.length > 1 ? "\u044B\u0435" : "\u044B\u0439"} \u043A\u043B\u044E\u0447${r.keys.length > 1 ? "\u0438" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u043A\u043B\u044E\u0447 \u0432 ${r.origin}`;
      case "invalid_union":
        return "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0435 \u0432\u0445\u043E\u0434\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435";
      case "invalid_element":
        return `\u041D\u0435\u0432\u0435\u0440\u043D\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u0432 ${r.origin}`;
      default:
        return "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0435 \u0432\u0445\u043E\u0434\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435";
    }
  };
}, "error");
function Fc() {
  return {
    localeError: xy()
  };
}
s(Fc, "default");

// versions/4.4.3/node_modules/zod/v4/locales/sl.js
var _y = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "znakov", verb: "imeti" },
    file: { unit: "bajtov", verb: "imeti" },
    array: { unit: "elementov", verb: "imeti" },
    set: { unit: "elementov", verb: "imeti" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "vnos",
    email: "e-po\u0161tni naslov",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datum in \u010Das",
    date: "ISO datum",
    time: "ISO \u010Das",
    duration: "ISO trajanje",
    ipv4: "IPv4 naslov",
    ipv6: "IPv6 naslov",
    cidrv4: "obseg IPv4",
    cidrv6: "obseg IPv6",
    base64: "base64 kodiran niz",
    base64url: "base64url kodiran niz",
    json_string: "JSON niz",
    e164: "E.164 \u0161tevilka",
    jwt: "JWT",
    template_literal: "vnos"
  }, i = {
    nan: "NaN",
    number: "\u0161tevilo",
    array: "tabela"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Neveljaven vnos: pri\u010Dakovano instanceof ${r.expected}, prejeto ${c}` : `Neveljaven vnos: pri\u010Dakovano ${o}, prejeto ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Neveljaven vnos: pri\u010Dakovano ${v(r.values[0])}` : `Neveljavna mo\u017Enost: pri\u010Dakovano eno izmed ${p(r.values, "|")}`;
      case "too_big": {
        let o = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Preveliko: pri\u010Dakovano, da bo ${r.origin ?? "vrednost"} imelo ${o}${r.maximum.toString()} ${a.unit ?? "elementov"}` : `Preveliko: pri\u010Dakovano, da bo ${r.origin ?? "vrednost"} ${o}${r.maximum.toString()}`;
      }
      case "too_small": {
        let o = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Premajhno: pri\u010Dakovano, da bo ${r.origin} imelo ${o}${r.minimum.toString()} ${a.unit}` : `Premajhno: pri\u010Dakovano, da bo ${r.origin} ${o}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `Neveljaven niz: mora se za\u010Deti z "${o.prefix}"` : o.format === "ends_with" ? `Neveljaven niz: mora se kon\u010Dati z "${o.suffix}"` : o.format === "includes" ? `Neveljaven niz: mora vsebovati "${o.includes}"` : o.format === "regex" ? `Neveljaven niz: mora ustrezati vzorcu ${o.pattern}` : `Neveljaven ${n[o.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Neveljavno \u0161tevilo: mora biti ve\u010Dkratnik ${r.divisor}`;
      case "unrecognized_keys":
        return `Neprepoznan${r.keys.length > 1 ? "i klju\u010Di" : " klju\u010D"}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Neveljaven klju\u010D v ${r.origin}`;
      case "invalid_union":
        return "Neveljaven vnos";
      case "invalid_element":
        return `Neveljavna vrednost v ${r.origin}`;
      default:
        return "Neveljaven vnos";
    }
  };
}, "error");
function Lc() {
  return {
    localeError: _y()
  };
}
s(Lc, "default");

// versions/4.4.3/node_modules/zod/v4/locales/sv.js
var wy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "tecken", verb: "att ha" },
    file: { unit: "bytes", verb: "att ha" },
    array: { unit: "objekt", verb: "att inneh\xE5lla" },
    set: { unit: "objekt", verb: "att inneh\xE5lla" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "regulj\xE4rt uttryck",
    email: "e-postadress",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO-datum och tid",
    date: "ISO-datum",
    time: "ISO-tid",
    duration: "ISO-varaktighet",
    ipv4: "IPv4-intervall",
    ipv6: "IPv6-intervall",
    cidrv4: "IPv4-spektrum",
    cidrv6: "IPv6-spektrum",
    base64: "base64-kodad str\xE4ng",
    base64url: "base64url-kodad str\xE4ng",
    json_string: "JSON-str\xE4ng",
    e164: "E.164-nummer",
    jwt: "JWT",
    template_literal: "mall-literal"
  }, i = {
    nan: "NaN",
    number: "antal",
    array: "lista"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Ogiltig inmatning: f\xF6rv\xE4ntat instanceof ${r.expected}, fick ${c}` : `Ogiltig inmatning: f\xF6rv\xE4ntat ${o}, fick ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Ogiltig inmatning: f\xF6rv\xE4ntat ${v(r.values[0])}` : `Ogiltigt val: f\xF6rv\xE4ntade en av ${p(r.values, "|")}`;
      case "too_big": {
        let o = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `F\xF6r stor(t): f\xF6rv\xE4ntade ${r.origin ?? "v\xE4rdet"} att ha ${o}${r.maximum.toString()} ${a.unit ?? "element"}` : `F\xF6r stor(t): f\xF6rv\xE4ntat ${r.origin ?? "v\xE4rdet"} att ha ${o}${r.maximum.toString()}`;
      }
      case "too_small": {
        let o = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `F\xF6r lite(t): f\xF6rv\xE4ntade ${r.origin ?? "v\xE4rdet"} att ha ${o}${r.minimum.toString()} ${a.unit}` : `F\xF6r lite(t): f\xF6rv\xE4ntade ${r.origin ?? "v\xE4rdet"} att ha ${o}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `Ogiltig str\xE4ng: m\xE5ste b\xF6rja med "${o.prefix}"` : o.format === "ends_with" ? `Ogiltig str\xE4ng: m\xE5ste sluta med "${o.suffix}"` : o.format === "includes" ? `Ogiltig str\xE4ng: m\xE5ste inneh\xE5lla "${o.includes}"` : o.format === "regex" ? `Ogiltig str\xE4ng: m\xE5ste matcha m\xF6nstret "${o.pattern}"` : `Ogiltig(t) ${n[o.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Ogiltigt tal: m\xE5ste vara en multipel av ${r.divisor}`;
      case "unrecognized_keys":
        return `${r.keys.length > 1 ? "Ok\xE4nda nycklar" : "Ok\xE4nd nyckel"}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Ogiltig nyckel i ${r.origin ?? "v\xE4rdet"}`;
      case "invalid_union":
        return "Ogiltig input";
      case "invalid_element":
        return `Ogiltigt v\xE4rde i ${r.origin ?? "v\xE4rdet"}`;
      default:
        return "Ogiltig input";
    }
  };
}, "error");
function Mc() {
  return {
    localeError: wy()
  };
}
s(Mc, "default");

// versions/4.4.3/node_modules/zod/v4/locales/ta.js
var ky = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0B8E\u0BB4\u0BC1\u0BA4\u0BCD\u0BA4\u0BC1\u0B95\u0BCD\u0B95\u0BB3\u0BCD", verb: "\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD" },
    file: { unit: "\u0BAA\u0BC8\u0B9F\u0BCD\u0B9F\u0BC1\u0B95\u0BB3\u0BCD", verb: "\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD" },
    array: { unit: "\u0B89\u0BB1\u0BC1\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD", verb: "\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD" },
    set: { unit: "\u0B89\u0BB1\u0BC1\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD", verb: "\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1",
    email: "\u0BAE\u0BBF\u0BA9\u0BCD\u0BA9\u0B9E\u0BCD\u0B9A\u0BB2\u0BCD \u0BAE\u0BC1\u0B95\u0BB5\u0BB0\u0BBF",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0BA4\u0BC7\u0BA4\u0BBF \u0BA8\u0BC7\u0BB0\u0BAE\u0BCD",
    date: "ISO \u0BA4\u0BC7\u0BA4\u0BBF",
    time: "ISO \u0BA8\u0BC7\u0BB0\u0BAE\u0BCD",
    duration: "ISO \u0B95\u0BBE\u0BB2 \u0B85\u0BB3\u0BB5\u0BC1",
    ipv4: "IPv4 \u0BAE\u0BC1\u0B95\u0BB5\u0BB0\u0BBF",
    ipv6: "IPv6 \u0BAE\u0BC1\u0B95\u0BB5\u0BB0\u0BBF",
    cidrv4: "IPv4 \u0BB5\u0BB0\u0BAE\u0BCD\u0BAA\u0BC1",
    cidrv6: "IPv6 \u0BB5\u0BB0\u0BAE\u0BCD\u0BAA\u0BC1",
    base64: "base64-encoded \u0B9A\u0BB0\u0BAE\u0BCD",
    base64url: "base64url-encoded \u0B9A\u0BB0\u0BAE\u0BCD",
    json_string: "JSON \u0B9A\u0BB0\u0BAE\u0BCD",
    e164: "E.164 \u0B8E\u0BA3\u0BCD",
    jwt: "JWT",
    template_literal: "input"
  }, i = {
    nan: "NaN",
    number: "\u0B8E\u0BA3\u0BCD",
    array: "\u0B85\u0BA3\u0BBF",
    null: "\u0BB5\u0BC6\u0BB1\u0BC1\u0BAE\u0BC8"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 instanceof ${r.expected}, \u0BAA\u0BC6\u0BB1\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${c}` : `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${o}, \u0BAA\u0BC6\u0BB1\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${v(r.values[0])}` : `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0BB5\u0BBF\u0BB0\u0BC1\u0BAA\u0BCD\u0BAA\u0BAE\u0BCD: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${p(r.values, "|")} \u0B87\u0BB2\u0BCD \u0B92\u0BA9\u0BCD\u0BB1\u0BC1`;
      case "too_big": {
        let o = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `\u0BAE\u0BBF\u0B95 \u0BAA\u0BC6\u0BB0\u0BBF\u0BAF\u0BA4\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${r.origin ?? "\u0BAE\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1"} ${o}${r.maximum.toString()} ${a.unit ?? "\u0B89\u0BB1\u0BC1\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD"} \u0B86\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : `\u0BAE\u0BBF\u0B95 \u0BAA\u0BC6\u0BB0\u0BBF\u0BAF\u0BA4\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${r.origin ?? "\u0BAE\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1"} ${o}${r.maximum.toString()} \u0B86\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD`;
      }
      case "too_small": {
        let o = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\u0BAE\u0BBF\u0B95\u0B9A\u0BCD \u0B9A\u0BBF\u0BB1\u0BBF\u0BAF\u0BA4\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${r.origin} ${o}${r.minimum.toString()} ${a.unit} \u0B86\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : `\u0BAE\u0BBF\u0B95\u0B9A\u0BCD \u0B9A\u0BBF\u0BB1\u0BBF\u0BAF\u0BA4\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${r.origin} ${o}${r.minimum.toString()} \u0B86\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B9A\u0BB0\u0BAE\u0BCD: "${o.prefix}" \u0B87\u0BB2\u0BCD \u0BA4\u0BCA\u0B9F\u0B99\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : o.format === "ends_with" ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B9A\u0BB0\u0BAE\u0BCD: "${o.suffix}" \u0B87\u0BB2\u0BCD \u0BAE\u0BC1\u0B9F\u0BBF\u0BB5\u0B9F\u0BC8\u0BAF \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : o.format === "includes" ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B9A\u0BB0\u0BAE\u0BCD: "${o.includes}" \u0B90 \u0B89\u0BB3\u0BCD\u0BB3\u0B9F\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : o.format === "regex" ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B9A\u0BB0\u0BAE\u0BCD: ${o.pattern} \u0BAE\u0BC1\u0BB1\u0BC8\u0BAA\u0BBE\u0B9F\u0BCD\u0B9F\u0BC1\u0B9F\u0BA9\u0BCD \u0BAA\u0BCA\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 ${n[o.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B8E\u0BA3\u0BCD: ${r.divisor} \u0B87\u0BA9\u0BCD \u0BAA\u0BB2\u0BAE\u0BBE\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD`;
      case "unrecognized_keys":
        return `\u0B85\u0B9F\u0BC8\u0BAF\u0BBE\u0BB3\u0BAE\u0BCD \u0BA4\u0BC6\u0BB0\u0BBF\u0BAF\u0BBE\u0BA4 \u0BB5\u0BBF\u0B9A\u0BC8${r.keys.length > 1 ? "\u0B95\u0BB3\u0BCD" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `${r.origin} \u0B87\u0BB2\u0BCD \u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0BB5\u0BBF\u0B9A\u0BC8`;
      case "invalid_union":
        return "\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1";
      case "invalid_element":
        return `${r.origin} \u0B87\u0BB2\u0BCD \u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0BAE\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1`;
      default:
        return "\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1";
    }
  };
}, "error");
function Bc() {
  return {
    localeError: ky()
  };
}
s(Bc, "default");

// versions/4.4.3/node_modules/zod/v4/locales/th.js
var zy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0E15\u0E31\u0E27\u0E2D\u0E31\u0E01\u0E29\u0E23", verb: "\u0E04\u0E27\u0E23\u0E21\u0E35" },
    file: { unit: "\u0E44\u0E1A\u0E15\u0E4C", verb: "\u0E04\u0E27\u0E23\u0E21\u0E35" },
    array: { unit: "\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23", verb: "\u0E04\u0E27\u0E23\u0E21\u0E35" },
    set: { unit: "\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23", verb: "\u0E04\u0E27\u0E23\u0E21\u0E35" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E17\u0E35\u0E48\u0E1B\u0E49\u0E2D\u0E19",
    email: "\u0E17\u0E35\u0E48\u0E2D\u0E22\u0E39\u0E48\u0E2D\u0E35\u0E40\u0E21\u0E25",
    url: "URL",
    emoji: "\u0E2D\u0E34\u0E42\u0E21\u0E08\u0E34",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48\u0E40\u0E27\u0E25\u0E32\u0E41\u0E1A\u0E1A ISO",
    date: "\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48\u0E41\u0E1A\u0E1A ISO",
    time: "\u0E40\u0E27\u0E25\u0E32\u0E41\u0E1A\u0E1A ISO",
    duration: "\u0E0A\u0E48\u0E27\u0E07\u0E40\u0E27\u0E25\u0E32\u0E41\u0E1A\u0E1A ISO",
    ipv4: "\u0E17\u0E35\u0E48\u0E2D\u0E22\u0E39\u0E48 IPv4",
    ipv6: "\u0E17\u0E35\u0E48\u0E2D\u0E22\u0E39\u0E48 IPv6",
    cidrv4: "\u0E0A\u0E48\u0E27\u0E07 IP \u0E41\u0E1A\u0E1A IPv4",
    cidrv6: "\u0E0A\u0E48\u0E27\u0E07 IP \u0E41\u0E1A\u0E1A IPv6",
    base64: "\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E41\u0E1A\u0E1A Base64",
    base64url: "\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E41\u0E1A\u0E1A Base64 \u0E2A\u0E33\u0E2B\u0E23\u0E31\u0E1A URL",
    json_string: "\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E41\u0E1A\u0E1A JSON",
    e164: "\u0E40\u0E1A\u0E2D\u0E23\u0E4C\u0E42\u0E17\u0E23\u0E28\u0E31\u0E1E\u0E17\u0E4C\u0E23\u0E30\u0E2B\u0E27\u0E48\u0E32\u0E07\u0E1B\u0E23\u0E30\u0E40\u0E17\u0E28 (E.164)",
    jwt: "\u0E42\u0E17\u0E40\u0E04\u0E19 JWT",
    template_literal: "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E17\u0E35\u0E48\u0E1B\u0E49\u0E2D\u0E19"
  }, i = {
    nan: "NaN",
    number: "\u0E15\u0E31\u0E27\u0E40\u0E25\u0E02",
    array: "\u0E2D\u0E32\u0E23\u0E4C\u0E40\u0E23\u0E22\u0E4C (Array)",
    null: "\u0E44\u0E21\u0E48\u0E21\u0E35\u0E04\u0E48\u0E32 (null)"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u0E1B\u0E23\u0E30\u0E40\u0E20\u0E17\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E04\u0E27\u0E23\u0E40\u0E1B\u0E47\u0E19 instanceof ${r.expected} \u0E41\u0E15\u0E48\u0E44\u0E14\u0E49\u0E23\u0E31\u0E1A ${c}` : `\u0E1B\u0E23\u0E30\u0E40\u0E20\u0E17\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E04\u0E27\u0E23\u0E40\u0E1B\u0E47\u0E19 ${o} \u0E41\u0E15\u0E48\u0E44\u0E14\u0E49\u0E23\u0E31\u0E1A ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u0E04\u0E48\u0E32\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E04\u0E27\u0E23\u0E40\u0E1B\u0E47\u0E19 ${v(r.values[0])}` : `\u0E15\u0E31\u0E27\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E04\u0E27\u0E23\u0E40\u0E1B\u0E47\u0E19\u0E2B\u0E19\u0E36\u0E48\u0E07\u0E43\u0E19 ${p(r.values, "|")}`;
      case "too_big": {
        let o = r.inclusive ? "\u0E44\u0E21\u0E48\u0E40\u0E01\u0E34\u0E19" : "\u0E19\u0E49\u0E2D\u0E22\u0E01\u0E27\u0E48\u0E32", a = t(r.origin);
        return a ? `\u0E40\u0E01\u0E34\u0E19\u0E01\u0E33\u0E2B\u0E19\u0E14: ${r.origin ?? "\u0E04\u0E48\u0E32"} \u0E04\u0E27\u0E23\u0E21\u0E35${o} ${r.maximum.toString()} ${a.unit ?? "\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23"}` : `\u0E40\u0E01\u0E34\u0E19\u0E01\u0E33\u0E2B\u0E19\u0E14: ${r.origin ?? "\u0E04\u0E48\u0E32"} \u0E04\u0E27\u0E23\u0E21\u0E35${o} ${r.maximum.toString()}`;
      }
      case "too_small": {
        let o = r.inclusive ? "\u0E2D\u0E22\u0E48\u0E32\u0E07\u0E19\u0E49\u0E2D\u0E22" : "\u0E21\u0E32\u0E01\u0E01\u0E27\u0E48\u0E32", a = t(r.origin);
        return a ? `\u0E19\u0E49\u0E2D\u0E22\u0E01\u0E27\u0E48\u0E32\u0E01\u0E33\u0E2B\u0E19\u0E14: ${r.origin} \u0E04\u0E27\u0E23\u0E21\u0E35${o} ${r.minimum.toString()} ${a.unit}` : `\u0E19\u0E49\u0E2D\u0E22\u0E01\u0E27\u0E48\u0E32\u0E01\u0E33\u0E2B\u0E19\u0E14: ${r.origin} \u0E04\u0E27\u0E23\u0E21\u0E35${o} ${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E15\u0E49\u0E2D\u0E07\u0E02\u0E36\u0E49\u0E19\u0E15\u0E49\u0E19\u0E14\u0E49\u0E27\u0E22 "${o.prefix}"` : o.format === "ends_with" ? `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E15\u0E49\u0E2D\u0E07\u0E25\u0E07\u0E17\u0E49\u0E32\u0E22\u0E14\u0E49\u0E27\u0E22 "${o.suffix}"` : o.format === "includes" ? `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E15\u0E49\u0E2D\u0E07\u0E21\u0E35 "${o.includes}" \u0E2D\u0E22\u0E39\u0E48\u0E43\u0E19\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21` : o.format === "regex" ? `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E15\u0E49\u0E2D\u0E07\u0E15\u0E23\u0E07\u0E01\u0E31\u0E1A\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E17\u0E35\u0E48\u0E01\u0E33\u0E2B\u0E19\u0E14 ${o.pattern}` : `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: ${n[o.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u0E15\u0E31\u0E27\u0E40\u0E25\u0E02\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E15\u0E49\u0E2D\u0E07\u0E40\u0E1B\u0E47\u0E19\u0E08\u0E33\u0E19\u0E27\u0E19\u0E17\u0E35\u0E48\u0E2B\u0E32\u0E23\u0E14\u0E49\u0E27\u0E22 ${r.divisor} \u0E44\u0E14\u0E49\u0E25\u0E07\u0E15\u0E31\u0E27`;
      case "unrecognized_keys":
        return `\u0E1E\u0E1A\u0E04\u0E35\u0E22\u0E4C\u0E17\u0E35\u0E48\u0E44\u0E21\u0E48\u0E23\u0E39\u0E49\u0E08\u0E31\u0E01: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `\u0E04\u0E35\u0E22\u0E4C\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07\u0E43\u0E19 ${r.origin}`;
      case "invalid_union":
        return "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E44\u0E21\u0E48\u0E15\u0E23\u0E07\u0E01\u0E31\u0E1A\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E22\u0E39\u0E40\u0E19\u0E35\u0E22\u0E19\u0E17\u0E35\u0E48\u0E01\u0E33\u0E2B\u0E19\u0E14\u0E44\u0E27\u0E49";
      case "invalid_element":
        return `\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07\u0E43\u0E19 ${r.origin}`;
      default:
        return "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07";
    }
  };
}, "error");
function Jc() {
  return {
    localeError: zy()
  };
}
s(Jc, "default");

// versions/4.4.3/node_modules/zod/v4/locales/tr.js
var Iy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "karakter", verb: "olmal\u0131" },
    file: { unit: "bayt", verb: "olmal\u0131" },
    array: { unit: "\xF6\u011Fe", verb: "olmal\u0131" },
    set: { unit: "\xF6\u011Fe", verb: "olmal\u0131" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "girdi",
    email: "e-posta adresi",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO tarih ve saat",
    date: "ISO tarih",
    time: "ISO saat",
    duration: "ISO s\xFCre",
    ipv4: "IPv4 adresi",
    ipv6: "IPv6 adresi",
    cidrv4: "IPv4 aral\u0131\u011F\u0131",
    cidrv6: "IPv6 aral\u0131\u011F\u0131",
    base64: "base64 ile \u015Fifrelenmi\u015F metin",
    base64url: "base64url ile \u015Fifrelenmi\u015F metin",
    json_string: "JSON dizesi",
    e164: "E.164 say\u0131s\u0131",
    jwt: "JWT",
    template_literal: "\u015Eablon dizesi"
  }, i = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Ge\xE7ersiz de\u011Fer: beklenen instanceof ${r.expected}, al\u0131nan ${c}` : `Ge\xE7ersiz de\u011Fer: beklenen ${o}, al\u0131nan ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Ge\xE7ersiz de\u011Fer: beklenen ${v(r.values[0])}` : `Ge\xE7ersiz se\xE7enek: a\u015Fa\u011F\u0131dakilerden biri olmal\u0131: ${p(r.values, "|")}`;
      case "too_big": {
        let o = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `\xC7ok b\xFCy\xFCk: beklenen ${r.origin ?? "de\u011Fer"} ${o}${r.maximum.toString()} ${a.unit ?? "\xF6\u011Fe"}` : `\xC7ok b\xFCy\xFCk: beklenen ${r.origin ?? "de\u011Fer"} ${o}${r.maximum.toString()}`;
      }
      case "too_small": {
        let o = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\xC7ok k\xFC\xE7\xFCk: beklenen ${r.origin} ${o}${r.minimum.toString()} ${a.unit}` : `\xC7ok k\xFC\xE7\xFCk: beklenen ${r.origin} ${o}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `Ge\xE7ersiz metin: "${o.prefix}" ile ba\u015Flamal\u0131` : o.format === "ends_with" ? `Ge\xE7ersiz metin: "${o.suffix}" ile bitmeli` : o.format === "includes" ? `Ge\xE7ersiz metin: "${o.includes}" i\xE7ermeli` : o.format === "regex" ? `Ge\xE7ersiz metin: ${o.pattern} desenine uymal\u0131` : `Ge\xE7ersiz ${n[o.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Ge\xE7ersiz say\u0131: ${r.divisor} ile tam b\xF6l\xFCnebilmeli`;
      case "unrecognized_keys":
        return `Tan\u0131nmayan anahtar${r.keys.length > 1 ? "lar" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `${r.origin} i\xE7inde ge\xE7ersiz anahtar`;
      case "invalid_union":
        return "Ge\xE7ersiz de\u011Fer";
      case "invalid_element":
        return `${r.origin} i\xE7inde ge\xE7ersiz de\u011Fer`;
      default:
        return "Ge\xE7ersiz de\u011Fer";
    }
  };
}, "error");
function Vc() {
  return {
    localeError: Iy()
  };
}
s(Vc, "default");

// versions/4.4.3/node_modules/zod/v4/locales/uk.js
var Sy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0441\u0438\u043C\u0432\u043E\u043B\u0456\u0432", verb: "\u043C\u0430\u0442\u0438\u043C\u0435" },
    file: { unit: "\u0431\u0430\u0439\u0442\u0456\u0432", verb: "\u043C\u0430\u0442\u0438\u043C\u0435" },
    array: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0456\u0432", verb: "\u043C\u0430\u0442\u0438\u043C\u0435" },
    set: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0456\u0432", verb: "\u043C\u0430\u0442\u0438\u043C\u0435" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456",
    email: "\u0430\u0434\u0440\u0435\u0441\u0430 \u0435\u043B\u0435\u043A\u0442\u0440\u043E\u043D\u043D\u043E\u0457 \u043F\u043E\u0448\u0442\u0438",
    url: "URL",
    emoji: "\u0435\u043C\u043E\u0434\u0437\u0456",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u0434\u0430\u0442\u0430 \u0442\u0430 \u0447\u0430\u0441 ISO",
    date: "\u0434\u0430\u0442\u0430 ISO",
    time: "\u0447\u0430\u0441 ISO",
    duration: "\u0442\u0440\u0438\u0432\u0430\u043B\u0456\u0441\u0442\u044C ISO",
    ipv4: "\u0430\u0434\u0440\u0435\u0441\u0430 IPv4",
    ipv6: "\u0430\u0434\u0440\u0435\u0441\u0430 IPv6",
    cidrv4: "\u0434\u0456\u0430\u043F\u0430\u0437\u043E\u043D IPv4",
    cidrv6: "\u0434\u0456\u0430\u043F\u0430\u0437\u043E\u043D IPv6",
    base64: "\u0440\u044F\u0434\u043E\u043A \u0443 \u043A\u043E\u0434\u0443\u0432\u0430\u043D\u043D\u0456 base64",
    base64url: "\u0440\u044F\u0434\u043E\u043A \u0443 \u043A\u043E\u0434\u0443\u0432\u0430\u043D\u043D\u0456 base64url",
    json_string: "\u0440\u044F\u0434\u043E\u043A JSON",
    e164: "\u043D\u043E\u043C\u0435\u0440 E.164",
    jwt: "JWT",
    template_literal: "\u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456"
  }, i = {
    nan: "NaN",
    number: "\u0447\u0438\u0441\u043B\u043E",
    array: "\u043C\u0430\u0441\u0438\u0432"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F instanceof ${r.expected}, \u043E\u0442\u0440\u0438\u043C\u0430\u043D\u043E ${c}` : `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F ${o}, \u043E\u0442\u0440\u0438\u043C\u0430\u043D\u043E ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F ${v(r.values[0])}` : `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0430 \u043E\u043F\u0446\u0456\u044F: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F \u043E\u0434\u043D\u0435 \u0437 ${p(r.values, "|")}`;
      case "too_big": {
        let o = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `\u0417\u0430\u043D\u0430\u0434\u0442\u043E \u0432\u0435\u043B\u0438\u043A\u0435: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F, \u0449\u043E ${r.origin ?? "\u0437\u043D\u0430\u0447\u0435\u043D\u043D\u044F"} ${a.verb} ${o}${r.maximum.toString()} ${a.unit ?? "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0456\u0432"}` : `\u0417\u0430\u043D\u0430\u0434\u0442\u043E \u0432\u0435\u043B\u0438\u043A\u0435: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F, \u0449\u043E ${r.origin ?? "\u0437\u043D\u0430\u0447\u0435\u043D\u043D\u044F"} \u0431\u0443\u0434\u0435 ${o}${r.maximum.toString()}`;
      }
      case "too_small": {
        let o = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\u0417\u0430\u043D\u0430\u0434\u0442\u043E \u043C\u0430\u043B\u0435: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F, \u0449\u043E ${r.origin} ${a.verb} ${o}${r.minimum.toString()} ${a.unit}` : `\u0417\u0430\u043D\u0430\u0434\u0442\u043E \u043C\u0430\u043B\u0435: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F, \u0449\u043E ${r.origin} \u0431\u0443\u0434\u0435 ${o}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u0440\u044F\u0434\u043E\u043A: \u043F\u043E\u0432\u0438\u043D\u0435\u043D \u043F\u043E\u0447\u0438\u043D\u0430\u0442\u0438\u0441\u044F \u0437 "${o.prefix}"` : o.format === "ends_with" ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u0440\u044F\u0434\u043E\u043A: \u043F\u043E\u0432\u0438\u043D\u0435\u043D \u0437\u0430\u043A\u0456\u043D\u0447\u0443\u0432\u0430\u0442\u0438\u0441\u044F \u043D\u0430 "${o.suffix}"` : o.format === "includes" ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u0440\u044F\u0434\u043E\u043A: \u043F\u043E\u0432\u0438\u043D\u0435\u043D \u043C\u0456\u0441\u0442\u0438\u0442\u0438 "${o.includes}"` : o.format === "regex" ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u0440\u044F\u0434\u043E\u043A: \u043F\u043E\u0432\u0438\u043D\u0435\u043D \u0432\u0456\u0434\u043F\u043E\u0432\u0456\u0434\u0430\u0442\u0438 \u0448\u0430\u0431\u043B\u043E\u043D\u0443 ${o.pattern}` : `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 ${n[o.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0435 \u0447\u0438\u0441\u043B\u043E: \u043F\u043E\u0432\u0438\u043D\u043D\u043E \u0431\u0443\u0442\u0438 \u043A\u0440\u0430\u0442\u043D\u0438\u043C ${r.divisor}`;
      case "unrecognized_keys":
        return `\u041D\u0435\u0440\u043E\u0437\u043F\u0456\u0437\u043D\u0430\u043D\u0438\u0439 \u043A\u043B\u044E\u0447${r.keys.length > 1 ? "\u0456" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u043A\u043B\u044E\u0447 \u0443 ${r.origin}`;
      case "invalid_union":
        return "\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456";
      case "invalid_element":
        return `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u043D\u044F \u0443 ${r.origin}`;
      default:
        return "\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456";
    }
  };
}, "error");
function Nr() {
  return {
    localeError: Sy()
  };
}
s(Nr, "default");

// versions/4.4.3/node_modules/zod/v4/locales/ua.js
function qc() {
  return Nr();
}
s(qc, "default");

// versions/4.4.3/node_modules/zod/v4/locales/ur.js
var jy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u062D\u0631\u0648\u0641", verb: "\u06C1\u0648\u0646\u0627" },
    file: { unit: "\u0628\u0627\u0626\u0679\u0633", verb: "\u06C1\u0648\u0646\u0627" },
    array: { unit: "\u0622\u0626\u0679\u0645\u0632", verb: "\u06C1\u0648\u0646\u0627" },
    set: { unit: "\u0622\u0626\u0679\u0645\u0632", verb: "\u06C1\u0648\u0646\u0627" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u0627\u0646 \u067E\u0679",
    email: "\u0627\u06CC \u0645\u06CC\u0644 \u0627\u06CC\u0688\u0631\u06CC\u0633",
    url: "\u06CC\u0648 \u0622\u0631 \u0627\u06CC\u0644",
    emoji: "\u0627\u06CC\u0645\u0648\u062C\u06CC",
    uuid: "\u06CC\u0648 \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC",
    uuidv4: "\u06CC\u0648 \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC \u0648\u06CC 4",
    uuidv6: "\u06CC\u0648 \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC \u0648\u06CC 6",
    nanoid: "\u0646\u06CC\u0646\u0648 \u0622\u0626\u06CC \u0688\u06CC",
    guid: "\u062C\u06CC \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC",
    cuid: "\u0633\u06CC \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC",
    cuid2: "\u0633\u06CC \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC 2",
    ulid: "\u06CC\u0648 \u0627\u06CC\u0644 \u0622\u0626\u06CC \u0688\u06CC",
    xid: "\u0627\u06CC\u06A9\u0633 \u0622\u0626\u06CC \u0688\u06CC",
    ksuid: "\u06A9\u06D2 \u0627\u06CC\u0633 \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC",
    datetime: "\u0622\u0626\u06CC \u0627\u06CC\u0633 \u0627\u0648 \u0688\u06CC\u0679 \u0679\u0627\u0626\u0645",
    date: "\u0622\u0626\u06CC \u0627\u06CC\u0633 \u0627\u0648 \u062A\u0627\u0631\u06CC\u062E",
    time: "\u0622\u0626\u06CC \u0627\u06CC\u0633 \u0627\u0648 \u0648\u0642\u062A",
    duration: "\u0622\u0626\u06CC \u0627\u06CC\u0633 \u0627\u0648 \u0645\u062F\u062A",
    ipv4: "\u0622\u0626\u06CC \u067E\u06CC \u0648\u06CC 4 \u0627\u06CC\u0688\u0631\u06CC\u0633",
    ipv6: "\u0622\u0626\u06CC \u067E\u06CC \u0648\u06CC 6 \u0627\u06CC\u0688\u0631\u06CC\u0633",
    cidrv4: "\u0622\u0626\u06CC \u067E\u06CC \u0648\u06CC 4 \u0631\u06CC\u0646\u062C",
    cidrv6: "\u0622\u0626\u06CC \u067E\u06CC \u0648\u06CC 6 \u0631\u06CC\u0646\u062C",
    base64: "\u0628\u06CC\u0633 64 \u0627\u0646 \u06A9\u0648\u0688\u0688 \u0633\u0679\u0631\u0646\u06AF",
    base64url: "\u0628\u06CC\u0633 64 \u06CC\u0648 \u0622\u0631 \u0627\u06CC\u0644 \u0627\u0646 \u06A9\u0648\u0688\u0688 \u0633\u0679\u0631\u0646\u06AF",
    json_string: "\u062C\u06D2 \u0627\u06CC\u0633 \u0627\u0648 \u0627\u06CC\u0646 \u0633\u0679\u0631\u0646\u06AF",
    e164: "\u0627\u06CC 164 \u0646\u0645\u0628\u0631",
    jwt: "\u062C\u06D2 \u0688\u0628\u0644\u06CC\u0648 \u0679\u06CC",
    template_literal: "\u0627\u0646 \u067E\u0679"
  }, i = {
    nan: "NaN",
    number: "\u0646\u0645\u0628\u0631",
    array: "\u0622\u0631\u06D2",
    null: "\u0646\u0644"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679: instanceof ${r.expected} \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627\u060C ${c} \u0645\u0648\u0635\u0648\u0644 \u06C1\u0648\u0627` : `\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679: ${o} \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627\u060C ${c} \u0645\u0648\u0635\u0648\u0644 \u06C1\u0648\u0627`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679: ${v(r.values[0])} \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627` : `\u063A\u0644\u0637 \u0622\u067E\u0634\u0646: ${p(r.values, "|")} \u0645\u06CC\u06BA \u0633\u06D2 \u0627\u06CC\u06A9 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627`;
      case "too_big": {
        let o = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `\u0628\u06C1\u062A \u0628\u0691\u0627: ${r.origin ?? "\u0648\u06CC\u0644\u06CC\u0648"} \u06A9\u06D2 ${o}${r.maximum.toString()} ${a.unit ?? "\u0639\u0646\u0627\u0635\u0631"} \u06C1\u0648\u0646\u06D2 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u06D2` : `\u0628\u06C1\u062A \u0628\u0691\u0627: ${r.origin ?? "\u0648\u06CC\u0644\u06CC\u0648"} \u06A9\u0627 ${o}${r.maximum.toString()} \u06C1\u0648\u0646\u0627 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627`;
      }
      case "too_small": {
        let o = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\u0628\u06C1\u062A \u0686\u06BE\u0648\u0679\u0627: ${r.origin} \u06A9\u06D2 ${o}${r.minimum.toString()} ${a.unit} \u06C1\u0648\u0646\u06D2 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u06D2` : `\u0628\u06C1\u062A \u0686\u06BE\u0648\u0679\u0627: ${r.origin} \u06A9\u0627 ${o}${r.minimum.toString()} \u06C1\u0648\u0646\u0627 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `\u063A\u0644\u0637 \u0633\u0679\u0631\u0646\u06AF: "${o.prefix}" \u0633\u06D2 \u0634\u0631\u0648\u0639 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2` : o.format === "ends_with" ? `\u063A\u0644\u0637 \u0633\u0679\u0631\u0646\u06AF: "${o.suffix}" \u067E\u0631 \u062E\u062A\u0645 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2` : o.format === "includes" ? `\u063A\u0644\u0637 \u0633\u0679\u0631\u0646\u06AF: "${o.includes}" \u0634\u0627\u0645\u0644 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2` : o.format === "regex" ? `\u063A\u0644\u0637 \u0633\u0679\u0631\u0646\u06AF: \u067E\u06CC\u0679\u0631\u0646 ${o.pattern} \u0633\u06D2 \u0645\u06CC\u0686 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2` : `\u063A\u0644\u0637 ${n[o.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u063A\u0644\u0637 \u0646\u0645\u0628\u0631: ${r.divisor} \u06A9\u0627 \u0645\u0636\u0627\u0639\u0641 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2`;
      case "unrecognized_keys":
        return `\u063A\u06CC\u0631 \u062A\u0633\u0644\u06CC\u0645 \u0634\u062F\u06C1 \u06A9\u06CC${r.keys.length > 1 ? "\u0632" : ""}: ${p(r.keys, "\u060C ")}`;
      case "invalid_key":
        return `${r.origin} \u0645\u06CC\u06BA \u063A\u0644\u0637 \u06A9\u06CC`;
      case "invalid_union":
        return "\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679";
      case "invalid_element":
        return `${r.origin} \u0645\u06CC\u06BA \u063A\u0644\u0637 \u0648\u06CC\u0644\u06CC\u0648`;
      default:
        return "\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679";
    }
  };
}, "error");
function Wc() {
  return {
    localeError: jy()
  };
}
s(Wc, "default");

// versions/4.4.3/node_modules/zod/v4/locales/uz.js
var Oy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "belgi", verb: "bo\u2018lishi kerak" },
    file: { unit: "bayt", verb: "bo\u2018lishi kerak" },
    array: { unit: "element", verb: "bo\u2018lishi kerak" },
    set: { unit: "element", verb: "bo\u2018lishi kerak" },
    map: { unit: "yozuv", verb: "bo\u2018lishi kerak" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "kirish",
    email: "elektron pochta manzili",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO sana va vaqti",
    date: "ISO sana",
    time: "ISO vaqt",
    duration: "ISO davomiylik",
    ipv4: "IPv4 manzil",
    ipv6: "IPv6 manzil",
    mac: "MAC manzil",
    cidrv4: "IPv4 diapazon",
    cidrv6: "IPv6 diapazon",
    base64: "base64 kodlangan satr",
    base64url: "base64url kodlangan satr",
    json_string: "JSON satr",
    e164: "E.164 raqam",
    jwt: "JWT",
    template_literal: "kirish"
  }, i = {
    nan: "NaN",
    number: "raqam",
    array: "massiv"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Noto\u2018g\u2018ri kirish: kutilgan instanceof ${r.expected}, qabul qilingan ${c}` : `Noto\u2018g\u2018ri kirish: kutilgan ${o}, qabul qilingan ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Noto\u2018g\u2018ri kirish: kutilgan ${v(r.values[0])}` : `Noto\u2018g\u2018ri variant: quyidagilardan biri kutilgan ${p(r.values, "|")}`;
      case "too_big": {
        let o = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Juda katta: kutilgan ${r.origin ?? "qiymat"} ${o}${r.maximum.toString()} ${a.unit} ${a.verb}` : `Juda katta: kutilgan ${r.origin ?? "qiymat"} ${o}${r.maximum.toString()}`;
      }
      case "too_small": {
        let o = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Juda kichik: kutilgan ${r.origin} ${o}${r.minimum.toString()} ${a.unit} ${a.verb}` : `Juda kichik: kutilgan ${r.origin} ${o}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `Noto\u2018g\u2018ri satr: "${o.prefix}" bilan boshlanishi kerak` : o.format === "ends_with" ? `Noto\u2018g\u2018ri satr: "${o.suffix}" bilan tugashi kerak` : o.format === "includes" ? `Noto\u2018g\u2018ri satr: "${o.includes}" ni o\u2018z ichiga olishi kerak` : o.format === "regex" ? `Noto\u2018g\u2018ri satr: ${o.pattern} shabloniga mos kelishi kerak` : `Noto\u2018g\u2018ri ${n[o.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Noto\u2018g\u2018ri raqam: ${r.divisor} ning karralisi bo\u2018lishi kerak`;
      case "unrecognized_keys":
        return `Noma\u2019lum kalit${r.keys.length > 1 ? "lar" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `${r.origin} dagi kalit noto\u2018g\u2018ri`;
      case "invalid_union":
        return "Noto\u2018g\u2018ri kirish";
      case "invalid_element":
        return `${r.origin} da noto\u2018g\u2018ri qiymat`;
      default:
        return "Noto\u2018g\u2018ri kirish";
    }
  };
}, "error");
function Kc() {
  return {
    localeError: Oy()
  };
}
s(Kc, "default");

// versions/4.4.3/node_modules/zod/v4/locales/vi.js
var Py = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "k\xFD t\u1EF1", verb: "c\xF3" },
    file: { unit: "byte", verb: "c\xF3" },
    array: { unit: "ph\u1EA7n t\u1EED", verb: "c\xF3" },
    set: { unit: "ph\u1EA7n t\u1EED", verb: "c\xF3" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u0111\u1EA7u v\xE0o",
    email: "\u0111\u1ECBa ch\u1EC9 email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ng\xE0y gi\u1EDD ISO",
    date: "ng\xE0y ISO",
    time: "gi\u1EDD ISO",
    duration: "kho\u1EA3ng th\u1EDDi gian ISO",
    ipv4: "\u0111\u1ECBa ch\u1EC9 IPv4",
    ipv6: "\u0111\u1ECBa ch\u1EC9 IPv6",
    cidrv4: "d\u1EA3i IPv4",
    cidrv6: "d\u1EA3i IPv6",
    base64: "chu\u1ED7i m\xE3 h\xF3a base64",
    base64url: "chu\u1ED7i m\xE3 h\xF3a base64url",
    json_string: "chu\u1ED7i JSON",
    e164: "s\u1ED1 E.164",
    jwt: "JWT",
    template_literal: "\u0111\u1EA7u v\xE0o"
  }, i = {
    nan: "NaN",
    number: "s\u1ED1",
    array: "m\u1EA3ng"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7: mong \u0111\u1EE3i instanceof ${r.expected}, nh\u1EADn \u0111\u01B0\u1EE3c ${c}` : `\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7: mong \u0111\u1EE3i ${o}, nh\u1EADn \u0111\u01B0\u1EE3c ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7: mong \u0111\u1EE3i ${v(r.values[0])}` : `T\xF9y ch\u1ECDn kh\xF4ng h\u1EE3p l\u1EC7: mong \u0111\u1EE3i m\u1ED9t trong c\xE1c gi\xE1 tr\u1ECB ${p(r.values, "|")}`;
      case "too_big": {
        let o = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Qu\xE1 l\u1EDBn: mong \u0111\u1EE3i ${r.origin ?? "gi\xE1 tr\u1ECB"} ${a.verb} ${o}${r.maximum.toString()} ${a.unit ?? "ph\u1EA7n t\u1EED"}` : `Qu\xE1 l\u1EDBn: mong \u0111\u1EE3i ${r.origin ?? "gi\xE1 tr\u1ECB"} ${o}${r.maximum.toString()}`;
      }
      case "too_small": {
        let o = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Qu\xE1 nh\u1ECF: mong \u0111\u1EE3i ${r.origin} ${a.verb} ${o}${r.minimum.toString()} ${a.unit}` : `Qu\xE1 nh\u1ECF: mong \u0111\u1EE3i ${r.origin} ${o}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `Chu\u1ED7i kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i b\u1EAFt \u0111\u1EA7u b\u1EB1ng "${o.prefix}"` : o.format === "ends_with" ? `Chu\u1ED7i kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i k\u1EBFt th\xFAc b\u1EB1ng "${o.suffix}"` : o.format === "includes" ? `Chu\u1ED7i kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i bao g\u1ED3m "${o.includes}"` : o.format === "regex" ? `Chu\u1ED7i kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i kh\u1EDBp v\u1EDBi m\u1EABu ${o.pattern}` : `${n[o.format] ?? r.format} kh\xF4ng h\u1EE3p l\u1EC7`;
      }
      case "not_multiple_of":
        return `S\u1ED1 kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i l\xE0 b\u1ED9i s\u1ED1 c\u1EE7a ${r.divisor}`;
      case "unrecognized_keys":
        return `Kh\xF3a kh\xF4ng \u0111\u01B0\u1EE3c nh\u1EADn d\u1EA1ng: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Kh\xF3a kh\xF4ng h\u1EE3p l\u1EC7 trong ${r.origin}`;
      case "invalid_union":
        return "\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7";
      case "invalid_element":
        return `Gi\xE1 tr\u1ECB kh\xF4ng h\u1EE3p l\u1EC7 trong ${r.origin}`;
      default:
        return "\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7";
    }
  };
}, "error");
function Gc() {
  return {
    localeError: Py()
  };
}
s(Gc, "default");

// versions/4.4.3/node_modules/zod/v4/locales/zh-CN.js
var Ty = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u5B57\u7B26", verb: "\u5305\u542B" },
    file: { unit: "\u5B57\u8282", verb: "\u5305\u542B" },
    array: { unit: "\u9879", verb: "\u5305\u542B" },
    set: { unit: "\u9879", verb: "\u5305\u542B" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u8F93\u5165",
    email: "\u7535\u5B50\u90AE\u4EF6",
    url: "URL",
    emoji: "\u8868\u60C5\u7B26\u53F7",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO\u65E5\u671F\u65F6\u95F4",
    date: "ISO\u65E5\u671F",
    time: "ISO\u65F6\u95F4",
    duration: "ISO\u65F6\u957F",
    ipv4: "IPv4\u5730\u5740",
    ipv6: "IPv6\u5730\u5740",
    cidrv4: "IPv4\u7F51\u6BB5",
    cidrv6: "IPv6\u7F51\u6BB5",
    base64: "base64\u7F16\u7801\u5B57\u7B26\u4E32",
    base64url: "base64url\u7F16\u7801\u5B57\u7B26\u4E32",
    json_string: "JSON\u5B57\u7B26\u4E32",
    e164: "E.164\u53F7\u7801",
    jwt: "JWT",
    template_literal: "\u8F93\u5165"
  }, i = {
    nan: "NaN",
    number: "\u6570\u5B57",
    array: "\u6570\u7EC4",
    null: "\u7A7A\u503C(null)"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u65E0\u6548\u8F93\u5165\uFF1A\u671F\u671B instanceof ${r.expected}\uFF0C\u5B9E\u9645\u63A5\u6536 ${c}` : `\u65E0\u6548\u8F93\u5165\uFF1A\u671F\u671B ${o}\uFF0C\u5B9E\u9645\u63A5\u6536 ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u65E0\u6548\u8F93\u5165\uFF1A\u671F\u671B ${v(r.values[0])}` : `\u65E0\u6548\u9009\u9879\uFF1A\u671F\u671B\u4EE5\u4E0B\u4E4B\u4E00 ${p(r.values, "|")}`;
      case "too_big": {
        let o = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `\u6570\u503C\u8FC7\u5927\uFF1A\u671F\u671B ${r.origin ?? "\u503C"} ${o}${r.maximum.toString()} ${a.unit ?? "\u4E2A\u5143\u7D20"}` : `\u6570\u503C\u8FC7\u5927\uFF1A\u671F\u671B ${r.origin ?? "\u503C"} ${o}${r.maximum.toString()}`;
      }
      case "too_small": {
        let o = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\u6570\u503C\u8FC7\u5C0F\uFF1A\u671F\u671B ${r.origin} ${o}${r.minimum.toString()} ${a.unit}` : `\u6570\u503C\u8FC7\u5C0F\uFF1A\u671F\u671B ${r.origin} ${o}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `\u65E0\u6548\u5B57\u7B26\u4E32\uFF1A\u5FC5\u987B\u4EE5 "${o.prefix}" \u5F00\u5934` : o.format === "ends_with" ? `\u65E0\u6548\u5B57\u7B26\u4E32\uFF1A\u5FC5\u987B\u4EE5 "${o.suffix}" \u7ED3\u5C3E` : o.format === "includes" ? `\u65E0\u6548\u5B57\u7B26\u4E32\uFF1A\u5FC5\u987B\u5305\u542B "${o.includes}"` : o.format === "regex" ? `\u65E0\u6548\u5B57\u7B26\u4E32\uFF1A\u5FC5\u987B\u6EE1\u8DB3\u6B63\u5219\u8868\u8FBE\u5F0F ${o.pattern}` : `\u65E0\u6548${n[o.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u65E0\u6548\u6570\u5B57\uFF1A\u5FC5\u987B\u662F ${r.divisor} \u7684\u500D\u6570`;
      case "unrecognized_keys":
        return `\u51FA\u73B0\u672A\u77E5\u7684\u952E(key): ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `${r.origin} \u4E2D\u7684\u952E(key)\u65E0\u6548`;
      case "invalid_union":
        return "\u65E0\u6548\u8F93\u5165";
      case "invalid_element":
        return `${r.origin} \u4E2D\u5305\u542B\u65E0\u6548\u503C(value)`;
      default:
        return "\u65E0\u6548\u8F93\u5165";
    }
  };
}, "error");
function Xc() {
  return {
    localeError: Ty()
  };
}
s(Xc, "default");

// versions/4.4.3/node_modules/zod/v4/locales/zh-TW.js
var Ey = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u5B57\u5143", verb: "\u64C1\u6709" },
    file: { unit: "\u4F4D\u5143\u7D44", verb: "\u64C1\u6709" },
    array: { unit: "\u9805\u76EE", verb: "\u64C1\u6709" },
    set: { unit: "\u9805\u76EE", verb: "\u64C1\u6709" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u8F38\u5165",
    email: "\u90F5\u4EF6\u5730\u5740",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u65E5\u671F\u6642\u9593",
    date: "ISO \u65E5\u671F",
    time: "ISO \u6642\u9593",
    duration: "ISO \u671F\u9593",
    ipv4: "IPv4 \u4F4D\u5740",
    ipv6: "IPv6 \u4F4D\u5740",
    cidrv4: "IPv4 \u7BC4\u570D",
    cidrv6: "IPv6 \u7BC4\u570D",
    base64: "base64 \u7DE8\u78BC\u5B57\u4E32",
    base64url: "base64url \u7DE8\u78BC\u5B57\u4E32",
    json_string: "JSON \u5B57\u4E32",
    e164: "E.164 \u6578\u503C",
    jwt: "JWT",
    template_literal: "\u8F38\u5165"
  }, i = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u7121\u6548\u7684\u8F38\u5165\u503C\uFF1A\u9810\u671F\u70BA instanceof ${r.expected}\uFF0C\u4F46\u6536\u5230 ${c}` : `\u7121\u6548\u7684\u8F38\u5165\u503C\uFF1A\u9810\u671F\u70BA ${o}\uFF0C\u4F46\u6536\u5230 ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u7121\u6548\u7684\u8F38\u5165\u503C\uFF1A\u9810\u671F\u70BA ${v(r.values[0])}` : `\u7121\u6548\u7684\u9078\u9805\uFF1A\u9810\u671F\u70BA\u4EE5\u4E0B\u5176\u4E2D\u4E4B\u4E00 ${p(r.values, "|")}`;
      case "too_big": {
        let o = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `\u6578\u503C\u904E\u5927\uFF1A\u9810\u671F ${r.origin ?? "\u503C"} \u61C9\u70BA ${o}${r.maximum.toString()} ${a.unit ?? "\u500B\u5143\u7D20"}` : `\u6578\u503C\u904E\u5927\uFF1A\u9810\u671F ${r.origin ?? "\u503C"} \u61C9\u70BA ${o}${r.maximum.toString()}`;
      }
      case "too_small": {
        let o = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\u6578\u503C\u904E\u5C0F\uFF1A\u9810\u671F ${r.origin} \u61C9\u70BA ${o}${r.minimum.toString()} ${a.unit}` : `\u6578\u503C\u904E\u5C0F\uFF1A\u9810\u671F ${r.origin} \u61C9\u70BA ${o}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `\u7121\u6548\u7684\u5B57\u4E32\uFF1A\u5FC5\u9808\u4EE5 "${o.prefix}" \u958B\u982D` : o.format === "ends_with" ? `\u7121\u6548\u7684\u5B57\u4E32\uFF1A\u5FC5\u9808\u4EE5 "${o.suffix}" \u7D50\u5C3E` : o.format === "includes" ? `\u7121\u6548\u7684\u5B57\u4E32\uFF1A\u5FC5\u9808\u5305\u542B "${o.includes}"` : o.format === "regex" ? `\u7121\u6548\u7684\u5B57\u4E32\uFF1A\u5FC5\u9808\u7B26\u5408\u683C\u5F0F ${o.pattern}` : `\u7121\u6548\u7684 ${n[o.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u7121\u6548\u7684\u6578\u5B57\uFF1A\u5FC5\u9808\u70BA ${r.divisor} \u7684\u500D\u6578`;
      case "unrecognized_keys":
        return `\u7121\u6CD5\u8B58\u5225\u7684\u9375\u503C${r.keys.length > 1 ? "\u5011" : ""}\uFF1A${p(r.keys, "\u3001")}`;
      case "invalid_key":
        return `${r.origin} \u4E2D\u6709\u7121\u6548\u7684\u9375\u503C`;
      case "invalid_union":
        return "\u7121\u6548\u7684\u8F38\u5165\u503C";
      case "invalid_element":
        return `${r.origin} \u4E2D\u6709\u7121\u6548\u7684\u503C`;
      default:
        return "\u7121\u6548\u7684\u8F38\u5165\u503C";
    }
  };
}, "error");
function Qc() {
  return {
    localeError: Ey()
  };
}
s(Qc, "default");

// versions/4.4.3/node_modules/zod/v4/locales/yo.js
var Uy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\xE0mi", verb: "n\xED" },
    file: { unit: "bytes", verb: "n\xED" },
    array: { unit: "nkan", verb: "n\xED" },
    set: { unit: "nkan", verb: "n\xED" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u1EB9\u0300r\u1ECD \xECb\xE1w\u1ECDl\xE9",
    email: "\xE0d\xEDr\u1EB9\u0301s\xEC \xECm\u1EB9\u0301l\xEC",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\xE0k\xF3k\xF2 ISO",
    date: "\u1ECDj\u1ECD\u0301 ISO",
    time: "\xE0k\xF3k\xF2 ISO",
    duration: "\xE0k\xF3k\xF2 t\xF3 p\xE9 ISO",
    ipv4: "\xE0d\xEDr\u1EB9\u0301s\xEC IPv4",
    ipv6: "\xE0d\xEDr\u1EB9\u0301s\xEC IPv6",
    cidrv4: "\xE0gb\xE8gb\xE8 IPv4",
    cidrv6: "\xE0gb\xE8gb\xE8 IPv6",
    base64: "\u1ECD\u0300r\u1ECD\u0300 t\xED a k\u1ECD\u0301 n\xED base64",
    base64url: "\u1ECD\u0300r\u1ECD\u0300 base64url",
    json_string: "\u1ECD\u0300r\u1ECD\u0300 JSON",
    e164: "n\u1ECD\u0301mb\xE0 E.164",
    jwt: "JWT",
    template_literal: "\u1EB9\u0300r\u1ECD \xECb\xE1w\u1ECDl\xE9"
  }, i = {
    nan: "NaN",
    number: "n\u1ECD\u0301mb\xE0",
    array: "akop\u1ECD"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let o = i[r.expected] ?? r.expected, a = b(r.input), c = i[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e: a n\xED l\xE1ti fi instanceof ${r.expected}, \xE0m\u1ECD\u0300 a r\xED ${c}` : `\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e: a n\xED l\xE1ti fi ${o}, \xE0m\u1ECD\u0300 a r\xED ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e: a n\xED l\xE1ti fi ${v(r.values[0])}` : `\xC0\u1E63\xE0y\xE0n a\u1E63\xEC\u1E63e: yan \u1ECD\u0300kan l\xE1ra ${p(r.values, "|")}`;
      case "too_big": {
        let o = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `T\xF3 p\u1ECD\u0300 j\xF9: a n\xED l\xE1ti j\u1EB9\u0301 p\xE9 ${r.origin ?? "iye"} ${a.verb} ${o}${r.maximum} ${a.unit}` : `T\xF3 p\u1ECD\u0300 j\xF9: a n\xED l\xE1ti j\u1EB9\u0301 ${o}${r.maximum}`;
      }
      case "too_small": {
        let o = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `K\xE9r\xE9 ju: a n\xED l\xE1ti j\u1EB9\u0301 p\xE9 ${r.origin} ${a.verb} ${o}${r.minimum} ${a.unit}` : `K\xE9r\xE9 ju: a n\xED l\xE1ti j\u1EB9\u0301 ${o}${r.minimum}`;
      }
      case "invalid_format": {
        let o = r;
        return o.format === "starts_with" ? `\u1ECC\u0300r\u1ECD\u0300 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 b\u1EB9\u0300r\u1EB9\u0300 p\u1EB9\u0300l\xFA "${o.prefix}"` : o.format === "ends_with" ? `\u1ECC\u0300r\u1ECD\u0300 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 par\xED p\u1EB9\u0300l\xFA "${o.suffix}"` : o.format === "includes" ? `\u1ECC\u0300r\u1ECD\u0300 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 n\xED "${o.includes}"` : o.format === "regex" ? `\u1ECC\u0300r\u1ECD\u0300 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 b\xE1 \xE0p\u1EB9\u1EB9r\u1EB9 mu ${o.pattern}` : `A\u1E63\xEC\u1E63e: ${n[o.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `N\u1ECD\u0301mb\xE0 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 j\u1EB9\u0301 \xE8y\xE0 p\xEDp\xEDn ti ${r.divisor}`;
      case "unrecognized_keys":
        return `B\u1ECDt\xECn\xEC \xE0\xECm\u1ECD\u0300: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `B\u1ECDt\xECn\xEC a\u1E63\xEC\u1E63e n\xEDn\xFA ${r.origin}`;
      case "invalid_union":
        return "\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e";
      case "invalid_element":
        return `Iye a\u1E63\xEC\u1E63e n\xEDn\xFA ${r.origin}`;
      default:
        return "\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e";
    }
  };
}, "error");
function Hc() {
  return {
    localeError: Uy()
  };
}
s(Hc, "default");

// versions/4.4.3/node_modules/zod/v4/core/registries.js
var up, Yc = Symbol("ZodOutput"), eu = Symbol("ZodInput"), Gn = class {
  static {
    s(this, "$ZodRegistry");
  }
  constructor() {
    this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map();
  }
  add(t, ...n) {
    let i = n[0];
    return this._map.set(t, i), i && typeof i == "object" && "id" in i && this._idmap.set(i.id, t), this;
  }
  clear() {
    return this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map(), this;
  }
  remove(t) {
    let n = this._map.get(t);
    return n && typeof n == "object" && "id" in n && this._idmap.delete(n.id), this._map.delete(t), this;
  }
  get(t) {
    let n = t._zod.parent;
    if (n) {
      let i = { ...this.get(n) ?? {} };
      delete i.id;
      let r = { ...i, ...this._map.get(t) };
      return Object.keys(r).length ? r : void 0;
    }
    return this._map.get(t);
  }
  has(t) {
    return this._map.has(t);
  }
};
function Xn() {
  return new Gn();
}
s(Xn, "registry");
(up = globalThis).__zod_globalRegistry ?? (up.__zod_globalRegistry = Xn());
var H = globalThis.__zod_globalRegistry;

// versions/4.4.3/node_modules/zod/v4/core/api.js
// @__NO_SIDE_EFFECTS__
function tu(e, t) {
  return new e({
    type: "string",
    ...x(t)
  });
}
s(tu, "_string");
// @__NO_SIDE_EFFECTS__
function ru(e, t) {
  return new e({
    type: "string",
    coerce: !0,
    ...x(t)
  });
}
s(ru, "_coercedString");
// @__NO_SIDE_EFFECTS__
function Qn(e, t) {
  return new e({
    type: "string",
    format: "email",
    check: "string_format",
    abort: !1,
    ...x(t)
  });
}
s(Qn, "_email");
// @__NO_SIDE_EFFECTS__
function Ar(e, t) {
  return new e({
    type: "string",
    format: "guid",
    check: "string_format",
    abort: !1,
    ...x(t)
  });
}
s(Ar, "_guid");
// @__NO_SIDE_EFFECTS__
function Hn(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    ...x(t)
  });
}
s(Hn, "_uuid");
// @__NO_SIDE_EFFECTS__
function Yn(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v4",
    ...x(t)
  });
}
s(Yn, "_uuidv4");
// @__NO_SIDE_EFFECTS__
function ei(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v6",
    ...x(t)
  });
}
s(ei, "_uuidv6");
// @__NO_SIDE_EFFECTS__
function ti(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v7",
    ...x(t)
  });
}
s(ti, "_uuidv7");
// @__NO_SIDE_EFFECTS__
function Cr(e, t) {
  return new e({
    type: "string",
    format: "url",
    check: "string_format",
    abort: !1,
    ...x(t)
  });
}
s(Cr, "_url");
// @__NO_SIDE_EFFECTS__
function ri(e, t) {
  return new e({
    type: "string",
    format: "emoji",
    check: "string_format",
    abort: !1,
    ...x(t)
  });
}
s(ri, "_emoji");
// @__NO_SIDE_EFFECTS__
function ni(e, t) {
  return new e({
    type: "string",
    format: "nanoid",
    check: "string_format",
    abort: !1,
    ...x(t)
  });
}
s(ni, "_nanoid");
// @__NO_SIDE_EFFECTS__
function ii(e, t) {
  return new e({
    type: "string",
    format: "cuid",
    check: "string_format",
    abort: !1,
    ...x(t)
  });
}
s(ii, "_cuid");
// @__NO_SIDE_EFFECTS__
function oi(e, t) {
  return new e({
    type: "string",
    format: "cuid2",
    check: "string_format",
    abort: !1,
    ...x(t)
  });
}
s(oi, "_cuid2");
// @__NO_SIDE_EFFECTS__
function ai(e, t) {
  return new e({
    type: "string",
    format: "ulid",
    check: "string_format",
    abort: !1,
    ...x(t)
  });
}
s(ai, "_ulid");
// @__NO_SIDE_EFFECTS__
function si(e, t) {
  return new e({
    type: "string",
    format: "xid",
    check: "string_format",
    abort: !1,
    ...x(t)
  });
}
s(si, "_xid");
// @__NO_SIDE_EFFECTS__
function ci(e, t) {
  return new e({
    type: "string",
    format: "ksuid",
    check: "string_format",
    abort: !1,
    ...x(t)
  });
}
s(ci, "_ksuid");
// @__NO_SIDE_EFFECTS__
function ui(e, t) {
  return new e({
    type: "string",
    format: "ipv4",
    check: "string_format",
    abort: !1,
    ...x(t)
  });
}
s(ui, "_ipv4");
// @__NO_SIDE_EFFECTS__
function li(e, t) {
  return new e({
    type: "string",
    format: "ipv6",
    check: "string_format",
    abort: !1,
    ...x(t)
  });
}
s(li, "_ipv6");
// @__NO_SIDE_EFFECTS__
function nu(e, t) {
  return new e({
    type: "string",
    format: "mac",
    check: "string_format",
    abort: !1,
    ...x(t)
  });
}
s(nu, "_mac");
// @__NO_SIDE_EFFECTS__
function di(e, t) {
  return new e({
    type: "string",
    format: "cidrv4",
    check: "string_format",
    abort: !1,
    ...x(t)
  });
}
s(di, "_cidrv4");
// @__NO_SIDE_EFFECTS__
function fi(e, t) {
  return new e({
    type: "string",
    format: "cidrv6",
    check: "string_format",
    abort: !1,
    ...x(t)
  });
}
s(fi, "_cidrv6");
// @__NO_SIDE_EFFECTS__
function pi(e, t) {
  return new e({
    type: "string",
    format: "base64",
    check: "string_format",
    abort: !1,
    ...x(t)
  });
}
s(pi, "_base64");
// @__NO_SIDE_EFFECTS__
function mi(e, t) {
  return new e({
    type: "string",
    format: "base64url",
    check: "string_format",
    abort: !1,
    ...x(t)
  });
}
s(mi, "_base64url");
// @__NO_SIDE_EFFECTS__
function gi(e, t) {
  return new e({
    type: "string",
    format: "e164",
    check: "string_format",
    abort: !1,
    ...x(t)
  });
}
s(gi, "_e164");
// @__NO_SIDE_EFFECTS__
function hi(e, t) {
  return new e({
    type: "string",
    format: "jwt",
    check: "string_format",
    abort: !1,
    ...x(t)
  });
}
s(hi, "_jwt");
var iu = {
  Any: null,
  Minute: -1,
  Second: 0,
  Millisecond: 3,
  Microsecond: 6
};
// @__NO_SIDE_EFFECTS__
function ou(e, t) {
  return new e({
    type: "string",
    format: "datetime",
    check: "string_format",
    offset: !1,
    local: !1,
    precision: null,
    ...x(t)
  });
}
s(ou, "_isoDateTime");
// @__NO_SIDE_EFFECTS__
function au(e, t) {
  return new e({
    type: "string",
    format: "date",
    check: "string_format",
    ...x(t)
  });
}
s(au, "_isoDate");
// @__NO_SIDE_EFFECTS__
function su(e, t) {
  return new e({
    type: "string",
    format: "time",
    check: "string_format",
    precision: null,
    ...x(t)
  });
}
s(su, "_isoTime");
// @__NO_SIDE_EFFECTS__
function cu(e, t) {
  return new e({
    type: "string",
    format: "duration",
    check: "string_format",
    ...x(t)
  });
}
s(cu, "_isoDuration");
// @__NO_SIDE_EFFECTS__
function uu(e, t) {
  return new e({
    type: "number",
    checks: [],
    ...x(t)
  });
}
s(uu, "_number");
// @__NO_SIDE_EFFECTS__
function lu(e, t) {
  return new e({
    type: "number",
    coerce: !0,
    checks: [],
    ...x(t)
  });
}
s(lu, "_coercedNumber");
// @__NO_SIDE_EFFECTS__
function du(e, t) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "safeint",
    ...x(t)
  });
}
s(du, "_int");
// @__NO_SIDE_EFFECTS__
function fu(e, t) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "float32",
    ...x(t)
  });
}
s(fu, "_float32");
// @__NO_SIDE_EFFECTS__
function pu(e, t) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "float64",
    ...x(t)
  });
}
s(pu, "_float64");
// @__NO_SIDE_EFFECTS__
function mu(e, t) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "int32",
    ...x(t)
  });
}
s(mu, "_int32");
// @__NO_SIDE_EFFECTS__
function gu(e, t) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "uint32",
    ...x(t)
  });
}
s(gu, "_uint32");
// @__NO_SIDE_EFFECTS__
function hu(e, t) {
  return new e({
    type: "boolean",
    ...x(t)
  });
}
s(hu, "_boolean");
// @__NO_SIDE_EFFECTS__
function vu(e, t) {
  return new e({
    type: "boolean",
    coerce: !0,
    ...x(t)
  });
}
s(vu, "_coercedBoolean");
// @__NO_SIDE_EFFECTS__
function yu(e, t) {
  return new e({
    type: "bigint",
    ...x(t)
  });
}
s(yu, "_bigint");
// @__NO_SIDE_EFFECTS__
function bu(e, t) {
  return new e({
    type: "bigint",
    coerce: !0,
    ...x(t)
  });
}
s(bu, "_coercedBigint");
// @__NO_SIDE_EFFECTS__
function $u(e, t) {
  return new e({
    type: "bigint",
    check: "bigint_format",
    abort: !1,
    format: "int64",
    ...x(t)
  });
}
s($u, "_int64");
// @__NO_SIDE_EFFECTS__
function xu(e, t) {
  return new e({
    type: "bigint",
    check: "bigint_format",
    abort: !1,
    format: "uint64",
    ...x(t)
  });
}
s(xu, "_uint64");
// @__NO_SIDE_EFFECTS__
function _u(e, t) {
  return new e({
    type: "symbol",
    ...x(t)
  });
}
s(_u, "_symbol");
// @__NO_SIDE_EFFECTS__
function wu(e, t) {
  return new e({
    type: "undefined",
    ...x(t)
  });
}
s(wu, "_undefined");
// @__NO_SIDE_EFFECTS__
function ku(e, t) {
  return new e({
    type: "null",
    ...x(t)
  });
}
s(ku, "_null");
// @__NO_SIDE_EFFECTS__
function zu(e) {
  return new e({
    type: "any"
  });
}
s(zu, "_any");
// @__NO_SIDE_EFFECTS__
function Iu(e) {
  return new e({
    type: "unknown"
  });
}
s(Iu, "_unknown");
// @__NO_SIDE_EFFECTS__
function Su(e, t) {
  return new e({
    type: "never",
    ...x(t)
  });
}
s(Su, "_never");
// @__NO_SIDE_EFFECTS__
function ju(e, t) {
  return new e({
    type: "void",
    ...x(t)
  });
}
s(ju, "_void");
// @__NO_SIDE_EFFECTS__
function Ou(e, t) {
  return new e({
    type: "date",
    ...x(t)
  });
}
s(Ou, "_date");
// @__NO_SIDE_EFFECTS__
function Pu(e, t) {
  return new e({
    type: "date",
    coerce: !0,
    ...x(t)
  });
}
s(Pu, "_coercedDate");
// @__NO_SIDE_EFFECTS__
function Tu(e, t) {
  return new e({
    type: "nan",
    ...x(t)
  });
}
s(Tu, "_nan");
// @__NO_SIDE_EFFECTS__
function ze(e, t) {
  return new Fn({
    check: "less_than",
    ...x(t),
    value: e,
    inclusive: !1
  });
}
s(ze, "_lt");
// @__NO_SIDE_EFFECTS__
function de(e, t) {
  return new Fn({
    check: "less_than",
    ...x(t),
    value: e,
    inclusive: !0
  });
}
s(de, "_lte");
// @__NO_SIDE_EFFECTS__
function Ie(e, t) {
  return new Ln({
    check: "greater_than",
    ...x(t),
    value: e,
    inclusive: !1
  });
}
s(Ie, "_gt");
// @__NO_SIDE_EFFECTS__
function ne(e, t) {
  return new Ln({
    check: "greater_than",
    ...x(t),
    value: e,
    inclusive: !0
  });
}
s(ne, "_gte");
// @__NO_SIDE_EFFECTS__
function vi(e) {
  return /* @__PURE__ */ Ie(0, e);
}
s(vi, "_positive");
// @__NO_SIDE_EFFECTS__
function yi(e) {
  return /* @__PURE__ */ ze(0, e);
}
s(yi, "_negative");
// @__NO_SIDE_EFFECTS__
function bi(e) {
  return /* @__PURE__ */ de(0, e);
}
s(bi, "_nonpositive");
// @__NO_SIDE_EFFECTS__
function $i(e) {
  return /* @__PURE__ */ ne(0, e);
}
s($i, "_nonnegative");
// @__NO_SIDE_EFFECTS__
function Je(e, t) {
  return new Ra({
    check: "multiple_of",
    ...x(t),
    value: e
  });
}
s(Je, "_multipleOf");
// @__NO_SIDE_EFFECTS__
function Ve(e, t) {
  return new Ma({
    check: "max_size",
    ...x(t),
    maximum: e
  });
}
s(Ve, "_maxSize");
// @__NO_SIDE_EFFECTS__
function Se(e, t) {
  return new Ba({
    check: "min_size",
    ...x(t),
    minimum: e
  });
}
s(Se, "_minSize");
// @__NO_SIDE_EFFECTS__
function st(e, t) {
  return new Ja({
    check: "size_equals",
    ...x(t),
    size: e
  });
}
s(st, "_size");
// @__NO_SIDE_EFFECTS__
function ct(e, t) {
  return new Va({
    check: "max_length",
    ...x(t),
    maximum: e
  });
}
s(ct, "_maxLength");
// @__NO_SIDE_EFFECTS__
function Ee(e, t) {
  return new qa({
    check: "min_length",
    ...x(t),
    minimum: e
  });
}
s(Ee, "_minLength");
// @__NO_SIDE_EFFECTS__
function ut(e, t) {
  return new Wa({
    check: "length_equals",
    ...x(t),
    length: e
  });
}
s(ut, "_length");
// @__NO_SIDE_EFFECTS__
function Rt(e, t) {
  return new Ka({
    check: "string_format",
    format: "regex",
    ...x(t),
    pattern: e
  });
}
s(Rt, "_regex");
// @__NO_SIDE_EFFECTS__
function Ft(e) {
  return new Ga({
    check: "string_format",
    format: "lowercase",
    ...x(e)
  });
}
s(Ft, "_lowercase");
// @__NO_SIDE_EFFECTS__
function Lt(e) {
  return new Xa({
    check: "string_format",
    format: "uppercase",
    ...x(e)
  });
}
s(Lt, "_uppercase");
// @__NO_SIDE_EFFECTS__
function Mt(e, t) {
  return new Qa({
    check: "string_format",
    format: "includes",
    ...x(t),
    includes: e
  });
}
s(Mt, "_includes");
// @__NO_SIDE_EFFECTS__
function Bt(e, t) {
  return new Ha({
    check: "string_format",
    format: "starts_with",
    ...x(t),
    prefix: e
  });
}
s(Bt, "_startsWith");
// @__NO_SIDE_EFFECTS__
function Jt(e, t) {
  return new Ya({
    check: "string_format",
    format: "ends_with",
    ...x(t),
    suffix: e
  });
}
s(Jt, "_endsWith");
// @__NO_SIDE_EFFECTS__
function xi(e, t, n) {
  return new es({
    check: "property",
    property: e,
    schema: t,
    ...x(n)
  });
}
s(xi, "_property");
// @__NO_SIDE_EFFECTS__
function Vt(e, t) {
  return new ts({
    check: "mime_type",
    mime: e,
    ...x(t)
  });
}
s(Vt, "_mime");
// @__NO_SIDE_EFFECTS__
function xe(e) {
  return new rs({
    check: "overwrite",
    tx: e
  });
}
s(xe, "_overwrite");
// @__NO_SIDE_EFFECTS__
function qt(e) {
  return /* @__PURE__ */ xe((t) => t.normalize(e));
}
s(qt, "_normalize");
// @__NO_SIDE_EFFECTS__
function Wt() {
  return /* @__PURE__ */ xe((e) => e.trim());
}
s(Wt, "_trim");
// @__NO_SIDE_EFFECTS__
function Kt() {
  return /* @__PURE__ */ xe((e) => e.toLowerCase());
}
s(Kt, "_toLowerCase");
// @__NO_SIDE_EFFECTS__
function Gt() {
  return /* @__PURE__ */ xe((e) => e.toUpperCase());
}
s(Gt, "_toUpperCase");
// @__NO_SIDE_EFFECTS__
function Xt() {
  return /* @__PURE__ */ xe((e) => Yo(e));
}
s(Xt, "_slugify");
// @__NO_SIDE_EFFECTS__
function Eu(e, t, n) {
  return new e({
    type: "array",
    element: t,
    // get element() {
    //   return element;
    // },
    ...x(n)
  });
}
s(Eu, "_array");
// @__NO_SIDE_EFFECTS__
function Ny(e, t, n) {
  return new e({
    type: "union",
    options: t,
    ...x(n)
  });
}
s(Ny, "_union");
function Zy(e, t, n) {
  return new e({
    type: "union",
    options: t,
    inclusive: !1,
    ...x(n)
  });
}
s(Zy, "_xor");
// @__NO_SIDE_EFFECTS__
function Ay(e, t, n, i) {
  return new e({
    type: "union",
    options: n,
    discriminator: t,
    ...x(i)
  });
}
s(Ay, "_discriminatedUnion");
// @__NO_SIDE_EFFECTS__
function Cy(e, t, n) {
  return new e({
    type: "intersection",
    left: t,
    right: n
  });
}
s(Cy, "_intersection");
// @__NO_SIDE_EFFECTS__
function Ry(e, t, n, i) {
  let r = n instanceof k, o = r ? i : n, a = r ? n : null;
  return new e({
    type: "tuple",
    items: t,
    rest: a,
    ...x(o)
  });
}
s(Ry, "_tuple");
// @__NO_SIDE_EFFECTS__
function Fy(e, t, n, i) {
  return new e({
    type: "record",
    keyType: t,
    valueType: n,
    ...x(i)
  });
}
s(Fy, "_record");
// @__NO_SIDE_EFFECTS__
function Ly(e, t, n, i) {
  return new e({
    type: "map",
    keyType: t,
    valueType: n,
    ...x(i)
  });
}
s(Ly, "_map");
// @__NO_SIDE_EFFECTS__
function My(e, t, n) {
  return new e({
    type: "set",
    valueType: t,
    ...x(n)
  });
}
s(My, "_set");
// @__NO_SIDE_EFFECTS__
function By(e, t, n) {
  let i = Array.isArray(t) ? Object.fromEntries(t.map((r) => [r, r])) : t;
  return new e({
    type: "enum",
    entries: i,
    ...x(n)
  });
}
s(By, "_enum");
// @__NO_SIDE_EFFECTS__
function Jy(e, t, n) {
  return new e({
    type: "enum",
    entries: t,
    ...x(n)
  });
}
s(Jy, "_nativeEnum");
// @__NO_SIDE_EFFECTS__
function Vy(e, t, n) {
  return new e({
    type: "literal",
    values: Array.isArray(t) ? t : [t],
    ...x(n)
  });
}
s(Vy, "_literal");
// @__NO_SIDE_EFFECTS__
function Uu(e, t) {
  return new e({
    type: "file",
    ...x(t)
  });
}
s(Uu, "_file");
// @__NO_SIDE_EFFECTS__
function qy(e, t) {
  return new e({
    type: "transform",
    transform: t
  });
}
s(qy, "_transform");
// @__NO_SIDE_EFFECTS__
function Wy(e, t) {
  return new e({
    type: "optional",
    innerType: t
  });
}
s(Wy, "_optional");
// @__NO_SIDE_EFFECTS__
function Ky(e, t) {
  return new e({
    type: "nullable",
    innerType: t
  });
}
s(Ky, "_nullable");
// @__NO_SIDE_EFFECTS__
function Gy(e, t, n) {
  return new e({
    type: "default",
    innerType: t,
    get defaultValue() {
      return typeof n == "function" ? n() : ta(n);
    }
  });
}
s(Gy, "_default");
// @__NO_SIDE_EFFECTS__
function Xy(e, t, n) {
  return new e({
    type: "nonoptional",
    innerType: t,
    ...x(n)
  });
}
s(Xy, "_nonoptional");
// @__NO_SIDE_EFFECTS__
function Qy(e, t) {
  return new e({
    type: "success",
    innerType: t
  });
}
s(Qy, "_success");
// @__NO_SIDE_EFFECTS__
function Hy(e, t, n) {
  return new e({
    type: "catch",
    innerType: t,
    catchValue: typeof n == "function" ? n : () => n
  });
}
s(Hy, "_catch");
// @__NO_SIDE_EFFECTS__
function Yy(e, t, n) {
  return new e({
    type: "pipe",
    in: t,
    out: n
  });
}
s(Yy, "_pipe");
// @__NO_SIDE_EFFECTS__
function eb(e, t) {
  return new e({
    type: "readonly",
    innerType: t
  });
}
s(eb, "_readonly");
// @__NO_SIDE_EFFECTS__
function tb(e, t, n) {
  return new e({
    type: "template_literal",
    parts: t,
    ...x(n)
  });
}
s(tb, "_templateLiteral");
// @__NO_SIDE_EFFECTS__
function rb(e, t) {
  return new e({
    type: "lazy",
    getter: t
  });
}
s(rb, "_lazy");
// @__NO_SIDE_EFFECTS__
function nb(e, t) {
  return new e({
    type: "promise",
    innerType: t
  });
}
s(nb, "_promise");
// @__NO_SIDE_EFFECTS__
function Du(e, t, n) {
  let i = x(n);
  return i.abort ?? (i.abort = !0), new e({
    type: "custom",
    check: "custom",
    fn: t,
    ...i
  });
}
s(Du, "_custom");
// @__NO_SIDE_EFFECTS__
function Nu(e, t, n) {
  return new e({
    type: "custom",
    check: "custom",
    fn: t,
    ...x(n)
  });
}
s(Nu, "_refine");
// @__NO_SIDE_EFFECTS__
function Zu(e, t) {
  let n = /* @__PURE__ */ lp((i) => (i.addIssue = (r) => {
    if (typeof r == "string")
      i.issues.push(jt(r, i.value, n._zod.def));
    else {
      let o = r;
      o.fatal && (o.continue = !1), o.code ?? (o.code = "custom"), o.input ?? (o.input = i.value), o.inst ?? (o.inst = n), o.continue ?? (o.continue = !n._zod.def.abort), i.issues.push(jt(o));
    }
  }, e(i.value, i)), t);
  return n;
}
s(Zu, "_superRefine");
// @__NO_SIDE_EFFECTS__
function lp(e, t) {
  let n = new R({
    check: "custom",
    ...x(t)
  });
  return n._zod.check = e, n;
}
s(lp, "_check");
// @__NO_SIDE_EFFECTS__
function Au(e) {
  let t = new R({ check: "describe" });
  return t._zod.onattach = [
    (n) => {
      let i = H.get(n) ?? {};
      H.add(n, { ...i, description: e });
    }
  ], t._zod.check = () => {
  }, t;
}
s(Au, "describe");
// @__NO_SIDE_EFFECTS__
function Cu(e) {
  let t = new R({ check: "meta" });
  return t._zod.onattach = [
    (n) => {
      let i = H.get(n) ?? {};
      H.add(n, { ...i, ...e });
    }
  ], t._zod.check = () => {
  }, t;
}
s(Cu, "meta");
// @__NO_SIDE_EFFECTS__
function Ru(e, t) {
  let n = x(t), i = n.truthy ?? ["true", "1", "yes", "on", "y", "enabled"], r = n.falsy ?? ["false", "0", "no", "off", "n", "disabled"];
  n.case !== "sensitive" && (i = i.map((h) => typeof h == "string" ? h.toLowerCase() : h), r = r.map((h) => typeof h == "string" ? h.toLowerCase() : h));
  let o = new Set(i), a = new Set(r), c = e.Codec ?? $e, u = e.Boolean ?? Pr, l = e.String ?? ot, d = new l({ type: "string", error: n.error }), m = new u({ type: "boolean", error: n.error }), y = new c({
    type: "pipe",
    in: d,
    out: m,
    transform: /* @__PURE__ */ s(((h, z) => {
      let D = h;
      return n.case !== "sensitive" && (D = D.toLowerCase()), o.has(D) ? !0 : a.has(D) ? !1 : (z.issues.push({
        code: "invalid_value",
        expected: "stringbool",
        values: [...o, ...a],
        input: z.value,
        inst: y,
        continue: !1
      }), {});
    }), "transform"),
    reverseTransform: /* @__PURE__ */ s(((h, z) => h === !0 ? i[0] || "true" : r[0] || "false"), "reverseTransform"),
    error: n.error
  });
  return y;
}
s(Ru, "_stringbool");
// @__NO_SIDE_EFFECTS__
function Qt(e, t, n, i = {}) {
  let r = x(i), o = {
    ...x(i),
    check: "string_format",
    type: "string",
    format: t,
    fn: typeof n == "function" ? n : (c) => n.test(c),
    ...r
  };
  return n instanceof RegExp && (o.pattern = n), new e(o);
}
s(Qt, "_stringFormat");

// versions/4.4.3/node_modules/zod/v4/core/to-json-schema.js
function qe(e) {
  let t = e?.target ?? "draft-2020-12";
  return t === "draft-4" && (t = "draft-04"), t === "draft-7" && (t = "draft-07"), {
    processors: e.processors ?? {},
    metadataRegistry: e?.metadata ?? H,
    target: t,
    unrepresentable: e?.unrepresentable ?? "throw",
    override: e?.override ?? (() => {
    }),
    io: e?.io ?? "output",
    counter: 0,
    seen: /* @__PURE__ */ new Map(),
    cycles: e?.cycles ?? "ref",
    reused: e?.reused ?? "inline",
    external: e?.external ?? void 0
  };
}
s(qe, "initializeContext");
function N(e, t, n = { path: [], schemaPath: [] }) {
  var i;
  let r = e._zod.def, o = t.seen.get(e);
  if (o)
    return o.count++, n.schemaPath.includes(e) && (o.cycle = n.path), o.schema;
  let a = { schema: {}, count: 1, cycle: void 0, path: n.path };
  t.seen.set(e, a);
  let c = e._zod.toJSONSchema?.();
  if (c)
    a.schema = c;
  else {
    let d = {
      ...n,
      schemaPath: [...n.schemaPath, e],
      path: n.path
    };
    if (e._zod.processJSONSchema)
      e._zod.processJSONSchema(t, a.schema, d);
    else {
      let y = a.schema, h = t.processors[r.type];
      if (!h)
        throw new Error(`[toJSONSchema]: Non-representable type encountered: ${r.type}`);
      h(e, t, y, d);
    }
    let m = e._zod.parent;
    m && (a.ref || (a.ref = m), N(m, t, d), t.seen.get(m).isParent = !0);
  }
  let u = t.metadataRegistry.get(e);
  return u && Object.assign(a.schema, u), t.io === "input" && ie(e) && (delete a.schema.examples, delete a.schema.default), t.io === "input" && "_prefault" in a.schema && ((i = a.schema).default ?? (i.default = a.schema._prefault)), delete a.schema._prefault, t.seen.get(e).schema;
}
s(N, "process");
function We(e, t) {
  let n = e.seen.get(t);
  if (!n)
    throw new Error("Unprocessed schema. This is a bug in Zod.");
  let i = /* @__PURE__ */ new Map();
  for (let a of e.seen.entries()) {
    let c = e.metadataRegistry.get(a[0])?.id;
    if (c) {
      let u = i.get(c);
      if (u && u !== a[0])
        throw new Error(`Duplicate schema id "${c}" detected during JSON Schema conversion. Two different schemas cannot share the same id when converted together.`);
      i.set(c, a[0]);
    }
  }
  let r = /* @__PURE__ */ s((a) => {
    let c = e.target === "draft-2020-12" ? "$defs" : "definitions";
    if (e.external) {
      let m = e.external.registry.get(a[0])?.id, y = e.external.uri ?? ((z) => z);
      if (m)
        return { ref: y(m) };
      let h = a[1].defId ?? a[1].schema.id ?? `schema${e.counter++}`;
      return a[1].defId = h, { defId: h, ref: `${y("__shared")}#/${c}/${h}` };
    }
    if (a[1] === n)
      return { ref: "#" };
    let l = `#/${c}/`, d = a[1].schema.id ?? `__schema${e.counter++}`;
    return { defId: d, ref: l + d };
  }, "makeURI"), o = /* @__PURE__ */ s((a) => {
    if (a[1].schema.$ref)
      return;
    let c = a[1], { ref: u, defId: l } = r(a);
    c.def = { ...c.schema }, l && (c.defId = l);
    let d = c.schema;
    for (let m in d)
      delete d[m];
    d.$ref = u;
  }, "extractToDef");
  if (e.cycles === "throw")
    for (let a of e.seen.entries()) {
      let c = a[1];
      if (c.cycle)
        throw new Error(`Cycle detected: #/${c.cycle?.join("/")}/<root>

Set the \`cycles\` parameter to \`"ref"\` to resolve cyclical schemas with defs.`);
    }
  for (let a of e.seen.entries()) {
    let c = a[1];
    if (t === a[0]) {
      o(a);
      continue;
    }
    if (e.external) {
      let l = e.external.registry.get(a[0])?.id;
      if (t !== a[0] && l) {
        o(a);
        continue;
      }
    }
    if (e.metadataRegistry.get(a[0])?.id) {
      o(a);
      continue;
    }
    if (c.cycle) {
      o(a);
      continue;
    }
    if (c.count > 1 && e.reused === "ref") {
      o(a);
      continue;
    }
  }
}
s(We, "extractDefs");
function Ke(e, t) {
  let n = e.seen.get(t);
  if (!n)
    throw new Error("Unprocessed schema. This is a bug in Zod.");
  let i = /* @__PURE__ */ s((c) => {
    let u = e.seen.get(c);
    if (u.ref === null)
      return;
    let l = u.def ?? u.schema, d = { ...l }, m = u.ref;
    if (u.ref = null, m) {
      i(m);
      let h = e.seen.get(m), z = h.schema;
      if (z.$ref && (e.target === "draft-07" || e.target === "draft-04" || e.target === "openapi-3.0") ? (l.allOf = l.allOf ?? [], l.allOf.push(z)) : Object.assign(l, z), Object.assign(l, d), c._zod.parent === m)
        for (let T in l)
          T === "$ref" || T === "allOf" || T in d || delete l[T];
      if (z.$ref && h.def)
        for (let T in l)
          T === "$ref" || T === "allOf" || T in h.def && JSON.stringify(l[T]) === JSON.stringify(h.def[T]) && delete l[T];
    }
    let y = c._zod.parent;
    if (y && y !== m) {
      i(y);
      let h = e.seen.get(y);
      if (h?.schema.$ref && (l.$ref = h.schema.$ref, h.def))
        for (let z in l)
          z === "$ref" || z === "allOf" || z in h.def && JSON.stringify(l[z]) === JSON.stringify(h.def[z]) && delete l[z];
    }
    e.override({
      zodSchema: c,
      jsonSchema: l,
      path: u.path ?? []
    });
  }, "flattenRef");
  for (let c of [...e.seen.entries()].reverse())
    i(c[0]);
  let r = {};
  if (e.target === "draft-2020-12" ? r.$schema = "https://json-schema.org/draft/2020-12/schema" : e.target === "draft-07" ? r.$schema = "http://json-schema.org/draft-07/schema#" : e.target === "draft-04" ? r.$schema = "http://json-schema.org/draft-04/schema#" : e.target, e.external?.uri) {
    let c = e.external.registry.get(t)?.id;
    if (!c)
      throw new Error("Schema is missing an `id` property");
    r.$id = e.external.uri(c);
  }
  Object.assign(r, n.def ?? n.schema);
  let o = e.metadataRegistry.get(t)?.id;
  o !== void 0 && r.id === o && delete r.id;
  let a = e.external?.defs ?? {};
  for (let c of e.seen.entries()) {
    let u = c[1];
    u.def && u.defId && (u.def.id === u.defId && delete u.def.id, a[u.defId] = u.def);
  }
  e.external || Object.keys(a).length > 0 && (e.target === "draft-2020-12" ? r.$defs = a : r.definitions = a);
  try {
    let c = JSON.parse(JSON.stringify(r));
    return Object.defineProperty(c, "~standard", {
      value: {
        ...t["~standard"],
        jsonSchema: {
          input: Ht(t, "input", e.processors),
          output: Ht(t, "output", e.processors)
        }
      },
      enumerable: !1,
      writable: !1
    }), c;
  } catch {
    throw new Error("Error converting schema to JSON.");
  }
}
s(Ke, "finalize");
function ie(e, t) {
  let n = t ?? { seen: /* @__PURE__ */ new Set() };
  if (n.seen.has(e))
    return !1;
  n.seen.add(e);
  let i = e._zod.def;
  if (i.type === "transform")
    return !0;
  if (i.type === "array")
    return ie(i.element, n);
  if (i.type === "set")
    return ie(i.valueType, n);
  if (i.type === "lazy")
    return ie(i.getter(), n);
  if (i.type === "promise" || i.type === "optional" || i.type === "nonoptional" || i.type === "nullable" || i.type === "readonly" || i.type === "default" || i.type === "prefault")
    return ie(i.innerType, n);
  if (i.type === "intersection")
    return ie(i.left, n) || ie(i.right, n);
  if (i.type === "record" || i.type === "map")
    return ie(i.keyType, n) || ie(i.valueType, n);
  if (i.type === "pipe")
    return e._zod.traits.has("$ZodCodec") ? !0 : ie(i.in, n) || ie(i.out, n);
  if (i.type === "object") {
    for (let r in i.shape)
      if (ie(i.shape[r], n))
        return !0;
    return !1;
  }
  if (i.type === "union") {
    for (let r of i.options)
      if (ie(r, n))
        return !0;
    return !1;
  }
  if (i.type === "tuple") {
    for (let r of i.items)
      if (ie(r, n))
        return !0;
    return !!(i.rest && ie(i.rest, n));
  }
  return !1;
}
s(ie, "isTransforming");
var Fu = /* @__PURE__ */ s((e, t = {}) => (n) => {
  let i = qe({ ...n, processors: t });
  return N(e, i), We(i, e), Ke(i, e);
}, "createToJSONSchemaMethod"), Ht = /* @__PURE__ */ s((e, t, n = {}) => (i) => {
  let { libraryOptions: r, target: o } = i ?? {}, a = qe({ ...r ?? {}, target: o, io: t, processors: n });
  return N(e, a), We(a, e), Ke(a, e);
}, "createStandardJSONSchemaMethod");

// versions/4.4.3/node_modules/zod/v4/core/json-schema-processors.js
var ib = {
  guid: "uuid",
  url: "uri",
  datetime: "date-time",
  json_string: "json-string",
  regex: ""
  // do not set
}, Lu = /* @__PURE__ */ s((e, t, n, i) => {
  let r = n;
  r.type = "string";
  let { minimum: o, maximum: a, format: c, patterns: u, contentEncoding: l } = e._zod.bag;
  if (typeof o == "number" && (r.minLength = o), typeof a == "number" && (r.maxLength = a), c && (r.format = ib[c] ?? c, r.format === "" && delete r.format, c === "time" && delete r.format), l && (r.contentEncoding = l), u && u.size > 0) {
    let d = [...u];
    d.length === 1 ? r.pattern = d[0].source : d.length > 1 && (r.allOf = [
      ...d.map((m) => ({
        ...t.target === "draft-07" || t.target === "draft-04" || t.target === "openapi-3.0" ? { type: "string" } : {},
        pattern: m.source
      }))
    ]);
  }
}, "stringProcessor"), Mu = /* @__PURE__ */ s((e, t, n, i) => {
  let r = n, { minimum: o, maximum: a, format: c, multipleOf: u, exclusiveMaximum: l, exclusiveMinimum: d } = e._zod.bag;
  typeof c == "string" && c.includes("int") ? r.type = "integer" : r.type = "number";
  let m = typeof d == "number" && d >= (o ?? Number.NEGATIVE_INFINITY), y = typeof l == "number" && l <= (a ?? Number.POSITIVE_INFINITY), h = t.target === "draft-04" || t.target === "openapi-3.0";
  m ? h ? (r.minimum = d, r.exclusiveMinimum = !0) : r.exclusiveMinimum = d : typeof o == "number" && (r.minimum = o), y ? h ? (r.maximum = l, r.exclusiveMaximum = !0) : r.exclusiveMaximum = l : typeof a == "number" && (r.maximum = a), typeof u == "number" && (r.multipleOf = u);
}, "numberProcessor"), Bu = /* @__PURE__ */ s((e, t, n, i) => {
  n.type = "boolean";
}, "booleanProcessor"), Ju = /* @__PURE__ */ s((e, t, n, i) => {
  if (t.unrepresentable === "throw")
    throw new Error("BigInt cannot be represented in JSON Schema");
}, "bigintProcessor"), Vu = /* @__PURE__ */ s((e, t, n, i) => {
  if (t.unrepresentable === "throw")
    throw new Error("Symbols cannot be represented in JSON Schema");
}, "symbolProcessor"), qu = /* @__PURE__ */ s((e, t, n, i) => {
  t.target === "openapi-3.0" ? (n.type = "string", n.nullable = !0, n.enum = [null]) : n.type = "null";
}, "nullProcessor"), Wu = /* @__PURE__ */ s((e, t, n, i) => {
  if (t.unrepresentable === "throw")
    throw new Error("Undefined cannot be represented in JSON Schema");
}, "undefinedProcessor"), Ku = /* @__PURE__ */ s((e, t, n, i) => {
  if (t.unrepresentable === "throw")
    throw new Error("Void cannot be represented in JSON Schema");
}, "voidProcessor"), Gu = /* @__PURE__ */ s((e, t, n, i) => {
  n.not = {};
}, "neverProcessor"), Xu = /* @__PURE__ */ s((e, t, n, i) => {
}, "anyProcessor"), Qu = /* @__PURE__ */ s((e, t, n, i) => {
}, "unknownProcessor"), Hu = /* @__PURE__ */ s((e, t, n, i) => {
  if (t.unrepresentable === "throw")
    throw new Error("Date cannot be represented in JSON Schema");
}, "dateProcessor"), Yu = /* @__PURE__ */ s((e, t, n, i) => {
  let r = e._zod.def, o = $r(r.entries);
  o.every((a) => typeof a == "number") && (n.type = "number"), o.every((a) => typeof a == "string") && (n.type = "string"), n.enum = o;
}, "enumProcessor"), el = /* @__PURE__ */ s((e, t, n, i) => {
  let r = e._zod.def, o = [];
  for (let a of r.values)
    if (a === void 0) {
      if (t.unrepresentable === "throw")
        throw new Error("Literal `undefined` cannot be represented in JSON Schema");
    } else if (typeof a == "bigint") {
      if (t.unrepresentable === "throw")
        throw new Error("BigInt literals cannot be represented in JSON Schema");
      o.push(Number(a));
    } else
      o.push(a);
  if (o.length !== 0)
    if (o.length === 1) {
      let a = o[0];
      n.type = a === null ? "null" : typeof a, t.target === "draft-04" || t.target === "openapi-3.0" ? n.enum = [a] : n.const = a;
    } else
      o.every((a) => typeof a == "number") && (n.type = "number"), o.every((a) => typeof a == "string") && (n.type = "string"), o.every((a) => typeof a == "boolean") && (n.type = "boolean"), o.every((a) => a === null) && (n.type = "null"), n.enum = o;
}, "literalProcessor"), tl = /* @__PURE__ */ s((e, t, n, i) => {
  if (t.unrepresentable === "throw")
    throw new Error("NaN cannot be represented in JSON Schema");
}, "nanProcessor"), rl = /* @__PURE__ */ s((e, t, n, i) => {
  let r = n, o = e._zod.pattern;
  if (!o)
    throw new Error("Pattern not found in template literal");
  r.type = "string", r.pattern = o.source;
}, "templateLiteralProcessor"), nl = /* @__PURE__ */ s((e, t, n, i) => {
  let r = n, o = {
    type: "string",
    format: "binary",
    contentEncoding: "binary"
  }, { minimum: a, maximum: c, mime: u } = e._zod.bag;
  a !== void 0 && (o.minLength = a), c !== void 0 && (o.maxLength = c), u ? u.length === 1 ? (o.contentMediaType = u[0], Object.assign(r, o)) : (Object.assign(r, o), r.anyOf = u.map((l) => ({ contentMediaType: l }))) : Object.assign(r, o);
}, "fileProcessor"), il = /* @__PURE__ */ s((e, t, n, i) => {
  n.type = "boolean";
}, "successProcessor"), ol = /* @__PURE__ */ s((e, t, n, i) => {
  if (t.unrepresentable === "throw")
    throw new Error("Custom types cannot be represented in JSON Schema");
}, "customProcessor"), al = /* @__PURE__ */ s((e, t, n, i) => {
  if (t.unrepresentable === "throw")
    throw new Error("Function types cannot be represented in JSON Schema");
}, "functionProcessor"), sl = /* @__PURE__ */ s((e, t, n, i) => {
  if (t.unrepresentable === "throw")
    throw new Error("Transforms cannot be represented in JSON Schema");
}, "transformProcessor"), cl = /* @__PURE__ */ s((e, t, n, i) => {
  if (t.unrepresentable === "throw")
    throw new Error("Map cannot be represented in JSON Schema");
}, "mapProcessor"), ul = /* @__PURE__ */ s((e, t, n, i) => {
  if (t.unrepresentable === "throw")
    throw new Error("Set cannot be represented in JSON Schema");
}, "setProcessor"), ll = /* @__PURE__ */ s((e, t, n, i) => {
  let r = n, o = e._zod.def, { minimum: a, maximum: c } = e._zod.bag;
  typeof a == "number" && (r.minItems = a), typeof c == "number" && (r.maxItems = c), r.type = "array", r.items = N(o.element, t, {
    ...i,
    path: [...i.path, "items"]
  });
}, "arrayProcessor"), dl = /* @__PURE__ */ s((e, t, n, i) => {
  let r = n, o = e._zod.def;
  r.type = "object", r.properties = {};
  let a = o.shape;
  for (let l in a)
    r.properties[l] = N(a[l], t, {
      ...i,
      path: [...i.path, "properties", l]
    });
  let c = new Set(Object.keys(a)), u = new Set([...c].filter((l) => {
    let d = o.shape[l]._zod;
    return t.io === "input" ? d.optin === void 0 : d.optout === void 0;
  }));
  u.size > 0 && (r.required = Array.from(u)), o.catchall?._zod.def.type === "never" ? r.additionalProperties = !1 : o.catchall ? o.catchall && (r.additionalProperties = N(o.catchall, t, {
    ...i,
    path: [...i.path, "additionalProperties"]
  })) : t.io === "output" && (r.additionalProperties = !1);
}, "objectProcessor"), wi = /* @__PURE__ */ s((e, t, n, i) => {
  let r = e._zod.def, o = r.inclusive === !1, a = r.options.map((c, u) => N(c, t, {
    ...i,
    path: [...i.path, o ? "oneOf" : "anyOf", u]
  }));
  o ? n.oneOf = a : n.anyOf = a;
}, "unionProcessor"), fl = /* @__PURE__ */ s((e, t, n, i) => {
  let r = e._zod.def, o = N(r.left, t, {
    ...i,
    path: [...i.path, "allOf", 0]
  }), a = N(r.right, t, {
    ...i,
    path: [...i.path, "allOf", 1]
  }), c = /* @__PURE__ */ s((l) => "allOf" in l && Object.keys(l).length === 1, "isSimpleIntersection"), u = [
    ...c(o) ? o.allOf : [o],
    ...c(a) ? a.allOf : [a]
  ];
  n.allOf = u;
}, "intersectionProcessor"), pl = /* @__PURE__ */ s((e, t, n, i) => {
  let r = n, o = e._zod.def;
  r.type = "array";
  let a = t.target === "draft-2020-12" ? "prefixItems" : "items", c = t.target === "draft-2020-12" || t.target === "openapi-3.0" ? "items" : "additionalItems", u = o.items.map((y, h) => N(y, t, {
    ...i,
    path: [...i.path, a, h]
  })), l = o.rest ? N(o.rest, t, {
    ...i,
    path: [...i.path, c, ...t.target === "openapi-3.0" ? [o.items.length] : []]
  }) : null;
  t.target === "draft-2020-12" ? (r.prefixItems = u, l && (r.items = l)) : t.target === "openapi-3.0" ? (r.items = {
    anyOf: u
  }, l && r.items.anyOf.push(l), r.minItems = u.length, l || (r.maxItems = u.length)) : (r.items = u, l && (r.additionalItems = l));
  let { minimum: d, maximum: m } = e._zod.bag;
  typeof d == "number" && (r.minItems = d), typeof m == "number" && (r.maxItems = m);
}, "tupleProcessor"), ml = /* @__PURE__ */ s((e, t, n, i) => {
  let r = n, o = e._zod.def;
  r.type = "object";
  let a = o.keyType, u = a._zod.bag?.patterns;
  if (o.mode === "loose" && u && u.size > 0) {
    let d = N(o.valueType, t, {
      ...i,
      path: [...i.path, "patternProperties", "*"]
    });
    r.patternProperties = {};
    for (let m of u)
      r.patternProperties[m.source] = d;
  } else
    (t.target === "draft-07" || t.target === "draft-2020-12") && (r.propertyNames = N(o.keyType, t, {
      ...i,
      path: [...i.path, "propertyNames"]
    })), r.additionalProperties = N(o.valueType, t, {
      ...i,
      path: [...i.path, "additionalProperties"]
    });
  let l = a._zod.values;
  if (l) {
    let d = [...l].filter((m) => typeof m == "string" || typeof m == "number");
    d.length > 0 && (r.required = d);
  }
}, "recordProcessor"), gl = /* @__PURE__ */ s((e, t, n, i) => {
  let r = e._zod.def, o = N(r.innerType, t, i), a = t.seen.get(e);
  t.target === "openapi-3.0" ? (a.ref = r.innerType, n.nullable = !0) : n.anyOf = [o, { type: "null" }];
}, "nullableProcessor"), hl = /* @__PURE__ */ s((e, t, n, i) => {
  let r = e._zod.def;
  N(r.innerType, t, i);
  let o = t.seen.get(e);
  o.ref = r.innerType;
}, "nonoptionalProcessor"), vl = /* @__PURE__ */ s((e, t, n, i) => {
  let r = e._zod.def;
  N(r.innerType, t, i);
  let o = t.seen.get(e);
  o.ref = r.innerType, n.default = JSON.parse(JSON.stringify(r.defaultValue));
}, "defaultProcessor"), yl = /* @__PURE__ */ s((e, t, n, i) => {
  let r = e._zod.def;
  N(r.innerType, t, i);
  let o = t.seen.get(e);
  o.ref = r.innerType, t.io === "input" && (n._prefault = JSON.parse(JSON.stringify(r.defaultValue)));
}, "prefaultProcessor"), bl = /* @__PURE__ */ s((e, t, n, i) => {
  let r = e._zod.def;
  N(r.innerType, t, i);
  let o = t.seen.get(e);
  o.ref = r.innerType;
  let a;
  try {
    a = r.catchValue(void 0);
  } catch {
    throw new Error("Dynamic catch values are not supported in JSON Schema");
  }
  n.default = a;
}, "catchProcessor"), $l = /* @__PURE__ */ s((e, t, n, i) => {
  let r = e._zod.def, o = r.in._zod.traits.has("$ZodTransform"), a = t.io === "input" ? o ? r.out : r.in : r.out;
  N(a, t, i);
  let c = t.seen.get(e);
  c.ref = a;
}, "pipeProcessor"), xl = /* @__PURE__ */ s((e, t, n, i) => {
  let r = e._zod.def;
  N(r.innerType, t, i);
  let o = t.seen.get(e);
  o.ref = r.innerType, n.readOnly = !0;
}, "readonlyProcessor"), _l = /* @__PURE__ */ s((e, t, n, i) => {
  let r = e._zod.def;
  N(r.innerType, t, i);
  let o = t.seen.get(e);
  o.ref = r.innerType;
}, "promiseProcessor"), ki = /* @__PURE__ */ s((e, t, n, i) => {
  let r = e._zod.def;
  N(r.innerType, t, i);
  let o = t.seen.get(e);
  o.ref = r.innerType;
}, "optionalProcessor"), wl = /* @__PURE__ */ s((e, t, n, i) => {
  let r = e._zod.innerType;
  N(r, t, i);
  let o = t.seen.get(e);
  o.ref = r;
}, "lazyProcessor"), _i = {
  string: Lu,
  number: Mu,
  boolean: Bu,
  bigint: Ju,
  symbol: Vu,
  null: qu,
  undefined: Wu,
  void: Ku,
  never: Gu,
  any: Xu,
  unknown: Qu,
  date: Hu,
  enum: Yu,
  literal: el,
  nan: tl,
  template_literal: rl,
  file: nl,
  success: il,
  custom: ol,
  function: al,
  transform: sl,
  map: cl,
  set: ul,
  array: ll,
  object: dl,
  union: wi,
  intersection: fl,
  tuple: pl,
  record: ml,
  nullable: gl,
  nonoptional: hl,
  default: vl,
  prefault: yl,
  catch: bl,
  pipe: $l,
  readonly: xl,
  promise: _l,
  optional: ki,
  lazy: wl
};
function zi(e, t) {
  if ("_idmap" in e) {
    let i = e, r = qe({ ...t, processors: _i }), o = {};
    for (let u of i._idmap.entries()) {
      let [l, d] = u;
      N(d, r);
    }
    let a = {}, c = {
      registry: i,
      uri: t?.uri,
      defs: o
    };
    r.external = c;
    for (let u of i._idmap.entries()) {
      let [l, d] = u;
      We(r, d), a[l] = Ke(r, d);
    }
    if (Object.keys(o).length > 0) {
      let u = r.target === "draft-2020-12" ? "$defs" : "definitions";
      a.__shared = {
        [u]: o
      };
    }
    return { schemas: a };
  }
  let n = qe({ ...t, processors: _i });
  return N(e, n), We(n, e), Ke(n, e);
}
s(zi, "toJSONSchema");

// versions/4.4.3/node_modules/zod/v4/core/json-schema-generator.js
var Ii = class {
  static {
    s(this, "JSONSchemaGenerator");
  }
  /** @deprecated Access via ctx instead */
  get metadataRegistry() {
    return this.ctx.metadataRegistry;
  }
  /** @deprecated Access via ctx instead */
  get target() {
    return this.ctx.target;
  }
  /** @deprecated Access via ctx instead */
  get unrepresentable() {
    return this.ctx.unrepresentable;
  }
  /** @deprecated Access via ctx instead */
  get override() {
    return this.ctx.override;
  }
  /** @deprecated Access via ctx instead */
  get io() {
    return this.ctx.io;
  }
  /** @deprecated Access via ctx instead */
  get counter() {
    return this.ctx.counter;
  }
  set counter(t) {
    this.ctx.counter = t;
  }
  /** @deprecated Access via ctx instead */
  get seen() {
    return this.ctx.seen;
  }
  constructor(t) {
    let n = t?.target ?? "draft-2020-12";
    n === "draft-4" && (n = "draft-04"), n === "draft-7" && (n = "draft-07"), this.ctx = qe({
      processors: _i,
      target: n,
      ...t?.metadata && { metadata: t.metadata },
      ...t?.unrepresentable && { unrepresentable: t.unrepresentable },
      ...t?.override && { override: t.override },
      ...t?.io && { io: t.io }
    });
  }
  /**
   * Process a schema to prepare it for JSON Schema generation.
   * This must be called before emit().
   */
  process(t, n = { path: [], schemaPath: [] }) {
    return N(t, this.ctx, n);
  }
  /**
   * Emit the final JSON Schema after processing.
   * Must call process() first.
   */
  emit(t, n) {
    n && (n.cycles && (this.ctx.cycles = n.cycles), n.reused && (this.ctx.reused = n.reused), n.external && (this.ctx.external = n.external)), We(this.ctx, t);
    let i = Ke(this.ctx, t), { "~standard": r, ...o } = i;
    return o;
  }
};

// versions/4.4.3/node_modules/zod/v4/core/json-schema.js
var dp = {};

// versions/4.4.3/node_modules/zod/v4/classic/schemas.js
var Rr = {};
Pe(Rr, {
  ZodAny: () => Bl,
  ZodArray: () => Wl,
  ZodBase64: () => Wi,
  ZodBase64URL: () => Ki,
  ZodBigInt: () => ar,
  ZodBigIntFormat: () => Qi,
  ZodBoolean: () => or,
  ZodCIDRv4: () => Vi,
  ZodCIDRv6: () => qi,
  ZodCUID: () => Ci,
  ZodCUID2: () => Ri,
  ZodCatch: () => gd,
  ZodCodec: () => Qr,
  ZodCustom: () => Hr,
  ZodCustomStringFormat: () => nr,
  ZodDate: () => Wr,
  ZodDefault: () => ud,
  ZodDiscriminatedUnion: () => Gl,
  ZodE164: () => Gi,
  ZodEmail: () => Ni,
  ZodEmoji: () => Zi,
  ZodEnum: () => tr,
  ZodExactOptional: () => ad,
  ZodFile: () => id,
  ZodFunction: () => zd,
  ZodGUID: () => Mr,
  ZodIPv4: () => Bi,
  ZodIPv6: () => Ji,
  ZodIntersection: () => Xl,
  ZodJWT: () => Xi,
  ZodKSUID: () => Mi,
  ZodLazy: () => _d,
  ZodLiteral: () => nd,
  ZodMAC: () => Cl,
  ZodMap: () => td,
  ZodNaN: () => vd,
  ZodNanoID: () => Ai,
  ZodNever: () => Vl,
  ZodNonOptional: () => io,
  ZodNull: () => Ll,
  ZodNullable: () => cd,
  ZodNumber: () => ir,
  ZodNumberFormat: () => mt,
  ZodObject: () => Kr,
  ZodOptional: () => no,
  ZodPipe: () => Xr,
  ZodPrefault: () => dd,
  ZodPreprocess: () => yd,
  ZodPromise: () => kd,
  ZodReadonly: () => bd,
  ZodRecord: () => er,
  ZodSet: () => rd,
  ZodString: () => rr,
  ZodStringFormat: () => C,
  ZodSuccess: () => md,
  ZodSymbol: () => Rl,
  ZodTemplateLiteral: () => xd,
  ZodTransform: () => od,
  ZodTuple: () => Hl,
  ZodType: () => S,
  ZodULID: () => Fi,
  ZodURL: () => Jr,
  ZodUUID: () => je,
  ZodUndefined: () => Fl,
  ZodUnion: () => Gr,
  ZodUnknown: () => Jl,
  ZodVoid: () => ql,
  ZodXID: () => Li,
  ZodXor: () => Kl,
  _ZodString: () => Di,
  _default: () => ld,
  _function: () => vm,
  any: () => Qp,
  array: () => gt,
  base64: () => Dp,
  base64url: () => Np,
  bigint: () => qp,
  boolean: () => qr,
  catch: () => hd,
  check: () => ym,
  cidrv4: () => Ep,
  cidrv6: () => Up,
  codec: () => oo,
  cuid: () => kp,
  cuid2: () => zp,
  custom: () => bm,
  date: () => Yi,
  describe: () => $m,
  discriminatedUnion: () => nm,
  e164: () => Zp,
  email: () => mp,
  emoji: () => _p,
  enum: () => to,
  exactOptional: () => sd,
  file: () => lm,
  float32: () => Mp,
  float64: () => Bp,
  function: () => vm,
  guid: () => gp,
  hash: () => Lp,
  hex: () => Fp,
  hostname: () => Rp,
  httpUrl: () => xp,
  instanceof: () => ao,
  int: () => Ei,
  int32: () => Jp,
  int64: () => Wp,
  intersection: () => Ql,
  invertCodec: () => mm,
  ipv4: () => Op,
  ipv6: () => Tp,
  json: () => wm,
  jwt: () => Ap,
  keyof: () => Yp,
  ksuid: () => jp,
  lazy: () => wd,
  literal: () => um,
  looseObject: () => tm,
  looseRecord: () => om,
  mac: () => Pp,
  map: () => am,
  meta: () => xm,
  nan: () => pm,
  nanoid: () => wp,
  nativeEnum: () => cm,
  never: () => Hi,
  nonoptional: () => pd,
  null: () => Ml,
  nullable: () => pt,
  nullish: () => dm,
  number: () => Vr,
  object: () => eo,
  optional: () => ft,
  partialRecord: () => im,
  pipe: () => Ui,
  prefault: () => fd,
  preprocess: () => km,
  promise: () => hm,
  readonly: () => $d,
  record: () => ed,
  refine: () => Id,
  set: () => sm,
  strictObject: () => em,
  string: () => lt,
  stringFormat: () => Cp,
  stringbool: () => _m,
  success: () => fm,
  superRefine: () => Sd,
  symbol: () => Gp,
  templateLiteral: () => gm,
  transform: () => ro,
  tuple: () => Yl,
  uint32: () => Vp,
  uint64: () => Kp,
  ulid: () => Ip,
  undefined: () => Xp,
  union: () => sr,
  unknown: () => dt,
  url: () => $p,
  uuid: () => hp,
  uuidv4: () => vp,
  uuidv6: () => yp,
  uuidv7: () => bp,
  void: () => Hp,
  xid: () => Sp,
  xor: () => rm
});

// versions/4.4.3/node_modules/zod/v4/classic/checks.js
var Si = {};
Pe(Si, {
  endsWith: () => Jt,
  gt: () => Ie,
  gte: () => ne,
  includes: () => Mt,
  length: () => ut,
  lowercase: () => Ft,
  lt: () => ze,
  lte: () => de,
  maxLength: () => ct,
  maxSize: () => Ve,
  mime: () => Vt,
  minLength: () => Ee,
  minSize: () => Se,
  multipleOf: () => Je,
  negative: () => yi,
  nonnegative: () => $i,
  nonpositive: () => bi,
  normalize: () => qt,
  overwrite: () => xe,
  positive: () => vi,
  property: () => xi,
  regex: () => Rt,
  size: () => st,
  slugify: () => Xt,
  startsWith: () => Bt,
  toLowerCase: () => Kt,
  toUpperCase: () => Gt,
  trim: () => Wt,
  uppercase: () => Lt
});

// versions/4.4.3/node_modules/zod/v4/classic/iso.js
var Yt = {};
Pe(Yt, {
  ZodISODate: () => Oi,
  ZodISODateTime: () => ji,
  ZodISODuration: () => Ti,
  ZodISOTime: () => Pi,
  date: () => zl,
  datetime: () => kl,
  duration: () => Sl,
  time: () => Il
});
var ji = /* @__PURE__ */ f("ZodISODateTime", (e, t) => {
  hs.init(e, t), C.init(e, t);
});
function kl(e) {
  return ou(ji, e);
}
s(kl, "datetime");
var Oi = /* @__PURE__ */ f("ZodISODate", (e, t) => {
  vs.init(e, t), C.init(e, t);
});
function zl(e) {
  return au(Oi, e);
}
s(zl, "date");
var Pi = /* @__PURE__ */ f("ZodISOTime", (e, t) => {
  ys.init(e, t), C.init(e, t);
});
function Il(e) {
  return su(Pi, e);
}
s(Il, "time");
var Ti = /* @__PURE__ */ f("ZodISODuration", (e, t) => {
  bs.init(e, t), C.init(e, t);
});
function Sl(e) {
  return cu(Ti, e);
}
s(Sl, "duration");

// versions/4.4.3/node_modules/zod/v4/classic/errors.js
var fp = /* @__PURE__ */ s((e, t) => {
  ve.init(e, t), e.name = "ZodError", Object.defineProperties(e, {
    format: {
      value: /* @__PURE__ */ s((n) => Ir(e, n), "value")
      // enumerable: false,
    },
    flatten: {
      value: /* @__PURE__ */ s((n) => zr(e, n), "value")
      // enumerable: false,
    },
    addIssue: {
      value: /* @__PURE__ */ s((n) => {
        e.issues.push(n), e.message = JSON.stringify(e.issues, It, 2);
      }, "value")
      // enumerable: false,
    },
    addIssues: {
      value: /* @__PURE__ */ s((n) => {
        e.issues.push(...n), e.message = JSON.stringify(e.issues, It, 2);
      }, "value")
      // enumerable: false,
    },
    isEmpty: {
      get() {
        return e.issues.length === 0;
      }
      // enumerable: false,
    }
  });
}, "initializer"), ab = /* @__PURE__ */ f("ZodError", fp), se = /* @__PURE__ */ f("ZodError", fp, {
  Parent: Error
});

// versions/4.4.3/node_modules/zod/v4/classic/parse.js
var Fr = /* @__PURE__ */ Ot(se), jl = /* @__PURE__ */ Pt(se), Ol = /* @__PURE__ */ Tt(se), Pl = /* @__PURE__ */ Et(se), Lr = /* @__PURE__ */ Pn(se), Tl = /* @__PURE__ */ Tn(se), El = /* @__PURE__ */ En(se), Ul = /* @__PURE__ */ Un(se), Dl = /* @__PURE__ */ Dn(se), Nl = /* @__PURE__ */ Nn(se), Zl = /* @__PURE__ */ Zn(se), Al = /* @__PURE__ */ An(se);

// versions/4.4.3/node_modules/zod/v4/classic/schemas.js
var pp = /* @__PURE__ */ new WeakMap();
function Br(e, t, n) {
  let i = Object.getPrototypeOf(e), r = pp.get(i);
  if (r || (r = /* @__PURE__ */ new Set(), pp.set(i, r)), !r.has(t)) {
    r.add(t);
    for (let o in n) {
      let a = n[o];
      Object.defineProperty(i, o, {
        configurable: !0,
        enumerable: !1,
        get() {
          let c = a.bind(this);
          return Object.defineProperty(this, o, {
            configurable: !0,
            writable: !0,
            enumerable: !0,
            value: c
          }), c;
        },
        set(c) {
          Object.defineProperty(this, o, {
            configurable: !0,
            writable: !0,
            enumerable: !0,
            value: c
          });
        }
      });
    }
  }
}
s(Br, "_installLazyMethods");
var S = /* @__PURE__ */ f("ZodType", (e, t) => (k.init(e, t), Object.assign(e["~standard"], {
  jsonSchema: {
    input: Ht(e, "input"),
    output: Ht(e, "output")
  }
}), e.toJSONSchema = Fu(e, {}), e.def = t, e.type = t.type, Object.defineProperty(e, "_def", { value: t }), e.parse = (n, i) => Fr(e, n, i, { callee: e.parse }), e.safeParse = (n, i) => Ol(e, n, i), e.parseAsync = async (n, i) => jl(e, n, i, { callee: e.parseAsync }), e.safeParseAsync = async (n, i) => Pl(e, n, i), e.spa = e.safeParseAsync, e.encode = (n, i) => Lr(e, n, i), e.decode = (n, i) => Tl(e, n, i), e.encodeAsync = async (n, i) => El(e, n, i), e.decodeAsync = async (n, i) => Ul(e, n, i), e.safeEncode = (n, i) => Dl(e, n, i), e.safeDecode = (n, i) => Nl(e, n, i), e.safeEncodeAsync = async (n, i) => Zl(e, n, i), e.safeDecodeAsync = async (n, i) => Al(e, n, i), Br(e, "ZodType", {
  check(...n) {
    let i = this.def;
    return this.clone($.mergeDefs(i, {
      checks: [
        ...i.checks ?? [],
        ...n.map((r) => typeof r == "function" ? { _zod: { check: r, def: { check: "custom" }, onattach: [] } } : r)
      ]
    }), { parent: !0 });
  },
  with(...n) {
    return this.check(...n);
  },
  clone(n, i) {
    return W(this, n, i);
  },
  brand() {
    return this;
  },
  register(n, i) {
    return n.add(this, i), this;
  },
  refine(n, i) {
    return this.check(Id(n, i));
  },
  superRefine(n, i) {
    return this.check(Sd(n, i));
  },
  overwrite(n) {
    return this.check(xe(n));
  },
  optional() {
    return ft(this);
  },
  exactOptional() {
    return sd(this);
  },
  nullable() {
    return pt(this);
  },
  nullish() {
    return ft(pt(this));
  },
  nonoptional(n) {
    return pd(this, n);
  },
  array() {
    return gt(this);
  },
  or(n) {
    return sr([this, n]);
  },
  and(n) {
    return Ql(this, n);
  },
  transform(n) {
    return Ui(this, ro(n));
  },
  default(n) {
    return ld(this, n);
  },
  prefault(n) {
    return fd(this, n);
  },
  catch(n) {
    return hd(this, n);
  },
  pipe(n) {
    return Ui(this, n);
  },
  readonly() {
    return $d(this);
  },
  describe(n) {
    let i = this.clone();
    return H.add(i, { description: n }), i;
  },
  meta(...n) {
    if (n.length === 0)
      return H.get(this);
    let i = this.clone();
    return H.add(i, n[0]), i;
  },
  isOptional() {
    return this.safeParse(void 0).success;
  },
  isNullable() {
    return this.safeParse(null).success;
  },
  apply(n) {
    return n(this);
  }
}), Object.defineProperty(e, "description", {
  get() {
    return H.get(e)?.description;
  },
  configurable: !0
}), e)), Di = /* @__PURE__ */ f("_ZodString", (e, t) => {
  ot.init(e, t), S.init(e, t), e._zod.processJSONSchema = (i, r, o) => Lu(e, i, r, o);
  let n = e._zod.bag;
  e.format = n.format ?? null, e.minLength = n.minimum ?? null, e.maxLength = n.maximum ?? null, Br(e, "_ZodString", {
    regex(...i) {
      return this.check(Rt(...i));
    },
    includes(...i) {
      return this.check(Mt(...i));
    },
    startsWith(...i) {
      return this.check(Bt(...i));
    },
    endsWith(...i) {
      return this.check(Jt(...i));
    },
    min(...i) {
      return this.check(Ee(...i));
    },
    max(...i) {
      return this.check(ct(...i));
    },
    length(...i) {
      return this.check(ut(...i));
    },
    nonempty(...i) {
      return this.check(Ee(1, ...i));
    },
    lowercase(i) {
      return this.check(Ft(i));
    },
    uppercase(i) {
      return this.check(Lt(i));
    },
    trim() {
      return this.check(Wt());
    },
    normalize(...i) {
      return this.check(qt(...i));
    },
    toLowerCase() {
      return this.check(Kt());
    },
    toUpperCase() {
      return this.check(Gt());
    },
    slugify() {
      return this.check(Xt());
    }
  });
}), rr = /* @__PURE__ */ f("ZodString", (e, t) => {
  ot.init(e, t), Di.init(e, t), e.email = (n) => e.check(Qn(Ni, n)), e.url = (n) => e.check(Cr(Jr, n)), e.jwt = (n) => e.check(hi(Xi, n)), e.emoji = (n) => e.check(ri(Zi, n)), e.guid = (n) => e.check(Ar(Mr, n)), e.uuid = (n) => e.check(Hn(je, n)), e.uuidv4 = (n) => e.check(Yn(je, n)), e.uuidv6 = (n) => e.check(ei(je, n)), e.uuidv7 = (n) => e.check(ti(je, n)), e.nanoid = (n) => e.check(ni(Ai, n)), e.guid = (n) => e.check(Ar(Mr, n)), e.cuid = (n) => e.check(ii(Ci, n)), e.cuid2 = (n) => e.check(oi(Ri, n)), e.ulid = (n) => e.check(ai(Fi, n)), e.base64 = (n) => e.check(pi(Wi, n)), e.base64url = (n) => e.check(mi(Ki, n)), e.xid = (n) => e.check(si(Li, n)), e.ksuid = (n) => e.check(ci(Mi, n)), e.ipv4 = (n) => e.check(ui(Bi, n)), e.ipv6 = (n) => e.check(li(Ji, n)), e.cidrv4 = (n) => e.check(di(Vi, n)), e.cidrv6 = (n) => e.check(fi(qi, n)), e.e164 = (n) => e.check(gi(Gi, n)), e.datetime = (n) => e.check(kl(n)), e.date = (n) => e.check(zl(n)), e.time = (n) => e.check(Il(n)), e.duration = (n) => e.check(Sl(n));
});
function lt(e) {
  return tu(rr, e);
}
s(lt, "string");
var C = /* @__PURE__ */ f("ZodStringFormat", (e, t) => {
  A.init(e, t), Di.init(e, t);
}), Ni = /* @__PURE__ */ f("ZodEmail", (e, t) => {
  ss.init(e, t), C.init(e, t);
});
function mp(e) {
  return Qn(Ni, e);
}
s(mp, "email");
var Mr = /* @__PURE__ */ f("ZodGUID", (e, t) => {
  os.init(e, t), C.init(e, t);
});
function gp(e) {
  return Ar(Mr, e);
}
s(gp, "guid");
var je = /* @__PURE__ */ f("ZodUUID", (e, t) => {
  as.init(e, t), C.init(e, t);
});
function hp(e) {
  return Hn(je, e);
}
s(hp, "uuid");
function vp(e) {
  return Yn(je, e);
}
s(vp, "uuidv4");
function yp(e) {
  return ei(je, e);
}
s(yp, "uuidv6");
function bp(e) {
  return ti(je, e);
}
s(bp, "uuidv7");
var Jr = /* @__PURE__ */ f("ZodURL", (e, t) => {
  cs.init(e, t), C.init(e, t);
});
function $p(e) {
  return Cr(Jr, e);
}
s($p, "url");
function xp(e) {
  return Cr(Jr, {
    protocol: ue.httpProtocol,
    hostname: ue.domain,
    ...$.normalizeParams(e)
  });
}
s(xp, "httpUrl");
var Zi = /* @__PURE__ */ f("ZodEmoji", (e, t) => {
  us.init(e, t), C.init(e, t);
});
function _p(e) {
  return ri(Zi, e);
}
s(_p, "emoji");
var Ai = /* @__PURE__ */ f("ZodNanoID", (e, t) => {
  ls.init(e, t), C.init(e, t);
});
function wp(e) {
  return ni(Ai, e);
}
s(wp, "nanoid");
var Ci = /* @__PURE__ */ f("ZodCUID", (e, t) => {
  ds.init(e, t), C.init(e, t);
});
function kp(e) {
  return ii(Ci, e);
}
s(kp, "cuid");
var Ri = /* @__PURE__ */ f("ZodCUID2", (e, t) => {
  fs.init(e, t), C.init(e, t);
});
function zp(e) {
  return oi(Ri, e);
}
s(zp, "cuid2");
var Fi = /* @__PURE__ */ f("ZodULID", (e, t) => {
  ps.init(e, t), C.init(e, t);
});
function Ip(e) {
  return ai(Fi, e);
}
s(Ip, "ulid");
var Li = /* @__PURE__ */ f("ZodXID", (e, t) => {
  ms.init(e, t), C.init(e, t);
});
function Sp(e) {
  return si(Li, e);
}
s(Sp, "xid");
var Mi = /* @__PURE__ */ f("ZodKSUID", (e, t) => {
  gs.init(e, t), C.init(e, t);
});
function jp(e) {
  return ci(Mi, e);
}
s(jp, "ksuid");
var Bi = /* @__PURE__ */ f("ZodIPv4", (e, t) => {
  $s.init(e, t), C.init(e, t);
});
function Op(e) {
  return ui(Bi, e);
}
s(Op, "ipv4");
var Cl = /* @__PURE__ */ f("ZodMAC", (e, t) => {
  _s.init(e, t), C.init(e, t);
});
function Pp(e) {
  return nu(Cl, e);
}
s(Pp, "mac");
var Ji = /* @__PURE__ */ f("ZodIPv6", (e, t) => {
  xs.init(e, t), C.init(e, t);
});
function Tp(e) {
  return li(Ji, e);
}
s(Tp, "ipv6");
var Vi = /* @__PURE__ */ f("ZodCIDRv4", (e, t) => {
  ws.init(e, t), C.init(e, t);
});
function Ep(e) {
  return di(Vi, e);
}
s(Ep, "cidrv4");
var qi = /* @__PURE__ */ f("ZodCIDRv6", (e, t) => {
  ks.init(e, t), C.init(e, t);
});
function Up(e) {
  return fi(qi, e);
}
s(Up, "cidrv6");
var Wi = /* @__PURE__ */ f("ZodBase64", (e, t) => {
  Is.init(e, t), C.init(e, t);
});
function Dp(e) {
  return pi(Wi, e);
}
s(Dp, "base64");
var Ki = /* @__PURE__ */ f("ZodBase64URL", (e, t) => {
  Ss.init(e, t), C.init(e, t);
});
function Np(e) {
  return mi(Ki, e);
}
s(Np, "base64url");
var Gi = /* @__PURE__ */ f("ZodE164", (e, t) => {
  js.init(e, t), C.init(e, t);
});
function Zp(e) {
  return gi(Gi, e);
}
s(Zp, "e164");
var Xi = /* @__PURE__ */ f("ZodJWT", (e, t) => {
  Os.init(e, t), C.init(e, t);
});
function Ap(e) {
  return hi(Xi, e);
}
s(Ap, "jwt");
var nr = /* @__PURE__ */ f("ZodCustomStringFormat", (e, t) => {
  Ps.init(e, t), C.init(e, t);
});
function Cp(e, t, n = {}) {
  return Qt(nr, e, t, n);
}
s(Cp, "stringFormat");
function Rp(e) {
  return Qt(nr, "hostname", ue.hostname, e);
}
s(Rp, "hostname");
function Fp(e) {
  return Qt(nr, "hex", ue.hex, e);
}
s(Fp, "hex");
function Lp(e, t) {
  let n = t?.enc ?? "hex", i = `${e}_${n}`, r = ue[i];
  if (!r)
    throw new Error(`Unrecognized hash format: ${i}`);
  return Qt(nr, i, r, t);
}
s(Lp, "hash");
var ir = /* @__PURE__ */ f("ZodNumber", (e, t) => {
  qn.init(e, t), S.init(e, t), e._zod.processJSONSchema = (i, r, o) => Mu(e, i, r, o), Br(e, "ZodNumber", {
    gt(i, r) {
      return this.check(Ie(i, r));
    },
    gte(i, r) {
      return this.check(ne(i, r));
    },
    min(i, r) {
      return this.check(ne(i, r));
    },
    lt(i, r) {
      return this.check(ze(i, r));
    },
    lte(i, r) {
      return this.check(de(i, r));
    },
    max(i, r) {
      return this.check(de(i, r));
    },
    int(i) {
      return this.check(Ei(i));
    },
    safe(i) {
      return this.check(Ei(i));
    },
    positive(i) {
      return this.check(Ie(0, i));
    },
    nonnegative(i) {
      return this.check(ne(0, i));
    },
    negative(i) {
      return this.check(ze(0, i));
    },
    nonpositive(i) {
      return this.check(de(0, i));
    },
    multipleOf(i, r) {
      return this.check(Je(i, r));
    },
    step(i, r) {
      return this.check(Je(i, r));
    },
    finite() {
      return this;
    }
  });
  let n = e._zod.bag;
  e.minValue = Math.max(n.minimum ?? Number.NEGATIVE_INFINITY, n.exclusiveMinimum ?? Number.NEGATIVE_INFINITY) ?? null, e.maxValue = Math.min(n.maximum ?? Number.POSITIVE_INFINITY, n.exclusiveMaximum ?? Number.POSITIVE_INFINITY) ?? null, e.isInt = (n.format ?? "").includes("int") || Number.isSafeInteger(n.multipleOf ?? 0.5), e.isFinite = !0, e.format = n.format ?? null;
});
function Vr(e) {
  return uu(ir, e);
}
s(Vr, "number");
var mt = /* @__PURE__ */ f("ZodNumberFormat", (e, t) => {
  Ts.init(e, t), ir.init(e, t);
});
function Ei(e) {
  return du(mt, e);
}
s(Ei, "int");
function Mp(e) {
  return fu(mt, e);
}
s(Mp, "float32");
function Bp(e) {
  return pu(mt, e);
}
s(Bp, "float64");
function Jp(e) {
  return mu(mt, e);
}
s(Jp, "int32");
function Vp(e) {
  return gu(mt, e);
}
s(Vp, "uint32");
var or = /* @__PURE__ */ f("ZodBoolean", (e, t) => {
  Pr.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, i, r) => Bu(e, n, i, r);
});
function qr(e) {
  return hu(or, e);
}
s(qr, "boolean");
var ar = /* @__PURE__ */ f("ZodBigInt", (e, t) => {
  Wn.init(e, t), S.init(e, t), e._zod.processJSONSchema = (i, r, o) => Ju(e, i, r, o), e.gte = (i, r) => e.check(ne(i, r)), e.min = (i, r) => e.check(ne(i, r)), e.gt = (i, r) => e.check(Ie(i, r)), e.gte = (i, r) => e.check(ne(i, r)), e.min = (i, r) => e.check(ne(i, r)), e.lt = (i, r) => e.check(ze(i, r)), e.lte = (i, r) => e.check(de(i, r)), e.max = (i, r) => e.check(de(i, r)), e.positive = (i) => e.check(Ie(BigInt(0), i)), e.negative = (i) => e.check(ze(BigInt(0), i)), e.nonpositive = (i) => e.check(de(BigInt(0), i)), e.nonnegative = (i) => e.check(ne(BigInt(0), i)), e.multipleOf = (i, r) => e.check(Je(i, r));
  let n = e._zod.bag;
  e.minValue = n.minimum ?? null, e.maxValue = n.maximum ?? null, e.format = n.format ?? null;
});
function qp(e) {
  return yu(ar, e);
}
s(qp, "bigint");
var Qi = /* @__PURE__ */ f("ZodBigIntFormat", (e, t) => {
  Es.init(e, t), ar.init(e, t);
});
function Wp(e) {
  return $u(Qi, e);
}
s(Wp, "int64");
function Kp(e) {
  return xu(Qi, e);
}
s(Kp, "uint64");
var Rl = /* @__PURE__ */ f("ZodSymbol", (e, t) => {
  Us.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, i, r) => Vu(e, n, i, r);
});
function Gp(e) {
  return _u(Rl, e);
}
s(Gp, "symbol");
var Fl = /* @__PURE__ */ f("ZodUndefined", (e, t) => {
  Ds.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, i, r) => Wu(e, n, i, r);
});
function Xp(e) {
  return wu(Fl, e);
}
s(Xp, "_undefined");
var Ll = /* @__PURE__ */ f("ZodNull", (e, t) => {
  Ns.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, i, r) => qu(e, n, i, r);
});
function Ml(e) {
  return ku(Ll, e);
}
s(Ml, "_null");
var Bl = /* @__PURE__ */ f("ZodAny", (e, t) => {
  Zs.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, i, r) => Xu(e, n, i, r);
});
function Qp() {
  return zu(Bl);
}
s(Qp, "any");
var Jl = /* @__PURE__ */ f("ZodUnknown", (e, t) => {
  As.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, i, r) => Qu(e, n, i, r);
});
function dt() {
  return Iu(Jl);
}
s(dt, "unknown");
var Vl = /* @__PURE__ */ f("ZodNever", (e, t) => {
  Cs.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, i, r) => Gu(e, n, i, r);
});
function Hi(e) {
  return Su(Vl, e);
}
s(Hi, "never");
var ql = /* @__PURE__ */ f("ZodVoid", (e, t) => {
  Rs.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, i, r) => Ku(e, n, i, r);
});
function Hp(e) {
  return ju(ql, e);
}
s(Hp, "_void");
var Wr = /* @__PURE__ */ f("ZodDate", (e, t) => {
  Dt.init(e, t), S.init(e, t), e._zod.processJSONSchema = (i, r, o) => Hu(e, i, r, o), e.min = (i, r) => e.check(ne(i, r)), e.max = (i, r) => e.check(de(i, r));
  let n = e._zod.bag;
  e.minDate = n.minimum ? new Date(n.minimum) : null, e.maxDate = n.maximum ? new Date(n.maximum) : null;
});
function Yi(e) {
  return Ou(Wr, e);
}
s(Yi, "date");
var Wl = /* @__PURE__ */ f("ZodArray", (e, t) => {
  Le.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, i, r) => ll(e, n, i, r), e.element = t.element, Br(e, "ZodArray", {
    min(n, i) {
      return this.check(Ee(n, i));
    },
    nonempty(n) {
      return this.check(Ee(1, n));
    },
    max(n, i) {
      return this.check(ct(n, i));
    },
    length(n, i) {
      return this.check(ut(n, i));
    },
    unwrap() {
      return this.element;
    }
  });
});
function gt(e, t) {
  return Eu(Wl, e, t);
}
s(gt, "array");
function Yp(e) {
  let t = e._zod.def.shape;
  return to(Object.keys(t));
}
s(Yp, "keyof");
var Kr = /* @__PURE__ */ f("ZodObject", (e, t) => {
  Fs.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, i, r) => dl(e, n, i, r), $.defineLazy(e, "shape", () => t.shape), Br(e, "ZodObject", {
    keyof() {
      return to(Object.keys(this._zod.def.shape));
    },
    catchall(n) {
      return this.clone({ ...this._zod.def, catchall: n });
    },
    passthrough() {
      return this.clone({ ...this._zod.def, catchall: dt() });
    },
    loose() {
      return this.clone({ ...this._zod.def, catchall: dt() });
    },
    strict() {
      return this.clone({ ...this._zod.def, catchall: Hi() });
    },
    strip() {
      return this.clone({ ...this._zod.def, catchall: void 0 });
    },
    extend(n) {
      return $.extend(this, n);
    },
    safeExtend(n) {
      return $.safeExtend(this, n);
    },
    merge(n) {
      return $.merge(this, n);
    },
    pick(n) {
      return $.pick(this, n);
    },
    omit(n) {
      return $.omit(this, n);
    },
    partial(...n) {
      return $.partial(no, this, n[0]);
    },
    required(...n) {
      return $.required(io, this, n[0]);
    }
  });
});
function eo(e, t) {
  let n = {
    type: "object",
    shape: e ?? {},
    ...$.normalizeParams(t)
  };
  return new Kr(n);
}
s(eo, "object");
function em(e, t) {
  return new Kr({
    type: "object",
    shape: e,
    catchall: Hi(),
    ...$.normalizeParams(t)
  });
}
s(em, "strictObject");
function tm(e, t) {
  return new Kr({
    type: "object",
    shape: e,
    catchall: dt(),
    ...$.normalizeParams(t)
  });
}
s(tm, "looseObject");
var Gr = /* @__PURE__ */ f("ZodUnion", (e, t) => {
  re.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, i, r) => wi(e, n, i, r), e.options = t.options;
});
function sr(e, t) {
  return new Gr({
    type: "union",
    options: e,
    ...$.normalizeParams(t)
  });
}
s(sr, "union");
var Kl = /* @__PURE__ */ f("ZodXor", (e, t) => {
  Gr.init(e, t), Ls.init(e, t), e._zod.processJSONSchema = (n, i, r) => wi(e, n, i, r), e.options = t.options;
});
function rm(e, t) {
  return new Kl({
    type: "union",
    options: e,
    inclusive: !1,
    ...$.normalizeParams(t)
  });
}
s(rm, "xor");
var Gl = /* @__PURE__ */ f("ZodDiscriminatedUnion", (e, t) => {
  Gr.init(e, t), Me.init(e, t);
});
function nm(e, t, n) {
  return new Gl({
    type: "union",
    options: t,
    discriminator: e,
    ...$.normalizeParams(n)
  });
}
s(nm, "discriminatedUnion");
var Xl = /* @__PURE__ */ f("ZodIntersection", (e, t) => {
  Ms.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, i, r) => fl(e, n, i, r);
});
function Ql(e, t) {
  return new Xl({
    type: "intersection",
    left: e,
    right: t
  });
}
s(Ql, "intersection");
var Hl = /* @__PURE__ */ f("ZodTuple", (e, t) => {
  Be.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, i, r) => pl(e, n, i, r), e.rest = (n) => e.clone({
    ...e._zod.def,
    rest: n
  });
});
function Yl(e, t, n) {
  let i = t instanceof k, r = i ? n : t, o = i ? t : null;
  return new Hl({
    type: "tuple",
    items: e,
    rest: o,
    ...$.normalizeParams(r)
  });
}
s(Yl, "tuple");
var er = /* @__PURE__ */ f("ZodRecord", (e, t) => {
  at.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, i, r) => ml(e, n, i, r), e.keyType = t.keyType, e.valueType = t.valueType;
});
function ed(e, t, n) {
  return !t || !t._zod ? new er({
    type: "record",
    keyType: lt(),
    valueType: e,
    ...$.normalizeParams(t)
  }) : new er({
    type: "record",
    keyType: e,
    valueType: t,
    ...$.normalizeParams(n)
  });
}
s(ed, "record");
function im(e, t, n) {
  let i = W(e);
  return i._zod.values = void 0, new er({
    type: "record",
    keyType: i,
    valueType: t,
    ...$.normalizeParams(n)
  });
}
s(im, "partialRecord");
function om(e, t, n) {
  return new er({
    type: "record",
    keyType: e,
    valueType: t,
    mode: "loose",
    ...$.normalizeParams(n)
  });
}
s(om, "looseRecord");
var td = /* @__PURE__ */ f("ZodMap", (e, t) => {
  Bs.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, i, r) => cl(e, n, i, r), e.keyType = t.keyType, e.valueType = t.valueType, e.min = (...n) => e.check(Se(...n)), e.nonempty = (n) => e.check(Se(1, n)), e.max = (...n) => e.check(Ve(...n)), e.size = (...n) => e.check(st(...n));
});
function am(e, t, n) {
  return new td({
    type: "map",
    keyType: e,
    valueType: t,
    ...$.normalizeParams(n)
  });
}
s(am, "map");
var rd = /* @__PURE__ */ f("ZodSet", (e, t) => {
  Js.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, i, r) => ul(e, n, i, r), e.min = (...n) => e.check(Se(...n)), e.nonempty = (n) => e.check(Se(1, n)), e.max = (...n) => e.check(Ve(...n)), e.size = (...n) => e.check(st(...n));
});
function sm(e, t) {
  return new rd({
    type: "set",
    valueType: e,
    ...$.normalizeParams(t)
  });
}
s(sm, "set");
var tr = /* @__PURE__ */ f("ZodEnum", (e, t) => {
  Nt.init(e, t), S.init(e, t), e._zod.processJSONSchema = (i, r, o) => Yu(e, i, r, o), e.enum = t.entries, e.options = Object.values(t.entries);
  let n = new Set(Object.keys(t.entries));
  e.extract = (i, r) => {
    let o = {};
    for (let a of i)
      if (n.has(a))
        o[a] = t.entries[a];
      else
        throw new Error(`Key ${a} not found in enum`);
    return new tr({
      ...t,
      checks: [],
      ...$.normalizeParams(r),
      entries: o
    });
  }, e.exclude = (i, r) => {
    let o = { ...t.entries };
    for (let a of i)
      if (n.has(a))
        delete o[a];
      else
        throw new Error(`Key ${a} not found in enum`);
    return new tr({
      ...t,
      checks: [],
      ...$.normalizeParams(r),
      entries: o
    });
  };
});
function to(e, t) {
  let n = Array.isArray(e) ? Object.fromEntries(e.map((i) => [i, i])) : e;
  return new tr({
    type: "enum",
    entries: n,
    ...$.normalizeParams(t)
  });
}
s(to, "_enum");
function cm(e, t) {
  return new tr({
    type: "enum",
    entries: e,
    ...$.normalizeParams(t)
  });
}
s(cm, "nativeEnum");
var nd = /* @__PURE__ */ f("ZodLiteral", (e, t) => {
  Zt.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, i, r) => el(e, n, i, r), e.values = new Set(t.values), Object.defineProperty(e, "value", {
    get() {
      if (t.values.length > 1)
        throw new Error("This schema contains multiple valid literal values. Use `.values` instead.");
      return t.values[0];
    }
  });
});
function um(e, t) {
  return new nd({
    type: "literal",
    values: Array.isArray(e) ? e : [e],
    ...$.normalizeParams(t)
  });
}
s(um, "literal");
var id = /* @__PURE__ */ f("ZodFile", (e, t) => {
  Vs.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, i, r) => nl(e, n, i, r), e.min = (n, i) => e.check(Se(n, i)), e.max = (n, i) => e.check(Ve(n, i)), e.mime = (n, i) => e.check(Vt(Array.isArray(n) ? n : [n], i));
});
function lm(e) {
  return Uu(id, e);
}
s(lm, "file");
var od = /* @__PURE__ */ f("ZodTransform", (e, t) => {
  qs.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, i, r) => sl(e, n, i, r), e._zod.parse = (n, i) => {
    if (i.direction === "backward")
      throw new Ne(e.constructor.name);
    n.addIssue = (o) => {
      if (typeof o == "string")
        n.issues.push($.issue(o, n.value, t));
      else {
        let a = o;
        a.fatal && (a.continue = !1), a.code ?? (a.code = "custom"), a.input ?? (a.input = n.value), a.inst ?? (a.inst = e), n.issues.push($.issue(a));
      }
    };
    let r = t.transform(n.value, n);
    return r instanceof Promise ? r.then((o) => (n.value = o, n.fallback = !0, n)) : (n.value = r, n.fallback = !0, n);
  };
});
function ro(e) {
  return new od({
    type: "transform",
    transform: e
  });
}
s(ro, "transform");
var no = /* @__PURE__ */ f("ZodOptional", (e, t) => {
  V.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, i, r) => ki(e, n, i, r), e.unwrap = () => e._zod.def.innerType;
});
function ft(e) {
  return new no({
    type: "optional",
    innerType: e
  });
}
s(ft, "optional");
var ad = /* @__PURE__ */ f("ZodExactOptional", (e, t) => {
  Ws.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, i, r) => ki(e, n, i, r), e.unwrap = () => e._zod.def.innerType;
});
function sd(e) {
  return new ad({
    type: "optional",
    innerType: e
  });
}
s(sd, "exactOptional");
var cd = /* @__PURE__ */ f("ZodNullable", (e, t) => {
  be.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, i, r) => gl(e, n, i, r), e.unwrap = () => e._zod.def.innerType;
});
function pt(e) {
  return new cd({
    type: "nullable",
    innerType: e
  });
}
s(pt, "nullable");
function dm(e) {
  return ft(pt(e));
}
s(dm, "nullish");
var ud = /* @__PURE__ */ f("ZodDefault", (e, t) => {
  le.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, i, r) => vl(e, n, i, r), e.unwrap = () => e._zod.def.innerType, e.removeDefault = e.unwrap;
});
function ld(e, t) {
  return new ud({
    type: "default",
    innerType: e,
    get defaultValue() {
      return typeof t == "function" ? t() : $.shallowClone(t);
    }
  });
}
s(ld, "_default");
var dd = /* @__PURE__ */ f("ZodPrefault", (e, t) => {
  Ks.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, i, r) => yl(e, n, i, r), e.unwrap = () => e._zod.def.innerType;
});
function fd(e, t) {
  return new dd({
    type: "prefault",
    innerType: e,
    get defaultValue() {
      return typeof t == "function" ? t() : $.shallowClone(t);
    }
  });
}
s(fd, "prefault");
var io = /* @__PURE__ */ f("ZodNonOptional", (e, t) => {
  Gs.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, i, r) => hl(e, n, i, r), e.unwrap = () => e._zod.def.innerType;
});
function pd(e, t) {
  return new io({
    type: "nonoptional",
    innerType: e,
    ...$.normalizeParams(t)
  });
}
s(pd, "nonoptional");
var md = /* @__PURE__ */ f("ZodSuccess", (e, t) => {
  Xs.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, i, r) => il(e, n, i, r), e.unwrap = () => e._zod.def.innerType;
});
function fm(e) {
  return new md({
    type: "success",
    innerType: e
  });
}
s(fm, "success");
var gd = /* @__PURE__ */ f("ZodCatch", (e, t) => {
  Qs.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, i, r) => bl(e, n, i, r), e.unwrap = () => e._zod.def.innerType, e.removeCatch = e.unwrap;
});
function hd(e, t) {
  return new gd({
    type: "catch",
    innerType: e,
    catchValue: typeof t == "function" ? t : () => t
  });
}
s(hd, "_catch");
var vd = /* @__PURE__ */ f("ZodNaN", (e, t) => {
  Hs.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, i, r) => tl(e, n, i, r);
});
function pm(e) {
  return Tu(vd, e);
}
s(pm, "nan");
var Xr = /* @__PURE__ */ f("ZodPipe", (e, t) => {
  Kn.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, i, r) => $l(e, n, i, r), e.in = t.in, e.out = t.out;
});
function Ui(e, t) {
  return new Xr({
    type: "pipe",
    in: e,
    out: t
    // ...util.normalizeParams(params),
  });
}
s(Ui, "pipe");
var Qr = /* @__PURE__ */ f("ZodCodec", (e, t) => {
  Xr.init(e, t), $e.init(e, t);
});
function oo(e, t, n) {
  return new Qr({
    type: "pipe",
    in: e,
    out: t,
    transform: n.decode,
    reverseTransform: n.encode
  });
}
s(oo, "codec");
function mm(e) {
  let t = e._zod.def;
  return new Qr({
    type: "pipe",
    in: t.out,
    out: t.in,
    transform: t.reverseTransform,
    reverseTransform: t.transform
  });
}
s(mm, "invertCodec");
var yd = /* @__PURE__ */ f("ZodPreprocess", (e, t) => {
  Xr.init(e, t), Ys.init(e, t);
}), bd = /* @__PURE__ */ f("ZodReadonly", (e, t) => {
  ec.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, i, r) => xl(e, n, i, r), e.unwrap = () => e._zod.def.innerType;
});
function $d(e) {
  return new bd({
    type: "readonly",
    innerType: e
  });
}
s($d, "readonly");
var xd = /* @__PURE__ */ f("ZodTemplateLiteral", (e, t) => {
  tc.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, i, r) => rl(e, n, i, r);
});
function gm(e, t) {
  return new xd({
    type: "template_literal",
    parts: e,
    ...$.normalizeParams(t)
  });
}
s(gm, "templateLiteral");
var _d = /* @__PURE__ */ f("ZodLazy", (e, t) => {
  At.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, i, r) => wl(e, n, i, r), e.unwrap = () => e._zod.def.getter();
});
function wd(e) {
  return new _d({
    type: "lazy",
    getter: e
  });
}
s(wd, "lazy");
var kd = /* @__PURE__ */ f("ZodPromise", (e, t) => {
  nc.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, i, r) => _l(e, n, i, r), e.unwrap = () => e._zod.def.innerType;
});
function hm(e) {
  return new kd({
    type: "promise",
    innerType: e
  });
}
s(hm, "promise");
var zd = /* @__PURE__ */ f("ZodFunction", (e, t) => {
  rc.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, i, r) => al(e, n, i, r);
});
function vm(e) {
  return new zd({
    type: "function",
    input: Array.isArray(e?.input) ? Yl(e?.input) : e?.input ?? gt(dt()),
    output: e?.output ?? dt()
  });
}
s(vm, "_function");
var Hr = /* @__PURE__ */ f("ZodCustom", (e, t) => {
  Tr.init(e, t), S.init(e, t), e._zod.processJSONSchema = (n, i, r) => ol(e, n, i, r);
});
function ym(e) {
  let t = new R({
    check: "custom"
    // ...util.normalizeParams(params),
  });
  return t._zod.check = e, t;
}
s(ym, "check");
function bm(e, t) {
  return Du(Hr, e ?? (() => !0), t);
}
s(bm, "custom");
function Id(e, t = {}) {
  return Nu(Hr, e, t);
}
s(Id, "refine");
function Sd(e, t) {
  return Zu(e, t);
}
s(Sd, "superRefine");
var $m = Au, xm = Cu;
function ao(e, t = {}) {
  let n = new Hr({
    type: "custom",
    check: "custom",
    fn: /* @__PURE__ */ s((i) => i instanceof e, "fn"),
    abort: !0,
    ...$.normalizeParams(t)
  });
  return n._zod.bag.Class = e, n._zod.check = (i) => {
    i.value instanceof e || i.issues.push({
      code: "invalid_type",
      expected: e.name,
      input: i.value,
      inst: n,
      path: [...n._zod.def.path ?? []]
    });
  }, n;
}
s(ao, "_instanceof");
var _m = /* @__PURE__ */ s((...e) => Ru({
  Codec: Qr,
  Boolean: or,
  String: rr
}, ...e), "stringbool");
function wm(e) {
  let t = wd(() => sr([lt(e), Vr(), qr(), Ml(), gt(t), ed(lt(), t)]));
  return t;
}
s(wm, "json");
function km(e, t) {
  return new yd({
    type: "pipe",
    in: ro(e),
    out: t
  });
}
s(km, "preprocess");

// versions/4.4.3/node_modules/zod/v4/classic/compat.js
var cb = {
  invalid_type: "invalid_type",
  too_big: "too_big",
  too_small: "too_small",
  invalid_format: "invalid_format",
  not_multiple_of: "not_multiple_of",
  unrecognized_keys: "unrecognized_keys",
  invalid_union: "invalid_union",
  invalid_key: "invalid_key",
  invalid_element: "invalid_element",
  invalid_value: "invalid_value",
  custom: "custom"
};
function ub(e) {
  q({
    customError: e
  });
}
s(ub, "setErrorMap");
function lb() {
  return q().customError;
}
s(lb, "getErrorMap");
var jd;
jd || (jd = {});

// versions/4.4.3/node_modules/zod/v4/classic/from-json-schema.js
var _ = {
  ...Rr,
  ...Si,
  iso: Yt
}, db = /* @__PURE__ */ new Set([
  // Schema identification
  "$schema",
  "$ref",
  "$defs",
  "definitions",
  // Core schema keywords
  "$id",
  "id",
  "$comment",
  "$anchor",
  "$vocabulary",
  "$dynamicRef",
  "$dynamicAnchor",
  // Type
  "type",
  "enum",
  "const",
  // Composition
  "anyOf",
  "oneOf",
  "allOf",
  "not",
  // Object
  "properties",
  "required",
  "additionalProperties",
  "patternProperties",
  "propertyNames",
  "minProperties",
  "maxProperties",
  // Array
  "items",
  "prefixItems",
  "additionalItems",
  "minItems",
  "maxItems",
  "uniqueItems",
  "contains",
  "minContains",
  "maxContains",
  // String
  "minLength",
  "maxLength",
  "pattern",
  "format",
  // Number
  "minimum",
  "maximum",
  "exclusiveMinimum",
  "exclusiveMaximum",
  "multipleOf",
  // Already handled metadata
  "description",
  "default",
  // Content
  "contentEncoding",
  "contentMediaType",
  "contentSchema",
  // Unsupported (error-throwing)
  "unevaluatedItems",
  "unevaluatedProperties",
  "if",
  "then",
  "else",
  "dependentSchemas",
  "dependentRequired",
  // OpenAPI
  "nullable",
  "readOnly"
]);
function fb(e, t) {
  let n = e.$schema;
  return n === "https://json-schema.org/draft/2020-12/schema" ? "draft-2020-12" : n === "http://json-schema.org/draft-07/schema#" ? "draft-7" : n === "http://json-schema.org/draft-04/schema#" ? "draft-4" : t ?? "draft-2020-12";
}
s(fb, "detectVersion");
function pb(e, t) {
  if (!e.startsWith("#"))
    throw new Error("External $ref is not supported, only local refs (#/...) are allowed");
  let n = e.slice(1).split("/").filter(Boolean);
  if (n.length === 0)
    return t.rootSchema;
  let i = t.version === "draft-2020-12" ? "$defs" : "definitions";
  if (n[0] === i) {
    let r = n[1];
    if (!r || !t.defs[r])
      throw new Error(`Reference not found: ${e}`);
    return t.defs[r];
  }
  throw new Error(`Reference not found: ${e}`);
}
s(pb, "resolveRef");
function zm(e, t) {
  if (e.not !== void 0) {
    if (typeof e.not == "object" && Object.keys(e.not).length === 0)
      return _.never();
    throw new Error("not is not supported in Zod (except { not: {} } for never)");
  }
  if (e.unevaluatedItems !== void 0)
    throw new Error("unevaluatedItems is not supported");
  if (e.unevaluatedProperties !== void 0)
    throw new Error("unevaluatedProperties is not supported");
  if (e.if !== void 0 || e.then !== void 0 || e.else !== void 0)
    throw new Error("Conditional schemas (if/then/else) are not supported");
  if (e.dependentSchemas !== void 0 || e.dependentRequired !== void 0)
    throw new Error("dependentSchemas and dependentRequired are not supported");
  if (e.$ref) {
    let r = e.$ref;
    if (t.refs.has(r))
      return t.refs.get(r);
    if (t.processing.has(r))
      return _.lazy(() => {
        if (!t.refs.has(r))
          throw new Error(`Circular reference not resolved: ${r}`);
        return t.refs.get(r);
      });
    t.processing.add(r);
    let o = pb(r, t), a = Y(o, t);
    return t.refs.set(r, a), t.processing.delete(r), a;
  }
  if (e.enum !== void 0) {
    let r = e.enum;
    if (t.version === "openapi-3.0" && e.nullable === !0 && r.length === 1 && r[0] === null)
      return _.null();
    if (r.length === 0)
      return _.never();
    if (r.length === 1)
      return _.literal(r[0]);
    if (r.every((a) => typeof a == "string"))
      return _.enum(r);
    let o = r.map((a) => _.literal(a));
    return o.length < 2 ? o[0] : _.union([o[0], o[1], ...o.slice(2)]);
  }
  if (e.const !== void 0)
    return _.literal(e.const);
  let n = e.type;
  if (Array.isArray(n)) {
    let r = n.map((o) => {
      let a = { ...e, type: o };
      return zm(a, t);
    });
    return r.length === 0 ? _.never() : r.length === 1 ? r[0] : _.union(r);
  }
  if (!n)
    return _.any();
  let i;
  switch (n) {
    case "string": {
      let r = _.string();
      if (e.format) {
        let o = e.format;
        o === "email" ? r = r.check(_.email()) : o === "uri" || o === "uri-reference" ? r = r.check(_.url()) : o === "uuid" || o === "guid" ? r = r.check(_.uuid()) : o === "date-time" ? r = r.check(_.iso.datetime()) : o === "date" ? r = r.check(_.iso.date()) : o === "time" ? r = r.check(_.iso.time()) : o === "duration" ? r = r.check(_.iso.duration()) : o === "ipv4" ? r = r.check(_.ipv4()) : o === "ipv6" ? r = r.check(_.ipv6()) : o === "mac" ? r = r.check(_.mac()) : o === "cidr" ? r = r.check(_.cidrv4()) : o === "cidr-v6" ? r = r.check(_.cidrv6()) : o === "base64" ? r = r.check(_.base64()) : o === "base64url" ? r = r.check(_.base64url()) : o === "e164" ? r = r.check(_.e164()) : o === "jwt" ? r = r.check(_.jwt()) : o === "emoji" ? r = r.check(_.emoji()) : o === "nanoid" ? r = r.check(_.nanoid()) : o === "cuid" ? r = r.check(_.cuid()) : o === "cuid2" ? r = r.check(_.cuid2()) : o === "ulid" ? r = r.check(_.ulid()) : o === "xid" ? r = r.check(_.xid()) : o === "ksuid" && (r = r.check(_.ksuid()));
      }
      typeof e.minLength == "number" && (r = r.min(e.minLength)), typeof e.maxLength == "number" && (r = r.max(e.maxLength)), e.pattern && (r = r.regex(new RegExp(e.pattern))), i = r;
      break;
    }
    case "number":
    case "integer": {
      let r = n === "integer" ? _.number().int() : _.number();
      typeof e.minimum == "number" && (r = r.min(e.minimum)), typeof e.maximum == "number" && (r = r.max(e.maximum)), typeof e.exclusiveMinimum == "number" ? r = r.gt(e.exclusiveMinimum) : e.exclusiveMinimum === !0 && typeof e.minimum == "number" && (r = r.gt(e.minimum)), typeof e.exclusiveMaximum == "number" ? r = r.lt(e.exclusiveMaximum) : e.exclusiveMaximum === !0 && typeof e.maximum == "number" && (r = r.lt(e.maximum)), typeof e.multipleOf == "number" && (r = r.multipleOf(e.multipleOf)), i = r;
      break;
    }
    case "boolean": {
      i = _.boolean();
      break;
    }
    case "null": {
      i = _.null();
      break;
    }
    case "object": {
      let r = {}, o = e.properties || {}, a = new Set(e.required || []);
      for (let [u, l] of Object.entries(o)) {
        let d = Y(l, t);
        r[u] = a.has(u) ? d : d.optional();
      }
      if (e.propertyNames) {
        let u = Y(e.propertyNames, t), l = e.additionalProperties && typeof e.additionalProperties == "object" ? Y(e.additionalProperties, t) : _.any();
        if (Object.keys(r).length === 0) {
          i = _.record(u, l);
          break;
        }
        let d = _.object(r).passthrough(), m = _.looseRecord(u, l);
        i = _.intersection(d, m);
        break;
      }
      if (e.patternProperties) {
        let u = e.patternProperties, l = Object.keys(u), d = [];
        for (let y of l) {
          let h = Y(u[y], t), z = _.string().regex(new RegExp(y));
          d.push(_.looseRecord(z, h));
        }
        let m = [];
        if (Object.keys(r).length > 0 && m.push(_.object(r).passthrough()), m.push(...d), m.length === 0)
          i = _.object({}).passthrough();
        else if (m.length === 1)
          i = m[0];
        else {
          let y = _.intersection(m[0], m[1]);
          for (let h = 2; h < m.length; h++)
            y = _.intersection(y, m[h]);
          i = y;
        }
        break;
      }
      let c = _.object(r);
      e.additionalProperties === !1 ? i = c.strict() : typeof e.additionalProperties == "object" ? i = c.catchall(Y(e.additionalProperties, t)) : i = c.passthrough();
      break;
    }
    case "array": {
      let r = e.prefixItems, o = e.items;
      if (r && Array.isArray(r)) {
        let a = r.map((u) => Y(u, t)), c = o && typeof o == "object" && !Array.isArray(o) ? Y(o, t) : void 0;
        c ? i = _.tuple(a).rest(c) : i = _.tuple(a), typeof e.minItems == "number" && (i = i.check(_.minLength(e.minItems))), typeof e.maxItems == "number" && (i = i.check(_.maxLength(e.maxItems)));
      } else if (Array.isArray(o)) {
        let a = o.map((u) => Y(u, t)), c = e.additionalItems && typeof e.additionalItems == "object" ? Y(e.additionalItems, t) : void 0;
        c ? i = _.tuple(a).rest(c) : i = _.tuple(a), typeof e.minItems == "number" && (i = i.check(_.minLength(e.minItems))), typeof e.maxItems == "number" && (i = i.check(_.maxLength(e.maxItems)));
      } else if (o !== void 0) {
        let a = Y(o, t), c = _.array(a);
        typeof e.minItems == "number" && (c = c.min(e.minItems)), typeof e.maxItems == "number" && (c = c.max(e.maxItems)), i = c;
      } else
        i = _.array(_.any());
      break;
    }
    default:
      throw new Error(`Unsupported type: ${n}`);
  }
  return i;
}
s(zm, "convertBaseSchema");
function Y(e, t) {
  if (typeof e == "boolean")
    return e ? _.any() : _.never();
  let n = zm(e, t), i = e.type || e.enum !== void 0 || e.const !== void 0;
  if (e.anyOf && Array.isArray(e.anyOf)) {
    let c = e.anyOf.map((l) => Y(l, t)), u = _.union(c);
    n = i ? _.intersection(n, u) : u;
  }
  if (e.oneOf && Array.isArray(e.oneOf)) {
    let c = e.oneOf.map((l) => Y(l, t)), u = _.xor(c);
    n = i ? _.intersection(n, u) : u;
  }
  if (e.allOf && Array.isArray(e.allOf))
    if (e.allOf.length === 0)
      n = i ? n : _.any();
    else {
      let c = i ? n : Y(e.allOf[0], t), u = i ? 0 : 1;
      for (let l = u; l < e.allOf.length; l++)
        c = _.intersection(c, Y(e.allOf[l], t));
      n = c;
    }
  e.nullable === !0 && t.version === "openapi-3.0" && (n = _.nullable(n)), e.readOnly === !0 && (n = _.readonly(n)), e.default !== void 0 && (n = n.default(e.default));
  let r = {}, o = ["$id", "id", "$comment", "$anchor", "$vocabulary", "$dynamicRef", "$dynamicAnchor"];
  for (let c of o)
    c in e && (r[c] = e[c]);
  let a = ["contentEncoding", "contentMediaType", "contentSchema"];
  for (let c of a)
    c in e && (r[c] = e[c]);
  for (let c of Object.keys(e))
    db.has(c) || (r[c] = e[c]);
  return Object.keys(r).length > 0 && t.registry.add(n, r), e.description && (n = n.describe(e.description)), n;
}
s(Y, "convertSchema");
function Im(e, t) {
  if (typeof e == "boolean")
    return e ? _.any() : _.never();
  let n;
  try {
    n = JSON.parse(JSON.stringify(e));
  } catch {
    throw new Error("fromJSONSchema input is not valid JSON (possibly cyclic); use $defs/$ref for recursive schemas");
  }
  let i = fb(n, t?.defaultTarget), r = n.$defs || n.definitions || {}, o = {
    version: i,
    defs: r,
    refs: /* @__PURE__ */ new Map(),
    processing: /* @__PURE__ */ new Set(),
    rootSchema: n,
    registry: t?.registry ?? H
  };
  return Y(n, o);
}
s(Im, "fromJSONSchema");

// versions/4.4.3/node_modules/zod/v4/classic/coerce.js
var Od = {};
Pe(Od, {
  bigint: () => vb,
  boolean: () => hb,
  date: () => yb,
  number: () => gb,
  string: () => mb
});
function mb(e) {
  return ru(rr, e);
}
s(mb, "string");
function gb(e) {
  return lu(ir, e);
}
s(gb, "number");
function hb(e) {
  return vu(or, e);
}
s(hb, "boolean");
function vb(e) {
  return bu(ar, e);
}
s(vb, "bigint");
function yb(e) {
  return Pu(Wr, e);
}
s(yb, "date");

// versions/4.4.3/node_modules/zod/v4/classic/external.js
q(Er());

// node_modules/zodvex/dist/index.js
var Sm = /* @__PURE__ */ new WeakMap(), $b = {
  getMetadata: /* @__PURE__ */ s((e) => Sm.get(e), "getMetadata"),
  setMetadata: /* @__PURE__ */ s((e, t) => Sm.set(e, t), "setMetadata")
};
var oj = w.discriminatedUnion("success", [
  w.object({ success: w.literal(!0) }),
  w.object({ success: w.literal(!1), error: w.string() })
]), aj = w.object({
  formErrors: w.array(w.string()),
  fieldErrors: w.record(w.string(), w.array(w.string()))
});
var xb = "__zodvexMeta";
function Pm(e, t) {
  Object.defineProperty(e, xb, {
    value: t,
    enumerable: !1,
    writable: !1,
    configurable: !1
  });
}
s(Pm, "attachMeta");
function Pd(e) {
  let t = w.string().check(
    w.refine((i) => typeof i == "string" && i.length > 0, {
      message: `Invalid ID for table "${e}"`
    }),
    w.describe(`convexId:${e}`)
  );
  $b.setMetadata(t, {
    isConvexId: !0,
    tableName: e
  });
  let n = t;
  return n._tableName = e, n;
}
s(Pd, "id");
function Tm(e) {
  return e instanceof re || e instanceof Me;
}
s(Tm, "isZodUnion");
function Em(e) {
  return e instanceof re, e._zod.def.options;
}
s(Em, "getUnionOptions");
function _b(e) {
  if (e.length < 2)
    throw new Error(
      `z.union() requires at least 2 options, but received ${e.length}. This indicates an invalid union schema was passed to zodTable().`
    );
}
s(_b, "assertUnionOptions");
function Um(e) {
  return _b(e), w.union(e);
}
s(Um, "createUnionFromOptions");
function Dm(e, t) {
  if (Tm(t)) {
    let i = Em(t).map((r) => {
      if (r instanceof K) {
        let o = {
          ...r._zod.def.shape,
          _id: Pd(e),
          _creationTime: w.number()
        };
        return W(r, { ...r._zod.def, shape: o });
      }
      return r;
    });
    return Um(i);
  }
  if (t instanceof K) {
    let n = { ...t._zod.def.shape, _id: Pd(e), _creationTime: w.number() };
    return W(t, { ...t._zod.def, shape: n });
  }
  return t;
}
s(Dm, "addSystemFields");
function wb(e) {
  return e instanceof V ? e : new V({ type: "optional", innerType: e });
}
s(wb, "ensureOptional");
function jm(e) {
  return new V({
    type: "optional",
    innerType: new be({ type: "nullable", innerType: e })
  });
}
s(jm, "nullableOptional2");
function kb(e) {
  let t = {};
  for (let [n, i] of Object.entries(e))
    t[n] = wb(i);
  return t;
}
s(kb, "createPartialShape");
function Td(e, t) {
  return w.object({
    _id: Pd(e),
    _creationTime: w.optional(w.number()),
    ...kb(t)
  });
}
s(Td, "createUpdateObjectSchema");
function Nm(e) {
  return w.object({
    page: w.array(e),
    isDone: w.boolean(),
    continueCursor: w.string(),
    splitCursor: jm(w.string()),
    pageStatus: jm(w.enum(["SplitRecommended", "SplitRequired"]))
  });
}
s(Nm, "createPaginatedDocSchema");
function zb(e, t, n = w.object(t)) {
  let i = Dm(e, n);
  return {
    doc: i,
    base: n,
    insert: n,
    update: Td(e, t),
    docArray: w.array(i),
    paginatedDoc: Nm(i)
  };
}
s(zb, "createObjectSchemaBundle");
function Ib(e, t) {
  if (Tm(t)) {
    let n = Em(t).map((i) => i instanceof K ? Td(e, i._zod.def.shape) : i);
    return Um(n);
  }
  return t instanceof K ? Td(e, t._zod.def.shape) : t;
}
s(Ib, "createSchemaUpdateSchema");
function Sb(e, t) {
  let n = Dm(e, t);
  return {
    doc: n,
    base: t,
    insert: t,
    update: Ib(e, t),
    docArray: w.array(n),
    paginatedDoc: Nm(n)
  };
}
s(Sb, "createSchemaBundle");
function Zm(e, t) {
  let n;
  return {
    get: /* @__PURE__ */ s(() => n || (n = t ?? w.object(e), n), "get")
  };
}
s(Zm, "lazyValidator");
function Yr(e, t, n, i, r = {}, o = {}, a = {}, c = null) {
  let u = Zm(t, c), l = {
    name: e,
    fields: t,
    schema: n,
    indexes: r,
    searchIndexes: o,
    vectorIndexes: a,
    get validator() {
      return u.get();
    },
    index(d, m) {
      return Yr(
        e,
        t,
        n,
        i,
        { ...r, [d]: [...m, "_creationTime"] },
        o,
        a,
        c
      );
    },
    searchIndex(d, m) {
      return Yr(
        e,
        t,
        n,
        i,
        r,
        { ...o, [d]: m },
        a,
        c
      );
    },
    vectorIndex(d, m) {
      return Yr(
        e,
        t,
        n,
        i,
        r,
        o,
        { ...a, [d]: m },
        c
      );
    }
  };
  return Pm(l, { type: "model", tableName: e, definitionSource: i, schemas: n }), l;
}
s(Yr, "createModel");
function en(e, t, n, i, r = {}, o = {}, a = {}) {
  let c = Zm(t, n), u = {
    name: e,
    fields: t,
    indexes: r,
    searchIndexes: o,
    vectorIndexes: a,
    get validator() {
      return c.get();
    },
    index(l, d) {
      return en(
        e,
        t,
        n,
        i,
        { ...r, [l]: [...d, "_creationTime"] },
        o,
        a
      );
    },
    searchIndex(l, d) {
      return en(
        e,
        t,
        n,
        i,
        r,
        { ...o, [l]: d },
        a
      );
    },
    vectorIndex(l, d) {
      return en(e, t, n, i, r, o, {
        ...a,
        [l]: d
      });
    }
  };
  return n !== null && (u.schema = n), Pm(u, { type: "model", tableName: e, definitionSource: i }), u;
}
s(en, "createSlimModel");
function Om(e, t, n) {
  let i = n?.schemaHelpers === !1;
  if (t instanceof k)
    return i ? en(e, {}, t, "schema") : Yr(
      e,
      {},
      Sb(e, t),
      "schema",
      void 0,
      void 0,
      void 0,
      t
    );
  let r = t;
  return i ? en(e, r, null, "shape") : Yr(e, r, zb(e, r), "shape");
}
s(Om, "defineZodModel");
function Am(e, t, n) {
  return t instanceof k, Om(e, t, n);
}
s(Am, "defineZodModel2");
function so(e) {
  let t = /* @__PURE__ */ Symbol.for(`zodvex.zx.cache.${e}`), n = globalThis, i = n[t];
  if (i) return i;
  let r = /* @__PURE__ */ new WeakMap();
  return n[t] = r, r;
}
s(so, "sharedWeakMap");
var sj = so("base"), cj = so("doc"), uj = so("update"), lj = so("docArray");

// ../zodvex-triage-20260909/node_modules/.bun/convex-helpers@0.1.113+b9ed8f5244cf7f28/node_modules/convex-helpers/index.js
var pj = Symbol();

// ../zodvex-triage-20260909/node_modules/.bun/convex-helpers@0.1.113+b9ed8f5244cf7f28/node_modules/convex-helpers/validators.js
var bj = g.string(), $j = g.float64(), xj = g.float64(), _j = g.boolean(), wj = g.int64(), kj = g.int64(), zj = g.any(), Ij = g.null(), { id: Sj, object: jj, array: Oj, bytes: Pj, literal: Tj, optional: Ej, union: Uj } = g, Dj = g.bytes();
var Nj = g.optional(g.any());

// ../zodvex-triage-20260909/node_modules/.bun/convex-helpers@0.1.113+b9ed8f5244cf7f28/node_modules/convex-helpers/server/customFunctions.js
var co = {
  args: {},
  input() {
    return { args: {}, ctx: {} };
  }
};

// node_modules/zodvex/dist/server/index.js
function Cm(e) {
  let t = e;
  for (let n = 0; n < 10; n++) {
    if (t instanceof V || t instanceof be || t instanceof le) {
      t = t._zod.def.innerType;
      continue;
    }
    break;
  }
  return t;
}
s(Cm, "unwrapOuter");
function jb(e, t) {
  let n = [], i = t;
  for (let r of e) {
    if (i = Cm(i), i instanceof $e)
      break;
    if (i instanceof K && typeof r == "string") {
      let o = i._zod.def.shape[r];
      if (!o) {
        n.push(r);
        break;
      }
      if (n.push(r), Cm(o) instanceof $e)
        break;
      i = o;
      continue;
    }
    if (i instanceof Le && typeof r == "number") {
      n.push(r), i = i._zod.def.element;
      continue;
    }
    n.push(r);
  }
  return n;
}
s(jb, "truncateAtCodecBoundary");
function Ob(e, t) {
  let n = e.issues.map((i) => ({
    ...i,
    path: jb(i.path, t)
  }));
  return new ve(n);
}
s(Ob, "normalizeCodecPaths");
function Pb(e, t) {
  try {
    return ye(e, t);
  } catch (n) {
    throw n instanceof ve ? Ob(n, e) : n;
  }
}
s(Pb, "safeEncode");
function Ge(e) {
  if (e == null)
    return e;
  if (Array.isArray(e))
    return e.map(Ge);
  if (typeof e == "object" && e.constructor === Object) {
    let t = {};
    for (let [n, i] of Object.entries(e))
      i !== void 0 && (t[n] = Ge(i));
    return t;
  }
  return e;
}
s(Ge, "stripUndefined");
var Tb = /* @__PURE__ */ Symbol.for("functionName");
function Rm(e) {
  if (typeof e == "string") return e;
  let t = e[Tb];
  return t || null;
}
s(Rm, "resolveFunctionPath");
var Eb = class extends ve {
  static {
    s(this, "ZodvexDecodeError");
  }
  functionPath;
  wireData;
  constructor(e, t, n) {
    super(t), this.functionPath = e, this.wireData = n, this.name = "ZodvexDecodeError";
  }
}, Fm = /* @__PURE__ */ new Set();
function Ub(e, t) {
  let n = t?.onDecodeError ?? "warn", i = t?.warnWirePreview === !0;
  function r(a, c) {
    if (c == null) return c;
    let u = Rm(a);
    if (u == null) return c;
    let l = e[u];
    return l?.args ? Ge(Pb(l.args, c)) : (l === void 0 && !Fm.has(u) && (Fm.add(u), console.debug(
      `[zodvex] No registry entry for "${u}" \u2014 args/returns pass through unencoded. This is expected when the target is a raw (non-zodvex) function; if it should be codec-aware, run \`zodvex generate\` to update the registry.`
    )), c);
  }
  s(r, "encodeArgs");
  function o(a, c) {
    let u = Rm(a);
    if (u == null) return c;
    let l = e[u];
    if (!l?.returns) return c;
    let d = nt(l.returns, c);
    if (d.success) return d.data;
    if (n === "throw")
      throw new Eb(u, d.error.issues, c);
    let m = d.error.issues.map((h) => `${h.path.join(".")}: ${h.message}`).join(", "), y = `[zodvex] Decode failed for ${u}: ${m}. Returning raw wire data.`;
    if (i) {
      let h = "[unavailable]";
      try {
        h = JSON.stringify(c) ?? "[unavailable]";
      } catch {
      }
      let z = h.length > 200 ? `${h.slice(0, 200)}...` : h;
      y += ` Preview: ${z}`;
    }
    return console.warn(y), c;
  }
  return s(o, "decodeResult"), { encodeArgs: r, decodeResult: o };
}
s(Ub, "createBoundaryHelpers");
function Lm(e, t) {
  return async (n, ...i) => {
    let r = t.encodeArgs(n, i[0]), o = await e(n, r);
    return t.decodeResult(n, o);
  };
}
s(Lm, "wrapRun");
function Db(e, t) {
  let n = { ...e };
  return n.runAfter = (i, r, ...o) => {
    let a = t.encodeArgs(r, o[0]);
    return e.runAfter(i, r, ...o.length ? [a] : []);
  }, n.runAt = (i, r, ...o) => {
    let a = t.encodeArgs(r, o[0]);
    return e.runAt(i, r, ...o.length ? [a] : []);
  }, n;
}
s(Db, "wrapScheduler");
function cg(e, t, n) {
  let i = Ub(e, n), r = {};
  return typeof t.runQuery == "function" && (r.runQuery = Lm(t.runQuery, i)), typeof t.runMutation == "function" && (r.runMutation = Lm(t.runMutation, i)), t.scheduler && (r.scheduler = Db(t.scheduler, i)), r;
}
s(cg, "createCodecCallOverrides");
var Mm = /* @__PURE__ */ new WeakMap(), po = {
  getMetadata: /* @__PURE__ */ s((e) => Mm.get(e), "getMetadata"),
  setMetadata: /* @__PURE__ */ s((e, t) => Mm.set(e, t), "setMetadata")
};
function Nb(e) {
  let t = e._zod.def.entries, n = Object.keys(t);
  if (n && Array.isArray(n) && n.length > 0) {
    let i = n.filter((r) => r != null).map((r) => g.literal(r));
    if (i.length === 1) {
      let [r] = i;
      return r;
    } else if (i.length >= 2) {
      let [r, o, ...a] = i;
      return g.union(
        r,
        o,
        ...a
      );
    } else
      return g.any();
  } else
    return g.any();
}
s(Nb, "convertEnumType");
function Zb(e, t, n) {
  let i = e._zod.def.innerType;
  if (i && i instanceof k)
    if (i instanceof V) {
      let r = i._zod.def.innerType, o = n(r, t);
      return {
        validator: g.union(o, g.null()),
        isOptional: !0
        // Mark as optional so it gets wrapped later
      };
    } else {
      let r = n(i, t);
      return {
        validator: g.union(r, g.null()),
        isOptional: !1
      };
    }
  else
    return {
      validator: g.any(),
      isOptional: !1
    };
}
s(Zb, "convertNullableType");
function Ab(e, t, n) {
  let i = e._zod.def.valueType;
  if (i || (i = e._zod.def.keyType), i && i instanceof k)
    if (i instanceof V || i instanceof le || i instanceof le && i._zod.def.innerType instanceof V) {
      let o, a, c = !1;
      if (i instanceof le) {
        c = !0, a = i._zod.def.defaultValue;
        let d = i._zod.def.innerType;
        d instanceof V ? o = d._zod.def.innerType : o = d;
      } else i instanceof V ? o = i._zod.def.innerType : o = i;
      let u = n(o, t), l = g.union(u, g.null());
      return c && (l._zodDefault = a), g.record(g.string(), l);
    } else
      return g.record(g.string(), n(i, t));
  else
    return g.record(g.string(), g.any());
}
s(Ab, "convertRecordType");
function Cb(e, t, n) {
  let i = e instanceof Me ? e._zod.def.options : (
    // cast: fallback for non-standard discriminated union variants
    e._zod?.def?.options
  );
  if (i) {
    let r = Array.isArray(i) ? i : Array.from(i);
    if (r.length >= 2) {
      let o = r.map((l) => {
        let d = new Set(t);
        return n(l, d);
      }), [a, c, ...u] = o;
      return g.union(
        a,
        c,
        ...u
      );
    } else
      return g.any();
  } else
    return g.any();
}
s(Cb, "convertDiscriminatedUnionType");
function Rb(e, t, n) {
  let i = e._zod.def.options;
  if (i && Array.isArray(i) && i.length > 0) {
    if (i.length === 1)
      return n(i[0], t);
    {
      let r = i.map((o) => {
        let a = new Set(t);
        return n(o, a);
      });
      if (r.length >= 2) {
        let [o, a, ...c] = r;
        return g.union(
          o,
          a,
          ...c
        );
      } else
        return g.any();
    }
  } else
    return g.any();
}
s(Rb, "convertUnionType");
function Fb(e) {
  let t = po.getMetadata(e);
  return t?.isConvexId === !0 && t?.tableName && typeof t.tableName == "string";
}
s(Fb, "isZid");
var Bm = /* @__PURE__ */ new WeakMap();
function ce(e, t = /* @__PURE__ */ new Set()) {
  if (!e)
    return g.any();
  let n = Bm.get(e);
  if (n)
    return n;
  if (t.has(e))
    return g.any();
  t.add(e);
  let i = e, r = !1, o, a = !1;
  e instanceof le && (a = !0, o = e._zod.def.defaultValue, i = e._zod.def.innerType), i instanceof V && (r = !0, i = i._zod.def.innerType, i instanceof le && (a = !0, o = i._zod.def.defaultValue, i = i._zod.def.innerType));
  let c;
  if (Fb(i)) {
    let d = po.getMetadata(i)?.tableName || "unknown";
    c = g.id(d);
  } else
    switch (i._zod.def.type) {
      case "string":
        c = g.string();
        break;
      case "number":
        c = g.float64();
        break;
      case "bigint":
        c = g.int64();
        break;
      case "boolean":
        c = g.boolean();
        break;
      case "date":
        c = g.float64();
        break;
      case "null":
        c = g.null();
        break;
      case "nan":
        c = g.float64();
        break;
      case "array": {
        if (i instanceof Le) {
          let d = i._zod.def.element;
          c = g.array(ce(d, t));
        } else
          c = g.array(g.any());
        break;
      }
      case "object": {
        if (i instanceof K) {
          let d = i._zod.def.shape, m = {};
          for (let [y, h] of Object.entries(d))
            h && h instanceof k && (m[y] = ce(h, t));
          c = g.object(m);
        } else
          c = g.object({});
        break;
      }
      case "union": {
        i instanceof re ? c = Rb(i, t, ce) : c = g.any();
        break;
      }
      case "discriminatedUnion": {
        c = Cb(
          i,
          t,
          ce
        );
        break;
      }
      case "literal": {
        if (i instanceof Zt) {
          let m = i._zod.def.values.values().next().value;
          m != null ? c = g.literal(m) : c = g.any();
        } else
          c = g.any();
        break;
      }
      case "enum": {
        i instanceof Nt ? c = Nb(i) : c = g.any();
        break;
      }
      case "record": {
        i instanceof at ? c = Ab(i, t, ce) : c = g.record(g.string(), g.any());
        break;
      }
      case "transform":
      case "pipe": {
        if (i instanceof $e) {
          let d = i._zod.def.in;
          d && d instanceof k ? c = ce(d, t) : c = g.any();
        } else {
          let d = po.getMetadata(i);
          if (d?.brand && d?.originalSchema)
            c = ce(d.originalSchema, t);
          else {
            let m = i._zod?.def?.in;
            m && m instanceof k ? c = ce(m, t) : c = g.any();
          }
        }
        break;
      }
      case "nullable": {
        if (i instanceof be) {
          let d = Zb(i, t, ce);
          c = d.validator, d.isOptional && (r = !0);
        } else
          c = g.any();
        break;
      }
      case "tuple": {
        if (i instanceof Be) {
          let d = i._zod.def.items;
          if (d && d.length > 0) {
            let m = {};
            d.forEach((y, h) => {
              m[`_${h}`] = ce(y, t);
            }), c = g.object(m);
          } else
            c = g.object({});
        } else
          c = g.object({});
        break;
      }
      case "lazy": {
        if (i instanceof At)
          try {
            let d = i._zod.def.getter;
            if (d) {
              let m = d();
              m && m instanceof k ? c = ce(m, t) : c = g.any();
            } else
              c = g.any();
          } catch {
            c = g.any();
          }
        else
          c = g.any();
        break;
      }
      case "any":
        c = g.any();
        break;
      case "unknown":
        c = g.any();
        break;
      case "undefined":
      case "void":
      case "never":
        c = g.any();
        break;
      case "intersection":
        c = g.any();
        break;
      case "optional": {
        let d = i._zod?.def?.innerType;
        d && d instanceof k ? (c = ce(d, t), r = !0) : (c = g.any(), r = !0);
        break;
      }
      default:
        c = g.any();
        break;
    }
  let u = r || a ? g.optional(c) : c;
  return a && typeof u == "object" && u !== null && (u._zodDefault = o), Bm.set(e, u), u;
}
s(ce, "zodToConvexInternal");
function ug(e) {
  return typeof e == "object" && e !== null && !(e instanceof k) ? mo(e) : ce(e);
}
s(ug, "zodToConvex");
function mo(e) {
  let t = e instanceof K ? e._zod.def.shape : e, n = {};
  for (let [i, r] of Object.entries(t))
    n[i] = ce(r);
  return n;
}
s(mo, "zodToConvexFields");
function ht(e) {
  if (e instanceof Dt) return !0;
  if (e instanceof $e) return !1;
  if (e instanceof V || e instanceof be || e instanceof le)
    return ht(e._zod.def.innerType);
  if (e instanceof K)
    return Object.values(e._zod.def.shape).some((t) => ht(t));
  if (e instanceof Le)
    return ht(e._zod.def.element);
  if (e instanceof re)
    return e._zod.def.options.some((t) => ht(t));
  if (e instanceof at)
    return ht(e._zod.def.valueType);
  if (e instanceof Be) {
    let t = e._zod.def.items;
    return t ? t.some((n) => ht(n)) : !1;
  }
  return !1;
}
s(ht, "containsNativeZodDate");
function Jm(e, t) {
  if (ht(e))
    throw new Error(
      `[zodvex] Native z.date() found in ${t}. Convex stores dates as timestamps (numbers), which z.date() cannot parse.

Fix: Replace z.date() with zx.date()

Before: { createdAt: z.date() }
After:  { createdAt: zx.date() }

zx.date() is a codec that handles timestamp \u2194 Date conversion automatically.`
    );
}
s(Jm, "assertNoNativeZodDate");
function lg(e, t) {
  return Fe(e, t);
}
s(lg, "decodeDoc");
function Vm(e, t) {
  return Ge(ye(e, t));
}
s(Vm, "encodeDoc");
function qm(e) {
  let t = {};
  for (let [n, i] of Object.entries(e))
    t[n] = i === void 0 ? void 0 : Ge(i);
  return t;
}
s(qm, "stripUndefinedPreservingTopLevel");
function Lb(e, t) {
  if (!(e instanceof K)) {
    let a = ye(e, t);
    return a !== null && typeof a == "object" && !Array.isArray(a) ? qm(a) : Ge(a);
  }
  let n = e._zod.def.shape, i = {};
  for (let [a, c] of Object.entries(n))
    i[a] = c instanceof V ? c : new V({ type: "optional", innerType: c });
  let r = w.object(i), o = ye(r, t);
  return qm(o);
}
s(Lb, "encodePartialDoc");
function dg(e, t, n) {
  return w.codec(e, t, n);
}
s(dg, "zodvexCodec");
function Ed(e, t, n) {
  if (t.includes(".")) return n;
  if (e instanceof K) {
    let i = e.shape[t];
    if (i) return ye(i, n);
  }
  if (e instanceof re) {
    let r = e._zod.def.options.filter((o) => o instanceof K).map((o) => o.shape[t]).filter(Boolean);
    if (r.length === 1) return ye(r[0], n);
    if (r.length > 1)
      return ye(w.union(r), n);
  }
  return n;
}
s(Ed, "encodeIndexValue");
function go(e, t) {
  return new Proxy(e, {
    get(n, i, r) {
      return typeof i == "string" && ["eq", "gt", "gte", "lt", "lte"].includes(i) ? (o, a) => {
        let c = Ed(t, o, a), u = n[i](o, c);
        return go(u, t);
      } : i === "search" ? (...o) => {
        let a = n.search(...o);
        return go(a, t);
      } : Reflect.get(n, i, r);
    }
  });
}
s(go, "wrapIndexRangeBuilder");
function Ud(e, t) {
  return e != null && Object.prototype.isPrototypeOf.call(t, e);
}
s(Ud, "isFilterExpression");
function Wm(e, t) {
  if (Ud(e, t)) {
    let n = e.serialize();
    if (n && typeof n == "object" && "$field" in n)
      return n.$field;
  }
  return null;
}
s(Wm, "extractFieldPath");
function Mb(e, t) {
  let n = Object.getPrototypeOf(e.field("_id"));
  return new Proxy(e, {
    get(i, r, o) {
      return typeof r == "string" && ["eq", "neq", "lt", "lte", "gt", "gte"].includes(r) ? (a, c) => {
        let u = Wm(a, n), l = Wm(c, n);
        return u && !Ud(c, n) ? c = Ed(t, u, c) : l && !Ud(a, n) && (a = Ed(t, l, a)), i[r](a, c);
      } : Reflect.get(i, r, o);
    }
  });
}
s(Mb, "wrapFilterBuilder");
var Cd = class fg {
  static {
    s(this, "_ZodvexQueryChain");
  }
  constructor(t, n) {
    this.inner = t, this.schema = n;
  }
  /** Factory method for intermediate methods. Subclasses override to return their own type. */
  createChain(t) {
    return new fg(t, this.schema);
  }
  /** Decode a wire-format doc and cast to the decoded document type. */
  decode(t) {
    return lg(this.schema, t);
  }
  // --- Intermediate methods: wire-typed TableInfo for Convex machinery ---
  fullTableScan() {
    return this.createChain(this.inner.fullTableScan());
  }
  withIndex(t, n) {
    let i = n ? (r) => n(go(r, this.schema)) : void 0;
    return this.createChain(this.inner.withIndex(t, i));
  }
  withSearchIndex(t, n) {
    let i = /* @__PURE__ */ s((r) => n(go(r, this.schema)), "wrappedFilter");
    return this.createChain(this.inner.withSearchIndex(t, i));
  }
  order(t) {
    return this.createChain(this.inner.order(t));
  }
  // Implementation
  filter(t) {
    let n = /* @__PURE__ */ s((i) => t(Mb(i, this.schema)), "wrappedPredicate");
    return this.createChain(this.inner.filter(n));
  }
  limit(t) {
    return this.createChain(this.inner.limit(t));
  }
  count() {
    return this.inner.count();
  }
  // --- Terminal methods: return decoded Doc type ---
  async first() {
    let t = await this.inner.first();
    return t ? this.decode(t) : null;
  }
  async unique() {
    let t = await this.inner.unique();
    return t ? this.decode(t) : null;
  }
  async collect() {
    return (await this.inner.collect()).map((n) => this.decode(n));
  }
  async take(t) {
    return (await this.inner.take(t)).map((i) => this.decode(i));
  }
  async paginate(t) {
    let n = await this.inner.paginate(t);
    return {
      ...n,
      page: n.page.map((i) => this.decode(i))
    };
  }
  // --- AsyncIterable: decode each yielded document ---
  async *[Symbol.asyncIterator]() {
    for await (let t of this.inner)
      yield this.decode(t);
  }
};
function Dd(e, t, n) {
  for (let i of Object.keys(t))
    if (e.normalizeId(i, n))
      return i;
  return null;
}
s(Dd, "resolveTableName");
var vo = class {
  static {
    s(this, "ZodvexDatabaseReader");
  }
  constructor(e, t) {
    this.db = e, this.tableMap = t, this.system = e.system;
  }
  system;
  /** @internal Expose for wrapper construction (rule/audit subclasses) */
  get _internals() {
    return { db: this.db, tableMap: this.tableMap };
  }
  /**
   * Escape hatch (#85/#92): returns the database this codec wrapper delegates
   * to — the composed underlying stack when `underlyingDb` is configured (e.g.
   * a trigger-wrapped writer), the bare Convex db otherwise.
   *
   * The returned db is native-shape: reads are undecoded wire documents and it
   * bypasses codec, `.withRules()`, and `.audit()` layers entirely.
   */
  unwrap() {
    return this.db;
  }
  normalizeId(e, t) {
    return this.db.normalizeId(e, t);
  }
  async get(e, t) {
    let n, i;
    if (t !== void 0 ? (n = e, i = await this.db.get(e, t)) : (i = await this.db.get(e), n = i ? Dd(this.db, this.tableMap, e) : null), !i) return null;
    let r = n ? this.tableMap[n] : void 0;
    return r ? lg(r.doc, i) : i;
  }
  query(e) {
    let t = this.tableMap[e], n = this.db.query(e);
    return t ? new Cd(n, t.doc) : n;
  }
  /**
   * Returns a new ZodvexDatabaseReader that applies per-table read rules.
   * The returned reader is also a ZodvexDatabaseReader, so `.withRules()` can be chained.
   */
  withRules(e, t, n) {
    return new mg(this, e, t, n ?? {});
  }
  /**
   * Returns a new ZodvexDatabaseReader that fires audit callbacks on reads.
   * The returned reader is also a ZodvexDatabaseReader, so `.audit()` can be chained
   * with `.withRules()`.
   */
  audit(e) {
    return new hg(this, e);
  }
}, Rd = class extends vo {
  static {
    s(this, "ZodvexDatabaseWriter");
  }
  // Narrows the inherited `protected db` to the writer-typed view without
  // shadowing the underlying instance. Used by the write methods below.
  get writerDb() {
    return this.db;
  }
  constructor(e, t) {
    super(e, t), this.system = e.system;
  }
  /**
   * @internal Expose writer-typed internals for rules / audit subclasses.
   * Includes a `reader` field that aliases `this` (writer IS-A reader after
   * the #64 refactor) so callers expecting `_internals.reader` still work.
   */
  get _internals() {
    return { db: this.writerDb, tableMap: this.tableMap, reader: this };
  }
  /**
   * Escape hatch (#85/#92): returns the writer this codec wrapper delegates
   * to — the composed underlying stack when `underlyingDb` is configured (e.g.
   * a trigger-wrapped writer), the bare Convex db otherwise.
   *
   * The returned db is native-shape: writes must be wire-format and it
   * bypasses codec, `.withRules()`, and `.audit()` layers entirely.
   */
  unwrap() {
    return this.writerDb;
  }
  async insert(e, t) {
    let n = this.tableMap[e], i = n ? Vm(n.insert, t) : t;
    return this.writerDb.insert(e, i);
  }
  async patch(e, t, n) {
    let i, r, o;
    n !== void 0 ? (i = e, r = t, o = n) : (r = e, o = t, i = Dd(this.db, this.tableMap, r));
    let a = i ? this.tableMap[i] : void 0, c = a ? Lb(a.insert, o) : o;
    return n !== void 0 ? this.writerDb.patch(e, r, c) : this.writerDb.patch(r, c);
  }
  async replace(e, t, n) {
    let i, r, o;
    n !== void 0 ? (i = e, r = t, o = n) : (r = e, o = t, i = Dd(this.db, this.tableMap, r));
    let a = i ? this.tableMap[i] : void 0, c = a ? Vm(a.insert, o) : o;
    return n !== void 0 ? this.writerDb.replace(e, r, c) : this.writerDb.replace(r, c);
  }
  async delete(e, t) {
    return t !== void 0 ? this.writerDb.delete(e, t) : this.writerDb.delete(e);
  }
  /**
   * Returns a new ZodvexDatabaseWriter that applies per-table read and write rules.
   * The returned writer is also a ZodvexDatabaseWriter, so `.withRules()` can be chained.
   *
   * Overrides Reader's signature so a writer chained call returns a writer.
   */
  withRules(e, t, n) {
    return new Jb(this, e, t, n ?? {});
  }
  /**
   * Returns a new ZodvexDatabaseWriter that fires audit callbacks on reads and writes.
   * The returned writer is also a ZodvexDatabaseWriter, so `.audit()` can be chained
   * with `.withRules()`.
   *
   * Overrides Reader's signature so a writer chained call returns a writer.
   */
  audit(e) {
    return new qb(this, e);
  }
};
function uo(e, t) {
  return e === !0 ? t : e === !1 ? null : e;
}
s(uo, "normalizeReadResult");
var Bb = class pg extends Cd {
  static {
    s(this, "_RulesQueryChain");
  }
  readRule;
  rulesConfig;
  ctx;
  constructor(t, n, i, r, o = {}) {
    super(t, n), this.readRule = i, this.rulesConfig = r, this.ctx = o;
  }
  createChain(t) {
    return new pg(t, this.schema, this.readRule, this.rulesConfig, this.ctx);
  }
  async first() {
    for await (let t of this)
      return t;
    return null;
  }
  async unique() {
    let t = await super.unique();
    return t === null ? null : uo(await this.readRule(this.ctx, t), t);
  }
  async collect() {
    let t = [];
    for await (let n of this)
      t.push(n);
    return t;
  }
  async take(t) {
    if (!Number.isInteger(t) || t < 0)
      throw new Error("take requires a non-negative integer");
    let n = [];
    if (t === 0) return n;
    for await (let i of this)
      if (n.push(i), n.length >= t) break;
    return n;
  }
  async paginate(t) {
    let n = await super.paginate(t), i = [];
    for (let r of n.page) {
      let o = uo(await this.readRule(this.ctx, r), r);
      o !== null && i.push(o);
    }
    return { ...n, page: i };
  }
  async count() {
    if (!this.rulesConfig.allowCounting)
      throw new Error("count is not allowed with rules");
    return super.count();
  }
  async *[Symbol.asyncIterator]() {
    for await (let t of super[Symbol.asyncIterator]()) {
      let n = uo(await this.readRule(this.ctx, t), t);
      n !== null && (yield n);
    }
  }
};
function lo(e, t, n, i) {
  for (let r of Object.keys(n))
    if (e.normalizeId(r, t))
      return r;
  if ((i.defaultPolicy ?? "allow") === "deny") {
    for (let r of Object.keys(e._internals.tableMap))
      if (e.normalizeId(r, t))
        return r;
  }
  return null;
}
s(lo, "resolveRulesTableName");
var mg = class extends vo {
  static {
    s(this, "RulesDatabaseReader");
  }
  constructor(e, t, n, i) {
    let { db: r, tableMap: o } = e._internals;
    super(r, o), this.inner = e, this.ctx = t, this.rules = n, this.rulesConfig = i, this.system = e.system;
  }
  async get(e, t) {
    let n = await this.inner.get(e, t);
    if (n === null) return null;
    let i = t !== void 0 ? e : lo(this.inner, e, this.rules, this.rulesConfig);
    return i ? this.applyReadRule(i, n) : n;
  }
  query(e) {
    let t = this.rules[e];
    if (!t?.read && (this.rulesConfig.defaultPolicy ?? "allow") === "allow")
      return this.inner.query(e);
    let n = this.inner.query(e), i = t?.read ?? (async () => null), r = w.any();
    return new Bb(n, r, i, this.rulesConfig, this.ctx);
  }
  async applyReadRule(e, t) {
    let n = this.rules[e];
    if (!n?.read)
      return (this.rulesConfig.defaultPolicy ?? "allow") === "deny" ? null : t;
    let i = await n.read(this.ctx, t);
    return uo(i, t);
  }
}, Jb = class extends Rd {
  static {
    s(this, "RulesDatabaseWriter");
  }
  constructor(e, t, n, i) {
    let { db: r, tableMap: o, reader: a } = e._internals;
    super(r, o), this.inner = e, this.ctx = t, this.rules = n, this.rulesConfig = i, this.rulesReader = new mg(a, t, n, i), this.system = e.system;
  }
  rulesReader;
  normalizeId(e, t) {
    return this.rulesReader.normalizeId(e, t);
  }
  async get(e, t) {
    return this.rulesReader.get(e, t);
  }
  query(e) {
    return this.rulesReader.query(e);
  }
  async insert(e, t) {
    let n = e, i = this.rules[n];
    if (i?.insert) {
      let r = await i.insert(this.ctx, t);
      return this.inner.insert(
        e,
        r
      );
    }
    if ((this.rulesConfig.defaultPolicy ?? "allow") === "deny")
      throw new Error(`insert not allowed on ${n}`);
    return this.inner.insert(e, t);
  }
  async patch(e, t, n) {
    let i, r;
    n !== void 0 ? (i = t, r = n) : (i = e, r = t);
    let o = await this.rulesReader.get(i);
    if (o === null)
      throw new Error("no read access or doc does not exist");
    let a = lo(this.inner, i, this.rules, this.rulesConfig), c = a ? this.rules[a] : void 0;
    if (c?.patch) {
      let u = await c.patch(this.ctx, o, r);
      return this.inner.patch(
        i,
        u
      );
    }
    if ((this.rulesConfig.defaultPolicy ?? "allow") === "deny")
      throw new Error(`patch not allowed on ${a}`);
    return this.inner.patch(i, r);
  }
  async replace(e, t, n) {
    let i, r;
    n !== void 0 ? (i = t, r = n) : (i = e, r = t);
    let o = await this.rulesReader.get(i);
    if (o === null)
      throw new Error("no read access or doc does not exist");
    let a = lo(this.inner, i, this.rules, this.rulesConfig), c = a ? this.rules[a] : void 0;
    if (c?.replace) {
      let u = await c.replace(this.ctx, o, r);
      return this.inner.replace(i, u);
    }
    if ((this.rulesConfig.defaultPolicy ?? "allow") === "deny")
      throw new Error(`replace not allowed on ${a}`);
    return this.inner.replace(i, r);
  }
  async delete(e, t) {
    let n;
    t !== void 0 ? n = t : n = e;
    let i = await this.rulesReader.get(n);
    if (i === null)
      throw new Error("no read access or doc does not exist");
    let r = lo(this.inner, n, this.rules, this.rulesConfig), o = r ? this.rules[r] : void 0;
    if (o?.delete)
      return await o.delete(this.ctx, i), this.inner.delete(n);
    if ((this.rulesConfig.defaultPolicy ?? "allow") === "deny")
      throw new Error(`delete not allowed on ${r}`);
    return this.inner.delete(n);
  }
}, Vb = class gg extends Cd {
  static {
    s(this, "_AuditQueryChain");
  }
  afterRead;
  tableName;
  constructor(t, n, i, r) {
    super(t, n), this.afterRead = i, this.tableName = r;
  }
  createChain(t) {
    return new gg(t, this.schema, this.afterRead, this.tableName);
  }
  async first() {
    let t = await super.first();
    return t !== null && await this.afterRead(this.tableName, t), t;
  }
  async unique() {
    let t = await super.unique();
    return t !== null && await this.afterRead(this.tableName, t), t;
  }
  async collect() {
    let t = await super.collect();
    for (let n of t)
      await this.afterRead(this.tableName, n);
    return t;
  }
  async take(t) {
    let n = await super.take(t);
    for (let i of n)
      await this.afterRead(this.tableName, i);
    return n;
  }
  async paginate(t) {
    let n = await super.paginate(t);
    for (let i of n.page)
      await this.afterRead(this.tableName, i);
    return n;
  }
  async *[Symbol.asyncIterator]() {
    for await (let t of super[Symbol.asyncIterator]())
      await this.afterRead(this.tableName, t), yield t;
  }
}, hg = class extends vo {
  static {
    s(this, "AuditDatabaseReader");
  }
  inner;
  afterRead;
  constructor(e, t) {
    let { db: n, tableMap: i } = e._internals;
    super(n, i), this.inner = e, this.afterRead = t.afterRead ?? (() => {
    }), this.system = e.system;
  }
  async get(e, t) {
    let n = await this.inner.get(e, t);
    if (n !== null) {
      let i = this.resolveTableFromId(
        t !== void 0 ? t : e,
        t !== void 0 ? e : void 0
      );
      i && await this.afterRead(i, n);
    }
    return n;
  }
  query(e) {
    let t = this.inner.query(e), n = w.any();
    return new Vb(t, n, this.afterRead, e);
  }
  resolveTableFromId(e, t) {
    if (t) return t;
    for (let n of Object.keys(this.tableMap))
      if (this.inner.normalizeId(n, e))
        return n;
    return null;
  }
}, qb = class extends Rd {
  static {
    s(this, "AuditDatabaseWriter");
  }
  inner;
  auditReader;
  afterWrite;
  constructor(e, t) {
    let { db: n, tableMap: i, reader: r } = e._internals;
    super(n, i), this.inner = e, this.afterWrite = t.afterWrite, this.auditReader = t.afterRead ? new hg(r, { afterRead: t.afterRead }) : r, this.system = e.system;
  }
  normalizeId(e, t) {
    return this.auditReader.normalizeId(e, t);
  }
  async get(e, t) {
    return this.auditReader.get(e, t);
  }
  query(e) {
    return this.auditReader.query(e);
  }
  async insert(e, t) {
    let n = await this.inner.insert(e, t);
    return this.afterWrite && await this.afterWrite(e, { type: "insert", id: n, value: t }), n;
  }
  async patch(e, t, n) {
    let i, r;
    n !== void 0 ? (i = t, r = n) : (i = e, r = t);
    let o = await this.inner.get(i);
    if (n !== void 0 ? await this.inner.patch(e, t, n) : await this.inner.patch(i, r), this.afterWrite) {
      let a = this.resolveTableFromId(i);
      a && await this.afterWrite(a, { type: "patch", id: i, doc: o, value: r });
    }
  }
  async replace(e, t, n) {
    let i, r;
    n !== void 0 ? (i = t, r = n) : (i = e, r = t);
    let o = await this.inner.get(i);
    if (n !== void 0 ? await this.inner.replace(e, t, n) : await this.inner.replace(i, r), this.afterWrite) {
      let a = this.resolveTableFromId(i);
      a && await this.afterWrite(a, { type: "replace", id: i, doc: o, value: r });
    }
  }
  async delete(e, t) {
    let n;
    t !== void 0 ? n = t : n = e;
    let i = await this.inner.get(n);
    if (t !== void 0 ? await this.inner.delete(e, t) : await this.inner.delete(n), this.afterWrite) {
      let r = this.resolveTableFromId(n);
      r && await this.afterWrite(r, { type: "delete", id: n, doc: i });
    }
  }
  resolveTableFromId(e) {
    for (let t of Object.keys(this.inner._internals.tableMap))
      if (this.inner.normalizeId(t, e))
        return t;
    return null;
  }
};
function Wb(e, t) {
  let n = t?.underlyingDb?.query, i = t?.underlyingDb?.mutation;
  return {
    query: {
      args: {},
      input: /* @__PURE__ */ s(async (r, o, a) => ({
        ctx: {
          db: new vo(n ? n(r) : r.db, e)
        },
        args: {}
      }), "input")
    },
    mutation: {
      args: {},
      input: /* @__PURE__ */ s(async (r, o, a) => ({
        ctx: {
          db: new Rd(i ? i(r) : r.db, e)
        },
        args: {}
      }), "input")
    }
  };
}
s(Wb, "createZodvexCustomization");
function vg(e, t) {
  let n = {};
  for (let i of t)
    i in e && (n[i] = e[i]);
  return n;
}
s(vg, "pick");
var yg = "__zodvexMeta";
function Kb(e, t) {
  Object.defineProperty(e, yg, {
    value: t,
    enumerable: !1,
    writable: !1,
    configurable: !1
  });
}
s(Kb, "attachMeta");
function bg(e) {
  if (!(e == null || typeof e != "object" && typeof e != "function"))
    return e[yg];
}
s(bg, "readMeta");
var Gb = "__zodvexCodecBrand";
function Xb(e, t) {
  Object.defineProperty(e, Gb, {
    value: t,
    enumerable: !1,
    writable: !1,
    configurable: !1
  });
}
s(Xb, "attachCodecBrand");
function Qb(e, t) {
  return {
    error: "ZodValidationError",
    context: t,
    issues: e.issues.map((n) => ({
      path: Array.isArray(n.path) ? n.path.join(".") : String(n.path ?? ""),
      code: n.code,
      message: n.message
    })),
    // Keep a flattened snapshot for easier debugging without cyclic refs
    flatten: JSON.parse(JSON.stringify(e.flatten?.() ?? {}))
  };
}
s(Qb, "formatZodIssues");
function Nd(e, t) {
  throw e instanceof ve ? new bt(Qb(e, t)) : e;
}
s(Nd, "handleZodValidationError");
function Hb(e, t) {
  try {
    return ye(e, t);
  } catch (n) {
    if (n?.message?.includes("unidirectional transform"))
      try {
        return Fe(e, t);
      } catch (i) {
        Nd(i, "returns");
      }
    Nd(n, "returns");
  }
  throw new Error("Unreachable");
}
s(Hb, "validateReturns");
function $g(e) {
  if (e)
    return e instanceof k ? e : w.object(e);
}
s($g, "normalizeFunctionSchema");
function Yb(e) {
  if (e) {
    if (e instanceof K)
      return e;
    if (!(e instanceof k))
      return w.object(e);
  }
}
s(Yb, "normalizeFunctionMetaArgs");
function Km(e, t, n) {
  Kb(e, {
    type: "function",
    zodArgs: Yb(t),
    zodReturns: $g(n)
  });
}
s(Km, "attachFunctionMeta");
var Gm = /* @__PURE__ */ new WeakMap();
function tn(e, t = 50, n = 0) {
  let i = Gm.get(e);
  if (i !== void 0)
    return i;
  if (n > t)
    return !1;
  let r = !1;
  return e instanceof Tr ? r = !0 : e instanceof re ? r = e._zod.def.options.some((o) => tn(o, t, n + 1)) : (e instanceof V || e instanceof be || e instanceof le) && (r = tn(e._zod.def.innerType, t, n + 1)), Gm.set(e, r), r;
}
s(tn, "containsCustom");
function e$(e) {
  if (e instanceof k) {
    if (e instanceof K)
      return {
        argsSchema: e,
        argsValidator: e._zod.def.shape
      };
    throw new Error(
      "Unsupported non-object Zod schema for args; please provide an args schema using z.object({...}), e.g. z.object({ foo: z.string() })"
    );
  }
  return {
    argsValidator: e,
    argsSchema: w.object(e)
  };
}
s(e$, "normalizeCustomArgsValidator");
function t$(e, t) {
  if (!(!e || t?.skipConvexValidation) && !(t?.skipCustomSchemas && tn(e)))
    return ug(e);
}
s(t$, "createConvexReturnsValidator");
function xg(e, t) {
  let n = nt(e, t);
  return n.success || Nd(n.error, "args"), n.data;
}
s(xg, "parseObjectArgsOrThrow");
async function Xm(e, t, n, i, r, o) {
  let a = vg(n, Object.keys(i)), c = o ? xg(o, a) : a;
  return await e(t, c, r);
}
s(Xm, "runCustomizationInput");
function Qm(e, t, n) {
  let i = { ...e, ...n?.ctx ?? {} }, r = n?.args ?? {};
  return {
    finalCtx: i,
    finalArgs: { ...t, ...r }
  };
}
s(Qm, "applyCustomizationResult");
async function Hm(e, t) {
  if (t?.added?.onSuccess && await t.added.onSuccess({
    ctx: t.ctx,
    args: t.args,
    result: e
  }), t?.returns) {
    let n = Hb(t.returns, e);
    return Ge(n);
  }
  return Ge(e);
}
s(Hm, "finalizeFunctionReturn");
function Fd(e, t) {
  let n = t.input ?? co.input, i = t.args ?? co.args, r = Object.entries(i), o = r.length > 0 && r.every(([, u]) => u instanceof k), a = o ? mo(i) : i, c = o ? w.object(i) : void 0;
  return /* @__PURE__ */ s(function(l) {
    let { args: d, handler: m = l, returns: y, ...h } = l, z = l.skipConvexValidation ?? !1, D = $g(y), T = t$(D, { skipConvexValidation: z }), Oe = T ? { returns: T } : void 0;
    if (D && Jm(D, "returns"), d) {
      let { argsValidator: G, argsSchema: P } = e$(d), L = z ? a : { ...mo(G), ...a };
      Jm(P, "args");
      let I = e({
        args: L,
        ...Oe,
        handler: /* @__PURE__ */ s(async (B, vt) => {
          let rn = await Xm(
            n,
            B,
            vt,
            a,
            h,
            c
          ), Pg = Object.keys(G), Tg = vg(vt, Pg), Jd = xg(P, Tg), { finalCtx: Eg, finalArgs: Ug } = Qm(B, Jd, rn), Dg = await m(Eg, Ug);
          return Hm(Dg, { ctx: B, args: Jd, added: rn, returns: D });
        }, "handler")
      }), O = c ? w.object({
        ...P._zod.def.shape,
        ...c._zod.def.shape
      }) : P;
      return Km(I, O, D), I;
    }
    let _e = e({
      args: a,
      ...Oe,
      handler: /* @__PURE__ */ s(async (G, P) => {
        let L = P, I = await Xm(
          n,
          G,
          P,
          a,
          h,
          c
        ), { finalCtx: O, finalArgs: B } = Qm(G, L, I), vt = await m(O, B);
        return Hm(vt, { ctx: G, args: L, added: I, returns: D });
      }, "handler")
    });
    return Km(_e, c ?? void 0, D), _e;
  }, "customBuilder");
}
s(Fd, "customFnBuilder");
function Ym(e, t) {
  return Fd(e, t);
}
s(Ym, "zCustomQuery");
function eg(e, t) {
  return Fd(
    e,
    t
  );
}
s(eg, "zCustomMutation");
function tg(e, t) {
  return Fd(
    e,
    t
  );
}
s(tg, "zCustomAction");
function _g(e, t, n) {
  let i = n?.wrapDb !== !1;
  if (!i && n?.underlyingDb)
    throw new Error(
      "[zodvex] initZodvex: `underlyingDb` requires the codec db wrapper \u2014 remove `wrapDb: false` or drop `underlyingDb`."
    );
  let r = Wb(e.__zodTableMap, {
    underlyingDb: n?.underlyingDb
  }), o = r$(), a = n?.registry, c = n$(a, o), u = {
    query: i ? r.query : o,
    mutation: i$(i ? r.mutation : o, a),
    action: c
  };
  return {
    zq: cr(t.query, u.query, Ym),
    zm: cr(t.mutation, u.mutation, eg),
    za: cr(t.action, u.action, tg),
    ziq: cr(t.internalQuery, u.query, Ym),
    zim: cr(t.internalMutation, u.mutation, eg),
    zia: cr(t.internalAction, u.action, tg)
  };
}
s(_g, "initZodvex");
function r$() {
  return { args: {}, input: co.input };
}
s(r$, "createNoOpCustomization");
function n$(e, t) {
  return e ? {
    args: {},
    input: /* @__PURE__ */ s(async (n) => ({
      // Auto-encode codec args at outbound call sites: runQuery/runMutation
      // (encode args, decode result) and scheduler.runAfter/runAt (encode args).
      ctx: cg(e(), n),
      args: {}
    }), "input")
  } : t;
}
s(n$, "createActionCustomization");
function i$(e, t) {
  return t ? {
    args: {},
    input: /* @__PURE__ */ s(async (n, i, r) => {
      let o = await e.input(n, {}, r), a = cg(t(), n);
      return {
        ctx: { ...o.ctx, ...a },
        args: {}
      };
    }, "input")
  } : e;
}
s(i$, "createMutationCustomization");
function o$(e, t) {
  return {
    args: t.args ?? {},
    input: /* @__PURE__ */ s(async (n, i, r) => {
      let o = await e.input(n, {}, r), a = { ...n, ...o.ctx };
      if (!t.input)
        return { ctx: o.ctx, args: {} };
      let c = await t.input(a, i, r);
      return {
        ctx: { ...o.ctx, ...c.ctx ?? {} },
        args: c.args ?? {},
        ...c.onSuccess && { onSuccess: c.onSuccess }
      };
    }, "input")
  };
}
s(o$, "composeCustomizations");
function cr(e, t, n) {
  let i = n(e, t);
  return i.withContext = (r) => {
    let o = o$(t, r);
    return n(e, o);
  }, i;
}
s(cr, "createZodvexBuilder");
function ho(e) {
  let t = w.string().check(
    w.refine((i) => typeof i == "string" && i.length > 0, {
      message: `Invalid ID for table "${e}"`
    }),
    w.describe(`convexId:${e}`)
  );
  po.setMetadata(t, {
    isConvexId: !0,
    tableName: e
  });
  let n = t;
  return n._tableName = e, n;
}
s(ho, "id");
function wg(e) {
  return e instanceof re || e instanceof Me;
}
s(wg, "isZodUnion");
function kg(e) {
  return e instanceof re, e._zod.def.options;
}
s(kg, "getUnionOptions");
function a$(e) {
  if (e.length < 2)
    throw new Error(
      `z.union() requires at least 2 options, but received ${e.length}. This indicates an invalid union schema was passed to zodTable().`
    );
}
s(a$, "assertUnionOptions");
function zg(e) {
  return a$(e), w.union(e);
}
s(zg, "createUnionFromOptions");
function s$(e, t) {
  if (wg(t)) {
    let i = kg(t).map((r) => {
      if (r instanceof K) {
        let o = {
          ...r._zod.def.shape,
          _id: ho(e),
          _creationTime: w.number()
        };
        return W(r, { ...r._zod.def, shape: o });
      }
      return r;
    });
    return zg(i);
  }
  if (t instanceof K) {
    let n = { ...t._zod.def.shape, _id: ho(e), _creationTime: w.number() };
    return W(t, { ...t._zod.def, shape: n });
  }
  return t;
}
s(s$, "addSystemFields");
function c$(e) {
  return e instanceof V ? e : new V({ type: "optional", innerType: e });
}
s(c$, "ensureOptional");
function u$(e) {
  let t = {};
  for (let [n, i] of Object.entries(e))
    t[n] = c$(i);
  return t;
}
s(u$, "createPartialShape");
function rg(e, t) {
  return w.object({
    _id: ho(e),
    _creationTime: w.optional(w.number()),
    ...u$(t)
  });
}
s(rg, "createUpdateObjectSchema");
function l$(e, t) {
  if (wg(t)) {
    let n = kg(t).map((i) => i instanceof K ? rg(e, i._zod.def.shape) : i);
    return zg(n);
  }
  return t instanceof K ? rg(e, t._zod.def.shape) : t;
}
s(l$, "createSchemaUpdateSchema");
var ng = /* @__PURE__ */ Symbol.for("zodvex.zxDate");
function d$(e) {
  e[ng] = !0;
  let t = e._zod?.def;
  return t && (t[ng] = !0), e;
}
s(d$, "brandZxDate");
function f$() {
  return d$(
    dg(
      w.number(),
      // Wire: timestamp
      w.custom((e) => e instanceof Date, {
        message: "Expected Date instance"
      }),
      {
        decode: /* @__PURE__ */ s((e) => new Date(e), "decode"),
        encode: /* @__PURE__ */ s((e) => e.getTime(), "encode")
      }
    )
  );
}
s(f$, "date");
function p$(e, t, n, i) {
  let r = dg(e, t, n);
  return i?.brand && Xb(r, i.brand), r;
}
s(p$, "codec");
function yo(e) {
  let t = /* @__PURE__ */ Symbol.for(`zodvex.zx.cache.${e}`), n = globalThis, i = n[t];
  if (i) return i;
  let r = /* @__PURE__ */ new WeakMap();
  return n[t] = r, r;
}
s(yo, "sharedWeakMap");
var ig = yo("base"), og = yo("doc"), ag = yo("update"), sg = yo("docArray");
function Ld(e) {
  let t = e.schema;
  return t instanceof k ? t : e.fields;
}
s(Ld, "slimCacheKey");
function Md(e) {
  let t = e.schema;
  if (t?.base instanceof k) return t.base;
  if (t instanceof k) return t;
  let n = ig.get(e.fields);
  if (n) return n;
  if (Object.keys(e.fields).length === 0)
    throw new Error(`[zodvex] Cannot derive base schema for model '${e.name}'`);
  let i = w.object(e.fields);
  return ig.set(e.fields, i), i;
}
s(Md, "base");
function Ig(e) {
  let t = e.schema;
  if (t?.doc instanceof k) return t.doc;
  let n = Ld(e), i = og.get(n);
  if (i) return i;
  let r = s$(e.name, Md(e));
  return og.set(n, r), r;
}
s(Ig, "doc");
function m$(e) {
  let t = e.schema;
  if (t?.update instanceof k) return t.update;
  let n = Ld(e), i = ag.get(n);
  if (i) return i;
  let r = l$(e.name, Md(e));
  return ag.set(n, r), r;
}
s(m$, "update");
function g$(e) {
  let t = e.schema;
  if (t?.docArray instanceof k) return t.docArray;
  let n = Ld(e), i = sg.get(n);
  if (i) return i;
  let r = w.array(Ig(e));
  return sg.set(n, r), r;
}
s(g$, "docArray");
function Sg(e) {
  return new be({ type: "nullable", innerType: e });
}
s(Sg, "nullable");
function fo(e) {
  return new V({ type: "optional", innerType: e });
}
s(fo, "optional");
function Zd(e) {
  return fo(Sg(e));
}
s(Zd, "nullableOptional2");
function h$() {
  return w.object({
    numItems: w.number(),
    cursor: Sg(w.string()),
    endCursor: Zd(w.string()),
    id: fo(w.number()),
    maximumRowsRead: fo(w.number()),
    maximumBytesRead: fo(w.number())
  });
}
s(h$, "paginationOpts");
function v$(e) {
  return w.object({
    page: w.array(e),
    isDone: w.boolean(),
    continueCursor: w.string(),
    splitCursor: Zd(w.string()),
    pageStatus: Zd(w.enum(["SplitRecommended", "SplitRequired"]))
  });
}
s(v$, "paginationResult");
var Ad = {
  /**
   * Date ↔ timestamp codec
   * @see {@link date}
   */
  date: f$,
  /**
   * Convex ID validator
   * @see {@link id}
   */
  id: ho,
  /**
   * Custom codec builder
   * @see {@link codec}
   */
  codec: p$,
  /**
   * Pagination options schema matching Convex's PaginationOptions type
   * @see {@link paginationOpts}
   */
  paginationOpts: h$,
  /**
   * Paginated result schema wrapping any item schema in Convex's PaginationResult shape
   * @see {@link paginationResult}
   */
  paginationResult: v$,
  /**
   * Base schema for a model (user fields only; no system fields).
   * For object models reconstructs from fields; for union models returns the
   * user-supplied union. Cached per-model.
   * @see {@link base}
   */
  base: Md,
  /**
   * Doc schema: model fields + _id + _creationTime
   * @see {@link doc}
   */
  doc: Ig,
  /**
   * Update schema: _id required, all other fields optional
   * @see {@link update}
   */
  update: m$,
  /**
   * Doc array schema: z.array(doc(model))
   * @see {@link docArray}
   */
  docArray: g$
};
function y$(e) {
  return bg(e)?.type === "model";
}
s(y$, "isZodModelEntry");
function jg(e) {
  let t = bg(e);
  if (!t || t.type !== "model")
    throw new Error(`Model '${e.name}' is missing zodvex model metadata.`);
  return t;
}
s(jg, "getZodModelMeta");
function b$(e) {
  let t = jg(e), i = t.definitionSource === "schema" || t.definitionSource == null && Object.keys(e.fields).length === 0 ? Ye(ug(Ad.base(e))) : Ye(mo(e.fields));
  for (let [r, o] of Object.entries(e.indexes)) {
    let a = o.filter((c) => c !== "_creationTime");
    i = i.index(r, a);
  }
  for (let [r, o] of Object.entries(e.searchIndexes))
    i = i.searchIndex(r, o);
  for (let [r, o] of Object.entries(e.vectorIndexes))
    i = i.vectorIndex(r, o);
  return i;
}
s(b$, "tableFromModel");
function Og(e) {
  let t = {}, n = {};
  for (let [o, a] of Object.entries(e))
    if (y$(a)) {
      if (a.name !== o)
        throw new Error(
          `Model name '${a.name}' does not match key '${o}'. The model name must match the key in the schema definition.`
        );
      t[o] = b$(a);
      let c = jg(a);
      c.schemas ? n[o] = {
        doc: c.schemas.doc,
        insert: c.schemas.insert
      } : n[o] = {
        doc: Ad.doc(a),
        insert: Ad.base(a)
      };
    } else
      t[o] = a.table, n[o] = {
        doc: a.schema.doc,
        insert: a.schema.insert
      };
  let i = In(t);
  return Object.assign(i, { __zodTableMap: n });
}
s(Og, "defineZodSchema");

// graphProbe.ts
var x$ = { query: Mo, mutation: Fo, action: Jo, internalQuery: Bo, internalMutation: Lo, internalAction: Vo }, _$ = { kind: "full", schemaHelpers: !1, server: x$, s: { number: Vr, string: lt, boolean: qr, optional: ft, nullable: pt, object: eo, array: gt, union: sr, date: Yi, codec: oo, instanceof: ao, parse: Fr, encode: Lr }, defineZodModel: Am, defineZodSchema: Og, initZodvex: _g }, w$ = jf(_$), k$ = { count: 0, width: 32, profile: "codec-rich", entries: 0 }, Bd = w$(k$), OO = $$({ args: {}, returns: g.object({ checksum: g.number(), output: g.object({ seq: g.number(), at: g.number(), secret: g.string(), payload: g.string() }), manifest: g.any(), nonce: g.string() }), handler: /* @__PURE__ */ s(() => {
  let e = Bd.operation();
  return globalThis.gc(), globalThis.gc(), { checksum: Bd.checksum(), output: e, manifest: Bd.manifest, nonce: "2818029d-0301-4129-bdde-759f9476cdb1" };
}, "handler") });
export {
  OO as default
};
