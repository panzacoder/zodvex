var Iu = Object.defineProperty;
var a = (e, t) => Iu(e, "name", { value: t, configurable: !0 });
var Ce = (e, t) => {
  for (var n in t)
    Iu(e, n, { get: t[n], enumerable: !0 });
};

// graphProbe.ts
import { query as sx } from "convex:/_system/repl/wrappers.js";

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/base64.js
var ye = [], se = [], mp = Uint8Array, Sn = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
for (Re = 0, Su = Sn.length; Re < Su; ++Re)
  ye[Re] = Sn[Re], se[Sn.charCodeAt(Re)] = Re;
var Re, Su;
se[45] = 62;
se[95] = 63;
function gp(e) {
  var t = e.length;
  if (t % 4 > 0)
    throw new Error("Invalid string. Length must be a multiple of 4");
  var n = e.indexOf("=");
  n === -1 && (n = t);
  var o = n === t ? 0 : 4 - n % 4;
  return [n, o];
}
a(gp, "getLens");
function hp(e, t, n) {
  return (t + n) * 3 / 4 - n;
}
a(hp, "_byteLength");
function xt(e) {
  var t, n = gp(e), o = n[0], r = n[1], i = new mp(hp(e, o, r)), s = 0, c = r > 0 ? o - 4 : o, u;
  for (u = 0; u < c; u += 4)
    t = se[e.charCodeAt(u)] << 18 | se[e.charCodeAt(u + 1)] << 12 | se[e.charCodeAt(u + 2)] << 6 | se[e.charCodeAt(u + 3)], i[s++] = t >> 16 & 255, i[s++] = t >> 8 & 255, i[s++] = t & 255;
  return r === 2 && (t = se[e.charCodeAt(u)] << 2 | se[e.charCodeAt(u + 1)] >> 4, i[s++] = t & 255), r === 1 && (t = se[e.charCodeAt(u)] << 10 | se[e.charCodeAt(u + 1)] << 4 | se[e.charCodeAt(u + 2)] >> 2, i[s++] = t >> 8 & 255, i[s++] = t & 255), i;
}
a(xt, "toByteArray");
function vp(e) {
  return ye[e >> 18 & 63] + ye[e >> 12 & 63] + ye[e >> 6 & 63] + ye[e & 63];
}
a(vp, "tripletToBase64");
function yp(e, t, n) {
  for (var o, r = [], i = t; i < n; i += 3)
    o = (e[i] << 16 & 16711680) + (e[i + 1] << 8 & 65280) + (e[i + 2] & 255), r.push(vp(o));
  return r.join("");
}
a(yp, "encodeChunk");
function $t(e) {
  for (var t, n = e.length, o = n % 3, r = [], i = 16383, s = 0, c = n - o; s < c; s += i)
    r.push(
      yp(
        e,
        s,
        s + i > c ? c : s + i
      )
    );
  return o === 1 ? (t = e[n - 1], r.push(ye[t >> 2] + ye[t << 4 & 63] + "==")) : o === 2 && (t = (e[n - 2] << 8) + e[n - 1], r.push(
    ye[t >> 10] + ye[t >> 4 & 63] + ye[t << 2 & 63] + "="
  )), r.join("");
}
a($t, "fromByteArray");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/common/index.js
function we(e) {
  if (e === void 0)
    return {};
  if (!or(e))
    throw new Error(
      `The arguments to a Convex function must be an object. Received: ${e}`
    );
  return e;
}
a(we, "parseArgs");
function or(e) {
  let t = typeof e == "object", n = Object.getPrototypeOf(e), o = n === null || n === Object.prototype || // Objects generated from other contexts (e.g. across Node.js `vm` modules) will not satisfy the previous
  // conditions but are still simple objects.
  n?.constructor?.name === "Object";
  return t && o;
}
a(or, "isSimpleObject");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/value.js
var Pu = !0, Xe = BigInt("-9223372036854775808"), Pn = BigInt("9223372036854775807"), On = BigInt("0"), bp = BigInt("8"), xp = BigInt("256");
function Uu(e) {
  return Number.isNaN(e) || !Number.isFinite(e) || Object.is(e, -0);
}
a(Uu, "isSpecial");
function $p(e) {
  e < On && (e -= Xe + Xe);
  let t = e.toString(16);
  t.length % 2 === 1 && (t = "0" + t);
  let n = new Uint8Array(new ArrayBuffer(8)), o = 0;
  for (let r of t.match(/.{2}/g).reverse())
    n.set([parseInt(r, 16)], o++), e >>= bp;
  return $t(n);
}
a($p, "slowBigIntToBase64");
function _p(e) {
  let t = xt(e);
  if (t.byteLength !== 8)
    throw new Error(
      `Received ${t.byteLength} bytes, expected 8 for $integer`
    );
  let n = On, o = On;
  for (let r of t)
    n += BigInt(r) * xp ** o, o++;
  return n > Pn && (n += Xe + Xe), n;
}
a(_p, "slowBase64ToBigInt");
function wp(e) {
  if (e < Xe || Pn < e)
    throw new Error(
      `BigInt ${e} does not fit into a 64-bit signed integer.`
    );
  let t = new ArrayBuffer(8);
  return new DataView(t).setBigInt64(0, e, !0), $t(new Uint8Array(t));
}
a(wp, "modernBigIntToBase64");
function kp(e) {
  let t = xt(e);
  if (t.byteLength !== 8)
    throw new Error(
      `Received ${t.byteLength} bytes, expected 8 for $integer`
    );
  return new DataView(t.buffer).getBigInt64(0, !0);
}
a(kp, "modernBase64ToBigInt");
var zp = DataView.prototype.setBigInt64 ? wp : $p, Ip = DataView.prototype.getBigInt64 ? kp : _p, Ou = 1024;
function Tn(e) {
  if (e.length > Ou)
    throw new Error(
      `Field name ${e} exceeds maximum field name length ${Ou}.`
    );
  if (e.startsWith("$"))
    throw new Error(`Field name ${e} starts with a '$', which is reserved.`);
  for (let t = 0; t < e.length; t += 1) {
    let n = e.charCodeAt(t);
    if (n < 32 || n >= 127)
      throw new Error(
        `Field name ${e} has invalid character '${e[t]}': Field names can only contain non-control ASCII characters`
      );
  }
}
a(Tn, "validateObjectField");
function M(e) {
  if (e === null || typeof e == "boolean" || typeof e == "number" || typeof e == "string")
    return e;
  if (Array.isArray(e))
    return e.map((o) => M(o));
  if (typeof e != "object")
    throw new Error(`Unexpected type of ${e}`);
  let t = Object.entries(e);
  if (t.length === 1) {
    let o = t[0][0];
    if (o === "$bytes") {
      if (typeof e.$bytes != "string")
        throw new Error(`Malformed $bytes field on ${e}`);
      return xt(e.$bytes).buffer;
    }
    if (o === "$integer") {
      if (typeof e.$integer != "string")
        throw new Error(`Malformed $integer field on ${e}`);
      return Ip(e.$integer);
    }
    if (o === "$float") {
      if (typeof e.$float != "string")
        throw new Error(`Malformed $float field on ${e}`);
      let r = xt(e.$float);
      if (r.byteLength !== 8)
        throw new Error(
          `Received ${r.byteLength} bytes, expected 8 for $float`
        );
      let s = new DataView(r.buffer).getFloat64(0, Pu);
      if (!Uu(s))
        throw new Error(`Float ${s} should be encoded as a number`);
      return s;
    }
    if (o === "$set")
      throw new Error(
        "Received a Set which is no longer supported as a Convex type."
      );
    if (o === "$map")
      throw new Error(
        "Received a Map which is no longer supported as a Convex type."
      );
  }
  let n = {};
  for (let [o, r] of Object.entries(e))
    Tn(o), n[o] = M(r);
  return n;
}
a(M, "jsonToConvex");
var Tu = 16384;
function Fe(e) {
  let t = JSON.stringify(e, (n, o) => o === void 0 ? "undefined" : typeof o == "bigint" ? `${o.toString()}n` : o);
  if (t.length > Tu) {
    let n = "[...truncated]", o = Tu - n.length, r = t.codePointAt(o - 1);
    return r !== void 0 && r > 65535 && (o -= 1), t.substring(0, o) + n;
  }
  return t;
}
a(Fe, "stringifyValueForError");
function _t(e, t, n, o) {
  if (e === void 0) {
    let s = n && ` (present at path ${n} in original object ${Fe(
      t
    )})`;
    throw new Error(
      `undefined is not a valid Convex value${s}. To learn about Convex's supported types, see https://docs.convex.dev/using/types.`
    );
  }
  if (e === null)
    return e;
  if (typeof e == "bigint") {
    if (e < Xe || Pn < e)
      throw new Error(
        `BigInt ${e} does not fit into a 64-bit signed integer.`
      );
    return { $integer: zp(e) };
  }
  if (typeof e == "number")
    if (Uu(e)) {
      let s = new ArrayBuffer(8);
      return new DataView(s).setFloat64(0, e, Pu), { $float: $t(new Uint8Array(s)) };
    } else
      return e;
  if (typeof e == "boolean" || typeof e == "string")
    return e;
  if (e instanceof ArrayBuffer)
    return { $bytes: $t(new Uint8Array(e)) };
  if (Array.isArray(e))
    return e.map(
      (s, c) => _t(s, t, n + `[${c}]`, !1)
    );
  if (e instanceof Set)
    throw new Error(
      jn(n, "Set", [...e], t)
    );
  if (e instanceof Map)
    throw new Error(
      jn(n, "Map", [...e], t)
    );
  if (!or(e)) {
    let s = e?.constructor?.name, c = s ? `${s} ` : "";
    throw new Error(
      jn(n, c, e, t)
    );
  }
  let r = {}, i = Object.entries(e);
  i.sort(([s, c], [u, l]) => s === u ? 0 : s < u ? -1 : 1);
  for (let [s, c] of i)
    c !== void 0 ? (Tn(s), r[s] = _t(c, t, n + `.${s}`, !1)) : o && (Tn(s), r[s] = Du(
      c,
      t,
      n + `.${s}`
    ));
  return r;
}
a(_t, "convexToJsonInternal");
function jn(e, t, n, o) {
  return e ? `${t}${Fe(
    n
  )} is not a supported Convex type (present at path ${e} in original object ${Fe(
    o
  )}). To learn about Convex's supported types, see https://docs.convex.dev/using/types.` : `${t}${Fe(
    n
  )} is not a supported Convex type.`;
}
a(jn, "errorMessageForUnsupportedType");
function Du(e, t, n) {
  if (e === void 0)
    return { $undefined: null };
  if (t === void 0)
    throw new Error(
      `Programming error. Current value is ${Fe(
        e
      )} but original value is undefined`
    );
  return _t(e, t, n, !1);
}
a(Du, "convexOrUndefinedToJsonInternal");
function C(e) {
  return _t(e, e, "", !1);
}
a(C, "convexToJson");
function ce(e) {
  return Du(e, e, "");
}
a(ce, "convexOrUndefinedToJson");
function Eu(e) {
  return _t(e, e, "", !0);
}
a(Eu, "patchValueToJson");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/validators.js
var Sp = Object.defineProperty, jp = /* @__PURE__ */ a((e, t, n) => t in e ? Sp(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), R = /* @__PURE__ */ a((e, t, n) => jp(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), Op = "https://docs.convex.dev/error#undefined-validator";
function wt(e, t) {
  let n = t !== void 0 ? ` for field "${t}"` : "";
  throw new Error(
    `A validator is undefined${n} in ${e}. This is often caused by circular imports. See ${Op} for details.`
  );
}
a(wt, "throwUndefinedValidatorError");
var H = class {
  static {
    a(this, "BaseValidator");
  }
  constructor({ isOptional: t }) {
    R(this, "type"), R(this, "fieldPaths"), R(this, "isOptional"), R(this, "isConvexValidator"), this.isOptional = t, this.isConvexValidator = !0;
  }
}, ar = class e extends H {
  static {
    a(this, "VId");
  }
  /**
   * Usually you'd use `v.id(tableName)` instead.
   */
  constructor({
    isOptional: t,
    tableName: n
  }) {
    if (super({ isOptional: t }), R(this, "tableName"), R(this, "kind", "id"), typeof n != "string")
      throw new Error("v.id(tableName) requires a string");
    this.tableName = n;
  }
  /** @internal */
  get json() {
    return { type: "id", tableName: this.tableName };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      tableName: this.tableName
    });
  }
}, kt = class e extends H {
  static {
    a(this, "VFloat64");
  }
  constructor() {
    super(...arguments), R(this, "kind", "float64");
  }
  /** @internal */
  get json() {
    return { type: "number" };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, zt = class e extends H {
  static {
    a(this, "VInt64");
  }
  constructor() {
    super(...arguments), R(this, "kind", "int64");
  }
  /** @internal */
  get json() {
    return { type: "bigint" };
  }
  /** @internal */
  asOptional() {
    return new e({ isOptional: "optional" });
  }
}, sr = class e extends H {
  static {
    a(this, "VBoolean");
  }
  constructor() {
    super(...arguments), R(this, "kind", "boolean");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, cr = class e extends H {
  static {
    a(this, "VBytes");
  }
  constructor() {
    super(...arguments), R(this, "kind", "bytes");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({ isOptional: "optional" });
  }
}, ur = class e extends H {
  static {
    a(this, "VString");
  }
  constructor() {
    super(...arguments), R(this, "kind", "string");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, lr = class e extends H {
  static {
    a(this, "VNull");
  }
  constructor() {
    super(...arguments), R(this, "kind", "null");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({ isOptional: "optional" });
  }
}, dr = class e extends H {
  static {
    a(this, "VAny");
  }
  constructor() {
    super(...arguments), R(this, "kind", "any");
  }
  /** @internal */
  get json() {
    return {
      type: this.kind
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, fr = class e extends H {
  static {
    a(this, "VObject");
  }
  /**
   * Usually you'd use `v.object({ ... })` instead.
   */
  constructor({
    isOptional: t,
    fields: n
  }) {
    super({ isOptional: t }), R(this, "fields"), R(this, "kind", "object"), globalThis.Object.entries(n).forEach(([o, r]) => {
      if (r === void 0 && wt("v.object()", o), !r.isConvexValidator)
        throw new Error("v.object() entries must be validators");
    }), this.fields = n;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: globalThis.Object.fromEntries(
        globalThis.Object.entries(this.fields).map(([t, n]) => [
          t,
          {
            fieldType: n.json,
            optional: n.isOptional === "optional"
          }
        ])
      )
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      fields: this.fields
    });
  }
  /**
   * Create a new VObject with the specified fields omitted.
   * @param fields The field names to omit from this VObject.
   */
  omit(...t) {
    let n = { ...this.fields };
    for (let o of t)
      delete n[o];
    return new e({
      isOptional: this.isOptional,
      fields: n
    });
  }
  /**
   * Create a new VObject with only the specified fields.
   * @param fields The field names to pick from this VObject.
   */
  pick(...t) {
    let n = {};
    for (let o of t)
      n[o] = this.fields[o];
    return new e({
      isOptional: this.isOptional,
      fields: n
    });
  }
  /**
   * Create a new VObject with all fields marked as optional.
   */
  partial() {
    let t = {};
    for (let [n, o] of globalThis.Object.entries(this.fields))
      t[n] = o.asOptional();
    return new e({
      isOptional: this.isOptional,
      fields: t
    });
  }
  /**
   * Create a new VObject with additional fields merged in.
   * @param fields An object with additional validators to merge into this VObject.
   */
  extend(t) {
    return new e({
      isOptional: this.isOptional,
      fields: { ...this.fields, ...t }
    });
  }
}, pr = class e extends H {
  static {
    a(this, "VLiteral");
  }
  /**
   * Usually you'd use `v.literal(value)` instead.
   */
  constructor({ isOptional: t, value: n }) {
    if (super({ isOptional: t }), R(this, "value"), R(this, "kind", "literal"), typeof n != "string" && typeof n != "boolean" && typeof n != "number" && typeof n != "bigint")
      throw new Error("v.literal(value) must be a string, number, or boolean");
    this.value = n;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: C(this.value)
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      value: this.value
    });
  }
}, mr = class e extends H {
  static {
    a(this, "VArray");
  }
  /**
   * Usually you'd use `v.array(element)` instead.
   */
  constructor({
    isOptional: t,
    element: n
  }) {
    super({ isOptional: t }), R(this, "element"), R(this, "kind", "array"), n === void 0 && wt("v.array()"), this.element = n;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: this.element.json
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      element: this.element
    });
  }
}, gr = class e extends H {
  static {
    a(this, "VRecord");
  }
  /**
   * Usually you'd use `v.record(key, value)` instead.
   */
  constructor({
    isOptional: t,
    key: n,
    value: o
  }) {
    if (super({ isOptional: t }), R(this, "key"), R(this, "value"), R(this, "kind", "record"), n === void 0 && wt("v.record()", "key"), o === void 0 && wt("v.record()", "value"), n.isOptional === "optional")
      throw new Error("Record validator cannot have optional keys");
    if (o.isOptional === "optional")
      throw new Error("Record validator cannot have optional values");
    if (!n.isConvexValidator || !o.isConvexValidator)
      throw new Error("Key and value of v.record() but be validators");
    this.key = n, this.value = o;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      // This cast is needed because TypeScript thinks the key type is too wide
      keys: this.key.json,
      values: {
        fieldType: this.value.json,
        optional: !1
      }
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      key: this.key,
      value: this.value
    });
  }
}, hr = class e extends H {
  static {
    a(this, "VUnion");
  }
  /**
   * Usually you'd use `v.union(...members)` instead.
   */
  constructor({ isOptional: t, members: n }) {
    super({ isOptional: t }), R(this, "members"), R(this, "kind", "union"), n.forEach((o, r) => {
      if (o === void 0 && wt("v.union()", `member at index ${r}`), !o.isConvexValidator)
        throw new Error("All members of v.union() must be validators");
    }), this.members = n;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: this.members.map((t) => t.json)
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      members: this.members
    });
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/validator.js
function Un(e) {
  return !!e.isConvexValidator;
}
a(Un, "isValidator");
function It(e) {
  return Un(e) ? e : m.object(e);
}
a(It, "asObjectValidator");
var m = {
  /**
   * Validates that the value is a document ID for the given table.
   *
   * IDs are strings at runtime but are typed as `Id<"tableName">` in
   * TypeScript for type safety.
   *
   * @example
   * ```typescript
   * args: { userId: v.id("users") }
   * ```
   *
   * @param tableName The name of the table.
   */
  id: /* @__PURE__ */ a((e) => new ar({
    isOptional: "required",
    tableName: e
  }), "id"),
  /**
   * Validates that the value is `null`.
   *
   * Use `returns: v.null()` for functions that don't return a meaningful value.
   * JavaScript `undefined` is not a valid Convex value, it is automatically
   * converted to `null`.
   */
  null: /* @__PURE__ */ a(() => new lr({ isOptional: "required" }), "null"),
  /**
   * Validates that the value is a JavaScript `number` (Convex Float64).
   *
   * Supports all IEEE-754 double-precision floating point numbers including
   * NaN and Infinity.
   *
   * Alias for `v.float64()`.
   */
  number: /* @__PURE__ */ a(() => new kt({ isOptional: "required" }), "number"),
  /**
   * Validates that the value is a JavaScript `number` (Convex Float64).
   *
   * Supports all IEEE-754 double-precision floating point numbers.
   */
  float64: /* @__PURE__ */ a(() => new kt({ isOptional: "required" }), "float64"),
  /**
   * @deprecated Use `v.int64()` instead.
   */
  bigint: /* @__PURE__ */ a(() => new zt({ isOptional: "required" }), "bigint"),
  /**
   * Validates that the value is a JavaScript `bigint` (Convex Int64).
   *
   * Supports BigInts between -2^63 and 2^63-1.
   *
   * @example
   * ```typescript
   * args: { timestamp: v.int64() }
   * // Usage: createDoc({ timestamp: 1234567890n })
   * ```
   */
  int64: /* @__PURE__ */ a(() => new zt({ isOptional: "required" }), "int64"),
  /**
   * Validates that the value is a `boolean`.
   */
  boolean: /* @__PURE__ */ a(() => new sr({ isOptional: "required" }), "boolean"),
  /**
   * Validates that the value is a `string`.
   *
   * Strings are stored as UTF-8 and their storage size is calculated as their
   * UTF-8 encoded size.
   */
  string: /* @__PURE__ */ a(() => new ur({ isOptional: "required" }), "string"),
  /**
   * Validates that the value is an `ArrayBuffer` (Convex Bytes).
   *
   * Use for binary data.
   */
  bytes: /* @__PURE__ */ a(() => new cr({ isOptional: "required" }), "bytes"),
  /**
   * Validates that the value is exactly equal to the given literal.
   *
   * Useful for discriminated unions and enum-like patterns.
   *
   * @example
   * ```typescript
   * // Discriminated union pattern:
   * v.union(
   *   v.object({ kind: v.literal("error"), message: v.string() }),
   *   v.object({ kind: v.literal("success"), value: v.number() }),
   * )
   * ```
   *
   * @param literal The literal value to compare against.
   */
  literal: /* @__PURE__ */ a((e) => new pr({ isOptional: "required", value: e }), "literal"),
  /**
   * Validates that the value is an `Array` where every element matches the
   * given validator.
   *
   * Arrays can have at most 8192 elements.
   *
   * @example
   * ```typescript
   * args: { tags: v.array(v.string()) }
   * args: { coordinates: v.array(v.number()) }
   * args: { items: v.array(v.object({ name: v.string(), qty: v.number() })) }
   * ```
   *
   * @param element The validator for the elements of the array.
   */
  array: /* @__PURE__ */ a((e) => new mr({ isOptional: "required", element: e }), "array"),
  /**
   * Validates that the value is an `Object` with the specified properties.
   *
   * Objects can have at most 1024 entries. Field names must be non-empty and
   * must not start with `"$"` or `"_"` (`_` is reserved for system fields
   * like `_id` and `_creationTime`; `$` is reserved for Convex internal use).
   *
   * @example
   * ```typescript
   * args: {
   *   user: v.object({
   *     name: v.string(),
   *     email: v.string(),
   *     age: v.optional(v.number()),
   *   })
   * }
   * ```
   *
   * @param fields An object mapping property names to their validators.
   */
  object: /* @__PURE__ */ a((e) => new fr({ isOptional: "required", fields: e }), "object"),
  /**
   * Validates that the value is a `Record` (object with dynamic keys).
   *
   * Records are objects at runtime but allow dynamic keys, unlike `v.object()`
   * which requires known property names. Keys must be ASCII characters only,
   * non-empty, and not start with `"$"` or `"_"`.
   *
   * @example
   * ```typescript
   * // Map of user IDs to scores:
   * args: { scores: v.record(v.id("users"), v.number()) }
   *
   * // Map of string keys to string values:
   * args: { metadata: v.record(v.string(), v.string()) }
   * ```
   *
   * @param keys The validator for the keys of the record.
   * @param values The validator for the values of the record.
   */
  record: /* @__PURE__ */ a((e, t) => new gr({
    isOptional: "required",
    key: e,
    value: t
  }), "record"),
  /**
   * Validates that the value matches at least one of the given validators.
   *
   * @example
   * ```typescript
   * // Allow string or number:
   * args: { value: v.union(v.string(), v.number()) }
   *
   * // Discriminated union (recommended pattern):
   * v.union(
   *   v.object({ kind: v.literal("text"), body: v.string() }),
   *   v.object({ kind: v.literal("image"), url: v.string() }),
   * )
   *
   * // Nullable value:
   * returns: v.union(v.object({ ... }), v.null())
   * ```
   *
   * @param members The validators to match against.
   */
  union: /* @__PURE__ */ a((...e) => new hr({
    isOptional: "required",
    members: e
  }), "union"),
  /**
   * A validator that accepts any Convex value without validation.
   *
   * Prefer using specific validators when possible for better type safety
   * and runtime validation.
   */
  any: /* @__PURE__ */ a(() => new dr({ isOptional: "required" }), "any"),
  /**
   * Makes a property optional in an object validator.
   *
   * An optional property can be omitted entirely when creating a document or
   * calling a function. This is different from `v.nullable()` which requires
   * the property to be present but allows `null`.
   *
   * @example
   * ```typescript
   * v.object({
   *   name: v.string(),              // required
   *   nickname: v.optional(v.string()), // can be omitted
   * })
   *
   * // Valid: { name: "Alice" }
   * // Valid: { name: "Alice", nickname: "Ali" }
   * // Invalid: { name: "Alice", nickname: null }  - use v.nullable() for this
   * ```
   *
   * @param value The property value validator to make optional.
   */
  optional: /* @__PURE__ */ a((e) => e.asOptional(), "optional"),
  /**
   * Allows a value to be either the given type or `null`.
   *
   * This is shorthand for `v.union(value, v.null())`. Unlike `v.optional()`,
   * the property must still be present, but may be `null`.
   *
   * @example
   * ```typescript
   * v.object({
   *   name: v.string(),
   *   deletedAt: v.nullable(v.number()), // must be present, can be null
   * })
   *
   * // Valid: { name: "Alice", deletedAt: null }
   * // Valid: { name: "Alice", deletedAt: 1234567890 }
   * // Invalid: { name: "Alice" }  - deletedAt is required
   * ```
   */
  nullable: /* @__PURE__ */ a((e) => m.union(e, m.null()), "nullable")
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/errors.js
var Tp = Object.defineProperty, Pp = /* @__PURE__ */ a((e, t, n) => t in e ? Tp(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), Dn = /* @__PURE__ */ a((e, t, n) => Pp(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), Zu, Nu, Up = Symbol.for("ConvexError"), He = class extends (Nu = Error, Zu = Up, Nu) {
  static {
    a(this, "ConvexError");
  }
  constructor(t) {
    super(typeof t == "string" ? t : Fe(t)), Dn(this, "name", "ConvexError"), Dn(this, "data"), Dn(this, Zu, !0), this.data = t;
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/compare_utf8.js
var Au = /* @__PURE__ */ a(() => Array.from({ length: 4 }, () => 0), "arr"), jx = Au(), Ox = Au();

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/index.js
var W = "1.32.0";

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/syscall.js
function St(e, t) {
  if (typeof Convex > "u" || Convex.syscall === void 0)
    throw new Error(
      "The Convex database and auth objects are being used outside of a Convex backend. Did you mean to use `useQuery` or `useMutation` to call a Convex function?"
    );
  let n = Convex.syscall(e, JSON.stringify(t));
  return JSON.parse(n);
}
a(St, "performSyscall");
async function P(e, t) {
  if (typeof Convex > "u" || Convex.asyncSyscall === void 0)
    throw new Error(
      "The Convex database and auth objects are being used outside of a Convex backend. Did you mean to use `useQuery` or `useMutation` to call a Convex function?"
    );
  let n;
  try {
    n = await Convex.asyncSyscall(e, JSON.stringify(t));
  } catch (o) {
    if (o.data !== void 0) {
      let r = new He(o.message);
      throw r.data = M(o.data), r;
    }
    throw new Error(o.message);
  }
  return JSON.parse(n);
}
a(P, "performAsyncSyscall");
function vr(e, t) {
  if (typeof Convex > "u" || Convex.jsSyscall === void 0)
    throw new Error(
      "The Convex database and auth objects are being used outside of a Convex backend. Did you mean to use `useQuery` or `useMutation` to call a Convex function?"
    );
  return Convex.jsSyscall(e, t);
}
a(vr, "performJsSyscall");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/functionName.js
var jt = Symbol.for("functionName");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/components/paths.js
var Cu = Symbol.for("toReferencePath");
function Ep(e) {
  return e[Cu] ?? null;
}
a(Ep, "extractReferencePath");
function Zp(e) {
  return e.startsWith("function://");
}
a(Zp, "isFunctionHandle");
function fe(e) {
  let t;
  if (typeof e == "string")
    Zp(e) ? t = { functionHandle: e } : t = { name: e };
  else if (e[jt])
    t = { name: e[jt] };
  else {
    let n = Ep(e);
    if (!n)
      throw new Error(`${e} is not a functionReference`);
    t = { reference: n };
  }
  return t;
}
a(fe, "getFunctionAddress");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/actions_impl.js
function En(e, t, n) {
  return {
    ...fe(t),
    args: C(we(n)),
    version: W,
    requestId: e
  };
}
a(En, "syscallArgs");
function Ru(e) {
  return {
    runQuery: /* @__PURE__ */ a(async (t, n) => {
      let o = await P(
        "1.0/actions/query",
        En(e, t, n)
      );
      return M(o);
    }, "runQuery"),
    runMutation: /* @__PURE__ */ a(async (t, n) => {
      let o = await P(
        "1.0/actions/mutation",
        En(e, t, n)
      );
      return M(o);
    }, "runMutation"),
    runAction: /* @__PURE__ */ a(async (t, n) => {
      let o = await P(
        "1.0/actions/action",
        En(e, t, n)
      );
      return M(o);
    }, "runAction")
  };
}
a(Ru, "setupActionCalls");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/vector_search.js
var Np = Object.defineProperty, Ap = /* @__PURE__ */ a((e, t, n) => t in e ? Np(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), Fu = /* @__PURE__ */ a((e, t, n) => Ap(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), yr = class {
  static {
    a(this, "FilterExpression");
  }
  /**
   * @internal
   */
  constructor() {
    Fu(this, "_isExpression"), Fu(this, "_value");
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/validate.js
function T(e, t, n, o) {
  if (e === void 0)
    throw new TypeError(
      `Must provide arg ${t} \`${o}\` to \`${n}\``
    );
}
a(T, "validateArg");
function Mu(e, t, n, o) {
  if (!Number.isInteger(e) || e < 0)
    throw new TypeError(
      `Arg ${t} \`${o}\` to \`${n}\` must be a non-negative integer`
    );
}
a(Mu, "validateArgIsNonNegativeInteger");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/vector_search_impl.js
var Cp = Object.defineProperty, Rp = /* @__PURE__ */ a((e, t, n) => t in e ? Cp(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), Zn = /* @__PURE__ */ a((e, t, n) => Rp(e, typeof t != "symbol" ? t + "" : t, n), "__publicField");
function Lu(e) {
  return async (t, n, o) => {
    if (T(t, 1, "vectorSearch", "tableName"), T(n, 2, "vectorSearch", "indexName"), T(o, 3, "vectorSearch", "query"), !o.vector || !Array.isArray(o.vector) || o.vector.length === 0)
      throw Error("`vector` must be a non-empty Array in vectorSearch");
    return await new Nn(
      e,
      t + "." + n,
      o
    ).collect();
  };
}
a(Lu, "setupActionVectorSearch");
var Nn = class {
  static {
    a(this, "VectorQueryImpl");
  }
  constructor(t, n, o) {
    Zn(this, "requestId"), Zn(this, "state"), this.requestId = t;
    let r = o.filter ? br(o.filter(Fp)) : null;
    this.state = {
      type: "preparing",
      query: {
        indexName: n,
        limit: o.limit,
        vector: o.vector,
        expressions: r
      }
    };
  }
  async collect() {
    if (this.state.type === "consumed")
      throw new Error("This query is closed and can't emit any more values.");
    let t = this.state.query;
    this.state = { type: "consumed" };
    let { results: n } = await P("1.0/actions/vectorSearch", {
      requestId: this.requestId,
      version: W,
      query: t
    });
    return n;
  }
}, Qe = class extends yr {
  static {
    a(this, "ExpressionImpl");
  }
  constructor(t) {
    super(), Zn(this, "inner"), this.inner = t;
  }
  serialize() {
    return this.inner;
  }
};
function br(e) {
  return e instanceof Qe ? e.serialize() : { $literal: ce(e) };
}
a(br, "serializeExpression");
var Fp = {
  //  Comparisons  /////////////////////////////////////////////////////////////
  eq(e, t) {
    if (typeof e != "string")
      throw new Error("The first argument to `q.eq` must be a field name.");
    return new Qe({
      $eq: [
        br(new Qe({ $field: e })),
        br(t)
      ]
    });
  },
  //  Logic  ///////////////////////////////////////////////////////////////////
  or(...e) {
    return new Qe({ $or: e.map(br) });
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/authentication_impl.js
function xr(e) {
  return {
    getUserIdentity: /* @__PURE__ */ a(async () => await P("1.0/getUserIdentity", {
      requestId: e
    }), "getUserIdentity")
  };
}
a(xr, "setupAuth");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/filter_builder.js
var Mp = Object.defineProperty, Lp = /* @__PURE__ */ a((e, t, n) => t in e ? Mp(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), Bu = /* @__PURE__ */ a((e, t, n) => Lp(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), $r = class {
  static {
    a(this, "Expression");
  }
  /**
   * @internal
   */
  constructor() {
    Bu(this, "_isExpression"), Bu(this, "_value");
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/filter_builder_impl.js
var Bp = Object.defineProperty, Vp = /* @__PURE__ */ a((e, t, n) => t in e ? Bp(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), qp = /* @__PURE__ */ a((e, t, n) => Vp(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), G = class extends $r {
  static {
    a(this, "ExpressionImpl");
  }
  constructor(t) {
    super(), qp(this, "inner"), this.inner = t;
  }
  serialize() {
    return this.inner;
  }
};
function D(e) {
  return e instanceof G ? e.serialize() : { $literal: ce(e) };
}
a(D, "serializeExpression");
var Vu = {
  //  Comparisons  /////////////////////////////////////////////////////////////
  eq(e, t) {
    return new G({
      $eq: [D(e), D(t)]
    });
  },
  neq(e, t) {
    return new G({
      $neq: [D(e), D(t)]
    });
  },
  lt(e, t) {
    return new G({
      $lt: [D(e), D(t)]
    });
  },
  lte(e, t) {
    return new G({
      $lte: [D(e), D(t)]
    });
  },
  gt(e, t) {
    return new G({
      $gt: [D(e), D(t)]
    });
  },
  gte(e, t) {
    return new G({
      $gte: [D(e), D(t)]
    });
  },
  //  Arithmetic  //////////////////////////////////////////////////////////////
  add(e, t) {
    return new G({
      $add: [D(e), D(t)]
    });
  },
  sub(e, t) {
    return new G({
      $sub: [D(e), D(t)]
    });
  },
  mul(e, t) {
    return new G({
      $mul: [D(e), D(t)]
    });
  },
  div(e, t) {
    return new G({
      $div: [D(e), D(t)]
    });
  },
  mod(e, t) {
    return new G({
      $mod: [D(e), D(t)]
    });
  },
  neg(e) {
    return new G({ $neg: D(e) });
  },
  //  Logic  ///////////////////////////////////////////////////////////////////
  and(...e) {
    return new G({ $and: e.map(D) });
  },
  or(...e) {
    return new G({ $or: e.map(D) });
  },
  not(e) {
    return new G({ $not: D(e) });
  },
  //  Other  ///////////////////////////////////////////////////////////////////
  field(e) {
    return new G({ $field: e });
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/index_range_builder.js
var Jp = Object.defineProperty, Wp = /* @__PURE__ */ a((e, t, n) => t in e ? Jp(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), Kp = /* @__PURE__ */ a((e, t, n) => Wp(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), _r = class {
  static {
    a(this, "IndexRange");
  }
  /**
   * @internal
   */
  constructor() {
    Kp(this, "_isIndexRange");
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/index_range_builder_impl.js
var Gp = Object.defineProperty, Xp = /* @__PURE__ */ a((e, t, n) => t in e ? Gp(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), qu = /* @__PURE__ */ a((e, t, n) => Xp(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), wr = class e extends _r {
  static {
    a(this, "IndexRangeBuilderImpl");
  }
  constructor(t) {
    super(), qu(this, "rangeExpressions"), qu(this, "isConsumed"), this.rangeExpressions = t, this.isConsumed = !1;
  }
  static new() {
    return new e([]);
  }
  consume() {
    if (this.isConsumed)
      throw new Error(
        "IndexRangeBuilder has already been used! Chain your method calls like `q => q.eq(...).eq(...)`. See https://docs.convex.dev/using/indexes"
      );
    this.isConsumed = !0;
  }
  eq(t, n) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Eq",
        fieldPath: t,
        value: ce(n)
      })
    );
  }
  gt(t, n) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Gt",
        fieldPath: t,
        value: ce(n)
      })
    );
  }
  gte(t, n) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Gte",
        fieldPath: t,
        value: ce(n)
      })
    );
  }
  lt(t, n) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Lt",
        fieldPath: t,
        value: ce(n)
      })
    );
  }
  lte(t, n) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Lte",
        fieldPath: t,
        value: ce(n)
      })
    );
  }
  export() {
    return this.consume(), this.rangeExpressions;
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/search_filter_builder.js
var Hp = Object.defineProperty, Qp = /* @__PURE__ */ a((e, t, n) => t in e ? Hp(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), Yp = /* @__PURE__ */ a((e, t, n) => Qp(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), kr = class {
  static {
    a(this, "SearchFilter");
  }
  /**
   * @internal
   */
  constructor() {
    Yp(this, "_isSearchFilter");
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/search_filter_builder_impl.js
var em = Object.defineProperty, tm = /* @__PURE__ */ a((e, t, n) => t in e ? em(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), Ju = /* @__PURE__ */ a((e, t, n) => tm(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), zr = class e extends kr {
  static {
    a(this, "SearchFilterBuilderImpl");
  }
  constructor(t) {
    super(), Ju(this, "filters"), Ju(this, "isConsumed"), this.filters = t, this.isConsumed = !1;
  }
  static new() {
    return new e([]);
  }
  consume() {
    if (this.isConsumed)
      throw new Error(
        "SearchFilterBuilder has already been used! Chain your method calls like `q => q.search(...).eq(...)`."
      );
    this.isConsumed = !0;
  }
  search(t, n) {
    return T(t, 1, "search", "fieldName"), T(n, 2, "search", "query"), this.consume(), new e(
      this.filters.concat({
        type: "Search",
        fieldPath: t,
        value: n
      })
    );
  }
  eq(t, n) {
    return T(t, 1, "eq", "fieldName"), arguments.length !== 2 && T(n, 2, "search", "value"), this.consume(), new e(
      this.filters.concat({
        type: "Eq",
        fieldPath: t,
        value: ce(n)
      })
    );
  }
  export() {
    return this.consume(), this.filters;
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/query_impl.js
var rm = Object.defineProperty, nm = /* @__PURE__ */ a((e, t, n) => t in e ? rm(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), An = /* @__PURE__ */ a((e, t, n) => nm(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), Wu = 256, Ye = class {
  static {
    a(this, "QueryInitializerImpl");
  }
  constructor(t) {
    An(this, "tableName"), this.tableName = t;
  }
  withIndex(t, n) {
    T(t, 1, "withIndex", "indexName");
    let o = wr.new();
    return n !== void 0 && (o = n(o)), new Me({
      source: {
        type: "IndexRange",
        indexName: this.tableName + "." + t,
        range: o.export(),
        order: null
      },
      operators: []
    });
  }
  withSearchIndex(t, n) {
    T(t, 1, "withSearchIndex", "indexName"), T(n, 2, "withSearchIndex", "searchFilter");
    let o = zr.new();
    return new Me({
      source: {
        type: "Search",
        indexName: this.tableName + "." + t,
        filters: n(o).export()
      },
      operators: []
    });
  }
  fullTableScan() {
    return new Me({
      source: {
        type: "FullTableScan",
        tableName: this.tableName,
        order: null
      },
      operators: []
    });
  }
  order(t) {
    return this.fullTableScan().order(t);
  }
  // This is internal API and should not be exposed to developers yet.
  async count() {
    let t = await P("1.0/count", {
      table: this.tableName
    });
    return M(t);
  }
  filter(t) {
    return this.fullTableScan().filter(t);
  }
  limit(t) {
    return this.fullTableScan().limit(t);
  }
  collect() {
    return this.fullTableScan().collect();
  }
  take(t) {
    return this.fullTableScan().take(t);
  }
  paginate(t) {
    return this.fullTableScan().paginate(t);
  }
  first() {
    return this.fullTableScan().first();
  }
  unique() {
    return this.fullTableScan().unique();
  }
  [Symbol.asyncIterator]() {
    return this.fullTableScan()[Symbol.asyncIterator]();
  }
};
function Ku(e) {
  throw new Error(
    e === "consumed" ? "This query is closed and can't emit any more values." : "This query has been chained with another operator and can't be reused."
  );
}
a(Ku, "throwClosedError");
var Me = class e {
  static {
    a(this, "QueryImpl");
  }
  constructor(t) {
    An(this, "state"), An(this, "tableNameForErrorMessages"), this.state = { type: "preparing", query: t }, t.source.type === "FullTableScan" ? this.tableNameForErrorMessages = t.source.tableName : this.tableNameForErrorMessages = t.source.indexName.split(".")[0];
  }
  takeQuery() {
    if (this.state.type !== "preparing")
      throw new Error(
        "A query can only be chained once and can't be chained after iteration begins."
      );
    let t = this.state.query;
    return this.state = { type: "closed" }, t;
  }
  startQuery() {
    if (this.state.type === "executing")
      throw new Error("Iteration can only begin on a query once.");
    (this.state.type === "closed" || this.state.type === "consumed") && Ku(this.state.type);
    let t = this.state.query, { queryId: n } = St("1.0/queryStream", { query: t, version: W });
    return this.state = { type: "executing", queryId: n }, n;
  }
  closeQuery() {
    if (this.state.type === "executing") {
      let t = this.state.queryId;
      St("1.0/queryCleanup", { queryId: t });
    }
    this.state = { type: "consumed" };
  }
  order(t) {
    T(t, 1, "order", "order");
    let n = this.takeQuery();
    if (n.source.type === "Search")
      throw new Error(
        "Search queries must always be in relevance order. Can not set order manually."
      );
    if (n.source.order !== null)
      throw new Error("Queries may only specify order at most once");
    return n.source.order = t, new e(n);
  }
  filter(t) {
    T(t, 1, "filter", "predicate");
    let n = this.takeQuery();
    if (n.operators.length >= Wu)
      throw new Error(
        `Can't construct query with more than ${Wu} operators`
      );
    return n.operators.push({
      filter: D(t(Vu))
    }), new e(n);
  }
  limit(t) {
    T(t, 1, "limit", "n");
    let n = this.takeQuery();
    return n.operators.push({ limit: t }), new e(n);
  }
  [Symbol.asyncIterator]() {
    return this.startQuery(), this;
  }
  async next() {
    (this.state.type === "closed" || this.state.type === "consumed") && Ku(this.state.type);
    let t = this.state.type === "preparing" ? this.startQuery() : this.state.queryId, { value: n, done: o } = await P("1.0/queryStreamNext", {
      queryId: t
    });
    return o && this.closeQuery(), { value: M(n), done: o };
  }
  return() {
    return this.closeQuery(), Promise.resolve({ done: !0, value: void 0 });
  }
  async paginate(t) {
    if (T(t, 1, "paginate", "options"), typeof t?.numItems != "number" || t.numItems < 0)
      throw new Error(
        `\`options.numItems\` must be a positive number. Received \`${t?.numItems}\`.`
      );
    let n = this.takeQuery(), o = t.numItems, r = t.cursor, i = t?.endCursor ?? null, s = t.maximumRowsRead ?? null, { page: c, isDone: u, continueCursor: l, splitCursor: d, pageStatus: g } = await P("1.0/queryPage", {
      query: n,
      cursor: r,
      endCursor: i,
      pageSize: o,
      maximumRowsRead: s,
      maximumBytesRead: t.maximumBytesRead,
      version: W
    });
    return {
      page: c.map((b) => M(b)),
      isDone: u,
      continueCursor: l,
      splitCursor: d,
      pageStatus: g
    };
  }
  async collect() {
    let t = [];
    for await (let n of this)
      t.push(n);
    return t;
  }
  async take(t) {
    return T(t, 1, "take", "n"), Mu(t, 1, "take", "n"), this.limit(t).collect();
  }
  async first() {
    let t = await this.take(1);
    return t.length === 0 ? null : t[0];
  }
  async unique() {
    let t = await this.take(2);
    if (t.length === 0)
      return null;
    if (t.length === 2)
      throw new Error(`unique() query returned more than one result from table ${this.tableNameForErrorMessages}:
 [${t[0]._id}, ${t[1]._id}, ...]`);
    return t[0];
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/database_impl.js
async function Cn(e, t, n) {
  if (T(t, 1, "get", "id"), typeof t != "string")
    throw new Error(
      `Invalid argument \`id\` for \`db.get\`, expected string but got '${typeof t}': ${t}`
    );
  let o = {
    id: C(t),
    isSystem: n,
    version: W,
    table: e
  }, r = await P("1.0/get", o);
  return M(r);
}
a(Cn, "get");
function Bn() {
  let e = /* @__PURE__ */ a((r = !1) => ({
    get: /* @__PURE__ */ a(async (i, s) => s !== void 0 ? await Cn(i, s, r) : await Cn(void 0, i, r), "get"),
    query: /* @__PURE__ */ a((i) => new Ot(i, r).query(), "query"),
    normalizeId: /* @__PURE__ */ a((i, s) => {
      T(i, 1, "normalizeId", "tableName"), T(s, 2, "normalizeId", "id");
      let c = i.startsWith("_");
      if (c !== r)
        throw new Error(
          `${c ? "System" : "User"} tables can only be accessed from db.${r ? "" : "system."}normalizeId().`
        );
      let u = St("1.0/db/normalizeId", {
        table: i,
        idString: s
      });
      return M(u).id;
    }, "normalizeId"),
    // We set the system reader on the next line
    system: null,
    table: /* @__PURE__ */ a((i) => new Ot(i, r), "table")
  }), "reader"), { system: t, ...n } = e(!0), o = e();
  return o.system = n, o;
}
a(Bn, "setupReader");
async function Gu(e, t) {
  if (e.startsWith("_"))
    throw new Error("System tables (prefixed with `_`) are read-only.");
  T(e, 1, "insert", "table"), T(t, 2, "insert", "value");
  let n = await P("1.0/insert", {
    table: e,
    value: C(t)
  });
  return M(n)._id;
}
a(Gu, "insert");
async function Rn(e, t, n) {
  T(t, 1, "patch", "id"), T(n, 2, "patch", "value"), await P("1.0/shallowMerge", {
    id: C(t),
    value: Eu(n),
    table: e
  });
}
a(Rn, "patch");
async function Fn(e, t, n) {
  T(t, 1, "replace", "id"), T(n, 2, "replace", "value"), await P("1.0/replace", {
    id: C(t),
    value: C(n),
    table: e
  });
}
a(Fn, "replace");
async function Mn(e, t) {
  T(t, 1, "delete", "id"), await P("1.0/remove", {
    id: C(t),
    table: e
  });
}
a(Mn, "delete_");
function Xu() {
  let e = Bn();
  return {
    get: e.get,
    query: e.query,
    normalizeId: e.normalizeId,
    system: e.system,
    insert: /* @__PURE__ */ a(async (t, n) => await Gu(t, n), "insert"),
    patch: /* @__PURE__ */ a(async (t, n, o) => o !== void 0 ? await Rn(t, n, o) : await Rn(void 0, t, n), "patch"),
    replace: /* @__PURE__ */ a(async (t, n, o) => o !== void 0 ? await Fn(t, n, o) : await Fn(void 0, t, n), "replace"),
    delete: /* @__PURE__ */ a(async (t, n) => n !== void 0 ? await Mn(t, n) : await Mn(void 0, t), "delete"),
    table: /* @__PURE__ */ a((t) => new Ln(t, !1), "table")
  };
}
a(Xu, "setupWriter");
var Ot = class {
  static {
    a(this, "TableReader");
  }
  constructor(t, n) {
    this.tableName = t, this.isSystem = n;
  }
  async get(t) {
    return Cn(this.tableName, t, this.isSystem);
  }
  query() {
    let t = this.tableName.startsWith("_");
    if (t !== this.isSystem)
      throw new Error(
        `${t ? "System" : "User"} tables can only be accessed from db.${this.isSystem ? "" : "system."}query().`
      );
    return new Ye(this.tableName);
  }
}, Ln = class extends Ot {
  static {
    a(this, "TableWriter");
  }
  async insert(t) {
    return Gu(this.tableName, t);
  }
  async patch(t, n) {
    return Rn(this.tableName, t, n);
  }
  async replace(t, n) {
    return Fn(this.tableName, t, n);
  }
  async delete(t) {
    return Mn(this.tableName, t);
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/scheduler_impl.js
function Hu() {
  return {
    runAfter: /* @__PURE__ */ a(async (e, t, n) => {
      let o = Yu(e, t, n);
      return await P("1.0/schedule", o);
    }, "runAfter"),
    runAt: /* @__PURE__ */ a(async (e, t, n) => {
      let o = el(
        e,
        t,
        n
      );
      return await P("1.0/schedule", o);
    }, "runAt"),
    cancel: /* @__PURE__ */ a(async (e) => {
      T(e, 1, "cancel", "id");
      let t = { id: C(e) };
      await P("1.0/cancel_job", t);
    }, "cancel")
  };
}
a(Hu, "setupMutationScheduler");
function Qu(e) {
  return {
    runAfter: /* @__PURE__ */ a(async (t, n, o) => {
      let r = {
        requestId: e,
        ...Yu(t, n, o)
      };
      return await P("1.0/actions/schedule", r);
    }, "runAfter"),
    runAt: /* @__PURE__ */ a(async (t, n, o) => {
      let r = {
        requestId: e,
        ...el(t, n, o)
      };
      return await P("1.0/actions/schedule", r);
    }, "runAt"),
    cancel: /* @__PURE__ */ a(async (t) => {
      T(t, 1, "cancel", "id");
      let n = {
        requestId: e,
        id: C(t)
      };
      return await P("1.0/actions/cancel_job", n);
    }, "cancel")
  };
}
a(Qu, "setupActionScheduler");
function Yu(e, t, n) {
  if (typeof e != "number")
    throw new Error("`delayMs` must be a number");
  if (!isFinite(e))
    throw new Error("`delayMs` must be a finite number");
  if (e < 0)
    throw new Error("`delayMs` must be non-negative");
  let o = we(n), r = fe(t), i = (Date.now() + e) / 1e3;
  return {
    ...r,
    ts: i,
    args: C(o),
    version: W
  };
}
a(Yu, "runAfterSyscallArgs");
function el(e, t, n) {
  let o;
  if (e instanceof Date)
    o = e.valueOf() / 1e3;
  else if (typeof e == "number")
    o = e / 1e3;
  else
    throw new Error("The invoke time must a Date or a timestamp");
  let r = fe(t), i = we(n);
  return {
    ...r,
    ts: o,
    args: C(i),
    version: W
  };
}
a(el, "runAtSyscallArgs");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/storage_impl.js
function Vn(e) {
  return {
    getUrl: /* @__PURE__ */ a(async (t) => (T(t, 1, "getUrl", "storageId"), await P("1.0/storageGetUrl", {
      requestId: e,
      version: W,
      storageId: t
    })), "getUrl"),
    getMetadata: /* @__PURE__ */ a(async (t) => await P("1.0/storageGetMetadata", {
      requestId: e,
      version: W,
      storageId: t
    }), "getMetadata")
  };
}
a(Vn, "setupStorageReader");
function qn(e) {
  let t = Vn(e);
  return {
    generateUploadUrl: /* @__PURE__ */ a(async () => await P("1.0/storageGenerateUploadUrl", {
      requestId: e,
      version: W
    }), "generateUploadUrl"),
    delete: /* @__PURE__ */ a(async (n) => {
      await P("1.0/storageDelete", {
        requestId: e,
        version: W,
        storageId: n
      });
    }, "delete"),
    getUrl: t.getUrl,
    getMetadata: t.getMetadata
  };
}
a(qn, "setupStorageWriter");
function tl(e) {
  return {
    ...qn(e),
    store: /* @__PURE__ */ a(async (n, o) => await vr("storage/storeBlob", {
      requestId: e,
      version: W,
      blob: n,
      options: o
    }), "store"),
    get: /* @__PURE__ */ a(async (n) => await vr("storage/getBlob", {
      requestId: e,
      version: W,
      storageId: n
    }), "get")
  };
}
a(tl, "setupStorageActionWriter");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/registration_impl.js
async function rl(e, t) {
  let o = M(JSON.parse(t)), r = {
    db: Xu(),
    auth: xr(""),
    storage: qn(""),
    scheduler: Hu(),
    runQuery: /* @__PURE__ */ a((s, c) => Jn("query", s, c), "runQuery"),
    runMutation: /* @__PURE__ */ a((s, c) => Jn("mutation", s, c), "runMutation")
  }, i = await Wn(e, r, o);
  return nl(i), JSON.stringify(C(i === void 0 ? null : i));
}
a(rl, "invokeMutation");
function nl(e) {
  if (e instanceof Ye || e instanceof Me)
    throw new Error(
      "Return value is a Query. Results must be retrieved with `.collect()`, `.take(n), `.unique()`, or `.first()`."
    );
}
a(nl, "validateReturnValue");
async function Wn(e, t, n) {
  let o;
  try {
    o = await Promise.resolve(e(t, ...n));
  } catch (r) {
    throw im(r);
  }
  return o;
}
a(Wn, "invokeFunction");
function et(e, t) {
  return (n, o) => (globalThis.console.warn(
    `Convex functions should not directly call other Convex functions. Consider calling a helper function instead. e.g. \`export const foo = ${e}(...); await foo(ctx);\` is not supported. See https://docs.convex.dev/production/best-practices/#use-helper-functions-to-write-shared-code`
  ), t(n, o));
}
a(et, "dontCallDirectly");
function im(e) {
  if (typeof e == "object" && e !== null && Symbol.for("ConvexError") in e) {
    let t = e;
    return t.data = JSON.stringify(
      C(t.data === void 0 ? null : t.data)
    ), t.ConvexErrorSymbol = Symbol.for("ConvexError"), t;
  } else
    return e;
}
a(im, "serializeConvexErrorData");
function tt() {
  if (typeof window > "u" || window.__convexAllowFunctionsInBrowser)
    return;
  (Object.getOwnPropertyDescriptor(globalThis, "window")?.get?.toString().includes("[native code]") ?? !1) && console.error(
    "Convex functions should not be imported in the browser. This will throw an error in future versions of `convex`. If this is a false negative, please report it to Convex support."
  );
}
a(tt, "assertNotBrowser");
function il(e, t) {
  if (t === void 0)
    throw new Error(
      `A validator is undefined for field "${e}". This is often caused by circular imports. See https://docs.convex.dev/error#undefined-validator for details.`
    );
  return t;
}
a(il, "strictReplacer");
function rt(e) {
  return () => {
    let t = m.any();
    return typeof e == "object" && e.args !== void 0 && (t = It(e.args)), JSON.stringify(t.json, il);
  };
}
a(rt, "exportArgs");
function nt(e) {
  return () => {
    let t;
    return typeof e == "object" && e.returns !== void 0 && (t = It(e.returns)), JSON.stringify(t ? t.json : null, il);
  };
}
a(nt, "exportReturns");
var Kn = /* @__PURE__ */ a(((e) => {
  let t = typeof e == "function" ? e : e.handler, n = et("mutation", t);
  return tt(), n.isMutation = !0, n.isPublic = !0, n.invokeMutation = (o) => rl(t, o), n.exportArgs = rt(e), n.exportReturns = nt(e), n._handler = t, n;
}), "mutationGeneric"), Gn = /* @__PURE__ */ a(((e) => {
  let t = typeof e == "function" ? e : e.handler, n = et(
    "internalMutation",
    t
  );
  return tt(), n.isMutation = !0, n.isInternal = !0, n.invokeMutation = (o) => rl(t, o), n.exportArgs = rt(e), n.exportReturns = nt(e), n._handler = t, n;
}), "internalMutationGeneric");
async function ol(e, t) {
  let o = M(JSON.parse(t)), r = {
    db: Bn(),
    auth: xr(""),
    storage: Vn(""),
    runQuery: /* @__PURE__ */ a((s, c) => Jn("query", s, c), "runQuery")
  }, i = await Wn(e, r, o);
  return nl(i), JSON.stringify(C(i === void 0 ? null : i));
}
a(ol, "invokeQuery");
var Xn = /* @__PURE__ */ a(((e) => {
  let t = typeof e == "function" ? e : e.handler, n = et("query", t);
  return tt(), n.isQuery = !0, n.isPublic = !0, n.invokeQuery = (o) => ol(t, o), n.exportArgs = rt(e), n.exportReturns = nt(e), n._handler = t, n;
}), "queryGeneric"), Hn = /* @__PURE__ */ a(((e) => {
  let t = typeof e == "function" ? e : e.handler, n = et("internalQuery", t);
  return tt(), n.isQuery = !0, n.isInternal = !0, n.invokeQuery = (o) => ol(t, o), n.exportArgs = rt(e), n.exportReturns = nt(e), n._handler = t, n;
}), "internalQueryGeneric");
async function al(e, t, n) {
  let o = M(JSON.parse(n)), i = {
    ...Ru(t),
    auth: xr(t),
    scheduler: Qu(t),
    storage: tl(t),
    vectorSearch: Lu(t)
  }, s = await Wn(e, i, o);
  return JSON.stringify(C(s === void 0 ? null : s));
}
a(al, "invokeAction");
var Qn = /* @__PURE__ */ a(((e) => {
  let t = typeof e == "function" ? e : e.handler, n = et("action", t);
  return tt(), n.isAction = !0, n.isPublic = !0, n.invokeAction = (o, r) => al(t, o, r), n.exportArgs = rt(e), n.exportReturns = nt(e), n._handler = t, n;
}), "actionGeneric"), Yn = /* @__PURE__ */ a(((e) => {
  let t = typeof e == "function" ? e : e.handler, n = et("internalAction", t);
  return tt(), n.isAction = !0, n.isInternal = !0, n.invokeAction = (o, r) => al(t, o, r), n.exportArgs = rt(e), n.exportReturns = nt(e), n._handler = t, n;
}), "internalActionGeneric");
async function Jn(e, t, n) {
  let o = we(n), r = {
    udfType: e,
    args: C(o),
    ...fe(t)
  }, i = await P("1.0/runUdf", r);
  return M(i);
}
a(Jn, "runUdf");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/pagination.js
var om = m.object({
  numItems: m.number(),
  cursor: m.union(m.string(), m.null()),
  endCursor: m.optional(m.union(m.string(), m.null())),
  id: m.optional(m.number()),
  maximumRowsRead: m.optional(m.number()),
  maximumBytesRead: m.optional(m.number())
});

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/api.js
function sl(e = []) {
  let t = {
    get(n, o) {
      if (typeof o == "string") {
        let r = [...e, o];
        return sl(r);
      } else if (o === jt) {
        if (e.length < 2) {
          let s = ["api", ...e].join(".");
          throw new Error(
            `API path is expected to be of the form \`api.moduleName.functionName\`. Found: \`${s}\``
          );
        }
        let r = e.slice(0, -1).join("/"), i = e[e.length - 1];
        return i === "default" ? r : r + ":" + i;
      } else return o === Symbol.toStringTag ? "FunctionReference" : void 0;
    }
  };
  return new Proxy({}, t);
}
a(sl, "createApi");
var am = sl();

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/schema.js
var cm = Object.defineProperty, um = /* @__PURE__ */ a((e, t, n) => t in e ? cm(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), be = /* @__PURE__ */ a((e, t, n) => um(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), Ir = class {
  static {
    a(this, "TableDefinition");
  }
  /**
   * @internal
   */
  constructor(t) {
    be(this, "indexes"), be(this, "stagedDbIndexes"), be(this, "searchIndexes"), be(this, "stagedSearchIndexes"), be(this, "vectorIndexes"), be(this, "stagedVectorIndexes"), be(this, "validator"), this.indexes = [], this.stagedDbIndexes = [], this.searchIndexes = [], this.stagedSearchIndexes = [], this.vectorIndexes = [], this.stagedVectorIndexes = [], this.validator = t;
  }
  /**
   * This API is experimental: it may change or disappear.
   *
   * Returns indexes defined on this table.
   * Intended for the advanced use cases of dynamically deciding which index to use for a query.
   * If you think you need this, please chime in on ths issue in the Convex JS GitHub repo.
   * https://github.com/get-convex/convex-js/issues/49
   */
  " indexes"() {
    return this.indexes;
  }
  index(t, n) {
    return Array.isArray(n) ? this.indexes.push({
      indexDescriptor: t,
      fields: n
    }) : n.staged ? this.stagedDbIndexes.push({
      indexDescriptor: t,
      fields: n.fields
    }) : this.indexes.push({
      indexDescriptor: t,
      fields: n.fields
    }), this;
  }
  searchIndex(t, n) {
    return n.staged ? this.stagedSearchIndexes.push({
      indexDescriptor: t,
      searchField: n.searchField,
      filterFields: n.filterFields || []
    }) : this.searchIndexes.push({
      indexDescriptor: t,
      searchField: n.searchField,
      filterFields: n.filterFields || []
    }), this;
  }
  vectorIndex(t, n) {
    return n.staged ? this.stagedVectorIndexes.push({
      indexDescriptor: t,
      vectorField: n.vectorField,
      dimensions: n.dimensions,
      filterFields: n.filterFields || []
    }) : this.vectorIndexes.push({
      indexDescriptor: t,
      vectorField: n.vectorField,
      dimensions: n.dimensions,
      filterFields: n.filterFields || []
    }), this;
  }
  /**
   * Work around for https://github.com/microsoft/TypeScript/issues/57035
   */
  self() {
    return this;
  }
  /**
   * Export the contents of this definition.
   *
   * This is called internally by the Convex framework.
   * @internal
   */
  export() {
    let t = this.validator.json;
    if (typeof t != "object")
      throw new Error(
        "Invalid validator: please make sure that the parameter of `defineTable` is valid (see https://docs.convex.dev/database/schemas)"
      );
    return {
      indexes: this.indexes,
      stagedDbIndexes: this.stagedDbIndexes,
      searchIndexes: this.searchIndexes,
      stagedSearchIndexes: this.stagedSearchIndexes,
      vectorIndexes: this.vectorIndexes,
      stagedVectorIndexes: this.stagedVectorIndexes,
      documentType: t
    };
  }
};
function Le(e) {
  return Un(e) ? new Ir(e) : new Ir(m.object(e));
}
a(Le, "defineTable");
var ei = class {
  static {
    a(this, "SchemaDefinition");
  }
  /**
   * @internal
   */
  constructor(t, n) {
    be(this, "tables"), be(this, "strictTableNameTypes"), be(this, "schemaValidation"), this.tables = t, this.schemaValidation = n?.schemaValidation === void 0 ? !0 : n.schemaValidation;
  }
  /**
   * Export the contents of this definition.
   *
   * This is called internally by the Convex framework.
   * @internal
   */
  export() {
    return JSON.stringify({
      tables: Object.entries(this.tables).map(([t, n]) => {
        let {
          indexes: o,
          stagedDbIndexes: r,
          searchIndexes: i,
          stagedSearchIndexes: s,
          vectorIndexes: c,
          stagedVectorIndexes: u,
          documentType: l
        } = n.export();
        return {
          tableName: t,
          indexes: o,
          stagedDbIndexes: r,
          searchIndexes: i,
          stagedSearchIndexes: s,
          vectorIndexes: c,
          stagedVectorIndexes: u,
          documentType: l
        };
      }),
      schemaValidation: this.schemaValidation
    });
  }
};
function Sr(e, t) {
  return new ei(e, t);
}
a(Sr, "defineSchema");
var rw = Sr({
  _scheduled_functions: Le({
    name: m.string(),
    args: m.array(m.any()),
    scheduledTime: m.float64(),
    completedTime: m.optional(m.float64()),
    state: m.union(
      m.object({ kind: m.literal("pending") }),
      m.object({ kind: m.literal("inProgress") }),
      m.object({ kind: m.literal("success") }),
      m.object({ kind: m.literal("failed"), error: m.string() }),
      m.object({ kind: m.literal("canceled") })
    )
  }),
  _storage: Le({
    sha256: m.string(),
    size: m.float64(),
    contentType: m.optional(m.string())
  })
});

// memory/profile.mjs
var Be = class {
  static {
    a(this, "SecretText");
  }
  constructor(t) {
    this.value = t;
  }
  toWire() {
    return this.value;
  }
}, ti = {
  seq: 1,
  at: 17e11,
  secret: "capacity",
  payload: "tiny"
};
function cl(e) {
  let t = e.kind === "native", n = e.kind === "full" || e.kind === "mini", o = t ? e.v : e.s;
  return /* @__PURE__ */ a(function({ count: i, width: s, profile: c, entries: u = 0 }) {
    if (!Number.isInteger(i) || i < 0 || !Number.isInteger(s) || s < 1 || !Number.isInteger(u) || u < 0 || !["fields-only", "codec-rich"].includes(c))
      throw new Error("Invalid graph fixture arguments");
    let l = {
      schemaConstructors: 0,
      fields: 0,
      codecSites: 0,
      allocatedCodecs: 0
    }, d = /* @__PURE__ */ a((k, ...O) => (l.schemaConstructors++, o[k](...O)), "make"), g = /* @__PURE__ */ a((k) => (l.fields += Object.keys(k).length, d("object", k)), "object"), b = /* @__PURE__ */ a(() => (l.codecSites++, t ? d("number") : (l.allocatedCodecs++, d("codec", d("number"), d("date"), {
      decode: /* @__PURE__ */ a((k) => new Date(k), "decode"),
      encode: /* @__PURE__ */ a((k) => k.getTime(), "encode")
    }))), "date"), x = /* @__PURE__ */ a(() => (l.codecSites++, t ? d("string") : (l.allocatedCodecs++, d("codec", d("string"), d("instanceof", Be), {
      decode: /* @__PURE__ */ a((k) => new Be(k), "decode"),
      encode: /* @__PURE__ */ a((k) => k.toWire(), "encode")
    }))), "secret"), j = /* @__PURE__ */ a((k) => {
      if (c === "fields-only")
        switch (k % 4) {
          case 0:
            return d("string");
          case 1:
            return d("number");
          case 2:
            return d("boolean");
          case 3:
            return d("optional", d("string"));
        }
      switch (k % 4) {
        case 0:
          return b();
        case 1:
          return x();
        case 2:
          return g({ at: b(), tag: d("optional", d("string")) });
        case 3:
          return d(
            "array",
            t ? d("union", d("string"), d("number")) : d("union", [d("string"), d("number")])
          );
      }
    }, "field"), z = {}, q = {}, Ae = /* @__PURE__ */ a((k, O) => {
      n ? (l.fields += Object.keys(O).length, z[k] = e.defineZodModel(k, O, e.schemaHelpers ? void 0 : { schemaHelpers: !1 })) : (q[k] = g(O), z[k] = t ? e.defineTable(q[k]) : q[k]);
    }, "add");
    Ae("benchmarkRows", {
      seq: d("number"),
      at: b(),
      secret: x(),
      payload: d("string")
    });
    for (let k = 0; k < i; k++) {
      let O = {};
      for (let B = 0; B < s; B++) O[`f${B}`] = j(B);
      Ae(`unused${k}`, O);
    }
    let ve = n ? e.defineZodSchema(z) : t ? e.defineSchema(z) : null;
    if (n) for (let k of Object.keys(z)) q[k] = ve.__zodTableMap[k].insert;
    let J = Object.keys(z), Z = {};
    for (let k = 0; k < u; k++) {
      let O = J[k % J.length], B = n ? ve.__zodTableMap[O].doc : q[O], Ge = g({
        id: d("string"),
        label: d("optional", d("string"))
      }), ir = t ? d("union", B, d("null")) : d("nullable", B);
      Z[`unused/fn${k}`] = { args: Ge, returns: ir };
    }
    let K = n ? e.initZodvex(
      ve,
      e.server,
      u ? { registry: /* @__PURE__ */ a(() => Z, "registry") } : void 0
    ) : e.makeBuilders();
    return {
      kind: e.kind,
      options: { count: i, width: s, profile: c, entries: u },
      models: z,
      sourceSchemas: q,
      schema: ve,
      registry: Z,
      builders: K,
      manifest: {
        backgroundModels: i,
        totalModels: i + 1,
        backgroundTopLevelFields: i * s,
        fixedProbeFields: 4,
        profile: c,
        registryEntries: u,
        ...l,
        counterScope: "Explicit fixture constructor calls and source fields/codecs; excludes library-generated helper schemas and runtime heap objects."
      },
      operation() {
        let k = { ...ti }, O = t ? {
          ...k,
          at: new Date(k.at),
          secret: new Be(k.secret)
        } : e.s.parse(q.benchmarkRows, k);
        if (!(O.at instanceof Date) || !(O.secret instanceof Be))
          throw new Error("Codec decode failed");
        O.at = new Date(O.at.getTime() + 1e3), O.secret = new Be(O.secret.toWire().toUpperCase());
        let B = t ? {
          ...O,
          at: O.at.getTime(),
          secret: O.secret.toWire()
        } : e.s.encode(q.benchmarkRows, O);
        if (JSON.stringify(B) !== JSON.stringify({
          ...ti,
          at: ti.at + 1e3,
          secret: "CAPACITY"
        }))
          throw new Error("Codec round trip mismatch");
        return B;
      },
      // Call after the operation and after GC measurements. The retained graph
      // includes every model, table schema, registry entry and builder closure.
      checksum() {
        let k = 0;
        for (let [O, B] of Object.entries(z)) {
          if (!B || !q[O]) throw new Error("Missing model");
          if (k += O.length, n && ve.__zodTableMap[O].insert !== q[O])
            throw new Error("Lost table-map alias");
        }
        for (let [O, B] of Object.entries(Z)) {
          if (!B.args || !B.returns)
            throw new Error("Missing registry schema");
          k += O.length;
        }
        if (Object.keys(K).length === 0)
          throw new Error("Lost builders");
        return k;
      }
    };
  }, "buildGraph");
}
a(cl, "createGraphFactory");

// versions/4.3.6/node_modules/zod/v4/mini/external.js
var $ = {};
Ce($, {
  $brand: () => ni,
  $input: () => vs,
  $output: () => hs,
  NEVER: () => ri,
  TimePrecision: () => Ls,
  ZodMiniAny: () => yd,
  ZodMiniArray: () => wd,
  ZodMiniBase64: () => ld,
  ZodMiniBase64URL: () => dd,
  ZodMiniBigInt: () => Yt,
  ZodMiniBigIntFormat: () => Kc,
  ZodMiniBoolean: () => Qt,
  ZodMiniCIDRv4: () => sd,
  ZodMiniCIDRv6: () => cd,
  ZodMiniCUID: () => ed,
  ZodMiniCUID2: () => td,
  ZodMiniCatch: () => Md,
  ZodMiniCodec: () => ru,
  ZodMiniCustom: () => iu,
  ZodMiniCustomStringFormat: () => Xt,
  ZodMiniDate: () => nn,
  ZodMiniDefault: () => Cd,
  ZodMiniDiscriminatedUnion: () => zd,
  ZodMiniE164: () => fd,
  ZodMiniEmail: () => Xl,
  ZodMiniEmoji: () => Ql,
  ZodMiniEnum: () => Qc,
  ZodMiniExactOptional: () => Nd,
  ZodMiniFile: () => Ed,
  ZodMiniFunction: () => Gd,
  ZodMiniGUID: () => Hl,
  ZodMiniIPv4: () => od,
  ZodMiniIPv6: () => ad,
  ZodMiniISODate: () => dn,
  ZodMiniISODateTime: () => ln,
  ZodMiniISODuration: () => pn,
  ZodMiniISOTime: () => fn,
  ZodMiniIntersection: () => Id,
  ZodMiniJWT: () => pd,
  ZodMiniKSUID: () => id,
  ZodMiniLazy: () => qd,
  ZodMiniLiteral: () => Dd,
  ZodMiniMAC: () => ud,
  ZodMiniMap: () => Td,
  ZodMiniNaN: () => Ld,
  ZodMiniNanoID: () => Yl,
  ZodMiniNever: () => xd,
  ZodMiniNonOptional: () => eu,
  ZodMiniNull: () => hd,
  ZodMiniNullable: () => Ad,
  ZodMiniNumber: () => Ht,
  ZodMiniNumberFormat: () => yt,
  ZodMiniObject: () => on,
  ZodMiniOptional: () => Yc,
  ZodMiniPipe: () => tu,
  ZodMiniPrefault: () => Rd,
  ZodMiniPromise: () => Wd,
  ZodMiniReadonly: () => Bd,
  ZodMiniRecord: () => sn,
  ZodMiniSet: () => Pd,
  ZodMiniString: () => vt,
  ZodMiniStringFormat: () => A,
  ZodMiniSuccess: () => Fd,
  ZodMiniSymbol: () => md,
  ZodMiniTemplateLiteral: () => Vd,
  ZodMiniTransform: () => Zd,
  ZodMiniTuple: () => Sd,
  ZodMiniType: () => S,
  ZodMiniULID: () => rd,
  ZodMiniURL: () => Wc,
  ZodMiniUUID: () => Gt,
  ZodMiniUndefined: () => gd,
  ZodMiniUnion: () => Hc,
  ZodMiniUnknown: () => bd,
  ZodMiniVoid: () => _d,
  ZodMiniXID: () => nd,
  ZodMiniXor: () => kd,
  _default: () => _y,
  _function: () => Ry,
  any: () => Xv,
  array: () => er,
  base64: () => Uv,
  base64url: () => Dv,
  bigint: () => qv,
  boolean: () => rn,
  catch: () => Iy,
  catchall: () => cy,
  check: () => Uy,
  cidrv4: () => Ov,
  cidrv6: () => Tv,
  clone: () => V,
  codec: () => nu,
  coerce: () => su,
  config: () => X,
  core: () => ht,
  cuid: () => _v,
  cuid2: () => wv,
  custom: () => Kd,
  date: () => Gc,
  decode: () => wi,
  decodeAsync: () => zi,
  describe: () => Zy,
  discriminatedUnion: () => ly,
  e164: () => Ev,
  email: () => fv,
  emoji: () => xv,
  encode: () => Q,
  encodeAsync: () => ki,
  endsWith: () => Uc,
  enum: () => Ud,
  exactOptional: () => xy,
  extend: () => ty,
  file: () => yy,
  flattenError: () => bi,
  float32: () => Mv,
  float64: () => Lv,
  formatError: () => xi,
  function: () => Ry,
  globalRegistry: () => he,
  gt: () => Xr,
  gte: () => Wt,
  guid: () => pv,
  hash: () => Rv,
  hex: () => Cv,
  hostname: () => Av,
  httpUrl: () => bv,
  includes: () => Tc,
  instanceof: () => ou,
  int: () => Fv,
  int32: () => Bv,
  int64: () => Jv,
  intersection: () => dy,
  ipv4: () => Sv,
  ipv6: () => jv,
  iso: () => au,
  json: () => Cy,
  jwt: () => Zv,
  keyof: () => Qv,
  ksuid: () => Iv,
  lazy: () => Jd,
  length: () => Ic,
  literal: () => vy,
  locales: () => qt,
  looseObject: () => ey,
  looseRecord: () => py,
  lowercase: () => jc,
  lt: () => Gr,
  lte: () => Jt,
  mac: () => Pv,
  map: () => my,
  maxLength: () => kc,
  maxSize: () => $c,
  maximum: () => Jt,
  merge: () => ny,
  meta: () => Ny,
  mime: () => Ec,
  minLength: () => zc,
  minSize: () => _c,
  minimum: () => Wt,
  multipleOf: () => xc,
  nan: () => Sy,
  nanoid: () => $v,
  nativeEnum: () => hy,
  negative: () => vc,
  never: () => $d,
  nonnegative: () => bc,
  nonoptional: () => ky,
  nonpositive: () => yc,
  normalize: () => Zc,
  null: () => vd,
  nullable: () => un,
  nullish: () => $y,
  number: () => tn,
  object: () => Xc,
  omit: () => oy,
  optional: () => cn,
  overwrite: () => Ue,
  parse: () => ne,
  parseAsync: () => je,
  partial: () => ay,
  partialRecord: () => fy,
  pick: () => iy,
  pipe: () => jy,
  positive: () => hc,
  prefault: () => wy,
  prettifyError: () => _i,
  promise: () => Py,
  property: () => Dc,
  readonly: () => Oy,
  record: () => Od,
  refine: () => Dy,
  regex: () => Sc,
  regexes: () => le,
  registry: () => Wr,
  required: () => sy,
  safeDecode: () => Si,
  safeDecodeAsync: () => Oi,
  safeEncode: () => Ii,
  safeEncodeAsync: () => ji,
  safeExtend: () => ry,
  safeParse: () => me,
  safeParseAsync: () => qe,
  set: () => gy,
  size: () => wc,
  startsWith: () => Pc,
  strictObject: () => Yv,
  string: () => Kt,
  stringFormat: () => Nv,
  stringbool: () => Ay,
  success: () => zy,
  superRefine: () => Ey,
  symbol: () => Kv,
  templateLiteral: () => Ty,
  toJSONSchema: () => Qr,
  toLowerCase: () => Ac,
  toUpperCase: () => Cc,
  transform: () => by,
  treeifyError: () => $i,
  trim: () => Nc,
  tuple: () => jd,
  uint32: () => Vv,
  uint64: () => Wv,
  ulid: () => kv,
  undefined: () => Gv,
  union: () => an,
  unknown: () => en,
  uppercase: () => Oc,
  url: () => yv,
  util: () => w,
  uuid: () => mv,
  uuidv4: () => gv,
  uuidv6: () => hv,
  uuidv7: () => vv,
  void: () => Hv,
  xid: () => zv,
  xor: () => uy
});

// versions/4.3.6/node_modules/zod/v4/core/index.js
var ht = {};
Ce(ht, {
  $ZodAny: () => ra,
  $ZodArray: () => Oe,
  $ZodAsyncError: () => pe,
  $ZodBase64: () => Jo,
  $ZodBase64URL: () => Wo,
  $ZodBigInt: () => qr,
  $ZodBigIntFormat: () => Qo,
  $ZodBoolean: () => Ft,
  $ZodCIDRv4: () => Bo,
  $ZodCIDRv6: () => Vo,
  $ZodCUID: () => Po,
  $ZodCUID2: () => Uo,
  $ZodCatch: () => ha,
  $ZodCheck: () => N,
  $ZodCheckBigIntFormat: () => ao,
  $ZodCheckEndsWith: () => bo,
  $ZodCheckGreaterThan: () => Cr,
  $ZodCheckIncludes: () => vo,
  $ZodCheckLengthEquals: () => po,
  $ZodCheckLessThan: () => Ar,
  $ZodCheckLowerCase: () => go,
  $ZodCheckMaxLength: () => lo,
  $ZodCheckMaxSize: () => so,
  $ZodCheckMimeType: () => $o,
  $ZodCheckMinLength: () => fo,
  $ZodCheckMinSize: () => co,
  $ZodCheckMultipleOf: () => io,
  $ZodCheckNumberFormat: () => oo,
  $ZodCheckOverwrite: () => _o,
  $ZodCheckProperty: () => xo,
  $ZodCheckRegex: () => mo,
  $ZodCheckSizeEquals: () => uo,
  $ZodCheckStartsWith: () => yo,
  $ZodCheckStringFormat: () => ct,
  $ZodCheckUpperCase: () => ho,
  $ZodCodec: () => ge,
  $ZodCustom: () => Mt,
  $ZodCustomStringFormat: () => Xo,
  $ZodDate: () => lt,
  $ZodDefault: () => ae,
  $ZodDiscriminatedUnion: () => Te,
  $ZodE164: () => Ko,
  $ZodEmail: () => So,
  $ZodEmoji: () => Oo,
  $ZodEncodeError: () => it,
  $ZodEnum: () => dt,
  $ZodError: () => $e,
  $ZodExactOptional: () => fa,
  $ZodFile: () => la,
  $ZodFunction: () => $a,
  $ZodGUID: () => zo,
  $ZodIPv4: () => Fo,
  $ZodIPv6: () => Mo,
  $ZodISODate: () => Ao,
  $ZodISODateTime: () => No,
  $ZodISODuration: () => Ro,
  $ZodISOTime: () => Co,
  $ZodIntersection: () => sa,
  $ZodJWT: () => Go,
  $ZodKSUID: () => Zo,
  $ZodLazy: () => pt,
  $ZodLiteral: () => ft,
  $ZodMAC: () => Lo,
  $ZodMap: () => ca,
  $ZodNaN: () => va,
  $ZodNanoID: () => To,
  $ZodNever: () => ia,
  $ZodNonOptional: () => ma,
  $ZodNull: () => ta,
  $ZodNullable: () => de,
  $ZodNumber: () => Vr,
  $ZodNumberFormat: () => Ho,
  $ZodObject: () => L,
  $ZodObjectJIT: () => ng,
  $ZodOptional: () => F,
  $ZodPipe: () => ya,
  $ZodPrefault: () => pa,
  $ZodPromise: () => _a,
  $ZodReadonly: () => ba,
  $ZodRealError: () => re,
  $ZodRecord: () => We,
  $ZodRegistry: () => Jr,
  $ZodSet: () => ua,
  $ZodString: () => ut,
  $ZodStringFormat: () => E,
  $ZodSuccess: () => ga,
  $ZodSymbol: () => Yo,
  $ZodTemplateLiteral: () => xa,
  $ZodTransform: () => da,
  $ZodTuple: () => Pe,
  $ZodType: () => _,
  $ZodULID: () => Do,
  $ZodURL: () => jo,
  $ZodUUID: () => Io,
  $ZodUndefined: () => ea,
  $ZodUnion: () => Y,
  $ZodUnknown: () => na,
  $ZodVoid: () => oa,
  $ZodXID: () => Eo,
  $ZodXor: () => aa,
  $brand: () => ni,
  $constructor: () => f,
  $input: () => vs,
  $output: () => hs,
  Doc: () => Rt,
  JSONSchema: () => Gl,
  JSONSchemaGenerator: () => Yr,
  NEVER: () => ri,
  TimePrecision: () => Ls,
  _any: () => uc,
  _array: () => eh,
  _base64: () => Cs,
  _base64url: () => Rs,
  _bigint: () => rc,
  _boolean: () => ec,
  _catch: () => yh,
  _check: () => Kl,
  _cidrv4: () => Ns,
  _cidrv6: () => As,
  _coercedBigint: () => nc,
  _coercedBoolean: () => tc,
  _coercedDate: () => mc,
  _coercedNumber: () => Ks,
  _coercedString: () => bs,
  _cuid: () => js,
  _cuid2: () => Os,
  _custom: () => Fc,
  _date: () => pc,
  _decode: () => gl,
  _decodeAsync: () => vl,
  _default: () => gh,
  _discriminatedUnion: () => nh,
  _e164: () => Fs,
  _email: () => xs,
  _emoji: () => Is,
  _encode: () => ml,
  _encodeAsync: () => hl,
  _endsWith: () => Uc,
  _enum: () => uh,
  _file: () => Rc,
  _float32: () => Xs,
  _float64: () => Hs,
  _gt: () => Xr,
  _gte: () => Wt,
  _guid: () => $s,
  _includes: () => Tc,
  _int: () => Gs,
  _int32: () => Qs,
  _int64: () => ic,
  _intersection: () => ih,
  _ipv4: () => Ds,
  _ipv6: () => Es,
  _isoDate: () => Vs,
  _isoDateTime: () => Bs,
  _isoDuration: () => Js,
  _isoTime: () => qs,
  _jwt: () => Ms,
  _ksuid: () => Us,
  _lazy: () => _h,
  _length: () => Ic,
  _literal: () => dh,
  _lowercase: () => jc,
  _lt: () => Gr,
  _lte: () => Jt,
  _mac: () => Zs,
  _map: () => sh,
  _max: () => Jt,
  _maxLength: () => kc,
  _maxSize: () => $c,
  _mime: () => Ec,
  _min: () => Wt,
  _minLength: () => zc,
  _minSize: () => _c,
  _multipleOf: () => xc,
  _nan: () => gc,
  _nanoid: () => Ss,
  _nativeEnum: () => lh,
  _negative: () => vc,
  _never: () => dc,
  _nonnegative: () => bc,
  _nonoptional: () => hh,
  _nonpositive: () => yc,
  _normalize: () => Zc,
  _null: () => cc,
  _nullable: () => mh,
  _number: () => Ws,
  _optional: () => ph,
  _overwrite: () => Ue,
  _parse: () => Pr,
  _parseAsync: () => Ur,
  _pipe: () => bh,
  _positive: () => hc,
  _promise: () => wh,
  _property: () => Dc,
  _readonly: () => xh,
  _record: () => ah,
  _refine: () => Mc,
  _regex: () => Sc,
  _safeDecode: () => bl,
  _safeDecodeAsync: () => $l,
  _safeEncode: () => yl,
  _safeEncodeAsync: () => xl,
  _safeParse: () => Dr,
  _safeParseAsync: () => Er,
  _set: () => ch,
  _size: () => wc,
  _slugify: () => Yg,
  _startsWith: () => Pc,
  _string: () => ys,
  _stringFormat: () => gt,
  _stringbool: () => qc,
  _success: () => vh,
  _superRefine: () => Lc,
  _symbol: () => ac,
  _templateLiteral: () => $h,
  _toLowerCase: () => Ac,
  _toUpperCase: () => Cc,
  _transform: () => fh,
  _trim: () => Nc,
  _tuple: () => oh,
  _uint32: () => Ys,
  _uint64: () => oc,
  _ulid: () => Ts,
  _undefined: () => sc,
  _union: () => th,
  _unknown: () => lc,
  _uppercase: () => Oc,
  _url: () => Kr,
  _uuid: () => _s,
  _uuidv4: () => ws,
  _uuidv6: () => ks,
  _uuidv7: () => zs,
  _void: () => fc,
  _xid: () => Ps,
  _xor: () => rh,
  clone: () => V,
  config: () => X,
  createStandardJSONSchemaMethod: () => Jc,
  createToJSONSchemaMethod: () => kh,
  decode: () => wi,
  decodeAsync: () => zi,
  describe: () => Bc,
  encode: () => Q,
  encodeAsync: () => ki,
  extractDefs: () => Ee,
  finalize: () => Ze,
  flattenError: () => bi,
  formatError: () => xi,
  globalConfig: () => Tt,
  globalRegistry: () => he,
  initializeContext: () => De,
  isValidBase64: () => qo,
  isValidBase64URL: () => Rl,
  isValidJWT: () => Fl,
  locales: () => qt,
  meta: () => Vc,
  parse: () => ne,
  parseAsync: () => je,
  prettifyError: () => _i,
  process: () => U,
  regexes: () => le,
  registry: () => Wr,
  safeDecode: () => Si,
  safeDecodeAsync: () => Oi,
  safeEncode: () => Ii,
  safeEncodeAsync: () => ji,
  safeParse: () => me,
  safeParseAsync: () => qe,
  toDotPath: () => pl,
  toJSONSchema: () => Qr,
  treeifyError: () => $i,
  util: () => w,
  version: () => wo
});

// versions/4.3.6/node_modules/zod/v4/core/core.js
var ri = Object.freeze({
  status: "aborted"
});
// @__NO_SIDE_EFFECTS__
function f(e, t, n) {
  function o(c, u) {
    if (c._zod || Object.defineProperty(c, "_zod", {
      value: {
        def: u,
        constr: s,
        traits: /* @__PURE__ */ new Set()
      },
      enumerable: !1
    }), c._zod.traits.has(e))
      return;
    c._zod.traits.add(e), t(c, u);
    let l = s.prototype, d = Object.keys(l);
    for (let g = 0; g < d.length; g++) {
      let b = d[g];
      b in c || (c[b] = l[b].bind(c));
    }
  }
  a(o, "init");
  let r = n?.Parent ?? Object;
  class i extends r {
    static {
      a(this, "Definition");
    }
  }
  Object.defineProperty(i, "name", { value: e });
  function s(c) {
    var u;
    let l = n?.Parent ? new i() : this;
    o(l, c), (u = l._zod).deferred ?? (u.deferred = []);
    for (let d of l._zod.deferred)
      d();
    return l;
  }
  return a(s, "_"), Object.defineProperty(s, "init", { value: o }), Object.defineProperty(s, Symbol.hasInstance, {
    value: /* @__PURE__ */ a((c) => n?.Parent && c instanceof n.Parent ? !0 : c?._zod?.traits?.has(e), "value")
  }), Object.defineProperty(s, "name", { value: e }), s;
}
a(f, "$constructor");
var ni = Symbol("zod_brand"), pe = class extends Error {
  static {
    a(this, "$ZodAsyncError");
  }
  constructor() {
    super("Encountered Promise during synchronous parse. Use .parseAsync() instead.");
  }
}, it = class extends Error {
  static {
    a(this, "$ZodEncodeError");
  }
  constructor(t) {
    super(`Encountered unidirectional transform during encode: ${t}`), this.name = "ZodEncodeError";
  }
}, Tt = {};
function X(e) {
  return e && Object.assign(Tt, e), Tt;
}
a(X, "config");

// versions/4.3.6/node_modules/zod/v4/core/util.js
var w = {};
Ce(w, {
  BIGINT_FORMAT_RANGES: () => pi,
  Class: () => oi,
  NUMBER_FORMAT_RANGES: () => fi,
  aborted: () => Se,
  allowsEval: () => ui,
  assert: () => mm,
  assertEqual: () => lm,
  assertIs: () => fm,
  assertNever: () => pm,
  assertNotEqual: () => dm,
  assignProp: () => ze,
  base64ToUint8Array: () => ll,
  base64urlToUint8Array: () => zm,
  cached: () => ot,
  captureStackTrace: () => Or,
  cleanEnum: () => km,
  cleanRegex: () => Dt,
  clone: () => V,
  cloneDef: () => hm,
  createTransparentProxy: () => _m,
  defineLazy: () => I,
  esc: () => jr,
  escapeRegex: () => ue,
  extend: () => Tr,
  finalizeIssue: () => te,
  floatSafeRemainder: () => si,
  getElementAtPath: () => vm,
  getEnumValues: () => Ut,
  getLengthableOrigin: () => Nt,
  getParsedType: () => $m,
  getSizableOrigin: () => Zt,
  hexToUint8Array: () => Sm,
  isObject: () => Ve,
  isPlainObject: () => Ie,
  issue: () => st,
  joinValues: () => p,
  jsonStringifyReplacer: () => ai,
  merge: () => wm,
  mergeDefs: () => xe,
  normalizeParams: () => h,
  nullish: () => ke,
  numKeys: () => xm,
  objectClone: () => gm,
  omit: () => gi,
  optionalKeys: () => di,
  parsedType: () => y,
  partial: () => vi,
  pick: () => mi,
  prefixIssues: () => oe,
  primitiveTypes: () => li,
  promiseAllObject: () => ym,
  propertyKeyTypes: () => Et,
  randomString: () => bm,
  required: () => yi,
  safeExtend: () => hi,
  shallowClone: () => at,
  slugify: () => ci,
  stringifyPrimitive: () => v,
  uint8ArrayToBase64: () => dl,
  uint8ArrayToBase64url: () => Im,
  uint8ArrayToHex: () => jm,
  unwrapMessage: () => Pt
});
function lm(e) {
  return e;
}
a(lm, "assertEqual");
function dm(e) {
  return e;
}
a(dm, "assertNotEqual");
function fm(e) {
}
a(fm, "assertIs");
function pm(e) {
  throw new Error("Unexpected value in exhaustive check");
}
a(pm, "assertNever");
function mm(e) {
}
a(mm, "assert");
function Ut(e) {
  let t = Object.values(e).filter((o) => typeof o == "number");
  return Object.entries(e).filter(([o, r]) => t.indexOf(+o) === -1).map(([o, r]) => r);
}
a(Ut, "getEnumValues");
function p(e, t = "|") {
  return e.map((n) => v(n)).join(t);
}
a(p, "joinValues");
function ai(e, t) {
  return typeof t == "bigint" ? t.toString() : t;
}
a(ai, "jsonStringifyReplacer");
function ot(e) {
  return {
    get value() {
      {
        let n = e();
        return Object.defineProperty(this, "value", { value: n }), n;
      }
      throw new Error("cached value already set");
    }
  };
}
a(ot, "cached");
function ke(e) {
  return e == null;
}
a(ke, "nullish");
function Dt(e) {
  let t = e.startsWith("^") ? 1 : 0, n = e.endsWith("$") ? e.length - 1 : e.length;
  return e.slice(t, n);
}
a(Dt, "cleanRegex");
function si(e, t) {
  let n = (e.toString().split(".")[1] || "").length, o = t.toString(), r = (o.split(".")[1] || "").length;
  if (r === 0 && /\d?e-\d?/.test(o)) {
    let u = o.match(/\d?e-(\d?)/);
    u?.[1] && (r = Number.parseInt(u[1]));
  }
  let i = n > r ? n : r, s = Number.parseInt(e.toFixed(i).replace(".", "")), c = Number.parseInt(t.toFixed(i).replace(".", ""));
  return s % c / 10 ** i;
}
a(si, "floatSafeRemainder");
var ul = Symbol("evaluating");
function I(e, t, n) {
  let o;
  Object.defineProperty(e, t, {
    get() {
      if (o !== ul)
        return o === void 0 && (o = ul, o = n()), o;
    },
    set(r) {
      Object.defineProperty(e, t, {
        value: r
        // configurable: true,
      });
    },
    configurable: !0
  });
}
a(I, "defineLazy");
function gm(e) {
  return Object.create(Object.getPrototypeOf(e), Object.getOwnPropertyDescriptors(e));
}
a(gm, "objectClone");
function ze(e, t, n) {
  Object.defineProperty(e, t, {
    value: n,
    writable: !0,
    enumerable: !0,
    configurable: !0
  });
}
a(ze, "assignProp");
function xe(...e) {
  let t = {};
  for (let n of e) {
    let o = Object.getOwnPropertyDescriptors(n);
    Object.assign(t, o);
  }
  return Object.defineProperties({}, t);
}
a(xe, "mergeDefs");
function hm(e) {
  return xe(e._zod.def);
}
a(hm, "cloneDef");
function vm(e, t) {
  return t ? t.reduce((n, o) => n?.[o], e) : e;
}
a(vm, "getElementAtPath");
function ym(e) {
  let t = Object.keys(e), n = t.map((o) => e[o]);
  return Promise.all(n).then((o) => {
    let r = {};
    for (let i = 0; i < t.length; i++)
      r[t[i]] = o[i];
    return r;
  });
}
a(ym, "promiseAllObject");
function bm(e = 10) {
  let t = "abcdefghijklmnopqrstuvwxyz", n = "";
  for (let o = 0; o < e; o++)
    n += t[Math.floor(Math.random() * t.length)];
  return n;
}
a(bm, "randomString");
function jr(e) {
  return JSON.stringify(e);
}
a(jr, "esc");
function ci(e) {
  return e.toLowerCase().trim().replace(/[^\w\s-]/g, "").replace(/[\s_-]+/g, "-").replace(/^-+|-+$/g, "");
}
a(ci, "slugify");
var Or = "captureStackTrace" in Error ? Error.captureStackTrace : (...e) => {
};
function Ve(e) {
  return typeof e == "object" && e !== null && !Array.isArray(e);
}
a(Ve, "isObject");
var ui = ot(() => {
  if (typeof navigator < "u" && navigator?.userAgent?.includes("Cloudflare"))
    return !1;
  try {
    let e = Function;
    return new e(""), !0;
  } catch {
    return !1;
  }
});
function Ie(e) {
  if (Ve(e) === !1)
    return !1;
  let t = e.constructor;
  if (t === void 0 || typeof t != "function")
    return !0;
  let n = t.prototype;
  return !(Ve(n) === !1 || Object.prototype.hasOwnProperty.call(n, "isPrototypeOf") === !1);
}
a(Ie, "isPlainObject");
function at(e) {
  return Ie(e) ? { ...e } : Array.isArray(e) ? [...e] : e;
}
a(at, "shallowClone");
function xm(e) {
  let t = 0;
  for (let n in e)
    Object.prototype.hasOwnProperty.call(e, n) && t++;
  return t;
}
a(xm, "numKeys");
var $m = /* @__PURE__ */ a((e) => {
  let t = typeof e;
  switch (t) {
    case "undefined":
      return "undefined";
    case "string":
      return "string";
    case "number":
      return Number.isNaN(e) ? "nan" : "number";
    case "boolean":
      return "boolean";
    case "function":
      return "function";
    case "bigint":
      return "bigint";
    case "symbol":
      return "symbol";
    case "object":
      return Array.isArray(e) ? "array" : e === null ? "null" : e.then && typeof e.then == "function" && e.catch && typeof e.catch == "function" ? "promise" : typeof Map < "u" && e instanceof Map ? "map" : typeof Set < "u" && e instanceof Set ? "set" : typeof Date < "u" && e instanceof Date ? "date" : typeof File < "u" && e instanceof File ? "file" : "object";
    default:
      throw new Error(`Unknown data type: ${t}`);
  }
}, "getParsedType"), Et = /* @__PURE__ */ new Set(["string", "number", "symbol"]), li = /* @__PURE__ */ new Set(["string", "number", "bigint", "boolean", "symbol", "undefined"]);
function ue(e) {
  return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
a(ue, "escapeRegex");
function V(e, t, n) {
  let o = new e._zod.constr(t ?? e._zod.def);
  return (!t || n?.parent) && (o._zod.parent = e), o;
}
a(V, "clone");
function h(e) {
  let t = e;
  if (!t)
    return {};
  if (typeof t == "string")
    return { error: /* @__PURE__ */ a(() => t, "error") };
  if (t?.message !== void 0) {
    if (t?.error !== void 0)
      throw new Error("Cannot specify both `message` and `error` params");
    t.error = t.message;
  }
  return delete t.message, typeof t.error == "string" ? { ...t, error: /* @__PURE__ */ a(() => t.error, "error") } : t;
}
a(h, "normalizeParams");
function _m(e) {
  let t;
  return new Proxy({}, {
    get(n, o, r) {
      return t ?? (t = e()), Reflect.get(t, o, r);
    },
    set(n, o, r, i) {
      return t ?? (t = e()), Reflect.set(t, o, r, i);
    },
    has(n, o) {
      return t ?? (t = e()), Reflect.has(t, o);
    },
    deleteProperty(n, o) {
      return t ?? (t = e()), Reflect.deleteProperty(t, o);
    },
    ownKeys(n) {
      return t ?? (t = e()), Reflect.ownKeys(t);
    },
    getOwnPropertyDescriptor(n, o) {
      return t ?? (t = e()), Reflect.getOwnPropertyDescriptor(t, o);
    },
    defineProperty(n, o, r) {
      return t ?? (t = e()), Reflect.defineProperty(t, o, r);
    }
  });
}
a(_m, "createTransparentProxy");
function v(e) {
  return typeof e == "bigint" ? e.toString() + "n" : typeof e == "string" ? `"${e}"` : `${e}`;
}
a(v, "stringifyPrimitive");
function di(e) {
  return Object.keys(e).filter((t) => e[t]._zod.optin === "optional" && e[t]._zod.optout === "optional");
}
a(di, "optionalKeys");
var fi = {
  safeint: [Number.MIN_SAFE_INTEGER, Number.MAX_SAFE_INTEGER],
  int32: [-2147483648, 2147483647],
  uint32: [0, 4294967295],
  float32: [-34028234663852886e22, 34028234663852886e22],
  float64: [-Number.MAX_VALUE, Number.MAX_VALUE]
}, pi = {
  int64: [/* @__PURE__ */ BigInt("-9223372036854775808"), /* @__PURE__ */ BigInt("9223372036854775807")],
  uint64: [/* @__PURE__ */ BigInt(0), /* @__PURE__ */ BigInt("18446744073709551615")]
};
function mi(e, t) {
  let n = e._zod.def, o = n.checks;
  if (o && o.length > 0)
    throw new Error(".pick() cannot be used on object schemas containing refinements");
  let i = xe(e._zod.def, {
    get shape() {
      let s = {};
      for (let c in t) {
        if (!(c in n.shape))
          throw new Error(`Unrecognized key: "${c}"`);
        t[c] && (s[c] = n.shape[c]);
      }
      return ze(this, "shape", s), s;
    },
    checks: []
  });
  return V(e, i);
}
a(mi, "pick");
function gi(e, t) {
  let n = e._zod.def, o = n.checks;
  if (o && o.length > 0)
    throw new Error(".omit() cannot be used on object schemas containing refinements");
  let i = xe(e._zod.def, {
    get shape() {
      let s = { ...e._zod.def.shape };
      for (let c in t) {
        if (!(c in n.shape))
          throw new Error(`Unrecognized key: "${c}"`);
        t[c] && delete s[c];
      }
      return ze(this, "shape", s), s;
    },
    checks: []
  });
  return V(e, i);
}
a(gi, "omit");
function Tr(e, t) {
  if (!Ie(t))
    throw new Error("Invalid input to extend: expected a plain object");
  let n = e._zod.def.checks;
  if (n && n.length > 0) {
    let i = e._zod.def.shape;
    for (let s in t)
      if (Object.getOwnPropertyDescriptor(i, s) !== void 0)
        throw new Error("Cannot overwrite keys on object schemas containing refinements. Use `.safeExtend()` instead.");
  }
  let r = xe(e._zod.def, {
    get shape() {
      let i = { ...e._zod.def.shape, ...t };
      return ze(this, "shape", i), i;
    }
  });
  return V(e, r);
}
a(Tr, "extend");
function hi(e, t) {
  if (!Ie(t))
    throw new Error("Invalid input to safeExtend: expected a plain object");
  let n = xe(e._zod.def, {
    get shape() {
      let o = { ...e._zod.def.shape, ...t };
      return ze(this, "shape", o), o;
    }
  });
  return V(e, n);
}
a(hi, "safeExtend");
function wm(e, t) {
  let n = xe(e._zod.def, {
    get shape() {
      let o = { ...e._zod.def.shape, ...t._zod.def.shape };
      return ze(this, "shape", o), o;
    },
    get catchall() {
      return t._zod.def.catchall;
    },
    checks: []
    // delete existing checks
  });
  return V(e, n);
}
a(wm, "merge");
function vi(e, t, n) {
  let r = t._zod.def.checks;
  if (r && r.length > 0)
    throw new Error(".partial() cannot be used on object schemas containing refinements");
  let s = xe(t._zod.def, {
    get shape() {
      let c = t._zod.def.shape, u = { ...c };
      if (n)
        for (let l in n) {
          if (!(l in c))
            throw new Error(`Unrecognized key: "${l}"`);
          n[l] && (u[l] = e ? new e({
            type: "optional",
            innerType: c[l]
          }) : c[l]);
        }
      else
        for (let l in c)
          u[l] = e ? new e({
            type: "optional",
            innerType: c[l]
          }) : c[l];
      return ze(this, "shape", u), u;
    },
    checks: []
  });
  return V(t, s);
}
a(vi, "partial");
function yi(e, t, n) {
  let o = xe(t._zod.def, {
    get shape() {
      let r = t._zod.def.shape, i = { ...r };
      if (n)
        for (let s in n) {
          if (!(s in i))
            throw new Error(`Unrecognized key: "${s}"`);
          n[s] && (i[s] = new e({
            type: "nonoptional",
            innerType: r[s]
          }));
        }
      else
        for (let s in r)
          i[s] = new e({
            type: "nonoptional",
            innerType: r[s]
          });
      return ze(this, "shape", i), i;
    }
  });
  return V(t, o);
}
a(yi, "required");
function Se(e, t = 0) {
  if (e.aborted === !0)
    return !0;
  for (let n = t; n < e.issues.length; n++)
    if (e.issues[n]?.continue !== !0)
      return !0;
  return !1;
}
a(Se, "aborted");
function oe(e, t) {
  return t.map((n) => {
    var o;
    return (o = n).path ?? (o.path = []), n.path.unshift(e), n;
  });
}
a(oe, "prefixIssues");
function Pt(e) {
  return typeof e == "string" ? e : e?.message;
}
a(Pt, "unwrapMessage");
function te(e, t, n) {
  let o = { ...e, path: e.path ?? [] };
  if (!e.message) {
    let r = Pt(e.inst?._zod.def?.error?.(e)) ?? Pt(t?.error?.(e)) ?? Pt(n.customError?.(e)) ?? Pt(n.localeError?.(e)) ?? "Invalid input";
    o.message = r;
  }
  return delete o.inst, delete o.continue, t?.reportInput || delete o.input, o;
}
a(te, "finalizeIssue");
function Zt(e) {
  return e instanceof Set ? "set" : e instanceof Map ? "map" : e instanceof File ? "file" : "unknown";
}
a(Zt, "getSizableOrigin");
function Nt(e) {
  return Array.isArray(e) ? "array" : typeof e == "string" ? "string" : "unknown";
}
a(Nt, "getLengthableOrigin");
function y(e) {
  let t = typeof e;
  switch (t) {
    case "number":
      return Number.isNaN(e) ? "nan" : "number";
    case "object": {
      if (e === null)
        return "null";
      if (Array.isArray(e))
        return "array";
      let n = e;
      if (n && Object.getPrototypeOf(n) !== Object.prototype && "constructor" in n && n.constructor)
        return n.constructor.name;
    }
  }
  return t;
}
a(y, "parsedType");
function st(...e) {
  let [t, n, o] = e;
  return typeof t == "string" ? {
    message: t,
    code: "custom",
    input: n,
    inst: o
  } : { ...t };
}
a(st, "issue");
function km(e) {
  return Object.entries(e).filter(([t, n]) => Number.isNaN(Number.parseInt(t, 10))).map((t) => t[1]);
}
a(km, "cleanEnum");
function ll(e) {
  let t = atob(e), n = new Uint8Array(t.length);
  for (let o = 0; o < t.length; o++)
    n[o] = t.charCodeAt(o);
  return n;
}
a(ll, "base64ToUint8Array");
function dl(e) {
  let t = "";
  for (let n = 0; n < e.length; n++)
    t += String.fromCharCode(e[n]);
  return btoa(t);
}
a(dl, "uint8ArrayToBase64");
function zm(e) {
  let t = e.replace(/-/g, "+").replace(/_/g, "/"), n = "=".repeat((4 - t.length % 4) % 4);
  return ll(t + n);
}
a(zm, "base64urlToUint8Array");
function Im(e) {
  return dl(e).replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, "");
}
a(Im, "uint8ArrayToBase64url");
function Sm(e) {
  let t = e.replace(/^0x/, "");
  if (t.length % 2 !== 0)
    throw new Error("Invalid hex string length");
  let n = new Uint8Array(t.length / 2);
  for (let o = 0; o < t.length; o += 2)
    n[o / 2] = Number.parseInt(t.slice(o, o + 2), 16);
  return n;
}
a(Sm, "hexToUint8Array");
function jm(e) {
  return Array.from(e).map((t) => t.toString(16).padStart(2, "0")).join("");
}
a(jm, "uint8ArrayToHex");
var oi = class {
  static {
    a(this, "Class");
  }
  constructor(...t) {
  }
};

// versions/4.3.6/node_modules/zod/v4/core/errors.js
var fl = /* @__PURE__ */ a((e, t) => {
  e.name = "$ZodError", Object.defineProperty(e, "_zod", {
    value: e._zod,
    enumerable: !1
  }), Object.defineProperty(e, "issues", {
    value: t,
    enumerable: !1
  }), e.message = JSON.stringify(t, ai, 2), Object.defineProperty(e, "toString", {
    value: /* @__PURE__ */ a(() => e.message, "value"),
    enumerable: !1
  });
}, "initializer"), $e = f("$ZodError", fl), re = f("$ZodError", fl, { Parent: Error });
function bi(e, t = (n) => n.message) {
  let n = {}, o = [];
  for (let r of e.issues)
    r.path.length > 0 ? (n[r.path[0]] = n[r.path[0]] || [], n[r.path[0]].push(t(r))) : o.push(t(r));
  return { formErrors: o, fieldErrors: n };
}
a(bi, "flattenError");
function xi(e, t = (n) => n.message) {
  let n = { _errors: [] }, o = /* @__PURE__ */ a((r) => {
    for (let i of r.issues)
      if (i.code === "invalid_union" && i.errors.length)
        i.errors.map((s) => o({ issues: s }));
      else if (i.code === "invalid_key")
        o({ issues: i.issues });
      else if (i.code === "invalid_element")
        o({ issues: i.issues });
      else if (i.path.length === 0)
        n._errors.push(t(i));
      else {
        let s = n, c = 0;
        for (; c < i.path.length; ) {
          let u = i.path[c];
          c === i.path.length - 1 ? (s[u] = s[u] || { _errors: [] }, s[u]._errors.push(t(i))) : s[u] = s[u] || { _errors: [] }, s = s[u], c++;
        }
      }
  }, "processError");
  return o(e), n;
}
a(xi, "formatError");
function $i(e, t = (n) => n.message) {
  let n = { errors: [] }, o = /* @__PURE__ */ a((r, i = []) => {
    var s, c;
    for (let u of r.issues)
      if (u.code === "invalid_union" && u.errors.length)
        u.errors.map((l) => o({ issues: l }, u.path));
      else if (u.code === "invalid_key")
        o({ issues: u.issues }, u.path);
      else if (u.code === "invalid_element")
        o({ issues: u.issues }, u.path);
      else {
        let l = [...i, ...u.path];
        if (l.length === 0) {
          n.errors.push(t(u));
          continue;
        }
        let d = n, g = 0;
        for (; g < l.length; ) {
          let b = l[g], x = g === l.length - 1;
          typeof b == "string" ? (d.properties ?? (d.properties = {}), (s = d.properties)[b] ?? (s[b] = { errors: [] }), d = d.properties[b]) : (d.items ?? (d.items = []), (c = d.items)[b] ?? (c[b] = { errors: [] }), d = d.items[b]), x && d.errors.push(t(u)), g++;
        }
      }
  }, "processError");
  return o(e), n;
}
a($i, "treeifyError");
function pl(e) {
  let t = [], n = e.map((o) => typeof o == "object" ? o.key : o);
  for (let o of n)
    typeof o == "number" ? t.push(`[${o}]`) : typeof o == "symbol" ? t.push(`[${JSON.stringify(String(o))}]`) : /[^\w$]/.test(o) ? t.push(`[${JSON.stringify(o)}]`) : (t.length && t.push("."), t.push(o));
  return t.join("");
}
a(pl, "toDotPath");
function _i(e) {
  let t = [], n = [...e.issues].sort((o, r) => (o.path ?? []).length - (r.path ?? []).length);
  for (let o of n)
    t.push(`\u2716 ${o.message}`), o.path?.length && t.push(`  \u2192 at ${pl(o.path)}`);
  return t.join(`
`);
}
a(_i, "prettifyError");

// versions/4.3.6/node_modules/zod/v4/core/parse.js
var Pr = /* @__PURE__ */ a((e) => (t, n, o, r) => {
  let i = o ? Object.assign(o, { async: !1 }) : { async: !1 }, s = t._zod.run({ value: n, issues: [] }, i);
  if (s instanceof Promise)
    throw new pe();
  if (s.issues.length) {
    let c = new (r?.Err ?? e)(s.issues.map((u) => te(u, i, X())));
    throw Or(c, r?.callee), c;
  }
  return s.value;
}, "_parse"), ne = /* @__PURE__ */ Pr(re), Ur = /* @__PURE__ */ a((e) => async (t, n, o, r) => {
  let i = o ? Object.assign(o, { async: !0 }) : { async: !0 }, s = t._zod.run({ value: n, issues: [] }, i);
  if (s instanceof Promise && (s = await s), s.issues.length) {
    let c = new (r?.Err ?? e)(s.issues.map((u) => te(u, i, X())));
    throw Or(c, r?.callee), c;
  }
  return s.value;
}, "_parseAsync"), je = /* @__PURE__ */ Ur(re), Dr = /* @__PURE__ */ a((e) => (t, n, o) => {
  let r = o ? { ...o, async: !1 } : { async: !1 }, i = t._zod.run({ value: n, issues: [] }, r);
  if (i instanceof Promise)
    throw new pe();
  return i.issues.length ? {
    success: !1,
    error: new (e ?? $e)(i.issues.map((s) => te(s, r, X())))
  } : { success: !0, data: i.value };
}, "_safeParse"), me = /* @__PURE__ */ Dr(re), Er = /* @__PURE__ */ a((e) => async (t, n, o) => {
  let r = o ? Object.assign(o, { async: !0 }) : { async: !0 }, i = t._zod.run({ value: n, issues: [] }, r);
  return i instanceof Promise && (i = await i), i.issues.length ? {
    success: !1,
    error: new e(i.issues.map((s) => te(s, r, X())))
  } : { success: !0, data: i.value };
}, "_safeParseAsync"), qe = /* @__PURE__ */ Er(re), ml = /* @__PURE__ */ a((e) => (t, n, o) => {
  let r = o ? Object.assign(o, { direction: "backward" }) : { direction: "backward" };
  return Pr(e)(t, n, r);
}, "_encode"), Q = /* @__PURE__ */ ml(re), gl = /* @__PURE__ */ a((e) => (t, n, o) => Pr(e)(t, n, o), "_decode"), wi = /* @__PURE__ */ gl(re), hl = /* @__PURE__ */ a((e) => async (t, n, o) => {
  let r = o ? Object.assign(o, { direction: "backward" }) : { direction: "backward" };
  return Ur(e)(t, n, r);
}, "_encodeAsync"), ki = /* @__PURE__ */ hl(re), vl = /* @__PURE__ */ a((e) => async (t, n, o) => Ur(e)(t, n, o), "_decodeAsync"), zi = /* @__PURE__ */ vl(re), yl = /* @__PURE__ */ a((e) => (t, n, o) => {
  let r = o ? Object.assign(o, { direction: "backward" }) : { direction: "backward" };
  return Dr(e)(t, n, r);
}, "_safeEncode"), Ii = /* @__PURE__ */ yl(re), bl = /* @__PURE__ */ a((e) => (t, n, o) => Dr(e)(t, n, o), "_safeDecode"), Si = /* @__PURE__ */ bl(re), xl = /* @__PURE__ */ a((e) => async (t, n, o) => {
  let r = o ? Object.assign(o, { direction: "backward" }) : { direction: "backward" };
  return Er(e)(t, n, r);
}, "_safeEncodeAsync"), ji = /* @__PURE__ */ xl(re), $l = /* @__PURE__ */ a((e) => async (t, n, o) => Er(e)(t, n, o), "_safeDecodeAsync"), Oi = /* @__PURE__ */ $l(re);

// versions/4.3.6/node_modules/zod/v4/core/regexes.js
var le = {};
Ce(le, {
  base64: () => qi,
  base64url: () => Zr,
  bigint: () => Hi,
  boolean: () => Yi,
  browserEmail: () => Am,
  cidrv4: () => Bi,
  cidrv6: () => Vi,
  cuid: () => Ti,
  cuid2: () => Pi,
  date: () => Wi,
  datetime: () => Gi,
  domain: () => Fm,
  duration: () => Ni,
  e164: () => Ji,
  email: () => Ci,
  emoji: () => Ri,
  extendedDuration: () => Tm,
  guid: () => Ai,
  hex: () => Mm,
  hostname: () => Rm,
  html5Email: () => Em,
  idnEmail: () => Nm,
  integer: () => Qi,
  ipv4: () => Fi,
  ipv6: () => Mi,
  ksuid: () => Ei,
  lowercase: () => ro,
  mac: () => Li,
  md5_base64: () => Bm,
  md5_base64url: () => Vm,
  md5_hex: () => Lm,
  nanoid: () => Zi,
  null: () => eo,
  number: () => Nr,
  rfc5322Email: () => Zm,
  sha1_base64: () => Jm,
  sha1_base64url: () => Wm,
  sha1_hex: () => qm,
  sha256_base64: () => Gm,
  sha256_base64url: () => Xm,
  sha256_hex: () => Km,
  sha384_base64: () => Qm,
  sha384_base64url: () => Ym,
  sha384_hex: () => Hm,
  sha512_base64: () => tg,
  sha512_base64url: () => rg,
  sha512_hex: () => eg,
  string: () => Xi,
  time: () => Ki,
  ulid: () => Ui,
  undefined: () => to,
  unicodeEmail: () => _l,
  uppercase: () => no,
  uuid: () => Je,
  uuid4: () => Pm,
  uuid6: () => Um,
  uuid7: () => Dm,
  xid: () => Di
});
var Ti = /^[cC][^\s-]{8,}$/, Pi = /^[0-9a-z]+$/, Ui = /^[0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{26}$/, Di = /^[0-9a-vA-V]{20}$/, Ei = /^[A-Za-z0-9]{27}$/, Zi = /^[a-zA-Z0-9_-]{21}$/, Ni = /^P(?:(\d+W)|(?!.*W)(?=\d|T\d)(\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+([.,]\d+)?S)?)?)$/, Tm = /^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/, Ai = /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/, Je = /* @__PURE__ */ a((e) => e ? new RegExp(`^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${e}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`) : /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/, "uuid"), Pm = /* @__PURE__ */ Je(4), Um = /* @__PURE__ */ Je(6), Dm = /* @__PURE__ */ Je(7), Ci = /^(?!\.)(?!.*\.\.)([A-Za-z0-9_'+\-\.]*)[A-Za-z0-9_+-]@([A-Za-z0-9][A-Za-z0-9\-]*\.)+[A-Za-z]{2,}$/, Em = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/, Zm = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/, _l = /^[^\s@"]{1,64}@[^\s@]{1,255}$/u, Nm = _l, Am = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/, Cm = "^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$";
function Ri() {
  return new RegExp(Cm, "u");
}
a(Ri, "emoji");
var Fi = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/, Mi = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))$/, Li = /* @__PURE__ */ a((e) => {
  let t = ue(e ?? ":");
  return new RegExp(`^(?:[0-9A-F]{2}${t}){5}[0-9A-F]{2}$|^(?:[0-9a-f]{2}${t}){5}[0-9a-f]{2}$`);
}, "mac"), Bi = /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/([0-9]|[1-2][0-9]|3[0-2])$/, Vi = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|::|([0-9a-fA-F]{1,4})?::([0-9a-fA-F]{1,4}:?){0,6})\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/, qi = /^$|^(?:[0-9a-zA-Z+/]{4})*(?:(?:[0-9a-zA-Z+/]{2}==)|(?:[0-9a-zA-Z+/]{3}=))?$/, Zr = /^[A-Za-z0-9_-]*$/, Rm = /^(?=.{1,253}\.?$)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[-0-9a-zA-Z]{0,61}[0-9a-zA-Z])?)*\.?$/, Fm = /^([a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$/, Ji = /^\+[1-9]\d{6,14}$/, wl = "(?:(?:\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-(?:(?:0[13578]|1[02])-(?:0[1-9]|[12]\\d|3[01])|(?:0[469]|11)-(?:0[1-9]|[12]\\d|30)|(?:02)-(?:0[1-9]|1\\d|2[0-8])))", Wi = /* @__PURE__ */ new RegExp(`^${wl}$`);
function kl(e) {
  let t = "(?:[01]\\d|2[0-3]):[0-5]\\d";
  return typeof e.precision == "number" ? e.precision === -1 ? `${t}` : e.precision === 0 ? `${t}:[0-5]\\d` : `${t}:[0-5]\\d\\.\\d{${e.precision}}` : `${t}(?::[0-5]\\d(?:\\.\\d+)?)?`;
}
a(kl, "timeSource");
function Ki(e) {
  return new RegExp(`^${kl(e)}$`);
}
a(Ki, "time");
function Gi(e) {
  let t = kl({ precision: e.precision }), n = ["Z"];
  e.local && n.push(""), e.offset && n.push("([+-](?:[01]\\d|2[0-3]):[0-5]\\d)");
  let o = `${t}(?:${n.join("|")})`;
  return new RegExp(`^${wl}T(?:${o})$`);
}
a(Gi, "datetime");
var Xi = /* @__PURE__ */ a((e) => {
  let t = e ? `[\\s\\S]{${e?.minimum ?? 0},${e?.maximum ?? ""}}` : "[\\s\\S]*";
  return new RegExp(`^${t}$`);
}, "string"), Hi = /^-?\d+n?$/, Qi = /^-?\d+$/, Nr = /^-?\d+(?:\.\d+)?$/, Yi = /^(?:true|false)$/i, eo = /^null$/i;
var to = /^undefined$/i;
var ro = /^[^A-Z]*$/, no = /^[^a-z]*$/, Mm = /^[0-9a-fA-F]*$/;
function At(e, t) {
  return new RegExp(`^[A-Za-z0-9+/]{${e}}${t}$`);
}
a(At, "fixedBase64");
function Ct(e) {
  return new RegExp(`^[A-Za-z0-9_-]{${e}}$`);
}
a(Ct, "fixedBase64url");
var Lm = /^[0-9a-fA-F]{32}$/, Bm = /* @__PURE__ */ At(22, "=="), Vm = /* @__PURE__ */ Ct(22), qm = /^[0-9a-fA-F]{40}$/, Jm = /* @__PURE__ */ At(27, "="), Wm = /* @__PURE__ */ Ct(27), Km = /^[0-9a-fA-F]{64}$/, Gm = /* @__PURE__ */ At(43, "="), Xm = /* @__PURE__ */ Ct(43), Hm = /^[0-9a-fA-F]{96}$/, Qm = /* @__PURE__ */ At(64, ""), Ym = /* @__PURE__ */ Ct(64), eg = /^[0-9a-fA-F]{128}$/, tg = /* @__PURE__ */ At(86, "=="), rg = /* @__PURE__ */ Ct(86);

// versions/4.3.6/node_modules/zod/v4/core/checks.js
var N = /* @__PURE__ */ f("$ZodCheck", (e, t) => {
  var n;
  e._zod ?? (e._zod = {}), e._zod.def = t, (n = e._zod).onattach ?? (n.onattach = []);
}), Il = {
  number: "number",
  bigint: "bigint",
  object: "date"
}, Ar = /* @__PURE__ */ f("$ZodCheckLessThan", (e, t) => {
  N.init(e, t);
  let n = Il[typeof t.value];
  e._zod.onattach.push((o) => {
    let r = o._zod.bag, i = (t.inclusive ? r.maximum : r.exclusiveMaximum) ?? Number.POSITIVE_INFINITY;
    t.value < i && (t.inclusive ? r.maximum = t.value : r.exclusiveMaximum = t.value);
  }), e._zod.check = (o) => {
    (t.inclusive ? o.value <= t.value : o.value < t.value) || o.issues.push({
      origin: n,
      code: "too_big",
      maximum: typeof t.value == "object" ? t.value.getTime() : t.value,
      input: o.value,
      inclusive: t.inclusive,
      inst: e,
      continue: !t.abort
    });
  };
}), Cr = /* @__PURE__ */ f("$ZodCheckGreaterThan", (e, t) => {
  N.init(e, t);
  let n = Il[typeof t.value];
  e._zod.onattach.push((o) => {
    let r = o._zod.bag, i = (t.inclusive ? r.minimum : r.exclusiveMinimum) ?? Number.NEGATIVE_INFINITY;
    t.value > i && (t.inclusive ? r.minimum = t.value : r.exclusiveMinimum = t.value);
  }), e._zod.check = (o) => {
    (t.inclusive ? o.value >= t.value : o.value > t.value) || o.issues.push({
      origin: n,
      code: "too_small",
      minimum: typeof t.value == "object" ? t.value.getTime() : t.value,
      input: o.value,
      inclusive: t.inclusive,
      inst: e,
      continue: !t.abort
    });
  };
}), io = /* @__PURE__ */ f("$ZodCheckMultipleOf", (e, t) => {
  N.init(e, t), e._zod.onattach.push((n) => {
    var o;
    (o = n._zod.bag).multipleOf ?? (o.multipleOf = t.value);
  }), e._zod.check = (n) => {
    if (typeof n.value != typeof t.value)
      throw new Error("Cannot mix number and bigint in multiple_of check.");
    (typeof n.value == "bigint" ? n.value % t.value === BigInt(0) : si(n.value, t.value) === 0) || n.issues.push({
      origin: typeof n.value,
      code: "not_multiple_of",
      divisor: t.value,
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), oo = /* @__PURE__ */ f("$ZodCheckNumberFormat", (e, t) => {
  N.init(e, t), t.format = t.format || "float64";
  let n = t.format?.includes("int"), o = n ? "int" : "number", [r, i] = fi[t.format];
  e._zod.onattach.push((s) => {
    let c = s._zod.bag;
    c.format = t.format, c.minimum = r, c.maximum = i, n && (c.pattern = Qi);
  }), e._zod.check = (s) => {
    let c = s.value;
    if (n) {
      if (!Number.isInteger(c)) {
        s.issues.push({
          expected: o,
          format: t.format,
          code: "invalid_type",
          continue: !1,
          input: c,
          inst: e
        });
        return;
      }
      if (!Number.isSafeInteger(c)) {
        c > 0 ? s.issues.push({
          input: c,
          code: "too_big",
          maximum: Number.MAX_SAFE_INTEGER,
          note: "Integers must be within the safe integer range.",
          inst: e,
          origin: o,
          inclusive: !0,
          continue: !t.abort
        }) : s.issues.push({
          input: c,
          code: "too_small",
          minimum: Number.MIN_SAFE_INTEGER,
          note: "Integers must be within the safe integer range.",
          inst: e,
          origin: o,
          inclusive: !0,
          continue: !t.abort
        });
        return;
      }
    }
    c < r && s.issues.push({
      origin: "number",
      input: c,
      code: "too_small",
      minimum: r,
      inclusive: !0,
      inst: e,
      continue: !t.abort
    }), c > i && s.issues.push({
      origin: "number",
      input: c,
      code: "too_big",
      maximum: i,
      inclusive: !0,
      inst: e,
      continue: !t.abort
    });
  };
}), ao = /* @__PURE__ */ f("$ZodCheckBigIntFormat", (e, t) => {
  N.init(e, t);
  let [n, o] = pi[t.format];
  e._zod.onattach.push((r) => {
    let i = r._zod.bag;
    i.format = t.format, i.minimum = n, i.maximum = o;
  }), e._zod.check = (r) => {
    let i = r.value;
    i < n && r.issues.push({
      origin: "bigint",
      input: i,
      code: "too_small",
      minimum: n,
      inclusive: !0,
      inst: e,
      continue: !t.abort
    }), i > o && r.issues.push({
      origin: "bigint",
      input: i,
      code: "too_big",
      maximum: o,
      inclusive: !0,
      inst: e,
      continue: !t.abort
    });
  };
}), so = /* @__PURE__ */ f("$ZodCheckMaxSize", (e, t) => {
  var n;
  N.init(e, t), (n = e._zod.def).when ?? (n.when = (o) => {
    let r = o.value;
    return !ke(r) && r.size !== void 0;
  }), e._zod.onattach.push((o) => {
    let r = o._zod.bag.maximum ?? Number.POSITIVE_INFINITY;
    t.maximum < r && (o._zod.bag.maximum = t.maximum);
  }), e._zod.check = (o) => {
    let r = o.value;
    r.size <= t.maximum || o.issues.push({
      origin: Zt(r),
      code: "too_big",
      maximum: t.maximum,
      inclusive: !0,
      input: r,
      inst: e,
      continue: !t.abort
    });
  };
}), co = /* @__PURE__ */ f("$ZodCheckMinSize", (e, t) => {
  var n;
  N.init(e, t), (n = e._zod.def).when ?? (n.when = (o) => {
    let r = o.value;
    return !ke(r) && r.size !== void 0;
  }), e._zod.onattach.push((o) => {
    let r = o._zod.bag.minimum ?? Number.NEGATIVE_INFINITY;
    t.minimum > r && (o._zod.bag.minimum = t.minimum);
  }), e._zod.check = (o) => {
    let r = o.value;
    r.size >= t.minimum || o.issues.push({
      origin: Zt(r),
      code: "too_small",
      minimum: t.minimum,
      inclusive: !0,
      input: r,
      inst: e,
      continue: !t.abort
    });
  };
}), uo = /* @__PURE__ */ f("$ZodCheckSizeEquals", (e, t) => {
  var n;
  N.init(e, t), (n = e._zod.def).when ?? (n.when = (o) => {
    let r = o.value;
    return !ke(r) && r.size !== void 0;
  }), e._zod.onattach.push((o) => {
    let r = o._zod.bag;
    r.minimum = t.size, r.maximum = t.size, r.size = t.size;
  }), e._zod.check = (o) => {
    let r = o.value, i = r.size;
    if (i === t.size)
      return;
    let s = i > t.size;
    o.issues.push({
      origin: Zt(r),
      ...s ? { code: "too_big", maximum: t.size } : { code: "too_small", minimum: t.size },
      inclusive: !0,
      exact: !0,
      input: o.value,
      inst: e,
      continue: !t.abort
    });
  };
}), lo = /* @__PURE__ */ f("$ZodCheckMaxLength", (e, t) => {
  var n;
  N.init(e, t), (n = e._zod.def).when ?? (n.when = (o) => {
    let r = o.value;
    return !ke(r) && r.length !== void 0;
  }), e._zod.onattach.push((o) => {
    let r = o._zod.bag.maximum ?? Number.POSITIVE_INFINITY;
    t.maximum < r && (o._zod.bag.maximum = t.maximum);
  }), e._zod.check = (o) => {
    let r = o.value;
    if (r.length <= t.maximum)
      return;
    let s = Nt(r);
    o.issues.push({
      origin: s,
      code: "too_big",
      maximum: t.maximum,
      inclusive: !0,
      input: r,
      inst: e,
      continue: !t.abort
    });
  };
}), fo = /* @__PURE__ */ f("$ZodCheckMinLength", (e, t) => {
  var n;
  N.init(e, t), (n = e._zod.def).when ?? (n.when = (o) => {
    let r = o.value;
    return !ke(r) && r.length !== void 0;
  }), e._zod.onattach.push((o) => {
    let r = o._zod.bag.minimum ?? Number.NEGATIVE_INFINITY;
    t.minimum > r && (o._zod.bag.minimum = t.minimum);
  }), e._zod.check = (o) => {
    let r = o.value;
    if (r.length >= t.minimum)
      return;
    let s = Nt(r);
    o.issues.push({
      origin: s,
      code: "too_small",
      minimum: t.minimum,
      inclusive: !0,
      input: r,
      inst: e,
      continue: !t.abort
    });
  };
}), po = /* @__PURE__ */ f("$ZodCheckLengthEquals", (e, t) => {
  var n;
  N.init(e, t), (n = e._zod.def).when ?? (n.when = (o) => {
    let r = o.value;
    return !ke(r) && r.length !== void 0;
  }), e._zod.onattach.push((o) => {
    let r = o._zod.bag;
    r.minimum = t.length, r.maximum = t.length, r.length = t.length;
  }), e._zod.check = (o) => {
    let r = o.value, i = r.length;
    if (i === t.length)
      return;
    let s = Nt(r), c = i > t.length;
    o.issues.push({
      origin: s,
      ...c ? { code: "too_big", maximum: t.length } : { code: "too_small", minimum: t.length },
      inclusive: !0,
      exact: !0,
      input: o.value,
      inst: e,
      continue: !t.abort
    });
  };
}), ct = /* @__PURE__ */ f("$ZodCheckStringFormat", (e, t) => {
  var n, o;
  N.init(e, t), e._zod.onattach.push((r) => {
    let i = r._zod.bag;
    i.format = t.format, t.pattern && (i.patterns ?? (i.patterns = /* @__PURE__ */ new Set()), i.patterns.add(t.pattern));
  }), t.pattern ? (n = e._zod).check ?? (n.check = (r) => {
    t.pattern.lastIndex = 0, !t.pattern.test(r.value) && r.issues.push({
      origin: "string",
      code: "invalid_format",
      format: t.format,
      input: r.value,
      ...t.pattern ? { pattern: t.pattern.toString() } : {},
      inst: e,
      continue: !t.abort
    });
  }) : (o = e._zod).check ?? (o.check = () => {
  });
}), mo = /* @__PURE__ */ f("$ZodCheckRegex", (e, t) => {
  ct.init(e, t), e._zod.check = (n) => {
    t.pattern.lastIndex = 0, !t.pattern.test(n.value) && n.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "regex",
      input: n.value,
      pattern: t.pattern.toString(),
      inst: e,
      continue: !t.abort
    });
  };
}), go = /* @__PURE__ */ f("$ZodCheckLowerCase", (e, t) => {
  t.pattern ?? (t.pattern = ro), ct.init(e, t);
}), ho = /* @__PURE__ */ f("$ZodCheckUpperCase", (e, t) => {
  t.pattern ?? (t.pattern = no), ct.init(e, t);
}), vo = /* @__PURE__ */ f("$ZodCheckIncludes", (e, t) => {
  N.init(e, t);
  let n = ue(t.includes), o = new RegExp(typeof t.position == "number" ? `^.{${t.position}}${n}` : n);
  t.pattern = o, e._zod.onattach.push((r) => {
    let i = r._zod.bag;
    i.patterns ?? (i.patterns = /* @__PURE__ */ new Set()), i.patterns.add(o);
  }), e._zod.check = (r) => {
    r.value.includes(t.includes, t.position) || r.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "includes",
      includes: t.includes,
      input: r.value,
      inst: e,
      continue: !t.abort
    });
  };
}), yo = /* @__PURE__ */ f("$ZodCheckStartsWith", (e, t) => {
  N.init(e, t);
  let n = new RegExp(`^${ue(t.prefix)}.*`);
  t.pattern ?? (t.pattern = n), e._zod.onattach.push((o) => {
    let r = o._zod.bag;
    r.patterns ?? (r.patterns = /* @__PURE__ */ new Set()), r.patterns.add(n);
  }), e._zod.check = (o) => {
    o.value.startsWith(t.prefix) || o.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "starts_with",
      prefix: t.prefix,
      input: o.value,
      inst: e,
      continue: !t.abort
    });
  };
}), bo = /* @__PURE__ */ f("$ZodCheckEndsWith", (e, t) => {
  N.init(e, t);
  let n = new RegExp(`.*${ue(t.suffix)}$`);
  t.pattern ?? (t.pattern = n), e._zod.onattach.push((o) => {
    let r = o._zod.bag;
    r.patterns ?? (r.patterns = /* @__PURE__ */ new Set()), r.patterns.add(n);
  }), e._zod.check = (o) => {
    o.value.endsWith(t.suffix) || o.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "ends_with",
      suffix: t.suffix,
      input: o.value,
      inst: e,
      continue: !t.abort
    });
  };
});
function zl(e, t, n) {
  e.issues.length && t.issues.push(...oe(n, e.issues));
}
a(zl, "handleCheckPropertyResult");
var xo = /* @__PURE__ */ f("$ZodCheckProperty", (e, t) => {
  N.init(e, t), e._zod.check = (n) => {
    let o = t.schema._zod.run({
      value: n.value[t.property],
      issues: []
    }, {});
    if (o instanceof Promise)
      return o.then((r) => zl(r, n, t.property));
    zl(o, n, t.property);
  };
}), $o = /* @__PURE__ */ f("$ZodCheckMimeType", (e, t) => {
  N.init(e, t);
  let n = new Set(t.mime);
  e._zod.onattach.push((o) => {
    o._zod.bag.mime = t.mime;
  }), e._zod.check = (o) => {
    n.has(o.value.type) || o.issues.push({
      code: "invalid_value",
      values: t.mime,
      input: o.value.type,
      inst: e,
      continue: !t.abort
    });
  };
}), _o = /* @__PURE__ */ f("$ZodCheckOverwrite", (e, t) => {
  N.init(e, t), e._zod.check = (n) => {
    n.value = t.tx(n.value);
  };
});

// versions/4.3.6/node_modules/zod/v4/core/doc.js
var Rt = class {
  static {
    a(this, "Doc");
  }
  constructor(t = []) {
    this.content = [], this.indent = 0, this && (this.args = t);
  }
  indented(t) {
    this.indent += 1, t(this), this.indent -= 1;
  }
  write(t) {
    if (typeof t == "function") {
      t(this, { execution: "sync" }), t(this, { execution: "async" });
      return;
    }
    let o = t.split(`
`).filter((s) => s), r = Math.min(...o.map((s) => s.length - s.trimStart().length)), i = o.map((s) => s.slice(r)).map((s) => " ".repeat(this.indent * 2) + s);
    for (let s of i)
      this.content.push(s);
  }
  compile() {
    let t = Function, n = this?.args, r = [...(this?.content ?? [""]).map((i) => `  ${i}`)];
    return new t(...n, r.join(`
`));
  }
};

// versions/4.3.6/node_modules/zod/v4/core/versions.js
var wo = {
  major: 4,
  minor: 3,
  patch: 6
};

// versions/4.3.6/node_modules/zod/v4/core/schemas.js
var _ = /* @__PURE__ */ f("$ZodType", (e, t) => {
  var n;
  e ?? (e = {}), e._zod.def = t, e._zod.bag = e._zod.bag || {}, e._zod.version = wo;
  let o = [...e._zod.def.checks ?? []];
  e._zod.traits.has("$ZodCheck") && o.unshift(e);
  for (let r of o)
    for (let i of r._zod.onattach)
      i(e);
  if (o.length === 0)
    (n = e._zod).deferred ?? (n.deferred = []), e._zod.deferred?.push(() => {
      e._zod.run = e._zod.parse;
    });
  else {
    let r = /* @__PURE__ */ a((s, c, u) => {
      let l = Se(s), d;
      for (let g of c) {
        if (g._zod.def.when) {
          if (!g._zod.def.when(s))
            continue;
        } else if (l)
          continue;
        let b = s.issues.length, x = g._zod.check(s);
        if (x instanceof Promise && u?.async === !1)
          throw new pe();
        if (d || x instanceof Promise)
          d = (d ?? Promise.resolve()).then(async () => {
            await x, s.issues.length !== b && (l || (l = Se(s, b)));
          });
        else {
          if (s.issues.length === b)
            continue;
          l || (l = Se(s, b));
        }
      }
      return d ? d.then(() => s) : s;
    }, "runChecks"), i = /* @__PURE__ */ a((s, c, u) => {
      if (Se(s))
        return s.aborted = !0, s;
      let l = r(c, o, u);
      if (l instanceof Promise) {
        if (u.async === !1)
          throw new pe();
        return l.then((d) => e._zod.parse(d, u));
      }
      return e._zod.parse(l, u);
    }, "handleCanaryResult");
    e._zod.run = (s, c) => {
      if (c.skipChecks)
        return e._zod.parse(s, c);
      if (c.direction === "backward") {
        let l = e._zod.parse({ value: s.value, issues: [] }, { ...c, skipChecks: !0 });
        return l instanceof Promise ? l.then((d) => i(d, s, c)) : i(l, s, c);
      }
      let u = e._zod.parse(s, c);
      if (u instanceof Promise) {
        if (c.async === !1)
          throw new pe();
        return u.then((l) => r(l, o, c));
      }
      return r(u, o, c);
    };
  }
  I(e, "~standard", () => ({
    validate: /* @__PURE__ */ a((r) => {
      try {
        let i = me(e, r);
        return i.success ? { value: i.data } : { issues: i.error?.issues };
      } catch {
        return qe(e, r).then((s) => s.success ? { value: s.data } : { issues: s.error?.issues });
      }
    }, "validate"),
    vendor: "zod",
    version: 1
  }));
}), ut = /* @__PURE__ */ f("$ZodString", (e, t) => {
  _.init(e, t), e._zod.pattern = [...e?._zod.bag?.patterns ?? []].pop() ?? Xi(e._zod.bag), e._zod.parse = (n, o) => {
    if (t.coerce)
      try {
        n.value = String(n.value);
      } catch {
      }
    return typeof n.value == "string" || n.issues.push({
      expected: "string",
      code: "invalid_type",
      input: n.value,
      inst: e
    }), n;
  };
}), E = /* @__PURE__ */ f("$ZodStringFormat", (e, t) => {
  ct.init(e, t), ut.init(e, t);
}), zo = /* @__PURE__ */ f("$ZodGUID", (e, t) => {
  t.pattern ?? (t.pattern = Ai), E.init(e, t);
}), Io = /* @__PURE__ */ f("$ZodUUID", (e, t) => {
  if (t.version) {
    let o = {
      v1: 1,
      v2: 2,
      v3: 3,
      v4: 4,
      v5: 5,
      v6: 6,
      v7: 7,
      v8: 8
    }[t.version];
    if (o === void 0)
      throw new Error(`Invalid UUID version: "${t.version}"`);
    t.pattern ?? (t.pattern = Je(o));
  } else
    t.pattern ?? (t.pattern = Je());
  E.init(e, t);
}), So = /* @__PURE__ */ f("$ZodEmail", (e, t) => {
  t.pattern ?? (t.pattern = Ci), E.init(e, t);
}), jo = /* @__PURE__ */ f("$ZodURL", (e, t) => {
  E.init(e, t), e._zod.check = (n) => {
    try {
      let o = n.value.trim(), r = new URL(o);
      t.hostname && (t.hostname.lastIndex = 0, t.hostname.test(r.hostname) || n.issues.push({
        code: "invalid_format",
        format: "url",
        note: "Invalid hostname",
        pattern: t.hostname.source,
        input: n.value,
        inst: e,
        continue: !t.abort
      })), t.protocol && (t.protocol.lastIndex = 0, t.protocol.test(r.protocol.endsWith(":") ? r.protocol.slice(0, -1) : r.protocol) || n.issues.push({
        code: "invalid_format",
        format: "url",
        note: "Invalid protocol",
        pattern: t.protocol.source,
        input: n.value,
        inst: e,
        continue: !t.abort
      })), t.normalize ? n.value = r.href : n.value = o;
      return;
    } catch {
      n.issues.push({
        code: "invalid_format",
        format: "url",
        input: n.value,
        inst: e,
        continue: !t.abort
      });
    }
  };
}), Oo = /* @__PURE__ */ f("$ZodEmoji", (e, t) => {
  t.pattern ?? (t.pattern = Ri()), E.init(e, t);
}), To = /* @__PURE__ */ f("$ZodNanoID", (e, t) => {
  t.pattern ?? (t.pattern = Zi), E.init(e, t);
}), Po = /* @__PURE__ */ f("$ZodCUID", (e, t) => {
  t.pattern ?? (t.pattern = Ti), E.init(e, t);
}), Uo = /* @__PURE__ */ f("$ZodCUID2", (e, t) => {
  t.pattern ?? (t.pattern = Pi), E.init(e, t);
}), Do = /* @__PURE__ */ f("$ZodULID", (e, t) => {
  t.pattern ?? (t.pattern = Ui), E.init(e, t);
}), Eo = /* @__PURE__ */ f("$ZodXID", (e, t) => {
  t.pattern ?? (t.pattern = Di), E.init(e, t);
}), Zo = /* @__PURE__ */ f("$ZodKSUID", (e, t) => {
  t.pattern ?? (t.pattern = Ei), E.init(e, t);
}), No = /* @__PURE__ */ f("$ZodISODateTime", (e, t) => {
  t.pattern ?? (t.pattern = Gi(t)), E.init(e, t);
}), Ao = /* @__PURE__ */ f("$ZodISODate", (e, t) => {
  t.pattern ?? (t.pattern = Wi), E.init(e, t);
}), Co = /* @__PURE__ */ f("$ZodISOTime", (e, t) => {
  t.pattern ?? (t.pattern = Ki(t)), E.init(e, t);
}), Ro = /* @__PURE__ */ f("$ZodISODuration", (e, t) => {
  t.pattern ?? (t.pattern = Ni), E.init(e, t);
}), Fo = /* @__PURE__ */ f("$ZodIPv4", (e, t) => {
  t.pattern ?? (t.pattern = Fi), E.init(e, t), e._zod.bag.format = "ipv4";
}), Mo = /* @__PURE__ */ f("$ZodIPv6", (e, t) => {
  t.pattern ?? (t.pattern = Mi), E.init(e, t), e._zod.bag.format = "ipv6", e._zod.check = (n) => {
    try {
      new URL(`http://[${n.value}]`);
    } catch {
      n.issues.push({
        code: "invalid_format",
        format: "ipv6",
        input: n.value,
        inst: e,
        continue: !t.abort
      });
    }
  };
}), Lo = /* @__PURE__ */ f("$ZodMAC", (e, t) => {
  t.pattern ?? (t.pattern = Li(t.delimiter)), E.init(e, t), e._zod.bag.format = "mac";
}), Bo = /* @__PURE__ */ f("$ZodCIDRv4", (e, t) => {
  t.pattern ?? (t.pattern = Bi), E.init(e, t);
}), Vo = /* @__PURE__ */ f("$ZodCIDRv6", (e, t) => {
  t.pattern ?? (t.pattern = Vi), E.init(e, t), e._zod.check = (n) => {
    let o = n.value.split("/");
    try {
      if (o.length !== 2)
        throw new Error();
      let [r, i] = o;
      if (!i)
        throw new Error();
      let s = Number(i);
      if (`${s}` !== i)
        throw new Error();
      if (s < 0 || s > 128)
        throw new Error();
      new URL(`http://[${r}]`);
    } catch {
      n.issues.push({
        code: "invalid_format",
        format: "cidrv6",
        input: n.value,
        inst: e,
        continue: !t.abort
      });
    }
  };
});
function qo(e) {
  if (e === "")
    return !0;
  if (e.length % 4 !== 0)
    return !1;
  try {
    return atob(e), !0;
  } catch {
    return !1;
  }
}
a(qo, "isValidBase64");
var Jo = /* @__PURE__ */ f("$ZodBase64", (e, t) => {
  t.pattern ?? (t.pattern = qi), E.init(e, t), e._zod.bag.contentEncoding = "base64", e._zod.check = (n) => {
    qo(n.value) || n.issues.push({
      code: "invalid_format",
      format: "base64",
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
});
function Rl(e) {
  if (!Zr.test(e))
    return !1;
  let t = e.replace(/[-_]/g, (o) => o === "-" ? "+" : "/"), n = t.padEnd(Math.ceil(t.length / 4) * 4, "=");
  return qo(n);
}
a(Rl, "isValidBase64URL");
var Wo = /* @__PURE__ */ f("$ZodBase64URL", (e, t) => {
  t.pattern ?? (t.pattern = Zr), E.init(e, t), e._zod.bag.contentEncoding = "base64url", e._zod.check = (n) => {
    Rl(n.value) || n.issues.push({
      code: "invalid_format",
      format: "base64url",
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Ko = /* @__PURE__ */ f("$ZodE164", (e, t) => {
  t.pattern ?? (t.pattern = Ji), E.init(e, t);
});
function Fl(e, t = null) {
  try {
    let n = e.split(".");
    if (n.length !== 3)
      return !1;
    let [o] = n;
    if (!o)
      return !1;
    let r = JSON.parse(atob(o));
    return !("typ" in r && r?.typ !== "JWT" || !r.alg || t && (!("alg" in r) || r.alg !== t));
  } catch {
    return !1;
  }
}
a(Fl, "isValidJWT");
var Go = /* @__PURE__ */ f("$ZodJWT", (e, t) => {
  E.init(e, t), e._zod.check = (n) => {
    Fl(n.value, t.alg) || n.issues.push({
      code: "invalid_format",
      format: "jwt",
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Xo = /* @__PURE__ */ f("$ZodCustomStringFormat", (e, t) => {
  E.init(e, t), e._zod.check = (n) => {
    t.fn(n.value) || n.issues.push({
      code: "invalid_format",
      format: t.format,
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Vr = /* @__PURE__ */ f("$ZodNumber", (e, t) => {
  _.init(e, t), e._zod.pattern = e._zod.bag.pattern ?? Nr, e._zod.parse = (n, o) => {
    if (t.coerce)
      try {
        n.value = Number(n.value);
      } catch {
      }
    let r = n.value;
    if (typeof r == "number" && !Number.isNaN(r) && Number.isFinite(r))
      return n;
    let i = typeof r == "number" ? Number.isNaN(r) ? "NaN" : Number.isFinite(r) ? void 0 : "Infinity" : void 0;
    return n.issues.push({
      expected: "number",
      code: "invalid_type",
      input: r,
      inst: e,
      ...i ? { received: i } : {}
    }), n;
  };
}), Ho = /* @__PURE__ */ f("$ZodNumberFormat", (e, t) => {
  oo.init(e, t), Vr.init(e, t);
}), Ft = /* @__PURE__ */ f("$ZodBoolean", (e, t) => {
  _.init(e, t), e._zod.pattern = Yi, e._zod.parse = (n, o) => {
    if (t.coerce)
      try {
        n.value = !!n.value;
      } catch {
      }
    let r = n.value;
    return typeof r == "boolean" || n.issues.push({
      expected: "boolean",
      code: "invalid_type",
      input: r,
      inst: e
    }), n;
  };
}), qr = /* @__PURE__ */ f("$ZodBigInt", (e, t) => {
  _.init(e, t), e._zod.pattern = Hi, e._zod.parse = (n, o) => {
    if (t.coerce)
      try {
        n.value = BigInt(n.value);
      } catch {
      }
    return typeof n.value == "bigint" || n.issues.push({
      expected: "bigint",
      code: "invalid_type",
      input: n.value,
      inst: e
    }), n;
  };
}), Qo = /* @__PURE__ */ f("$ZodBigIntFormat", (e, t) => {
  ao.init(e, t), qr.init(e, t);
}), Yo = /* @__PURE__ */ f("$ZodSymbol", (e, t) => {
  _.init(e, t), e._zod.parse = (n, o) => {
    let r = n.value;
    return typeof r == "symbol" || n.issues.push({
      expected: "symbol",
      code: "invalid_type",
      input: r,
      inst: e
    }), n;
  };
}), ea = /* @__PURE__ */ f("$ZodUndefined", (e, t) => {
  _.init(e, t), e._zod.pattern = to, e._zod.values = /* @__PURE__ */ new Set([void 0]), e._zod.optin = "optional", e._zod.optout = "optional", e._zod.parse = (n, o) => {
    let r = n.value;
    return typeof r > "u" || n.issues.push({
      expected: "undefined",
      code: "invalid_type",
      input: r,
      inst: e
    }), n;
  };
}), ta = /* @__PURE__ */ f("$ZodNull", (e, t) => {
  _.init(e, t), e._zod.pattern = eo, e._zod.values = /* @__PURE__ */ new Set([null]), e._zod.parse = (n, o) => {
    let r = n.value;
    return r === null || n.issues.push({
      expected: "null",
      code: "invalid_type",
      input: r,
      inst: e
    }), n;
  };
}), ra = /* @__PURE__ */ f("$ZodAny", (e, t) => {
  _.init(e, t), e._zod.parse = (n) => n;
}), na = /* @__PURE__ */ f("$ZodUnknown", (e, t) => {
  _.init(e, t), e._zod.parse = (n) => n;
}), ia = /* @__PURE__ */ f("$ZodNever", (e, t) => {
  _.init(e, t), e._zod.parse = (n, o) => (n.issues.push({
    expected: "never",
    code: "invalid_type",
    input: n.value,
    inst: e
  }), n);
}), oa = /* @__PURE__ */ f("$ZodVoid", (e, t) => {
  _.init(e, t), e._zod.parse = (n, o) => {
    let r = n.value;
    return typeof r > "u" || n.issues.push({
      expected: "void",
      code: "invalid_type",
      input: r,
      inst: e
    }), n;
  };
}), lt = /* @__PURE__ */ f("$ZodDate", (e, t) => {
  _.init(e, t), e._zod.parse = (n, o) => {
    if (t.coerce)
      try {
        n.value = new Date(n.value);
      } catch {
      }
    let r = n.value, i = r instanceof Date;
    return i && !Number.isNaN(r.getTime()) || n.issues.push({
      expected: "date",
      code: "invalid_type",
      input: r,
      ...i ? { received: "Invalid Date" } : {},
      inst: e
    }), n;
  };
});
function jl(e, t, n) {
  e.issues.length && t.issues.push(...oe(n, e.issues)), t.value[n] = e.value;
}
a(jl, "handleArrayResult");
var Oe = /* @__PURE__ */ f("$ZodArray", (e, t) => {
  _.init(e, t), e._zod.parse = (n, o) => {
    let r = n.value;
    if (!Array.isArray(r))
      return n.issues.push({
        expected: "array",
        code: "invalid_type",
        input: r,
        inst: e
      }), n;
    n.value = Array(r.length);
    let i = [];
    for (let s = 0; s < r.length; s++) {
      let c = r[s], u = t.element._zod.run({
        value: c,
        issues: []
      }, o);
      u instanceof Promise ? i.push(u.then((l) => jl(l, n, s))) : jl(u, n, s);
    }
    return i.length ? Promise.all(i).then(() => n) : n;
  };
});
function Br(e, t, n, o, r) {
  if (e.issues.length) {
    if (r && !(n in o))
      return;
    t.issues.push(...oe(n, e.issues));
  }
  e.value === void 0 ? n in o && (t.value[n] = void 0) : t.value[n] = e.value;
}
a(Br, "handlePropertyResult");
function Ml(e) {
  let t = Object.keys(e.shape);
  for (let o of t)
    if (!e.shape?.[o]?._zod?.traits?.has("$ZodType"))
      throw new Error(`Invalid element at key "${o}": expected a Zod schema`);
  let n = di(e.shape);
  return {
    ...e,
    keys: t,
    keySet: new Set(t),
    numKeys: t.length,
    optionalKeys: new Set(n)
  };
}
a(Ml, "normalizeDef");
function Ll(e, t, n, o, r, i) {
  let s = [], c = r.keySet, u = r.catchall._zod, l = u.def.type, d = u.optout === "optional";
  for (let g in t) {
    if (c.has(g))
      continue;
    if (l === "never") {
      s.push(g);
      continue;
    }
    let b = u.run({ value: t[g], issues: [] }, o);
    b instanceof Promise ? e.push(b.then((x) => Br(x, n, g, t, d))) : Br(b, n, g, t, d);
  }
  return s.length && n.issues.push({
    code: "unrecognized_keys",
    keys: s,
    input: t,
    inst: i
  }), e.length ? Promise.all(e).then(() => n) : n;
}
a(Ll, "handleCatchall");
var L = /* @__PURE__ */ f("$ZodObject", (e, t) => {
  if (_.init(e, t), !Object.getOwnPropertyDescriptor(t, "shape")?.get) {
    let c = t.shape;
    Object.defineProperty(t, "shape", {
      get: /* @__PURE__ */ a(() => {
        let u = { ...c };
        return Object.defineProperty(t, "shape", {
          value: u
        }), u;
      }, "get")
    });
  }
  let o = ot(() => Ml(t));
  I(e._zod, "propValues", () => {
    let c = t.shape, u = {};
    for (let l in c) {
      let d = c[l]._zod;
      if (d.values) {
        u[l] ?? (u[l] = /* @__PURE__ */ new Set());
        for (let g of d.values)
          u[l].add(g);
      }
    }
    return u;
  });
  let r = Ve, i = t.catchall, s;
  e._zod.parse = (c, u) => {
    s ?? (s = o.value);
    let l = c.value;
    if (!r(l))
      return c.issues.push({
        expected: "object",
        code: "invalid_type",
        input: l,
        inst: e
      }), c;
    c.value = {};
    let d = [], g = s.shape;
    for (let b of s.keys) {
      let x = g[b], j = x._zod.optout === "optional", z = x._zod.run({ value: l[b], issues: [] }, u);
      z instanceof Promise ? d.push(z.then((q) => Br(q, c, b, l, j))) : Br(z, c, b, l, j);
    }
    return i ? Ll(d, l, c, u, o.value, e) : d.length ? Promise.all(d).then(() => c) : c;
  };
}), ng = /* @__PURE__ */ f("$ZodObjectJIT", (e, t) => {
  L.init(e, t);
  let n = e._zod.parse, o = ot(() => Ml(t)), r = /* @__PURE__ */ a((b) => {
    let x = new Rt(["shape", "payload", "ctx"]), j = o.value, z = /* @__PURE__ */ a((J) => {
      let Z = jr(J);
      return `shape[${Z}]._zod.run({ value: input[${Z}], issues: [] }, ctx)`;
    }, "parseStr");
    x.write("const input = payload.value;");
    let q = /* @__PURE__ */ Object.create(null), Ae = 0;
    for (let J of j.keys)
      q[J] = `key_${Ae++}`;
    x.write("const newResult = {};");
    for (let J of j.keys) {
      let Z = q[J], K = jr(J), O = b[J]?._zod?.optout === "optional";
      x.write(`const ${Z} = ${z(J)};`), O ? x.write(`
        if (${Z}.issues.length) {
          if (${K} in input) {
            payload.issues = payload.issues.concat(${Z}.issues.map(iss => ({
              ...iss,
              path: iss.path ? [${K}, ...iss.path] : [${K}]
            })));
          }
        }
        
        if (${Z}.value === undefined) {
          if (${K} in input) {
            newResult[${K}] = undefined;
          }
        } else {
          newResult[${K}] = ${Z}.value;
        }
        
      `) : x.write(`
        if (${Z}.issues.length) {
          payload.issues = payload.issues.concat(${Z}.issues.map(iss => ({
            ...iss,
            path: iss.path ? [${K}, ...iss.path] : [${K}]
          })));
        }
        
        if (${Z}.value === undefined) {
          if (${K} in input) {
            newResult[${K}] = undefined;
          }
        } else {
          newResult[${K}] = ${Z}.value;
        }
        
      `);
    }
    x.write("payload.value = newResult;"), x.write("return payload;");
    let ve = x.compile();
    return (J, Z) => ve(b, J, Z);
  }, "generateFastpass"), i, s = Ve, c = !Tt.jitless, l = c && ui.value, d = t.catchall, g;
  e._zod.parse = (b, x) => {
    g ?? (g = o.value);
    let j = b.value;
    return s(j) ? c && l && x?.async === !1 && x.jitless !== !0 ? (i || (i = r(t.shape)), b = i(b, x), d ? Ll([], j, b, x, g, e) : b) : n(b, x) : (b.issues.push({
      expected: "object",
      code: "invalid_type",
      input: j,
      inst: e
    }), b);
  };
});
function Ol(e, t, n, o) {
  for (let i of e)
    if (i.issues.length === 0)
      return t.value = i.value, t;
  let r = e.filter((i) => !Se(i));
  return r.length === 1 ? (t.value = r[0].value, r[0]) : (t.issues.push({
    code: "invalid_union",
    input: t.value,
    inst: n,
    errors: e.map((i) => i.issues.map((s) => te(s, o, X())))
  }), t);
}
a(Ol, "handleUnionResults");
var Y = /* @__PURE__ */ f("$ZodUnion", (e, t) => {
  _.init(e, t), I(e._zod, "optin", () => t.options.some((r) => r._zod.optin === "optional") ? "optional" : void 0), I(e._zod, "optout", () => t.options.some((r) => r._zod.optout === "optional") ? "optional" : void 0), I(e._zod, "values", () => {
    if (t.options.every((r) => r._zod.values))
      return new Set(t.options.flatMap((r) => Array.from(r._zod.values)));
  }), I(e._zod, "pattern", () => {
    if (t.options.every((r) => r._zod.pattern)) {
      let r = t.options.map((i) => i._zod.pattern);
      return new RegExp(`^(${r.map((i) => Dt(i.source)).join("|")})$`);
    }
  });
  let n = t.options.length === 1, o = t.options[0]._zod.run;
  e._zod.parse = (r, i) => {
    if (n)
      return o(r, i);
    let s = !1, c = [];
    for (let u of t.options) {
      let l = u._zod.run({
        value: r.value,
        issues: []
      }, i);
      if (l instanceof Promise)
        c.push(l), s = !0;
      else {
        if (l.issues.length === 0)
          return l;
        c.push(l);
      }
    }
    return s ? Promise.all(c).then((u) => Ol(u, r, e, i)) : Ol(c, r, e, i);
  };
});
function Tl(e, t, n, o) {
  let r = e.filter((i) => i.issues.length === 0);
  return r.length === 1 ? (t.value = r[0].value, t) : (r.length === 0 ? t.issues.push({
    code: "invalid_union",
    input: t.value,
    inst: n,
    errors: e.map((i) => i.issues.map((s) => te(s, o, X())))
  }) : t.issues.push({
    code: "invalid_union",
    input: t.value,
    inst: n,
    errors: [],
    inclusive: !1
  }), t);
}
a(Tl, "handleExclusiveUnionResults");
var aa = /* @__PURE__ */ f("$ZodXor", (e, t) => {
  Y.init(e, t), t.inclusive = !1;
  let n = t.options.length === 1, o = t.options[0]._zod.run;
  e._zod.parse = (r, i) => {
    if (n)
      return o(r, i);
    let s = !1, c = [];
    for (let u of t.options) {
      let l = u._zod.run({
        value: r.value,
        issues: []
      }, i);
      l instanceof Promise ? (c.push(l), s = !0) : c.push(l);
    }
    return s ? Promise.all(c).then((u) => Tl(u, r, e, i)) : Tl(c, r, e, i);
  };
}), Te = /* @__PURE__ */ f("$ZodDiscriminatedUnion", (e, t) => {
  t.inclusive = !1, Y.init(e, t);
  let n = e._zod.parse;
  I(e._zod, "propValues", () => {
    let r = {};
    for (let i of t.options) {
      let s = i._zod.propValues;
      if (!s || Object.keys(s).length === 0)
        throw new Error(`Invalid discriminated union option at index "${t.options.indexOf(i)}"`);
      for (let [c, u] of Object.entries(s)) {
        r[c] || (r[c] = /* @__PURE__ */ new Set());
        for (let l of u)
          r[c].add(l);
      }
    }
    return r;
  });
  let o = ot(() => {
    let r = t.options, i = /* @__PURE__ */ new Map();
    for (let s of r) {
      let c = s._zod.propValues?.[t.discriminator];
      if (!c || c.size === 0)
        throw new Error(`Invalid discriminated union option at index "${t.options.indexOf(s)}"`);
      for (let u of c) {
        if (i.has(u))
          throw new Error(`Duplicate discriminator value "${String(u)}"`);
        i.set(u, s);
      }
    }
    return i;
  });
  e._zod.parse = (r, i) => {
    let s = r.value;
    if (!Ve(s))
      return r.issues.push({
        code: "invalid_type",
        expected: "object",
        input: s,
        inst: e
      }), r;
    let c = o.value.get(s?.[t.discriminator]);
    return c ? c._zod.run(r, i) : t.unionFallback ? n(r, i) : (r.issues.push({
      code: "invalid_union",
      errors: [],
      note: "No matching discriminator",
      discriminator: t.discriminator,
      input: s,
      path: [t.discriminator],
      inst: e
    }), r);
  };
}), sa = /* @__PURE__ */ f("$ZodIntersection", (e, t) => {
  _.init(e, t), e._zod.parse = (n, o) => {
    let r = n.value, i = t.left._zod.run({ value: r, issues: [] }, o), s = t.right._zod.run({ value: r, issues: [] }, o);
    return i instanceof Promise || s instanceof Promise ? Promise.all([i, s]).then(([u, l]) => Pl(n, u, l)) : Pl(n, i, s);
  };
});
function ko(e, t) {
  if (e === t)
    return { valid: !0, data: e };
  if (e instanceof Date && t instanceof Date && +e == +t)
    return { valid: !0, data: e };
  if (Ie(e) && Ie(t)) {
    let n = Object.keys(t), o = Object.keys(e).filter((i) => n.indexOf(i) !== -1), r = { ...e, ...t };
    for (let i of o) {
      let s = ko(e[i], t[i]);
      if (!s.valid)
        return {
          valid: !1,
          mergeErrorPath: [i, ...s.mergeErrorPath]
        };
      r[i] = s.data;
    }
    return { valid: !0, data: r };
  }
  if (Array.isArray(e) && Array.isArray(t)) {
    if (e.length !== t.length)
      return { valid: !1, mergeErrorPath: [] };
    let n = [];
    for (let o = 0; o < e.length; o++) {
      let r = e[o], i = t[o], s = ko(r, i);
      if (!s.valid)
        return {
          valid: !1,
          mergeErrorPath: [o, ...s.mergeErrorPath]
        };
      n.push(s.data);
    }
    return { valid: !0, data: n };
  }
  return { valid: !1, mergeErrorPath: [] };
}
a(ko, "mergeValues");
function Pl(e, t, n) {
  let o = /* @__PURE__ */ new Map(), r;
  for (let c of t.issues)
    if (c.code === "unrecognized_keys") {
      r ?? (r = c);
      for (let u of c.keys)
        o.has(u) || o.set(u, {}), o.get(u).l = !0;
    } else
      e.issues.push(c);
  for (let c of n.issues)
    if (c.code === "unrecognized_keys")
      for (let u of c.keys)
        o.has(u) || o.set(u, {}), o.get(u).r = !0;
    else
      e.issues.push(c);
  let i = [...o].filter(([, c]) => c.l && c.r).map(([c]) => c);
  if (i.length && r && e.issues.push({ ...r, keys: i }), Se(e))
    return e;
  let s = ko(t.value, n.value);
  if (!s.valid)
    throw new Error(`Unmergable intersection. Error path: ${JSON.stringify(s.mergeErrorPath)}`);
  return e.value = s.data, e;
}
a(Pl, "handleIntersectionResults");
var Pe = /* @__PURE__ */ f("$ZodTuple", (e, t) => {
  _.init(e, t);
  let n = t.items;
  e._zod.parse = (o, r) => {
    let i = o.value;
    if (!Array.isArray(i))
      return o.issues.push({
        input: i,
        inst: e,
        expected: "tuple",
        code: "invalid_type"
      }), o;
    o.value = [];
    let s = [], c = [...n].reverse().findIndex((d) => d._zod.optin !== "optional"), u = c === -1 ? 0 : n.length - c;
    if (!t.rest) {
      let d = i.length > n.length, g = i.length < u - 1;
      if (d || g)
        return o.issues.push({
          ...d ? { code: "too_big", maximum: n.length, inclusive: !0 } : { code: "too_small", minimum: n.length },
          input: i,
          inst: e,
          origin: "array"
        }), o;
    }
    let l = -1;
    for (let d of n) {
      if (l++, l >= i.length && l >= u)
        continue;
      let g = d._zod.run({
        value: i[l],
        issues: []
      }, r);
      g instanceof Promise ? s.push(g.then((b) => Rr(b, o, l))) : Rr(g, o, l);
    }
    if (t.rest) {
      let d = i.slice(n.length);
      for (let g of d) {
        l++;
        let b = t.rest._zod.run({
          value: g,
          issues: []
        }, r);
        b instanceof Promise ? s.push(b.then((x) => Rr(x, o, l))) : Rr(b, o, l);
      }
    }
    return s.length ? Promise.all(s).then(() => o) : o;
  };
});
function Rr(e, t, n) {
  e.issues.length && t.issues.push(...oe(n, e.issues)), t.value[n] = e.value;
}
a(Rr, "handleTupleResult");
var We = /* @__PURE__ */ f("$ZodRecord", (e, t) => {
  _.init(e, t), e._zod.parse = (n, o) => {
    let r = n.value;
    if (!Ie(r))
      return n.issues.push({
        expected: "record",
        code: "invalid_type",
        input: r,
        inst: e
      }), n;
    let i = [], s = t.keyType._zod.values;
    if (s) {
      n.value = {};
      let c = /* @__PURE__ */ new Set();
      for (let l of s)
        if (typeof l == "string" || typeof l == "number" || typeof l == "symbol") {
          c.add(typeof l == "number" ? l.toString() : l);
          let d = t.valueType._zod.run({ value: r[l], issues: [] }, o);
          d instanceof Promise ? i.push(d.then((g) => {
            g.issues.length && n.issues.push(...oe(l, g.issues)), n.value[l] = g.value;
          })) : (d.issues.length && n.issues.push(...oe(l, d.issues)), n.value[l] = d.value);
        }
      let u;
      for (let l in r)
        c.has(l) || (u = u ?? [], u.push(l));
      u && u.length > 0 && n.issues.push({
        code: "unrecognized_keys",
        input: r,
        inst: e,
        keys: u
      });
    } else {
      n.value = {};
      for (let c of Reflect.ownKeys(r)) {
        if (c === "__proto__")
          continue;
        let u = t.keyType._zod.run({ value: c, issues: [] }, o);
        if (u instanceof Promise)
          throw new Error("Async schemas not supported in object keys currently");
        if (typeof c == "string" && Nr.test(c) && u.issues.length) {
          let g = t.keyType._zod.run({ value: Number(c), issues: [] }, o);
          if (g instanceof Promise)
            throw new Error("Async schemas not supported in object keys currently");
          g.issues.length === 0 && (u = g);
        }
        if (u.issues.length) {
          t.mode === "loose" ? n.value[c] = r[c] : n.issues.push({
            code: "invalid_key",
            origin: "record",
            issues: u.issues.map((g) => te(g, o, X())),
            input: c,
            path: [c],
            inst: e
          });
          continue;
        }
        let d = t.valueType._zod.run({ value: r[c], issues: [] }, o);
        d instanceof Promise ? i.push(d.then((g) => {
          g.issues.length && n.issues.push(...oe(c, g.issues)), n.value[u.value] = g.value;
        })) : (d.issues.length && n.issues.push(...oe(c, d.issues)), n.value[u.value] = d.value);
      }
    }
    return i.length ? Promise.all(i).then(() => n) : n;
  };
}), ca = /* @__PURE__ */ f("$ZodMap", (e, t) => {
  _.init(e, t), e._zod.parse = (n, o) => {
    let r = n.value;
    if (!(r instanceof Map))
      return n.issues.push({
        expected: "map",
        code: "invalid_type",
        input: r,
        inst: e
      }), n;
    let i = [];
    n.value = /* @__PURE__ */ new Map();
    for (let [s, c] of r) {
      let u = t.keyType._zod.run({ value: s, issues: [] }, o), l = t.valueType._zod.run({ value: c, issues: [] }, o);
      u instanceof Promise || l instanceof Promise ? i.push(Promise.all([u, l]).then(([d, g]) => {
        Ul(d, g, n, s, r, e, o);
      })) : Ul(u, l, n, s, r, e, o);
    }
    return i.length ? Promise.all(i).then(() => n) : n;
  };
});
function Ul(e, t, n, o, r, i, s) {
  e.issues.length && (Et.has(typeof o) ? n.issues.push(...oe(o, e.issues)) : n.issues.push({
    code: "invalid_key",
    origin: "map",
    input: r,
    inst: i,
    issues: e.issues.map((c) => te(c, s, X()))
  })), t.issues.length && (Et.has(typeof o) ? n.issues.push(...oe(o, t.issues)) : n.issues.push({
    origin: "map",
    code: "invalid_element",
    input: r,
    inst: i,
    key: o,
    issues: t.issues.map((c) => te(c, s, X()))
  })), n.value.set(e.value, t.value);
}
a(Ul, "handleMapResult");
var ua = /* @__PURE__ */ f("$ZodSet", (e, t) => {
  _.init(e, t), e._zod.parse = (n, o) => {
    let r = n.value;
    if (!(r instanceof Set))
      return n.issues.push({
        input: r,
        inst: e,
        expected: "set",
        code: "invalid_type"
      }), n;
    let i = [];
    n.value = /* @__PURE__ */ new Set();
    for (let s of r) {
      let c = t.valueType._zod.run({ value: s, issues: [] }, o);
      c instanceof Promise ? i.push(c.then((u) => Dl(u, n))) : Dl(c, n);
    }
    return i.length ? Promise.all(i).then(() => n) : n;
  };
});
function Dl(e, t) {
  e.issues.length && t.issues.push(...e.issues), t.value.add(e.value);
}
a(Dl, "handleSetResult");
var dt = /* @__PURE__ */ f("$ZodEnum", (e, t) => {
  _.init(e, t);
  let n = Ut(t.entries), o = new Set(n);
  e._zod.values = o, e._zod.pattern = new RegExp(`^(${n.filter((r) => Et.has(typeof r)).map((r) => typeof r == "string" ? ue(r) : r.toString()).join("|")})$`), e._zod.parse = (r, i) => {
    let s = r.value;
    return o.has(s) || r.issues.push({
      code: "invalid_value",
      values: n,
      input: s,
      inst: e
    }), r;
  };
}), ft = /* @__PURE__ */ f("$ZodLiteral", (e, t) => {
  if (_.init(e, t), t.values.length === 0)
    throw new Error("Cannot create literal schema with no valid values");
  let n = new Set(t.values);
  e._zod.values = n, e._zod.pattern = new RegExp(`^(${t.values.map((o) => typeof o == "string" ? ue(o) : o ? ue(o.toString()) : String(o)).join("|")})$`), e._zod.parse = (o, r) => {
    let i = o.value;
    return n.has(i) || o.issues.push({
      code: "invalid_value",
      values: t.values,
      input: i,
      inst: e
    }), o;
  };
}), la = /* @__PURE__ */ f("$ZodFile", (e, t) => {
  _.init(e, t), e._zod.parse = (n, o) => {
    let r = n.value;
    return r instanceof File || n.issues.push({
      expected: "file",
      code: "invalid_type",
      input: r,
      inst: e
    }), n;
  };
}), da = /* @__PURE__ */ f("$ZodTransform", (e, t) => {
  _.init(e, t), e._zod.parse = (n, o) => {
    if (o.direction === "backward")
      throw new it(e.constructor.name);
    let r = t.transform(n.value, n);
    if (o.async)
      return (r instanceof Promise ? r : Promise.resolve(r)).then((s) => (n.value = s, n));
    if (r instanceof Promise)
      throw new pe();
    return n.value = r, n;
  };
});
function El(e, t) {
  return e.issues.length && t === void 0 ? { issues: [], value: void 0 } : e;
}
a(El, "handleOptionalResult");
var F = /* @__PURE__ */ f("$ZodOptional", (e, t) => {
  _.init(e, t), e._zod.optin = "optional", e._zod.optout = "optional", I(e._zod, "values", () => t.innerType._zod.values ? /* @__PURE__ */ new Set([...t.innerType._zod.values, void 0]) : void 0), I(e._zod, "pattern", () => {
    let n = t.innerType._zod.pattern;
    return n ? new RegExp(`^(${Dt(n.source)})?$`) : void 0;
  }), e._zod.parse = (n, o) => {
    if (t.innerType._zod.optin === "optional") {
      let r = t.innerType._zod.run(n, o);
      return r instanceof Promise ? r.then((i) => El(i, n.value)) : El(r, n.value);
    }
    return n.value === void 0 ? n : t.innerType._zod.run(n, o);
  };
}), fa = /* @__PURE__ */ f("$ZodExactOptional", (e, t) => {
  F.init(e, t), I(e._zod, "values", () => t.innerType._zod.values), I(e._zod, "pattern", () => t.innerType._zod.pattern), e._zod.parse = (n, o) => t.innerType._zod.run(n, o);
}), de = /* @__PURE__ */ f("$ZodNullable", (e, t) => {
  _.init(e, t), I(e._zod, "optin", () => t.innerType._zod.optin), I(e._zod, "optout", () => t.innerType._zod.optout), I(e._zod, "pattern", () => {
    let n = t.innerType._zod.pattern;
    return n ? new RegExp(`^(${Dt(n.source)}|null)$`) : void 0;
  }), I(e._zod, "values", () => t.innerType._zod.values ? /* @__PURE__ */ new Set([...t.innerType._zod.values, null]) : void 0), e._zod.parse = (n, o) => n.value === null ? n : t.innerType._zod.run(n, o);
}), ae = /* @__PURE__ */ f("$ZodDefault", (e, t) => {
  _.init(e, t), e._zod.optin = "optional", I(e._zod, "values", () => t.innerType._zod.values), e._zod.parse = (n, o) => {
    if (o.direction === "backward")
      return t.innerType._zod.run(n, o);
    if (n.value === void 0)
      return n.value = t.defaultValue, n;
    let r = t.innerType._zod.run(n, o);
    return r instanceof Promise ? r.then((i) => Zl(i, t)) : Zl(r, t);
  };
});
function Zl(e, t) {
  return e.value === void 0 && (e.value = t.defaultValue), e;
}
a(Zl, "handleDefaultResult");
var pa = /* @__PURE__ */ f("$ZodPrefault", (e, t) => {
  _.init(e, t), e._zod.optin = "optional", I(e._zod, "values", () => t.innerType._zod.values), e._zod.parse = (n, o) => (o.direction === "backward" || n.value === void 0 && (n.value = t.defaultValue), t.innerType._zod.run(n, o));
}), ma = /* @__PURE__ */ f("$ZodNonOptional", (e, t) => {
  _.init(e, t), I(e._zod, "values", () => {
    let n = t.innerType._zod.values;
    return n ? new Set([...n].filter((o) => o !== void 0)) : void 0;
  }), e._zod.parse = (n, o) => {
    let r = t.innerType._zod.run(n, o);
    return r instanceof Promise ? r.then((i) => Nl(i, e)) : Nl(r, e);
  };
});
function Nl(e, t) {
  return !e.issues.length && e.value === void 0 && e.issues.push({
    code: "invalid_type",
    expected: "nonoptional",
    input: e.value,
    inst: t
  }), e;
}
a(Nl, "handleNonOptionalResult");
var ga = /* @__PURE__ */ f("$ZodSuccess", (e, t) => {
  _.init(e, t), e._zod.parse = (n, o) => {
    if (o.direction === "backward")
      throw new it("ZodSuccess");
    let r = t.innerType._zod.run(n, o);
    return r instanceof Promise ? r.then((i) => (n.value = i.issues.length === 0, n)) : (n.value = r.issues.length === 0, n);
  };
}), ha = /* @__PURE__ */ f("$ZodCatch", (e, t) => {
  _.init(e, t), I(e._zod, "optin", () => t.innerType._zod.optin), I(e._zod, "optout", () => t.innerType._zod.optout), I(e._zod, "values", () => t.innerType._zod.values), e._zod.parse = (n, o) => {
    if (o.direction === "backward")
      return t.innerType._zod.run(n, o);
    let r = t.innerType._zod.run(n, o);
    return r instanceof Promise ? r.then((i) => (n.value = i.value, i.issues.length && (n.value = t.catchValue({
      ...n,
      error: {
        issues: i.issues.map((s) => te(s, o, X()))
      },
      input: n.value
    }), n.issues = []), n)) : (n.value = r.value, r.issues.length && (n.value = t.catchValue({
      ...n,
      error: {
        issues: r.issues.map((i) => te(i, o, X()))
      },
      input: n.value
    }), n.issues = []), n);
  };
}), va = /* @__PURE__ */ f("$ZodNaN", (e, t) => {
  _.init(e, t), e._zod.parse = (n, o) => ((typeof n.value != "number" || !Number.isNaN(n.value)) && n.issues.push({
    input: n.value,
    inst: e,
    expected: "nan",
    code: "invalid_type"
  }), n);
}), ya = /* @__PURE__ */ f("$ZodPipe", (e, t) => {
  _.init(e, t), I(e._zod, "values", () => t.in._zod.values), I(e._zod, "optin", () => t.in._zod.optin), I(e._zod, "optout", () => t.out._zod.optout), I(e._zod, "propValues", () => t.in._zod.propValues), e._zod.parse = (n, o) => {
    if (o.direction === "backward") {
      let i = t.out._zod.run(n, o);
      return i instanceof Promise ? i.then((s) => Fr(s, t.in, o)) : Fr(i, t.in, o);
    }
    let r = t.in._zod.run(n, o);
    return r instanceof Promise ? r.then((i) => Fr(i, t.out, o)) : Fr(r, t.out, o);
  };
});
function Fr(e, t, n) {
  return e.issues.length ? (e.aborted = !0, e) : t._zod.run({ value: e.value, issues: e.issues }, n);
}
a(Fr, "handlePipeResult");
var ge = /* @__PURE__ */ f("$ZodCodec", (e, t) => {
  _.init(e, t), I(e._zod, "values", () => t.in._zod.values), I(e._zod, "optin", () => t.in._zod.optin), I(e._zod, "optout", () => t.out._zod.optout), I(e._zod, "propValues", () => t.in._zod.propValues), e._zod.parse = (n, o) => {
    if ((o.direction || "forward") === "forward") {
      let i = t.in._zod.run(n, o);
      return i instanceof Promise ? i.then((s) => Mr(s, t, o)) : Mr(i, t, o);
    } else {
      let i = t.out._zod.run(n, o);
      return i instanceof Promise ? i.then((s) => Mr(s, t, o)) : Mr(i, t, o);
    }
  };
});
function Mr(e, t, n) {
  if (e.issues.length)
    return e.aborted = !0, e;
  if ((n.direction || "forward") === "forward") {
    let r = t.transform(e.value, e);
    return r instanceof Promise ? r.then((i) => Lr(e, i, t.out, n)) : Lr(e, r, t.out, n);
  } else {
    let r = t.reverseTransform(e.value, e);
    return r instanceof Promise ? r.then((i) => Lr(e, i, t.in, n)) : Lr(e, r, t.in, n);
  }
}
a(Mr, "handleCodecAResult");
function Lr(e, t, n, o) {
  return e.issues.length ? (e.aborted = !0, e) : n._zod.run({ value: t, issues: e.issues }, o);
}
a(Lr, "handleCodecTxResult");
var ba = /* @__PURE__ */ f("$ZodReadonly", (e, t) => {
  _.init(e, t), I(e._zod, "propValues", () => t.innerType._zod.propValues), I(e._zod, "values", () => t.innerType._zod.values), I(e._zod, "optin", () => t.innerType?._zod?.optin), I(e._zod, "optout", () => t.innerType?._zod?.optout), e._zod.parse = (n, o) => {
    if (o.direction === "backward")
      return t.innerType._zod.run(n, o);
    let r = t.innerType._zod.run(n, o);
    return r instanceof Promise ? r.then(Al) : Al(r);
  };
});
function Al(e) {
  return e.value = Object.freeze(e.value), e;
}
a(Al, "handleReadonlyResult");
var xa = /* @__PURE__ */ f("$ZodTemplateLiteral", (e, t) => {
  _.init(e, t);
  let n = [];
  for (let o of t.parts)
    if (typeof o == "object" && o !== null) {
      if (!o._zod.pattern)
        throw new Error(`Invalid template literal part, no pattern found: ${[...o._zod.traits].shift()}`);
      let r = o._zod.pattern instanceof RegExp ? o._zod.pattern.source : o._zod.pattern;
      if (!r)
        throw new Error(`Invalid template literal part: ${o._zod.traits}`);
      let i = r.startsWith("^") ? 1 : 0, s = r.endsWith("$") ? r.length - 1 : r.length;
      n.push(r.slice(i, s));
    } else if (o === null || li.has(typeof o))
      n.push(ue(`${o}`));
    else
      throw new Error(`Invalid template literal part: ${o}`);
  e._zod.pattern = new RegExp(`^${n.join("")}$`), e._zod.parse = (o, r) => typeof o.value != "string" ? (o.issues.push({
    input: o.value,
    inst: e,
    expected: "string",
    code: "invalid_type"
  }), o) : (e._zod.pattern.lastIndex = 0, e._zod.pattern.test(o.value) || o.issues.push({
    input: o.value,
    inst: e,
    code: "invalid_format",
    format: t.format ?? "template_literal",
    pattern: e._zod.pattern.source
  }), o);
}), $a = /* @__PURE__ */ f("$ZodFunction", (e, t) => (_.init(e, t), e._def = t, e._zod.def = t, e.implement = (n) => {
  if (typeof n != "function")
    throw new Error("implement() must be called with a function");
  return function(...o) {
    let r = e._def.input ? ne(e._def.input, o) : o, i = Reflect.apply(n, this, r);
    return e._def.output ? ne(e._def.output, i) : i;
  };
}, e.implementAsync = (n) => {
  if (typeof n != "function")
    throw new Error("implementAsync() must be called with a function");
  return async function(...o) {
    let r = e._def.input ? await je(e._def.input, o) : o, i = await Reflect.apply(n, this, r);
    return e._def.output ? await je(e._def.output, i) : i;
  };
}, e._zod.parse = (n, o) => typeof n.value != "function" ? (n.issues.push({
  code: "invalid_type",
  expected: "function",
  input: n.value,
  inst: e
}), n) : (e._def.output && e._def.output._zod.def.type === "promise" ? n.value = e.implementAsync(n.value) : n.value = e.implement(n.value), n), e.input = (...n) => {
  let o = e.constructor;
  return Array.isArray(n[0]) ? new o({
    type: "function",
    input: new Pe({
      type: "tuple",
      items: n[0],
      rest: n[1]
    }),
    output: e._def.output
  }) : new o({
    type: "function",
    input: n[0],
    output: e._def.output
  });
}, e.output = (n) => {
  let o = e.constructor;
  return new o({
    type: "function",
    input: e._def.input,
    output: n
  });
}, e)), _a = /* @__PURE__ */ f("$ZodPromise", (e, t) => {
  _.init(e, t), e._zod.parse = (n, o) => Promise.resolve(n.value).then((r) => t.innerType._zod.run({ value: r, issues: [] }, o));
}), pt = /* @__PURE__ */ f("$ZodLazy", (e, t) => {
  _.init(e, t), I(e._zod, "innerType", () => t.getter()), I(e._zod, "pattern", () => e._zod.innerType?._zod?.pattern), I(e._zod, "propValues", () => e._zod.innerType?._zod?.propValues), I(e._zod, "optin", () => e._zod.innerType?._zod?.optin ?? void 0), I(e._zod, "optout", () => e._zod.innerType?._zod?.optout ?? void 0), e._zod.parse = (n, o) => e._zod.innerType._zod.run(n, o);
}), Mt = /* @__PURE__ */ f("$ZodCustom", (e, t) => {
  N.init(e, t), _.init(e, t), e._zod.parse = (n, o) => n, e._zod.check = (n) => {
    let o = n.value, r = t.fn(o);
    if (r instanceof Promise)
      return r.then((i) => Cl(i, n, o, e));
    Cl(r, n, o, e);
  };
});
function Cl(e, t, n, o) {
  if (!e) {
    let r = {
      code: "custom",
      input: n,
      inst: o,
      // incorporates params.error into issue reporting
      path: [...o._zod.def.path ?? []],
      // incorporates params.error into issue reporting
      continue: !o._zod.def.abort
      // params: inst._zod.def.params,
    };
    o._zod.def.params && (r.params = o._zod.def.params), t.issues.push(st(r));
  }
}
a(Cl, "handleRefineResult");

// versions/4.3.6/node_modules/zod/v4/locales/index.js
var qt = {};
Ce(qt, {
  ar: () => wa,
  az: () => ka,
  be: () => za,
  bg: () => Ia,
  ca: () => Sa,
  cs: () => ja,
  da: () => Oa,
  de: () => Ta,
  en: () => Pa,
  eo: () => Ua,
  es: () => Da,
  fa: () => Ea,
  fi: () => Za,
  fr: () => Na,
  frCA: () => Aa,
  he: () => Ca,
  hu: () => Ra,
  hy: () => Fa,
  id: () => Ma,
  is: () => La,
  it: () => Ba,
  ja: () => Va,
  ka: () => qa,
  kh: () => Ja,
  km: () => Lt,
  ko: () => Wa,
  lt: () => Ka,
  mk: () => Ga,
  ms: () => Xa,
  nl: () => Ha,
  no: () => Qa,
  ota: () => Ya,
  pl: () => ts,
  ps: () => es,
  pt: () => rs,
  ru: () => ns,
  sl: () => is,
  sv: () => os,
  ta: () => as,
  th: () => ss,
  tr: () => cs,
  ua: () => us,
  uk: () => Vt,
  ur: () => ls,
  uz: () => ds,
  vi: () => fs,
  yo: () => gs,
  zhCN: () => ps,
  zhTW: () => ms
});

// versions/4.3.6/node_modules/zod/v4/locales/ar.js
var og = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "\u062D\u0631\u0641", verb: "\u0623\u0646 \u064A\u062D\u0648\u064A" },
    file: { unit: "\u0628\u0627\u064A\u062A", verb: "\u0623\u0646 \u064A\u062D\u0648\u064A" },
    array: { unit: "\u0639\u0646\u0635\u0631", verb: "\u0623\u0646 \u064A\u062D\u0648\u064A" },
    set: { unit: "\u0639\u0646\u0635\u0631", verb: "\u0623\u0646 \u064A\u062D\u0648\u064A" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "\u0645\u062F\u062E\u0644",
    email: "\u0628\u0631\u064A\u062F \u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A",
    url: "\u0631\u0627\u0628\u0637",
    emoji: "\u0625\u064A\u0645\u0648\u062C\u064A",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u062A\u0627\u0631\u064A\u062E \u0648\u0648\u0642\u062A \u0628\u0645\u0639\u064A\u0627\u0631 ISO",
    date: "\u062A\u0627\u0631\u064A\u062E \u0628\u0645\u0639\u064A\u0627\u0631 ISO",
    time: "\u0648\u0642\u062A \u0628\u0645\u0639\u064A\u0627\u0631 ISO",
    duration: "\u0645\u062F\u0629 \u0628\u0645\u0639\u064A\u0627\u0631 ISO",
    ipv4: "\u0639\u0646\u0648\u0627\u0646 IPv4",
    ipv6: "\u0639\u0646\u0648\u0627\u0646 IPv6",
    cidrv4: "\u0645\u062F\u0649 \u0639\u0646\u0627\u0648\u064A\u0646 \u0628\u0635\u064A\u063A\u0629 IPv4",
    cidrv6: "\u0645\u062F\u0649 \u0639\u0646\u0627\u0648\u064A\u0646 \u0628\u0635\u064A\u063A\u0629 IPv6",
    base64: "\u0646\u064E\u0635 \u0628\u062A\u0631\u0645\u064A\u0632 base64-encoded",
    base64url: "\u0646\u064E\u0635 \u0628\u062A\u0631\u0645\u064A\u0632 base64url-encoded",
    json_string: "\u0646\u064E\u0635 \u0639\u0644\u0649 \u0647\u064A\u0626\u0629 JSON",
    e164: "\u0631\u0642\u0645 \u0647\u0627\u062A\u0641 \u0628\u0645\u0639\u064A\u0627\u0631 E.164",
    jwt: "JWT",
    template_literal: "\u0645\u062F\u062E\u0644"
  }, o = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = y(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `\u0645\u062F\u062E\u0644\u0627\u062A \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644\u0629: \u064A\u0641\u062A\u0631\u0636 \u0625\u062F\u062E\u0627\u0644 instanceof ${r.expected}\u060C \u0648\u0644\u0643\u0646 \u062A\u0645 \u0625\u062F\u062E\u0627\u0644 ${c}` : `\u0645\u062F\u062E\u0644\u0627\u062A \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644\u0629: \u064A\u0641\u062A\u0631\u0636 \u0625\u062F\u062E\u0627\u0644 ${i}\u060C \u0648\u0644\u0643\u0646 \u062A\u0645 \u0625\u062F\u062E\u0627\u0644 ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u0645\u062F\u062E\u0644\u0627\u062A \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644\u0629: \u064A\u0641\u062A\u0631\u0636 \u0625\u062F\u062E\u0627\u0644 ${v(r.values[0])}` : `\u0627\u062E\u062A\u064A\u0627\u0631 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062A\u0648\u0642\u0639 \u0627\u0646\u062A\u0642\u0627\u0621 \u0623\u062D\u062F \u0647\u0630\u0647 \u0627\u0644\u062E\u064A\u0627\u0631\u0627\u062A: ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? ` \u0623\u0643\u0628\u0631 \u0645\u0646 \u0627\u0644\u0644\u0627\u0632\u0645: \u064A\u0641\u062A\u0631\u0636 \u0623\u0646 \u062A\u0643\u0648\u0646 ${r.origin ?? "\u0627\u0644\u0642\u064A\u0645\u0629"} ${i} ${r.maximum.toString()} ${s.unit ?? "\u0639\u0646\u0635\u0631"}` : `\u0623\u0643\u0628\u0631 \u0645\u0646 \u0627\u0644\u0644\u0627\u0632\u0645: \u064A\u0641\u062A\u0631\u0636 \u0623\u0646 \u062A\u0643\u0648\u0646 ${r.origin ?? "\u0627\u0644\u0642\u064A\u0645\u0629"} ${i} ${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `\u0623\u0635\u063A\u0631 \u0645\u0646 \u0627\u0644\u0644\u0627\u0632\u0645: \u064A\u0641\u062A\u0631\u0636 \u0644\u0640 ${r.origin} \u0623\u0646 \u064A\u0643\u0648\u0646 ${i} ${r.minimum.toString()} ${s.unit}` : `\u0623\u0635\u063A\u0631 \u0645\u0646 \u0627\u0644\u0644\u0627\u0632\u0645: \u064A\u0641\u062A\u0631\u0636 \u0644\u0640 ${r.origin} \u0623\u0646 \u064A\u0643\u0648\u0646 ${i} ${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u0646\u064E\u0635 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u0628\u062F\u0623 \u0628\u0640 "${r.prefix}"` : i.format === "ends_with" ? `\u0646\u064E\u0635 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u0646\u062A\u0647\u064A \u0628\u0640 "${i.suffix}"` : i.format === "includes" ? `\u0646\u064E\u0635 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u062A\u0636\u0645\u0651\u064E\u0646 "${i.includes}"` : i.format === "regex" ? `\u0646\u064E\u0635 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u0637\u0627\u0628\u0642 \u0627\u0644\u0646\u0645\u0637 ${i.pattern}` : `${n[i.format] ?? r.format} \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644`;
      }
      case "not_multiple_of":
        return `\u0631\u0642\u0645 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u0643\u0648\u0646 \u0645\u0646 \u0645\u0636\u0627\u0639\u0641\u0627\u062A ${r.divisor}`;
      case "unrecognized_keys":
        return `\u0645\u0639\u0631\u0641${r.keys.length > 1 ? "\u0627\u062A" : ""} \u063A\u0631\u064A\u0628${r.keys.length > 1 ? "\u0629" : ""}: ${p(r.keys, "\u060C ")}`;
      case "invalid_key":
        return `\u0645\u0639\u0631\u0641 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644 \u0641\u064A ${r.origin}`;
      case "invalid_union":
        return "\u0645\u062F\u062E\u0644 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644";
      case "invalid_element":
        return `\u0645\u062F\u062E\u0644 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644 \u0641\u064A ${r.origin}`;
      default:
        return "\u0645\u062F\u062E\u0644 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644";
    }
  };
}, "error");
function wa() {
  return {
    localeError: og()
  };
}
a(wa, "default");

// versions/4.3.6/node_modules/zod/v4/locales/az.js
var ag = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "simvol", verb: "olmal\u0131d\u0131r" },
    file: { unit: "bayt", verb: "olmal\u0131d\u0131r" },
    array: { unit: "element", verb: "olmal\u0131d\u0131r" },
    set: { unit: "element", verb: "olmal\u0131d\u0131r" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "input",
    email: "email address",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datetime",
    date: "ISO date",
    time: "ISO time",
    duration: "ISO duration",
    ipv4: "IPv4 address",
    ipv6: "IPv6 address",
    cidrv4: "IPv4 range",
    cidrv6: "IPv6 range",
    base64: "base64-encoded string",
    base64url: "base64url-encoded string",
    json_string: "JSON string",
    e164: "E.164 number",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = y(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Yanl\u0131\u015F d\u0259y\u0259r: g\xF6zl\u0259nil\u0259n instanceof ${r.expected}, daxil olan ${c}` : `Yanl\u0131\u015F d\u0259y\u0259r: g\xF6zl\u0259nil\u0259n ${i}, daxil olan ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Yanl\u0131\u015F d\u0259y\u0259r: g\xF6zl\u0259nil\u0259n ${v(r.values[0])}` : `Yanl\u0131\u015F se\xE7im: a\u015Fa\u011F\u0131dak\u0131lardan biri olmal\u0131d\u0131r: ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `\xC7ox b\xF6y\xFCk: g\xF6zl\u0259nil\u0259n ${r.origin ?? "d\u0259y\u0259r"} ${i}${r.maximum.toString()} ${s.unit ?? "element"}` : `\xC7ox b\xF6y\xFCk: g\xF6zl\u0259nil\u0259n ${r.origin ?? "d\u0259y\u0259r"} ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `\xC7ox ki\xE7ik: g\xF6zl\u0259nil\u0259n ${r.origin} ${i}${r.minimum.toString()} ${s.unit}` : `\xC7ox ki\xE7ik: g\xF6zl\u0259nil\u0259n ${r.origin} ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Yanl\u0131\u015F m\u0259tn: "${i.prefix}" il\u0259 ba\u015Flamal\u0131d\u0131r` : i.format === "ends_with" ? `Yanl\u0131\u015F m\u0259tn: "${i.suffix}" il\u0259 bitm\u0259lidir` : i.format === "includes" ? `Yanl\u0131\u015F m\u0259tn: "${i.includes}" daxil olmal\u0131d\u0131r` : i.format === "regex" ? `Yanl\u0131\u015F m\u0259tn: ${i.pattern} \u015Fablonuna uy\u011Fun olmal\u0131d\u0131r` : `Yanl\u0131\u015F ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Yanl\u0131\u015F \u0259d\u0259d: ${r.divisor} il\u0259 b\xF6l\xFCn\u0259 bil\u0259n olmal\u0131d\u0131r`;
      case "unrecognized_keys":
        return `Tan\u0131nmayan a\xE7ar${r.keys.length > 1 ? "lar" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `${r.origin} daxilind\u0259 yanl\u0131\u015F a\xE7ar`;
      case "invalid_union":
        return "Yanl\u0131\u015F d\u0259y\u0259r";
      case "invalid_element":
        return `${r.origin} daxilind\u0259 yanl\u0131\u015F d\u0259y\u0259r`;
      default:
        return "Yanl\u0131\u015F d\u0259y\u0259r";
    }
  };
}, "error");
function ka() {
  return {
    localeError: ag()
  };
}
a(ka, "default");

// versions/4.3.6/node_modules/zod/v4/locales/be.js
function Bl(e, t, n, o) {
  let r = Math.abs(e), i = r % 10, s = r % 100;
  return s >= 11 && s <= 19 ? o : i === 1 ? t : i >= 2 && i <= 4 ? n : o;
}
a(Bl, "getBelarusianPlural");
var sg = /* @__PURE__ */ a(() => {
  let e = {
    string: {
      unit: {
        one: "\u0441\u0456\u043C\u0432\u0430\u043B",
        few: "\u0441\u0456\u043C\u0432\u0430\u043B\u044B",
        many: "\u0441\u0456\u043C\u0432\u0430\u043B\u0430\u045E"
      },
      verb: "\u043C\u0435\u0446\u044C"
    },
    array: {
      unit: {
        one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
        few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u044B",
        many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430\u045E"
      },
      verb: "\u043C\u0435\u0446\u044C"
    },
    set: {
      unit: {
        one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
        few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u044B",
        many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430\u045E"
      },
      verb: "\u043C\u0435\u0446\u044C"
    },
    file: {
      unit: {
        one: "\u0431\u0430\u0439\u0442",
        few: "\u0431\u0430\u0439\u0442\u044B",
        many: "\u0431\u0430\u0439\u0442\u0430\u045E"
      },
      verb: "\u043C\u0435\u0446\u044C"
    }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "\u0443\u0432\u043E\u0434",
    email: "email \u0430\u0434\u0440\u0430\u0441",
    url: "URL",
    emoji: "\u044D\u043C\u043E\u0434\u0437\u0456",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0434\u0430\u0442\u0430 \u0456 \u0447\u0430\u0441",
    date: "ISO \u0434\u0430\u0442\u0430",
    time: "ISO \u0447\u0430\u0441",
    duration: "ISO \u043F\u0440\u0430\u0446\u044F\u0433\u043B\u0430\u0441\u0446\u044C",
    ipv4: "IPv4 \u0430\u0434\u0440\u0430\u0441",
    ipv6: "IPv6 \u0430\u0434\u0440\u0430\u0441",
    cidrv4: "IPv4 \u0434\u044B\u044F\u043F\u0430\u0437\u043E\u043D",
    cidrv6: "IPv6 \u0434\u044B\u044F\u043F\u0430\u0437\u043E\u043D",
    base64: "\u0440\u0430\u0434\u043E\u043A \u0443 \u0444\u0430\u0440\u043C\u0430\u0446\u0435 base64",
    base64url: "\u0440\u0430\u0434\u043E\u043A \u0443 \u0444\u0430\u0440\u043C\u0430\u0446\u0435 base64url",
    json_string: "JSON \u0440\u0430\u0434\u043E\u043A",
    e164: "\u043D\u0443\u043C\u0430\u0440 E.164",
    jwt: "JWT",
    template_literal: "\u0443\u0432\u043E\u0434"
  }, o = {
    nan: "NaN",
    number: "\u043B\u0456\u043A",
    array: "\u043C\u0430\u0441\u0456\u045E"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = y(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434: \u0447\u0430\u043A\u0430\u045E\u0441\u044F instanceof ${r.expected}, \u0430\u0442\u0440\u044B\u043C\u0430\u043D\u0430 ${c}` : `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434: \u0447\u0430\u043A\u0430\u045E\u0441\u044F ${i}, \u0430\u0442\u0440\u044B\u043C\u0430\u043D\u0430 ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F ${v(r.values[0])}` : `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0432\u0430\u0440\u044B\u044F\u043D\u0442: \u0447\u0430\u043A\u0430\u045E\u0441\u044F \u0430\u0434\u0437\u0456\u043D \u0437 ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        if (s) {
          let c = Number(r.maximum), u = Bl(c, s.unit.one, s.unit.few, s.unit.many);
          return `\u0417\u0430\u043D\u0430\u0434\u0442\u0430 \u0432\u044F\u043B\u0456\u043A\u0456: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F, \u0448\u0442\u043E ${r.origin ?? "\u0437\u043D\u0430\u0447\u044D\u043D\u043D\u0435"} \u043F\u0430\u0432\u0456\u043D\u043D\u0430 ${s.verb} ${i}${r.maximum.toString()} ${u}`;
        }
        return `\u0417\u0430\u043D\u0430\u0434\u0442\u0430 \u0432\u044F\u043B\u0456\u043A\u0456: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F, \u0448\u0442\u043E ${r.origin ?? "\u0437\u043D\u0430\u0447\u044D\u043D\u043D\u0435"} \u043F\u0430\u0432\u0456\u043D\u043D\u0430 \u0431\u044B\u0446\u044C ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        if (s) {
          let c = Number(r.minimum), u = Bl(c, s.unit.one, s.unit.few, s.unit.many);
          return `\u0417\u0430\u043D\u0430\u0434\u0442\u0430 \u043C\u0430\u043B\u044B: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F, \u0448\u0442\u043E ${r.origin} \u043F\u0430\u0432\u0456\u043D\u043D\u0430 ${s.verb} ${i}${r.minimum.toString()} ${u}`;
        }
        return `\u0417\u0430\u043D\u0430\u0434\u0442\u0430 \u043C\u0430\u043B\u044B: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F, \u0448\u0442\u043E ${r.origin} \u043F\u0430\u0432\u0456\u043D\u043D\u0430 \u0431\u044B\u0446\u044C ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0440\u0430\u0434\u043E\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u043F\u0430\u0447\u044B\u043D\u0430\u0446\u0446\u0430 \u0437 "${i.prefix}"` : i.format === "ends_with" ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0440\u0430\u0434\u043E\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u0437\u0430\u043A\u0430\u043D\u0447\u0432\u0430\u0446\u0446\u0430 \u043D\u0430 "${i.suffix}"` : i.format === "includes" ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0440\u0430\u0434\u043E\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u0437\u043C\u044F\u0448\u0447\u0430\u0446\u044C "${i.includes}"` : i.format === "regex" ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0440\u0430\u0434\u043E\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u0430\u0434\u043F\u0430\u0432\u044F\u0434\u0430\u0446\u044C \u0448\u0430\u0431\u043B\u043E\u043D\u0443 ${i.pattern}` : `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u043B\u0456\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u0431\u044B\u0446\u044C \u043A\u0440\u0430\u0442\u043D\u044B\u043C ${r.divisor}`;
      case "unrecognized_keys":
        return `\u041D\u0435\u0440\u0430\u0441\u043F\u0430\u0437\u043D\u0430\u043D\u044B ${r.keys.length > 1 ? "\u043A\u043B\u044E\u0447\u044B" : "\u043A\u043B\u044E\u0447"}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u043A\u043B\u044E\u0447 \u0443 ${r.origin}`;
      case "invalid_union":
        return "\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434";
      case "invalid_element":
        return `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u0430\u0435 \u0437\u043D\u0430\u0447\u044D\u043D\u043D\u0435 \u045E ${r.origin}`;
      default:
        return "\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434";
    }
  };
}, "error");
function za() {
  return {
    localeError: sg()
  };
}
a(za, "default");

// versions/4.3.6/node_modules/zod/v4/locales/bg.js
var cg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "\u0441\u0438\u043C\u0432\u043E\u043B\u0430", verb: "\u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430" },
    file: { unit: "\u0431\u0430\u0439\u0442\u0430", verb: "\u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430" },
    array: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0430", verb: "\u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430" },
    set: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0430", verb: "\u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "\u0432\u0445\u043E\u0434",
    email: "\u0438\u043C\u0435\u0439\u043B \u0430\u0434\u0440\u0435\u0441",
    url: "URL",
    emoji: "\u0435\u043C\u043E\u0434\u0436\u0438",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0432\u0440\u0435\u043C\u0435",
    date: "ISO \u0434\u0430\u0442\u0430",
    time: "ISO \u0432\u0440\u0435\u043C\u0435",
    duration: "ISO \u043F\u0440\u043E\u0434\u044A\u043B\u0436\u0438\u0442\u0435\u043B\u043D\u043E\u0441\u0442",
    ipv4: "IPv4 \u0430\u0434\u0440\u0435\u0441",
    ipv6: "IPv6 \u0430\u0434\u0440\u0435\u0441",
    cidrv4: "IPv4 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D",
    cidrv6: "IPv6 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D",
    base64: "base64-\u043A\u043E\u0434\u0438\u0440\u0430\u043D \u043D\u0438\u0437",
    base64url: "base64url-\u043A\u043E\u0434\u0438\u0440\u0430\u043D \u043D\u0438\u0437",
    json_string: "JSON \u043D\u0438\u0437",
    e164: "E.164 \u043D\u043E\u043C\u0435\u0440",
    jwt: "JWT",
    template_literal: "\u0432\u0445\u043E\u0434"
  }, o = {
    nan: "NaN",
    number: "\u0447\u0438\u0441\u043B\u043E",
    array: "\u043C\u0430\u0441\u0438\u0432"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = y(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434: \u043E\u0447\u0430\u043A\u0432\u0430\u043D instanceof ${r.expected}, \u043F\u043E\u043B\u0443\u0447\u0435\u043D ${c}` : `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434: \u043E\u0447\u0430\u043A\u0432\u0430\u043D ${i}, \u043F\u043E\u043B\u0443\u0447\u0435\u043D ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434: \u043E\u0447\u0430\u043A\u0432\u0430\u043D ${v(r.values[0])}` : `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u0430 \u043E\u043F\u0446\u0438\u044F: \u043E\u0447\u0430\u043A\u0432\u0430\u043D\u043E \u0435\u0434\u043D\u043E \u043E\u0442 ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `\u0422\u0432\u044A\u0440\u0434\u0435 \u0433\u043E\u043B\u044F\u043C\u043E: \u043E\u0447\u0430\u043A\u0432\u0430 \u0441\u0435 ${r.origin ?? "\u0441\u0442\u043E\u0439\u043D\u043E\u0441\u0442"} \u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430 ${i}${r.maximum.toString()} ${s.unit ?? "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0430"}` : `\u0422\u0432\u044A\u0440\u0434\u0435 \u0433\u043E\u043B\u044F\u043C\u043E: \u043E\u0447\u0430\u043A\u0432\u0430 \u0441\u0435 ${r.origin ?? "\u0441\u0442\u043E\u0439\u043D\u043E\u0441\u0442"} \u0434\u0430 \u0431\u044A\u0434\u0435 ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `\u0422\u0432\u044A\u0440\u0434\u0435 \u043C\u0430\u043B\u043A\u043E: \u043E\u0447\u0430\u043A\u0432\u0430 \u0441\u0435 ${r.origin} \u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430 ${i}${r.minimum.toString()} ${s.unit}` : `\u0422\u0432\u044A\u0440\u0434\u0435 \u043C\u0430\u043B\u043A\u043E: \u043E\u0447\u0430\u043A\u0432\u0430 \u0441\u0435 ${r.origin} \u0434\u0430 \u0431\u044A\u0434\u0435 ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        if (i.format === "starts_with")
          return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043D\u0438\u0437: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0437\u0430\u043F\u043E\u0447\u0432\u0430 \u0441 "${i.prefix}"`;
        if (i.format === "ends_with")
          return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043D\u0438\u0437: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0437\u0430\u0432\u044A\u0440\u0448\u0432\u0430 \u0441 "${i.suffix}"`;
        if (i.format === "includes")
          return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043D\u0438\u0437: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0432\u043A\u043B\u044E\u0447\u0432\u0430 "${i.includes}"`;
        if (i.format === "regex")
          return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043D\u0438\u0437: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0441\u044A\u0432\u043F\u0430\u0434\u0430 \u0441 ${i.pattern}`;
        let s = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D";
        return i.format === "emoji" && (s = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u043E"), i.format === "datetime" && (s = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u043E"), i.format === "date" && (s = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u0430"), i.format === "time" && (s = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u043E"), i.format === "duration" && (s = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u0430"), `${s} ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u043E \u0447\u0438\u0441\u043B\u043E: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0431\u044A\u0434\u0435 \u043A\u0440\u0430\u0442\u043D\u043E \u043D\u0430 ${r.divisor}`;
      case "unrecognized_keys":
        return `\u041D\u0435\u0440\u0430\u0437\u043F\u043E\u0437\u043D\u0430\u0442${r.keys.length > 1 ? "\u0438" : ""} \u043A\u043B\u044E\u0447${r.keys.length > 1 ? "\u043E\u0432\u0435" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043A\u043B\u044E\u0447 \u0432 ${r.origin}`;
      case "invalid_union":
        return "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434";
      case "invalid_element":
        return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u0430 \u0441\u0442\u043E\u0439\u043D\u043E\u0441\u0442 \u0432 ${r.origin}`;
      default:
        return "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434";
    }
  };
}, "error");
function Ia() {
  return {
    localeError: cg()
  };
}
a(Ia, "default");

// versions/4.3.6/node_modules/zod/v4/locales/ca.js
var ug = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "car\xE0cters", verb: "contenir" },
    file: { unit: "bytes", verb: "contenir" },
    array: { unit: "elements", verb: "contenir" },
    set: { unit: "elements", verb: "contenir" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "entrada",
    email: "adre\xE7a electr\xF2nica",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "data i hora ISO",
    date: "data ISO",
    time: "hora ISO",
    duration: "durada ISO",
    ipv4: "adre\xE7a IPv4",
    ipv6: "adre\xE7a IPv6",
    cidrv4: "rang IPv4",
    cidrv6: "rang IPv6",
    base64: "cadena codificada en base64",
    base64url: "cadena codificada en base64url",
    json_string: "cadena JSON",
    e164: "n\xFAmero E.164",
    jwt: "JWT",
    template_literal: "entrada"
  }, o = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = y(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Tipus inv\xE0lid: s'esperava instanceof ${r.expected}, s'ha rebut ${c}` : `Tipus inv\xE0lid: s'esperava ${i}, s'ha rebut ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Valor inv\xE0lid: s'esperava ${v(r.values[0])}` : `Opci\xF3 inv\xE0lida: s'esperava una de ${p(r.values, " o ")}`;
      case "too_big": {
        let i = r.inclusive ? "com a m\xE0xim" : "menys de", s = t(r.origin);
        return s ? `Massa gran: s'esperava que ${r.origin ?? "el valor"} contingu\xE9s ${i} ${r.maximum.toString()} ${s.unit ?? "elements"}` : `Massa gran: s'esperava que ${r.origin ?? "el valor"} fos ${i} ${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? "com a m\xEDnim" : "m\xE9s de", s = t(r.origin);
        return s ? `Massa petit: s'esperava que ${r.origin} contingu\xE9s ${i} ${r.minimum.toString()} ${s.unit}` : `Massa petit: s'esperava que ${r.origin} fos ${i} ${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Format inv\xE0lid: ha de comen\xE7ar amb "${i.prefix}"` : i.format === "ends_with" ? `Format inv\xE0lid: ha d'acabar amb "${i.suffix}"` : i.format === "includes" ? `Format inv\xE0lid: ha d'incloure "${i.includes}"` : i.format === "regex" ? `Format inv\xE0lid: ha de coincidir amb el patr\xF3 ${i.pattern}` : `Format inv\xE0lid per a ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `N\xFAmero inv\xE0lid: ha de ser m\xFAltiple de ${r.divisor}`;
      case "unrecognized_keys":
        return `Clau${r.keys.length > 1 ? "s" : ""} no reconeguda${r.keys.length > 1 ? "s" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Clau inv\xE0lida a ${r.origin}`;
      case "invalid_union":
        return "Entrada inv\xE0lida";
      // Could also be "Tipus d'unió invàlid" but "Entrada invàlida" is more general
      case "invalid_element":
        return `Element inv\xE0lid a ${r.origin}`;
      default:
        return "Entrada inv\xE0lida";
    }
  };
}, "error");
function Sa() {
  return {
    localeError: ug()
  };
}
a(Sa, "default");

// versions/4.3.6/node_modules/zod/v4/locales/cs.js
var lg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "znak\u016F", verb: "m\xEDt" },
    file: { unit: "bajt\u016F", verb: "m\xEDt" },
    array: { unit: "prvk\u016F", verb: "m\xEDt" },
    set: { unit: "prvk\u016F", verb: "m\xEDt" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "regul\xE1rn\xED v\xFDraz",
    email: "e-mailov\xE1 adresa",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "datum a \u010Das ve form\xE1tu ISO",
    date: "datum ve form\xE1tu ISO",
    time: "\u010Das ve form\xE1tu ISO",
    duration: "doba trv\xE1n\xED ISO",
    ipv4: "IPv4 adresa",
    ipv6: "IPv6 adresa",
    cidrv4: "rozsah IPv4",
    cidrv6: "rozsah IPv6",
    base64: "\u0159et\u011Bzec zak\xF3dovan\xFD ve form\xE1tu base64",
    base64url: "\u0159et\u011Bzec zak\xF3dovan\xFD ve form\xE1tu base64url",
    json_string: "\u0159et\u011Bzec ve form\xE1tu JSON",
    e164: "\u010D\xEDslo E.164",
    jwt: "JWT",
    template_literal: "vstup"
  }, o = {
    nan: "NaN",
    number: "\u010D\xEDslo",
    string: "\u0159et\u011Bzec",
    function: "funkce",
    array: "pole"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = y(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Neplatn\xFD vstup: o\u010Dek\xE1v\xE1no instanceof ${r.expected}, obdr\u017Eeno ${c}` : `Neplatn\xFD vstup: o\u010Dek\xE1v\xE1no ${i}, obdr\u017Eeno ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Neplatn\xFD vstup: o\u010Dek\xE1v\xE1no ${v(r.values[0])}` : `Neplatn\xE1 mo\u017Enost: o\u010Dek\xE1v\xE1na jedna z hodnot ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `Hodnota je p\u0159\xEDli\u0161 velk\xE1: ${r.origin ?? "hodnota"} mus\xED m\xEDt ${i}${r.maximum.toString()} ${s.unit ?? "prvk\u016F"}` : `Hodnota je p\u0159\xEDli\u0161 velk\xE1: ${r.origin ?? "hodnota"} mus\xED b\xFDt ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `Hodnota je p\u0159\xEDli\u0161 mal\xE1: ${r.origin ?? "hodnota"} mus\xED m\xEDt ${i}${r.minimum.toString()} ${s.unit ?? "prvk\u016F"}` : `Hodnota je p\u0159\xEDli\u0161 mal\xE1: ${r.origin ?? "hodnota"} mus\xED b\xFDt ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Neplatn\xFD \u0159et\u011Bzec: mus\xED za\u010D\xEDnat na "${i.prefix}"` : i.format === "ends_with" ? `Neplatn\xFD \u0159et\u011Bzec: mus\xED kon\u010Dit na "${i.suffix}"` : i.format === "includes" ? `Neplatn\xFD \u0159et\u011Bzec: mus\xED obsahovat "${i.includes}"` : i.format === "regex" ? `Neplatn\xFD \u0159et\u011Bzec: mus\xED odpov\xEDdat vzoru ${i.pattern}` : `Neplatn\xFD form\xE1t ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Neplatn\xE9 \u010D\xEDslo: mus\xED b\xFDt n\xE1sobkem ${r.divisor}`;
      case "unrecognized_keys":
        return `Nezn\xE1m\xE9 kl\xED\u010De: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Neplatn\xFD kl\xED\u010D v ${r.origin}`;
      case "invalid_union":
        return "Neplatn\xFD vstup";
      case "invalid_element":
        return `Neplatn\xE1 hodnota v ${r.origin}`;
      default:
        return "Neplatn\xFD vstup";
    }
  };
}, "error");
function ja() {
  return {
    localeError: lg()
  };
}
a(ja, "default");

// versions/4.3.6/node_modules/zod/v4/locales/da.js
var dg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "tegn", verb: "havde" },
    file: { unit: "bytes", verb: "havde" },
    array: { unit: "elementer", verb: "indeholdt" },
    set: { unit: "elementer", verb: "indeholdt" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "input",
    email: "e-mailadresse",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO dato- og klokkesl\xE6t",
    date: "ISO-dato",
    time: "ISO-klokkesl\xE6t",
    duration: "ISO-varighed",
    ipv4: "IPv4-omr\xE5de",
    ipv6: "IPv6-omr\xE5de",
    cidrv4: "IPv4-spektrum",
    cidrv6: "IPv6-spektrum",
    base64: "base64-kodet streng",
    base64url: "base64url-kodet streng",
    json_string: "JSON-streng",
    e164: "E.164-nummer",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN",
    string: "streng",
    number: "tal",
    boolean: "boolean",
    array: "liste",
    object: "objekt",
    set: "s\xE6t",
    file: "fil"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = y(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Ugyldigt input: forventede instanceof ${r.expected}, fik ${c}` : `Ugyldigt input: forventede ${i}, fik ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Ugyldig v\xE6rdi: forventede ${v(r.values[0])}` : `Ugyldigt valg: forventede en af f\xF8lgende ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin), c = o[r.origin] ?? r.origin;
        return s ? `For stor: forventede ${c ?? "value"} ${s.verb} ${i} ${r.maximum.toString()} ${s.unit ?? "elementer"}` : `For stor: forventede ${c ?? "value"} havde ${i} ${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin), c = o[r.origin] ?? r.origin;
        return s ? `For lille: forventede ${c} ${s.verb} ${i} ${r.minimum.toString()} ${s.unit}` : `For lille: forventede ${c} havde ${i} ${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Ugyldig streng: skal starte med "${i.prefix}"` : i.format === "ends_with" ? `Ugyldig streng: skal ende med "${i.suffix}"` : i.format === "includes" ? `Ugyldig streng: skal indeholde "${i.includes}"` : i.format === "regex" ? `Ugyldig streng: skal matche m\xF8nsteret ${i.pattern}` : `Ugyldig ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Ugyldigt tal: skal v\xE6re deleligt med ${r.divisor}`;
      case "unrecognized_keys":
        return `${r.keys.length > 1 ? "Ukendte n\xF8gler" : "Ukendt n\xF8gle"}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Ugyldig n\xF8gle i ${r.origin}`;
      case "invalid_union":
        return "Ugyldigt input: matcher ingen af de tilladte typer";
      case "invalid_element":
        return `Ugyldig v\xE6rdi i ${r.origin}`;
      default:
        return "Ugyldigt input";
    }
  };
}, "error");
function Oa() {
  return {
    localeError: dg()
  };
}
a(Oa, "default");

// versions/4.3.6/node_modules/zod/v4/locales/de.js
var fg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "Zeichen", verb: "zu haben" },
    file: { unit: "Bytes", verb: "zu haben" },
    array: { unit: "Elemente", verb: "zu haben" },
    set: { unit: "Elemente", verb: "zu haben" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "Eingabe",
    email: "E-Mail-Adresse",
    url: "URL",
    emoji: "Emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO-Datum und -Uhrzeit",
    date: "ISO-Datum",
    time: "ISO-Uhrzeit",
    duration: "ISO-Dauer",
    ipv4: "IPv4-Adresse",
    ipv6: "IPv6-Adresse",
    cidrv4: "IPv4-Bereich",
    cidrv6: "IPv6-Bereich",
    base64: "Base64-codierter String",
    base64url: "Base64-URL-codierter String",
    json_string: "JSON-String",
    e164: "E.164-Nummer",
    jwt: "JWT",
    template_literal: "Eingabe"
  }, o = {
    nan: "NaN",
    number: "Zahl",
    array: "Array"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = y(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Ung\xFCltige Eingabe: erwartet instanceof ${r.expected}, erhalten ${c}` : `Ung\xFCltige Eingabe: erwartet ${i}, erhalten ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Ung\xFCltige Eingabe: erwartet ${v(r.values[0])}` : `Ung\xFCltige Option: erwartet eine von ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `Zu gro\xDF: erwartet, dass ${r.origin ?? "Wert"} ${i}${r.maximum.toString()} ${s.unit ?? "Elemente"} hat` : `Zu gro\xDF: erwartet, dass ${r.origin ?? "Wert"} ${i}${r.maximum.toString()} ist`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `Zu klein: erwartet, dass ${r.origin} ${i}${r.minimum.toString()} ${s.unit} hat` : `Zu klein: erwartet, dass ${r.origin} ${i}${r.minimum.toString()} ist`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Ung\xFCltiger String: muss mit "${i.prefix}" beginnen` : i.format === "ends_with" ? `Ung\xFCltiger String: muss mit "${i.suffix}" enden` : i.format === "includes" ? `Ung\xFCltiger String: muss "${i.includes}" enthalten` : i.format === "regex" ? `Ung\xFCltiger String: muss dem Muster ${i.pattern} entsprechen` : `Ung\xFCltig: ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Ung\xFCltige Zahl: muss ein Vielfaches von ${r.divisor} sein`;
      case "unrecognized_keys":
        return `${r.keys.length > 1 ? "Unbekannte Schl\xFCssel" : "Unbekannter Schl\xFCssel"}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Ung\xFCltiger Schl\xFCssel in ${r.origin}`;
      case "invalid_union":
        return "Ung\xFCltige Eingabe";
      case "invalid_element":
        return `Ung\xFCltiger Wert in ${r.origin}`;
      default:
        return "Ung\xFCltige Eingabe";
    }
  };
}, "error");
function Ta() {
  return {
    localeError: fg()
  };
}
a(Ta, "default");

// versions/4.3.6/node_modules/zod/v4/locales/en.js
var pg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "characters", verb: "to have" },
    file: { unit: "bytes", verb: "to have" },
    array: { unit: "items", verb: "to have" },
    set: { unit: "items", verb: "to have" },
    map: { unit: "entries", verb: "to have" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "input",
    email: "email address",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datetime",
    date: "ISO date",
    time: "ISO time",
    duration: "ISO duration",
    ipv4: "IPv4 address",
    ipv6: "IPv6 address",
    mac: "MAC address",
    cidrv4: "IPv4 range",
    cidrv6: "IPv6 range",
    base64: "base64-encoded string",
    base64url: "base64url-encoded string",
    json_string: "JSON string",
    e164: "E.164 number",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    // Compatibility: "nan" -> "NaN" for display
    nan: "NaN"
    // All other type names omitted - they fall back to raw values via ?? operator
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = y(r.input), c = o[s] ?? s;
        return `Invalid input: expected ${i}, received ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Invalid input: expected ${v(r.values[0])}` : `Invalid option: expected one of ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `Too big: expected ${r.origin ?? "value"} to have ${i}${r.maximum.toString()} ${s.unit ?? "elements"}` : `Too big: expected ${r.origin ?? "value"} to be ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `Too small: expected ${r.origin} to have ${i}${r.minimum.toString()} ${s.unit}` : `Too small: expected ${r.origin} to be ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Invalid string: must start with "${i.prefix}"` : i.format === "ends_with" ? `Invalid string: must end with "${i.suffix}"` : i.format === "includes" ? `Invalid string: must include "${i.includes}"` : i.format === "regex" ? `Invalid string: must match pattern ${i.pattern}` : `Invalid ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Invalid number: must be a multiple of ${r.divisor}`;
      case "unrecognized_keys":
        return `Unrecognized key${r.keys.length > 1 ? "s" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Invalid key in ${r.origin}`;
      case "invalid_union":
        return "Invalid input";
      case "invalid_element":
        return `Invalid value in ${r.origin}`;
      default:
        return "Invalid input";
    }
  };
}, "error");
function Pa() {
  return {
    localeError: pg()
  };
}
a(Pa, "default");

// versions/4.3.6/node_modules/zod/v4/locales/eo.js
var mg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "karaktrojn", verb: "havi" },
    file: { unit: "bajtojn", verb: "havi" },
    array: { unit: "elementojn", verb: "havi" },
    set: { unit: "elementojn", verb: "havi" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "enigo",
    email: "retadreso",
    url: "URL",
    emoji: "emo\u011Dio",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO-datotempo",
    date: "ISO-dato",
    time: "ISO-tempo",
    duration: "ISO-da\u016Dro",
    ipv4: "IPv4-adreso",
    ipv6: "IPv6-adreso",
    cidrv4: "IPv4-rango",
    cidrv6: "IPv6-rango",
    base64: "64-ume kodita karaktraro",
    base64url: "URL-64-ume kodita karaktraro",
    json_string: "JSON-karaktraro",
    e164: "E.164-nombro",
    jwt: "JWT",
    template_literal: "enigo"
  }, o = {
    nan: "NaN",
    number: "nombro",
    array: "tabelo",
    null: "senvalora"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = y(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Nevalida enigo: atendi\u011Dis instanceof ${r.expected}, ricevi\u011Dis ${c}` : `Nevalida enigo: atendi\u011Dis ${i}, ricevi\u011Dis ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Nevalida enigo: atendi\u011Dis ${v(r.values[0])}` : `Nevalida opcio: atendi\u011Dis unu el ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `Tro granda: atendi\u011Dis ke ${r.origin ?? "valoro"} havu ${i}${r.maximum.toString()} ${s.unit ?? "elementojn"}` : `Tro granda: atendi\u011Dis ke ${r.origin ?? "valoro"} havu ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `Tro malgranda: atendi\u011Dis ke ${r.origin} havu ${i}${r.minimum.toString()} ${s.unit}` : `Tro malgranda: atendi\u011Dis ke ${r.origin} estu ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Nevalida karaktraro: devas komenci\u011Di per "${i.prefix}"` : i.format === "ends_with" ? `Nevalida karaktraro: devas fini\u011Di per "${i.suffix}"` : i.format === "includes" ? `Nevalida karaktraro: devas inkluzivi "${i.includes}"` : i.format === "regex" ? `Nevalida karaktraro: devas kongrui kun la modelo ${i.pattern}` : `Nevalida ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Nevalida nombro: devas esti oblo de ${r.divisor}`;
      case "unrecognized_keys":
        return `Nekonata${r.keys.length > 1 ? "j" : ""} \u015Dlosilo${r.keys.length > 1 ? "j" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Nevalida \u015Dlosilo en ${r.origin}`;
      case "invalid_union":
        return "Nevalida enigo";
      case "invalid_element":
        return `Nevalida valoro en ${r.origin}`;
      default:
        return "Nevalida enigo";
    }
  };
}, "error");
function Ua() {
  return {
    localeError: mg()
  };
}
a(Ua, "default");

// versions/4.3.6/node_modules/zod/v4/locales/es.js
var gg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "caracteres", verb: "tener" },
    file: { unit: "bytes", verb: "tener" },
    array: { unit: "elementos", verb: "tener" },
    set: { unit: "elementos", verb: "tener" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "entrada",
    email: "direcci\xF3n de correo electr\xF3nico",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "fecha y hora ISO",
    date: "fecha ISO",
    time: "hora ISO",
    duration: "duraci\xF3n ISO",
    ipv4: "direcci\xF3n IPv4",
    ipv6: "direcci\xF3n IPv6",
    cidrv4: "rango IPv4",
    cidrv6: "rango IPv6",
    base64: "cadena codificada en base64",
    base64url: "URL codificada en base64",
    json_string: "cadena JSON",
    e164: "n\xFAmero E.164",
    jwt: "JWT",
    template_literal: "entrada"
  }, o = {
    nan: "NaN",
    string: "texto",
    number: "n\xFAmero",
    boolean: "booleano",
    array: "arreglo",
    object: "objeto",
    set: "conjunto",
    file: "archivo",
    date: "fecha",
    bigint: "n\xFAmero grande",
    symbol: "s\xEDmbolo",
    undefined: "indefinido",
    null: "nulo",
    function: "funci\xF3n",
    map: "mapa",
    record: "registro",
    tuple: "tupla",
    enum: "enumeraci\xF3n",
    union: "uni\xF3n",
    literal: "literal",
    promise: "promesa",
    void: "vac\xEDo",
    never: "nunca",
    unknown: "desconocido",
    any: "cualquiera"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = y(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Entrada inv\xE1lida: se esperaba instanceof ${r.expected}, recibido ${c}` : `Entrada inv\xE1lida: se esperaba ${i}, recibido ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Entrada inv\xE1lida: se esperaba ${v(r.values[0])}` : `Opci\xF3n inv\xE1lida: se esperaba una de ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin), c = o[r.origin] ?? r.origin;
        return s ? `Demasiado grande: se esperaba que ${c ?? "valor"} tuviera ${i}${r.maximum.toString()} ${s.unit ?? "elementos"}` : `Demasiado grande: se esperaba que ${c ?? "valor"} fuera ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin), c = o[r.origin] ?? r.origin;
        return s ? `Demasiado peque\xF1o: se esperaba que ${c} tuviera ${i}${r.minimum.toString()} ${s.unit}` : `Demasiado peque\xF1o: se esperaba que ${c} fuera ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Cadena inv\xE1lida: debe comenzar con "${i.prefix}"` : i.format === "ends_with" ? `Cadena inv\xE1lida: debe terminar en "${i.suffix}"` : i.format === "includes" ? `Cadena inv\xE1lida: debe incluir "${i.includes}"` : i.format === "regex" ? `Cadena inv\xE1lida: debe coincidir con el patr\xF3n ${i.pattern}` : `Inv\xE1lido ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `N\xFAmero inv\xE1lido: debe ser m\xFAltiplo de ${r.divisor}`;
      case "unrecognized_keys":
        return `Llave${r.keys.length > 1 ? "s" : ""} desconocida${r.keys.length > 1 ? "s" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Llave inv\xE1lida en ${o[r.origin] ?? r.origin}`;
      case "invalid_union":
        return "Entrada inv\xE1lida";
      case "invalid_element":
        return `Valor inv\xE1lido en ${o[r.origin] ?? r.origin}`;
      default:
        return "Entrada inv\xE1lida";
    }
  };
}, "error");
function Da() {
  return {
    localeError: gg()
  };
}
a(Da, "default");

// versions/4.3.6/node_modules/zod/v4/locales/fa.js
var hg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "\u06A9\u0627\u0631\u0627\u06A9\u062A\u0631", verb: "\u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F" },
    file: { unit: "\u0628\u0627\u06CC\u062A", verb: "\u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F" },
    array: { unit: "\u0622\u06CC\u062A\u0645", verb: "\u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F" },
    set: { unit: "\u0622\u06CC\u062A\u0645", verb: "\u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "\u0648\u0631\u0648\u062F\u06CC",
    email: "\u0622\u062F\u0631\u0633 \u0627\u06CC\u0645\u06CC\u0644",
    url: "URL",
    emoji: "\u0627\u06CC\u0645\u0648\u062C\u06CC",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u062A\u0627\u0631\u06CC\u062E \u0648 \u0632\u0645\u0627\u0646 \u0627\u06CC\u0632\u0648",
    date: "\u062A\u0627\u0631\u06CC\u062E \u0627\u06CC\u0632\u0648",
    time: "\u0632\u0645\u0627\u0646 \u0627\u06CC\u0632\u0648",
    duration: "\u0645\u062F\u062A \u0632\u0645\u0627\u0646 \u0627\u06CC\u0632\u0648",
    ipv4: "IPv4 \u0622\u062F\u0631\u0633",
    ipv6: "IPv6 \u0622\u062F\u0631\u0633",
    cidrv4: "IPv4 \u062F\u0627\u0645\u0646\u0647",
    cidrv6: "IPv6 \u062F\u0627\u0645\u0646\u0647",
    base64: "base64-encoded \u0631\u0634\u062A\u0647",
    base64url: "base64url-encoded \u0631\u0634\u062A\u0647",
    json_string: "JSON \u0631\u0634\u062A\u0647",
    e164: "E.164 \u0639\u062F\u062F",
    jwt: "JWT",
    template_literal: "\u0648\u0631\u0648\u062F\u06CC"
  }, o = {
    nan: "NaN",
    number: "\u0639\u062F\u062F",
    array: "\u0622\u0631\u0627\u06CC\u0647"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = y(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0645\u06CC\u200C\u0628\u0627\u06CC\u0633\u062A instanceof ${r.expected} \u0645\u06CC\u200C\u0628\u0648\u062F\u060C ${c} \u062F\u0631\u06CC\u0627\u0641\u062A \u0634\u062F` : `\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0645\u06CC\u200C\u0628\u0627\u06CC\u0633\u062A ${i} \u0645\u06CC\u200C\u0628\u0648\u062F\u060C ${c} \u062F\u0631\u06CC\u0627\u0641\u062A \u0634\u062F`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0645\u06CC\u200C\u0628\u0627\u06CC\u0633\u062A ${v(r.values[0])} \u0645\u06CC\u200C\u0628\u0648\u062F` : `\u06AF\u0632\u06CC\u0646\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0645\u06CC\u200C\u0628\u0627\u06CC\u0633\u062A \u06CC\u06A9\u06CC \u0627\u0632 ${p(r.values, "|")} \u0645\u06CC\u200C\u0628\u0648\u062F`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `\u062E\u06CC\u0644\u06CC \u0628\u0632\u0631\u06AF: ${r.origin ?? "\u0645\u0642\u062F\u0627\u0631"} \u0628\u0627\u06CC\u062F ${i}${r.maximum.toString()} ${s.unit ?? "\u0639\u0646\u0635\u0631"} \u0628\u0627\u0634\u062F` : `\u062E\u06CC\u0644\u06CC \u0628\u0632\u0631\u06AF: ${r.origin ?? "\u0645\u0642\u062F\u0627\u0631"} \u0628\u0627\u06CC\u062F ${i}${r.maximum.toString()} \u0628\u0627\u0634\u062F`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `\u062E\u06CC\u0644\u06CC \u06A9\u0648\u0686\u06A9: ${r.origin} \u0628\u0627\u06CC\u062F ${i}${r.minimum.toString()} ${s.unit} \u0628\u0627\u0634\u062F` : `\u062E\u06CC\u0644\u06CC \u06A9\u0648\u0686\u06A9: ${r.origin} \u0628\u0627\u06CC\u062F ${i}${r.minimum.toString()} \u0628\u0627\u0634\u062F`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u0631\u0634\u062A\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0628\u0627 "${i.prefix}" \u0634\u0631\u0648\u0639 \u0634\u0648\u062F` : i.format === "ends_with" ? `\u0631\u0634\u062A\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0628\u0627 "${i.suffix}" \u062A\u0645\u0627\u0645 \u0634\u0648\u062F` : i.format === "includes" ? `\u0631\u0634\u062A\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0634\u0627\u0645\u0644 "${i.includes}" \u0628\u0627\u0634\u062F` : i.format === "regex" ? `\u0631\u0634\u062A\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0628\u0627 \u0627\u0644\u06AF\u0648\u06CC ${i.pattern} \u0645\u0637\u0627\u0628\u0642\u062A \u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F` : `${n[i.format] ?? r.format} \u0646\u0627\u0645\u0639\u062A\u0628\u0631`;
      }
      case "not_multiple_of":
        return `\u0639\u062F\u062F \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0645\u0636\u0631\u0628 ${r.divisor} \u0628\u0627\u0634\u062F`;
      case "unrecognized_keys":
        return `\u06A9\u0644\u06CC\u062F${r.keys.length > 1 ? "\u0647\u0627\u06CC" : ""} \u0646\u0627\u0634\u0646\u0627\u0633: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `\u06A9\u0644\u06CC\u062F \u0646\u0627\u0634\u0646\u0627\u0633 \u062F\u0631 ${r.origin}`;
      case "invalid_union":
        return "\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631";
      case "invalid_element":
        return `\u0645\u0642\u062F\u0627\u0631 \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u062F\u0631 ${r.origin}`;
      default:
        return "\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631";
    }
  };
}, "error");
function Ea() {
  return {
    localeError: hg()
  };
}
a(Ea, "default");

// versions/4.3.6/node_modules/zod/v4/locales/fi.js
var vg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "merkki\xE4", subject: "merkkijonon" },
    file: { unit: "tavua", subject: "tiedoston" },
    array: { unit: "alkiota", subject: "listan" },
    set: { unit: "alkiota", subject: "joukon" },
    number: { unit: "", subject: "luvun" },
    bigint: { unit: "", subject: "suuren kokonaisluvun" },
    int: { unit: "", subject: "kokonaisluvun" },
    date: { unit: "", subject: "p\xE4iv\xE4m\xE4\xE4r\xE4n" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "s\xE4\xE4nn\xF6llinen lauseke",
    email: "s\xE4hk\xF6postiosoite",
    url: "URL-osoite",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO-aikaleima",
    date: "ISO-p\xE4iv\xE4m\xE4\xE4r\xE4",
    time: "ISO-aika",
    duration: "ISO-kesto",
    ipv4: "IPv4-osoite",
    ipv6: "IPv6-osoite",
    cidrv4: "IPv4-alue",
    cidrv6: "IPv6-alue",
    base64: "base64-koodattu merkkijono",
    base64url: "base64url-koodattu merkkijono",
    json_string: "JSON-merkkijono",
    e164: "E.164-luku",
    jwt: "JWT",
    template_literal: "templaattimerkkijono"
  }, o = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = y(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Virheellinen tyyppi: odotettiin instanceof ${r.expected}, oli ${c}` : `Virheellinen tyyppi: odotettiin ${i}, oli ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Virheellinen sy\xF6te: t\xE4ytyy olla ${v(r.values[0])}` : `Virheellinen valinta: t\xE4ytyy olla yksi seuraavista: ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `Liian suuri: ${s.subject} t\xE4ytyy olla ${i}${r.maximum.toString()} ${s.unit}`.trim() : `Liian suuri: arvon t\xE4ytyy olla ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `Liian pieni: ${s.subject} t\xE4ytyy olla ${i}${r.minimum.toString()} ${s.unit}`.trim() : `Liian pieni: arvon t\xE4ytyy olla ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Virheellinen sy\xF6te: t\xE4ytyy alkaa "${i.prefix}"` : i.format === "ends_with" ? `Virheellinen sy\xF6te: t\xE4ytyy loppua "${i.suffix}"` : i.format === "includes" ? `Virheellinen sy\xF6te: t\xE4ytyy sis\xE4lt\xE4\xE4 "${i.includes}"` : i.format === "regex" ? `Virheellinen sy\xF6te: t\xE4ytyy vastata s\xE4\xE4nn\xF6llist\xE4 lauseketta ${i.pattern}` : `Virheellinen ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Virheellinen luku: t\xE4ytyy olla luvun ${r.divisor} monikerta`;
      case "unrecognized_keys":
        return `${r.keys.length > 1 ? "Tuntemattomat avaimet" : "Tuntematon avain"}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return "Virheellinen avain tietueessa";
      case "invalid_union":
        return "Virheellinen unioni";
      case "invalid_element":
        return "Virheellinen arvo joukossa";
      default:
        return "Virheellinen sy\xF6te";
    }
  };
}, "error");
function Za() {
  return {
    localeError: vg()
  };
}
a(Za, "default");

// versions/4.3.6/node_modules/zod/v4/locales/fr.js
var yg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "caract\xE8res", verb: "avoir" },
    file: { unit: "octets", verb: "avoir" },
    array: { unit: "\xE9l\xE9ments", verb: "avoir" },
    set: { unit: "\xE9l\xE9ments", verb: "avoir" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "entr\xE9e",
    email: "adresse e-mail",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "date et heure ISO",
    date: "date ISO",
    time: "heure ISO",
    duration: "dur\xE9e ISO",
    ipv4: "adresse IPv4",
    ipv6: "adresse IPv6",
    cidrv4: "plage IPv4",
    cidrv6: "plage IPv6",
    base64: "cha\xEEne encod\xE9e en base64",
    base64url: "cha\xEEne encod\xE9e en base64url",
    json_string: "cha\xEEne JSON",
    e164: "num\xE9ro E.164",
    jwt: "JWT",
    template_literal: "entr\xE9e"
  }, o = {
    nan: "NaN",
    number: "nombre",
    array: "tableau"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = y(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Entr\xE9e invalide : instanceof ${r.expected} attendu, ${c} re\xE7u` : `Entr\xE9e invalide : ${i} attendu, ${c} re\xE7u`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Entr\xE9e invalide : ${v(r.values[0])} attendu` : `Option invalide : une valeur parmi ${p(r.values, "|")} attendue`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `Trop grand : ${r.origin ?? "valeur"} doit ${s.verb} ${i}${r.maximum.toString()} ${s.unit ?? "\xE9l\xE9ment(s)"}` : `Trop grand : ${r.origin ?? "valeur"} doit \xEAtre ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `Trop petit : ${r.origin} doit ${s.verb} ${i}${r.minimum.toString()} ${s.unit}` : `Trop petit : ${r.origin} doit \xEAtre ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Cha\xEEne invalide : doit commencer par "${i.prefix}"` : i.format === "ends_with" ? `Cha\xEEne invalide : doit se terminer par "${i.suffix}"` : i.format === "includes" ? `Cha\xEEne invalide : doit inclure "${i.includes}"` : i.format === "regex" ? `Cha\xEEne invalide : doit correspondre au mod\xE8le ${i.pattern}` : `${n[i.format] ?? r.format} invalide`;
      }
      case "not_multiple_of":
        return `Nombre invalide : doit \xEAtre un multiple de ${r.divisor}`;
      case "unrecognized_keys":
        return `Cl\xE9${r.keys.length > 1 ? "s" : ""} non reconnue${r.keys.length > 1 ? "s" : ""} : ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Cl\xE9 invalide dans ${r.origin}`;
      case "invalid_union":
        return "Entr\xE9e invalide";
      case "invalid_element":
        return `Valeur invalide dans ${r.origin}`;
      default:
        return "Entr\xE9e invalide";
    }
  };
}, "error");
function Na() {
  return {
    localeError: yg()
  };
}
a(Na, "default");

// versions/4.3.6/node_modules/zod/v4/locales/fr-CA.js
var bg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "caract\xE8res", verb: "avoir" },
    file: { unit: "octets", verb: "avoir" },
    array: { unit: "\xE9l\xE9ments", verb: "avoir" },
    set: { unit: "\xE9l\xE9ments", verb: "avoir" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "entr\xE9e",
    email: "adresse courriel",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "date-heure ISO",
    date: "date ISO",
    time: "heure ISO",
    duration: "dur\xE9e ISO",
    ipv4: "adresse IPv4",
    ipv6: "adresse IPv6",
    cidrv4: "plage IPv4",
    cidrv6: "plage IPv6",
    base64: "cha\xEEne encod\xE9e en base64",
    base64url: "cha\xEEne encod\xE9e en base64url",
    json_string: "cha\xEEne JSON",
    e164: "num\xE9ro E.164",
    jwt: "JWT",
    template_literal: "entr\xE9e"
  }, o = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = y(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Entr\xE9e invalide : attendu instanceof ${r.expected}, re\xE7u ${c}` : `Entr\xE9e invalide : attendu ${i}, re\xE7u ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Entr\xE9e invalide : attendu ${v(r.values[0])}` : `Option invalide : attendu l'une des valeurs suivantes ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "\u2264" : "<", s = t(r.origin);
        return s ? `Trop grand : attendu que ${r.origin ?? "la valeur"} ait ${i}${r.maximum.toString()} ${s.unit}` : `Trop grand : attendu que ${r.origin ?? "la valeur"} soit ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? "\u2265" : ">", s = t(r.origin);
        return s ? `Trop petit : attendu que ${r.origin} ait ${i}${r.minimum.toString()} ${s.unit}` : `Trop petit : attendu que ${r.origin} soit ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Cha\xEEne invalide : doit commencer par "${i.prefix}"` : i.format === "ends_with" ? `Cha\xEEne invalide : doit se terminer par "${i.suffix}"` : i.format === "includes" ? `Cha\xEEne invalide : doit inclure "${i.includes}"` : i.format === "regex" ? `Cha\xEEne invalide : doit correspondre au motif ${i.pattern}` : `${n[i.format] ?? r.format} invalide`;
      }
      case "not_multiple_of":
        return `Nombre invalide : doit \xEAtre un multiple de ${r.divisor}`;
      case "unrecognized_keys":
        return `Cl\xE9${r.keys.length > 1 ? "s" : ""} non reconnue${r.keys.length > 1 ? "s" : ""} : ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Cl\xE9 invalide dans ${r.origin}`;
      case "invalid_union":
        return "Entr\xE9e invalide";
      case "invalid_element":
        return `Valeur invalide dans ${r.origin}`;
      default:
        return "Entr\xE9e invalide";
    }
  };
}, "error");
function Aa() {
  return {
    localeError: bg()
  };
}
a(Aa, "default");

// versions/4.3.6/node_modules/zod/v4/locales/he.js
var xg = /* @__PURE__ */ a(() => {
  let e = {
    string: { label: "\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA", gender: "f" },
    number: { label: "\u05DE\u05E1\u05E4\u05E8", gender: "m" },
    boolean: { label: "\u05E2\u05E8\u05DA \u05D1\u05D5\u05DC\u05D9\u05D0\u05E0\u05D9", gender: "m" },
    bigint: { label: "BigInt", gender: "m" },
    date: { label: "\u05EA\u05D0\u05E8\u05D9\u05DA", gender: "m" },
    array: { label: "\u05DE\u05E2\u05E8\u05DA", gender: "m" },
    object: { label: "\u05D0\u05D5\u05D1\u05D9\u05D9\u05E7\u05D8", gender: "m" },
    null: { label: "\u05E2\u05E8\u05DA \u05E8\u05D9\u05E7 (null)", gender: "m" },
    undefined: { label: "\u05E2\u05E8\u05DA \u05DC\u05D0 \u05DE\u05D5\u05D2\u05D3\u05E8 (undefined)", gender: "m" },
    symbol: { label: "\u05E1\u05D9\u05DE\u05D1\u05D5\u05DC (Symbol)", gender: "m" },
    function: { label: "\u05E4\u05D5\u05E0\u05E7\u05E6\u05D9\u05D4", gender: "f" },
    map: { label: "\u05DE\u05E4\u05D4 (Map)", gender: "f" },
    set: { label: "\u05E7\u05D1\u05D5\u05E6\u05D4 (Set)", gender: "f" },
    file: { label: "\u05E7\u05D5\u05D1\u05E5", gender: "m" },
    promise: { label: "Promise", gender: "m" },
    NaN: { label: "NaN", gender: "m" },
    unknown: { label: "\u05E2\u05E8\u05DA \u05DC\u05D0 \u05D9\u05D3\u05D5\u05E2", gender: "m" },
    value: { label: "\u05E2\u05E8\u05DA", gender: "m" }
  }, t = {
    string: { unit: "\u05EA\u05D5\u05D5\u05D9\u05DD", shortLabel: "\u05E7\u05E6\u05E8", longLabel: "\u05D0\u05E8\u05D5\u05DA" },
    file: { unit: "\u05D1\u05D9\u05D9\u05D8\u05D9\u05DD", shortLabel: "\u05E7\u05D8\u05DF", longLabel: "\u05D2\u05D3\u05D5\u05DC" },
    array: { unit: "\u05E4\u05E8\u05D9\u05D8\u05D9\u05DD", shortLabel: "\u05E7\u05D8\u05DF", longLabel: "\u05D2\u05D3\u05D5\u05DC" },
    set: { unit: "\u05E4\u05E8\u05D9\u05D8\u05D9\u05DD", shortLabel: "\u05E7\u05D8\u05DF", longLabel: "\u05D2\u05D3\u05D5\u05DC" },
    number: { unit: "", shortLabel: "\u05E7\u05D8\u05DF", longLabel: "\u05D2\u05D3\u05D5\u05DC" }
    // no unit
  }, n = /* @__PURE__ */ a((l) => l ? e[l] : void 0, "typeEntry"), o = /* @__PURE__ */ a((l) => {
    let d = n(l);
    return d ? d.label : l ?? e.unknown.label;
  }, "typeLabel"), r = /* @__PURE__ */ a((l) => `\u05D4${o(l)}`, "withDefinite"), i = /* @__PURE__ */ a((l) => (n(l)?.gender ?? "m") === "f" ? "\u05E6\u05E8\u05D9\u05DB\u05D4 \u05DC\u05D4\u05D9\u05D5\u05EA" : "\u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA", "verbFor"), s = /* @__PURE__ */ a((l) => l ? t[l] ?? null : null, "getSizing"), c = {
    regex: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    email: { label: "\u05DB\u05EA\u05D5\u05D1\u05EA \u05D0\u05D9\u05DE\u05D9\u05D9\u05DC", gender: "f" },
    url: { label: "\u05DB\u05EA\u05D5\u05D1\u05EA \u05E8\u05E9\u05EA", gender: "f" },
    emoji: { label: "\u05D0\u05D9\u05DE\u05D5\u05D2'\u05D9", gender: "m" },
    uuid: { label: "UUID", gender: "m" },
    nanoid: { label: "nanoid", gender: "m" },
    guid: { label: "GUID", gender: "m" },
    cuid: { label: "cuid", gender: "m" },
    cuid2: { label: "cuid2", gender: "m" },
    ulid: { label: "ULID", gender: "m" },
    xid: { label: "XID", gender: "m" },
    ksuid: { label: "KSUID", gender: "m" },
    datetime: { label: "\u05EA\u05D0\u05E8\u05D9\u05DA \u05D5\u05D6\u05DE\u05DF ISO", gender: "m" },
    date: { label: "\u05EA\u05D0\u05E8\u05D9\u05DA ISO", gender: "m" },
    time: { label: "\u05D6\u05DE\u05DF ISO", gender: "m" },
    duration: { label: "\u05DE\u05E9\u05DA \u05D6\u05DE\u05DF ISO", gender: "m" },
    ipv4: { label: "\u05DB\u05EA\u05D5\u05D1\u05EA IPv4", gender: "f" },
    ipv6: { label: "\u05DB\u05EA\u05D5\u05D1\u05EA IPv6", gender: "f" },
    cidrv4: { label: "\u05D8\u05D5\u05D5\u05D7 IPv4", gender: "m" },
    cidrv6: { label: "\u05D8\u05D5\u05D5\u05D7 IPv6", gender: "m" },
    base64: { label: "\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D1\u05D1\u05E1\u05D9\u05E1 64", gender: "f" },
    base64url: { label: "\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D1\u05D1\u05E1\u05D9\u05E1 64 \u05DC\u05DB\u05EA\u05D5\u05D1\u05D5\u05EA \u05E8\u05E9\u05EA", gender: "f" },
    json_string: { label: "\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA JSON", gender: "f" },
    e164: { label: "\u05DE\u05E1\u05E4\u05E8 E.164", gender: "m" },
    jwt: { label: "JWT", gender: "m" },
    ends_with: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    includes: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    lowercase: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    starts_with: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    uppercase: { label: "\u05E7\u05DC\u05D8", gender: "m" }
  }, u = {
    nan: "NaN"
  };
  return (l) => {
    switch (l.code) {
      case "invalid_type": {
        let d = l.expected, g = u[d ?? ""] ?? o(d), b = y(l.input), x = u[b] ?? e[b]?.label ?? b;
        return /^[A-Z]/.test(l.expected) ? `\u05E7\u05DC\u05D8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA instanceof ${l.expected}, \u05D4\u05EA\u05E7\u05D1\u05DC ${x}` : `\u05E7\u05DC\u05D8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA ${g}, \u05D4\u05EA\u05E7\u05D1\u05DC ${x}`;
      }
      case "invalid_value": {
        if (l.values.length === 1)
          return `\u05E2\u05E8\u05DA \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05D4\u05E2\u05E8\u05DA \u05D7\u05D9\u05D9\u05D1 \u05DC\u05D4\u05D9\u05D5\u05EA ${v(l.values[0])}`;
        let d = l.values.map((x) => v(x));
        if (l.values.length === 2)
          return `\u05E2\u05E8\u05DA \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05D4\u05D0\u05E4\u05E9\u05E8\u05D5\u05D9\u05D5\u05EA \u05D4\u05DE\u05EA\u05D0\u05D9\u05DE\u05D5\u05EA \u05D4\u05DF ${d[0]} \u05D0\u05D5 ${d[1]}`;
        let g = d[d.length - 1];
        return `\u05E2\u05E8\u05DA \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05D4\u05D0\u05E4\u05E9\u05E8\u05D5\u05D9\u05D5\u05EA \u05D4\u05DE\u05EA\u05D0\u05D9\u05DE\u05D5\u05EA \u05D4\u05DF ${d.slice(0, -1).join(", ")} \u05D0\u05D5 ${g}`;
      }
      case "too_big": {
        let d = s(l.origin), g = r(l.origin ?? "value");
        if (l.origin === "string")
          return `${d?.longLabel ?? "\u05D0\u05E8\u05D5\u05DA"} \u05DE\u05D3\u05D9: ${g} \u05E6\u05E8\u05D9\u05DB\u05D4 \u05DC\u05D4\u05DB\u05D9\u05DC ${l.maximum.toString()} ${d?.unit ?? ""} ${l.inclusive ? "\u05D0\u05D5 \u05E4\u05D7\u05D5\u05EA" : "\u05DC\u05DB\u05DC \u05D4\u05D9\u05D5\u05EA\u05E8"}`.trim();
        if (l.origin === "number") {
          let j = l.inclusive ? `\u05E7\u05D8\u05DF \u05D0\u05D5 \u05E9\u05D5\u05D5\u05D4 \u05DC-${l.maximum}` : `\u05E7\u05D8\u05DF \u05DE-${l.maximum}`;
          return `\u05D2\u05D3\u05D5\u05DC \u05DE\u05D3\u05D9: ${g} \u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA ${j}`;
        }
        if (l.origin === "array" || l.origin === "set") {
          let j = l.origin === "set" ? "\u05E6\u05E8\u05D9\u05DB\u05D4" : "\u05E6\u05E8\u05D9\u05DA", z = l.inclusive ? `${l.maximum} ${d?.unit ?? ""} \u05D0\u05D5 \u05E4\u05D7\u05D5\u05EA` : `\u05E4\u05D7\u05D5\u05EA \u05DE-${l.maximum} ${d?.unit ?? ""}`;
          return `\u05D2\u05D3\u05D5\u05DC \u05DE\u05D3\u05D9: ${g} ${j} \u05DC\u05D4\u05DB\u05D9\u05DC ${z}`.trim();
        }
        let b = l.inclusive ? "<=" : "<", x = i(l.origin ?? "value");
        return d?.unit ? `${d.longLabel} \u05DE\u05D3\u05D9: ${g} ${x} ${b}${l.maximum.toString()} ${d.unit}` : `${d?.longLabel ?? "\u05D2\u05D3\u05D5\u05DC"} \u05DE\u05D3\u05D9: ${g} ${x} ${b}${l.maximum.toString()}`;
      }
      case "too_small": {
        let d = s(l.origin), g = r(l.origin ?? "value");
        if (l.origin === "string")
          return `${d?.shortLabel ?? "\u05E7\u05E6\u05E8"} \u05DE\u05D3\u05D9: ${g} \u05E6\u05E8\u05D9\u05DB\u05D4 \u05DC\u05D4\u05DB\u05D9\u05DC ${l.minimum.toString()} ${d?.unit ?? ""} ${l.inclusive ? "\u05D0\u05D5 \u05D9\u05D5\u05EA\u05E8" : "\u05DC\u05E4\u05D7\u05D5\u05EA"}`.trim();
        if (l.origin === "number") {
          let j = l.inclusive ? `\u05D2\u05D3\u05D5\u05DC \u05D0\u05D5 \u05E9\u05D5\u05D5\u05D4 \u05DC-${l.minimum}` : `\u05D2\u05D3\u05D5\u05DC \u05DE-${l.minimum}`;
          return `\u05E7\u05D8\u05DF \u05DE\u05D3\u05D9: ${g} \u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA ${j}`;
        }
        if (l.origin === "array" || l.origin === "set") {
          let j = l.origin === "set" ? "\u05E6\u05E8\u05D9\u05DB\u05D4" : "\u05E6\u05E8\u05D9\u05DA";
          if (l.minimum === 1 && l.inclusive) {
            let q = (l.origin === "set", "\u05DC\u05E4\u05D7\u05D5\u05EA \u05E4\u05E8\u05D9\u05D8 \u05D0\u05D7\u05D3");
            return `\u05E7\u05D8\u05DF \u05DE\u05D3\u05D9: ${g} ${j} \u05DC\u05D4\u05DB\u05D9\u05DC ${q}`;
          }
          let z = l.inclusive ? `${l.minimum} ${d?.unit ?? ""} \u05D0\u05D5 \u05D9\u05D5\u05EA\u05E8` : `\u05D9\u05D5\u05EA\u05E8 \u05DE-${l.minimum} ${d?.unit ?? ""}`;
          return `\u05E7\u05D8\u05DF \u05DE\u05D3\u05D9: ${g} ${j} \u05DC\u05D4\u05DB\u05D9\u05DC ${z}`.trim();
        }
        let b = l.inclusive ? ">=" : ">", x = i(l.origin ?? "value");
        return d?.unit ? `${d.shortLabel} \u05DE\u05D3\u05D9: ${g} ${x} ${b}${l.minimum.toString()} ${d.unit}` : `${d?.shortLabel ?? "\u05E7\u05D8\u05DF"} \u05DE\u05D3\u05D9: ${g} ${x} ${b}${l.minimum.toString()}`;
      }
      case "invalid_format": {
        let d = l;
        if (d.format === "starts_with")
          return `\u05D4\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D7\u05D9\u05D9\u05D1\u05EA \u05DC\u05D4\u05EA\u05D7\u05D9\u05DC \u05D1 "${d.prefix}"`;
        if (d.format === "ends_with")
          return `\u05D4\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D7\u05D9\u05D9\u05D1\u05EA \u05DC\u05D4\u05E1\u05EA\u05D9\u05D9\u05DD \u05D1 "${d.suffix}"`;
        if (d.format === "includes")
          return `\u05D4\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D7\u05D9\u05D9\u05D1\u05EA \u05DC\u05DB\u05DC\u05D5\u05DC "${d.includes}"`;
        if (d.format === "regex")
          return `\u05D4\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D7\u05D9\u05D9\u05D1\u05EA \u05DC\u05D4\u05EA\u05D0\u05D9\u05DD \u05DC\u05EA\u05D1\u05E0\u05D9\u05EA ${d.pattern}`;
        let g = c[d.format], b = g?.label ?? d.format, j = (g?.gender ?? "m") === "f" ? "\u05EA\u05E7\u05D9\u05E0\u05D4" : "\u05EA\u05E7\u05D9\u05DF";
        return `${b} \u05DC\u05D0 ${j}`;
      }
      case "not_multiple_of":
        return `\u05DE\u05E1\u05E4\u05E8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05D7\u05D9\u05D9\u05D1 \u05DC\u05D4\u05D9\u05D5\u05EA \u05DE\u05DB\u05E4\u05DC\u05D4 \u05E9\u05DC ${l.divisor}`;
      case "unrecognized_keys":
        return `\u05DE\u05E4\u05EA\u05D7${l.keys.length > 1 ? "\u05D5\u05EA" : ""} \u05DC\u05D0 \u05DE\u05D6\u05D5\u05D4${l.keys.length > 1 ? "\u05D9\u05DD" : "\u05D4"}: ${p(l.keys, ", ")}`;
      case "invalid_key":
        return "\u05E9\u05D3\u05D4 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF \u05D1\u05D0\u05D5\u05D1\u05D9\u05D9\u05E7\u05D8";
      case "invalid_union":
        return "\u05E7\u05DC\u05D8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF";
      case "invalid_element":
        return `\u05E2\u05E8\u05DA \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF \u05D1${r(l.origin ?? "array")}`;
      default:
        return "\u05E7\u05DC\u05D8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF";
    }
  };
}, "error");
function Ca() {
  return {
    localeError: xg()
  };
}
a(Ca, "default");

// versions/4.3.6/node_modules/zod/v4/locales/hu.js
var $g = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "karakter", verb: "legyen" },
    file: { unit: "byte", verb: "legyen" },
    array: { unit: "elem", verb: "legyen" },
    set: { unit: "elem", verb: "legyen" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "bemenet",
    email: "email c\xEDm",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO id\u0151b\xE9lyeg",
    date: "ISO d\xE1tum",
    time: "ISO id\u0151",
    duration: "ISO id\u0151intervallum",
    ipv4: "IPv4 c\xEDm",
    ipv6: "IPv6 c\xEDm",
    cidrv4: "IPv4 tartom\xE1ny",
    cidrv6: "IPv6 tartom\xE1ny",
    base64: "base64-k\xF3dolt string",
    base64url: "base64url-k\xF3dolt string",
    json_string: "JSON string",
    e164: "E.164 sz\xE1m",
    jwt: "JWT",
    template_literal: "bemenet"
  }, o = {
    nan: "NaN",
    number: "sz\xE1m",
    array: "t\xF6mb"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = y(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `\xC9rv\xE9nytelen bemenet: a v\xE1rt \xE9rt\xE9k instanceof ${r.expected}, a kapott \xE9rt\xE9k ${c}` : `\xC9rv\xE9nytelen bemenet: a v\xE1rt \xE9rt\xE9k ${i}, a kapott \xE9rt\xE9k ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\xC9rv\xE9nytelen bemenet: a v\xE1rt \xE9rt\xE9k ${v(r.values[0])}` : `\xC9rv\xE9nytelen opci\xF3: valamelyik \xE9rt\xE9k v\xE1rt ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `T\xFAl nagy: ${r.origin ?? "\xE9rt\xE9k"} m\xE9rete t\xFAl nagy ${i}${r.maximum.toString()} ${s.unit ?? "elem"}` : `T\xFAl nagy: a bemeneti \xE9rt\xE9k ${r.origin ?? "\xE9rt\xE9k"} t\xFAl nagy: ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `T\xFAl kicsi: a bemeneti \xE9rt\xE9k ${r.origin} m\xE9rete t\xFAl kicsi ${i}${r.minimum.toString()} ${s.unit}` : `T\xFAl kicsi: a bemeneti \xE9rt\xE9k ${r.origin} t\xFAl kicsi ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\xC9rv\xE9nytelen string: "${i.prefix}" \xE9rt\xE9kkel kell kezd\u0151dnie` : i.format === "ends_with" ? `\xC9rv\xE9nytelen string: "${i.suffix}" \xE9rt\xE9kkel kell v\xE9gz\u0151dnie` : i.format === "includes" ? `\xC9rv\xE9nytelen string: "${i.includes}" \xE9rt\xE9ket kell tartalmaznia` : i.format === "regex" ? `\xC9rv\xE9nytelen string: ${i.pattern} mint\xE1nak kell megfelelnie` : `\xC9rv\xE9nytelen ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\xC9rv\xE9nytelen sz\xE1m: ${r.divisor} t\xF6bbsz\xF6r\xF6s\xE9nek kell lennie`;
      case "unrecognized_keys":
        return `Ismeretlen kulcs${r.keys.length > 1 ? "s" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `\xC9rv\xE9nytelen kulcs ${r.origin}`;
      case "invalid_union":
        return "\xC9rv\xE9nytelen bemenet";
      case "invalid_element":
        return `\xC9rv\xE9nytelen \xE9rt\xE9k: ${r.origin}`;
      default:
        return "\xC9rv\xE9nytelen bemenet";
    }
  };
}, "error");
function Ra() {
  return {
    localeError: $g()
  };
}
a(Ra, "default");

// versions/4.3.6/node_modules/zod/v4/locales/hy.js
function Vl(e, t, n) {
  return Math.abs(e) === 1 ? t : n;
}
a(Vl, "getArmenianPlural");
function mt(e) {
  if (!e)
    return "";
  let t = ["\u0561", "\u0565", "\u0568", "\u056B", "\u0578", "\u0578\u0582", "\u0585"], n = e[e.length - 1];
  return e + (t.includes(n) ? "\u0576" : "\u0568");
}
a(mt, "withDefiniteArticle");
var _g = /* @__PURE__ */ a(() => {
  let e = {
    string: {
      unit: {
        one: "\u0576\u0577\u0561\u0576",
        many: "\u0576\u0577\u0561\u0576\u0576\u0565\u0580"
      },
      verb: "\u0578\u0582\u0576\u0565\u0576\u0561\u056C"
    },
    file: {
      unit: {
        one: "\u0562\u0561\u0575\u0569",
        many: "\u0562\u0561\u0575\u0569\u0565\u0580"
      },
      verb: "\u0578\u0582\u0576\u0565\u0576\u0561\u056C"
    },
    array: {
      unit: {
        one: "\u057F\u0561\u0580\u0580",
        many: "\u057F\u0561\u0580\u0580\u0565\u0580"
      },
      verb: "\u0578\u0582\u0576\u0565\u0576\u0561\u056C"
    },
    set: {
      unit: {
        one: "\u057F\u0561\u0580\u0580",
        many: "\u057F\u0561\u0580\u0580\u0565\u0580"
      },
      verb: "\u0578\u0582\u0576\u0565\u0576\u0561\u056C"
    }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "\u0574\u0578\u0582\u057F\u0584",
    email: "\u0567\u056C. \u0570\u0561\u057D\u0581\u0565",
    url: "URL",
    emoji: "\u0567\u0574\u0578\u057B\u056B",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0561\u0574\u057D\u0561\u0569\u056B\u057E \u0587 \u056A\u0561\u0574",
    date: "ISO \u0561\u0574\u057D\u0561\u0569\u056B\u057E",
    time: "ISO \u056A\u0561\u0574",
    duration: "ISO \u057F\u0587\u0578\u0572\u0578\u0582\u0569\u0575\u0578\u0582\u0576",
    ipv4: "IPv4 \u0570\u0561\u057D\u0581\u0565",
    ipv6: "IPv6 \u0570\u0561\u057D\u0581\u0565",
    cidrv4: "IPv4 \u0574\u056B\u057B\u0561\u056F\u0561\u0575\u0584",
    cidrv6: "IPv6 \u0574\u056B\u057B\u0561\u056F\u0561\u0575\u0584",
    base64: "base64 \u0571\u0587\u0561\u0579\u0561\u0583\u0578\u057E \u057F\u0578\u0572",
    base64url: "base64url \u0571\u0587\u0561\u0579\u0561\u0583\u0578\u057E \u057F\u0578\u0572",
    json_string: "JSON \u057F\u0578\u0572",
    e164: "E.164 \u0570\u0561\u0574\u0561\u0580",
    jwt: "JWT",
    template_literal: "\u0574\u0578\u0582\u057F\u0584"
  }, o = {
    nan: "NaN",
    number: "\u0569\u056B\u057E",
    array: "\u0566\u0561\u0576\u0563\u057E\u0561\u056E"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = y(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567\u0580 instanceof ${r.expected}, \u057D\u057F\u0561\u0581\u057E\u0565\u056C \u0567 ${c}` : `\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567\u0580 ${i}, \u057D\u057F\u0561\u0581\u057E\u0565\u056C \u0567 ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567\u0580 ${v(r.values[1])}` : `\u054D\u056D\u0561\u056C \u057F\u0561\u0580\u0562\u0565\u0580\u0561\u056F\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567\u0580 \u0570\u0565\u057F\u0587\u0575\u0561\u056C\u0576\u0565\u0580\u056B\u0581 \u0574\u0565\u056F\u0568\u055D ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        if (s) {
          let c = Number(r.maximum), u = Vl(c, s.unit.one, s.unit.many);
          return `\u0549\u0561\u0583\u0561\u0566\u0561\u0576\u0581 \u0574\u0565\u056E \u0561\u0580\u056A\u0565\u0584\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567, \u0578\u0580 ${mt(r.origin ?? "\u0561\u0580\u056A\u0565\u0584")} \u056F\u0578\u0582\u0576\u0565\u0576\u0561 ${i}${r.maximum.toString()} ${u}`;
        }
        return `\u0549\u0561\u0583\u0561\u0566\u0561\u0576\u0581 \u0574\u0565\u056E \u0561\u0580\u056A\u0565\u0584\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567, \u0578\u0580 ${mt(r.origin ?? "\u0561\u0580\u056A\u0565\u0584")} \u056C\u056B\u0576\u056B ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        if (s) {
          let c = Number(r.minimum), u = Vl(c, s.unit.one, s.unit.many);
          return `\u0549\u0561\u0583\u0561\u0566\u0561\u0576\u0581 \u0583\u0578\u0584\u0580 \u0561\u0580\u056A\u0565\u0584\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567, \u0578\u0580 ${mt(r.origin)} \u056F\u0578\u0582\u0576\u0565\u0576\u0561 ${i}${r.minimum.toString()} ${u}`;
        }
        return `\u0549\u0561\u0583\u0561\u0566\u0561\u0576\u0581 \u0583\u0578\u0584\u0580 \u0561\u0580\u056A\u0565\u0584\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567, \u0578\u0580 ${mt(r.origin)} \u056C\u056B\u0576\u056B ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u054D\u056D\u0561\u056C \u057F\u0578\u0572\u2024 \u057A\u0565\u057F\u0584 \u0567 \u057D\u056F\u057D\u057E\u056B "${i.prefix}"-\u0578\u057E` : i.format === "ends_with" ? `\u054D\u056D\u0561\u056C \u057F\u0578\u0572\u2024 \u057A\u0565\u057F\u0584 \u0567 \u0561\u057E\u0561\u0580\u057F\u057E\u056B "${i.suffix}"-\u0578\u057E` : i.format === "includes" ? `\u054D\u056D\u0561\u056C \u057F\u0578\u0572\u2024 \u057A\u0565\u057F\u0584 \u0567 \u057A\u0561\u0580\u0578\u0582\u0576\u0561\u056F\u056B "${i.includes}"` : i.format === "regex" ? `\u054D\u056D\u0561\u056C \u057F\u0578\u0572\u2024 \u057A\u0565\u057F\u0584 \u0567 \u0570\u0561\u0574\u0561\u057A\u0561\u057F\u0561\u057D\u056D\u0561\u0576\u056B ${i.pattern} \u0571\u0587\u0561\u0579\u0561\u0583\u056B\u0576` : `\u054D\u056D\u0561\u056C ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u054D\u056D\u0561\u056C \u0569\u056B\u057E\u2024 \u057A\u0565\u057F\u0584 \u0567 \u0562\u0561\u0566\u0574\u0561\u057A\u0561\u057F\u056B\u056F \u056C\u056B\u0576\u056B ${r.divisor}-\u056B`;
      case "unrecognized_keys":
        return `\u0549\u0573\u0561\u0576\u0561\u0579\u057E\u0561\u056E \u0562\u0561\u0576\u0561\u056C\u056B${r.keys.length > 1 ? "\u0576\u0565\u0580" : ""}. ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `\u054D\u056D\u0561\u056C \u0562\u0561\u0576\u0561\u056C\u056B ${mt(r.origin)}-\u0578\u0582\u0574`;
      case "invalid_union":
        return "\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574";
      case "invalid_element":
        return `\u054D\u056D\u0561\u056C \u0561\u0580\u056A\u0565\u0584 ${mt(r.origin)}-\u0578\u0582\u0574`;
      default:
        return "\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574";
    }
  };
}, "error");
function Fa() {
  return {
    localeError: _g()
  };
}
a(Fa, "default");

// versions/4.3.6/node_modules/zod/v4/locales/id.js
var wg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "karakter", verb: "memiliki" },
    file: { unit: "byte", verb: "memiliki" },
    array: { unit: "item", verb: "memiliki" },
    set: { unit: "item", verb: "memiliki" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "input",
    email: "alamat email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "tanggal dan waktu format ISO",
    date: "tanggal format ISO",
    time: "jam format ISO",
    duration: "durasi format ISO",
    ipv4: "alamat IPv4",
    ipv6: "alamat IPv6",
    cidrv4: "rentang alamat IPv4",
    cidrv6: "rentang alamat IPv6",
    base64: "string dengan enkode base64",
    base64url: "string dengan enkode base64url",
    json_string: "string JSON",
    e164: "angka E.164",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = y(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Input tidak valid: diharapkan instanceof ${r.expected}, diterima ${c}` : `Input tidak valid: diharapkan ${i}, diterima ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Input tidak valid: diharapkan ${v(r.values[0])}` : `Pilihan tidak valid: diharapkan salah satu dari ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `Terlalu besar: diharapkan ${r.origin ?? "value"} memiliki ${i}${r.maximum.toString()} ${s.unit ?? "elemen"}` : `Terlalu besar: diharapkan ${r.origin ?? "value"} menjadi ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `Terlalu kecil: diharapkan ${r.origin} memiliki ${i}${r.minimum.toString()} ${s.unit}` : `Terlalu kecil: diharapkan ${r.origin} menjadi ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `String tidak valid: harus dimulai dengan "${i.prefix}"` : i.format === "ends_with" ? `String tidak valid: harus berakhir dengan "${i.suffix}"` : i.format === "includes" ? `String tidak valid: harus menyertakan "${i.includes}"` : i.format === "regex" ? `String tidak valid: harus sesuai pola ${i.pattern}` : `${n[i.format] ?? r.format} tidak valid`;
      }
      case "not_multiple_of":
        return `Angka tidak valid: harus kelipatan dari ${r.divisor}`;
      case "unrecognized_keys":
        return `Kunci tidak dikenali ${r.keys.length > 1 ? "s" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Kunci tidak valid di ${r.origin}`;
      case "invalid_union":
        return "Input tidak valid";
      case "invalid_element":
        return `Nilai tidak valid di ${r.origin}`;
      default:
        return "Input tidak valid";
    }
  };
}, "error");
function Ma() {
  return {
    localeError: wg()
  };
}
a(Ma, "default");

// versions/4.3.6/node_modules/zod/v4/locales/is.js
var kg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "stafi", verb: "a\xF0 hafa" },
    file: { unit: "b\xE6ti", verb: "a\xF0 hafa" },
    array: { unit: "hluti", verb: "a\xF0 hafa" },
    set: { unit: "hluti", verb: "a\xF0 hafa" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "gildi",
    email: "netfang",
    url: "vefsl\xF3\xF0",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO dagsetning og t\xEDmi",
    date: "ISO dagsetning",
    time: "ISO t\xEDmi",
    duration: "ISO t\xEDmalengd",
    ipv4: "IPv4 address",
    ipv6: "IPv6 address",
    cidrv4: "IPv4 range",
    cidrv6: "IPv6 range",
    base64: "base64-encoded strengur",
    base64url: "base64url-encoded strengur",
    json_string: "JSON strengur",
    e164: "E.164 t\xF6lugildi",
    jwt: "JWT",
    template_literal: "gildi"
  }, o = {
    nan: "NaN",
    number: "n\xFAmer",
    array: "fylki"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = y(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Rangt gildi: \xDE\xFA sl\xF3st inn ${c} \xFEar sem \xE1 a\xF0 vera instanceof ${r.expected}` : `Rangt gildi: \xDE\xFA sl\xF3st inn ${c} \xFEar sem \xE1 a\xF0 vera ${i}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Rangt gildi: gert r\xE1\xF0 fyrir ${v(r.values[0])}` : `\xD3gilt val: m\xE1 vera eitt af eftirfarandi ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `Of st\xF3rt: gert er r\xE1\xF0 fyrir a\xF0 ${r.origin ?? "gildi"} hafi ${i}${r.maximum.toString()} ${s.unit ?? "hluti"}` : `Of st\xF3rt: gert er r\xE1\xF0 fyrir a\xF0 ${r.origin ?? "gildi"} s\xE9 ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `Of l\xEDti\xF0: gert er r\xE1\xF0 fyrir a\xF0 ${r.origin} hafi ${i}${r.minimum.toString()} ${s.unit}` : `Of l\xEDti\xF0: gert er r\xE1\xF0 fyrir a\xF0 ${r.origin} s\xE9 ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\xD3gildur strengur: ver\xF0ur a\xF0 byrja \xE1 "${i.prefix}"` : i.format === "ends_with" ? `\xD3gildur strengur: ver\xF0ur a\xF0 enda \xE1 "${i.suffix}"` : i.format === "includes" ? `\xD3gildur strengur: ver\xF0ur a\xF0 innihalda "${i.includes}"` : i.format === "regex" ? `\xD3gildur strengur: ver\xF0ur a\xF0 fylgja mynstri ${i.pattern}` : `Rangt ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `R\xF6ng tala: ver\xF0ur a\xF0 vera margfeldi af ${r.divisor}`;
      case "unrecognized_keys":
        return `\xD3\xFEekkt ${r.keys.length > 1 ? "ir lyklar" : "ur lykill"}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Rangur lykill \xED ${r.origin}`;
      case "invalid_union":
        return "Rangt gildi";
      case "invalid_element":
        return `Rangt gildi \xED ${r.origin}`;
      default:
        return "Rangt gildi";
    }
  };
}, "error");
function La() {
  return {
    localeError: kg()
  };
}
a(La, "default");

// versions/4.3.6/node_modules/zod/v4/locales/it.js
var zg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "caratteri", verb: "avere" },
    file: { unit: "byte", verb: "avere" },
    array: { unit: "elementi", verb: "avere" },
    set: { unit: "elementi", verb: "avere" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "input",
    email: "indirizzo email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "data e ora ISO",
    date: "data ISO",
    time: "ora ISO",
    duration: "durata ISO",
    ipv4: "indirizzo IPv4",
    ipv6: "indirizzo IPv6",
    cidrv4: "intervallo IPv4",
    cidrv6: "intervallo IPv6",
    base64: "stringa codificata in base64",
    base64url: "URL codificata in base64",
    json_string: "stringa JSON",
    e164: "numero E.164",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN",
    number: "numero",
    array: "vettore"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = y(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Input non valido: atteso instanceof ${r.expected}, ricevuto ${c}` : `Input non valido: atteso ${i}, ricevuto ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Input non valido: atteso ${v(r.values[0])}` : `Opzione non valida: atteso uno tra ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `Troppo grande: ${r.origin ?? "valore"} deve avere ${i}${r.maximum.toString()} ${s.unit ?? "elementi"}` : `Troppo grande: ${r.origin ?? "valore"} deve essere ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `Troppo piccolo: ${r.origin} deve avere ${i}${r.minimum.toString()} ${s.unit}` : `Troppo piccolo: ${r.origin} deve essere ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Stringa non valida: deve iniziare con "${i.prefix}"` : i.format === "ends_with" ? `Stringa non valida: deve terminare con "${i.suffix}"` : i.format === "includes" ? `Stringa non valida: deve includere "${i.includes}"` : i.format === "regex" ? `Stringa non valida: deve corrispondere al pattern ${i.pattern}` : `Invalid ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Numero non valido: deve essere un multiplo di ${r.divisor}`;
      case "unrecognized_keys":
        return `Chiav${r.keys.length > 1 ? "i" : "e"} non riconosciut${r.keys.length > 1 ? "e" : "a"}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Chiave non valida in ${r.origin}`;
      case "invalid_union":
        return "Input non valido";
      case "invalid_element":
        return `Valore non valido in ${r.origin}`;
      default:
        return "Input non valido";
    }
  };
}, "error");
function Ba() {
  return {
    localeError: zg()
  };
}
a(Ba, "default");

// versions/4.3.6/node_modules/zod/v4/locales/ja.js
var Ig = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "\u6587\u5B57", verb: "\u3067\u3042\u308B" },
    file: { unit: "\u30D0\u30A4\u30C8", verb: "\u3067\u3042\u308B" },
    array: { unit: "\u8981\u7D20", verb: "\u3067\u3042\u308B" },
    set: { unit: "\u8981\u7D20", verb: "\u3067\u3042\u308B" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "\u5165\u529B\u5024",
    email: "\u30E1\u30FC\u30EB\u30A2\u30C9\u30EC\u30B9",
    url: "URL",
    emoji: "\u7D75\u6587\u5B57",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO\u65E5\u6642",
    date: "ISO\u65E5\u4ED8",
    time: "ISO\u6642\u523B",
    duration: "ISO\u671F\u9593",
    ipv4: "IPv4\u30A2\u30C9\u30EC\u30B9",
    ipv6: "IPv6\u30A2\u30C9\u30EC\u30B9",
    cidrv4: "IPv4\u7BC4\u56F2",
    cidrv6: "IPv6\u7BC4\u56F2",
    base64: "base64\u30A8\u30F3\u30B3\u30FC\u30C9\u6587\u5B57\u5217",
    base64url: "base64url\u30A8\u30F3\u30B3\u30FC\u30C9\u6587\u5B57\u5217",
    json_string: "JSON\u6587\u5B57\u5217",
    e164: "E.164\u756A\u53F7",
    jwt: "JWT",
    template_literal: "\u5165\u529B\u5024"
  }, o = {
    nan: "NaN",
    number: "\u6570\u5024",
    array: "\u914D\u5217"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = y(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `\u7121\u52B9\u306A\u5165\u529B: instanceof ${r.expected}\u304C\u671F\u5F85\u3055\u308C\u307E\u3057\u305F\u304C\u3001${c}\u304C\u5165\u529B\u3055\u308C\u307E\u3057\u305F` : `\u7121\u52B9\u306A\u5165\u529B: ${i}\u304C\u671F\u5F85\u3055\u308C\u307E\u3057\u305F\u304C\u3001${c}\u304C\u5165\u529B\u3055\u308C\u307E\u3057\u305F`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u7121\u52B9\u306A\u5165\u529B: ${v(r.values[0])}\u304C\u671F\u5F85\u3055\u308C\u307E\u3057\u305F` : `\u7121\u52B9\u306A\u9078\u629E: ${p(r.values, "\u3001")}\u306E\u3044\u305A\u308C\u304B\u3067\u3042\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`;
      case "too_big": {
        let i = r.inclusive ? "\u4EE5\u4E0B\u3067\u3042\u308B" : "\u3088\u308A\u5C0F\u3055\u3044", s = t(r.origin);
        return s ? `\u5927\u304D\u3059\u304E\u308B\u5024: ${r.origin ?? "\u5024"}\u306F${r.maximum.toString()}${s.unit ?? "\u8981\u7D20"}${i}\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : `\u5927\u304D\u3059\u304E\u308B\u5024: ${r.origin ?? "\u5024"}\u306F${r.maximum.toString()}${i}\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`;
      }
      case "too_small": {
        let i = r.inclusive ? "\u4EE5\u4E0A\u3067\u3042\u308B" : "\u3088\u308A\u5927\u304D\u3044", s = t(r.origin);
        return s ? `\u5C0F\u3055\u3059\u304E\u308B\u5024: ${r.origin}\u306F${r.minimum.toString()}${s.unit}${i}\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : `\u5C0F\u3055\u3059\u304E\u308B\u5024: ${r.origin}\u306F${r.minimum.toString()}${i}\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u7121\u52B9\u306A\u6587\u5B57\u5217: "${i.prefix}"\u3067\u59CB\u307E\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : i.format === "ends_with" ? `\u7121\u52B9\u306A\u6587\u5B57\u5217: "${i.suffix}"\u3067\u7D42\u308F\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : i.format === "includes" ? `\u7121\u52B9\u306A\u6587\u5B57\u5217: "${i.includes}"\u3092\u542B\u3080\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : i.format === "regex" ? `\u7121\u52B9\u306A\u6587\u5B57\u5217: \u30D1\u30BF\u30FC\u30F3${i.pattern}\u306B\u4E00\u81F4\u3059\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : `\u7121\u52B9\u306A${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u7121\u52B9\u306A\u6570\u5024: ${r.divisor}\u306E\u500D\u6570\u3067\u3042\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`;
      case "unrecognized_keys":
        return `\u8A8D\u8B58\u3055\u308C\u3066\u3044\u306A\u3044\u30AD\u30FC${r.keys.length > 1 ? "\u7FA4" : ""}: ${p(r.keys, "\u3001")}`;
      case "invalid_key":
        return `${r.origin}\u5185\u306E\u7121\u52B9\u306A\u30AD\u30FC`;
      case "invalid_union":
        return "\u7121\u52B9\u306A\u5165\u529B";
      case "invalid_element":
        return `${r.origin}\u5185\u306E\u7121\u52B9\u306A\u5024`;
      default:
        return "\u7121\u52B9\u306A\u5165\u529B";
    }
  };
}, "error");
function Va() {
  return {
    localeError: Ig()
  };
}
a(Va, "default");

// versions/4.3.6/node_modules/zod/v4/locales/ka.js
var Sg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "\u10E1\u10D8\u10DB\u10D1\u10DD\u10DA\u10DD", verb: "\u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1" },
    file: { unit: "\u10D1\u10D0\u10D8\u10E2\u10D8", verb: "\u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1" },
    array: { unit: "\u10D4\u10DA\u10D4\u10DB\u10D4\u10DC\u10E2\u10D8", verb: "\u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1" },
    set: { unit: "\u10D4\u10DA\u10D4\u10DB\u10D4\u10DC\u10E2\u10D8", verb: "\u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "\u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0",
    email: "\u10D4\u10DA-\u10E4\u10DD\u10E1\u10E2\u10D8\u10E1 \u10DB\u10D8\u10E1\u10D0\u10DB\u10D0\u10E0\u10D7\u10D8",
    url: "URL",
    emoji: "\u10D4\u10DB\u10DD\u10EF\u10D8",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u10D7\u10D0\u10E0\u10D8\u10E6\u10D8-\u10D3\u10E0\u10DD",
    date: "\u10D7\u10D0\u10E0\u10D8\u10E6\u10D8",
    time: "\u10D3\u10E0\u10DD",
    duration: "\u10EE\u10D0\u10DC\u10D2\u10E0\u10EB\u10DA\u10D8\u10D5\u10DD\u10D1\u10D0",
    ipv4: "IPv4 \u10DB\u10D8\u10E1\u10D0\u10DB\u10D0\u10E0\u10D7\u10D8",
    ipv6: "IPv6 \u10DB\u10D8\u10E1\u10D0\u10DB\u10D0\u10E0\u10D7\u10D8",
    cidrv4: "IPv4 \u10D3\u10D8\u10D0\u10DE\u10D0\u10D6\u10DD\u10DC\u10D8",
    cidrv6: "IPv6 \u10D3\u10D8\u10D0\u10DE\u10D0\u10D6\u10DD\u10DC\u10D8",
    base64: "base64-\u10D9\u10DD\u10D3\u10D8\u10E0\u10D4\u10D1\u10E3\u10DA\u10D8 \u10E1\u10E2\u10E0\u10D8\u10DC\u10D2\u10D8",
    base64url: "base64url-\u10D9\u10DD\u10D3\u10D8\u10E0\u10D4\u10D1\u10E3\u10DA\u10D8 \u10E1\u10E2\u10E0\u10D8\u10DC\u10D2\u10D8",
    json_string: "JSON \u10E1\u10E2\u10E0\u10D8\u10DC\u10D2\u10D8",
    e164: "E.164 \u10DC\u10DD\u10DB\u10D4\u10E0\u10D8",
    jwt: "JWT",
    template_literal: "\u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0"
  }, o = {
    nan: "NaN",
    number: "\u10E0\u10D8\u10EA\u10EE\u10D5\u10D8",
    string: "\u10E1\u10E2\u10E0\u10D8\u10DC\u10D2\u10D8",
    boolean: "\u10D1\u10E3\u10DA\u10D4\u10D0\u10DC\u10D8",
    function: "\u10E4\u10E3\u10DC\u10E5\u10EA\u10D8\u10D0",
    array: "\u10DB\u10D0\u10E1\u10D8\u10D5\u10D8"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = y(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 instanceof ${r.expected}, \u10DB\u10D8\u10E6\u10D4\u10D1\u10E3\u10DA\u10D8 ${c}` : `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${i}, \u10DB\u10D8\u10E6\u10D4\u10D1\u10E3\u10DA\u10D8 ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${v(r.values[0])}` : `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D5\u10D0\u10E0\u10D8\u10D0\u10DC\u10E2\u10D8: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8\u10D0 \u10D4\u10E0\u10D7-\u10D4\u10E0\u10D7\u10D8 ${p(r.values, "|")}-\u10D3\u10D0\u10DC`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `\u10D6\u10D4\u10D3\u10DB\u10D4\u10E2\u10D0\u10D3 \u10D3\u10D8\u10D3\u10D8: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${r.origin ?? "\u10DB\u10DC\u10D8\u10E8\u10D5\u10DC\u10D4\u10DA\u10DD\u10D1\u10D0"} ${s.verb} ${i}${r.maximum.toString()} ${s.unit}` : `\u10D6\u10D4\u10D3\u10DB\u10D4\u10E2\u10D0\u10D3 \u10D3\u10D8\u10D3\u10D8: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${r.origin ?? "\u10DB\u10DC\u10D8\u10E8\u10D5\u10DC\u10D4\u10DA\u10DD\u10D1\u10D0"} \u10D8\u10E7\u10DD\u10E1 ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `\u10D6\u10D4\u10D3\u10DB\u10D4\u10E2\u10D0\u10D3 \u10DE\u10D0\u10E2\u10D0\u10E0\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${r.origin} ${s.verb} ${i}${r.minimum.toString()} ${s.unit}` : `\u10D6\u10D4\u10D3\u10DB\u10D4\u10E2\u10D0\u10D3 \u10DE\u10D0\u10E2\u10D0\u10E0\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${r.origin} \u10D8\u10E7\u10DD\u10E1 ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E1\u10E2\u10E0\u10D8\u10DC\u10D2\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10D8\u10EC\u10E7\u10D4\u10D1\u10DD\u10D3\u10D4\u10E1 "${i.prefix}"-\u10D8\u10D7` : i.format === "ends_with" ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E1\u10E2\u10E0\u10D8\u10DC\u10D2\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10DB\u10D7\u10D0\u10D5\u10E0\u10D3\u10D4\u10D1\u10DD\u10D3\u10D4\u10E1 "${i.suffix}"-\u10D8\u10D7` : i.format === "includes" ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E1\u10E2\u10E0\u10D8\u10DC\u10D2\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1 "${i.includes}"-\u10E1` : i.format === "regex" ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E1\u10E2\u10E0\u10D8\u10DC\u10D2\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D4\u10E1\u10D0\u10D1\u10D0\u10DB\u10D4\u10D1\u10DD\u10D3\u10D4\u10E1 \u10E8\u10D0\u10D1\u10DA\u10DD\u10DC\u10E1 ${i.pattern}` : `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E0\u10D8\u10EA\u10EE\u10D5\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10D8\u10E7\u10DD\u10E1 ${r.divisor}-\u10D8\u10E1 \u10EF\u10D4\u10E0\u10D0\u10D3\u10D8`;
      case "unrecognized_keys":
        return `\u10E3\u10EA\u10DC\u10DD\u10D1\u10D8 \u10D2\u10D0\u10E1\u10D0\u10E6\u10D4\u10D1${r.keys.length > 1 ? "\u10D4\u10D1\u10D8" : "\u10D8"}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D2\u10D0\u10E1\u10D0\u10E6\u10D4\u10D1\u10D8 ${r.origin}-\u10E8\u10D8`;
      case "invalid_union":
        return "\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0";
      case "invalid_element":
        return `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10DB\u10DC\u10D8\u10E8\u10D5\u10DC\u10D4\u10DA\u10DD\u10D1\u10D0 ${r.origin}-\u10E8\u10D8`;
      default:
        return "\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0";
    }
  };
}, "error");
function qa() {
  return {
    localeError: Sg()
  };
}
a(qa, "default");

// versions/4.3.6/node_modules/zod/v4/locales/km.js
var jg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "\u178F\u17BD\u17A2\u1780\u17D2\u179F\u179A", verb: "\u1782\u17BD\u179A\u1798\u17B6\u1793" },
    file: { unit: "\u1794\u17C3", verb: "\u1782\u17BD\u179A\u1798\u17B6\u1793" },
    array: { unit: "\u1792\u17B6\u178F\u17BB", verb: "\u1782\u17BD\u179A\u1798\u17B6\u1793" },
    set: { unit: "\u1792\u17B6\u178F\u17BB", verb: "\u1782\u17BD\u179A\u1798\u17B6\u1793" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B",
    email: "\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793\u17A2\u17CA\u17B8\u1798\u17C2\u179B",
    url: "URL",
    emoji: "\u179F\u1789\u17D2\u1789\u17B6\u17A2\u17B6\u179A\u1798\u17D2\u1798\u178E\u17CD",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u1780\u17B6\u179B\u1794\u179A\u17B7\u1785\u17D2\u1786\u17C1\u1791 \u1793\u17B7\u1784\u1798\u17C9\u17C4\u1784 ISO",
    date: "\u1780\u17B6\u179B\u1794\u179A\u17B7\u1785\u17D2\u1786\u17C1\u1791 ISO",
    time: "\u1798\u17C9\u17C4\u1784 ISO",
    duration: "\u179A\u1799\u17C8\u1796\u17C1\u179B ISO",
    ipv4: "\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793 IPv4",
    ipv6: "\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793 IPv6",
    cidrv4: "\u178A\u17C2\u1793\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793 IPv4",
    cidrv6: "\u178A\u17C2\u1793\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793 IPv6",
    base64: "\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u17A2\u17CA\u17B7\u1780\u17BC\u178A base64",
    base64url: "\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u17A2\u17CA\u17B7\u1780\u17BC\u178A base64url",
    json_string: "\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A JSON",
    e164: "\u179B\u17C1\u1781 E.164",
    jwt: "JWT",
    template_literal: "\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B"
  }, o = {
    nan: "NaN",
    number: "\u179B\u17C1\u1781",
    array: "\u17A2\u17B6\u179A\u17C1 (Array)",
    null: "\u1782\u17D2\u1798\u17B6\u1793\u178F\u1798\u17D2\u179B\u17C3 (null)"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = y(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A instanceof ${r.expected} \u1794\u17C9\u17BB\u1793\u17D2\u178F\u17C2\u1791\u1791\u17BD\u179B\u1794\u17B6\u1793 ${c}` : `\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${i} \u1794\u17C9\u17BB\u1793\u17D2\u178F\u17C2\u1791\u1791\u17BD\u179B\u1794\u17B6\u1793 ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${v(r.values[0])}` : `\u1787\u1798\u17D2\u179A\u17BE\u179F\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1787\u17B6\u1798\u17BD\u1799\u1780\u17D2\u1793\u17BB\u1784\u1785\u17C6\u178E\u17C4\u1798 ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `\u1792\u17C6\u1796\u17C1\u1780\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${r.origin ?? "\u178F\u1798\u17D2\u179B\u17C3"} ${i} ${r.maximum.toString()} ${s.unit ?? "\u1792\u17B6\u178F\u17BB"}` : `\u1792\u17C6\u1796\u17C1\u1780\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${r.origin ?? "\u178F\u1798\u17D2\u179B\u17C3"} ${i} ${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `\u178F\u17BC\u1785\u1796\u17C1\u1780\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${r.origin} ${i} ${r.minimum.toString()} ${s.unit}` : `\u178F\u17BC\u1785\u1796\u17C1\u1780\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${r.origin} ${i} ${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1785\u17B6\u1794\u17CB\u1795\u17D2\u178F\u17BE\u1798\u178A\u17C4\u1799 "${i.prefix}"` : i.format === "ends_with" ? `\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1794\u1789\u17D2\u1785\u1794\u17CB\u178A\u17C4\u1799 "${i.suffix}"` : i.format === "includes" ? `\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1798\u17B6\u1793 "${i.includes}"` : i.format === "regex" ? `\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u178F\u17C2\u1795\u17D2\u1782\u17BC\u1795\u17D2\u1782\u1784\u1793\u17B9\u1784\u1791\u1798\u17D2\u179A\u1784\u17CB\u178A\u17C2\u179B\u1794\u17B6\u1793\u1780\u17C6\u178E\u178F\u17CB ${i.pattern}` : `\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u179B\u17C1\u1781\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u178F\u17C2\u1787\u17B6\u1796\u17A0\u17BB\u1782\u17BB\u178E\u1793\u17C3 ${r.divisor}`;
      case "unrecognized_keys":
        return `\u179A\u1780\u1783\u17BE\u1789\u179F\u17C4\u1798\u17B7\u1793\u179F\u17D2\u1782\u17B6\u179B\u17CB\u17D6 ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `\u179F\u17C4\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u1793\u17C5\u1780\u17D2\u1793\u17BB\u1784 ${r.origin}`;
      case "invalid_union":
        return "\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C";
      case "invalid_element":
        return `\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u1793\u17C5\u1780\u17D2\u1793\u17BB\u1784 ${r.origin}`;
      default:
        return "\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C";
    }
  };
}, "error");
function Lt() {
  return {
    localeError: jg()
  };
}
a(Lt, "default");

// versions/4.3.6/node_modules/zod/v4/locales/kh.js
function Ja() {
  return Lt();
}
a(Ja, "default");

// versions/4.3.6/node_modules/zod/v4/locales/ko.js
var Og = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "\uBB38\uC790", verb: "to have" },
    file: { unit: "\uBC14\uC774\uD2B8", verb: "to have" },
    array: { unit: "\uAC1C", verb: "to have" },
    set: { unit: "\uAC1C", verb: "to have" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "\uC785\uB825",
    email: "\uC774\uBA54\uC77C \uC8FC\uC18C",
    url: "URL",
    emoji: "\uC774\uBAA8\uC9C0",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \uB0A0\uC9DC\uC2DC\uAC04",
    date: "ISO \uB0A0\uC9DC",
    time: "ISO \uC2DC\uAC04",
    duration: "ISO \uAE30\uAC04",
    ipv4: "IPv4 \uC8FC\uC18C",
    ipv6: "IPv6 \uC8FC\uC18C",
    cidrv4: "IPv4 \uBC94\uC704",
    cidrv6: "IPv6 \uBC94\uC704",
    base64: "base64 \uC778\uCF54\uB529 \uBB38\uC790\uC5F4",
    base64url: "base64url \uC778\uCF54\uB529 \uBB38\uC790\uC5F4",
    json_string: "JSON \uBB38\uC790\uC5F4",
    e164: "E.164 \uBC88\uD638",
    jwt: "JWT",
    template_literal: "\uC785\uB825"
  }, o = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = y(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `\uC798\uBABB\uB41C \uC785\uB825: \uC608\uC0C1 \uD0C0\uC785\uC740 instanceof ${r.expected}, \uBC1B\uC740 \uD0C0\uC785\uC740 ${c}\uC785\uB2C8\uB2E4` : `\uC798\uBABB\uB41C \uC785\uB825: \uC608\uC0C1 \uD0C0\uC785\uC740 ${i}, \uBC1B\uC740 \uD0C0\uC785\uC740 ${c}\uC785\uB2C8\uB2E4`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\uC798\uBABB\uB41C \uC785\uB825: \uAC12\uC740 ${v(r.values[0])} \uC774\uC5B4\uC57C \uD569\uB2C8\uB2E4` : `\uC798\uBABB\uB41C \uC635\uC158: ${p(r.values, "\uB610\uB294 ")} \uC911 \uD558\uB098\uC5EC\uC57C \uD569\uB2C8\uB2E4`;
      case "too_big": {
        let i = r.inclusive ? "\uC774\uD558" : "\uBBF8\uB9CC", s = i === "\uBBF8\uB9CC" ? "\uC774\uC5B4\uC57C \uD569\uB2C8\uB2E4" : "\uC5EC\uC57C \uD569\uB2C8\uB2E4", c = t(r.origin), u = c?.unit ?? "\uC694\uC18C";
        return c ? `${r.origin ?? "\uAC12"}\uC774 \uB108\uBB34 \uD07D\uB2C8\uB2E4: ${r.maximum.toString()}${u} ${i}${s}` : `${r.origin ?? "\uAC12"}\uC774 \uB108\uBB34 \uD07D\uB2C8\uB2E4: ${r.maximum.toString()} ${i}${s}`;
      }
      case "too_small": {
        let i = r.inclusive ? "\uC774\uC0C1" : "\uCD08\uACFC", s = i === "\uC774\uC0C1" ? "\uC774\uC5B4\uC57C \uD569\uB2C8\uB2E4" : "\uC5EC\uC57C \uD569\uB2C8\uB2E4", c = t(r.origin), u = c?.unit ?? "\uC694\uC18C";
        return c ? `${r.origin ?? "\uAC12"}\uC774 \uB108\uBB34 \uC791\uC2B5\uB2C8\uB2E4: ${r.minimum.toString()}${u} ${i}${s}` : `${r.origin ?? "\uAC12"}\uC774 \uB108\uBB34 \uC791\uC2B5\uB2C8\uB2E4: ${r.minimum.toString()} ${i}${s}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\uC798\uBABB\uB41C \uBB38\uC790\uC5F4: "${i.prefix}"(\uC73C)\uB85C \uC2DC\uC791\uD574\uC57C \uD569\uB2C8\uB2E4` : i.format === "ends_with" ? `\uC798\uBABB\uB41C \uBB38\uC790\uC5F4: "${i.suffix}"(\uC73C)\uB85C \uB05D\uB098\uC57C \uD569\uB2C8\uB2E4` : i.format === "includes" ? `\uC798\uBABB\uB41C \uBB38\uC790\uC5F4: "${i.includes}"\uC744(\uB97C) \uD3EC\uD568\uD574\uC57C \uD569\uB2C8\uB2E4` : i.format === "regex" ? `\uC798\uBABB\uB41C \uBB38\uC790\uC5F4: \uC815\uADDC\uC2DD ${i.pattern} \uD328\uD134\uACFC \uC77C\uCE58\uD574\uC57C \uD569\uB2C8\uB2E4` : `\uC798\uBABB\uB41C ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\uC798\uBABB\uB41C \uC22B\uC790: ${r.divisor}\uC758 \uBC30\uC218\uC5EC\uC57C \uD569\uB2C8\uB2E4`;
      case "unrecognized_keys":
        return `\uC778\uC2DD\uD560 \uC218 \uC5C6\uB294 \uD0A4: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `\uC798\uBABB\uB41C \uD0A4: ${r.origin}`;
      case "invalid_union":
        return "\uC798\uBABB\uB41C \uC785\uB825";
      case "invalid_element":
        return `\uC798\uBABB\uB41C \uAC12: ${r.origin}`;
      default:
        return "\uC798\uBABB\uB41C \uC785\uB825";
    }
  };
}, "error");
function Wa() {
  return {
    localeError: Og()
  };
}
a(Wa, "default");

// versions/4.3.6/node_modules/zod/v4/locales/lt.js
var Bt = /* @__PURE__ */ a((e) => e.charAt(0).toUpperCase() + e.slice(1), "capitalizeFirstCharacter");
function ql(e) {
  let t = Math.abs(e), n = t % 10, o = t % 100;
  return o >= 11 && o <= 19 || n === 0 ? "many" : n === 1 ? "one" : "few";
}
a(ql, "getUnitTypeFromNumber");
var Tg = /* @__PURE__ */ a(() => {
  let e = {
    string: {
      unit: {
        one: "simbolis",
        few: "simboliai",
        many: "simboli\u0173"
      },
      verb: {
        smaller: {
          inclusive: "turi b\u016Bti ne ilgesn\u0117 kaip",
          notInclusive: "turi b\u016Bti trumpesn\u0117 kaip"
        },
        bigger: {
          inclusive: "turi b\u016Bti ne trumpesn\u0117 kaip",
          notInclusive: "turi b\u016Bti ilgesn\u0117 kaip"
        }
      }
    },
    file: {
      unit: {
        one: "baitas",
        few: "baitai",
        many: "bait\u0173"
      },
      verb: {
        smaller: {
          inclusive: "turi b\u016Bti ne didesnis kaip",
          notInclusive: "turi b\u016Bti ma\u017Eesnis kaip"
        },
        bigger: {
          inclusive: "turi b\u016Bti ne ma\u017Eesnis kaip",
          notInclusive: "turi b\u016Bti didesnis kaip"
        }
      }
    },
    array: {
      unit: {
        one: "element\u0105",
        few: "elementus",
        many: "element\u0173"
      },
      verb: {
        smaller: {
          inclusive: "turi tur\u0117ti ne daugiau kaip",
          notInclusive: "turi tur\u0117ti ma\u017Eiau kaip"
        },
        bigger: {
          inclusive: "turi tur\u0117ti ne ma\u017Eiau kaip",
          notInclusive: "turi tur\u0117ti daugiau kaip"
        }
      }
    },
    set: {
      unit: {
        one: "element\u0105",
        few: "elementus",
        many: "element\u0173"
      },
      verb: {
        smaller: {
          inclusive: "turi tur\u0117ti ne daugiau kaip",
          notInclusive: "turi tur\u0117ti ma\u017Eiau kaip"
        },
        bigger: {
          inclusive: "turi tur\u0117ti ne ma\u017Eiau kaip",
          notInclusive: "turi tur\u0117ti daugiau kaip"
        }
      }
    }
  };
  function t(r, i, s, c) {
    let u = e[r] ?? null;
    return u === null ? u : {
      unit: u.unit[i],
      verb: u.verb[c][s ? "inclusive" : "notInclusive"]
    };
  }
  a(t, "getSizing");
  let n = {
    regex: "\u012Fvestis",
    email: "el. pa\u0161to adresas",
    url: "URL",
    emoji: "jaustukas",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO data ir laikas",
    date: "ISO data",
    time: "ISO laikas",
    duration: "ISO trukm\u0117",
    ipv4: "IPv4 adresas",
    ipv6: "IPv6 adresas",
    cidrv4: "IPv4 tinklo prefiksas (CIDR)",
    cidrv6: "IPv6 tinklo prefiksas (CIDR)",
    base64: "base64 u\u017Ekoduota eilut\u0117",
    base64url: "base64url u\u017Ekoduota eilut\u0117",
    json_string: "JSON eilut\u0117",
    e164: "E.164 numeris",
    jwt: "JWT",
    template_literal: "\u012Fvestis"
  }, o = {
    nan: "NaN",
    number: "skai\u010Dius",
    bigint: "sveikasis skai\u010Dius",
    string: "eilut\u0117",
    boolean: "login\u0117 reik\u0161m\u0117",
    undefined: "neapibr\u0117\u017Eta reik\u0161m\u0117",
    function: "funkcija",
    symbol: "simbolis",
    array: "masyvas",
    object: "objektas",
    null: "nulin\u0117 reik\u0161m\u0117"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = y(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Gautas tipas ${c}, o tik\u0117tasi - instanceof ${r.expected}` : `Gautas tipas ${c}, o tik\u0117tasi - ${i}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Privalo b\u016Bti ${v(r.values[0])}` : `Privalo b\u016Bti vienas i\u0161 ${p(r.values, "|")} pasirinkim\u0173`;
      case "too_big": {
        let i = o[r.origin] ?? r.origin, s = t(r.origin, ql(Number(r.maximum)), r.inclusive ?? !1, "smaller");
        if (s?.verb)
          return `${Bt(i ?? r.origin ?? "reik\u0161m\u0117")} ${s.verb} ${r.maximum.toString()} ${s.unit ?? "element\u0173"}`;
        let c = r.inclusive ? "ne didesnis kaip" : "ma\u017Eesnis kaip";
        return `${Bt(i ?? r.origin ?? "reik\u0161m\u0117")} turi b\u016Bti ${c} ${r.maximum.toString()} ${s?.unit}`;
      }
      case "too_small": {
        let i = o[r.origin] ?? r.origin, s = t(r.origin, ql(Number(r.minimum)), r.inclusive ?? !1, "bigger");
        if (s?.verb)
          return `${Bt(i ?? r.origin ?? "reik\u0161m\u0117")} ${s.verb} ${r.minimum.toString()} ${s.unit ?? "element\u0173"}`;
        let c = r.inclusive ? "ne ma\u017Eesnis kaip" : "didesnis kaip";
        return `${Bt(i ?? r.origin ?? "reik\u0161m\u0117")} turi b\u016Bti ${c} ${r.minimum.toString()} ${s?.unit}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Eilut\u0117 privalo prasid\u0117ti "${i.prefix}"` : i.format === "ends_with" ? `Eilut\u0117 privalo pasibaigti "${i.suffix}"` : i.format === "includes" ? `Eilut\u0117 privalo \u012Ftraukti "${i.includes}"` : i.format === "regex" ? `Eilut\u0117 privalo atitikti ${i.pattern}` : `Neteisingas ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Skai\u010Dius privalo b\u016Bti ${r.divisor} kartotinis.`;
      case "unrecognized_keys":
        return `Neatpa\u017Eint${r.keys.length > 1 ? "i" : "as"} rakt${r.keys.length > 1 ? "ai" : "as"}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return "Rastas klaidingas raktas";
      case "invalid_union":
        return "Klaidinga \u012Fvestis";
      case "invalid_element": {
        let i = o[r.origin] ?? r.origin;
        return `${Bt(i ?? r.origin ?? "reik\u0161m\u0117")} turi klaiding\u0105 \u012Fvest\u012F`;
      }
      default:
        return "Klaidinga \u012Fvestis";
    }
  };
}, "error");
function Ka() {
  return {
    localeError: Tg()
  };
}
a(Ka, "default");

// versions/4.3.6/node_modules/zod/v4/locales/mk.js
var Pg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "\u0437\u043D\u0430\u0446\u0438", verb: "\u0434\u0430 \u0438\u043C\u0430\u0430\u0442" },
    file: { unit: "\u0431\u0430\u0458\u0442\u0438", verb: "\u0434\u0430 \u0438\u043C\u0430\u0430\u0442" },
    array: { unit: "\u0441\u0442\u0430\u0432\u043A\u0438", verb: "\u0434\u0430 \u0438\u043C\u0430\u0430\u0442" },
    set: { unit: "\u0441\u0442\u0430\u0432\u043A\u0438", verb: "\u0434\u0430 \u0438\u043C\u0430\u0430\u0442" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "\u0432\u043D\u0435\u0441",
    email: "\u0430\u0434\u0440\u0435\u0441\u0430 \u043D\u0430 \u0435-\u043F\u043E\u0448\u0442\u0430",
    url: "URL",
    emoji: "\u0435\u043C\u043E\u045F\u0438",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0434\u0430\u0442\u0443\u043C \u0438 \u0432\u0440\u0435\u043C\u0435",
    date: "ISO \u0434\u0430\u0442\u0443\u043C",
    time: "ISO \u0432\u0440\u0435\u043C\u0435",
    duration: "ISO \u0432\u0440\u0435\u043C\u0435\u0442\u0440\u0430\u0435\u045A\u0435",
    ipv4: "IPv4 \u0430\u0434\u0440\u0435\u0441\u0430",
    ipv6: "IPv6 \u0430\u0434\u0440\u0435\u0441\u0430",
    cidrv4: "IPv4 \u043E\u043F\u0441\u0435\u0433",
    cidrv6: "IPv6 \u043E\u043F\u0441\u0435\u0433",
    base64: "base64-\u0435\u043D\u043A\u043E\u0434\u0438\u0440\u0430\u043D\u0430 \u043D\u0438\u0437\u0430",
    base64url: "base64url-\u0435\u043D\u043A\u043E\u0434\u0438\u0440\u0430\u043D\u0430 \u043D\u0438\u0437\u0430",
    json_string: "JSON \u043D\u0438\u0437\u0430",
    e164: "E.164 \u0431\u0440\u043E\u0458",
    jwt: "JWT",
    template_literal: "\u0432\u043D\u0435\u0441"
  }, o = {
    nan: "NaN",
    number: "\u0431\u0440\u043E\u0458",
    array: "\u043D\u0438\u0437\u0430"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = y(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `\u0413\u0440\u0435\u0448\u0435\u043D \u0432\u043D\u0435\u0441: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 instanceof ${r.expected}, \u043F\u0440\u0438\u043C\u0435\u043D\u043E ${c}` : `\u0413\u0440\u0435\u0448\u0435\u043D \u0432\u043D\u0435\u0441: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${i}, \u043F\u0440\u0438\u043C\u0435\u043D\u043E ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Invalid input: expected ${v(r.values[0])}` : `\u0413\u0440\u0435\u0448\u0430\u043D\u0430 \u043E\u043F\u0446\u0438\u0458\u0430: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 \u0435\u0434\u043D\u0430 ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `\u041F\u0440\u0435\u043C\u043D\u043E\u0433\u0443 \u0433\u043E\u043B\u0435\u043C: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${r.origin ?? "\u0432\u0440\u0435\u0434\u043D\u043E\u0441\u0442\u0430"} \u0434\u0430 \u0438\u043C\u0430 ${i}${r.maximum.toString()} ${s.unit ?? "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0438"}` : `\u041F\u0440\u0435\u043C\u043D\u043E\u0433\u0443 \u0433\u043E\u043B\u0435\u043C: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${r.origin ?? "\u0432\u0440\u0435\u0434\u043D\u043E\u0441\u0442\u0430"} \u0434\u0430 \u0431\u0438\u0434\u0435 ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `\u041F\u0440\u0435\u043C\u043D\u043E\u0433\u0443 \u043C\u0430\u043B: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${r.origin} \u0434\u0430 \u0438\u043C\u0430 ${i}${r.minimum.toString()} ${s.unit}` : `\u041F\u0440\u0435\u043C\u043D\u043E\u0433\u0443 \u043C\u0430\u043B: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${r.origin} \u0434\u0430 \u0431\u0438\u0434\u0435 ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u041D\u0435\u0432\u0430\u0436\u0435\u0447\u043A\u0430 \u043D\u0438\u0437\u0430: \u043C\u043E\u0440\u0430 \u0434\u0430 \u0437\u0430\u043F\u043E\u0447\u043D\u0443\u0432\u0430 \u0441\u043E "${i.prefix}"` : i.format === "ends_with" ? `\u041D\u0435\u0432\u0430\u0436\u0435\u0447\u043A\u0430 \u043D\u0438\u0437\u0430: \u043C\u043E\u0440\u0430 \u0434\u0430 \u0437\u0430\u0432\u0440\u0448\u0443\u0432\u0430 \u0441\u043E "${i.suffix}"` : i.format === "includes" ? `\u041D\u0435\u0432\u0430\u0436\u0435\u0447\u043A\u0430 \u043D\u0438\u0437\u0430: \u043C\u043E\u0440\u0430 \u0434\u0430 \u0432\u043A\u043B\u0443\u0447\u0443\u0432\u0430 "${i.includes}"` : i.format === "regex" ? `\u041D\u0435\u0432\u0430\u0436\u0435\u0447\u043A\u0430 \u043D\u0438\u0437\u0430: \u043C\u043E\u0440\u0430 \u0434\u0430 \u043E\u0434\u0433\u043E\u0430\u0440\u0430 \u043D\u0430 \u043F\u0430\u0442\u0435\u0440\u043D\u043E\u0442 ${i.pattern}` : `Invalid ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u0413\u0440\u0435\u0448\u0435\u043D \u0431\u0440\u043E\u0458: \u043C\u043E\u0440\u0430 \u0434\u0430 \u0431\u0438\u0434\u0435 \u0434\u0435\u043B\u0438\u0432 \u0441\u043E ${r.divisor}`;
      case "unrecognized_keys":
        return `${r.keys.length > 1 ? "\u041D\u0435\u043F\u0440\u0435\u043F\u043E\u0437\u043D\u0430\u0435\u043D\u0438 \u043A\u043B\u0443\u0447\u0435\u0432\u0438" : "\u041D\u0435\u043F\u0440\u0435\u043F\u043E\u0437\u043D\u0430\u0435\u043D \u043A\u043B\u0443\u0447"}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `\u0413\u0440\u0435\u0448\u0435\u043D \u043A\u043B\u0443\u0447 \u0432\u043E ${r.origin}`;
      case "invalid_union":
        return "\u0413\u0440\u0435\u0448\u0435\u043D \u0432\u043D\u0435\u0441";
      case "invalid_element":
        return `\u0413\u0440\u0435\u0448\u043D\u0430 \u0432\u0440\u0435\u0434\u043D\u043E\u0441\u0442 \u0432\u043E ${r.origin}`;
      default:
        return "\u0413\u0440\u0435\u0448\u0435\u043D \u0432\u043D\u0435\u0441";
    }
  };
}, "error");
function Ga() {
  return {
    localeError: Pg()
  };
}
a(Ga, "default");

// versions/4.3.6/node_modules/zod/v4/locales/ms.js
var Ug = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "aksara", verb: "mempunyai" },
    file: { unit: "bait", verb: "mempunyai" },
    array: { unit: "elemen", verb: "mempunyai" },
    set: { unit: "elemen", verb: "mempunyai" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "input",
    email: "alamat e-mel",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "tarikh masa ISO",
    date: "tarikh ISO",
    time: "masa ISO",
    duration: "tempoh ISO",
    ipv4: "alamat IPv4",
    ipv6: "alamat IPv6",
    cidrv4: "julat IPv4",
    cidrv6: "julat IPv6",
    base64: "string dikodkan base64",
    base64url: "string dikodkan base64url",
    json_string: "string JSON",
    e164: "nombor E.164",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN",
    number: "nombor"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = y(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Input tidak sah: dijangka instanceof ${r.expected}, diterima ${c}` : `Input tidak sah: dijangka ${i}, diterima ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Input tidak sah: dijangka ${v(r.values[0])}` : `Pilihan tidak sah: dijangka salah satu daripada ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `Terlalu besar: dijangka ${r.origin ?? "nilai"} ${s.verb} ${i}${r.maximum.toString()} ${s.unit ?? "elemen"}` : `Terlalu besar: dijangka ${r.origin ?? "nilai"} adalah ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `Terlalu kecil: dijangka ${r.origin} ${s.verb} ${i}${r.minimum.toString()} ${s.unit}` : `Terlalu kecil: dijangka ${r.origin} adalah ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `String tidak sah: mesti bermula dengan "${i.prefix}"` : i.format === "ends_with" ? `String tidak sah: mesti berakhir dengan "${i.suffix}"` : i.format === "includes" ? `String tidak sah: mesti mengandungi "${i.includes}"` : i.format === "regex" ? `String tidak sah: mesti sepadan dengan corak ${i.pattern}` : `${n[i.format] ?? r.format} tidak sah`;
      }
      case "not_multiple_of":
        return `Nombor tidak sah: perlu gandaan ${r.divisor}`;
      case "unrecognized_keys":
        return `Kunci tidak dikenali: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Kunci tidak sah dalam ${r.origin}`;
      case "invalid_union":
        return "Input tidak sah";
      case "invalid_element":
        return `Nilai tidak sah dalam ${r.origin}`;
      default:
        return "Input tidak sah";
    }
  };
}, "error");
function Xa() {
  return {
    localeError: Ug()
  };
}
a(Xa, "default");

// versions/4.3.6/node_modules/zod/v4/locales/nl.js
var Dg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "tekens", verb: "heeft" },
    file: { unit: "bytes", verb: "heeft" },
    array: { unit: "elementen", verb: "heeft" },
    set: { unit: "elementen", verb: "heeft" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "invoer",
    email: "emailadres",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datum en tijd",
    date: "ISO datum",
    time: "ISO tijd",
    duration: "ISO duur",
    ipv4: "IPv4-adres",
    ipv6: "IPv6-adres",
    cidrv4: "IPv4-bereik",
    cidrv6: "IPv6-bereik",
    base64: "base64-gecodeerde tekst",
    base64url: "base64 URL-gecodeerde tekst",
    json_string: "JSON string",
    e164: "E.164-nummer",
    jwt: "JWT",
    template_literal: "invoer"
  }, o = {
    nan: "NaN",
    number: "getal"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = y(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Ongeldige invoer: verwacht instanceof ${r.expected}, ontving ${c}` : `Ongeldige invoer: verwacht ${i}, ontving ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Ongeldige invoer: verwacht ${v(r.values[0])}` : `Ongeldige optie: verwacht \xE9\xE9n van ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin), c = r.origin === "date" ? "laat" : r.origin === "string" ? "lang" : "groot";
        return s ? `Te ${c}: verwacht dat ${r.origin ?? "waarde"} ${i}${r.maximum.toString()} ${s.unit ?? "elementen"} ${s.verb}` : `Te ${c}: verwacht dat ${r.origin ?? "waarde"} ${i}${r.maximum.toString()} is`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin), c = r.origin === "date" ? "vroeg" : r.origin === "string" ? "kort" : "klein";
        return s ? `Te ${c}: verwacht dat ${r.origin} ${i}${r.minimum.toString()} ${s.unit} ${s.verb}` : `Te ${c}: verwacht dat ${r.origin} ${i}${r.minimum.toString()} is`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Ongeldige tekst: moet met "${i.prefix}" beginnen` : i.format === "ends_with" ? `Ongeldige tekst: moet op "${i.suffix}" eindigen` : i.format === "includes" ? `Ongeldige tekst: moet "${i.includes}" bevatten` : i.format === "regex" ? `Ongeldige tekst: moet overeenkomen met patroon ${i.pattern}` : `Ongeldig: ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Ongeldig getal: moet een veelvoud van ${r.divisor} zijn`;
      case "unrecognized_keys":
        return `Onbekende key${r.keys.length > 1 ? "s" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Ongeldige key in ${r.origin}`;
      case "invalid_union":
        return "Ongeldige invoer";
      case "invalid_element":
        return `Ongeldige waarde in ${r.origin}`;
      default:
        return "Ongeldige invoer";
    }
  };
}, "error");
function Ha() {
  return {
    localeError: Dg()
  };
}
a(Ha, "default");

// versions/4.3.6/node_modules/zod/v4/locales/no.js
var Eg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "tegn", verb: "\xE5 ha" },
    file: { unit: "bytes", verb: "\xE5 ha" },
    array: { unit: "elementer", verb: "\xE5 inneholde" },
    set: { unit: "elementer", verb: "\xE5 inneholde" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "input",
    email: "e-postadresse",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO dato- og klokkeslett",
    date: "ISO-dato",
    time: "ISO-klokkeslett",
    duration: "ISO-varighet",
    ipv4: "IPv4-omr\xE5de",
    ipv6: "IPv6-omr\xE5de",
    cidrv4: "IPv4-spekter",
    cidrv6: "IPv6-spekter",
    base64: "base64-enkodet streng",
    base64url: "base64url-enkodet streng",
    json_string: "JSON-streng",
    e164: "E.164-nummer",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN",
    number: "tall",
    array: "liste"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = y(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Ugyldig input: forventet instanceof ${r.expected}, fikk ${c}` : `Ugyldig input: forventet ${i}, fikk ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Ugyldig verdi: forventet ${v(r.values[0])}` : `Ugyldig valg: forventet en av ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `For stor(t): forventet ${r.origin ?? "value"} til \xE5 ha ${i}${r.maximum.toString()} ${s.unit ?? "elementer"}` : `For stor(t): forventet ${r.origin ?? "value"} til \xE5 ha ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `For lite(n): forventet ${r.origin} til \xE5 ha ${i}${r.minimum.toString()} ${s.unit}` : `For lite(n): forventet ${r.origin} til \xE5 ha ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Ugyldig streng: m\xE5 starte med "${i.prefix}"` : i.format === "ends_with" ? `Ugyldig streng: m\xE5 ende med "${i.suffix}"` : i.format === "includes" ? `Ugyldig streng: m\xE5 inneholde "${i.includes}"` : i.format === "regex" ? `Ugyldig streng: m\xE5 matche m\xF8nsteret ${i.pattern}` : `Ugyldig ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Ugyldig tall: m\xE5 v\xE6re et multiplum av ${r.divisor}`;
      case "unrecognized_keys":
        return `${r.keys.length > 1 ? "Ukjente n\xF8kler" : "Ukjent n\xF8kkel"}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Ugyldig n\xF8kkel i ${r.origin}`;
      case "invalid_union":
        return "Ugyldig input";
      case "invalid_element":
        return `Ugyldig verdi i ${r.origin}`;
      default:
        return "Ugyldig input";
    }
  };
}, "error");
function Qa() {
  return {
    localeError: Eg()
  };
}
a(Qa, "default");

// versions/4.3.6/node_modules/zod/v4/locales/ota.js
var Zg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "harf", verb: "olmal\u0131d\u0131r" },
    file: { unit: "bayt", verb: "olmal\u0131d\u0131r" },
    array: { unit: "unsur", verb: "olmal\u0131d\u0131r" },
    set: { unit: "unsur", verb: "olmal\u0131d\u0131r" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "giren",
    email: "epostag\xE2h",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO heng\xE2m\u0131",
    date: "ISO tarihi",
    time: "ISO zaman\u0131",
    duration: "ISO m\xFCddeti",
    ipv4: "IPv4 ni\u015F\xE2n\u0131",
    ipv6: "IPv6 ni\u015F\xE2n\u0131",
    cidrv4: "IPv4 menzili",
    cidrv6: "IPv6 menzili",
    base64: "base64-\u015Fifreli metin",
    base64url: "base64url-\u015Fifreli metin",
    json_string: "JSON metin",
    e164: "E.164 say\u0131s\u0131",
    jwt: "JWT",
    template_literal: "giren"
  }, o = {
    nan: "NaN",
    number: "numara",
    array: "saf",
    null: "gayb"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = y(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `F\xE2sit giren: umulan instanceof ${r.expected}, al\u0131nan ${c}` : `F\xE2sit giren: umulan ${i}, al\u0131nan ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `F\xE2sit giren: umulan ${v(r.values[0])}` : `F\xE2sit tercih: m\xFBteberler ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `Fazla b\xFCy\xFCk: ${r.origin ?? "value"}, ${i}${r.maximum.toString()} ${s.unit ?? "elements"} sahip olmal\u0131yd\u0131.` : `Fazla b\xFCy\xFCk: ${r.origin ?? "value"}, ${i}${r.maximum.toString()} olmal\u0131yd\u0131.`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `Fazla k\xFC\xE7\xFCk: ${r.origin}, ${i}${r.minimum.toString()} ${s.unit} sahip olmal\u0131yd\u0131.` : `Fazla k\xFC\xE7\xFCk: ${r.origin}, ${i}${r.minimum.toString()} olmal\u0131yd\u0131.`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `F\xE2sit metin: "${i.prefix}" ile ba\u015Flamal\u0131.` : i.format === "ends_with" ? `F\xE2sit metin: "${i.suffix}" ile bitmeli.` : i.format === "includes" ? `F\xE2sit metin: "${i.includes}" ihtiv\xE2 etmeli.` : i.format === "regex" ? `F\xE2sit metin: ${i.pattern} nak\u015F\u0131na uymal\u0131.` : `F\xE2sit ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `F\xE2sit say\u0131: ${r.divisor} kat\u0131 olmal\u0131yd\u0131.`;
      case "unrecognized_keys":
        return `Tan\u0131nmayan anahtar ${r.keys.length > 1 ? "s" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `${r.origin} i\xE7in tan\u0131nmayan anahtar var.`;
      case "invalid_union":
        return "Giren tan\u0131namad\u0131.";
      case "invalid_element":
        return `${r.origin} i\xE7in tan\u0131nmayan k\u0131ymet var.`;
      default:
        return "K\u0131ymet tan\u0131namad\u0131.";
    }
  };
}, "error");
function Ya() {
  return {
    localeError: Zg()
  };
}
a(Ya, "default");

// versions/4.3.6/node_modules/zod/v4/locales/ps.js
var Ng = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "\u062A\u0648\u06A9\u064A", verb: "\u0648\u0644\u0631\u064A" },
    file: { unit: "\u0628\u0627\u06CC\u067C\u0633", verb: "\u0648\u0644\u0631\u064A" },
    array: { unit: "\u062A\u0648\u06A9\u064A", verb: "\u0648\u0644\u0631\u064A" },
    set: { unit: "\u062A\u0648\u06A9\u064A", verb: "\u0648\u0644\u0631\u064A" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "\u0648\u0631\u0648\u062F\u064A",
    email: "\u0628\u0631\u06CC\u069A\u0646\u0627\u0644\u06CC\u06A9",
    url: "\u06CC\u0648 \u0622\u0631 \u0627\u0644",
    emoji: "\u0627\u06CC\u0645\u0648\u062C\u064A",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u0646\u06CC\u067C\u0647 \u0627\u0648 \u0648\u062E\u062A",
    date: "\u0646\u06D0\u067C\u0647",
    time: "\u0648\u062E\u062A",
    duration: "\u0645\u0648\u062F\u0647",
    ipv4: "\u062F IPv4 \u067E\u062A\u0647",
    ipv6: "\u062F IPv6 \u067E\u062A\u0647",
    cidrv4: "\u062F IPv4 \u0633\u0627\u062D\u0647",
    cidrv6: "\u062F IPv6 \u0633\u0627\u062D\u0647",
    base64: "base64-encoded \u0645\u062A\u0646",
    base64url: "base64url-encoded \u0645\u062A\u0646",
    json_string: "JSON \u0645\u062A\u0646",
    e164: "\u062F E.164 \u0634\u0645\u06D0\u0631\u0647",
    jwt: "JWT",
    template_literal: "\u0648\u0631\u0648\u062F\u064A"
  }, o = {
    nan: "NaN",
    number: "\u0639\u062F\u062F",
    array: "\u0627\u0631\u06D0"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = y(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `\u0646\u0627\u0633\u0645 \u0648\u0631\u0648\u062F\u064A: \u0628\u0627\u06CC\u062F instanceof ${r.expected} \u0648\u0627\u06CC, \u0645\u06AB\u0631 ${c} \u062A\u0631\u0644\u0627\u0633\u0647 \u0634\u0648` : `\u0646\u0627\u0633\u0645 \u0648\u0631\u0648\u062F\u064A: \u0628\u0627\u06CC\u062F ${i} \u0648\u0627\u06CC, \u0645\u06AB\u0631 ${c} \u062A\u0631\u0644\u0627\u0633\u0647 \u0634\u0648`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u0646\u0627\u0633\u0645 \u0648\u0631\u0648\u062F\u064A: \u0628\u0627\u06CC\u062F ${v(r.values[0])} \u0648\u0627\u06CC` : `\u0646\u0627\u0633\u0645 \u0627\u0646\u062A\u062E\u0627\u0628: \u0628\u0627\u06CC\u062F \u06CC\u0648 \u0644\u0647 ${p(r.values, "|")} \u0685\u062E\u0647 \u0648\u0627\u06CC`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `\u0689\u06CC\u0631 \u0644\u0648\u06CC: ${r.origin ?? "\u0627\u0631\u0632\u069A\u062A"} \u0628\u0627\u06CC\u062F ${i}${r.maximum.toString()} ${s.unit ?? "\u0639\u0646\u0635\u0631\u0648\u0646\u0647"} \u0648\u0644\u0631\u064A` : `\u0689\u06CC\u0631 \u0644\u0648\u06CC: ${r.origin ?? "\u0627\u0631\u0632\u069A\u062A"} \u0628\u0627\u06CC\u062F ${i}${r.maximum.toString()} \u0648\u064A`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `\u0689\u06CC\u0631 \u06A9\u0648\u0686\u0646\u06CC: ${r.origin} \u0628\u0627\u06CC\u062F ${i}${r.minimum.toString()} ${s.unit} \u0648\u0644\u0631\u064A` : `\u0689\u06CC\u0631 \u06A9\u0648\u0686\u0646\u06CC: ${r.origin} \u0628\u0627\u06CC\u062F ${i}${r.minimum.toString()} \u0648\u064A`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u0646\u0627\u0633\u0645 \u0645\u062A\u0646: \u0628\u0627\u06CC\u062F \u062F "${i.prefix}" \u0633\u0631\u0647 \u067E\u06CC\u0644 \u0634\u064A` : i.format === "ends_with" ? `\u0646\u0627\u0633\u0645 \u0645\u062A\u0646: \u0628\u0627\u06CC\u062F \u062F "${i.suffix}" \u0633\u0631\u0647 \u067E\u0627\u06CC \u062A\u0647 \u0648\u0631\u0633\u064A\u0696\u064A` : i.format === "includes" ? `\u0646\u0627\u0633\u0645 \u0645\u062A\u0646: \u0628\u0627\u06CC\u062F "${i.includes}" \u0648\u0644\u0631\u064A` : i.format === "regex" ? `\u0646\u0627\u0633\u0645 \u0645\u062A\u0646: \u0628\u0627\u06CC\u062F \u062F ${i.pattern} \u0633\u0631\u0647 \u0645\u0637\u0627\u0628\u0642\u062A \u0648\u0644\u0631\u064A` : `${n[i.format] ?? r.format} \u0646\u0627\u0633\u0645 \u062F\u06CC`;
      }
      case "not_multiple_of":
        return `\u0646\u0627\u0633\u0645 \u0639\u062F\u062F: \u0628\u0627\u06CC\u062F \u062F ${r.divisor} \u0645\u0636\u0631\u0628 \u0648\u064A`;
      case "unrecognized_keys":
        return `\u0646\u0627\u0633\u0645 ${r.keys.length > 1 ? "\u06A9\u0644\u06CC\u0689\u0648\u0646\u0647" : "\u06A9\u0644\u06CC\u0689"}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `\u0646\u0627\u0633\u0645 \u06A9\u0644\u06CC\u0689 \u067E\u0647 ${r.origin} \u06A9\u06D0`;
      case "invalid_union":
        return "\u0646\u0627\u0633\u0645\u0647 \u0648\u0631\u0648\u062F\u064A";
      case "invalid_element":
        return `\u0646\u0627\u0633\u0645 \u0639\u0646\u0635\u0631 \u067E\u0647 ${r.origin} \u06A9\u06D0`;
      default:
        return "\u0646\u0627\u0633\u0645\u0647 \u0648\u0631\u0648\u062F\u064A";
    }
  };
}, "error");
function es() {
  return {
    localeError: Ng()
  };
}
a(es, "default");

// versions/4.3.6/node_modules/zod/v4/locales/pl.js
var Ag = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "znak\xF3w", verb: "mie\u0107" },
    file: { unit: "bajt\xF3w", verb: "mie\u0107" },
    array: { unit: "element\xF3w", verb: "mie\u0107" },
    set: { unit: "element\xF3w", verb: "mie\u0107" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "wyra\u017Cenie",
    email: "adres email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "data i godzina w formacie ISO",
    date: "data w formacie ISO",
    time: "godzina w formacie ISO",
    duration: "czas trwania ISO",
    ipv4: "adres IPv4",
    ipv6: "adres IPv6",
    cidrv4: "zakres IPv4",
    cidrv6: "zakres IPv6",
    base64: "ci\u0105g znak\xF3w zakodowany w formacie base64",
    base64url: "ci\u0105g znak\xF3w zakodowany w formacie base64url",
    json_string: "ci\u0105g znak\xF3w w formacie JSON",
    e164: "liczba E.164",
    jwt: "JWT",
    template_literal: "wej\u015Bcie"
  }, o = {
    nan: "NaN",
    number: "liczba",
    array: "tablica"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = y(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Nieprawid\u0142owe dane wej\u015Bciowe: oczekiwano instanceof ${r.expected}, otrzymano ${c}` : `Nieprawid\u0142owe dane wej\u015Bciowe: oczekiwano ${i}, otrzymano ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Nieprawid\u0142owe dane wej\u015Bciowe: oczekiwano ${v(r.values[0])}` : `Nieprawid\u0142owa opcja: oczekiwano jednej z warto\u015Bci ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `Za du\u017Ca warto\u015B\u0107: oczekiwano, \u017Ce ${r.origin ?? "warto\u015B\u0107"} b\u0119dzie mie\u0107 ${i}${r.maximum.toString()} ${s.unit ?? "element\xF3w"}` : `Zbyt du\u017C(y/a/e): oczekiwano, \u017Ce ${r.origin ?? "warto\u015B\u0107"} b\u0119dzie wynosi\u0107 ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `Za ma\u0142a warto\u015B\u0107: oczekiwano, \u017Ce ${r.origin ?? "warto\u015B\u0107"} b\u0119dzie mie\u0107 ${i}${r.minimum.toString()} ${s.unit ?? "element\xF3w"}` : `Zbyt ma\u0142(y/a/e): oczekiwano, \u017Ce ${r.origin ?? "warto\u015B\u0107"} b\u0119dzie wynosi\u0107 ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Nieprawid\u0142owy ci\u0105g znak\xF3w: musi zaczyna\u0107 si\u0119 od "${i.prefix}"` : i.format === "ends_with" ? `Nieprawid\u0142owy ci\u0105g znak\xF3w: musi ko\u0144czy\u0107 si\u0119 na "${i.suffix}"` : i.format === "includes" ? `Nieprawid\u0142owy ci\u0105g znak\xF3w: musi zawiera\u0107 "${i.includes}"` : i.format === "regex" ? `Nieprawid\u0142owy ci\u0105g znak\xF3w: musi odpowiada\u0107 wzorcowi ${i.pattern}` : `Nieprawid\u0142ow(y/a/e) ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Nieprawid\u0142owa liczba: musi by\u0107 wielokrotno\u015Bci\u0105 ${r.divisor}`;
      case "unrecognized_keys":
        return `Nierozpoznane klucze${r.keys.length > 1 ? "s" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Nieprawid\u0142owy klucz w ${r.origin}`;
      case "invalid_union":
        return "Nieprawid\u0142owe dane wej\u015Bciowe";
      case "invalid_element":
        return `Nieprawid\u0142owa warto\u015B\u0107 w ${r.origin}`;
      default:
        return "Nieprawid\u0142owe dane wej\u015Bciowe";
    }
  };
}, "error");
function ts() {
  return {
    localeError: Ag()
  };
}
a(ts, "default");

// versions/4.3.6/node_modules/zod/v4/locales/pt.js
var Cg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "caracteres", verb: "ter" },
    file: { unit: "bytes", verb: "ter" },
    array: { unit: "itens", verb: "ter" },
    set: { unit: "itens", verb: "ter" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "padr\xE3o",
    email: "endere\xE7o de e-mail",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "data e hora ISO",
    date: "data ISO",
    time: "hora ISO",
    duration: "dura\xE7\xE3o ISO",
    ipv4: "endere\xE7o IPv4",
    ipv6: "endere\xE7o IPv6",
    cidrv4: "faixa de IPv4",
    cidrv6: "faixa de IPv6",
    base64: "texto codificado em base64",
    base64url: "URL codificada em base64",
    json_string: "texto JSON",
    e164: "n\xFAmero E.164",
    jwt: "JWT",
    template_literal: "entrada"
  }, o = {
    nan: "NaN",
    number: "n\xFAmero",
    null: "nulo"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = y(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Tipo inv\xE1lido: esperado instanceof ${r.expected}, recebido ${c}` : `Tipo inv\xE1lido: esperado ${i}, recebido ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Entrada inv\xE1lida: esperado ${v(r.values[0])}` : `Op\xE7\xE3o inv\xE1lida: esperada uma das ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `Muito grande: esperado que ${r.origin ?? "valor"} tivesse ${i}${r.maximum.toString()} ${s.unit ?? "elementos"}` : `Muito grande: esperado que ${r.origin ?? "valor"} fosse ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `Muito pequeno: esperado que ${r.origin} tivesse ${i}${r.minimum.toString()} ${s.unit}` : `Muito pequeno: esperado que ${r.origin} fosse ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Texto inv\xE1lido: deve come\xE7ar com "${i.prefix}"` : i.format === "ends_with" ? `Texto inv\xE1lido: deve terminar com "${i.suffix}"` : i.format === "includes" ? `Texto inv\xE1lido: deve incluir "${i.includes}"` : i.format === "regex" ? `Texto inv\xE1lido: deve corresponder ao padr\xE3o ${i.pattern}` : `${n[i.format] ?? r.format} inv\xE1lido`;
      }
      case "not_multiple_of":
        return `N\xFAmero inv\xE1lido: deve ser m\xFAltiplo de ${r.divisor}`;
      case "unrecognized_keys":
        return `Chave${r.keys.length > 1 ? "s" : ""} desconhecida${r.keys.length > 1 ? "s" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Chave inv\xE1lida em ${r.origin}`;
      case "invalid_union":
        return "Entrada inv\xE1lida";
      case "invalid_element":
        return `Valor inv\xE1lido em ${r.origin}`;
      default:
        return "Campo inv\xE1lido";
    }
  };
}, "error");
function rs() {
  return {
    localeError: Cg()
  };
}
a(rs, "default");

// versions/4.3.6/node_modules/zod/v4/locales/ru.js
function Jl(e, t, n, o) {
  let r = Math.abs(e), i = r % 10, s = r % 100;
  return s >= 11 && s <= 19 ? o : i === 1 ? t : i >= 2 && i <= 4 ? n : o;
}
a(Jl, "getRussianPlural");
var Rg = /* @__PURE__ */ a(() => {
  let e = {
    string: {
      unit: {
        one: "\u0441\u0438\u043C\u0432\u043E\u043B",
        few: "\u0441\u0438\u043C\u0432\u043E\u043B\u0430",
        many: "\u0441\u0438\u043C\u0432\u043E\u043B\u043E\u0432"
      },
      verb: "\u0438\u043C\u0435\u0442\u044C"
    },
    file: {
      unit: {
        one: "\u0431\u0430\u0439\u0442",
        few: "\u0431\u0430\u0439\u0442\u0430",
        many: "\u0431\u0430\u0439\u0442"
      },
      verb: "\u0438\u043C\u0435\u0442\u044C"
    },
    array: {
      unit: {
        one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
        few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430",
        many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u043E\u0432"
      },
      verb: "\u0438\u043C\u0435\u0442\u044C"
    },
    set: {
      unit: {
        one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
        few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430",
        many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u043E\u0432"
      },
      verb: "\u0438\u043C\u0435\u0442\u044C"
    }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "\u0432\u0432\u043E\u0434",
    email: "email \u0430\u0434\u0440\u0435\u0441",
    url: "URL",
    emoji: "\u044D\u043C\u043E\u0434\u0437\u0438",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0434\u0430\u0442\u0430 \u0438 \u0432\u0440\u0435\u043C\u044F",
    date: "ISO \u0434\u0430\u0442\u0430",
    time: "ISO \u0432\u0440\u0435\u043C\u044F",
    duration: "ISO \u0434\u043B\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C",
    ipv4: "IPv4 \u0430\u0434\u0440\u0435\u0441",
    ipv6: "IPv6 \u0430\u0434\u0440\u0435\u0441",
    cidrv4: "IPv4 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D",
    cidrv6: "IPv6 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D",
    base64: "\u0441\u0442\u0440\u043E\u043A\u0430 \u0432 \u0444\u043E\u0440\u043C\u0430\u0442\u0435 base64",
    base64url: "\u0441\u0442\u0440\u043E\u043A\u0430 \u0432 \u0444\u043E\u0440\u043C\u0430\u0442\u0435 base64url",
    json_string: "JSON \u0441\u0442\u0440\u043E\u043A\u0430",
    e164: "\u043D\u043E\u043C\u0435\u0440 E.164",
    jwt: "JWT",
    template_literal: "\u0432\u0432\u043E\u0434"
  }, o = {
    nan: "NaN",
    number: "\u0447\u0438\u0441\u043B\u043E",
    array: "\u043C\u0430\u0441\u0441\u0438\u0432"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = y(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0432\u0432\u043E\u0434: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C instanceof ${r.expected}, \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u043E ${c}` : `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0432\u0432\u043E\u0434: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C ${i}, \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u043E ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0432\u0432\u043E\u0434: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C ${v(r.values[0])}` : `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0432\u0430\u0440\u0438\u0430\u043D\u0442: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C \u043E\u0434\u043D\u043E \u0438\u0437 ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        if (s) {
          let c = Number(r.maximum), u = Jl(c, s.unit.one, s.unit.few, s.unit.many);
          return `\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C, \u0447\u0442\u043E ${r.origin ?? "\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435"} \u0431\u0443\u0434\u0435\u0442 \u0438\u043C\u0435\u0442\u044C ${i}${r.maximum.toString()} ${u}`;
        }
        return `\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C, \u0447\u0442\u043E ${r.origin ?? "\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435"} \u0431\u0443\u0434\u0435\u0442 ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        if (s) {
          let c = Number(r.minimum), u = Jl(c, s.unit.one, s.unit.few, s.unit.many);
          return `\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u043C\u0430\u043B\u0435\u043D\u044C\u043A\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C, \u0447\u0442\u043E ${r.origin} \u0431\u0443\u0434\u0435\u0442 \u0438\u043C\u0435\u0442\u044C ${i}${r.minimum.toString()} ${u}`;
        }
        return `\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u043C\u0430\u043B\u0435\u043D\u044C\u043A\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C, \u0447\u0442\u043E ${r.origin} \u0431\u0443\u0434\u0435\u0442 ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u0441\u0442\u0440\u043E\u043A\u0430: \u0434\u043E\u043B\u0436\u043D\u0430 \u043D\u0430\u0447\u0438\u043D\u0430\u0442\u044C\u0441\u044F \u0441 "${i.prefix}"` : i.format === "ends_with" ? `\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u0441\u0442\u0440\u043E\u043A\u0430: \u0434\u043E\u043B\u0436\u043D\u0430 \u0437\u0430\u043A\u0430\u043D\u0447\u0438\u0432\u0430\u0442\u044C\u0441\u044F \u043D\u0430 "${i.suffix}"` : i.format === "includes" ? `\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u0441\u0442\u0440\u043E\u043A\u0430: \u0434\u043E\u043B\u0436\u043D\u0430 \u0441\u043E\u0434\u0435\u0440\u0436\u0430\u0442\u044C "${i.includes}"` : i.format === "regex" ? `\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u0441\u0442\u0440\u043E\u043A\u0430: \u0434\u043E\u043B\u0436\u043D\u0430 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u043E\u0432\u0430\u0442\u044C \u0448\u0430\u0431\u043B\u043E\u043D\u0443 ${i.pattern}` : `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u041D\u0435\u0432\u0435\u0440\u043D\u043E\u0435 \u0447\u0438\u0441\u043B\u043E: \u0434\u043E\u043B\u0436\u043D\u043E \u0431\u044B\u0442\u044C \u043A\u0440\u0430\u0442\u043D\u044B\u043C ${r.divisor}`;
      case "unrecognized_keys":
        return `\u041D\u0435\u0440\u0430\u0441\u043F\u043E\u0437\u043D\u0430\u043D\u043D${r.keys.length > 1 ? "\u044B\u0435" : "\u044B\u0439"} \u043A\u043B\u044E\u0447${r.keys.length > 1 ? "\u0438" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u043A\u043B\u044E\u0447 \u0432 ${r.origin}`;
      case "invalid_union":
        return "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0435 \u0432\u0445\u043E\u0434\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435";
      case "invalid_element":
        return `\u041D\u0435\u0432\u0435\u0440\u043D\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u0432 ${r.origin}`;
      default:
        return "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0435 \u0432\u0445\u043E\u0434\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435";
    }
  };
}, "error");
function ns() {
  return {
    localeError: Rg()
  };
}
a(ns, "default");

// versions/4.3.6/node_modules/zod/v4/locales/sl.js
var Fg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "znakov", verb: "imeti" },
    file: { unit: "bajtov", verb: "imeti" },
    array: { unit: "elementov", verb: "imeti" },
    set: { unit: "elementov", verb: "imeti" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "vnos",
    email: "e-po\u0161tni naslov",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datum in \u010Das",
    date: "ISO datum",
    time: "ISO \u010Das",
    duration: "ISO trajanje",
    ipv4: "IPv4 naslov",
    ipv6: "IPv6 naslov",
    cidrv4: "obseg IPv4",
    cidrv6: "obseg IPv6",
    base64: "base64 kodiran niz",
    base64url: "base64url kodiran niz",
    json_string: "JSON niz",
    e164: "E.164 \u0161tevilka",
    jwt: "JWT",
    template_literal: "vnos"
  }, o = {
    nan: "NaN",
    number: "\u0161tevilo",
    array: "tabela"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = y(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Neveljaven vnos: pri\u010Dakovano instanceof ${r.expected}, prejeto ${c}` : `Neveljaven vnos: pri\u010Dakovano ${i}, prejeto ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Neveljaven vnos: pri\u010Dakovano ${v(r.values[0])}` : `Neveljavna mo\u017Enost: pri\u010Dakovano eno izmed ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `Preveliko: pri\u010Dakovano, da bo ${r.origin ?? "vrednost"} imelo ${i}${r.maximum.toString()} ${s.unit ?? "elementov"}` : `Preveliko: pri\u010Dakovano, da bo ${r.origin ?? "vrednost"} ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `Premajhno: pri\u010Dakovano, da bo ${r.origin} imelo ${i}${r.minimum.toString()} ${s.unit}` : `Premajhno: pri\u010Dakovano, da bo ${r.origin} ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Neveljaven niz: mora se za\u010Deti z "${i.prefix}"` : i.format === "ends_with" ? `Neveljaven niz: mora se kon\u010Dati z "${i.suffix}"` : i.format === "includes" ? `Neveljaven niz: mora vsebovati "${i.includes}"` : i.format === "regex" ? `Neveljaven niz: mora ustrezati vzorcu ${i.pattern}` : `Neveljaven ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Neveljavno \u0161tevilo: mora biti ve\u010Dkratnik ${r.divisor}`;
      case "unrecognized_keys":
        return `Neprepoznan${r.keys.length > 1 ? "i klju\u010Di" : " klju\u010D"}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Neveljaven klju\u010D v ${r.origin}`;
      case "invalid_union":
        return "Neveljaven vnos";
      case "invalid_element":
        return `Neveljavna vrednost v ${r.origin}`;
      default:
        return "Neveljaven vnos";
    }
  };
}, "error");
function is() {
  return {
    localeError: Fg()
  };
}
a(is, "default");

// versions/4.3.6/node_modules/zod/v4/locales/sv.js
var Mg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "tecken", verb: "att ha" },
    file: { unit: "bytes", verb: "att ha" },
    array: { unit: "objekt", verb: "att inneh\xE5lla" },
    set: { unit: "objekt", verb: "att inneh\xE5lla" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "regulj\xE4rt uttryck",
    email: "e-postadress",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO-datum och tid",
    date: "ISO-datum",
    time: "ISO-tid",
    duration: "ISO-varaktighet",
    ipv4: "IPv4-intervall",
    ipv6: "IPv6-intervall",
    cidrv4: "IPv4-spektrum",
    cidrv6: "IPv6-spektrum",
    base64: "base64-kodad str\xE4ng",
    base64url: "base64url-kodad str\xE4ng",
    json_string: "JSON-str\xE4ng",
    e164: "E.164-nummer",
    jwt: "JWT",
    template_literal: "mall-literal"
  }, o = {
    nan: "NaN",
    number: "antal",
    array: "lista"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = y(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Ogiltig inmatning: f\xF6rv\xE4ntat instanceof ${r.expected}, fick ${c}` : `Ogiltig inmatning: f\xF6rv\xE4ntat ${i}, fick ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Ogiltig inmatning: f\xF6rv\xE4ntat ${v(r.values[0])}` : `Ogiltigt val: f\xF6rv\xE4ntade en av ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `F\xF6r stor(t): f\xF6rv\xE4ntade ${r.origin ?? "v\xE4rdet"} att ha ${i}${r.maximum.toString()} ${s.unit ?? "element"}` : `F\xF6r stor(t): f\xF6rv\xE4ntat ${r.origin ?? "v\xE4rdet"} att ha ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `F\xF6r lite(t): f\xF6rv\xE4ntade ${r.origin ?? "v\xE4rdet"} att ha ${i}${r.minimum.toString()} ${s.unit}` : `F\xF6r lite(t): f\xF6rv\xE4ntade ${r.origin ?? "v\xE4rdet"} att ha ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Ogiltig str\xE4ng: m\xE5ste b\xF6rja med "${i.prefix}"` : i.format === "ends_with" ? `Ogiltig str\xE4ng: m\xE5ste sluta med "${i.suffix}"` : i.format === "includes" ? `Ogiltig str\xE4ng: m\xE5ste inneh\xE5lla "${i.includes}"` : i.format === "regex" ? `Ogiltig str\xE4ng: m\xE5ste matcha m\xF6nstret "${i.pattern}"` : `Ogiltig(t) ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Ogiltigt tal: m\xE5ste vara en multipel av ${r.divisor}`;
      case "unrecognized_keys":
        return `${r.keys.length > 1 ? "Ok\xE4nda nycklar" : "Ok\xE4nd nyckel"}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Ogiltig nyckel i ${r.origin ?? "v\xE4rdet"}`;
      case "invalid_union":
        return "Ogiltig input";
      case "invalid_element":
        return `Ogiltigt v\xE4rde i ${r.origin ?? "v\xE4rdet"}`;
      default:
        return "Ogiltig input";
    }
  };
}, "error");
function os() {
  return {
    localeError: Mg()
  };
}
a(os, "default");

// versions/4.3.6/node_modules/zod/v4/locales/ta.js
var Lg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "\u0B8E\u0BB4\u0BC1\u0BA4\u0BCD\u0BA4\u0BC1\u0B95\u0BCD\u0B95\u0BB3\u0BCD", verb: "\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD" },
    file: { unit: "\u0BAA\u0BC8\u0B9F\u0BCD\u0B9F\u0BC1\u0B95\u0BB3\u0BCD", verb: "\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD" },
    array: { unit: "\u0B89\u0BB1\u0BC1\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD", verb: "\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD" },
    set: { unit: "\u0B89\u0BB1\u0BC1\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD", verb: "\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "\u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1",
    email: "\u0BAE\u0BBF\u0BA9\u0BCD\u0BA9\u0B9E\u0BCD\u0B9A\u0BB2\u0BCD \u0BAE\u0BC1\u0B95\u0BB5\u0BB0\u0BBF",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0BA4\u0BC7\u0BA4\u0BBF \u0BA8\u0BC7\u0BB0\u0BAE\u0BCD",
    date: "ISO \u0BA4\u0BC7\u0BA4\u0BBF",
    time: "ISO \u0BA8\u0BC7\u0BB0\u0BAE\u0BCD",
    duration: "ISO \u0B95\u0BBE\u0BB2 \u0B85\u0BB3\u0BB5\u0BC1",
    ipv4: "IPv4 \u0BAE\u0BC1\u0B95\u0BB5\u0BB0\u0BBF",
    ipv6: "IPv6 \u0BAE\u0BC1\u0B95\u0BB5\u0BB0\u0BBF",
    cidrv4: "IPv4 \u0BB5\u0BB0\u0BAE\u0BCD\u0BAA\u0BC1",
    cidrv6: "IPv6 \u0BB5\u0BB0\u0BAE\u0BCD\u0BAA\u0BC1",
    base64: "base64-encoded \u0B9A\u0BB0\u0BAE\u0BCD",
    base64url: "base64url-encoded \u0B9A\u0BB0\u0BAE\u0BCD",
    json_string: "JSON \u0B9A\u0BB0\u0BAE\u0BCD",
    e164: "E.164 \u0B8E\u0BA3\u0BCD",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN",
    number: "\u0B8E\u0BA3\u0BCD",
    array: "\u0B85\u0BA3\u0BBF",
    null: "\u0BB5\u0BC6\u0BB1\u0BC1\u0BAE\u0BC8"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = y(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 instanceof ${r.expected}, \u0BAA\u0BC6\u0BB1\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${c}` : `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${i}, \u0BAA\u0BC6\u0BB1\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${v(r.values[0])}` : `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0BB5\u0BBF\u0BB0\u0BC1\u0BAA\u0BCD\u0BAA\u0BAE\u0BCD: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${p(r.values, "|")} \u0B87\u0BB2\u0BCD \u0B92\u0BA9\u0BCD\u0BB1\u0BC1`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `\u0BAE\u0BBF\u0B95 \u0BAA\u0BC6\u0BB0\u0BBF\u0BAF\u0BA4\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${r.origin ?? "\u0BAE\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1"} ${i}${r.maximum.toString()} ${s.unit ?? "\u0B89\u0BB1\u0BC1\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD"} \u0B86\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : `\u0BAE\u0BBF\u0B95 \u0BAA\u0BC6\u0BB0\u0BBF\u0BAF\u0BA4\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${r.origin ?? "\u0BAE\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1"} ${i}${r.maximum.toString()} \u0B86\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `\u0BAE\u0BBF\u0B95\u0B9A\u0BCD \u0B9A\u0BBF\u0BB1\u0BBF\u0BAF\u0BA4\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${r.origin} ${i}${r.minimum.toString()} ${s.unit} \u0B86\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : `\u0BAE\u0BBF\u0B95\u0B9A\u0BCD \u0B9A\u0BBF\u0BB1\u0BBF\u0BAF\u0BA4\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${r.origin} ${i}${r.minimum.toString()} \u0B86\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B9A\u0BB0\u0BAE\u0BCD: "${i.prefix}" \u0B87\u0BB2\u0BCD \u0BA4\u0BCA\u0B9F\u0B99\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : i.format === "ends_with" ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B9A\u0BB0\u0BAE\u0BCD: "${i.suffix}" \u0B87\u0BB2\u0BCD \u0BAE\u0BC1\u0B9F\u0BBF\u0BB5\u0B9F\u0BC8\u0BAF \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : i.format === "includes" ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B9A\u0BB0\u0BAE\u0BCD: "${i.includes}" \u0B90 \u0B89\u0BB3\u0BCD\u0BB3\u0B9F\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : i.format === "regex" ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B9A\u0BB0\u0BAE\u0BCD: ${i.pattern} \u0BAE\u0BC1\u0BB1\u0BC8\u0BAA\u0BBE\u0B9F\u0BCD\u0B9F\u0BC1\u0B9F\u0BA9\u0BCD \u0BAA\u0BCA\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B8E\u0BA3\u0BCD: ${r.divisor} \u0B87\u0BA9\u0BCD \u0BAA\u0BB2\u0BAE\u0BBE\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD`;
      case "unrecognized_keys":
        return `\u0B85\u0B9F\u0BC8\u0BAF\u0BBE\u0BB3\u0BAE\u0BCD \u0BA4\u0BC6\u0BB0\u0BBF\u0BAF\u0BBE\u0BA4 \u0BB5\u0BBF\u0B9A\u0BC8${r.keys.length > 1 ? "\u0B95\u0BB3\u0BCD" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `${r.origin} \u0B87\u0BB2\u0BCD \u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0BB5\u0BBF\u0B9A\u0BC8`;
      case "invalid_union":
        return "\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1";
      case "invalid_element":
        return `${r.origin} \u0B87\u0BB2\u0BCD \u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0BAE\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1`;
      default:
        return "\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1";
    }
  };
}, "error");
function as() {
  return {
    localeError: Lg()
  };
}
a(as, "default");

// versions/4.3.6/node_modules/zod/v4/locales/th.js
var Bg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "\u0E15\u0E31\u0E27\u0E2D\u0E31\u0E01\u0E29\u0E23", verb: "\u0E04\u0E27\u0E23\u0E21\u0E35" },
    file: { unit: "\u0E44\u0E1A\u0E15\u0E4C", verb: "\u0E04\u0E27\u0E23\u0E21\u0E35" },
    array: { unit: "\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23", verb: "\u0E04\u0E27\u0E23\u0E21\u0E35" },
    set: { unit: "\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23", verb: "\u0E04\u0E27\u0E23\u0E21\u0E35" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E17\u0E35\u0E48\u0E1B\u0E49\u0E2D\u0E19",
    email: "\u0E17\u0E35\u0E48\u0E2D\u0E22\u0E39\u0E48\u0E2D\u0E35\u0E40\u0E21\u0E25",
    url: "URL",
    emoji: "\u0E2D\u0E34\u0E42\u0E21\u0E08\u0E34",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48\u0E40\u0E27\u0E25\u0E32\u0E41\u0E1A\u0E1A ISO",
    date: "\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48\u0E41\u0E1A\u0E1A ISO",
    time: "\u0E40\u0E27\u0E25\u0E32\u0E41\u0E1A\u0E1A ISO",
    duration: "\u0E0A\u0E48\u0E27\u0E07\u0E40\u0E27\u0E25\u0E32\u0E41\u0E1A\u0E1A ISO",
    ipv4: "\u0E17\u0E35\u0E48\u0E2D\u0E22\u0E39\u0E48 IPv4",
    ipv6: "\u0E17\u0E35\u0E48\u0E2D\u0E22\u0E39\u0E48 IPv6",
    cidrv4: "\u0E0A\u0E48\u0E27\u0E07 IP \u0E41\u0E1A\u0E1A IPv4",
    cidrv6: "\u0E0A\u0E48\u0E27\u0E07 IP \u0E41\u0E1A\u0E1A IPv6",
    base64: "\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E41\u0E1A\u0E1A Base64",
    base64url: "\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E41\u0E1A\u0E1A Base64 \u0E2A\u0E33\u0E2B\u0E23\u0E31\u0E1A URL",
    json_string: "\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E41\u0E1A\u0E1A JSON",
    e164: "\u0E40\u0E1A\u0E2D\u0E23\u0E4C\u0E42\u0E17\u0E23\u0E28\u0E31\u0E1E\u0E17\u0E4C\u0E23\u0E30\u0E2B\u0E27\u0E48\u0E32\u0E07\u0E1B\u0E23\u0E30\u0E40\u0E17\u0E28 (E.164)",
    jwt: "\u0E42\u0E17\u0E40\u0E04\u0E19 JWT",
    template_literal: "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E17\u0E35\u0E48\u0E1B\u0E49\u0E2D\u0E19"
  }, o = {
    nan: "NaN",
    number: "\u0E15\u0E31\u0E27\u0E40\u0E25\u0E02",
    array: "\u0E2D\u0E32\u0E23\u0E4C\u0E40\u0E23\u0E22\u0E4C (Array)",
    null: "\u0E44\u0E21\u0E48\u0E21\u0E35\u0E04\u0E48\u0E32 (null)"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = y(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `\u0E1B\u0E23\u0E30\u0E40\u0E20\u0E17\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E04\u0E27\u0E23\u0E40\u0E1B\u0E47\u0E19 instanceof ${r.expected} \u0E41\u0E15\u0E48\u0E44\u0E14\u0E49\u0E23\u0E31\u0E1A ${c}` : `\u0E1B\u0E23\u0E30\u0E40\u0E20\u0E17\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E04\u0E27\u0E23\u0E40\u0E1B\u0E47\u0E19 ${i} \u0E41\u0E15\u0E48\u0E44\u0E14\u0E49\u0E23\u0E31\u0E1A ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u0E04\u0E48\u0E32\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E04\u0E27\u0E23\u0E40\u0E1B\u0E47\u0E19 ${v(r.values[0])}` : `\u0E15\u0E31\u0E27\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E04\u0E27\u0E23\u0E40\u0E1B\u0E47\u0E19\u0E2B\u0E19\u0E36\u0E48\u0E07\u0E43\u0E19 ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "\u0E44\u0E21\u0E48\u0E40\u0E01\u0E34\u0E19" : "\u0E19\u0E49\u0E2D\u0E22\u0E01\u0E27\u0E48\u0E32", s = t(r.origin);
        return s ? `\u0E40\u0E01\u0E34\u0E19\u0E01\u0E33\u0E2B\u0E19\u0E14: ${r.origin ?? "\u0E04\u0E48\u0E32"} \u0E04\u0E27\u0E23\u0E21\u0E35${i} ${r.maximum.toString()} ${s.unit ?? "\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23"}` : `\u0E40\u0E01\u0E34\u0E19\u0E01\u0E33\u0E2B\u0E19\u0E14: ${r.origin ?? "\u0E04\u0E48\u0E32"} \u0E04\u0E27\u0E23\u0E21\u0E35${i} ${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? "\u0E2D\u0E22\u0E48\u0E32\u0E07\u0E19\u0E49\u0E2D\u0E22" : "\u0E21\u0E32\u0E01\u0E01\u0E27\u0E48\u0E32", s = t(r.origin);
        return s ? `\u0E19\u0E49\u0E2D\u0E22\u0E01\u0E27\u0E48\u0E32\u0E01\u0E33\u0E2B\u0E19\u0E14: ${r.origin} \u0E04\u0E27\u0E23\u0E21\u0E35${i} ${r.minimum.toString()} ${s.unit}` : `\u0E19\u0E49\u0E2D\u0E22\u0E01\u0E27\u0E48\u0E32\u0E01\u0E33\u0E2B\u0E19\u0E14: ${r.origin} \u0E04\u0E27\u0E23\u0E21\u0E35${i} ${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E15\u0E49\u0E2D\u0E07\u0E02\u0E36\u0E49\u0E19\u0E15\u0E49\u0E19\u0E14\u0E49\u0E27\u0E22 "${i.prefix}"` : i.format === "ends_with" ? `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E15\u0E49\u0E2D\u0E07\u0E25\u0E07\u0E17\u0E49\u0E32\u0E22\u0E14\u0E49\u0E27\u0E22 "${i.suffix}"` : i.format === "includes" ? `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E15\u0E49\u0E2D\u0E07\u0E21\u0E35 "${i.includes}" \u0E2D\u0E22\u0E39\u0E48\u0E43\u0E19\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21` : i.format === "regex" ? `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E15\u0E49\u0E2D\u0E07\u0E15\u0E23\u0E07\u0E01\u0E31\u0E1A\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E17\u0E35\u0E48\u0E01\u0E33\u0E2B\u0E19\u0E14 ${i.pattern}` : `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u0E15\u0E31\u0E27\u0E40\u0E25\u0E02\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E15\u0E49\u0E2D\u0E07\u0E40\u0E1B\u0E47\u0E19\u0E08\u0E33\u0E19\u0E27\u0E19\u0E17\u0E35\u0E48\u0E2B\u0E32\u0E23\u0E14\u0E49\u0E27\u0E22 ${r.divisor} \u0E44\u0E14\u0E49\u0E25\u0E07\u0E15\u0E31\u0E27`;
      case "unrecognized_keys":
        return `\u0E1E\u0E1A\u0E04\u0E35\u0E22\u0E4C\u0E17\u0E35\u0E48\u0E44\u0E21\u0E48\u0E23\u0E39\u0E49\u0E08\u0E31\u0E01: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `\u0E04\u0E35\u0E22\u0E4C\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07\u0E43\u0E19 ${r.origin}`;
      case "invalid_union":
        return "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E44\u0E21\u0E48\u0E15\u0E23\u0E07\u0E01\u0E31\u0E1A\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E22\u0E39\u0E40\u0E19\u0E35\u0E22\u0E19\u0E17\u0E35\u0E48\u0E01\u0E33\u0E2B\u0E19\u0E14\u0E44\u0E27\u0E49";
      case "invalid_element":
        return `\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07\u0E43\u0E19 ${r.origin}`;
      default:
        return "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07";
    }
  };
}, "error");
function ss() {
  return {
    localeError: Bg()
  };
}
a(ss, "default");

// versions/4.3.6/node_modules/zod/v4/locales/tr.js
var Vg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "karakter", verb: "olmal\u0131" },
    file: { unit: "bayt", verb: "olmal\u0131" },
    array: { unit: "\xF6\u011Fe", verb: "olmal\u0131" },
    set: { unit: "\xF6\u011Fe", verb: "olmal\u0131" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "girdi",
    email: "e-posta adresi",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO tarih ve saat",
    date: "ISO tarih",
    time: "ISO saat",
    duration: "ISO s\xFCre",
    ipv4: "IPv4 adresi",
    ipv6: "IPv6 adresi",
    cidrv4: "IPv4 aral\u0131\u011F\u0131",
    cidrv6: "IPv6 aral\u0131\u011F\u0131",
    base64: "base64 ile \u015Fifrelenmi\u015F metin",
    base64url: "base64url ile \u015Fifrelenmi\u015F metin",
    json_string: "JSON dizesi",
    e164: "E.164 say\u0131s\u0131",
    jwt: "JWT",
    template_literal: "\u015Eablon dizesi"
  }, o = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = y(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Ge\xE7ersiz de\u011Fer: beklenen instanceof ${r.expected}, al\u0131nan ${c}` : `Ge\xE7ersiz de\u011Fer: beklenen ${i}, al\u0131nan ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Ge\xE7ersiz de\u011Fer: beklenen ${v(r.values[0])}` : `Ge\xE7ersiz se\xE7enek: a\u015Fa\u011F\u0131dakilerden biri olmal\u0131: ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `\xC7ok b\xFCy\xFCk: beklenen ${r.origin ?? "de\u011Fer"} ${i}${r.maximum.toString()} ${s.unit ?? "\xF6\u011Fe"}` : `\xC7ok b\xFCy\xFCk: beklenen ${r.origin ?? "de\u011Fer"} ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `\xC7ok k\xFC\xE7\xFCk: beklenen ${r.origin} ${i}${r.minimum.toString()} ${s.unit}` : `\xC7ok k\xFC\xE7\xFCk: beklenen ${r.origin} ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Ge\xE7ersiz metin: "${i.prefix}" ile ba\u015Flamal\u0131` : i.format === "ends_with" ? `Ge\xE7ersiz metin: "${i.suffix}" ile bitmeli` : i.format === "includes" ? `Ge\xE7ersiz metin: "${i.includes}" i\xE7ermeli` : i.format === "regex" ? `Ge\xE7ersiz metin: ${i.pattern} desenine uymal\u0131` : `Ge\xE7ersiz ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Ge\xE7ersiz say\u0131: ${r.divisor} ile tam b\xF6l\xFCnebilmeli`;
      case "unrecognized_keys":
        return `Tan\u0131nmayan anahtar${r.keys.length > 1 ? "lar" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `${r.origin} i\xE7inde ge\xE7ersiz anahtar`;
      case "invalid_union":
        return "Ge\xE7ersiz de\u011Fer";
      case "invalid_element":
        return `${r.origin} i\xE7inde ge\xE7ersiz de\u011Fer`;
      default:
        return "Ge\xE7ersiz de\u011Fer";
    }
  };
}, "error");
function cs() {
  return {
    localeError: Vg()
  };
}
a(cs, "default");

// versions/4.3.6/node_modules/zod/v4/locales/uk.js
var qg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "\u0441\u0438\u043C\u0432\u043E\u043B\u0456\u0432", verb: "\u043C\u0430\u0442\u0438\u043C\u0435" },
    file: { unit: "\u0431\u0430\u0439\u0442\u0456\u0432", verb: "\u043C\u0430\u0442\u0438\u043C\u0435" },
    array: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0456\u0432", verb: "\u043C\u0430\u0442\u0438\u043C\u0435" },
    set: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0456\u0432", verb: "\u043C\u0430\u0442\u0438\u043C\u0435" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "\u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456",
    email: "\u0430\u0434\u0440\u0435\u0441\u0430 \u0435\u043B\u0435\u043A\u0442\u0440\u043E\u043D\u043D\u043E\u0457 \u043F\u043E\u0448\u0442\u0438",
    url: "URL",
    emoji: "\u0435\u043C\u043E\u0434\u0437\u0456",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u0434\u0430\u0442\u0430 \u0442\u0430 \u0447\u0430\u0441 ISO",
    date: "\u0434\u0430\u0442\u0430 ISO",
    time: "\u0447\u0430\u0441 ISO",
    duration: "\u0442\u0440\u0438\u0432\u0430\u043B\u0456\u0441\u0442\u044C ISO",
    ipv4: "\u0430\u0434\u0440\u0435\u0441\u0430 IPv4",
    ipv6: "\u0430\u0434\u0440\u0435\u0441\u0430 IPv6",
    cidrv4: "\u0434\u0456\u0430\u043F\u0430\u0437\u043E\u043D IPv4",
    cidrv6: "\u0434\u0456\u0430\u043F\u0430\u0437\u043E\u043D IPv6",
    base64: "\u0440\u044F\u0434\u043E\u043A \u0443 \u043A\u043E\u0434\u0443\u0432\u0430\u043D\u043D\u0456 base64",
    base64url: "\u0440\u044F\u0434\u043E\u043A \u0443 \u043A\u043E\u0434\u0443\u0432\u0430\u043D\u043D\u0456 base64url",
    json_string: "\u0440\u044F\u0434\u043E\u043A JSON",
    e164: "\u043D\u043E\u043C\u0435\u0440 E.164",
    jwt: "JWT",
    template_literal: "\u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456"
  }, o = {
    nan: "NaN",
    number: "\u0447\u0438\u0441\u043B\u043E",
    array: "\u043C\u0430\u0441\u0438\u0432"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = y(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F instanceof ${r.expected}, \u043E\u0442\u0440\u0438\u043C\u0430\u043D\u043E ${c}` : `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F ${i}, \u043E\u0442\u0440\u0438\u043C\u0430\u043D\u043E ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F ${v(r.values[0])}` : `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0430 \u043E\u043F\u0446\u0456\u044F: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F \u043E\u0434\u043D\u0435 \u0437 ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `\u0417\u0430\u043D\u0430\u0434\u0442\u043E \u0432\u0435\u043B\u0438\u043A\u0435: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F, \u0449\u043E ${r.origin ?? "\u0437\u043D\u0430\u0447\u0435\u043D\u043D\u044F"} ${s.verb} ${i}${r.maximum.toString()} ${s.unit ?? "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0456\u0432"}` : `\u0417\u0430\u043D\u0430\u0434\u0442\u043E \u0432\u0435\u043B\u0438\u043A\u0435: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F, \u0449\u043E ${r.origin ?? "\u0437\u043D\u0430\u0447\u0435\u043D\u043D\u044F"} \u0431\u0443\u0434\u0435 ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `\u0417\u0430\u043D\u0430\u0434\u0442\u043E \u043C\u0430\u043B\u0435: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F, \u0449\u043E ${r.origin} ${s.verb} ${i}${r.minimum.toString()} ${s.unit}` : `\u0417\u0430\u043D\u0430\u0434\u0442\u043E \u043C\u0430\u043B\u0435: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F, \u0449\u043E ${r.origin} \u0431\u0443\u0434\u0435 ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u0440\u044F\u0434\u043E\u043A: \u043F\u043E\u0432\u0438\u043D\u0435\u043D \u043F\u043E\u0447\u0438\u043D\u0430\u0442\u0438\u0441\u044F \u0437 "${i.prefix}"` : i.format === "ends_with" ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u0440\u044F\u0434\u043E\u043A: \u043F\u043E\u0432\u0438\u043D\u0435\u043D \u0437\u0430\u043A\u0456\u043D\u0447\u0443\u0432\u0430\u0442\u0438\u0441\u044F \u043D\u0430 "${i.suffix}"` : i.format === "includes" ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u0440\u044F\u0434\u043E\u043A: \u043F\u043E\u0432\u0438\u043D\u0435\u043D \u043C\u0456\u0441\u0442\u0438\u0442\u0438 "${i.includes}"` : i.format === "regex" ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u0440\u044F\u0434\u043E\u043A: \u043F\u043E\u0432\u0438\u043D\u0435\u043D \u0432\u0456\u0434\u043F\u043E\u0432\u0456\u0434\u0430\u0442\u0438 \u0448\u0430\u0431\u043B\u043E\u043D\u0443 ${i.pattern}` : `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0435 \u0447\u0438\u0441\u043B\u043E: \u043F\u043E\u0432\u0438\u043D\u043D\u043E \u0431\u0443\u0442\u0438 \u043A\u0440\u0430\u0442\u043D\u0438\u043C ${r.divisor}`;
      case "unrecognized_keys":
        return `\u041D\u0435\u0440\u043E\u0437\u043F\u0456\u0437\u043D\u0430\u043D\u0438\u0439 \u043A\u043B\u044E\u0447${r.keys.length > 1 ? "\u0456" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u043A\u043B\u044E\u0447 \u0443 ${r.origin}`;
      case "invalid_union":
        return "\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456";
      case "invalid_element":
        return `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u043D\u044F \u0443 ${r.origin}`;
      default:
        return "\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456";
    }
  };
}, "error");
function Vt() {
  return {
    localeError: qg()
  };
}
a(Vt, "default");

// versions/4.3.6/node_modules/zod/v4/locales/ua.js
function us() {
  return Vt();
}
a(us, "default");

// versions/4.3.6/node_modules/zod/v4/locales/ur.js
var Jg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "\u062D\u0631\u0648\u0641", verb: "\u06C1\u0648\u0646\u0627" },
    file: { unit: "\u0628\u0627\u0626\u0679\u0633", verb: "\u06C1\u0648\u0646\u0627" },
    array: { unit: "\u0622\u0626\u0679\u0645\u0632", verb: "\u06C1\u0648\u0646\u0627" },
    set: { unit: "\u0622\u0626\u0679\u0645\u0632", verb: "\u06C1\u0648\u0646\u0627" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "\u0627\u0646 \u067E\u0679",
    email: "\u0627\u06CC \u0645\u06CC\u0644 \u0627\u06CC\u0688\u0631\u06CC\u0633",
    url: "\u06CC\u0648 \u0622\u0631 \u0627\u06CC\u0644",
    emoji: "\u0627\u06CC\u0645\u0648\u062C\u06CC",
    uuid: "\u06CC\u0648 \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC",
    uuidv4: "\u06CC\u0648 \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC \u0648\u06CC 4",
    uuidv6: "\u06CC\u0648 \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC \u0648\u06CC 6",
    nanoid: "\u0646\u06CC\u0646\u0648 \u0622\u0626\u06CC \u0688\u06CC",
    guid: "\u062C\u06CC \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC",
    cuid: "\u0633\u06CC \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC",
    cuid2: "\u0633\u06CC \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC 2",
    ulid: "\u06CC\u0648 \u0627\u06CC\u0644 \u0622\u0626\u06CC \u0688\u06CC",
    xid: "\u0627\u06CC\u06A9\u0633 \u0622\u0626\u06CC \u0688\u06CC",
    ksuid: "\u06A9\u06D2 \u0627\u06CC\u0633 \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC",
    datetime: "\u0622\u0626\u06CC \u0627\u06CC\u0633 \u0627\u0648 \u0688\u06CC\u0679 \u0679\u0627\u0626\u0645",
    date: "\u0622\u0626\u06CC \u0627\u06CC\u0633 \u0627\u0648 \u062A\u0627\u0631\u06CC\u062E",
    time: "\u0622\u0626\u06CC \u0627\u06CC\u0633 \u0627\u0648 \u0648\u0642\u062A",
    duration: "\u0622\u0626\u06CC \u0627\u06CC\u0633 \u0627\u0648 \u0645\u062F\u062A",
    ipv4: "\u0622\u0626\u06CC \u067E\u06CC \u0648\u06CC 4 \u0627\u06CC\u0688\u0631\u06CC\u0633",
    ipv6: "\u0622\u0626\u06CC \u067E\u06CC \u0648\u06CC 6 \u0627\u06CC\u0688\u0631\u06CC\u0633",
    cidrv4: "\u0622\u0626\u06CC \u067E\u06CC \u0648\u06CC 4 \u0631\u06CC\u0646\u062C",
    cidrv6: "\u0622\u0626\u06CC \u067E\u06CC \u0648\u06CC 6 \u0631\u06CC\u0646\u062C",
    base64: "\u0628\u06CC\u0633 64 \u0627\u0646 \u06A9\u0648\u0688\u0688 \u0633\u0679\u0631\u0646\u06AF",
    base64url: "\u0628\u06CC\u0633 64 \u06CC\u0648 \u0622\u0631 \u0627\u06CC\u0644 \u0627\u0646 \u06A9\u0648\u0688\u0688 \u0633\u0679\u0631\u0646\u06AF",
    json_string: "\u062C\u06D2 \u0627\u06CC\u0633 \u0627\u0648 \u0627\u06CC\u0646 \u0633\u0679\u0631\u0646\u06AF",
    e164: "\u0627\u06CC 164 \u0646\u0645\u0628\u0631",
    jwt: "\u062C\u06D2 \u0688\u0628\u0644\u06CC\u0648 \u0679\u06CC",
    template_literal: "\u0627\u0646 \u067E\u0679"
  }, o = {
    nan: "NaN",
    number: "\u0646\u0645\u0628\u0631",
    array: "\u0622\u0631\u06D2",
    null: "\u0646\u0644"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = y(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679: instanceof ${r.expected} \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627\u060C ${c} \u0645\u0648\u0635\u0648\u0644 \u06C1\u0648\u0627` : `\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679: ${i} \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627\u060C ${c} \u0645\u0648\u0635\u0648\u0644 \u06C1\u0648\u0627`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679: ${v(r.values[0])} \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627` : `\u063A\u0644\u0637 \u0622\u067E\u0634\u0646: ${p(r.values, "|")} \u0645\u06CC\u06BA \u0633\u06D2 \u0627\u06CC\u06A9 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `\u0628\u06C1\u062A \u0628\u0691\u0627: ${r.origin ?? "\u0648\u06CC\u0644\u06CC\u0648"} \u06A9\u06D2 ${i}${r.maximum.toString()} ${s.unit ?? "\u0639\u0646\u0627\u0635\u0631"} \u06C1\u0648\u0646\u06D2 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u06D2` : `\u0628\u06C1\u062A \u0628\u0691\u0627: ${r.origin ?? "\u0648\u06CC\u0644\u06CC\u0648"} \u06A9\u0627 ${i}${r.maximum.toString()} \u06C1\u0648\u0646\u0627 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `\u0628\u06C1\u062A \u0686\u06BE\u0648\u0679\u0627: ${r.origin} \u06A9\u06D2 ${i}${r.minimum.toString()} ${s.unit} \u06C1\u0648\u0646\u06D2 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u06D2` : `\u0628\u06C1\u062A \u0686\u06BE\u0648\u0679\u0627: ${r.origin} \u06A9\u0627 ${i}${r.minimum.toString()} \u06C1\u0648\u0646\u0627 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u063A\u0644\u0637 \u0633\u0679\u0631\u0646\u06AF: "${i.prefix}" \u0633\u06D2 \u0634\u0631\u0648\u0639 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2` : i.format === "ends_with" ? `\u063A\u0644\u0637 \u0633\u0679\u0631\u0646\u06AF: "${i.suffix}" \u067E\u0631 \u062E\u062A\u0645 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2` : i.format === "includes" ? `\u063A\u0644\u0637 \u0633\u0679\u0631\u0646\u06AF: "${i.includes}" \u0634\u0627\u0645\u0644 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2` : i.format === "regex" ? `\u063A\u0644\u0637 \u0633\u0679\u0631\u0646\u06AF: \u067E\u06CC\u0679\u0631\u0646 ${i.pattern} \u0633\u06D2 \u0645\u06CC\u0686 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2` : `\u063A\u0644\u0637 ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u063A\u0644\u0637 \u0646\u0645\u0628\u0631: ${r.divisor} \u06A9\u0627 \u0645\u0636\u0627\u0639\u0641 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2`;
      case "unrecognized_keys":
        return `\u063A\u06CC\u0631 \u062A\u0633\u0644\u06CC\u0645 \u0634\u062F\u06C1 \u06A9\u06CC${r.keys.length > 1 ? "\u0632" : ""}: ${p(r.keys, "\u060C ")}`;
      case "invalid_key":
        return `${r.origin} \u0645\u06CC\u06BA \u063A\u0644\u0637 \u06A9\u06CC`;
      case "invalid_union":
        return "\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679";
      case "invalid_element":
        return `${r.origin} \u0645\u06CC\u06BA \u063A\u0644\u0637 \u0648\u06CC\u0644\u06CC\u0648`;
      default:
        return "\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679";
    }
  };
}, "error");
function ls() {
  return {
    localeError: Jg()
  };
}
a(ls, "default");

// versions/4.3.6/node_modules/zod/v4/locales/uz.js
var Wg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "belgi", verb: "bo\u2018lishi kerak" },
    file: { unit: "bayt", verb: "bo\u2018lishi kerak" },
    array: { unit: "element", verb: "bo\u2018lishi kerak" },
    set: { unit: "element", verb: "bo\u2018lishi kerak" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "kirish",
    email: "elektron pochta manzili",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO sana va vaqti",
    date: "ISO sana",
    time: "ISO vaqt",
    duration: "ISO davomiylik",
    ipv4: "IPv4 manzil",
    ipv6: "IPv6 manzil",
    mac: "MAC manzil",
    cidrv4: "IPv4 diapazon",
    cidrv6: "IPv6 diapazon",
    base64: "base64 kodlangan satr",
    base64url: "base64url kodlangan satr",
    json_string: "JSON satr",
    e164: "E.164 raqam",
    jwt: "JWT",
    template_literal: "kirish"
  }, o = {
    nan: "NaN",
    number: "raqam",
    array: "massiv"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = y(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Noto\u2018g\u2018ri kirish: kutilgan instanceof ${r.expected}, qabul qilingan ${c}` : `Noto\u2018g\u2018ri kirish: kutilgan ${i}, qabul qilingan ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Noto\u2018g\u2018ri kirish: kutilgan ${v(r.values[0])}` : `Noto\u2018g\u2018ri variant: quyidagilardan biri kutilgan ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `Juda katta: kutilgan ${r.origin ?? "qiymat"} ${i}${r.maximum.toString()} ${s.unit} ${s.verb}` : `Juda katta: kutilgan ${r.origin ?? "qiymat"} ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `Juda kichik: kutilgan ${r.origin} ${i}${r.minimum.toString()} ${s.unit} ${s.verb}` : `Juda kichik: kutilgan ${r.origin} ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Noto\u2018g\u2018ri satr: "${i.prefix}" bilan boshlanishi kerak` : i.format === "ends_with" ? `Noto\u2018g\u2018ri satr: "${i.suffix}" bilan tugashi kerak` : i.format === "includes" ? `Noto\u2018g\u2018ri satr: "${i.includes}" ni o\u2018z ichiga olishi kerak` : i.format === "regex" ? `Noto\u2018g\u2018ri satr: ${i.pattern} shabloniga mos kelishi kerak` : `Noto\u2018g\u2018ri ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Noto\u2018g\u2018ri raqam: ${r.divisor} ning karralisi bo\u2018lishi kerak`;
      case "unrecognized_keys":
        return `Noma\u2019lum kalit${r.keys.length > 1 ? "lar" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `${r.origin} dagi kalit noto\u2018g\u2018ri`;
      case "invalid_union":
        return "Noto\u2018g\u2018ri kirish";
      case "invalid_element":
        return `${r.origin} da noto\u2018g\u2018ri qiymat`;
      default:
        return "Noto\u2018g\u2018ri kirish";
    }
  };
}, "error");
function ds() {
  return {
    localeError: Wg()
  };
}
a(ds, "default");

// versions/4.3.6/node_modules/zod/v4/locales/vi.js
var Kg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "k\xFD t\u1EF1", verb: "c\xF3" },
    file: { unit: "byte", verb: "c\xF3" },
    array: { unit: "ph\u1EA7n t\u1EED", verb: "c\xF3" },
    set: { unit: "ph\u1EA7n t\u1EED", verb: "c\xF3" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "\u0111\u1EA7u v\xE0o",
    email: "\u0111\u1ECBa ch\u1EC9 email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ng\xE0y gi\u1EDD ISO",
    date: "ng\xE0y ISO",
    time: "gi\u1EDD ISO",
    duration: "kho\u1EA3ng th\u1EDDi gian ISO",
    ipv4: "\u0111\u1ECBa ch\u1EC9 IPv4",
    ipv6: "\u0111\u1ECBa ch\u1EC9 IPv6",
    cidrv4: "d\u1EA3i IPv4",
    cidrv6: "d\u1EA3i IPv6",
    base64: "chu\u1ED7i m\xE3 h\xF3a base64",
    base64url: "chu\u1ED7i m\xE3 h\xF3a base64url",
    json_string: "chu\u1ED7i JSON",
    e164: "s\u1ED1 E.164",
    jwt: "JWT",
    template_literal: "\u0111\u1EA7u v\xE0o"
  }, o = {
    nan: "NaN",
    number: "s\u1ED1",
    array: "m\u1EA3ng"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = y(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7: mong \u0111\u1EE3i instanceof ${r.expected}, nh\u1EADn \u0111\u01B0\u1EE3c ${c}` : `\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7: mong \u0111\u1EE3i ${i}, nh\u1EADn \u0111\u01B0\u1EE3c ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7: mong \u0111\u1EE3i ${v(r.values[0])}` : `T\xF9y ch\u1ECDn kh\xF4ng h\u1EE3p l\u1EC7: mong \u0111\u1EE3i m\u1ED9t trong c\xE1c gi\xE1 tr\u1ECB ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `Qu\xE1 l\u1EDBn: mong \u0111\u1EE3i ${r.origin ?? "gi\xE1 tr\u1ECB"} ${s.verb} ${i}${r.maximum.toString()} ${s.unit ?? "ph\u1EA7n t\u1EED"}` : `Qu\xE1 l\u1EDBn: mong \u0111\u1EE3i ${r.origin ?? "gi\xE1 tr\u1ECB"} ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `Qu\xE1 nh\u1ECF: mong \u0111\u1EE3i ${r.origin} ${s.verb} ${i}${r.minimum.toString()} ${s.unit}` : `Qu\xE1 nh\u1ECF: mong \u0111\u1EE3i ${r.origin} ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Chu\u1ED7i kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i b\u1EAFt \u0111\u1EA7u b\u1EB1ng "${i.prefix}"` : i.format === "ends_with" ? `Chu\u1ED7i kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i k\u1EBFt th\xFAc b\u1EB1ng "${i.suffix}"` : i.format === "includes" ? `Chu\u1ED7i kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i bao g\u1ED3m "${i.includes}"` : i.format === "regex" ? `Chu\u1ED7i kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i kh\u1EDBp v\u1EDBi m\u1EABu ${i.pattern}` : `${n[i.format] ?? r.format} kh\xF4ng h\u1EE3p l\u1EC7`;
      }
      case "not_multiple_of":
        return `S\u1ED1 kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i l\xE0 b\u1ED9i s\u1ED1 c\u1EE7a ${r.divisor}`;
      case "unrecognized_keys":
        return `Kh\xF3a kh\xF4ng \u0111\u01B0\u1EE3c nh\u1EADn d\u1EA1ng: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Kh\xF3a kh\xF4ng h\u1EE3p l\u1EC7 trong ${r.origin}`;
      case "invalid_union":
        return "\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7";
      case "invalid_element":
        return `Gi\xE1 tr\u1ECB kh\xF4ng h\u1EE3p l\u1EC7 trong ${r.origin}`;
      default:
        return "\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7";
    }
  };
}, "error");
function fs() {
  return {
    localeError: Kg()
  };
}
a(fs, "default");

// versions/4.3.6/node_modules/zod/v4/locales/zh-CN.js
var Gg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "\u5B57\u7B26", verb: "\u5305\u542B" },
    file: { unit: "\u5B57\u8282", verb: "\u5305\u542B" },
    array: { unit: "\u9879", verb: "\u5305\u542B" },
    set: { unit: "\u9879", verb: "\u5305\u542B" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "\u8F93\u5165",
    email: "\u7535\u5B50\u90AE\u4EF6",
    url: "URL",
    emoji: "\u8868\u60C5\u7B26\u53F7",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO\u65E5\u671F\u65F6\u95F4",
    date: "ISO\u65E5\u671F",
    time: "ISO\u65F6\u95F4",
    duration: "ISO\u65F6\u957F",
    ipv4: "IPv4\u5730\u5740",
    ipv6: "IPv6\u5730\u5740",
    cidrv4: "IPv4\u7F51\u6BB5",
    cidrv6: "IPv6\u7F51\u6BB5",
    base64: "base64\u7F16\u7801\u5B57\u7B26\u4E32",
    base64url: "base64url\u7F16\u7801\u5B57\u7B26\u4E32",
    json_string: "JSON\u5B57\u7B26\u4E32",
    e164: "E.164\u53F7\u7801",
    jwt: "JWT",
    template_literal: "\u8F93\u5165"
  }, o = {
    nan: "NaN",
    number: "\u6570\u5B57",
    array: "\u6570\u7EC4",
    null: "\u7A7A\u503C(null)"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = y(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `\u65E0\u6548\u8F93\u5165\uFF1A\u671F\u671B instanceof ${r.expected}\uFF0C\u5B9E\u9645\u63A5\u6536 ${c}` : `\u65E0\u6548\u8F93\u5165\uFF1A\u671F\u671B ${i}\uFF0C\u5B9E\u9645\u63A5\u6536 ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u65E0\u6548\u8F93\u5165\uFF1A\u671F\u671B ${v(r.values[0])}` : `\u65E0\u6548\u9009\u9879\uFF1A\u671F\u671B\u4EE5\u4E0B\u4E4B\u4E00 ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `\u6570\u503C\u8FC7\u5927\uFF1A\u671F\u671B ${r.origin ?? "\u503C"} ${i}${r.maximum.toString()} ${s.unit ?? "\u4E2A\u5143\u7D20"}` : `\u6570\u503C\u8FC7\u5927\uFF1A\u671F\u671B ${r.origin ?? "\u503C"} ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `\u6570\u503C\u8FC7\u5C0F\uFF1A\u671F\u671B ${r.origin} ${i}${r.minimum.toString()} ${s.unit}` : `\u6570\u503C\u8FC7\u5C0F\uFF1A\u671F\u671B ${r.origin} ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u65E0\u6548\u5B57\u7B26\u4E32\uFF1A\u5FC5\u987B\u4EE5 "${i.prefix}" \u5F00\u5934` : i.format === "ends_with" ? `\u65E0\u6548\u5B57\u7B26\u4E32\uFF1A\u5FC5\u987B\u4EE5 "${i.suffix}" \u7ED3\u5C3E` : i.format === "includes" ? `\u65E0\u6548\u5B57\u7B26\u4E32\uFF1A\u5FC5\u987B\u5305\u542B "${i.includes}"` : i.format === "regex" ? `\u65E0\u6548\u5B57\u7B26\u4E32\uFF1A\u5FC5\u987B\u6EE1\u8DB3\u6B63\u5219\u8868\u8FBE\u5F0F ${i.pattern}` : `\u65E0\u6548${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u65E0\u6548\u6570\u5B57\uFF1A\u5FC5\u987B\u662F ${r.divisor} \u7684\u500D\u6570`;
      case "unrecognized_keys":
        return `\u51FA\u73B0\u672A\u77E5\u7684\u952E(key): ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `${r.origin} \u4E2D\u7684\u952E(key)\u65E0\u6548`;
      case "invalid_union":
        return "\u65E0\u6548\u8F93\u5165";
      case "invalid_element":
        return `${r.origin} \u4E2D\u5305\u542B\u65E0\u6548\u503C(value)`;
      default:
        return "\u65E0\u6548\u8F93\u5165";
    }
  };
}, "error");
function ps() {
  return {
    localeError: Gg()
  };
}
a(ps, "default");

// versions/4.3.6/node_modules/zod/v4/locales/zh-TW.js
var Xg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "\u5B57\u5143", verb: "\u64C1\u6709" },
    file: { unit: "\u4F4D\u5143\u7D44", verb: "\u64C1\u6709" },
    array: { unit: "\u9805\u76EE", verb: "\u64C1\u6709" },
    set: { unit: "\u9805\u76EE", verb: "\u64C1\u6709" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "\u8F38\u5165",
    email: "\u90F5\u4EF6\u5730\u5740",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u65E5\u671F\u6642\u9593",
    date: "ISO \u65E5\u671F",
    time: "ISO \u6642\u9593",
    duration: "ISO \u671F\u9593",
    ipv4: "IPv4 \u4F4D\u5740",
    ipv6: "IPv6 \u4F4D\u5740",
    cidrv4: "IPv4 \u7BC4\u570D",
    cidrv6: "IPv6 \u7BC4\u570D",
    base64: "base64 \u7DE8\u78BC\u5B57\u4E32",
    base64url: "base64url \u7DE8\u78BC\u5B57\u4E32",
    json_string: "JSON \u5B57\u4E32",
    e164: "E.164 \u6578\u503C",
    jwt: "JWT",
    template_literal: "\u8F38\u5165"
  }, o = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = y(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `\u7121\u6548\u7684\u8F38\u5165\u503C\uFF1A\u9810\u671F\u70BA instanceof ${r.expected}\uFF0C\u4F46\u6536\u5230 ${c}` : `\u7121\u6548\u7684\u8F38\u5165\u503C\uFF1A\u9810\u671F\u70BA ${i}\uFF0C\u4F46\u6536\u5230 ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u7121\u6548\u7684\u8F38\u5165\u503C\uFF1A\u9810\u671F\u70BA ${v(r.values[0])}` : `\u7121\u6548\u7684\u9078\u9805\uFF1A\u9810\u671F\u70BA\u4EE5\u4E0B\u5176\u4E2D\u4E4B\u4E00 ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `\u6578\u503C\u904E\u5927\uFF1A\u9810\u671F ${r.origin ?? "\u503C"} \u61C9\u70BA ${i}${r.maximum.toString()} ${s.unit ?? "\u500B\u5143\u7D20"}` : `\u6578\u503C\u904E\u5927\uFF1A\u9810\u671F ${r.origin ?? "\u503C"} \u61C9\u70BA ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `\u6578\u503C\u904E\u5C0F\uFF1A\u9810\u671F ${r.origin} \u61C9\u70BA ${i}${r.minimum.toString()} ${s.unit}` : `\u6578\u503C\u904E\u5C0F\uFF1A\u9810\u671F ${r.origin} \u61C9\u70BA ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u7121\u6548\u7684\u5B57\u4E32\uFF1A\u5FC5\u9808\u4EE5 "${i.prefix}" \u958B\u982D` : i.format === "ends_with" ? `\u7121\u6548\u7684\u5B57\u4E32\uFF1A\u5FC5\u9808\u4EE5 "${i.suffix}" \u7D50\u5C3E` : i.format === "includes" ? `\u7121\u6548\u7684\u5B57\u4E32\uFF1A\u5FC5\u9808\u5305\u542B "${i.includes}"` : i.format === "regex" ? `\u7121\u6548\u7684\u5B57\u4E32\uFF1A\u5FC5\u9808\u7B26\u5408\u683C\u5F0F ${i.pattern}` : `\u7121\u6548\u7684 ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u7121\u6548\u7684\u6578\u5B57\uFF1A\u5FC5\u9808\u70BA ${r.divisor} \u7684\u500D\u6578`;
      case "unrecognized_keys":
        return `\u7121\u6CD5\u8B58\u5225\u7684\u9375\u503C${r.keys.length > 1 ? "\u5011" : ""}\uFF1A${p(r.keys, "\u3001")}`;
      case "invalid_key":
        return `${r.origin} \u4E2D\u6709\u7121\u6548\u7684\u9375\u503C`;
      case "invalid_union":
        return "\u7121\u6548\u7684\u8F38\u5165\u503C";
      case "invalid_element":
        return `${r.origin} \u4E2D\u6709\u7121\u6548\u7684\u503C`;
      default:
        return "\u7121\u6548\u7684\u8F38\u5165\u503C";
    }
  };
}, "error");
function ms() {
  return {
    localeError: Xg()
  };
}
a(ms, "default");

// versions/4.3.6/node_modules/zod/v4/locales/yo.js
var Hg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "\xE0mi", verb: "n\xED" },
    file: { unit: "bytes", verb: "n\xED" },
    array: { unit: "nkan", verb: "n\xED" },
    set: { unit: "nkan", verb: "n\xED" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "\u1EB9\u0300r\u1ECD \xECb\xE1w\u1ECDl\xE9",
    email: "\xE0d\xEDr\u1EB9\u0301s\xEC \xECm\u1EB9\u0301l\xEC",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\xE0k\xF3k\xF2 ISO",
    date: "\u1ECDj\u1ECD\u0301 ISO",
    time: "\xE0k\xF3k\xF2 ISO",
    duration: "\xE0k\xF3k\xF2 t\xF3 p\xE9 ISO",
    ipv4: "\xE0d\xEDr\u1EB9\u0301s\xEC IPv4",
    ipv6: "\xE0d\xEDr\u1EB9\u0301s\xEC IPv6",
    cidrv4: "\xE0gb\xE8gb\xE8 IPv4",
    cidrv6: "\xE0gb\xE8gb\xE8 IPv6",
    base64: "\u1ECD\u0300r\u1ECD\u0300 t\xED a k\u1ECD\u0301 n\xED base64",
    base64url: "\u1ECD\u0300r\u1ECD\u0300 base64url",
    json_string: "\u1ECD\u0300r\u1ECD\u0300 JSON",
    e164: "n\u1ECD\u0301mb\xE0 E.164",
    jwt: "JWT",
    template_literal: "\u1EB9\u0300r\u1ECD \xECb\xE1w\u1ECDl\xE9"
  }, o = {
    nan: "NaN",
    number: "n\u1ECD\u0301mb\xE0",
    array: "akop\u1ECD"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = y(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e: a n\xED l\xE1ti fi instanceof ${r.expected}, \xE0m\u1ECD\u0300 a r\xED ${c}` : `\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e: a n\xED l\xE1ti fi ${i}, \xE0m\u1ECD\u0300 a r\xED ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e: a n\xED l\xE1ti fi ${v(r.values[0])}` : `\xC0\u1E63\xE0y\xE0n a\u1E63\xEC\u1E63e: yan \u1ECD\u0300kan l\xE1ra ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `T\xF3 p\u1ECD\u0300 j\xF9: a n\xED l\xE1ti j\u1EB9\u0301 p\xE9 ${r.origin ?? "iye"} ${s.verb} ${i}${r.maximum} ${s.unit}` : `T\xF3 p\u1ECD\u0300 j\xF9: a n\xED l\xE1ti j\u1EB9\u0301 ${i}${r.maximum}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `K\xE9r\xE9 ju: a n\xED l\xE1ti j\u1EB9\u0301 p\xE9 ${r.origin} ${s.verb} ${i}${r.minimum} ${s.unit}` : `K\xE9r\xE9 ju: a n\xED l\xE1ti j\u1EB9\u0301 ${i}${r.minimum}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u1ECC\u0300r\u1ECD\u0300 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 b\u1EB9\u0300r\u1EB9\u0300 p\u1EB9\u0300l\xFA "${i.prefix}"` : i.format === "ends_with" ? `\u1ECC\u0300r\u1ECD\u0300 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 par\xED p\u1EB9\u0300l\xFA "${i.suffix}"` : i.format === "includes" ? `\u1ECC\u0300r\u1ECD\u0300 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 n\xED "${i.includes}"` : i.format === "regex" ? `\u1ECC\u0300r\u1ECD\u0300 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 b\xE1 \xE0p\u1EB9\u1EB9r\u1EB9 mu ${i.pattern}` : `A\u1E63\xEC\u1E63e: ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `N\u1ECD\u0301mb\xE0 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 j\u1EB9\u0301 \xE8y\xE0 p\xEDp\xEDn ti ${r.divisor}`;
      case "unrecognized_keys":
        return `B\u1ECDt\xECn\xEC \xE0\xECm\u1ECD\u0300: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `B\u1ECDt\xECn\xEC a\u1E63\xEC\u1E63e n\xEDn\xFA ${r.origin}`;
      case "invalid_union":
        return "\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e";
      case "invalid_element":
        return `Iye a\u1E63\xEC\u1E63e n\xEDn\xFA ${r.origin}`;
      default:
        return "\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e";
    }
  };
}, "error");
function gs() {
  return {
    localeError: Hg()
  };
}
a(gs, "default");

// versions/4.3.6/node_modules/zod/v4/core/registries.js
var Wl, hs = Symbol("ZodOutput"), vs = Symbol("ZodInput"), Jr = class {
  static {
    a(this, "$ZodRegistry");
  }
  constructor() {
    this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map();
  }
  add(t, ...n) {
    let o = n[0];
    return this._map.set(t, o), o && typeof o == "object" && "id" in o && this._idmap.set(o.id, t), this;
  }
  clear() {
    return this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map(), this;
  }
  remove(t) {
    let n = this._map.get(t);
    return n && typeof n == "object" && "id" in n && this._idmap.delete(n.id), this._map.delete(t), this;
  }
  get(t) {
    let n = t._zod.parent;
    if (n) {
      let o = { ...this.get(n) ?? {} };
      delete o.id;
      let r = { ...o, ...this._map.get(t) };
      return Object.keys(r).length ? r : void 0;
    }
    return this._map.get(t);
  }
  has(t) {
    return this._map.has(t);
  }
};
function Wr() {
  return new Jr();
}
a(Wr, "registry");
(Wl = globalThis).__zod_globalRegistry ?? (Wl.__zod_globalRegistry = Wr());
var he = globalThis.__zod_globalRegistry;

// versions/4.3.6/node_modules/zod/v4/core/api.js
// @__NO_SIDE_EFFECTS__
function ys(e, t) {
  return new e({
    type: "string",
    ...h(t)
  });
}
a(ys, "_string");
// @__NO_SIDE_EFFECTS__
function bs(e, t) {
  return new e({
    type: "string",
    coerce: !0,
    ...h(t)
  });
}
a(bs, "_coercedString");
// @__NO_SIDE_EFFECTS__
function xs(e, t) {
  return new e({
    type: "string",
    format: "email",
    check: "string_format",
    abort: !1,
    ...h(t)
  });
}
a(xs, "_email");
// @__NO_SIDE_EFFECTS__
function $s(e, t) {
  return new e({
    type: "string",
    format: "guid",
    check: "string_format",
    abort: !1,
    ...h(t)
  });
}
a($s, "_guid");
// @__NO_SIDE_EFFECTS__
function _s(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    ...h(t)
  });
}
a(_s, "_uuid");
// @__NO_SIDE_EFFECTS__
function ws(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v4",
    ...h(t)
  });
}
a(ws, "_uuidv4");
// @__NO_SIDE_EFFECTS__
function ks(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v6",
    ...h(t)
  });
}
a(ks, "_uuidv6");
// @__NO_SIDE_EFFECTS__
function zs(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v7",
    ...h(t)
  });
}
a(zs, "_uuidv7");
// @__NO_SIDE_EFFECTS__
function Kr(e, t) {
  return new e({
    type: "string",
    format: "url",
    check: "string_format",
    abort: !1,
    ...h(t)
  });
}
a(Kr, "_url");
// @__NO_SIDE_EFFECTS__
function Is(e, t) {
  return new e({
    type: "string",
    format: "emoji",
    check: "string_format",
    abort: !1,
    ...h(t)
  });
}
a(Is, "_emoji");
// @__NO_SIDE_EFFECTS__
function Ss(e, t) {
  return new e({
    type: "string",
    format: "nanoid",
    check: "string_format",
    abort: !1,
    ...h(t)
  });
}
a(Ss, "_nanoid");
// @__NO_SIDE_EFFECTS__
function js(e, t) {
  return new e({
    type: "string",
    format: "cuid",
    check: "string_format",
    abort: !1,
    ...h(t)
  });
}
a(js, "_cuid");
// @__NO_SIDE_EFFECTS__
function Os(e, t) {
  return new e({
    type: "string",
    format: "cuid2",
    check: "string_format",
    abort: !1,
    ...h(t)
  });
}
a(Os, "_cuid2");
// @__NO_SIDE_EFFECTS__
function Ts(e, t) {
  return new e({
    type: "string",
    format: "ulid",
    check: "string_format",
    abort: !1,
    ...h(t)
  });
}
a(Ts, "_ulid");
// @__NO_SIDE_EFFECTS__
function Ps(e, t) {
  return new e({
    type: "string",
    format: "xid",
    check: "string_format",
    abort: !1,
    ...h(t)
  });
}
a(Ps, "_xid");
// @__NO_SIDE_EFFECTS__
function Us(e, t) {
  return new e({
    type: "string",
    format: "ksuid",
    check: "string_format",
    abort: !1,
    ...h(t)
  });
}
a(Us, "_ksuid");
// @__NO_SIDE_EFFECTS__
function Ds(e, t) {
  return new e({
    type: "string",
    format: "ipv4",
    check: "string_format",
    abort: !1,
    ...h(t)
  });
}
a(Ds, "_ipv4");
// @__NO_SIDE_EFFECTS__
function Es(e, t) {
  return new e({
    type: "string",
    format: "ipv6",
    check: "string_format",
    abort: !1,
    ...h(t)
  });
}
a(Es, "_ipv6");
// @__NO_SIDE_EFFECTS__
function Zs(e, t) {
  return new e({
    type: "string",
    format: "mac",
    check: "string_format",
    abort: !1,
    ...h(t)
  });
}
a(Zs, "_mac");
// @__NO_SIDE_EFFECTS__
function Ns(e, t) {
  return new e({
    type: "string",
    format: "cidrv4",
    check: "string_format",
    abort: !1,
    ...h(t)
  });
}
a(Ns, "_cidrv4");
// @__NO_SIDE_EFFECTS__
function As(e, t) {
  return new e({
    type: "string",
    format: "cidrv6",
    check: "string_format",
    abort: !1,
    ...h(t)
  });
}
a(As, "_cidrv6");
// @__NO_SIDE_EFFECTS__
function Cs(e, t) {
  return new e({
    type: "string",
    format: "base64",
    check: "string_format",
    abort: !1,
    ...h(t)
  });
}
a(Cs, "_base64");
// @__NO_SIDE_EFFECTS__
function Rs(e, t) {
  return new e({
    type: "string",
    format: "base64url",
    check: "string_format",
    abort: !1,
    ...h(t)
  });
}
a(Rs, "_base64url");
// @__NO_SIDE_EFFECTS__
function Fs(e, t) {
  return new e({
    type: "string",
    format: "e164",
    check: "string_format",
    abort: !1,
    ...h(t)
  });
}
a(Fs, "_e164");
// @__NO_SIDE_EFFECTS__
function Ms(e, t) {
  return new e({
    type: "string",
    format: "jwt",
    check: "string_format",
    abort: !1,
    ...h(t)
  });
}
a(Ms, "_jwt");
var Ls = {
  Any: null,
  Minute: -1,
  Second: 0,
  Millisecond: 3,
  Microsecond: 6
};
// @__NO_SIDE_EFFECTS__
function Bs(e, t) {
  return new e({
    type: "string",
    format: "datetime",
    check: "string_format",
    offset: !1,
    local: !1,
    precision: null,
    ...h(t)
  });
}
a(Bs, "_isoDateTime");
// @__NO_SIDE_EFFECTS__
function Vs(e, t) {
  return new e({
    type: "string",
    format: "date",
    check: "string_format",
    ...h(t)
  });
}
a(Vs, "_isoDate");
// @__NO_SIDE_EFFECTS__
function qs(e, t) {
  return new e({
    type: "string",
    format: "time",
    check: "string_format",
    precision: null,
    ...h(t)
  });
}
a(qs, "_isoTime");
// @__NO_SIDE_EFFECTS__
function Js(e, t) {
  return new e({
    type: "string",
    format: "duration",
    check: "string_format",
    ...h(t)
  });
}
a(Js, "_isoDuration");
// @__NO_SIDE_EFFECTS__
function Ws(e, t) {
  return new e({
    type: "number",
    checks: [],
    ...h(t)
  });
}
a(Ws, "_number");
// @__NO_SIDE_EFFECTS__
function Ks(e, t) {
  return new e({
    type: "number",
    coerce: !0,
    checks: [],
    ...h(t)
  });
}
a(Ks, "_coercedNumber");
// @__NO_SIDE_EFFECTS__
function Gs(e, t) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "safeint",
    ...h(t)
  });
}
a(Gs, "_int");
// @__NO_SIDE_EFFECTS__
function Xs(e, t) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "float32",
    ...h(t)
  });
}
a(Xs, "_float32");
// @__NO_SIDE_EFFECTS__
function Hs(e, t) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "float64",
    ...h(t)
  });
}
a(Hs, "_float64");
// @__NO_SIDE_EFFECTS__
function Qs(e, t) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "int32",
    ...h(t)
  });
}
a(Qs, "_int32");
// @__NO_SIDE_EFFECTS__
function Ys(e, t) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "uint32",
    ...h(t)
  });
}
a(Ys, "_uint32");
// @__NO_SIDE_EFFECTS__
function ec(e, t) {
  return new e({
    type: "boolean",
    ...h(t)
  });
}
a(ec, "_boolean");
// @__NO_SIDE_EFFECTS__
function tc(e, t) {
  return new e({
    type: "boolean",
    coerce: !0,
    ...h(t)
  });
}
a(tc, "_coercedBoolean");
// @__NO_SIDE_EFFECTS__
function rc(e, t) {
  return new e({
    type: "bigint",
    ...h(t)
  });
}
a(rc, "_bigint");
// @__NO_SIDE_EFFECTS__
function nc(e, t) {
  return new e({
    type: "bigint",
    coerce: !0,
    ...h(t)
  });
}
a(nc, "_coercedBigint");
// @__NO_SIDE_EFFECTS__
function ic(e, t) {
  return new e({
    type: "bigint",
    check: "bigint_format",
    abort: !1,
    format: "int64",
    ...h(t)
  });
}
a(ic, "_int64");
// @__NO_SIDE_EFFECTS__
function oc(e, t) {
  return new e({
    type: "bigint",
    check: "bigint_format",
    abort: !1,
    format: "uint64",
    ...h(t)
  });
}
a(oc, "_uint64");
// @__NO_SIDE_EFFECTS__
function ac(e, t) {
  return new e({
    type: "symbol",
    ...h(t)
  });
}
a(ac, "_symbol");
// @__NO_SIDE_EFFECTS__
function sc(e, t) {
  return new e({
    type: "undefined",
    ...h(t)
  });
}
a(sc, "_undefined");
// @__NO_SIDE_EFFECTS__
function cc(e, t) {
  return new e({
    type: "null",
    ...h(t)
  });
}
a(cc, "_null");
// @__NO_SIDE_EFFECTS__
function uc(e) {
  return new e({
    type: "any"
  });
}
a(uc, "_any");
// @__NO_SIDE_EFFECTS__
function lc(e) {
  return new e({
    type: "unknown"
  });
}
a(lc, "_unknown");
// @__NO_SIDE_EFFECTS__
function dc(e, t) {
  return new e({
    type: "never",
    ...h(t)
  });
}
a(dc, "_never");
// @__NO_SIDE_EFFECTS__
function fc(e, t) {
  return new e({
    type: "void",
    ...h(t)
  });
}
a(fc, "_void");
// @__NO_SIDE_EFFECTS__
function pc(e, t) {
  return new e({
    type: "date",
    ...h(t)
  });
}
a(pc, "_date");
// @__NO_SIDE_EFFECTS__
function mc(e, t) {
  return new e({
    type: "date",
    coerce: !0,
    ...h(t)
  });
}
a(mc, "_coercedDate");
// @__NO_SIDE_EFFECTS__
function gc(e, t) {
  return new e({
    type: "nan",
    ...h(t)
  });
}
a(gc, "_nan");
// @__NO_SIDE_EFFECTS__
function Gr(e, t) {
  return new Ar({
    check: "less_than",
    ...h(t),
    value: e,
    inclusive: !1
  });
}
a(Gr, "_lt");
// @__NO_SIDE_EFFECTS__
function Jt(e, t) {
  return new Ar({
    check: "less_than",
    ...h(t),
    value: e,
    inclusive: !0
  });
}
a(Jt, "_lte");
// @__NO_SIDE_EFFECTS__
function Xr(e, t) {
  return new Cr({
    check: "greater_than",
    ...h(t),
    value: e,
    inclusive: !1
  });
}
a(Xr, "_gt");
// @__NO_SIDE_EFFECTS__
function Wt(e, t) {
  return new Cr({
    check: "greater_than",
    ...h(t),
    value: e,
    inclusive: !0
  });
}
a(Wt, "_gte");
// @__NO_SIDE_EFFECTS__
function hc(e) {
  return /* @__PURE__ */ Xr(0, e);
}
a(hc, "_positive");
// @__NO_SIDE_EFFECTS__
function vc(e) {
  return /* @__PURE__ */ Gr(0, e);
}
a(vc, "_negative");
// @__NO_SIDE_EFFECTS__
function yc(e) {
  return /* @__PURE__ */ Jt(0, e);
}
a(yc, "_nonpositive");
// @__NO_SIDE_EFFECTS__
function bc(e) {
  return /* @__PURE__ */ Wt(0, e);
}
a(bc, "_nonnegative");
// @__NO_SIDE_EFFECTS__
function xc(e, t) {
  return new io({
    check: "multiple_of",
    ...h(t),
    value: e
  });
}
a(xc, "_multipleOf");
// @__NO_SIDE_EFFECTS__
function $c(e, t) {
  return new so({
    check: "max_size",
    ...h(t),
    maximum: e
  });
}
a($c, "_maxSize");
// @__NO_SIDE_EFFECTS__
function _c(e, t) {
  return new co({
    check: "min_size",
    ...h(t),
    minimum: e
  });
}
a(_c, "_minSize");
// @__NO_SIDE_EFFECTS__
function wc(e, t) {
  return new uo({
    check: "size_equals",
    ...h(t),
    size: e
  });
}
a(wc, "_size");
// @__NO_SIDE_EFFECTS__
function kc(e, t) {
  return new lo({
    check: "max_length",
    ...h(t),
    maximum: e
  });
}
a(kc, "_maxLength");
// @__NO_SIDE_EFFECTS__
function zc(e, t) {
  return new fo({
    check: "min_length",
    ...h(t),
    minimum: e
  });
}
a(zc, "_minLength");
// @__NO_SIDE_EFFECTS__
function Ic(e, t) {
  return new po({
    check: "length_equals",
    ...h(t),
    length: e
  });
}
a(Ic, "_length");
// @__NO_SIDE_EFFECTS__
function Sc(e, t) {
  return new mo({
    check: "string_format",
    format: "regex",
    ...h(t),
    pattern: e
  });
}
a(Sc, "_regex");
// @__NO_SIDE_EFFECTS__
function jc(e) {
  return new go({
    check: "string_format",
    format: "lowercase",
    ...h(e)
  });
}
a(jc, "_lowercase");
// @__NO_SIDE_EFFECTS__
function Oc(e) {
  return new ho({
    check: "string_format",
    format: "uppercase",
    ...h(e)
  });
}
a(Oc, "_uppercase");
// @__NO_SIDE_EFFECTS__
function Tc(e, t) {
  return new vo({
    check: "string_format",
    format: "includes",
    ...h(t),
    includes: e
  });
}
a(Tc, "_includes");
// @__NO_SIDE_EFFECTS__
function Pc(e, t) {
  return new yo({
    check: "string_format",
    format: "starts_with",
    ...h(t),
    prefix: e
  });
}
a(Pc, "_startsWith");
// @__NO_SIDE_EFFECTS__
function Uc(e, t) {
  return new bo({
    check: "string_format",
    format: "ends_with",
    ...h(t),
    suffix: e
  });
}
a(Uc, "_endsWith");
// @__NO_SIDE_EFFECTS__
function Dc(e, t, n) {
  return new xo({
    check: "property",
    property: e,
    schema: t,
    ...h(n)
  });
}
a(Dc, "_property");
// @__NO_SIDE_EFFECTS__
function Ec(e, t) {
  return new $o({
    check: "mime_type",
    mime: e,
    ...h(t)
  });
}
a(Ec, "_mime");
// @__NO_SIDE_EFFECTS__
function Ue(e) {
  return new _o({
    check: "overwrite",
    tx: e
  });
}
a(Ue, "_overwrite");
// @__NO_SIDE_EFFECTS__
function Zc(e) {
  return /* @__PURE__ */ Ue((t) => t.normalize(e));
}
a(Zc, "_normalize");
// @__NO_SIDE_EFFECTS__
function Nc() {
  return /* @__PURE__ */ Ue((e) => e.trim());
}
a(Nc, "_trim");
// @__NO_SIDE_EFFECTS__
function Ac() {
  return /* @__PURE__ */ Ue((e) => e.toLowerCase());
}
a(Ac, "_toLowerCase");
// @__NO_SIDE_EFFECTS__
function Cc() {
  return /* @__PURE__ */ Ue((e) => e.toUpperCase());
}
a(Cc, "_toUpperCase");
// @__NO_SIDE_EFFECTS__
function Yg() {
  return /* @__PURE__ */ Ue((e) => ci(e));
}
a(Yg, "_slugify");
// @__NO_SIDE_EFFECTS__
function eh(e, t, n) {
  return new e({
    type: "array",
    element: t,
    // get element() {
    //   return element;
    // },
    ...h(n)
  });
}
a(eh, "_array");
// @__NO_SIDE_EFFECTS__
function th(e, t, n) {
  return new e({
    type: "union",
    options: t,
    ...h(n)
  });
}
a(th, "_union");
function rh(e, t, n) {
  return new e({
    type: "union",
    options: t,
    inclusive: !1,
    ...h(n)
  });
}
a(rh, "_xor");
// @__NO_SIDE_EFFECTS__
function nh(e, t, n, o) {
  return new e({
    type: "union",
    options: n,
    discriminator: t,
    ...h(o)
  });
}
a(nh, "_discriminatedUnion");
// @__NO_SIDE_EFFECTS__
function ih(e, t, n) {
  return new e({
    type: "intersection",
    left: t,
    right: n
  });
}
a(ih, "_intersection");
// @__NO_SIDE_EFFECTS__
function oh(e, t, n, o) {
  let r = n instanceof _, i = r ? o : n, s = r ? n : null;
  return new e({
    type: "tuple",
    items: t,
    rest: s,
    ...h(i)
  });
}
a(oh, "_tuple");
// @__NO_SIDE_EFFECTS__
function ah(e, t, n, o) {
  return new e({
    type: "record",
    keyType: t,
    valueType: n,
    ...h(o)
  });
}
a(ah, "_record");
// @__NO_SIDE_EFFECTS__
function sh(e, t, n, o) {
  return new e({
    type: "map",
    keyType: t,
    valueType: n,
    ...h(o)
  });
}
a(sh, "_map");
// @__NO_SIDE_EFFECTS__
function ch(e, t, n) {
  return new e({
    type: "set",
    valueType: t,
    ...h(n)
  });
}
a(ch, "_set");
// @__NO_SIDE_EFFECTS__
function uh(e, t, n) {
  let o = Array.isArray(t) ? Object.fromEntries(t.map((r) => [r, r])) : t;
  return new e({
    type: "enum",
    entries: o,
    ...h(n)
  });
}
a(uh, "_enum");
// @__NO_SIDE_EFFECTS__
function lh(e, t, n) {
  return new e({
    type: "enum",
    entries: t,
    ...h(n)
  });
}
a(lh, "_nativeEnum");
// @__NO_SIDE_EFFECTS__
function dh(e, t, n) {
  return new e({
    type: "literal",
    values: Array.isArray(t) ? t : [t],
    ...h(n)
  });
}
a(dh, "_literal");
// @__NO_SIDE_EFFECTS__
function Rc(e, t) {
  return new e({
    type: "file",
    ...h(t)
  });
}
a(Rc, "_file");
// @__NO_SIDE_EFFECTS__
function fh(e, t) {
  return new e({
    type: "transform",
    transform: t
  });
}
a(fh, "_transform");
// @__NO_SIDE_EFFECTS__
function ph(e, t) {
  return new e({
    type: "optional",
    innerType: t
  });
}
a(ph, "_optional");
// @__NO_SIDE_EFFECTS__
function mh(e, t) {
  return new e({
    type: "nullable",
    innerType: t
  });
}
a(mh, "_nullable");
// @__NO_SIDE_EFFECTS__
function gh(e, t, n) {
  return new e({
    type: "default",
    innerType: t,
    get defaultValue() {
      return typeof n == "function" ? n() : at(n);
    }
  });
}
a(gh, "_default");
// @__NO_SIDE_EFFECTS__
function hh(e, t, n) {
  return new e({
    type: "nonoptional",
    innerType: t,
    ...h(n)
  });
}
a(hh, "_nonoptional");
// @__NO_SIDE_EFFECTS__
function vh(e, t) {
  return new e({
    type: "success",
    innerType: t
  });
}
a(vh, "_success");
// @__NO_SIDE_EFFECTS__
function yh(e, t, n) {
  return new e({
    type: "catch",
    innerType: t,
    catchValue: typeof n == "function" ? n : () => n
  });
}
a(yh, "_catch");
// @__NO_SIDE_EFFECTS__
function bh(e, t, n) {
  return new e({
    type: "pipe",
    in: t,
    out: n
  });
}
a(bh, "_pipe");
// @__NO_SIDE_EFFECTS__
function xh(e, t) {
  return new e({
    type: "readonly",
    innerType: t
  });
}
a(xh, "_readonly");
// @__NO_SIDE_EFFECTS__
function $h(e, t, n) {
  return new e({
    type: "template_literal",
    parts: t,
    ...h(n)
  });
}
a($h, "_templateLiteral");
// @__NO_SIDE_EFFECTS__
function _h(e, t) {
  return new e({
    type: "lazy",
    getter: t
  });
}
a(_h, "_lazy");
// @__NO_SIDE_EFFECTS__
function wh(e, t) {
  return new e({
    type: "promise",
    innerType: t
  });
}
a(wh, "_promise");
// @__NO_SIDE_EFFECTS__
function Fc(e, t, n) {
  let o = h(n);
  return o.abort ?? (o.abort = !0), new e({
    type: "custom",
    check: "custom",
    fn: t,
    ...o
  });
}
a(Fc, "_custom");
// @__NO_SIDE_EFFECTS__
function Mc(e, t, n) {
  return new e({
    type: "custom",
    check: "custom",
    fn: t,
    ...h(n)
  });
}
a(Mc, "_refine");
// @__NO_SIDE_EFFECTS__
function Lc(e) {
  let t = /* @__PURE__ */ Kl((n) => (n.addIssue = (o) => {
    if (typeof o == "string")
      n.issues.push(st(o, n.value, t._zod.def));
    else {
      let r = o;
      r.fatal && (r.continue = !1), r.code ?? (r.code = "custom"), r.input ?? (r.input = n.value), r.inst ?? (r.inst = t), r.continue ?? (r.continue = !t._zod.def.abort), n.issues.push(st(r));
    }
  }, e(n.value, n)));
  return t;
}
a(Lc, "_superRefine");
// @__NO_SIDE_EFFECTS__
function Kl(e, t) {
  let n = new N({
    check: "custom",
    ...h(t)
  });
  return n._zod.check = e, n;
}
a(Kl, "_check");
// @__NO_SIDE_EFFECTS__
function Bc(e) {
  let t = new N({ check: "describe" });
  return t._zod.onattach = [
    (n) => {
      let o = he.get(n) ?? {};
      he.add(n, { ...o, description: e });
    }
  ], t._zod.check = () => {
  }, t;
}
a(Bc, "describe");
// @__NO_SIDE_EFFECTS__
function Vc(e) {
  let t = new N({ check: "meta" });
  return t._zod.onattach = [
    (n) => {
      let o = he.get(n) ?? {};
      he.add(n, { ...o, ...e });
    }
  ], t._zod.check = () => {
  }, t;
}
a(Vc, "meta");
// @__NO_SIDE_EFFECTS__
function qc(e, t) {
  let n = h(t), o = n.truthy ?? ["true", "1", "yes", "on", "y", "enabled"], r = n.falsy ?? ["false", "0", "no", "off", "n", "disabled"];
  n.case !== "sensitive" && (o = o.map((x) => typeof x == "string" ? x.toLowerCase() : x), r = r.map((x) => typeof x == "string" ? x.toLowerCase() : x));
  let i = new Set(o), s = new Set(r), c = e.Codec ?? ge, u = e.Boolean ?? Ft, l = e.String ?? ut, d = new l({ type: "string", error: n.error }), g = new u({ type: "boolean", error: n.error }), b = new c({
    type: "pipe",
    in: d,
    out: g,
    transform: /* @__PURE__ */ a(((x, j) => {
      let z = x;
      return n.case !== "sensitive" && (z = z.toLowerCase()), i.has(z) ? !0 : s.has(z) ? !1 : (j.issues.push({
        code: "invalid_value",
        expected: "stringbool",
        values: [...i, ...s],
        input: j.value,
        inst: b,
        continue: !1
      }), {});
    }), "transform"),
    reverseTransform: /* @__PURE__ */ a(((x, j) => x === !0 ? o[0] || "true" : r[0] || "false"), "reverseTransform"),
    error: n.error
  });
  return b;
}
a(qc, "_stringbool");
// @__NO_SIDE_EFFECTS__
function gt(e, t, n, o = {}) {
  let r = h(o), i = {
    ...h(o),
    check: "string_format",
    type: "string",
    format: t,
    fn: typeof n == "function" ? n : (c) => n.test(c),
    ...r
  };
  return n instanceof RegExp && (i.pattern = n), new e(i);
}
a(gt, "_stringFormat");

// versions/4.3.6/node_modules/zod/v4/core/to-json-schema.js
function De(e) {
  let t = e?.target ?? "draft-2020-12";
  return t === "draft-4" && (t = "draft-04"), t === "draft-7" && (t = "draft-07"), {
    processors: e.processors ?? {},
    metadataRegistry: e?.metadata ?? he,
    target: t,
    unrepresentable: e?.unrepresentable ?? "throw",
    override: e?.override ?? (() => {
    }),
    io: e?.io ?? "output",
    counter: 0,
    seen: /* @__PURE__ */ new Map(),
    cycles: e?.cycles ?? "ref",
    reused: e?.reused ?? "inline",
    external: e?.external ?? void 0
  };
}
a(De, "initializeContext");
function U(e, t, n = { path: [], schemaPath: [] }) {
  var o;
  let r = e._zod.def, i = t.seen.get(e);
  if (i)
    return i.count++, n.schemaPath.includes(e) && (i.cycle = n.path), i.schema;
  let s = { schema: {}, count: 1, cycle: void 0, path: n.path };
  t.seen.set(e, s);
  let c = e._zod.toJSONSchema?.();
  if (c)
    s.schema = c;
  else {
    let d = {
      ...n,
      schemaPath: [...n.schemaPath, e],
      path: n.path
    };
    if (e._zod.processJSONSchema)
      e._zod.processJSONSchema(t, s.schema, d);
    else {
      let b = s.schema, x = t.processors[r.type];
      if (!x)
        throw new Error(`[toJSONSchema]: Non-representable type encountered: ${r.type}`);
      x(e, t, b, d);
    }
    let g = e._zod.parent;
    g && (s.ref || (s.ref = g), U(g, t, d), t.seen.get(g).isParent = !0);
  }
  let u = t.metadataRegistry.get(e);
  return u && Object.assign(s.schema, u), t.io === "input" && ee(e) && (delete s.schema.examples, delete s.schema.default), t.io === "input" && s.schema._prefault && ((o = s.schema).default ?? (o.default = s.schema._prefault)), delete s.schema._prefault, t.seen.get(e).schema;
}
a(U, "process");
function Ee(e, t) {
  let n = e.seen.get(t);
  if (!n)
    throw new Error("Unprocessed schema. This is a bug in Zod.");
  let o = /* @__PURE__ */ new Map();
  for (let s of e.seen.entries()) {
    let c = e.metadataRegistry.get(s[0])?.id;
    if (c) {
      let u = o.get(c);
      if (u && u !== s[0])
        throw new Error(`Duplicate schema id "${c}" detected during JSON Schema conversion. Two different schemas cannot share the same id when converted together.`);
      o.set(c, s[0]);
    }
  }
  let r = /* @__PURE__ */ a((s) => {
    let c = e.target === "draft-2020-12" ? "$defs" : "definitions";
    if (e.external) {
      let g = e.external.registry.get(s[0])?.id, b = e.external.uri ?? ((j) => j);
      if (g)
        return { ref: b(g) };
      let x = s[1].defId ?? s[1].schema.id ?? `schema${e.counter++}`;
      return s[1].defId = x, { defId: x, ref: `${b("__shared")}#/${c}/${x}` };
    }
    if (s[1] === n)
      return { ref: "#" };
    let l = `#/${c}/`, d = s[1].schema.id ?? `__schema${e.counter++}`;
    return { defId: d, ref: l + d };
  }, "makeURI"), i = /* @__PURE__ */ a((s) => {
    if (s[1].schema.$ref)
      return;
    let c = s[1], { ref: u, defId: l } = r(s);
    c.def = { ...c.schema }, l && (c.defId = l);
    let d = c.schema;
    for (let g in d)
      delete d[g];
    d.$ref = u;
  }, "extractToDef");
  if (e.cycles === "throw")
    for (let s of e.seen.entries()) {
      let c = s[1];
      if (c.cycle)
        throw new Error(`Cycle detected: #/${c.cycle?.join("/")}/<root>

Set the \`cycles\` parameter to \`"ref"\` to resolve cyclical schemas with defs.`);
    }
  for (let s of e.seen.entries()) {
    let c = s[1];
    if (t === s[0]) {
      i(s);
      continue;
    }
    if (e.external) {
      let l = e.external.registry.get(s[0])?.id;
      if (t !== s[0] && l) {
        i(s);
        continue;
      }
    }
    if (e.metadataRegistry.get(s[0])?.id) {
      i(s);
      continue;
    }
    if (c.cycle) {
      i(s);
      continue;
    }
    if (c.count > 1 && e.reused === "ref") {
      i(s);
      continue;
    }
  }
}
a(Ee, "extractDefs");
function Ze(e, t) {
  let n = e.seen.get(t);
  if (!n)
    throw new Error("Unprocessed schema. This is a bug in Zod.");
  let o = /* @__PURE__ */ a((s) => {
    let c = e.seen.get(s);
    if (c.ref === null)
      return;
    let u = c.def ?? c.schema, l = { ...u }, d = c.ref;
    if (c.ref = null, d) {
      o(d);
      let b = e.seen.get(d), x = b.schema;
      if (x.$ref && (e.target === "draft-07" || e.target === "draft-04" || e.target === "openapi-3.0") ? (u.allOf = u.allOf ?? [], u.allOf.push(x)) : Object.assign(u, x), Object.assign(u, l), s._zod.parent === d)
        for (let z in u)
          z === "$ref" || z === "allOf" || z in l || delete u[z];
      if (x.$ref && b.def)
        for (let z in u)
          z === "$ref" || z === "allOf" || z in b.def && JSON.stringify(u[z]) === JSON.stringify(b.def[z]) && delete u[z];
    }
    let g = s._zod.parent;
    if (g && g !== d) {
      o(g);
      let b = e.seen.get(g);
      if (b?.schema.$ref && (u.$ref = b.schema.$ref, b.def))
        for (let x in u)
          x === "$ref" || x === "allOf" || x in b.def && JSON.stringify(u[x]) === JSON.stringify(b.def[x]) && delete u[x];
    }
    e.override({
      zodSchema: s,
      jsonSchema: u,
      path: c.path ?? []
    });
  }, "flattenRef");
  for (let s of [...e.seen.entries()].reverse())
    o(s[0]);
  let r = {};
  if (e.target === "draft-2020-12" ? r.$schema = "https://json-schema.org/draft/2020-12/schema" : e.target === "draft-07" ? r.$schema = "http://json-schema.org/draft-07/schema#" : e.target === "draft-04" ? r.$schema = "http://json-schema.org/draft-04/schema#" : e.target, e.external?.uri) {
    let s = e.external.registry.get(t)?.id;
    if (!s)
      throw new Error("Schema is missing an `id` property");
    r.$id = e.external.uri(s);
  }
  Object.assign(r, n.def ?? n.schema);
  let i = e.external?.defs ?? {};
  for (let s of e.seen.entries()) {
    let c = s[1];
    c.def && c.defId && (i[c.defId] = c.def);
  }
  e.external || Object.keys(i).length > 0 && (e.target === "draft-2020-12" ? r.$defs = i : r.definitions = i);
  try {
    let s = JSON.parse(JSON.stringify(r));
    return Object.defineProperty(s, "~standard", {
      value: {
        ...t["~standard"],
        jsonSchema: {
          input: Jc(t, "input", e.processors),
          output: Jc(t, "output", e.processors)
        }
      },
      enumerable: !1,
      writable: !1
    }), s;
  } catch {
    throw new Error("Error converting schema to JSON.");
  }
}
a(Ze, "finalize");
function ee(e, t) {
  let n = t ?? { seen: /* @__PURE__ */ new Set() };
  if (n.seen.has(e))
    return !1;
  n.seen.add(e);
  let o = e._zod.def;
  if (o.type === "transform")
    return !0;
  if (o.type === "array")
    return ee(o.element, n);
  if (o.type === "set")
    return ee(o.valueType, n);
  if (o.type === "lazy")
    return ee(o.getter(), n);
  if (o.type === "promise" || o.type === "optional" || o.type === "nonoptional" || o.type === "nullable" || o.type === "readonly" || o.type === "default" || o.type === "prefault")
    return ee(o.innerType, n);
  if (o.type === "intersection")
    return ee(o.left, n) || ee(o.right, n);
  if (o.type === "record" || o.type === "map")
    return ee(o.keyType, n) || ee(o.valueType, n);
  if (o.type === "pipe")
    return ee(o.in, n) || ee(o.out, n);
  if (o.type === "object") {
    for (let r in o.shape)
      if (ee(o.shape[r], n))
        return !0;
    return !1;
  }
  if (o.type === "union") {
    for (let r of o.options)
      if (ee(r, n))
        return !0;
    return !1;
  }
  if (o.type === "tuple") {
    for (let r of o.items)
      if (ee(r, n))
        return !0;
    return !!(o.rest && ee(o.rest, n));
  }
  return !1;
}
a(ee, "isTransforming");
var kh = /* @__PURE__ */ a((e, t = {}) => (n) => {
  let o = De({ ...n, processors: t });
  return U(e, o), Ee(o, e), Ze(o, e);
}, "createToJSONSchemaMethod"), Jc = /* @__PURE__ */ a((e, t, n = {}) => (o) => {
  let { libraryOptions: r, target: i } = o ?? {}, s = De({ ...r ?? {}, target: i, io: t, processors: n });
  return U(e, s), Ee(s, e), Ze(s, e);
}, "createStandardJSONSchemaMethod");

// versions/4.3.6/node_modules/zod/v4/core/json-schema-processors.js
var zh = {
  guid: "uuid",
  url: "uri",
  datetime: "date-time",
  json_string: "json-string",
  regex: ""
  // do not set
}, Ih = /* @__PURE__ */ a((e, t, n, o) => {
  let r = n;
  r.type = "string";
  let { minimum: i, maximum: s, format: c, patterns: u, contentEncoding: l } = e._zod.bag;
  if (typeof i == "number" && (r.minLength = i), typeof s == "number" && (r.maxLength = s), c && (r.format = zh[c] ?? c, r.format === "" && delete r.format, c === "time" && delete r.format), l && (r.contentEncoding = l), u && u.size > 0) {
    let d = [...u];
    d.length === 1 ? r.pattern = d[0].source : d.length > 1 && (r.allOf = [
      ...d.map((g) => ({
        ...t.target === "draft-07" || t.target === "draft-04" || t.target === "openapi-3.0" ? { type: "string" } : {},
        pattern: g.source
      }))
    ]);
  }
}, "stringProcessor"), Sh = /* @__PURE__ */ a((e, t, n, o) => {
  let r = n, { minimum: i, maximum: s, format: c, multipleOf: u, exclusiveMaximum: l, exclusiveMinimum: d } = e._zod.bag;
  typeof c == "string" && c.includes("int") ? r.type = "integer" : r.type = "number", typeof d == "number" && (t.target === "draft-04" || t.target === "openapi-3.0" ? (r.minimum = d, r.exclusiveMinimum = !0) : r.exclusiveMinimum = d), typeof i == "number" && (r.minimum = i, typeof d == "number" && t.target !== "draft-04" && (d >= i ? delete r.minimum : delete r.exclusiveMinimum)), typeof l == "number" && (t.target === "draft-04" || t.target === "openapi-3.0" ? (r.maximum = l, r.exclusiveMaximum = !0) : r.exclusiveMaximum = l), typeof s == "number" && (r.maximum = s, typeof l == "number" && t.target !== "draft-04" && (l <= s ? delete r.maximum : delete r.exclusiveMaximum)), typeof u == "number" && (r.multipleOf = u);
}, "numberProcessor"), jh = /* @__PURE__ */ a((e, t, n, o) => {
  n.type = "boolean";
}, "booleanProcessor"), Oh = /* @__PURE__ */ a((e, t, n, o) => {
  if (t.unrepresentable === "throw")
    throw new Error("BigInt cannot be represented in JSON Schema");
}, "bigintProcessor"), Th = /* @__PURE__ */ a((e, t, n, o) => {
  if (t.unrepresentable === "throw")
    throw new Error("Symbols cannot be represented in JSON Schema");
}, "symbolProcessor"), Ph = /* @__PURE__ */ a((e, t, n, o) => {
  t.target === "openapi-3.0" ? (n.type = "string", n.nullable = !0, n.enum = [null]) : n.type = "null";
}, "nullProcessor"), Uh = /* @__PURE__ */ a((e, t, n, o) => {
  if (t.unrepresentable === "throw")
    throw new Error("Undefined cannot be represented in JSON Schema");
}, "undefinedProcessor"), Dh = /* @__PURE__ */ a((e, t, n, o) => {
  if (t.unrepresentable === "throw")
    throw new Error("Void cannot be represented in JSON Schema");
}, "voidProcessor"), Eh = /* @__PURE__ */ a((e, t, n, o) => {
  n.not = {};
}, "neverProcessor"), Zh = /* @__PURE__ */ a((e, t, n, o) => {
}, "anyProcessor"), Nh = /* @__PURE__ */ a((e, t, n, o) => {
}, "unknownProcessor"), Ah = /* @__PURE__ */ a((e, t, n, o) => {
  if (t.unrepresentable === "throw")
    throw new Error("Date cannot be represented in JSON Schema");
}, "dateProcessor"), Ch = /* @__PURE__ */ a((e, t, n, o) => {
  let r = e._zod.def, i = Ut(r.entries);
  i.every((s) => typeof s == "number") && (n.type = "number"), i.every((s) => typeof s == "string") && (n.type = "string"), n.enum = i;
}, "enumProcessor"), Rh = /* @__PURE__ */ a((e, t, n, o) => {
  let r = e._zod.def, i = [];
  for (let s of r.values)
    if (s === void 0) {
      if (t.unrepresentable === "throw")
        throw new Error("Literal `undefined` cannot be represented in JSON Schema");
    } else if (typeof s == "bigint") {
      if (t.unrepresentable === "throw")
        throw new Error("BigInt literals cannot be represented in JSON Schema");
      i.push(Number(s));
    } else
      i.push(s);
  if (i.length !== 0)
    if (i.length === 1) {
      let s = i[0];
      n.type = s === null ? "null" : typeof s, t.target === "draft-04" || t.target === "openapi-3.0" ? n.enum = [s] : n.const = s;
    } else
      i.every((s) => typeof s == "number") && (n.type = "number"), i.every((s) => typeof s == "string") && (n.type = "string"), i.every((s) => typeof s == "boolean") && (n.type = "boolean"), i.every((s) => s === null) && (n.type = "null"), n.enum = i;
}, "literalProcessor"), Fh = /* @__PURE__ */ a((e, t, n, o) => {
  if (t.unrepresentable === "throw")
    throw new Error("NaN cannot be represented in JSON Schema");
}, "nanProcessor"), Mh = /* @__PURE__ */ a((e, t, n, o) => {
  let r = n, i = e._zod.pattern;
  if (!i)
    throw new Error("Pattern not found in template literal");
  r.type = "string", r.pattern = i.source;
}, "templateLiteralProcessor"), Lh = /* @__PURE__ */ a((e, t, n, o) => {
  let r = n, i = {
    type: "string",
    format: "binary",
    contentEncoding: "binary"
  }, { minimum: s, maximum: c, mime: u } = e._zod.bag;
  s !== void 0 && (i.minLength = s), c !== void 0 && (i.maxLength = c), u ? u.length === 1 ? (i.contentMediaType = u[0], Object.assign(r, i)) : (Object.assign(r, i), r.anyOf = u.map((l) => ({ contentMediaType: l }))) : Object.assign(r, i);
}, "fileProcessor"), Bh = /* @__PURE__ */ a((e, t, n, o) => {
  n.type = "boolean";
}, "successProcessor"), Vh = /* @__PURE__ */ a((e, t, n, o) => {
  if (t.unrepresentable === "throw")
    throw new Error("Custom types cannot be represented in JSON Schema");
}, "customProcessor"), qh = /* @__PURE__ */ a((e, t, n, o) => {
  if (t.unrepresentable === "throw")
    throw new Error("Function types cannot be represented in JSON Schema");
}, "functionProcessor"), Jh = /* @__PURE__ */ a((e, t, n, o) => {
  if (t.unrepresentable === "throw")
    throw new Error("Transforms cannot be represented in JSON Schema");
}, "transformProcessor"), Wh = /* @__PURE__ */ a((e, t, n, o) => {
  if (t.unrepresentable === "throw")
    throw new Error("Map cannot be represented in JSON Schema");
}, "mapProcessor"), Kh = /* @__PURE__ */ a((e, t, n, o) => {
  if (t.unrepresentable === "throw")
    throw new Error("Set cannot be represented in JSON Schema");
}, "setProcessor"), Gh = /* @__PURE__ */ a((e, t, n, o) => {
  let r = n, i = e._zod.def, { minimum: s, maximum: c } = e._zod.bag;
  typeof s == "number" && (r.minItems = s), typeof c == "number" && (r.maxItems = c), r.type = "array", r.items = U(i.element, t, { ...o, path: [...o.path, "items"] });
}, "arrayProcessor"), Xh = /* @__PURE__ */ a((e, t, n, o) => {
  let r = n, i = e._zod.def;
  r.type = "object", r.properties = {};
  let s = i.shape;
  for (let l in s)
    r.properties[l] = U(s[l], t, {
      ...o,
      path: [...o.path, "properties", l]
    });
  let c = new Set(Object.keys(s)), u = new Set([...c].filter((l) => {
    let d = i.shape[l]._zod;
    return t.io === "input" ? d.optin === void 0 : d.optout === void 0;
  }));
  u.size > 0 && (r.required = Array.from(u)), i.catchall?._zod.def.type === "never" ? r.additionalProperties = !1 : i.catchall ? i.catchall && (r.additionalProperties = U(i.catchall, t, {
    ...o,
    path: [...o.path, "additionalProperties"]
  })) : t.io === "output" && (r.additionalProperties = !1);
}, "objectProcessor"), Hh = /* @__PURE__ */ a((e, t, n, o) => {
  let r = e._zod.def, i = r.inclusive === !1, s = r.options.map((c, u) => U(c, t, {
    ...o,
    path: [...o.path, i ? "oneOf" : "anyOf", u]
  }));
  i ? n.oneOf = s : n.anyOf = s;
}, "unionProcessor"), Qh = /* @__PURE__ */ a((e, t, n, o) => {
  let r = e._zod.def, i = U(r.left, t, {
    ...o,
    path: [...o.path, "allOf", 0]
  }), s = U(r.right, t, {
    ...o,
    path: [...o.path, "allOf", 1]
  }), c = /* @__PURE__ */ a((l) => "allOf" in l && Object.keys(l).length === 1, "isSimpleIntersection"), u = [
    ...c(i) ? i.allOf : [i],
    ...c(s) ? s.allOf : [s]
  ];
  n.allOf = u;
}, "intersectionProcessor"), Yh = /* @__PURE__ */ a((e, t, n, o) => {
  let r = n, i = e._zod.def;
  r.type = "array";
  let s = t.target === "draft-2020-12" ? "prefixItems" : "items", c = t.target === "draft-2020-12" || t.target === "openapi-3.0" ? "items" : "additionalItems", u = i.items.map((b, x) => U(b, t, {
    ...o,
    path: [...o.path, s, x]
  })), l = i.rest ? U(i.rest, t, {
    ...o,
    path: [...o.path, c, ...t.target === "openapi-3.0" ? [i.items.length] : []]
  }) : null;
  t.target === "draft-2020-12" ? (r.prefixItems = u, l && (r.items = l)) : t.target === "openapi-3.0" ? (r.items = {
    anyOf: u
  }, l && r.items.anyOf.push(l), r.minItems = u.length, l || (r.maxItems = u.length)) : (r.items = u, l && (r.additionalItems = l));
  let { minimum: d, maximum: g } = e._zod.bag;
  typeof d == "number" && (r.minItems = d), typeof g == "number" && (r.maxItems = g);
}, "tupleProcessor"), ev = /* @__PURE__ */ a((e, t, n, o) => {
  let r = n, i = e._zod.def;
  r.type = "object";
  let s = i.keyType, u = s._zod.bag?.patterns;
  if (i.mode === "loose" && u && u.size > 0) {
    let d = U(i.valueType, t, {
      ...o,
      path: [...o.path, "patternProperties", "*"]
    });
    r.patternProperties = {};
    for (let g of u)
      r.patternProperties[g.source] = d;
  } else
    (t.target === "draft-07" || t.target === "draft-2020-12") && (r.propertyNames = U(i.keyType, t, {
      ...o,
      path: [...o.path, "propertyNames"]
    })), r.additionalProperties = U(i.valueType, t, {
      ...o,
      path: [...o.path, "additionalProperties"]
    });
  let l = s._zod.values;
  if (l) {
    let d = [...l].filter((g) => typeof g == "string" || typeof g == "number");
    d.length > 0 && (r.required = d);
  }
}, "recordProcessor"), tv = /* @__PURE__ */ a((e, t, n, o) => {
  let r = e._zod.def, i = U(r.innerType, t, o), s = t.seen.get(e);
  t.target === "openapi-3.0" ? (s.ref = r.innerType, n.nullable = !0) : n.anyOf = [i, { type: "null" }];
}, "nullableProcessor"), rv = /* @__PURE__ */ a((e, t, n, o) => {
  let r = e._zod.def;
  U(r.innerType, t, o);
  let i = t.seen.get(e);
  i.ref = r.innerType;
}, "nonoptionalProcessor"), nv = /* @__PURE__ */ a((e, t, n, o) => {
  let r = e._zod.def;
  U(r.innerType, t, o);
  let i = t.seen.get(e);
  i.ref = r.innerType, n.default = JSON.parse(JSON.stringify(r.defaultValue));
}, "defaultProcessor"), iv = /* @__PURE__ */ a((e, t, n, o) => {
  let r = e._zod.def;
  U(r.innerType, t, o);
  let i = t.seen.get(e);
  i.ref = r.innerType, t.io === "input" && (n._prefault = JSON.parse(JSON.stringify(r.defaultValue)));
}, "prefaultProcessor"), ov = /* @__PURE__ */ a((e, t, n, o) => {
  let r = e._zod.def;
  U(r.innerType, t, o);
  let i = t.seen.get(e);
  i.ref = r.innerType;
  let s;
  try {
    s = r.catchValue(void 0);
  } catch {
    throw new Error("Dynamic catch values are not supported in JSON Schema");
  }
  n.default = s;
}, "catchProcessor"), av = /* @__PURE__ */ a((e, t, n, o) => {
  let r = e._zod.def, i = t.io === "input" ? r.in._zod.def.type === "transform" ? r.out : r.in : r.out;
  U(i, t, o);
  let s = t.seen.get(e);
  s.ref = i;
}, "pipeProcessor"), sv = /* @__PURE__ */ a((e, t, n, o) => {
  let r = e._zod.def;
  U(r.innerType, t, o);
  let i = t.seen.get(e);
  i.ref = r.innerType, n.readOnly = !0;
}, "readonlyProcessor"), cv = /* @__PURE__ */ a((e, t, n, o) => {
  let r = e._zod.def;
  U(r.innerType, t, o);
  let i = t.seen.get(e);
  i.ref = r.innerType;
}, "promiseProcessor"), uv = /* @__PURE__ */ a((e, t, n, o) => {
  let r = e._zod.def;
  U(r.innerType, t, o);
  let i = t.seen.get(e);
  i.ref = r.innerType;
}, "optionalProcessor"), lv = /* @__PURE__ */ a((e, t, n, o) => {
  let r = e._zod.innerType;
  U(r, t, o);
  let i = t.seen.get(e);
  i.ref = r;
}, "lazyProcessor"), Hr = {
  string: Ih,
  number: Sh,
  boolean: jh,
  bigint: Oh,
  symbol: Th,
  null: Ph,
  undefined: Uh,
  void: Dh,
  never: Eh,
  any: Zh,
  unknown: Nh,
  date: Ah,
  enum: Ch,
  literal: Rh,
  nan: Fh,
  template_literal: Mh,
  file: Lh,
  success: Bh,
  custom: Vh,
  function: qh,
  transform: Jh,
  map: Wh,
  set: Kh,
  array: Gh,
  object: Xh,
  union: Hh,
  intersection: Qh,
  tuple: Yh,
  record: ev,
  nullable: tv,
  nonoptional: rv,
  default: nv,
  prefault: iv,
  catch: ov,
  pipe: av,
  readonly: sv,
  promise: cv,
  optional: uv,
  lazy: lv
};
function Qr(e, t) {
  if ("_idmap" in e) {
    let o = e, r = De({ ...t, processors: Hr }), i = {};
    for (let u of o._idmap.entries()) {
      let [l, d] = u;
      U(d, r);
    }
    let s = {}, c = {
      registry: o,
      uri: t?.uri,
      defs: i
    };
    r.external = c;
    for (let u of o._idmap.entries()) {
      let [l, d] = u;
      Ee(r, d), s[l] = Ze(r, d);
    }
    if (Object.keys(i).length > 0) {
      let u = r.target === "draft-2020-12" ? "$defs" : "definitions";
      s.__shared = {
        [u]: i
      };
    }
    return { schemas: s };
  }
  let n = De({ ...t, processors: Hr });
  return U(e, n), Ee(n, e), Ze(n, e);
}
a(Qr, "toJSONSchema");

// versions/4.3.6/node_modules/zod/v4/core/json-schema-generator.js
var Yr = class {
  static {
    a(this, "JSONSchemaGenerator");
  }
  /** @deprecated Access via ctx instead */
  get metadataRegistry() {
    return this.ctx.metadataRegistry;
  }
  /** @deprecated Access via ctx instead */
  get target() {
    return this.ctx.target;
  }
  /** @deprecated Access via ctx instead */
  get unrepresentable() {
    return this.ctx.unrepresentable;
  }
  /** @deprecated Access via ctx instead */
  get override() {
    return this.ctx.override;
  }
  /** @deprecated Access via ctx instead */
  get io() {
    return this.ctx.io;
  }
  /** @deprecated Access via ctx instead */
  get counter() {
    return this.ctx.counter;
  }
  set counter(t) {
    this.ctx.counter = t;
  }
  /** @deprecated Access via ctx instead */
  get seen() {
    return this.ctx.seen;
  }
  constructor(t) {
    let n = t?.target ?? "draft-2020-12";
    n === "draft-4" && (n = "draft-04"), n === "draft-7" && (n = "draft-07"), this.ctx = De({
      processors: Hr,
      target: n,
      ...t?.metadata && { metadata: t.metadata },
      ...t?.unrepresentable && { unrepresentable: t.unrepresentable },
      ...t?.override && { override: t.override },
      ...t?.io && { io: t.io }
    });
  }
  /**
   * Process a schema to prepare it for JSON Schema generation.
   * This must be called before emit().
   */
  process(t, n = { path: [], schemaPath: [] }) {
    return U(t, this.ctx, n);
  }
  /**
   * Emit the final JSON Schema after processing.
   * Must call process() first.
   */
  emit(t, n) {
    n && (n.cycles && (this.ctx.cycles = n.cycles), n.reused && (this.ctx.reused = n.reused), n.external && (this.ctx.external = n.external)), Ee(this.ctx, t);
    let o = Ze(this.ctx, t), { "~standard": r, ...i } = o;
    return i;
  }
};

// versions/4.3.6/node_modules/zod/v4/core/json-schema.js
var Gl = {};

// versions/4.3.6/node_modules/zod/v4/mini/schemas.js
var S = /* @__PURE__ */ f("ZodMiniType", (e, t) => {
  if (!e._zod)
    throw new Error("Uninitialized schema in ZodMiniType.");
  _.init(e, t), e.def = t, e.type = t.type, e.parse = (n, o) => ne(e, n, o, { callee: e.parse }), e.safeParse = (n, o) => me(e, n, o), e.parseAsync = async (n, o) => je(e, n, o, { callee: e.parseAsync }), e.safeParseAsync = async (n, o) => qe(e, n, o), e.check = (...n) => e.clone({
    ...t,
    checks: [
      ...t.checks ?? [],
      ...n.map((o) => typeof o == "function" ? { _zod: { check: o, def: { check: "custom" }, onattach: [] } } : o)
    ]
  }, { parent: !0 }), e.with = e.check, e.clone = (n, o) => V(e, n, o), e.brand = () => e, e.register = ((n, o) => (n.add(e, o), e)), e.apply = (n) => n(e);
}), vt = /* @__PURE__ */ f("ZodMiniString", (e, t) => {
  ut.init(e, t), S.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Kt(e) {
  return ys(vt, e);
}
a(Kt, "string");
var A = /* @__PURE__ */ f("ZodMiniStringFormat", (e, t) => {
  E.init(e, t), vt.init(e, t);
}), Xl = /* @__PURE__ */ f("ZodMiniEmail", (e, t) => {
  So.init(e, t), A.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function fv(e) {
  return xs(Xl, e);
}
a(fv, "email");
var Hl = /* @__PURE__ */ f("ZodMiniGUID", (e, t) => {
  zo.init(e, t), A.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function pv(e) {
  return $s(Hl, e);
}
a(pv, "guid");
var Gt = /* @__PURE__ */ f("ZodMiniUUID", (e, t) => {
  Io.init(e, t), A.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function mv(e) {
  return _s(Gt, e);
}
a(mv, "uuid");
// @__NO_SIDE_EFFECTS__
function gv(e) {
  return ws(Gt, e);
}
a(gv, "uuidv4");
// @__NO_SIDE_EFFECTS__
function hv(e) {
  return ks(Gt, e);
}
a(hv, "uuidv6");
// @__NO_SIDE_EFFECTS__
function vv(e) {
  return zs(Gt, e);
}
a(vv, "uuidv7");
var Wc = /* @__PURE__ */ f("ZodMiniURL", (e, t) => {
  jo.init(e, t), A.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function yv(e) {
  return Kr(Wc, e);
}
a(yv, "url");
// @__NO_SIDE_EFFECTS__
function bv(e) {
  return Kr(Wc, {
    protocol: /^https?$/,
    hostname: le.domain,
    ...h(e)
  });
}
a(bv, "httpUrl");
var Ql = /* @__PURE__ */ f("ZodMiniEmoji", (e, t) => {
  Oo.init(e, t), A.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function xv(e) {
  return Is(Ql, e);
}
a(xv, "emoji");
var Yl = /* @__PURE__ */ f("ZodMiniNanoID", (e, t) => {
  To.init(e, t), A.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function $v(e) {
  return Ss(Yl, e);
}
a($v, "nanoid");
var ed = /* @__PURE__ */ f("ZodMiniCUID", (e, t) => {
  Po.init(e, t), A.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function _v(e) {
  return js(ed, e);
}
a(_v, "cuid");
var td = /* @__PURE__ */ f("ZodMiniCUID2", (e, t) => {
  Uo.init(e, t), A.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function wv(e) {
  return Os(td, e);
}
a(wv, "cuid2");
var rd = /* @__PURE__ */ f("ZodMiniULID", (e, t) => {
  Do.init(e, t), A.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function kv(e) {
  return Ts(rd, e);
}
a(kv, "ulid");
var nd = /* @__PURE__ */ f("ZodMiniXID", (e, t) => {
  Eo.init(e, t), A.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function zv(e) {
  return Ps(nd, e);
}
a(zv, "xid");
var id = /* @__PURE__ */ f("ZodMiniKSUID", (e, t) => {
  Zo.init(e, t), A.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Iv(e) {
  return Us(id, e);
}
a(Iv, "ksuid");
var od = /* @__PURE__ */ f("ZodMiniIPv4", (e, t) => {
  Fo.init(e, t), A.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Sv(e) {
  return Ds(od, e);
}
a(Sv, "ipv4");
var ad = /* @__PURE__ */ f("ZodMiniIPv6", (e, t) => {
  Mo.init(e, t), A.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function jv(e) {
  return Es(ad, e);
}
a(jv, "ipv6");
var sd = /* @__PURE__ */ f("ZodMiniCIDRv4", (e, t) => {
  Bo.init(e, t), A.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Ov(e) {
  return Ns(sd, e);
}
a(Ov, "cidrv4");
var cd = /* @__PURE__ */ f("ZodMiniCIDRv6", (e, t) => {
  Vo.init(e, t), A.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Tv(e) {
  return As(cd, e);
}
a(Tv, "cidrv6");
var ud = /* @__PURE__ */ f("ZodMiniMAC", (e, t) => {
  Lo.init(e, t), A.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Pv(e) {
  return Zs(ud, e);
}
a(Pv, "mac");
var ld = /* @__PURE__ */ f("ZodMiniBase64", (e, t) => {
  Jo.init(e, t), A.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Uv(e) {
  return Cs(ld, e);
}
a(Uv, "base64");
var dd = /* @__PURE__ */ f("ZodMiniBase64URL", (e, t) => {
  Wo.init(e, t), A.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Dv(e) {
  return Rs(dd, e);
}
a(Dv, "base64url");
var fd = /* @__PURE__ */ f("ZodMiniE164", (e, t) => {
  Ko.init(e, t), A.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Ev(e) {
  return Fs(fd, e);
}
a(Ev, "e164");
var pd = /* @__PURE__ */ f("ZodMiniJWT", (e, t) => {
  Go.init(e, t), A.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Zv(e) {
  return Ms(pd, e);
}
a(Zv, "jwt");
var Xt = /* @__PURE__ */ f("ZodMiniCustomStringFormat", (e, t) => {
  Xo.init(e, t), A.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Nv(e, t, n = {}) {
  return gt(Xt, e, t, n);
}
a(Nv, "stringFormat");
// @__NO_SIDE_EFFECTS__
function Av(e) {
  return gt(Xt, "hostname", le.hostname, e);
}
a(Av, "hostname");
// @__NO_SIDE_EFFECTS__
function Cv(e) {
  return gt(Xt, "hex", le.hex, e);
}
a(Cv, "hex");
// @__NO_SIDE_EFFECTS__
function Rv(e, t) {
  let n = t?.enc ?? "hex", o = `${e}_${n}`, r = le[o];
  if (!r)
    throw new Error(`Unrecognized hash format: ${o}`);
  return gt(Xt, o, r, t);
}
a(Rv, "hash");
var Ht = /* @__PURE__ */ f("ZodMiniNumber", (e, t) => {
  Vr.init(e, t), S.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function tn(e) {
  return Ws(Ht, e);
}
a(tn, "number");
var yt = /* @__PURE__ */ f("ZodMiniNumberFormat", (e, t) => {
  Ho.init(e, t), Ht.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Fv(e) {
  return Gs(yt, e);
}
a(Fv, "int");
// @__NO_SIDE_EFFECTS__
function Mv(e) {
  return Xs(yt, e);
}
a(Mv, "float32");
// @__NO_SIDE_EFFECTS__
function Lv(e) {
  return Hs(yt, e);
}
a(Lv, "float64");
// @__NO_SIDE_EFFECTS__
function Bv(e) {
  return Qs(yt, e);
}
a(Bv, "int32");
// @__NO_SIDE_EFFECTS__
function Vv(e) {
  return Ys(yt, e);
}
a(Vv, "uint32");
var Qt = /* @__PURE__ */ f("ZodMiniBoolean", (e, t) => {
  Ft.init(e, t), S.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function rn(e) {
  return ec(Qt, e);
}
a(rn, "boolean");
var Yt = /* @__PURE__ */ f("ZodMiniBigInt", (e, t) => {
  qr.init(e, t), S.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function qv(e) {
  return rc(Yt, e);
}
a(qv, "bigint");
var Kc = /* @__PURE__ */ f("ZodMiniBigIntFormat", (e, t) => {
  Qo.init(e, t), Yt.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Jv(e) {
  return ic(Kc, e);
}
a(Jv, "int64");
// @__NO_SIDE_EFFECTS__
function Wv(e) {
  return oc(Kc, e);
}
a(Wv, "uint64");
var md = /* @__PURE__ */ f("ZodMiniSymbol", (e, t) => {
  Yo.init(e, t), S.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Kv(e) {
  return ac(md, e);
}
a(Kv, "symbol");
var gd = /* @__PURE__ */ f("ZodMiniUndefined", (e, t) => {
  ea.init(e, t), S.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Gv(e) {
  return sc(gd, e);
}
a(Gv, "_undefined");
var hd = /* @__PURE__ */ f("ZodMiniNull", (e, t) => {
  ta.init(e, t), S.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function vd(e) {
  return cc(hd, e);
}
a(vd, "_null");
var yd = /* @__PURE__ */ f("ZodMiniAny", (e, t) => {
  ra.init(e, t), S.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Xv() {
  return uc(yd);
}
a(Xv, "any");
var bd = /* @__PURE__ */ f("ZodMiniUnknown", (e, t) => {
  na.init(e, t), S.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function en() {
  return lc(bd);
}
a(en, "unknown");
var xd = /* @__PURE__ */ f("ZodMiniNever", (e, t) => {
  ia.init(e, t), S.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function $d(e) {
  return dc(xd, e);
}
a($d, "never");
var _d = /* @__PURE__ */ f("ZodMiniVoid", (e, t) => {
  oa.init(e, t), S.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Hv(e) {
  return fc(_d, e);
}
a(Hv, "_void");
var nn = /* @__PURE__ */ f("ZodMiniDate", (e, t) => {
  lt.init(e, t), S.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Gc(e) {
  return pc(nn, e);
}
a(Gc, "date");
var wd = /* @__PURE__ */ f("ZodMiniArray", (e, t) => {
  Oe.init(e, t), S.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function er(e, t) {
  return new wd({
    type: "array",
    element: e,
    ...h(t)
  });
}
a(er, "array");
// @__NO_SIDE_EFFECTS__
function Qv(e) {
  let t = e._zod.def.shape;
  return /* @__PURE__ */ Ud(Object.keys(t));
}
a(Qv, "keyof");
var on = /* @__PURE__ */ f("ZodMiniObject", (e, t) => {
  L.init(e, t), S.init(e, t), I(e, "shape", () => t.shape);
});
// @__NO_SIDE_EFFECTS__
function Xc(e, t) {
  let n = {
    type: "object",
    shape: e ?? {},
    ...h(t)
  };
  return new on(n);
}
a(Xc, "object");
// @__NO_SIDE_EFFECTS__
function Yv(e, t) {
  return new on({
    type: "object",
    shape: e,
    catchall: /* @__PURE__ */ $d(),
    ...h(t)
  });
}
a(Yv, "strictObject");
// @__NO_SIDE_EFFECTS__
function ey(e, t) {
  return new on({
    type: "object",
    shape: e,
    catchall: /* @__PURE__ */ en(),
    ...h(t)
  });
}
a(ey, "looseObject");
// @__NO_SIDE_EFFECTS__
function ty(e, t) {
  return Tr(e, t);
}
a(ty, "extend");
// @__NO_SIDE_EFFECTS__
function ry(e, t) {
  return hi(e, t);
}
a(ry, "safeExtend");
// @__NO_SIDE_EFFECTS__
function ny(e, t) {
  return Tr(e, t);
}
a(ny, "merge");
// @__NO_SIDE_EFFECTS__
function iy(e, t) {
  return mi(e, t);
}
a(iy, "pick");
// @__NO_SIDE_EFFECTS__
function oy(e, t) {
  return gi(e, t);
}
a(oy, "omit");
// @__NO_SIDE_EFFECTS__
function ay(e, t) {
  return vi(Yc, e, t);
}
a(ay, "partial");
// @__NO_SIDE_EFFECTS__
function sy(e, t) {
  return yi(eu, e, t);
}
a(sy, "required");
// @__NO_SIDE_EFFECTS__
function cy(e, t) {
  return e.clone({ ...e._zod.def, catchall: t });
}
a(cy, "catchall");
var Hc = /* @__PURE__ */ f("ZodMiniUnion", (e, t) => {
  Y.init(e, t), S.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function an(e, t) {
  return new Hc({
    type: "union",
    options: e,
    ...h(t)
  });
}
a(an, "union");
var kd = /* @__PURE__ */ f("ZodMiniXor", (e, t) => {
  Hc.init(e, t), aa.init(e, t);
});
function uy(e, t) {
  return new kd({
    type: "union",
    options: e,
    inclusive: !1,
    ...h(t)
  });
}
a(uy, "xor");
var zd = /* @__PURE__ */ f("ZodMiniDiscriminatedUnion", (e, t) => {
  Te.init(e, t), S.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function ly(e, t, n) {
  return new zd({
    type: "union",
    options: t,
    discriminator: e,
    ...h(n)
  });
}
a(ly, "discriminatedUnion");
var Id = /* @__PURE__ */ f("ZodMiniIntersection", (e, t) => {
  sa.init(e, t), S.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function dy(e, t) {
  return new Id({
    type: "intersection",
    left: e,
    right: t
  });
}
a(dy, "intersection");
var Sd = /* @__PURE__ */ f("ZodMiniTuple", (e, t) => {
  Pe.init(e, t), S.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function jd(e, t, n) {
  let o = t instanceof _, r = o ? n : t, i = o ? t : null;
  return new Sd({
    type: "tuple",
    items: e,
    rest: i,
    ...h(r)
  });
}
a(jd, "tuple");
var sn = /* @__PURE__ */ f("ZodMiniRecord", (e, t) => {
  We.init(e, t), S.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Od(e, t, n) {
  return new sn({
    type: "record",
    keyType: e,
    valueType: t,
    ...h(n)
  });
}
a(Od, "record");
// @__NO_SIDE_EFFECTS__
function fy(e, t, n) {
  let o = V(e);
  return o._zod.values = void 0, new sn({
    type: "record",
    keyType: o,
    valueType: t,
    ...h(n)
  });
}
a(fy, "partialRecord");
function py(e, t, n) {
  return new sn({
    type: "record",
    keyType: e,
    valueType: t,
    mode: "loose",
    ...h(n)
  });
}
a(py, "looseRecord");
var Td = /* @__PURE__ */ f("ZodMiniMap", (e, t) => {
  ca.init(e, t), S.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function my(e, t, n) {
  return new Td({
    type: "map",
    keyType: e,
    valueType: t,
    ...h(n)
  });
}
a(my, "map");
var Pd = /* @__PURE__ */ f("ZodMiniSet", (e, t) => {
  ua.init(e, t), S.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function gy(e, t) {
  return new Pd({
    type: "set",
    valueType: e,
    ...h(t)
  });
}
a(gy, "set");
var Qc = /* @__PURE__ */ f("ZodMiniEnum", (e, t) => {
  dt.init(e, t), S.init(e, t), e.options = Object.values(t.entries);
});
// @__NO_SIDE_EFFECTS__
function Ud(e, t) {
  let n = Array.isArray(e) ? Object.fromEntries(e.map((o) => [o, o])) : e;
  return new Qc({
    type: "enum",
    entries: n,
    ...h(t)
  });
}
a(Ud, "_enum");
// @__NO_SIDE_EFFECTS__
function hy(e, t) {
  return new Qc({
    type: "enum",
    entries: e,
    ...h(t)
  });
}
a(hy, "nativeEnum");
var Dd = /* @__PURE__ */ f("ZodMiniLiteral", (e, t) => {
  ft.init(e, t), S.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function vy(e, t) {
  return new Dd({
    type: "literal",
    values: Array.isArray(e) ? e : [e],
    ...h(t)
  });
}
a(vy, "literal");
var Ed = /* @__PURE__ */ f("ZodMiniFile", (e, t) => {
  la.init(e, t), S.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function yy(e) {
  return Rc(Ed, e);
}
a(yy, "file");
var Zd = /* @__PURE__ */ f("ZodMiniTransform", (e, t) => {
  da.init(e, t), S.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function by(e) {
  return new Zd({
    type: "transform",
    transform: e
  });
}
a(by, "transform");
var Yc = /* @__PURE__ */ f("ZodMiniOptional", (e, t) => {
  F.init(e, t), S.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function cn(e) {
  return new Yc({
    type: "optional",
    innerType: e
  });
}
a(cn, "optional");
var Nd = /* @__PURE__ */ f("ZodMiniExactOptional", (e, t) => {
  fa.init(e, t), S.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function xy(e) {
  return new Nd({
    type: "optional",
    innerType: e
  });
}
a(xy, "exactOptional");
var Ad = /* @__PURE__ */ f("ZodMiniNullable", (e, t) => {
  de.init(e, t), S.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function un(e) {
  return new Ad({
    type: "nullable",
    innerType: e
  });
}
a(un, "nullable");
// @__NO_SIDE_EFFECTS__
function $y(e) {
  return /* @__PURE__ */ cn(/* @__PURE__ */ un(e));
}
a($y, "nullish");
var Cd = /* @__PURE__ */ f("ZodMiniDefault", (e, t) => {
  ae.init(e, t), S.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function _y(e, t) {
  return new Cd({
    type: "default",
    innerType: e,
    get defaultValue() {
      return typeof t == "function" ? t() : at(t);
    }
  });
}
a(_y, "_default");
var Rd = /* @__PURE__ */ f("ZodMiniPrefault", (e, t) => {
  pa.init(e, t), S.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function wy(e, t) {
  return new Rd({
    type: "prefault",
    innerType: e,
    get defaultValue() {
      return typeof t == "function" ? t() : at(t);
    }
  });
}
a(wy, "prefault");
var eu = /* @__PURE__ */ f("ZodMiniNonOptional", (e, t) => {
  ma.init(e, t), S.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function ky(e, t) {
  return new eu({
    type: "nonoptional",
    innerType: e,
    ...h(t)
  });
}
a(ky, "nonoptional");
var Fd = /* @__PURE__ */ f("ZodMiniSuccess", (e, t) => {
  ga.init(e, t), S.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function zy(e) {
  return new Fd({
    type: "success",
    innerType: e
  });
}
a(zy, "success");
var Md = /* @__PURE__ */ f("ZodMiniCatch", (e, t) => {
  ha.init(e, t), S.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Iy(e, t) {
  return new Md({
    type: "catch",
    innerType: e,
    catchValue: typeof t == "function" ? t : () => t
  });
}
a(Iy, "_catch");
var Ld = /* @__PURE__ */ f("ZodMiniNaN", (e, t) => {
  va.init(e, t), S.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Sy(e) {
  return gc(Ld, e);
}
a(Sy, "nan");
var tu = /* @__PURE__ */ f("ZodMiniPipe", (e, t) => {
  ya.init(e, t), S.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function jy(e, t) {
  return new tu({
    type: "pipe",
    in: e,
    out: t
  });
}
a(jy, "pipe");
var ru = /* @__PURE__ */ f("ZodMiniCodec", (e, t) => {
  tu.init(e, t), ge.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function nu(e, t, n) {
  return new ru({
    type: "pipe",
    in: e,
    out: t,
    transform: n.decode,
    reverseTransform: n.encode
  });
}
a(nu, "codec");
var Bd = /* @__PURE__ */ f("ZodMiniReadonly", (e, t) => {
  ba.init(e, t), S.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Oy(e) {
  return new Bd({
    type: "readonly",
    innerType: e
  });
}
a(Oy, "readonly");
var Vd = /* @__PURE__ */ f("ZodMiniTemplateLiteral", (e, t) => {
  xa.init(e, t), S.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Ty(e, t) {
  return new Vd({
    type: "template_literal",
    parts: e,
    ...h(t)
  });
}
a(Ty, "templateLiteral");
var qd = /* @__PURE__ */ f("ZodMiniLazy", (e, t) => {
  pt.init(e, t), S.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Jd(e) {
  return new qd({
    type: "lazy",
    getter: e
  });
}
a(Jd, "_lazy");
var Wd = /* @__PURE__ */ f("ZodMiniPromise", (e, t) => {
  _a.init(e, t), S.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Py(e) {
  return new Wd({
    type: "promise",
    innerType: e
  });
}
a(Py, "promise");
var iu = /* @__PURE__ */ f("ZodMiniCustom", (e, t) => {
  Mt.init(e, t), S.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Uy(e, t) {
  let n = new N({
    check: "custom",
    ...h(t)
  });
  return n._zod.check = e, n;
}
a(Uy, "check");
// @__NO_SIDE_EFFECTS__
function Kd(e, t) {
  return Fc(iu, e ?? (() => !0), t);
}
a(Kd, "custom");
// @__NO_SIDE_EFFECTS__
function Dy(e, t = {}) {
  return Mc(iu, e, t);
}
a(Dy, "refine");
// @__NO_SIDE_EFFECTS__
function Ey(e) {
  return Lc(e);
}
a(Ey, "superRefine");
var Zy = Bc, Ny = Vc;
// @__NO_SIDE_EFFECTS__
function ou(e, t = {}) {
  let n = /* @__PURE__ */ Kd((o) => o instanceof e, t);
  return n._zod.bag.Class = e, n._zod.check = (o) => {
    o.value instanceof e || o.issues.push({
      code: "invalid_type",
      expected: e.name,
      input: o.value,
      inst: n,
      path: [...n._zod.def.path ?? []]
    });
  }, n;
}
a(ou, "_instanceof");
var Ay = /* @__PURE__ */ a((...e) => qc({
  Codec: ru,
  Boolean: Qt,
  String: vt
}, ...e), "stringbool");
// @__NO_SIDE_EFFECTS__
function Cy() {
  let e = /* @__PURE__ */ Jd(() => /* @__PURE__ */ an([/* @__PURE__ */ Kt(), /* @__PURE__ */ tn(), /* @__PURE__ */ rn(), /* @__PURE__ */ vd(), /* @__PURE__ */ er(e), /* @__PURE__ */ Od(/* @__PURE__ */ Kt(), e)]));
  return e;
}
a(Cy, "json");
var Gd = /* @__PURE__ */ f("ZodMiniFunction", (e, t) => {
  $a.init(e, t), S.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Ry(e) {
  return new Gd({
    type: "function",
    input: Array.isArray(e?.input) ? /* @__PURE__ */ jd(e?.input) : e?.input ?? /* @__PURE__ */ er(/* @__PURE__ */ en()),
    output: e?.output ?? /* @__PURE__ */ en()
  });
}
a(Ry, "_function");

// versions/4.3.6/node_modules/zod/v4/mini/iso.js
var au = {};
Ce(au, {
  ZodMiniISODate: () => dn,
  ZodMiniISODateTime: () => ln,
  ZodMiniISODuration: () => pn,
  ZodMiniISOTime: () => fn,
  date: () => My,
  datetime: () => Fy,
  duration: () => By,
  time: () => Ly
});
var ln = /* @__PURE__ */ f("ZodMiniISODateTime", (e, t) => {
  No.init(e, t), A.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Fy(e) {
  return Bs(ln, e);
}
a(Fy, "datetime");
var dn = /* @__PURE__ */ f("ZodMiniISODate", (e, t) => {
  Ao.init(e, t), A.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function My(e) {
  return Vs(dn, e);
}
a(My, "date");
var fn = /* @__PURE__ */ f("ZodMiniISOTime", (e, t) => {
  Co.init(e, t), A.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Ly(e) {
  return qs(fn, e);
}
a(Ly, "time");
var pn = /* @__PURE__ */ f("ZodMiniISODuration", (e, t) => {
  Ro.init(e, t), A.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function By(e) {
  return Js(pn, e);
}
a(By, "duration");

// versions/4.3.6/node_modules/zod/v4/mini/coerce.js
var su = {};
Ce(su, {
  bigint: () => Wy,
  boolean: () => Jy,
  date: () => Ky,
  number: () => qy,
  string: () => Vy
});
// @__NO_SIDE_EFFECTS__
function Vy(e) {
  return bs(vt, e);
}
a(Vy, "string");
// @__NO_SIDE_EFFECTS__
function qy(e) {
  return Ks(Ht, e);
}
a(qy, "number");
// @__NO_SIDE_EFFECTS__
function Jy(e) {
  return tc(Qt, e);
}
a(Jy, "boolean");
// @__NO_SIDE_EFFECTS__
function Wy(e) {
  return nc(Yt, e);
}
a(Wy, "bigint");
// @__NO_SIDE_EFFECTS__
function Ky(e) {
  return mc(nn, e);
}
a(Ky, "date");

// node_modules/zodvex/dist/mini/index.js
var Hd = /* @__PURE__ */ new WeakMap(), Xy = {
  getMetadata: /* @__PURE__ */ a((e) => Hd.get(e), "getMetadata"),
  setMetadata: /* @__PURE__ */ a((e, t) => Hd.set(e, t), "setMetadata")
};
var Qd = /* @__PURE__ */ Symbol.for("zodvex.zxDate");
function Hy(e) {
  e[Qd] = !0;
  let t = e._zod?.def;
  return t && (t[Qd] = !0), e;
}
a(Hy, "brandZxDate");
var wS = $.discriminatedUnion("success", [
  $.object({ success: $.literal(!0) }),
  $.object({ success: $.literal(!1), error: $.string() })
]), kS = $.object({
  formErrors: $.array($.string()),
  fieldErrors: $.record($.string(), $.array($.string()))
});
var Qy = "__zodvexMeta";
function af(e, t) {
  Object.defineProperty(e, Qy, {
    value: t,
    enumerable: !1,
    writable: !1,
    configurable: !1
  });
}
a(af, "attachMeta");
var Yy = "__zodvexCodecBrand";
function eb(e, t) {
  Object.defineProperty(e, Yy, {
    value: t,
    enumerable: !1,
    writable: !1,
    configurable: !1
  });
}
a(eb, "attachCodecBrand");
function sf(e, t, n) {
  return $.codec(e, t, n);
}
a(sf, "zodvexCodec");
function gn(e) {
  let t = $.string().check(
    $.refine((o) => typeof o == "string" && o.length > 0, {
      message: `Invalid ID for table "${e}"`
    }),
    $.describe(`convexId:${e}`)
  );
  Xy.setMetadata(t, {
    isConvexId: !0,
    tableName: e
  });
  let n = t;
  return n._tableName = e, n;
}
a(gn, "id");
function cf(e) {
  return e instanceof Y || e instanceof Te;
}
a(cf, "isZodUnion");
function uf(e) {
  return e instanceof Y, e._zod.def.options;
}
a(uf, "getUnionOptions");
function tb(e) {
  if (e.length < 2)
    throw new Error(
      `z.union() requires at least 2 options, but received ${e.length}. This indicates an invalid union schema was passed to zodTable().`
    );
}
a(tb, "assertUnionOptions");
function lf(e) {
  return tb(e), $.union(e);
}
a(lf, "createUnionFromOptions");
function lu(e, t) {
  if (cf(t)) {
    let o = uf(t).map((r) => {
      if (r instanceof L) {
        let i = {
          ...r._zod.def.shape,
          _id: gn(e),
          _creationTime: $.number()
        };
        return V(r, { ...r._zod.def, shape: i });
      }
      return r;
    });
    return lf(o);
  }
  if (t instanceof L) {
    let n = { ...t._zod.def.shape, _id: gn(e), _creationTime: $.number() };
    return V(t, { ...t._zod.def, shape: n });
  }
  return t;
}
a(lu, "addSystemFields");
function rb(e) {
  return e instanceof F ? e : new F({ type: "optional", innerType: e });
}
a(rb, "ensureOptional");
function Yd(e) {
  return new F({
    type: "optional",
    innerType: new de({ type: "nullable", innerType: e })
  });
}
a(Yd, "nullableOptional2");
function nb(e) {
  let t = {};
  for (let [n, o] of Object.entries(e))
    t[n] = rb(o);
  return t;
}
a(nb, "createPartialShape");
function cu(e, t) {
  return $.object({
    _id: gn(e),
    _creationTime: $.optional($.number()),
    ...nb(t)
  });
}
a(cu, "createUpdateObjectSchema");
function df(e) {
  return $.object({
    page: $.array(e),
    isDone: $.boolean(),
    continueCursor: $.string(),
    splitCursor: Yd($.string()),
    pageStatus: Yd($.enum(["SplitRecommended", "SplitRequired"]))
  });
}
a(df, "createPaginatedDocSchema");
function ib(e, t, n = $.object(t)) {
  let o = lu(e, n);
  return {
    doc: o,
    base: n,
    insert: n,
    update: cu(e, t),
    docArray: $.array(o),
    paginatedDoc: df(o)
  };
}
a(ib, "createObjectSchemaBundle");
function ff(e, t) {
  if (cf(t)) {
    let n = uf(t).map((o) => o instanceof L ? cu(e, o._zod.def.shape) : o);
    return lf(n);
  }
  return t instanceof L ? cu(e, t._zod.def.shape) : t;
}
a(ff, "createSchemaUpdateSchema");
function ob(e, t) {
  let n = lu(e, t);
  return {
    doc: n,
    base: t,
    insert: t,
    update: ff(e, t),
    docArray: $.array(n),
    paginatedDoc: df(n)
  };
}
a(ob, "createSchemaBundle");
function pf(e, t) {
  let n;
  return {
    get: /* @__PURE__ */ a(() => n || (n = t ?? $.object(e), n), "get")
  };
}
a(pf, "lazyValidator");
function tr(e, t, n, o, r = {}, i = {}, s = {}, c = null) {
  let u = pf(t, c), l = {
    name: e,
    fields: t,
    schema: n,
    indexes: r,
    searchIndexes: i,
    vectorIndexes: s,
    get validator() {
      return u.get();
    },
    index(d, g) {
      return tr(
        e,
        t,
        n,
        o,
        { ...r, [d]: [...g, "_creationTime"] },
        i,
        s,
        c
      );
    },
    searchIndex(d, g) {
      return tr(
        e,
        t,
        n,
        o,
        r,
        { ...i, [d]: g },
        s,
        c
      );
    },
    vectorIndex(d, g) {
      return tr(
        e,
        t,
        n,
        o,
        r,
        i,
        { ...s, [d]: g },
        c
      );
    }
  };
  return af(l, { type: "model", tableName: e, definitionSource: o, schemas: n }), l;
}
a(tr, "createModel");
function rr(e, t, n, o, r = {}, i = {}, s = {}) {
  let c = pf(t, n), u = {
    name: e,
    fields: t,
    indexes: r,
    searchIndexes: i,
    vectorIndexes: s,
    get validator() {
      return c.get();
    },
    index(l, d) {
      return rr(
        e,
        t,
        n,
        o,
        { ...r, [l]: [...d, "_creationTime"] },
        i,
        s
      );
    },
    searchIndex(l, d) {
      return rr(
        e,
        t,
        n,
        o,
        r,
        { ...i, [l]: d },
        s
      );
    },
    vectorIndex(l, d) {
      return rr(e, t, n, o, r, i, {
        ...s,
        [l]: d
      });
    }
  };
  return n !== null && (u.schema = n), af(u, { type: "model", tableName: e, definitionSource: o }), u;
}
a(rr, "createSlimModel");
function ef(e, t, n) {
  let o = n?.schemaHelpers === !1;
  if (t instanceof _)
    return o ? rr(e, {}, t, "schema") : tr(
      e,
      {},
      ob(e, t),
      "schema",
      void 0,
      void 0,
      void 0,
      t
    );
  let r = t;
  return o ? rr(e, r, null, "shape") : tr(e, r, ib(e, r), "shape");
}
a(ef, "defineZodModel");
function mf(e, t, n) {
  return t instanceof _, ef(e, t, n);
}
a(mf, "defineZodModel2");
function ab() {
  return Hy(
    sf(
      $.number(),
      // Wire: timestamp
      $.custom((e) => e instanceof Date, {
        message: "Expected Date instance"
      }),
      {
        decode: /* @__PURE__ */ a((e) => new Date(e), "decode"),
        encode: /* @__PURE__ */ a((e) => e.getTime(), "encode")
      }
    )
  );
}
a(ab, "date");
function sb(e, t, n, o) {
  let r = sf(e, t, n);
  return o?.brand && eb(r, o.brand), r;
}
a(sb, "codec");
function hn(e) {
  let t = /* @__PURE__ */ Symbol.for(`zodvex.zx.cache.${e}`), n = globalThis, o = n[t];
  if (o) return o;
  let r = /* @__PURE__ */ new WeakMap();
  return n[t] = r, r;
}
a(hn, "sharedWeakMap");
var tf = hn("base"), rf = hn("doc"), nf = hn("update"), of = hn("docArray");
function du(e) {
  let t = e.schema;
  return t instanceof _ ? t : e.fields;
}
a(du, "slimCacheKey");
function fu(e) {
  let t = e.schema;
  if (t?.base instanceof _) return t.base;
  if (t instanceof _) return t;
  let n = tf.get(e.fields);
  if (n) return n;
  if (Object.keys(e.fields).length === 0)
    throw new Error(`[zodvex] Cannot derive base schema for model '${e.name}'`);
  let o = $.object(e.fields);
  return tf.set(e.fields, o), o;
}
a(fu, "base");
function gf(e) {
  let t = e.schema;
  if (t?.doc instanceof _) return t.doc;
  let n = du(e), o = rf.get(n);
  if (o) return o;
  let r = lu(e.name, fu(e));
  return rf.set(n, r), r;
}
a(gf, "doc");
function cb(e) {
  let t = e.schema;
  if (t?.update instanceof _) return t.update;
  let n = du(e), o = nf.get(n);
  if (o) return o;
  let r = ff(e.name, fu(e));
  return nf.set(n, r), r;
}
a(cb, "update");
function ub(e) {
  let t = e.schema;
  if (t?.docArray instanceof _) return t.docArray;
  let n = du(e), o = of.get(n);
  if (o) return o;
  let r = $.array(gf(e));
  return of.set(n, r), r;
}
a(ub, "docArray");
function hf(e) {
  return new de({ type: "nullable", innerType: e });
}
a(hf, "nullable");
function mn(e) {
  return new F({ type: "optional", innerType: e });
}
a(mn, "optional");
function uu(e) {
  return mn(hf(e));
}
a(uu, "nullableOptional3");
function lb() {
  return $.object({
    numItems: $.number(),
    cursor: hf($.string()),
    endCursor: uu($.string()),
    id: mn($.number()),
    maximumRowsRead: mn($.number()),
    maximumBytesRead: mn($.number())
  });
}
a(lb, "paginationOpts");
function db(e) {
  return $.object({
    page: $.array(e),
    isDone: $.boolean(),
    continueCursor: $.string(),
    splitCursor: uu($.string()),
    pageStatus: uu($.enum(["SplitRecommended", "SplitRequired"]))
  });
}
a(db, "paginationResult");
var _e = {
  /**
   * Date ↔ timestamp codec
   * @see {@link date}
   */
  date: ab,
  /**
   * Convex ID validator
   * @see {@link id}
   */
  id: gn,
  /**
   * Custom codec builder
   * @see {@link codec}
   */
  codec: sb,
  /**
   * Pagination options schema matching Convex's PaginationOptions type
   * @see {@link paginationOpts}
   */
  paginationOpts: lb,
  /**
   * Paginated result schema wrapping any item schema in Convex's PaginationResult shape
   * @see {@link paginationResult}
   */
  paginationResult: db,
  /**
   * Base schema for a model (user fields only; no system fields).
   * For object models reconstructs from fields; for union models returns the
   * user-supplied union. Cached per-model.
   * @see {@link base}
   */
  base: fu,
  /**
   * Doc schema: model fields + _id + _creationTime
   * @see {@link doc}
   */
  doc: gf,
  /**
   * Update schema: _id required, all other fields optional
   * @see {@link update}
   */
  update: cb,
  /**
   * Doc array schema: z.array(doc(model))
   * @see {@link docArray}
   */
  docArray: ub
};
function fb() {
  return _e.date();
}
a(fb, "date2");
function pb(e) {
  return _e.id(e);
}
a(pb, "id2");
function mb(e, t, n, o) {
  return _e.codec(e, t, n, o);
}
a(mb, "codec2");
var zS = {
  date: fb,
  id: pb,
  codec: mb,
  paginationOpts: _e.paginationOpts,
  paginationResult: _e.paginationResult,
  base: _e.base,
  doc: _e.doc,
  update: _e.update,
  docArray: _e.docArray
};

// ../zodvex-triage-20260909/node_modules/.bun/convex-helpers@0.1.113+b9ed8f5244cf7f28/node_modules/convex-helpers/index.js
var jS = Symbol();

// ../zodvex-triage-20260909/node_modules/.bun/convex-helpers@0.1.113+b9ed8f5244cf7f28/node_modules/convex-helpers/validators.js
var ES = m.string(), ZS = m.float64(), NS = m.float64(), AS = m.boolean(), CS = m.int64(), RS = m.int64(), FS = m.any(), MS = m.null(), { id: LS, object: BS, array: VS, bytes: qS, literal: JS, optional: WS, union: KS } = m, GS = m.bytes();
var XS = m.optional(m.any());

// ../zodvex-triage-20260909/node_modules/.bun/convex-helpers@0.1.113+b9ed8f5244cf7f28/node_modules/convex-helpers/server/customFunctions.js
var vn = {
  args: {},
  input() {
    return { args: {}, ctx: {} };
  }
};

// node_modules/zodvex/dist/mini/server/index.js
function vf(e) {
  let t = e;
  for (let n = 0; n < 10; n++) {
    if (t instanceof F || t instanceof de || t instanceof ae) {
      t = t._zod.def.innerType;
      continue;
    }
    break;
  }
  return t;
}
a(vf, "unwrapOuter");
function gb(e, t) {
  let n = [], o = t;
  for (let r of e) {
    if (o = vf(o), o instanceof ge)
      break;
    if (o instanceof L && typeof r == "string") {
      let i = o._zod.def.shape[r];
      if (!i) {
        n.push(r);
        break;
      }
      if (n.push(r), vf(i) instanceof ge)
        break;
      o = i;
      continue;
    }
    if (o instanceof Oe && typeof r == "number") {
      n.push(r), o = o._zod.def.element;
      continue;
    }
    n.push(r);
  }
  return n;
}
a(gb, "truncateAtCodecBoundary");
function hb(e, t) {
  let n = e.issues.map((o) => ({
    ...o,
    path: gb(o.path, t)
  }));
  return new $e(n);
}
a(hb, "normalizeCodecPaths");
function vb(e, t) {
  try {
    return Q(e, t);
  } catch (n) {
    throw n instanceof $e ? hb(n, e) : n;
  }
}
a(vb, "safeEncode");
function Ne(e) {
  if (e == null)
    return e;
  if (Array.isArray(e))
    return e.map(Ne);
  if (typeof e == "object" && e.constructor === Object) {
    let t = {};
    for (let [n, o] of Object.entries(e))
      o !== void 0 && (t[n] = Ne(o));
    return t;
  }
  return e;
}
a(Ne, "stripUndefined");
var yb = /* @__PURE__ */ Symbol.for("functionName");
function yf(e) {
  if (typeof e == "string") return e;
  let t = e[yb];
  return t || null;
}
a(yf, "resolveFunctionPath");
var bb = class extends $e {
  static {
    a(this, "ZodvexDecodeError");
  }
  functionPath;
  wireData;
  constructor(e, t, n) {
    super(t), this.functionPath = e, this.wireData = n, this.name = "ZodvexDecodeError";
  }
}, bf = /* @__PURE__ */ new Set();
function xb(e, t) {
  let n = t?.onDecodeError ?? "warn", o = t?.warnWirePreview === !0;
  function r(s, c) {
    if (c == null) return c;
    let u = yf(s);
    if (u == null) return c;
    let l = e[u];
    return l?.args ? Ne(vb(l.args, c)) : (l === void 0 && !bf.has(u) && (bf.add(u), console.debug(
      `[zodvex] No registry entry for "${u}" \u2014 args/returns pass through unencoded. This is expected when the target is a raw (non-zodvex) function; if it should be codec-aware, run \`zodvex generate\` to update the registry.`
    )), c);
  }
  a(r, "encodeArgs");
  function i(s, c) {
    let u = yf(s);
    if (u == null) return c;
    let l = e[u];
    if (!l?.returns) return c;
    let d = me(l.returns, c);
    if (d.success) return d.data;
    if (n === "throw")
      throw new bb(u, d.error.issues, c);
    let g = d.error.issues.map((x) => `${x.path.join(".")}: ${x.message}`).join(", "), b = `[zodvex] Decode failed for ${u}: ${g}. Returning raw wire data.`;
    if (o) {
      let x = "[unavailable]";
      try {
        x = JSON.stringify(c) ?? "[unavailable]";
      } catch {
      }
      let j = x.length > 200 ? `${x.slice(0, 200)}...` : x;
      b += ` Preview: ${j}`;
    }
    return console.warn(b), c;
  }
  return a(i, "decodeResult"), { encodeArgs: r, decodeResult: i };
}
a(xb, "createBoundaryHelpers");
function xf(e, t) {
  return async (n, ...o) => {
    let r = t.encodeArgs(n, o[0]), i = await e(n, r);
    return t.decodeResult(n, i);
  };
}
a(xf, "wrapRun");
function $b(e, t) {
  let n = { ...e };
  return n.runAfter = (o, r, ...i) => {
    let s = t.encodeArgs(r, i[0]);
    return e.runAfter(o, r, ...i.length ? [s] : []);
  }, n.runAt = (o, r, ...i) => {
    let s = t.encodeArgs(r, i[0]);
    return e.runAt(o, r, ...i.length ? [s] : []);
  }, n;
}
a($b, "wrapScheduler");
function Mf(e, t, n) {
  let o = xb(e, n), r = {};
  return typeof t.runQuery == "function" && (r.runQuery = xf(t.runQuery, o)), typeof t.runMutation == "function" && (r.runMutation = xf(t.runMutation, o)), t.scheduler && (r.scheduler = $b(t.scheduler, o)), r;
}
a(Mf, "createCodecCallOverrides");
var $f = /* @__PURE__ */ new WeakMap(), $n = {
  getMetadata: /* @__PURE__ */ a((e) => $f.get(e), "getMetadata"),
  setMetadata: /* @__PURE__ */ a((e, t) => $f.set(e, t), "setMetadata")
};
function _b(e) {
  let t = e._zod.def.entries, n = Object.keys(t);
  if (n && Array.isArray(n) && n.length > 0) {
    let o = n.filter((r) => r != null).map((r) => m.literal(r));
    if (o.length === 1) {
      let [r] = o;
      return r;
    } else if (o.length >= 2) {
      let [r, i, ...s] = o;
      return m.union(
        r,
        i,
        ...s
      );
    } else
      return m.any();
  } else
    return m.any();
}
a(_b, "convertEnumType");
function wb(e, t, n) {
  let o = e._zod.def.innerType;
  if (o && o instanceof _)
    if (o instanceof F) {
      let r = o._zod.def.innerType, i = n(r, t);
      return {
        validator: m.union(i, m.null()),
        isOptional: !0
        // Mark as optional so it gets wrapped later
      };
    } else {
      let r = n(o, t);
      return {
        validator: m.union(r, m.null()),
        isOptional: !1
      };
    }
  else
    return {
      validator: m.any(),
      isOptional: !1
    };
}
a(wb, "convertNullableType");
function kb(e, t, n) {
  let o = e._zod.def.valueType;
  if (o || (o = e._zod.def.keyType), o && o instanceof _)
    if (o instanceof F || o instanceof ae || o instanceof ae && o._zod.def.innerType instanceof F) {
      let i, s, c = !1;
      if (o instanceof ae) {
        c = !0, s = o._zod.def.defaultValue;
        let d = o._zod.def.innerType;
        d instanceof F ? i = d._zod.def.innerType : i = d;
      } else o instanceof F ? i = o._zod.def.innerType : i = o;
      let u = n(i, t), l = m.union(u, m.null());
      return c && (l._zodDefault = s), m.record(m.string(), l);
    } else
      return m.record(m.string(), n(o, t));
  else
    return m.record(m.string(), m.any());
}
a(kb, "convertRecordType");
function zb(e, t, n) {
  let o = e instanceof Te ? e._zod.def.options : (
    // cast: fallback for non-standard discriminated union variants
    e._zod?.def?.options
  );
  if (o) {
    let r = Array.isArray(o) ? o : Array.from(o);
    if (r.length >= 2) {
      let i = r.map((l) => {
        let d = new Set(t);
        return n(l, d);
      }), [s, c, ...u] = i;
      return m.union(
        s,
        c,
        ...u
      );
    } else
      return m.any();
  } else
    return m.any();
}
a(zb, "convertDiscriminatedUnionType");
function Ib(e, t, n) {
  let o = e._zod.def.options;
  if (o && Array.isArray(o) && o.length > 0) {
    if (o.length === 1)
      return n(o[0], t);
    {
      let r = o.map((i) => {
        let s = new Set(t);
        return n(i, s);
      });
      if (r.length >= 2) {
        let [i, s, ...c] = r;
        return m.union(
          i,
          s,
          ...c
        );
      } else
        return m.any();
    }
  } else
    return m.any();
}
a(Ib, "convertUnionType");
function Sb(e) {
  let t = $n.getMetadata(e);
  return t?.isConvexId === !0 && t?.tableName && typeof t.tableName == "string";
}
a(Sb, "isZid");
var _f = /* @__PURE__ */ new WeakMap();
function ie(e, t = /* @__PURE__ */ new Set()) {
  if (!e)
    return m.any();
  let n = _f.get(e);
  if (n)
    return n;
  if (t.has(e))
    return m.any();
  t.add(e);
  let o = e, r = !1, i, s = !1;
  e instanceof ae && (s = !0, i = e._zod.def.defaultValue, o = e._zod.def.innerType), o instanceof F && (r = !0, o = o._zod.def.innerType, o instanceof ae && (s = !0, i = o._zod.def.defaultValue, o = o._zod.def.innerType));
  let c;
  if (Sb(o)) {
    let d = $n.getMetadata(o)?.tableName || "unknown";
    c = m.id(d);
  } else
    switch (o._zod.def.type) {
      case "string":
        c = m.string();
        break;
      case "number":
        c = m.float64();
        break;
      case "bigint":
        c = m.int64();
        break;
      case "boolean":
        c = m.boolean();
        break;
      case "date":
        c = m.float64();
        break;
      case "null":
        c = m.null();
        break;
      case "nan":
        c = m.float64();
        break;
      case "array": {
        if (o instanceof Oe) {
          let d = o._zod.def.element;
          c = m.array(ie(d, t));
        } else
          c = m.array(m.any());
        break;
      }
      case "object": {
        if (o instanceof L) {
          let d = o._zod.def.shape, g = {};
          for (let [b, x] of Object.entries(d))
            x && x instanceof _ && (g[b] = ie(x, t));
          c = m.object(g);
        } else
          c = m.object({});
        break;
      }
      case "union": {
        o instanceof Y ? c = Ib(o, t, ie) : c = m.any();
        break;
      }
      case "discriminatedUnion": {
        c = zb(
          o,
          t,
          ie
        );
        break;
      }
      case "literal": {
        if (o instanceof ft) {
          let g = o._zod.def.values.values().next().value;
          g != null ? c = m.literal(g) : c = m.any();
        } else
          c = m.any();
        break;
      }
      case "enum": {
        o instanceof dt ? c = _b(o) : c = m.any();
        break;
      }
      case "record": {
        o instanceof We ? c = kb(o, t, ie) : c = m.record(m.string(), m.any());
        break;
      }
      case "transform":
      case "pipe": {
        if (o instanceof ge) {
          let d = o._zod.def.in;
          d && d instanceof _ ? c = ie(d, t) : c = m.any();
        } else {
          let d = $n.getMetadata(o);
          if (d?.brand && d?.originalSchema)
            c = ie(d.originalSchema, t);
          else {
            let g = o._zod?.def?.in;
            g && g instanceof _ ? c = ie(g, t) : c = m.any();
          }
        }
        break;
      }
      case "nullable": {
        if (o instanceof de) {
          let d = wb(o, t, ie);
          c = d.validator, d.isOptional && (r = !0);
        } else
          c = m.any();
        break;
      }
      case "tuple": {
        if (o instanceof Pe) {
          let d = o._zod.def.items;
          if (d && d.length > 0) {
            let g = {};
            d.forEach((b, x) => {
              g[`_${x}`] = ie(b, t);
            }), c = m.object(g);
          } else
            c = m.object({});
        } else
          c = m.object({});
        break;
      }
      case "lazy": {
        if (o instanceof pt)
          try {
            let d = o._zod.def.getter;
            if (d) {
              let g = d();
              g && g instanceof _ ? c = ie(g, t) : c = m.any();
            } else
              c = m.any();
          } catch {
            c = m.any();
          }
        else
          c = m.any();
        break;
      }
      case "any":
        c = m.any();
        break;
      case "unknown":
        c = m.any();
        break;
      case "undefined":
      case "void":
      case "never":
        c = m.any();
        break;
      case "intersection":
        c = m.any();
        break;
      case "optional": {
        let d = o._zod?.def?.innerType;
        d && d instanceof _ ? (c = ie(d, t), r = !0) : (c = m.any(), r = !0);
        break;
      }
      default:
        c = m.any();
        break;
    }
  let u = r || s ? m.optional(c) : c;
  return s && typeof u == "object" && u !== null && (u._zodDefault = i), _f.set(e, u), u;
}
a(ie, "zodToConvexInternal");
function Lf(e) {
  return typeof e == "object" && e !== null && !(e instanceof _) ? _n(e) : ie(e);
}
a(Lf, "zodToConvex");
function _n(e) {
  let t = e instanceof L ? e._zod.def.shape : e, n = {};
  for (let [o, r] of Object.entries(t))
    n[o] = ie(r);
  return n;
}
a(_n, "zodToConvexFields");
function Ke(e) {
  if (e instanceof lt) return !0;
  if (e instanceof ge) return !1;
  if (e instanceof F || e instanceof de || e instanceof ae)
    return Ke(e._zod.def.innerType);
  if (e instanceof L)
    return Object.values(e._zod.def.shape).some((t) => Ke(t));
  if (e instanceof Oe)
    return Ke(e._zod.def.element);
  if (e instanceof Y)
    return e._zod.def.options.some((t) => Ke(t));
  if (e instanceof We)
    return Ke(e._zod.def.valueType);
  if (e instanceof Pe) {
    let t = e._zod.def.items;
    return t ? t.some((n) => Ke(n)) : !1;
  }
  return !1;
}
a(Ke, "containsNativeZodDate");
function wf(e, t) {
  if (Ke(e))
    throw new Error(
      `[zodvex] Native z.date() found in ${t}. Convex stores dates as timestamps (numbers), which z.date() cannot parse.

Fix: Replace z.date() with zx.date()

Before: { createdAt: z.date() }
After:  { createdAt: zx.date() }

zx.date() is a codec that handles timestamp \u2194 Date conversion automatically.`
    );
}
a(wf, "assertNoNativeZodDate");
function Bf(e, t) {
  return ne(e, t);
}
a(Bf, "decodeDoc");
function kf(e, t) {
  return Ne(Q(e, t));
}
a(kf, "encodeDoc");
function zf(e) {
  let t = {};
  for (let [n, o] of Object.entries(e))
    t[n] = o === void 0 ? void 0 : Ne(o);
  return t;
}
a(zf, "stripUndefinedPreservingTopLevel");
function jb(e, t) {
  if (!(e instanceof L)) {
    let s = Q(e, t);
    return s !== null && typeof s == "object" && !Array.isArray(s) ? zf(s) : Ne(s);
  }
  let n = e._zod.def.shape, o = {};
  for (let [s, c] of Object.entries(n))
    o[s] = c instanceof F ? c : new F({ type: "optional", innerType: c });
  let r = $.object(o), i = Q(r, t);
  return zf(i);
}
a(jb, "encodePartialDoc");
function Vf(e, t, n) {
  return $.codec(e, t, n);
}
a(Vf, "zodvexCodec");
function pu(e, t, n) {
  if (t.includes(".")) return n;
  if (e instanceof L) {
    let o = e.shape[t];
    if (o) return Q(o, n);
  }
  if (e instanceof Y) {
    let r = e._zod.def.options.filter((i) => i instanceof L).map((i) => i.shape[t]).filter(Boolean);
    if (r.length === 1) return Q(r[0], n);
    if (r.length > 1)
      return Q($.union(r), n);
  }
  return n;
}
a(pu, "encodeIndexValue");
function wn(e, t) {
  return new Proxy(e, {
    get(n, o, r) {
      return typeof o == "string" && ["eq", "gt", "gte", "lt", "lte"].includes(o) ? (i, s) => {
        let c = pu(t, i, s), u = n[o](i, c);
        return wn(u, t);
      } : o === "search" ? (...i) => {
        let s = n.search(...i);
        return wn(s, t);
      } : Reflect.get(n, o, r);
    }
  });
}
a(wn, "wrapIndexRangeBuilder");
function mu(e, t) {
  return e != null && Object.prototype.isPrototypeOf.call(t, e);
}
a(mu, "isFilterExpression");
function If(e, t) {
  if (mu(e, t)) {
    let n = e.serialize();
    if (n && typeof n == "object" && "$field" in n)
      return n.$field;
  }
  return null;
}
a(If, "extractFieldPath");
function Ob(e, t) {
  let n = Object.getPrototypeOf(e.field("_id"));
  return new Proxy(e, {
    get(o, r, i) {
      return typeof r == "string" && ["eq", "neq", "lt", "lte", "gt", "gte"].includes(r) ? (s, c) => {
        let u = If(s, n), l = If(c, n);
        return u && !mu(c, n) ? c = pu(t, u, c) : l && !mu(s, n) && (s = pu(t, l, s)), o[r](s, c);
      } : Reflect.get(o, r, i);
    }
  });
}
a(Ob, "wrapFilterBuilder");
var bu = class qf {
  static {
    a(this, "_ZodvexQueryChain");
  }
  constructor(t, n) {
    this.inner = t, this.schema = n;
  }
  /** Factory method for intermediate methods. Subclasses override to return their own type. */
  createChain(t) {
    return new qf(t, this.schema);
  }
  /** Decode a wire-format doc and cast to the decoded document type. */
  decode(t) {
    return Bf(this.schema, t);
  }
  // --- Intermediate methods: wire-typed TableInfo for Convex machinery ---
  fullTableScan() {
    return this.createChain(this.inner.fullTableScan());
  }
  withIndex(t, n) {
    let o = n ? (r) => n(wn(r, this.schema)) : void 0;
    return this.createChain(this.inner.withIndex(t, o));
  }
  withSearchIndex(t, n) {
    let o = /* @__PURE__ */ a((r) => n(wn(r, this.schema)), "wrappedFilter");
    return this.createChain(this.inner.withSearchIndex(t, o));
  }
  order(t) {
    return this.createChain(this.inner.order(t));
  }
  // Implementation
  filter(t) {
    let n = /* @__PURE__ */ a((o) => t(Ob(o, this.schema)), "wrappedPredicate");
    return this.createChain(this.inner.filter(n));
  }
  limit(t) {
    return this.createChain(this.inner.limit(t));
  }
  count() {
    return this.inner.count();
  }
  // --- Terminal methods: return decoded Doc type ---
  async first() {
    let t = await this.inner.first();
    return t ? this.decode(t) : null;
  }
  async unique() {
    let t = await this.inner.unique();
    return t ? this.decode(t) : null;
  }
  async collect() {
    return (await this.inner.collect()).map((n) => this.decode(n));
  }
  async take(t) {
    return (await this.inner.take(t)).map((o) => this.decode(o));
  }
  async paginate(t) {
    let n = await this.inner.paginate(t);
    return {
      ...n,
      page: n.page.map((o) => this.decode(o))
    };
  }
  // --- AsyncIterable: decode each yielded document ---
  async *[Symbol.asyncIterator]() {
    for await (let t of this.inner)
      yield this.decode(t);
  }
};
function gu(e, t, n) {
  for (let o of Object.keys(t))
    if (e.normalizeId(o, n))
      return o;
  return null;
}
a(gu, "resolveTableName");
var zn = class {
  static {
    a(this, "ZodvexDatabaseReader");
  }
  constructor(e, t) {
    this.db = e, this.tableMap = t, this.system = e.system;
  }
  system;
  /** @internal Expose for wrapper construction (rule/audit subclasses) */
  get _internals() {
    return { db: this.db, tableMap: this.tableMap };
  }
  /**
   * Escape hatch (#85/#92): returns the database this codec wrapper delegates
   * to — the composed underlying stack when `underlyingDb` is configured (e.g.
   * a trigger-wrapped writer), the bare Convex db otherwise.
   *
   * The returned db is native-shape: reads are undecoded wire documents and it
   * bypasses codec, `.withRules()`, and `.audit()` layers entirely.
   */
  unwrap() {
    return this.db;
  }
  normalizeId(e, t) {
    return this.db.normalizeId(e, t);
  }
  async get(e, t) {
    let n, o;
    if (t !== void 0 ? (n = e, o = await this.db.get(e, t)) : (o = await this.db.get(e), n = o ? gu(this.db, this.tableMap, e) : null), !o) return null;
    let r = n ? this.tableMap[n] : void 0;
    return r ? Bf(r.doc, o) : o;
  }
  query(e) {
    let t = this.tableMap[e], n = this.db.query(e);
    return t ? new bu(n, t.doc) : n;
  }
  /**
   * Returns a new ZodvexDatabaseReader that applies per-table read rules.
   * The returned reader is also a ZodvexDatabaseReader, so `.withRules()` can be chained.
   */
  withRules(e, t, n) {
    return new Wf(this, e, t, n ?? {});
  }
  /**
   * Returns a new ZodvexDatabaseReader that fires audit callbacks on reads.
   * The returned reader is also a ZodvexDatabaseReader, so `.audit()` can be chained
   * with `.withRules()`.
   */
  audit(e) {
    return new Gf(this, e);
  }
}, xu = class extends zn {
  static {
    a(this, "ZodvexDatabaseWriter");
  }
  // Narrows the inherited `protected db` to the writer-typed view without
  // shadowing the underlying instance. Used by the write methods below.
  get writerDb() {
    return this.db;
  }
  constructor(e, t) {
    super(e, t), this.system = e.system;
  }
  /**
   * @internal Expose writer-typed internals for rules / audit subclasses.
   * Includes a `reader` field that aliases `this` (writer IS-A reader after
   * the #64 refactor) so callers expecting `_internals.reader` still work.
   */
  get _internals() {
    return { db: this.writerDb, tableMap: this.tableMap, reader: this };
  }
  /**
   * Escape hatch (#85/#92): returns the writer this codec wrapper delegates
   * to — the composed underlying stack when `underlyingDb` is configured (e.g.
   * a trigger-wrapped writer), the bare Convex db otherwise.
   *
   * The returned db is native-shape: writes must be wire-format and it
   * bypasses codec, `.withRules()`, and `.audit()` layers entirely.
   */
  unwrap() {
    return this.writerDb;
  }
  async insert(e, t) {
    let n = this.tableMap[e], o = n ? kf(n.insert, t) : t;
    return this.writerDb.insert(e, o);
  }
  async patch(e, t, n) {
    let o, r, i;
    n !== void 0 ? (o = e, r = t, i = n) : (r = e, i = t, o = gu(this.db, this.tableMap, r));
    let s = o ? this.tableMap[o] : void 0, c = s ? jb(s.insert, i) : i;
    return n !== void 0 ? this.writerDb.patch(e, r, c) : this.writerDb.patch(r, c);
  }
  async replace(e, t, n) {
    let o, r, i;
    n !== void 0 ? (o = e, r = t, i = n) : (r = e, i = t, o = gu(this.db, this.tableMap, r));
    let s = o ? this.tableMap[o] : void 0, c = s ? kf(s.insert, i) : i;
    return n !== void 0 ? this.writerDb.replace(e, r, c) : this.writerDb.replace(r, c);
  }
  async delete(e, t) {
    return t !== void 0 ? this.writerDb.delete(e, t) : this.writerDb.delete(e);
  }
  /**
   * Returns a new ZodvexDatabaseWriter that applies per-table read and write rules.
   * The returned writer is also a ZodvexDatabaseWriter, so `.withRules()` can be chained.
   *
   * Overrides Reader's signature so a writer chained call returns a writer.
   */
  withRules(e, t, n) {
    return new Pb(this, e, t, n ?? {});
  }
  /**
   * Returns a new ZodvexDatabaseWriter that fires audit callbacks on reads and writes.
   * The returned writer is also a ZodvexDatabaseWriter, so `.audit()` can be chained
   * with `.withRules()`.
   *
   * Overrides Reader's signature so a writer chained call returns a writer.
   */
  audit(e) {
    return new Db(this, e);
  }
};
function yn(e, t) {
  return e === !0 ? t : e === !1 ? null : e;
}
a(yn, "normalizeReadResult");
var Tb = class Jf extends bu {
  static {
    a(this, "_RulesQueryChain");
  }
  readRule;
  rulesConfig;
  ctx;
  constructor(t, n, o, r, i = {}) {
    super(t, n), this.readRule = o, this.rulesConfig = r, this.ctx = i;
  }
  createChain(t) {
    return new Jf(t, this.schema, this.readRule, this.rulesConfig, this.ctx);
  }
  async first() {
    for await (let t of this)
      return t;
    return null;
  }
  async unique() {
    let t = await super.unique();
    return t === null ? null : yn(await this.readRule(this.ctx, t), t);
  }
  async collect() {
    let t = [];
    for await (let n of this)
      t.push(n);
    return t;
  }
  async take(t) {
    if (!Number.isInteger(t) || t < 0)
      throw new Error("take requires a non-negative integer");
    let n = [];
    if (t === 0) return n;
    for await (let o of this)
      if (n.push(o), n.length >= t) break;
    return n;
  }
  async paginate(t) {
    let n = await super.paginate(t), o = [];
    for (let r of n.page) {
      let i = yn(await this.readRule(this.ctx, r), r);
      i !== null && o.push(i);
    }
    return { ...n, page: o };
  }
  async count() {
    if (!this.rulesConfig.allowCounting)
      throw new Error("count is not allowed with rules");
    return super.count();
  }
  async *[Symbol.asyncIterator]() {
    for await (let t of super[Symbol.asyncIterator]()) {
      let n = yn(await this.readRule(this.ctx, t), t);
      n !== null && (yield n);
    }
  }
};
function bn(e, t, n, o) {
  for (let r of Object.keys(n))
    if (e.normalizeId(r, t))
      return r;
  if ((o.defaultPolicy ?? "allow") === "deny") {
    for (let r of Object.keys(e._internals.tableMap))
      if (e.normalizeId(r, t))
        return r;
  }
  return null;
}
a(bn, "resolveRulesTableName");
var Wf = class extends zn {
  static {
    a(this, "RulesDatabaseReader");
  }
  constructor(e, t, n, o) {
    let { db: r, tableMap: i } = e._internals;
    super(r, i), this.inner = e, this.ctx = t, this.rules = n, this.rulesConfig = o, this.system = e.system;
  }
  async get(e, t) {
    let n = await this.inner.get(e, t);
    if (n === null) return null;
    let o = t !== void 0 ? e : bn(this.inner, e, this.rules, this.rulesConfig);
    return o ? this.applyReadRule(o, n) : n;
  }
  query(e) {
    let t = this.rules[e];
    if (!t?.read && (this.rulesConfig.defaultPolicy ?? "allow") === "allow")
      return this.inner.query(e);
    let n = this.inner.query(e), o = t?.read ?? (async () => null), r = $.any();
    return new Tb(n, r, o, this.rulesConfig, this.ctx);
  }
  async applyReadRule(e, t) {
    let n = this.rules[e];
    if (!n?.read)
      return (this.rulesConfig.defaultPolicy ?? "allow") === "deny" ? null : t;
    let o = await n.read(this.ctx, t);
    return yn(o, t);
  }
}, Pb = class extends xu {
  static {
    a(this, "RulesDatabaseWriter");
  }
  constructor(e, t, n, o) {
    let { db: r, tableMap: i, reader: s } = e._internals;
    super(r, i), this.inner = e, this.ctx = t, this.rules = n, this.rulesConfig = o, this.rulesReader = new Wf(s, t, n, o), this.system = e.system;
  }
  rulesReader;
  normalizeId(e, t) {
    return this.rulesReader.normalizeId(e, t);
  }
  async get(e, t) {
    return this.rulesReader.get(e, t);
  }
  query(e) {
    return this.rulesReader.query(e);
  }
  async insert(e, t) {
    let n = e, o = this.rules[n];
    if (o?.insert) {
      let r = await o.insert(this.ctx, t);
      return this.inner.insert(
        e,
        r
      );
    }
    if ((this.rulesConfig.defaultPolicy ?? "allow") === "deny")
      throw new Error(`insert not allowed on ${n}`);
    return this.inner.insert(e, t);
  }
  async patch(e, t, n) {
    let o, r;
    n !== void 0 ? (o = t, r = n) : (o = e, r = t);
    let i = await this.rulesReader.get(o);
    if (i === null)
      throw new Error("no read access or doc does not exist");
    let s = bn(this.inner, o, this.rules, this.rulesConfig), c = s ? this.rules[s] : void 0;
    if (c?.patch) {
      let u = await c.patch(this.ctx, i, r);
      return this.inner.patch(
        o,
        u
      );
    }
    if ((this.rulesConfig.defaultPolicy ?? "allow") === "deny")
      throw new Error(`patch not allowed on ${s}`);
    return this.inner.patch(o, r);
  }
  async replace(e, t, n) {
    let o, r;
    n !== void 0 ? (o = t, r = n) : (o = e, r = t);
    let i = await this.rulesReader.get(o);
    if (i === null)
      throw new Error("no read access or doc does not exist");
    let s = bn(this.inner, o, this.rules, this.rulesConfig), c = s ? this.rules[s] : void 0;
    if (c?.replace) {
      let u = await c.replace(this.ctx, i, r);
      return this.inner.replace(o, u);
    }
    if ((this.rulesConfig.defaultPolicy ?? "allow") === "deny")
      throw new Error(`replace not allowed on ${s}`);
    return this.inner.replace(o, r);
  }
  async delete(e, t) {
    let n;
    t !== void 0 ? n = t : n = e;
    let o = await this.rulesReader.get(n);
    if (o === null)
      throw new Error("no read access or doc does not exist");
    let r = bn(this.inner, n, this.rules, this.rulesConfig), i = r ? this.rules[r] : void 0;
    if (i?.delete)
      return await i.delete(this.ctx, o), this.inner.delete(n);
    if ((this.rulesConfig.defaultPolicy ?? "allow") === "deny")
      throw new Error(`delete not allowed on ${r}`);
    return this.inner.delete(n);
  }
}, Ub = class Kf extends bu {
  static {
    a(this, "_AuditQueryChain");
  }
  afterRead;
  tableName;
  constructor(t, n, o, r) {
    super(t, n), this.afterRead = o, this.tableName = r;
  }
  createChain(t) {
    return new Kf(t, this.schema, this.afterRead, this.tableName);
  }
  async first() {
    let t = await super.first();
    return t !== null && await this.afterRead(this.tableName, t), t;
  }
  async unique() {
    let t = await super.unique();
    return t !== null && await this.afterRead(this.tableName, t), t;
  }
  async collect() {
    let t = await super.collect();
    for (let n of t)
      await this.afterRead(this.tableName, n);
    return t;
  }
  async take(t) {
    let n = await super.take(t);
    for (let o of n)
      await this.afterRead(this.tableName, o);
    return n;
  }
  async paginate(t) {
    let n = await super.paginate(t);
    for (let o of n.page)
      await this.afterRead(this.tableName, o);
    return n;
  }
  async *[Symbol.asyncIterator]() {
    for await (let t of super[Symbol.asyncIterator]())
      await this.afterRead(this.tableName, t), yield t;
  }
}, Gf = class extends zn {
  static {
    a(this, "AuditDatabaseReader");
  }
  inner;
  afterRead;
  constructor(e, t) {
    let { db: n, tableMap: o } = e._internals;
    super(n, o), this.inner = e, this.afterRead = t.afterRead ?? (() => {
    }), this.system = e.system;
  }
  async get(e, t) {
    let n = await this.inner.get(e, t);
    if (n !== null) {
      let o = this.resolveTableFromId(
        t !== void 0 ? t : e,
        t !== void 0 ? e : void 0
      );
      o && await this.afterRead(o, n);
    }
    return n;
  }
  query(e) {
    let t = this.inner.query(e), n = $.any();
    return new Ub(t, n, this.afterRead, e);
  }
  resolveTableFromId(e, t) {
    if (t) return t;
    for (let n of Object.keys(this.tableMap))
      if (this.inner.normalizeId(n, e))
        return n;
    return null;
  }
}, Db = class extends xu {
  static {
    a(this, "AuditDatabaseWriter");
  }
  inner;
  auditReader;
  afterWrite;
  constructor(e, t) {
    let { db: n, tableMap: o, reader: r } = e._internals;
    super(n, o), this.inner = e, this.afterWrite = t.afterWrite, this.auditReader = t.afterRead ? new Gf(r, { afterRead: t.afterRead }) : r, this.system = e.system;
  }
  normalizeId(e, t) {
    return this.auditReader.normalizeId(e, t);
  }
  async get(e, t) {
    return this.auditReader.get(e, t);
  }
  query(e) {
    return this.auditReader.query(e);
  }
  async insert(e, t) {
    let n = await this.inner.insert(e, t);
    return this.afterWrite && await this.afterWrite(e, { type: "insert", id: n, value: t }), n;
  }
  async patch(e, t, n) {
    let o, r;
    n !== void 0 ? (o = t, r = n) : (o = e, r = t);
    let i = await this.inner.get(o);
    if (n !== void 0 ? await this.inner.patch(e, t, n) : await this.inner.patch(o, r), this.afterWrite) {
      let s = this.resolveTableFromId(o);
      s && await this.afterWrite(s, { type: "patch", id: o, doc: i, value: r });
    }
  }
  async replace(e, t, n) {
    let o, r;
    n !== void 0 ? (o = t, r = n) : (o = e, r = t);
    let i = await this.inner.get(o);
    if (n !== void 0 ? await this.inner.replace(e, t, n) : await this.inner.replace(o, r), this.afterWrite) {
      let s = this.resolveTableFromId(o);
      s && await this.afterWrite(s, { type: "replace", id: o, doc: i, value: r });
    }
  }
  async delete(e, t) {
    let n;
    t !== void 0 ? n = t : n = e;
    let o = await this.inner.get(n);
    if (t !== void 0 ? await this.inner.delete(e, t) : await this.inner.delete(n), this.afterWrite) {
      let r = this.resolveTableFromId(n);
      r && await this.afterWrite(r, { type: "delete", id: n, doc: o });
    }
  }
  resolveTableFromId(e) {
    for (let t of Object.keys(this.inner._internals.tableMap))
      if (this.inner.normalizeId(t, e))
        return t;
    return null;
  }
};
function Eb(e, t) {
  let n = t?.underlyingDb?.query, o = t?.underlyingDb?.mutation;
  return {
    query: {
      args: {},
      input: /* @__PURE__ */ a(async (r, i, s) => ({
        ctx: {
          db: new zn(n ? n(r) : r.db, e)
        },
        args: {}
      }), "input")
    },
    mutation: {
      args: {},
      input: /* @__PURE__ */ a(async (r, i, s) => ({
        ctx: {
          db: new xu(o ? o(r) : r.db, e)
        },
        args: {}
      }), "input")
    }
  };
}
a(Eb, "createZodvexCustomization");
function Xf(e, t) {
  let n = {};
  for (let o of t)
    o in e && (n[o] = e[o]);
  return n;
}
a(Xf, "pick");
var Hf = "__zodvexMeta";
function Zb(e, t) {
  Object.defineProperty(e, Hf, {
    value: t,
    enumerable: !1,
    writable: !1,
    configurable: !1
  });
}
a(Zb, "attachMeta");
function Qf(e) {
  if (!(e == null || typeof e != "object" && typeof e != "function"))
    return e[Hf];
}
a(Qf, "readMeta");
var Nb = "__zodvexCodecBrand";
function Ab(e, t) {
  Object.defineProperty(e, Nb, {
    value: t,
    enumerable: !1,
    writable: !1,
    configurable: !1
  });
}
a(Ab, "attachCodecBrand");
function Cb(e, t) {
  return {
    error: "ZodValidationError",
    context: t,
    issues: e.issues.map((n) => ({
      path: Array.isArray(n.path) ? n.path.join(".") : String(n.path ?? ""),
      code: n.code,
      message: n.message
    })),
    // Keep a flattened snapshot for easier debugging without cyclic refs
    flatten: JSON.parse(JSON.stringify(e.flatten?.() ?? {}))
  };
}
a(Cb, "formatZodIssues");
function hu(e, t) {
  throw e instanceof $e ? new He(Cb(e, t)) : e;
}
a(hu, "handleZodValidationError");
function Rb(e, t) {
  try {
    return Q(e, t);
  } catch (n) {
    if (n?.message?.includes("unidirectional transform"))
      try {
        return ne(e, t);
      } catch (o) {
        hu(o, "returns");
      }
    hu(n, "returns");
  }
  throw new Error("Unreachable");
}
a(Rb, "validateReturns");
function Yf(e) {
  if (e)
    return e instanceof _ ? e : $.object(e);
}
a(Yf, "normalizeFunctionSchema");
function Fb(e) {
  if (e) {
    if (e instanceof L)
      return e;
    if (!(e instanceof _))
      return $.object(e);
  }
}
a(Fb, "normalizeFunctionMetaArgs");
function Sf(e, t, n) {
  Zb(e, {
    type: "function",
    zodArgs: Fb(t),
    zodReturns: Yf(n)
  });
}
a(Sf, "attachFunctionMeta");
var jf = /* @__PURE__ */ new WeakMap();
function nr(e, t = 50, n = 0) {
  let o = jf.get(e);
  if (o !== void 0)
    return o;
  if (n > t)
    return !1;
  let r = !1;
  return e instanceof Mt ? r = !0 : e instanceof Y ? r = e._zod.def.options.some((i) => nr(i, t, n + 1)) : (e instanceof F || e instanceof de || e instanceof ae) && (r = nr(e._zod.def.innerType, t, n + 1)), jf.set(e, r), r;
}
a(nr, "containsCustom");
function Mb(e) {
  if (e instanceof _) {
    if (e instanceof L)
      return {
        argsSchema: e,
        argsValidator: e._zod.def.shape
      };
    throw new Error(
      "Unsupported non-object Zod schema for args; please provide an args schema using z.object({...}), e.g. z.object({ foo: z.string() })"
    );
  }
  return {
    argsValidator: e,
    argsSchema: $.object(e)
  };
}
a(Mb, "normalizeCustomArgsValidator");
function Lb(e, t) {
  if (!(!e || t?.skipConvexValidation) && !(t?.skipCustomSchemas && nr(e)))
    return Lf(e);
}
a(Lb, "createConvexReturnsValidator");
function ep(e, t) {
  let n = me(e, t);
  return n.success || hu(n.error, "args"), n.data;
}
a(ep, "parseObjectArgsOrThrow");
async function Of(e, t, n, o, r, i) {
  let s = Xf(n, Object.keys(o)), c = i ? ep(i, s) : s;
  return await e(t, c, r);
}
a(Of, "runCustomizationInput");
function Tf(e, t, n) {
  let o = { ...e, ...n?.ctx ?? {} }, r = n?.args ?? {};
  return {
    finalCtx: o,
    finalArgs: { ...t, ...r }
  };
}
a(Tf, "applyCustomizationResult");
async function Pf(e, t) {
  if (t?.added?.onSuccess && await t.added.onSuccess({
    ctx: t.ctx,
    args: t.args,
    result: e
  }), t?.returns) {
    let n = Rb(t.returns, e);
    return Ne(n);
  }
  return Ne(e);
}
a(Pf, "finalizeFunctionReturn");
function $u(e, t) {
  let n = t.input ?? vn.input, o = t.args ?? vn.args, r = Object.entries(o), i = r.length > 0 && r.every(([, u]) => u instanceof _), s = i ? _n(o) : o, c = i ? $.object(o) : void 0;
  return /* @__PURE__ */ a(function(l) {
    let { args: d, handler: g = l, returns: b, ...x } = l, j = l.skipConvexValidation ?? !1, z = Yf(b), q = Lb(z, { skipConvexValidation: j }), Ae = q ? { returns: q } : void 0;
    if (z && wf(z, "returns"), d) {
      let { argsValidator: J, argsSchema: Z } = Mb(d), K = j ? s : { ..._n(J), ...s };
      wf(Z, "args");
      let k = e({
        args: K,
        ...Ae,
        handler: /* @__PURE__ */ a(async (B, Ge) => {
          let ir = await Of(
            n,
            B,
            Ge,
            s,
            x,
            c
          ), up = Object.keys(J), lp = Xf(Ge, up), zu = ep(Z, lp), { finalCtx: dp, finalArgs: fp } = Tf(B, zu, ir), pp = await g(dp, fp);
          return Pf(pp, { ctx: B, args: zu, added: ir, returns: z });
        }, "handler")
      }), O = c ? $.object({
        ...Z._zod.def.shape,
        ...c._zod.def.shape
      }) : Z;
      return Sf(k, O, z), k;
    }
    let ve = e({
      args: s,
      ...Ae,
      handler: /* @__PURE__ */ a(async (J, Z) => {
        let K = Z, k = await Of(
          n,
          J,
          Z,
          s,
          x,
          c
        ), { finalCtx: O, finalArgs: B } = Tf(J, K, k), Ge = await g(O, B);
        return Pf(Ge, { ctx: J, args: K, added: k, returns: z });
      }, "handler")
    });
    return Sf(ve, c ?? void 0, z), ve;
  }, "customBuilder");
}
a($u, "customFnBuilder");
function Uf(e, t) {
  return $u(e, t);
}
a(Uf, "zCustomQuery");
function Df(e, t) {
  return $u(
    e,
    t
  );
}
a(Df, "zCustomMutation");
function Ef(e, t) {
  return $u(
    e,
    t
  );
}
a(Ef, "zCustomAction");
function tp(e, t, n) {
  let o = n?.wrapDb !== !1;
  if (!o && n?.underlyingDb)
    throw new Error(
      "[zodvex] initZodvex: `underlyingDb` requires the codec db wrapper \u2014 remove `wrapDb: false` or drop `underlyingDb`."
    );
  let r = Eb(e.__zodTableMap, {
    underlyingDb: n?.underlyingDb
  }), i = Bb(), s = n?.registry, c = Vb(s, i), u = {
    query: o ? r.query : i,
    mutation: qb(o ? r.mutation : i, s),
    action: c
  };
  return {
    zq: bt(t.query, u.query, Uf),
    zm: bt(t.mutation, u.mutation, Df),
    za: bt(t.action, u.action, Ef),
    ziq: bt(t.internalQuery, u.query, Uf),
    zim: bt(t.internalMutation, u.mutation, Df),
    zia: bt(t.internalAction, u.action, Ef)
  };
}
a(tp, "initZodvex");
function Bb() {
  return { args: {}, input: vn.input };
}
a(Bb, "createNoOpCustomization");
function Vb(e, t) {
  return e ? {
    args: {},
    input: /* @__PURE__ */ a(async (n) => ({
      // Auto-encode codec args at outbound call sites: runQuery/runMutation
      // (encode args, decode result) and scheduler.runAfter/runAt (encode args).
      ctx: Mf(e(), n),
      args: {}
    }), "input")
  } : t;
}
a(Vb, "createActionCustomization");
function qb(e, t) {
  return t ? {
    args: {},
    input: /* @__PURE__ */ a(async (n, o, r) => {
      let i = await e.input(n, {}, r), s = Mf(t(), n);
      return {
        ctx: { ...i.ctx, ...s },
        args: {}
      };
    }, "input")
  } : e;
}
a(qb, "createMutationCustomization");
function Jb(e, t) {
  return {
    args: t.args ?? {},
    input: /* @__PURE__ */ a(async (n, o, r) => {
      let i = await e.input(n, {}, r), s = { ...n, ...i.ctx };
      if (!t.input)
        return { ctx: i.ctx, args: {} };
      let c = await t.input(s, o, r);
      return {
        ctx: { ...i.ctx, ...c.ctx ?? {} },
        args: c.args ?? {},
        ...c.onSuccess && { onSuccess: c.onSuccess }
      };
    }, "input")
  };
}
a(Jb, "composeCustomizations");
function bt(e, t, n) {
  let o = n(e, t);
  return o.withContext = (r) => {
    let i = Jb(t, r);
    return n(e, i);
  }, o;
}
a(bt, "createZodvexBuilder");
function kn(e) {
  let t = $.string().check(
    $.refine((o) => typeof o == "string" && o.length > 0, {
      message: `Invalid ID for table "${e}"`
    }),
    $.describe(`convexId:${e}`)
  );
  $n.setMetadata(t, {
    isConvexId: !0,
    tableName: e
  });
  let n = t;
  return n._tableName = e, n;
}
a(kn, "id");
function rp(e) {
  return e instanceof Y || e instanceof Te;
}
a(rp, "isZodUnion");
function np(e) {
  return e instanceof Y, e._zod.def.options;
}
a(np, "getUnionOptions");
function Wb(e) {
  if (e.length < 2)
    throw new Error(
      `z.union() requires at least 2 options, but received ${e.length}. This indicates an invalid union schema was passed to zodTable().`
    );
}
a(Wb, "assertUnionOptions");
function ip(e) {
  return Wb(e), $.union(e);
}
a(ip, "createUnionFromOptions");
function Kb(e, t) {
  if (rp(t)) {
    let o = np(t).map((r) => {
      if (r instanceof L) {
        let i = {
          ...r._zod.def.shape,
          _id: kn(e),
          _creationTime: $.number()
        };
        return V(r, { ...r._zod.def, shape: i });
      }
      return r;
    });
    return ip(o);
  }
  if (t instanceof L) {
    let n = { ...t._zod.def.shape, _id: kn(e), _creationTime: $.number() };
    return V(t, { ...t._zod.def, shape: n });
  }
  return t;
}
a(Kb, "addSystemFields");
function Gb(e) {
  return e instanceof F ? e : new F({ type: "optional", innerType: e });
}
a(Gb, "ensureOptional");
function Xb(e) {
  let t = {};
  for (let [n, o] of Object.entries(e))
    t[n] = Gb(o);
  return t;
}
a(Xb, "createPartialShape");
function Zf(e, t) {
  return $.object({
    _id: kn(e),
    _creationTime: $.optional($.number()),
    ...Xb(t)
  });
}
a(Zf, "createUpdateObjectSchema");
function Hb(e, t) {
  if (rp(t)) {
    let n = np(t).map((o) => o instanceof L ? Zf(e, o._zod.def.shape) : o);
    return ip(n);
  }
  return t instanceof L ? Zf(e, t._zod.def.shape) : t;
}
a(Hb, "createSchemaUpdateSchema");
var Nf = /* @__PURE__ */ Symbol.for("zodvex.zxDate");
function Qb(e) {
  e[Nf] = !0;
  let t = e._zod?.def;
  return t && (t[Nf] = !0), e;
}
a(Qb, "brandZxDate");
function Yb() {
  return Qb(
    Vf(
      $.number(),
      // Wire: timestamp
      $.custom((e) => e instanceof Date, {
        message: "Expected Date instance"
      }),
      {
        decode: /* @__PURE__ */ a((e) => new Date(e), "decode"),
        encode: /* @__PURE__ */ a((e) => e.getTime(), "encode")
      }
    )
  );
}
a(Yb, "date");
function ex(e, t, n, o) {
  let r = Vf(e, t, n);
  return o?.brand && Ab(r, o.brand), r;
}
a(ex, "codec");
function In(e) {
  let t = /* @__PURE__ */ Symbol.for(`zodvex.zx.cache.${e}`), n = globalThis, o = n[t];
  if (o) return o;
  let r = /* @__PURE__ */ new WeakMap();
  return n[t] = r, r;
}
a(In, "sharedWeakMap");
var Af = In("base"), Cf = In("doc"), Rf = In("update"), Ff = In("docArray");
function _u(e) {
  let t = e.schema;
  return t instanceof _ ? t : e.fields;
}
a(_u, "slimCacheKey");
function wu(e) {
  let t = e.schema;
  if (t?.base instanceof _) return t.base;
  if (t instanceof _) return t;
  let n = Af.get(e.fields);
  if (n) return n;
  if (Object.keys(e.fields).length === 0)
    throw new Error(`[zodvex] Cannot derive base schema for model '${e.name}'`);
  let o = $.object(e.fields);
  return Af.set(e.fields, o), o;
}
a(wu, "base");
function op(e) {
  let t = e.schema;
  if (t?.doc instanceof _) return t.doc;
  let n = _u(e), o = Cf.get(n);
  if (o) return o;
  let r = Kb(e.name, wu(e));
  return Cf.set(n, r), r;
}
a(op, "doc");
function tx(e) {
  let t = e.schema;
  if (t?.update instanceof _) return t.update;
  let n = _u(e), o = Rf.get(n);
  if (o) return o;
  let r = Hb(e.name, wu(e));
  return Rf.set(n, r), r;
}
a(tx, "update");
function rx(e) {
  let t = e.schema;
  if (t?.docArray instanceof _) return t.docArray;
  let n = _u(e), o = Ff.get(n);
  if (o) return o;
  let r = $.array(op(e));
  return Ff.set(n, r), r;
}
a(rx, "docArray");
function ap(e) {
  return new de({ type: "nullable", innerType: e });
}
a(ap, "nullable");
function xn(e) {
  return new F({ type: "optional", innerType: e });
}
a(xn, "optional");
function vu(e) {
  return xn(ap(e));
}
a(vu, "nullableOptional2");
function nx() {
  return $.object({
    numItems: $.number(),
    cursor: ap($.string()),
    endCursor: vu($.string()),
    id: xn($.number()),
    maximumRowsRead: xn($.number()),
    maximumBytesRead: xn($.number())
  });
}
a(nx, "paginationOpts");
function ix(e) {
  return $.object({
    page: $.array(e),
    isDone: $.boolean(),
    continueCursor: $.string(),
    splitCursor: vu($.string()),
    pageStatus: vu($.enum(["SplitRecommended", "SplitRequired"]))
  });
}
a(ix, "paginationResult");
var yu = {
  /**
   * Date ↔ timestamp codec
   * @see {@link date}
   */
  date: Yb,
  /**
   * Convex ID validator
   * @see {@link id}
   */
  id: kn,
  /**
   * Custom codec builder
   * @see {@link codec}
   */
  codec: ex,
  /**
   * Pagination options schema matching Convex's PaginationOptions type
   * @see {@link paginationOpts}
   */
  paginationOpts: nx,
  /**
   * Paginated result schema wrapping any item schema in Convex's PaginationResult shape
   * @see {@link paginationResult}
   */
  paginationResult: ix,
  /**
   * Base schema for a model (user fields only; no system fields).
   * For object models reconstructs from fields; for union models returns the
   * user-supplied union. Cached per-model.
   * @see {@link base}
   */
  base: wu,
  /**
   * Doc schema: model fields + _id + _creationTime
   * @see {@link doc}
   */
  doc: op,
  /**
   * Update schema: _id required, all other fields optional
   * @see {@link update}
   */
  update: tx,
  /**
   * Doc array schema: z.array(doc(model))
   * @see {@link docArray}
   */
  docArray: rx
};
function ox(e) {
  return Qf(e)?.type === "model";
}
a(ox, "isZodModelEntry");
function sp(e) {
  let t = Qf(e);
  if (!t || t.type !== "model")
    throw new Error(`Model '${e.name}' is missing zodvex model metadata.`);
  return t;
}
a(sp, "getZodModelMeta");
function ax(e) {
  let t = sp(e), o = t.definitionSource === "schema" || t.definitionSource == null && Object.keys(e.fields).length === 0 ? Le(Lf(yu.base(e))) : Le(_n(e.fields));
  for (let [r, i] of Object.entries(e.indexes)) {
    let s = i.filter((c) => c !== "_creationTime");
    o = o.index(r, s);
  }
  for (let [r, i] of Object.entries(e.searchIndexes))
    o = o.searchIndex(r, i);
  for (let [r, i] of Object.entries(e.vectorIndexes))
    o = o.vectorIndex(r, i);
  return o;
}
a(ax, "tableFromModel");
function cp(e) {
  let t = {}, n = {};
  for (let [i, s] of Object.entries(e))
    if (ox(s)) {
      if (s.name !== i)
        throw new Error(
          `Model name '${s.name}' does not match key '${i}'. The model name must match the key in the schema definition.`
        );
      t[i] = ax(s);
      let c = sp(s);
      c.schemas ? n[i] = {
        doc: c.schemas.doc,
        insert: c.schemas.insert
      } : n[i] = {
        doc: yu.doc(s),
        insert: yu.base(s)
      };
    } else
      t[i] = s.table, n[i] = {
        doc: s.schema.doc,
        insert: s.schema.insert
      };
  let o = Sr(t);
  return Object.assign(o, { __zodTableMap: n });
}
a(cp, "defineZodSchema");

// graphProbe.ts
var cx = { query: Xn, mutation: Kn, action: Qn, internalQuery: Hn, internalMutation: Gn, internalAction: Yn }, ux = { kind: "mini", schemaHelpers: !0, server: cx, s: { number: tn, string: Kt, boolean: rn, optional: cn, nullable: un, object: Xc, array: er, union: an, date: Gc, codec: nu, instanceof: ou, parse: ne, encode: Q }, defineZodModel: mf, defineZodSchema: cp, initZodvex: tp }, lx = cl(ux), dx = { count: 0, width: 32, profile: "codec-rich", entries: 0 }, ku = lx(dx), Vj = sx({ args: {}, returns: m.object({ checksum: m.number(), output: m.object({ seq: m.number(), at: m.number(), secret: m.string(), payload: m.string() }), manifest: m.any(), nonce: m.string() }), handler: /* @__PURE__ */ a(() => {
  let e = ku.operation();
  return globalThis.gc(), globalThis.gc(), { checksum: ku.checksum(), output: e, manifest: ku.manifest, nonce: "b13568cc-7948-493d-8e64-e029c2b84637" };
}, "handler") });
export {
  Vj as default
};
