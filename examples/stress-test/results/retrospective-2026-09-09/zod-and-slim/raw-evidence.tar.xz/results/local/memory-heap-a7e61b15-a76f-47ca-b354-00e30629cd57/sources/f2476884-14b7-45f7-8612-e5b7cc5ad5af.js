var Tu = Object.defineProperty;
var a = (e, t) => Tu(e, "name", { value: t, configurable: !0 });
var Ce = (e, t) => {
  for (var n in t)
    Tu(e, n, { get: t[n], enumerable: !0 });
};

// graphProbe.ts
import { query as $$ } from "convex:/_system/repl/wrappers.js";

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/base64.js
var ye = [], ce = [], _p = Uint8Array, jn = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
for (Re = 0, Pu = jn.length; Re < Pu; ++Re)
  ye[Re] = jn[Re], ce[jn.charCodeAt(Re)] = Re;
var Re, Pu;
ce[45] = 62;
ce[95] = 63;
function wp(e) {
  var t = e.length;
  if (t % 4 > 0)
    throw new Error("Invalid string. Length must be a multiple of 4");
  var n = e.indexOf("=");
  n === -1 && (n = t);
  var o = n === t ? 0 : 4 - n % 4;
  return [n, o];
}
a(wp, "getLens");
function kp(e, t, n) {
  return (t + n) * 3 / 4 - n;
}
a(kp, "_byteLength");
function _t(e) {
  var t, n = wp(e), o = n[0], r = n[1], i = new _p(kp(e, o, r)), s = 0, c = r > 0 ? o - 4 : o, u;
  for (u = 0; u < c; u += 4)
    t = ce[e.charCodeAt(u)] << 18 | ce[e.charCodeAt(u + 1)] << 12 | ce[e.charCodeAt(u + 2)] << 6 | ce[e.charCodeAt(u + 3)], i[s++] = t >> 16 & 255, i[s++] = t >> 8 & 255, i[s++] = t & 255;
  return r === 2 && (t = ce[e.charCodeAt(u)] << 2 | ce[e.charCodeAt(u + 1)] >> 4, i[s++] = t & 255), r === 1 && (t = ce[e.charCodeAt(u)] << 10 | ce[e.charCodeAt(u + 1)] << 4 | ce[e.charCodeAt(u + 2)] >> 2, i[s++] = t >> 8 & 255, i[s++] = t & 255), i;
}
a(_t, "toByteArray");
function Ip(e) {
  return ye[e >> 18 & 63] + ye[e >> 12 & 63] + ye[e >> 6 & 63] + ye[e & 63];
}
a(Ip, "tripletToBase64");
function zp(e, t, n) {
  for (var o, r = [], i = t; i < n; i += 3)
    o = (e[i] << 16 & 16711680) + (e[i + 1] << 8 & 65280) + (e[i + 2] & 255), r.push(Ip(o));
  return r.join("");
}
a(zp, "encodeChunk");
function wt(e) {
  for (var t, n = e.length, o = n % 3, r = [], i = 16383, s = 0, c = n - o; s < c; s += i)
    r.push(
      zp(
        e,
        s,
        s + i > c ? c : s + i
      )
    );
  return o === 1 ? (t = e[n - 1], r.push(ye[t >> 2] + ye[t << 4 & 63] + "==")) : o === 2 && (t = (e[n - 2] << 8) + e[n - 1], r.push(
    ye[t >> 10] + ye[t >> 4 & 63] + ye[t << 2 & 63] + "="
  )), r.join("");
}
a(wt, "fromByteArray");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/common/index.js
function ke(e) {
  if (e === void 0)
    return {};
  if (!ar(e))
    throw new Error(
      `The arguments to a Convex function must be an object. Received: ${e}`
    );
  return e;
}
a(ke, "parseArgs");
function ar(e) {
  let t = typeof e == "object", n = Object.getPrototypeOf(e), o = n === null || n === Object.prototype || // Objects generated from other contexts (e.g. across Node.js `vm` modules) will not satisfy the previous
  // conditions but are still simple objects.
  n?.constructor?.name === "Object";
  return t && o;
}
a(ar, "isSimpleObject");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/value.js
var Nu = !0, He = BigInt("-9223372036854775808"), Un = BigInt("9223372036854775807"), Tn = BigInt("0"), Sp = BigInt("8"), jp = BigInt("256");
function Zu(e) {
  return Number.isNaN(e) || !Number.isFinite(e) || Object.is(e, -0);
}
a(Zu, "isSpecial");
function Op(e) {
  e < Tn && (e -= He + He);
  let t = e.toString(16);
  t.length % 2 === 1 && (t = "0" + t);
  let n = new Uint8Array(new ArrayBuffer(8)), o = 0;
  for (let r of t.match(/.{2}/g).reverse())
    n.set([parseInt(r, 16)], o++), e >>= Sp;
  return wt(n);
}
a(Op, "slowBigIntToBase64");
function Tp(e) {
  let t = _t(e);
  if (t.byteLength !== 8)
    throw new Error(
      `Received ${t.byteLength} bytes, expected 8 for $integer`
    );
  let n = Tn, o = Tn;
  for (let r of t)
    n += BigInt(r) * jp ** o, o++;
  return n > Un && (n += He + He), n;
}
a(Tp, "slowBase64ToBigInt");
function Pp(e) {
  if (e < He || Un < e)
    throw new Error(
      `BigInt ${e} does not fit into a 64-bit signed integer.`
    );
  let t = new ArrayBuffer(8);
  return new DataView(t).setBigInt64(0, e, !0), wt(new Uint8Array(t));
}
a(Pp, "modernBigIntToBase64");
function Up(e) {
  let t = _t(e);
  if (t.byteLength !== 8)
    throw new Error(
      `Received ${t.byteLength} bytes, expected 8 for $integer`
    );
  return new DataView(t.buffer).getBigInt64(0, !0);
}
a(Up, "modernBase64ToBigInt");
var Dp = DataView.prototype.setBigInt64 ? Pp : Op, Ep = DataView.prototype.getBigInt64 ? Up : Tp, Du = 1024;
function Pn(e) {
  if (e.length > Du)
    throw new Error(
      `Field name ${e} exceeds maximum field name length ${Du}.`
    );
  if (e.startsWith("$"))
    throw new Error(`Field name ${e} starts with a '$', which is reserved.`);
  for (let t = 0; t < e.length; t += 1) {
    let n = e.charCodeAt(t);
    if (n < 32 || n >= 127)
      throw new Error(
        `Field name ${e} has invalid character '${e[t]}': Field names can only contain non-control ASCII characters`
      );
  }
}
a(Pn, "validateObjectField");
function V(e) {
  if (e === null || typeof e == "boolean" || typeof e == "number" || typeof e == "string")
    return e;
  if (Array.isArray(e))
    return e.map((o) => V(o));
  if (typeof e != "object")
    throw new Error(`Unexpected type of ${e}`);
  let t = Object.entries(e);
  if (t.length === 1) {
    let o = t[0][0];
    if (o === "$bytes") {
      if (typeof e.$bytes != "string")
        throw new Error(`Malformed $bytes field on ${e}`);
      return _t(e.$bytes).buffer;
    }
    if (o === "$integer") {
      if (typeof e.$integer != "string")
        throw new Error(`Malformed $integer field on ${e}`);
      return Ep(e.$integer);
    }
    if (o === "$float") {
      if (typeof e.$float != "string")
        throw new Error(`Malformed $float field on ${e}`);
      let r = _t(e.$float);
      if (r.byteLength !== 8)
        throw new Error(
          `Received ${r.byteLength} bytes, expected 8 for $float`
        );
      let s = new DataView(r.buffer).getFloat64(0, Nu);
      if (!Zu(s))
        throw new Error(`Float ${s} should be encoded as a number`);
      return s;
    }
    if (o === "$set")
      throw new Error(
        "Received a Set which is no longer supported as a Convex type."
      );
    if (o === "$map")
      throw new Error(
        "Received a Map which is no longer supported as a Convex type."
      );
  }
  let n = {};
  for (let [o, r] of Object.entries(e))
    Pn(o), n[o] = V(r);
  return n;
}
a(V, "jsonToConvex");
var Eu = 16384;
function Fe(e) {
  let t = JSON.stringify(e, (n, o) => o === void 0 ? "undefined" : typeof o == "bigint" ? `${o.toString()}n` : o);
  if (t.length > Eu) {
    let n = "[...truncated]", o = Eu - n.length, r = t.codePointAt(o - 1);
    return r !== void 0 && r > 65535 && (o -= 1), t.substring(0, o) + n;
  }
  return t;
}
a(Fe, "stringifyValueForError");
function kt(e, t, n, o) {
  if (e === void 0) {
    let s = n && ` (present at path ${n} in original object ${Fe(
      t
    )})`;
    throw new Error(
      `undefined is not a valid Convex value${s}. To learn about Convex's supported types, see https://docs.convex.dev/using/types.`
    );
  }
  if (e === null)
    return e;
  if (typeof e == "bigint") {
    if (e < He || Un < e)
      throw new Error(
        `BigInt ${e} does not fit into a 64-bit signed integer.`
      );
    return { $integer: Dp(e) };
  }
  if (typeof e == "number")
    if (Zu(e)) {
      let s = new ArrayBuffer(8);
      return new DataView(s).setFloat64(0, e, Nu), { $float: wt(new Uint8Array(s)) };
    } else
      return e;
  if (typeof e == "boolean" || typeof e == "string")
    return e;
  if (e instanceof ArrayBuffer)
    return { $bytes: wt(new Uint8Array(e)) };
  if (Array.isArray(e))
    return e.map(
      (s, c) => kt(s, t, n + `[${c}]`, !1)
    );
  if (e instanceof Set)
    throw new Error(
      On(n, "Set", [...e], t)
    );
  if (e instanceof Map)
    throw new Error(
      On(n, "Map", [...e], t)
    );
  if (!ar(e)) {
    let s = e?.constructor?.name, c = s ? `${s} ` : "";
    throw new Error(
      On(n, c, e, t)
    );
  }
  let r = {}, i = Object.entries(e);
  i.sort(([s, c], [u, l]) => s === u ? 0 : s < u ? -1 : 1);
  for (let [s, c] of i)
    c !== void 0 ? (Pn(s), r[s] = kt(c, t, n + `.${s}`, !1)) : o && (Pn(s), r[s] = Au(
      c,
      t,
      n + `.${s}`
    ));
  return r;
}
a(kt, "convexToJsonInternal");
function On(e, t, n, o) {
  return e ? `${t}${Fe(
    n
  )} is not a supported Convex type (present at path ${e} in original object ${Fe(
    o
  )}). To learn about Convex's supported types, see https://docs.convex.dev/using/types.` : `${t}${Fe(
    n
  )} is not a supported Convex type.`;
}
a(On, "errorMessageForUnsupportedType");
function Au(e, t, n) {
  if (e === void 0)
    return { $undefined: null };
  if (t === void 0)
    throw new Error(
      `Programming error. Current value is ${Fe(
        e
      )} but original value is undefined`
    );
  return kt(e, t, n, !1);
}
a(Au, "convexOrUndefinedToJsonInternal");
function R(e) {
  return kt(e, e, "", !1);
}
a(R, "convexToJson");
function ue(e) {
  return Au(e, e, "");
}
a(ue, "convexOrUndefinedToJson");
function Cu(e) {
  return kt(e, e, "", !0);
}
a(Cu, "patchValueToJson");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/validators.js
var Np = Object.defineProperty, Zp = /* @__PURE__ */ a((e, t, n) => t in e ? Np(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), M = /* @__PURE__ */ a((e, t, n) => Zp(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), Ap = "https://docs.convex.dev/error#undefined-validator";
function It(e, t) {
  let n = t !== void 0 ? ` for field "${t}"` : "";
  throw new Error(
    `A validator is undefined${n} in ${e}. This is often caused by circular imports. See ${Ap} for details.`
  );
}
a(It, "throwUndefinedValidatorError");
var H = class {
  static {
    a(this, "BaseValidator");
  }
  constructor({ isOptional: t }) {
    M(this, "type"), M(this, "fieldPaths"), M(this, "isOptional"), M(this, "isConvexValidator"), this.isOptional = t, this.isConvexValidator = !0;
  }
}, sr = class e extends H {
  static {
    a(this, "VId");
  }
  /**
   * Usually you'd use `v.id(tableName)` instead.
   */
  constructor({
    isOptional: t,
    tableName: n
  }) {
    if (super({ isOptional: t }), M(this, "tableName"), M(this, "kind", "id"), typeof n != "string")
      throw new Error("v.id(tableName) requires a string");
    this.tableName = n;
  }
  /** @internal */
  get json() {
    return { type: "id", tableName: this.tableName };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      tableName: this.tableName
    });
  }
}, zt = class e extends H {
  static {
    a(this, "VFloat64");
  }
  constructor() {
    super(...arguments), M(this, "kind", "float64");
  }
  /** @internal */
  get json() {
    return { type: "number" };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, St = class e extends H {
  static {
    a(this, "VInt64");
  }
  constructor() {
    super(...arguments), M(this, "kind", "int64");
  }
  /** @internal */
  get json() {
    return { type: "bigint" };
  }
  /** @internal */
  asOptional() {
    return new e({ isOptional: "optional" });
  }
}, cr = class e extends H {
  static {
    a(this, "VBoolean");
  }
  constructor() {
    super(...arguments), M(this, "kind", "boolean");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, ur = class e extends H {
  static {
    a(this, "VBytes");
  }
  constructor() {
    super(...arguments), M(this, "kind", "bytes");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({ isOptional: "optional" });
  }
}, lr = class e extends H {
  static {
    a(this, "VString");
  }
  constructor() {
    super(...arguments), M(this, "kind", "string");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, dr = class e extends H {
  static {
    a(this, "VNull");
  }
  constructor() {
    super(...arguments), M(this, "kind", "null");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({ isOptional: "optional" });
  }
}, fr = class e extends H {
  static {
    a(this, "VAny");
  }
  constructor() {
    super(...arguments), M(this, "kind", "any");
  }
  /** @internal */
  get json() {
    return {
      type: this.kind
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, pr = class e extends H {
  static {
    a(this, "VObject");
  }
  /**
   * Usually you'd use `v.object({ ... })` instead.
   */
  constructor({
    isOptional: t,
    fields: n
  }) {
    super({ isOptional: t }), M(this, "fields"), M(this, "kind", "object"), globalThis.Object.entries(n).forEach(([o, r]) => {
      if (r === void 0 && It("v.object()", o), !r.isConvexValidator)
        throw new Error("v.object() entries must be validators");
    }), this.fields = n;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: globalThis.Object.fromEntries(
        globalThis.Object.entries(this.fields).map(([t, n]) => [
          t,
          {
            fieldType: n.json,
            optional: n.isOptional === "optional"
          }
        ])
      )
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      fields: this.fields
    });
  }
  /**
   * Create a new VObject with the specified fields omitted.
   * @param fields The field names to omit from this VObject.
   */
  omit(...t) {
    let n = { ...this.fields };
    for (let o of t)
      delete n[o];
    return new e({
      isOptional: this.isOptional,
      fields: n
    });
  }
  /**
   * Create a new VObject with only the specified fields.
   * @param fields The field names to pick from this VObject.
   */
  pick(...t) {
    let n = {};
    for (let o of t)
      n[o] = this.fields[o];
    return new e({
      isOptional: this.isOptional,
      fields: n
    });
  }
  /**
   * Create a new VObject with all fields marked as optional.
   */
  partial() {
    let t = {};
    for (let [n, o] of globalThis.Object.entries(this.fields))
      t[n] = o.asOptional();
    return new e({
      isOptional: this.isOptional,
      fields: t
    });
  }
  /**
   * Create a new VObject with additional fields merged in.
   * @param fields An object with additional validators to merge into this VObject.
   */
  extend(t) {
    return new e({
      isOptional: this.isOptional,
      fields: { ...this.fields, ...t }
    });
  }
}, mr = class e extends H {
  static {
    a(this, "VLiteral");
  }
  /**
   * Usually you'd use `v.literal(value)` instead.
   */
  constructor({ isOptional: t, value: n }) {
    if (super({ isOptional: t }), M(this, "value"), M(this, "kind", "literal"), typeof n != "string" && typeof n != "boolean" && typeof n != "number" && typeof n != "bigint")
      throw new Error("v.literal(value) must be a string, number, or boolean");
    this.value = n;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: R(this.value)
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      value: this.value
    });
  }
}, gr = class e extends H {
  static {
    a(this, "VArray");
  }
  /**
   * Usually you'd use `v.array(element)` instead.
   */
  constructor({
    isOptional: t,
    element: n
  }) {
    super({ isOptional: t }), M(this, "element"), M(this, "kind", "array"), n === void 0 && It("v.array()"), this.element = n;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: this.element.json
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      element: this.element
    });
  }
}, hr = class e extends H {
  static {
    a(this, "VRecord");
  }
  /**
   * Usually you'd use `v.record(key, value)` instead.
   */
  constructor({
    isOptional: t,
    key: n,
    value: o
  }) {
    if (super({ isOptional: t }), M(this, "key"), M(this, "value"), M(this, "kind", "record"), n === void 0 && It("v.record()", "key"), o === void 0 && It("v.record()", "value"), n.isOptional === "optional")
      throw new Error("Record validator cannot have optional keys");
    if (o.isOptional === "optional")
      throw new Error("Record validator cannot have optional values");
    if (!n.isConvexValidator || !o.isConvexValidator)
      throw new Error("Key and value of v.record() but be validators");
    this.key = n, this.value = o;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      // This cast is needed because TypeScript thinks the key type is too wide
      keys: this.key.json,
      values: {
        fieldType: this.value.json,
        optional: !1
      }
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      key: this.key,
      value: this.value
    });
  }
}, vr = class e extends H {
  static {
    a(this, "VUnion");
  }
  /**
   * Usually you'd use `v.union(...members)` instead.
   */
  constructor({ isOptional: t, members: n }) {
    super({ isOptional: t }), M(this, "members"), M(this, "kind", "union"), n.forEach((o, r) => {
      if (o === void 0 && It("v.union()", `member at index ${r}`), !o.isConvexValidator)
        throw new Error("All members of v.union() must be validators");
    }), this.members = n;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: this.members.map((t) => t.json)
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      members: this.members
    });
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/validator.js
function Dn(e) {
  return !!e.isConvexValidator;
}
a(Dn, "isValidator");
function jt(e) {
  return Dn(e) ? e : m.object(e);
}
a(jt, "asObjectValidator");
var m = {
  /**
   * Validates that the value is a document ID for the given table.
   *
   * IDs are strings at runtime but are typed as `Id<"tableName">` in
   * TypeScript for type safety.
   *
   * @example
   * ```typescript
   * args: { userId: v.id("users") }
   * ```
   *
   * @param tableName The name of the table.
   */
  id: /* @__PURE__ */ a((e) => new sr({
    isOptional: "required",
    tableName: e
  }), "id"),
  /**
   * Validates that the value is `null`.
   *
   * Use `returns: v.null()` for functions that don't return a meaningful value.
   * JavaScript `undefined` is not a valid Convex value, it is automatically
   * converted to `null`.
   */
  null: /* @__PURE__ */ a(() => new dr({ isOptional: "required" }), "null"),
  /**
   * Validates that the value is a JavaScript `number` (Convex Float64).
   *
   * Supports all IEEE-754 double-precision floating point numbers including
   * NaN and Infinity.
   *
   * Alias for `v.float64()`.
   */
  number: /* @__PURE__ */ a(() => new zt({ isOptional: "required" }), "number"),
  /**
   * Validates that the value is a JavaScript `number` (Convex Float64).
   *
   * Supports all IEEE-754 double-precision floating point numbers.
   */
  float64: /* @__PURE__ */ a(() => new zt({ isOptional: "required" }), "float64"),
  /**
   * @deprecated Use `v.int64()` instead.
   */
  bigint: /* @__PURE__ */ a(() => new St({ isOptional: "required" }), "bigint"),
  /**
   * Validates that the value is a JavaScript `bigint` (Convex Int64).
   *
   * Supports BigInts between -2^63 and 2^63-1.
   *
   * @example
   * ```typescript
   * args: { timestamp: v.int64() }
   * // Usage: createDoc({ timestamp: 1234567890n })
   * ```
   */
  int64: /* @__PURE__ */ a(() => new St({ isOptional: "required" }), "int64"),
  /**
   * Validates that the value is a `boolean`.
   */
  boolean: /* @__PURE__ */ a(() => new cr({ isOptional: "required" }), "boolean"),
  /**
   * Validates that the value is a `string`.
   *
   * Strings are stored as UTF-8 and their storage size is calculated as their
   * UTF-8 encoded size.
   */
  string: /* @__PURE__ */ a(() => new lr({ isOptional: "required" }), "string"),
  /**
   * Validates that the value is an `ArrayBuffer` (Convex Bytes).
   *
   * Use for binary data.
   */
  bytes: /* @__PURE__ */ a(() => new ur({ isOptional: "required" }), "bytes"),
  /**
   * Validates that the value is exactly equal to the given literal.
   *
   * Useful for discriminated unions and enum-like patterns.
   *
   * @example
   * ```typescript
   * // Discriminated union pattern:
   * v.union(
   *   v.object({ kind: v.literal("error"), message: v.string() }),
   *   v.object({ kind: v.literal("success"), value: v.number() }),
   * )
   * ```
   *
   * @param literal The literal value to compare against.
   */
  literal: /* @__PURE__ */ a((e) => new mr({ isOptional: "required", value: e }), "literal"),
  /**
   * Validates that the value is an `Array` where every element matches the
   * given validator.
   *
   * Arrays can have at most 8192 elements.
   *
   * @example
   * ```typescript
   * args: { tags: v.array(v.string()) }
   * args: { coordinates: v.array(v.number()) }
   * args: { items: v.array(v.object({ name: v.string(), qty: v.number() })) }
   * ```
   *
   * @param element The validator for the elements of the array.
   */
  array: /* @__PURE__ */ a((e) => new gr({ isOptional: "required", element: e }), "array"),
  /**
   * Validates that the value is an `Object` with the specified properties.
   *
   * Objects can have at most 1024 entries. Field names must be non-empty and
   * must not start with `"$"` or `"_"` (`_` is reserved for system fields
   * like `_id` and `_creationTime`; `$` is reserved for Convex internal use).
   *
   * @example
   * ```typescript
   * args: {
   *   user: v.object({
   *     name: v.string(),
   *     email: v.string(),
   *     age: v.optional(v.number()),
   *   })
   * }
   * ```
   *
   * @param fields An object mapping property names to their validators.
   */
  object: /* @__PURE__ */ a((e) => new pr({ isOptional: "required", fields: e }), "object"),
  /**
   * Validates that the value is a `Record` (object with dynamic keys).
   *
   * Records are objects at runtime but allow dynamic keys, unlike `v.object()`
   * which requires known property names. Keys must be ASCII characters only,
   * non-empty, and not start with `"$"` or `"_"`.
   *
   * @example
   * ```typescript
   * // Map of user IDs to scores:
   * args: { scores: v.record(v.id("users"), v.number()) }
   *
   * // Map of string keys to string values:
   * args: { metadata: v.record(v.string(), v.string()) }
   * ```
   *
   * @param keys The validator for the keys of the record.
   * @param values The validator for the values of the record.
   */
  record: /* @__PURE__ */ a((e, t) => new hr({
    isOptional: "required",
    key: e,
    value: t
  }), "record"),
  /**
   * Validates that the value matches at least one of the given validators.
   *
   * @example
   * ```typescript
   * // Allow string or number:
   * args: { value: v.union(v.string(), v.number()) }
   *
   * // Discriminated union (recommended pattern):
   * v.union(
   *   v.object({ kind: v.literal("text"), body: v.string() }),
   *   v.object({ kind: v.literal("image"), url: v.string() }),
   * )
   *
   * // Nullable value:
   * returns: v.union(v.object({ ... }), v.null())
   * ```
   *
   * @param members The validators to match against.
   */
  union: /* @__PURE__ */ a((...e) => new vr({
    isOptional: "required",
    members: e
  }), "union"),
  /**
   * A validator that accepts any Convex value without validation.
   *
   * Prefer using specific validators when possible for better type safety
   * and runtime validation.
   */
  any: /* @__PURE__ */ a(() => new fr({ isOptional: "required" }), "any"),
  /**
   * Makes a property optional in an object validator.
   *
   * An optional property can be omitted entirely when creating a document or
   * calling a function. This is different from `v.nullable()` which requires
   * the property to be present but allows `null`.
   *
   * @example
   * ```typescript
   * v.object({
   *   name: v.string(),              // required
   *   nickname: v.optional(v.string()), // can be omitted
   * })
   *
   * // Valid: { name: "Alice" }
   * // Valid: { name: "Alice", nickname: "Ali" }
   * // Invalid: { name: "Alice", nickname: null }  - use v.nullable() for this
   * ```
   *
   * @param value The property value validator to make optional.
   */
  optional: /* @__PURE__ */ a((e) => e.asOptional(), "optional"),
  /**
   * Allows a value to be either the given type or `null`.
   *
   * This is shorthand for `v.union(value, v.null())`. Unlike `v.optional()`,
   * the property must still be present, but may be `null`.
   *
   * @example
   * ```typescript
   * v.object({
   *   name: v.string(),
   *   deletedAt: v.nullable(v.number()), // must be present, can be null
   * })
   *
   * // Valid: { name: "Alice", deletedAt: null }
   * // Valid: { name: "Alice", deletedAt: 1234567890 }
   * // Invalid: { name: "Alice" }  - deletedAt is required
   * ```
   */
  nullable: /* @__PURE__ */ a((e) => m.union(e, m.null()), "nullable")
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/errors.js
var Cp = Object.defineProperty, Rp = /* @__PURE__ */ a((e, t, n) => t in e ? Cp(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), En = /* @__PURE__ */ a((e, t, n) => Rp(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), Ru, Fu, Fp = Symbol.for("ConvexError"), Qe = class extends (Fu = Error, Ru = Fp, Fu) {
  static {
    a(this, "ConvexError");
  }
  constructor(t) {
    super(typeof t == "string" ? t : Fe(t)), En(this, "name", "ConvexError"), En(this, "data"), En(this, Ru, !0), this.data = t;
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/compare_utf8.js
var Mu = /* @__PURE__ */ a(() => Array.from({ length: 4 }, () => 0), "arr"), M$ = Mu(), L$ = Mu();

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/index.js
var K = "1.32.0";

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/syscall.js
function Ot(e, t) {
  if (typeof Convex > "u" || Convex.syscall === void 0)
    throw new Error(
      "The Convex database and auth objects are being used outside of a Convex backend. Did you mean to use `useQuery` or `useMutation` to call a Convex function?"
    );
  let n = Convex.syscall(e, JSON.stringify(t));
  return JSON.parse(n);
}
a(Ot, "performSyscall");
async function U(e, t) {
  if (typeof Convex > "u" || Convex.asyncSyscall === void 0)
    throw new Error(
      "The Convex database and auth objects are being used outside of a Convex backend. Did you mean to use `useQuery` or `useMutation` to call a Convex function?"
    );
  let n;
  try {
    n = await Convex.asyncSyscall(e, JSON.stringify(t));
  } catch (o) {
    if (o.data !== void 0) {
      let r = new Qe(o.message);
      throw r.data = V(o.data), r;
    }
    throw new Error(o.message);
  }
  return JSON.parse(n);
}
a(U, "performAsyncSyscall");
function yr(e, t) {
  if (typeof Convex > "u" || Convex.jsSyscall === void 0)
    throw new Error(
      "The Convex database and auth objects are being used outside of a Convex backend. Did you mean to use `useQuery` or `useMutation` to call a Convex function?"
    );
  return Convex.jsSyscall(e, t);
}
a(yr, "performJsSyscall");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/functionName.js
var Tt = Symbol.for("functionName");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/components/paths.js
var Lu = Symbol.for("toReferencePath");
function Lp(e) {
  return e[Lu] ?? null;
}
a(Lp, "extractReferencePath");
function Bp(e) {
  return e.startsWith("function://");
}
a(Bp, "isFunctionHandle");
function fe(e) {
  let t;
  if (typeof e == "string")
    Bp(e) ? t = { functionHandle: e } : t = { name: e };
  else if (e[Tt])
    t = { name: e[Tt] };
  else {
    let n = Lp(e);
    if (!n)
      throw new Error(`${e} is not a functionReference`);
    t = { reference: n };
  }
  return t;
}
a(fe, "getFunctionAddress");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/actions_impl.js
function Nn(e, t, n) {
  return {
    ...fe(t),
    args: R(ke(n)),
    version: K,
    requestId: e
  };
}
a(Nn, "syscallArgs");
function Bu(e) {
  return {
    runQuery: /* @__PURE__ */ a(async (t, n) => {
      let o = await U(
        "1.0/actions/query",
        Nn(e, t, n)
      );
      return V(o);
    }, "runQuery"),
    runMutation: /* @__PURE__ */ a(async (t, n) => {
      let o = await U(
        "1.0/actions/mutation",
        Nn(e, t, n)
      );
      return V(o);
    }, "runMutation"),
    runAction: /* @__PURE__ */ a(async (t, n) => {
      let o = await U(
        "1.0/actions/action",
        Nn(e, t, n)
      );
      return V(o);
    }, "runAction")
  };
}
a(Bu, "setupActionCalls");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/vector_search.js
var Vp = Object.defineProperty, qp = /* @__PURE__ */ a((e, t, n) => t in e ? Vp(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), Vu = /* @__PURE__ */ a((e, t, n) => qp(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), br = class {
  static {
    a(this, "FilterExpression");
  }
  /**
   * @internal
   */
  constructor() {
    Vu(this, "_isExpression"), Vu(this, "_value");
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/validate.js
function P(e, t, n, o) {
  if (e === void 0)
    throw new TypeError(
      `Must provide arg ${t} \`${o}\` to \`${n}\``
    );
}
a(P, "validateArg");
function qu(e, t, n, o) {
  if (!Number.isInteger(e) || e < 0)
    throw new TypeError(
      `Arg ${t} \`${o}\` to \`${n}\` must be a non-negative integer`
    );
}
a(qu, "validateArgIsNonNegativeInteger");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/vector_search_impl.js
var Jp = Object.defineProperty, Wp = /* @__PURE__ */ a((e, t, n) => t in e ? Jp(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), Zn = /* @__PURE__ */ a((e, t, n) => Wp(e, typeof t != "symbol" ? t + "" : t, n), "__publicField");
function Ju(e) {
  return async (t, n, o) => {
    if (P(t, 1, "vectorSearch", "tableName"), P(n, 2, "vectorSearch", "indexName"), P(o, 3, "vectorSearch", "query"), !o.vector || !Array.isArray(o.vector) || o.vector.length === 0)
      throw Error("`vector` must be a non-empty Array in vectorSearch");
    return await new An(
      e,
      t + "." + n,
      o
    ).collect();
  };
}
a(Ju, "setupActionVectorSearch");
var An = class {
  static {
    a(this, "VectorQueryImpl");
  }
  constructor(t, n, o) {
    Zn(this, "requestId"), Zn(this, "state"), this.requestId = t;
    let r = o.filter ? $r(o.filter(Kp)) : null;
    this.state = {
      type: "preparing",
      query: {
        indexName: n,
        limit: o.limit,
        vector: o.vector,
        expressions: r
      }
    };
  }
  async collect() {
    if (this.state.type === "consumed")
      throw new Error("This query is closed and can't emit any more values.");
    let t = this.state.query;
    this.state = { type: "consumed" };
    let { results: n } = await U("1.0/actions/vectorSearch", {
      requestId: this.requestId,
      version: K,
      query: t
    });
    return n;
  }
}, Ye = class extends br {
  static {
    a(this, "ExpressionImpl");
  }
  constructor(t) {
    super(), Zn(this, "inner"), this.inner = t;
  }
  serialize() {
    return this.inner;
  }
};
function $r(e) {
  return e instanceof Ye ? e.serialize() : { $literal: ue(e) };
}
a($r, "serializeExpression");
var Kp = {
  //  Comparisons  /////////////////////////////////////////////////////////////
  eq(e, t) {
    if (typeof e != "string")
      throw new Error("The first argument to `q.eq` must be a field name.");
    return new Ye({
      $eq: [
        $r(new Ye({ $field: e })),
        $r(t)
      ]
    });
  },
  //  Logic  ///////////////////////////////////////////////////////////////////
  or(...e) {
    return new Ye({ $or: e.map($r) });
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/authentication_impl.js
function xr(e) {
  return {
    getUserIdentity: /* @__PURE__ */ a(async () => await U("1.0/getUserIdentity", {
      requestId: e
    }), "getUserIdentity")
  };
}
a(xr, "setupAuth");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/filter_builder.js
var Gp = Object.defineProperty, Xp = /* @__PURE__ */ a((e, t, n) => t in e ? Gp(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), Wu = /* @__PURE__ */ a((e, t, n) => Xp(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), _r = class {
  static {
    a(this, "Expression");
  }
  /**
   * @internal
   */
  constructor() {
    Wu(this, "_isExpression"), Wu(this, "_value");
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/filter_builder_impl.js
var Hp = Object.defineProperty, Qp = /* @__PURE__ */ a((e, t, n) => t in e ? Hp(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), Yp = /* @__PURE__ */ a((e, t, n) => Qp(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), G = class extends _r {
  static {
    a(this, "ExpressionImpl");
  }
  constructor(t) {
    super(), Yp(this, "inner"), this.inner = t;
  }
  serialize() {
    return this.inner;
  }
};
function N(e) {
  return e instanceof G ? e.serialize() : { $literal: ue(e) };
}
a(N, "serializeExpression");
var Ku = {
  //  Comparisons  /////////////////////////////////////////////////////////////
  eq(e, t) {
    return new G({
      $eq: [N(e), N(t)]
    });
  },
  neq(e, t) {
    return new G({
      $neq: [N(e), N(t)]
    });
  },
  lt(e, t) {
    return new G({
      $lt: [N(e), N(t)]
    });
  },
  lte(e, t) {
    return new G({
      $lte: [N(e), N(t)]
    });
  },
  gt(e, t) {
    return new G({
      $gt: [N(e), N(t)]
    });
  },
  gte(e, t) {
    return new G({
      $gte: [N(e), N(t)]
    });
  },
  //  Arithmetic  //////////////////////////////////////////////////////////////
  add(e, t) {
    return new G({
      $add: [N(e), N(t)]
    });
  },
  sub(e, t) {
    return new G({
      $sub: [N(e), N(t)]
    });
  },
  mul(e, t) {
    return new G({
      $mul: [N(e), N(t)]
    });
  },
  div(e, t) {
    return new G({
      $div: [N(e), N(t)]
    });
  },
  mod(e, t) {
    return new G({
      $mod: [N(e), N(t)]
    });
  },
  neg(e) {
    return new G({ $neg: N(e) });
  },
  //  Logic  ///////////////////////////////////////////////////////////////////
  and(...e) {
    return new G({ $and: e.map(N) });
  },
  or(...e) {
    return new G({ $or: e.map(N) });
  },
  not(e) {
    return new G({ $not: N(e) });
  },
  //  Other  ///////////////////////////////////////////////////////////////////
  field(e) {
    return new G({ $field: e });
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/index_range_builder.js
var em = Object.defineProperty, tm = /* @__PURE__ */ a((e, t, n) => t in e ? em(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), rm = /* @__PURE__ */ a((e, t, n) => tm(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), wr = class {
  static {
    a(this, "IndexRange");
  }
  /**
   * @internal
   */
  constructor() {
    rm(this, "_isIndexRange");
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/index_range_builder_impl.js
var nm = Object.defineProperty, im = /* @__PURE__ */ a((e, t, n) => t in e ? nm(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), Gu = /* @__PURE__ */ a((e, t, n) => im(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), kr = class e extends wr {
  static {
    a(this, "IndexRangeBuilderImpl");
  }
  constructor(t) {
    super(), Gu(this, "rangeExpressions"), Gu(this, "isConsumed"), this.rangeExpressions = t, this.isConsumed = !1;
  }
  static new() {
    return new e([]);
  }
  consume() {
    if (this.isConsumed)
      throw new Error(
        "IndexRangeBuilder has already been used! Chain your method calls like `q => q.eq(...).eq(...)`. See https://docs.convex.dev/using/indexes"
      );
    this.isConsumed = !0;
  }
  eq(t, n) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Eq",
        fieldPath: t,
        value: ue(n)
      })
    );
  }
  gt(t, n) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Gt",
        fieldPath: t,
        value: ue(n)
      })
    );
  }
  gte(t, n) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Gte",
        fieldPath: t,
        value: ue(n)
      })
    );
  }
  lt(t, n) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Lt",
        fieldPath: t,
        value: ue(n)
      })
    );
  }
  lte(t, n) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Lte",
        fieldPath: t,
        value: ue(n)
      })
    );
  }
  export() {
    return this.consume(), this.rangeExpressions;
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/search_filter_builder.js
var om = Object.defineProperty, am = /* @__PURE__ */ a((e, t, n) => t in e ? om(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), sm = /* @__PURE__ */ a((e, t, n) => am(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), Ir = class {
  static {
    a(this, "SearchFilter");
  }
  /**
   * @internal
   */
  constructor() {
    sm(this, "_isSearchFilter");
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/search_filter_builder_impl.js
var cm = Object.defineProperty, um = /* @__PURE__ */ a((e, t, n) => t in e ? cm(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), Xu = /* @__PURE__ */ a((e, t, n) => um(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), zr = class e extends Ir {
  static {
    a(this, "SearchFilterBuilderImpl");
  }
  constructor(t) {
    super(), Xu(this, "filters"), Xu(this, "isConsumed"), this.filters = t, this.isConsumed = !1;
  }
  static new() {
    return new e([]);
  }
  consume() {
    if (this.isConsumed)
      throw new Error(
        "SearchFilterBuilder has already been used! Chain your method calls like `q => q.search(...).eq(...)`."
      );
    this.isConsumed = !0;
  }
  search(t, n) {
    return P(t, 1, "search", "fieldName"), P(n, 2, "search", "query"), this.consume(), new e(
      this.filters.concat({
        type: "Search",
        fieldPath: t,
        value: n
      })
    );
  }
  eq(t, n) {
    return P(t, 1, "eq", "fieldName"), arguments.length !== 2 && P(n, 2, "search", "value"), this.consume(), new e(
      this.filters.concat({
        type: "Eq",
        fieldPath: t,
        value: ue(n)
      })
    );
  }
  export() {
    return this.consume(), this.filters;
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/query_impl.js
var lm = Object.defineProperty, dm = /* @__PURE__ */ a((e, t, n) => t in e ? lm(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), Cn = /* @__PURE__ */ a((e, t, n) => dm(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), Hu = 256, et = class {
  static {
    a(this, "QueryInitializerImpl");
  }
  constructor(t) {
    Cn(this, "tableName"), this.tableName = t;
  }
  withIndex(t, n) {
    P(t, 1, "withIndex", "indexName");
    let o = kr.new();
    return n !== void 0 && (o = n(o)), new Me({
      source: {
        type: "IndexRange",
        indexName: this.tableName + "." + t,
        range: o.export(),
        order: null
      },
      operators: []
    });
  }
  withSearchIndex(t, n) {
    P(t, 1, "withSearchIndex", "indexName"), P(n, 2, "withSearchIndex", "searchFilter");
    let o = zr.new();
    return new Me({
      source: {
        type: "Search",
        indexName: this.tableName + "." + t,
        filters: n(o).export()
      },
      operators: []
    });
  }
  fullTableScan() {
    return new Me({
      source: {
        type: "FullTableScan",
        tableName: this.tableName,
        order: null
      },
      operators: []
    });
  }
  order(t) {
    return this.fullTableScan().order(t);
  }
  // This is internal API and should not be exposed to developers yet.
  async count() {
    let t = await U("1.0/count", {
      table: this.tableName
    });
    return V(t);
  }
  filter(t) {
    return this.fullTableScan().filter(t);
  }
  limit(t) {
    return this.fullTableScan().limit(t);
  }
  collect() {
    return this.fullTableScan().collect();
  }
  take(t) {
    return this.fullTableScan().take(t);
  }
  paginate(t) {
    return this.fullTableScan().paginate(t);
  }
  first() {
    return this.fullTableScan().first();
  }
  unique() {
    return this.fullTableScan().unique();
  }
  [Symbol.asyncIterator]() {
    return this.fullTableScan()[Symbol.asyncIterator]();
  }
};
function Qu(e) {
  throw new Error(
    e === "consumed" ? "This query is closed and can't emit any more values." : "This query has been chained with another operator and can't be reused."
  );
}
a(Qu, "throwClosedError");
var Me = class e {
  static {
    a(this, "QueryImpl");
  }
  constructor(t) {
    Cn(this, "state"), Cn(this, "tableNameForErrorMessages"), this.state = { type: "preparing", query: t }, t.source.type === "FullTableScan" ? this.tableNameForErrorMessages = t.source.tableName : this.tableNameForErrorMessages = t.source.indexName.split(".")[0];
  }
  takeQuery() {
    if (this.state.type !== "preparing")
      throw new Error(
        "A query can only be chained once and can't be chained after iteration begins."
      );
    let t = this.state.query;
    return this.state = { type: "closed" }, t;
  }
  startQuery() {
    if (this.state.type === "executing")
      throw new Error("Iteration can only begin on a query once.");
    (this.state.type === "closed" || this.state.type === "consumed") && Qu(this.state.type);
    let t = this.state.query, { queryId: n } = Ot("1.0/queryStream", { query: t, version: K });
    return this.state = { type: "executing", queryId: n }, n;
  }
  closeQuery() {
    if (this.state.type === "executing") {
      let t = this.state.queryId;
      Ot("1.0/queryCleanup", { queryId: t });
    }
    this.state = { type: "consumed" };
  }
  order(t) {
    P(t, 1, "order", "order");
    let n = this.takeQuery();
    if (n.source.type === "Search")
      throw new Error(
        "Search queries must always be in relevance order. Can not set order manually."
      );
    if (n.source.order !== null)
      throw new Error("Queries may only specify order at most once");
    return n.source.order = t, new e(n);
  }
  filter(t) {
    P(t, 1, "filter", "predicate");
    let n = this.takeQuery();
    if (n.operators.length >= Hu)
      throw new Error(
        `Can't construct query with more than ${Hu} operators`
      );
    return n.operators.push({
      filter: N(t(Ku))
    }), new e(n);
  }
  limit(t) {
    P(t, 1, "limit", "n");
    let n = this.takeQuery();
    return n.operators.push({ limit: t }), new e(n);
  }
  [Symbol.asyncIterator]() {
    return this.startQuery(), this;
  }
  async next() {
    (this.state.type === "closed" || this.state.type === "consumed") && Qu(this.state.type);
    let t = this.state.type === "preparing" ? this.startQuery() : this.state.queryId, { value: n, done: o } = await U("1.0/queryStreamNext", {
      queryId: t
    });
    return o && this.closeQuery(), { value: V(n), done: o };
  }
  return() {
    return this.closeQuery(), Promise.resolve({ done: !0, value: void 0 });
  }
  async paginate(t) {
    if (P(t, 1, "paginate", "options"), typeof t?.numItems != "number" || t.numItems < 0)
      throw new Error(
        `\`options.numItems\` must be a positive number. Received \`${t?.numItems}\`.`
      );
    let n = this.takeQuery(), o = t.numItems, r = t.cursor, i = t?.endCursor ?? null, s = t.maximumRowsRead ?? null, { page: c, isDone: u, continueCursor: l, splitCursor: d, pageStatus: g } = await U("1.0/queryPage", {
      query: n,
      cursor: r,
      endCursor: i,
      pageSize: o,
      maximumRowsRead: s,
      maximumBytesRead: t.maximumBytesRead,
      version: K
    });
    return {
      page: c.map(($) => V($)),
      isDone: u,
      continueCursor: l,
      splitCursor: d,
      pageStatus: g
    };
  }
  async collect() {
    let t = [];
    for await (let n of this)
      t.push(n);
    return t;
  }
  async take(t) {
    return P(t, 1, "take", "n"), qu(t, 1, "take", "n"), this.limit(t).collect();
  }
  async first() {
    let t = await this.take(1);
    return t.length === 0 ? null : t[0];
  }
  async unique() {
    let t = await this.take(2);
    if (t.length === 0)
      return null;
    if (t.length === 2)
      throw new Error(`unique() query returned more than one result from table ${this.tableNameForErrorMessages}:
 [${t[0]._id}, ${t[1]._id}, ...]`);
    return t[0];
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/database_impl.js
async function Rn(e, t, n) {
  if (P(t, 1, "get", "id"), typeof t != "string")
    throw new Error(
      `Invalid argument \`id\` for \`db.get\`, expected string but got '${typeof t}': ${t}`
    );
  let o = {
    id: R(t),
    isSystem: n,
    version: K,
    table: e
  }, r = await U("1.0/get", o);
  return V(r);
}
a(Rn, "get");
function Vn() {
  let e = /* @__PURE__ */ a((r = !1) => ({
    get: /* @__PURE__ */ a(async (i, s) => s !== void 0 ? await Rn(i, s, r) : await Rn(void 0, i, r), "get"),
    query: /* @__PURE__ */ a((i) => new Pt(i, r).query(), "query"),
    normalizeId: /* @__PURE__ */ a((i, s) => {
      P(i, 1, "normalizeId", "tableName"), P(s, 2, "normalizeId", "id");
      let c = i.startsWith("_");
      if (c !== r)
        throw new Error(
          `${c ? "System" : "User"} tables can only be accessed from db.${r ? "" : "system."}normalizeId().`
        );
      let u = Ot("1.0/db/normalizeId", {
        table: i,
        idString: s
      });
      return V(u).id;
    }, "normalizeId"),
    // We set the system reader on the next line
    system: null,
    table: /* @__PURE__ */ a((i) => new Pt(i, r), "table")
  }), "reader"), { system: t, ...n } = e(!0), o = e();
  return o.system = n, o;
}
a(Vn, "setupReader");
async function Yu(e, t) {
  if (e.startsWith("_"))
    throw new Error("System tables (prefixed with `_`) are read-only.");
  P(e, 1, "insert", "table"), P(t, 2, "insert", "value");
  let n = await U("1.0/insert", {
    table: e,
    value: R(t)
  });
  return V(n)._id;
}
a(Yu, "insert");
async function Fn(e, t, n) {
  P(t, 1, "patch", "id"), P(n, 2, "patch", "value"), await U("1.0/shallowMerge", {
    id: R(t),
    value: Cu(n),
    table: e
  });
}
a(Fn, "patch");
async function Mn(e, t, n) {
  P(t, 1, "replace", "id"), P(n, 2, "replace", "value"), await U("1.0/replace", {
    id: R(t),
    value: R(n),
    table: e
  });
}
a(Mn, "replace");
async function Ln(e, t) {
  P(t, 1, "delete", "id"), await U("1.0/remove", {
    id: R(t),
    table: e
  });
}
a(Ln, "delete_");
function el() {
  let e = Vn();
  return {
    get: e.get,
    query: e.query,
    normalizeId: e.normalizeId,
    system: e.system,
    insert: /* @__PURE__ */ a(async (t, n) => await Yu(t, n), "insert"),
    patch: /* @__PURE__ */ a(async (t, n, o) => o !== void 0 ? await Fn(t, n, o) : await Fn(void 0, t, n), "patch"),
    replace: /* @__PURE__ */ a(async (t, n, o) => o !== void 0 ? await Mn(t, n, o) : await Mn(void 0, t, n), "replace"),
    delete: /* @__PURE__ */ a(async (t, n) => n !== void 0 ? await Ln(t, n) : await Ln(void 0, t), "delete"),
    table: /* @__PURE__ */ a((t) => new Bn(t, !1), "table")
  };
}
a(el, "setupWriter");
var Pt = class {
  static {
    a(this, "TableReader");
  }
  constructor(t, n) {
    this.tableName = t, this.isSystem = n;
  }
  async get(t) {
    return Rn(this.tableName, t, this.isSystem);
  }
  query() {
    let t = this.tableName.startsWith("_");
    if (t !== this.isSystem)
      throw new Error(
        `${t ? "System" : "User"} tables can only be accessed from db.${this.isSystem ? "" : "system."}query().`
      );
    return new et(this.tableName);
  }
}, Bn = class extends Pt {
  static {
    a(this, "TableWriter");
  }
  async insert(t) {
    return Yu(this.tableName, t);
  }
  async patch(t, n) {
    return Fn(this.tableName, t, n);
  }
  async replace(t, n) {
    return Mn(this.tableName, t, n);
  }
  async delete(t) {
    return Ln(this.tableName, t);
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/scheduler_impl.js
function tl() {
  return {
    runAfter: /* @__PURE__ */ a(async (e, t, n) => {
      let o = nl(e, t, n);
      return await U("1.0/schedule", o);
    }, "runAfter"),
    runAt: /* @__PURE__ */ a(async (e, t, n) => {
      let o = il(
        e,
        t,
        n
      );
      return await U("1.0/schedule", o);
    }, "runAt"),
    cancel: /* @__PURE__ */ a(async (e) => {
      P(e, 1, "cancel", "id");
      let t = { id: R(e) };
      await U("1.0/cancel_job", t);
    }, "cancel")
  };
}
a(tl, "setupMutationScheduler");
function rl(e) {
  return {
    runAfter: /* @__PURE__ */ a(async (t, n, o) => {
      let r = {
        requestId: e,
        ...nl(t, n, o)
      };
      return await U("1.0/actions/schedule", r);
    }, "runAfter"),
    runAt: /* @__PURE__ */ a(async (t, n, o) => {
      let r = {
        requestId: e,
        ...il(t, n, o)
      };
      return await U("1.0/actions/schedule", r);
    }, "runAt"),
    cancel: /* @__PURE__ */ a(async (t) => {
      P(t, 1, "cancel", "id");
      let n = {
        requestId: e,
        id: R(t)
      };
      return await U("1.0/actions/cancel_job", n);
    }, "cancel")
  };
}
a(rl, "setupActionScheduler");
function nl(e, t, n) {
  if (typeof e != "number")
    throw new Error("`delayMs` must be a number");
  if (!isFinite(e))
    throw new Error("`delayMs` must be a finite number");
  if (e < 0)
    throw new Error("`delayMs` must be non-negative");
  let o = ke(n), r = fe(t), i = (Date.now() + e) / 1e3;
  return {
    ...r,
    ts: i,
    args: R(o),
    version: K
  };
}
a(nl, "runAfterSyscallArgs");
function il(e, t, n) {
  let o;
  if (e instanceof Date)
    o = e.valueOf() / 1e3;
  else if (typeof e == "number")
    o = e / 1e3;
  else
    throw new Error("The invoke time must a Date or a timestamp");
  let r = fe(t), i = ke(n);
  return {
    ...r,
    ts: o,
    args: R(i),
    version: K
  };
}
a(il, "runAtSyscallArgs");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/storage_impl.js
function qn(e) {
  return {
    getUrl: /* @__PURE__ */ a(async (t) => (P(t, 1, "getUrl", "storageId"), await U("1.0/storageGetUrl", {
      requestId: e,
      version: K,
      storageId: t
    })), "getUrl"),
    getMetadata: /* @__PURE__ */ a(async (t) => await U("1.0/storageGetMetadata", {
      requestId: e,
      version: K,
      storageId: t
    }), "getMetadata")
  };
}
a(qn, "setupStorageReader");
function Jn(e) {
  let t = qn(e);
  return {
    generateUploadUrl: /* @__PURE__ */ a(async () => await U("1.0/storageGenerateUploadUrl", {
      requestId: e,
      version: K
    }), "generateUploadUrl"),
    delete: /* @__PURE__ */ a(async (n) => {
      await U("1.0/storageDelete", {
        requestId: e,
        version: K,
        storageId: n
      });
    }, "delete"),
    getUrl: t.getUrl,
    getMetadata: t.getMetadata
  };
}
a(Jn, "setupStorageWriter");
function ol(e) {
  return {
    ...Jn(e),
    store: /* @__PURE__ */ a(async (n, o) => await yr("storage/storeBlob", {
      requestId: e,
      version: K,
      blob: n,
      options: o
    }), "store"),
    get: /* @__PURE__ */ a(async (n) => await yr("storage/getBlob", {
      requestId: e,
      version: K,
      storageId: n
    }), "get")
  };
}
a(ol, "setupStorageActionWriter");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/registration_impl.js
async function al(e, t) {
  let o = V(JSON.parse(t)), r = {
    db: el(),
    auth: xr(""),
    storage: Jn(""),
    scheduler: tl(),
    runQuery: /* @__PURE__ */ a((s, c) => Wn("query", s, c), "runQuery"),
    runMutation: /* @__PURE__ */ a((s, c) => Wn("mutation", s, c), "runMutation")
  }, i = await Kn(e, r, o);
  return sl(i), JSON.stringify(R(i === void 0 ? null : i));
}
a(al, "invokeMutation");
function sl(e) {
  if (e instanceof et || e instanceof Me)
    throw new Error(
      "Return value is a Query. Results must be retrieved with `.collect()`, `.take(n), `.unique()`, or `.first()`."
    );
}
a(sl, "validateReturnValue");
async function Kn(e, t, n) {
  let o;
  try {
    o = await Promise.resolve(e(t, ...n));
  } catch (r) {
    throw fm(r);
  }
  return o;
}
a(Kn, "invokeFunction");
function tt(e, t) {
  return (n, o) => (globalThis.console.warn(
    `Convex functions should not directly call other Convex functions. Consider calling a helper function instead. e.g. \`export const foo = ${e}(...); await foo(ctx);\` is not supported. See https://docs.convex.dev/production/best-practices/#use-helper-functions-to-write-shared-code`
  ), t(n, o));
}
a(tt, "dontCallDirectly");
function fm(e) {
  if (typeof e == "object" && e !== null && Symbol.for("ConvexError") in e) {
    let t = e;
    return t.data = JSON.stringify(
      R(t.data === void 0 ? null : t.data)
    ), t.ConvexErrorSymbol = Symbol.for("ConvexError"), t;
  } else
    return e;
}
a(fm, "serializeConvexErrorData");
function rt() {
  if (typeof window > "u" || window.__convexAllowFunctionsInBrowser)
    return;
  (Object.getOwnPropertyDescriptor(globalThis, "window")?.get?.toString().includes("[native code]") ?? !1) && console.error(
    "Convex functions should not be imported in the browser. This will throw an error in future versions of `convex`. If this is a false negative, please report it to Convex support."
  );
}
a(rt, "assertNotBrowser");
function cl(e, t) {
  if (t === void 0)
    throw new Error(
      `A validator is undefined for field "${e}". This is often caused by circular imports. See https://docs.convex.dev/error#undefined-validator for details.`
    );
  return t;
}
a(cl, "strictReplacer");
function nt(e) {
  return () => {
    let t = m.any();
    return typeof e == "object" && e.args !== void 0 && (t = jt(e.args)), JSON.stringify(t.json, cl);
  };
}
a(nt, "exportArgs");
function it(e) {
  return () => {
    let t;
    return typeof e == "object" && e.returns !== void 0 && (t = jt(e.returns)), JSON.stringify(t ? t.json : null, cl);
  };
}
a(it, "exportReturns");
var Gn = /* @__PURE__ */ a(((e) => {
  let t = typeof e == "function" ? e : e.handler, n = tt("mutation", t);
  return rt(), n.isMutation = !0, n.isPublic = !0, n.invokeMutation = (o) => al(t, o), n.exportArgs = nt(e), n.exportReturns = it(e), n._handler = t, n;
}), "mutationGeneric"), Xn = /* @__PURE__ */ a(((e) => {
  let t = typeof e == "function" ? e : e.handler, n = tt(
    "internalMutation",
    t
  );
  return rt(), n.isMutation = !0, n.isInternal = !0, n.invokeMutation = (o) => al(t, o), n.exportArgs = nt(e), n.exportReturns = it(e), n._handler = t, n;
}), "internalMutationGeneric");
async function ul(e, t) {
  let o = V(JSON.parse(t)), r = {
    db: Vn(),
    auth: xr(""),
    storage: qn(""),
    runQuery: /* @__PURE__ */ a((s, c) => Wn("query", s, c), "runQuery")
  }, i = await Kn(e, r, o);
  return sl(i), JSON.stringify(R(i === void 0 ? null : i));
}
a(ul, "invokeQuery");
var Hn = /* @__PURE__ */ a(((e) => {
  let t = typeof e == "function" ? e : e.handler, n = tt("query", t);
  return rt(), n.isQuery = !0, n.isPublic = !0, n.invokeQuery = (o) => ul(t, o), n.exportArgs = nt(e), n.exportReturns = it(e), n._handler = t, n;
}), "queryGeneric"), Qn = /* @__PURE__ */ a(((e) => {
  let t = typeof e == "function" ? e : e.handler, n = tt("internalQuery", t);
  return rt(), n.isQuery = !0, n.isInternal = !0, n.invokeQuery = (o) => ul(t, o), n.exportArgs = nt(e), n.exportReturns = it(e), n._handler = t, n;
}), "internalQueryGeneric");
async function ll(e, t, n) {
  let o = V(JSON.parse(n)), i = {
    ...Bu(t),
    auth: xr(t),
    scheduler: rl(t),
    storage: ol(t),
    vectorSearch: Ju(t)
  }, s = await Kn(e, i, o);
  return JSON.stringify(R(s === void 0 ? null : s));
}
a(ll, "invokeAction");
var Yn = /* @__PURE__ */ a(((e) => {
  let t = typeof e == "function" ? e : e.handler, n = tt("action", t);
  return rt(), n.isAction = !0, n.isPublic = !0, n.invokeAction = (o, r) => ll(t, o, r), n.exportArgs = nt(e), n.exportReturns = it(e), n._handler = t, n;
}), "actionGeneric"), ei = /* @__PURE__ */ a(((e) => {
  let t = typeof e == "function" ? e : e.handler, n = tt("internalAction", t);
  return rt(), n.isAction = !0, n.isInternal = !0, n.invokeAction = (o, r) => ll(t, o, r), n.exportArgs = nt(e), n.exportReturns = it(e), n._handler = t, n;
}), "internalActionGeneric");
async function Wn(e, t, n) {
  let o = ke(n), r = {
    udfType: e,
    args: R(o),
    ...fe(t)
  }, i = await U("1.0/runUdf", r);
  return V(i);
}
a(Wn, "runUdf");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/pagination.js
var pm = m.object({
  numItems: m.number(),
  cursor: m.union(m.string(), m.null()),
  endCursor: m.optional(m.union(m.string(), m.null())),
  id: m.optional(m.number()),
  maximumRowsRead: m.optional(m.number()),
  maximumBytesRead: m.optional(m.number())
});

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/api.js
function dl(e = []) {
  let t = {
    get(n, o) {
      if (typeof o == "string") {
        let r = [...e, o];
        return dl(r);
      } else if (o === Tt) {
        if (e.length < 2) {
          let s = ["api", ...e].join(".");
          throw new Error(
            `API path is expected to be of the form \`api.moduleName.functionName\`. Found: \`${s}\``
          );
        }
        let r = e.slice(0, -1).join("/"), i = e[e.length - 1];
        return i === "default" ? r : r + ":" + i;
      } else return o === Symbol.toStringTag ? "FunctionReference" : void 0;
    }
  };
  return new Proxy({}, t);
}
a(dl, "createApi");
var mm = dl();

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/schema.js
var hm = Object.defineProperty, vm = /* @__PURE__ */ a((e, t, n) => t in e ? hm(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), be = /* @__PURE__ */ a((e, t, n) => vm(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), Sr = class {
  static {
    a(this, "TableDefinition");
  }
  /**
   * @internal
   */
  constructor(t) {
    be(this, "indexes"), be(this, "stagedDbIndexes"), be(this, "searchIndexes"), be(this, "stagedSearchIndexes"), be(this, "vectorIndexes"), be(this, "stagedVectorIndexes"), be(this, "validator"), this.indexes = [], this.stagedDbIndexes = [], this.searchIndexes = [], this.stagedSearchIndexes = [], this.vectorIndexes = [], this.stagedVectorIndexes = [], this.validator = t;
  }
  /**
   * This API is experimental: it may change or disappear.
   *
   * Returns indexes defined on this table.
   * Intended for the advanced use cases of dynamically deciding which index to use for a query.
   * If you think you need this, please chime in on ths issue in the Convex JS GitHub repo.
   * https://github.com/get-convex/convex-js/issues/49
   */
  " indexes"() {
    return this.indexes;
  }
  index(t, n) {
    return Array.isArray(n) ? this.indexes.push({
      indexDescriptor: t,
      fields: n
    }) : n.staged ? this.stagedDbIndexes.push({
      indexDescriptor: t,
      fields: n.fields
    }) : this.indexes.push({
      indexDescriptor: t,
      fields: n.fields
    }), this;
  }
  searchIndex(t, n) {
    return n.staged ? this.stagedSearchIndexes.push({
      indexDescriptor: t,
      searchField: n.searchField,
      filterFields: n.filterFields || []
    }) : this.searchIndexes.push({
      indexDescriptor: t,
      searchField: n.searchField,
      filterFields: n.filterFields || []
    }), this;
  }
  vectorIndex(t, n) {
    return n.staged ? this.stagedVectorIndexes.push({
      indexDescriptor: t,
      vectorField: n.vectorField,
      dimensions: n.dimensions,
      filterFields: n.filterFields || []
    }) : this.vectorIndexes.push({
      indexDescriptor: t,
      vectorField: n.vectorField,
      dimensions: n.dimensions,
      filterFields: n.filterFields || []
    }), this;
  }
  /**
   * Work around for https://github.com/microsoft/TypeScript/issues/57035
   */
  self() {
    return this;
  }
  /**
   * Export the contents of this definition.
   *
   * This is called internally by the Convex framework.
   * @internal
   */
  export() {
    let t = this.validator.json;
    if (typeof t != "object")
      throw new Error(
        "Invalid validator: please make sure that the parameter of `defineTable` is valid (see https://docs.convex.dev/database/schemas)"
      );
    return {
      indexes: this.indexes,
      stagedDbIndexes: this.stagedDbIndexes,
      searchIndexes: this.searchIndexes,
      stagedSearchIndexes: this.stagedSearchIndexes,
      vectorIndexes: this.vectorIndexes,
      stagedVectorIndexes: this.stagedVectorIndexes,
      documentType: t
    };
  }
};
function Le(e) {
  return Dn(e) ? new Sr(e) : new Sr(m.object(e));
}
a(Le, "defineTable");
var ti = class {
  static {
    a(this, "SchemaDefinition");
  }
  /**
   * @internal
   */
  constructor(t, n) {
    be(this, "tables"), be(this, "strictTableNameTypes"), be(this, "schemaValidation"), this.tables = t, this.schemaValidation = n?.schemaValidation === void 0 ? !0 : n.schemaValidation;
  }
  /**
   * Export the contents of this definition.
   *
   * This is called internally by the Convex framework.
   * @internal
   */
  export() {
    return JSON.stringify({
      tables: Object.entries(this.tables).map(([t, n]) => {
        let {
          indexes: o,
          stagedDbIndexes: r,
          searchIndexes: i,
          stagedSearchIndexes: s,
          vectorIndexes: c,
          stagedVectorIndexes: u,
          documentType: l
        } = n.export();
        return {
          tableName: t,
          indexes: o,
          stagedDbIndexes: r,
          searchIndexes: i,
          stagedSearchIndexes: s,
          vectorIndexes: c,
          stagedVectorIndexes: u,
          documentType: l
        };
      }),
      schemaValidation: this.schemaValidation
    });
  }
};
function jr(e, t) {
  return new ti(e, t);
}
a(jr, "defineSchema");
var gw = jr({
  _scheduled_functions: Le({
    name: m.string(),
    args: m.array(m.any()),
    scheduledTime: m.float64(),
    completedTime: m.optional(m.float64()),
    state: m.union(
      m.object({ kind: m.literal("pending") }),
      m.object({ kind: m.literal("inProgress") }),
      m.object({ kind: m.literal("success") }),
      m.object({ kind: m.literal("failed"), error: m.string() }),
      m.object({ kind: m.literal("canceled") })
    )
  }),
  _storage: Le({
    sha256: m.string(),
    size: m.float64(),
    contentType: m.optional(m.string())
  })
});

// memory/profile.mjs
var Be = class {
  static {
    a(this, "SecretText");
  }
  constructor(t) {
    this.value = t;
  }
  toWire() {
    return this.value;
  }
}, ri = {
  seq: 1,
  at: 17e11,
  secret: "capacity",
  payload: "tiny"
};
function fl(e) {
  let t = e.kind === "native", n = e.kind === "full" || e.kind === "mini", o = t ? e.v : e.s;
  return /* @__PURE__ */ a(function({ count: i, width: s, profile: c, entries: u = 0 }) {
    if (!Number.isInteger(i) || i < 0 || !Number.isInteger(s) || s < 1 || !Number.isInteger(u) || u < 0 || !["fields-only", "codec-rich"].includes(c))
      throw new Error("Invalid graph fixture arguments");
    let l = {
      schemaConstructors: 0,
      fields: 0,
      codecSites: 0,
      allocatedCodecs: 0
    }, d = /* @__PURE__ */ a((I, ...j) => (l.schemaConstructors++, o[I](...j)), "make"), g = /* @__PURE__ */ a((I) => (l.fields += Object.keys(I).length, d("object", I)), "object"), $ = /* @__PURE__ */ a(() => (l.codecSites++, t ? d("number") : (l.allocatedCodecs++, d("codec", d("number"), d("date"), {
      decode: /* @__PURE__ */ a((I) => new Date(I), "decode"),
      encode: /* @__PURE__ */ a((I) => I.getTime(), "encode")
    }))), "date"), v = /* @__PURE__ */ a(() => (l.codecSites++, t ? d("string") : (l.allocatedCodecs++, d("codec", d("string"), d("instanceof", Be), {
      decode: /* @__PURE__ */ a((I) => new Be(I), "decode"),
      encode: /* @__PURE__ */ a((I) => I.toWire(), "encode")
    }))), "secret"), k = /* @__PURE__ */ a((I) => {
      if (c === "fields-only")
        switch (I % 4) {
          case 0:
            return d("string");
          case 1:
            return d("number");
          case 2:
            return d("boolean");
          case 3:
            return d("optional", d("string"));
        }
      switch (I % 4) {
        case 0:
          return $();
        case 1:
          return v();
        case 2:
          return g({ at: $(), tag: d("optional", d("string")) });
        case 3:
          return d(
            "array",
            t ? d("union", d("string"), d("number")) : d("union", [d("string"), d("number")])
          );
      }
    }, "field"), D = {}, T = {}, $e = /* @__PURE__ */ a((I, j) => {
      n ? (l.fields += Object.keys(j).length, D[I] = e.defineZodModel(I, j, e.schemaHelpers ? void 0 : { schemaHelpers: !1 })) : (T[I] = g(j), D[I] = t ? e.defineTable(T[I]) : T[I]);
    }, "add");
    $e("benchmarkRows", {
      seq: d("number"),
      at: $(),
      secret: v(),
      payload: d("string")
    });
    for (let I = 0; I < i; I++) {
      let j = {};
      for (let B = 0; B < s; B++) j[`f${B}`] = k(B);
      $e(`unused${I}`, j);
    }
    let ve = n ? e.defineZodSchema(D) : t ? e.defineSchema(D) : null;
    if (n) for (let I of Object.keys(D)) T[I] = ve.__zodTableMap[I].insert;
    let W = Object.keys(D), O = {};
    for (let I = 0; I < u; I++) {
      let j = W[I % W.length], B = n ? ve.__zodTableMap[j].doc : T[j], Xe = g({
        id: d("string"),
        label: d("optional", d("string"))
      }), or = t ? d("union", B, d("null")) : d("nullable", B);
      O[`unused/fn${I}`] = { args: Xe, returns: or };
    }
    let F = n ? e.initZodvex(
      ve,
      e.server,
      u ? { registry: /* @__PURE__ */ a(() => O, "registry") } : void 0
    ) : e.makeBuilders();
    return {
      kind: e.kind,
      options: { count: i, width: s, profile: c, entries: u },
      models: D,
      sourceSchemas: T,
      schema: ve,
      registry: O,
      builders: F,
      manifest: {
        backgroundModels: i,
        totalModels: i + 1,
        backgroundTopLevelFields: i * s,
        fixedProbeFields: 4,
        profile: c,
        registryEntries: u,
        ...l,
        counterScope: "Explicit fixture constructor calls and source fields/codecs; excludes library-generated helper schemas and runtime heap objects."
      },
      operation() {
        let I = { ...ri }, j = t ? {
          ...I,
          at: new Date(I.at),
          secret: new Be(I.secret)
        } : e.s.parse(T.benchmarkRows, I);
        if (!(j.at instanceof Date) || !(j.secret instanceof Be))
          throw new Error("Codec decode failed");
        j.at = new Date(j.at.getTime() + 1e3), j.secret = new Be(j.secret.toWire().toUpperCase());
        let B = t ? {
          ...j,
          at: j.at.getTime(),
          secret: j.secret.toWire()
        } : e.s.encode(T.benchmarkRows, j);
        if (JSON.stringify(B) !== JSON.stringify({
          ...ri,
          at: ri.at + 1e3,
          secret: "CAPACITY"
        }))
          throw new Error("Codec round trip mismatch");
        return B;
      },
      // Call after the operation and after GC measurements. The retained graph
      // includes every model, table schema, registry entry and builder closure.
      checksum() {
        let I = 0;
        for (let [j, B] of Object.entries(D)) {
          if (!B || !T[j]) throw new Error("Missing model");
          if (I += j.length, n && ve.__zodTableMap[j].insert !== T[j])
            throw new Error("Lost table-map alias");
        }
        for (let [j, B] of Object.entries(O)) {
          if (!B.args || !B.returns)
            throw new Error("Missing registry schema");
          I += j.length;
        }
        if (Object.keys(F).length === 0)
          throw new Error("Lost builders");
        return I;
      }
    };
  }, "buildGraph");
}
a(fl, "createGraphFactory");

// versions/4.4.3/node_modules/zod/v4/mini/external.js
var x = {};
Ce(x, {
  $brand: () => ii,
  $input: () => _s,
  $output: () => xs,
  NEVER: () => ni,
  TimePrecision: () => Ws,
  ZodMiniAny: () => zd,
  ZodMiniArray: () => Pd,
  ZodMiniBase64: () => yd,
  ZodMiniBase64URL: () => bd,
  ZodMiniBigInt: () => er,
  ZodMiniBigIntFormat: () => Yc,
  ZodMiniBoolean: () => Yt,
  ZodMiniCIDRv4: () => gd,
  ZodMiniCIDRv6: () => hd,
  ZodMiniCUID: () => cd,
  ZodMiniCUID2: () => ud,
  ZodMiniCatch: () => Gd,
  ZodMiniCodec: () => ln,
  ZodMiniCustom: () => cu,
  ZodMiniCustomStringFormat: () => Ht,
  ZodMiniDate: () => on,
  ZodMiniDefault: () => Jd,
  ZodMiniDiscriminatedUnion: () => Dd,
  ZodMiniE164: () => $d,
  ZodMiniEmail: () => id,
  ZodMiniEmoji: () => ad,
  ZodMiniEnum: () => nu,
  ZodMiniExactOptional: () => Vd,
  ZodMiniFile: () => Ld,
  ZodMiniFunction: () => nf,
  ZodMiniGUID: () => od,
  ZodMiniIPv4: () => pd,
  ZodMiniIPv6: () => md,
  ZodMiniISODate: () => fn,
  ZodMiniISODateTime: () => dn,
  ZodMiniISODuration: () => mn,
  ZodMiniISOTime: () => pn,
  ZodMiniIntersection: () => Ed,
  ZodMiniJWT: () => xd,
  ZodMiniKSUID: () => fd,
  ZodMiniLazy: () => Yd,
  ZodMiniLiteral: () => Md,
  ZodMiniMAC: () => vd,
  ZodMiniMap: () => Cd,
  ZodMiniNaN: () => Xd,
  ZodMiniNanoID: () => sd,
  ZodMiniNever: () => jd,
  ZodMiniNonOptional: () => ou,
  ZodMiniNull: () => kd,
  ZodMiniNullable: () => qd,
  ZodMiniNumber: () => Qt,
  ZodMiniNumberFormat: () => $t,
  ZodMiniObject: () => an,
  ZodMiniOptional: () => iu,
  ZodMiniPipe: () => au,
  ZodMiniPrefault: () => Wd,
  ZodMiniPromise: () => tf,
  ZodMiniReadonly: () => Hd,
  ZodMiniRecord: () => Gt,
  ZodMiniSet: () => Rd,
  ZodMiniString: () => bt,
  ZodMiniStringFormat: () => C,
  ZodMiniSuccess: () => Kd,
  ZodMiniSymbol: () => _d,
  ZodMiniTemplateLiteral: () => Qd,
  ZodMiniTransform: () => Bd,
  ZodMiniTuple: () => Nd,
  ZodMiniType: () => z,
  ZodMiniULID: () => ld,
  ZodMiniURL: () => Qc,
  ZodMiniUUID: () => Xt,
  ZodMiniUndefined: () => wd,
  ZodMiniUnion: () => ru,
  ZodMiniUnknown: () => Sd,
  ZodMiniVoid: () => Td,
  ZodMiniXID: () => dd,
  ZodMiniXor: () => Ud,
  _default: () => Ey,
  _function: () => Qy,
  any: () => cy,
  array: () => tr,
  base64: () => Vv,
  base64url: () => qv,
  bigint: () => ny,
  boolean: () => nn,
  catch: () => Cy,
  catchall: () => $y,
  check: () => qy,
  cidrv4: () => Mv,
  cidrv6: () => Lv,
  clone: () => J,
  codec: () => su,
  coerce: () => du,
  config: () => X,
  core: () => vt,
  cuid: () => Ev,
  cuid2: () => Nv,
  custom: () => rf,
  date: () => eu,
  decode: () => Ii,
  decodeAsync: () => Si,
  describe: () => Ky,
  discriminatedUnion: () => _y,
  e164: () => Jv,
  email: () => kv,
  emoji: () => Uv,
  encode: () => Y,
  encodeAsync: () => zi,
  endsWith: () => Ac,
  enum: () => Fd,
  exactOptional: () => Uy,
  extend: () => py,
  file: () => Ty,
  flattenError: () => xi,
  float32: () => Yv,
  float64: () => ey,
  formatError: () => _i,
  function: () => Qy,
  globalRegistry: () => he,
  gt: () => Hr,
  gte: () => Kt,
  guid: () => Iv,
  hash: () => Hv,
  hex: () => Xv,
  hostname: () => Gv,
  httpUrl: () => Pv,
  includes: () => Nc,
  instanceof: () => uu,
  int: () => Qv,
  int32: () => ty,
  int64: () => iy,
  intersection: () => wy,
  invertCodec: () => My,
  ipv4: () => Rv,
  ipv6: () => Fv,
  iso: () => lu,
  json: () => Hy,
  jwt: () => Wv,
  keyof: () => ly,
  ksuid: () => Cv,
  lazy: () => ef,
  length: () => Pc,
  literal: () => Oy,
  locales: () => Jt,
  looseObject: () => fy,
  looseRecord: () => Iy,
  lowercase: () => Dc,
  lt: () => Xr,
  lte: () => Wt,
  mac: () => Bv,
  map: () => zy,
  maxLength: () => Oc,
  maxSize: () => zc,
  maximum: () => Wt,
  merge: () => gy,
  meta: () => Gy,
  mime: () => Rc,
  minLength: () => Tc,
  minSize: () => Sc,
  minimum: () => Kt,
  multipleOf: () => Ic,
  nan: () => Ry,
  nanoid: () => Dv,
  nativeEnum: () => jy,
  negative: () => _c,
  never: () => Od,
  nonnegative: () => kc,
  nonoptional: () => Zy,
  nonpositive: () => wc,
  normalize: () => Fc,
  null: () => Id,
  nullable: () => un,
  nullish: () => Dy,
  number: () => rn,
  object: () => tu,
  omit: () => vy,
  optional: () => cn,
  overwrite: () => De,
  parse: () => ie,
  parseAsync: () => Oe,
  partial: () => yy,
  partialRecord: () => ky,
  pick: () => hy,
  pipe: () => Fy,
  positive: () => xc,
  prefault: () => Ny,
  prettifyError: () => ki,
  promise: () => Vy,
  property: () => Cc,
  readonly: () => Ly,
  record: () => Ad,
  refine: () => Jy,
  regex: () => Uc,
  regexes: () => ae,
  registry: () => Kr,
  required: () => by,
  safeDecode: () => Oi,
  safeDecodeAsync: () => Pi,
  safeEncode: () => ji,
  safeEncodeAsync: () => Ti,
  safeExtend: () => my,
  safeParse: () => me,
  safeParseAsync: () => Je,
  set: () => Sy,
  size: () => jc,
  startsWith: () => Zc,
  strictObject: () => dy,
  string: () => yt,
  stringFormat: () => Kv,
  stringbool: () => Xy,
  success: () => Ay,
  superRefine: () => Wy,
  symbol: () => ay,
  templateLiteral: () => By,
  toJSONSchema: () => Yr,
  toLowerCase: () => Lc,
  toUpperCase: () => Bc,
  transform: () => Py,
  treeifyError: () => wi,
  trim: () => Mc,
  tuple: () => Zd,
  uint32: () => ry,
  uint64: () => oy,
  ulid: () => Zv,
  undefined: () => sy,
  union: () => sn,
  unknown: () => tn,
  uppercase: () => Ec,
  url: () => Tv,
  util: () => w,
  uuid: () => zv,
  uuidv4: () => Sv,
  uuidv6: () => jv,
  uuidv7: () => Ov,
  void: () => uy,
  xid: () => Av,
  xor: () => xy
});

// versions/4.4.3/node_modules/zod/v4/core/index.js
var vt = {};
Ce(vt, {
  $ZodAny: () => oa,
  $ZodArray: () => Te,
  $ZodAsyncError: () => pe,
  $ZodBase64: () => Go,
  $ZodBase64URL: () => Xo,
  $ZodBigInt: () => qr,
  $ZodBigIntFormat: () => ta,
  $ZodBoolean: () => Mt,
  $ZodCIDRv4: () => Jo,
  $ZodCIDRv6: () => Wo,
  $ZodCUID: () => Eo,
  $ZodCUID2: () => No,
  $ZodCatch: () => ba,
  $ZodCheck: () => A,
  $ZodCheckBigIntFormat: () => uo,
  $ZodCheckEndsWith: () => _o,
  $ZodCheckGreaterThan: () => Rr,
  $ZodCheckIncludes: () => $o,
  $ZodCheckLengthEquals: () => ho,
  $ZodCheckLessThan: () => Cr,
  $ZodCheckLowerCase: () => yo,
  $ZodCheckMaxLength: () => mo,
  $ZodCheckMaxSize: () => lo,
  $ZodCheckMimeType: () => ko,
  $ZodCheckMinLength: () => go,
  $ZodCheckMinSize: () => fo,
  $ZodCheckMultipleOf: () => so,
  $ZodCheckNumberFormat: () => co,
  $ZodCheckOverwrite: () => Io,
  $ZodCheckProperty: () => wo,
  $ZodCheckRegex: () => vo,
  $ZodCheckSizeEquals: () => po,
  $ZodCheckStartsWith: () => xo,
  $ZodCheckStringFormat: () => ut,
  $ZodCheckUpperCase: () => bo,
  $ZodCodec: () => ge,
  $ZodCustom: () => Lt,
  $ZodCustomStringFormat: () => Yo,
  $ZodDate: () => dt,
  $ZodDefault: () => se,
  $ZodDiscriminatedUnion: () => Pe,
  $ZodE164: () => Ho,
  $ZodEmail: () => To,
  $ZodEmoji: () => Uo,
  $ZodEncodeError: () => ot,
  $ZodEnum: () => ft,
  $ZodError: () => _e,
  $ZodExactOptional: () => ga,
  $ZodFile: () => pa,
  $ZodFunction: () => wa,
  $ZodGUID: () => jo,
  $ZodIPv4: () => Bo,
  $ZodIPv6: () => Vo,
  $ZodISODate: () => Fo,
  $ZodISODateTime: () => Ro,
  $ZodISODuration: () => Lo,
  $ZodISOTime: () => Mo,
  $ZodIntersection: () => la,
  $ZodJWT: () => Qo,
  $ZodKSUID: () => Co,
  $ZodLazy: () => mt,
  $ZodLiteral: () => pt,
  $ZodMAC: () => qo,
  $ZodMap: () => da,
  $ZodNaN: () => $a,
  $ZodNanoID: () => Do,
  $ZodNever: () => sa,
  $ZodNonOptional: () => va,
  $ZodNull: () => ia,
  $ZodNullable: () => de,
  $ZodNumber: () => Vr,
  $ZodNumberFormat: () => ea,
  $ZodObject: () => q,
  $ZodObjectJIT: () => dg,
  $ZodOptional: () => L,
  $ZodPipe: () => Jr,
  $ZodPrefault: () => ha,
  $ZodPreprocess: () => fg,
  $ZodPromise: () => ka,
  $ZodReadonly: () => xa,
  $ZodRealError: () => ne,
  $ZodRecord: () => Ke,
  $ZodRegistry: () => Wr,
  $ZodSet: () => fa,
  $ZodString: () => lt,
  $ZodStringFormat: () => Z,
  $ZodSuccess: () => ya,
  $ZodSymbol: () => ra,
  $ZodTemplateLiteral: () => _a,
  $ZodTransform: () => ma,
  $ZodTuple: () => Ue,
  $ZodType: () => _,
  $ZodULID: () => Zo,
  $ZodURL: () => Po,
  $ZodUUID: () => Oo,
  $ZodUndefined: () => na,
  $ZodUnion: () => ee,
  $ZodUnknown: () => aa,
  $ZodVoid: () => ca,
  $ZodXID: () => Ao,
  $ZodXor: () => ua,
  $brand: () => ii,
  $constructor: () => f,
  $input: () => _s,
  $output: () => xs,
  Doc: () => Ft,
  JSONSchema: () => nd,
  JSONSchemaGenerator: () => en,
  NEVER: () => ni,
  TimePrecision: () => Ws,
  _any: () => mc,
  _array: () => fh,
  _base64: () => Bs,
  _base64url: () => Vs,
  _bigint: () => sc,
  _boolean: () => oc,
  _catch: () => Th,
  _check: () => rd,
  _cidrv4: () => Ms,
  _cidrv6: () => Ls,
  _coercedBigint: () => cc,
  _coercedBoolean: () => ac,
  _coercedDate: () => bc,
  _coercedNumber: () => Ys,
  _coercedString: () => ks,
  _cuid: () => Ds,
  _cuid2: () => Es,
  _custom: () => qc,
  _date: () => yc,
  _decode: () => $l,
  _decodeAsync: () => _l,
  _default: () => Sh,
  _discriminatedUnion: () => gh,
  _e164: () => qs,
  _email: () => Is,
  _emoji: () => Ps,
  _encode: () => bl,
  _encodeAsync: () => xl,
  _endsWith: () => Ac,
  _enum: () => xh,
  _file: () => Vc,
  _float32: () => tc,
  _float64: () => rc,
  _gt: () => Hr,
  _gte: () => Kt,
  _guid: () => zs,
  _includes: () => Nc,
  _int: () => ec,
  _int32: () => nc,
  _int64: () => uc,
  _intersection: () => hh,
  _ipv4: () => Cs,
  _ipv6: () => Rs,
  _isoDate: () => Gs,
  _isoDateTime: () => Ks,
  _isoDuration: () => Hs,
  _isoTime: () => Xs,
  _jwt: () => Js,
  _ksuid: () => As,
  _lazy: () => Eh,
  _length: () => Pc,
  _literal: () => wh,
  _lowercase: () => Dc,
  _lt: () => Xr,
  _lte: () => Wt,
  _mac: () => Fs,
  _map: () => bh,
  _max: () => Wt,
  _maxLength: () => Oc,
  _maxSize: () => zc,
  _mime: () => Rc,
  _min: () => Kt,
  _minLength: () => Tc,
  _minSize: () => Sc,
  _multipleOf: () => Ic,
  _nan: () => $c,
  _nanoid: () => Us,
  _nativeEnum: () => _h,
  _negative: () => _c,
  _never: () => hc,
  _nonnegative: () => kc,
  _nonoptional: () => jh,
  _nonpositive: () => wc,
  _normalize: () => Fc,
  _null: () => pc,
  _nullable: () => zh,
  _number: () => Qs,
  _optional: () => Ih,
  _overwrite: () => De,
  _parse: () => Ur,
  _parseAsync: () => Dr,
  _pipe: () => Ph,
  _positive: () => xc,
  _promise: () => Nh,
  _property: () => Cc,
  _readonly: () => Uh,
  _record: () => yh,
  _refine: () => Jc,
  _regex: () => Uc,
  _safeDecode: () => kl,
  _safeDecodeAsync: () => zl,
  _safeEncode: () => wl,
  _safeEncodeAsync: () => Il,
  _safeParse: () => Er,
  _safeParseAsync: () => Nr,
  _set: () => $h,
  _size: () => jc,
  _slugify: () => dh,
  _startsWith: () => Zc,
  _string: () => ws,
  _stringFormat: () => ht,
  _stringbool: () => Xc,
  _success: () => Oh,
  _superRefine: () => Wc,
  _symbol: () => dc,
  _templateLiteral: () => Dh,
  _toLowerCase: () => Lc,
  _toUpperCase: () => Bc,
  _transform: () => kh,
  _trim: () => Mc,
  _tuple: () => vh,
  _uint32: () => ic,
  _uint64: () => lc,
  _ulid: () => Ns,
  _undefined: () => fc,
  _union: () => ph,
  _unknown: () => gc,
  _uppercase: () => Ec,
  _url: () => Gr,
  _uuid: () => Ss,
  _uuidv4: () => js,
  _uuidv6: () => Os,
  _uuidv7: () => Ts,
  _void: () => vc,
  _xid: () => Zs,
  _xor: () => mh,
  clone: () => J,
  config: () => X,
  createStandardJSONSchemaMethod: () => Hc,
  createToJSONSchemaMethod: () => Zh,
  decode: () => Ii,
  decodeAsync: () => Si,
  describe: () => Kc,
  encode: () => Y,
  encodeAsync: () => zi,
  extractDefs: () => Ne,
  finalize: () => Ze,
  flattenError: () => xi,
  formatError: () => _i,
  globalConfig: () => Ve,
  globalRegistry: () => he,
  initializeContext: () => Ee,
  isValidBase64: () => Ko,
  isValidBase64URL: () => Wl,
  isValidJWT: () => Kl,
  locales: () => Jt,
  meta: () => Gc,
  parse: () => ie,
  parseAsync: () => Oe,
  prettifyError: () => ki,
  process: () => E,
  regexes: () => ae,
  registry: () => Kr,
  safeDecode: () => Oi,
  safeDecodeAsync: () => Pi,
  safeEncode: () => ji,
  safeEncodeAsync: () => Ti,
  safeParse: () => me,
  safeParseAsync: () => Je,
  toDotPath: () => yl,
  toJSONSchema: () => Yr,
  treeifyError: () => wi,
  util: () => w,
  version: () => zo
});

// versions/4.4.3/node_modules/zod/v4/core/core.js
var pl, ni = /* @__PURE__ */ Object.freeze({
  status: "aborted"
});
// @__NO_SIDE_EFFECTS__
function f(e, t, n) {
  function o(c, u) {
    if (c._zod || Object.defineProperty(c, "_zod", {
      value: {
        def: u,
        constr: s,
        traits: /* @__PURE__ */ new Set()
      },
      enumerable: !1
    }), c._zod.traits.has(e))
      return;
    c._zod.traits.add(e), t(c, u);
    let l = s.prototype, d = Object.keys(l);
    for (let g = 0; g < d.length; g++) {
      let $ = d[g];
      $ in c || (c[$] = l[$].bind(c));
    }
  }
  a(o, "init");
  let r = n?.Parent ?? Object;
  class i extends r {
    static {
      a(this, "Definition");
    }
  }
  Object.defineProperty(i, "name", { value: e });
  function s(c) {
    var u;
    let l = n?.Parent ? new i() : this;
    o(l, c), (u = l._zod).deferred ?? (u.deferred = []);
    for (let d of l._zod.deferred)
      d();
    return l;
  }
  return a(s, "_"), Object.defineProperty(s, "init", { value: o }), Object.defineProperty(s, Symbol.hasInstance, {
    value: /* @__PURE__ */ a((c) => n?.Parent && c instanceof n.Parent ? !0 : c?._zod?.traits?.has(e), "value")
  }), Object.defineProperty(s, "name", { value: e }), s;
}
a(f, "$constructor");
var ii = Symbol("zod_brand"), pe = class extends Error {
  static {
    a(this, "$ZodAsyncError");
  }
  constructor() {
    super("Encountered Promise during synchronous parse. Use .parseAsync() instead.");
  }
}, ot = class extends Error {
  static {
    a(this, "$ZodEncodeError");
  }
  constructor(t) {
    super(`Encountered unidirectional transform during encode: ${t}`), this.name = "ZodEncodeError";
  }
};
(pl = globalThis).__zod_globalConfig ?? (pl.__zod_globalConfig = {});
var Ve = globalThis.__zod_globalConfig;
function X(e) {
  return e && Object.assign(Ve, e), Ve;
}
a(X, "config");

// versions/4.4.3/node_modules/zod/v4/core/util.js
var w = {};
Ce(w, {
  BIGINT_FORMAT_RANGES: () => mi,
  Class: () => ai,
  NUMBER_FORMAT_RANGES: () => pi,
  aborted: () => je,
  allowsEval: () => li,
  assert: () => _m,
  assertEqual: () => ym,
  assertIs: () => $m,
  assertNever: () => xm,
  assertNotEqual: () => bm,
  assignProp: () => ze,
  base64ToUint8Array: () => gl,
  base64urlToUint8Array: () => Dm,
  cached: () => at,
  captureStackTrace: () => Tr,
  cleanEnum: () => Um,
  cleanRegex: () => Et,
  clone: () => J,
  cloneDef: () => km,
  createTransparentProxy: () => Tm,
  defineLazy: () => S,
  esc: () => Or,
  escapeRegex: () => le,
  explicitlyAborted: () => $i,
  extend: () => Pr,
  finalizeIssue: () => Q,
  floatSafeRemainder: () => ci,
  getElementAtPath: () => Im,
  getEnumValues: () => Dt,
  getLengthableOrigin: () => At,
  getParsedType: () => Om,
  getSizableOrigin: () => Zt,
  hexToUint8Array: () => Nm,
  isObject: () => qe,
  isPlainObject: () => Se,
  issue: () => ct,
  joinValues: () => p,
  jsonStringifyReplacer: () => si,
  merge: () => Pm,
  mergeDefs: () => xe,
  normalizeParams: () => h,
  nullish: () => Ie,
  numKeys: () => jm,
  objectClone: () => wm,
  omit: () => hi,
  optionalKeys: () => fi,
  parsedType: () => b,
  partial: () => yi,
  pick: () => gi,
  prefixIssues: () => re,
  primitiveTypes: () => di,
  promiseAllObject: () => zm,
  propertyKeyTypes: () => Nt,
  randomString: () => Sm,
  required: () => bi,
  safeExtend: () => vi,
  shallowClone: () => st,
  slugify: () => ui,
  stringifyPrimitive: () => y,
  uint8ArrayToBase64: () => hl,
  uint8ArrayToBase64url: () => Em,
  uint8ArrayToHex: () => Zm,
  unwrapMessage: () => Ut
});
function ym(e) {
  return e;
}
a(ym, "assertEqual");
function bm(e) {
  return e;
}
a(bm, "assertNotEqual");
function $m(e) {
}
a($m, "assertIs");
function xm(e) {
  throw new Error("Unexpected value in exhaustive check");
}
a(xm, "assertNever");
function _m(e) {
}
a(_m, "assert");
function Dt(e) {
  let t = Object.values(e).filter((o) => typeof o == "number");
  return Object.entries(e).filter(([o, r]) => t.indexOf(+o) === -1).map(([o, r]) => r);
}
a(Dt, "getEnumValues");
function p(e, t = "|") {
  return e.map((n) => y(n)).join(t);
}
a(p, "joinValues");
function si(e, t) {
  return typeof t == "bigint" ? t.toString() : t;
}
a(si, "jsonStringifyReplacer");
function at(e) {
  return {
    get value() {
      {
        let n = e();
        return Object.defineProperty(this, "value", { value: n }), n;
      }
      throw new Error("cached value already set");
    }
  };
}
a(at, "cached");
function Ie(e) {
  return e == null;
}
a(Ie, "nullish");
function Et(e) {
  let t = e.startsWith("^") ? 1 : 0, n = e.endsWith("$") ? e.length - 1 : e.length;
  return e.slice(t, n);
}
a(Et, "cleanRegex");
function ci(e, t) {
  let n = e / t, o = Math.round(n), r = Number.EPSILON * Math.max(Math.abs(n), 1);
  return Math.abs(n - o) < r ? 0 : n - o;
}
a(ci, "floatSafeRemainder");
var ml = /* @__PURE__ */ Symbol("evaluating");
function S(e, t, n) {
  let o;
  Object.defineProperty(e, t, {
    get() {
      if (o !== ml)
        return o === void 0 && (o = ml, o = n()), o;
    },
    set(r) {
      Object.defineProperty(e, t, {
        value: r
        // configurable: true,
      });
    },
    configurable: !0
  });
}
a(S, "defineLazy");
function wm(e) {
  return Object.create(Object.getPrototypeOf(e), Object.getOwnPropertyDescriptors(e));
}
a(wm, "objectClone");
function ze(e, t, n) {
  Object.defineProperty(e, t, {
    value: n,
    writable: !0,
    enumerable: !0,
    configurable: !0
  });
}
a(ze, "assignProp");
function xe(...e) {
  let t = {};
  for (let n of e) {
    let o = Object.getOwnPropertyDescriptors(n);
    Object.assign(t, o);
  }
  return Object.defineProperties({}, t);
}
a(xe, "mergeDefs");
function km(e) {
  return xe(e._zod.def);
}
a(km, "cloneDef");
function Im(e, t) {
  return t ? t.reduce((n, o) => n?.[o], e) : e;
}
a(Im, "getElementAtPath");
function zm(e) {
  let t = Object.keys(e), n = t.map((o) => e[o]);
  return Promise.all(n).then((o) => {
    let r = {};
    for (let i = 0; i < t.length; i++)
      r[t[i]] = o[i];
    return r;
  });
}
a(zm, "promiseAllObject");
function Sm(e = 10) {
  let t = "abcdefghijklmnopqrstuvwxyz", n = "";
  for (let o = 0; o < e; o++)
    n += t[Math.floor(Math.random() * t.length)];
  return n;
}
a(Sm, "randomString");
function Or(e) {
  return JSON.stringify(e);
}
a(Or, "esc");
function ui(e) {
  return e.toLowerCase().trim().replace(/[^\w\s-]/g, "").replace(/[\s_-]+/g, "-").replace(/^-+|-+$/g, "");
}
a(ui, "slugify");
var Tr = "captureStackTrace" in Error ? Error.captureStackTrace : (...e) => {
};
function qe(e) {
  return typeof e == "object" && e !== null && !Array.isArray(e);
}
a(qe, "isObject");
var li = /* @__PURE__ */ at(() => {
  if (Ve.jitless || typeof navigator < "u" && navigator?.userAgent?.includes("Cloudflare"))
    return !1;
  try {
    let e = Function;
    return new e(""), !0;
  } catch {
    return !1;
  }
});
function Se(e) {
  if (qe(e) === !1)
    return !1;
  let t = e.constructor;
  if (t === void 0 || typeof t != "function")
    return !0;
  let n = t.prototype;
  return !(qe(n) === !1 || Object.prototype.hasOwnProperty.call(n, "isPrototypeOf") === !1);
}
a(Se, "isPlainObject");
function st(e) {
  return Se(e) ? { ...e } : Array.isArray(e) ? [...e] : e instanceof Map ? new Map(e) : e instanceof Set ? new Set(e) : e;
}
a(st, "shallowClone");
function jm(e) {
  let t = 0;
  for (let n in e)
    Object.prototype.hasOwnProperty.call(e, n) && t++;
  return t;
}
a(jm, "numKeys");
var Om = /* @__PURE__ */ a((e) => {
  let t = typeof e;
  switch (t) {
    case "undefined":
      return "undefined";
    case "string":
      return "string";
    case "number":
      return Number.isNaN(e) ? "nan" : "number";
    case "boolean":
      return "boolean";
    case "function":
      return "function";
    case "bigint":
      return "bigint";
    case "symbol":
      return "symbol";
    case "object":
      return Array.isArray(e) ? "array" : e === null ? "null" : e.then && typeof e.then == "function" && e.catch && typeof e.catch == "function" ? "promise" : typeof Map < "u" && e instanceof Map ? "map" : typeof Set < "u" && e instanceof Set ? "set" : typeof Date < "u" && e instanceof Date ? "date" : typeof File < "u" && e instanceof File ? "file" : "object";
    default:
      throw new Error(`Unknown data type: ${t}`);
  }
}, "getParsedType"), Nt = /* @__PURE__ */ new Set(["string", "number", "symbol"]), di = /* @__PURE__ */ new Set([
  "string",
  "number",
  "bigint",
  "boolean",
  "symbol",
  "undefined"
]);
function le(e) {
  return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
a(le, "escapeRegex");
function J(e, t, n) {
  let o = new e._zod.constr(t ?? e._zod.def);
  return (!t || n?.parent) && (o._zod.parent = e), o;
}
a(J, "clone");
function h(e) {
  let t = e;
  if (!t)
    return {};
  if (typeof t == "string")
    return { error: /* @__PURE__ */ a(() => t, "error") };
  if (t?.message !== void 0) {
    if (t?.error !== void 0)
      throw new Error("Cannot specify both `message` and `error` params");
    t.error = t.message;
  }
  return delete t.message, typeof t.error == "string" ? { ...t, error: /* @__PURE__ */ a(() => t.error, "error") } : t;
}
a(h, "normalizeParams");
function Tm(e) {
  let t;
  return new Proxy({}, {
    get(n, o, r) {
      return t ?? (t = e()), Reflect.get(t, o, r);
    },
    set(n, o, r, i) {
      return t ?? (t = e()), Reflect.set(t, o, r, i);
    },
    has(n, o) {
      return t ?? (t = e()), Reflect.has(t, o);
    },
    deleteProperty(n, o) {
      return t ?? (t = e()), Reflect.deleteProperty(t, o);
    },
    ownKeys(n) {
      return t ?? (t = e()), Reflect.ownKeys(t);
    },
    getOwnPropertyDescriptor(n, o) {
      return t ?? (t = e()), Reflect.getOwnPropertyDescriptor(t, o);
    },
    defineProperty(n, o, r) {
      return t ?? (t = e()), Reflect.defineProperty(t, o, r);
    }
  });
}
a(Tm, "createTransparentProxy");
function y(e) {
  return typeof e == "bigint" ? e.toString() + "n" : typeof e == "string" ? `"${e}"` : `${e}`;
}
a(y, "stringifyPrimitive");
function fi(e) {
  return Object.keys(e).filter((t) => e[t]._zod.optin === "optional" && e[t]._zod.optout === "optional");
}
a(fi, "optionalKeys");
var pi = {
  safeint: [Number.MIN_SAFE_INTEGER, Number.MAX_SAFE_INTEGER],
  int32: [-2147483648, 2147483647],
  uint32: [0, 4294967295],
  float32: [-34028234663852886e22, 34028234663852886e22],
  float64: [-Number.MAX_VALUE, Number.MAX_VALUE]
}, mi = {
  int64: [/* @__PURE__ */ BigInt("-9223372036854775808"), /* @__PURE__ */ BigInt("9223372036854775807")],
  uint64: [/* @__PURE__ */ BigInt(0), /* @__PURE__ */ BigInt("18446744073709551615")]
};
function gi(e, t) {
  let n = e._zod.def, o = n.checks;
  if (o && o.length > 0)
    throw new Error(".pick() cannot be used on object schemas containing refinements");
  let i = xe(e._zod.def, {
    get shape() {
      let s = {};
      for (let c in t) {
        if (!(c in n.shape))
          throw new Error(`Unrecognized key: "${c}"`);
        t[c] && (s[c] = n.shape[c]);
      }
      return ze(this, "shape", s), s;
    },
    checks: []
  });
  return J(e, i);
}
a(gi, "pick");
function hi(e, t) {
  let n = e._zod.def, o = n.checks;
  if (o && o.length > 0)
    throw new Error(".omit() cannot be used on object schemas containing refinements");
  let i = xe(e._zod.def, {
    get shape() {
      let s = { ...e._zod.def.shape };
      for (let c in t) {
        if (!(c in n.shape))
          throw new Error(`Unrecognized key: "${c}"`);
        t[c] && delete s[c];
      }
      return ze(this, "shape", s), s;
    },
    checks: []
  });
  return J(e, i);
}
a(hi, "omit");
function Pr(e, t) {
  if (!Se(t))
    throw new Error("Invalid input to extend: expected a plain object");
  let n = e._zod.def.checks;
  if (n && n.length > 0) {
    let i = e._zod.def.shape;
    for (let s in t)
      if (Object.getOwnPropertyDescriptor(i, s) !== void 0)
        throw new Error("Cannot overwrite keys on object schemas containing refinements. Use `.safeExtend()` instead.");
  }
  let r = xe(e._zod.def, {
    get shape() {
      let i = { ...e._zod.def.shape, ...t };
      return ze(this, "shape", i), i;
    }
  });
  return J(e, r);
}
a(Pr, "extend");
function vi(e, t) {
  if (!Se(t))
    throw new Error("Invalid input to safeExtend: expected a plain object");
  let n = xe(e._zod.def, {
    get shape() {
      let o = { ...e._zod.def.shape, ...t };
      return ze(this, "shape", o), o;
    }
  });
  return J(e, n);
}
a(vi, "safeExtend");
function Pm(e, t) {
  if (e._zod.def.checks?.length)
    throw new Error(".merge() cannot be used on object schemas containing refinements. Use .safeExtend() instead.");
  let n = xe(e._zod.def, {
    get shape() {
      let o = { ...e._zod.def.shape, ...t._zod.def.shape };
      return ze(this, "shape", o), o;
    },
    get catchall() {
      return t._zod.def.catchall;
    },
    checks: t._zod.def.checks ?? []
  });
  return J(e, n);
}
a(Pm, "merge");
function yi(e, t, n) {
  let r = t._zod.def.checks;
  if (r && r.length > 0)
    throw new Error(".partial() cannot be used on object schemas containing refinements");
  let s = xe(t._zod.def, {
    get shape() {
      let c = t._zod.def.shape, u = { ...c };
      if (n)
        for (let l in n) {
          if (!(l in c))
            throw new Error(`Unrecognized key: "${l}"`);
          n[l] && (u[l] = e ? new e({
            type: "optional",
            innerType: c[l]
          }) : c[l]);
        }
      else
        for (let l in c)
          u[l] = e ? new e({
            type: "optional",
            innerType: c[l]
          }) : c[l];
      return ze(this, "shape", u), u;
    },
    checks: []
  });
  return J(t, s);
}
a(yi, "partial");
function bi(e, t, n) {
  let o = xe(t._zod.def, {
    get shape() {
      let r = t._zod.def.shape, i = { ...r };
      if (n)
        for (let s in n) {
          if (!(s in i))
            throw new Error(`Unrecognized key: "${s}"`);
          n[s] && (i[s] = new e({
            type: "nonoptional",
            innerType: r[s]
          }));
        }
      else
        for (let s in r)
          i[s] = new e({
            type: "nonoptional",
            innerType: r[s]
          });
      return ze(this, "shape", i), i;
    }
  });
  return J(t, o);
}
a(bi, "required");
function je(e, t = 0) {
  if (e.aborted === !0)
    return !0;
  for (let n = t; n < e.issues.length; n++)
    if (e.issues[n]?.continue !== !0)
      return !0;
  return !1;
}
a(je, "aborted");
function $i(e, t = 0) {
  if (e.aborted === !0)
    return !0;
  for (let n = t; n < e.issues.length; n++)
    if (e.issues[n]?.continue === !1)
      return !0;
  return !1;
}
a($i, "explicitlyAborted");
function re(e, t) {
  return t.map((n) => {
    var o;
    return (o = n).path ?? (o.path = []), n.path.unshift(e), n;
  });
}
a(re, "prefixIssues");
function Ut(e) {
  return typeof e == "string" ? e : e?.message;
}
a(Ut, "unwrapMessage");
function Q(e, t, n) {
  let o = e.message ? e.message : Ut(e.inst?._zod.def?.error?.(e)) ?? Ut(t?.error?.(e)) ?? Ut(n.customError?.(e)) ?? Ut(n.localeError?.(e)) ?? "Invalid input", { inst: r, continue: i, input: s, ...c } = e;
  return c.path ?? (c.path = []), c.message = o, t?.reportInput && (c.input = s), c;
}
a(Q, "finalizeIssue");
function Zt(e) {
  return e instanceof Set ? "set" : e instanceof Map ? "map" : e instanceof File ? "file" : "unknown";
}
a(Zt, "getSizableOrigin");
function At(e) {
  return Array.isArray(e) ? "array" : typeof e == "string" ? "string" : "unknown";
}
a(At, "getLengthableOrigin");
function b(e) {
  let t = typeof e;
  switch (t) {
    case "number":
      return Number.isNaN(e) ? "nan" : "number";
    case "object": {
      if (e === null)
        return "null";
      if (Array.isArray(e))
        return "array";
      let n = e;
      if (n && Object.getPrototypeOf(n) !== Object.prototype && "constructor" in n && n.constructor)
        return n.constructor.name;
    }
  }
  return t;
}
a(b, "parsedType");
function ct(...e) {
  let [t, n, o] = e;
  return typeof t == "string" ? {
    message: t,
    code: "custom",
    input: n,
    inst: o
  } : { ...t };
}
a(ct, "issue");
function Um(e) {
  return Object.entries(e).filter(([t, n]) => Number.isNaN(Number.parseInt(t, 10))).map((t) => t[1]);
}
a(Um, "cleanEnum");
function gl(e) {
  let t = atob(e), n = new Uint8Array(t.length);
  for (let o = 0; o < t.length; o++)
    n[o] = t.charCodeAt(o);
  return n;
}
a(gl, "base64ToUint8Array");
function hl(e) {
  let t = "";
  for (let n = 0; n < e.length; n++)
    t += String.fromCharCode(e[n]);
  return btoa(t);
}
a(hl, "uint8ArrayToBase64");
function Dm(e) {
  let t = e.replace(/-/g, "+").replace(/_/g, "/"), n = "=".repeat((4 - t.length % 4) % 4);
  return gl(t + n);
}
a(Dm, "base64urlToUint8Array");
function Em(e) {
  return hl(e).replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, "");
}
a(Em, "uint8ArrayToBase64url");
function Nm(e) {
  let t = e.replace(/^0x/, "");
  if (t.length % 2 !== 0)
    throw new Error("Invalid hex string length");
  let n = new Uint8Array(t.length / 2);
  for (let o = 0; o < t.length; o += 2)
    n[o / 2] = Number.parseInt(t.slice(o, o + 2), 16);
  return n;
}
a(Nm, "hexToUint8Array");
function Zm(e) {
  return Array.from(e).map((t) => t.toString(16).padStart(2, "0")).join("");
}
a(Zm, "uint8ArrayToHex");
var ai = class {
  static {
    a(this, "Class");
  }
  constructor(...t) {
  }
};

// versions/4.4.3/node_modules/zod/v4/core/errors.js
var vl = /* @__PURE__ */ a((e, t) => {
  e.name = "$ZodError", Object.defineProperty(e, "_zod", {
    value: e._zod,
    enumerable: !1
  }), Object.defineProperty(e, "issues", {
    value: t,
    enumerable: !1
  }), e.message = JSON.stringify(t, si, 2), Object.defineProperty(e, "toString", {
    value: /* @__PURE__ */ a(() => e.message, "value"),
    enumerable: !1
  });
}, "initializer"), _e = f("$ZodError", vl), ne = f("$ZodError", vl, { Parent: Error });
function xi(e, t = (n) => n.message) {
  let n = {}, o = [];
  for (let r of e.issues)
    r.path.length > 0 ? (n[r.path[0]] = n[r.path[0]] || [], n[r.path[0]].push(t(r))) : o.push(t(r));
  return { formErrors: o, fieldErrors: n };
}
a(xi, "flattenError");
function _i(e, t = (n) => n.message) {
  let n = { _errors: [] }, o = /* @__PURE__ */ a((r, i = []) => {
    for (let s of r.issues)
      if (s.code === "invalid_union" && s.errors.length)
        s.errors.map((c) => o({ issues: c }, [...i, ...s.path]));
      else if (s.code === "invalid_key")
        o({ issues: s.issues }, [...i, ...s.path]);
      else if (s.code === "invalid_element")
        o({ issues: s.issues }, [...i, ...s.path]);
      else {
        let c = [...i, ...s.path];
        if (c.length === 0)
          n._errors.push(t(s));
        else {
          let u = n, l = 0;
          for (; l < c.length; ) {
            let d = c[l];
            l === c.length - 1 ? (u[d] = u[d] || { _errors: [] }, u[d]._errors.push(t(s))) : u[d] = u[d] || { _errors: [] }, u = u[d], l++;
          }
        }
      }
  }, "processError");
  return o(e), n;
}
a(_i, "formatError");
function wi(e, t = (n) => n.message) {
  let n = { errors: [] }, o = /* @__PURE__ */ a((r, i = []) => {
    var s, c;
    for (let u of r.issues)
      if (u.code === "invalid_union" && u.errors.length)
        u.errors.map((l) => o({ issues: l }, [...i, ...u.path]));
      else if (u.code === "invalid_key")
        o({ issues: u.issues }, [...i, ...u.path]);
      else if (u.code === "invalid_element")
        o({ issues: u.issues }, [...i, ...u.path]);
      else {
        let l = [...i, ...u.path];
        if (l.length === 0) {
          n.errors.push(t(u));
          continue;
        }
        let d = n, g = 0;
        for (; g < l.length; ) {
          let $ = l[g], v = g === l.length - 1;
          typeof $ == "string" ? (d.properties ?? (d.properties = {}), (s = d.properties)[$] ?? (s[$] = { errors: [] }), d = d.properties[$]) : (d.items ?? (d.items = []), (c = d.items)[$] ?? (c[$] = { errors: [] }), d = d.items[$]), v && d.errors.push(t(u)), g++;
        }
      }
  }, "processError");
  return o(e), n;
}
a(wi, "treeifyError");
function yl(e) {
  let t = [], n = e.map((o) => typeof o == "object" ? o.key : o);
  for (let o of n)
    typeof o == "number" ? t.push(`[${o}]`) : typeof o == "symbol" ? t.push(`[${JSON.stringify(String(o))}]`) : /[^\w$]/.test(o) ? t.push(`[${JSON.stringify(o)}]`) : (t.length && t.push("."), t.push(o));
  return t.join("");
}
a(yl, "toDotPath");
function ki(e) {
  let t = [], n = [...e.issues].sort((o, r) => (o.path ?? []).length - (r.path ?? []).length);
  for (let o of n)
    t.push(`\u2716 ${o.message}`), o.path?.length && t.push(`  \u2192 at ${yl(o.path)}`);
  return t.join(`
`);
}
a(ki, "prettifyError");

// versions/4.4.3/node_modules/zod/v4/core/parse.js
var Ur = /* @__PURE__ */ a((e) => (t, n, o, r) => {
  let i = o ? { ...o, async: !1 } : { async: !1 }, s = t._zod.run({ value: n, issues: [] }, i);
  if (s instanceof Promise)
    throw new pe();
  if (s.issues.length) {
    let c = new (r?.Err ?? e)(s.issues.map((u) => Q(u, i, X())));
    throw Tr(c, r?.callee), c;
  }
  return s.value;
}, "_parse"), ie = /* @__PURE__ */ Ur(ne), Dr = /* @__PURE__ */ a((e) => async (t, n, o, r) => {
  let i = o ? { ...o, async: !0 } : { async: !0 }, s = t._zod.run({ value: n, issues: [] }, i);
  if (s instanceof Promise && (s = await s), s.issues.length) {
    let c = new (r?.Err ?? e)(s.issues.map((u) => Q(u, i, X())));
    throw Tr(c, r?.callee), c;
  }
  return s.value;
}, "_parseAsync"), Oe = /* @__PURE__ */ Dr(ne), Er = /* @__PURE__ */ a((e) => (t, n, o) => {
  let r = o ? { ...o, async: !1 } : { async: !1 }, i = t._zod.run({ value: n, issues: [] }, r);
  if (i instanceof Promise)
    throw new pe();
  return i.issues.length ? {
    success: !1,
    error: new (e ?? _e)(i.issues.map((s) => Q(s, r, X())))
  } : { success: !0, data: i.value };
}, "_safeParse"), me = /* @__PURE__ */ Er(ne), Nr = /* @__PURE__ */ a((e) => async (t, n, o) => {
  let r = o ? { ...o, async: !0 } : { async: !0 }, i = t._zod.run({ value: n, issues: [] }, r);
  return i instanceof Promise && (i = await i), i.issues.length ? {
    success: !1,
    error: new e(i.issues.map((s) => Q(s, r, X())))
  } : { success: !0, data: i.value };
}, "_safeParseAsync"), Je = /* @__PURE__ */ Nr(ne), bl = /* @__PURE__ */ a((e) => (t, n, o) => {
  let r = o ? { ...o, direction: "backward" } : { direction: "backward" };
  return Ur(e)(t, n, r);
}, "_encode"), Y = /* @__PURE__ */ bl(ne), $l = /* @__PURE__ */ a((e) => (t, n, o) => Ur(e)(t, n, o), "_decode"), Ii = /* @__PURE__ */ $l(ne), xl = /* @__PURE__ */ a((e) => async (t, n, o) => {
  let r = o ? { ...o, direction: "backward" } : { direction: "backward" };
  return Dr(e)(t, n, r);
}, "_encodeAsync"), zi = /* @__PURE__ */ xl(ne), _l = /* @__PURE__ */ a((e) => async (t, n, o) => Dr(e)(t, n, o), "_decodeAsync"), Si = /* @__PURE__ */ _l(ne), wl = /* @__PURE__ */ a((e) => (t, n, o) => {
  let r = o ? { ...o, direction: "backward" } : { direction: "backward" };
  return Er(e)(t, n, r);
}, "_safeEncode"), ji = /* @__PURE__ */ wl(ne), kl = /* @__PURE__ */ a((e) => (t, n, o) => Er(e)(t, n, o), "_safeDecode"), Oi = /* @__PURE__ */ kl(ne), Il = /* @__PURE__ */ a((e) => async (t, n, o) => {
  let r = o ? { ...o, direction: "backward" } : { direction: "backward" };
  return Nr(e)(t, n, r);
}, "_safeEncodeAsync"), Ti = /* @__PURE__ */ Il(ne), zl = /* @__PURE__ */ a((e) => async (t, n, o) => Nr(e)(t, n, o), "_safeDecodeAsync"), Pi = /* @__PURE__ */ zl(ne);

// versions/4.4.3/node_modules/zod/v4/core/regexes.js
var ae = {};
Ce(ae, {
  base64: () => Wi,
  base64url: () => Zr,
  bigint: () => eo,
  boolean: () => ro,
  browserEmail: () => qm,
  cidrv4: () => qi,
  cidrv6: () => Ji,
  cuid: () => Ui,
  cuid2: () => Di,
  date: () => Xi,
  datetime: () => Qi,
  domain: () => Km,
  duration: () => Ci,
  e164: () => Gi,
  email: () => Fi,
  emoji: () => Mi,
  extendedDuration: () => Cm,
  guid: () => Ri,
  hex: () => Gm,
  hostname: () => Wm,
  html5Email: () => Lm,
  httpProtocol: () => Ki,
  idnEmail: () => Vm,
  integer: () => to,
  ipv4: () => Li,
  ipv6: () => Bi,
  ksuid: () => Zi,
  lowercase: () => oo,
  mac: () => Vi,
  md5_base64: () => Hm,
  md5_base64url: () => Qm,
  md5_hex: () => Xm,
  nanoid: () => Ai,
  null: () => no,
  number: () => Ar,
  rfc5322Email: () => Bm,
  sha1_base64: () => eg,
  sha1_base64url: () => tg,
  sha1_hex: () => Ym,
  sha256_base64: () => ng,
  sha256_base64url: () => ig,
  sha256_hex: () => rg,
  sha384_base64: () => ag,
  sha384_base64url: () => sg,
  sha384_hex: () => og,
  sha512_base64: () => ug,
  sha512_base64url: () => lg,
  sha512_hex: () => cg,
  string: () => Yi,
  time: () => Hi,
  ulid: () => Ei,
  undefined: () => io,
  unicodeEmail: () => Sl,
  uppercase: () => ao,
  uuid: () => We,
  uuid4: () => Rm,
  uuid6: () => Fm,
  uuid7: () => Mm,
  xid: () => Ni
});
var Ui = /^[cC][0-9a-z]{6,}$/, Di = /^[0-9a-z]+$/, Ei = /^[0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{26}$/, Ni = /^[0-9a-vA-V]{20}$/, Zi = /^[A-Za-z0-9]{27}$/, Ai = /^[a-zA-Z0-9_-]{21}$/, Ci = /^P(?:(\d+W)|(?!.*W)(?=\d|T\d)(\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+([.,]\d+)?S)?)?)$/, Cm = /^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/, Ri = /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/, We = /* @__PURE__ */ a((e) => e ? new RegExp(`^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${e}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`) : /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/, "uuid"), Rm = /* @__PURE__ */ We(4), Fm = /* @__PURE__ */ We(6), Mm = /* @__PURE__ */ We(7), Fi = /^(?!\.)(?!.*\.\.)([A-Za-z0-9_'+\-\.]*)[A-Za-z0-9_+-]@([A-Za-z0-9][A-Za-z0-9\-]*\.)+[A-Za-z]{2,}$/, Lm = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/, Bm = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/, Sl = /^[^\s@"]{1,64}@[^\s@]{1,255}$/u, Vm = Sl, qm = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/, Jm = "^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$";
function Mi() {
  return new RegExp(Jm, "u");
}
a(Mi, "emoji");
var Li = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/, Bi = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))$/, Vi = /* @__PURE__ */ a((e) => {
  let t = le(e ?? ":");
  return new RegExp(`^(?:[0-9A-F]{2}${t}){5}[0-9A-F]{2}$|^(?:[0-9a-f]{2}${t}){5}[0-9a-f]{2}$`);
}, "mac"), qi = /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/([0-9]|[1-2][0-9]|3[0-2])$/, Ji = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|::|([0-9a-fA-F]{1,4})?::([0-9a-fA-F]{1,4}:?){0,6})\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/, Wi = /^$|^(?:[0-9a-zA-Z+/]{4})*(?:(?:[0-9a-zA-Z+/]{2}==)|(?:[0-9a-zA-Z+/]{3}=))?$/, Zr = /^[A-Za-z0-9_-]*$/, Wm = /^(?=.{1,253}\.?$)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[-0-9a-zA-Z]{0,61}[0-9a-zA-Z])?)*\.?$/, Km = /^([a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$/, Ki = /^https?$/, Gi = /^\+[1-9]\d{6,14}$/, jl = "(?:(?:\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-(?:(?:0[13578]|1[02])-(?:0[1-9]|[12]\\d|3[01])|(?:0[469]|11)-(?:0[1-9]|[12]\\d|30)|(?:02)-(?:0[1-9]|1\\d|2[0-8])))", Xi = /* @__PURE__ */ new RegExp(`^${jl}$`);
function Ol(e) {
  let t = "(?:[01]\\d|2[0-3]):[0-5]\\d";
  return typeof e.precision == "number" ? e.precision === -1 ? `${t}` : e.precision === 0 ? `${t}:[0-5]\\d` : `${t}:[0-5]\\d\\.\\d{${e.precision}}` : `${t}(?::[0-5]\\d(?:\\.\\d+)?)?`;
}
a(Ol, "timeSource");
function Hi(e) {
  return new RegExp(`^${Ol(e)}$`);
}
a(Hi, "time");
function Qi(e) {
  let t = Ol({ precision: e.precision }), n = ["Z"];
  e.local && n.push(""), e.offset && n.push("([+-](?:[01]\\d|2[0-3]):[0-5]\\d)");
  let o = `${t}(?:${n.join("|")})`;
  return new RegExp(`^${jl}T(?:${o})$`);
}
a(Qi, "datetime");
var Yi = /* @__PURE__ */ a((e) => {
  let t = e ? `[\\s\\S]{${e?.minimum ?? 0},${e?.maximum ?? ""}}` : "[\\s\\S]*";
  return new RegExp(`^${t}$`);
}, "string"), eo = /^-?\d+n?$/, to = /^-?\d+$/, Ar = /^-?\d+(?:\.\d+)?$/, ro = /^(?:true|false)$/i, no = /^null$/i;
var io = /^undefined$/i;
var oo = /^[^A-Z]*$/, ao = /^[^a-z]*$/, Gm = /^[0-9a-fA-F]*$/;
function Ct(e, t) {
  return new RegExp(`^[A-Za-z0-9+/]{${e}}${t}$`);
}
a(Ct, "fixedBase64");
function Rt(e) {
  return new RegExp(`^[A-Za-z0-9_-]{${e}}$`);
}
a(Rt, "fixedBase64url");
var Xm = /^[0-9a-fA-F]{32}$/, Hm = /* @__PURE__ */ Ct(22, "=="), Qm = /* @__PURE__ */ Rt(22), Ym = /^[0-9a-fA-F]{40}$/, eg = /* @__PURE__ */ Ct(27, "="), tg = /* @__PURE__ */ Rt(27), rg = /^[0-9a-fA-F]{64}$/, ng = /* @__PURE__ */ Ct(43, "="), ig = /* @__PURE__ */ Rt(43), og = /^[0-9a-fA-F]{96}$/, ag = /* @__PURE__ */ Ct(64, ""), sg = /* @__PURE__ */ Rt(64), cg = /^[0-9a-fA-F]{128}$/, ug = /* @__PURE__ */ Ct(86, "=="), lg = /* @__PURE__ */ Rt(86);

// versions/4.4.3/node_modules/zod/v4/core/checks.js
var A = /* @__PURE__ */ f("$ZodCheck", (e, t) => {
  var n;
  e._zod ?? (e._zod = {}), e._zod.def = t, (n = e._zod).onattach ?? (n.onattach = []);
}), Pl = {
  number: "number",
  bigint: "bigint",
  object: "date"
}, Cr = /* @__PURE__ */ f("$ZodCheckLessThan", (e, t) => {
  A.init(e, t);
  let n = Pl[typeof t.value];
  e._zod.onattach.push((o) => {
    let r = o._zod.bag, i = (t.inclusive ? r.maximum : r.exclusiveMaximum) ?? Number.POSITIVE_INFINITY;
    t.value < i && (t.inclusive ? r.maximum = t.value : r.exclusiveMaximum = t.value);
  }), e._zod.check = (o) => {
    (t.inclusive ? o.value <= t.value : o.value < t.value) || o.issues.push({
      origin: n,
      code: "too_big",
      maximum: typeof t.value == "object" ? t.value.getTime() : t.value,
      input: o.value,
      inclusive: t.inclusive,
      inst: e,
      continue: !t.abort
    });
  };
}), Rr = /* @__PURE__ */ f("$ZodCheckGreaterThan", (e, t) => {
  A.init(e, t);
  let n = Pl[typeof t.value];
  e._zod.onattach.push((o) => {
    let r = o._zod.bag, i = (t.inclusive ? r.minimum : r.exclusiveMinimum) ?? Number.NEGATIVE_INFINITY;
    t.value > i && (t.inclusive ? r.minimum = t.value : r.exclusiveMinimum = t.value);
  }), e._zod.check = (o) => {
    (t.inclusive ? o.value >= t.value : o.value > t.value) || o.issues.push({
      origin: n,
      code: "too_small",
      minimum: typeof t.value == "object" ? t.value.getTime() : t.value,
      input: o.value,
      inclusive: t.inclusive,
      inst: e,
      continue: !t.abort
    });
  };
}), so = /* @__PURE__ */ f("$ZodCheckMultipleOf", (e, t) => {
  A.init(e, t), e._zod.onattach.push((n) => {
    var o;
    (o = n._zod.bag).multipleOf ?? (o.multipleOf = t.value);
  }), e._zod.check = (n) => {
    if (typeof n.value != typeof t.value)
      throw new Error("Cannot mix number and bigint in multiple_of check.");
    (typeof n.value == "bigint" ? n.value % t.value === BigInt(0) : ci(n.value, t.value) === 0) || n.issues.push({
      origin: typeof n.value,
      code: "not_multiple_of",
      divisor: t.value,
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), co = /* @__PURE__ */ f("$ZodCheckNumberFormat", (e, t) => {
  A.init(e, t), t.format = t.format || "float64";
  let n = t.format?.includes("int"), o = n ? "int" : "number", [r, i] = pi[t.format];
  e._zod.onattach.push((s) => {
    let c = s._zod.bag;
    c.format = t.format, c.minimum = r, c.maximum = i, n && (c.pattern = to);
  }), e._zod.check = (s) => {
    let c = s.value;
    if (n) {
      if (!Number.isInteger(c)) {
        s.issues.push({
          expected: o,
          format: t.format,
          code: "invalid_type",
          continue: !1,
          input: c,
          inst: e
        });
        return;
      }
      if (!Number.isSafeInteger(c)) {
        c > 0 ? s.issues.push({
          input: c,
          code: "too_big",
          maximum: Number.MAX_SAFE_INTEGER,
          note: "Integers must be within the safe integer range.",
          inst: e,
          origin: o,
          inclusive: !0,
          continue: !t.abort
        }) : s.issues.push({
          input: c,
          code: "too_small",
          minimum: Number.MIN_SAFE_INTEGER,
          note: "Integers must be within the safe integer range.",
          inst: e,
          origin: o,
          inclusive: !0,
          continue: !t.abort
        });
        return;
      }
    }
    c < r && s.issues.push({
      origin: "number",
      input: c,
      code: "too_small",
      minimum: r,
      inclusive: !0,
      inst: e,
      continue: !t.abort
    }), c > i && s.issues.push({
      origin: "number",
      input: c,
      code: "too_big",
      maximum: i,
      inclusive: !0,
      inst: e,
      continue: !t.abort
    });
  };
}), uo = /* @__PURE__ */ f("$ZodCheckBigIntFormat", (e, t) => {
  A.init(e, t);
  let [n, o] = mi[t.format];
  e._zod.onattach.push((r) => {
    let i = r._zod.bag;
    i.format = t.format, i.minimum = n, i.maximum = o;
  }), e._zod.check = (r) => {
    let i = r.value;
    i < n && r.issues.push({
      origin: "bigint",
      input: i,
      code: "too_small",
      minimum: n,
      inclusive: !0,
      inst: e,
      continue: !t.abort
    }), i > o && r.issues.push({
      origin: "bigint",
      input: i,
      code: "too_big",
      maximum: o,
      inclusive: !0,
      inst: e,
      continue: !t.abort
    });
  };
}), lo = /* @__PURE__ */ f("$ZodCheckMaxSize", (e, t) => {
  var n;
  A.init(e, t), (n = e._zod.def).when ?? (n.when = (o) => {
    let r = o.value;
    return !Ie(r) && r.size !== void 0;
  }), e._zod.onattach.push((o) => {
    let r = o._zod.bag.maximum ?? Number.POSITIVE_INFINITY;
    t.maximum < r && (o._zod.bag.maximum = t.maximum);
  }), e._zod.check = (o) => {
    let r = o.value;
    r.size <= t.maximum || o.issues.push({
      origin: Zt(r),
      code: "too_big",
      maximum: t.maximum,
      inclusive: !0,
      input: r,
      inst: e,
      continue: !t.abort
    });
  };
}), fo = /* @__PURE__ */ f("$ZodCheckMinSize", (e, t) => {
  var n;
  A.init(e, t), (n = e._zod.def).when ?? (n.when = (o) => {
    let r = o.value;
    return !Ie(r) && r.size !== void 0;
  }), e._zod.onattach.push((o) => {
    let r = o._zod.bag.minimum ?? Number.NEGATIVE_INFINITY;
    t.minimum > r && (o._zod.bag.minimum = t.minimum);
  }), e._zod.check = (o) => {
    let r = o.value;
    r.size >= t.minimum || o.issues.push({
      origin: Zt(r),
      code: "too_small",
      minimum: t.minimum,
      inclusive: !0,
      input: r,
      inst: e,
      continue: !t.abort
    });
  };
}), po = /* @__PURE__ */ f("$ZodCheckSizeEquals", (e, t) => {
  var n;
  A.init(e, t), (n = e._zod.def).when ?? (n.when = (o) => {
    let r = o.value;
    return !Ie(r) && r.size !== void 0;
  }), e._zod.onattach.push((o) => {
    let r = o._zod.bag;
    r.minimum = t.size, r.maximum = t.size, r.size = t.size;
  }), e._zod.check = (o) => {
    let r = o.value, i = r.size;
    if (i === t.size)
      return;
    let s = i > t.size;
    o.issues.push({
      origin: Zt(r),
      ...s ? { code: "too_big", maximum: t.size } : { code: "too_small", minimum: t.size },
      inclusive: !0,
      exact: !0,
      input: o.value,
      inst: e,
      continue: !t.abort
    });
  };
}), mo = /* @__PURE__ */ f("$ZodCheckMaxLength", (e, t) => {
  var n;
  A.init(e, t), (n = e._zod.def).when ?? (n.when = (o) => {
    let r = o.value;
    return !Ie(r) && r.length !== void 0;
  }), e._zod.onattach.push((o) => {
    let r = o._zod.bag.maximum ?? Number.POSITIVE_INFINITY;
    t.maximum < r && (o._zod.bag.maximum = t.maximum);
  }), e._zod.check = (o) => {
    let r = o.value;
    if (r.length <= t.maximum)
      return;
    let s = At(r);
    o.issues.push({
      origin: s,
      code: "too_big",
      maximum: t.maximum,
      inclusive: !0,
      input: r,
      inst: e,
      continue: !t.abort
    });
  };
}), go = /* @__PURE__ */ f("$ZodCheckMinLength", (e, t) => {
  var n;
  A.init(e, t), (n = e._zod.def).when ?? (n.when = (o) => {
    let r = o.value;
    return !Ie(r) && r.length !== void 0;
  }), e._zod.onattach.push((o) => {
    let r = o._zod.bag.minimum ?? Number.NEGATIVE_INFINITY;
    t.minimum > r && (o._zod.bag.minimum = t.minimum);
  }), e._zod.check = (o) => {
    let r = o.value;
    if (r.length >= t.minimum)
      return;
    let s = At(r);
    o.issues.push({
      origin: s,
      code: "too_small",
      minimum: t.minimum,
      inclusive: !0,
      input: r,
      inst: e,
      continue: !t.abort
    });
  };
}), ho = /* @__PURE__ */ f("$ZodCheckLengthEquals", (e, t) => {
  var n;
  A.init(e, t), (n = e._zod.def).when ?? (n.when = (o) => {
    let r = o.value;
    return !Ie(r) && r.length !== void 0;
  }), e._zod.onattach.push((o) => {
    let r = o._zod.bag;
    r.minimum = t.length, r.maximum = t.length, r.length = t.length;
  }), e._zod.check = (o) => {
    let r = o.value, i = r.length;
    if (i === t.length)
      return;
    let s = At(r), c = i > t.length;
    o.issues.push({
      origin: s,
      ...c ? { code: "too_big", maximum: t.length } : { code: "too_small", minimum: t.length },
      inclusive: !0,
      exact: !0,
      input: o.value,
      inst: e,
      continue: !t.abort
    });
  };
}), ut = /* @__PURE__ */ f("$ZodCheckStringFormat", (e, t) => {
  var n, o;
  A.init(e, t), e._zod.onattach.push((r) => {
    let i = r._zod.bag;
    i.format = t.format, t.pattern && (i.patterns ?? (i.patterns = /* @__PURE__ */ new Set()), i.patterns.add(t.pattern));
  }), t.pattern ? (n = e._zod).check ?? (n.check = (r) => {
    t.pattern.lastIndex = 0, !t.pattern.test(r.value) && r.issues.push({
      origin: "string",
      code: "invalid_format",
      format: t.format,
      input: r.value,
      ...t.pattern ? { pattern: t.pattern.toString() } : {},
      inst: e,
      continue: !t.abort
    });
  }) : (o = e._zod).check ?? (o.check = () => {
  });
}), vo = /* @__PURE__ */ f("$ZodCheckRegex", (e, t) => {
  ut.init(e, t), e._zod.check = (n) => {
    t.pattern.lastIndex = 0, !t.pattern.test(n.value) && n.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "regex",
      input: n.value,
      pattern: t.pattern.toString(),
      inst: e,
      continue: !t.abort
    });
  };
}), yo = /* @__PURE__ */ f("$ZodCheckLowerCase", (e, t) => {
  t.pattern ?? (t.pattern = oo), ut.init(e, t);
}), bo = /* @__PURE__ */ f("$ZodCheckUpperCase", (e, t) => {
  t.pattern ?? (t.pattern = ao), ut.init(e, t);
}), $o = /* @__PURE__ */ f("$ZodCheckIncludes", (e, t) => {
  A.init(e, t);
  let n = le(t.includes), o = new RegExp(typeof t.position == "number" ? `^.{${t.position}}${n}` : n);
  t.pattern = o, e._zod.onattach.push((r) => {
    let i = r._zod.bag;
    i.patterns ?? (i.patterns = /* @__PURE__ */ new Set()), i.patterns.add(o);
  }), e._zod.check = (r) => {
    r.value.includes(t.includes, t.position) || r.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "includes",
      includes: t.includes,
      input: r.value,
      inst: e,
      continue: !t.abort
    });
  };
}), xo = /* @__PURE__ */ f("$ZodCheckStartsWith", (e, t) => {
  A.init(e, t);
  let n = new RegExp(`^${le(t.prefix)}.*`);
  t.pattern ?? (t.pattern = n), e._zod.onattach.push((o) => {
    let r = o._zod.bag;
    r.patterns ?? (r.patterns = /* @__PURE__ */ new Set()), r.patterns.add(n);
  }), e._zod.check = (o) => {
    o.value.startsWith(t.prefix) || o.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "starts_with",
      prefix: t.prefix,
      input: o.value,
      inst: e,
      continue: !t.abort
    });
  };
}), _o = /* @__PURE__ */ f("$ZodCheckEndsWith", (e, t) => {
  A.init(e, t);
  let n = new RegExp(`.*${le(t.suffix)}$`);
  t.pattern ?? (t.pattern = n), e._zod.onattach.push((o) => {
    let r = o._zod.bag;
    r.patterns ?? (r.patterns = /* @__PURE__ */ new Set()), r.patterns.add(n);
  }), e._zod.check = (o) => {
    o.value.endsWith(t.suffix) || o.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "ends_with",
      suffix: t.suffix,
      input: o.value,
      inst: e,
      continue: !t.abort
    });
  };
});
function Tl(e, t, n) {
  e.issues.length && t.issues.push(...re(n, e.issues));
}
a(Tl, "handleCheckPropertyResult");
var wo = /* @__PURE__ */ f("$ZodCheckProperty", (e, t) => {
  A.init(e, t), e._zod.check = (n) => {
    let o = t.schema._zod.run({
      value: n.value[t.property],
      issues: []
    }, {});
    if (o instanceof Promise)
      return o.then((r) => Tl(r, n, t.property));
    Tl(o, n, t.property);
  };
}), ko = /* @__PURE__ */ f("$ZodCheckMimeType", (e, t) => {
  A.init(e, t);
  let n = new Set(t.mime);
  e._zod.onattach.push((o) => {
    o._zod.bag.mime = t.mime;
  }), e._zod.check = (o) => {
    n.has(o.value.type) || o.issues.push({
      code: "invalid_value",
      values: t.mime,
      input: o.value.type,
      inst: e,
      continue: !t.abort
    });
  };
}), Io = /* @__PURE__ */ f("$ZodCheckOverwrite", (e, t) => {
  A.init(e, t), e._zod.check = (n) => {
    n.value = t.tx(n.value);
  };
});

// versions/4.4.3/node_modules/zod/v4/core/doc.js
var Ft = class {
  static {
    a(this, "Doc");
  }
  constructor(t = []) {
    this.content = [], this.indent = 0, this && (this.args = t);
  }
  indented(t) {
    this.indent += 1, t(this), this.indent -= 1;
  }
  write(t) {
    if (typeof t == "function") {
      t(this, { execution: "sync" }), t(this, { execution: "async" });
      return;
    }
    let o = t.split(`
`).filter((s) => s), r = Math.min(...o.map((s) => s.length - s.trimStart().length)), i = o.map((s) => s.slice(r)).map((s) => " ".repeat(this.indent * 2) + s);
    for (let s of i)
      this.content.push(s);
  }
  compile() {
    let t = Function, n = this?.args, r = [...(this?.content ?? [""]).map((i) => `  ${i}`)];
    return new t(...n, r.join(`
`));
  }
};

// versions/4.4.3/node_modules/zod/v4/core/versions.js
var zo = {
  major: 4,
  minor: 4,
  patch: 3
};

// versions/4.4.3/node_modules/zod/v4/core/schemas.js
var _ = /* @__PURE__ */ f("$ZodType", (e, t) => {
  var n;
  e ?? (e = {}), e._zod.def = t, e._zod.bag = e._zod.bag || {}, e._zod.version = zo;
  let o = [...e._zod.def.checks ?? []];
  e._zod.traits.has("$ZodCheck") && o.unshift(e);
  for (let r of o)
    for (let i of r._zod.onattach)
      i(e);
  if (o.length === 0)
    (n = e._zod).deferred ?? (n.deferred = []), e._zod.deferred?.push(() => {
      e._zod.run = e._zod.parse;
    });
  else {
    let r = /* @__PURE__ */ a((s, c, u) => {
      let l = je(s), d;
      for (let g of c) {
        if (g._zod.def.when) {
          if ($i(s) || !g._zod.def.when(s))
            continue;
        } else if (l)
          continue;
        let $ = s.issues.length, v = g._zod.check(s);
        if (v instanceof Promise && u?.async === !1)
          throw new pe();
        if (d || v instanceof Promise)
          d = (d ?? Promise.resolve()).then(async () => {
            await v, s.issues.length !== $ && (l || (l = je(s, $)));
          });
        else {
          if (s.issues.length === $)
            continue;
          l || (l = je(s, $));
        }
      }
      return d ? d.then(() => s) : s;
    }, "runChecks"), i = /* @__PURE__ */ a((s, c, u) => {
      if (je(s))
        return s.aborted = !0, s;
      let l = r(c, o, u);
      if (l instanceof Promise) {
        if (u.async === !1)
          throw new pe();
        return l.then((d) => e._zod.parse(d, u));
      }
      return e._zod.parse(l, u);
    }, "handleCanaryResult");
    e._zod.run = (s, c) => {
      if (c.skipChecks)
        return e._zod.parse(s, c);
      if (c.direction === "backward") {
        let l = e._zod.parse({ value: s.value, issues: [] }, { ...c, skipChecks: !0 });
        return l instanceof Promise ? l.then((d) => i(d, s, c)) : i(l, s, c);
      }
      let u = e._zod.parse(s, c);
      if (u instanceof Promise) {
        if (c.async === !1)
          throw new pe();
        return u.then((l) => r(l, o, c));
      }
      return r(u, o, c);
    };
  }
  S(e, "~standard", () => ({
    validate: /* @__PURE__ */ a((r) => {
      try {
        let i = me(e, r);
        return i.success ? { value: i.data } : { issues: i.error?.issues };
      } catch {
        return Je(e, r).then((s) => s.success ? { value: s.data } : { issues: s.error?.issues });
      }
    }, "validate"),
    vendor: "zod",
    version: 1
  }));
}), lt = /* @__PURE__ */ f("$ZodString", (e, t) => {
  _.init(e, t), e._zod.pattern = [...e?._zod.bag?.patterns ?? []].pop() ?? Yi(e._zod.bag), e._zod.parse = (n, o) => {
    if (t.coerce)
      try {
        n.value = String(n.value);
      } catch {
      }
    return typeof n.value == "string" || n.issues.push({
      expected: "string",
      code: "invalid_type",
      input: n.value,
      inst: e
    }), n;
  };
}), Z = /* @__PURE__ */ f("$ZodStringFormat", (e, t) => {
  ut.init(e, t), lt.init(e, t);
}), jo = /* @__PURE__ */ f("$ZodGUID", (e, t) => {
  t.pattern ?? (t.pattern = Ri), Z.init(e, t);
}), Oo = /* @__PURE__ */ f("$ZodUUID", (e, t) => {
  if (t.version) {
    let o = {
      v1: 1,
      v2: 2,
      v3: 3,
      v4: 4,
      v5: 5,
      v6: 6,
      v7: 7,
      v8: 8
    }[t.version];
    if (o === void 0)
      throw new Error(`Invalid UUID version: "${t.version}"`);
    t.pattern ?? (t.pattern = We(o));
  } else
    t.pattern ?? (t.pattern = We());
  Z.init(e, t);
}), To = /* @__PURE__ */ f("$ZodEmail", (e, t) => {
  t.pattern ?? (t.pattern = Fi), Z.init(e, t);
}), Po = /* @__PURE__ */ f("$ZodURL", (e, t) => {
  Z.init(e, t), e._zod.check = (n) => {
    try {
      let o = n.value.trim();
      if (!t.normalize && t.protocol?.source === Ki.source && !/^https?:\/\//i.test(o)) {
        n.issues.push({
          code: "invalid_format",
          format: "url",
          note: "Invalid URL format",
          input: n.value,
          inst: e,
          continue: !t.abort
        });
        return;
      }
      let r = new URL(o);
      t.hostname && (t.hostname.lastIndex = 0, t.hostname.test(r.hostname) || n.issues.push({
        code: "invalid_format",
        format: "url",
        note: "Invalid hostname",
        pattern: t.hostname.source,
        input: n.value,
        inst: e,
        continue: !t.abort
      })), t.protocol && (t.protocol.lastIndex = 0, t.protocol.test(r.protocol.endsWith(":") ? r.protocol.slice(0, -1) : r.protocol) || n.issues.push({
        code: "invalid_format",
        format: "url",
        note: "Invalid protocol",
        pattern: t.protocol.source,
        input: n.value,
        inst: e,
        continue: !t.abort
      })), t.normalize ? n.value = r.href : n.value = o;
      return;
    } catch {
      n.issues.push({
        code: "invalid_format",
        format: "url",
        input: n.value,
        inst: e,
        continue: !t.abort
      });
    }
  };
}), Uo = /* @__PURE__ */ f("$ZodEmoji", (e, t) => {
  t.pattern ?? (t.pattern = Mi()), Z.init(e, t);
}), Do = /* @__PURE__ */ f("$ZodNanoID", (e, t) => {
  t.pattern ?? (t.pattern = Ai), Z.init(e, t);
}), Eo = /* @__PURE__ */ f("$ZodCUID", (e, t) => {
  t.pattern ?? (t.pattern = Ui), Z.init(e, t);
}), No = /* @__PURE__ */ f("$ZodCUID2", (e, t) => {
  t.pattern ?? (t.pattern = Di), Z.init(e, t);
}), Zo = /* @__PURE__ */ f("$ZodULID", (e, t) => {
  t.pattern ?? (t.pattern = Ei), Z.init(e, t);
}), Ao = /* @__PURE__ */ f("$ZodXID", (e, t) => {
  t.pattern ?? (t.pattern = Ni), Z.init(e, t);
}), Co = /* @__PURE__ */ f("$ZodKSUID", (e, t) => {
  t.pattern ?? (t.pattern = Zi), Z.init(e, t);
}), Ro = /* @__PURE__ */ f("$ZodISODateTime", (e, t) => {
  t.pattern ?? (t.pattern = Qi(t)), Z.init(e, t);
}), Fo = /* @__PURE__ */ f("$ZodISODate", (e, t) => {
  t.pattern ?? (t.pattern = Xi), Z.init(e, t);
}), Mo = /* @__PURE__ */ f("$ZodISOTime", (e, t) => {
  t.pattern ?? (t.pattern = Hi(t)), Z.init(e, t);
}), Lo = /* @__PURE__ */ f("$ZodISODuration", (e, t) => {
  t.pattern ?? (t.pattern = Ci), Z.init(e, t);
}), Bo = /* @__PURE__ */ f("$ZodIPv4", (e, t) => {
  t.pattern ?? (t.pattern = Li), Z.init(e, t), e._zod.bag.format = "ipv4";
}), Vo = /* @__PURE__ */ f("$ZodIPv6", (e, t) => {
  t.pattern ?? (t.pattern = Bi), Z.init(e, t), e._zod.bag.format = "ipv6", e._zod.check = (n) => {
    try {
      new URL(`http://[${n.value}]`);
    } catch {
      n.issues.push({
        code: "invalid_format",
        format: "ipv6",
        input: n.value,
        inst: e,
        continue: !t.abort
      });
    }
  };
}), qo = /* @__PURE__ */ f("$ZodMAC", (e, t) => {
  t.pattern ?? (t.pattern = Vi(t.delimiter)), Z.init(e, t), e._zod.bag.format = "mac";
}), Jo = /* @__PURE__ */ f("$ZodCIDRv4", (e, t) => {
  t.pattern ?? (t.pattern = qi), Z.init(e, t);
}), Wo = /* @__PURE__ */ f("$ZodCIDRv6", (e, t) => {
  t.pattern ?? (t.pattern = Ji), Z.init(e, t), e._zod.check = (n) => {
    let o = n.value.split("/");
    try {
      if (o.length !== 2)
        throw new Error();
      let [r, i] = o;
      if (!i)
        throw new Error();
      let s = Number(i);
      if (`${s}` !== i)
        throw new Error();
      if (s < 0 || s > 128)
        throw new Error();
      new URL(`http://[${r}]`);
    } catch {
      n.issues.push({
        code: "invalid_format",
        format: "cidrv6",
        input: n.value,
        inst: e,
        continue: !t.abort
      });
    }
  };
});
function Ko(e) {
  if (e === "")
    return !0;
  if (/\s/.test(e) || e.length % 4 !== 0)
    return !1;
  try {
    return atob(e), !0;
  } catch {
    return !1;
  }
}
a(Ko, "isValidBase64");
var Go = /* @__PURE__ */ f("$ZodBase64", (e, t) => {
  t.pattern ?? (t.pattern = Wi), Z.init(e, t), e._zod.bag.contentEncoding = "base64", e._zod.check = (n) => {
    Ko(n.value) || n.issues.push({
      code: "invalid_format",
      format: "base64",
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
});
function Wl(e) {
  if (!Zr.test(e))
    return !1;
  let t = e.replace(/[-_]/g, (o) => o === "-" ? "+" : "/"), n = t.padEnd(Math.ceil(t.length / 4) * 4, "=");
  return Ko(n);
}
a(Wl, "isValidBase64URL");
var Xo = /* @__PURE__ */ f("$ZodBase64URL", (e, t) => {
  t.pattern ?? (t.pattern = Zr), Z.init(e, t), e._zod.bag.contentEncoding = "base64url", e._zod.check = (n) => {
    Wl(n.value) || n.issues.push({
      code: "invalid_format",
      format: "base64url",
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Ho = /* @__PURE__ */ f("$ZodE164", (e, t) => {
  t.pattern ?? (t.pattern = Gi), Z.init(e, t);
});
function Kl(e, t = null) {
  try {
    let n = e.split(".");
    if (n.length !== 3)
      return !1;
    let [o] = n;
    if (!o)
      return !1;
    let r = JSON.parse(atob(o));
    return !("typ" in r && r?.typ !== "JWT" || !r.alg || t && (!("alg" in r) || r.alg !== t));
  } catch {
    return !1;
  }
}
a(Kl, "isValidJWT");
var Qo = /* @__PURE__ */ f("$ZodJWT", (e, t) => {
  Z.init(e, t), e._zod.check = (n) => {
    Kl(n.value, t.alg) || n.issues.push({
      code: "invalid_format",
      format: "jwt",
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Yo = /* @__PURE__ */ f("$ZodCustomStringFormat", (e, t) => {
  Z.init(e, t), e._zod.check = (n) => {
    t.fn(n.value) || n.issues.push({
      code: "invalid_format",
      format: t.format,
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Vr = /* @__PURE__ */ f("$ZodNumber", (e, t) => {
  _.init(e, t), e._zod.pattern = e._zod.bag.pattern ?? Ar, e._zod.parse = (n, o) => {
    if (t.coerce)
      try {
        n.value = Number(n.value);
      } catch {
      }
    let r = n.value;
    if (typeof r == "number" && !Number.isNaN(r) && Number.isFinite(r))
      return n;
    let i = typeof r == "number" ? Number.isNaN(r) ? "NaN" : Number.isFinite(r) ? void 0 : "Infinity" : void 0;
    return n.issues.push({
      expected: "number",
      code: "invalid_type",
      input: r,
      inst: e,
      ...i ? { received: i } : {}
    }), n;
  };
}), ea = /* @__PURE__ */ f("$ZodNumberFormat", (e, t) => {
  co.init(e, t), Vr.init(e, t);
}), Mt = /* @__PURE__ */ f("$ZodBoolean", (e, t) => {
  _.init(e, t), e._zod.pattern = ro, e._zod.parse = (n, o) => {
    if (t.coerce)
      try {
        n.value = !!n.value;
      } catch {
      }
    let r = n.value;
    return typeof r == "boolean" || n.issues.push({
      expected: "boolean",
      code: "invalid_type",
      input: r,
      inst: e
    }), n;
  };
}), qr = /* @__PURE__ */ f("$ZodBigInt", (e, t) => {
  _.init(e, t), e._zod.pattern = eo, e._zod.parse = (n, o) => {
    if (t.coerce)
      try {
        n.value = BigInt(n.value);
      } catch {
      }
    return typeof n.value == "bigint" || n.issues.push({
      expected: "bigint",
      code: "invalid_type",
      input: n.value,
      inst: e
    }), n;
  };
}), ta = /* @__PURE__ */ f("$ZodBigIntFormat", (e, t) => {
  uo.init(e, t), qr.init(e, t);
}), ra = /* @__PURE__ */ f("$ZodSymbol", (e, t) => {
  _.init(e, t), e._zod.parse = (n, o) => {
    let r = n.value;
    return typeof r == "symbol" || n.issues.push({
      expected: "symbol",
      code: "invalid_type",
      input: r,
      inst: e
    }), n;
  };
}), na = /* @__PURE__ */ f("$ZodUndefined", (e, t) => {
  _.init(e, t), e._zod.pattern = io, e._zod.values = /* @__PURE__ */ new Set([void 0]), e._zod.parse = (n, o) => {
    let r = n.value;
    return typeof r > "u" || n.issues.push({
      expected: "undefined",
      code: "invalid_type",
      input: r,
      inst: e
    }), n;
  };
}), ia = /* @__PURE__ */ f("$ZodNull", (e, t) => {
  _.init(e, t), e._zod.pattern = no, e._zod.values = /* @__PURE__ */ new Set([null]), e._zod.parse = (n, o) => {
    let r = n.value;
    return r === null || n.issues.push({
      expected: "null",
      code: "invalid_type",
      input: r,
      inst: e
    }), n;
  };
}), oa = /* @__PURE__ */ f("$ZodAny", (e, t) => {
  _.init(e, t), e._zod.parse = (n) => n;
}), aa = /* @__PURE__ */ f("$ZodUnknown", (e, t) => {
  _.init(e, t), e._zod.parse = (n) => n;
}), sa = /* @__PURE__ */ f("$ZodNever", (e, t) => {
  _.init(e, t), e._zod.parse = (n, o) => (n.issues.push({
    expected: "never",
    code: "invalid_type",
    input: n.value,
    inst: e
  }), n);
}), ca = /* @__PURE__ */ f("$ZodVoid", (e, t) => {
  _.init(e, t), e._zod.parse = (n, o) => {
    let r = n.value;
    return typeof r > "u" || n.issues.push({
      expected: "void",
      code: "invalid_type",
      input: r,
      inst: e
    }), n;
  };
}), dt = /* @__PURE__ */ f("$ZodDate", (e, t) => {
  _.init(e, t), e._zod.parse = (n, o) => {
    if (t.coerce)
      try {
        n.value = new Date(n.value);
      } catch {
      }
    let r = n.value, i = r instanceof Date;
    return i && !Number.isNaN(r.getTime()) || n.issues.push({
      expected: "date",
      code: "invalid_type",
      input: r,
      ...i ? { received: "Invalid Date" } : {},
      inst: e
    }), n;
  };
});
function Dl(e, t, n) {
  e.issues.length && t.issues.push(...re(n, e.issues)), t.value[n] = e.value;
}
a(Dl, "handleArrayResult");
var Te = /* @__PURE__ */ f("$ZodArray", (e, t) => {
  _.init(e, t), e._zod.parse = (n, o) => {
    let r = n.value;
    if (!Array.isArray(r))
      return n.issues.push({
        expected: "array",
        code: "invalid_type",
        input: r,
        inst: e
      }), n;
    n.value = Array(r.length);
    let i = [];
    for (let s = 0; s < r.length; s++) {
      let c = r[s], u = t.element._zod.run({
        value: c,
        issues: []
      }, o);
      u instanceof Promise ? i.push(u.then((l) => Dl(l, n, s))) : Dl(u, n, s);
    }
    return i.length ? Promise.all(i).then(() => n) : n;
  };
});
function Br(e, t, n, o, r, i) {
  let s = n in o;
  if (e.issues.length) {
    if (r && i && !s)
      return;
    t.issues.push(...re(n, e.issues));
  }
  if (!s && !r) {
    e.issues.length || t.issues.push({
      code: "invalid_type",
      expected: "nonoptional",
      input: void 0,
      path: [n]
    });
    return;
  }
  e.value === void 0 ? s && (t.value[n] = void 0) : t.value[n] = e.value;
}
a(Br, "handlePropertyResult");
function Gl(e) {
  let t = Object.keys(e.shape);
  for (let o of t)
    if (!e.shape?.[o]?._zod?.traits?.has("$ZodType"))
      throw new Error(`Invalid element at key "${o}": expected a Zod schema`);
  let n = fi(e.shape);
  return {
    ...e,
    keys: t,
    keySet: new Set(t),
    numKeys: t.length,
    optionalKeys: new Set(n)
  };
}
a(Gl, "normalizeDef");
function Xl(e, t, n, o, r, i) {
  let s = [], c = r.keySet, u = r.catchall._zod, l = u.def.type, d = u.optin === "optional", g = u.optout === "optional";
  for (let $ in t) {
    if ($ === "__proto__" || c.has($))
      continue;
    if (l === "never") {
      s.push($);
      continue;
    }
    let v = u.run({ value: t[$], issues: [] }, o);
    v instanceof Promise ? e.push(v.then((k) => Br(k, n, $, t, d, g))) : Br(v, n, $, t, d, g);
  }
  return s.length && n.issues.push({
    code: "unrecognized_keys",
    keys: s,
    input: t,
    inst: i
  }), e.length ? Promise.all(e).then(() => n) : n;
}
a(Xl, "handleCatchall");
var q = /* @__PURE__ */ f("$ZodObject", (e, t) => {
  if (_.init(e, t), !Object.getOwnPropertyDescriptor(t, "shape")?.get) {
    let c = t.shape;
    Object.defineProperty(t, "shape", {
      get: /* @__PURE__ */ a(() => {
        let u = { ...c };
        return Object.defineProperty(t, "shape", {
          value: u
        }), u;
      }, "get")
    });
  }
  let o = at(() => Gl(t));
  S(e._zod, "propValues", () => {
    let c = t.shape, u = {};
    for (let l in c) {
      let d = c[l]._zod;
      if (d.values) {
        u[l] ?? (u[l] = /* @__PURE__ */ new Set());
        for (let g of d.values)
          u[l].add(g);
      }
    }
    return u;
  });
  let r = qe, i = t.catchall, s;
  e._zod.parse = (c, u) => {
    s ?? (s = o.value);
    let l = c.value;
    if (!r(l))
      return c.issues.push({
        expected: "object",
        code: "invalid_type",
        input: l,
        inst: e
      }), c;
    c.value = {};
    let d = [], g = s.shape;
    for (let $ of s.keys) {
      let v = g[$], k = v._zod.optin === "optional", D = v._zod.optout === "optional", T = v._zod.run({ value: l[$], issues: [] }, u);
      T instanceof Promise ? d.push(T.then(($e) => Br($e, c, $, l, k, D))) : Br(T, c, $, l, k, D);
    }
    return i ? Xl(d, l, c, u, o.value, e) : d.length ? Promise.all(d).then(() => c) : c;
  };
}), dg = /* @__PURE__ */ f("$ZodObjectJIT", (e, t) => {
  q.init(e, t);
  let n = e._zod.parse, o = at(() => Gl(t)), r = /* @__PURE__ */ a(($) => {
    let v = new Ft(["shape", "payload", "ctx"]), k = o.value, D = /* @__PURE__ */ a((W) => {
      let O = Or(W);
      return `shape[${O}]._zod.run({ value: input[${O}], issues: [] }, ctx)`;
    }, "parseStr");
    v.write("const input = payload.value;");
    let T = /* @__PURE__ */ Object.create(null), $e = 0;
    for (let W of k.keys)
      T[W] = `key_${$e++}`;
    v.write("const newResult = {};");
    for (let W of k.keys) {
      let O = T[W], F = Or(W), I = $[W], j = I?._zod?.optin === "optional", B = I?._zod?.optout === "optional";
      v.write(`const ${O} = ${D(W)};`), j && B ? v.write(`
        if (${O}.issues.length) {
          if (${F} in input) {
            payload.issues = payload.issues.concat(${O}.issues.map(iss => ({
              ...iss,
              path: iss.path ? [${F}, ...iss.path] : [${F}]
            })));
          }
        }
        
        if (${O}.value === undefined) {
          if (${F} in input) {
            newResult[${F}] = undefined;
          }
        } else {
          newResult[${F}] = ${O}.value;
        }
        
      `) : j ? v.write(`
        if (${O}.issues.length) {
          payload.issues = payload.issues.concat(${O}.issues.map(iss => ({
            ...iss,
            path: iss.path ? [${F}, ...iss.path] : [${F}]
          })));
        }
        
        if (${O}.value === undefined) {
          if (${F} in input) {
            newResult[${F}] = undefined;
          }
        } else {
          newResult[${F}] = ${O}.value;
        }
        
      `) : v.write(`
        const ${O}_present = ${F} in input;
        if (${O}.issues.length) {
          payload.issues = payload.issues.concat(${O}.issues.map(iss => ({
            ...iss,
            path: iss.path ? [${F}, ...iss.path] : [${F}]
          })));
        }
        if (!${O}_present && !${O}.issues.length) {
          payload.issues.push({
            code: "invalid_type",
            expected: "nonoptional",
            input: undefined,
            path: [${F}]
          });
        }

        if (${O}_present) {
          if (${O}.value === undefined) {
            newResult[${F}] = undefined;
          } else {
            newResult[${F}] = ${O}.value;
          }
        }

      `);
    }
    v.write("payload.value = newResult;"), v.write("return payload;");
    let ve = v.compile();
    return (W, O) => ve($, W, O);
  }, "generateFastpass"), i, s = qe, c = !Ve.jitless, l = c && li.value, d = t.catchall, g;
  e._zod.parse = ($, v) => {
    g ?? (g = o.value);
    let k = $.value;
    return s(k) ? c && l && v?.async === !1 && v.jitless !== !0 ? (i || (i = r(t.shape)), $ = i($, v), d ? Xl([], k, $, v, g, e) : $) : n($, v) : ($.issues.push({
      expected: "object",
      code: "invalid_type",
      input: k,
      inst: e
    }), $);
  };
});
function El(e, t, n, o) {
  for (let i of e)
    if (i.issues.length === 0)
      return t.value = i.value, t;
  let r = e.filter((i) => !je(i));
  return r.length === 1 ? (t.value = r[0].value, r[0]) : (t.issues.push({
    code: "invalid_union",
    input: t.value,
    inst: n,
    errors: e.map((i) => i.issues.map((s) => Q(s, o, X())))
  }), t);
}
a(El, "handleUnionResults");
var ee = /* @__PURE__ */ f("$ZodUnion", (e, t) => {
  _.init(e, t), S(e._zod, "optin", () => t.options.some((o) => o._zod.optin === "optional") ? "optional" : void 0), S(e._zod, "optout", () => t.options.some((o) => o._zod.optout === "optional") ? "optional" : void 0), S(e._zod, "values", () => {
    if (t.options.every((o) => o._zod.values))
      return new Set(t.options.flatMap((o) => Array.from(o._zod.values)));
  }), S(e._zod, "pattern", () => {
    if (t.options.every((o) => o._zod.pattern)) {
      let o = t.options.map((r) => r._zod.pattern);
      return new RegExp(`^(${o.map((r) => Et(r.source)).join("|")})$`);
    }
  });
  let n = t.options.length === 1 ? t.options[0]._zod.run : null;
  e._zod.parse = (o, r) => {
    if (n)
      return n(o, r);
    let i = !1, s = [];
    for (let c of t.options) {
      let u = c._zod.run({
        value: o.value,
        issues: []
      }, r);
      if (u instanceof Promise)
        s.push(u), i = !0;
      else {
        if (u.issues.length === 0)
          return u;
        s.push(u);
      }
    }
    return i ? Promise.all(s).then((c) => El(c, o, e, r)) : El(s, o, e, r);
  };
});
function Nl(e, t, n, o) {
  let r = e.filter((i) => i.issues.length === 0);
  return r.length === 1 ? (t.value = r[0].value, t) : (r.length === 0 ? t.issues.push({
    code: "invalid_union",
    input: t.value,
    inst: n,
    errors: e.map((i) => i.issues.map((s) => Q(s, o, X())))
  }) : t.issues.push({
    code: "invalid_union",
    input: t.value,
    inst: n,
    errors: [],
    inclusive: !1
  }), t);
}
a(Nl, "handleExclusiveUnionResults");
var ua = /* @__PURE__ */ f("$ZodXor", (e, t) => {
  ee.init(e, t), t.inclusive = !1;
  let n = t.options.length === 1 ? t.options[0]._zod.run : null;
  e._zod.parse = (o, r) => {
    if (n)
      return n(o, r);
    let i = !1, s = [];
    for (let c of t.options) {
      let u = c._zod.run({
        value: o.value,
        issues: []
      }, r);
      u instanceof Promise ? (s.push(u), i = !0) : s.push(u);
    }
    return i ? Promise.all(s).then((c) => Nl(c, o, e, r)) : Nl(s, o, e, r);
  };
}), Pe = /* @__PURE__ */ f("$ZodDiscriminatedUnion", (e, t) => {
  t.inclusive = !1, ee.init(e, t);
  let n = e._zod.parse;
  S(e._zod, "propValues", () => {
    let r = {};
    for (let i of t.options) {
      let s = i._zod.propValues;
      if (!s || Object.keys(s).length === 0)
        throw new Error(`Invalid discriminated union option at index "${t.options.indexOf(i)}"`);
      for (let [c, u] of Object.entries(s)) {
        r[c] || (r[c] = /* @__PURE__ */ new Set());
        for (let l of u)
          r[c].add(l);
      }
    }
    return r;
  });
  let o = at(() => {
    let r = t.options, i = /* @__PURE__ */ new Map();
    for (let s of r) {
      let c = s._zod.propValues?.[t.discriminator];
      if (!c || c.size === 0)
        throw new Error(`Invalid discriminated union option at index "${t.options.indexOf(s)}"`);
      for (let u of c) {
        if (i.has(u))
          throw new Error(`Duplicate discriminator value "${String(u)}"`);
        i.set(u, s);
      }
    }
    return i;
  });
  e._zod.parse = (r, i) => {
    let s = r.value;
    if (!qe(s))
      return r.issues.push({
        code: "invalid_type",
        expected: "object",
        input: s,
        inst: e
      }), r;
    let c = o.value.get(s?.[t.discriminator]);
    return c ? c._zod.run(r, i) : t.unionFallback || i.direction === "backward" ? n(r, i) : (r.issues.push({
      code: "invalid_union",
      errors: [],
      note: "No matching discriminator",
      discriminator: t.discriminator,
      options: Array.from(o.value.keys()),
      input: s,
      path: [t.discriminator],
      inst: e
    }), r);
  };
}), la = /* @__PURE__ */ f("$ZodIntersection", (e, t) => {
  _.init(e, t), e._zod.parse = (n, o) => {
    let r = n.value, i = t.left._zod.run({ value: r, issues: [] }, o), s = t.right._zod.run({ value: r, issues: [] }, o);
    return i instanceof Promise || s instanceof Promise ? Promise.all([i, s]).then(([u, l]) => Zl(n, u, l)) : Zl(n, i, s);
  };
});
function So(e, t) {
  if (e === t)
    return { valid: !0, data: e };
  if (e instanceof Date && t instanceof Date && +e == +t)
    return { valid: !0, data: e };
  if (Se(e) && Se(t)) {
    let n = Object.keys(t), o = Object.keys(e).filter((i) => n.indexOf(i) !== -1), r = { ...e, ...t };
    for (let i of o) {
      let s = So(e[i], t[i]);
      if (!s.valid)
        return {
          valid: !1,
          mergeErrorPath: [i, ...s.mergeErrorPath]
        };
      r[i] = s.data;
    }
    return { valid: !0, data: r };
  }
  if (Array.isArray(e) && Array.isArray(t)) {
    if (e.length !== t.length)
      return { valid: !1, mergeErrorPath: [] };
    let n = [];
    for (let o = 0; o < e.length; o++) {
      let r = e[o], i = t[o], s = So(r, i);
      if (!s.valid)
        return {
          valid: !1,
          mergeErrorPath: [o, ...s.mergeErrorPath]
        };
      n.push(s.data);
    }
    return { valid: !0, data: n };
  }
  return { valid: !1, mergeErrorPath: [] };
}
a(So, "mergeValues");
function Zl(e, t, n) {
  let o = /* @__PURE__ */ new Map(), r;
  for (let c of t.issues)
    if (c.code === "unrecognized_keys") {
      r ?? (r = c);
      for (let u of c.keys)
        o.has(u) || o.set(u, {}), o.get(u).l = !0;
    } else
      e.issues.push(c);
  for (let c of n.issues)
    if (c.code === "unrecognized_keys")
      for (let u of c.keys)
        o.has(u) || o.set(u, {}), o.get(u).r = !0;
    else
      e.issues.push(c);
  let i = [...o].filter(([, c]) => c.l && c.r).map(([c]) => c);
  if (i.length && r && e.issues.push({ ...r, keys: i }), je(e))
    return e;
  let s = So(t.value, n.value);
  if (!s.valid)
    throw new Error(`Unmergable intersection. Error path: ${JSON.stringify(s.mergeErrorPath)}`);
  return e.value = s.data, e;
}
a(Zl, "handleIntersectionResults");
var Ue = /* @__PURE__ */ f("$ZodTuple", (e, t) => {
  _.init(e, t);
  let n = t.items;
  e._zod.parse = (o, r) => {
    let i = o.value;
    if (!Array.isArray(i))
      return o.issues.push({
        input: i,
        inst: e,
        expected: "tuple",
        code: "invalid_type"
      }), o;
    o.value = [];
    let s = [], c = Al(n, "optin"), u = Al(n, "optout");
    if (!t.rest) {
      if (i.length < c)
        return o.issues.push({
          code: "too_small",
          minimum: c,
          inclusive: !0,
          input: i,
          inst: e,
          origin: "array"
        }), o;
      i.length > n.length && o.issues.push({
        code: "too_big",
        maximum: n.length,
        inclusive: !0,
        input: i,
        inst: e,
        origin: "array"
      });
    }
    let l = new Array(n.length);
    for (let d = 0; d < n.length; d++) {
      let g = n[d]._zod.run({ value: i[d], issues: [] }, r);
      g instanceof Promise ? s.push(g.then(($) => {
        l[d] = $;
      })) : l[d] = g;
    }
    if (t.rest) {
      let d = n.length - 1, g = i.slice(n.length);
      for (let $ of g) {
        d++;
        let v = t.rest._zod.run({ value: $, issues: [] }, r);
        v instanceof Promise ? s.push(v.then((k) => Cl(k, o, d))) : Cl(v, o, d);
      }
    }
    return s.length ? Promise.all(s).then(() => Rl(l, o, n, i, u)) : Rl(l, o, n, i, u);
  };
});
function Al(e, t) {
  for (let n = e.length - 1; n >= 0; n--)
    if (e[n]._zod[t] !== "optional")
      return n + 1;
  return 0;
}
a(Al, "getTupleOptStart");
function Cl(e, t, n) {
  e.issues.length && t.issues.push(...re(n, e.issues)), t.value[n] = e.value;
}
a(Cl, "handleTupleResult");
function Rl(e, t, n, o, r) {
  for (let i = 0; i < n.length; i++) {
    let s = e[i], c = i < o.length;
    if (s.issues.length) {
      if (!c && i >= r) {
        t.value.length = i;
        break;
      }
      t.issues.push(...re(i, s.issues));
    }
    t.value[i] = s.value;
  }
  for (let i = t.value.length - 1; i >= o.length && (n[i]._zod.optout === "optional" && t.value[i] === void 0); i--)
    t.value.length = i;
  return t;
}
a(Rl, "handleTupleResults");
var Ke = /* @__PURE__ */ f("$ZodRecord", (e, t) => {
  _.init(e, t), e._zod.parse = (n, o) => {
    let r = n.value;
    if (!Se(r))
      return n.issues.push({
        expected: "record",
        code: "invalid_type",
        input: r,
        inst: e
      }), n;
    let i = [], s = t.keyType._zod.values;
    if (s) {
      n.value = {};
      let c = /* @__PURE__ */ new Set();
      for (let l of s)
        if (typeof l == "string" || typeof l == "number" || typeof l == "symbol") {
          c.add(typeof l == "number" ? l.toString() : l);
          let d = t.keyType._zod.run({ value: l, issues: [] }, o);
          if (d instanceof Promise)
            throw new Error("Async schemas not supported in object keys currently");
          if (d.issues.length) {
            n.issues.push({
              code: "invalid_key",
              origin: "record",
              issues: d.issues.map((v) => Q(v, o, X())),
              input: l,
              path: [l],
              inst: e
            });
            continue;
          }
          let g = d.value, $ = t.valueType._zod.run({ value: r[l], issues: [] }, o);
          $ instanceof Promise ? i.push($.then((v) => {
            v.issues.length && n.issues.push(...re(l, v.issues)), n.value[g] = v.value;
          })) : ($.issues.length && n.issues.push(...re(l, $.issues)), n.value[g] = $.value);
        }
      let u;
      for (let l in r)
        c.has(l) || (u = u ?? [], u.push(l));
      u && u.length > 0 && n.issues.push({
        code: "unrecognized_keys",
        input: r,
        inst: e,
        keys: u
      });
    } else {
      n.value = {};
      for (let c of Reflect.ownKeys(r)) {
        if (c === "__proto__" || !Object.prototype.propertyIsEnumerable.call(r, c))
          continue;
        let u = t.keyType._zod.run({ value: c, issues: [] }, o);
        if (u instanceof Promise)
          throw new Error("Async schemas not supported in object keys currently");
        if (typeof c == "string" && Ar.test(c) && u.issues.length) {
          let g = t.keyType._zod.run({ value: Number(c), issues: [] }, o);
          if (g instanceof Promise)
            throw new Error("Async schemas not supported in object keys currently");
          g.issues.length === 0 && (u = g);
        }
        if (u.issues.length) {
          t.mode === "loose" ? n.value[c] = r[c] : n.issues.push({
            code: "invalid_key",
            origin: "record",
            issues: u.issues.map((g) => Q(g, o, X())),
            input: c,
            path: [c],
            inst: e
          });
          continue;
        }
        let d = t.valueType._zod.run({ value: r[c], issues: [] }, o);
        d instanceof Promise ? i.push(d.then((g) => {
          g.issues.length && n.issues.push(...re(c, g.issues)), n.value[u.value] = g.value;
        })) : (d.issues.length && n.issues.push(...re(c, d.issues)), n.value[u.value] = d.value);
      }
    }
    return i.length ? Promise.all(i).then(() => n) : n;
  };
}), da = /* @__PURE__ */ f("$ZodMap", (e, t) => {
  _.init(e, t), e._zod.parse = (n, o) => {
    let r = n.value;
    if (!(r instanceof Map))
      return n.issues.push({
        expected: "map",
        code: "invalid_type",
        input: r,
        inst: e
      }), n;
    let i = [];
    n.value = /* @__PURE__ */ new Map();
    for (let [s, c] of r) {
      let u = t.keyType._zod.run({ value: s, issues: [] }, o), l = t.valueType._zod.run({ value: c, issues: [] }, o);
      u instanceof Promise || l instanceof Promise ? i.push(Promise.all([u, l]).then(([d, g]) => {
        Fl(d, g, n, s, r, e, o);
      })) : Fl(u, l, n, s, r, e, o);
    }
    return i.length ? Promise.all(i).then(() => n) : n;
  };
});
function Fl(e, t, n, o, r, i, s) {
  e.issues.length && (Nt.has(typeof o) ? n.issues.push(...re(o, e.issues)) : n.issues.push({
    code: "invalid_key",
    origin: "map",
    input: r,
    inst: i,
    issues: e.issues.map((c) => Q(c, s, X()))
  })), t.issues.length && (Nt.has(typeof o) ? n.issues.push(...re(o, t.issues)) : n.issues.push({
    origin: "map",
    code: "invalid_element",
    input: r,
    inst: i,
    key: o,
    issues: t.issues.map((c) => Q(c, s, X()))
  })), n.value.set(e.value, t.value);
}
a(Fl, "handleMapResult");
var fa = /* @__PURE__ */ f("$ZodSet", (e, t) => {
  _.init(e, t), e._zod.parse = (n, o) => {
    let r = n.value;
    if (!(r instanceof Set))
      return n.issues.push({
        input: r,
        inst: e,
        expected: "set",
        code: "invalid_type"
      }), n;
    let i = [];
    n.value = /* @__PURE__ */ new Set();
    for (let s of r) {
      let c = t.valueType._zod.run({ value: s, issues: [] }, o);
      c instanceof Promise ? i.push(c.then((u) => Ml(u, n))) : Ml(c, n);
    }
    return i.length ? Promise.all(i).then(() => n) : n;
  };
});
function Ml(e, t) {
  e.issues.length && t.issues.push(...e.issues), t.value.add(e.value);
}
a(Ml, "handleSetResult");
var ft = /* @__PURE__ */ f("$ZodEnum", (e, t) => {
  _.init(e, t);
  let n = Dt(t.entries), o = new Set(n);
  e._zod.values = o, e._zod.pattern = new RegExp(`^(${n.filter((r) => Nt.has(typeof r)).map((r) => typeof r == "string" ? le(r) : r.toString()).join("|")})$`), e._zod.parse = (r, i) => {
    let s = r.value;
    return o.has(s) || r.issues.push({
      code: "invalid_value",
      values: n,
      input: s,
      inst: e
    }), r;
  };
}), pt = /* @__PURE__ */ f("$ZodLiteral", (e, t) => {
  if (_.init(e, t), t.values.length === 0)
    throw new Error("Cannot create literal schema with no valid values");
  let n = new Set(t.values);
  e._zod.values = n, e._zod.pattern = new RegExp(`^(${t.values.map((o) => typeof o == "string" ? le(o) : o ? le(o.toString()) : String(o)).join("|")})$`), e._zod.parse = (o, r) => {
    let i = o.value;
    return n.has(i) || o.issues.push({
      code: "invalid_value",
      values: t.values,
      input: i,
      inst: e
    }), o;
  };
}), pa = /* @__PURE__ */ f("$ZodFile", (e, t) => {
  _.init(e, t), e._zod.parse = (n, o) => {
    let r = n.value;
    return r instanceof File || n.issues.push({
      expected: "file",
      code: "invalid_type",
      input: r,
      inst: e
    }), n;
  };
}), ma = /* @__PURE__ */ f("$ZodTransform", (e, t) => {
  _.init(e, t), e._zod.optin = "optional", e._zod.parse = (n, o) => {
    if (o.direction === "backward")
      throw new ot(e.constructor.name);
    let r = t.transform(n.value, n);
    if (o.async)
      return (r instanceof Promise ? r : Promise.resolve(r)).then((s) => (n.value = s, n.fallback = !0, n));
    if (r instanceof Promise)
      throw new pe();
    return n.value = r, n.fallback = !0, n;
  };
});
function Ll(e, t) {
  return t === void 0 && (e.issues.length || e.fallback) ? { issues: [], value: void 0 } : e;
}
a(Ll, "handleOptionalResult");
var L = /* @__PURE__ */ f("$ZodOptional", (e, t) => {
  _.init(e, t), e._zod.optin = "optional", e._zod.optout = "optional", S(e._zod, "values", () => t.innerType._zod.values ? /* @__PURE__ */ new Set([...t.innerType._zod.values, void 0]) : void 0), S(e._zod, "pattern", () => {
    let n = t.innerType._zod.pattern;
    return n ? new RegExp(`^(${Et(n.source)})?$`) : void 0;
  }), e._zod.parse = (n, o) => {
    if (t.innerType._zod.optin === "optional") {
      let r = n.value, i = t.innerType._zod.run(n, o);
      return i instanceof Promise ? i.then((s) => Ll(s, r)) : Ll(i, r);
    }
    return n.value === void 0 ? n : t.innerType._zod.run(n, o);
  };
}), ga = /* @__PURE__ */ f("$ZodExactOptional", (e, t) => {
  L.init(e, t), S(e._zod, "values", () => t.innerType._zod.values), S(e._zod, "pattern", () => t.innerType._zod.pattern), e._zod.parse = (n, o) => t.innerType._zod.run(n, o);
}), de = /* @__PURE__ */ f("$ZodNullable", (e, t) => {
  _.init(e, t), S(e._zod, "optin", () => t.innerType._zod.optin), S(e._zod, "optout", () => t.innerType._zod.optout), S(e._zod, "pattern", () => {
    let n = t.innerType._zod.pattern;
    return n ? new RegExp(`^(${Et(n.source)}|null)$`) : void 0;
  }), S(e._zod, "values", () => t.innerType._zod.values ? /* @__PURE__ */ new Set([...t.innerType._zod.values, null]) : void 0), e._zod.parse = (n, o) => n.value === null ? n : t.innerType._zod.run(n, o);
}), se = /* @__PURE__ */ f("$ZodDefault", (e, t) => {
  _.init(e, t), e._zod.optin = "optional", S(e._zod, "values", () => t.innerType._zod.values), e._zod.parse = (n, o) => {
    if (o.direction === "backward")
      return t.innerType._zod.run(n, o);
    if (n.value === void 0)
      return n.value = t.defaultValue, n;
    let r = t.innerType._zod.run(n, o);
    return r instanceof Promise ? r.then((i) => Bl(i, t)) : Bl(r, t);
  };
});
function Bl(e, t) {
  return e.value === void 0 && (e.value = t.defaultValue), e;
}
a(Bl, "handleDefaultResult");
var ha = /* @__PURE__ */ f("$ZodPrefault", (e, t) => {
  _.init(e, t), e._zod.optin = "optional", S(e._zod, "values", () => t.innerType._zod.values), e._zod.parse = (n, o) => (o.direction === "backward" || n.value === void 0 && (n.value = t.defaultValue), t.innerType._zod.run(n, o));
}), va = /* @__PURE__ */ f("$ZodNonOptional", (e, t) => {
  _.init(e, t), S(e._zod, "values", () => {
    let n = t.innerType._zod.values;
    return n ? new Set([...n].filter((o) => o !== void 0)) : void 0;
  }), e._zod.parse = (n, o) => {
    let r = t.innerType._zod.run(n, o);
    return r instanceof Promise ? r.then((i) => Vl(i, e)) : Vl(r, e);
  };
});
function Vl(e, t) {
  return !e.issues.length && e.value === void 0 && e.issues.push({
    code: "invalid_type",
    expected: "nonoptional",
    input: e.value,
    inst: t
  }), e;
}
a(Vl, "handleNonOptionalResult");
var ya = /* @__PURE__ */ f("$ZodSuccess", (e, t) => {
  _.init(e, t), e._zod.parse = (n, o) => {
    if (o.direction === "backward")
      throw new ot("ZodSuccess");
    let r = t.innerType._zod.run(n, o);
    return r instanceof Promise ? r.then((i) => (n.value = i.issues.length === 0, n)) : (n.value = r.issues.length === 0, n);
  };
}), ba = /* @__PURE__ */ f("$ZodCatch", (e, t) => {
  _.init(e, t), e._zod.optin = "optional", S(e._zod, "optout", () => t.innerType._zod.optout), S(e._zod, "values", () => t.innerType._zod.values), e._zod.parse = (n, o) => {
    if (o.direction === "backward")
      return t.innerType._zod.run(n, o);
    let r = t.innerType._zod.run(n, o);
    return r instanceof Promise ? r.then((i) => (n.value = i.value, i.issues.length && (n.value = t.catchValue({
      ...n,
      error: {
        issues: i.issues.map((s) => Q(s, o, X()))
      },
      input: n.value
    }), n.issues = [], n.fallback = !0), n)) : (n.value = r.value, r.issues.length && (n.value = t.catchValue({
      ...n,
      error: {
        issues: r.issues.map((i) => Q(i, o, X()))
      },
      input: n.value
    }), n.issues = [], n.fallback = !0), n);
  };
}), $a = /* @__PURE__ */ f("$ZodNaN", (e, t) => {
  _.init(e, t), e._zod.parse = (n, o) => ((typeof n.value != "number" || !Number.isNaN(n.value)) && n.issues.push({
    input: n.value,
    inst: e,
    expected: "nan",
    code: "invalid_type"
  }), n);
}), Jr = /* @__PURE__ */ f("$ZodPipe", (e, t) => {
  _.init(e, t), S(e._zod, "values", () => t.in._zod.values), S(e._zod, "optin", () => t.in._zod.optin), S(e._zod, "optout", () => t.out._zod.optout), S(e._zod, "propValues", () => t.in._zod.propValues), e._zod.parse = (n, o) => {
    if (o.direction === "backward") {
      let i = t.out._zod.run(n, o);
      return i instanceof Promise ? i.then((s) => Fr(s, t.in, o)) : Fr(i, t.in, o);
    }
    let r = t.in._zod.run(n, o);
    return r instanceof Promise ? r.then((i) => Fr(i, t.out, o)) : Fr(r, t.out, o);
  };
});
function Fr(e, t, n) {
  return e.issues.length ? (e.aborted = !0, e) : t._zod.run({ value: e.value, issues: e.issues, fallback: e.fallback }, n);
}
a(Fr, "handlePipeResult");
var ge = /* @__PURE__ */ f("$ZodCodec", (e, t) => {
  _.init(e, t), S(e._zod, "values", () => t.in._zod.values), S(e._zod, "optin", () => t.in._zod.optin), S(e._zod, "optout", () => t.out._zod.optout), S(e._zod, "propValues", () => t.in._zod.propValues), e._zod.parse = (n, o) => {
    if ((o.direction || "forward") === "forward") {
      let i = t.in._zod.run(n, o);
      return i instanceof Promise ? i.then((s) => Mr(s, t, o)) : Mr(i, t, o);
    } else {
      let i = t.out._zod.run(n, o);
      return i instanceof Promise ? i.then((s) => Mr(s, t, o)) : Mr(i, t, o);
    }
  };
});
function Mr(e, t, n) {
  if (e.issues.length)
    return e.aborted = !0, e;
  if ((n.direction || "forward") === "forward") {
    let r = t.transform(e.value, e);
    return r instanceof Promise ? r.then((i) => Lr(e, i, t.out, n)) : Lr(e, r, t.out, n);
  } else {
    let r = t.reverseTransform(e.value, e);
    return r instanceof Promise ? r.then((i) => Lr(e, i, t.in, n)) : Lr(e, r, t.in, n);
  }
}
a(Mr, "handleCodecAResult");
function Lr(e, t, n, o) {
  return e.issues.length ? (e.aborted = !0, e) : n._zod.run({ value: t, issues: e.issues }, o);
}
a(Lr, "handleCodecTxResult");
var fg = /* @__PURE__ */ f("$ZodPreprocess", (e, t) => {
  Jr.init(e, t);
}), xa = /* @__PURE__ */ f("$ZodReadonly", (e, t) => {
  _.init(e, t), S(e._zod, "propValues", () => t.innerType._zod.propValues), S(e._zod, "values", () => t.innerType._zod.values), S(e._zod, "optin", () => t.innerType?._zod?.optin), S(e._zod, "optout", () => t.innerType?._zod?.optout), e._zod.parse = (n, o) => {
    if (o.direction === "backward")
      return t.innerType._zod.run(n, o);
    let r = t.innerType._zod.run(n, o);
    return r instanceof Promise ? r.then(ql) : ql(r);
  };
});
function ql(e) {
  return e.value = Object.freeze(e.value), e;
}
a(ql, "handleReadonlyResult");
var _a = /* @__PURE__ */ f("$ZodTemplateLiteral", (e, t) => {
  _.init(e, t);
  let n = [];
  for (let o of t.parts)
    if (typeof o == "object" && o !== null) {
      if (!o._zod.pattern)
        throw new Error(`Invalid template literal part, no pattern found: ${[...o._zod.traits].shift()}`);
      let r = o._zod.pattern instanceof RegExp ? o._zod.pattern.source : o._zod.pattern;
      if (!r)
        throw new Error(`Invalid template literal part: ${o._zod.traits}`);
      let i = r.startsWith("^") ? 1 : 0, s = r.endsWith("$") ? r.length - 1 : r.length;
      n.push(r.slice(i, s));
    } else if (o === null || di.has(typeof o))
      n.push(le(`${o}`));
    else
      throw new Error(`Invalid template literal part: ${o}`);
  e._zod.pattern = new RegExp(`^${n.join("")}$`), e._zod.parse = (o, r) => typeof o.value != "string" ? (o.issues.push({
    input: o.value,
    inst: e,
    expected: "string",
    code: "invalid_type"
  }), o) : (e._zod.pattern.lastIndex = 0, e._zod.pattern.test(o.value) || o.issues.push({
    input: o.value,
    inst: e,
    code: "invalid_format",
    format: t.format ?? "template_literal",
    pattern: e._zod.pattern.source
  }), o);
}), wa = /* @__PURE__ */ f("$ZodFunction", (e, t) => (_.init(e, t), e._def = t, e._zod.def = t, e.implement = (n) => {
  if (typeof n != "function")
    throw new Error("implement() must be called with a function");
  return function(...o) {
    let r = e._def.input ? ie(e._def.input, o) : o, i = Reflect.apply(n, this, r);
    return e._def.output ? ie(e._def.output, i) : i;
  };
}, e.implementAsync = (n) => {
  if (typeof n != "function")
    throw new Error("implementAsync() must be called with a function");
  return async function(...o) {
    let r = e._def.input ? await Oe(e._def.input, o) : o, i = await Reflect.apply(n, this, r);
    return e._def.output ? await Oe(e._def.output, i) : i;
  };
}, e._zod.parse = (n, o) => typeof n.value != "function" ? (n.issues.push({
  code: "invalid_type",
  expected: "function",
  input: n.value,
  inst: e
}), n) : (e._def.output && e._def.output._zod.def.type === "promise" ? n.value = e.implementAsync(n.value) : n.value = e.implement(n.value), n), e.input = (...n) => {
  let o = e.constructor;
  return Array.isArray(n[0]) ? new o({
    type: "function",
    input: new Ue({
      type: "tuple",
      items: n[0],
      rest: n[1]
    }),
    output: e._def.output
  }) : new o({
    type: "function",
    input: n[0],
    output: e._def.output
  });
}, e.output = (n) => {
  let o = e.constructor;
  return new o({
    type: "function",
    input: e._def.input,
    output: n
  });
}, e)), ka = /* @__PURE__ */ f("$ZodPromise", (e, t) => {
  _.init(e, t), e._zod.parse = (n, o) => Promise.resolve(n.value).then((r) => t.innerType._zod.run({ value: r, issues: [] }, o));
}), mt = /* @__PURE__ */ f("$ZodLazy", (e, t) => {
  _.init(e, t), S(e._zod, "innerType", () => {
    let n = t;
    return n._cachedInner || (n._cachedInner = t.getter()), n._cachedInner;
  }), S(e._zod, "pattern", () => e._zod.innerType?._zod?.pattern), S(e._zod, "propValues", () => e._zod.innerType?._zod?.propValues), S(e._zod, "optin", () => e._zod.innerType?._zod?.optin ?? void 0), S(e._zod, "optout", () => e._zod.innerType?._zod?.optout ?? void 0), e._zod.parse = (n, o) => e._zod.innerType._zod.run(n, o);
}), Lt = /* @__PURE__ */ f("$ZodCustom", (e, t) => {
  A.init(e, t), _.init(e, t), e._zod.parse = (n, o) => n, e._zod.check = (n) => {
    let o = n.value, r = t.fn(o);
    if (r instanceof Promise)
      return r.then((i) => Jl(i, n, o, e));
    Jl(r, n, o, e);
  };
});
function Jl(e, t, n, o) {
  if (!e) {
    let r = {
      code: "custom",
      input: n,
      inst: o,
      // incorporates params.error into issue reporting
      path: [...o._zod.def.path ?? []],
      // incorporates params.error into issue reporting
      continue: !o._zod.def.abort
      // params: inst._zod.def.params,
    };
    o._zod.def.params && (r.params = o._zod.def.params), t.issues.push(ct(r));
  }
}
a(Jl, "handleRefineResult");

// versions/4.4.3/node_modules/zod/v4/locales/index.js
var Jt = {};
Ce(Jt, {
  ar: () => Ia,
  az: () => za,
  be: () => Sa,
  bg: () => ja,
  ca: () => Oa,
  cs: () => Ta,
  da: () => Pa,
  de: () => Ua,
  el: () => Da,
  en: () => Ea,
  eo: () => Na,
  es: () => Za,
  fa: () => Aa,
  fi: () => Ca,
  fr: () => Ra,
  frCA: () => Fa,
  he: () => Ma,
  hr: () => La,
  hu: () => Ba,
  hy: () => Va,
  id: () => qa,
  is: () => Ja,
  it: () => Wa,
  ja: () => Ka,
  ka: () => Ga,
  kh: () => Xa,
  km: () => Bt,
  ko: () => Ha,
  lt: () => Qa,
  mk: () => Ya,
  ms: () => es,
  nl: () => ts,
  no: () => rs,
  ota: () => ns,
  pl: () => os,
  ps: () => is,
  pt: () => as,
  ro: () => ss,
  ru: () => cs,
  sl: () => us,
  sv: () => ls,
  ta: () => ds,
  th: () => fs,
  tr: () => ps,
  ua: () => ms,
  uk: () => qt,
  ur: () => gs,
  uz: () => hs,
  vi: () => vs,
  yo: () => $s,
  zhCN: () => ys,
  zhTW: () => bs
});

// versions/4.4.3/node_modules/zod/v4/locales/ar.js
var mg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "\u062D\u0631\u0641", verb: "\u0623\u0646 \u064A\u062D\u0648\u064A" },
    file: { unit: "\u0628\u0627\u064A\u062A", verb: "\u0623\u0646 \u064A\u062D\u0648\u064A" },
    array: { unit: "\u0639\u0646\u0635\u0631", verb: "\u0623\u0646 \u064A\u062D\u0648\u064A" },
    set: { unit: "\u0639\u0646\u0635\u0631", verb: "\u0623\u0646 \u064A\u062D\u0648\u064A" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "\u0645\u062F\u062E\u0644",
    email: "\u0628\u0631\u064A\u062F \u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A",
    url: "\u0631\u0627\u0628\u0637",
    emoji: "\u0625\u064A\u0645\u0648\u062C\u064A",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u062A\u0627\u0631\u064A\u062E \u0648\u0648\u0642\u062A \u0628\u0645\u0639\u064A\u0627\u0631 ISO",
    date: "\u062A\u0627\u0631\u064A\u062E \u0628\u0645\u0639\u064A\u0627\u0631 ISO",
    time: "\u0648\u0642\u062A \u0628\u0645\u0639\u064A\u0627\u0631 ISO",
    duration: "\u0645\u062F\u0629 \u0628\u0645\u0639\u064A\u0627\u0631 ISO",
    ipv4: "\u0639\u0646\u0648\u0627\u0646 IPv4",
    ipv6: "\u0639\u0646\u0648\u0627\u0646 IPv6",
    cidrv4: "\u0645\u062F\u0649 \u0639\u0646\u0627\u0648\u064A\u0646 \u0628\u0635\u064A\u063A\u0629 IPv4",
    cidrv6: "\u0645\u062F\u0649 \u0639\u0646\u0627\u0648\u064A\u0646 \u0628\u0635\u064A\u063A\u0629 IPv6",
    base64: "\u0646\u064E\u0635 \u0628\u062A\u0631\u0645\u064A\u0632 base64-encoded",
    base64url: "\u0646\u064E\u0635 \u0628\u062A\u0631\u0645\u064A\u0632 base64url-encoded",
    json_string: "\u0646\u064E\u0635 \u0639\u0644\u0649 \u0647\u064A\u0626\u0629 JSON",
    e164: "\u0631\u0642\u0645 \u0647\u0627\u062A\u0641 \u0628\u0645\u0639\u064A\u0627\u0631 E.164",
    jwt: "JWT",
    template_literal: "\u0645\u062F\u062E\u0644"
  }, o = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `\u0645\u062F\u062E\u0644\u0627\u062A \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644\u0629: \u064A\u0641\u062A\u0631\u0636 \u0625\u062F\u062E\u0627\u0644 instanceof ${r.expected}\u060C \u0648\u0644\u0643\u0646 \u062A\u0645 \u0625\u062F\u062E\u0627\u0644 ${c}` : `\u0645\u062F\u062E\u0644\u0627\u062A \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644\u0629: \u064A\u0641\u062A\u0631\u0636 \u0625\u062F\u062E\u0627\u0644 ${i}\u060C \u0648\u0644\u0643\u0646 \u062A\u0645 \u0625\u062F\u062E\u0627\u0644 ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u0645\u062F\u062E\u0644\u0627\u062A \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644\u0629: \u064A\u0641\u062A\u0631\u0636 \u0625\u062F\u062E\u0627\u0644 ${y(r.values[0])}` : `\u0627\u062E\u062A\u064A\u0627\u0631 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062A\u0648\u0642\u0639 \u0627\u0646\u062A\u0642\u0627\u0621 \u0623\u062D\u062F \u0647\u0630\u0647 \u0627\u0644\u062E\u064A\u0627\u0631\u0627\u062A: ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? ` \u0623\u0643\u0628\u0631 \u0645\u0646 \u0627\u0644\u0644\u0627\u0632\u0645: \u064A\u0641\u062A\u0631\u0636 \u0623\u0646 \u062A\u0643\u0648\u0646 ${r.origin ?? "\u0627\u0644\u0642\u064A\u0645\u0629"} ${i} ${r.maximum.toString()} ${s.unit ?? "\u0639\u0646\u0635\u0631"}` : `\u0623\u0643\u0628\u0631 \u0645\u0646 \u0627\u0644\u0644\u0627\u0632\u0645: \u064A\u0641\u062A\u0631\u0636 \u0623\u0646 \u062A\u0643\u0648\u0646 ${r.origin ?? "\u0627\u0644\u0642\u064A\u0645\u0629"} ${i} ${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `\u0623\u0635\u063A\u0631 \u0645\u0646 \u0627\u0644\u0644\u0627\u0632\u0645: \u064A\u0641\u062A\u0631\u0636 \u0644\u0640 ${r.origin} \u0623\u0646 \u064A\u0643\u0648\u0646 ${i} ${r.minimum.toString()} ${s.unit}` : `\u0623\u0635\u063A\u0631 \u0645\u0646 \u0627\u0644\u0644\u0627\u0632\u0645: \u064A\u0641\u062A\u0631\u0636 \u0644\u0640 ${r.origin} \u0623\u0646 \u064A\u0643\u0648\u0646 ${i} ${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u0646\u064E\u0635 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u0628\u062F\u0623 \u0628\u0640 "${r.prefix}"` : i.format === "ends_with" ? `\u0646\u064E\u0635 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u0646\u062A\u0647\u064A \u0628\u0640 "${i.suffix}"` : i.format === "includes" ? `\u0646\u064E\u0635 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u062A\u0636\u0645\u0651\u064E\u0646 "${i.includes}"` : i.format === "regex" ? `\u0646\u064E\u0635 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u0637\u0627\u0628\u0642 \u0627\u0644\u0646\u0645\u0637 ${i.pattern}` : `${n[i.format] ?? r.format} \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644`;
      }
      case "not_multiple_of":
        return `\u0631\u0642\u0645 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u0643\u0648\u0646 \u0645\u0646 \u0645\u0636\u0627\u0639\u0641\u0627\u062A ${r.divisor}`;
      case "unrecognized_keys":
        return `\u0645\u0639\u0631\u0641${r.keys.length > 1 ? "\u0627\u062A" : ""} \u063A\u0631\u064A\u0628${r.keys.length > 1 ? "\u0629" : ""}: ${p(r.keys, "\u060C ")}`;
      case "invalid_key":
        return `\u0645\u0639\u0631\u0641 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644 \u0641\u064A ${r.origin}`;
      case "invalid_union":
        return "\u0645\u062F\u062E\u0644 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644";
      case "invalid_element":
        return `\u0645\u062F\u062E\u0644 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644 \u0641\u064A ${r.origin}`;
      default:
        return "\u0645\u062F\u062E\u0644 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644";
    }
  };
}, "error");
function Ia() {
  return {
    localeError: mg()
  };
}
a(Ia, "default");

// versions/4.4.3/node_modules/zod/v4/locales/az.js
var gg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "simvol", verb: "olmal\u0131d\u0131r" },
    file: { unit: "bayt", verb: "olmal\u0131d\u0131r" },
    array: { unit: "element", verb: "olmal\u0131d\u0131r" },
    set: { unit: "element", verb: "olmal\u0131d\u0131r" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "input",
    email: "email address",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datetime",
    date: "ISO date",
    time: "ISO time",
    duration: "ISO duration",
    ipv4: "IPv4 address",
    ipv6: "IPv6 address",
    cidrv4: "IPv4 range",
    cidrv6: "IPv6 range",
    base64: "base64-encoded string",
    base64url: "base64url-encoded string",
    json_string: "JSON string",
    e164: "E.164 number",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Yanl\u0131\u015F d\u0259y\u0259r: g\xF6zl\u0259nil\u0259n instanceof ${r.expected}, daxil olan ${c}` : `Yanl\u0131\u015F d\u0259y\u0259r: g\xF6zl\u0259nil\u0259n ${i}, daxil olan ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Yanl\u0131\u015F d\u0259y\u0259r: g\xF6zl\u0259nil\u0259n ${y(r.values[0])}` : `Yanl\u0131\u015F se\xE7im: a\u015Fa\u011F\u0131dak\u0131lardan biri olmal\u0131d\u0131r: ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `\xC7ox b\xF6y\xFCk: g\xF6zl\u0259nil\u0259n ${r.origin ?? "d\u0259y\u0259r"} ${i}${r.maximum.toString()} ${s.unit ?? "element"}` : `\xC7ox b\xF6y\xFCk: g\xF6zl\u0259nil\u0259n ${r.origin ?? "d\u0259y\u0259r"} ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `\xC7ox ki\xE7ik: g\xF6zl\u0259nil\u0259n ${r.origin} ${i}${r.minimum.toString()} ${s.unit}` : `\xC7ox ki\xE7ik: g\xF6zl\u0259nil\u0259n ${r.origin} ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Yanl\u0131\u015F m\u0259tn: "${i.prefix}" il\u0259 ba\u015Flamal\u0131d\u0131r` : i.format === "ends_with" ? `Yanl\u0131\u015F m\u0259tn: "${i.suffix}" il\u0259 bitm\u0259lidir` : i.format === "includes" ? `Yanl\u0131\u015F m\u0259tn: "${i.includes}" daxil olmal\u0131d\u0131r` : i.format === "regex" ? `Yanl\u0131\u015F m\u0259tn: ${i.pattern} \u015Fablonuna uy\u011Fun olmal\u0131d\u0131r` : `Yanl\u0131\u015F ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Yanl\u0131\u015F \u0259d\u0259d: ${r.divisor} il\u0259 b\xF6l\xFCn\u0259 bil\u0259n olmal\u0131d\u0131r`;
      case "unrecognized_keys":
        return `Tan\u0131nmayan a\xE7ar${r.keys.length > 1 ? "lar" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `${r.origin} daxilind\u0259 yanl\u0131\u015F a\xE7ar`;
      case "invalid_union":
        return "Yanl\u0131\u015F d\u0259y\u0259r";
      case "invalid_element":
        return `${r.origin} daxilind\u0259 yanl\u0131\u015F d\u0259y\u0259r`;
      default:
        return "Yanl\u0131\u015F d\u0259y\u0259r";
    }
  };
}, "error");
function za() {
  return {
    localeError: gg()
  };
}
a(za, "default");

// versions/4.4.3/node_modules/zod/v4/locales/be.js
function Hl(e, t, n, o) {
  let r = Math.abs(e), i = r % 10, s = r % 100;
  return s >= 11 && s <= 19 ? o : i === 1 ? t : i >= 2 && i <= 4 ? n : o;
}
a(Hl, "getBelarusianPlural");
var hg = /* @__PURE__ */ a(() => {
  let e = {
    string: {
      unit: {
        one: "\u0441\u0456\u043C\u0432\u0430\u043B",
        few: "\u0441\u0456\u043C\u0432\u0430\u043B\u044B",
        many: "\u0441\u0456\u043C\u0432\u0430\u043B\u0430\u045E"
      },
      verb: "\u043C\u0435\u0446\u044C"
    },
    array: {
      unit: {
        one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
        few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u044B",
        many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430\u045E"
      },
      verb: "\u043C\u0435\u0446\u044C"
    },
    set: {
      unit: {
        one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
        few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u044B",
        many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430\u045E"
      },
      verb: "\u043C\u0435\u0446\u044C"
    },
    file: {
      unit: {
        one: "\u0431\u0430\u0439\u0442",
        few: "\u0431\u0430\u0439\u0442\u044B",
        many: "\u0431\u0430\u0439\u0442\u0430\u045E"
      },
      verb: "\u043C\u0435\u0446\u044C"
    }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "\u0443\u0432\u043E\u0434",
    email: "email \u0430\u0434\u0440\u0430\u0441",
    url: "URL",
    emoji: "\u044D\u043C\u043E\u0434\u0437\u0456",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0434\u0430\u0442\u0430 \u0456 \u0447\u0430\u0441",
    date: "ISO \u0434\u0430\u0442\u0430",
    time: "ISO \u0447\u0430\u0441",
    duration: "ISO \u043F\u0440\u0430\u0446\u044F\u0433\u043B\u0430\u0441\u0446\u044C",
    ipv4: "IPv4 \u0430\u0434\u0440\u0430\u0441",
    ipv6: "IPv6 \u0430\u0434\u0440\u0430\u0441",
    cidrv4: "IPv4 \u0434\u044B\u044F\u043F\u0430\u0437\u043E\u043D",
    cidrv6: "IPv6 \u0434\u044B\u044F\u043F\u0430\u0437\u043E\u043D",
    base64: "\u0440\u0430\u0434\u043E\u043A \u0443 \u0444\u0430\u0440\u043C\u0430\u0446\u0435 base64",
    base64url: "\u0440\u0430\u0434\u043E\u043A \u0443 \u0444\u0430\u0440\u043C\u0430\u0446\u0435 base64url",
    json_string: "JSON \u0440\u0430\u0434\u043E\u043A",
    e164: "\u043D\u0443\u043C\u0430\u0440 E.164",
    jwt: "JWT",
    template_literal: "\u0443\u0432\u043E\u0434"
  }, o = {
    nan: "NaN",
    number: "\u043B\u0456\u043A",
    array: "\u043C\u0430\u0441\u0456\u045E"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434: \u0447\u0430\u043A\u0430\u045E\u0441\u044F instanceof ${r.expected}, \u0430\u0442\u0440\u044B\u043C\u0430\u043D\u0430 ${c}` : `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434: \u0447\u0430\u043A\u0430\u045E\u0441\u044F ${i}, \u0430\u0442\u0440\u044B\u043C\u0430\u043D\u0430 ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F ${y(r.values[0])}` : `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0432\u0430\u0440\u044B\u044F\u043D\u0442: \u0447\u0430\u043A\u0430\u045E\u0441\u044F \u0430\u0434\u0437\u0456\u043D \u0437 ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        if (s) {
          let c = Number(r.maximum), u = Hl(c, s.unit.one, s.unit.few, s.unit.many);
          return `\u0417\u0430\u043D\u0430\u0434\u0442\u0430 \u0432\u044F\u043B\u0456\u043A\u0456: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F, \u0448\u0442\u043E ${r.origin ?? "\u0437\u043D\u0430\u0447\u044D\u043D\u043D\u0435"} \u043F\u0430\u0432\u0456\u043D\u043D\u0430 ${s.verb} ${i}${r.maximum.toString()} ${u}`;
        }
        return `\u0417\u0430\u043D\u0430\u0434\u0442\u0430 \u0432\u044F\u043B\u0456\u043A\u0456: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F, \u0448\u0442\u043E ${r.origin ?? "\u0437\u043D\u0430\u0447\u044D\u043D\u043D\u0435"} \u043F\u0430\u0432\u0456\u043D\u043D\u0430 \u0431\u044B\u0446\u044C ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        if (s) {
          let c = Number(r.minimum), u = Hl(c, s.unit.one, s.unit.few, s.unit.many);
          return `\u0417\u0430\u043D\u0430\u0434\u0442\u0430 \u043C\u0430\u043B\u044B: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F, \u0448\u0442\u043E ${r.origin} \u043F\u0430\u0432\u0456\u043D\u043D\u0430 ${s.verb} ${i}${r.minimum.toString()} ${u}`;
        }
        return `\u0417\u0430\u043D\u0430\u0434\u0442\u0430 \u043C\u0430\u043B\u044B: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F, \u0448\u0442\u043E ${r.origin} \u043F\u0430\u0432\u0456\u043D\u043D\u0430 \u0431\u044B\u0446\u044C ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0440\u0430\u0434\u043E\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u043F\u0430\u0447\u044B\u043D\u0430\u0446\u0446\u0430 \u0437 "${i.prefix}"` : i.format === "ends_with" ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0440\u0430\u0434\u043E\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u0437\u0430\u043A\u0430\u043D\u0447\u0432\u0430\u0446\u0446\u0430 \u043D\u0430 "${i.suffix}"` : i.format === "includes" ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0440\u0430\u0434\u043E\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u0437\u043C\u044F\u0448\u0447\u0430\u0446\u044C "${i.includes}"` : i.format === "regex" ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0440\u0430\u0434\u043E\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u0430\u0434\u043F\u0430\u0432\u044F\u0434\u0430\u0446\u044C \u0448\u0430\u0431\u043B\u043E\u043D\u0443 ${i.pattern}` : `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u043B\u0456\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u0431\u044B\u0446\u044C \u043A\u0440\u0430\u0442\u043D\u044B\u043C ${r.divisor}`;
      case "unrecognized_keys":
        return `\u041D\u0435\u0440\u0430\u0441\u043F\u0430\u0437\u043D\u0430\u043D\u044B ${r.keys.length > 1 ? "\u043A\u043B\u044E\u0447\u044B" : "\u043A\u043B\u044E\u0447"}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u043A\u043B\u044E\u0447 \u0443 ${r.origin}`;
      case "invalid_union":
        return "\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434";
      case "invalid_element":
        return `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u0430\u0435 \u0437\u043D\u0430\u0447\u044D\u043D\u043D\u0435 \u045E ${r.origin}`;
      default:
        return "\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434";
    }
  };
}, "error");
function Sa() {
  return {
    localeError: hg()
  };
}
a(Sa, "default");

// versions/4.4.3/node_modules/zod/v4/locales/bg.js
var vg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "\u0441\u0438\u043C\u0432\u043E\u043B\u0430", verb: "\u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430" },
    file: { unit: "\u0431\u0430\u0439\u0442\u0430", verb: "\u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430" },
    array: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0430", verb: "\u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430" },
    set: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0430", verb: "\u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "\u0432\u0445\u043E\u0434",
    email: "\u0438\u043C\u0435\u0439\u043B \u0430\u0434\u0440\u0435\u0441",
    url: "URL",
    emoji: "\u0435\u043C\u043E\u0434\u0436\u0438",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0432\u0440\u0435\u043C\u0435",
    date: "ISO \u0434\u0430\u0442\u0430",
    time: "ISO \u0432\u0440\u0435\u043C\u0435",
    duration: "ISO \u043F\u0440\u043E\u0434\u044A\u043B\u0436\u0438\u0442\u0435\u043B\u043D\u043E\u0441\u0442",
    ipv4: "IPv4 \u0430\u0434\u0440\u0435\u0441",
    ipv6: "IPv6 \u0430\u0434\u0440\u0435\u0441",
    cidrv4: "IPv4 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D",
    cidrv6: "IPv6 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D",
    base64: "base64-\u043A\u043E\u0434\u0438\u0440\u0430\u043D \u043D\u0438\u0437",
    base64url: "base64url-\u043A\u043E\u0434\u0438\u0440\u0430\u043D \u043D\u0438\u0437",
    json_string: "JSON \u043D\u0438\u0437",
    e164: "E.164 \u043D\u043E\u043C\u0435\u0440",
    jwt: "JWT",
    template_literal: "\u0432\u0445\u043E\u0434"
  }, o = {
    nan: "NaN",
    number: "\u0447\u0438\u0441\u043B\u043E",
    array: "\u043C\u0430\u0441\u0438\u0432"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434: \u043E\u0447\u0430\u043A\u0432\u0430\u043D instanceof ${r.expected}, \u043F\u043E\u043B\u0443\u0447\u0435\u043D ${c}` : `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434: \u043E\u0447\u0430\u043A\u0432\u0430\u043D ${i}, \u043F\u043E\u043B\u0443\u0447\u0435\u043D ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434: \u043E\u0447\u0430\u043A\u0432\u0430\u043D ${y(r.values[0])}` : `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u0430 \u043E\u043F\u0446\u0438\u044F: \u043E\u0447\u0430\u043A\u0432\u0430\u043D\u043E \u0435\u0434\u043D\u043E \u043E\u0442 ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `\u0422\u0432\u044A\u0440\u0434\u0435 \u0433\u043E\u043B\u044F\u043C\u043E: \u043E\u0447\u0430\u043A\u0432\u0430 \u0441\u0435 ${r.origin ?? "\u0441\u0442\u043E\u0439\u043D\u043E\u0441\u0442"} \u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430 ${i}${r.maximum.toString()} ${s.unit ?? "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0430"}` : `\u0422\u0432\u044A\u0440\u0434\u0435 \u0433\u043E\u043B\u044F\u043C\u043E: \u043E\u0447\u0430\u043A\u0432\u0430 \u0441\u0435 ${r.origin ?? "\u0441\u0442\u043E\u0439\u043D\u043E\u0441\u0442"} \u0434\u0430 \u0431\u044A\u0434\u0435 ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `\u0422\u0432\u044A\u0440\u0434\u0435 \u043C\u0430\u043B\u043A\u043E: \u043E\u0447\u0430\u043A\u0432\u0430 \u0441\u0435 ${r.origin} \u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430 ${i}${r.minimum.toString()} ${s.unit}` : `\u0422\u0432\u044A\u0440\u0434\u0435 \u043C\u0430\u043B\u043A\u043E: \u043E\u0447\u0430\u043A\u0432\u0430 \u0441\u0435 ${r.origin} \u0434\u0430 \u0431\u044A\u0434\u0435 ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        if (i.format === "starts_with")
          return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043D\u0438\u0437: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0437\u0430\u043F\u043E\u0447\u0432\u0430 \u0441 "${i.prefix}"`;
        if (i.format === "ends_with")
          return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043D\u0438\u0437: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0437\u0430\u0432\u044A\u0440\u0448\u0432\u0430 \u0441 "${i.suffix}"`;
        if (i.format === "includes")
          return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043D\u0438\u0437: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0432\u043A\u043B\u044E\u0447\u0432\u0430 "${i.includes}"`;
        if (i.format === "regex")
          return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043D\u0438\u0437: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0441\u044A\u0432\u043F\u0430\u0434\u0430 \u0441 ${i.pattern}`;
        let s = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D";
        return i.format === "emoji" && (s = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u043E"), i.format === "datetime" && (s = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u043E"), i.format === "date" && (s = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u0430"), i.format === "time" && (s = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u043E"), i.format === "duration" && (s = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u0430"), `${s} ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u043E \u0447\u0438\u0441\u043B\u043E: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0431\u044A\u0434\u0435 \u043A\u0440\u0430\u0442\u043D\u043E \u043D\u0430 ${r.divisor}`;
      case "unrecognized_keys":
        return `\u041D\u0435\u0440\u0430\u0437\u043F\u043E\u0437\u043D\u0430\u0442${r.keys.length > 1 ? "\u0438" : ""} \u043A\u043B\u044E\u0447${r.keys.length > 1 ? "\u043E\u0432\u0435" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043A\u043B\u044E\u0447 \u0432 ${r.origin}`;
      case "invalid_union":
        return "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434";
      case "invalid_element":
        return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u0430 \u0441\u0442\u043E\u0439\u043D\u043E\u0441\u0442 \u0432 ${r.origin}`;
      default:
        return "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434";
    }
  };
}, "error");
function ja() {
  return {
    localeError: vg()
  };
}
a(ja, "default");

// versions/4.4.3/node_modules/zod/v4/locales/ca.js
var yg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "car\xE0cters", verb: "contenir" },
    file: { unit: "bytes", verb: "contenir" },
    array: { unit: "elements", verb: "contenir" },
    set: { unit: "elements", verb: "contenir" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "entrada",
    email: "adre\xE7a electr\xF2nica",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "data i hora ISO",
    date: "data ISO",
    time: "hora ISO",
    duration: "durada ISO",
    ipv4: "adre\xE7a IPv4",
    ipv6: "adre\xE7a IPv6",
    cidrv4: "rang IPv4",
    cidrv6: "rang IPv6",
    base64: "cadena codificada en base64",
    base64url: "cadena codificada en base64url",
    json_string: "cadena JSON",
    e164: "n\xFAmero E.164",
    jwt: "JWT",
    template_literal: "entrada"
  }, o = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Tipus inv\xE0lid: s'esperava instanceof ${r.expected}, s'ha rebut ${c}` : `Tipus inv\xE0lid: s'esperava ${i}, s'ha rebut ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Valor inv\xE0lid: s'esperava ${y(r.values[0])}` : `Opci\xF3 inv\xE0lida: s'esperava una de ${p(r.values, " o ")}`;
      case "too_big": {
        let i = r.inclusive ? "com a m\xE0xim" : "menys de", s = t(r.origin);
        return s ? `Massa gran: s'esperava que ${r.origin ?? "el valor"} contingu\xE9s ${i} ${r.maximum.toString()} ${s.unit ?? "elements"}` : `Massa gran: s'esperava que ${r.origin ?? "el valor"} fos ${i} ${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? "com a m\xEDnim" : "m\xE9s de", s = t(r.origin);
        return s ? `Massa petit: s'esperava que ${r.origin} contingu\xE9s ${i} ${r.minimum.toString()} ${s.unit}` : `Massa petit: s'esperava que ${r.origin} fos ${i} ${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Format inv\xE0lid: ha de comen\xE7ar amb "${i.prefix}"` : i.format === "ends_with" ? `Format inv\xE0lid: ha d'acabar amb "${i.suffix}"` : i.format === "includes" ? `Format inv\xE0lid: ha d'incloure "${i.includes}"` : i.format === "regex" ? `Format inv\xE0lid: ha de coincidir amb el patr\xF3 ${i.pattern}` : `Format inv\xE0lid per a ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `N\xFAmero inv\xE0lid: ha de ser m\xFAltiple de ${r.divisor}`;
      case "unrecognized_keys":
        return `Clau${r.keys.length > 1 ? "s" : ""} no reconeguda${r.keys.length > 1 ? "s" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Clau inv\xE0lida a ${r.origin}`;
      case "invalid_union":
        return "Entrada inv\xE0lida";
      // Could also be "Tipus d'unió invàlid" but "Entrada invàlida" is more general
      case "invalid_element":
        return `Element inv\xE0lid a ${r.origin}`;
      default:
        return "Entrada inv\xE0lida";
    }
  };
}, "error");
function Oa() {
  return {
    localeError: yg()
  };
}
a(Oa, "default");

// versions/4.4.3/node_modules/zod/v4/locales/cs.js
var bg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "znak\u016F", verb: "m\xEDt" },
    file: { unit: "bajt\u016F", verb: "m\xEDt" },
    array: { unit: "prvk\u016F", verb: "m\xEDt" },
    set: { unit: "prvk\u016F", verb: "m\xEDt" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "regul\xE1rn\xED v\xFDraz",
    email: "e-mailov\xE1 adresa",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "datum a \u010Das ve form\xE1tu ISO",
    date: "datum ve form\xE1tu ISO",
    time: "\u010Das ve form\xE1tu ISO",
    duration: "doba trv\xE1n\xED ISO",
    ipv4: "IPv4 adresa",
    ipv6: "IPv6 adresa",
    cidrv4: "rozsah IPv4",
    cidrv6: "rozsah IPv6",
    base64: "\u0159et\u011Bzec zak\xF3dovan\xFD ve form\xE1tu base64",
    base64url: "\u0159et\u011Bzec zak\xF3dovan\xFD ve form\xE1tu base64url",
    json_string: "\u0159et\u011Bzec ve form\xE1tu JSON",
    e164: "\u010D\xEDslo E.164",
    jwt: "JWT",
    template_literal: "vstup"
  }, o = {
    nan: "NaN",
    number: "\u010D\xEDslo",
    string: "\u0159et\u011Bzec",
    function: "funkce",
    array: "pole"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Neplatn\xFD vstup: o\u010Dek\xE1v\xE1no instanceof ${r.expected}, obdr\u017Eeno ${c}` : `Neplatn\xFD vstup: o\u010Dek\xE1v\xE1no ${i}, obdr\u017Eeno ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Neplatn\xFD vstup: o\u010Dek\xE1v\xE1no ${y(r.values[0])}` : `Neplatn\xE1 mo\u017Enost: o\u010Dek\xE1v\xE1na jedna z hodnot ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `Hodnota je p\u0159\xEDli\u0161 velk\xE1: ${r.origin ?? "hodnota"} mus\xED m\xEDt ${i}${r.maximum.toString()} ${s.unit ?? "prvk\u016F"}` : `Hodnota je p\u0159\xEDli\u0161 velk\xE1: ${r.origin ?? "hodnota"} mus\xED b\xFDt ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `Hodnota je p\u0159\xEDli\u0161 mal\xE1: ${r.origin ?? "hodnota"} mus\xED m\xEDt ${i}${r.minimum.toString()} ${s.unit ?? "prvk\u016F"}` : `Hodnota je p\u0159\xEDli\u0161 mal\xE1: ${r.origin ?? "hodnota"} mus\xED b\xFDt ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Neplatn\xFD \u0159et\u011Bzec: mus\xED za\u010D\xEDnat na "${i.prefix}"` : i.format === "ends_with" ? `Neplatn\xFD \u0159et\u011Bzec: mus\xED kon\u010Dit na "${i.suffix}"` : i.format === "includes" ? `Neplatn\xFD \u0159et\u011Bzec: mus\xED obsahovat "${i.includes}"` : i.format === "regex" ? `Neplatn\xFD \u0159et\u011Bzec: mus\xED odpov\xEDdat vzoru ${i.pattern}` : `Neplatn\xFD form\xE1t ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Neplatn\xE9 \u010D\xEDslo: mus\xED b\xFDt n\xE1sobkem ${r.divisor}`;
      case "unrecognized_keys":
        return `Nezn\xE1m\xE9 kl\xED\u010De: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Neplatn\xFD kl\xED\u010D v ${r.origin}`;
      case "invalid_union":
        return "Neplatn\xFD vstup";
      case "invalid_element":
        return `Neplatn\xE1 hodnota v ${r.origin}`;
      default:
        return "Neplatn\xFD vstup";
    }
  };
}, "error");
function Ta() {
  return {
    localeError: bg()
  };
}
a(Ta, "default");

// versions/4.4.3/node_modules/zod/v4/locales/da.js
var $g = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "tegn", verb: "havde" },
    file: { unit: "bytes", verb: "havde" },
    array: { unit: "elementer", verb: "indeholdt" },
    set: { unit: "elementer", verb: "indeholdt" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "input",
    email: "e-mailadresse",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO dato- og klokkesl\xE6t",
    date: "ISO-dato",
    time: "ISO-klokkesl\xE6t",
    duration: "ISO-varighed",
    ipv4: "IPv4-omr\xE5de",
    ipv6: "IPv6-omr\xE5de",
    cidrv4: "IPv4-spektrum",
    cidrv6: "IPv6-spektrum",
    base64: "base64-kodet streng",
    base64url: "base64url-kodet streng",
    json_string: "JSON-streng",
    e164: "E.164-nummer",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN",
    string: "streng",
    number: "tal",
    boolean: "boolean",
    array: "liste",
    object: "objekt",
    set: "s\xE6t",
    file: "fil"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Ugyldigt input: forventede instanceof ${r.expected}, fik ${c}` : `Ugyldigt input: forventede ${i}, fik ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Ugyldig v\xE6rdi: forventede ${y(r.values[0])}` : `Ugyldigt valg: forventede en af f\xF8lgende ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin), c = o[r.origin] ?? r.origin;
        return s ? `For stor: forventede ${c ?? "value"} ${s.verb} ${i} ${r.maximum.toString()} ${s.unit ?? "elementer"}` : `For stor: forventede ${c ?? "value"} havde ${i} ${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin), c = o[r.origin] ?? r.origin;
        return s ? `For lille: forventede ${c} ${s.verb} ${i} ${r.minimum.toString()} ${s.unit}` : `For lille: forventede ${c} havde ${i} ${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Ugyldig streng: skal starte med "${i.prefix}"` : i.format === "ends_with" ? `Ugyldig streng: skal ende med "${i.suffix}"` : i.format === "includes" ? `Ugyldig streng: skal indeholde "${i.includes}"` : i.format === "regex" ? `Ugyldig streng: skal matche m\xF8nsteret ${i.pattern}` : `Ugyldig ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Ugyldigt tal: skal v\xE6re deleligt med ${r.divisor}`;
      case "unrecognized_keys":
        return `${r.keys.length > 1 ? "Ukendte n\xF8gler" : "Ukendt n\xF8gle"}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Ugyldig n\xF8gle i ${r.origin}`;
      case "invalid_union":
        return "Ugyldigt input: matcher ingen af de tilladte typer";
      case "invalid_element":
        return `Ugyldig v\xE6rdi i ${r.origin}`;
      default:
        return "Ugyldigt input";
    }
  };
}, "error");
function Pa() {
  return {
    localeError: $g()
  };
}
a(Pa, "default");

// versions/4.4.3/node_modules/zod/v4/locales/de.js
var xg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "Zeichen", verb: "zu haben" },
    file: { unit: "Bytes", verb: "zu haben" },
    array: { unit: "Elemente", verb: "zu haben" },
    set: { unit: "Elemente", verb: "zu haben" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "Eingabe",
    email: "E-Mail-Adresse",
    url: "URL",
    emoji: "Emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO-Datum und -Uhrzeit",
    date: "ISO-Datum",
    time: "ISO-Uhrzeit",
    duration: "ISO-Dauer",
    ipv4: "IPv4-Adresse",
    ipv6: "IPv6-Adresse",
    cidrv4: "IPv4-Bereich",
    cidrv6: "IPv6-Bereich",
    base64: "Base64-codierter String",
    base64url: "Base64-URL-codierter String",
    json_string: "JSON-String",
    e164: "E.164-Nummer",
    jwt: "JWT",
    template_literal: "Eingabe"
  }, o = {
    nan: "NaN",
    number: "Zahl",
    array: "Array"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Ung\xFCltige Eingabe: erwartet instanceof ${r.expected}, erhalten ${c}` : `Ung\xFCltige Eingabe: erwartet ${i}, erhalten ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Ung\xFCltige Eingabe: erwartet ${y(r.values[0])}` : `Ung\xFCltige Option: erwartet eine von ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `Zu gro\xDF: erwartet, dass ${r.origin ?? "Wert"} ${i}${r.maximum.toString()} ${s.unit ?? "Elemente"} hat` : `Zu gro\xDF: erwartet, dass ${r.origin ?? "Wert"} ${i}${r.maximum.toString()} ist`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `Zu klein: erwartet, dass ${r.origin} ${i}${r.minimum.toString()} ${s.unit} hat` : `Zu klein: erwartet, dass ${r.origin} ${i}${r.minimum.toString()} ist`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Ung\xFCltiger String: muss mit "${i.prefix}" beginnen` : i.format === "ends_with" ? `Ung\xFCltiger String: muss mit "${i.suffix}" enden` : i.format === "includes" ? `Ung\xFCltiger String: muss "${i.includes}" enthalten` : i.format === "regex" ? `Ung\xFCltiger String: muss dem Muster ${i.pattern} entsprechen` : `Ung\xFCltig: ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Ung\xFCltige Zahl: muss ein Vielfaches von ${r.divisor} sein`;
      case "unrecognized_keys":
        return `${r.keys.length > 1 ? "Unbekannte Schl\xFCssel" : "Unbekannter Schl\xFCssel"}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Ung\xFCltiger Schl\xFCssel in ${r.origin}`;
      case "invalid_union":
        return "Ung\xFCltige Eingabe";
      case "invalid_element":
        return `Ung\xFCltiger Wert in ${r.origin}`;
      default:
        return "Ung\xFCltige Eingabe";
    }
  };
}, "error");
function Ua() {
  return {
    localeError: xg()
  };
}
a(Ua, "default");

// versions/4.4.3/node_modules/zod/v4/locales/el.js
var _g = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "\u03C7\u03B1\u03C1\u03B1\u03BA\u03C4\u03AE\u03C1\u03B5\u03C2", verb: "\u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9" },
    file: { unit: "bytes", verb: "\u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9" },
    array: { unit: "\u03C3\u03C4\u03BF\u03B9\u03C7\u03B5\u03AF\u03B1", verb: "\u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9" },
    set: { unit: "\u03C3\u03C4\u03BF\u03B9\u03C7\u03B5\u03AF\u03B1", verb: "\u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9" },
    map: { unit: "\u03BA\u03B1\u03C4\u03B1\u03C7\u03C9\u03C1\u03AE\u03C3\u03B5\u03B9\u03C2", verb: "\u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "\u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2",
    email: "\u03B4\u03B9\u03B5\u03CD\u03B8\u03C5\u03BD\u03C3\u03B7 email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u03B7\u03BC\u03B5\u03C1\u03BF\u03BC\u03B7\u03BD\u03AF\u03B1 \u03BA\u03B1\u03B9 \u03CE\u03C1\u03B1",
    date: "ISO \u03B7\u03BC\u03B5\u03C1\u03BF\u03BC\u03B7\u03BD\u03AF\u03B1",
    time: "ISO \u03CE\u03C1\u03B1",
    duration: "ISO \u03B4\u03B9\u03AC\u03C1\u03BA\u03B5\u03B9\u03B1",
    ipv4: "\u03B4\u03B9\u03B5\u03CD\u03B8\u03C5\u03BD\u03C3\u03B7 IPv4",
    ipv6: "\u03B4\u03B9\u03B5\u03CD\u03B8\u03C5\u03BD\u03C3\u03B7 IPv6",
    mac: "\u03B4\u03B9\u03B5\u03CD\u03B8\u03C5\u03BD\u03C3\u03B7 MAC",
    cidrv4: "\u03B5\u03CD\u03C1\u03BF\u03C2 IPv4",
    cidrv6: "\u03B5\u03CD\u03C1\u03BF\u03C2 IPv6",
    base64: "\u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC \u03BA\u03C9\u03B4\u03B9\u03BA\u03BF\u03C0\u03BF\u03B9\u03B7\u03BC\u03AD\u03BD\u03B7 \u03C3\u03B5 base64",
    base64url: "\u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC \u03BA\u03C9\u03B4\u03B9\u03BA\u03BF\u03C0\u03BF\u03B9\u03B7\u03BC\u03AD\u03BD\u03B7 \u03C3\u03B5 base64url",
    json_string: "\u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC JSON",
    e164: "\u03B1\u03C1\u03B9\u03B8\u03BC\u03CC\u03C2 E.164",
    jwt: "JWT",
    template_literal: "\u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2"
  }, o = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return typeof r.expected == "string" && /^[A-Z]/.test(r.expected) ? `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD instanceof ${r.expected}, \u03BB\u03AE\u03C6\u03B8\u03B7\u03BA\u03B5 ${c}` : `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${i}, \u03BB\u03AE\u03C6\u03B8\u03B7\u03BA\u03B5 ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${y(r.values[0])}` : `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03C0\u03B9\u03BB\u03BF\u03B3\u03AE: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD \u03AD\u03BD\u03B1 \u03B1\u03C0\u03CC ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `\u03A0\u03BF\u03BB\u03CD \u03BC\u03B5\u03B3\u03AC\u03BB\u03BF: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${r.origin ?? "\u03C4\u03B9\u03BC\u03AE"} \u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9 ${i}${r.maximum.toString()} ${s.unit ?? "\u03C3\u03C4\u03BF\u03B9\u03C7\u03B5\u03AF\u03B1"}` : `\u03A0\u03BF\u03BB\u03CD \u03BC\u03B5\u03B3\u03AC\u03BB\u03BF: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${r.origin ?? "\u03C4\u03B9\u03BC\u03AE"} \u03BD\u03B1 \u03B5\u03AF\u03BD\u03B1\u03B9 ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `\u03A0\u03BF\u03BB\u03CD \u03BC\u03B9\u03BA\u03C1\u03CC: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${r.origin} \u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9 ${i}${r.minimum.toString()} ${s.unit}` : `\u03A0\u03BF\u03BB\u03CD \u03BC\u03B9\u03BA\u03C1\u03CC: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${r.origin} \u03BD\u03B1 \u03B5\u03AF\u03BD\u03B1\u03B9 ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC: \u03C0\u03C1\u03AD\u03C0\u03B5\u03B9 \u03BD\u03B1 \u03BE\u03B5\u03BA\u03B9\u03BD\u03AC \u03BC\u03B5 "${i.prefix}"` : i.format === "ends_with" ? `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC: \u03C0\u03C1\u03AD\u03C0\u03B5\u03B9 \u03BD\u03B1 \u03C4\u03B5\u03BB\u03B5\u03B9\u03CE\u03BD\u03B5\u03B9 \u03BC\u03B5 "${i.suffix}"` : i.format === "includes" ? `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC: \u03C0\u03C1\u03AD\u03C0\u03B5\u03B9 \u03BD\u03B1 \u03C0\u03B5\u03C1\u03B9\u03AD\u03C7\u03B5\u03B9 "${i.includes}"` : i.format === "regex" ? `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC: \u03C0\u03C1\u03AD\u03C0\u03B5\u03B9 \u03BD\u03B1 \u03C4\u03B1\u03B9\u03C1\u03B9\u03AC\u03B6\u03B5\u03B9 \u03BC\u03B5 \u03C4\u03BF \u03BC\u03BF\u03C4\u03AF\u03B2\u03BF ${i.pattern}` : `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03BF: ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03BF\u03C2 \u03B1\u03C1\u03B9\u03B8\u03BC\u03CC\u03C2: \u03C0\u03C1\u03AD\u03C0\u03B5\u03B9 \u03BD\u03B1 \u03B5\u03AF\u03BD\u03B1\u03B9 \u03C0\u03BF\u03BB\u03BB\u03B1\u03C0\u03BB\u03AC\u03C3\u03B9\u03BF \u03C4\u03BF\u03C5 ${r.divisor}`;
      case "unrecognized_keys":
        return `\u0386\u03B3\u03BD\u03C9\u03C3\u03C4${r.keys.length > 1 ? "\u03B1" : "\u03BF"} \u03BA\u03BB\u03B5\u03B9\u03B4${r.keys.length > 1 ? "\u03B9\u03AC" : "\u03AF"}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03BF \u03BA\u03BB\u03B5\u03B9\u03B4\u03AF \u03C3\u03C4\u03BF ${r.origin}`;
      case "invalid_union":
        return "\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2";
      case "invalid_element":
        return `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03C4\u03B9\u03BC\u03AE \u03C3\u03C4\u03BF ${r.origin}`;
      default:
        return "\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2";
    }
  };
}, "error");
function Da() {
  return {
    localeError: _g()
  };
}
a(Da, "default");

// versions/4.4.3/node_modules/zod/v4/locales/en.js
var wg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "characters", verb: "to have" },
    file: { unit: "bytes", verb: "to have" },
    array: { unit: "items", verb: "to have" },
    set: { unit: "items", verb: "to have" },
    map: { unit: "entries", verb: "to have" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "input",
    email: "email address",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datetime",
    date: "ISO date",
    time: "ISO time",
    duration: "ISO duration",
    ipv4: "IPv4 address",
    ipv6: "IPv6 address",
    mac: "MAC address",
    cidrv4: "IPv4 range",
    cidrv6: "IPv6 range",
    base64: "base64-encoded string",
    base64url: "base64url-encoded string",
    json_string: "JSON string",
    e164: "E.164 number",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    // Compatibility: "nan" -> "NaN" for display
    nan: "NaN"
    // All other type names omitted - they fall back to raw values via ?? operator
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return `Invalid input: expected ${i}, received ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Invalid input: expected ${y(r.values[0])}` : `Invalid option: expected one of ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `Too big: expected ${r.origin ?? "value"} to have ${i}${r.maximum.toString()} ${s.unit ?? "elements"}` : `Too big: expected ${r.origin ?? "value"} to be ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `Too small: expected ${r.origin} to have ${i}${r.minimum.toString()} ${s.unit}` : `Too small: expected ${r.origin} to be ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Invalid string: must start with "${i.prefix}"` : i.format === "ends_with" ? `Invalid string: must end with "${i.suffix}"` : i.format === "includes" ? `Invalid string: must include "${i.includes}"` : i.format === "regex" ? `Invalid string: must match pattern ${i.pattern}` : `Invalid ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Invalid number: must be a multiple of ${r.divisor}`;
      case "unrecognized_keys":
        return `Unrecognized key${r.keys.length > 1 ? "s" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Invalid key in ${r.origin}`;
      case "invalid_union":
        return r.options && Array.isArray(r.options) && r.options.length > 0 ? `Invalid discriminator value. Expected ${r.options.map((s) => `'${s}'`).join(" | ")}` : "Invalid input";
      case "invalid_element":
        return `Invalid value in ${r.origin}`;
      default:
        return "Invalid input";
    }
  };
}, "error");
function Ea() {
  return {
    localeError: wg()
  };
}
a(Ea, "default");

// versions/4.4.3/node_modules/zod/v4/locales/eo.js
var kg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "karaktrojn", verb: "havi" },
    file: { unit: "bajtojn", verb: "havi" },
    array: { unit: "elementojn", verb: "havi" },
    set: { unit: "elementojn", verb: "havi" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "enigo",
    email: "retadreso",
    url: "URL",
    emoji: "emo\u011Dio",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO-datotempo",
    date: "ISO-dato",
    time: "ISO-tempo",
    duration: "ISO-da\u016Dro",
    ipv4: "IPv4-adreso",
    ipv6: "IPv6-adreso",
    cidrv4: "IPv4-rango",
    cidrv6: "IPv6-rango",
    base64: "64-ume kodita karaktraro",
    base64url: "URL-64-ume kodita karaktraro",
    json_string: "JSON-karaktraro",
    e164: "E.164-nombro",
    jwt: "JWT",
    template_literal: "enigo"
  }, o = {
    nan: "NaN",
    number: "nombro",
    array: "tabelo",
    null: "senvalora"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Nevalida enigo: atendi\u011Dis instanceof ${r.expected}, ricevi\u011Dis ${c}` : `Nevalida enigo: atendi\u011Dis ${i}, ricevi\u011Dis ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Nevalida enigo: atendi\u011Dis ${y(r.values[0])}` : `Nevalida opcio: atendi\u011Dis unu el ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `Tro granda: atendi\u011Dis ke ${r.origin ?? "valoro"} havu ${i}${r.maximum.toString()} ${s.unit ?? "elementojn"}` : `Tro granda: atendi\u011Dis ke ${r.origin ?? "valoro"} havu ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `Tro malgranda: atendi\u011Dis ke ${r.origin} havu ${i}${r.minimum.toString()} ${s.unit}` : `Tro malgranda: atendi\u011Dis ke ${r.origin} estu ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Nevalida karaktraro: devas komenci\u011Di per "${i.prefix}"` : i.format === "ends_with" ? `Nevalida karaktraro: devas fini\u011Di per "${i.suffix}"` : i.format === "includes" ? `Nevalida karaktraro: devas inkluzivi "${i.includes}"` : i.format === "regex" ? `Nevalida karaktraro: devas kongrui kun la modelo ${i.pattern}` : `Nevalida ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Nevalida nombro: devas esti oblo de ${r.divisor}`;
      case "unrecognized_keys":
        return `Nekonata${r.keys.length > 1 ? "j" : ""} \u015Dlosilo${r.keys.length > 1 ? "j" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Nevalida \u015Dlosilo en ${r.origin}`;
      case "invalid_union":
        return "Nevalida enigo";
      case "invalid_element":
        return `Nevalida valoro en ${r.origin}`;
      default:
        return "Nevalida enigo";
    }
  };
}, "error");
function Na() {
  return {
    localeError: kg()
  };
}
a(Na, "default");

// versions/4.4.3/node_modules/zod/v4/locales/es.js
var Ig = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "caracteres", verb: "tener" },
    file: { unit: "bytes", verb: "tener" },
    array: { unit: "elementos", verb: "tener" },
    set: { unit: "elementos", verb: "tener" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "entrada",
    email: "direcci\xF3n de correo electr\xF3nico",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "fecha y hora ISO",
    date: "fecha ISO",
    time: "hora ISO",
    duration: "duraci\xF3n ISO",
    ipv4: "direcci\xF3n IPv4",
    ipv6: "direcci\xF3n IPv6",
    cidrv4: "rango IPv4",
    cidrv6: "rango IPv6",
    base64: "cadena codificada en base64",
    base64url: "URL codificada en base64",
    json_string: "cadena JSON",
    e164: "n\xFAmero E.164",
    jwt: "JWT",
    template_literal: "entrada"
  }, o = {
    nan: "NaN",
    string: "texto",
    number: "n\xFAmero",
    boolean: "booleano",
    array: "arreglo",
    object: "objeto",
    set: "conjunto",
    file: "archivo",
    date: "fecha",
    bigint: "n\xFAmero grande",
    symbol: "s\xEDmbolo",
    undefined: "indefinido",
    null: "nulo",
    function: "funci\xF3n",
    map: "mapa",
    record: "registro",
    tuple: "tupla",
    enum: "enumeraci\xF3n",
    union: "uni\xF3n",
    literal: "literal",
    promise: "promesa",
    void: "vac\xEDo",
    never: "nunca",
    unknown: "desconocido",
    any: "cualquiera"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Entrada inv\xE1lida: se esperaba instanceof ${r.expected}, recibido ${c}` : `Entrada inv\xE1lida: se esperaba ${i}, recibido ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Entrada inv\xE1lida: se esperaba ${y(r.values[0])}` : `Opci\xF3n inv\xE1lida: se esperaba una de ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin), c = o[r.origin] ?? r.origin;
        return s ? `Demasiado grande: se esperaba que ${c ?? "valor"} tuviera ${i}${r.maximum.toString()} ${s.unit ?? "elementos"}` : `Demasiado grande: se esperaba que ${c ?? "valor"} fuera ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin), c = o[r.origin] ?? r.origin;
        return s ? `Demasiado peque\xF1o: se esperaba que ${c} tuviera ${i}${r.minimum.toString()} ${s.unit}` : `Demasiado peque\xF1o: se esperaba que ${c} fuera ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Cadena inv\xE1lida: debe comenzar con "${i.prefix}"` : i.format === "ends_with" ? `Cadena inv\xE1lida: debe terminar en "${i.suffix}"` : i.format === "includes" ? `Cadena inv\xE1lida: debe incluir "${i.includes}"` : i.format === "regex" ? `Cadena inv\xE1lida: debe coincidir con el patr\xF3n ${i.pattern}` : `Inv\xE1lido ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `N\xFAmero inv\xE1lido: debe ser m\xFAltiplo de ${r.divisor}`;
      case "unrecognized_keys":
        return `Llave${r.keys.length > 1 ? "s" : ""} desconocida${r.keys.length > 1 ? "s" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Llave inv\xE1lida en ${o[r.origin] ?? r.origin}`;
      case "invalid_union":
        return "Entrada inv\xE1lida";
      case "invalid_element":
        return `Valor inv\xE1lido en ${o[r.origin] ?? r.origin}`;
      default:
        return "Entrada inv\xE1lida";
    }
  };
}, "error");
function Za() {
  return {
    localeError: Ig()
  };
}
a(Za, "default");

// versions/4.4.3/node_modules/zod/v4/locales/fa.js
var zg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "\u06A9\u0627\u0631\u0627\u06A9\u062A\u0631", verb: "\u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F" },
    file: { unit: "\u0628\u0627\u06CC\u062A", verb: "\u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F" },
    array: { unit: "\u0622\u06CC\u062A\u0645", verb: "\u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F" },
    set: { unit: "\u0622\u06CC\u062A\u0645", verb: "\u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "\u0648\u0631\u0648\u062F\u06CC",
    email: "\u0622\u062F\u0631\u0633 \u0627\u06CC\u0645\u06CC\u0644",
    url: "URL",
    emoji: "\u0627\u06CC\u0645\u0648\u062C\u06CC",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u062A\u0627\u0631\u06CC\u062E \u0648 \u0632\u0645\u0627\u0646 \u0627\u06CC\u0632\u0648",
    date: "\u062A\u0627\u0631\u06CC\u062E \u0627\u06CC\u0632\u0648",
    time: "\u0632\u0645\u0627\u0646 \u0627\u06CC\u0632\u0648",
    duration: "\u0645\u062F\u062A \u0632\u0645\u0627\u0646 \u0627\u06CC\u0632\u0648",
    ipv4: "IPv4 \u0622\u062F\u0631\u0633",
    ipv6: "IPv6 \u0622\u062F\u0631\u0633",
    cidrv4: "IPv4 \u062F\u0627\u0645\u0646\u0647",
    cidrv6: "IPv6 \u062F\u0627\u0645\u0646\u0647",
    base64: "base64-encoded \u0631\u0634\u062A\u0647",
    base64url: "base64url-encoded \u0631\u0634\u062A\u0647",
    json_string: "JSON \u0631\u0634\u062A\u0647",
    e164: "E.164 \u0639\u062F\u062F",
    jwt: "JWT",
    template_literal: "\u0648\u0631\u0648\u062F\u06CC"
  }, o = {
    nan: "NaN",
    number: "\u0639\u062F\u062F",
    array: "\u0622\u0631\u0627\u06CC\u0647"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0645\u06CC\u200C\u0628\u0627\u06CC\u0633\u062A instanceof ${r.expected} \u0645\u06CC\u200C\u0628\u0648\u062F\u060C ${c} \u062F\u0631\u06CC\u0627\u0641\u062A \u0634\u062F` : `\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0645\u06CC\u200C\u0628\u0627\u06CC\u0633\u062A ${i} \u0645\u06CC\u200C\u0628\u0648\u062F\u060C ${c} \u062F\u0631\u06CC\u0627\u0641\u062A \u0634\u062F`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0645\u06CC\u200C\u0628\u0627\u06CC\u0633\u062A ${y(r.values[0])} \u0645\u06CC\u200C\u0628\u0648\u062F` : `\u06AF\u0632\u06CC\u0646\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0645\u06CC\u200C\u0628\u0627\u06CC\u0633\u062A \u06CC\u06A9\u06CC \u0627\u0632 ${p(r.values, "|")} \u0645\u06CC\u200C\u0628\u0648\u062F`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `\u062E\u06CC\u0644\u06CC \u0628\u0632\u0631\u06AF: ${r.origin ?? "\u0645\u0642\u062F\u0627\u0631"} \u0628\u0627\u06CC\u062F ${i}${r.maximum.toString()} ${s.unit ?? "\u0639\u0646\u0635\u0631"} \u0628\u0627\u0634\u062F` : `\u062E\u06CC\u0644\u06CC \u0628\u0632\u0631\u06AF: ${r.origin ?? "\u0645\u0642\u062F\u0627\u0631"} \u0628\u0627\u06CC\u062F ${i}${r.maximum.toString()} \u0628\u0627\u0634\u062F`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `\u062E\u06CC\u0644\u06CC \u06A9\u0648\u0686\u06A9: ${r.origin} \u0628\u0627\u06CC\u062F ${i}${r.minimum.toString()} ${s.unit} \u0628\u0627\u0634\u062F` : `\u062E\u06CC\u0644\u06CC \u06A9\u0648\u0686\u06A9: ${r.origin} \u0628\u0627\u06CC\u062F ${i}${r.minimum.toString()} \u0628\u0627\u0634\u062F`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u0631\u0634\u062A\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0628\u0627 "${i.prefix}" \u0634\u0631\u0648\u0639 \u0634\u0648\u062F` : i.format === "ends_with" ? `\u0631\u0634\u062A\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0628\u0627 "${i.suffix}" \u062A\u0645\u0627\u0645 \u0634\u0648\u062F` : i.format === "includes" ? `\u0631\u0634\u062A\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0634\u0627\u0645\u0644 "${i.includes}" \u0628\u0627\u0634\u062F` : i.format === "regex" ? `\u0631\u0634\u062A\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0628\u0627 \u0627\u0644\u06AF\u0648\u06CC ${i.pattern} \u0645\u0637\u0627\u0628\u0642\u062A \u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F` : `${n[i.format] ?? r.format} \u0646\u0627\u0645\u0639\u062A\u0628\u0631`;
      }
      case "not_multiple_of":
        return `\u0639\u062F\u062F \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0645\u0636\u0631\u0628 ${r.divisor} \u0628\u0627\u0634\u062F`;
      case "unrecognized_keys":
        return `\u06A9\u0644\u06CC\u062F${r.keys.length > 1 ? "\u0647\u0627\u06CC" : ""} \u0646\u0627\u0634\u0646\u0627\u0633: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `\u06A9\u0644\u06CC\u062F \u0646\u0627\u0634\u0646\u0627\u0633 \u062F\u0631 ${r.origin}`;
      case "invalid_union":
        return "\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631";
      case "invalid_element":
        return `\u0645\u0642\u062F\u0627\u0631 \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u062F\u0631 ${r.origin}`;
      default:
        return "\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631";
    }
  };
}, "error");
function Aa() {
  return {
    localeError: zg()
  };
}
a(Aa, "default");

// versions/4.4.3/node_modules/zod/v4/locales/fi.js
var Sg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "merkki\xE4", subject: "merkkijonon" },
    file: { unit: "tavua", subject: "tiedoston" },
    array: { unit: "alkiota", subject: "listan" },
    set: { unit: "alkiota", subject: "joukon" },
    number: { unit: "", subject: "luvun" },
    bigint: { unit: "", subject: "suuren kokonaisluvun" },
    int: { unit: "", subject: "kokonaisluvun" },
    date: { unit: "", subject: "p\xE4iv\xE4m\xE4\xE4r\xE4n" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "s\xE4\xE4nn\xF6llinen lauseke",
    email: "s\xE4hk\xF6postiosoite",
    url: "URL-osoite",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO-aikaleima",
    date: "ISO-p\xE4iv\xE4m\xE4\xE4r\xE4",
    time: "ISO-aika",
    duration: "ISO-kesto",
    ipv4: "IPv4-osoite",
    ipv6: "IPv6-osoite",
    cidrv4: "IPv4-alue",
    cidrv6: "IPv6-alue",
    base64: "base64-koodattu merkkijono",
    base64url: "base64url-koodattu merkkijono",
    json_string: "JSON-merkkijono",
    e164: "E.164-luku",
    jwt: "JWT",
    template_literal: "templaattimerkkijono"
  }, o = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Virheellinen tyyppi: odotettiin instanceof ${r.expected}, oli ${c}` : `Virheellinen tyyppi: odotettiin ${i}, oli ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Virheellinen sy\xF6te: t\xE4ytyy olla ${y(r.values[0])}` : `Virheellinen valinta: t\xE4ytyy olla yksi seuraavista: ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `Liian suuri: ${s.subject} t\xE4ytyy olla ${i}${r.maximum.toString()} ${s.unit}`.trim() : `Liian suuri: arvon t\xE4ytyy olla ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `Liian pieni: ${s.subject} t\xE4ytyy olla ${i}${r.minimum.toString()} ${s.unit}`.trim() : `Liian pieni: arvon t\xE4ytyy olla ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Virheellinen sy\xF6te: t\xE4ytyy alkaa "${i.prefix}"` : i.format === "ends_with" ? `Virheellinen sy\xF6te: t\xE4ytyy loppua "${i.suffix}"` : i.format === "includes" ? `Virheellinen sy\xF6te: t\xE4ytyy sis\xE4lt\xE4\xE4 "${i.includes}"` : i.format === "regex" ? `Virheellinen sy\xF6te: t\xE4ytyy vastata s\xE4\xE4nn\xF6llist\xE4 lauseketta ${i.pattern}` : `Virheellinen ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Virheellinen luku: t\xE4ytyy olla luvun ${r.divisor} monikerta`;
      case "unrecognized_keys":
        return `${r.keys.length > 1 ? "Tuntemattomat avaimet" : "Tuntematon avain"}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return "Virheellinen avain tietueessa";
      case "invalid_union":
        return "Virheellinen unioni";
      case "invalid_element":
        return "Virheellinen arvo joukossa";
      default:
        return "Virheellinen sy\xF6te";
    }
  };
}, "error");
function Ca() {
  return {
    localeError: Sg()
  };
}
a(Ca, "default");

// versions/4.4.3/node_modules/zod/v4/locales/fr.js
var jg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "caract\xE8res", verb: "avoir" },
    file: { unit: "octets", verb: "avoir" },
    array: { unit: "\xE9l\xE9ments", verb: "avoir" },
    set: { unit: "\xE9l\xE9ments", verb: "avoir" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "entr\xE9e",
    email: "adresse e-mail",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "date et heure ISO",
    date: "date ISO",
    time: "heure ISO",
    duration: "dur\xE9e ISO",
    ipv4: "adresse IPv4",
    ipv6: "adresse IPv6",
    cidrv4: "plage IPv4",
    cidrv6: "plage IPv6",
    base64: "cha\xEEne encod\xE9e en base64",
    base64url: "cha\xEEne encod\xE9e en base64url",
    json_string: "cha\xEEne JSON",
    e164: "num\xE9ro E.164",
    jwt: "JWT",
    template_literal: "entr\xE9e"
  }, o = {
    string: "cha\xEEne",
    number: "nombre",
    int: "entier",
    boolean: "bool\xE9en",
    bigint: "grand entier",
    symbol: "symbole",
    undefined: "ind\xE9fini",
    null: "null",
    never: "jamais",
    void: "vide",
    date: "date",
    array: "tableau",
    object: "objet",
    tuple: "tuple",
    record: "enregistrement",
    map: "carte",
    set: "ensemble",
    file: "fichier",
    nonoptional: "non-optionnel",
    nan: "NaN",
    function: "fonction"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Entr\xE9e invalide : instanceof ${r.expected} attendu, ${c} re\xE7u` : `Entr\xE9e invalide : ${i} attendu, ${c} re\xE7u`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Entr\xE9e invalide : ${y(r.values[0])} attendu` : `Option invalide : une valeur parmi ${p(r.values, "|")} attendue`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `Trop grand : ${o[r.origin] ?? "valeur"} doit ${s.verb} ${i}${r.maximum.toString()} ${s.unit ?? "\xE9l\xE9ment(s)"}` : `Trop grand : ${o[r.origin] ?? "valeur"} doit \xEAtre ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `Trop petit : ${o[r.origin] ?? "valeur"} doit ${s.verb} ${i}${r.minimum.toString()} ${s.unit}` : `Trop petit : ${o[r.origin] ?? "valeur"} doit \xEAtre ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Cha\xEEne invalide : doit commencer par "${i.prefix}"` : i.format === "ends_with" ? `Cha\xEEne invalide : doit se terminer par "${i.suffix}"` : i.format === "includes" ? `Cha\xEEne invalide : doit inclure "${i.includes}"` : i.format === "regex" ? `Cha\xEEne invalide : doit correspondre au mod\xE8le ${i.pattern}` : `${n[i.format] ?? r.format} invalide`;
      }
      case "not_multiple_of":
        return `Nombre invalide : doit \xEAtre un multiple de ${r.divisor}`;
      case "unrecognized_keys":
        return `Cl\xE9${r.keys.length > 1 ? "s" : ""} non reconnue${r.keys.length > 1 ? "s" : ""} : ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Cl\xE9 invalide dans ${r.origin}`;
      case "invalid_union":
        return "Entr\xE9e invalide";
      case "invalid_element":
        return `Valeur invalide dans ${r.origin}`;
      default:
        return "Entr\xE9e invalide";
    }
  };
}, "error");
function Ra() {
  return {
    localeError: jg()
  };
}
a(Ra, "default");

// versions/4.4.3/node_modules/zod/v4/locales/fr-CA.js
var Og = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "caract\xE8res", verb: "avoir" },
    file: { unit: "octets", verb: "avoir" },
    array: { unit: "\xE9l\xE9ments", verb: "avoir" },
    set: { unit: "\xE9l\xE9ments", verb: "avoir" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "entr\xE9e",
    email: "adresse courriel",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "date-heure ISO",
    date: "date ISO",
    time: "heure ISO",
    duration: "dur\xE9e ISO",
    ipv4: "adresse IPv4",
    ipv6: "adresse IPv6",
    cidrv4: "plage IPv4",
    cidrv6: "plage IPv6",
    base64: "cha\xEEne encod\xE9e en base64",
    base64url: "cha\xEEne encod\xE9e en base64url",
    json_string: "cha\xEEne JSON",
    e164: "num\xE9ro E.164",
    jwt: "JWT",
    template_literal: "entr\xE9e"
  }, o = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Entr\xE9e invalide : attendu instanceof ${r.expected}, re\xE7u ${c}` : `Entr\xE9e invalide : attendu ${i}, re\xE7u ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Entr\xE9e invalide : attendu ${y(r.values[0])}` : `Option invalide : attendu l'une des valeurs suivantes ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "\u2264" : "<", s = t(r.origin);
        return s ? `Trop grand : attendu que ${r.origin ?? "la valeur"} ait ${i}${r.maximum.toString()} ${s.unit}` : `Trop grand : attendu que ${r.origin ?? "la valeur"} soit ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? "\u2265" : ">", s = t(r.origin);
        return s ? `Trop petit : attendu que ${r.origin} ait ${i}${r.minimum.toString()} ${s.unit}` : `Trop petit : attendu que ${r.origin} soit ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Cha\xEEne invalide : doit commencer par "${i.prefix}"` : i.format === "ends_with" ? `Cha\xEEne invalide : doit se terminer par "${i.suffix}"` : i.format === "includes" ? `Cha\xEEne invalide : doit inclure "${i.includes}"` : i.format === "regex" ? `Cha\xEEne invalide : doit correspondre au motif ${i.pattern}` : `${n[i.format] ?? r.format} invalide`;
      }
      case "not_multiple_of":
        return `Nombre invalide : doit \xEAtre un multiple de ${r.divisor}`;
      case "unrecognized_keys":
        return `Cl\xE9${r.keys.length > 1 ? "s" : ""} non reconnue${r.keys.length > 1 ? "s" : ""} : ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Cl\xE9 invalide dans ${r.origin}`;
      case "invalid_union":
        return "Entr\xE9e invalide";
      case "invalid_element":
        return `Valeur invalide dans ${r.origin}`;
      default:
        return "Entr\xE9e invalide";
    }
  };
}, "error");
function Fa() {
  return {
    localeError: Og()
  };
}
a(Fa, "default");

// versions/4.4.3/node_modules/zod/v4/locales/he.js
var Tg = /* @__PURE__ */ a(() => {
  let e = {
    string: { label: "\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA", gender: "f" },
    number: { label: "\u05DE\u05E1\u05E4\u05E8", gender: "m" },
    boolean: { label: "\u05E2\u05E8\u05DA \u05D1\u05D5\u05DC\u05D9\u05D0\u05E0\u05D9", gender: "m" },
    bigint: { label: "BigInt", gender: "m" },
    date: { label: "\u05EA\u05D0\u05E8\u05D9\u05DA", gender: "m" },
    array: { label: "\u05DE\u05E2\u05E8\u05DA", gender: "m" },
    object: { label: "\u05D0\u05D5\u05D1\u05D9\u05D9\u05E7\u05D8", gender: "m" },
    null: { label: "\u05E2\u05E8\u05DA \u05E8\u05D9\u05E7 (null)", gender: "m" },
    undefined: { label: "\u05E2\u05E8\u05DA \u05DC\u05D0 \u05DE\u05D5\u05D2\u05D3\u05E8 (undefined)", gender: "m" },
    symbol: { label: "\u05E1\u05D9\u05DE\u05D1\u05D5\u05DC (Symbol)", gender: "m" },
    function: { label: "\u05E4\u05D5\u05E0\u05E7\u05E6\u05D9\u05D4", gender: "f" },
    map: { label: "\u05DE\u05E4\u05D4 (Map)", gender: "f" },
    set: { label: "\u05E7\u05D1\u05D5\u05E6\u05D4 (Set)", gender: "f" },
    file: { label: "\u05E7\u05D5\u05D1\u05E5", gender: "m" },
    promise: { label: "Promise", gender: "m" },
    NaN: { label: "NaN", gender: "m" },
    unknown: { label: "\u05E2\u05E8\u05DA \u05DC\u05D0 \u05D9\u05D3\u05D5\u05E2", gender: "m" },
    value: { label: "\u05E2\u05E8\u05DA", gender: "m" }
  }, t = {
    string: { unit: "\u05EA\u05D5\u05D5\u05D9\u05DD", shortLabel: "\u05E7\u05E6\u05E8", longLabel: "\u05D0\u05E8\u05D5\u05DA" },
    file: { unit: "\u05D1\u05D9\u05D9\u05D8\u05D9\u05DD", shortLabel: "\u05E7\u05D8\u05DF", longLabel: "\u05D2\u05D3\u05D5\u05DC" },
    array: { unit: "\u05E4\u05E8\u05D9\u05D8\u05D9\u05DD", shortLabel: "\u05E7\u05D8\u05DF", longLabel: "\u05D2\u05D3\u05D5\u05DC" },
    set: { unit: "\u05E4\u05E8\u05D9\u05D8\u05D9\u05DD", shortLabel: "\u05E7\u05D8\u05DF", longLabel: "\u05D2\u05D3\u05D5\u05DC" },
    number: { unit: "", shortLabel: "\u05E7\u05D8\u05DF", longLabel: "\u05D2\u05D3\u05D5\u05DC" }
    // no unit
  }, n = /* @__PURE__ */ a((l) => l ? e[l] : void 0, "typeEntry"), o = /* @__PURE__ */ a((l) => {
    let d = n(l);
    return d ? d.label : l ?? e.unknown.label;
  }, "typeLabel"), r = /* @__PURE__ */ a((l) => `\u05D4${o(l)}`, "withDefinite"), i = /* @__PURE__ */ a((l) => (n(l)?.gender ?? "m") === "f" ? "\u05E6\u05E8\u05D9\u05DB\u05D4 \u05DC\u05D4\u05D9\u05D5\u05EA" : "\u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA", "verbFor"), s = /* @__PURE__ */ a((l) => l ? t[l] ?? null : null, "getSizing"), c = {
    regex: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    email: { label: "\u05DB\u05EA\u05D5\u05D1\u05EA \u05D0\u05D9\u05DE\u05D9\u05D9\u05DC", gender: "f" },
    url: { label: "\u05DB\u05EA\u05D5\u05D1\u05EA \u05E8\u05E9\u05EA", gender: "f" },
    emoji: { label: "\u05D0\u05D9\u05DE\u05D5\u05D2'\u05D9", gender: "m" },
    uuid: { label: "UUID", gender: "m" },
    nanoid: { label: "nanoid", gender: "m" },
    guid: { label: "GUID", gender: "m" },
    cuid: { label: "cuid", gender: "m" },
    cuid2: { label: "cuid2", gender: "m" },
    ulid: { label: "ULID", gender: "m" },
    xid: { label: "XID", gender: "m" },
    ksuid: { label: "KSUID", gender: "m" },
    datetime: { label: "\u05EA\u05D0\u05E8\u05D9\u05DA \u05D5\u05D6\u05DE\u05DF ISO", gender: "m" },
    date: { label: "\u05EA\u05D0\u05E8\u05D9\u05DA ISO", gender: "m" },
    time: { label: "\u05D6\u05DE\u05DF ISO", gender: "m" },
    duration: { label: "\u05DE\u05E9\u05DA \u05D6\u05DE\u05DF ISO", gender: "m" },
    ipv4: { label: "\u05DB\u05EA\u05D5\u05D1\u05EA IPv4", gender: "f" },
    ipv6: { label: "\u05DB\u05EA\u05D5\u05D1\u05EA IPv6", gender: "f" },
    cidrv4: { label: "\u05D8\u05D5\u05D5\u05D7 IPv4", gender: "m" },
    cidrv6: { label: "\u05D8\u05D5\u05D5\u05D7 IPv6", gender: "m" },
    base64: { label: "\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D1\u05D1\u05E1\u05D9\u05E1 64", gender: "f" },
    base64url: { label: "\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D1\u05D1\u05E1\u05D9\u05E1 64 \u05DC\u05DB\u05EA\u05D5\u05D1\u05D5\u05EA \u05E8\u05E9\u05EA", gender: "f" },
    json_string: { label: "\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA JSON", gender: "f" },
    e164: { label: "\u05DE\u05E1\u05E4\u05E8 E.164", gender: "m" },
    jwt: { label: "JWT", gender: "m" },
    ends_with: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    includes: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    lowercase: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    starts_with: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    uppercase: { label: "\u05E7\u05DC\u05D8", gender: "m" }
  }, u = {
    nan: "NaN"
  };
  return (l) => {
    switch (l.code) {
      case "invalid_type": {
        let d = l.expected, g = u[d ?? ""] ?? o(d), $ = b(l.input), v = u[$] ?? e[$]?.label ?? $;
        return /^[A-Z]/.test(l.expected) ? `\u05E7\u05DC\u05D8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA instanceof ${l.expected}, \u05D4\u05EA\u05E7\u05D1\u05DC ${v}` : `\u05E7\u05DC\u05D8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA ${g}, \u05D4\u05EA\u05E7\u05D1\u05DC ${v}`;
      }
      case "invalid_value": {
        if (l.values.length === 1)
          return `\u05E2\u05E8\u05DA \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05D4\u05E2\u05E8\u05DA \u05D7\u05D9\u05D9\u05D1 \u05DC\u05D4\u05D9\u05D5\u05EA ${y(l.values[0])}`;
        let d = l.values.map((v) => y(v));
        if (l.values.length === 2)
          return `\u05E2\u05E8\u05DA \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05D4\u05D0\u05E4\u05E9\u05E8\u05D5\u05D9\u05D5\u05EA \u05D4\u05DE\u05EA\u05D0\u05D9\u05DE\u05D5\u05EA \u05D4\u05DF ${d[0]} \u05D0\u05D5 ${d[1]}`;
        let g = d[d.length - 1];
        return `\u05E2\u05E8\u05DA \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05D4\u05D0\u05E4\u05E9\u05E8\u05D5\u05D9\u05D5\u05EA \u05D4\u05DE\u05EA\u05D0\u05D9\u05DE\u05D5\u05EA \u05D4\u05DF ${d.slice(0, -1).join(", ")} \u05D0\u05D5 ${g}`;
      }
      case "too_big": {
        let d = s(l.origin), g = r(l.origin ?? "value");
        if (l.origin === "string")
          return `${d?.longLabel ?? "\u05D0\u05E8\u05D5\u05DA"} \u05DE\u05D3\u05D9: ${g} \u05E6\u05E8\u05D9\u05DB\u05D4 \u05DC\u05D4\u05DB\u05D9\u05DC ${l.maximum.toString()} ${d?.unit ?? ""} ${l.inclusive ? "\u05D0\u05D5 \u05E4\u05D7\u05D5\u05EA" : "\u05DC\u05DB\u05DC \u05D4\u05D9\u05D5\u05EA\u05E8"}`.trim();
        if (l.origin === "number") {
          let k = l.inclusive ? `\u05E7\u05D8\u05DF \u05D0\u05D5 \u05E9\u05D5\u05D5\u05D4 \u05DC-${l.maximum}` : `\u05E7\u05D8\u05DF \u05DE-${l.maximum}`;
          return `\u05D2\u05D3\u05D5\u05DC \u05DE\u05D3\u05D9: ${g} \u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA ${k}`;
        }
        if (l.origin === "array" || l.origin === "set") {
          let k = l.origin === "set" ? "\u05E6\u05E8\u05D9\u05DB\u05D4" : "\u05E6\u05E8\u05D9\u05DA", D = l.inclusive ? `${l.maximum} ${d?.unit ?? ""} \u05D0\u05D5 \u05E4\u05D7\u05D5\u05EA` : `\u05E4\u05D7\u05D5\u05EA \u05DE-${l.maximum} ${d?.unit ?? ""}`;
          return `\u05D2\u05D3\u05D5\u05DC \u05DE\u05D3\u05D9: ${g} ${k} \u05DC\u05D4\u05DB\u05D9\u05DC ${D}`.trim();
        }
        let $ = l.inclusive ? "<=" : "<", v = i(l.origin ?? "value");
        return d?.unit ? `${d.longLabel} \u05DE\u05D3\u05D9: ${g} ${v} ${$}${l.maximum.toString()} ${d.unit}` : `${d?.longLabel ?? "\u05D2\u05D3\u05D5\u05DC"} \u05DE\u05D3\u05D9: ${g} ${v} ${$}${l.maximum.toString()}`;
      }
      case "too_small": {
        let d = s(l.origin), g = r(l.origin ?? "value");
        if (l.origin === "string")
          return `${d?.shortLabel ?? "\u05E7\u05E6\u05E8"} \u05DE\u05D3\u05D9: ${g} \u05E6\u05E8\u05D9\u05DB\u05D4 \u05DC\u05D4\u05DB\u05D9\u05DC ${l.minimum.toString()} ${d?.unit ?? ""} ${l.inclusive ? "\u05D0\u05D5 \u05D9\u05D5\u05EA\u05E8" : "\u05DC\u05E4\u05D7\u05D5\u05EA"}`.trim();
        if (l.origin === "number") {
          let k = l.inclusive ? `\u05D2\u05D3\u05D5\u05DC \u05D0\u05D5 \u05E9\u05D5\u05D5\u05D4 \u05DC-${l.minimum}` : `\u05D2\u05D3\u05D5\u05DC \u05DE-${l.minimum}`;
          return `\u05E7\u05D8\u05DF \u05DE\u05D3\u05D9: ${g} \u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA ${k}`;
        }
        if (l.origin === "array" || l.origin === "set") {
          let k = l.origin === "set" ? "\u05E6\u05E8\u05D9\u05DB\u05D4" : "\u05E6\u05E8\u05D9\u05DA";
          if (l.minimum === 1 && l.inclusive) {
            let T = (l.origin === "set", "\u05DC\u05E4\u05D7\u05D5\u05EA \u05E4\u05E8\u05D9\u05D8 \u05D0\u05D7\u05D3");
            return `\u05E7\u05D8\u05DF \u05DE\u05D3\u05D9: ${g} ${k} \u05DC\u05D4\u05DB\u05D9\u05DC ${T}`;
          }
          let D = l.inclusive ? `${l.minimum} ${d?.unit ?? ""} \u05D0\u05D5 \u05D9\u05D5\u05EA\u05E8` : `\u05D9\u05D5\u05EA\u05E8 \u05DE-${l.minimum} ${d?.unit ?? ""}`;
          return `\u05E7\u05D8\u05DF \u05DE\u05D3\u05D9: ${g} ${k} \u05DC\u05D4\u05DB\u05D9\u05DC ${D}`.trim();
        }
        let $ = l.inclusive ? ">=" : ">", v = i(l.origin ?? "value");
        return d?.unit ? `${d.shortLabel} \u05DE\u05D3\u05D9: ${g} ${v} ${$}${l.minimum.toString()} ${d.unit}` : `${d?.shortLabel ?? "\u05E7\u05D8\u05DF"} \u05DE\u05D3\u05D9: ${g} ${v} ${$}${l.minimum.toString()}`;
      }
      case "invalid_format": {
        let d = l;
        if (d.format === "starts_with")
          return `\u05D4\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D7\u05D9\u05D9\u05D1\u05EA \u05DC\u05D4\u05EA\u05D7\u05D9\u05DC \u05D1 "${d.prefix}"`;
        if (d.format === "ends_with")
          return `\u05D4\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D7\u05D9\u05D9\u05D1\u05EA \u05DC\u05D4\u05E1\u05EA\u05D9\u05D9\u05DD \u05D1 "${d.suffix}"`;
        if (d.format === "includes")
          return `\u05D4\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D7\u05D9\u05D9\u05D1\u05EA \u05DC\u05DB\u05DC\u05D5\u05DC "${d.includes}"`;
        if (d.format === "regex")
          return `\u05D4\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D7\u05D9\u05D9\u05D1\u05EA \u05DC\u05D4\u05EA\u05D0\u05D9\u05DD \u05DC\u05EA\u05D1\u05E0\u05D9\u05EA ${d.pattern}`;
        let g = c[d.format], $ = g?.label ?? d.format, k = (g?.gender ?? "m") === "f" ? "\u05EA\u05E7\u05D9\u05E0\u05D4" : "\u05EA\u05E7\u05D9\u05DF";
        return `${$} \u05DC\u05D0 ${k}`;
      }
      case "not_multiple_of":
        return `\u05DE\u05E1\u05E4\u05E8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05D7\u05D9\u05D9\u05D1 \u05DC\u05D4\u05D9\u05D5\u05EA \u05DE\u05DB\u05E4\u05DC\u05D4 \u05E9\u05DC ${l.divisor}`;
      case "unrecognized_keys":
        return `\u05DE\u05E4\u05EA\u05D7${l.keys.length > 1 ? "\u05D5\u05EA" : ""} \u05DC\u05D0 \u05DE\u05D6\u05D5\u05D4${l.keys.length > 1 ? "\u05D9\u05DD" : "\u05D4"}: ${p(l.keys, ", ")}`;
      case "invalid_key":
        return "\u05E9\u05D3\u05D4 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF \u05D1\u05D0\u05D5\u05D1\u05D9\u05D9\u05E7\u05D8";
      case "invalid_union":
        return "\u05E7\u05DC\u05D8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF";
      case "invalid_element":
        return `\u05E2\u05E8\u05DA \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF \u05D1${r(l.origin ?? "array")}`;
      default:
        return "\u05E7\u05DC\u05D8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF";
    }
  };
}, "error");
function Ma() {
  return {
    localeError: Tg()
  };
}
a(Ma, "default");

// versions/4.4.3/node_modules/zod/v4/locales/hr.js
var Pg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "znakova", verb: "imati" },
    file: { unit: "bajtova", verb: "imati" },
    array: { unit: "stavki", verb: "imati" },
    set: { unit: "stavki", verb: "imati" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "unos",
    email: "email adresa",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datum i vrijeme",
    date: "ISO datum",
    time: "ISO vrijeme",
    duration: "ISO trajanje",
    ipv4: "IPv4 adresa",
    ipv6: "IPv6 adresa",
    cidrv4: "IPv4 raspon",
    cidrv6: "IPv6 raspon",
    base64: "base64 kodirani tekst",
    base64url: "base64url kodirani tekst",
    json_string: "JSON tekst",
    e164: "E.164 broj",
    jwt: "JWT",
    template_literal: "unos"
  }, o = {
    nan: "NaN",
    string: "tekst",
    number: "broj",
    boolean: "boolean",
    array: "niz",
    object: "objekt",
    set: "skup",
    file: "datoteka",
    date: "datum",
    bigint: "bigint",
    symbol: "simbol",
    undefined: "undefined",
    null: "null",
    function: "funkcija",
    map: "mapa"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Neispravan unos: o\u010Dekuje se instanceof ${r.expected}, a primljeno je ${c}` : `Neispravan unos: o\u010Dekuje se ${i}, a primljeno je ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Neispravna vrijednost: o\u010Dekivano ${y(r.values[0])}` : `Neispravna opcija: o\u010Dekivano jedno od ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin), c = o[r.origin] ?? r.origin;
        return s ? `Preveliko: o\u010Dekivano da ${c ?? "vrijednost"} ima ${i}${r.maximum.toString()} ${s.unit ?? "elemenata"}` : `Preveliko: o\u010Dekivano da ${c ?? "vrijednost"} bude ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin), c = o[r.origin] ?? r.origin;
        return s ? `Premalo: o\u010Dekivano da ${c} ima ${i}${r.minimum.toString()} ${s.unit}` : `Premalo: o\u010Dekivano da ${c} bude ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Neispravan tekst: mora zapo\u010Dinjati s "${i.prefix}"` : i.format === "ends_with" ? `Neispravan tekst: mora zavr\u0161avati s "${i.suffix}"` : i.format === "includes" ? `Neispravan tekst: mora sadr\u017Eavati "${i.includes}"` : i.format === "regex" ? `Neispravan tekst: mora odgovarati uzorku ${i.pattern}` : `Neispravna ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Neispravan broj: mora biti vi\u0161ekratnik od ${r.divisor}`;
      case "unrecognized_keys":
        return `Neprepoznat${r.keys.length > 1 ? "i klju\u010Devi" : " klju\u010D"}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Neispravan klju\u010D u ${o[r.origin] ?? r.origin}`;
      case "invalid_union":
        return "Neispravan unos";
      case "invalid_element":
        return `Neispravna vrijednost u ${o[r.origin] ?? r.origin}`;
      default:
        return "Neispravan unos";
    }
  };
}, "error");
function La() {
  return {
    localeError: Pg()
  };
}
a(La, "default");

// versions/4.4.3/node_modules/zod/v4/locales/hu.js
var Ug = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "karakter", verb: "legyen" },
    file: { unit: "byte", verb: "legyen" },
    array: { unit: "elem", verb: "legyen" },
    set: { unit: "elem", verb: "legyen" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "bemenet",
    email: "email c\xEDm",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO id\u0151b\xE9lyeg",
    date: "ISO d\xE1tum",
    time: "ISO id\u0151",
    duration: "ISO id\u0151intervallum",
    ipv4: "IPv4 c\xEDm",
    ipv6: "IPv6 c\xEDm",
    cidrv4: "IPv4 tartom\xE1ny",
    cidrv6: "IPv6 tartom\xE1ny",
    base64: "base64-k\xF3dolt string",
    base64url: "base64url-k\xF3dolt string",
    json_string: "JSON string",
    e164: "E.164 sz\xE1m",
    jwt: "JWT",
    template_literal: "bemenet"
  }, o = {
    nan: "NaN",
    number: "sz\xE1m",
    array: "t\xF6mb"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `\xC9rv\xE9nytelen bemenet: a v\xE1rt \xE9rt\xE9k instanceof ${r.expected}, a kapott \xE9rt\xE9k ${c}` : `\xC9rv\xE9nytelen bemenet: a v\xE1rt \xE9rt\xE9k ${i}, a kapott \xE9rt\xE9k ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\xC9rv\xE9nytelen bemenet: a v\xE1rt \xE9rt\xE9k ${y(r.values[0])}` : `\xC9rv\xE9nytelen opci\xF3: valamelyik \xE9rt\xE9k v\xE1rt ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `T\xFAl nagy: ${r.origin ?? "\xE9rt\xE9k"} m\xE9rete t\xFAl nagy ${i}${r.maximum.toString()} ${s.unit ?? "elem"}` : `T\xFAl nagy: a bemeneti \xE9rt\xE9k ${r.origin ?? "\xE9rt\xE9k"} t\xFAl nagy: ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `T\xFAl kicsi: a bemeneti \xE9rt\xE9k ${r.origin} m\xE9rete t\xFAl kicsi ${i}${r.minimum.toString()} ${s.unit}` : `T\xFAl kicsi: a bemeneti \xE9rt\xE9k ${r.origin} t\xFAl kicsi ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\xC9rv\xE9nytelen string: "${i.prefix}" \xE9rt\xE9kkel kell kezd\u0151dnie` : i.format === "ends_with" ? `\xC9rv\xE9nytelen string: "${i.suffix}" \xE9rt\xE9kkel kell v\xE9gz\u0151dnie` : i.format === "includes" ? `\xC9rv\xE9nytelen string: "${i.includes}" \xE9rt\xE9ket kell tartalmaznia` : i.format === "regex" ? `\xC9rv\xE9nytelen string: ${i.pattern} mint\xE1nak kell megfelelnie` : `\xC9rv\xE9nytelen ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\xC9rv\xE9nytelen sz\xE1m: ${r.divisor} t\xF6bbsz\xF6r\xF6s\xE9nek kell lennie`;
      case "unrecognized_keys":
        return `Ismeretlen kulcs${r.keys.length > 1 ? "s" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `\xC9rv\xE9nytelen kulcs ${r.origin}`;
      case "invalid_union":
        return "\xC9rv\xE9nytelen bemenet";
      case "invalid_element":
        return `\xC9rv\xE9nytelen \xE9rt\xE9k: ${r.origin}`;
      default:
        return "\xC9rv\xE9nytelen bemenet";
    }
  };
}, "error");
function Ba() {
  return {
    localeError: Ug()
  };
}
a(Ba, "default");

// versions/4.4.3/node_modules/zod/v4/locales/hy.js
function Ql(e, t, n) {
  return Math.abs(e) === 1 ? t : n;
}
a(Ql, "getArmenianPlural");
function gt(e) {
  if (!e)
    return "";
  let t = ["\u0561", "\u0565", "\u0568", "\u056B", "\u0578", "\u0578\u0582", "\u0585"], n = e[e.length - 1];
  return e + (t.includes(n) ? "\u0576" : "\u0568");
}
a(gt, "withDefiniteArticle");
var Dg = /* @__PURE__ */ a(() => {
  let e = {
    string: {
      unit: {
        one: "\u0576\u0577\u0561\u0576",
        many: "\u0576\u0577\u0561\u0576\u0576\u0565\u0580"
      },
      verb: "\u0578\u0582\u0576\u0565\u0576\u0561\u056C"
    },
    file: {
      unit: {
        one: "\u0562\u0561\u0575\u0569",
        many: "\u0562\u0561\u0575\u0569\u0565\u0580"
      },
      verb: "\u0578\u0582\u0576\u0565\u0576\u0561\u056C"
    },
    array: {
      unit: {
        one: "\u057F\u0561\u0580\u0580",
        many: "\u057F\u0561\u0580\u0580\u0565\u0580"
      },
      verb: "\u0578\u0582\u0576\u0565\u0576\u0561\u056C"
    },
    set: {
      unit: {
        one: "\u057F\u0561\u0580\u0580",
        many: "\u057F\u0561\u0580\u0580\u0565\u0580"
      },
      verb: "\u0578\u0582\u0576\u0565\u0576\u0561\u056C"
    }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "\u0574\u0578\u0582\u057F\u0584",
    email: "\u0567\u056C. \u0570\u0561\u057D\u0581\u0565",
    url: "URL",
    emoji: "\u0567\u0574\u0578\u057B\u056B",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0561\u0574\u057D\u0561\u0569\u056B\u057E \u0587 \u056A\u0561\u0574",
    date: "ISO \u0561\u0574\u057D\u0561\u0569\u056B\u057E",
    time: "ISO \u056A\u0561\u0574",
    duration: "ISO \u057F\u0587\u0578\u0572\u0578\u0582\u0569\u0575\u0578\u0582\u0576",
    ipv4: "IPv4 \u0570\u0561\u057D\u0581\u0565",
    ipv6: "IPv6 \u0570\u0561\u057D\u0581\u0565",
    cidrv4: "IPv4 \u0574\u056B\u057B\u0561\u056F\u0561\u0575\u0584",
    cidrv6: "IPv6 \u0574\u056B\u057B\u0561\u056F\u0561\u0575\u0584",
    base64: "base64 \u0571\u0587\u0561\u0579\u0561\u0583\u0578\u057E \u057F\u0578\u0572",
    base64url: "base64url \u0571\u0587\u0561\u0579\u0561\u0583\u0578\u057E \u057F\u0578\u0572",
    json_string: "JSON \u057F\u0578\u0572",
    e164: "E.164 \u0570\u0561\u0574\u0561\u0580",
    jwt: "JWT",
    template_literal: "\u0574\u0578\u0582\u057F\u0584"
  }, o = {
    nan: "NaN",
    number: "\u0569\u056B\u057E",
    array: "\u0566\u0561\u0576\u0563\u057E\u0561\u056E"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567\u0580 instanceof ${r.expected}, \u057D\u057F\u0561\u0581\u057E\u0565\u056C \u0567 ${c}` : `\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567\u0580 ${i}, \u057D\u057F\u0561\u0581\u057E\u0565\u056C \u0567 ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567\u0580 ${y(r.values[1])}` : `\u054D\u056D\u0561\u056C \u057F\u0561\u0580\u0562\u0565\u0580\u0561\u056F\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567\u0580 \u0570\u0565\u057F\u0587\u0575\u0561\u056C\u0576\u0565\u0580\u056B\u0581 \u0574\u0565\u056F\u0568\u055D ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        if (s) {
          let c = Number(r.maximum), u = Ql(c, s.unit.one, s.unit.many);
          return `\u0549\u0561\u0583\u0561\u0566\u0561\u0576\u0581 \u0574\u0565\u056E \u0561\u0580\u056A\u0565\u0584\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567, \u0578\u0580 ${gt(r.origin ?? "\u0561\u0580\u056A\u0565\u0584")} \u056F\u0578\u0582\u0576\u0565\u0576\u0561 ${i}${r.maximum.toString()} ${u}`;
        }
        return `\u0549\u0561\u0583\u0561\u0566\u0561\u0576\u0581 \u0574\u0565\u056E \u0561\u0580\u056A\u0565\u0584\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567, \u0578\u0580 ${gt(r.origin ?? "\u0561\u0580\u056A\u0565\u0584")} \u056C\u056B\u0576\u056B ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        if (s) {
          let c = Number(r.minimum), u = Ql(c, s.unit.one, s.unit.many);
          return `\u0549\u0561\u0583\u0561\u0566\u0561\u0576\u0581 \u0583\u0578\u0584\u0580 \u0561\u0580\u056A\u0565\u0584\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567, \u0578\u0580 ${gt(r.origin)} \u056F\u0578\u0582\u0576\u0565\u0576\u0561 ${i}${r.minimum.toString()} ${u}`;
        }
        return `\u0549\u0561\u0583\u0561\u0566\u0561\u0576\u0581 \u0583\u0578\u0584\u0580 \u0561\u0580\u056A\u0565\u0584\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567, \u0578\u0580 ${gt(r.origin)} \u056C\u056B\u0576\u056B ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u054D\u056D\u0561\u056C \u057F\u0578\u0572\u2024 \u057A\u0565\u057F\u0584 \u0567 \u057D\u056F\u057D\u057E\u056B "${i.prefix}"-\u0578\u057E` : i.format === "ends_with" ? `\u054D\u056D\u0561\u056C \u057F\u0578\u0572\u2024 \u057A\u0565\u057F\u0584 \u0567 \u0561\u057E\u0561\u0580\u057F\u057E\u056B "${i.suffix}"-\u0578\u057E` : i.format === "includes" ? `\u054D\u056D\u0561\u056C \u057F\u0578\u0572\u2024 \u057A\u0565\u057F\u0584 \u0567 \u057A\u0561\u0580\u0578\u0582\u0576\u0561\u056F\u056B "${i.includes}"` : i.format === "regex" ? `\u054D\u056D\u0561\u056C \u057F\u0578\u0572\u2024 \u057A\u0565\u057F\u0584 \u0567 \u0570\u0561\u0574\u0561\u057A\u0561\u057F\u0561\u057D\u056D\u0561\u0576\u056B ${i.pattern} \u0571\u0587\u0561\u0579\u0561\u0583\u056B\u0576` : `\u054D\u056D\u0561\u056C ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u054D\u056D\u0561\u056C \u0569\u056B\u057E\u2024 \u057A\u0565\u057F\u0584 \u0567 \u0562\u0561\u0566\u0574\u0561\u057A\u0561\u057F\u056B\u056F \u056C\u056B\u0576\u056B ${r.divisor}-\u056B`;
      case "unrecognized_keys":
        return `\u0549\u0573\u0561\u0576\u0561\u0579\u057E\u0561\u056E \u0562\u0561\u0576\u0561\u056C\u056B${r.keys.length > 1 ? "\u0576\u0565\u0580" : ""}. ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `\u054D\u056D\u0561\u056C \u0562\u0561\u0576\u0561\u056C\u056B ${gt(r.origin)}-\u0578\u0582\u0574`;
      case "invalid_union":
        return "\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574";
      case "invalid_element":
        return `\u054D\u056D\u0561\u056C \u0561\u0580\u056A\u0565\u0584 ${gt(r.origin)}-\u0578\u0582\u0574`;
      default:
        return "\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574";
    }
  };
}, "error");
function Va() {
  return {
    localeError: Dg()
  };
}
a(Va, "default");

// versions/4.4.3/node_modules/zod/v4/locales/id.js
var Eg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "karakter", verb: "memiliki" },
    file: { unit: "byte", verb: "memiliki" },
    array: { unit: "item", verb: "memiliki" },
    set: { unit: "item", verb: "memiliki" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "input",
    email: "alamat email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "tanggal dan waktu format ISO",
    date: "tanggal format ISO",
    time: "jam format ISO",
    duration: "durasi format ISO",
    ipv4: "alamat IPv4",
    ipv6: "alamat IPv6",
    cidrv4: "rentang alamat IPv4",
    cidrv6: "rentang alamat IPv6",
    base64: "string dengan enkode base64",
    base64url: "string dengan enkode base64url",
    json_string: "string JSON",
    e164: "angka E.164",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Input tidak valid: diharapkan instanceof ${r.expected}, diterima ${c}` : `Input tidak valid: diharapkan ${i}, diterima ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Input tidak valid: diharapkan ${y(r.values[0])}` : `Pilihan tidak valid: diharapkan salah satu dari ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `Terlalu besar: diharapkan ${r.origin ?? "value"} memiliki ${i}${r.maximum.toString()} ${s.unit ?? "elemen"}` : `Terlalu besar: diharapkan ${r.origin ?? "value"} menjadi ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `Terlalu kecil: diharapkan ${r.origin} memiliki ${i}${r.minimum.toString()} ${s.unit}` : `Terlalu kecil: diharapkan ${r.origin} menjadi ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `String tidak valid: harus dimulai dengan "${i.prefix}"` : i.format === "ends_with" ? `String tidak valid: harus berakhir dengan "${i.suffix}"` : i.format === "includes" ? `String tidak valid: harus menyertakan "${i.includes}"` : i.format === "regex" ? `String tidak valid: harus sesuai pola ${i.pattern}` : `${n[i.format] ?? r.format} tidak valid`;
      }
      case "not_multiple_of":
        return `Angka tidak valid: harus kelipatan dari ${r.divisor}`;
      case "unrecognized_keys":
        return `Kunci tidak dikenali ${r.keys.length > 1 ? "s" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Kunci tidak valid di ${r.origin}`;
      case "invalid_union":
        return "Input tidak valid";
      case "invalid_element":
        return `Nilai tidak valid di ${r.origin}`;
      default:
        return "Input tidak valid";
    }
  };
}, "error");
function qa() {
  return {
    localeError: Eg()
  };
}
a(qa, "default");

// versions/4.4.3/node_modules/zod/v4/locales/is.js
var Ng = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "stafi", verb: "a\xF0 hafa" },
    file: { unit: "b\xE6ti", verb: "a\xF0 hafa" },
    array: { unit: "hluti", verb: "a\xF0 hafa" },
    set: { unit: "hluti", verb: "a\xF0 hafa" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "gildi",
    email: "netfang",
    url: "vefsl\xF3\xF0",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO dagsetning og t\xEDmi",
    date: "ISO dagsetning",
    time: "ISO t\xEDmi",
    duration: "ISO t\xEDmalengd",
    ipv4: "IPv4 address",
    ipv6: "IPv6 address",
    cidrv4: "IPv4 range",
    cidrv6: "IPv6 range",
    base64: "base64-encoded strengur",
    base64url: "base64url-encoded strengur",
    json_string: "JSON strengur",
    e164: "E.164 t\xF6lugildi",
    jwt: "JWT",
    template_literal: "gildi"
  }, o = {
    nan: "NaN",
    number: "n\xFAmer",
    array: "fylki"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Rangt gildi: \xDE\xFA sl\xF3st inn ${c} \xFEar sem \xE1 a\xF0 vera instanceof ${r.expected}` : `Rangt gildi: \xDE\xFA sl\xF3st inn ${c} \xFEar sem \xE1 a\xF0 vera ${i}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Rangt gildi: gert r\xE1\xF0 fyrir ${y(r.values[0])}` : `\xD3gilt val: m\xE1 vera eitt af eftirfarandi ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `Of st\xF3rt: gert er r\xE1\xF0 fyrir a\xF0 ${r.origin ?? "gildi"} hafi ${i}${r.maximum.toString()} ${s.unit ?? "hluti"}` : `Of st\xF3rt: gert er r\xE1\xF0 fyrir a\xF0 ${r.origin ?? "gildi"} s\xE9 ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `Of l\xEDti\xF0: gert er r\xE1\xF0 fyrir a\xF0 ${r.origin} hafi ${i}${r.minimum.toString()} ${s.unit}` : `Of l\xEDti\xF0: gert er r\xE1\xF0 fyrir a\xF0 ${r.origin} s\xE9 ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\xD3gildur strengur: ver\xF0ur a\xF0 byrja \xE1 "${i.prefix}"` : i.format === "ends_with" ? `\xD3gildur strengur: ver\xF0ur a\xF0 enda \xE1 "${i.suffix}"` : i.format === "includes" ? `\xD3gildur strengur: ver\xF0ur a\xF0 innihalda "${i.includes}"` : i.format === "regex" ? `\xD3gildur strengur: ver\xF0ur a\xF0 fylgja mynstri ${i.pattern}` : `Rangt ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `R\xF6ng tala: ver\xF0ur a\xF0 vera margfeldi af ${r.divisor}`;
      case "unrecognized_keys":
        return `\xD3\xFEekkt ${r.keys.length > 1 ? "ir lyklar" : "ur lykill"}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Rangur lykill \xED ${r.origin}`;
      case "invalid_union":
        return "Rangt gildi";
      case "invalid_element":
        return `Rangt gildi \xED ${r.origin}`;
      default:
        return "Rangt gildi";
    }
  };
}, "error");
function Ja() {
  return {
    localeError: Ng()
  };
}
a(Ja, "default");

// versions/4.4.3/node_modules/zod/v4/locales/it.js
var Zg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "caratteri", verb: "avere" },
    file: { unit: "byte", verb: "avere" },
    array: { unit: "elementi", verb: "avere" },
    set: { unit: "elementi", verb: "avere" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "input",
    email: "indirizzo email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "data e ora ISO",
    date: "data ISO",
    time: "ora ISO",
    duration: "durata ISO",
    ipv4: "indirizzo IPv4",
    ipv6: "indirizzo IPv6",
    cidrv4: "intervallo IPv4",
    cidrv6: "intervallo IPv6",
    base64: "stringa codificata in base64",
    base64url: "URL codificata in base64",
    json_string: "stringa JSON",
    e164: "numero E.164",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN",
    number: "numero",
    array: "vettore"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Input non valido: atteso instanceof ${r.expected}, ricevuto ${c}` : `Input non valido: atteso ${i}, ricevuto ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Input non valido: atteso ${y(r.values[0])}` : `Opzione non valida: atteso uno tra ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `Troppo grande: ${r.origin ?? "valore"} deve avere ${i}${r.maximum.toString()} ${s.unit ?? "elementi"}` : `Troppo grande: ${r.origin ?? "valore"} deve essere ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `Troppo piccolo: ${r.origin} deve avere ${i}${r.minimum.toString()} ${s.unit}` : `Troppo piccolo: ${r.origin} deve essere ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Stringa non valida: deve iniziare con "${i.prefix}"` : i.format === "ends_with" ? `Stringa non valida: deve terminare con "${i.suffix}"` : i.format === "includes" ? `Stringa non valida: deve includere "${i.includes}"` : i.format === "regex" ? `Stringa non valida: deve corrispondere al pattern ${i.pattern}` : `Input non valido: ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Numero non valido: deve essere un multiplo di ${r.divisor}`;
      case "unrecognized_keys":
        return `Chiav${r.keys.length > 1 ? "i" : "e"} non riconosciut${r.keys.length > 1 ? "e" : "a"}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Chiave non valida in ${r.origin}`;
      case "invalid_union":
        return "Input non valido";
      case "invalid_element":
        return `Valore non valido in ${r.origin}`;
      default:
        return "Input non valido";
    }
  };
}, "error");
function Wa() {
  return {
    localeError: Zg()
  };
}
a(Wa, "default");

// versions/4.4.3/node_modules/zod/v4/locales/ja.js
var Ag = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "\u6587\u5B57", verb: "\u3067\u3042\u308B" },
    file: { unit: "\u30D0\u30A4\u30C8", verb: "\u3067\u3042\u308B" },
    array: { unit: "\u8981\u7D20", verb: "\u3067\u3042\u308B" },
    set: { unit: "\u8981\u7D20", verb: "\u3067\u3042\u308B" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "\u5165\u529B\u5024",
    email: "\u30E1\u30FC\u30EB\u30A2\u30C9\u30EC\u30B9",
    url: "URL",
    emoji: "\u7D75\u6587\u5B57",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO\u65E5\u6642",
    date: "ISO\u65E5\u4ED8",
    time: "ISO\u6642\u523B",
    duration: "ISO\u671F\u9593",
    ipv4: "IPv4\u30A2\u30C9\u30EC\u30B9",
    ipv6: "IPv6\u30A2\u30C9\u30EC\u30B9",
    cidrv4: "IPv4\u7BC4\u56F2",
    cidrv6: "IPv6\u7BC4\u56F2",
    base64: "base64\u30A8\u30F3\u30B3\u30FC\u30C9\u6587\u5B57\u5217",
    base64url: "base64url\u30A8\u30F3\u30B3\u30FC\u30C9\u6587\u5B57\u5217",
    json_string: "JSON\u6587\u5B57\u5217",
    e164: "E.164\u756A\u53F7",
    jwt: "JWT",
    template_literal: "\u5165\u529B\u5024"
  }, o = {
    nan: "NaN",
    number: "\u6570\u5024",
    array: "\u914D\u5217"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `\u7121\u52B9\u306A\u5165\u529B: instanceof ${r.expected}\u304C\u671F\u5F85\u3055\u308C\u307E\u3057\u305F\u304C\u3001${c}\u304C\u5165\u529B\u3055\u308C\u307E\u3057\u305F` : `\u7121\u52B9\u306A\u5165\u529B: ${i}\u304C\u671F\u5F85\u3055\u308C\u307E\u3057\u305F\u304C\u3001${c}\u304C\u5165\u529B\u3055\u308C\u307E\u3057\u305F`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u7121\u52B9\u306A\u5165\u529B: ${y(r.values[0])}\u304C\u671F\u5F85\u3055\u308C\u307E\u3057\u305F` : `\u7121\u52B9\u306A\u9078\u629E: ${p(r.values, "\u3001")}\u306E\u3044\u305A\u308C\u304B\u3067\u3042\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`;
      case "too_big": {
        let i = r.inclusive ? "\u4EE5\u4E0B\u3067\u3042\u308B" : "\u3088\u308A\u5C0F\u3055\u3044", s = t(r.origin);
        return s ? `\u5927\u304D\u3059\u304E\u308B\u5024: ${r.origin ?? "\u5024"}\u306F${r.maximum.toString()}${s.unit ?? "\u8981\u7D20"}${i}\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : `\u5927\u304D\u3059\u304E\u308B\u5024: ${r.origin ?? "\u5024"}\u306F${r.maximum.toString()}${i}\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`;
      }
      case "too_small": {
        let i = r.inclusive ? "\u4EE5\u4E0A\u3067\u3042\u308B" : "\u3088\u308A\u5927\u304D\u3044", s = t(r.origin);
        return s ? `\u5C0F\u3055\u3059\u304E\u308B\u5024: ${r.origin}\u306F${r.minimum.toString()}${s.unit}${i}\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : `\u5C0F\u3055\u3059\u304E\u308B\u5024: ${r.origin}\u306F${r.minimum.toString()}${i}\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u7121\u52B9\u306A\u6587\u5B57\u5217: "${i.prefix}"\u3067\u59CB\u307E\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : i.format === "ends_with" ? `\u7121\u52B9\u306A\u6587\u5B57\u5217: "${i.suffix}"\u3067\u7D42\u308F\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : i.format === "includes" ? `\u7121\u52B9\u306A\u6587\u5B57\u5217: "${i.includes}"\u3092\u542B\u3080\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : i.format === "regex" ? `\u7121\u52B9\u306A\u6587\u5B57\u5217: \u30D1\u30BF\u30FC\u30F3${i.pattern}\u306B\u4E00\u81F4\u3059\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : `\u7121\u52B9\u306A${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u7121\u52B9\u306A\u6570\u5024: ${r.divisor}\u306E\u500D\u6570\u3067\u3042\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`;
      case "unrecognized_keys":
        return `\u8A8D\u8B58\u3055\u308C\u3066\u3044\u306A\u3044\u30AD\u30FC${r.keys.length > 1 ? "\u7FA4" : ""}: ${p(r.keys, "\u3001")}`;
      case "invalid_key":
        return `${r.origin}\u5185\u306E\u7121\u52B9\u306A\u30AD\u30FC`;
      case "invalid_union":
        return "\u7121\u52B9\u306A\u5165\u529B";
      case "invalid_element":
        return `${r.origin}\u5185\u306E\u7121\u52B9\u306A\u5024`;
      default:
        return "\u7121\u52B9\u306A\u5165\u529B";
    }
  };
}, "error");
function Ka() {
  return {
    localeError: Ag()
  };
}
a(Ka, "default");

// versions/4.4.3/node_modules/zod/v4/locales/ka.js
var Cg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "\u10E1\u10D8\u10DB\u10D1\u10DD\u10DA\u10DD", verb: "\u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1" },
    file: { unit: "\u10D1\u10D0\u10D8\u10E2\u10D8", verb: "\u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1" },
    array: { unit: "\u10D4\u10DA\u10D4\u10DB\u10D4\u10DC\u10E2\u10D8", verb: "\u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1" },
    set: { unit: "\u10D4\u10DA\u10D4\u10DB\u10D4\u10DC\u10E2\u10D8", verb: "\u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "\u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0",
    email: "\u10D4\u10DA-\u10E4\u10DD\u10E1\u10E2\u10D8\u10E1 \u10DB\u10D8\u10E1\u10D0\u10DB\u10D0\u10E0\u10D7\u10D8",
    url: "URL",
    emoji: "\u10D4\u10DB\u10DD\u10EF\u10D8",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u10D7\u10D0\u10E0\u10D8\u10E6\u10D8-\u10D3\u10E0\u10DD",
    date: "\u10D7\u10D0\u10E0\u10D8\u10E6\u10D8",
    time: "\u10D3\u10E0\u10DD",
    duration: "\u10EE\u10D0\u10DC\u10D2\u10E0\u10EB\u10DA\u10D8\u10D5\u10DD\u10D1\u10D0",
    ipv4: "IPv4 \u10DB\u10D8\u10E1\u10D0\u10DB\u10D0\u10E0\u10D7\u10D8",
    ipv6: "IPv6 \u10DB\u10D8\u10E1\u10D0\u10DB\u10D0\u10E0\u10D7\u10D8",
    cidrv4: "IPv4 \u10D3\u10D8\u10D0\u10DE\u10D0\u10D6\u10DD\u10DC\u10D8",
    cidrv6: "IPv6 \u10D3\u10D8\u10D0\u10DE\u10D0\u10D6\u10DD\u10DC\u10D8",
    base64: "base64-\u10D9\u10DD\u10D3\u10D8\u10E0\u10D4\u10D1\u10E3\u10DA\u10D8 \u10D5\u10D4\u10DA\u10D8",
    base64url: "base64url-\u10D9\u10DD\u10D3\u10D8\u10E0\u10D4\u10D1\u10E3\u10DA\u10D8 \u10D5\u10D4\u10DA\u10D8",
    json_string: "JSON \u10D5\u10D4\u10DA\u10D8",
    e164: "E.164 \u10DC\u10DD\u10DB\u10D4\u10E0\u10D8",
    jwt: "JWT",
    template_literal: "\u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0"
  }, o = {
    nan: "NaN",
    number: "\u10E0\u10D8\u10EA\u10EE\u10D5\u10D8",
    string: "\u10D5\u10D4\u10DA\u10D8",
    boolean: "\u10D1\u10E3\u10DA\u10D4\u10D0\u10DC\u10D8",
    function: "\u10E4\u10E3\u10DC\u10E5\u10EA\u10D8\u10D0",
    array: "\u10DB\u10D0\u10E1\u10D8\u10D5\u10D8"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 instanceof ${r.expected}, \u10DB\u10D8\u10E6\u10D4\u10D1\u10E3\u10DA\u10D8 ${c}` : `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${i}, \u10DB\u10D8\u10E6\u10D4\u10D1\u10E3\u10DA\u10D8 ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${y(r.values[0])}` : `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D5\u10D0\u10E0\u10D8\u10D0\u10DC\u10E2\u10D8: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8\u10D0 \u10D4\u10E0\u10D7-\u10D4\u10E0\u10D7\u10D8 ${p(r.values, "|")}-\u10D3\u10D0\u10DC`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `\u10D6\u10D4\u10D3\u10DB\u10D4\u10E2\u10D0\u10D3 \u10D3\u10D8\u10D3\u10D8: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${r.origin ?? "\u10DB\u10DC\u10D8\u10E8\u10D5\u10DC\u10D4\u10DA\u10DD\u10D1\u10D0"} ${s.verb} ${i}${r.maximum.toString()} ${s.unit}` : `\u10D6\u10D4\u10D3\u10DB\u10D4\u10E2\u10D0\u10D3 \u10D3\u10D8\u10D3\u10D8: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${r.origin ?? "\u10DB\u10DC\u10D8\u10E8\u10D5\u10DC\u10D4\u10DA\u10DD\u10D1\u10D0"} \u10D8\u10E7\u10DD\u10E1 ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `\u10D6\u10D4\u10D3\u10DB\u10D4\u10E2\u10D0\u10D3 \u10DE\u10D0\u10E2\u10D0\u10E0\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${r.origin} ${s.verb} ${i}${r.minimum.toString()} ${s.unit}` : `\u10D6\u10D4\u10D3\u10DB\u10D4\u10E2\u10D0\u10D3 \u10DE\u10D0\u10E2\u10D0\u10E0\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${r.origin} \u10D8\u10E7\u10DD\u10E1 ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D5\u10D4\u10DA\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10D8\u10EC\u10E7\u10D4\u10D1\u10DD\u10D3\u10D4\u10E1 "${i.prefix}"-\u10D8\u10D7` : i.format === "ends_with" ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D5\u10D4\u10DA\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10DB\u10D7\u10D0\u10D5\u10E0\u10D3\u10D4\u10D1\u10DD\u10D3\u10D4\u10E1 "${i.suffix}"-\u10D8\u10D7` : i.format === "includes" ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D5\u10D4\u10DA\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1 "${i.includes}"-\u10E1` : i.format === "regex" ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D5\u10D4\u10DA\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D4\u10E1\u10D0\u10D1\u10D0\u10DB\u10D4\u10D1\u10DD\u10D3\u10D4\u10E1 \u10E8\u10D0\u10D1\u10DA\u10DD\u10DC\u10E1 ${i.pattern}` : `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E0\u10D8\u10EA\u10EE\u10D5\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10D8\u10E7\u10DD\u10E1 ${r.divisor}-\u10D8\u10E1 \u10EF\u10D4\u10E0\u10D0\u10D3\u10D8`;
      case "unrecognized_keys":
        return `\u10E3\u10EA\u10DC\u10DD\u10D1\u10D8 \u10D2\u10D0\u10E1\u10D0\u10E6\u10D4\u10D1${r.keys.length > 1 ? "\u10D4\u10D1\u10D8" : "\u10D8"}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D2\u10D0\u10E1\u10D0\u10E6\u10D4\u10D1\u10D8 ${r.origin}-\u10E8\u10D8`;
      case "invalid_union":
        return "\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0";
      case "invalid_element":
        return `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10DB\u10DC\u10D8\u10E8\u10D5\u10DC\u10D4\u10DA\u10DD\u10D1\u10D0 ${r.origin}-\u10E8\u10D8`;
      default:
        return "\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0";
    }
  };
}, "error");
function Ga() {
  return {
    localeError: Cg()
  };
}
a(Ga, "default");

// versions/4.4.3/node_modules/zod/v4/locales/km.js
var Rg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "\u178F\u17BD\u17A2\u1780\u17D2\u179F\u179A", verb: "\u1782\u17BD\u179A\u1798\u17B6\u1793" },
    file: { unit: "\u1794\u17C3", verb: "\u1782\u17BD\u179A\u1798\u17B6\u1793" },
    array: { unit: "\u1792\u17B6\u178F\u17BB", verb: "\u1782\u17BD\u179A\u1798\u17B6\u1793" },
    set: { unit: "\u1792\u17B6\u178F\u17BB", verb: "\u1782\u17BD\u179A\u1798\u17B6\u1793" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B",
    email: "\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793\u17A2\u17CA\u17B8\u1798\u17C2\u179B",
    url: "URL",
    emoji: "\u179F\u1789\u17D2\u1789\u17B6\u17A2\u17B6\u179A\u1798\u17D2\u1798\u178E\u17CD",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u1780\u17B6\u179B\u1794\u179A\u17B7\u1785\u17D2\u1786\u17C1\u1791 \u1793\u17B7\u1784\u1798\u17C9\u17C4\u1784 ISO",
    date: "\u1780\u17B6\u179B\u1794\u179A\u17B7\u1785\u17D2\u1786\u17C1\u1791 ISO",
    time: "\u1798\u17C9\u17C4\u1784 ISO",
    duration: "\u179A\u1799\u17C8\u1796\u17C1\u179B ISO",
    ipv4: "\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793 IPv4",
    ipv6: "\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793 IPv6",
    cidrv4: "\u178A\u17C2\u1793\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793 IPv4",
    cidrv6: "\u178A\u17C2\u1793\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793 IPv6",
    base64: "\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u17A2\u17CA\u17B7\u1780\u17BC\u178A base64",
    base64url: "\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u17A2\u17CA\u17B7\u1780\u17BC\u178A base64url",
    json_string: "\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A JSON",
    e164: "\u179B\u17C1\u1781 E.164",
    jwt: "JWT",
    template_literal: "\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B"
  }, o = {
    nan: "NaN",
    number: "\u179B\u17C1\u1781",
    array: "\u17A2\u17B6\u179A\u17C1 (Array)",
    null: "\u1782\u17D2\u1798\u17B6\u1793\u178F\u1798\u17D2\u179B\u17C3 (null)"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A instanceof ${r.expected} \u1794\u17C9\u17BB\u1793\u17D2\u178F\u17C2\u1791\u1791\u17BD\u179B\u1794\u17B6\u1793 ${c}` : `\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${i} \u1794\u17C9\u17BB\u1793\u17D2\u178F\u17C2\u1791\u1791\u17BD\u179B\u1794\u17B6\u1793 ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${y(r.values[0])}` : `\u1787\u1798\u17D2\u179A\u17BE\u179F\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1787\u17B6\u1798\u17BD\u1799\u1780\u17D2\u1793\u17BB\u1784\u1785\u17C6\u178E\u17C4\u1798 ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `\u1792\u17C6\u1796\u17C1\u1780\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${r.origin ?? "\u178F\u1798\u17D2\u179B\u17C3"} ${i} ${r.maximum.toString()} ${s.unit ?? "\u1792\u17B6\u178F\u17BB"}` : `\u1792\u17C6\u1796\u17C1\u1780\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${r.origin ?? "\u178F\u1798\u17D2\u179B\u17C3"} ${i} ${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `\u178F\u17BC\u1785\u1796\u17C1\u1780\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${r.origin} ${i} ${r.minimum.toString()} ${s.unit}` : `\u178F\u17BC\u1785\u1796\u17C1\u1780\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${r.origin} ${i} ${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1785\u17B6\u1794\u17CB\u1795\u17D2\u178F\u17BE\u1798\u178A\u17C4\u1799 "${i.prefix}"` : i.format === "ends_with" ? `\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1794\u1789\u17D2\u1785\u1794\u17CB\u178A\u17C4\u1799 "${i.suffix}"` : i.format === "includes" ? `\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1798\u17B6\u1793 "${i.includes}"` : i.format === "regex" ? `\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u178F\u17C2\u1795\u17D2\u1782\u17BC\u1795\u17D2\u1782\u1784\u1793\u17B9\u1784\u1791\u1798\u17D2\u179A\u1784\u17CB\u178A\u17C2\u179B\u1794\u17B6\u1793\u1780\u17C6\u178E\u178F\u17CB ${i.pattern}` : `\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u179B\u17C1\u1781\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u178F\u17C2\u1787\u17B6\u1796\u17A0\u17BB\u1782\u17BB\u178E\u1793\u17C3 ${r.divisor}`;
      case "unrecognized_keys":
        return `\u179A\u1780\u1783\u17BE\u1789\u179F\u17C4\u1798\u17B7\u1793\u179F\u17D2\u1782\u17B6\u179B\u17CB\u17D6 ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `\u179F\u17C4\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u1793\u17C5\u1780\u17D2\u1793\u17BB\u1784 ${r.origin}`;
      case "invalid_union":
        return "\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C";
      case "invalid_element":
        return `\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u1793\u17C5\u1780\u17D2\u1793\u17BB\u1784 ${r.origin}`;
      default:
        return "\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C";
    }
  };
}, "error");
function Bt() {
  return {
    localeError: Rg()
  };
}
a(Bt, "default");

// versions/4.4.3/node_modules/zod/v4/locales/kh.js
function Xa() {
  return Bt();
}
a(Xa, "default");

// versions/4.4.3/node_modules/zod/v4/locales/ko.js
var Fg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "\uBB38\uC790", verb: "to have" },
    file: { unit: "\uBC14\uC774\uD2B8", verb: "to have" },
    array: { unit: "\uAC1C", verb: "to have" },
    set: { unit: "\uAC1C", verb: "to have" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "\uC785\uB825",
    email: "\uC774\uBA54\uC77C \uC8FC\uC18C",
    url: "URL",
    emoji: "\uC774\uBAA8\uC9C0",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \uB0A0\uC9DC\uC2DC\uAC04",
    date: "ISO \uB0A0\uC9DC",
    time: "ISO \uC2DC\uAC04",
    duration: "ISO \uAE30\uAC04",
    ipv4: "IPv4 \uC8FC\uC18C",
    ipv6: "IPv6 \uC8FC\uC18C",
    cidrv4: "IPv4 \uBC94\uC704",
    cidrv6: "IPv6 \uBC94\uC704",
    base64: "base64 \uC778\uCF54\uB529 \uBB38\uC790\uC5F4",
    base64url: "base64url \uC778\uCF54\uB529 \uBB38\uC790\uC5F4",
    json_string: "JSON \uBB38\uC790\uC5F4",
    e164: "E.164 \uBC88\uD638",
    jwt: "JWT",
    template_literal: "\uC785\uB825"
  }, o = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `\uC798\uBABB\uB41C \uC785\uB825: \uC608\uC0C1 \uD0C0\uC785\uC740 instanceof ${r.expected}, \uBC1B\uC740 \uD0C0\uC785\uC740 ${c}\uC785\uB2C8\uB2E4` : `\uC798\uBABB\uB41C \uC785\uB825: \uC608\uC0C1 \uD0C0\uC785\uC740 ${i}, \uBC1B\uC740 \uD0C0\uC785\uC740 ${c}\uC785\uB2C8\uB2E4`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\uC798\uBABB\uB41C \uC785\uB825: \uAC12\uC740 ${y(r.values[0])} \uC774\uC5B4\uC57C \uD569\uB2C8\uB2E4` : `\uC798\uBABB\uB41C \uC635\uC158: ${p(r.values, "\uB610\uB294 ")} \uC911 \uD558\uB098\uC5EC\uC57C \uD569\uB2C8\uB2E4`;
      case "too_big": {
        let i = r.inclusive ? "\uC774\uD558" : "\uBBF8\uB9CC", s = i === "\uBBF8\uB9CC" ? "\uC774\uC5B4\uC57C \uD569\uB2C8\uB2E4" : "\uC5EC\uC57C \uD569\uB2C8\uB2E4", c = t(r.origin), u = c?.unit ?? "\uC694\uC18C";
        return c ? `${r.origin ?? "\uAC12"}\uC774 \uB108\uBB34 \uD07D\uB2C8\uB2E4: ${r.maximum.toString()}${u} ${i}${s}` : `${r.origin ?? "\uAC12"}\uC774 \uB108\uBB34 \uD07D\uB2C8\uB2E4: ${r.maximum.toString()} ${i}${s}`;
      }
      case "too_small": {
        let i = r.inclusive ? "\uC774\uC0C1" : "\uCD08\uACFC", s = i === "\uC774\uC0C1" ? "\uC774\uC5B4\uC57C \uD569\uB2C8\uB2E4" : "\uC5EC\uC57C \uD569\uB2C8\uB2E4", c = t(r.origin), u = c?.unit ?? "\uC694\uC18C";
        return c ? `${r.origin ?? "\uAC12"}\uC774 \uB108\uBB34 \uC791\uC2B5\uB2C8\uB2E4: ${r.minimum.toString()}${u} ${i}${s}` : `${r.origin ?? "\uAC12"}\uC774 \uB108\uBB34 \uC791\uC2B5\uB2C8\uB2E4: ${r.minimum.toString()} ${i}${s}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\uC798\uBABB\uB41C \uBB38\uC790\uC5F4: "${i.prefix}"(\uC73C)\uB85C \uC2DC\uC791\uD574\uC57C \uD569\uB2C8\uB2E4` : i.format === "ends_with" ? `\uC798\uBABB\uB41C \uBB38\uC790\uC5F4: "${i.suffix}"(\uC73C)\uB85C \uB05D\uB098\uC57C \uD569\uB2C8\uB2E4` : i.format === "includes" ? `\uC798\uBABB\uB41C \uBB38\uC790\uC5F4: "${i.includes}"\uC744(\uB97C) \uD3EC\uD568\uD574\uC57C \uD569\uB2C8\uB2E4` : i.format === "regex" ? `\uC798\uBABB\uB41C \uBB38\uC790\uC5F4: \uC815\uADDC\uC2DD ${i.pattern} \uD328\uD134\uACFC \uC77C\uCE58\uD574\uC57C \uD569\uB2C8\uB2E4` : `\uC798\uBABB\uB41C ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\uC798\uBABB\uB41C \uC22B\uC790: ${r.divisor}\uC758 \uBC30\uC218\uC5EC\uC57C \uD569\uB2C8\uB2E4`;
      case "unrecognized_keys":
        return `\uC778\uC2DD\uD560 \uC218 \uC5C6\uB294 \uD0A4: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `\uC798\uBABB\uB41C \uD0A4: ${r.origin}`;
      case "invalid_union":
        return "\uC798\uBABB\uB41C \uC785\uB825";
      case "invalid_element":
        return `\uC798\uBABB\uB41C \uAC12: ${r.origin}`;
      default:
        return "\uC798\uBABB\uB41C \uC785\uB825";
    }
  };
}, "error");
function Ha() {
  return {
    localeError: Fg()
  };
}
a(Ha, "default");

// versions/4.4.3/node_modules/zod/v4/locales/lt.js
var Vt = /* @__PURE__ */ a((e) => e.charAt(0).toUpperCase() + e.slice(1), "capitalizeFirstCharacter");
function Yl(e) {
  let t = Math.abs(e), n = t % 10, o = t % 100;
  return o >= 11 && o <= 19 || n === 0 ? "many" : n === 1 ? "one" : "few";
}
a(Yl, "getUnitTypeFromNumber");
var Mg = /* @__PURE__ */ a(() => {
  let e = {
    string: {
      unit: {
        one: "simbolis",
        few: "simboliai",
        many: "simboli\u0173"
      },
      verb: {
        smaller: {
          inclusive: "turi b\u016Bti ne ilgesn\u0117 kaip",
          notInclusive: "turi b\u016Bti trumpesn\u0117 kaip"
        },
        bigger: {
          inclusive: "turi b\u016Bti ne trumpesn\u0117 kaip",
          notInclusive: "turi b\u016Bti ilgesn\u0117 kaip"
        }
      }
    },
    file: {
      unit: {
        one: "baitas",
        few: "baitai",
        many: "bait\u0173"
      },
      verb: {
        smaller: {
          inclusive: "turi b\u016Bti ne didesnis kaip",
          notInclusive: "turi b\u016Bti ma\u017Eesnis kaip"
        },
        bigger: {
          inclusive: "turi b\u016Bti ne ma\u017Eesnis kaip",
          notInclusive: "turi b\u016Bti didesnis kaip"
        }
      }
    },
    array: {
      unit: {
        one: "element\u0105",
        few: "elementus",
        many: "element\u0173"
      },
      verb: {
        smaller: {
          inclusive: "turi tur\u0117ti ne daugiau kaip",
          notInclusive: "turi tur\u0117ti ma\u017Eiau kaip"
        },
        bigger: {
          inclusive: "turi tur\u0117ti ne ma\u017Eiau kaip",
          notInclusive: "turi tur\u0117ti daugiau kaip"
        }
      }
    },
    set: {
      unit: {
        one: "element\u0105",
        few: "elementus",
        many: "element\u0173"
      },
      verb: {
        smaller: {
          inclusive: "turi tur\u0117ti ne daugiau kaip",
          notInclusive: "turi tur\u0117ti ma\u017Eiau kaip"
        },
        bigger: {
          inclusive: "turi tur\u0117ti ne ma\u017Eiau kaip",
          notInclusive: "turi tur\u0117ti daugiau kaip"
        }
      }
    }
  };
  function t(r, i, s, c) {
    let u = e[r] ?? null;
    return u === null ? u : {
      unit: u.unit[i],
      verb: u.verb[c][s ? "inclusive" : "notInclusive"]
    };
  }
  a(t, "getSizing");
  let n = {
    regex: "\u012Fvestis",
    email: "el. pa\u0161to adresas",
    url: "URL",
    emoji: "jaustukas",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO data ir laikas",
    date: "ISO data",
    time: "ISO laikas",
    duration: "ISO trukm\u0117",
    ipv4: "IPv4 adresas",
    ipv6: "IPv6 adresas",
    cidrv4: "IPv4 tinklo prefiksas (CIDR)",
    cidrv6: "IPv6 tinklo prefiksas (CIDR)",
    base64: "base64 u\u017Ekoduota eilut\u0117",
    base64url: "base64url u\u017Ekoduota eilut\u0117",
    json_string: "JSON eilut\u0117",
    e164: "E.164 numeris",
    jwt: "JWT",
    template_literal: "\u012Fvestis"
  }, o = {
    nan: "NaN",
    number: "skai\u010Dius",
    bigint: "sveikasis skai\u010Dius",
    string: "eilut\u0117",
    boolean: "login\u0117 reik\u0161m\u0117",
    undefined: "neapibr\u0117\u017Eta reik\u0161m\u0117",
    function: "funkcija",
    symbol: "simbolis",
    array: "masyvas",
    object: "objektas",
    null: "nulin\u0117 reik\u0161m\u0117"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Gautas tipas ${c}, o tik\u0117tasi - instanceof ${r.expected}` : `Gautas tipas ${c}, o tik\u0117tasi - ${i}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Privalo b\u016Bti ${y(r.values[0])}` : `Privalo b\u016Bti vienas i\u0161 ${p(r.values, "|")} pasirinkim\u0173`;
      case "too_big": {
        let i = o[r.origin] ?? r.origin, s = t(r.origin, Yl(Number(r.maximum)), r.inclusive ?? !1, "smaller");
        if (s?.verb)
          return `${Vt(i ?? r.origin ?? "reik\u0161m\u0117")} ${s.verb} ${r.maximum.toString()} ${s.unit ?? "element\u0173"}`;
        let c = r.inclusive ? "ne didesnis kaip" : "ma\u017Eesnis kaip";
        return `${Vt(i ?? r.origin ?? "reik\u0161m\u0117")} turi b\u016Bti ${c} ${r.maximum.toString()} ${s?.unit}`;
      }
      case "too_small": {
        let i = o[r.origin] ?? r.origin, s = t(r.origin, Yl(Number(r.minimum)), r.inclusive ?? !1, "bigger");
        if (s?.verb)
          return `${Vt(i ?? r.origin ?? "reik\u0161m\u0117")} ${s.verb} ${r.minimum.toString()} ${s.unit ?? "element\u0173"}`;
        let c = r.inclusive ? "ne ma\u017Eesnis kaip" : "didesnis kaip";
        return `${Vt(i ?? r.origin ?? "reik\u0161m\u0117")} turi b\u016Bti ${c} ${r.minimum.toString()} ${s?.unit}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Eilut\u0117 privalo prasid\u0117ti "${i.prefix}"` : i.format === "ends_with" ? `Eilut\u0117 privalo pasibaigti "${i.suffix}"` : i.format === "includes" ? `Eilut\u0117 privalo \u012Ftraukti "${i.includes}"` : i.format === "regex" ? `Eilut\u0117 privalo atitikti ${i.pattern}` : `Neteisingas ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Skai\u010Dius privalo b\u016Bti ${r.divisor} kartotinis.`;
      case "unrecognized_keys":
        return `Neatpa\u017Eint${r.keys.length > 1 ? "i" : "as"} rakt${r.keys.length > 1 ? "ai" : "as"}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return "Rastas klaidingas raktas";
      case "invalid_union":
        return "Klaidinga \u012Fvestis";
      case "invalid_element": {
        let i = o[r.origin] ?? r.origin;
        return `${Vt(i ?? r.origin ?? "reik\u0161m\u0117")} turi klaiding\u0105 \u012Fvest\u012F`;
      }
      default:
        return "Klaidinga \u012Fvestis";
    }
  };
}, "error");
function Qa() {
  return {
    localeError: Mg()
  };
}
a(Qa, "default");

// versions/4.4.3/node_modules/zod/v4/locales/mk.js
var Lg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "\u0437\u043D\u0430\u0446\u0438", verb: "\u0434\u0430 \u0438\u043C\u0430\u0430\u0442" },
    file: { unit: "\u0431\u0430\u0458\u0442\u0438", verb: "\u0434\u0430 \u0438\u043C\u0430\u0430\u0442" },
    array: { unit: "\u0441\u0442\u0430\u0432\u043A\u0438", verb: "\u0434\u0430 \u0438\u043C\u0430\u0430\u0442" },
    set: { unit: "\u0441\u0442\u0430\u0432\u043A\u0438", verb: "\u0434\u0430 \u0438\u043C\u0430\u0430\u0442" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "\u0432\u043D\u0435\u0441",
    email: "\u0430\u0434\u0440\u0435\u0441\u0430 \u043D\u0430 \u0435-\u043F\u043E\u0448\u0442\u0430",
    url: "URL",
    emoji: "\u0435\u043C\u043E\u045F\u0438",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0434\u0430\u0442\u0443\u043C \u0438 \u0432\u0440\u0435\u043C\u0435",
    date: "ISO \u0434\u0430\u0442\u0443\u043C",
    time: "ISO \u0432\u0440\u0435\u043C\u0435",
    duration: "ISO \u0432\u0440\u0435\u043C\u0435\u0442\u0440\u0430\u0435\u045A\u0435",
    ipv4: "IPv4 \u0430\u0434\u0440\u0435\u0441\u0430",
    ipv6: "IPv6 \u0430\u0434\u0440\u0435\u0441\u0430",
    cidrv4: "IPv4 \u043E\u043F\u0441\u0435\u0433",
    cidrv6: "IPv6 \u043E\u043F\u0441\u0435\u0433",
    base64: "base64-\u0435\u043D\u043A\u043E\u0434\u0438\u0440\u0430\u043D\u0430 \u043D\u0438\u0437\u0430",
    base64url: "base64url-\u0435\u043D\u043A\u043E\u0434\u0438\u0440\u0430\u043D\u0430 \u043D\u0438\u0437\u0430",
    json_string: "JSON \u043D\u0438\u0437\u0430",
    e164: "E.164 \u0431\u0440\u043E\u0458",
    jwt: "JWT",
    template_literal: "\u0432\u043D\u0435\u0441"
  }, o = {
    nan: "NaN",
    number: "\u0431\u0440\u043E\u0458",
    array: "\u043D\u0438\u0437\u0430"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `\u0413\u0440\u0435\u0448\u0435\u043D \u0432\u043D\u0435\u0441: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 instanceof ${r.expected}, \u043F\u0440\u0438\u043C\u0435\u043D\u043E ${c}` : `\u0413\u0440\u0435\u0448\u0435\u043D \u0432\u043D\u0435\u0441: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${i}, \u043F\u0440\u0438\u043C\u0435\u043D\u043E ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Invalid input: expected ${y(r.values[0])}` : `\u0413\u0440\u0435\u0448\u0430\u043D\u0430 \u043E\u043F\u0446\u0438\u0458\u0430: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 \u0435\u0434\u043D\u0430 ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `\u041F\u0440\u0435\u043C\u043D\u043E\u0433\u0443 \u0433\u043E\u043B\u0435\u043C: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${r.origin ?? "\u0432\u0440\u0435\u0434\u043D\u043E\u0441\u0442\u0430"} \u0434\u0430 \u0438\u043C\u0430 ${i}${r.maximum.toString()} ${s.unit ?? "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0438"}` : `\u041F\u0440\u0435\u043C\u043D\u043E\u0433\u0443 \u0433\u043E\u043B\u0435\u043C: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${r.origin ?? "\u0432\u0440\u0435\u0434\u043D\u043E\u0441\u0442\u0430"} \u0434\u0430 \u0431\u0438\u0434\u0435 ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `\u041F\u0440\u0435\u043C\u043D\u043E\u0433\u0443 \u043C\u0430\u043B: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${r.origin} \u0434\u0430 \u0438\u043C\u0430 ${i}${r.minimum.toString()} ${s.unit}` : `\u041F\u0440\u0435\u043C\u043D\u043E\u0433\u0443 \u043C\u0430\u043B: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${r.origin} \u0434\u0430 \u0431\u0438\u0434\u0435 ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u041D\u0435\u0432\u0430\u0436\u0435\u0447\u043A\u0430 \u043D\u0438\u0437\u0430: \u043C\u043E\u0440\u0430 \u0434\u0430 \u0437\u0430\u043F\u043E\u0447\u043D\u0443\u0432\u0430 \u0441\u043E "${i.prefix}"` : i.format === "ends_with" ? `\u041D\u0435\u0432\u0430\u0436\u0435\u0447\u043A\u0430 \u043D\u0438\u0437\u0430: \u043C\u043E\u0440\u0430 \u0434\u0430 \u0437\u0430\u0432\u0440\u0448\u0443\u0432\u0430 \u0441\u043E "${i.suffix}"` : i.format === "includes" ? `\u041D\u0435\u0432\u0430\u0436\u0435\u0447\u043A\u0430 \u043D\u0438\u0437\u0430: \u043C\u043E\u0440\u0430 \u0434\u0430 \u0432\u043A\u043B\u0443\u0447\u0443\u0432\u0430 "${i.includes}"` : i.format === "regex" ? `\u041D\u0435\u0432\u0430\u0436\u0435\u0447\u043A\u0430 \u043D\u0438\u0437\u0430: \u043C\u043E\u0440\u0430 \u0434\u0430 \u043E\u0434\u0433\u043E\u0430\u0440\u0430 \u043D\u0430 \u043F\u0430\u0442\u0435\u0440\u043D\u043E\u0442 ${i.pattern}` : `Invalid ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u0413\u0440\u0435\u0448\u0435\u043D \u0431\u0440\u043E\u0458: \u043C\u043E\u0440\u0430 \u0434\u0430 \u0431\u0438\u0434\u0435 \u0434\u0435\u043B\u0438\u0432 \u0441\u043E ${r.divisor}`;
      case "unrecognized_keys":
        return `${r.keys.length > 1 ? "\u041D\u0435\u043F\u0440\u0435\u043F\u043E\u0437\u043D\u0430\u0435\u043D\u0438 \u043A\u043B\u0443\u0447\u0435\u0432\u0438" : "\u041D\u0435\u043F\u0440\u0435\u043F\u043E\u0437\u043D\u0430\u0435\u043D \u043A\u043B\u0443\u0447"}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `\u0413\u0440\u0435\u0448\u0435\u043D \u043A\u043B\u0443\u0447 \u0432\u043E ${r.origin}`;
      case "invalid_union":
        return "\u0413\u0440\u0435\u0448\u0435\u043D \u0432\u043D\u0435\u0441";
      case "invalid_element":
        return `\u0413\u0440\u0435\u0448\u043D\u0430 \u0432\u0440\u0435\u0434\u043D\u043E\u0441\u0442 \u0432\u043E ${r.origin}`;
      default:
        return "\u0413\u0440\u0435\u0448\u0435\u043D \u0432\u043D\u0435\u0441";
    }
  };
}, "error");
function Ya() {
  return {
    localeError: Lg()
  };
}
a(Ya, "default");

// versions/4.4.3/node_modules/zod/v4/locales/ms.js
var Bg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "aksara", verb: "mempunyai" },
    file: { unit: "bait", verb: "mempunyai" },
    array: { unit: "elemen", verb: "mempunyai" },
    set: { unit: "elemen", verb: "mempunyai" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "input",
    email: "alamat e-mel",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "tarikh masa ISO",
    date: "tarikh ISO",
    time: "masa ISO",
    duration: "tempoh ISO",
    ipv4: "alamat IPv4",
    ipv6: "alamat IPv6",
    cidrv4: "julat IPv4",
    cidrv6: "julat IPv6",
    base64: "string dikodkan base64",
    base64url: "string dikodkan base64url",
    json_string: "string JSON",
    e164: "nombor E.164",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN",
    number: "nombor"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Input tidak sah: dijangka instanceof ${r.expected}, diterima ${c}` : `Input tidak sah: dijangka ${i}, diterima ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Input tidak sah: dijangka ${y(r.values[0])}` : `Pilihan tidak sah: dijangka salah satu daripada ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `Terlalu besar: dijangka ${r.origin ?? "nilai"} ${s.verb} ${i}${r.maximum.toString()} ${s.unit ?? "elemen"}` : `Terlalu besar: dijangka ${r.origin ?? "nilai"} adalah ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `Terlalu kecil: dijangka ${r.origin} ${s.verb} ${i}${r.minimum.toString()} ${s.unit}` : `Terlalu kecil: dijangka ${r.origin} adalah ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `String tidak sah: mesti bermula dengan "${i.prefix}"` : i.format === "ends_with" ? `String tidak sah: mesti berakhir dengan "${i.suffix}"` : i.format === "includes" ? `String tidak sah: mesti mengandungi "${i.includes}"` : i.format === "regex" ? `String tidak sah: mesti sepadan dengan corak ${i.pattern}` : `${n[i.format] ?? r.format} tidak sah`;
      }
      case "not_multiple_of":
        return `Nombor tidak sah: perlu gandaan ${r.divisor}`;
      case "unrecognized_keys":
        return `Kunci tidak dikenali: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Kunci tidak sah dalam ${r.origin}`;
      case "invalid_union":
        return "Input tidak sah";
      case "invalid_element":
        return `Nilai tidak sah dalam ${r.origin}`;
      default:
        return "Input tidak sah";
    }
  };
}, "error");
function es() {
  return {
    localeError: Bg()
  };
}
a(es, "default");

// versions/4.4.3/node_modules/zod/v4/locales/nl.js
var Vg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "tekens", verb: "heeft" },
    file: { unit: "bytes", verb: "heeft" },
    array: { unit: "elementen", verb: "heeft" },
    set: { unit: "elementen", verb: "heeft" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "invoer",
    email: "emailadres",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datum en tijd",
    date: "ISO datum",
    time: "ISO tijd",
    duration: "ISO duur",
    ipv4: "IPv4-adres",
    ipv6: "IPv6-adres",
    cidrv4: "IPv4-bereik",
    cidrv6: "IPv6-bereik",
    base64: "base64-gecodeerde tekst",
    base64url: "base64 URL-gecodeerde tekst",
    json_string: "JSON string",
    e164: "E.164-nummer",
    jwt: "JWT",
    template_literal: "invoer"
  }, o = {
    nan: "NaN",
    number: "getal"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Ongeldige invoer: verwacht instanceof ${r.expected}, ontving ${c}` : `Ongeldige invoer: verwacht ${i}, ontving ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Ongeldige invoer: verwacht ${y(r.values[0])}` : `Ongeldige optie: verwacht \xE9\xE9n van ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin), c = r.origin === "date" ? "laat" : r.origin === "string" ? "lang" : "groot";
        return s ? `Te ${c}: verwacht dat ${r.origin ?? "waarde"} ${i}${r.maximum.toString()} ${s.unit ?? "elementen"} ${s.verb}` : `Te ${c}: verwacht dat ${r.origin ?? "waarde"} ${i}${r.maximum.toString()} is`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin), c = r.origin === "date" ? "vroeg" : r.origin === "string" ? "kort" : "klein";
        return s ? `Te ${c}: verwacht dat ${r.origin} ${i}${r.minimum.toString()} ${s.unit} ${s.verb}` : `Te ${c}: verwacht dat ${r.origin} ${i}${r.minimum.toString()} is`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Ongeldige tekst: moet met "${i.prefix}" beginnen` : i.format === "ends_with" ? `Ongeldige tekst: moet op "${i.suffix}" eindigen` : i.format === "includes" ? `Ongeldige tekst: moet "${i.includes}" bevatten` : i.format === "regex" ? `Ongeldige tekst: moet overeenkomen met patroon ${i.pattern}` : `Ongeldig: ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Ongeldig getal: moet een veelvoud van ${r.divisor} zijn`;
      case "unrecognized_keys":
        return `Onbekende key${r.keys.length > 1 ? "s" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Ongeldige key in ${r.origin}`;
      case "invalid_union":
        return "Ongeldige invoer";
      case "invalid_element":
        return `Ongeldige waarde in ${r.origin}`;
      default:
        return "Ongeldige invoer";
    }
  };
}, "error");
function ts() {
  return {
    localeError: Vg()
  };
}
a(ts, "default");

// versions/4.4.3/node_modules/zod/v4/locales/no.js
var qg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "tegn", verb: "\xE5 ha" },
    file: { unit: "bytes", verb: "\xE5 ha" },
    array: { unit: "elementer", verb: "\xE5 inneholde" },
    set: { unit: "elementer", verb: "\xE5 inneholde" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "input",
    email: "e-postadresse",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO dato- og klokkeslett",
    date: "ISO-dato",
    time: "ISO-klokkeslett",
    duration: "ISO-varighet",
    ipv4: "IPv4-omr\xE5de",
    ipv6: "IPv6-omr\xE5de",
    cidrv4: "IPv4-spekter",
    cidrv6: "IPv6-spekter",
    base64: "base64-enkodet streng",
    base64url: "base64url-enkodet streng",
    json_string: "JSON-streng",
    e164: "E.164-nummer",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN",
    number: "tall",
    array: "liste"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Ugyldig input: forventet instanceof ${r.expected}, fikk ${c}` : `Ugyldig input: forventet ${i}, fikk ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Ugyldig verdi: forventet ${y(r.values[0])}` : `Ugyldig valg: forventet en av ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `For stor(t): forventet ${r.origin ?? "value"} til \xE5 ha ${i}${r.maximum.toString()} ${s.unit ?? "elementer"}` : `For stor(t): forventet ${r.origin ?? "value"} til \xE5 ha ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `For lite(n): forventet ${r.origin} til \xE5 ha ${i}${r.minimum.toString()} ${s.unit}` : `For lite(n): forventet ${r.origin} til \xE5 ha ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Ugyldig streng: m\xE5 starte med "${i.prefix}"` : i.format === "ends_with" ? `Ugyldig streng: m\xE5 ende med "${i.suffix}"` : i.format === "includes" ? `Ugyldig streng: m\xE5 inneholde "${i.includes}"` : i.format === "regex" ? `Ugyldig streng: m\xE5 matche m\xF8nsteret ${i.pattern}` : `Ugyldig ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Ugyldig tall: m\xE5 v\xE6re et multiplum av ${r.divisor}`;
      case "unrecognized_keys":
        return `${r.keys.length > 1 ? "Ukjente n\xF8kler" : "Ukjent n\xF8kkel"}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Ugyldig n\xF8kkel i ${r.origin}`;
      case "invalid_union":
        return "Ugyldig input";
      case "invalid_element":
        return `Ugyldig verdi i ${r.origin}`;
      default:
        return "Ugyldig input";
    }
  };
}, "error");
function rs() {
  return {
    localeError: qg()
  };
}
a(rs, "default");

// versions/4.4.3/node_modules/zod/v4/locales/ota.js
var Jg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "harf", verb: "olmal\u0131d\u0131r" },
    file: { unit: "bayt", verb: "olmal\u0131d\u0131r" },
    array: { unit: "unsur", verb: "olmal\u0131d\u0131r" },
    set: { unit: "unsur", verb: "olmal\u0131d\u0131r" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "giren",
    email: "epostag\xE2h",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO heng\xE2m\u0131",
    date: "ISO tarihi",
    time: "ISO zaman\u0131",
    duration: "ISO m\xFCddeti",
    ipv4: "IPv4 ni\u015F\xE2n\u0131",
    ipv6: "IPv6 ni\u015F\xE2n\u0131",
    cidrv4: "IPv4 menzili",
    cidrv6: "IPv6 menzili",
    base64: "base64-\u015Fifreli metin",
    base64url: "base64url-\u015Fifreli metin",
    json_string: "JSON metin",
    e164: "E.164 say\u0131s\u0131",
    jwt: "JWT",
    template_literal: "giren"
  }, o = {
    nan: "NaN",
    number: "numara",
    array: "saf",
    null: "gayb"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `F\xE2sit giren: umulan instanceof ${r.expected}, al\u0131nan ${c}` : `F\xE2sit giren: umulan ${i}, al\u0131nan ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `F\xE2sit giren: umulan ${y(r.values[0])}` : `F\xE2sit tercih: m\xFBteberler ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `Fazla b\xFCy\xFCk: ${r.origin ?? "value"}, ${i}${r.maximum.toString()} ${s.unit ?? "elements"} sahip olmal\u0131yd\u0131.` : `Fazla b\xFCy\xFCk: ${r.origin ?? "value"}, ${i}${r.maximum.toString()} olmal\u0131yd\u0131.`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `Fazla k\xFC\xE7\xFCk: ${r.origin}, ${i}${r.minimum.toString()} ${s.unit} sahip olmal\u0131yd\u0131.` : `Fazla k\xFC\xE7\xFCk: ${r.origin}, ${i}${r.minimum.toString()} olmal\u0131yd\u0131.`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `F\xE2sit metin: "${i.prefix}" ile ba\u015Flamal\u0131.` : i.format === "ends_with" ? `F\xE2sit metin: "${i.suffix}" ile bitmeli.` : i.format === "includes" ? `F\xE2sit metin: "${i.includes}" ihtiv\xE2 etmeli.` : i.format === "regex" ? `F\xE2sit metin: ${i.pattern} nak\u015F\u0131na uymal\u0131.` : `F\xE2sit ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `F\xE2sit say\u0131: ${r.divisor} kat\u0131 olmal\u0131yd\u0131.`;
      case "unrecognized_keys":
        return `Tan\u0131nmayan anahtar ${r.keys.length > 1 ? "s" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `${r.origin} i\xE7in tan\u0131nmayan anahtar var.`;
      case "invalid_union":
        return "Giren tan\u0131namad\u0131.";
      case "invalid_element":
        return `${r.origin} i\xE7in tan\u0131nmayan k\u0131ymet var.`;
      default:
        return "K\u0131ymet tan\u0131namad\u0131.";
    }
  };
}, "error");
function ns() {
  return {
    localeError: Jg()
  };
}
a(ns, "default");

// versions/4.4.3/node_modules/zod/v4/locales/ps.js
var Wg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "\u062A\u0648\u06A9\u064A", verb: "\u0648\u0644\u0631\u064A" },
    file: { unit: "\u0628\u0627\u06CC\u067C\u0633", verb: "\u0648\u0644\u0631\u064A" },
    array: { unit: "\u062A\u0648\u06A9\u064A", verb: "\u0648\u0644\u0631\u064A" },
    set: { unit: "\u062A\u0648\u06A9\u064A", verb: "\u0648\u0644\u0631\u064A" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "\u0648\u0631\u0648\u062F\u064A",
    email: "\u0628\u0631\u06CC\u069A\u0646\u0627\u0644\u06CC\u06A9",
    url: "\u06CC\u0648 \u0622\u0631 \u0627\u0644",
    emoji: "\u0627\u06CC\u0645\u0648\u062C\u064A",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u0646\u06CC\u067C\u0647 \u0627\u0648 \u0648\u062E\u062A",
    date: "\u0646\u06D0\u067C\u0647",
    time: "\u0648\u062E\u062A",
    duration: "\u0645\u0648\u062F\u0647",
    ipv4: "\u062F IPv4 \u067E\u062A\u0647",
    ipv6: "\u062F IPv6 \u067E\u062A\u0647",
    cidrv4: "\u062F IPv4 \u0633\u0627\u062D\u0647",
    cidrv6: "\u062F IPv6 \u0633\u0627\u062D\u0647",
    base64: "base64-encoded \u0645\u062A\u0646",
    base64url: "base64url-encoded \u0645\u062A\u0646",
    json_string: "JSON \u0645\u062A\u0646",
    e164: "\u062F E.164 \u0634\u0645\u06D0\u0631\u0647",
    jwt: "JWT",
    template_literal: "\u0648\u0631\u0648\u062F\u064A"
  }, o = {
    nan: "NaN",
    number: "\u0639\u062F\u062F",
    array: "\u0627\u0631\u06D0"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `\u0646\u0627\u0633\u0645 \u0648\u0631\u0648\u062F\u064A: \u0628\u0627\u06CC\u062F instanceof ${r.expected} \u0648\u0627\u06CC, \u0645\u06AB\u0631 ${c} \u062A\u0631\u0644\u0627\u0633\u0647 \u0634\u0648` : `\u0646\u0627\u0633\u0645 \u0648\u0631\u0648\u062F\u064A: \u0628\u0627\u06CC\u062F ${i} \u0648\u0627\u06CC, \u0645\u06AB\u0631 ${c} \u062A\u0631\u0644\u0627\u0633\u0647 \u0634\u0648`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u0646\u0627\u0633\u0645 \u0648\u0631\u0648\u062F\u064A: \u0628\u0627\u06CC\u062F ${y(r.values[0])} \u0648\u0627\u06CC` : `\u0646\u0627\u0633\u0645 \u0627\u0646\u062A\u062E\u0627\u0628: \u0628\u0627\u06CC\u062F \u06CC\u0648 \u0644\u0647 ${p(r.values, "|")} \u0685\u062E\u0647 \u0648\u0627\u06CC`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `\u0689\u06CC\u0631 \u0644\u0648\u06CC: ${r.origin ?? "\u0627\u0631\u0632\u069A\u062A"} \u0628\u0627\u06CC\u062F ${i}${r.maximum.toString()} ${s.unit ?? "\u0639\u0646\u0635\u0631\u0648\u0646\u0647"} \u0648\u0644\u0631\u064A` : `\u0689\u06CC\u0631 \u0644\u0648\u06CC: ${r.origin ?? "\u0627\u0631\u0632\u069A\u062A"} \u0628\u0627\u06CC\u062F ${i}${r.maximum.toString()} \u0648\u064A`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `\u0689\u06CC\u0631 \u06A9\u0648\u0686\u0646\u06CC: ${r.origin} \u0628\u0627\u06CC\u062F ${i}${r.minimum.toString()} ${s.unit} \u0648\u0644\u0631\u064A` : `\u0689\u06CC\u0631 \u06A9\u0648\u0686\u0646\u06CC: ${r.origin} \u0628\u0627\u06CC\u062F ${i}${r.minimum.toString()} \u0648\u064A`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u0646\u0627\u0633\u0645 \u0645\u062A\u0646: \u0628\u0627\u06CC\u062F \u062F "${i.prefix}" \u0633\u0631\u0647 \u067E\u06CC\u0644 \u0634\u064A` : i.format === "ends_with" ? `\u0646\u0627\u0633\u0645 \u0645\u062A\u0646: \u0628\u0627\u06CC\u062F \u062F "${i.suffix}" \u0633\u0631\u0647 \u067E\u0627\u06CC \u062A\u0647 \u0648\u0631\u0633\u064A\u0696\u064A` : i.format === "includes" ? `\u0646\u0627\u0633\u0645 \u0645\u062A\u0646: \u0628\u0627\u06CC\u062F "${i.includes}" \u0648\u0644\u0631\u064A` : i.format === "regex" ? `\u0646\u0627\u0633\u0645 \u0645\u062A\u0646: \u0628\u0627\u06CC\u062F \u062F ${i.pattern} \u0633\u0631\u0647 \u0645\u0637\u0627\u0628\u0642\u062A \u0648\u0644\u0631\u064A` : `${n[i.format] ?? r.format} \u0646\u0627\u0633\u0645 \u062F\u06CC`;
      }
      case "not_multiple_of":
        return `\u0646\u0627\u0633\u0645 \u0639\u062F\u062F: \u0628\u0627\u06CC\u062F \u062F ${r.divisor} \u0645\u0636\u0631\u0628 \u0648\u064A`;
      case "unrecognized_keys":
        return `\u0646\u0627\u0633\u0645 ${r.keys.length > 1 ? "\u06A9\u0644\u06CC\u0689\u0648\u0646\u0647" : "\u06A9\u0644\u06CC\u0689"}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `\u0646\u0627\u0633\u0645 \u06A9\u0644\u06CC\u0689 \u067E\u0647 ${r.origin} \u06A9\u06D0`;
      case "invalid_union":
        return "\u0646\u0627\u0633\u0645\u0647 \u0648\u0631\u0648\u062F\u064A";
      case "invalid_element":
        return `\u0646\u0627\u0633\u0645 \u0639\u0646\u0635\u0631 \u067E\u0647 ${r.origin} \u06A9\u06D0`;
      default:
        return "\u0646\u0627\u0633\u0645\u0647 \u0648\u0631\u0648\u062F\u064A";
    }
  };
}, "error");
function is() {
  return {
    localeError: Wg()
  };
}
a(is, "default");

// versions/4.4.3/node_modules/zod/v4/locales/pl.js
var Kg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "znak\xF3w", verb: "mie\u0107" },
    file: { unit: "bajt\xF3w", verb: "mie\u0107" },
    array: { unit: "element\xF3w", verb: "mie\u0107" },
    set: { unit: "element\xF3w", verb: "mie\u0107" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "wyra\u017Cenie",
    email: "adres email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "data i godzina w formacie ISO",
    date: "data w formacie ISO",
    time: "godzina w formacie ISO",
    duration: "czas trwania ISO",
    ipv4: "adres IPv4",
    ipv6: "adres IPv6",
    cidrv4: "zakres IPv4",
    cidrv6: "zakres IPv6",
    base64: "ci\u0105g znak\xF3w zakodowany w formacie base64",
    base64url: "ci\u0105g znak\xF3w zakodowany w formacie base64url",
    json_string: "ci\u0105g znak\xF3w w formacie JSON",
    e164: "liczba E.164",
    jwt: "JWT",
    template_literal: "wej\u015Bcie"
  }, o = {
    nan: "NaN",
    number: "liczba",
    array: "tablica"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Nieprawid\u0142owe dane wej\u015Bciowe: oczekiwano instanceof ${r.expected}, otrzymano ${c}` : `Nieprawid\u0142owe dane wej\u015Bciowe: oczekiwano ${i}, otrzymano ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Nieprawid\u0142owe dane wej\u015Bciowe: oczekiwano ${y(r.values[0])}` : `Nieprawid\u0142owa opcja: oczekiwano jednej z warto\u015Bci ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `Za du\u017Ca warto\u015B\u0107: oczekiwano, \u017Ce ${r.origin ?? "warto\u015B\u0107"} b\u0119dzie mie\u0107 ${i}${r.maximum.toString()} ${s.unit ?? "element\xF3w"}` : `Zbyt du\u017C(y/a/e): oczekiwano, \u017Ce ${r.origin ?? "warto\u015B\u0107"} b\u0119dzie wynosi\u0107 ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `Za ma\u0142a warto\u015B\u0107: oczekiwano, \u017Ce ${r.origin ?? "warto\u015B\u0107"} b\u0119dzie mie\u0107 ${i}${r.minimum.toString()} ${s.unit ?? "element\xF3w"}` : `Zbyt ma\u0142(y/a/e): oczekiwano, \u017Ce ${r.origin ?? "warto\u015B\u0107"} b\u0119dzie wynosi\u0107 ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Nieprawid\u0142owy ci\u0105g znak\xF3w: musi zaczyna\u0107 si\u0119 od "${i.prefix}"` : i.format === "ends_with" ? `Nieprawid\u0142owy ci\u0105g znak\xF3w: musi ko\u0144czy\u0107 si\u0119 na "${i.suffix}"` : i.format === "includes" ? `Nieprawid\u0142owy ci\u0105g znak\xF3w: musi zawiera\u0107 "${i.includes}"` : i.format === "regex" ? `Nieprawid\u0142owy ci\u0105g znak\xF3w: musi odpowiada\u0107 wzorcowi ${i.pattern}` : `Nieprawid\u0142ow(y/a/e) ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Nieprawid\u0142owa liczba: musi by\u0107 wielokrotno\u015Bci\u0105 ${r.divisor}`;
      case "unrecognized_keys":
        return `Nierozpoznane klucze${r.keys.length > 1 ? "s" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Nieprawid\u0142owy klucz w ${r.origin}`;
      case "invalid_union":
        return "Nieprawid\u0142owe dane wej\u015Bciowe";
      case "invalid_element":
        return `Nieprawid\u0142owa warto\u015B\u0107 w ${r.origin}`;
      default:
        return "Nieprawid\u0142owe dane wej\u015Bciowe";
    }
  };
}, "error");
function os() {
  return {
    localeError: Kg()
  };
}
a(os, "default");

// versions/4.4.3/node_modules/zod/v4/locales/pt.js
var Gg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "caracteres", verb: "ter" },
    file: { unit: "bytes", verb: "ter" },
    array: { unit: "itens", verb: "ter" },
    set: { unit: "itens", verb: "ter" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "padr\xE3o",
    email: "endere\xE7o de e-mail",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "data e hora ISO",
    date: "data ISO",
    time: "hora ISO",
    duration: "dura\xE7\xE3o ISO",
    ipv4: "endere\xE7o IPv4",
    ipv6: "endere\xE7o IPv6",
    cidrv4: "faixa de IPv4",
    cidrv6: "faixa de IPv6",
    base64: "texto codificado em base64",
    base64url: "URL codificada em base64",
    json_string: "texto JSON",
    e164: "n\xFAmero E.164",
    jwt: "JWT",
    template_literal: "entrada"
  }, o = {
    nan: "NaN",
    number: "n\xFAmero",
    null: "nulo"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Tipo inv\xE1lido: esperado instanceof ${r.expected}, recebido ${c}` : `Tipo inv\xE1lido: esperado ${i}, recebido ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Entrada inv\xE1lida: esperado ${y(r.values[0])}` : `Op\xE7\xE3o inv\xE1lida: esperada uma das ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `Muito grande: esperado que ${r.origin ?? "valor"} tivesse ${i}${r.maximum.toString()} ${s.unit ?? "elementos"}` : `Muito grande: esperado que ${r.origin ?? "valor"} fosse ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `Muito pequeno: esperado que ${r.origin} tivesse ${i}${r.minimum.toString()} ${s.unit}` : `Muito pequeno: esperado que ${r.origin} fosse ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Texto inv\xE1lido: deve come\xE7ar com "${i.prefix}"` : i.format === "ends_with" ? `Texto inv\xE1lido: deve terminar com "${i.suffix}"` : i.format === "includes" ? `Texto inv\xE1lido: deve incluir "${i.includes}"` : i.format === "regex" ? `Texto inv\xE1lido: deve corresponder ao padr\xE3o ${i.pattern}` : `${n[i.format] ?? r.format} inv\xE1lido`;
      }
      case "not_multiple_of":
        return `N\xFAmero inv\xE1lido: deve ser m\xFAltiplo de ${r.divisor}`;
      case "unrecognized_keys":
        return `Chave${r.keys.length > 1 ? "s" : ""} desconhecida${r.keys.length > 1 ? "s" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Chave inv\xE1lida em ${r.origin}`;
      case "invalid_union":
        return "Entrada inv\xE1lida";
      case "invalid_element":
        return `Valor inv\xE1lido em ${r.origin}`;
      default:
        return "Campo inv\xE1lido";
    }
  };
}, "error");
function as() {
  return {
    localeError: Gg()
  };
}
a(as, "default");

// versions/4.4.3/node_modules/zod/v4/locales/ro.js
var Xg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "caractere", verb: "s\u0103 aib\u0103" },
    file: { unit: "octe\u021Bi", verb: "s\u0103 aib\u0103" },
    array: { unit: "elemente", verb: "s\u0103 aib\u0103" },
    set: { unit: "elemente", verb: "s\u0103 aib\u0103" },
    map: { unit: "intr\u0103ri", verb: "s\u0103 aib\u0103" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "intrare",
    email: "adres\u0103 de email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "dat\u0103 \u0219i or\u0103 ISO",
    date: "dat\u0103 ISO",
    time: "or\u0103 ISO",
    duration: "durat\u0103 ISO",
    ipv4: "adres\u0103 IPv4",
    ipv6: "adres\u0103 IPv6",
    mac: "adres\u0103 MAC",
    cidrv4: "interval IPv4",
    cidrv6: "interval IPv6",
    base64: "\u0219ir codat base64",
    base64url: "\u0219ir codat base64url",
    json_string: "\u0219ir JSON",
    e164: "num\u0103r E.164",
    jwt: "JWT",
    template_literal: "intrare"
  }, o = {
    nan: "NaN",
    string: "\u0219ir",
    number: "num\u0103r",
    boolean: "boolean",
    function: "func\u021Bie",
    array: "matrice",
    object: "obiect",
    undefined: "nedefinit",
    symbol: "simbol",
    bigint: "num\u0103r mare",
    void: "void",
    never: "never",
    map: "hart\u0103",
    set: "set"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return `Intrare invalid\u0103: a\u0219teptat ${i}, primit ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Intrare invalid\u0103: a\u0219teptat ${y(r.values[0])}` : `Op\u021Biune invalid\u0103: a\u0219teptat una dintre ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `Prea mare: a\u0219teptat ca ${r.origin ?? "valoarea"} ${s.verb} ${i}${r.maximum.toString()} ${s.unit ?? "elemente"}` : `Prea mare: a\u0219teptat ca ${r.origin ?? "valoarea"} s\u0103 fie ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `Prea mic: a\u0219teptat ca ${r.origin} ${s.verb} ${i}${r.minimum.toString()} ${s.unit}` : `Prea mic: a\u0219teptat ca ${r.origin} s\u0103 fie ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u0218ir invalid: trebuie s\u0103 \xEEnceap\u0103 cu "${i.prefix}"` : i.format === "ends_with" ? `\u0218ir invalid: trebuie s\u0103 se termine cu "${i.suffix}"` : i.format === "includes" ? `\u0218ir invalid: trebuie s\u0103 includ\u0103 "${i.includes}"` : i.format === "regex" ? `\u0218ir invalid: trebuie s\u0103 se potriveasc\u0103 cu modelul ${i.pattern}` : `Format invalid: ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Num\u0103r invalid: trebuie s\u0103 fie multiplu de ${r.divisor}`;
      case "unrecognized_keys":
        return `Chei nerecunoscute: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Cheie invalid\u0103 \xEEn ${r.origin}`;
      case "invalid_union":
        return "Intrare invalid\u0103";
      case "invalid_element":
        return `Valoare invalid\u0103 \xEEn ${r.origin}`;
      default:
        return "Intrare invalid\u0103";
    }
  };
}, "error");
function ss() {
  return {
    localeError: Xg()
  };
}
a(ss, "default");

// versions/4.4.3/node_modules/zod/v4/locales/ru.js
function ed(e, t, n, o) {
  let r = Math.abs(e), i = r % 10, s = r % 100;
  return s >= 11 && s <= 19 ? o : i === 1 ? t : i >= 2 && i <= 4 ? n : o;
}
a(ed, "getRussianPlural");
var Hg = /* @__PURE__ */ a(() => {
  let e = {
    string: {
      unit: {
        one: "\u0441\u0438\u043C\u0432\u043E\u043B",
        few: "\u0441\u0438\u043C\u0432\u043E\u043B\u0430",
        many: "\u0441\u0438\u043C\u0432\u043E\u043B\u043E\u0432"
      },
      verb: "\u0438\u043C\u0435\u0442\u044C"
    },
    file: {
      unit: {
        one: "\u0431\u0430\u0439\u0442",
        few: "\u0431\u0430\u0439\u0442\u0430",
        many: "\u0431\u0430\u0439\u0442"
      },
      verb: "\u0438\u043C\u0435\u0442\u044C"
    },
    array: {
      unit: {
        one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
        few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430",
        many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u043E\u0432"
      },
      verb: "\u0438\u043C\u0435\u0442\u044C"
    },
    set: {
      unit: {
        one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
        few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430",
        many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u043E\u0432"
      },
      verb: "\u0438\u043C\u0435\u0442\u044C"
    }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "\u0432\u0432\u043E\u0434",
    email: "email \u0430\u0434\u0440\u0435\u0441",
    url: "URL",
    emoji: "\u044D\u043C\u043E\u0434\u0437\u0438",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0434\u0430\u0442\u0430 \u0438 \u0432\u0440\u0435\u043C\u044F",
    date: "ISO \u0434\u0430\u0442\u0430",
    time: "ISO \u0432\u0440\u0435\u043C\u044F",
    duration: "ISO \u0434\u043B\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C",
    ipv4: "IPv4 \u0430\u0434\u0440\u0435\u0441",
    ipv6: "IPv6 \u0430\u0434\u0440\u0435\u0441",
    cidrv4: "IPv4 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D",
    cidrv6: "IPv6 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D",
    base64: "\u0441\u0442\u0440\u043E\u043A\u0430 \u0432 \u0444\u043E\u0440\u043C\u0430\u0442\u0435 base64",
    base64url: "\u0441\u0442\u0440\u043E\u043A\u0430 \u0432 \u0444\u043E\u0440\u043C\u0430\u0442\u0435 base64url",
    json_string: "JSON \u0441\u0442\u0440\u043E\u043A\u0430",
    e164: "\u043D\u043E\u043C\u0435\u0440 E.164",
    jwt: "JWT",
    template_literal: "\u0432\u0432\u043E\u0434"
  }, o = {
    nan: "NaN",
    number: "\u0447\u0438\u0441\u043B\u043E",
    array: "\u043C\u0430\u0441\u0441\u0438\u0432"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0432\u0432\u043E\u0434: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C instanceof ${r.expected}, \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u043E ${c}` : `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0432\u0432\u043E\u0434: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C ${i}, \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u043E ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0432\u0432\u043E\u0434: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C ${y(r.values[0])}` : `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0432\u0430\u0440\u0438\u0430\u043D\u0442: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C \u043E\u0434\u043D\u043E \u0438\u0437 ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        if (s) {
          let c = Number(r.maximum), u = ed(c, s.unit.one, s.unit.few, s.unit.many);
          return `\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C, \u0447\u0442\u043E ${r.origin ?? "\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435"} \u0431\u0443\u0434\u0435\u0442 \u0438\u043C\u0435\u0442\u044C ${i}${r.maximum.toString()} ${u}`;
        }
        return `\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C, \u0447\u0442\u043E ${r.origin ?? "\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435"} \u0431\u0443\u0434\u0435\u0442 ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        if (s) {
          let c = Number(r.minimum), u = ed(c, s.unit.one, s.unit.few, s.unit.many);
          return `\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u043C\u0430\u043B\u0435\u043D\u044C\u043A\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C, \u0447\u0442\u043E ${r.origin} \u0431\u0443\u0434\u0435\u0442 \u0438\u043C\u0435\u0442\u044C ${i}${r.minimum.toString()} ${u}`;
        }
        return `\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u043C\u0430\u043B\u0435\u043D\u044C\u043A\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C, \u0447\u0442\u043E ${r.origin} \u0431\u0443\u0434\u0435\u0442 ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u0441\u0442\u0440\u043E\u043A\u0430: \u0434\u043E\u043B\u0436\u043D\u0430 \u043D\u0430\u0447\u0438\u043D\u0430\u0442\u044C\u0441\u044F \u0441 "${i.prefix}"` : i.format === "ends_with" ? `\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u0441\u0442\u0440\u043E\u043A\u0430: \u0434\u043E\u043B\u0436\u043D\u0430 \u0437\u0430\u043A\u0430\u043D\u0447\u0438\u0432\u0430\u0442\u044C\u0441\u044F \u043D\u0430 "${i.suffix}"` : i.format === "includes" ? `\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u0441\u0442\u0440\u043E\u043A\u0430: \u0434\u043E\u043B\u0436\u043D\u0430 \u0441\u043E\u0434\u0435\u0440\u0436\u0430\u0442\u044C "${i.includes}"` : i.format === "regex" ? `\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u0441\u0442\u0440\u043E\u043A\u0430: \u0434\u043E\u043B\u0436\u043D\u0430 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u043E\u0432\u0430\u0442\u044C \u0448\u0430\u0431\u043B\u043E\u043D\u0443 ${i.pattern}` : `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u041D\u0435\u0432\u0435\u0440\u043D\u043E\u0435 \u0447\u0438\u0441\u043B\u043E: \u0434\u043E\u043B\u0436\u043D\u043E \u0431\u044B\u0442\u044C \u043A\u0440\u0430\u0442\u043D\u044B\u043C ${r.divisor}`;
      case "unrecognized_keys":
        return `\u041D\u0435\u0440\u0430\u0441\u043F\u043E\u0437\u043D\u0430\u043D\u043D${r.keys.length > 1 ? "\u044B\u0435" : "\u044B\u0439"} \u043A\u043B\u044E\u0447${r.keys.length > 1 ? "\u0438" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u043A\u043B\u044E\u0447 \u0432 ${r.origin}`;
      case "invalid_union":
        return "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0435 \u0432\u0445\u043E\u0434\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435";
      case "invalid_element":
        return `\u041D\u0435\u0432\u0435\u0440\u043D\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u0432 ${r.origin}`;
      default:
        return "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0435 \u0432\u0445\u043E\u0434\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435";
    }
  };
}, "error");
function cs() {
  return {
    localeError: Hg()
  };
}
a(cs, "default");

// versions/4.4.3/node_modules/zod/v4/locales/sl.js
var Qg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "znakov", verb: "imeti" },
    file: { unit: "bajtov", verb: "imeti" },
    array: { unit: "elementov", verb: "imeti" },
    set: { unit: "elementov", verb: "imeti" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "vnos",
    email: "e-po\u0161tni naslov",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datum in \u010Das",
    date: "ISO datum",
    time: "ISO \u010Das",
    duration: "ISO trajanje",
    ipv4: "IPv4 naslov",
    ipv6: "IPv6 naslov",
    cidrv4: "obseg IPv4",
    cidrv6: "obseg IPv6",
    base64: "base64 kodiran niz",
    base64url: "base64url kodiran niz",
    json_string: "JSON niz",
    e164: "E.164 \u0161tevilka",
    jwt: "JWT",
    template_literal: "vnos"
  }, o = {
    nan: "NaN",
    number: "\u0161tevilo",
    array: "tabela"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Neveljaven vnos: pri\u010Dakovano instanceof ${r.expected}, prejeto ${c}` : `Neveljaven vnos: pri\u010Dakovano ${i}, prejeto ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Neveljaven vnos: pri\u010Dakovano ${y(r.values[0])}` : `Neveljavna mo\u017Enost: pri\u010Dakovano eno izmed ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `Preveliko: pri\u010Dakovano, da bo ${r.origin ?? "vrednost"} imelo ${i}${r.maximum.toString()} ${s.unit ?? "elementov"}` : `Preveliko: pri\u010Dakovano, da bo ${r.origin ?? "vrednost"} ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `Premajhno: pri\u010Dakovano, da bo ${r.origin} imelo ${i}${r.minimum.toString()} ${s.unit}` : `Premajhno: pri\u010Dakovano, da bo ${r.origin} ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Neveljaven niz: mora se za\u010Deti z "${i.prefix}"` : i.format === "ends_with" ? `Neveljaven niz: mora se kon\u010Dati z "${i.suffix}"` : i.format === "includes" ? `Neveljaven niz: mora vsebovati "${i.includes}"` : i.format === "regex" ? `Neveljaven niz: mora ustrezati vzorcu ${i.pattern}` : `Neveljaven ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Neveljavno \u0161tevilo: mora biti ve\u010Dkratnik ${r.divisor}`;
      case "unrecognized_keys":
        return `Neprepoznan${r.keys.length > 1 ? "i klju\u010Di" : " klju\u010D"}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Neveljaven klju\u010D v ${r.origin}`;
      case "invalid_union":
        return "Neveljaven vnos";
      case "invalid_element":
        return `Neveljavna vrednost v ${r.origin}`;
      default:
        return "Neveljaven vnos";
    }
  };
}, "error");
function us() {
  return {
    localeError: Qg()
  };
}
a(us, "default");

// versions/4.4.3/node_modules/zod/v4/locales/sv.js
var Yg = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "tecken", verb: "att ha" },
    file: { unit: "bytes", verb: "att ha" },
    array: { unit: "objekt", verb: "att inneh\xE5lla" },
    set: { unit: "objekt", verb: "att inneh\xE5lla" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "regulj\xE4rt uttryck",
    email: "e-postadress",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO-datum och tid",
    date: "ISO-datum",
    time: "ISO-tid",
    duration: "ISO-varaktighet",
    ipv4: "IPv4-intervall",
    ipv6: "IPv6-intervall",
    cidrv4: "IPv4-spektrum",
    cidrv6: "IPv6-spektrum",
    base64: "base64-kodad str\xE4ng",
    base64url: "base64url-kodad str\xE4ng",
    json_string: "JSON-str\xE4ng",
    e164: "E.164-nummer",
    jwt: "JWT",
    template_literal: "mall-literal"
  }, o = {
    nan: "NaN",
    number: "antal",
    array: "lista"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Ogiltig inmatning: f\xF6rv\xE4ntat instanceof ${r.expected}, fick ${c}` : `Ogiltig inmatning: f\xF6rv\xE4ntat ${i}, fick ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Ogiltig inmatning: f\xF6rv\xE4ntat ${y(r.values[0])}` : `Ogiltigt val: f\xF6rv\xE4ntade en av ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `F\xF6r stor(t): f\xF6rv\xE4ntade ${r.origin ?? "v\xE4rdet"} att ha ${i}${r.maximum.toString()} ${s.unit ?? "element"}` : `F\xF6r stor(t): f\xF6rv\xE4ntat ${r.origin ?? "v\xE4rdet"} att ha ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `F\xF6r lite(t): f\xF6rv\xE4ntade ${r.origin ?? "v\xE4rdet"} att ha ${i}${r.minimum.toString()} ${s.unit}` : `F\xF6r lite(t): f\xF6rv\xE4ntade ${r.origin ?? "v\xE4rdet"} att ha ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Ogiltig str\xE4ng: m\xE5ste b\xF6rja med "${i.prefix}"` : i.format === "ends_with" ? `Ogiltig str\xE4ng: m\xE5ste sluta med "${i.suffix}"` : i.format === "includes" ? `Ogiltig str\xE4ng: m\xE5ste inneh\xE5lla "${i.includes}"` : i.format === "regex" ? `Ogiltig str\xE4ng: m\xE5ste matcha m\xF6nstret "${i.pattern}"` : `Ogiltig(t) ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Ogiltigt tal: m\xE5ste vara en multipel av ${r.divisor}`;
      case "unrecognized_keys":
        return `${r.keys.length > 1 ? "Ok\xE4nda nycklar" : "Ok\xE4nd nyckel"}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Ogiltig nyckel i ${r.origin ?? "v\xE4rdet"}`;
      case "invalid_union":
        return "Ogiltig input";
      case "invalid_element":
        return `Ogiltigt v\xE4rde i ${r.origin ?? "v\xE4rdet"}`;
      default:
        return "Ogiltig input";
    }
  };
}, "error");
function ls() {
  return {
    localeError: Yg()
  };
}
a(ls, "default");

// versions/4.4.3/node_modules/zod/v4/locales/ta.js
var eh = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "\u0B8E\u0BB4\u0BC1\u0BA4\u0BCD\u0BA4\u0BC1\u0B95\u0BCD\u0B95\u0BB3\u0BCD", verb: "\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD" },
    file: { unit: "\u0BAA\u0BC8\u0B9F\u0BCD\u0B9F\u0BC1\u0B95\u0BB3\u0BCD", verb: "\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD" },
    array: { unit: "\u0B89\u0BB1\u0BC1\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD", verb: "\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD" },
    set: { unit: "\u0B89\u0BB1\u0BC1\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD", verb: "\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "\u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1",
    email: "\u0BAE\u0BBF\u0BA9\u0BCD\u0BA9\u0B9E\u0BCD\u0B9A\u0BB2\u0BCD \u0BAE\u0BC1\u0B95\u0BB5\u0BB0\u0BBF",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0BA4\u0BC7\u0BA4\u0BBF \u0BA8\u0BC7\u0BB0\u0BAE\u0BCD",
    date: "ISO \u0BA4\u0BC7\u0BA4\u0BBF",
    time: "ISO \u0BA8\u0BC7\u0BB0\u0BAE\u0BCD",
    duration: "ISO \u0B95\u0BBE\u0BB2 \u0B85\u0BB3\u0BB5\u0BC1",
    ipv4: "IPv4 \u0BAE\u0BC1\u0B95\u0BB5\u0BB0\u0BBF",
    ipv6: "IPv6 \u0BAE\u0BC1\u0B95\u0BB5\u0BB0\u0BBF",
    cidrv4: "IPv4 \u0BB5\u0BB0\u0BAE\u0BCD\u0BAA\u0BC1",
    cidrv6: "IPv6 \u0BB5\u0BB0\u0BAE\u0BCD\u0BAA\u0BC1",
    base64: "base64-encoded \u0B9A\u0BB0\u0BAE\u0BCD",
    base64url: "base64url-encoded \u0B9A\u0BB0\u0BAE\u0BCD",
    json_string: "JSON \u0B9A\u0BB0\u0BAE\u0BCD",
    e164: "E.164 \u0B8E\u0BA3\u0BCD",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN",
    number: "\u0B8E\u0BA3\u0BCD",
    array: "\u0B85\u0BA3\u0BBF",
    null: "\u0BB5\u0BC6\u0BB1\u0BC1\u0BAE\u0BC8"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 instanceof ${r.expected}, \u0BAA\u0BC6\u0BB1\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${c}` : `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${i}, \u0BAA\u0BC6\u0BB1\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${y(r.values[0])}` : `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0BB5\u0BBF\u0BB0\u0BC1\u0BAA\u0BCD\u0BAA\u0BAE\u0BCD: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${p(r.values, "|")} \u0B87\u0BB2\u0BCD \u0B92\u0BA9\u0BCD\u0BB1\u0BC1`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `\u0BAE\u0BBF\u0B95 \u0BAA\u0BC6\u0BB0\u0BBF\u0BAF\u0BA4\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${r.origin ?? "\u0BAE\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1"} ${i}${r.maximum.toString()} ${s.unit ?? "\u0B89\u0BB1\u0BC1\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD"} \u0B86\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : `\u0BAE\u0BBF\u0B95 \u0BAA\u0BC6\u0BB0\u0BBF\u0BAF\u0BA4\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${r.origin ?? "\u0BAE\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1"} ${i}${r.maximum.toString()} \u0B86\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `\u0BAE\u0BBF\u0B95\u0B9A\u0BCD \u0B9A\u0BBF\u0BB1\u0BBF\u0BAF\u0BA4\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${r.origin} ${i}${r.minimum.toString()} ${s.unit} \u0B86\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : `\u0BAE\u0BBF\u0B95\u0B9A\u0BCD \u0B9A\u0BBF\u0BB1\u0BBF\u0BAF\u0BA4\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${r.origin} ${i}${r.minimum.toString()} \u0B86\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B9A\u0BB0\u0BAE\u0BCD: "${i.prefix}" \u0B87\u0BB2\u0BCD \u0BA4\u0BCA\u0B9F\u0B99\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : i.format === "ends_with" ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B9A\u0BB0\u0BAE\u0BCD: "${i.suffix}" \u0B87\u0BB2\u0BCD \u0BAE\u0BC1\u0B9F\u0BBF\u0BB5\u0B9F\u0BC8\u0BAF \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : i.format === "includes" ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B9A\u0BB0\u0BAE\u0BCD: "${i.includes}" \u0B90 \u0B89\u0BB3\u0BCD\u0BB3\u0B9F\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : i.format === "regex" ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B9A\u0BB0\u0BAE\u0BCD: ${i.pattern} \u0BAE\u0BC1\u0BB1\u0BC8\u0BAA\u0BBE\u0B9F\u0BCD\u0B9F\u0BC1\u0B9F\u0BA9\u0BCD \u0BAA\u0BCA\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B8E\u0BA3\u0BCD: ${r.divisor} \u0B87\u0BA9\u0BCD \u0BAA\u0BB2\u0BAE\u0BBE\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD`;
      case "unrecognized_keys":
        return `\u0B85\u0B9F\u0BC8\u0BAF\u0BBE\u0BB3\u0BAE\u0BCD \u0BA4\u0BC6\u0BB0\u0BBF\u0BAF\u0BBE\u0BA4 \u0BB5\u0BBF\u0B9A\u0BC8${r.keys.length > 1 ? "\u0B95\u0BB3\u0BCD" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `${r.origin} \u0B87\u0BB2\u0BCD \u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0BB5\u0BBF\u0B9A\u0BC8`;
      case "invalid_union":
        return "\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1";
      case "invalid_element":
        return `${r.origin} \u0B87\u0BB2\u0BCD \u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0BAE\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1`;
      default:
        return "\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1";
    }
  };
}, "error");
function ds() {
  return {
    localeError: eh()
  };
}
a(ds, "default");

// versions/4.4.3/node_modules/zod/v4/locales/th.js
var th = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "\u0E15\u0E31\u0E27\u0E2D\u0E31\u0E01\u0E29\u0E23", verb: "\u0E04\u0E27\u0E23\u0E21\u0E35" },
    file: { unit: "\u0E44\u0E1A\u0E15\u0E4C", verb: "\u0E04\u0E27\u0E23\u0E21\u0E35" },
    array: { unit: "\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23", verb: "\u0E04\u0E27\u0E23\u0E21\u0E35" },
    set: { unit: "\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23", verb: "\u0E04\u0E27\u0E23\u0E21\u0E35" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E17\u0E35\u0E48\u0E1B\u0E49\u0E2D\u0E19",
    email: "\u0E17\u0E35\u0E48\u0E2D\u0E22\u0E39\u0E48\u0E2D\u0E35\u0E40\u0E21\u0E25",
    url: "URL",
    emoji: "\u0E2D\u0E34\u0E42\u0E21\u0E08\u0E34",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48\u0E40\u0E27\u0E25\u0E32\u0E41\u0E1A\u0E1A ISO",
    date: "\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48\u0E41\u0E1A\u0E1A ISO",
    time: "\u0E40\u0E27\u0E25\u0E32\u0E41\u0E1A\u0E1A ISO",
    duration: "\u0E0A\u0E48\u0E27\u0E07\u0E40\u0E27\u0E25\u0E32\u0E41\u0E1A\u0E1A ISO",
    ipv4: "\u0E17\u0E35\u0E48\u0E2D\u0E22\u0E39\u0E48 IPv4",
    ipv6: "\u0E17\u0E35\u0E48\u0E2D\u0E22\u0E39\u0E48 IPv6",
    cidrv4: "\u0E0A\u0E48\u0E27\u0E07 IP \u0E41\u0E1A\u0E1A IPv4",
    cidrv6: "\u0E0A\u0E48\u0E27\u0E07 IP \u0E41\u0E1A\u0E1A IPv6",
    base64: "\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E41\u0E1A\u0E1A Base64",
    base64url: "\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E41\u0E1A\u0E1A Base64 \u0E2A\u0E33\u0E2B\u0E23\u0E31\u0E1A URL",
    json_string: "\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E41\u0E1A\u0E1A JSON",
    e164: "\u0E40\u0E1A\u0E2D\u0E23\u0E4C\u0E42\u0E17\u0E23\u0E28\u0E31\u0E1E\u0E17\u0E4C\u0E23\u0E30\u0E2B\u0E27\u0E48\u0E32\u0E07\u0E1B\u0E23\u0E30\u0E40\u0E17\u0E28 (E.164)",
    jwt: "\u0E42\u0E17\u0E40\u0E04\u0E19 JWT",
    template_literal: "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E17\u0E35\u0E48\u0E1B\u0E49\u0E2D\u0E19"
  }, o = {
    nan: "NaN",
    number: "\u0E15\u0E31\u0E27\u0E40\u0E25\u0E02",
    array: "\u0E2D\u0E32\u0E23\u0E4C\u0E40\u0E23\u0E22\u0E4C (Array)",
    null: "\u0E44\u0E21\u0E48\u0E21\u0E35\u0E04\u0E48\u0E32 (null)"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `\u0E1B\u0E23\u0E30\u0E40\u0E20\u0E17\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E04\u0E27\u0E23\u0E40\u0E1B\u0E47\u0E19 instanceof ${r.expected} \u0E41\u0E15\u0E48\u0E44\u0E14\u0E49\u0E23\u0E31\u0E1A ${c}` : `\u0E1B\u0E23\u0E30\u0E40\u0E20\u0E17\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E04\u0E27\u0E23\u0E40\u0E1B\u0E47\u0E19 ${i} \u0E41\u0E15\u0E48\u0E44\u0E14\u0E49\u0E23\u0E31\u0E1A ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u0E04\u0E48\u0E32\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E04\u0E27\u0E23\u0E40\u0E1B\u0E47\u0E19 ${y(r.values[0])}` : `\u0E15\u0E31\u0E27\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E04\u0E27\u0E23\u0E40\u0E1B\u0E47\u0E19\u0E2B\u0E19\u0E36\u0E48\u0E07\u0E43\u0E19 ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "\u0E44\u0E21\u0E48\u0E40\u0E01\u0E34\u0E19" : "\u0E19\u0E49\u0E2D\u0E22\u0E01\u0E27\u0E48\u0E32", s = t(r.origin);
        return s ? `\u0E40\u0E01\u0E34\u0E19\u0E01\u0E33\u0E2B\u0E19\u0E14: ${r.origin ?? "\u0E04\u0E48\u0E32"} \u0E04\u0E27\u0E23\u0E21\u0E35${i} ${r.maximum.toString()} ${s.unit ?? "\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23"}` : `\u0E40\u0E01\u0E34\u0E19\u0E01\u0E33\u0E2B\u0E19\u0E14: ${r.origin ?? "\u0E04\u0E48\u0E32"} \u0E04\u0E27\u0E23\u0E21\u0E35${i} ${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? "\u0E2D\u0E22\u0E48\u0E32\u0E07\u0E19\u0E49\u0E2D\u0E22" : "\u0E21\u0E32\u0E01\u0E01\u0E27\u0E48\u0E32", s = t(r.origin);
        return s ? `\u0E19\u0E49\u0E2D\u0E22\u0E01\u0E27\u0E48\u0E32\u0E01\u0E33\u0E2B\u0E19\u0E14: ${r.origin} \u0E04\u0E27\u0E23\u0E21\u0E35${i} ${r.minimum.toString()} ${s.unit}` : `\u0E19\u0E49\u0E2D\u0E22\u0E01\u0E27\u0E48\u0E32\u0E01\u0E33\u0E2B\u0E19\u0E14: ${r.origin} \u0E04\u0E27\u0E23\u0E21\u0E35${i} ${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E15\u0E49\u0E2D\u0E07\u0E02\u0E36\u0E49\u0E19\u0E15\u0E49\u0E19\u0E14\u0E49\u0E27\u0E22 "${i.prefix}"` : i.format === "ends_with" ? `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E15\u0E49\u0E2D\u0E07\u0E25\u0E07\u0E17\u0E49\u0E32\u0E22\u0E14\u0E49\u0E27\u0E22 "${i.suffix}"` : i.format === "includes" ? `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E15\u0E49\u0E2D\u0E07\u0E21\u0E35 "${i.includes}" \u0E2D\u0E22\u0E39\u0E48\u0E43\u0E19\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21` : i.format === "regex" ? `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E15\u0E49\u0E2D\u0E07\u0E15\u0E23\u0E07\u0E01\u0E31\u0E1A\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E17\u0E35\u0E48\u0E01\u0E33\u0E2B\u0E19\u0E14 ${i.pattern}` : `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u0E15\u0E31\u0E27\u0E40\u0E25\u0E02\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E15\u0E49\u0E2D\u0E07\u0E40\u0E1B\u0E47\u0E19\u0E08\u0E33\u0E19\u0E27\u0E19\u0E17\u0E35\u0E48\u0E2B\u0E32\u0E23\u0E14\u0E49\u0E27\u0E22 ${r.divisor} \u0E44\u0E14\u0E49\u0E25\u0E07\u0E15\u0E31\u0E27`;
      case "unrecognized_keys":
        return `\u0E1E\u0E1A\u0E04\u0E35\u0E22\u0E4C\u0E17\u0E35\u0E48\u0E44\u0E21\u0E48\u0E23\u0E39\u0E49\u0E08\u0E31\u0E01: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `\u0E04\u0E35\u0E22\u0E4C\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07\u0E43\u0E19 ${r.origin}`;
      case "invalid_union":
        return "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E44\u0E21\u0E48\u0E15\u0E23\u0E07\u0E01\u0E31\u0E1A\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E22\u0E39\u0E40\u0E19\u0E35\u0E22\u0E19\u0E17\u0E35\u0E48\u0E01\u0E33\u0E2B\u0E19\u0E14\u0E44\u0E27\u0E49";
      case "invalid_element":
        return `\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07\u0E43\u0E19 ${r.origin}`;
      default:
        return "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07";
    }
  };
}, "error");
function fs() {
  return {
    localeError: th()
  };
}
a(fs, "default");

// versions/4.4.3/node_modules/zod/v4/locales/tr.js
var rh = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "karakter", verb: "olmal\u0131" },
    file: { unit: "bayt", verb: "olmal\u0131" },
    array: { unit: "\xF6\u011Fe", verb: "olmal\u0131" },
    set: { unit: "\xF6\u011Fe", verb: "olmal\u0131" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "girdi",
    email: "e-posta adresi",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO tarih ve saat",
    date: "ISO tarih",
    time: "ISO saat",
    duration: "ISO s\xFCre",
    ipv4: "IPv4 adresi",
    ipv6: "IPv6 adresi",
    cidrv4: "IPv4 aral\u0131\u011F\u0131",
    cidrv6: "IPv6 aral\u0131\u011F\u0131",
    base64: "base64 ile \u015Fifrelenmi\u015F metin",
    base64url: "base64url ile \u015Fifrelenmi\u015F metin",
    json_string: "JSON dizesi",
    e164: "E.164 say\u0131s\u0131",
    jwt: "JWT",
    template_literal: "\u015Eablon dizesi"
  }, o = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Ge\xE7ersiz de\u011Fer: beklenen instanceof ${r.expected}, al\u0131nan ${c}` : `Ge\xE7ersiz de\u011Fer: beklenen ${i}, al\u0131nan ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Ge\xE7ersiz de\u011Fer: beklenen ${y(r.values[0])}` : `Ge\xE7ersiz se\xE7enek: a\u015Fa\u011F\u0131dakilerden biri olmal\u0131: ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `\xC7ok b\xFCy\xFCk: beklenen ${r.origin ?? "de\u011Fer"} ${i}${r.maximum.toString()} ${s.unit ?? "\xF6\u011Fe"}` : `\xC7ok b\xFCy\xFCk: beklenen ${r.origin ?? "de\u011Fer"} ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `\xC7ok k\xFC\xE7\xFCk: beklenen ${r.origin} ${i}${r.minimum.toString()} ${s.unit}` : `\xC7ok k\xFC\xE7\xFCk: beklenen ${r.origin} ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Ge\xE7ersiz metin: "${i.prefix}" ile ba\u015Flamal\u0131` : i.format === "ends_with" ? `Ge\xE7ersiz metin: "${i.suffix}" ile bitmeli` : i.format === "includes" ? `Ge\xE7ersiz metin: "${i.includes}" i\xE7ermeli` : i.format === "regex" ? `Ge\xE7ersiz metin: ${i.pattern} desenine uymal\u0131` : `Ge\xE7ersiz ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Ge\xE7ersiz say\u0131: ${r.divisor} ile tam b\xF6l\xFCnebilmeli`;
      case "unrecognized_keys":
        return `Tan\u0131nmayan anahtar${r.keys.length > 1 ? "lar" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `${r.origin} i\xE7inde ge\xE7ersiz anahtar`;
      case "invalid_union":
        return "Ge\xE7ersiz de\u011Fer";
      case "invalid_element":
        return `${r.origin} i\xE7inde ge\xE7ersiz de\u011Fer`;
      default:
        return "Ge\xE7ersiz de\u011Fer";
    }
  };
}, "error");
function ps() {
  return {
    localeError: rh()
  };
}
a(ps, "default");

// versions/4.4.3/node_modules/zod/v4/locales/uk.js
var nh = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "\u0441\u0438\u043C\u0432\u043E\u043B\u0456\u0432", verb: "\u043C\u0430\u0442\u0438\u043C\u0435" },
    file: { unit: "\u0431\u0430\u0439\u0442\u0456\u0432", verb: "\u043C\u0430\u0442\u0438\u043C\u0435" },
    array: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0456\u0432", verb: "\u043C\u0430\u0442\u0438\u043C\u0435" },
    set: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0456\u0432", verb: "\u043C\u0430\u0442\u0438\u043C\u0435" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "\u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456",
    email: "\u0430\u0434\u0440\u0435\u0441\u0430 \u0435\u043B\u0435\u043A\u0442\u0440\u043E\u043D\u043D\u043E\u0457 \u043F\u043E\u0448\u0442\u0438",
    url: "URL",
    emoji: "\u0435\u043C\u043E\u0434\u0437\u0456",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u0434\u0430\u0442\u0430 \u0442\u0430 \u0447\u0430\u0441 ISO",
    date: "\u0434\u0430\u0442\u0430 ISO",
    time: "\u0447\u0430\u0441 ISO",
    duration: "\u0442\u0440\u0438\u0432\u0430\u043B\u0456\u0441\u0442\u044C ISO",
    ipv4: "\u0430\u0434\u0440\u0435\u0441\u0430 IPv4",
    ipv6: "\u0430\u0434\u0440\u0435\u0441\u0430 IPv6",
    cidrv4: "\u0434\u0456\u0430\u043F\u0430\u0437\u043E\u043D IPv4",
    cidrv6: "\u0434\u0456\u0430\u043F\u0430\u0437\u043E\u043D IPv6",
    base64: "\u0440\u044F\u0434\u043E\u043A \u0443 \u043A\u043E\u0434\u0443\u0432\u0430\u043D\u043D\u0456 base64",
    base64url: "\u0440\u044F\u0434\u043E\u043A \u0443 \u043A\u043E\u0434\u0443\u0432\u0430\u043D\u043D\u0456 base64url",
    json_string: "\u0440\u044F\u0434\u043E\u043A JSON",
    e164: "\u043D\u043E\u043C\u0435\u0440 E.164",
    jwt: "JWT",
    template_literal: "\u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456"
  }, o = {
    nan: "NaN",
    number: "\u0447\u0438\u0441\u043B\u043E",
    array: "\u043C\u0430\u0441\u0438\u0432"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F instanceof ${r.expected}, \u043E\u0442\u0440\u0438\u043C\u0430\u043D\u043E ${c}` : `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F ${i}, \u043E\u0442\u0440\u0438\u043C\u0430\u043D\u043E ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F ${y(r.values[0])}` : `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0430 \u043E\u043F\u0446\u0456\u044F: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F \u043E\u0434\u043D\u0435 \u0437 ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `\u0417\u0430\u043D\u0430\u0434\u0442\u043E \u0432\u0435\u043B\u0438\u043A\u0435: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F, \u0449\u043E ${r.origin ?? "\u0437\u043D\u0430\u0447\u0435\u043D\u043D\u044F"} ${s.verb} ${i}${r.maximum.toString()} ${s.unit ?? "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0456\u0432"}` : `\u0417\u0430\u043D\u0430\u0434\u0442\u043E \u0432\u0435\u043B\u0438\u043A\u0435: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F, \u0449\u043E ${r.origin ?? "\u0437\u043D\u0430\u0447\u0435\u043D\u043D\u044F"} \u0431\u0443\u0434\u0435 ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `\u0417\u0430\u043D\u0430\u0434\u0442\u043E \u043C\u0430\u043B\u0435: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F, \u0449\u043E ${r.origin} ${s.verb} ${i}${r.minimum.toString()} ${s.unit}` : `\u0417\u0430\u043D\u0430\u0434\u0442\u043E \u043C\u0430\u043B\u0435: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F, \u0449\u043E ${r.origin} \u0431\u0443\u0434\u0435 ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u0440\u044F\u0434\u043E\u043A: \u043F\u043E\u0432\u0438\u043D\u0435\u043D \u043F\u043E\u0447\u0438\u043D\u0430\u0442\u0438\u0441\u044F \u0437 "${i.prefix}"` : i.format === "ends_with" ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u0440\u044F\u0434\u043E\u043A: \u043F\u043E\u0432\u0438\u043D\u0435\u043D \u0437\u0430\u043A\u0456\u043D\u0447\u0443\u0432\u0430\u0442\u0438\u0441\u044F \u043D\u0430 "${i.suffix}"` : i.format === "includes" ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u0440\u044F\u0434\u043E\u043A: \u043F\u043E\u0432\u0438\u043D\u0435\u043D \u043C\u0456\u0441\u0442\u0438\u0442\u0438 "${i.includes}"` : i.format === "regex" ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u0440\u044F\u0434\u043E\u043A: \u043F\u043E\u0432\u0438\u043D\u0435\u043D \u0432\u0456\u0434\u043F\u043E\u0432\u0456\u0434\u0430\u0442\u0438 \u0448\u0430\u0431\u043B\u043E\u043D\u0443 ${i.pattern}` : `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0435 \u0447\u0438\u0441\u043B\u043E: \u043F\u043E\u0432\u0438\u043D\u043D\u043E \u0431\u0443\u0442\u0438 \u043A\u0440\u0430\u0442\u043D\u0438\u043C ${r.divisor}`;
      case "unrecognized_keys":
        return `\u041D\u0435\u0440\u043E\u0437\u043F\u0456\u0437\u043D\u0430\u043D\u0438\u0439 \u043A\u043B\u044E\u0447${r.keys.length > 1 ? "\u0456" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u043A\u043B\u044E\u0447 \u0443 ${r.origin}`;
      case "invalid_union":
        return "\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456";
      case "invalid_element":
        return `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u043D\u044F \u0443 ${r.origin}`;
      default:
        return "\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456";
    }
  };
}, "error");
function qt() {
  return {
    localeError: nh()
  };
}
a(qt, "default");

// versions/4.4.3/node_modules/zod/v4/locales/ua.js
function ms() {
  return qt();
}
a(ms, "default");

// versions/4.4.3/node_modules/zod/v4/locales/ur.js
var ih = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "\u062D\u0631\u0648\u0641", verb: "\u06C1\u0648\u0646\u0627" },
    file: { unit: "\u0628\u0627\u0626\u0679\u0633", verb: "\u06C1\u0648\u0646\u0627" },
    array: { unit: "\u0622\u0626\u0679\u0645\u0632", verb: "\u06C1\u0648\u0646\u0627" },
    set: { unit: "\u0622\u0626\u0679\u0645\u0632", verb: "\u06C1\u0648\u0646\u0627" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "\u0627\u0646 \u067E\u0679",
    email: "\u0627\u06CC \u0645\u06CC\u0644 \u0627\u06CC\u0688\u0631\u06CC\u0633",
    url: "\u06CC\u0648 \u0622\u0631 \u0627\u06CC\u0644",
    emoji: "\u0627\u06CC\u0645\u0648\u062C\u06CC",
    uuid: "\u06CC\u0648 \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC",
    uuidv4: "\u06CC\u0648 \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC \u0648\u06CC 4",
    uuidv6: "\u06CC\u0648 \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC \u0648\u06CC 6",
    nanoid: "\u0646\u06CC\u0646\u0648 \u0622\u0626\u06CC \u0688\u06CC",
    guid: "\u062C\u06CC \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC",
    cuid: "\u0633\u06CC \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC",
    cuid2: "\u0633\u06CC \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC 2",
    ulid: "\u06CC\u0648 \u0627\u06CC\u0644 \u0622\u0626\u06CC \u0688\u06CC",
    xid: "\u0627\u06CC\u06A9\u0633 \u0622\u0626\u06CC \u0688\u06CC",
    ksuid: "\u06A9\u06D2 \u0627\u06CC\u0633 \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC",
    datetime: "\u0622\u0626\u06CC \u0627\u06CC\u0633 \u0627\u0648 \u0688\u06CC\u0679 \u0679\u0627\u0626\u0645",
    date: "\u0622\u0626\u06CC \u0627\u06CC\u0633 \u0627\u0648 \u062A\u0627\u0631\u06CC\u062E",
    time: "\u0622\u0626\u06CC \u0627\u06CC\u0633 \u0627\u0648 \u0648\u0642\u062A",
    duration: "\u0622\u0626\u06CC \u0627\u06CC\u0633 \u0627\u0648 \u0645\u062F\u062A",
    ipv4: "\u0622\u0626\u06CC \u067E\u06CC \u0648\u06CC 4 \u0627\u06CC\u0688\u0631\u06CC\u0633",
    ipv6: "\u0622\u0626\u06CC \u067E\u06CC \u0648\u06CC 6 \u0627\u06CC\u0688\u0631\u06CC\u0633",
    cidrv4: "\u0622\u0626\u06CC \u067E\u06CC \u0648\u06CC 4 \u0631\u06CC\u0646\u062C",
    cidrv6: "\u0622\u0626\u06CC \u067E\u06CC \u0648\u06CC 6 \u0631\u06CC\u0646\u062C",
    base64: "\u0628\u06CC\u0633 64 \u0627\u0646 \u06A9\u0648\u0688\u0688 \u0633\u0679\u0631\u0646\u06AF",
    base64url: "\u0628\u06CC\u0633 64 \u06CC\u0648 \u0622\u0631 \u0627\u06CC\u0644 \u0627\u0646 \u06A9\u0648\u0688\u0688 \u0633\u0679\u0631\u0646\u06AF",
    json_string: "\u062C\u06D2 \u0627\u06CC\u0633 \u0627\u0648 \u0627\u06CC\u0646 \u0633\u0679\u0631\u0646\u06AF",
    e164: "\u0627\u06CC 164 \u0646\u0645\u0628\u0631",
    jwt: "\u062C\u06D2 \u0688\u0628\u0644\u06CC\u0648 \u0679\u06CC",
    template_literal: "\u0627\u0646 \u067E\u0679"
  }, o = {
    nan: "NaN",
    number: "\u0646\u0645\u0628\u0631",
    array: "\u0622\u0631\u06D2",
    null: "\u0646\u0644"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679: instanceof ${r.expected} \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627\u060C ${c} \u0645\u0648\u0635\u0648\u0644 \u06C1\u0648\u0627` : `\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679: ${i} \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627\u060C ${c} \u0645\u0648\u0635\u0648\u0644 \u06C1\u0648\u0627`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679: ${y(r.values[0])} \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627` : `\u063A\u0644\u0637 \u0622\u067E\u0634\u0646: ${p(r.values, "|")} \u0645\u06CC\u06BA \u0633\u06D2 \u0627\u06CC\u06A9 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `\u0628\u06C1\u062A \u0628\u0691\u0627: ${r.origin ?? "\u0648\u06CC\u0644\u06CC\u0648"} \u06A9\u06D2 ${i}${r.maximum.toString()} ${s.unit ?? "\u0639\u0646\u0627\u0635\u0631"} \u06C1\u0648\u0646\u06D2 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u06D2` : `\u0628\u06C1\u062A \u0628\u0691\u0627: ${r.origin ?? "\u0648\u06CC\u0644\u06CC\u0648"} \u06A9\u0627 ${i}${r.maximum.toString()} \u06C1\u0648\u0646\u0627 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `\u0628\u06C1\u062A \u0686\u06BE\u0648\u0679\u0627: ${r.origin} \u06A9\u06D2 ${i}${r.minimum.toString()} ${s.unit} \u06C1\u0648\u0646\u06D2 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u06D2` : `\u0628\u06C1\u062A \u0686\u06BE\u0648\u0679\u0627: ${r.origin} \u06A9\u0627 ${i}${r.minimum.toString()} \u06C1\u0648\u0646\u0627 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u063A\u0644\u0637 \u0633\u0679\u0631\u0646\u06AF: "${i.prefix}" \u0633\u06D2 \u0634\u0631\u0648\u0639 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2` : i.format === "ends_with" ? `\u063A\u0644\u0637 \u0633\u0679\u0631\u0646\u06AF: "${i.suffix}" \u067E\u0631 \u062E\u062A\u0645 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2` : i.format === "includes" ? `\u063A\u0644\u0637 \u0633\u0679\u0631\u0646\u06AF: "${i.includes}" \u0634\u0627\u0645\u0644 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2` : i.format === "regex" ? `\u063A\u0644\u0637 \u0633\u0679\u0631\u0646\u06AF: \u067E\u06CC\u0679\u0631\u0646 ${i.pattern} \u0633\u06D2 \u0645\u06CC\u0686 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2` : `\u063A\u0644\u0637 ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u063A\u0644\u0637 \u0646\u0645\u0628\u0631: ${r.divisor} \u06A9\u0627 \u0645\u0636\u0627\u0639\u0641 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2`;
      case "unrecognized_keys":
        return `\u063A\u06CC\u0631 \u062A\u0633\u0644\u06CC\u0645 \u0634\u062F\u06C1 \u06A9\u06CC${r.keys.length > 1 ? "\u0632" : ""}: ${p(r.keys, "\u060C ")}`;
      case "invalid_key":
        return `${r.origin} \u0645\u06CC\u06BA \u063A\u0644\u0637 \u06A9\u06CC`;
      case "invalid_union":
        return "\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679";
      case "invalid_element":
        return `${r.origin} \u0645\u06CC\u06BA \u063A\u0644\u0637 \u0648\u06CC\u0644\u06CC\u0648`;
      default:
        return "\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679";
    }
  };
}, "error");
function gs() {
  return {
    localeError: ih()
  };
}
a(gs, "default");

// versions/4.4.3/node_modules/zod/v4/locales/uz.js
var oh = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "belgi", verb: "bo\u2018lishi kerak" },
    file: { unit: "bayt", verb: "bo\u2018lishi kerak" },
    array: { unit: "element", verb: "bo\u2018lishi kerak" },
    set: { unit: "element", verb: "bo\u2018lishi kerak" },
    map: { unit: "yozuv", verb: "bo\u2018lishi kerak" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "kirish",
    email: "elektron pochta manzili",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO sana va vaqti",
    date: "ISO sana",
    time: "ISO vaqt",
    duration: "ISO davomiylik",
    ipv4: "IPv4 manzil",
    ipv6: "IPv6 manzil",
    mac: "MAC manzil",
    cidrv4: "IPv4 diapazon",
    cidrv6: "IPv6 diapazon",
    base64: "base64 kodlangan satr",
    base64url: "base64url kodlangan satr",
    json_string: "JSON satr",
    e164: "E.164 raqam",
    jwt: "JWT",
    template_literal: "kirish"
  }, o = {
    nan: "NaN",
    number: "raqam",
    array: "massiv"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `Noto\u2018g\u2018ri kirish: kutilgan instanceof ${r.expected}, qabul qilingan ${c}` : `Noto\u2018g\u2018ri kirish: kutilgan ${i}, qabul qilingan ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Noto\u2018g\u2018ri kirish: kutilgan ${y(r.values[0])}` : `Noto\u2018g\u2018ri variant: quyidagilardan biri kutilgan ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `Juda katta: kutilgan ${r.origin ?? "qiymat"} ${i}${r.maximum.toString()} ${s.unit} ${s.verb}` : `Juda katta: kutilgan ${r.origin ?? "qiymat"} ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `Juda kichik: kutilgan ${r.origin} ${i}${r.minimum.toString()} ${s.unit} ${s.verb}` : `Juda kichik: kutilgan ${r.origin} ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Noto\u2018g\u2018ri satr: "${i.prefix}" bilan boshlanishi kerak` : i.format === "ends_with" ? `Noto\u2018g\u2018ri satr: "${i.suffix}" bilan tugashi kerak` : i.format === "includes" ? `Noto\u2018g\u2018ri satr: "${i.includes}" ni o\u2018z ichiga olishi kerak` : i.format === "regex" ? `Noto\u2018g\u2018ri satr: ${i.pattern} shabloniga mos kelishi kerak` : `Noto\u2018g\u2018ri ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Noto\u2018g\u2018ri raqam: ${r.divisor} ning karralisi bo\u2018lishi kerak`;
      case "unrecognized_keys":
        return `Noma\u2019lum kalit${r.keys.length > 1 ? "lar" : ""}: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `${r.origin} dagi kalit noto\u2018g\u2018ri`;
      case "invalid_union":
        return "Noto\u2018g\u2018ri kirish";
      case "invalid_element":
        return `${r.origin} da noto\u2018g\u2018ri qiymat`;
      default:
        return "Noto\u2018g\u2018ri kirish";
    }
  };
}, "error");
function hs() {
  return {
    localeError: oh()
  };
}
a(hs, "default");

// versions/4.4.3/node_modules/zod/v4/locales/vi.js
var ah = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "k\xFD t\u1EF1", verb: "c\xF3" },
    file: { unit: "byte", verb: "c\xF3" },
    array: { unit: "ph\u1EA7n t\u1EED", verb: "c\xF3" },
    set: { unit: "ph\u1EA7n t\u1EED", verb: "c\xF3" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "\u0111\u1EA7u v\xE0o",
    email: "\u0111\u1ECBa ch\u1EC9 email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ng\xE0y gi\u1EDD ISO",
    date: "ng\xE0y ISO",
    time: "gi\u1EDD ISO",
    duration: "kho\u1EA3ng th\u1EDDi gian ISO",
    ipv4: "\u0111\u1ECBa ch\u1EC9 IPv4",
    ipv6: "\u0111\u1ECBa ch\u1EC9 IPv6",
    cidrv4: "d\u1EA3i IPv4",
    cidrv6: "d\u1EA3i IPv6",
    base64: "chu\u1ED7i m\xE3 h\xF3a base64",
    base64url: "chu\u1ED7i m\xE3 h\xF3a base64url",
    json_string: "chu\u1ED7i JSON",
    e164: "s\u1ED1 E.164",
    jwt: "JWT",
    template_literal: "\u0111\u1EA7u v\xE0o"
  }, o = {
    nan: "NaN",
    number: "s\u1ED1",
    array: "m\u1EA3ng"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7: mong \u0111\u1EE3i instanceof ${r.expected}, nh\u1EADn \u0111\u01B0\u1EE3c ${c}` : `\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7: mong \u0111\u1EE3i ${i}, nh\u1EADn \u0111\u01B0\u1EE3c ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7: mong \u0111\u1EE3i ${y(r.values[0])}` : `T\xF9y ch\u1ECDn kh\xF4ng h\u1EE3p l\u1EC7: mong \u0111\u1EE3i m\u1ED9t trong c\xE1c gi\xE1 tr\u1ECB ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `Qu\xE1 l\u1EDBn: mong \u0111\u1EE3i ${r.origin ?? "gi\xE1 tr\u1ECB"} ${s.verb} ${i}${r.maximum.toString()} ${s.unit ?? "ph\u1EA7n t\u1EED"}` : `Qu\xE1 l\u1EDBn: mong \u0111\u1EE3i ${r.origin ?? "gi\xE1 tr\u1ECB"} ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `Qu\xE1 nh\u1ECF: mong \u0111\u1EE3i ${r.origin} ${s.verb} ${i}${r.minimum.toString()} ${s.unit}` : `Qu\xE1 nh\u1ECF: mong \u0111\u1EE3i ${r.origin} ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Chu\u1ED7i kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i b\u1EAFt \u0111\u1EA7u b\u1EB1ng "${i.prefix}"` : i.format === "ends_with" ? `Chu\u1ED7i kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i k\u1EBFt th\xFAc b\u1EB1ng "${i.suffix}"` : i.format === "includes" ? `Chu\u1ED7i kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i bao g\u1ED3m "${i.includes}"` : i.format === "regex" ? `Chu\u1ED7i kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i kh\u1EDBp v\u1EDBi m\u1EABu ${i.pattern}` : `${n[i.format] ?? r.format} kh\xF4ng h\u1EE3p l\u1EC7`;
      }
      case "not_multiple_of":
        return `S\u1ED1 kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i l\xE0 b\u1ED9i s\u1ED1 c\u1EE7a ${r.divisor}`;
      case "unrecognized_keys":
        return `Kh\xF3a kh\xF4ng \u0111\u01B0\u1EE3c nh\u1EADn d\u1EA1ng: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `Kh\xF3a kh\xF4ng h\u1EE3p l\u1EC7 trong ${r.origin}`;
      case "invalid_union":
        return "\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7";
      case "invalid_element":
        return `Gi\xE1 tr\u1ECB kh\xF4ng h\u1EE3p l\u1EC7 trong ${r.origin}`;
      default:
        return "\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7";
    }
  };
}, "error");
function vs() {
  return {
    localeError: ah()
  };
}
a(vs, "default");

// versions/4.4.3/node_modules/zod/v4/locales/zh-CN.js
var sh = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "\u5B57\u7B26", verb: "\u5305\u542B" },
    file: { unit: "\u5B57\u8282", verb: "\u5305\u542B" },
    array: { unit: "\u9879", verb: "\u5305\u542B" },
    set: { unit: "\u9879", verb: "\u5305\u542B" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "\u8F93\u5165",
    email: "\u7535\u5B50\u90AE\u4EF6",
    url: "URL",
    emoji: "\u8868\u60C5\u7B26\u53F7",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO\u65E5\u671F\u65F6\u95F4",
    date: "ISO\u65E5\u671F",
    time: "ISO\u65F6\u95F4",
    duration: "ISO\u65F6\u957F",
    ipv4: "IPv4\u5730\u5740",
    ipv6: "IPv6\u5730\u5740",
    cidrv4: "IPv4\u7F51\u6BB5",
    cidrv6: "IPv6\u7F51\u6BB5",
    base64: "base64\u7F16\u7801\u5B57\u7B26\u4E32",
    base64url: "base64url\u7F16\u7801\u5B57\u7B26\u4E32",
    json_string: "JSON\u5B57\u7B26\u4E32",
    e164: "E.164\u53F7\u7801",
    jwt: "JWT",
    template_literal: "\u8F93\u5165"
  }, o = {
    nan: "NaN",
    number: "\u6570\u5B57",
    array: "\u6570\u7EC4",
    null: "\u7A7A\u503C(null)"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `\u65E0\u6548\u8F93\u5165\uFF1A\u671F\u671B instanceof ${r.expected}\uFF0C\u5B9E\u9645\u63A5\u6536 ${c}` : `\u65E0\u6548\u8F93\u5165\uFF1A\u671F\u671B ${i}\uFF0C\u5B9E\u9645\u63A5\u6536 ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u65E0\u6548\u8F93\u5165\uFF1A\u671F\u671B ${y(r.values[0])}` : `\u65E0\u6548\u9009\u9879\uFF1A\u671F\u671B\u4EE5\u4E0B\u4E4B\u4E00 ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `\u6570\u503C\u8FC7\u5927\uFF1A\u671F\u671B ${r.origin ?? "\u503C"} ${i}${r.maximum.toString()} ${s.unit ?? "\u4E2A\u5143\u7D20"}` : `\u6570\u503C\u8FC7\u5927\uFF1A\u671F\u671B ${r.origin ?? "\u503C"} ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `\u6570\u503C\u8FC7\u5C0F\uFF1A\u671F\u671B ${r.origin} ${i}${r.minimum.toString()} ${s.unit}` : `\u6570\u503C\u8FC7\u5C0F\uFF1A\u671F\u671B ${r.origin} ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u65E0\u6548\u5B57\u7B26\u4E32\uFF1A\u5FC5\u987B\u4EE5 "${i.prefix}" \u5F00\u5934` : i.format === "ends_with" ? `\u65E0\u6548\u5B57\u7B26\u4E32\uFF1A\u5FC5\u987B\u4EE5 "${i.suffix}" \u7ED3\u5C3E` : i.format === "includes" ? `\u65E0\u6548\u5B57\u7B26\u4E32\uFF1A\u5FC5\u987B\u5305\u542B "${i.includes}"` : i.format === "regex" ? `\u65E0\u6548\u5B57\u7B26\u4E32\uFF1A\u5FC5\u987B\u6EE1\u8DB3\u6B63\u5219\u8868\u8FBE\u5F0F ${i.pattern}` : `\u65E0\u6548${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u65E0\u6548\u6570\u5B57\uFF1A\u5FC5\u987B\u662F ${r.divisor} \u7684\u500D\u6570`;
      case "unrecognized_keys":
        return `\u51FA\u73B0\u672A\u77E5\u7684\u952E(key): ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `${r.origin} \u4E2D\u7684\u952E(key)\u65E0\u6548`;
      case "invalid_union":
        return "\u65E0\u6548\u8F93\u5165";
      case "invalid_element":
        return `${r.origin} \u4E2D\u5305\u542B\u65E0\u6548\u503C(value)`;
      default:
        return "\u65E0\u6548\u8F93\u5165";
    }
  };
}, "error");
function ys() {
  return {
    localeError: sh()
  };
}
a(ys, "default");

// versions/4.4.3/node_modules/zod/v4/locales/zh-TW.js
var ch = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "\u5B57\u5143", verb: "\u64C1\u6709" },
    file: { unit: "\u4F4D\u5143\u7D44", verb: "\u64C1\u6709" },
    array: { unit: "\u9805\u76EE", verb: "\u64C1\u6709" },
    set: { unit: "\u9805\u76EE", verb: "\u64C1\u6709" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "\u8F38\u5165",
    email: "\u90F5\u4EF6\u5730\u5740",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u65E5\u671F\u6642\u9593",
    date: "ISO \u65E5\u671F",
    time: "ISO \u6642\u9593",
    duration: "ISO \u671F\u9593",
    ipv4: "IPv4 \u4F4D\u5740",
    ipv6: "IPv6 \u4F4D\u5740",
    cidrv4: "IPv4 \u7BC4\u570D",
    cidrv6: "IPv6 \u7BC4\u570D",
    base64: "base64 \u7DE8\u78BC\u5B57\u4E32",
    base64url: "base64url \u7DE8\u78BC\u5B57\u4E32",
    json_string: "JSON \u5B57\u4E32",
    e164: "E.164 \u6578\u503C",
    jwt: "JWT",
    template_literal: "\u8F38\u5165"
  }, o = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `\u7121\u6548\u7684\u8F38\u5165\u503C\uFF1A\u9810\u671F\u70BA instanceof ${r.expected}\uFF0C\u4F46\u6536\u5230 ${c}` : `\u7121\u6548\u7684\u8F38\u5165\u503C\uFF1A\u9810\u671F\u70BA ${i}\uFF0C\u4F46\u6536\u5230 ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u7121\u6548\u7684\u8F38\u5165\u503C\uFF1A\u9810\u671F\u70BA ${y(r.values[0])}` : `\u7121\u6548\u7684\u9078\u9805\uFF1A\u9810\u671F\u70BA\u4EE5\u4E0B\u5176\u4E2D\u4E4B\u4E00 ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `\u6578\u503C\u904E\u5927\uFF1A\u9810\u671F ${r.origin ?? "\u503C"} \u61C9\u70BA ${i}${r.maximum.toString()} ${s.unit ?? "\u500B\u5143\u7D20"}` : `\u6578\u503C\u904E\u5927\uFF1A\u9810\u671F ${r.origin ?? "\u503C"} \u61C9\u70BA ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `\u6578\u503C\u904E\u5C0F\uFF1A\u9810\u671F ${r.origin} \u61C9\u70BA ${i}${r.minimum.toString()} ${s.unit}` : `\u6578\u503C\u904E\u5C0F\uFF1A\u9810\u671F ${r.origin} \u61C9\u70BA ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u7121\u6548\u7684\u5B57\u4E32\uFF1A\u5FC5\u9808\u4EE5 "${i.prefix}" \u958B\u982D` : i.format === "ends_with" ? `\u7121\u6548\u7684\u5B57\u4E32\uFF1A\u5FC5\u9808\u4EE5 "${i.suffix}" \u7D50\u5C3E` : i.format === "includes" ? `\u7121\u6548\u7684\u5B57\u4E32\uFF1A\u5FC5\u9808\u5305\u542B "${i.includes}"` : i.format === "regex" ? `\u7121\u6548\u7684\u5B57\u4E32\uFF1A\u5FC5\u9808\u7B26\u5408\u683C\u5F0F ${i.pattern}` : `\u7121\u6548\u7684 ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u7121\u6548\u7684\u6578\u5B57\uFF1A\u5FC5\u9808\u70BA ${r.divisor} \u7684\u500D\u6578`;
      case "unrecognized_keys":
        return `\u7121\u6CD5\u8B58\u5225\u7684\u9375\u503C${r.keys.length > 1 ? "\u5011" : ""}\uFF1A${p(r.keys, "\u3001")}`;
      case "invalid_key":
        return `${r.origin} \u4E2D\u6709\u7121\u6548\u7684\u9375\u503C`;
      case "invalid_union":
        return "\u7121\u6548\u7684\u8F38\u5165\u503C";
      case "invalid_element":
        return `${r.origin} \u4E2D\u6709\u7121\u6548\u7684\u503C`;
      default:
        return "\u7121\u6548\u7684\u8F38\u5165\u503C";
    }
  };
}, "error");
function bs() {
  return {
    localeError: ch()
  };
}
a(bs, "default");

// versions/4.4.3/node_modules/zod/v4/locales/yo.js
var uh = /* @__PURE__ */ a(() => {
  let e = {
    string: { unit: "\xE0mi", verb: "n\xED" },
    file: { unit: "bytes", verb: "n\xED" },
    array: { unit: "nkan", verb: "n\xED" },
    set: { unit: "nkan", verb: "n\xED" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  a(t, "getSizing");
  let n = {
    regex: "\u1EB9\u0300r\u1ECD \xECb\xE1w\u1ECDl\xE9",
    email: "\xE0d\xEDr\u1EB9\u0301s\xEC \xECm\u1EB9\u0301l\xEC",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\xE0k\xF3k\xF2 ISO",
    date: "\u1ECDj\u1ECD\u0301 ISO",
    time: "\xE0k\xF3k\xF2 ISO",
    duration: "\xE0k\xF3k\xF2 t\xF3 p\xE9 ISO",
    ipv4: "\xE0d\xEDr\u1EB9\u0301s\xEC IPv4",
    ipv6: "\xE0d\xEDr\u1EB9\u0301s\xEC IPv6",
    cidrv4: "\xE0gb\xE8gb\xE8 IPv4",
    cidrv6: "\xE0gb\xE8gb\xE8 IPv6",
    base64: "\u1ECD\u0300r\u1ECD\u0300 t\xED a k\u1ECD\u0301 n\xED base64",
    base64url: "\u1ECD\u0300r\u1ECD\u0300 base64url",
    json_string: "\u1ECD\u0300r\u1ECD\u0300 JSON",
    e164: "n\u1ECD\u0301mb\xE0 E.164",
    jwt: "JWT",
    template_literal: "\u1EB9\u0300r\u1ECD \xECb\xE1w\u1ECDl\xE9"
  }, o = {
    nan: "NaN",
    number: "n\u1ECD\u0301mb\xE0",
    array: "akop\u1ECD"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, s = b(r.input), c = o[s] ?? s;
        return /^[A-Z]/.test(r.expected) ? `\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e: a n\xED l\xE1ti fi instanceof ${r.expected}, \xE0m\u1ECD\u0300 a r\xED ${c}` : `\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e: a n\xED l\xE1ti fi ${i}, \xE0m\u1ECD\u0300 a r\xED ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e: a n\xED l\xE1ti fi ${y(r.values[0])}` : `\xC0\u1E63\xE0y\xE0n a\u1E63\xEC\u1E63e: yan \u1ECD\u0300kan l\xE1ra ${p(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", s = t(r.origin);
        return s ? `T\xF3 p\u1ECD\u0300 j\xF9: a n\xED l\xE1ti j\u1EB9\u0301 p\xE9 ${r.origin ?? "iye"} ${s.verb} ${i}${r.maximum} ${s.unit}` : `T\xF3 p\u1ECD\u0300 j\xF9: a n\xED l\xE1ti j\u1EB9\u0301 ${i}${r.maximum}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", s = t(r.origin);
        return s ? `K\xE9r\xE9 ju: a n\xED l\xE1ti j\u1EB9\u0301 p\xE9 ${r.origin} ${s.verb} ${i}${r.minimum} ${s.unit}` : `K\xE9r\xE9 ju: a n\xED l\xE1ti j\u1EB9\u0301 ${i}${r.minimum}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u1ECC\u0300r\u1ECD\u0300 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 b\u1EB9\u0300r\u1EB9\u0300 p\u1EB9\u0300l\xFA "${i.prefix}"` : i.format === "ends_with" ? `\u1ECC\u0300r\u1ECD\u0300 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 par\xED p\u1EB9\u0300l\xFA "${i.suffix}"` : i.format === "includes" ? `\u1ECC\u0300r\u1ECD\u0300 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 n\xED "${i.includes}"` : i.format === "regex" ? `\u1ECC\u0300r\u1ECD\u0300 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 b\xE1 \xE0p\u1EB9\u1EB9r\u1EB9 mu ${i.pattern}` : `A\u1E63\xEC\u1E63e: ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `N\u1ECD\u0301mb\xE0 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 j\u1EB9\u0301 \xE8y\xE0 p\xEDp\xEDn ti ${r.divisor}`;
      case "unrecognized_keys":
        return `B\u1ECDt\xECn\xEC \xE0\xECm\u1ECD\u0300: ${p(r.keys, ", ")}`;
      case "invalid_key":
        return `B\u1ECDt\xECn\xEC a\u1E63\xEC\u1E63e n\xEDn\xFA ${r.origin}`;
      case "invalid_union":
        return "\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e";
      case "invalid_element":
        return `Iye a\u1E63\xEC\u1E63e n\xEDn\xFA ${r.origin}`;
      default:
        return "\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e";
    }
  };
}, "error");
function $s() {
  return {
    localeError: uh()
  };
}
a($s, "default");

// versions/4.4.3/node_modules/zod/v4/core/registries.js
var td, xs = Symbol("ZodOutput"), _s = Symbol("ZodInput"), Wr = class {
  static {
    a(this, "$ZodRegistry");
  }
  constructor() {
    this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map();
  }
  add(t, ...n) {
    let o = n[0];
    return this._map.set(t, o), o && typeof o == "object" && "id" in o && this._idmap.set(o.id, t), this;
  }
  clear() {
    return this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map(), this;
  }
  remove(t) {
    let n = this._map.get(t);
    return n && typeof n == "object" && "id" in n && this._idmap.delete(n.id), this._map.delete(t), this;
  }
  get(t) {
    let n = t._zod.parent;
    if (n) {
      let o = { ...this.get(n) ?? {} };
      delete o.id;
      let r = { ...o, ...this._map.get(t) };
      return Object.keys(r).length ? r : void 0;
    }
    return this._map.get(t);
  }
  has(t) {
    return this._map.has(t);
  }
};
function Kr() {
  return new Wr();
}
a(Kr, "registry");
(td = globalThis).__zod_globalRegistry ?? (td.__zod_globalRegistry = Kr());
var he = globalThis.__zod_globalRegistry;

// versions/4.4.3/node_modules/zod/v4/core/api.js
// @__NO_SIDE_EFFECTS__
function ws(e, t) {
  return new e({
    type: "string",
    ...h(t)
  });
}
a(ws, "_string");
// @__NO_SIDE_EFFECTS__
function ks(e, t) {
  return new e({
    type: "string",
    coerce: !0,
    ...h(t)
  });
}
a(ks, "_coercedString");
// @__NO_SIDE_EFFECTS__
function Is(e, t) {
  return new e({
    type: "string",
    format: "email",
    check: "string_format",
    abort: !1,
    ...h(t)
  });
}
a(Is, "_email");
// @__NO_SIDE_EFFECTS__
function zs(e, t) {
  return new e({
    type: "string",
    format: "guid",
    check: "string_format",
    abort: !1,
    ...h(t)
  });
}
a(zs, "_guid");
// @__NO_SIDE_EFFECTS__
function Ss(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    ...h(t)
  });
}
a(Ss, "_uuid");
// @__NO_SIDE_EFFECTS__
function js(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v4",
    ...h(t)
  });
}
a(js, "_uuidv4");
// @__NO_SIDE_EFFECTS__
function Os(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v6",
    ...h(t)
  });
}
a(Os, "_uuidv6");
// @__NO_SIDE_EFFECTS__
function Ts(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v7",
    ...h(t)
  });
}
a(Ts, "_uuidv7");
// @__NO_SIDE_EFFECTS__
function Gr(e, t) {
  return new e({
    type: "string",
    format: "url",
    check: "string_format",
    abort: !1,
    ...h(t)
  });
}
a(Gr, "_url");
// @__NO_SIDE_EFFECTS__
function Ps(e, t) {
  return new e({
    type: "string",
    format: "emoji",
    check: "string_format",
    abort: !1,
    ...h(t)
  });
}
a(Ps, "_emoji");
// @__NO_SIDE_EFFECTS__
function Us(e, t) {
  return new e({
    type: "string",
    format: "nanoid",
    check: "string_format",
    abort: !1,
    ...h(t)
  });
}
a(Us, "_nanoid");
// @__NO_SIDE_EFFECTS__
function Ds(e, t) {
  return new e({
    type: "string",
    format: "cuid",
    check: "string_format",
    abort: !1,
    ...h(t)
  });
}
a(Ds, "_cuid");
// @__NO_SIDE_EFFECTS__
function Es(e, t) {
  return new e({
    type: "string",
    format: "cuid2",
    check: "string_format",
    abort: !1,
    ...h(t)
  });
}
a(Es, "_cuid2");
// @__NO_SIDE_EFFECTS__
function Ns(e, t) {
  return new e({
    type: "string",
    format: "ulid",
    check: "string_format",
    abort: !1,
    ...h(t)
  });
}
a(Ns, "_ulid");
// @__NO_SIDE_EFFECTS__
function Zs(e, t) {
  return new e({
    type: "string",
    format: "xid",
    check: "string_format",
    abort: !1,
    ...h(t)
  });
}
a(Zs, "_xid");
// @__NO_SIDE_EFFECTS__
function As(e, t) {
  return new e({
    type: "string",
    format: "ksuid",
    check: "string_format",
    abort: !1,
    ...h(t)
  });
}
a(As, "_ksuid");
// @__NO_SIDE_EFFECTS__
function Cs(e, t) {
  return new e({
    type: "string",
    format: "ipv4",
    check: "string_format",
    abort: !1,
    ...h(t)
  });
}
a(Cs, "_ipv4");
// @__NO_SIDE_EFFECTS__
function Rs(e, t) {
  return new e({
    type: "string",
    format: "ipv6",
    check: "string_format",
    abort: !1,
    ...h(t)
  });
}
a(Rs, "_ipv6");
// @__NO_SIDE_EFFECTS__
function Fs(e, t) {
  return new e({
    type: "string",
    format: "mac",
    check: "string_format",
    abort: !1,
    ...h(t)
  });
}
a(Fs, "_mac");
// @__NO_SIDE_EFFECTS__
function Ms(e, t) {
  return new e({
    type: "string",
    format: "cidrv4",
    check: "string_format",
    abort: !1,
    ...h(t)
  });
}
a(Ms, "_cidrv4");
// @__NO_SIDE_EFFECTS__
function Ls(e, t) {
  return new e({
    type: "string",
    format: "cidrv6",
    check: "string_format",
    abort: !1,
    ...h(t)
  });
}
a(Ls, "_cidrv6");
// @__NO_SIDE_EFFECTS__
function Bs(e, t) {
  return new e({
    type: "string",
    format: "base64",
    check: "string_format",
    abort: !1,
    ...h(t)
  });
}
a(Bs, "_base64");
// @__NO_SIDE_EFFECTS__
function Vs(e, t) {
  return new e({
    type: "string",
    format: "base64url",
    check: "string_format",
    abort: !1,
    ...h(t)
  });
}
a(Vs, "_base64url");
// @__NO_SIDE_EFFECTS__
function qs(e, t) {
  return new e({
    type: "string",
    format: "e164",
    check: "string_format",
    abort: !1,
    ...h(t)
  });
}
a(qs, "_e164");
// @__NO_SIDE_EFFECTS__
function Js(e, t) {
  return new e({
    type: "string",
    format: "jwt",
    check: "string_format",
    abort: !1,
    ...h(t)
  });
}
a(Js, "_jwt");
var Ws = {
  Any: null,
  Minute: -1,
  Second: 0,
  Millisecond: 3,
  Microsecond: 6
};
// @__NO_SIDE_EFFECTS__
function Ks(e, t) {
  return new e({
    type: "string",
    format: "datetime",
    check: "string_format",
    offset: !1,
    local: !1,
    precision: null,
    ...h(t)
  });
}
a(Ks, "_isoDateTime");
// @__NO_SIDE_EFFECTS__
function Gs(e, t) {
  return new e({
    type: "string",
    format: "date",
    check: "string_format",
    ...h(t)
  });
}
a(Gs, "_isoDate");
// @__NO_SIDE_EFFECTS__
function Xs(e, t) {
  return new e({
    type: "string",
    format: "time",
    check: "string_format",
    precision: null,
    ...h(t)
  });
}
a(Xs, "_isoTime");
// @__NO_SIDE_EFFECTS__
function Hs(e, t) {
  return new e({
    type: "string",
    format: "duration",
    check: "string_format",
    ...h(t)
  });
}
a(Hs, "_isoDuration");
// @__NO_SIDE_EFFECTS__
function Qs(e, t) {
  return new e({
    type: "number",
    checks: [],
    ...h(t)
  });
}
a(Qs, "_number");
// @__NO_SIDE_EFFECTS__
function Ys(e, t) {
  return new e({
    type: "number",
    coerce: !0,
    checks: [],
    ...h(t)
  });
}
a(Ys, "_coercedNumber");
// @__NO_SIDE_EFFECTS__
function ec(e, t) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "safeint",
    ...h(t)
  });
}
a(ec, "_int");
// @__NO_SIDE_EFFECTS__
function tc(e, t) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "float32",
    ...h(t)
  });
}
a(tc, "_float32");
// @__NO_SIDE_EFFECTS__
function rc(e, t) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "float64",
    ...h(t)
  });
}
a(rc, "_float64");
// @__NO_SIDE_EFFECTS__
function nc(e, t) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "int32",
    ...h(t)
  });
}
a(nc, "_int32");
// @__NO_SIDE_EFFECTS__
function ic(e, t) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "uint32",
    ...h(t)
  });
}
a(ic, "_uint32");
// @__NO_SIDE_EFFECTS__
function oc(e, t) {
  return new e({
    type: "boolean",
    ...h(t)
  });
}
a(oc, "_boolean");
// @__NO_SIDE_EFFECTS__
function ac(e, t) {
  return new e({
    type: "boolean",
    coerce: !0,
    ...h(t)
  });
}
a(ac, "_coercedBoolean");
// @__NO_SIDE_EFFECTS__
function sc(e, t) {
  return new e({
    type: "bigint",
    ...h(t)
  });
}
a(sc, "_bigint");
// @__NO_SIDE_EFFECTS__
function cc(e, t) {
  return new e({
    type: "bigint",
    coerce: !0,
    ...h(t)
  });
}
a(cc, "_coercedBigint");
// @__NO_SIDE_EFFECTS__
function uc(e, t) {
  return new e({
    type: "bigint",
    check: "bigint_format",
    abort: !1,
    format: "int64",
    ...h(t)
  });
}
a(uc, "_int64");
// @__NO_SIDE_EFFECTS__
function lc(e, t) {
  return new e({
    type: "bigint",
    check: "bigint_format",
    abort: !1,
    format: "uint64",
    ...h(t)
  });
}
a(lc, "_uint64");
// @__NO_SIDE_EFFECTS__
function dc(e, t) {
  return new e({
    type: "symbol",
    ...h(t)
  });
}
a(dc, "_symbol");
// @__NO_SIDE_EFFECTS__
function fc(e, t) {
  return new e({
    type: "undefined",
    ...h(t)
  });
}
a(fc, "_undefined");
// @__NO_SIDE_EFFECTS__
function pc(e, t) {
  return new e({
    type: "null",
    ...h(t)
  });
}
a(pc, "_null");
// @__NO_SIDE_EFFECTS__
function mc(e) {
  return new e({
    type: "any"
  });
}
a(mc, "_any");
// @__NO_SIDE_EFFECTS__
function gc(e) {
  return new e({
    type: "unknown"
  });
}
a(gc, "_unknown");
// @__NO_SIDE_EFFECTS__
function hc(e, t) {
  return new e({
    type: "never",
    ...h(t)
  });
}
a(hc, "_never");
// @__NO_SIDE_EFFECTS__
function vc(e, t) {
  return new e({
    type: "void",
    ...h(t)
  });
}
a(vc, "_void");
// @__NO_SIDE_EFFECTS__
function yc(e, t) {
  return new e({
    type: "date",
    ...h(t)
  });
}
a(yc, "_date");
// @__NO_SIDE_EFFECTS__
function bc(e, t) {
  return new e({
    type: "date",
    coerce: !0,
    ...h(t)
  });
}
a(bc, "_coercedDate");
// @__NO_SIDE_EFFECTS__
function $c(e, t) {
  return new e({
    type: "nan",
    ...h(t)
  });
}
a($c, "_nan");
// @__NO_SIDE_EFFECTS__
function Xr(e, t) {
  return new Cr({
    check: "less_than",
    ...h(t),
    value: e,
    inclusive: !1
  });
}
a(Xr, "_lt");
// @__NO_SIDE_EFFECTS__
function Wt(e, t) {
  return new Cr({
    check: "less_than",
    ...h(t),
    value: e,
    inclusive: !0
  });
}
a(Wt, "_lte");
// @__NO_SIDE_EFFECTS__
function Hr(e, t) {
  return new Rr({
    check: "greater_than",
    ...h(t),
    value: e,
    inclusive: !1
  });
}
a(Hr, "_gt");
// @__NO_SIDE_EFFECTS__
function Kt(e, t) {
  return new Rr({
    check: "greater_than",
    ...h(t),
    value: e,
    inclusive: !0
  });
}
a(Kt, "_gte");
// @__NO_SIDE_EFFECTS__
function xc(e) {
  return /* @__PURE__ */ Hr(0, e);
}
a(xc, "_positive");
// @__NO_SIDE_EFFECTS__
function _c(e) {
  return /* @__PURE__ */ Xr(0, e);
}
a(_c, "_negative");
// @__NO_SIDE_EFFECTS__
function wc(e) {
  return /* @__PURE__ */ Wt(0, e);
}
a(wc, "_nonpositive");
// @__NO_SIDE_EFFECTS__
function kc(e) {
  return /* @__PURE__ */ Kt(0, e);
}
a(kc, "_nonnegative");
// @__NO_SIDE_EFFECTS__
function Ic(e, t) {
  return new so({
    check: "multiple_of",
    ...h(t),
    value: e
  });
}
a(Ic, "_multipleOf");
// @__NO_SIDE_EFFECTS__
function zc(e, t) {
  return new lo({
    check: "max_size",
    ...h(t),
    maximum: e
  });
}
a(zc, "_maxSize");
// @__NO_SIDE_EFFECTS__
function Sc(e, t) {
  return new fo({
    check: "min_size",
    ...h(t),
    minimum: e
  });
}
a(Sc, "_minSize");
// @__NO_SIDE_EFFECTS__
function jc(e, t) {
  return new po({
    check: "size_equals",
    ...h(t),
    size: e
  });
}
a(jc, "_size");
// @__NO_SIDE_EFFECTS__
function Oc(e, t) {
  return new mo({
    check: "max_length",
    ...h(t),
    maximum: e
  });
}
a(Oc, "_maxLength");
// @__NO_SIDE_EFFECTS__
function Tc(e, t) {
  return new go({
    check: "min_length",
    ...h(t),
    minimum: e
  });
}
a(Tc, "_minLength");
// @__NO_SIDE_EFFECTS__
function Pc(e, t) {
  return new ho({
    check: "length_equals",
    ...h(t),
    length: e
  });
}
a(Pc, "_length");
// @__NO_SIDE_EFFECTS__
function Uc(e, t) {
  return new vo({
    check: "string_format",
    format: "regex",
    ...h(t),
    pattern: e
  });
}
a(Uc, "_regex");
// @__NO_SIDE_EFFECTS__
function Dc(e) {
  return new yo({
    check: "string_format",
    format: "lowercase",
    ...h(e)
  });
}
a(Dc, "_lowercase");
// @__NO_SIDE_EFFECTS__
function Ec(e) {
  return new bo({
    check: "string_format",
    format: "uppercase",
    ...h(e)
  });
}
a(Ec, "_uppercase");
// @__NO_SIDE_EFFECTS__
function Nc(e, t) {
  return new $o({
    check: "string_format",
    format: "includes",
    ...h(t),
    includes: e
  });
}
a(Nc, "_includes");
// @__NO_SIDE_EFFECTS__
function Zc(e, t) {
  return new xo({
    check: "string_format",
    format: "starts_with",
    ...h(t),
    prefix: e
  });
}
a(Zc, "_startsWith");
// @__NO_SIDE_EFFECTS__
function Ac(e, t) {
  return new _o({
    check: "string_format",
    format: "ends_with",
    ...h(t),
    suffix: e
  });
}
a(Ac, "_endsWith");
// @__NO_SIDE_EFFECTS__
function Cc(e, t, n) {
  return new wo({
    check: "property",
    property: e,
    schema: t,
    ...h(n)
  });
}
a(Cc, "_property");
// @__NO_SIDE_EFFECTS__
function Rc(e, t) {
  return new ko({
    check: "mime_type",
    mime: e,
    ...h(t)
  });
}
a(Rc, "_mime");
// @__NO_SIDE_EFFECTS__
function De(e) {
  return new Io({
    check: "overwrite",
    tx: e
  });
}
a(De, "_overwrite");
// @__NO_SIDE_EFFECTS__
function Fc(e) {
  return /* @__PURE__ */ De((t) => t.normalize(e));
}
a(Fc, "_normalize");
// @__NO_SIDE_EFFECTS__
function Mc() {
  return /* @__PURE__ */ De((e) => e.trim());
}
a(Mc, "_trim");
// @__NO_SIDE_EFFECTS__
function Lc() {
  return /* @__PURE__ */ De((e) => e.toLowerCase());
}
a(Lc, "_toLowerCase");
// @__NO_SIDE_EFFECTS__
function Bc() {
  return /* @__PURE__ */ De((e) => e.toUpperCase());
}
a(Bc, "_toUpperCase");
// @__NO_SIDE_EFFECTS__
function dh() {
  return /* @__PURE__ */ De((e) => ui(e));
}
a(dh, "_slugify");
// @__NO_SIDE_EFFECTS__
function fh(e, t, n) {
  return new e({
    type: "array",
    element: t,
    // get element() {
    //   return element;
    // },
    ...h(n)
  });
}
a(fh, "_array");
// @__NO_SIDE_EFFECTS__
function ph(e, t, n) {
  return new e({
    type: "union",
    options: t,
    ...h(n)
  });
}
a(ph, "_union");
function mh(e, t, n) {
  return new e({
    type: "union",
    options: t,
    inclusive: !1,
    ...h(n)
  });
}
a(mh, "_xor");
// @__NO_SIDE_EFFECTS__
function gh(e, t, n, o) {
  return new e({
    type: "union",
    options: n,
    discriminator: t,
    ...h(o)
  });
}
a(gh, "_discriminatedUnion");
// @__NO_SIDE_EFFECTS__
function hh(e, t, n) {
  return new e({
    type: "intersection",
    left: t,
    right: n
  });
}
a(hh, "_intersection");
// @__NO_SIDE_EFFECTS__
function vh(e, t, n, o) {
  let r = n instanceof _, i = r ? o : n, s = r ? n : null;
  return new e({
    type: "tuple",
    items: t,
    rest: s,
    ...h(i)
  });
}
a(vh, "_tuple");
// @__NO_SIDE_EFFECTS__
function yh(e, t, n, o) {
  return new e({
    type: "record",
    keyType: t,
    valueType: n,
    ...h(o)
  });
}
a(yh, "_record");
// @__NO_SIDE_EFFECTS__
function bh(e, t, n, o) {
  return new e({
    type: "map",
    keyType: t,
    valueType: n,
    ...h(o)
  });
}
a(bh, "_map");
// @__NO_SIDE_EFFECTS__
function $h(e, t, n) {
  return new e({
    type: "set",
    valueType: t,
    ...h(n)
  });
}
a($h, "_set");
// @__NO_SIDE_EFFECTS__
function xh(e, t, n) {
  let o = Array.isArray(t) ? Object.fromEntries(t.map((r) => [r, r])) : t;
  return new e({
    type: "enum",
    entries: o,
    ...h(n)
  });
}
a(xh, "_enum");
// @__NO_SIDE_EFFECTS__
function _h(e, t, n) {
  return new e({
    type: "enum",
    entries: t,
    ...h(n)
  });
}
a(_h, "_nativeEnum");
// @__NO_SIDE_EFFECTS__
function wh(e, t, n) {
  return new e({
    type: "literal",
    values: Array.isArray(t) ? t : [t],
    ...h(n)
  });
}
a(wh, "_literal");
// @__NO_SIDE_EFFECTS__
function Vc(e, t) {
  return new e({
    type: "file",
    ...h(t)
  });
}
a(Vc, "_file");
// @__NO_SIDE_EFFECTS__
function kh(e, t) {
  return new e({
    type: "transform",
    transform: t
  });
}
a(kh, "_transform");
// @__NO_SIDE_EFFECTS__
function Ih(e, t) {
  return new e({
    type: "optional",
    innerType: t
  });
}
a(Ih, "_optional");
// @__NO_SIDE_EFFECTS__
function zh(e, t) {
  return new e({
    type: "nullable",
    innerType: t
  });
}
a(zh, "_nullable");
// @__NO_SIDE_EFFECTS__
function Sh(e, t, n) {
  return new e({
    type: "default",
    innerType: t,
    get defaultValue() {
      return typeof n == "function" ? n() : st(n);
    }
  });
}
a(Sh, "_default");
// @__NO_SIDE_EFFECTS__
function jh(e, t, n) {
  return new e({
    type: "nonoptional",
    innerType: t,
    ...h(n)
  });
}
a(jh, "_nonoptional");
// @__NO_SIDE_EFFECTS__
function Oh(e, t) {
  return new e({
    type: "success",
    innerType: t
  });
}
a(Oh, "_success");
// @__NO_SIDE_EFFECTS__
function Th(e, t, n) {
  return new e({
    type: "catch",
    innerType: t,
    catchValue: typeof n == "function" ? n : () => n
  });
}
a(Th, "_catch");
// @__NO_SIDE_EFFECTS__
function Ph(e, t, n) {
  return new e({
    type: "pipe",
    in: t,
    out: n
  });
}
a(Ph, "_pipe");
// @__NO_SIDE_EFFECTS__
function Uh(e, t) {
  return new e({
    type: "readonly",
    innerType: t
  });
}
a(Uh, "_readonly");
// @__NO_SIDE_EFFECTS__
function Dh(e, t, n) {
  return new e({
    type: "template_literal",
    parts: t,
    ...h(n)
  });
}
a(Dh, "_templateLiteral");
// @__NO_SIDE_EFFECTS__
function Eh(e, t) {
  return new e({
    type: "lazy",
    getter: t
  });
}
a(Eh, "_lazy");
// @__NO_SIDE_EFFECTS__
function Nh(e, t) {
  return new e({
    type: "promise",
    innerType: t
  });
}
a(Nh, "_promise");
// @__NO_SIDE_EFFECTS__
function qc(e, t, n) {
  let o = h(n);
  return o.abort ?? (o.abort = !0), new e({
    type: "custom",
    check: "custom",
    fn: t,
    ...o
  });
}
a(qc, "_custom");
// @__NO_SIDE_EFFECTS__
function Jc(e, t, n) {
  return new e({
    type: "custom",
    check: "custom",
    fn: t,
    ...h(n)
  });
}
a(Jc, "_refine");
// @__NO_SIDE_EFFECTS__
function Wc(e, t) {
  let n = /* @__PURE__ */ rd((o) => (o.addIssue = (r) => {
    if (typeof r == "string")
      o.issues.push(ct(r, o.value, n._zod.def));
    else {
      let i = r;
      i.fatal && (i.continue = !1), i.code ?? (i.code = "custom"), i.input ?? (i.input = o.value), i.inst ?? (i.inst = n), i.continue ?? (i.continue = !n._zod.def.abort), o.issues.push(ct(i));
    }
  }, e(o.value, o)), t);
  return n;
}
a(Wc, "_superRefine");
// @__NO_SIDE_EFFECTS__
function rd(e, t) {
  let n = new A({
    check: "custom",
    ...h(t)
  });
  return n._zod.check = e, n;
}
a(rd, "_check");
// @__NO_SIDE_EFFECTS__
function Kc(e) {
  let t = new A({ check: "describe" });
  return t._zod.onattach = [
    (n) => {
      let o = he.get(n) ?? {};
      he.add(n, { ...o, description: e });
    }
  ], t._zod.check = () => {
  }, t;
}
a(Kc, "describe");
// @__NO_SIDE_EFFECTS__
function Gc(e) {
  let t = new A({ check: "meta" });
  return t._zod.onattach = [
    (n) => {
      let o = he.get(n) ?? {};
      he.add(n, { ...o, ...e });
    }
  ], t._zod.check = () => {
  }, t;
}
a(Gc, "meta");
// @__NO_SIDE_EFFECTS__
function Xc(e, t) {
  let n = h(t), o = n.truthy ?? ["true", "1", "yes", "on", "y", "enabled"], r = n.falsy ?? ["false", "0", "no", "off", "n", "disabled"];
  n.case !== "sensitive" && (o = o.map((v) => typeof v == "string" ? v.toLowerCase() : v), r = r.map((v) => typeof v == "string" ? v.toLowerCase() : v));
  let i = new Set(o), s = new Set(r), c = e.Codec ?? ge, u = e.Boolean ?? Mt, l = e.String ?? lt, d = new l({ type: "string", error: n.error }), g = new u({ type: "boolean", error: n.error }), $ = new c({
    type: "pipe",
    in: d,
    out: g,
    transform: /* @__PURE__ */ a(((v, k) => {
      let D = v;
      return n.case !== "sensitive" && (D = D.toLowerCase()), i.has(D) ? !0 : s.has(D) ? !1 : (k.issues.push({
        code: "invalid_value",
        expected: "stringbool",
        values: [...i, ...s],
        input: k.value,
        inst: $,
        continue: !1
      }), {});
    }), "transform"),
    reverseTransform: /* @__PURE__ */ a(((v, k) => v === !0 ? o[0] || "true" : r[0] || "false"), "reverseTransform"),
    error: n.error
  });
  return $;
}
a(Xc, "_stringbool");
// @__NO_SIDE_EFFECTS__
function ht(e, t, n, o = {}) {
  let r = h(o), i = {
    ...h(o),
    check: "string_format",
    type: "string",
    format: t,
    fn: typeof n == "function" ? n : (c) => n.test(c),
    ...r
  };
  return n instanceof RegExp && (i.pattern = n), new e(i);
}
a(ht, "_stringFormat");

// versions/4.4.3/node_modules/zod/v4/core/to-json-schema.js
function Ee(e) {
  let t = e?.target ?? "draft-2020-12";
  return t === "draft-4" && (t = "draft-04"), t === "draft-7" && (t = "draft-07"), {
    processors: e.processors ?? {},
    metadataRegistry: e?.metadata ?? he,
    target: t,
    unrepresentable: e?.unrepresentable ?? "throw",
    override: e?.override ?? (() => {
    }),
    io: e?.io ?? "output",
    counter: 0,
    seen: /* @__PURE__ */ new Map(),
    cycles: e?.cycles ?? "ref",
    reused: e?.reused ?? "inline",
    external: e?.external ?? void 0
  };
}
a(Ee, "initializeContext");
function E(e, t, n = { path: [], schemaPath: [] }) {
  var o;
  let r = e._zod.def, i = t.seen.get(e);
  if (i)
    return i.count++, n.schemaPath.includes(e) && (i.cycle = n.path), i.schema;
  let s = { schema: {}, count: 1, cycle: void 0, path: n.path };
  t.seen.set(e, s);
  let c = e._zod.toJSONSchema?.();
  if (c)
    s.schema = c;
  else {
    let d = {
      ...n,
      schemaPath: [...n.schemaPath, e],
      path: n.path
    };
    if (e._zod.processJSONSchema)
      e._zod.processJSONSchema(t, s.schema, d);
    else {
      let $ = s.schema, v = t.processors[r.type];
      if (!v)
        throw new Error(`[toJSONSchema]: Non-representable type encountered: ${r.type}`);
      v(e, t, $, d);
    }
    let g = e._zod.parent;
    g && (s.ref || (s.ref = g), E(g, t, d), t.seen.get(g).isParent = !0);
  }
  let u = t.metadataRegistry.get(e);
  return u && Object.assign(s.schema, u), t.io === "input" && te(e) && (delete s.schema.examples, delete s.schema.default), t.io === "input" && "_prefault" in s.schema && ((o = s.schema).default ?? (o.default = s.schema._prefault)), delete s.schema._prefault, t.seen.get(e).schema;
}
a(E, "process");
function Ne(e, t) {
  let n = e.seen.get(t);
  if (!n)
    throw new Error("Unprocessed schema. This is a bug in Zod.");
  let o = /* @__PURE__ */ new Map();
  for (let s of e.seen.entries()) {
    let c = e.metadataRegistry.get(s[0])?.id;
    if (c) {
      let u = o.get(c);
      if (u && u !== s[0])
        throw new Error(`Duplicate schema id "${c}" detected during JSON Schema conversion. Two different schemas cannot share the same id when converted together.`);
      o.set(c, s[0]);
    }
  }
  let r = /* @__PURE__ */ a((s) => {
    let c = e.target === "draft-2020-12" ? "$defs" : "definitions";
    if (e.external) {
      let g = e.external.registry.get(s[0])?.id, $ = e.external.uri ?? ((k) => k);
      if (g)
        return { ref: $(g) };
      let v = s[1].defId ?? s[1].schema.id ?? `schema${e.counter++}`;
      return s[1].defId = v, { defId: v, ref: `${$("__shared")}#/${c}/${v}` };
    }
    if (s[1] === n)
      return { ref: "#" };
    let l = `#/${c}/`, d = s[1].schema.id ?? `__schema${e.counter++}`;
    return { defId: d, ref: l + d };
  }, "makeURI"), i = /* @__PURE__ */ a((s) => {
    if (s[1].schema.$ref)
      return;
    let c = s[1], { ref: u, defId: l } = r(s);
    c.def = { ...c.schema }, l && (c.defId = l);
    let d = c.schema;
    for (let g in d)
      delete d[g];
    d.$ref = u;
  }, "extractToDef");
  if (e.cycles === "throw")
    for (let s of e.seen.entries()) {
      let c = s[1];
      if (c.cycle)
        throw new Error(`Cycle detected: #/${c.cycle?.join("/")}/<root>

Set the \`cycles\` parameter to \`"ref"\` to resolve cyclical schemas with defs.`);
    }
  for (let s of e.seen.entries()) {
    let c = s[1];
    if (t === s[0]) {
      i(s);
      continue;
    }
    if (e.external) {
      let l = e.external.registry.get(s[0])?.id;
      if (t !== s[0] && l) {
        i(s);
        continue;
      }
    }
    if (e.metadataRegistry.get(s[0])?.id) {
      i(s);
      continue;
    }
    if (c.cycle) {
      i(s);
      continue;
    }
    if (c.count > 1 && e.reused === "ref") {
      i(s);
      continue;
    }
  }
}
a(Ne, "extractDefs");
function Ze(e, t) {
  let n = e.seen.get(t);
  if (!n)
    throw new Error("Unprocessed schema. This is a bug in Zod.");
  let o = /* @__PURE__ */ a((c) => {
    let u = e.seen.get(c);
    if (u.ref === null)
      return;
    let l = u.def ?? u.schema, d = { ...l }, g = u.ref;
    if (u.ref = null, g) {
      o(g);
      let v = e.seen.get(g), k = v.schema;
      if (k.$ref && (e.target === "draft-07" || e.target === "draft-04" || e.target === "openapi-3.0") ? (l.allOf = l.allOf ?? [], l.allOf.push(k)) : Object.assign(l, k), Object.assign(l, d), c._zod.parent === g)
        for (let T in l)
          T === "$ref" || T === "allOf" || T in d || delete l[T];
      if (k.$ref && v.def)
        for (let T in l)
          T === "$ref" || T === "allOf" || T in v.def && JSON.stringify(l[T]) === JSON.stringify(v.def[T]) && delete l[T];
    }
    let $ = c._zod.parent;
    if ($ && $ !== g) {
      o($);
      let v = e.seen.get($);
      if (v?.schema.$ref && (l.$ref = v.schema.$ref, v.def))
        for (let k in l)
          k === "$ref" || k === "allOf" || k in v.def && JSON.stringify(l[k]) === JSON.stringify(v.def[k]) && delete l[k];
    }
    e.override({
      zodSchema: c,
      jsonSchema: l,
      path: u.path ?? []
    });
  }, "flattenRef");
  for (let c of [...e.seen.entries()].reverse())
    o(c[0]);
  let r = {};
  if (e.target === "draft-2020-12" ? r.$schema = "https://json-schema.org/draft/2020-12/schema" : e.target === "draft-07" ? r.$schema = "http://json-schema.org/draft-07/schema#" : e.target === "draft-04" ? r.$schema = "http://json-schema.org/draft-04/schema#" : e.target, e.external?.uri) {
    let c = e.external.registry.get(t)?.id;
    if (!c)
      throw new Error("Schema is missing an `id` property");
    r.$id = e.external.uri(c);
  }
  Object.assign(r, n.def ?? n.schema);
  let i = e.metadataRegistry.get(t)?.id;
  i !== void 0 && r.id === i && delete r.id;
  let s = e.external?.defs ?? {};
  for (let c of e.seen.entries()) {
    let u = c[1];
    u.def && u.defId && (u.def.id === u.defId && delete u.def.id, s[u.defId] = u.def);
  }
  e.external || Object.keys(s).length > 0 && (e.target === "draft-2020-12" ? r.$defs = s : r.definitions = s);
  try {
    let c = JSON.parse(JSON.stringify(r));
    return Object.defineProperty(c, "~standard", {
      value: {
        ...t["~standard"],
        jsonSchema: {
          input: Hc(t, "input", e.processors),
          output: Hc(t, "output", e.processors)
        }
      },
      enumerable: !1,
      writable: !1
    }), c;
  } catch {
    throw new Error("Error converting schema to JSON.");
  }
}
a(Ze, "finalize");
function te(e, t) {
  let n = t ?? { seen: /* @__PURE__ */ new Set() };
  if (n.seen.has(e))
    return !1;
  n.seen.add(e);
  let o = e._zod.def;
  if (o.type === "transform")
    return !0;
  if (o.type === "array")
    return te(o.element, n);
  if (o.type === "set")
    return te(o.valueType, n);
  if (o.type === "lazy")
    return te(o.getter(), n);
  if (o.type === "promise" || o.type === "optional" || o.type === "nonoptional" || o.type === "nullable" || o.type === "readonly" || o.type === "default" || o.type === "prefault")
    return te(o.innerType, n);
  if (o.type === "intersection")
    return te(o.left, n) || te(o.right, n);
  if (o.type === "record" || o.type === "map")
    return te(o.keyType, n) || te(o.valueType, n);
  if (o.type === "pipe")
    return e._zod.traits.has("$ZodCodec") ? !0 : te(o.in, n) || te(o.out, n);
  if (o.type === "object") {
    for (let r in o.shape)
      if (te(o.shape[r], n))
        return !0;
    return !1;
  }
  if (o.type === "union") {
    for (let r of o.options)
      if (te(r, n))
        return !0;
    return !1;
  }
  if (o.type === "tuple") {
    for (let r of o.items)
      if (te(r, n))
        return !0;
    return !!(o.rest && te(o.rest, n));
  }
  return !1;
}
a(te, "isTransforming");
var Zh = /* @__PURE__ */ a((e, t = {}) => (n) => {
  let o = Ee({ ...n, processors: t });
  return E(e, o), Ne(o, e), Ze(o, e);
}, "createToJSONSchemaMethod"), Hc = /* @__PURE__ */ a((e, t, n = {}) => (o) => {
  let { libraryOptions: r, target: i } = o ?? {}, s = Ee({ ...r ?? {}, target: i, io: t, processors: n });
  return E(e, s), Ne(s, e), Ze(s, e);
}, "createStandardJSONSchemaMethod");

// versions/4.4.3/node_modules/zod/v4/core/json-schema-processors.js
var Ah = {
  guid: "uuid",
  url: "uri",
  datetime: "date-time",
  json_string: "json-string",
  regex: ""
  // do not set
}, Ch = /* @__PURE__ */ a((e, t, n, o) => {
  let r = n;
  r.type = "string";
  let { minimum: i, maximum: s, format: c, patterns: u, contentEncoding: l } = e._zod.bag;
  if (typeof i == "number" && (r.minLength = i), typeof s == "number" && (r.maxLength = s), c && (r.format = Ah[c] ?? c, r.format === "" && delete r.format, c === "time" && delete r.format), l && (r.contentEncoding = l), u && u.size > 0) {
    let d = [...u];
    d.length === 1 ? r.pattern = d[0].source : d.length > 1 && (r.allOf = [
      ...d.map((g) => ({
        ...t.target === "draft-07" || t.target === "draft-04" || t.target === "openapi-3.0" ? { type: "string" } : {},
        pattern: g.source
      }))
    ]);
  }
}, "stringProcessor"), Rh = /* @__PURE__ */ a((e, t, n, o) => {
  let r = n, { minimum: i, maximum: s, format: c, multipleOf: u, exclusiveMaximum: l, exclusiveMinimum: d } = e._zod.bag;
  typeof c == "string" && c.includes("int") ? r.type = "integer" : r.type = "number";
  let g = typeof d == "number" && d >= (i ?? Number.NEGATIVE_INFINITY), $ = typeof l == "number" && l <= (s ?? Number.POSITIVE_INFINITY), v = t.target === "draft-04" || t.target === "openapi-3.0";
  g ? v ? (r.minimum = d, r.exclusiveMinimum = !0) : r.exclusiveMinimum = d : typeof i == "number" && (r.minimum = i), $ ? v ? (r.maximum = l, r.exclusiveMaximum = !0) : r.exclusiveMaximum = l : typeof s == "number" && (r.maximum = s), typeof u == "number" && (r.multipleOf = u);
}, "numberProcessor"), Fh = /* @__PURE__ */ a((e, t, n, o) => {
  n.type = "boolean";
}, "booleanProcessor"), Mh = /* @__PURE__ */ a((e, t, n, o) => {
  if (t.unrepresentable === "throw")
    throw new Error("BigInt cannot be represented in JSON Schema");
}, "bigintProcessor"), Lh = /* @__PURE__ */ a((e, t, n, o) => {
  if (t.unrepresentable === "throw")
    throw new Error("Symbols cannot be represented in JSON Schema");
}, "symbolProcessor"), Bh = /* @__PURE__ */ a((e, t, n, o) => {
  t.target === "openapi-3.0" ? (n.type = "string", n.nullable = !0, n.enum = [null]) : n.type = "null";
}, "nullProcessor"), Vh = /* @__PURE__ */ a((e, t, n, o) => {
  if (t.unrepresentable === "throw")
    throw new Error("Undefined cannot be represented in JSON Schema");
}, "undefinedProcessor"), qh = /* @__PURE__ */ a((e, t, n, o) => {
  if (t.unrepresentable === "throw")
    throw new Error("Void cannot be represented in JSON Schema");
}, "voidProcessor"), Jh = /* @__PURE__ */ a((e, t, n, o) => {
  n.not = {};
}, "neverProcessor"), Wh = /* @__PURE__ */ a((e, t, n, o) => {
}, "anyProcessor"), Kh = /* @__PURE__ */ a((e, t, n, o) => {
}, "unknownProcessor"), Gh = /* @__PURE__ */ a((e, t, n, o) => {
  if (t.unrepresentable === "throw")
    throw new Error("Date cannot be represented in JSON Schema");
}, "dateProcessor"), Xh = /* @__PURE__ */ a((e, t, n, o) => {
  let r = e._zod.def, i = Dt(r.entries);
  i.every((s) => typeof s == "number") && (n.type = "number"), i.every((s) => typeof s == "string") && (n.type = "string"), n.enum = i;
}, "enumProcessor"), Hh = /* @__PURE__ */ a((e, t, n, o) => {
  let r = e._zod.def, i = [];
  for (let s of r.values)
    if (s === void 0) {
      if (t.unrepresentable === "throw")
        throw new Error("Literal `undefined` cannot be represented in JSON Schema");
    } else if (typeof s == "bigint") {
      if (t.unrepresentable === "throw")
        throw new Error("BigInt literals cannot be represented in JSON Schema");
      i.push(Number(s));
    } else
      i.push(s);
  if (i.length !== 0)
    if (i.length === 1) {
      let s = i[0];
      n.type = s === null ? "null" : typeof s, t.target === "draft-04" || t.target === "openapi-3.0" ? n.enum = [s] : n.const = s;
    } else
      i.every((s) => typeof s == "number") && (n.type = "number"), i.every((s) => typeof s == "string") && (n.type = "string"), i.every((s) => typeof s == "boolean") && (n.type = "boolean"), i.every((s) => s === null) && (n.type = "null"), n.enum = i;
}, "literalProcessor"), Qh = /* @__PURE__ */ a((e, t, n, o) => {
  if (t.unrepresentable === "throw")
    throw new Error("NaN cannot be represented in JSON Schema");
}, "nanProcessor"), Yh = /* @__PURE__ */ a((e, t, n, o) => {
  let r = n, i = e._zod.pattern;
  if (!i)
    throw new Error("Pattern not found in template literal");
  r.type = "string", r.pattern = i.source;
}, "templateLiteralProcessor"), ev = /* @__PURE__ */ a((e, t, n, o) => {
  let r = n, i = {
    type: "string",
    format: "binary",
    contentEncoding: "binary"
  }, { minimum: s, maximum: c, mime: u } = e._zod.bag;
  s !== void 0 && (i.minLength = s), c !== void 0 && (i.maxLength = c), u ? u.length === 1 ? (i.contentMediaType = u[0], Object.assign(r, i)) : (Object.assign(r, i), r.anyOf = u.map((l) => ({ contentMediaType: l }))) : Object.assign(r, i);
}, "fileProcessor"), tv = /* @__PURE__ */ a((e, t, n, o) => {
  n.type = "boolean";
}, "successProcessor"), rv = /* @__PURE__ */ a((e, t, n, o) => {
  if (t.unrepresentable === "throw")
    throw new Error("Custom types cannot be represented in JSON Schema");
}, "customProcessor"), nv = /* @__PURE__ */ a((e, t, n, o) => {
  if (t.unrepresentable === "throw")
    throw new Error("Function types cannot be represented in JSON Schema");
}, "functionProcessor"), iv = /* @__PURE__ */ a((e, t, n, o) => {
  if (t.unrepresentable === "throw")
    throw new Error("Transforms cannot be represented in JSON Schema");
}, "transformProcessor"), ov = /* @__PURE__ */ a((e, t, n, o) => {
  if (t.unrepresentable === "throw")
    throw new Error("Map cannot be represented in JSON Schema");
}, "mapProcessor"), av = /* @__PURE__ */ a((e, t, n, o) => {
  if (t.unrepresentable === "throw")
    throw new Error("Set cannot be represented in JSON Schema");
}, "setProcessor"), sv = /* @__PURE__ */ a((e, t, n, o) => {
  let r = n, i = e._zod.def, { minimum: s, maximum: c } = e._zod.bag;
  typeof s == "number" && (r.minItems = s), typeof c == "number" && (r.maxItems = c), r.type = "array", r.items = E(i.element, t, {
    ...o,
    path: [...o.path, "items"]
  });
}, "arrayProcessor"), cv = /* @__PURE__ */ a((e, t, n, o) => {
  let r = n, i = e._zod.def;
  r.type = "object", r.properties = {};
  let s = i.shape;
  for (let l in s)
    r.properties[l] = E(s[l], t, {
      ...o,
      path: [...o.path, "properties", l]
    });
  let c = new Set(Object.keys(s)), u = new Set([...c].filter((l) => {
    let d = i.shape[l]._zod;
    return t.io === "input" ? d.optin === void 0 : d.optout === void 0;
  }));
  u.size > 0 && (r.required = Array.from(u)), i.catchall?._zod.def.type === "never" ? r.additionalProperties = !1 : i.catchall ? i.catchall && (r.additionalProperties = E(i.catchall, t, {
    ...o,
    path: [...o.path, "additionalProperties"]
  })) : t.io === "output" && (r.additionalProperties = !1);
}, "objectProcessor"), uv = /* @__PURE__ */ a((e, t, n, o) => {
  let r = e._zod.def, i = r.inclusive === !1, s = r.options.map((c, u) => E(c, t, {
    ...o,
    path: [...o.path, i ? "oneOf" : "anyOf", u]
  }));
  i ? n.oneOf = s : n.anyOf = s;
}, "unionProcessor"), lv = /* @__PURE__ */ a((e, t, n, o) => {
  let r = e._zod.def, i = E(r.left, t, {
    ...o,
    path: [...o.path, "allOf", 0]
  }), s = E(r.right, t, {
    ...o,
    path: [...o.path, "allOf", 1]
  }), c = /* @__PURE__ */ a((l) => "allOf" in l && Object.keys(l).length === 1, "isSimpleIntersection"), u = [
    ...c(i) ? i.allOf : [i],
    ...c(s) ? s.allOf : [s]
  ];
  n.allOf = u;
}, "intersectionProcessor"), dv = /* @__PURE__ */ a((e, t, n, o) => {
  let r = n, i = e._zod.def;
  r.type = "array";
  let s = t.target === "draft-2020-12" ? "prefixItems" : "items", c = t.target === "draft-2020-12" || t.target === "openapi-3.0" ? "items" : "additionalItems", u = i.items.map(($, v) => E($, t, {
    ...o,
    path: [...o.path, s, v]
  })), l = i.rest ? E(i.rest, t, {
    ...o,
    path: [...o.path, c, ...t.target === "openapi-3.0" ? [i.items.length] : []]
  }) : null;
  t.target === "draft-2020-12" ? (r.prefixItems = u, l && (r.items = l)) : t.target === "openapi-3.0" ? (r.items = {
    anyOf: u
  }, l && r.items.anyOf.push(l), r.minItems = u.length, l || (r.maxItems = u.length)) : (r.items = u, l && (r.additionalItems = l));
  let { minimum: d, maximum: g } = e._zod.bag;
  typeof d == "number" && (r.minItems = d), typeof g == "number" && (r.maxItems = g);
}, "tupleProcessor"), fv = /* @__PURE__ */ a((e, t, n, o) => {
  let r = n, i = e._zod.def;
  r.type = "object";
  let s = i.keyType, u = s._zod.bag?.patterns;
  if (i.mode === "loose" && u && u.size > 0) {
    let d = E(i.valueType, t, {
      ...o,
      path: [...o.path, "patternProperties", "*"]
    });
    r.patternProperties = {};
    for (let g of u)
      r.patternProperties[g.source] = d;
  } else
    (t.target === "draft-07" || t.target === "draft-2020-12") && (r.propertyNames = E(i.keyType, t, {
      ...o,
      path: [...o.path, "propertyNames"]
    })), r.additionalProperties = E(i.valueType, t, {
      ...o,
      path: [...o.path, "additionalProperties"]
    });
  let l = s._zod.values;
  if (l) {
    let d = [...l].filter((g) => typeof g == "string" || typeof g == "number");
    d.length > 0 && (r.required = d);
  }
}, "recordProcessor"), pv = /* @__PURE__ */ a((e, t, n, o) => {
  let r = e._zod.def, i = E(r.innerType, t, o), s = t.seen.get(e);
  t.target === "openapi-3.0" ? (s.ref = r.innerType, n.nullable = !0) : n.anyOf = [i, { type: "null" }];
}, "nullableProcessor"), mv = /* @__PURE__ */ a((e, t, n, o) => {
  let r = e._zod.def;
  E(r.innerType, t, o);
  let i = t.seen.get(e);
  i.ref = r.innerType;
}, "nonoptionalProcessor"), gv = /* @__PURE__ */ a((e, t, n, o) => {
  let r = e._zod.def;
  E(r.innerType, t, o);
  let i = t.seen.get(e);
  i.ref = r.innerType, n.default = JSON.parse(JSON.stringify(r.defaultValue));
}, "defaultProcessor"), hv = /* @__PURE__ */ a((e, t, n, o) => {
  let r = e._zod.def;
  E(r.innerType, t, o);
  let i = t.seen.get(e);
  i.ref = r.innerType, t.io === "input" && (n._prefault = JSON.parse(JSON.stringify(r.defaultValue)));
}, "prefaultProcessor"), vv = /* @__PURE__ */ a((e, t, n, o) => {
  let r = e._zod.def;
  E(r.innerType, t, o);
  let i = t.seen.get(e);
  i.ref = r.innerType;
  let s;
  try {
    s = r.catchValue(void 0);
  } catch {
    throw new Error("Dynamic catch values are not supported in JSON Schema");
  }
  n.default = s;
}, "catchProcessor"), yv = /* @__PURE__ */ a((e, t, n, o) => {
  let r = e._zod.def, i = r.in._zod.traits.has("$ZodTransform"), s = t.io === "input" ? i ? r.out : r.in : r.out;
  E(s, t, o);
  let c = t.seen.get(e);
  c.ref = s;
}, "pipeProcessor"), bv = /* @__PURE__ */ a((e, t, n, o) => {
  let r = e._zod.def;
  E(r.innerType, t, o);
  let i = t.seen.get(e);
  i.ref = r.innerType, n.readOnly = !0;
}, "readonlyProcessor"), $v = /* @__PURE__ */ a((e, t, n, o) => {
  let r = e._zod.def;
  E(r.innerType, t, o);
  let i = t.seen.get(e);
  i.ref = r.innerType;
}, "promiseProcessor"), xv = /* @__PURE__ */ a((e, t, n, o) => {
  let r = e._zod.def;
  E(r.innerType, t, o);
  let i = t.seen.get(e);
  i.ref = r.innerType;
}, "optionalProcessor"), _v = /* @__PURE__ */ a((e, t, n, o) => {
  let r = e._zod.innerType;
  E(r, t, o);
  let i = t.seen.get(e);
  i.ref = r;
}, "lazyProcessor"), Qr = {
  string: Ch,
  number: Rh,
  boolean: Fh,
  bigint: Mh,
  symbol: Lh,
  null: Bh,
  undefined: Vh,
  void: qh,
  never: Jh,
  any: Wh,
  unknown: Kh,
  date: Gh,
  enum: Xh,
  literal: Hh,
  nan: Qh,
  template_literal: Yh,
  file: ev,
  success: tv,
  custom: rv,
  function: nv,
  transform: iv,
  map: ov,
  set: av,
  array: sv,
  object: cv,
  union: uv,
  intersection: lv,
  tuple: dv,
  record: fv,
  nullable: pv,
  nonoptional: mv,
  default: gv,
  prefault: hv,
  catch: vv,
  pipe: yv,
  readonly: bv,
  promise: $v,
  optional: xv,
  lazy: _v
};
function Yr(e, t) {
  if ("_idmap" in e) {
    let o = e, r = Ee({ ...t, processors: Qr }), i = {};
    for (let u of o._idmap.entries()) {
      let [l, d] = u;
      E(d, r);
    }
    let s = {}, c = {
      registry: o,
      uri: t?.uri,
      defs: i
    };
    r.external = c;
    for (let u of o._idmap.entries()) {
      let [l, d] = u;
      Ne(r, d), s[l] = Ze(r, d);
    }
    if (Object.keys(i).length > 0) {
      let u = r.target === "draft-2020-12" ? "$defs" : "definitions";
      s.__shared = {
        [u]: i
      };
    }
    return { schemas: s };
  }
  let n = Ee({ ...t, processors: Qr });
  return E(e, n), Ne(n, e), Ze(n, e);
}
a(Yr, "toJSONSchema");

// versions/4.4.3/node_modules/zod/v4/core/json-schema-generator.js
var en = class {
  static {
    a(this, "JSONSchemaGenerator");
  }
  /** @deprecated Access via ctx instead */
  get metadataRegistry() {
    return this.ctx.metadataRegistry;
  }
  /** @deprecated Access via ctx instead */
  get target() {
    return this.ctx.target;
  }
  /** @deprecated Access via ctx instead */
  get unrepresentable() {
    return this.ctx.unrepresentable;
  }
  /** @deprecated Access via ctx instead */
  get override() {
    return this.ctx.override;
  }
  /** @deprecated Access via ctx instead */
  get io() {
    return this.ctx.io;
  }
  /** @deprecated Access via ctx instead */
  get counter() {
    return this.ctx.counter;
  }
  set counter(t) {
    this.ctx.counter = t;
  }
  /** @deprecated Access via ctx instead */
  get seen() {
    return this.ctx.seen;
  }
  constructor(t) {
    let n = t?.target ?? "draft-2020-12";
    n === "draft-4" && (n = "draft-04"), n === "draft-7" && (n = "draft-07"), this.ctx = Ee({
      processors: Qr,
      target: n,
      ...t?.metadata && { metadata: t.metadata },
      ...t?.unrepresentable && { unrepresentable: t.unrepresentable },
      ...t?.override && { override: t.override },
      ...t?.io && { io: t.io }
    });
  }
  /**
   * Process a schema to prepare it for JSON Schema generation.
   * This must be called before emit().
   */
  process(t, n = { path: [], schemaPath: [] }) {
    return E(t, this.ctx, n);
  }
  /**
   * Emit the final JSON Schema after processing.
   * Must call process() first.
   */
  emit(t, n) {
    n && (n.cycles && (this.ctx.cycles = n.cycles), n.reused && (this.ctx.reused = n.reused), n.external && (this.ctx.external = n.external)), Ne(this.ctx, t);
    let o = Ze(this.ctx, t), { "~standard": r, ...i } = o;
    return i;
  }
};

// versions/4.4.3/node_modules/zod/v4/core/json-schema.js
var nd = {};

// versions/4.4.3/node_modules/zod/v4/mini/schemas.js
var z = /* @__PURE__ */ f("ZodMiniType", (e, t) => {
  if (!e._zod)
    throw new Error("Uninitialized schema in ZodMiniType.");
  _.init(e, t), e.def = t, e.type = t.type, e.parse = (n, o) => ie(e, n, o, { callee: e.parse }), e.safeParse = (n, o) => me(e, n, o), e.parseAsync = async (n, o) => Oe(e, n, o, { callee: e.parseAsync }), e.safeParseAsync = async (n, o) => Je(e, n, o), e.check = (...n) => e.clone({
    ...t,
    checks: [
      ...t.checks ?? [],
      ...n.map((o) => typeof o == "function" ? {
        _zod: { check: o, def: { check: "custom" }, onattach: [] }
      } : o)
    ]
  }, { parent: !0 }), e.with = e.check, e.clone = (n, o) => J(e, n, o), e.brand = () => e, e.register = ((n, o) => (n.add(e, o), e)), e.apply = (n) => n(e);
}), bt = /* @__PURE__ */ f("ZodMiniString", (e, t) => {
  lt.init(e, t), z.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function yt(e) {
  return ws(bt, e);
}
a(yt, "string");
var C = /* @__PURE__ */ f("ZodMiniStringFormat", (e, t) => {
  Z.init(e, t), bt.init(e, t);
}), id = /* @__PURE__ */ f("ZodMiniEmail", (e, t) => {
  To.init(e, t), C.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function kv(e) {
  return Is(id, e);
}
a(kv, "email");
var od = /* @__PURE__ */ f("ZodMiniGUID", (e, t) => {
  jo.init(e, t), C.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Iv(e) {
  return zs(od, e);
}
a(Iv, "guid");
var Xt = /* @__PURE__ */ f("ZodMiniUUID", (e, t) => {
  Oo.init(e, t), C.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function zv(e) {
  return Ss(Xt, e);
}
a(zv, "uuid");
// @__NO_SIDE_EFFECTS__
function Sv(e) {
  return js(Xt, e);
}
a(Sv, "uuidv4");
// @__NO_SIDE_EFFECTS__
function jv(e) {
  return Os(Xt, e);
}
a(jv, "uuidv6");
// @__NO_SIDE_EFFECTS__
function Ov(e) {
  return Ts(Xt, e);
}
a(Ov, "uuidv7");
var Qc = /* @__PURE__ */ f("ZodMiniURL", (e, t) => {
  Po.init(e, t), C.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Tv(e) {
  return Gr(Qc, e);
}
a(Tv, "url");
// @__NO_SIDE_EFFECTS__
function Pv(e) {
  return Gr(Qc, {
    protocol: ae.httpProtocol,
    hostname: ae.domain,
    ...h(e)
  });
}
a(Pv, "httpUrl");
var ad = /* @__PURE__ */ f("ZodMiniEmoji", (e, t) => {
  Uo.init(e, t), C.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Uv(e) {
  return Ps(ad, e);
}
a(Uv, "emoji");
var sd = /* @__PURE__ */ f("ZodMiniNanoID", (e, t) => {
  Do.init(e, t), C.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Dv(e) {
  return Us(sd, e);
}
a(Dv, "nanoid");
var cd = /* @__PURE__ */ f("ZodMiniCUID", (e, t) => {
  Eo.init(e, t), C.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Ev(e) {
  return Ds(cd, e);
}
a(Ev, "cuid");
var ud = /* @__PURE__ */ f("ZodMiniCUID2", (e, t) => {
  No.init(e, t), C.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Nv(e) {
  return Es(ud, e);
}
a(Nv, "cuid2");
var ld = /* @__PURE__ */ f("ZodMiniULID", (e, t) => {
  Zo.init(e, t), C.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Zv(e) {
  return Ns(ld, e);
}
a(Zv, "ulid");
var dd = /* @__PURE__ */ f("ZodMiniXID", (e, t) => {
  Ao.init(e, t), C.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Av(e) {
  return Zs(dd, e);
}
a(Av, "xid");
var fd = /* @__PURE__ */ f("ZodMiniKSUID", (e, t) => {
  Co.init(e, t), C.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Cv(e) {
  return As(fd, e);
}
a(Cv, "ksuid");
var pd = /* @__PURE__ */ f("ZodMiniIPv4", (e, t) => {
  Bo.init(e, t), C.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Rv(e) {
  return Cs(pd, e);
}
a(Rv, "ipv4");
var md = /* @__PURE__ */ f("ZodMiniIPv6", (e, t) => {
  Vo.init(e, t), C.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Fv(e) {
  return Rs(md, e);
}
a(Fv, "ipv6");
var gd = /* @__PURE__ */ f("ZodMiniCIDRv4", (e, t) => {
  Jo.init(e, t), C.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Mv(e) {
  return Ms(gd, e);
}
a(Mv, "cidrv4");
var hd = /* @__PURE__ */ f("ZodMiniCIDRv6", (e, t) => {
  Wo.init(e, t), C.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Lv(e) {
  return Ls(hd, e);
}
a(Lv, "cidrv6");
var vd = /* @__PURE__ */ f("ZodMiniMAC", (e, t) => {
  qo.init(e, t), C.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Bv(e) {
  return Fs(vd, e);
}
a(Bv, "mac");
var yd = /* @__PURE__ */ f("ZodMiniBase64", (e, t) => {
  Go.init(e, t), C.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Vv(e) {
  return Bs(yd, e);
}
a(Vv, "base64");
var bd = /* @__PURE__ */ f("ZodMiniBase64URL", (e, t) => {
  Xo.init(e, t), C.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function qv(e) {
  return Vs(bd, e);
}
a(qv, "base64url");
var $d = /* @__PURE__ */ f("ZodMiniE164", (e, t) => {
  Ho.init(e, t), C.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Jv(e) {
  return qs($d, e);
}
a(Jv, "e164");
var xd = /* @__PURE__ */ f("ZodMiniJWT", (e, t) => {
  Qo.init(e, t), C.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Wv(e) {
  return Js(xd, e);
}
a(Wv, "jwt");
var Ht = /* @__PURE__ */ f("ZodMiniCustomStringFormat", (e, t) => {
  Yo.init(e, t), C.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Kv(e, t, n = {}) {
  return ht(Ht, e, t, n);
}
a(Kv, "stringFormat");
// @__NO_SIDE_EFFECTS__
function Gv(e) {
  return ht(Ht, "hostname", ae.hostname, e);
}
a(Gv, "hostname");
// @__NO_SIDE_EFFECTS__
function Xv(e) {
  return ht(Ht, "hex", ae.hex, e);
}
a(Xv, "hex");
// @__NO_SIDE_EFFECTS__
function Hv(e, t) {
  let n = t?.enc ?? "hex", o = `${e}_${n}`, r = ae[o];
  if (!r)
    throw new Error(`Unrecognized hash format: ${o}`);
  return ht(Ht, o, r, t);
}
a(Hv, "hash");
var Qt = /* @__PURE__ */ f("ZodMiniNumber", (e, t) => {
  Vr.init(e, t), z.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function rn(e) {
  return Qs(Qt, e);
}
a(rn, "number");
var $t = /* @__PURE__ */ f("ZodMiniNumberFormat", (e, t) => {
  ea.init(e, t), Qt.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Qv(e) {
  return ec($t, e);
}
a(Qv, "int");
// @__NO_SIDE_EFFECTS__
function Yv(e) {
  return tc($t, e);
}
a(Yv, "float32");
// @__NO_SIDE_EFFECTS__
function ey(e) {
  return rc($t, e);
}
a(ey, "float64");
// @__NO_SIDE_EFFECTS__
function ty(e) {
  return nc($t, e);
}
a(ty, "int32");
// @__NO_SIDE_EFFECTS__
function ry(e) {
  return ic($t, e);
}
a(ry, "uint32");
var Yt = /* @__PURE__ */ f("ZodMiniBoolean", (e, t) => {
  Mt.init(e, t), z.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function nn(e) {
  return oc(Yt, e);
}
a(nn, "boolean");
var er = /* @__PURE__ */ f("ZodMiniBigInt", (e, t) => {
  qr.init(e, t), z.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function ny(e) {
  return sc(er, e);
}
a(ny, "bigint");
var Yc = /* @__PURE__ */ f("ZodMiniBigIntFormat", (e, t) => {
  ta.init(e, t), er.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function iy(e) {
  return uc(Yc, e);
}
a(iy, "int64");
// @__NO_SIDE_EFFECTS__
function oy(e) {
  return lc(Yc, e);
}
a(oy, "uint64");
var _d = /* @__PURE__ */ f("ZodMiniSymbol", (e, t) => {
  ra.init(e, t), z.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function ay(e) {
  return dc(_d, e);
}
a(ay, "symbol");
var wd = /* @__PURE__ */ f("ZodMiniUndefined", (e, t) => {
  na.init(e, t), z.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function sy(e) {
  return fc(wd, e);
}
a(sy, "_undefined");
var kd = /* @__PURE__ */ f("ZodMiniNull", (e, t) => {
  ia.init(e, t), z.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Id(e) {
  return pc(kd, e);
}
a(Id, "_null");
var zd = /* @__PURE__ */ f("ZodMiniAny", (e, t) => {
  oa.init(e, t), z.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function cy() {
  return mc(zd);
}
a(cy, "any");
var Sd = /* @__PURE__ */ f("ZodMiniUnknown", (e, t) => {
  aa.init(e, t), z.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function tn() {
  return gc(Sd);
}
a(tn, "unknown");
var jd = /* @__PURE__ */ f("ZodMiniNever", (e, t) => {
  sa.init(e, t), z.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Od(e) {
  return hc(jd, e);
}
a(Od, "never");
var Td = /* @__PURE__ */ f("ZodMiniVoid", (e, t) => {
  ca.init(e, t), z.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function uy(e) {
  return vc(Td, e);
}
a(uy, "_void");
var on = /* @__PURE__ */ f("ZodMiniDate", (e, t) => {
  dt.init(e, t), z.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function eu(e) {
  return yc(on, e);
}
a(eu, "date");
var Pd = /* @__PURE__ */ f("ZodMiniArray", (e, t) => {
  Te.init(e, t), z.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function tr(e, t) {
  return new Pd({
    type: "array",
    element: e,
    ...h(t)
  });
}
a(tr, "array");
// @__NO_SIDE_EFFECTS__
function ly(e) {
  let t = e._zod.def.shape;
  return /* @__PURE__ */ Fd(Object.keys(t));
}
a(ly, "keyof");
var an = /* @__PURE__ */ f("ZodMiniObject", (e, t) => {
  q.init(e, t), z.init(e, t), S(e, "shape", () => t.shape);
});
// @__NO_SIDE_EFFECTS__
function tu(e, t) {
  let n = {
    type: "object",
    shape: e ?? {},
    ...h(t)
  };
  return new an(n);
}
a(tu, "object");
// @__NO_SIDE_EFFECTS__
function dy(e, t) {
  return new an({
    type: "object",
    shape: e,
    catchall: /* @__PURE__ */ Od(),
    ...h(t)
  });
}
a(dy, "strictObject");
// @__NO_SIDE_EFFECTS__
function fy(e, t) {
  return new an({
    type: "object",
    shape: e,
    catchall: /* @__PURE__ */ tn(),
    ...h(t)
  });
}
a(fy, "looseObject");
// @__NO_SIDE_EFFECTS__
function py(e, t) {
  return Pr(e, t);
}
a(py, "extend");
// @__NO_SIDE_EFFECTS__
function my(e, t) {
  return vi(e, t);
}
a(my, "safeExtend");
// @__NO_SIDE_EFFECTS__
function gy(e, t) {
  return Pr(e, t);
}
a(gy, "merge");
// @__NO_SIDE_EFFECTS__
function hy(e, t) {
  return gi(e, t);
}
a(hy, "pick");
// @__NO_SIDE_EFFECTS__
function vy(e, t) {
  return hi(e, t);
}
a(vy, "omit");
// @__NO_SIDE_EFFECTS__
function yy(e, t) {
  return yi(iu, e, t);
}
a(yy, "partial");
// @__NO_SIDE_EFFECTS__
function by(e, t) {
  return bi(ou, e, t);
}
a(by, "required");
// @__NO_SIDE_EFFECTS__
function $y(e, t) {
  return e.clone({ ...e._zod.def, catchall: t });
}
a($y, "catchall");
var ru = /* @__PURE__ */ f("ZodMiniUnion", (e, t) => {
  ee.init(e, t), z.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function sn(e, t) {
  return new ru({
    type: "union",
    options: e,
    ...h(t)
  });
}
a(sn, "union");
var Ud = /* @__PURE__ */ f("ZodMiniXor", (e, t) => {
  ru.init(e, t), ua.init(e, t);
});
function xy(e, t) {
  return new Ud({
    type: "union",
    options: e,
    inclusive: !1,
    ...h(t)
  });
}
a(xy, "xor");
var Dd = /* @__PURE__ */ f("ZodMiniDiscriminatedUnion", (e, t) => {
  Pe.init(e, t), z.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function _y(e, t, n) {
  return new Dd({
    type: "union",
    options: t,
    discriminator: e,
    ...h(n)
  });
}
a(_y, "discriminatedUnion");
var Ed = /* @__PURE__ */ f("ZodMiniIntersection", (e, t) => {
  la.init(e, t), z.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function wy(e, t) {
  return new Ed({
    type: "intersection",
    left: e,
    right: t
  });
}
a(wy, "intersection");
var Nd = /* @__PURE__ */ f("ZodMiniTuple", (e, t) => {
  Ue.init(e, t), z.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Zd(e, t, n) {
  let o = t instanceof _, r = o ? n : t, i = o ? t : null;
  return new Nd({
    type: "tuple",
    items: e,
    rest: i,
    ...h(r)
  });
}
a(Zd, "tuple");
var Gt = /* @__PURE__ */ f("ZodMiniRecord", (e, t) => {
  Ke.init(e, t), z.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Ad(e, t, n) {
  return !t || !t._zod ? new Gt({
    type: "record",
    keyType: /* @__PURE__ */ yt(),
    valueType: e,
    ...h(t)
  }) : new Gt({
    type: "record",
    keyType: e,
    valueType: t,
    ...h(n)
  });
}
a(Ad, "record");
// @__NO_SIDE_EFFECTS__
function ky(e, t, n) {
  let o = J(e);
  return o._zod.values = void 0, new Gt({
    type: "record",
    keyType: o,
    valueType: t,
    ...h(n)
  });
}
a(ky, "partialRecord");
function Iy(e, t, n) {
  return new Gt({
    type: "record",
    keyType: e,
    valueType: t,
    mode: "loose",
    ...h(n)
  });
}
a(Iy, "looseRecord");
var Cd = /* @__PURE__ */ f("ZodMiniMap", (e, t) => {
  da.init(e, t), z.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function zy(e, t, n) {
  return new Cd({
    type: "map",
    keyType: e,
    valueType: t,
    ...h(n)
  });
}
a(zy, "map");
var Rd = /* @__PURE__ */ f("ZodMiniSet", (e, t) => {
  fa.init(e, t), z.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Sy(e, t) {
  return new Rd({
    type: "set",
    valueType: e,
    ...h(t)
  });
}
a(Sy, "set");
var nu = /* @__PURE__ */ f("ZodMiniEnum", (e, t) => {
  ft.init(e, t), z.init(e, t), e.options = Object.values(t.entries);
});
// @__NO_SIDE_EFFECTS__
function Fd(e, t) {
  let n = Array.isArray(e) ? Object.fromEntries(e.map((o) => [o, o])) : e;
  return new nu({
    type: "enum",
    entries: n,
    ...h(t)
  });
}
a(Fd, "_enum");
// @__NO_SIDE_EFFECTS__
function jy(e, t) {
  return new nu({
    type: "enum",
    entries: e,
    ...h(t)
  });
}
a(jy, "nativeEnum");
var Md = /* @__PURE__ */ f("ZodMiniLiteral", (e, t) => {
  pt.init(e, t), z.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Oy(e, t) {
  return new Md({
    type: "literal",
    values: Array.isArray(e) ? e : [e],
    ...h(t)
  });
}
a(Oy, "literal");
var Ld = /* @__PURE__ */ f("ZodMiniFile", (e, t) => {
  pa.init(e, t), z.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Ty(e) {
  return Vc(Ld, e);
}
a(Ty, "file");
var Bd = /* @__PURE__ */ f("ZodMiniTransform", (e, t) => {
  ma.init(e, t), z.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Py(e) {
  return new Bd({
    type: "transform",
    transform: e
  });
}
a(Py, "transform");
var iu = /* @__PURE__ */ f("ZodMiniOptional", (e, t) => {
  L.init(e, t), z.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function cn(e) {
  return new iu({
    type: "optional",
    innerType: e
  });
}
a(cn, "optional");
var Vd = /* @__PURE__ */ f("ZodMiniExactOptional", (e, t) => {
  ga.init(e, t), z.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Uy(e) {
  return new Vd({
    type: "optional",
    innerType: e
  });
}
a(Uy, "exactOptional");
var qd = /* @__PURE__ */ f("ZodMiniNullable", (e, t) => {
  de.init(e, t), z.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function un(e) {
  return new qd({
    type: "nullable",
    innerType: e
  });
}
a(un, "nullable");
// @__NO_SIDE_EFFECTS__
function Dy(e) {
  return /* @__PURE__ */ cn(/* @__PURE__ */ un(e));
}
a(Dy, "nullish");
var Jd = /* @__PURE__ */ f("ZodMiniDefault", (e, t) => {
  se.init(e, t), z.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Ey(e, t) {
  return new Jd({
    type: "default",
    innerType: e,
    get defaultValue() {
      return typeof t == "function" ? t() : st(t);
    }
  });
}
a(Ey, "_default");
var Wd = /* @__PURE__ */ f("ZodMiniPrefault", (e, t) => {
  ha.init(e, t), z.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Ny(e, t) {
  return new Wd({
    type: "prefault",
    innerType: e,
    get defaultValue() {
      return typeof t == "function" ? t() : st(t);
    }
  });
}
a(Ny, "prefault");
var ou = /* @__PURE__ */ f("ZodMiniNonOptional", (e, t) => {
  va.init(e, t), z.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Zy(e, t) {
  return new ou({
    type: "nonoptional",
    innerType: e,
    ...h(t)
  });
}
a(Zy, "nonoptional");
var Kd = /* @__PURE__ */ f("ZodMiniSuccess", (e, t) => {
  ya.init(e, t), z.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Ay(e) {
  return new Kd({
    type: "success",
    innerType: e
  });
}
a(Ay, "success");
var Gd = /* @__PURE__ */ f("ZodMiniCatch", (e, t) => {
  ba.init(e, t), z.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Cy(e, t) {
  return new Gd({
    type: "catch",
    innerType: e,
    catchValue: typeof t == "function" ? t : () => t
  });
}
a(Cy, "_catch");
var Xd = /* @__PURE__ */ f("ZodMiniNaN", (e, t) => {
  $a.init(e, t), z.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Ry(e) {
  return $c(Xd, e);
}
a(Ry, "nan");
var au = /* @__PURE__ */ f("ZodMiniPipe", (e, t) => {
  Jr.init(e, t), z.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Fy(e, t) {
  return new au({
    type: "pipe",
    in: e,
    out: t
  });
}
a(Fy, "pipe");
var ln = /* @__PURE__ */ f("ZodMiniCodec", (e, t) => {
  au.init(e, t), ge.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function su(e, t, n) {
  return new ln({
    type: "pipe",
    in: e,
    out: t,
    transform: n.decode,
    reverseTransform: n.encode
  });
}
a(su, "codec");
// @__NO_SIDE_EFFECTS__
function My(e) {
  let t = e._zod.def;
  return new ln({
    type: "pipe",
    in: t.out,
    out: t.in,
    transform: t.reverseTransform,
    reverseTransform: t.transform
  });
}
a(My, "invertCodec");
var Hd = /* @__PURE__ */ f("ZodMiniReadonly", (e, t) => {
  xa.init(e, t), z.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Ly(e) {
  return new Hd({
    type: "readonly",
    innerType: e
  });
}
a(Ly, "readonly");
var Qd = /* @__PURE__ */ f("ZodMiniTemplateLiteral", (e, t) => {
  _a.init(e, t), z.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function By(e, t) {
  return new Qd({
    type: "template_literal",
    parts: e,
    ...h(t)
  });
}
a(By, "templateLiteral");
var Yd = /* @__PURE__ */ f("ZodMiniLazy", (e, t) => {
  mt.init(e, t), z.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function ef(e) {
  return new Yd({
    type: "lazy",
    getter: e
  });
}
a(ef, "_lazy");
var tf = /* @__PURE__ */ f("ZodMiniPromise", (e, t) => {
  ka.init(e, t), z.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Vy(e) {
  return new tf({
    type: "promise",
    innerType: e
  });
}
a(Vy, "promise");
var cu = /* @__PURE__ */ f("ZodMiniCustom", (e, t) => {
  Lt.init(e, t), z.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function qy(e, t) {
  let n = new A({
    check: "custom",
    ...h(t)
  });
  return n._zod.check = e, n;
}
a(qy, "check");
// @__NO_SIDE_EFFECTS__
function rf(e, t) {
  return qc(cu, e ?? (() => !0), t);
}
a(rf, "custom");
// @__NO_SIDE_EFFECTS__
function Jy(e, t = {}) {
  return Jc(cu, e, t);
}
a(Jy, "refine");
// @__NO_SIDE_EFFECTS__
function Wy(e, t) {
  return Wc(e, t);
}
a(Wy, "superRefine");
var Ky = Kc, Gy = Gc;
// @__NO_SIDE_EFFECTS__
function uu(e, t = {}) {
  let n = /* @__PURE__ */ rf((o) => o instanceof e, t);
  return n._zod.bag.Class = e, n._zod.check = (o) => {
    o.value instanceof e || o.issues.push({
      code: "invalid_type",
      expected: e.name,
      input: o.value,
      inst: n,
      path: [...n._zod.def.path ?? []]
    });
  }, n;
}
a(uu, "_instanceof");
var Xy = /* @__PURE__ */ a((...e) => Xc({
  Codec: ln,
  Boolean: Yt,
  String: bt
}, ...e), "stringbool");
// @__NO_SIDE_EFFECTS__
function Hy() {
  let e = /* @__PURE__ */ ef(() => /* @__PURE__ */ sn([/* @__PURE__ */ yt(), /* @__PURE__ */ rn(), /* @__PURE__ */ nn(), /* @__PURE__ */ Id(), /* @__PURE__ */ tr(e), /* @__PURE__ */ Ad(/* @__PURE__ */ yt(), e)]));
  return e;
}
a(Hy, "json");
var nf = /* @__PURE__ */ f("ZodMiniFunction", (e, t) => {
  wa.init(e, t), z.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Qy(e) {
  return new nf({
    type: "function",
    input: Array.isArray(e?.input) ? /* @__PURE__ */ Zd(e?.input) : e?.input ?? /* @__PURE__ */ tr(/* @__PURE__ */ tn()),
    output: e?.output ?? /* @__PURE__ */ tn()
  });
}
a(Qy, "_function");

// versions/4.4.3/node_modules/zod/v4/mini/iso.js
var lu = {};
Ce(lu, {
  ZodMiniISODate: () => fn,
  ZodMiniISODateTime: () => dn,
  ZodMiniISODuration: () => mn,
  ZodMiniISOTime: () => pn,
  date: () => eb,
  datetime: () => Yy,
  duration: () => rb,
  time: () => tb
});
var dn = /* @__PURE__ */ f("ZodMiniISODateTime", (e, t) => {
  Ro.init(e, t), C.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Yy(e) {
  return Ks(dn, e);
}
a(Yy, "datetime");
var fn = /* @__PURE__ */ f("ZodMiniISODate", (e, t) => {
  Fo.init(e, t), C.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function eb(e) {
  return Gs(fn, e);
}
a(eb, "date");
var pn = /* @__PURE__ */ f("ZodMiniISOTime", (e, t) => {
  Mo.init(e, t), C.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function tb(e) {
  return Xs(pn, e);
}
a(tb, "time");
var mn = /* @__PURE__ */ f("ZodMiniISODuration", (e, t) => {
  Lo.init(e, t), C.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function rb(e) {
  return Hs(mn, e);
}
a(rb, "duration");

// versions/4.4.3/node_modules/zod/v4/mini/coerce.js
var du = {};
Ce(du, {
  bigint: () => ab,
  boolean: () => ob,
  date: () => sb,
  number: () => ib,
  string: () => nb
});
// @__NO_SIDE_EFFECTS__
function nb(e) {
  return ks(bt, e);
}
a(nb, "string");
// @__NO_SIDE_EFFECTS__
function ib(e) {
  return Ys(Qt, e);
}
a(ib, "number");
// @__NO_SIDE_EFFECTS__
function ob(e) {
  return ac(Yt, e);
}
a(ob, "boolean");
// @__NO_SIDE_EFFECTS__
function ab(e) {
  return cc(er, e);
}
a(ab, "bigint");
// @__NO_SIDE_EFFECTS__
function sb(e) {
  return bc(on, e);
}
a(sb, "date");

// node_modules/zodvex/dist/mini/index.js
var af = /* @__PURE__ */ new WeakMap(), ub = {
  getMetadata: /* @__PURE__ */ a((e) => af.get(e), "getMetadata"),
  setMetadata: /* @__PURE__ */ a((e, t) => af.set(e, t), "setMetadata")
};
var sf = /* @__PURE__ */ Symbol.for("zodvex.zxDate");
function lb(e) {
  e[sf] = !0;
  let t = e._zod?.def;
  return t && (t[sf] = !0), e;
}
a(lb, "brandZxDate");
var JS = x.discriminatedUnion("success", [
  x.object({ success: x.literal(!0) }),
  x.object({ success: x.literal(!1), error: x.string() })
]), WS = x.object({
  formErrors: x.array(x.string()),
  fieldErrors: x.record(x.string(), x.array(x.string()))
});
var db = "__zodvexMeta";
function mf(e, t) {
  Object.defineProperty(e, db, {
    value: t,
    enumerable: !1,
    writable: !1,
    configurable: !1
  });
}
a(mf, "attachMeta");
var fb = "__zodvexCodecBrand";
function pb(e, t) {
  Object.defineProperty(e, fb, {
    value: t,
    enumerable: !1,
    writable: !1,
    configurable: !1
  });
}
a(pb, "attachCodecBrand");
function gf(e, t, n) {
  return x.codec(e, t, n);
}
a(gf, "zodvexCodec");
function hn(e) {
  let t = x.string().check(
    x.refine((o) => typeof o == "string" && o.length > 0, {
      message: `Invalid ID for table "${e}"`
    }),
    x.describe(`convexId:${e}`)
  );
  ub.setMetadata(t, {
    isConvexId: !0,
    tableName: e
  });
  let n = t;
  return n._tableName = e, n;
}
a(hn, "id");
function hf(e) {
  return e instanceof ee || e instanceof Pe;
}
a(hf, "isZodUnion");
function vf(e) {
  return e instanceof ee, e._zod.def.options;
}
a(vf, "getUnionOptions");
function mb(e) {
  if (e.length < 2)
    throw new Error(
      `z.union() requires at least 2 options, but received ${e.length}. This indicates an invalid union schema was passed to zodTable().`
    );
}
a(mb, "assertUnionOptions");
function yf(e) {
  return mb(e), x.union(e);
}
a(yf, "createUnionFromOptions");
function mu(e, t) {
  if (hf(t)) {
    let o = vf(t).map((r) => {
      if (r instanceof q) {
        let i = {
          ...r._zod.def.shape,
          _id: hn(e),
          _creationTime: x.number()
        };
        return J(r, { ...r._zod.def, shape: i });
      }
      return r;
    });
    return yf(o);
  }
  if (t instanceof q) {
    let n = { ...t._zod.def.shape, _id: hn(e), _creationTime: x.number() };
    return J(t, { ...t._zod.def, shape: n });
  }
  return t;
}
a(mu, "addSystemFields");
function gb(e) {
  return e instanceof L ? e : new L({ type: "optional", innerType: e });
}
a(gb, "ensureOptional");
function cf(e) {
  return new L({
    type: "optional",
    innerType: new de({ type: "nullable", innerType: e })
  });
}
a(cf, "nullableOptional2");
function hb(e) {
  let t = {};
  for (let [n, o] of Object.entries(e))
    t[n] = gb(o);
  return t;
}
a(hb, "createPartialShape");
function fu(e, t) {
  return x.object({
    _id: hn(e),
    _creationTime: x.optional(x.number()),
    ...hb(t)
  });
}
a(fu, "createUpdateObjectSchema");
function bf(e) {
  return x.object({
    page: x.array(e),
    isDone: x.boolean(),
    continueCursor: x.string(),
    splitCursor: cf(x.string()),
    pageStatus: cf(x.enum(["SplitRecommended", "SplitRequired"]))
  });
}
a(bf, "createPaginatedDocSchema");
function vb(e, t, n = x.object(t)) {
  let o = mu(e, n);
  return {
    doc: o,
    base: n,
    insert: n,
    update: fu(e, t),
    docArray: x.array(o),
    paginatedDoc: bf(o)
  };
}
a(vb, "createObjectSchemaBundle");
function $f(e, t) {
  if (hf(t)) {
    let n = vf(t).map((o) => o instanceof q ? fu(e, o._zod.def.shape) : o);
    return yf(n);
  }
  return t instanceof q ? fu(e, t._zod.def.shape) : t;
}
a($f, "createSchemaUpdateSchema");
function yb(e, t) {
  let n = mu(e, t);
  return {
    doc: n,
    base: t,
    insert: t,
    update: $f(e, t),
    docArray: x.array(n),
    paginatedDoc: bf(n)
  };
}
a(yb, "createSchemaBundle");
function xf(e, t) {
  let n;
  return {
    get: /* @__PURE__ */ a(() => n || (n = t ?? x.object(e), n), "get")
  };
}
a(xf, "lazyValidator");
function rr(e, t, n, o, r = {}, i = {}, s = {}, c = null) {
  let u = xf(t, c), l = {
    name: e,
    fields: t,
    schema: n,
    indexes: r,
    searchIndexes: i,
    vectorIndexes: s,
    get validator() {
      return u.get();
    },
    index(d, g) {
      return rr(
        e,
        t,
        n,
        o,
        { ...r, [d]: [...g, "_creationTime"] },
        i,
        s,
        c
      );
    },
    searchIndex(d, g) {
      return rr(
        e,
        t,
        n,
        o,
        r,
        { ...i, [d]: g },
        s,
        c
      );
    },
    vectorIndex(d, g) {
      return rr(
        e,
        t,
        n,
        o,
        r,
        i,
        { ...s, [d]: g },
        c
      );
    }
  };
  return mf(l, { type: "model", tableName: e, definitionSource: o, schemas: n }), l;
}
a(rr, "createModel");
function nr(e, t, n, o, r = {}, i = {}, s = {}) {
  let c = xf(t, n), u = {
    name: e,
    fields: t,
    indexes: r,
    searchIndexes: i,
    vectorIndexes: s,
    get validator() {
      return c.get();
    },
    index(l, d) {
      return nr(
        e,
        t,
        n,
        o,
        { ...r, [l]: [...d, "_creationTime"] },
        i,
        s
      );
    },
    searchIndex(l, d) {
      return nr(
        e,
        t,
        n,
        o,
        r,
        { ...i, [l]: d },
        s
      );
    },
    vectorIndex(l, d) {
      return nr(e, t, n, o, r, i, {
        ...s,
        [l]: d
      });
    }
  };
  return n !== null && (u.schema = n), mf(u, { type: "model", tableName: e, definitionSource: o }), u;
}
a(nr, "createSlimModel");
function uf(e, t, n) {
  let o = n?.schemaHelpers === !1;
  if (t instanceof _)
    return o ? nr(e, {}, t, "schema") : rr(
      e,
      {},
      yb(e, t),
      "schema",
      void 0,
      void 0,
      void 0,
      t
    );
  let r = t;
  return o ? nr(e, r, null, "shape") : rr(e, r, vb(e, r), "shape");
}
a(uf, "defineZodModel");
function _f(e, t, n) {
  return t instanceof _, uf(e, t, n);
}
a(_f, "defineZodModel2");
function bb() {
  return lb(
    gf(
      x.number(),
      // Wire: timestamp
      x.custom((e) => e instanceof Date, {
        message: "Expected Date instance"
      }),
      {
        decode: /* @__PURE__ */ a((e) => new Date(e), "decode"),
        encode: /* @__PURE__ */ a((e) => e.getTime(), "encode")
      }
    )
  );
}
a(bb, "date");
function $b(e, t, n, o) {
  let r = gf(e, t, n);
  return o?.brand && pb(r, o.brand), r;
}
a($b, "codec");
function vn(e) {
  let t = /* @__PURE__ */ Symbol.for(`zodvex.zx.cache.${e}`), n = globalThis, o = n[t];
  if (o) return o;
  let r = /* @__PURE__ */ new WeakMap();
  return n[t] = r, r;
}
a(vn, "sharedWeakMap");
var lf = vn("base"), df = vn("doc"), ff = vn("update"), pf = vn("docArray");
function gu(e) {
  let t = e.schema;
  return t instanceof _ ? t : e.fields;
}
a(gu, "slimCacheKey");
function hu(e) {
  let t = e.schema;
  if (t?.base instanceof _) return t.base;
  if (t instanceof _) return t;
  let n = lf.get(e.fields);
  if (n) return n;
  if (Object.keys(e.fields).length === 0)
    throw new Error(`[zodvex] Cannot derive base schema for model '${e.name}'`);
  let o = x.object(e.fields);
  return lf.set(e.fields, o), o;
}
a(hu, "base");
function wf(e) {
  let t = e.schema;
  if (t?.doc instanceof _) return t.doc;
  let n = gu(e), o = df.get(n);
  if (o) return o;
  let r = mu(e.name, hu(e));
  return df.set(n, r), r;
}
a(wf, "doc");
function xb(e) {
  let t = e.schema;
  if (t?.update instanceof _) return t.update;
  let n = gu(e), o = ff.get(n);
  if (o) return o;
  let r = $f(e.name, hu(e));
  return ff.set(n, r), r;
}
a(xb, "update");
function _b(e) {
  let t = e.schema;
  if (t?.docArray instanceof _) return t.docArray;
  let n = gu(e), o = pf.get(n);
  if (o) return o;
  let r = x.array(wf(e));
  return pf.set(n, r), r;
}
a(_b, "docArray");
function kf(e) {
  return new de({ type: "nullable", innerType: e });
}
a(kf, "nullable");
function gn(e) {
  return new L({ type: "optional", innerType: e });
}
a(gn, "optional");
function pu(e) {
  return gn(kf(e));
}
a(pu, "nullableOptional3");
function wb() {
  return x.object({
    numItems: x.number(),
    cursor: kf(x.string()),
    endCursor: pu(x.string()),
    id: gn(x.number()),
    maximumRowsRead: gn(x.number()),
    maximumBytesRead: gn(x.number())
  });
}
a(wb, "paginationOpts");
function kb(e) {
  return x.object({
    page: x.array(e),
    isDone: x.boolean(),
    continueCursor: x.string(),
    splitCursor: pu(x.string()),
    pageStatus: pu(x.enum(["SplitRecommended", "SplitRequired"]))
  });
}
a(kb, "paginationResult");
var we = {
  /**
   * Date ↔ timestamp codec
   * @see {@link date}
   */
  date: bb,
  /**
   * Convex ID validator
   * @see {@link id}
   */
  id: hn,
  /**
   * Custom codec builder
   * @see {@link codec}
   */
  codec: $b,
  /**
   * Pagination options schema matching Convex's PaginationOptions type
   * @see {@link paginationOpts}
   */
  paginationOpts: wb,
  /**
   * Paginated result schema wrapping any item schema in Convex's PaginationResult shape
   * @see {@link paginationResult}
   */
  paginationResult: kb,
  /**
   * Base schema for a model (user fields only; no system fields).
   * For object models reconstructs from fields; for union models returns the
   * user-supplied union. Cached per-model.
   * @see {@link base}
   */
  base: hu,
  /**
   * Doc schema: model fields + _id + _creationTime
   * @see {@link doc}
   */
  doc: wf,
  /**
   * Update schema: _id required, all other fields optional
   * @see {@link update}
   */
  update: xb,
  /**
   * Doc array schema: z.array(doc(model))
   * @see {@link docArray}
   */
  docArray: _b
};
function Ib() {
  return we.date();
}
a(Ib, "date2");
function zb(e) {
  return we.id(e);
}
a(zb, "id2");
function Sb(e, t, n, o) {
  return we.codec(e, t, n, o);
}
a(Sb, "codec2");
var KS = {
  date: Ib,
  id: zb,
  codec: Sb,
  paginationOpts: we.paginationOpts,
  paginationResult: we.paginationResult,
  base: we.base,
  doc: we.doc,
  update: we.update,
  docArray: we.docArray
};

// ../zodvex-triage-20260909/node_modules/.bun/convex-helpers@0.1.113+b9ed8f5244cf7f28/node_modules/convex-helpers/index.js
var HS = Symbol();

// ../zodvex-triage-20260909/node_modules/.bun/convex-helpers@0.1.113+b9ed8f5244cf7f28/node_modules/convex-helpers/validators.js
var nj = m.string(), ij = m.float64(), oj = m.float64(), aj = m.boolean(), sj = m.int64(), cj = m.int64(), uj = m.any(), lj = m.null(), { id: dj, object: fj, array: pj, bytes: mj, literal: gj, optional: hj, union: vj } = m, yj = m.bytes();
var bj = m.optional(m.any());

// ../zodvex-triage-20260909/node_modules/.bun/convex-helpers@0.1.113+b9ed8f5244cf7f28/node_modules/convex-helpers/server/customFunctions.js
var yn = {
  args: {},
  input() {
    return { args: {}, ctx: {} };
  }
};

// node_modules/zodvex/dist/mini/server/index.js
function If(e) {
  let t = e;
  for (let n = 0; n < 10; n++) {
    if (t instanceof L || t instanceof de || t instanceof se) {
      t = t._zod.def.innerType;
      continue;
    }
    break;
  }
  return t;
}
a(If, "unwrapOuter");
function jb(e, t) {
  let n = [], o = t;
  for (let r of e) {
    if (o = If(o), o instanceof ge)
      break;
    if (o instanceof q && typeof r == "string") {
      let i = o._zod.def.shape[r];
      if (!i) {
        n.push(r);
        break;
      }
      if (n.push(r), If(i) instanceof ge)
        break;
      o = i;
      continue;
    }
    if (o instanceof Te && typeof r == "number") {
      n.push(r), o = o._zod.def.element;
      continue;
    }
    n.push(r);
  }
  return n;
}
a(jb, "truncateAtCodecBoundary");
function Ob(e, t) {
  let n = e.issues.map((o) => ({
    ...o,
    path: jb(o.path, t)
  }));
  return new _e(n);
}
a(Ob, "normalizeCodecPaths");
function Tb(e, t) {
  try {
    return Y(e, t);
  } catch (n) {
    throw n instanceof _e ? Ob(n, e) : n;
  }
}
a(Tb, "safeEncode");
function Ae(e) {
  if (e == null)
    return e;
  if (Array.isArray(e))
    return e.map(Ae);
  if (typeof e == "object" && e.constructor === Object) {
    let t = {};
    for (let [n, o] of Object.entries(e))
      o !== void 0 && (t[n] = Ae(o));
    return t;
  }
  return e;
}
a(Ae, "stripUndefined");
var Pb = /* @__PURE__ */ Symbol.for("functionName");
function zf(e) {
  if (typeof e == "string") return e;
  let t = e[Pb];
  return t || null;
}
a(zf, "resolveFunctionPath");
var Ub = class extends _e {
  static {
    a(this, "ZodvexDecodeError");
  }
  functionPath;
  wireData;
  constructor(e, t, n) {
    super(t), this.functionPath = e, this.wireData = n, this.name = "ZodvexDecodeError";
  }
}, Sf = /* @__PURE__ */ new Set();
function Db(e, t) {
  let n = t?.onDecodeError ?? "warn", o = t?.warnWirePreview === !0;
  function r(s, c) {
    if (c == null) return c;
    let u = zf(s);
    if (u == null) return c;
    let l = e[u];
    return l?.args ? Ae(Tb(l.args, c)) : (l === void 0 && !Sf.has(u) && (Sf.add(u), console.debug(
      `[zodvex] No registry entry for "${u}" \u2014 args/returns pass through unencoded. This is expected when the target is a raw (non-zodvex) function; if it should be codec-aware, run \`zodvex generate\` to update the registry.`
    )), c);
  }
  a(r, "encodeArgs");
  function i(s, c) {
    let u = zf(s);
    if (u == null) return c;
    let l = e[u];
    if (!l?.returns) return c;
    let d = me(l.returns, c);
    if (d.success) return d.data;
    if (n === "throw")
      throw new Ub(u, d.error.issues, c);
    let g = d.error.issues.map((v) => `${v.path.join(".")}: ${v.message}`).join(", "), $ = `[zodvex] Decode failed for ${u}: ${g}. Returning raw wire data.`;
    if (o) {
      let v = "[unavailable]";
      try {
        v = JSON.stringify(c) ?? "[unavailable]";
      } catch {
      }
      let k = v.length > 200 ? `${v.slice(0, 200)}...` : v;
      $ += ` Preview: ${k}`;
    }
    return console.warn($), c;
  }
  return a(i, "decodeResult"), { encodeArgs: r, decodeResult: i };
}
a(Db, "createBoundaryHelpers");
function jf(e, t) {
  return async (n, ...o) => {
    let r = t.encodeArgs(n, o[0]), i = await e(n, r);
    return t.decodeResult(n, i);
  };
}
a(jf, "wrapRun");
function Eb(e, t) {
  let n = { ...e };
  return n.runAfter = (o, r, ...i) => {
    let s = t.encodeArgs(r, i[0]);
    return e.runAfter(o, r, ...i.length ? [s] : []);
  }, n.runAt = (o, r, ...i) => {
    let s = t.encodeArgs(r, i[0]);
    return e.runAt(o, r, ...i.length ? [s] : []);
  }, n;
}
a(Eb, "wrapScheduler");
function Gf(e, t, n) {
  let o = Db(e, n), r = {};
  return typeof t.runQuery == "function" && (r.runQuery = jf(t.runQuery, o)), typeof t.runMutation == "function" && (r.runMutation = jf(t.runMutation, o)), t.scheduler && (r.scheduler = Eb(t.scheduler, o)), r;
}
a(Gf, "createCodecCallOverrides");
var Of = /* @__PURE__ */ new WeakMap(), _n = {
  getMetadata: /* @__PURE__ */ a((e) => Of.get(e), "getMetadata"),
  setMetadata: /* @__PURE__ */ a((e, t) => Of.set(e, t), "setMetadata")
};
function Nb(e) {
  let t = e._zod.def.entries, n = Object.keys(t);
  if (n && Array.isArray(n) && n.length > 0) {
    let o = n.filter((r) => r != null).map((r) => m.literal(r));
    if (o.length === 1) {
      let [r] = o;
      return r;
    } else if (o.length >= 2) {
      let [r, i, ...s] = o;
      return m.union(
        r,
        i,
        ...s
      );
    } else
      return m.any();
  } else
    return m.any();
}
a(Nb, "convertEnumType");
function Zb(e, t, n) {
  let o = e._zod.def.innerType;
  if (o && o instanceof _)
    if (o instanceof L) {
      let r = o._zod.def.innerType, i = n(r, t);
      return {
        validator: m.union(i, m.null()),
        isOptional: !0
        // Mark as optional so it gets wrapped later
      };
    } else {
      let r = n(o, t);
      return {
        validator: m.union(r, m.null()),
        isOptional: !1
      };
    }
  else
    return {
      validator: m.any(),
      isOptional: !1
    };
}
a(Zb, "convertNullableType");
function Ab(e, t, n) {
  let o = e._zod.def.valueType;
  if (o || (o = e._zod.def.keyType), o && o instanceof _)
    if (o instanceof L || o instanceof se || o instanceof se && o._zod.def.innerType instanceof L) {
      let i, s, c = !1;
      if (o instanceof se) {
        c = !0, s = o._zod.def.defaultValue;
        let d = o._zod.def.innerType;
        d instanceof L ? i = d._zod.def.innerType : i = d;
      } else o instanceof L ? i = o._zod.def.innerType : i = o;
      let u = n(i, t), l = m.union(u, m.null());
      return c && (l._zodDefault = s), m.record(m.string(), l);
    } else
      return m.record(m.string(), n(o, t));
  else
    return m.record(m.string(), m.any());
}
a(Ab, "convertRecordType");
function Cb(e, t, n) {
  let o = e instanceof Pe ? e._zod.def.options : (
    // cast: fallback for non-standard discriminated union variants
    e._zod?.def?.options
  );
  if (o) {
    let r = Array.isArray(o) ? o : Array.from(o);
    if (r.length >= 2) {
      let i = r.map((l) => {
        let d = new Set(t);
        return n(l, d);
      }), [s, c, ...u] = i;
      return m.union(
        s,
        c,
        ...u
      );
    } else
      return m.any();
  } else
    return m.any();
}
a(Cb, "convertDiscriminatedUnionType");
function Rb(e, t, n) {
  let o = e._zod.def.options;
  if (o && Array.isArray(o) && o.length > 0) {
    if (o.length === 1)
      return n(o[0], t);
    {
      let r = o.map((i) => {
        let s = new Set(t);
        return n(i, s);
      });
      if (r.length >= 2) {
        let [i, s, ...c] = r;
        return m.union(
          i,
          s,
          ...c
        );
      } else
        return m.any();
    }
  } else
    return m.any();
}
a(Rb, "convertUnionType");
function Fb(e) {
  let t = _n.getMetadata(e);
  return t?.isConvexId === !0 && t?.tableName && typeof t.tableName == "string";
}
a(Fb, "isZid");
var Tf = /* @__PURE__ */ new WeakMap();
function oe(e, t = /* @__PURE__ */ new Set()) {
  if (!e)
    return m.any();
  let n = Tf.get(e);
  if (n)
    return n;
  if (t.has(e))
    return m.any();
  t.add(e);
  let o = e, r = !1, i, s = !1;
  e instanceof se && (s = !0, i = e._zod.def.defaultValue, o = e._zod.def.innerType), o instanceof L && (r = !0, o = o._zod.def.innerType, o instanceof se && (s = !0, i = o._zod.def.defaultValue, o = o._zod.def.innerType));
  let c;
  if (Fb(o)) {
    let d = _n.getMetadata(o)?.tableName || "unknown";
    c = m.id(d);
  } else
    switch (o._zod.def.type) {
      case "string":
        c = m.string();
        break;
      case "number":
        c = m.float64();
        break;
      case "bigint":
        c = m.int64();
        break;
      case "boolean":
        c = m.boolean();
        break;
      case "date":
        c = m.float64();
        break;
      case "null":
        c = m.null();
        break;
      case "nan":
        c = m.float64();
        break;
      case "array": {
        if (o instanceof Te) {
          let d = o._zod.def.element;
          c = m.array(oe(d, t));
        } else
          c = m.array(m.any());
        break;
      }
      case "object": {
        if (o instanceof q) {
          let d = o._zod.def.shape, g = {};
          for (let [$, v] of Object.entries(d))
            v && v instanceof _ && (g[$] = oe(v, t));
          c = m.object(g);
        } else
          c = m.object({});
        break;
      }
      case "union": {
        o instanceof ee ? c = Rb(o, t, oe) : c = m.any();
        break;
      }
      case "discriminatedUnion": {
        c = Cb(
          o,
          t,
          oe
        );
        break;
      }
      case "literal": {
        if (o instanceof pt) {
          let g = o._zod.def.values.values().next().value;
          g != null ? c = m.literal(g) : c = m.any();
        } else
          c = m.any();
        break;
      }
      case "enum": {
        o instanceof ft ? c = Nb(o) : c = m.any();
        break;
      }
      case "record": {
        o instanceof Ke ? c = Ab(o, t, oe) : c = m.record(m.string(), m.any());
        break;
      }
      case "transform":
      case "pipe": {
        if (o instanceof ge) {
          let d = o._zod.def.in;
          d && d instanceof _ ? c = oe(d, t) : c = m.any();
        } else {
          let d = _n.getMetadata(o);
          if (d?.brand && d?.originalSchema)
            c = oe(d.originalSchema, t);
          else {
            let g = o._zod?.def?.in;
            g && g instanceof _ ? c = oe(g, t) : c = m.any();
          }
        }
        break;
      }
      case "nullable": {
        if (o instanceof de) {
          let d = Zb(o, t, oe);
          c = d.validator, d.isOptional && (r = !0);
        } else
          c = m.any();
        break;
      }
      case "tuple": {
        if (o instanceof Ue) {
          let d = o._zod.def.items;
          if (d && d.length > 0) {
            let g = {};
            d.forEach(($, v) => {
              g[`_${v}`] = oe($, t);
            }), c = m.object(g);
          } else
            c = m.object({});
        } else
          c = m.object({});
        break;
      }
      case "lazy": {
        if (o instanceof mt)
          try {
            let d = o._zod.def.getter;
            if (d) {
              let g = d();
              g && g instanceof _ ? c = oe(g, t) : c = m.any();
            } else
              c = m.any();
          } catch {
            c = m.any();
          }
        else
          c = m.any();
        break;
      }
      case "any":
        c = m.any();
        break;
      case "unknown":
        c = m.any();
        break;
      case "undefined":
      case "void":
      case "never":
        c = m.any();
        break;
      case "intersection":
        c = m.any();
        break;
      case "optional": {
        let d = o._zod?.def?.innerType;
        d && d instanceof _ ? (c = oe(d, t), r = !0) : (c = m.any(), r = !0);
        break;
      }
      default:
        c = m.any();
        break;
    }
  let u = r || s ? m.optional(c) : c;
  return s && typeof u == "object" && u !== null && (u._zodDefault = i), Tf.set(e, u), u;
}
a(oe, "zodToConvexInternal");
function Xf(e) {
  return typeof e == "object" && e !== null && !(e instanceof _) ? wn(e) : oe(e);
}
a(Xf, "zodToConvex");
function wn(e) {
  let t = e instanceof q ? e._zod.def.shape : e, n = {};
  for (let [o, r] of Object.entries(t))
    n[o] = oe(r);
  return n;
}
a(wn, "zodToConvexFields");
function Ge(e) {
  if (e instanceof dt) return !0;
  if (e instanceof ge) return !1;
  if (e instanceof L || e instanceof de || e instanceof se)
    return Ge(e._zod.def.innerType);
  if (e instanceof q)
    return Object.values(e._zod.def.shape).some((t) => Ge(t));
  if (e instanceof Te)
    return Ge(e._zod.def.element);
  if (e instanceof ee)
    return e._zod.def.options.some((t) => Ge(t));
  if (e instanceof Ke)
    return Ge(e._zod.def.valueType);
  if (e instanceof Ue) {
    let t = e._zod.def.items;
    return t ? t.some((n) => Ge(n)) : !1;
  }
  return !1;
}
a(Ge, "containsNativeZodDate");
function Pf(e, t) {
  if (Ge(e))
    throw new Error(
      `[zodvex] Native z.date() found in ${t}. Convex stores dates as timestamps (numbers), which z.date() cannot parse.

Fix: Replace z.date() with zx.date()

Before: { createdAt: z.date() }
After:  { createdAt: zx.date() }

zx.date() is a codec that handles timestamp \u2194 Date conversion automatically.`
    );
}
a(Pf, "assertNoNativeZodDate");
function Hf(e, t) {
  return ie(e, t);
}
a(Hf, "decodeDoc");
function Uf(e, t) {
  return Ae(Y(e, t));
}
a(Uf, "encodeDoc");
function Df(e) {
  let t = {};
  for (let [n, o] of Object.entries(e))
    t[n] = o === void 0 ? void 0 : Ae(o);
  return t;
}
a(Df, "stripUndefinedPreservingTopLevel");
function Mb(e, t) {
  if (!(e instanceof q)) {
    let s = Y(e, t);
    return s !== null && typeof s == "object" && !Array.isArray(s) ? Df(s) : Ae(s);
  }
  let n = e._zod.def.shape, o = {};
  for (let [s, c] of Object.entries(n))
    o[s] = c instanceof L ? c : new L({ type: "optional", innerType: c });
  let r = x.object(o), i = Y(r, t);
  return Df(i);
}
a(Mb, "encodePartialDoc");
function Qf(e, t, n) {
  return x.codec(e, t, n);
}
a(Qf, "zodvexCodec");
function vu(e, t, n) {
  if (t.includes(".")) return n;
  if (e instanceof q) {
    let o = e.shape[t];
    if (o) return Y(o, n);
  }
  if (e instanceof ee) {
    let r = e._zod.def.options.filter((i) => i instanceof q).map((i) => i.shape[t]).filter(Boolean);
    if (r.length === 1) return Y(r[0], n);
    if (r.length > 1)
      return Y(x.union(r), n);
  }
  return n;
}
a(vu, "encodeIndexValue");
function kn(e, t) {
  return new Proxy(e, {
    get(n, o, r) {
      return typeof o == "string" && ["eq", "gt", "gte", "lt", "lte"].includes(o) ? (i, s) => {
        let c = vu(t, i, s), u = n[o](i, c);
        return kn(u, t);
      } : o === "search" ? (...i) => {
        let s = n.search(...i);
        return kn(s, t);
      } : Reflect.get(n, o, r);
    }
  });
}
a(kn, "wrapIndexRangeBuilder");
function yu(e, t) {
  return e != null && Object.prototype.isPrototypeOf.call(t, e);
}
a(yu, "isFilterExpression");
function Ef(e, t) {
  if (yu(e, t)) {
    let n = e.serialize();
    if (n && typeof n == "object" && "$field" in n)
      return n.$field;
  }
  return null;
}
a(Ef, "extractFieldPath");
function Lb(e, t) {
  let n = Object.getPrototypeOf(e.field("_id"));
  return new Proxy(e, {
    get(o, r, i) {
      return typeof r == "string" && ["eq", "neq", "lt", "lte", "gt", "gte"].includes(r) ? (s, c) => {
        let u = Ef(s, n), l = Ef(c, n);
        return u && !yu(c, n) ? c = vu(t, u, c) : l && !yu(s, n) && (s = vu(t, l, s)), o[r](s, c);
      } : Reflect.get(o, r, i);
    }
  });
}
a(Lb, "wrapFilterBuilder");
var wu = class Yf {
  static {
    a(this, "_ZodvexQueryChain");
  }
  constructor(t, n) {
    this.inner = t, this.schema = n;
  }
  /** Factory method for intermediate methods. Subclasses override to return their own type. */
  createChain(t) {
    return new Yf(t, this.schema);
  }
  /** Decode a wire-format doc and cast to the decoded document type. */
  decode(t) {
    return Hf(this.schema, t);
  }
  // --- Intermediate methods: wire-typed TableInfo for Convex machinery ---
  fullTableScan() {
    return this.createChain(this.inner.fullTableScan());
  }
  withIndex(t, n) {
    let o = n ? (r) => n(kn(r, this.schema)) : void 0;
    return this.createChain(this.inner.withIndex(t, o));
  }
  withSearchIndex(t, n) {
    let o = /* @__PURE__ */ a((r) => n(kn(r, this.schema)), "wrappedFilter");
    return this.createChain(this.inner.withSearchIndex(t, o));
  }
  order(t) {
    return this.createChain(this.inner.order(t));
  }
  // Implementation
  filter(t) {
    let n = /* @__PURE__ */ a((o) => t(Lb(o, this.schema)), "wrappedPredicate");
    return this.createChain(this.inner.filter(n));
  }
  limit(t) {
    return this.createChain(this.inner.limit(t));
  }
  count() {
    return this.inner.count();
  }
  // --- Terminal methods: return decoded Doc type ---
  async first() {
    let t = await this.inner.first();
    return t ? this.decode(t) : null;
  }
  async unique() {
    let t = await this.inner.unique();
    return t ? this.decode(t) : null;
  }
  async collect() {
    return (await this.inner.collect()).map((n) => this.decode(n));
  }
  async take(t) {
    return (await this.inner.take(t)).map((o) => this.decode(o));
  }
  async paginate(t) {
    let n = await this.inner.paginate(t);
    return {
      ...n,
      page: n.page.map((o) => this.decode(o))
    };
  }
  // --- AsyncIterable: decode each yielded document ---
  async *[Symbol.asyncIterator]() {
    for await (let t of this.inner)
      yield this.decode(t);
  }
};
function bu(e, t, n) {
  for (let o of Object.keys(t))
    if (e.normalizeId(o, n))
      return o;
  return null;
}
a(bu, "resolveTableName");
var zn = class {
  static {
    a(this, "ZodvexDatabaseReader");
  }
  constructor(e, t) {
    this.db = e, this.tableMap = t, this.system = e.system;
  }
  system;
  /** @internal Expose for wrapper construction (rule/audit subclasses) */
  get _internals() {
    return { db: this.db, tableMap: this.tableMap };
  }
  /**
   * Escape hatch (#85/#92): returns the database this codec wrapper delegates
   * to — the composed underlying stack when `underlyingDb` is configured (e.g.
   * a trigger-wrapped writer), the bare Convex db otherwise.
   *
   * The returned db is native-shape: reads are undecoded wire documents and it
   * bypasses codec, `.withRules()`, and `.audit()` layers entirely.
   */
  unwrap() {
    return this.db;
  }
  normalizeId(e, t) {
    return this.db.normalizeId(e, t);
  }
  async get(e, t) {
    let n, o;
    if (t !== void 0 ? (n = e, o = await this.db.get(e, t)) : (o = await this.db.get(e), n = o ? bu(this.db, this.tableMap, e) : null), !o) return null;
    let r = n ? this.tableMap[n] : void 0;
    return r ? Hf(r.doc, o) : o;
  }
  query(e) {
    let t = this.tableMap[e], n = this.db.query(e);
    return t ? new wu(n, t.doc) : n;
  }
  /**
   * Returns a new ZodvexDatabaseReader that applies per-table read rules.
   * The returned reader is also a ZodvexDatabaseReader, so `.withRules()` can be chained.
   */
  withRules(e, t, n) {
    return new tp(this, e, t, n ?? {});
  }
  /**
   * Returns a new ZodvexDatabaseReader that fires audit callbacks on reads.
   * The returned reader is also a ZodvexDatabaseReader, so `.audit()` can be chained
   * with `.withRules()`.
   */
  audit(e) {
    return new np(this, e);
  }
}, ku = class extends zn {
  static {
    a(this, "ZodvexDatabaseWriter");
  }
  // Narrows the inherited `protected db` to the writer-typed view without
  // shadowing the underlying instance. Used by the write methods below.
  get writerDb() {
    return this.db;
  }
  constructor(e, t) {
    super(e, t), this.system = e.system;
  }
  /**
   * @internal Expose writer-typed internals for rules / audit subclasses.
   * Includes a `reader` field that aliases `this` (writer IS-A reader after
   * the #64 refactor) so callers expecting `_internals.reader` still work.
   */
  get _internals() {
    return { db: this.writerDb, tableMap: this.tableMap, reader: this };
  }
  /**
   * Escape hatch (#85/#92): returns the writer this codec wrapper delegates
   * to — the composed underlying stack when `underlyingDb` is configured (e.g.
   * a trigger-wrapped writer), the bare Convex db otherwise.
   *
   * The returned db is native-shape: writes must be wire-format and it
   * bypasses codec, `.withRules()`, and `.audit()` layers entirely.
   */
  unwrap() {
    return this.writerDb;
  }
  async insert(e, t) {
    let n = this.tableMap[e], o = n ? Uf(n.insert, t) : t;
    return this.writerDb.insert(e, o);
  }
  async patch(e, t, n) {
    let o, r, i;
    n !== void 0 ? (o = e, r = t, i = n) : (r = e, i = t, o = bu(this.db, this.tableMap, r));
    let s = o ? this.tableMap[o] : void 0, c = s ? Mb(s.insert, i) : i;
    return n !== void 0 ? this.writerDb.patch(e, r, c) : this.writerDb.patch(r, c);
  }
  async replace(e, t, n) {
    let o, r, i;
    n !== void 0 ? (o = e, r = t, i = n) : (r = e, i = t, o = bu(this.db, this.tableMap, r));
    let s = o ? this.tableMap[o] : void 0, c = s ? Uf(s.insert, i) : i;
    return n !== void 0 ? this.writerDb.replace(e, r, c) : this.writerDb.replace(r, c);
  }
  async delete(e, t) {
    return t !== void 0 ? this.writerDb.delete(e, t) : this.writerDb.delete(e);
  }
  /**
   * Returns a new ZodvexDatabaseWriter that applies per-table read and write rules.
   * The returned writer is also a ZodvexDatabaseWriter, so `.withRules()` can be chained.
   *
   * Overrides Reader's signature so a writer chained call returns a writer.
   */
  withRules(e, t, n) {
    return new Vb(this, e, t, n ?? {});
  }
  /**
   * Returns a new ZodvexDatabaseWriter that fires audit callbacks on reads and writes.
   * The returned writer is also a ZodvexDatabaseWriter, so `.audit()` can be chained
   * with `.withRules()`.
   *
   * Overrides Reader's signature so a writer chained call returns a writer.
   */
  audit(e) {
    return new Jb(this, e);
  }
};
function bn(e, t) {
  return e === !0 ? t : e === !1 ? null : e;
}
a(bn, "normalizeReadResult");
var Bb = class ep extends wu {
  static {
    a(this, "_RulesQueryChain");
  }
  readRule;
  rulesConfig;
  ctx;
  constructor(t, n, o, r, i = {}) {
    super(t, n), this.readRule = o, this.rulesConfig = r, this.ctx = i;
  }
  createChain(t) {
    return new ep(t, this.schema, this.readRule, this.rulesConfig, this.ctx);
  }
  async first() {
    for await (let t of this)
      return t;
    return null;
  }
  async unique() {
    let t = await super.unique();
    return t === null ? null : bn(await this.readRule(this.ctx, t), t);
  }
  async collect() {
    let t = [];
    for await (let n of this)
      t.push(n);
    return t;
  }
  async take(t) {
    if (!Number.isInteger(t) || t < 0)
      throw new Error("take requires a non-negative integer");
    let n = [];
    if (t === 0) return n;
    for await (let o of this)
      if (n.push(o), n.length >= t) break;
    return n;
  }
  async paginate(t) {
    let n = await super.paginate(t), o = [];
    for (let r of n.page) {
      let i = bn(await this.readRule(this.ctx, r), r);
      i !== null && o.push(i);
    }
    return { ...n, page: o };
  }
  async count() {
    if (!this.rulesConfig.allowCounting)
      throw new Error("count is not allowed with rules");
    return super.count();
  }
  async *[Symbol.asyncIterator]() {
    for await (let t of super[Symbol.asyncIterator]()) {
      let n = bn(await this.readRule(this.ctx, t), t);
      n !== null && (yield n);
    }
  }
};
function $n(e, t, n, o) {
  for (let r of Object.keys(n))
    if (e.normalizeId(r, t))
      return r;
  if ((o.defaultPolicy ?? "allow") === "deny") {
    for (let r of Object.keys(e._internals.tableMap))
      if (e.normalizeId(r, t))
        return r;
  }
  return null;
}
a($n, "resolveRulesTableName");
var tp = class extends zn {
  static {
    a(this, "RulesDatabaseReader");
  }
  constructor(e, t, n, o) {
    let { db: r, tableMap: i } = e._internals;
    super(r, i), this.inner = e, this.ctx = t, this.rules = n, this.rulesConfig = o, this.system = e.system;
  }
  async get(e, t) {
    let n = await this.inner.get(e, t);
    if (n === null) return null;
    let o = t !== void 0 ? e : $n(this.inner, e, this.rules, this.rulesConfig);
    return o ? this.applyReadRule(o, n) : n;
  }
  query(e) {
    let t = this.rules[e];
    if (!t?.read && (this.rulesConfig.defaultPolicy ?? "allow") === "allow")
      return this.inner.query(e);
    let n = this.inner.query(e), o = t?.read ?? (async () => null), r = x.any();
    return new Bb(n, r, o, this.rulesConfig, this.ctx);
  }
  async applyReadRule(e, t) {
    let n = this.rules[e];
    if (!n?.read)
      return (this.rulesConfig.defaultPolicy ?? "allow") === "deny" ? null : t;
    let o = await n.read(this.ctx, t);
    return bn(o, t);
  }
}, Vb = class extends ku {
  static {
    a(this, "RulesDatabaseWriter");
  }
  constructor(e, t, n, o) {
    let { db: r, tableMap: i, reader: s } = e._internals;
    super(r, i), this.inner = e, this.ctx = t, this.rules = n, this.rulesConfig = o, this.rulesReader = new tp(s, t, n, o), this.system = e.system;
  }
  rulesReader;
  normalizeId(e, t) {
    return this.rulesReader.normalizeId(e, t);
  }
  async get(e, t) {
    return this.rulesReader.get(e, t);
  }
  query(e) {
    return this.rulesReader.query(e);
  }
  async insert(e, t) {
    let n = e, o = this.rules[n];
    if (o?.insert) {
      let r = await o.insert(this.ctx, t);
      return this.inner.insert(
        e,
        r
      );
    }
    if ((this.rulesConfig.defaultPolicy ?? "allow") === "deny")
      throw new Error(`insert not allowed on ${n}`);
    return this.inner.insert(e, t);
  }
  async patch(e, t, n) {
    let o, r;
    n !== void 0 ? (o = t, r = n) : (o = e, r = t);
    let i = await this.rulesReader.get(o);
    if (i === null)
      throw new Error("no read access or doc does not exist");
    let s = $n(this.inner, o, this.rules, this.rulesConfig), c = s ? this.rules[s] : void 0;
    if (c?.patch) {
      let u = await c.patch(this.ctx, i, r);
      return this.inner.patch(
        o,
        u
      );
    }
    if ((this.rulesConfig.defaultPolicy ?? "allow") === "deny")
      throw new Error(`patch not allowed on ${s}`);
    return this.inner.patch(o, r);
  }
  async replace(e, t, n) {
    let o, r;
    n !== void 0 ? (o = t, r = n) : (o = e, r = t);
    let i = await this.rulesReader.get(o);
    if (i === null)
      throw new Error("no read access or doc does not exist");
    let s = $n(this.inner, o, this.rules, this.rulesConfig), c = s ? this.rules[s] : void 0;
    if (c?.replace) {
      let u = await c.replace(this.ctx, i, r);
      return this.inner.replace(o, u);
    }
    if ((this.rulesConfig.defaultPolicy ?? "allow") === "deny")
      throw new Error(`replace not allowed on ${s}`);
    return this.inner.replace(o, r);
  }
  async delete(e, t) {
    let n;
    t !== void 0 ? n = t : n = e;
    let o = await this.rulesReader.get(n);
    if (o === null)
      throw new Error("no read access or doc does not exist");
    let r = $n(this.inner, n, this.rules, this.rulesConfig), i = r ? this.rules[r] : void 0;
    if (i?.delete)
      return await i.delete(this.ctx, o), this.inner.delete(n);
    if ((this.rulesConfig.defaultPolicy ?? "allow") === "deny")
      throw new Error(`delete not allowed on ${r}`);
    return this.inner.delete(n);
  }
}, qb = class rp extends wu {
  static {
    a(this, "_AuditQueryChain");
  }
  afterRead;
  tableName;
  constructor(t, n, o, r) {
    super(t, n), this.afterRead = o, this.tableName = r;
  }
  createChain(t) {
    return new rp(t, this.schema, this.afterRead, this.tableName);
  }
  async first() {
    let t = await super.first();
    return t !== null && await this.afterRead(this.tableName, t), t;
  }
  async unique() {
    let t = await super.unique();
    return t !== null && await this.afterRead(this.tableName, t), t;
  }
  async collect() {
    let t = await super.collect();
    for (let n of t)
      await this.afterRead(this.tableName, n);
    return t;
  }
  async take(t) {
    let n = await super.take(t);
    for (let o of n)
      await this.afterRead(this.tableName, o);
    return n;
  }
  async paginate(t) {
    let n = await super.paginate(t);
    for (let o of n.page)
      await this.afterRead(this.tableName, o);
    return n;
  }
  async *[Symbol.asyncIterator]() {
    for await (let t of super[Symbol.asyncIterator]())
      await this.afterRead(this.tableName, t), yield t;
  }
}, np = class extends zn {
  static {
    a(this, "AuditDatabaseReader");
  }
  inner;
  afterRead;
  constructor(e, t) {
    let { db: n, tableMap: o } = e._internals;
    super(n, o), this.inner = e, this.afterRead = t.afterRead ?? (() => {
    }), this.system = e.system;
  }
  async get(e, t) {
    let n = await this.inner.get(e, t);
    if (n !== null) {
      let o = this.resolveTableFromId(
        t !== void 0 ? t : e,
        t !== void 0 ? e : void 0
      );
      o && await this.afterRead(o, n);
    }
    return n;
  }
  query(e) {
    let t = this.inner.query(e), n = x.any();
    return new qb(t, n, this.afterRead, e);
  }
  resolveTableFromId(e, t) {
    if (t) return t;
    for (let n of Object.keys(this.tableMap))
      if (this.inner.normalizeId(n, e))
        return n;
    return null;
  }
}, Jb = class extends ku {
  static {
    a(this, "AuditDatabaseWriter");
  }
  inner;
  auditReader;
  afterWrite;
  constructor(e, t) {
    let { db: n, tableMap: o, reader: r } = e._internals;
    super(n, o), this.inner = e, this.afterWrite = t.afterWrite, this.auditReader = t.afterRead ? new np(r, { afterRead: t.afterRead }) : r, this.system = e.system;
  }
  normalizeId(e, t) {
    return this.auditReader.normalizeId(e, t);
  }
  async get(e, t) {
    return this.auditReader.get(e, t);
  }
  query(e) {
    return this.auditReader.query(e);
  }
  async insert(e, t) {
    let n = await this.inner.insert(e, t);
    return this.afterWrite && await this.afterWrite(e, { type: "insert", id: n, value: t }), n;
  }
  async patch(e, t, n) {
    let o, r;
    n !== void 0 ? (o = t, r = n) : (o = e, r = t);
    let i = await this.inner.get(o);
    if (n !== void 0 ? await this.inner.patch(e, t, n) : await this.inner.patch(o, r), this.afterWrite) {
      let s = this.resolveTableFromId(o);
      s && await this.afterWrite(s, { type: "patch", id: o, doc: i, value: r });
    }
  }
  async replace(e, t, n) {
    let o, r;
    n !== void 0 ? (o = t, r = n) : (o = e, r = t);
    let i = await this.inner.get(o);
    if (n !== void 0 ? await this.inner.replace(e, t, n) : await this.inner.replace(o, r), this.afterWrite) {
      let s = this.resolveTableFromId(o);
      s && await this.afterWrite(s, { type: "replace", id: o, doc: i, value: r });
    }
  }
  async delete(e, t) {
    let n;
    t !== void 0 ? n = t : n = e;
    let o = await this.inner.get(n);
    if (t !== void 0 ? await this.inner.delete(e, t) : await this.inner.delete(n), this.afterWrite) {
      let r = this.resolveTableFromId(n);
      r && await this.afterWrite(r, { type: "delete", id: n, doc: o });
    }
  }
  resolveTableFromId(e) {
    for (let t of Object.keys(this.inner._internals.tableMap))
      if (this.inner.normalizeId(t, e))
        return t;
    return null;
  }
};
function Wb(e, t) {
  let n = t?.underlyingDb?.query, o = t?.underlyingDb?.mutation;
  return {
    query: {
      args: {},
      input: /* @__PURE__ */ a(async (r, i, s) => ({
        ctx: {
          db: new zn(n ? n(r) : r.db, e)
        },
        args: {}
      }), "input")
    },
    mutation: {
      args: {},
      input: /* @__PURE__ */ a(async (r, i, s) => ({
        ctx: {
          db: new ku(o ? o(r) : r.db, e)
        },
        args: {}
      }), "input")
    }
  };
}
a(Wb, "createZodvexCustomization");
function ip(e, t) {
  let n = {};
  for (let o of t)
    o in e && (n[o] = e[o]);
  return n;
}
a(ip, "pick");
var op = "__zodvexMeta";
function Kb(e, t) {
  Object.defineProperty(e, op, {
    value: t,
    enumerable: !1,
    writable: !1,
    configurable: !1
  });
}
a(Kb, "attachMeta");
function ap(e) {
  if (!(e == null || typeof e != "object" && typeof e != "function"))
    return e[op];
}
a(ap, "readMeta");
var Gb = "__zodvexCodecBrand";
function Xb(e, t) {
  Object.defineProperty(e, Gb, {
    value: t,
    enumerable: !1,
    writable: !1,
    configurable: !1
  });
}
a(Xb, "attachCodecBrand");
function Hb(e, t) {
  return {
    error: "ZodValidationError",
    context: t,
    issues: e.issues.map((n) => ({
      path: Array.isArray(n.path) ? n.path.join(".") : String(n.path ?? ""),
      code: n.code,
      message: n.message
    })),
    // Keep a flattened snapshot for easier debugging without cyclic refs
    flatten: JSON.parse(JSON.stringify(e.flatten?.() ?? {}))
  };
}
a(Hb, "formatZodIssues");
function $u(e, t) {
  throw e instanceof _e ? new Qe(Hb(e, t)) : e;
}
a($u, "handleZodValidationError");
function Qb(e, t) {
  try {
    return Y(e, t);
  } catch (n) {
    if (n?.message?.includes("unidirectional transform"))
      try {
        return ie(e, t);
      } catch (o) {
        $u(o, "returns");
      }
    $u(n, "returns");
  }
  throw new Error("Unreachable");
}
a(Qb, "validateReturns");
function sp(e) {
  if (e)
    return e instanceof _ ? e : x.object(e);
}
a(sp, "normalizeFunctionSchema");
function Yb(e) {
  if (e) {
    if (e instanceof q)
      return e;
    if (!(e instanceof _))
      return x.object(e);
  }
}
a(Yb, "normalizeFunctionMetaArgs");
function Nf(e, t, n) {
  Kb(e, {
    type: "function",
    zodArgs: Yb(t),
    zodReturns: sp(n)
  });
}
a(Nf, "attachFunctionMeta");
var Zf = /* @__PURE__ */ new WeakMap();
function ir(e, t = 50, n = 0) {
  let o = Zf.get(e);
  if (o !== void 0)
    return o;
  if (n > t)
    return !1;
  let r = !1;
  return e instanceof Lt ? r = !0 : e instanceof ee ? r = e._zod.def.options.some((i) => ir(i, t, n + 1)) : (e instanceof L || e instanceof de || e instanceof se) && (r = ir(e._zod.def.innerType, t, n + 1)), Zf.set(e, r), r;
}
a(ir, "containsCustom");
function e$(e) {
  if (e instanceof _) {
    if (e instanceof q)
      return {
        argsSchema: e,
        argsValidator: e._zod.def.shape
      };
    throw new Error(
      "Unsupported non-object Zod schema for args; please provide an args schema using z.object({...}), e.g. z.object({ foo: z.string() })"
    );
  }
  return {
    argsValidator: e,
    argsSchema: x.object(e)
  };
}
a(e$, "normalizeCustomArgsValidator");
function t$(e, t) {
  if (!(!e || t?.skipConvexValidation) && !(t?.skipCustomSchemas && ir(e)))
    return Xf(e);
}
a(t$, "createConvexReturnsValidator");
function cp(e, t) {
  let n = me(e, t);
  return n.success || $u(n.error, "args"), n.data;
}
a(cp, "parseObjectArgsOrThrow");
async function Af(e, t, n, o, r, i) {
  let s = ip(n, Object.keys(o)), c = i ? cp(i, s) : s;
  return await e(t, c, r);
}
a(Af, "runCustomizationInput");
function Cf(e, t, n) {
  let o = { ...e, ...n?.ctx ?? {} }, r = n?.args ?? {};
  return {
    finalCtx: o,
    finalArgs: { ...t, ...r }
  };
}
a(Cf, "applyCustomizationResult");
async function Rf(e, t) {
  if (t?.added?.onSuccess && await t.added.onSuccess({
    ctx: t.ctx,
    args: t.args,
    result: e
  }), t?.returns) {
    let n = Qb(t.returns, e);
    return Ae(n);
  }
  return Ae(e);
}
a(Rf, "finalizeFunctionReturn");
function Iu(e, t) {
  let n = t.input ?? yn.input, o = t.args ?? yn.args, r = Object.entries(o), i = r.length > 0 && r.every(([, u]) => u instanceof _), s = i ? wn(o) : o, c = i ? x.object(o) : void 0;
  return /* @__PURE__ */ a(function(l) {
    let { args: d, handler: g = l, returns: $, ...v } = l, k = l.skipConvexValidation ?? !1, D = sp($), T = t$(D, { skipConvexValidation: k }), $e = T ? { returns: T } : void 0;
    if (D && Pf(D, "returns"), d) {
      let { argsValidator: W, argsSchema: O } = e$(d), F = k ? s : { ...wn(W), ...s };
      Pf(O, "args");
      let I = e({
        args: F,
        ...$e,
        handler: /* @__PURE__ */ a(async (B, Xe) => {
          let or = await Af(
            n,
            B,
            Xe,
            s,
            v,
            c
          ), vp = Object.keys(W), yp = ip(Xe, vp), Ou = cp(O, yp), { finalCtx: bp, finalArgs: $p } = Cf(B, Ou, or), xp = await g(bp, $p);
          return Rf(xp, { ctx: B, args: Ou, added: or, returns: D });
        }, "handler")
      }), j = c ? x.object({
        ...O._zod.def.shape,
        ...c._zod.def.shape
      }) : O;
      return Nf(I, j, D), I;
    }
    let ve = e({
      args: s,
      ...$e,
      handler: /* @__PURE__ */ a(async (W, O) => {
        let F = O, I = await Af(
          n,
          W,
          O,
          s,
          v,
          c
        ), { finalCtx: j, finalArgs: B } = Cf(W, F, I), Xe = await g(j, B);
        return Rf(Xe, { ctx: W, args: F, added: I, returns: D });
      }, "handler")
    });
    return Nf(ve, c ?? void 0, D), ve;
  }, "customBuilder");
}
a(Iu, "customFnBuilder");
function Ff(e, t) {
  return Iu(e, t);
}
a(Ff, "zCustomQuery");
function Mf(e, t) {
  return Iu(
    e,
    t
  );
}
a(Mf, "zCustomMutation");
function Lf(e, t) {
  return Iu(
    e,
    t
  );
}
a(Lf, "zCustomAction");
function up(e, t, n) {
  let o = n?.wrapDb !== !1;
  if (!o && n?.underlyingDb)
    throw new Error(
      "[zodvex] initZodvex: `underlyingDb` requires the codec db wrapper \u2014 remove `wrapDb: false` or drop `underlyingDb`."
    );
  let r = Wb(e.__zodTableMap, {
    underlyingDb: n?.underlyingDb
  }), i = r$(), s = n?.registry, c = n$(s, i), u = {
    query: o ? r.query : i,
    mutation: i$(o ? r.mutation : i, s),
    action: c
  };
  return {
    zq: xt(t.query, u.query, Ff),
    zm: xt(t.mutation, u.mutation, Mf),
    za: xt(t.action, u.action, Lf),
    ziq: xt(t.internalQuery, u.query, Ff),
    zim: xt(t.internalMutation, u.mutation, Mf),
    zia: xt(t.internalAction, u.action, Lf)
  };
}
a(up, "initZodvex");
function r$() {
  return { args: {}, input: yn.input };
}
a(r$, "createNoOpCustomization");
function n$(e, t) {
  return e ? {
    args: {},
    input: /* @__PURE__ */ a(async (n) => ({
      // Auto-encode codec args at outbound call sites: runQuery/runMutation
      // (encode args, decode result) and scheduler.runAfter/runAt (encode args).
      ctx: Gf(e(), n),
      args: {}
    }), "input")
  } : t;
}
a(n$, "createActionCustomization");
function i$(e, t) {
  return t ? {
    args: {},
    input: /* @__PURE__ */ a(async (n, o, r) => {
      let i = await e.input(n, {}, r), s = Gf(t(), n);
      return {
        ctx: { ...i.ctx, ...s },
        args: {}
      };
    }, "input")
  } : e;
}
a(i$, "createMutationCustomization");
function o$(e, t) {
  return {
    args: t.args ?? {},
    input: /* @__PURE__ */ a(async (n, o, r) => {
      let i = await e.input(n, {}, r), s = { ...n, ...i.ctx };
      if (!t.input)
        return { ctx: i.ctx, args: {} };
      let c = await t.input(s, o, r);
      return {
        ctx: { ...i.ctx, ...c.ctx ?? {} },
        args: c.args ?? {},
        ...c.onSuccess && { onSuccess: c.onSuccess }
      };
    }, "input")
  };
}
a(o$, "composeCustomizations");
function xt(e, t, n) {
  let o = n(e, t);
  return o.withContext = (r) => {
    let i = o$(t, r);
    return n(e, i);
  }, o;
}
a(xt, "createZodvexBuilder");
function In(e) {
  let t = x.string().check(
    x.refine((o) => typeof o == "string" && o.length > 0, {
      message: `Invalid ID for table "${e}"`
    }),
    x.describe(`convexId:${e}`)
  );
  _n.setMetadata(t, {
    isConvexId: !0,
    tableName: e
  });
  let n = t;
  return n._tableName = e, n;
}
a(In, "id");
function lp(e) {
  return e instanceof ee || e instanceof Pe;
}
a(lp, "isZodUnion");
function dp(e) {
  return e instanceof ee, e._zod.def.options;
}
a(dp, "getUnionOptions");
function a$(e) {
  if (e.length < 2)
    throw new Error(
      `z.union() requires at least 2 options, but received ${e.length}. This indicates an invalid union schema was passed to zodTable().`
    );
}
a(a$, "assertUnionOptions");
function fp(e) {
  return a$(e), x.union(e);
}
a(fp, "createUnionFromOptions");
function s$(e, t) {
  if (lp(t)) {
    let o = dp(t).map((r) => {
      if (r instanceof q) {
        let i = {
          ...r._zod.def.shape,
          _id: In(e),
          _creationTime: x.number()
        };
        return J(r, { ...r._zod.def, shape: i });
      }
      return r;
    });
    return fp(o);
  }
  if (t instanceof q) {
    let n = { ...t._zod.def.shape, _id: In(e), _creationTime: x.number() };
    return J(t, { ...t._zod.def, shape: n });
  }
  return t;
}
a(s$, "addSystemFields");
function c$(e) {
  return e instanceof L ? e : new L({ type: "optional", innerType: e });
}
a(c$, "ensureOptional");
function u$(e) {
  let t = {};
  for (let [n, o] of Object.entries(e))
    t[n] = c$(o);
  return t;
}
a(u$, "createPartialShape");
function Bf(e, t) {
  return x.object({
    _id: In(e),
    _creationTime: x.optional(x.number()),
    ...u$(t)
  });
}
a(Bf, "createUpdateObjectSchema");
function l$(e, t) {
  if (lp(t)) {
    let n = dp(t).map((o) => o instanceof q ? Bf(e, o._zod.def.shape) : o);
    return fp(n);
  }
  return t instanceof q ? Bf(e, t._zod.def.shape) : t;
}
a(l$, "createSchemaUpdateSchema");
var Vf = /* @__PURE__ */ Symbol.for("zodvex.zxDate");
function d$(e) {
  e[Vf] = !0;
  let t = e._zod?.def;
  return t && (t[Vf] = !0), e;
}
a(d$, "brandZxDate");
function f$() {
  return d$(
    Qf(
      x.number(),
      // Wire: timestamp
      x.custom((e) => e instanceof Date, {
        message: "Expected Date instance"
      }),
      {
        decode: /* @__PURE__ */ a((e) => new Date(e), "decode"),
        encode: /* @__PURE__ */ a((e) => e.getTime(), "encode")
      }
    )
  );
}
a(f$, "date");
function p$(e, t, n, o) {
  let r = Qf(e, t, n);
  return o?.brand && Xb(r, o.brand), r;
}
a(p$, "codec");
function Sn(e) {
  let t = /* @__PURE__ */ Symbol.for(`zodvex.zx.cache.${e}`), n = globalThis, o = n[t];
  if (o) return o;
  let r = /* @__PURE__ */ new WeakMap();
  return n[t] = r, r;
}
a(Sn, "sharedWeakMap");
var qf = Sn("base"), Jf = Sn("doc"), Wf = Sn("update"), Kf = Sn("docArray");
function zu(e) {
  let t = e.schema;
  return t instanceof _ ? t : e.fields;
}
a(zu, "slimCacheKey");
function Su(e) {
  let t = e.schema;
  if (t?.base instanceof _) return t.base;
  if (t instanceof _) return t;
  let n = qf.get(e.fields);
  if (n) return n;
  if (Object.keys(e.fields).length === 0)
    throw new Error(`[zodvex] Cannot derive base schema for model '${e.name}'`);
  let o = x.object(e.fields);
  return qf.set(e.fields, o), o;
}
a(Su, "base");
function pp(e) {
  let t = e.schema;
  if (t?.doc instanceof _) return t.doc;
  let n = zu(e), o = Jf.get(n);
  if (o) return o;
  let r = s$(e.name, Su(e));
  return Jf.set(n, r), r;
}
a(pp, "doc");
function m$(e) {
  let t = e.schema;
  if (t?.update instanceof _) return t.update;
  let n = zu(e), o = Wf.get(n);
  if (o) return o;
  let r = l$(e.name, Su(e));
  return Wf.set(n, r), r;
}
a(m$, "update");
function g$(e) {
  let t = e.schema;
  if (t?.docArray instanceof _) return t.docArray;
  let n = zu(e), o = Kf.get(n);
  if (o) return o;
  let r = x.array(pp(e));
  return Kf.set(n, r), r;
}
a(g$, "docArray");
function mp(e) {
  return new de({ type: "nullable", innerType: e });
}
a(mp, "nullable");
function xn(e) {
  return new L({ type: "optional", innerType: e });
}
a(xn, "optional");
function xu(e) {
  return xn(mp(e));
}
a(xu, "nullableOptional2");
function h$() {
  return x.object({
    numItems: x.number(),
    cursor: mp(x.string()),
    endCursor: xu(x.string()),
    id: xn(x.number()),
    maximumRowsRead: xn(x.number()),
    maximumBytesRead: xn(x.number())
  });
}
a(h$, "paginationOpts");
function v$(e) {
  return x.object({
    page: x.array(e),
    isDone: x.boolean(),
    continueCursor: x.string(),
    splitCursor: xu(x.string()),
    pageStatus: xu(x.enum(["SplitRecommended", "SplitRequired"]))
  });
}
a(v$, "paginationResult");
var _u = {
  /**
   * Date ↔ timestamp codec
   * @see {@link date}
   */
  date: f$,
  /**
   * Convex ID validator
   * @see {@link id}
   */
  id: In,
  /**
   * Custom codec builder
   * @see {@link codec}
   */
  codec: p$,
  /**
   * Pagination options schema matching Convex's PaginationOptions type
   * @see {@link paginationOpts}
   */
  paginationOpts: h$,
  /**
   * Paginated result schema wrapping any item schema in Convex's PaginationResult shape
   * @see {@link paginationResult}
   */
  paginationResult: v$,
  /**
   * Base schema for a model (user fields only; no system fields).
   * For object models reconstructs from fields; for union models returns the
   * user-supplied union. Cached per-model.
   * @see {@link base}
   */
  base: Su,
  /**
   * Doc schema: model fields + _id + _creationTime
   * @see {@link doc}
   */
  doc: pp,
  /**
   * Update schema: _id required, all other fields optional
   * @see {@link update}
   */
  update: m$,
  /**
   * Doc array schema: z.array(doc(model))
   * @see {@link docArray}
   */
  docArray: g$
};
function y$(e) {
  return ap(e)?.type === "model";
}
a(y$, "isZodModelEntry");
function gp(e) {
  let t = ap(e);
  if (!t || t.type !== "model")
    throw new Error(`Model '${e.name}' is missing zodvex model metadata.`);
  return t;
}
a(gp, "getZodModelMeta");
function b$(e) {
  let t = gp(e), o = t.definitionSource === "schema" || t.definitionSource == null && Object.keys(e.fields).length === 0 ? Le(Xf(_u.base(e))) : Le(wn(e.fields));
  for (let [r, i] of Object.entries(e.indexes)) {
    let s = i.filter((c) => c !== "_creationTime");
    o = o.index(r, s);
  }
  for (let [r, i] of Object.entries(e.searchIndexes))
    o = o.searchIndex(r, i);
  for (let [r, i] of Object.entries(e.vectorIndexes))
    o = o.vectorIndex(r, i);
  return o;
}
a(b$, "tableFromModel");
function hp(e) {
  let t = {}, n = {};
  for (let [i, s] of Object.entries(e))
    if (y$(s)) {
      if (s.name !== i)
        throw new Error(
          `Model name '${s.name}' does not match key '${i}'. The model name must match the key in the schema definition.`
        );
      t[i] = b$(s);
      let c = gp(s);
      c.schemas ? n[i] = {
        doc: c.schemas.doc,
        insert: c.schemas.insert
      } : n[i] = {
        doc: _u.doc(s),
        insert: _u.base(s)
      };
    } else
      t[i] = s.table, n[i] = {
        doc: s.schema.doc,
        insert: s.schema.insert
      };
  let o = jr(t);
  return Object.assign(o, { __zodTableMap: n });
}
a(hp, "defineZodSchema");

// graphProbe.ts
var x$ = { query: Hn, mutation: Gn, action: Yn, internalQuery: Qn, internalMutation: Xn, internalAction: ei }, _$ = { kind: "mini", schemaHelpers: !1, server: x$, s: { number: rn, string: yt, boolean: nn, optional: cn, nullable: un, object: tu, array: tr, union: sn, date: eu, codec: su, instanceof: uu, parse: ie, encode: Y }, defineZodModel: _f, defineZodSchema: hp, initZodvex: up }, w$ = fl(_$), k$ = { count: 16, width: 32, profile: "codec-rich", entries: 0 }, ju = w$(k$), p4 = $$({ args: {}, returns: m.object({ checksum: m.number(), output: m.object({ seq: m.number(), at: m.number(), secret: m.string(), payload: m.string() }), manifest: m.any(), nonce: m.string() }), handler: /* @__PURE__ */ a(() => {
  let e = ju.operation();
  return globalThis.gc(), globalThis.gc(), { checksum: ju.checksum(), output: e, manifest: ju.manifest, nonce: "f2476884-14b7-45f7-8612-e5b7cc5ad5af" };
}, "handler") });
export {
  p4 as default
};
