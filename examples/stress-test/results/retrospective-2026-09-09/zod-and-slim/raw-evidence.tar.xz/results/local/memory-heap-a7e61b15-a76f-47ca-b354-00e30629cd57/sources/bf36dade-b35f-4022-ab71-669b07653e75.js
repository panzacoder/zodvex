var Yn = Object.defineProperty;
var s = (e, t) => Yn(e, "name", { value: t, configurable: !0 });
var ku = (e, t) => {
  for (var r in t)
    Yn(e, r, { get: t[r], enumerable: !0 });
};

// graphProbe.ts
import { query as pp } from "convex:/_system/repl/wrappers.js";

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/base64.js
var te = [], K = [], Su = Uint8Array, xr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
for (pe = 0, Xn = xr.length; pe < Xn; ++pe)
  te[pe] = xr[pe], K[xr.charCodeAt(pe)] = pe;
var pe, Xn;
K[45] = 62;
K[95] = 63;
function Zu(e) {
  var t = e.length;
  if (t % 4 > 0)
    throw new Error("Invalid string. Length must be a multiple of 4");
  var r = e.indexOf("=");
  r === -1 && (r = t);
  var n = r === t ? 0 : 4 - r % 4;
  return [r, n];
}
s(Zu, "getLens");
function Pu(e, t, r) {
  return (t + r) * 3 / 4 - r;
}
s(Pu, "_byteLength");
function Ne(e) {
  var t, r = Zu(e), n = r[0], o = r[1], i = new Su(Pu(e, n, o)), c = 0, u = o > 0 ? n - 4 : n, a;
  for (a = 0; a < u; a += 4)
    t = K[e.charCodeAt(a)] << 18 | K[e.charCodeAt(a + 1)] << 12 | K[e.charCodeAt(a + 2)] << 6 | K[e.charCodeAt(a + 3)], i[c++] = t >> 16 & 255, i[c++] = t >> 8 & 255, i[c++] = t & 255;
  return o === 2 && (t = K[e.charCodeAt(a)] << 2 | K[e.charCodeAt(a + 1)] >> 4, i[c++] = t & 255), o === 1 && (t = K[e.charCodeAt(a)] << 10 | K[e.charCodeAt(a + 1)] << 4 | K[e.charCodeAt(a + 2)] >> 2, i[c++] = t >> 8 & 255, i[c++] = t & 255), i;
}
s(Ne, "toByteArray");
function Ou(e) {
  return te[e >> 18 & 63] + te[e >> 12 & 63] + te[e >> 6 & 63] + te[e & 63];
}
s(Ou, "tripletToBase64");
function Eu(e, t, r) {
  for (var n, o = [], i = t; i < r; i += 3)
    n = (e[i] << 16 & 16711680) + (e[i + 1] << 8 & 65280) + (e[i + 2] & 255), o.push(Ou(n));
  return o.join("");
}
s(Eu, "encodeChunk");
function Ce(e) {
  for (var t, r = e.length, n = r % 3, o = [], i = 16383, c = 0, u = r - n; c < u; c += i)
    o.push(
      Eu(
        e,
        c,
        c + i > u ? u : c + i
      )
    );
  return n === 1 ? (t = e[r - 1], o.push(te[t >> 2] + te[t << 4 & 63] + "==")) : n === 2 && (t = (e[r - 2] << 8) + e[r - 1], o.push(
    te[t >> 10] + te[t >> 4 & 63] + te[t << 2 & 63] + "="
  )), o.join("");
}
s(Ce, "fromByteArray");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/common/index.js
function ie(e) {
  if (e === void 0)
    return {};
  if (!dt(e))
    throw new Error(
      `The arguments to a Convex function must be an object. Received: ${e}`
    );
  return e;
}
s(ie, "parseArgs");
function dt(e) {
  let t = typeof e == "object", r = Object.getPrototypeOf(e), n = r === null || r === Object.prototype || // Objects generated from other contexts (e.g. across Node.js `vm` modules) will not satisfy the previous
  // conditions but are still simple objects.
  r?.constructor?.name === "Object";
  return t && n;
}
s(dt, "isSimpleObject");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/value.js
var no = !0, ge = BigInt("-9223372036854775808"), vr = BigInt("9223372036854775807"), wr = BigInt("0"), Tu = BigInt("8"), Iu = BigInt("256");
function oo(e) {
  return Number.isNaN(e) || !Number.isFinite(e) || Object.is(e, -0);
}
s(oo, "isSpecial");
function Au(e) {
  e < wr && (e -= ge + ge);
  let t = e.toString(16);
  t.length % 2 === 1 && (t = "0" + t);
  let r = new Uint8Array(new ArrayBuffer(8)), n = 0;
  for (let o of t.match(/.{2}/g).reverse())
    r.set([parseInt(o, 16)], n++), e >>= Tu;
  return Ce(r);
}
s(Au, "slowBigIntToBase64");
function Nu(e) {
  let t = Ne(e);
  if (t.byteLength !== 8)
    throw new Error(
      `Received ${t.byteLength} bytes, expected 8 for $integer`
    );
  let r = wr, n = wr;
  for (let o of t)
    r += BigInt(o) * Iu ** n, n++;
  return r > vr && (r += ge + ge), r;
}
s(Nu, "slowBase64ToBigInt");
function Cu(e) {
  if (e < ge || vr < e)
    throw new Error(
      `BigInt ${e} does not fit into a 64-bit signed integer.`
    );
  let t = new ArrayBuffer(8);
  return new DataView(t).setBigInt64(0, e, !0), Ce(new Uint8Array(t));
}
s(Cu, "modernBigIntToBase64");
function ju(e) {
  let t = Ne(e);
  if (t.byteLength !== 8)
    throw new Error(
      `Received ${t.byteLength} bytes, expected 8 for $integer`
    );
  return new DataView(t.buffer).getBigInt64(0, !0);
}
s(ju, "modernBase64ToBigInt");
var Ru = DataView.prototype.setBigInt64 ? Cu : Au, Fu = DataView.prototype.getBigInt64 ? ju : Nu, to = 1024;
function zr(e) {
  if (e.length > to)
    throw new Error(
      `Field name ${e} exceeds maximum field name length ${to}.`
    );
  if (e.startsWith("$"))
    throw new Error(`Field name ${e} starts with a '$', which is reserved.`);
  for (let t = 0; t < e.length; t += 1) {
    let r = e.charCodeAt(t);
    if (r < 32 || r >= 127)
      throw new Error(
        `Field name ${e} has invalid character '${e[t]}': Field names can only contain non-control ASCII characters`
      );
  }
}
s(zr, "validateObjectField");
function C(e) {
  if (e === null || typeof e == "boolean" || typeof e == "number" || typeof e == "string")
    return e;
  if (Array.isArray(e))
    return e.map((n) => C(n));
  if (typeof e != "object")
    throw new Error(`Unexpected type of ${e}`);
  let t = Object.entries(e);
  if (t.length === 1) {
    let n = t[0][0];
    if (n === "$bytes") {
      if (typeof e.$bytes != "string")
        throw new Error(`Malformed $bytes field on ${e}`);
      return Ne(e.$bytes).buffer;
    }
    if (n === "$integer") {
      if (typeof e.$integer != "string")
        throw new Error(`Malformed $integer field on ${e}`);
      return Fu(e.$integer);
    }
    if (n === "$float") {
      if (typeof e.$float != "string")
        throw new Error(`Malformed $float field on ${e}`);
      let o = Ne(e.$float);
      if (o.byteLength !== 8)
        throw new Error(
          `Received ${o.byteLength} bytes, expected 8 for $float`
        );
      let c = new DataView(o.buffer).getFloat64(0, no);
      if (!oo(c))
        throw new Error(`Float ${c} should be encoded as a number`);
      return c;
    }
    if (n === "$set")
      throw new Error(
        "Received a Set which is no longer supported as a Convex type."
      );
    if (n === "$map")
      throw new Error(
        "Received a Map which is no longer supported as a Convex type."
      );
  }
  let r = {};
  for (let [n, o] of Object.entries(e))
    zr(n), r[n] = C(o);
  return r;
}
s(C, "jsonToConvex");
var ro = 16384;
function fe(e) {
  let t = JSON.stringify(e, (r, n) => n === void 0 ? "undefined" : typeof n == "bigint" ? `${n.toString()}n` : n);
  if (t.length > ro) {
    let r = "[...truncated]", n = ro - r.length, o = t.codePointAt(n - 1);
    return o !== void 0 && o > 65535 && (n -= 1), t.substring(0, n) + r;
  }
  return t;
}
s(fe, "stringifyValueForError");
function je(e, t, r, n) {
  if (e === void 0) {
    let c = r && ` (present at path ${r} in original object ${fe(
      t
    )})`;
    throw new Error(
      `undefined is not a valid Convex value${c}. To learn about Convex's supported types, see https://docs.convex.dev/using/types.`
    );
  }
  if (e === null)
    return e;
  if (typeof e == "bigint") {
    if (e < ge || vr < e)
      throw new Error(
        `BigInt ${e} does not fit into a 64-bit signed integer.`
      );
    return { $integer: Ru(e) };
  }
  if (typeof e == "number")
    if (oo(e)) {
      let c = new ArrayBuffer(8);
      return new DataView(c).setFloat64(0, e, no), { $float: Ce(new Uint8Array(c)) };
    } else
      return e;
  if (typeof e == "boolean" || typeof e == "string")
    return e;
  if (e instanceof ArrayBuffer)
    return { $bytes: Ce(new Uint8Array(e)) };
  if (Array.isArray(e))
    return e.map(
      (c, u) => je(c, t, r + `[${u}]`, !1)
    );
  if (e instanceof Set)
    throw new Error(
      br(r, "Set", [...e], t)
    );
  if (e instanceof Map)
    throw new Error(
      br(r, "Map", [...e], t)
    );
  if (!dt(e)) {
    let c = e?.constructor?.name, u = c ? `${c} ` : "";
    throw new Error(
      br(r, u, e, t)
    );
  }
  let o = {}, i = Object.entries(e);
  i.sort(([c, u], [a, l]) => c === a ? 0 : c < a ? -1 : 1);
  for (let [c, u] of i)
    u !== void 0 ? (zr(c), o[c] = je(u, t, r + `.${c}`, !1)) : n && (zr(c), o[c] = so(
      u,
      t,
      r + `.${c}`
    ));
  return o;
}
s(je, "convexToJsonInternal");
function br(e, t, r, n) {
  return e ? `${t}${fe(
    r
  )} is not a supported Convex type (present at path ${e} in original object ${fe(
    n
  )}). To learn about Convex's supported types, see https://docs.convex.dev/using/types.` : `${t}${fe(
    r
  )} is not a supported Convex type.`;
}
s(br, "errorMessageForUnsupportedType");
function so(e, t, r) {
  if (e === void 0)
    return { $undefined: null };
  if (t === void 0)
    throw new Error(
      `Programming error. Current value is ${fe(
        e
      )} but original value is undefined`
    );
  return je(e, t, r, !1);
}
s(so, "convexOrUndefinedToJsonInternal");
function O(e) {
  return je(e, e, "", !1);
}
s(O, "convexToJson");
function Y(e) {
  return so(e, e, "");
}
s(Y, "convexOrUndefinedToJson");
function io(e) {
  return je(e, e, "", !0);
}
s(io, "patchValueToJson");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/validators.js
var Lu = Object.defineProperty, Mu = /* @__PURE__ */ s((e, t, r) => t in e ? Lu(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), T = /* @__PURE__ */ s((e, t, r) => Mu(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), Du = "https://docs.convex.dev/error#undefined-validator";
function Re(e, t) {
  let r = t !== void 0 ? ` for field "${t}"` : "";
  throw new Error(
    `A validator is undefined${r} in ${e}. This is often caused by circular imports. See ${Du} for details.`
  );
}
s(Re, "throwUndefinedValidatorError");
var B = class {
  static {
    s(this, "BaseValidator");
  }
  constructor({ isOptional: t }) {
    T(this, "type"), T(this, "fieldPaths"), T(this, "isOptional"), T(this, "isConvexValidator"), this.isOptional = t, this.isConvexValidator = !0;
  }
}, mt = class e extends B {
  static {
    s(this, "VId");
  }
  /**
   * Usually you'd use `v.id(tableName)` instead.
   */
  constructor({
    isOptional: t,
    tableName: r
  }) {
    if (super({ isOptional: t }), T(this, "tableName"), T(this, "kind", "id"), typeof r != "string")
      throw new Error("v.id(tableName) requires a string");
    this.tableName = r;
  }
  /** @internal */
  get json() {
    return { type: "id", tableName: this.tableName };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      tableName: this.tableName
    });
  }
}, Fe = class e extends B {
  static {
    s(this, "VFloat64");
  }
  constructor() {
    super(...arguments), T(this, "kind", "float64");
  }
  /** @internal */
  get json() {
    return { type: "number" };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, Le = class e extends B {
  static {
    s(this, "VInt64");
  }
  constructor() {
    super(...arguments), T(this, "kind", "int64");
  }
  /** @internal */
  get json() {
    return { type: "bigint" };
  }
  /** @internal */
  asOptional() {
    return new e({ isOptional: "optional" });
  }
}, ht = class e extends B {
  static {
    s(this, "VBoolean");
  }
  constructor() {
    super(...arguments), T(this, "kind", "boolean");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, gt = class e extends B {
  static {
    s(this, "VBytes");
  }
  constructor() {
    super(...arguments), T(this, "kind", "bytes");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({ isOptional: "optional" });
  }
}, yt = class e extends B {
  static {
    s(this, "VString");
  }
  constructor() {
    super(...arguments), T(this, "kind", "string");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, _t = class e extends B {
  static {
    s(this, "VNull");
  }
  constructor() {
    super(...arguments), T(this, "kind", "null");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({ isOptional: "optional" });
  }
}, xt = class e extends B {
  static {
    s(this, "VAny");
  }
  constructor() {
    super(...arguments), T(this, "kind", "any");
  }
  /** @internal */
  get json() {
    return {
      type: this.kind
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, bt = class e extends B {
  static {
    s(this, "VObject");
  }
  /**
   * Usually you'd use `v.object({ ... })` instead.
   */
  constructor({
    isOptional: t,
    fields: r
  }) {
    super({ isOptional: t }), T(this, "fields"), T(this, "kind", "object"), globalThis.Object.entries(r).forEach(([n, o]) => {
      if (o === void 0 && Re("v.object()", n), !o.isConvexValidator)
        throw new Error("v.object() entries must be validators");
    }), this.fields = r;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: globalThis.Object.fromEntries(
        globalThis.Object.entries(this.fields).map(([t, r]) => [
          t,
          {
            fieldType: r.json,
            optional: r.isOptional === "optional"
          }
        ])
      )
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      fields: this.fields
    });
  }
  /**
   * Create a new VObject with the specified fields omitted.
   * @param fields The field names to omit from this VObject.
   */
  omit(...t) {
    let r = { ...this.fields };
    for (let n of t)
      delete r[n];
    return new e({
      isOptional: this.isOptional,
      fields: r
    });
  }
  /**
   * Create a new VObject with only the specified fields.
   * @param fields The field names to pick from this VObject.
   */
  pick(...t) {
    let r = {};
    for (let n of t)
      r[n] = this.fields[n];
    return new e({
      isOptional: this.isOptional,
      fields: r
    });
  }
  /**
   * Create a new VObject with all fields marked as optional.
   */
  partial() {
    let t = {};
    for (let [r, n] of globalThis.Object.entries(this.fields))
      t[r] = n.asOptional();
    return new e({
      isOptional: this.isOptional,
      fields: t
    });
  }
  /**
   * Create a new VObject with additional fields merged in.
   * @param fields An object with additional validators to merge into this VObject.
   */
  extend(t) {
    return new e({
      isOptional: this.isOptional,
      fields: { ...this.fields, ...t }
    });
  }
}, wt = class e extends B {
  static {
    s(this, "VLiteral");
  }
  /**
   * Usually you'd use `v.literal(value)` instead.
   */
  constructor({ isOptional: t, value: r }) {
    if (super({ isOptional: t }), T(this, "value"), T(this, "kind", "literal"), typeof r != "string" && typeof r != "boolean" && typeof r != "number" && typeof r != "bigint")
      throw new Error("v.literal(value) must be a string, number, or boolean");
    this.value = r;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: O(this.value)
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      value: this.value
    });
  }
}, zt = class e extends B {
  static {
    s(this, "VArray");
  }
  /**
   * Usually you'd use `v.array(element)` instead.
   */
  constructor({
    isOptional: t,
    element: r
  }) {
    super({ isOptional: t }), T(this, "element"), T(this, "kind", "array"), r === void 0 && Re("v.array()"), this.element = r;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: this.element.json
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      element: this.element
    });
  }
}, vt = class e extends B {
  static {
    s(this, "VRecord");
  }
  /**
   * Usually you'd use `v.record(key, value)` instead.
   */
  constructor({
    isOptional: t,
    key: r,
    value: n
  }) {
    if (super({ isOptional: t }), T(this, "key"), T(this, "value"), T(this, "kind", "record"), r === void 0 && Re("v.record()", "key"), n === void 0 && Re("v.record()", "value"), r.isOptional === "optional")
      throw new Error("Record validator cannot have optional keys");
    if (n.isOptional === "optional")
      throw new Error("Record validator cannot have optional values");
    if (!r.isConvexValidator || !n.isConvexValidator)
      throw new Error("Key and value of v.record() but be validators");
    this.key = r, this.value = n;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      // This cast is needed because TypeScript thinks the key type is too wide
      keys: this.key.json,
      values: {
        fieldType: this.value.json,
        optional: !1
      }
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      key: this.key,
      value: this.value
    });
  }
}, $t = class e extends B {
  static {
    s(this, "VUnion");
  }
  /**
   * Usually you'd use `v.union(...members)` instead.
   */
  constructor({ isOptional: t, members: r }) {
    super({ isOptional: t }), T(this, "members"), T(this, "kind", "union"), r.forEach((n, o) => {
      if (n === void 0 && Re("v.union()", `member at index ${o}`), !n.isConvexValidator)
        throw new Error("All members of v.union() must be validators");
    }), this.members = r;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: this.members.map((t) => t.json)
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      members: this.members
    });
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/validator.js
function $r(e) {
  return !!e.isConvexValidator;
}
s($r, "isValidator");
function ye(e) {
  return $r(e) ? e : d.object(e);
}
s(ye, "asObjectValidator");
var d = {
  /**
   * Validates that the value is a document ID for the given table.
   *
   * IDs are strings at runtime but are typed as `Id<"tableName">` in
   * TypeScript for type safety.
   *
   * @example
   * ```typescript
   * args: { userId: v.id("users") }
   * ```
   *
   * @param tableName The name of the table.
   */
  id: /* @__PURE__ */ s((e) => new mt({
    isOptional: "required",
    tableName: e
  }), "id"),
  /**
   * Validates that the value is `null`.
   *
   * Use `returns: v.null()` for functions that don't return a meaningful value.
   * JavaScript `undefined` is not a valid Convex value, it is automatically
   * converted to `null`.
   */
  null: /* @__PURE__ */ s(() => new _t({ isOptional: "required" }), "null"),
  /**
   * Validates that the value is a JavaScript `number` (Convex Float64).
   *
   * Supports all IEEE-754 double-precision floating point numbers including
   * NaN and Infinity.
   *
   * Alias for `v.float64()`.
   */
  number: /* @__PURE__ */ s(() => new Fe({ isOptional: "required" }), "number"),
  /**
   * Validates that the value is a JavaScript `number` (Convex Float64).
   *
   * Supports all IEEE-754 double-precision floating point numbers.
   */
  float64: /* @__PURE__ */ s(() => new Fe({ isOptional: "required" }), "float64"),
  /**
   * @deprecated Use `v.int64()` instead.
   */
  bigint: /* @__PURE__ */ s(() => new Le({ isOptional: "required" }), "bigint"),
  /**
   * Validates that the value is a JavaScript `bigint` (Convex Int64).
   *
   * Supports BigInts between -2^63 and 2^63-1.
   *
   * @example
   * ```typescript
   * args: { timestamp: v.int64() }
   * // Usage: createDoc({ timestamp: 1234567890n })
   * ```
   */
  int64: /* @__PURE__ */ s(() => new Le({ isOptional: "required" }), "int64"),
  /**
   * Validates that the value is a `boolean`.
   */
  boolean: /* @__PURE__ */ s(() => new ht({ isOptional: "required" }), "boolean"),
  /**
   * Validates that the value is a `string`.
   *
   * Strings are stored as UTF-8 and their storage size is calculated as their
   * UTF-8 encoded size.
   */
  string: /* @__PURE__ */ s(() => new yt({ isOptional: "required" }), "string"),
  /**
   * Validates that the value is an `ArrayBuffer` (Convex Bytes).
   *
   * Use for binary data.
   */
  bytes: /* @__PURE__ */ s(() => new gt({ isOptional: "required" }), "bytes"),
  /**
   * Validates that the value is exactly equal to the given literal.
   *
   * Useful for discriminated unions and enum-like patterns.
   *
   * @example
   * ```typescript
   * // Discriminated union pattern:
   * v.union(
   *   v.object({ kind: v.literal("error"), message: v.string() }),
   *   v.object({ kind: v.literal("success"), value: v.number() }),
   * )
   * ```
   *
   * @param literal The literal value to compare against.
   */
  literal: /* @__PURE__ */ s((e) => new wt({ isOptional: "required", value: e }), "literal"),
  /**
   * Validates that the value is an `Array` where every element matches the
   * given validator.
   *
   * Arrays can have at most 8192 elements.
   *
   * @example
   * ```typescript
   * args: { tags: v.array(v.string()) }
   * args: { coordinates: v.array(v.number()) }
   * args: { items: v.array(v.object({ name: v.string(), qty: v.number() })) }
   * ```
   *
   * @param element The validator for the elements of the array.
   */
  array: /* @__PURE__ */ s((e) => new zt({ isOptional: "required", element: e }), "array"),
  /**
   * Validates that the value is an `Object` with the specified properties.
   *
   * Objects can have at most 1024 entries. Field names must be non-empty and
   * must not start with `"$"` or `"_"` (`_` is reserved for system fields
   * like `_id` and `_creationTime`; `$` is reserved for Convex internal use).
   *
   * @example
   * ```typescript
   * args: {
   *   user: v.object({
   *     name: v.string(),
   *     email: v.string(),
   *     age: v.optional(v.number()),
   *   })
   * }
   * ```
   *
   * @param fields An object mapping property names to their validators.
   */
  object: /* @__PURE__ */ s((e) => new bt({ isOptional: "required", fields: e }), "object"),
  /**
   * Validates that the value is a `Record` (object with dynamic keys).
   *
   * Records are objects at runtime but allow dynamic keys, unlike `v.object()`
   * which requires known property names. Keys must be ASCII characters only,
   * non-empty, and not start with `"$"` or `"_"`.
   *
   * @example
   * ```typescript
   * // Map of user IDs to scores:
   * args: { scores: v.record(v.id("users"), v.number()) }
   *
   * // Map of string keys to string values:
   * args: { metadata: v.record(v.string(), v.string()) }
   * ```
   *
   * @param keys The validator for the keys of the record.
   * @param values The validator for the values of the record.
   */
  record: /* @__PURE__ */ s((e, t) => new vt({
    isOptional: "required",
    key: e,
    value: t
  }), "record"),
  /**
   * Validates that the value matches at least one of the given validators.
   *
   * @example
   * ```typescript
   * // Allow string or number:
   * args: { value: v.union(v.string(), v.number()) }
   *
   * // Discriminated union (recommended pattern):
   * v.union(
   *   v.object({ kind: v.literal("text"), body: v.string() }),
   *   v.object({ kind: v.literal("image"), url: v.string() }),
   * )
   *
   * // Nullable value:
   * returns: v.union(v.object({ ... }), v.null())
   * ```
   *
   * @param members The validators to match against.
   */
  union: /* @__PURE__ */ s((...e) => new $t({
    isOptional: "required",
    members: e
  }), "union"),
  /**
   * A validator that accepts any Convex value without validation.
   *
   * Prefer using specific validators when possible for better type safety
   * and runtime validation.
   */
  any: /* @__PURE__ */ s(() => new xt({ isOptional: "required" }), "any"),
  /**
   * Makes a property optional in an object validator.
   *
   * An optional property can be omitted entirely when creating a document or
   * calling a function. This is different from `v.nullable()` which requires
   * the property to be present but allows `null`.
   *
   * @example
   * ```typescript
   * v.object({
   *   name: v.string(),              // required
   *   nickname: v.optional(v.string()), // can be omitted
   * })
   *
   * // Valid: { name: "Alice" }
   * // Valid: { name: "Alice", nickname: "Ali" }
   * // Invalid: { name: "Alice", nickname: null }  - use v.nullable() for this
   * ```
   *
   * @param value The property value validator to make optional.
   */
  optional: /* @__PURE__ */ s((e) => e.asOptional(), "optional"),
  /**
   * Allows a value to be either the given type or `null`.
   *
   * This is shorthand for `v.union(value, v.null())`. Unlike `v.optional()`,
   * the property must still be present, but may be `null`.
   *
   * @example
   * ```typescript
   * v.object({
   *   name: v.string(),
   *   deletedAt: v.nullable(v.number()), // must be present, can be null
   * })
   *
   * // Valid: { name: "Alice", deletedAt: null }
   * // Valid: { name: "Alice", deletedAt: 1234567890 }
   * // Invalid: { name: "Alice" }  - deletedAt is required
   * ```
   */
  nullable: /* @__PURE__ */ s((e) => d.union(e, d.null()), "nullable")
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/errors.js
var Uu = Object.defineProperty, Bu = /* @__PURE__ */ s((e, t, r) => t in e ? Uu(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), kr = /* @__PURE__ */ s((e, t, r) => Bu(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), co, uo, Ju = Symbol.for("ConvexError"), _e = class extends (uo = Error, co = Ju, uo) {
  static {
    s(this, "ConvexError");
  }
  constructor(t) {
    super(typeof t == "string" ? t : fe(t)), kr(this, "name", "ConvexError"), kr(this, "data"), kr(this, co, !0), this.data = t;
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/compare_utf8.js
var ao = /* @__PURE__ */ s(() => Array.from({ length: 4 }, () => 0), "arr"), Tp = ao(), Ip = ao();

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/index.js
var L = "1.32.0";

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/syscall.js
function Me(e, t) {
  if (typeof Convex > "u" || Convex.syscall === void 0)
    throw new Error(
      "The Convex database and auth objects are being used outside of a Convex backend. Did you mean to use `useQuery` or `useMutation` to call a Convex function?"
    );
  let r = Convex.syscall(e, JSON.stringify(t));
  return JSON.parse(r);
}
s(Me, "performSyscall");
async function k(e, t) {
  if (typeof Convex > "u" || Convex.asyncSyscall === void 0)
    throw new Error(
      "The Convex database and auth objects are being used outside of a Convex backend. Did you mean to use `useQuery` or `useMutation` to call a Convex function?"
    );
  let r;
  try {
    r = await Convex.asyncSyscall(e, JSON.stringify(t));
  } catch (n) {
    if (n.data !== void 0) {
      let o = new _e(n.message);
      throw o.data = C(n.data), o;
    }
    throw new Error(n.message);
  }
  return JSON.parse(r);
}
s(k, "performAsyncSyscall");
function kt(e, t) {
  if (typeof Convex > "u" || Convex.jsSyscall === void 0)
    throw new Error(
      "The Convex database and auth objects are being used outside of a Convex backend. Did you mean to use `useQuery` or `useMutation` to call a Convex function?"
    );
  return Convex.jsSyscall(e, t);
}
s(kt, "performJsSyscall");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/functionName.js
var De = Symbol.for("functionName");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/components/paths.js
var lo = Symbol.for("toReferencePath");
function Vu(e) {
  return e[lo] ?? null;
}
s(Vu, "extractReferencePath");
function qu(e) {
  return e.startsWith("function://");
}
s(qu, "isFunctionHandle");
function X(e) {
  let t;
  if (typeof e == "string")
    qu(e) ? t = { functionHandle: e } : t = { name: e };
  else if (e[De])
    t = { name: e[De] };
  else {
    let r = Vu(e);
    if (!r)
      throw new Error(`${e} is not a functionReference`);
    t = { reference: r };
  }
  return t;
}
s(X, "getFunctionAddress");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/actions_impl.js
function Sr(e, t, r) {
  return {
    ...X(t),
    args: O(ie(r)),
    version: L,
    requestId: e
  };
}
s(Sr, "syscallArgs");
function po(e) {
  return {
    runQuery: /* @__PURE__ */ s(async (t, r) => {
      let n = await k(
        "1.0/actions/query",
        Sr(e, t, r)
      );
      return C(n);
    }, "runQuery"),
    runMutation: /* @__PURE__ */ s(async (t, r) => {
      let n = await k(
        "1.0/actions/mutation",
        Sr(e, t, r)
      );
      return C(n);
    }, "runMutation"),
    runAction: /* @__PURE__ */ s(async (t, r) => {
      let n = await k(
        "1.0/actions/action",
        Sr(e, t, r)
      );
      return C(n);
    }, "runAction")
  };
}
s(po, "setupActionCalls");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/vector_search.js
var Wu = Object.defineProperty, Gu = /* @__PURE__ */ s((e, t, r) => t in e ? Wu(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), fo = /* @__PURE__ */ s((e, t, r) => Gu(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), St = class {
  static {
    s(this, "FilterExpression");
  }
  /**
   * @internal
   */
  constructor() {
    fo(this, "_isExpression"), fo(this, "_value");
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/validate.js
function $(e, t, r, n) {
  if (e === void 0)
    throw new TypeError(
      `Must provide arg ${t} \`${n}\` to \`${r}\``
    );
}
s($, "validateArg");
function mo(e, t, r, n) {
  if (!Number.isInteger(e) || e < 0)
    throw new TypeError(
      `Arg ${t} \`${n}\` to \`${r}\` must be a non-negative integer`
    );
}
s(mo, "validateArgIsNonNegativeInteger");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/vector_search_impl.js
var Hu = Object.defineProperty, Qu = /* @__PURE__ */ s((e, t, r) => t in e ? Hu(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), Zr = /* @__PURE__ */ s((e, t, r) => Qu(e, typeof t != "symbol" ? t + "" : t, r), "__publicField");
function ho(e) {
  return async (t, r, n) => {
    if ($(t, 1, "vectorSearch", "tableName"), $(r, 2, "vectorSearch", "indexName"), $(n, 3, "vectorSearch", "query"), !n.vector || !Array.isArray(n.vector) || n.vector.length === 0)
      throw Error("`vector` must be a non-empty Array in vectorSearch");
    return await new Pr(
      e,
      t + "." + r,
      n
    ).collect();
  };
}
s(ho, "setupActionVectorSearch");
var Pr = class {
  static {
    s(this, "VectorQueryImpl");
  }
  constructor(t, r, n) {
    Zr(this, "requestId"), Zr(this, "state"), this.requestId = t;
    let o = n.filter ? Zt(n.filter(Ku)) : null;
    this.state = {
      type: "preparing",
      query: {
        indexName: r,
        limit: n.limit,
        vector: n.vector,
        expressions: o
      }
    };
  }
  async collect() {
    if (this.state.type === "consumed")
      throw new Error("This query is closed and can't emit any more values.");
    let t = this.state.query;
    this.state = { type: "consumed" };
    let { results: r } = await k("1.0/actions/vectorSearch", {
      requestId: this.requestId,
      version: L,
      query: t
    });
    return r;
  }
}, xe = class extends St {
  static {
    s(this, "ExpressionImpl");
  }
  constructor(t) {
    super(), Zr(this, "inner"), this.inner = t;
  }
  serialize() {
    return this.inner;
  }
};
function Zt(e) {
  return e instanceof xe ? e.serialize() : { $literal: Y(e) };
}
s(Zt, "serializeExpression");
var Ku = {
  //  Comparisons  /////////////////////////////////////////////////////////////
  eq(e, t) {
    if (typeof e != "string")
      throw new Error("The first argument to `q.eq` must be a field name.");
    return new xe({
      $eq: [
        Zt(new xe({ $field: e })),
        Zt(t)
      ]
    });
  },
  //  Logic  ///////////////////////////////////////////////////////////////////
  or(...e) {
    return new xe({ $or: e.map(Zt) });
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/authentication_impl.js
function Pt(e) {
  return {
    getUserIdentity: /* @__PURE__ */ s(async () => await k("1.0/getUserIdentity", {
      requestId: e
    }), "getUserIdentity")
  };
}
s(Pt, "setupAuth");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/filter_builder.js
var Yu = Object.defineProperty, Xu = /* @__PURE__ */ s((e, t, r) => t in e ? Yu(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), go = /* @__PURE__ */ s((e, t, r) => Xu(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), Ot = class {
  static {
    s(this, "Expression");
  }
  /**
   * @internal
   */
  constructor() {
    go(this, "_isExpression"), go(this, "_value");
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/filter_builder_impl.js
var ea = Object.defineProperty, ta = /* @__PURE__ */ s((e, t, r) => t in e ? ea(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), ra = /* @__PURE__ */ s((e, t, r) => ta(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), M = class extends Ot {
  static {
    s(this, "ExpressionImpl");
  }
  constructor(t) {
    super(), ra(this, "inner"), this.inner = t;
  }
  serialize() {
    return this.inner;
  }
};
function P(e) {
  return e instanceof M ? e.serialize() : { $literal: Y(e) };
}
s(P, "serializeExpression");
var yo = {
  //  Comparisons  /////////////////////////////////////////////////////////////
  eq(e, t) {
    return new M({
      $eq: [P(e), P(t)]
    });
  },
  neq(e, t) {
    return new M({
      $neq: [P(e), P(t)]
    });
  },
  lt(e, t) {
    return new M({
      $lt: [P(e), P(t)]
    });
  },
  lte(e, t) {
    return new M({
      $lte: [P(e), P(t)]
    });
  },
  gt(e, t) {
    return new M({
      $gt: [P(e), P(t)]
    });
  },
  gte(e, t) {
    return new M({
      $gte: [P(e), P(t)]
    });
  },
  //  Arithmetic  //////////////////////////////////////////////////////////////
  add(e, t) {
    return new M({
      $add: [P(e), P(t)]
    });
  },
  sub(e, t) {
    return new M({
      $sub: [P(e), P(t)]
    });
  },
  mul(e, t) {
    return new M({
      $mul: [P(e), P(t)]
    });
  },
  div(e, t) {
    return new M({
      $div: [P(e), P(t)]
    });
  },
  mod(e, t) {
    return new M({
      $mod: [P(e), P(t)]
    });
  },
  neg(e) {
    return new M({ $neg: P(e) });
  },
  //  Logic  ///////////////////////////////////////////////////////////////////
  and(...e) {
    return new M({ $and: e.map(P) });
  },
  or(...e) {
    return new M({ $or: e.map(P) });
  },
  not(e) {
    return new M({ $not: P(e) });
  },
  //  Other  ///////////////////////////////////////////////////////////////////
  field(e) {
    return new M({ $field: e });
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/index_range_builder.js
var na = Object.defineProperty, oa = /* @__PURE__ */ s((e, t, r) => t in e ? na(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), sa = /* @__PURE__ */ s((e, t, r) => oa(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), Et = class {
  static {
    s(this, "IndexRange");
  }
  /**
   * @internal
   */
  constructor() {
    sa(this, "_isIndexRange");
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/index_range_builder_impl.js
var ia = Object.defineProperty, ca = /* @__PURE__ */ s((e, t, r) => t in e ? ia(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), _o = /* @__PURE__ */ s((e, t, r) => ca(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), Tt = class e extends Et {
  static {
    s(this, "IndexRangeBuilderImpl");
  }
  constructor(t) {
    super(), _o(this, "rangeExpressions"), _o(this, "isConsumed"), this.rangeExpressions = t, this.isConsumed = !1;
  }
  static new() {
    return new e([]);
  }
  consume() {
    if (this.isConsumed)
      throw new Error(
        "IndexRangeBuilder has already been used! Chain your method calls like `q => q.eq(...).eq(...)`. See https://docs.convex.dev/using/indexes"
      );
    this.isConsumed = !0;
  }
  eq(t, r) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Eq",
        fieldPath: t,
        value: Y(r)
      })
    );
  }
  gt(t, r) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Gt",
        fieldPath: t,
        value: Y(r)
      })
    );
  }
  gte(t, r) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Gte",
        fieldPath: t,
        value: Y(r)
      })
    );
  }
  lt(t, r) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Lt",
        fieldPath: t,
        value: Y(r)
      })
    );
  }
  lte(t, r) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Lte",
        fieldPath: t,
        value: Y(r)
      })
    );
  }
  export() {
    return this.consume(), this.rangeExpressions;
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/search_filter_builder.js
var ua = Object.defineProperty, aa = /* @__PURE__ */ s((e, t, r) => t in e ? ua(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), la = /* @__PURE__ */ s((e, t, r) => aa(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), It = class {
  static {
    s(this, "SearchFilter");
  }
  /**
   * @internal
   */
  constructor() {
    la(this, "_isSearchFilter");
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/search_filter_builder_impl.js
var pa = Object.defineProperty, fa = /* @__PURE__ */ s((e, t, r) => t in e ? pa(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), xo = /* @__PURE__ */ s((e, t, r) => fa(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), At = class e extends It {
  static {
    s(this, "SearchFilterBuilderImpl");
  }
  constructor(t) {
    super(), xo(this, "filters"), xo(this, "isConsumed"), this.filters = t, this.isConsumed = !1;
  }
  static new() {
    return new e([]);
  }
  consume() {
    if (this.isConsumed)
      throw new Error(
        "SearchFilterBuilder has already been used! Chain your method calls like `q => q.search(...).eq(...)`."
      );
    this.isConsumed = !0;
  }
  search(t, r) {
    return $(t, 1, "search", "fieldName"), $(r, 2, "search", "query"), this.consume(), new e(
      this.filters.concat({
        type: "Search",
        fieldPath: t,
        value: r
      })
    );
  }
  eq(t, r) {
    return $(t, 1, "eq", "fieldName"), arguments.length !== 2 && $(r, 2, "search", "value"), this.consume(), new e(
      this.filters.concat({
        type: "Eq",
        fieldPath: t,
        value: Y(r)
      })
    );
  }
  export() {
    return this.consume(), this.filters;
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/query_impl.js
var da = Object.defineProperty, ma = /* @__PURE__ */ s((e, t, r) => t in e ? da(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), Or = /* @__PURE__ */ s((e, t, r) => ma(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), bo = 256, be = class {
  static {
    s(this, "QueryInitializerImpl");
  }
  constructor(t) {
    Or(this, "tableName"), this.tableName = t;
  }
  withIndex(t, r) {
    $(t, 1, "withIndex", "indexName");
    let n = Tt.new();
    return r !== void 0 && (n = r(n)), new de({
      source: {
        type: "IndexRange",
        indexName: this.tableName + "." + t,
        range: n.export(),
        order: null
      },
      operators: []
    });
  }
  withSearchIndex(t, r) {
    $(t, 1, "withSearchIndex", "indexName"), $(r, 2, "withSearchIndex", "searchFilter");
    let n = At.new();
    return new de({
      source: {
        type: "Search",
        indexName: this.tableName + "." + t,
        filters: r(n).export()
      },
      operators: []
    });
  }
  fullTableScan() {
    return new de({
      source: {
        type: "FullTableScan",
        tableName: this.tableName,
        order: null
      },
      operators: []
    });
  }
  order(t) {
    return this.fullTableScan().order(t);
  }
  // This is internal API and should not be exposed to developers yet.
  async count() {
    let t = await k("1.0/count", {
      table: this.tableName
    });
    return C(t);
  }
  filter(t) {
    return this.fullTableScan().filter(t);
  }
  limit(t) {
    return this.fullTableScan().limit(t);
  }
  collect() {
    return this.fullTableScan().collect();
  }
  take(t) {
    return this.fullTableScan().take(t);
  }
  paginate(t) {
    return this.fullTableScan().paginate(t);
  }
  first() {
    return this.fullTableScan().first();
  }
  unique() {
    return this.fullTableScan().unique();
  }
  [Symbol.asyncIterator]() {
    return this.fullTableScan()[Symbol.asyncIterator]();
  }
};
function wo(e) {
  throw new Error(
    e === "consumed" ? "This query is closed and can't emit any more values." : "This query has been chained with another operator and can't be reused."
  );
}
s(wo, "throwClosedError");
var de = class e {
  static {
    s(this, "QueryImpl");
  }
  constructor(t) {
    Or(this, "state"), Or(this, "tableNameForErrorMessages"), this.state = { type: "preparing", query: t }, t.source.type === "FullTableScan" ? this.tableNameForErrorMessages = t.source.tableName : this.tableNameForErrorMessages = t.source.indexName.split(".")[0];
  }
  takeQuery() {
    if (this.state.type !== "preparing")
      throw new Error(
        "A query can only be chained once and can't be chained after iteration begins."
      );
    let t = this.state.query;
    return this.state = { type: "closed" }, t;
  }
  startQuery() {
    if (this.state.type === "executing")
      throw new Error("Iteration can only begin on a query once.");
    (this.state.type === "closed" || this.state.type === "consumed") && wo(this.state.type);
    let t = this.state.query, { queryId: r } = Me("1.0/queryStream", { query: t, version: L });
    return this.state = { type: "executing", queryId: r }, r;
  }
  closeQuery() {
    if (this.state.type === "executing") {
      let t = this.state.queryId;
      Me("1.0/queryCleanup", { queryId: t });
    }
    this.state = { type: "consumed" };
  }
  order(t) {
    $(t, 1, "order", "order");
    let r = this.takeQuery();
    if (r.source.type === "Search")
      throw new Error(
        "Search queries must always be in relevance order. Can not set order manually."
      );
    if (r.source.order !== null)
      throw new Error("Queries may only specify order at most once");
    return r.source.order = t, new e(r);
  }
  filter(t) {
    $(t, 1, "filter", "predicate");
    let r = this.takeQuery();
    if (r.operators.length >= bo)
      throw new Error(
        `Can't construct query with more than ${bo} operators`
      );
    return r.operators.push({
      filter: P(t(yo))
    }), new e(r);
  }
  limit(t) {
    $(t, 1, "limit", "n");
    let r = this.takeQuery();
    return r.operators.push({ limit: t }), new e(r);
  }
  [Symbol.asyncIterator]() {
    return this.startQuery(), this;
  }
  async next() {
    (this.state.type === "closed" || this.state.type === "consumed") && wo(this.state.type);
    let t = this.state.type === "preparing" ? this.startQuery() : this.state.queryId, { value: r, done: n } = await k("1.0/queryStreamNext", {
      queryId: t
    });
    return n && this.closeQuery(), { value: C(r), done: n };
  }
  return() {
    return this.closeQuery(), Promise.resolve({ done: !0, value: void 0 });
  }
  async paginate(t) {
    if ($(t, 1, "paginate", "options"), typeof t?.numItems != "number" || t.numItems < 0)
      throw new Error(
        `\`options.numItems\` must be a positive number. Received \`${t?.numItems}\`.`
      );
    let r = this.takeQuery(), n = t.numItems, o = t.cursor, i = t?.endCursor ?? null, c = t.maximumRowsRead ?? null, { page: u, isDone: a, continueCursor: l, splitCursor: f, pageStatus: h } = await k("1.0/queryPage", {
      query: r,
      cursor: o,
      endCursor: i,
      pageSize: n,
      maximumRowsRead: c,
      maximumBytesRead: t.maximumBytesRead,
      version: L
    });
    return {
      page: u.map((g) => C(g)),
      isDone: a,
      continueCursor: l,
      splitCursor: f,
      pageStatus: h
    };
  }
  async collect() {
    let t = [];
    for await (let r of this)
      t.push(r);
    return t;
  }
  async take(t) {
    return $(t, 1, "take", "n"), mo(t, 1, "take", "n"), this.limit(t).collect();
  }
  async first() {
    let t = await this.take(1);
    return t.length === 0 ? null : t[0];
  }
  async unique() {
    let t = await this.take(2);
    if (t.length === 0)
      return null;
    if (t.length === 2)
      throw new Error(`unique() query returned more than one result from table ${this.tableNameForErrorMessages}:
 [${t[0]._id}, ${t[1]._id}, ...]`);
    return t[0];
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/database_impl.js
async function Er(e, t, r) {
  if ($(t, 1, "get", "id"), typeof t != "string")
    throw new Error(
      `Invalid argument \`id\` for \`db.get\`, expected string but got '${typeof t}': ${t}`
    );
  let n = {
    id: O(t),
    isSystem: r,
    version: L,
    table: e
  }, o = await k("1.0/get", n);
  return C(o);
}
s(Er, "get");
function Cr() {
  let e = /* @__PURE__ */ s((o = !1) => ({
    get: /* @__PURE__ */ s(async (i, c) => c !== void 0 ? await Er(i, c, o) : await Er(void 0, i, o), "get"),
    query: /* @__PURE__ */ s((i) => new Ue(i, o).query(), "query"),
    normalizeId: /* @__PURE__ */ s((i, c) => {
      $(i, 1, "normalizeId", "tableName"), $(c, 2, "normalizeId", "id");
      let u = i.startsWith("_");
      if (u !== o)
        throw new Error(
          `${u ? "System" : "User"} tables can only be accessed from db.${o ? "" : "system."}normalizeId().`
        );
      let a = Me("1.0/db/normalizeId", {
        table: i,
        idString: c
      });
      return C(a).id;
    }, "normalizeId"),
    // We set the system reader on the next line
    system: null,
    table: /* @__PURE__ */ s((i) => new Ue(i, o), "table")
  }), "reader"), { system: t, ...r } = e(!0), n = e();
  return n.system = r, n;
}
s(Cr, "setupReader");
async function zo(e, t) {
  if (e.startsWith("_"))
    throw new Error("System tables (prefixed with `_`) are read-only.");
  $(e, 1, "insert", "table"), $(t, 2, "insert", "value");
  let r = await k("1.0/insert", {
    table: e,
    value: O(t)
  });
  return C(r)._id;
}
s(zo, "insert");
async function Tr(e, t, r) {
  $(t, 1, "patch", "id"), $(r, 2, "patch", "value"), await k("1.0/shallowMerge", {
    id: O(t),
    value: io(r),
    table: e
  });
}
s(Tr, "patch");
async function Ir(e, t, r) {
  $(t, 1, "replace", "id"), $(r, 2, "replace", "value"), await k("1.0/replace", {
    id: O(t),
    value: O(r),
    table: e
  });
}
s(Ir, "replace");
async function Ar(e, t) {
  $(t, 1, "delete", "id"), await k("1.0/remove", {
    id: O(t),
    table: e
  });
}
s(Ar, "delete_");
function vo() {
  let e = Cr();
  return {
    get: e.get,
    query: e.query,
    normalizeId: e.normalizeId,
    system: e.system,
    insert: /* @__PURE__ */ s(async (t, r) => await zo(t, r), "insert"),
    patch: /* @__PURE__ */ s(async (t, r, n) => n !== void 0 ? await Tr(t, r, n) : await Tr(void 0, t, r), "patch"),
    replace: /* @__PURE__ */ s(async (t, r, n) => n !== void 0 ? await Ir(t, r, n) : await Ir(void 0, t, r), "replace"),
    delete: /* @__PURE__ */ s(async (t, r) => r !== void 0 ? await Ar(t, r) : await Ar(void 0, t), "delete"),
    table: /* @__PURE__ */ s((t) => new Nr(t, !1), "table")
  };
}
s(vo, "setupWriter");
var Ue = class {
  static {
    s(this, "TableReader");
  }
  constructor(t, r) {
    this.tableName = t, this.isSystem = r;
  }
  async get(t) {
    return Er(this.tableName, t, this.isSystem);
  }
  query() {
    let t = this.tableName.startsWith("_");
    if (t !== this.isSystem)
      throw new Error(
        `${t ? "System" : "User"} tables can only be accessed from db.${this.isSystem ? "" : "system."}query().`
      );
    return new be(this.tableName);
  }
}, Nr = class extends Ue {
  static {
    s(this, "TableWriter");
  }
  async insert(t) {
    return zo(this.tableName, t);
  }
  async patch(t, r) {
    return Tr(this.tableName, t, r);
  }
  async replace(t, r) {
    return Ir(this.tableName, t, r);
  }
  async delete(t) {
    return Ar(this.tableName, t);
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/scheduler_impl.js
function $o() {
  return {
    runAfter: /* @__PURE__ */ s(async (e, t, r) => {
      let n = So(e, t, r);
      return await k("1.0/schedule", n);
    }, "runAfter"),
    runAt: /* @__PURE__ */ s(async (e, t, r) => {
      let n = Zo(
        e,
        t,
        r
      );
      return await k("1.0/schedule", n);
    }, "runAt"),
    cancel: /* @__PURE__ */ s(async (e) => {
      $(e, 1, "cancel", "id");
      let t = { id: O(e) };
      await k("1.0/cancel_job", t);
    }, "cancel")
  };
}
s($o, "setupMutationScheduler");
function ko(e) {
  return {
    runAfter: /* @__PURE__ */ s(async (t, r, n) => {
      let o = {
        requestId: e,
        ...So(t, r, n)
      };
      return await k("1.0/actions/schedule", o);
    }, "runAfter"),
    runAt: /* @__PURE__ */ s(async (t, r, n) => {
      let o = {
        requestId: e,
        ...Zo(t, r, n)
      };
      return await k("1.0/actions/schedule", o);
    }, "runAt"),
    cancel: /* @__PURE__ */ s(async (t) => {
      $(t, 1, "cancel", "id");
      let r = {
        requestId: e,
        id: O(t)
      };
      return await k("1.0/actions/cancel_job", r);
    }, "cancel")
  };
}
s(ko, "setupActionScheduler");
function So(e, t, r) {
  if (typeof e != "number")
    throw new Error("`delayMs` must be a number");
  if (!isFinite(e))
    throw new Error("`delayMs` must be a finite number");
  if (e < 0)
    throw new Error("`delayMs` must be non-negative");
  let n = ie(r), o = X(t), i = (Date.now() + e) / 1e3;
  return {
    ...o,
    ts: i,
    args: O(n),
    version: L
  };
}
s(So, "runAfterSyscallArgs");
function Zo(e, t, r) {
  let n;
  if (e instanceof Date)
    n = e.valueOf() / 1e3;
  else if (typeof e == "number")
    n = e / 1e3;
  else
    throw new Error("The invoke time must a Date or a timestamp");
  let o = X(t), i = ie(r);
  return {
    ...o,
    ts: n,
    args: O(i),
    version: L
  };
}
s(Zo, "runAtSyscallArgs");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/storage_impl.js
function jr(e) {
  return {
    getUrl: /* @__PURE__ */ s(async (t) => ($(t, 1, "getUrl", "storageId"), await k("1.0/storageGetUrl", {
      requestId: e,
      version: L,
      storageId: t
    })), "getUrl"),
    getMetadata: /* @__PURE__ */ s(async (t) => await k("1.0/storageGetMetadata", {
      requestId: e,
      version: L,
      storageId: t
    }), "getMetadata")
  };
}
s(jr, "setupStorageReader");
function Rr(e) {
  let t = jr(e);
  return {
    generateUploadUrl: /* @__PURE__ */ s(async () => await k("1.0/storageGenerateUploadUrl", {
      requestId: e,
      version: L
    }), "generateUploadUrl"),
    delete: /* @__PURE__ */ s(async (r) => {
      await k("1.0/storageDelete", {
        requestId: e,
        version: L,
        storageId: r
      });
    }, "delete"),
    getUrl: t.getUrl,
    getMetadata: t.getMetadata
  };
}
s(Rr, "setupStorageWriter");
function Po(e) {
  return {
    ...Rr(e),
    store: /* @__PURE__ */ s(async (r, n) => await kt("storage/storeBlob", {
      requestId: e,
      version: L,
      blob: r,
      options: n
    }), "store"),
    get: /* @__PURE__ */ s(async (r) => await kt("storage/getBlob", {
      requestId: e,
      version: L,
      storageId: r
    }), "get")
  };
}
s(Po, "setupStorageActionWriter");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/registration_impl.js
async function Oo(e, t) {
  let n = C(JSON.parse(t)), o = {
    db: vo(),
    auth: Pt(""),
    storage: Rr(""),
    scheduler: $o(),
    runQuery: /* @__PURE__ */ s((c, u) => Fr("query", c, u), "runQuery"),
    runMutation: /* @__PURE__ */ s((c, u) => Fr("mutation", c, u), "runMutation")
  }, i = await Lr(e, o, n);
  return Eo(i), JSON.stringify(O(i === void 0 ? null : i));
}
s(Oo, "invokeMutation");
function Eo(e) {
  if (e instanceof be || e instanceof de)
    throw new Error(
      "Return value is a Query. Results must be retrieved with `.collect()`, `.take(n), `.unique()`, or `.first()`."
    );
}
s(Eo, "validateReturnValue");
async function Lr(e, t, r) {
  let n;
  try {
    n = await Promise.resolve(e(t, ...r));
  } catch (o) {
    throw ha(o);
  }
  return n;
}
s(Lr, "invokeFunction");
function we(e, t) {
  return (r, n) => (globalThis.console.warn(
    `Convex functions should not directly call other Convex functions. Consider calling a helper function instead. e.g. \`export const foo = ${e}(...); await foo(ctx);\` is not supported. See https://docs.convex.dev/production/best-practices/#use-helper-functions-to-write-shared-code`
  ), t(r, n));
}
s(we, "dontCallDirectly");
function ha(e) {
  if (typeof e == "object" && e !== null && Symbol.for("ConvexError") in e) {
    let t = e;
    return t.data = JSON.stringify(
      O(t.data === void 0 ? null : t.data)
    ), t.ConvexErrorSymbol = Symbol.for("ConvexError"), t;
  } else
    return e;
}
s(ha, "serializeConvexErrorData");
function ze() {
  if (typeof window > "u" || window.__convexAllowFunctionsInBrowser)
    return;
  (Object.getOwnPropertyDescriptor(globalThis, "window")?.get?.toString().includes("[native code]") ?? !1) && console.error(
    "Convex functions should not be imported in the browser. This will throw an error in future versions of `convex`. If this is a false negative, please report it to Convex support."
  );
}
s(ze, "assertNotBrowser");
function To(e, t) {
  if (t === void 0)
    throw new Error(
      `A validator is undefined for field "${e}". This is often caused by circular imports. See https://docs.convex.dev/error#undefined-validator for details.`
    );
  return t;
}
s(To, "strictReplacer");
function ve(e) {
  return () => {
    let t = d.any();
    return typeof e == "object" && e.args !== void 0 && (t = ye(e.args)), JSON.stringify(t.json, To);
  };
}
s(ve, "exportArgs");
function $e(e) {
  return () => {
    let t;
    return typeof e == "object" && e.returns !== void 0 && (t = ye(e.returns)), JSON.stringify(t ? t.json : null, To);
  };
}
s($e, "exportReturns");
var Mr = /* @__PURE__ */ s(((e) => {
  let t = typeof e == "function" ? e : e.handler, r = we("mutation", t);
  return ze(), r.isMutation = !0, r.isPublic = !0, r.invokeMutation = (n) => Oo(t, n), r.exportArgs = ve(e), r.exportReturns = $e(e), r._handler = t, r;
}), "mutationGeneric"), Dr = /* @__PURE__ */ s(((e) => {
  let t = typeof e == "function" ? e : e.handler, r = we(
    "internalMutation",
    t
  );
  return ze(), r.isMutation = !0, r.isInternal = !0, r.invokeMutation = (n) => Oo(t, n), r.exportArgs = ve(e), r.exportReturns = $e(e), r._handler = t, r;
}), "internalMutationGeneric");
async function Io(e, t) {
  let n = C(JSON.parse(t)), o = {
    db: Cr(),
    auth: Pt(""),
    storage: jr(""),
    runQuery: /* @__PURE__ */ s((c, u) => Fr("query", c, u), "runQuery")
  }, i = await Lr(e, o, n);
  return Eo(i), JSON.stringify(O(i === void 0 ? null : i));
}
s(Io, "invokeQuery");
var Ur = /* @__PURE__ */ s(((e) => {
  let t = typeof e == "function" ? e : e.handler, r = we("query", t);
  return ze(), r.isQuery = !0, r.isPublic = !0, r.invokeQuery = (n) => Io(t, n), r.exportArgs = ve(e), r.exportReturns = $e(e), r._handler = t, r;
}), "queryGeneric"), Br = /* @__PURE__ */ s(((e) => {
  let t = typeof e == "function" ? e : e.handler, r = we("internalQuery", t);
  return ze(), r.isQuery = !0, r.isInternal = !0, r.invokeQuery = (n) => Io(t, n), r.exportArgs = ve(e), r.exportReturns = $e(e), r._handler = t, r;
}), "internalQueryGeneric");
async function Ao(e, t, r) {
  let n = C(JSON.parse(r)), i = {
    ...po(t),
    auth: Pt(t),
    scheduler: ko(t),
    storage: Po(t),
    vectorSearch: ho(t)
  }, c = await Lr(e, i, n);
  return JSON.stringify(O(c === void 0 ? null : c));
}
s(Ao, "invokeAction");
var Jr = /* @__PURE__ */ s(((e) => {
  let t = typeof e == "function" ? e : e.handler, r = we("action", t);
  return ze(), r.isAction = !0, r.isPublic = !0, r.invokeAction = (n, o) => Ao(t, n, o), r.exportArgs = ve(e), r.exportReturns = $e(e), r._handler = t, r;
}), "actionGeneric"), Vr = /* @__PURE__ */ s(((e) => {
  let t = typeof e == "function" ? e : e.handler, r = we("internalAction", t);
  return ze(), r.isAction = !0, r.isInternal = !0, r.invokeAction = (n, o) => Ao(t, n, o), r.exportArgs = ve(e), r.exportReturns = $e(e), r._handler = t, r;
}), "internalActionGeneric");
async function Fr(e, t, r) {
  let n = ie(r), o = {
    udfType: e,
    args: O(n),
    ...X(t)
  }, i = await k("1.0/runUdf", o);
  return C(i);
}
s(Fr, "runUdf");

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/pagination.js
var Fd = d.object({
  numItems: d.number(),
  cursor: d.union(d.string(), d.null()),
  endCursor: d.optional(d.union(d.string(), d.null())),
  id: d.optional(d.number()),
  maximumRowsRead: d.optional(d.number()),
  maximumBytesRead: d.optional(d.number())
});

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/api.js
function No(e = []) {
  let t = {
    get(r, n) {
      if (typeof n == "string") {
        let o = [...e, n];
        return No(o);
      } else if (n === De) {
        if (e.length < 2) {
          let c = ["api", ...e].join(".");
          throw new Error(
            `API path is expected to be of the form \`api.moduleName.functionName\`. Found: \`${c}\``
          );
        }
        let o = e.slice(0, -1).join("/"), i = e[e.length - 1];
        return i === "default" ? o : o + ":" + i;
      } else return n === Symbol.toStringTag ? "FunctionReference" : void 0;
    }
  };
  return new Proxy({}, t);
}
s(No, "createApi");
var ga = No();

// ../zodvex-triage-20260909/node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/schema.js
var _a = Object.defineProperty, xa = /* @__PURE__ */ s((e, t, r) => t in e ? _a(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), re = /* @__PURE__ */ s((e, t, r) => xa(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), Nt = class {
  static {
    s(this, "TableDefinition");
  }
  /**
   * @internal
   */
  constructor(t) {
    re(this, "indexes"), re(this, "stagedDbIndexes"), re(this, "searchIndexes"), re(this, "stagedSearchIndexes"), re(this, "vectorIndexes"), re(this, "stagedVectorIndexes"), re(this, "validator"), this.indexes = [], this.stagedDbIndexes = [], this.searchIndexes = [], this.stagedSearchIndexes = [], this.vectorIndexes = [], this.stagedVectorIndexes = [], this.validator = t;
  }
  /**
   * This API is experimental: it may change or disappear.
   *
   * Returns indexes defined on this table.
   * Intended for the advanced use cases of dynamically deciding which index to use for a query.
   * If you think you need this, please chime in on ths issue in the Convex JS GitHub repo.
   * https://github.com/get-convex/convex-js/issues/49
   */
  " indexes"() {
    return this.indexes;
  }
  index(t, r) {
    return Array.isArray(r) ? this.indexes.push({
      indexDescriptor: t,
      fields: r
    }) : r.staged ? this.stagedDbIndexes.push({
      indexDescriptor: t,
      fields: r.fields
    }) : this.indexes.push({
      indexDescriptor: t,
      fields: r.fields
    }), this;
  }
  searchIndex(t, r) {
    return r.staged ? this.stagedSearchIndexes.push({
      indexDescriptor: t,
      searchField: r.searchField,
      filterFields: r.filterFields || []
    }) : this.searchIndexes.push({
      indexDescriptor: t,
      searchField: r.searchField,
      filterFields: r.filterFields || []
    }), this;
  }
  vectorIndex(t, r) {
    return r.staged ? this.stagedVectorIndexes.push({
      indexDescriptor: t,
      vectorField: r.vectorField,
      dimensions: r.dimensions,
      filterFields: r.filterFields || []
    }) : this.vectorIndexes.push({
      indexDescriptor: t,
      vectorField: r.vectorField,
      dimensions: r.dimensions,
      filterFields: r.filterFields || []
    }), this;
  }
  /**
   * Work around for https://github.com/microsoft/TypeScript/issues/57035
   */
  self() {
    return this;
  }
  /**
   * Export the contents of this definition.
   *
   * This is called internally by the Convex framework.
   * @internal
   */
  export() {
    let t = this.validator.json;
    if (typeof t != "object")
      throw new Error(
        "Invalid validator: please make sure that the parameter of `defineTable` is valid (see https://docs.convex.dev/database/schemas)"
      );
    return {
      indexes: this.indexes,
      stagedDbIndexes: this.stagedDbIndexes,
      searchIndexes: this.searchIndexes,
      stagedSearchIndexes: this.stagedSearchIndexes,
      vectorIndexes: this.vectorIndexes,
      stagedVectorIndexes: this.stagedVectorIndexes,
      documentType: t
    };
  }
};
function qr(e) {
  return $r(e) ? new Nt(e) : new Nt(d.object(e));
}
s(qr, "defineTable");
var Wr = class {
  static {
    s(this, "SchemaDefinition");
  }
  /**
   * @internal
   */
  constructor(t, r) {
    re(this, "tables"), re(this, "strictTableNameTypes"), re(this, "schemaValidation"), this.tables = t, this.schemaValidation = r?.schemaValidation === void 0 ? !0 : r.schemaValidation;
  }
  /**
   * Export the contents of this definition.
   *
   * This is called internally by the Convex framework.
   * @internal
   */
  export() {
    return JSON.stringify({
      tables: Object.entries(this.tables).map(([t, r]) => {
        let {
          indexes: n,
          stagedDbIndexes: o,
          searchIndexes: i,
          stagedSearchIndexes: c,
          vectorIndexes: u,
          stagedVectorIndexes: a,
          documentType: l
        } = r.export();
        return {
          tableName: t,
          indexes: n,
          stagedDbIndexes: o,
          searchIndexes: i,
          stagedSearchIndexes: c,
          vectorIndexes: u,
          stagedVectorIndexes: a,
          documentType: l
        };
      }),
      schemaValidation: this.schemaValidation
    });
  }
};
function Co(e, t) {
  return new Wr(e, t);
}
s(Co, "defineSchema");
var um = Co({
  _scheduled_functions: qr({
    name: d.string(),
    args: d.array(d.any()),
    scheduledTime: d.float64(),
    completedTime: d.optional(d.float64()),
    state: d.union(
      d.object({ kind: d.literal("pending") }),
      d.object({ kind: d.literal("inProgress") }),
      d.object({ kind: d.literal("success") }),
      d.object({ kind: d.literal("failed"), error: d.string() }),
      d.object({ kind: d.literal("canceled") })
    )
  }),
  _storage: qr({
    sha256: d.string(),
    size: d.float64(),
    contentType: d.optional(d.string())
  })
});

// memory/profile.mjs
var me = class {
  static {
    s(this, "SecretText");
  }
  constructor(t) {
    this.value = t;
  }
  toWire() {
    return this.value;
  }
}, Gr = {
  seq: 1,
  at: 17e11,
  secret: "capacity",
  payload: "tiny"
};
function jo(e) {
  let t = e.kind === "native", r = e.kind === "full" || e.kind === "mini", n = t ? e.v : e.s;
  return /* @__PURE__ */ s(function({ count: i, width: c, profile: u, entries: a = 0 }) {
    if (!Number.isInteger(i) || i < 0 || !Number.isInteger(c) || c < 1 || !Number.isInteger(a) || a < 0 || !["fields-only", "codec-rich"].includes(u))
      throw new Error("Invalid graph fixture arguments");
    let l = {
      schemaConstructors: 0,
      fields: 0,
      codecSites: 0,
      allocatedCodecs: 0
    }, f = /* @__PURE__ */ s((_, ...z) => (l.schemaConstructors++, n[_](...z)), "make"), h = /* @__PURE__ */ s((_) => (l.fields += Object.keys(_).length, f("object", _)), "object"), g = /* @__PURE__ */ s(() => (l.codecSites++, t ? f("number") : (l.allocatedCodecs++, f("codec", f("number"), f("date"), {
      decode: /* @__PURE__ */ s((_) => new Date(_), "decode"),
      encode: /* @__PURE__ */ s((_) => _.getTime(), "encode")
    }))), "date"), m = /* @__PURE__ */ s(() => (l.codecSites++, t ? f("string") : (l.allocatedCodecs++, f("codec", f("string"), f("instanceof", me), {
      decode: /* @__PURE__ */ s((_) => new me(_), "decode"),
      encode: /* @__PURE__ */ s((_) => _.toWire(), "encode")
    }))), "secret"), b = /* @__PURE__ */ s((_) => {
      if (u === "fields-only")
        switch (_ % 4) {
          case 0:
            return f("string");
          case 1:
            return f("number");
          case 2:
            return f("boolean");
          case 3:
            return f("optional", f("string"));
        }
      switch (_ % 4) {
        case 0:
          return g();
        case 1:
          return m();
        case 2:
          return h({ at: g(), tag: f("optional", f("string")) });
        case 3:
          return f(
            "array",
            t ? f("union", f("string"), f("number")) : f("union", [f("string"), f("number")])
          );
      }
    }, "field"), A = {}, v = {}, q = /* @__PURE__ */ s((_, z) => {
      r ? (l.fields += Object.keys(z).length, A[_] = e.defineZodModel(_, z, e.schemaHelpers ? void 0 : { schemaHelpers: !1 })) : (v[_] = h(z), A[_] = t ? e.defineTable(v[_]) : v[_]);
    }, "add");
    q("benchmarkRows", {
      seq: f("number"),
      at: g(),
      secret: m(),
      payload: f("string")
    });
    for (let _ = 0; _ < i; _++) {
      let z = {};
      for (let F = 0; F < c; F++) z[`f${F}`] = b(F);
      q(`unused${_}`, z);
    }
    let W = r ? e.defineZodSchema(A) : t ? e.defineSchema(A) : null;
    if (r) for (let _ of Object.keys(A)) v[_] = W.__zodTableMap[_].insert;
    let R = Object.keys(A), S = {};
    for (let _ = 0; _ < a; _++) {
      let z = R[_ % R.length], F = r ? W.__zodTableMap[z].doc : v[z], vu = h({
        id: f("string"),
        label: f("optional", f("string"))
      }), $u = t ? f("union", F, f("null")) : f("nullable", F);
      S[`unused/fn${_}`] = { args: vu, returns: $u };
    }
    let N = r ? e.initZodvex(
      W,
      e.server,
      a ? { registry: /* @__PURE__ */ s(() => S, "registry") } : void 0
    ) : e.makeBuilders();
    return {
      kind: e.kind,
      options: { count: i, width: c, profile: u, entries: a },
      models: A,
      sourceSchemas: v,
      schema: W,
      registry: S,
      builders: N,
      manifest: {
        backgroundModels: i,
        totalModels: i + 1,
        backgroundTopLevelFields: i * c,
        fixedProbeFields: 4,
        profile: u,
        registryEntries: a,
        ...l,
        counterScope: "Explicit fixture constructor calls and source fields/codecs; excludes library-generated helper schemas and runtime heap objects."
      },
      operation() {
        let _ = { ...Gr }, z = t ? {
          ..._,
          at: new Date(_.at),
          secret: new me(_.secret)
        } : e.s.parse(v.benchmarkRows, _);
        if (!(z.at instanceof Date) || !(z.secret instanceof me))
          throw new Error("Codec decode failed");
        z.at = new Date(z.at.getTime() + 1e3), z.secret = new me(z.secret.toWire().toUpperCase());
        let F = t ? {
          ...z,
          at: z.at.getTime(),
          secret: z.secret.toWire()
        } : e.s.encode(v.benchmarkRows, z);
        if (JSON.stringify(F) !== JSON.stringify({
          ...Gr,
          at: Gr.at + 1e3,
          secret: "CAPACITY"
        }))
          throw new Error("Codec round trip mismatch");
        return F;
      },
      // Call after the operation and after GC measurements. The retained graph
      // includes every model, table schema, registry entry and builder closure.
      checksum() {
        let _ = 0;
        for (let [z, F] of Object.entries(A)) {
          if (!F || !v[z]) throw new Error("Missing model");
          if (_ += z.length, r && W.__zodTableMap[z].insert !== v[z])
            throw new Error("Lost table-map alias");
        }
        for (let [z, F] of Object.entries(S)) {
          if (!F.args || !F.returns)
            throw new Error("Missing registry schema");
          _ += z.length;
        }
        if (Object.keys(N).length === 0)
          throw new Error("Lost builders");
        return _;
      }
    };
  }, "buildGraph");
}
s(jo, "createGraphFactory");

// versions/4.4.3/node_modules/zod/v4/core/core.js
var Ro;
// @__NO_SIDE_EFFECTS__
function p(e, t, r) {
  function n(u, a) {
    if (u._zod || Object.defineProperty(u, "_zod", {
      value: {
        def: a,
        constr: c,
        traits: /* @__PURE__ */ new Set()
      },
      enumerable: !1
    }), u._zod.traits.has(e))
      return;
    u._zod.traits.add(e), t(u, a);
    let l = c.prototype, f = Object.keys(l);
    for (let h = 0; h < f.length; h++) {
      let g = f[h];
      g in u || (u[g] = l[g].bind(u));
    }
  }
  s(n, "init");
  let o = r?.Parent ?? Object;
  class i extends o {
    static {
      s(this, "Definition");
    }
  }
  Object.defineProperty(i, "name", { value: e });
  function c(u) {
    var a;
    let l = r?.Parent ? new i() : this;
    n(l, u), (a = l._zod).deferred ?? (a.deferred = []);
    for (let f of l._zod.deferred)
      f();
    return l;
  }
  return s(c, "_"), Object.defineProperty(c, "init", { value: n }), Object.defineProperty(c, Symbol.hasInstance, {
    value: /* @__PURE__ */ s((u) => r?.Parent && u instanceof r.Parent ? !0 : u?._zod?.traits?.has(e), "value")
  }), Object.defineProperty(c, "name", { value: e }), c;
}
s(p, "$constructor");
var Fm = Symbol("zod_brand"), ne = class extends Error {
  static {
    s(this, "$ZodAsyncError");
  }
  constructor() {
    super("Encountered Promise during synchronous parse. Use .parseAsync() instead.");
  }
}, ke = class extends Error {
  static {
    s(this, "$ZodEncodeError");
  }
  constructor(t) {
    super(`Encountered unidirectional transform during encode: ${t}`), this.name = "ZodEncodeError";
  }
};
(Ro = globalThis).__zod_globalConfig ?? (Ro.__zod_globalConfig = {});
var Se = globalThis.__zod_globalConfig;
function G(e) {
  return e && Object.assign(Se, e), Se;
}
s(G, "config");

// versions/4.4.3/node_modules/zod/v4/core/util.js
var Z = {};
ku(Z, {
  BIGINT_FORMAT_RANGES: () => Do,
  Class: () => Qr,
  NUMBER_FORMAT_RANGES: () => rn,
  aborted: () => ae,
  allowsEval: () => Xr,
  assert: () => $a,
  assertEqual: () => ba,
  assertIs: () => za,
  assertNever: () => va,
  assertNotEqual: () => wa,
  assignProp: () => ce,
  base64ToUint8Array: () => Bo,
  base64urlToUint8Array: () => Ba,
  cached: () => Ve,
  captureStackTrace: () => jt,
  cleanEnum: () => Ua,
  cleanRegex: () => We,
  clone: () => ee,
  cloneDef: () => Za,
  createTransparentProxy: () => Aa,
  defineLazy: () => w,
  esc: () => Ct,
  escapeRegex: () => oe,
  explicitlyAborted: () => nn,
  extend: () => ja,
  finalizeIssue: () => V,
  floatSafeRemainder: () => Kr,
  getElementAtPath: () => Pa,
  getEnumValues: () => Je,
  getLengthableOrigin: () => He,
  getParsedType: () => Ia,
  getSizableOrigin: () => Uo,
  hexToUint8Array: () => Va,
  isObject: () => Ze,
  isPlainObject: () => ue,
  issue: () => Oe,
  joinValues: () => ka,
  jsonStringifyReplacer: () => Pe,
  merge: () => Fa,
  mergeDefs: () => se,
  normalizeParams: () => y,
  nullish: () => qe,
  numKeys: () => Ta,
  objectClone: () => Sa,
  omit: () => Ca,
  optionalKeys: () => tn,
  parsedType: () => Da,
  partial: () => La,
  pick: () => Na,
  prefixIssues: () => H,
  primitiveTypes: () => en,
  promiseAllObject: () => Oa,
  propertyKeyTypes: () => Ge,
  randomString: () => Ea,
  required: () => Ma,
  safeExtend: () => Ra,
  shallowClone: () => Lo,
  slugify: () => Yr,
  stringifyPrimitive: () => Mo,
  uint8ArrayToBase64: () => Jo,
  uint8ArrayToBase64url: () => Ja,
  uint8ArrayToHex: () => qa,
  unwrapMessage: () => Be
});
function ba(e) {
  return e;
}
s(ba, "assertEqual");
function wa(e) {
  return e;
}
s(wa, "assertNotEqual");
function za(e) {
}
s(za, "assertIs");
function va(e) {
  throw new Error("Unexpected value in exhaustive check");
}
s(va, "assertNever");
function $a(e) {
}
s($a, "assert");
function Je(e) {
  let t = Object.values(e).filter((n) => typeof n == "number");
  return Object.entries(e).filter(([n, o]) => t.indexOf(+n) === -1).map(([n, o]) => o);
}
s(Je, "getEnumValues");
function ka(e, t = "|") {
  return e.map((r) => Mo(r)).join(t);
}
s(ka, "joinValues");
function Pe(e, t) {
  return typeof t == "bigint" ? t.toString() : t;
}
s(Pe, "jsonStringifyReplacer");
function Ve(e) {
  return {
    get value() {
      {
        let r = e();
        return Object.defineProperty(this, "value", { value: r }), r;
      }
      throw new Error("cached value already set");
    }
  };
}
s(Ve, "cached");
function qe(e) {
  return e == null;
}
s(qe, "nullish");
function We(e) {
  let t = e.startsWith("^") ? 1 : 0, r = e.endsWith("$") ? e.length - 1 : e.length;
  return e.slice(t, r);
}
s(We, "cleanRegex");
function Kr(e, t) {
  let r = e / t, n = Math.round(r), o = Number.EPSILON * Math.max(Math.abs(r), 1);
  return Math.abs(r - n) < o ? 0 : r - n;
}
s(Kr, "floatSafeRemainder");
var Fo = /* @__PURE__ */ Symbol("evaluating");
function w(e, t, r) {
  let n;
  Object.defineProperty(e, t, {
    get() {
      if (n !== Fo)
        return n === void 0 && (n = Fo, n = r()), n;
    },
    set(o) {
      Object.defineProperty(e, t, {
        value: o
        // configurable: true,
      });
    },
    configurable: !0
  });
}
s(w, "defineLazy");
function Sa(e) {
  return Object.create(Object.getPrototypeOf(e), Object.getOwnPropertyDescriptors(e));
}
s(Sa, "objectClone");
function ce(e, t, r) {
  Object.defineProperty(e, t, {
    value: r,
    writable: !0,
    enumerable: !0,
    configurable: !0
  });
}
s(ce, "assignProp");
function se(...e) {
  let t = {};
  for (let r of e) {
    let n = Object.getOwnPropertyDescriptors(r);
    Object.assign(t, n);
  }
  return Object.defineProperties({}, t);
}
s(se, "mergeDefs");
function Za(e) {
  return se(e._zod.def);
}
s(Za, "cloneDef");
function Pa(e, t) {
  return t ? t.reduce((r, n) => r?.[n], e) : e;
}
s(Pa, "getElementAtPath");
function Oa(e) {
  let t = Object.keys(e), r = t.map((n) => e[n]);
  return Promise.all(r).then((n) => {
    let o = {};
    for (let i = 0; i < t.length; i++)
      o[t[i]] = n[i];
    return o;
  });
}
s(Oa, "promiseAllObject");
function Ea(e = 10) {
  let t = "abcdefghijklmnopqrstuvwxyz", r = "";
  for (let n = 0; n < e; n++)
    r += t[Math.floor(Math.random() * t.length)];
  return r;
}
s(Ea, "randomString");
function Ct(e) {
  return JSON.stringify(e);
}
s(Ct, "esc");
function Yr(e) {
  return e.toLowerCase().trim().replace(/[^\w\s-]/g, "").replace(/[\s_-]+/g, "-").replace(/^-+|-+$/g, "");
}
s(Yr, "slugify");
var jt = "captureStackTrace" in Error ? Error.captureStackTrace : (...e) => {
};
function Ze(e) {
  return typeof e == "object" && e !== null && !Array.isArray(e);
}
s(Ze, "isObject");
var Xr = /* @__PURE__ */ Ve(() => {
  if (Se.jitless || typeof navigator < "u" && navigator?.userAgent?.includes("Cloudflare"))
    return !1;
  try {
    let e = Function;
    return new e(""), !0;
  } catch {
    return !1;
  }
});
function ue(e) {
  if (Ze(e) === !1)
    return !1;
  let t = e.constructor;
  if (t === void 0 || typeof t != "function")
    return !0;
  let r = t.prototype;
  return !(Ze(r) === !1 || Object.prototype.hasOwnProperty.call(r, "isPrototypeOf") === !1);
}
s(ue, "isPlainObject");
function Lo(e) {
  return ue(e) ? { ...e } : Array.isArray(e) ? [...e] : e instanceof Map ? new Map(e) : e instanceof Set ? new Set(e) : e;
}
s(Lo, "shallowClone");
function Ta(e) {
  let t = 0;
  for (let r in e)
    Object.prototype.hasOwnProperty.call(e, r) && t++;
  return t;
}
s(Ta, "numKeys");
var Ia = /* @__PURE__ */ s((e) => {
  let t = typeof e;
  switch (t) {
    case "undefined":
      return "undefined";
    case "string":
      return "string";
    case "number":
      return Number.isNaN(e) ? "nan" : "number";
    case "boolean":
      return "boolean";
    case "function":
      return "function";
    case "bigint":
      return "bigint";
    case "symbol":
      return "symbol";
    case "object":
      return Array.isArray(e) ? "array" : e === null ? "null" : e.then && typeof e.then == "function" && e.catch && typeof e.catch == "function" ? "promise" : typeof Map < "u" && e instanceof Map ? "map" : typeof Set < "u" && e instanceof Set ? "set" : typeof Date < "u" && e instanceof Date ? "date" : typeof File < "u" && e instanceof File ? "file" : "object";
    default:
      throw new Error(`Unknown data type: ${t}`);
  }
}, "getParsedType"), Ge = /* @__PURE__ */ new Set(["string", "number", "symbol"]), en = /* @__PURE__ */ new Set([
  "string",
  "number",
  "bigint",
  "boolean",
  "symbol",
  "undefined"
]);
function oe(e) {
  return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
s(oe, "escapeRegex");
function ee(e, t, r) {
  let n = new e._zod.constr(t ?? e._zod.def);
  return (!t || r?.parent) && (n._zod.parent = e), n;
}
s(ee, "clone");
function y(e) {
  let t = e;
  if (!t)
    return {};
  if (typeof t == "string")
    return { error: /* @__PURE__ */ s(() => t, "error") };
  if (t?.message !== void 0) {
    if (t?.error !== void 0)
      throw new Error("Cannot specify both `message` and `error` params");
    t.error = t.message;
  }
  return delete t.message, typeof t.error == "string" ? { ...t, error: /* @__PURE__ */ s(() => t.error, "error") } : t;
}
s(y, "normalizeParams");
function Aa(e) {
  let t;
  return new Proxy({}, {
    get(r, n, o) {
      return t ?? (t = e()), Reflect.get(t, n, o);
    },
    set(r, n, o, i) {
      return t ?? (t = e()), Reflect.set(t, n, o, i);
    },
    has(r, n) {
      return t ?? (t = e()), Reflect.has(t, n);
    },
    deleteProperty(r, n) {
      return t ?? (t = e()), Reflect.deleteProperty(t, n);
    },
    ownKeys(r) {
      return t ?? (t = e()), Reflect.ownKeys(t);
    },
    getOwnPropertyDescriptor(r, n) {
      return t ?? (t = e()), Reflect.getOwnPropertyDescriptor(t, n);
    },
    defineProperty(r, n, o) {
      return t ?? (t = e()), Reflect.defineProperty(t, n, o);
    }
  });
}
s(Aa, "createTransparentProxy");
function Mo(e) {
  return typeof e == "bigint" ? e.toString() + "n" : typeof e == "string" ? `"${e}"` : `${e}`;
}
s(Mo, "stringifyPrimitive");
function tn(e) {
  return Object.keys(e).filter((t) => e[t]._zod.optin === "optional" && e[t]._zod.optout === "optional");
}
s(tn, "optionalKeys");
var rn = {
  safeint: [Number.MIN_SAFE_INTEGER, Number.MAX_SAFE_INTEGER],
  int32: [-2147483648, 2147483647],
  uint32: [0, 4294967295],
  float32: [-34028234663852886e22, 34028234663852886e22],
  float64: [-Number.MAX_VALUE, Number.MAX_VALUE]
}, Do = {
  int64: [/* @__PURE__ */ BigInt("-9223372036854775808"), /* @__PURE__ */ BigInt("9223372036854775807")],
  uint64: [/* @__PURE__ */ BigInt(0), /* @__PURE__ */ BigInt("18446744073709551615")]
};
function Na(e, t) {
  let r = e._zod.def, n = r.checks;
  if (n && n.length > 0)
    throw new Error(".pick() cannot be used on object schemas containing refinements");
  let i = se(e._zod.def, {
    get shape() {
      let c = {};
      for (let u in t) {
        if (!(u in r.shape))
          throw new Error(`Unrecognized key: "${u}"`);
        t[u] && (c[u] = r.shape[u]);
      }
      return ce(this, "shape", c), c;
    },
    checks: []
  });
  return ee(e, i);
}
s(Na, "pick");
function Ca(e, t) {
  let r = e._zod.def, n = r.checks;
  if (n && n.length > 0)
    throw new Error(".omit() cannot be used on object schemas containing refinements");
  let i = se(e._zod.def, {
    get shape() {
      let c = { ...e._zod.def.shape };
      for (let u in t) {
        if (!(u in r.shape))
          throw new Error(`Unrecognized key: "${u}"`);
        t[u] && delete c[u];
      }
      return ce(this, "shape", c), c;
    },
    checks: []
  });
  return ee(e, i);
}
s(Ca, "omit");
function ja(e, t) {
  if (!ue(t))
    throw new Error("Invalid input to extend: expected a plain object");
  let r = e._zod.def.checks;
  if (r && r.length > 0) {
    let i = e._zod.def.shape;
    for (let c in t)
      if (Object.getOwnPropertyDescriptor(i, c) !== void 0)
        throw new Error("Cannot overwrite keys on object schemas containing refinements. Use `.safeExtend()` instead.");
  }
  let o = se(e._zod.def, {
    get shape() {
      let i = { ...e._zod.def.shape, ...t };
      return ce(this, "shape", i), i;
    }
  });
  return ee(e, o);
}
s(ja, "extend");
function Ra(e, t) {
  if (!ue(t))
    throw new Error("Invalid input to safeExtend: expected a plain object");
  let r = se(e._zod.def, {
    get shape() {
      let n = { ...e._zod.def.shape, ...t };
      return ce(this, "shape", n), n;
    }
  });
  return ee(e, r);
}
s(Ra, "safeExtend");
function Fa(e, t) {
  if (e._zod.def.checks?.length)
    throw new Error(".merge() cannot be used on object schemas containing refinements. Use .safeExtend() instead.");
  let r = se(e._zod.def, {
    get shape() {
      let n = { ...e._zod.def.shape, ...t._zod.def.shape };
      return ce(this, "shape", n), n;
    },
    get catchall() {
      return t._zod.def.catchall;
    },
    checks: t._zod.def.checks ?? []
  });
  return ee(e, r);
}
s(Fa, "merge");
function La(e, t, r) {
  let o = t._zod.def.checks;
  if (o && o.length > 0)
    throw new Error(".partial() cannot be used on object schemas containing refinements");
  let c = se(t._zod.def, {
    get shape() {
      let u = t._zod.def.shape, a = { ...u };
      if (r)
        for (let l in r) {
          if (!(l in u))
            throw new Error(`Unrecognized key: "${l}"`);
          r[l] && (a[l] = e ? new e({
            type: "optional",
            innerType: u[l]
          }) : u[l]);
        }
      else
        for (let l in u)
          a[l] = e ? new e({
            type: "optional",
            innerType: u[l]
          }) : u[l];
      return ce(this, "shape", a), a;
    },
    checks: []
  });
  return ee(t, c);
}
s(La, "partial");
function Ma(e, t, r) {
  let n = se(t._zod.def, {
    get shape() {
      let o = t._zod.def.shape, i = { ...o };
      if (r)
        for (let c in r) {
          if (!(c in i))
            throw new Error(`Unrecognized key: "${c}"`);
          r[c] && (i[c] = new e({
            type: "nonoptional",
            innerType: o[c]
          }));
        }
      else
        for (let c in o)
          i[c] = new e({
            type: "nonoptional",
            innerType: o[c]
          });
      return ce(this, "shape", i), i;
    }
  });
  return ee(t, n);
}
s(Ma, "required");
function ae(e, t = 0) {
  if (e.aborted === !0)
    return !0;
  for (let r = t; r < e.issues.length; r++)
    if (e.issues[r]?.continue !== !0)
      return !0;
  return !1;
}
s(ae, "aborted");
function nn(e, t = 0) {
  if (e.aborted === !0)
    return !0;
  for (let r = t; r < e.issues.length; r++)
    if (e.issues[r]?.continue === !1)
      return !0;
  return !1;
}
s(nn, "explicitlyAborted");
function H(e, t) {
  return t.map((r) => {
    var n;
    return (n = r).path ?? (n.path = []), r.path.unshift(e), r;
  });
}
s(H, "prefixIssues");
function Be(e) {
  return typeof e == "string" ? e : e?.message;
}
s(Be, "unwrapMessage");
function V(e, t, r) {
  let n = e.message ? e.message : Be(e.inst?._zod.def?.error?.(e)) ?? Be(t?.error?.(e)) ?? Be(r.customError?.(e)) ?? Be(r.localeError?.(e)) ?? "Invalid input", { inst: o, continue: i, input: c, ...u } = e;
  return u.path ?? (u.path = []), u.message = n, t?.reportInput && (u.input = c), u;
}
s(V, "finalizeIssue");
function Uo(e) {
  return e instanceof Set ? "set" : e instanceof Map ? "map" : e instanceof File ? "file" : "unknown";
}
s(Uo, "getSizableOrigin");
function He(e) {
  return Array.isArray(e) ? "array" : typeof e == "string" ? "string" : "unknown";
}
s(He, "getLengthableOrigin");
function Da(e) {
  let t = typeof e;
  switch (t) {
    case "number":
      return Number.isNaN(e) ? "nan" : "number";
    case "object": {
      if (e === null)
        return "null";
      if (Array.isArray(e))
        return "array";
      let r = e;
      if (r && Object.getPrototypeOf(r) !== Object.prototype && "constructor" in r && r.constructor)
        return r.constructor.name;
    }
  }
  return t;
}
s(Da, "parsedType");
function Oe(...e) {
  let [t, r, n] = e;
  return typeof t == "string" ? {
    message: t,
    code: "custom",
    input: r,
    inst: n
  } : { ...t };
}
s(Oe, "issue");
function Ua(e) {
  return Object.entries(e).filter(([t, r]) => Number.isNaN(Number.parseInt(t, 10))).map((t) => t[1]);
}
s(Ua, "cleanEnum");
function Bo(e) {
  let t = atob(e), r = new Uint8Array(t.length);
  for (let n = 0; n < t.length; n++)
    r[n] = t.charCodeAt(n);
  return r;
}
s(Bo, "base64ToUint8Array");
function Jo(e) {
  let t = "";
  for (let r = 0; r < e.length; r++)
    t += String.fromCharCode(e[r]);
  return btoa(t);
}
s(Jo, "uint8ArrayToBase64");
function Ba(e) {
  let t = e.replace(/-/g, "+").replace(/_/g, "/"), r = "=".repeat((4 - t.length % 4) % 4);
  return Bo(t + r);
}
s(Ba, "base64urlToUint8Array");
function Ja(e) {
  return Jo(e).replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, "");
}
s(Ja, "uint8ArrayToBase64url");
function Va(e) {
  let t = e.replace(/^0x/, "");
  if (t.length % 2 !== 0)
    throw new Error("Invalid hex string length");
  let r = new Uint8Array(t.length / 2);
  for (let n = 0; n < t.length; n += 2)
    r[n / 2] = Number.parseInt(t.slice(n, n + 2), 16);
  return r;
}
s(Va, "hexToUint8Array");
function qa(e) {
  return Array.from(e).map((t) => t.toString(16).padStart(2, "0")).join("");
}
s(qa, "uint8ArrayToHex");
var Qr = class {
  static {
    s(this, "Class");
  }
  constructor(...t) {
  }
};

// versions/4.4.3/node_modules/zod/v4/core/errors.js
var Vo = /* @__PURE__ */ s((e, t) => {
  e.name = "$ZodError", Object.defineProperty(e, "_zod", {
    value: e._zod,
    enumerable: !1
  }), Object.defineProperty(e, "issues", {
    value: t,
    enumerable: !1
  }), e.message = JSON.stringify(t, Pe, 2), Object.defineProperty(e, "toString", {
    value: /* @__PURE__ */ s(() => e.message, "value"),
    enumerable: !1
  });
}, "initializer"), Rt = p("$ZodError", Vo), Qe = p("$ZodError", Vo, { Parent: Error });
function qo(e, t = (r) => r.message) {
  let r = {}, n = [];
  for (let o of e.issues)
    o.path.length > 0 ? (r[o.path[0]] = r[o.path[0]] || [], r[o.path[0]].push(t(o))) : n.push(t(o));
  return { formErrors: n, fieldErrors: r };
}
s(qo, "flattenError");
function Wo(e, t = (r) => r.message) {
  let r = { _errors: [] }, n = /* @__PURE__ */ s((o, i = []) => {
    for (let c of o.issues)
      if (c.code === "invalid_union" && c.errors.length)
        c.errors.map((u) => n({ issues: u }, [...i, ...c.path]));
      else if (c.code === "invalid_key")
        n({ issues: c.issues }, [...i, ...c.path]);
      else if (c.code === "invalid_element")
        n({ issues: c.issues }, [...i, ...c.path]);
      else {
        let u = [...i, ...c.path];
        if (u.length === 0)
          r._errors.push(t(c));
        else {
          let a = r, l = 0;
          for (; l < u.length; ) {
            let f = u[l];
            l === u.length - 1 ? (a[f] = a[f] || { _errors: [] }, a[f]._errors.push(t(c))) : a[f] = a[f] || { _errors: [] }, a = a[f], l++;
          }
        }
      }
  }, "processError");
  return n(e), r;
}
s(Wo, "formatError");

// versions/4.4.3/node_modules/zod/v4/core/parse.js
var Ke = /* @__PURE__ */ s((e) => (t, r, n, o) => {
  let i = n ? { ...n, async: !1 } : { async: !1 }, c = t._zod.run({ value: r, issues: [] }, i);
  if (c instanceof Promise)
    throw new ne();
  if (c.issues.length) {
    let u = new (o?.Err ?? e)(c.issues.map((a) => V(a, i, G())));
    throw jt(u, o?.callee), u;
  }
  return c.value;
}, "_parse"), on = /* @__PURE__ */ Ke(Qe), Ye = /* @__PURE__ */ s((e) => async (t, r, n, o) => {
  let i = n ? { ...n, async: !0 } : { async: !0 }, c = t._zod.run({ value: r, issues: [] }, i);
  if (c instanceof Promise && (c = await c), c.issues.length) {
    let u = new (o?.Err ?? e)(c.issues.map((a) => V(a, i, G())));
    throw jt(u, o?.callee), u;
  }
  return c.value;
}, "_parseAsync"), sn = /* @__PURE__ */ Ye(Qe), Xe = /* @__PURE__ */ s((e) => (t, r, n) => {
  let o = n ? { ...n, async: !1 } : { async: !1 }, i = t._zod.run({ value: r, issues: [] }, o);
  if (i instanceof Promise)
    throw new ne();
  return i.issues.length ? {
    success: !1,
    error: new (e ?? Rt)(i.issues.map((c) => V(c, o, G())))
  } : { success: !0, data: i.value };
}, "_safeParse"), Go = /* @__PURE__ */ Xe(Qe), et = /* @__PURE__ */ s((e) => async (t, r, n) => {
  let o = n ? { ...n, async: !0 } : { async: !0 }, i = t._zod.run({ value: r, issues: [] }, o);
  return i instanceof Promise && (i = await i), i.issues.length ? {
    success: !1,
    error: new e(i.issues.map((c) => V(c, o, G())))
  } : { success: !0, data: i.value };
}, "_safeParseAsync"), Ho = /* @__PURE__ */ et(Qe), Qo = /* @__PURE__ */ s((e) => (t, r, n) => {
  let o = n ? { ...n, direction: "backward" } : { direction: "backward" };
  return Ke(e)(t, r, o);
}, "_encode");
var Ko = /* @__PURE__ */ s((e) => (t, r, n) => Ke(e)(t, r, n), "_decode");
var Yo = /* @__PURE__ */ s((e) => async (t, r, n) => {
  let o = n ? { ...n, direction: "backward" } : { direction: "backward" };
  return Ye(e)(t, r, o);
}, "_encodeAsync");
var Xo = /* @__PURE__ */ s((e) => async (t, r, n) => Ye(e)(t, r, n), "_decodeAsync");
var es = /* @__PURE__ */ s((e) => (t, r, n) => {
  let o = n ? { ...n, direction: "backward" } : { direction: "backward" };
  return Xe(e)(t, r, o);
}, "_safeEncode");
var ts = /* @__PURE__ */ s((e) => (t, r, n) => Xe(e)(t, r, n), "_safeDecode");
var rs = /* @__PURE__ */ s((e) => async (t, r, n) => {
  let o = n ? { ...n, direction: "backward" } : { direction: "backward" };
  return et(e)(t, r, o);
}, "_safeEncodeAsync");
var ns = /* @__PURE__ */ s((e) => async (t, r, n) => et(e)(t, r, n), "_safeDecodeAsync");

// versions/4.4.3/node_modules/zod/v4/core/regexes.js
var os = /^[cC][0-9a-z]{6,}$/, ss = /^[0-9a-z]+$/, is = /^[0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{26}$/, cs = /^[0-9a-vA-V]{20}$/, us = /^[A-Za-z0-9]{27}$/, as = /^[a-zA-Z0-9_-]{21}$/, ls = /^P(?:(\d+W)|(?!.*W)(?=\d|T\d)(\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+([.,]\d+)?S)?)?)$/;
var ps = /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/, cn = /* @__PURE__ */ s((e) => e ? new RegExp(`^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${e}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`) : /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/, "uuid");
var fs = /^(?!\.)(?!.*\.\.)([A-Za-z0-9_'+\-\.]*)[A-Za-z0-9_+-]@([A-Za-z0-9][A-Za-z0-9\-]*\.)+[A-Za-z]{2,}$/;
var Ga = "^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$";
function ds() {
  return new RegExp(Ga, "u");
}
s(ds, "emoji");
var ms = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/, hs = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))$/;
var gs = /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/([0-9]|[1-2][0-9]|3[0-2])$/, ys = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|::|([0-9a-fA-F]{1,4})?::([0-9a-fA-F]{1,4}:?){0,6})\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/, _s = /^$|^(?:[0-9a-zA-Z+/]{4})*(?:(?:[0-9a-zA-Z+/]{2}==)|(?:[0-9a-zA-Z+/]{3}=))?$/, un = /^[A-Za-z0-9_-]*$/;
var xs = /^https?$/, bs = /^\+[1-9]\d{6,14}$/, ws = "(?:(?:\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-(?:(?:0[13578]|1[02])-(?:0[1-9]|[12]\\d|3[01])|(?:0[469]|11)-(?:0[1-9]|[12]\\d|30)|(?:02)-(?:0[1-9]|1\\d|2[0-8])))", zs = /* @__PURE__ */ new RegExp(`^${ws}$`);
function vs(e) {
  let t = "(?:[01]\\d|2[0-3]):[0-5]\\d";
  return typeof e.precision == "number" ? e.precision === -1 ? `${t}` : e.precision === 0 ? `${t}:[0-5]\\d` : `${t}:[0-5]\\d\\.\\d{${e.precision}}` : `${t}(?::[0-5]\\d(?:\\.\\d+)?)?`;
}
s(vs, "timeSource");
function $s(e) {
  return new RegExp(`^${vs(e)}$`);
}
s($s, "time");
function ks(e) {
  let t = vs({ precision: e.precision }), r = ["Z"];
  e.local && r.push(""), e.offset && r.push("([+-](?:[01]\\d|2[0-3]):[0-5]\\d)");
  let n = `${t}(?:${r.join("|")})`;
  return new RegExp(`^${ws}T(?:${n})$`);
}
s(ks, "datetime");
var Ss = /* @__PURE__ */ s((e) => {
  let t = e ? `[\\s\\S]{${e?.minimum ?? 0},${e?.maximum ?? ""}}` : "[\\s\\S]*";
  return new RegExp(`^${t}$`);
}, "string"), Zs = /^-?\d+n?$/, Ps = /^-?\d+$/, an = /^-?\d+(?:\.\d+)?$/, Os = /^(?:true|false)$/i, Es = /^null$/i;
var Ts = /^undefined$/i;
var Is = /^[^A-Z]*$/, As = /^[^a-z]*$/;

// versions/4.4.3/node_modules/zod/v4/core/checks.js
var U = /* @__PURE__ */ p("$ZodCheck", (e, t) => {
  var r;
  e._zod ?? (e._zod = {}), e._zod.def = t, (r = e._zod).onattach ?? (r.onattach = []);
}), Ns = {
  number: "number",
  bigint: "bigint",
  object: "date"
}, ln = /* @__PURE__ */ p("$ZodCheckLessThan", (e, t) => {
  U.init(e, t);
  let r = Ns[typeof t.value];
  e._zod.onattach.push((n) => {
    let o = n._zod.bag, i = (t.inclusive ? o.maximum : o.exclusiveMaximum) ?? Number.POSITIVE_INFINITY;
    t.value < i && (t.inclusive ? o.maximum = t.value : o.exclusiveMaximum = t.value);
  }), e._zod.check = (n) => {
    (t.inclusive ? n.value <= t.value : n.value < t.value) || n.issues.push({
      origin: r,
      code: "too_big",
      maximum: typeof t.value == "object" ? t.value.getTime() : t.value,
      input: n.value,
      inclusive: t.inclusive,
      inst: e,
      continue: !t.abort
    });
  };
}), pn = /* @__PURE__ */ p("$ZodCheckGreaterThan", (e, t) => {
  U.init(e, t);
  let r = Ns[typeof t.value];
  e._zod.onattach.push((n) => {
    let o = n._zod.bag, i = (t.inclusive ? o.minimum : o.exclusiveMinimum) ?? Number.NEGATIVE_INFINITY;
    t.value > i && (t.inclusive ? o.minimum = t.value : o.exclusiveMinimum = t.value);
  }), e._zod.check = (n) => {
    (t.inclusive ? n.value >= t.value : n.value > t.value) || n.issues.push({
      origin: r,
      code: "too_small",
      minimum: typeof t.value == "object" ? t.value.getTime() : t.value,
      input: n.value,
      inclusive: t.inclusive,
      inst: e,
      continue: !t.abort
    });
  };
}), Cs = /* @__PURE__ */ p("$ZodCheckMultipleOf", (e, t) => {
  U.init(e, t), e._zod.onattach.push((r) => {
    var n;
    (n = r._zod.bag).multipleOf ?? (n.multipleOf = t.value);
  }), e._zod.check = (r) => {
    if (typeof r.value != typeof t.value)
      throw new Error("Cannot mix number and bigint in multiple_of check.");
    (typeof r.value == "bigint" ? r.value % t.value === BigInt(0) : Kr(r.value, t.value) === 0) || r.issues.push({
      origin: typeof r.value,
      code: "not_multiple_of",
      divisor: t.value,
      input: r.value,
      inst: e,
      continue: !t.abort
    });
  };
}), js = /* @__PURE__ */ p("$ZodCheckNumberFormat", (e, t) => {
  U.init(e, t), t.format = t.format || "float64";
  let r = t.format?.includes("int"), n = r ? "int" : "number", [o, i] = rn[t.format];
  e._zod.onattach.push((c) => {
    let u = c._zod.bag;
    u.format = t.format, u.minimum = o, u.maximum = i, r && (u.pattern = Ps);
  }), e._zod.check = (c) => {
    let u = c.value;
    if (r) {
      if (!Number.isInteger(u)) {
        c.issues.push({
          expected: n,
          format: t.format,
          code: "invalid_type",
          continue: !1,
          input: u,
          inst: e
        });
        return;
      }
      if (!Number.isSafeInteger(u)) {
        u > 0 ? c.issues.push({
          input: u,
          code: "too_big",
          maximum: Number.MAX_SAFE_INTEGER,
          note: "Integers must be within the safe integer range.",
          inst: e,
          origin: n,
          inclusive: !0,
          continue: !t.abort
        }) : c.issues.push({
          input: u,
          code: "too_small",
          minimum: Number.MIN_SAFE_INTEGER,
          note: "Integers must be within the safe integer range.",
          inst: e,
          origin: n,
          inclusive: !0,
          continue: !t.abort
        });
        return;
      }
    }
    u < o && c.issues.push({
      origin: "number",
      input: u,
      code: "too_small",
      minimum: o,
      inclusive: !0,
      inst: e,
      continue: !t.abort
    }), u > i && c.issues.push({
      origin: "number",
      input: u,
      code: "too_big",
      maximum: i,
      inclusive: !0,
      inst: e,
      continue: !t.abort
    });
  };
});
var Rs = /* @__PURE__ */ p("$ZodCheckMaxLength", (e, t) => {
  var r;
  U.init(e, t), (r = e._zod.def).when ?? (r.when = (n) => {
    let o = n.value;
    return !qe(o) && o.length !== void 0;
  }), e._zod.onattach.push((n) => {
    let o = n._zod.bag.maximum ?? Number.POSITIVE_INFINITY;
    t.maximum < o && (n._zod.bag.maximum = t.maximum);
  }), e._zod.check = (n) => {
    let o = n.value;
    if (o.length <= t.maximum)
      return;
    let c = He(o);
    n.issues.push({
      origin: c,
      code: "too_big",
      maximum: t.maximum,
      inclusive: !0,
      input: o,
      inst: e,
      continue: !t.abort
    });
  };
}), Fs = /* @__PURE__ */ p("$ZodCheckMinLength", (e, t) => {
  var r;
  U.init(e, t), (r = e._zod.def).when ?? (r.when = (n) => {
    let o = n.value;
    return !qe(o) && o.length !== void 0;
  }), e._zod.onattach.push((n) => {
    let o = n._zod.bag.minimum ?? Number.NEGATIVE_INFINITY;
    t.minimum > o && (n._zod.bag.minimum = t.minimum);
  }), e._zod.check = (n) => {
    let o = n.value;
    if (o.length >= t.minimum)
      return;
    let c = He(o);
    n.issues.push({
      origin: c,
      code: "too_small",
      minimum: t.minimum,
      inclusive: !0,
      input: o,
      inst: e,
      continue: !t.abort
    });
  };
}), Ls = /* @__PURE__ */ p("$ZodCheckLengthEquals", (e, t) => {
  var r;
  U.init(e, t), (r = e._zod.def).when ?? (r.when = (n) => {
    let o = n.value;
    return !qe(o) && o.length !== void 0;
  }), e._zod.onattach.push((n) => {
    let o = n._zod.bag;
    o.minimum = t.length, o.maximum = t.length, o.length = t.length;
  }), e._zod.check = (n) => {
    let o = n.value, i = o.length;
    if (i === t.length)
      return;
    let c = He(o), u = i > t.length;
    n.issues.push({
      origin: c,
      ...u ? { code: "too_big", maximum: t.length } : { code: "too_small", minimum: t.length },
      inclusive: !0,
      exact: !0,
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), tt = /* @__PURE__ */ p("$ZodCheckStringFormat", (e, t) => {
  var r, n;
  U.init(e, t), e._zod.onattach.push((o) => {
    let i = o._zod.bag;
    i.format = t.format, t.pattern && (i.patterns ?? (i.patterns = /* @__PURE__ */ new Set()), i.patterns.add(t.pattern));
  }), t.pattern ? (r = e._zod).check ?? (r.check = (o) => {
    t.pattern.lastIndex = 0, !t.pattern.test(o.value) && o.issues.push({
      origin: "string",
      code: "invalid_format",
      format: t.format,
      input: o.value,
      ...t.pattern ? { pattern: t.pattern.toString() } : {},
      inst: e,
      continue: !t.abort
    });
  }) : (n = e._zod).check ?? (n.check = () => {
  });
}), Ms = /* @__PURE__ */ p("$ZodCheckRegex", (e, t) => {
  tt.init(e, t), e._zod.check = (r) => {
    t.pattern.lastIndex = 0, !t.pattern.test(r.value) && r.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "regex",
      input: r.value,
      pattern: t.pattern.toString(),
      inst: e,
      continue: !t.abort
    });
  };
}), Ds = /* @__PURE__ */ p("$ZodCheckLowerCase", (e, t) => {
  t.pattern ?? (t.pattern = Is), tt.init(e, t);
}), Us = /* @__PURE__ */ p("$ZodCheckUpperCase", (e, t) => {
  t.pattern ?? (t.pattern = As), tt.init(e, t);
}), Bs = /* @__PURE__ */ p("$ZodCheckIncludes", (e, t) => {
  U.init(e, t);
  let r = oe(t.includes), n = new RegExp(typeof t.position == "number" ? `^.{${t.position}}${r}` : r);
  t.pattern = n, e._zod.onattach.push((o) => {
    let i = o._zod.bag;
    i.patterns ?? (i.patterns = /* @__PURE__ */ new Set()), i.patterns.add(n);
  }), e._zod.check = (o) => {
    o.value.includes(t.includes, t.position) || o.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "includes",
      includes: t.includes,
      input: o.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Js = /* @__PURE__ */ p("$ZodCheckStartsWith", (e, t) => {
  U.init(e, t);
  let r = new RegExp(`^${oe(t.prefix)}.*`);
  t.pattern ?? (t.pattern = r), e._zod.onattach.push((n) => {
    let o = n._zod.bag;
    o.patterns ?? (o.patterns = /* @__PURE__ */ new Set()), o.patterns.add(r);
  }), e._zod.check = (n) => {
    n.value.startsWith(t.prefix) || n.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "starts_with",
      prefix: t.prefix,
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Vs = /* @__PURE__ */ p("$ZodCheckEndsWith", (e, t) => {
  U.init(e, t);
  let r = new RegExp(`.*${oe(t.suffix)}$`);
  t.pattern ?? (t.pattern = r), e._zod.onattach.push((n) => {
    let o = n._zod.bag;
    o.patterns ?? (o.patterns = /* @__PURE__ */ new Set()), o.patterns.add(r);
  }), e._zod.check = (n) => {
    n.value.endsWith(t.suffix) || n.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "ends_with",
      suffix: t.suffix,
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
});
var qs = /* @__PURE__ */ p("$ZodCheckOverwrite", (e, t) => {
  U.init(e, t), e._zod.check = (r) => {
    r.value = t.tx(r.value);
  };
});

// versions/4.4.3/node_modules/zod/v4/core/doc.js
var Lt = class {
  static {
    s(this, "Doc");
  }
  constructor(t = []) {
    this.content = [], this.indent = 0, this && (this.args = t);
  }
  indented(t) {
    this.indent += 1, t(this), this.indent -= 1;
  }
  write(t) {
    if (typeof t == "function") {
      t(this, { execution: "sync" }), t(this, { execution: "async" });
      return;
    }
    let n = t.split(`
`).filter((c) => c), o = Math.min(...n.map((c) => c.length - c.trimStart().length)), i = n.map((c) => c.slice(o)).map((c) => " ".repeat(this.indent * 2) + c);
    for (let c of i)
      this.content.push(c);
  }
  compile() {
    let t = Function, r = this?.args, o = [...(this?.content ?? [""]).map((i) => `  ${i}`)];
    return new t(...r, o.join(`
`));
  }
};

// versions/4.4.3/node_modules/zod/v4/core/versions.js
var Gs = {
  major: 4,
  minor: 4,
  patch: 3
};

// versions/4.4.3/node_modules/zod/v4/core/schemas.js
var x = /* @__PURE__ */ p("$ZodType", (e, t) => {
  var r;
  e ?? (e = {}), e._zod.def = t, e._zod.bag = e._zod.bag || {}, e._zod.version = Gs;
  let n = [...e._zod.def.checks ?? []];
  e._zod.traits.has("$ZodCheck") && n.unshift(e);
  for (let o of n)
    for (let i of o._zod.onattach)
      i(e);
  if (n.length === 0)
    (r = e._zod).deferred ?? (r.deferred = []), e._zod.deferred?.push(() => {
      e._zod.run = e._zod.parse;
    });
  else {
    let o = /* @__PURE__ */ s((c, u, a) => {
      let l = ae(c), f;
      for (let h of u) {
        if (h._zod.def.when) {
          if (nn(c) || !h._zod.def.when(c))
            continue;
        } else if (l)
          continue;
        let g = c.issues.length, m = h._zod.check(c);
        if (m instanceof Promise && a?.async === !1)
          throw new ne();
        if (f || m instanceof Promise)
          f = (f ?? Promise.resolve()).then(async () => {
            await m, c.issues.length !== g && (l || (l = ae(c, g)));
          });
        else {
          if (c.issues.length === g)
            continue;
          l || (l = ae(c, g));
        }
      }
      return f ? f.then(() => c) : c;
    }, "runChecks"), i = /* @__PURE__ */ s((c, u, a) => {
      if (ae(c))
        return c.aborted = !0, c;
      let l = o(u, n, a);
      if (l instanceof Promise) {
        if (a.async === !1)
          throw new ne();
        return l.then((f) => e._zod.parse(f, a));
      }
      return e._zod.parse(l, a);
    }, "handleCanaryResult");
    e._zod.run = (c, u) => {
      if (u.skipChecks)
        return e._zod.parse(c, u);
      if (u.direction === "backward") {
        let l = e._zod.parse({ value: c.value, issues: [] }, { ...u, skipChecks: !0 });
        return l instanceof Promise ? l.then((f) => i(f, c, u)) : i(l, c, u);
      }
      let a = e._zod.parse(c, u);
      if (a instanceof Promise) {
        if (u.async === !1)
          throw new ne();
        return a.then((l) => o(l, n, u));
      }
      return o(a, n, u);
    };
  }
  w(e, "~standard", () => ({
    validate: /* @__PURE__ */ s((o) => {
      try {
        let i = Go(e, o);
        return i.success ? { value: i.data } : { issues: i.error?.issues };
      } catch {
        return Ho(e, o).then((c) => c.success ? { value: c.data } : { issues: c.error?.issues });
      }
    }, "validate"),
    vendor: "zod",
    version: 1
  }));
}), Ee = /* @__PURE__ */ p("$ZodString", (e, t) => {
  x.init(e, t), e._zod.pattern = [...e?._zod.bag?.patterns ?? []].pop() ?? Ss(e._zod.bag), e._zod.parse = (r, n) => {
    if (t.coerce)
      try {
        r.value = String(r.value);
      } catch {
      }
    return typeof r.value == "string" || r.issues.push({
      expected: "string",
      code: "invalid_type",
      input: r.value,
      inst: e
    }), r;
  };
}), E = /* @__PURE__ */ p("$ZodStringFormat", (e, t) => {
  tt.init(e, t), Ee.init(e, t);
}), ui = /* @__PURE__ */ p("$ZodGUID", (e, t) => {
  t.pattern ?? (t.pattern = ps), E.init(e, t);
}), ai = /* @__PURE__ */ p("$ZodUUID", (e, t) => {
  if (t.version) {
    let n = {
      v1: 1,
      v2: 2,
      v3: 3,
      v4: 4,
      v5: 5,
      v6: 6,
      v7: 7,
      v8: 8
    }[t.version];
    if (n === void 0)
      throw new Error(`Invalid UUID version: "${t.version}"`);
    t.pattern ?? (t.pattern = cn(n));
  } else
    t.pattern ?? (t.pattern = cn());
  E.init(e, t);
}), li = /* @__PURE__ */ p("$ZodEmail", (e, t) => {
  t.pattern ?? (t.pattern = fs), E.init(e, t);
}), pi = /* @__PURE__ */ p("$ZodURL", (e, t) => {
  E.init(e, t), e._zod.check = (r) => {
    try {
      let n = r.value.trim();
      if (!t.normalize && t.protocol?.source === xs.source && !/^https?:\/\//i.test(n)) {
        r.issues.push({
          code: "invalid_format",
          format: "url",
          note: "Invalid URL format",
          input: r.value,
          inst: e,
          continue: !t.abort
        });
        return;
      }
      let o = new URL(n);
      t.hostname && (t.hostname.lastIndex = 0, t.hostname.test(o.hostname) || r.issues.push({
        code: "invalid_format",
        format: "url",
        note: "Invalid hostname",
        pattern: t.hostname.source,
        input: r.value,
        inst: e,
        continue: !t.abort
      })), t.protocol && (t.protocol.lastIndex = 0, t.protocol.test(o.protocol.endsWith(":") ? o.protocol.slice(0, -1) : o.protocol) || r.issues.push({
        code: "invalid_format",
        format: "url",
        note: "Invalid protocol",
        pattern: t.protocol.source,
        input: r.value,
        inst: e,
        continue: !t.abort
      })), t.normalize ? r.value = o.href : r.value = n;
      return;
    } catch {
      r.issues.push({
        code: "invalid_format",
        format: "url",
        input: r.value,
        inst: e,
        continue: !t.abort
      });
    }
  };
}), fi = /* @__PURE__ */ p("$ZodEmoji", (e, t) => {
  t.pattern ?? (t.pattern = ds()), E.init(e, t);
}), di = /* @__PURE__ */ p("$ZodNanoID", (e, t) => {
  t.pattern ?? (t.pattern = as), E.init(e, t);
}), mi = /* @__PURE__ */ p("$ZodCUID", (e, t) => {
  t.pattern ?? (t.pattern = os), E.init(e, t);
}), hi = /* @__PURE__ */ p("$ZodCUID2", (e, t) => {
  t.pattern ?? (t.pattern = ss), E.init(e, t);
}), gi = /* @__PURE__ */ p("$ZodULID", (e, t) => {
  t.pattern ?? (t.pattern = is), E.init(e, t);
}), yi = /* @__PURE__ */ p("$ZodXID", (e, t) => {
  t.pattern ?? (t.pattern = cs), E.init(e, t);
}), _i = /* @__PURE__ */ p("$ZodKSUID", (e, t) => {
  t.pattern ?? (t.pattern = us), E.init(e, t);
}), xi = /* @__PURE__ */ p("$ZodISODateTime", (e, t) => {
  t.pattern ?? (t.pattern = ks(t)), E.init(e, t);
}), bi = /* @__PURE__ */ p("$ZodISODate", (e, t) => {
  t.pattern ?? (t.pattern = zs), E.init(e, t);
}), wi = /* @__PURE__ */ p("$ZodISOTime", (e, t) => {
  t.pattern ?? (t.pattern = $s(t)), E.init(e, t);
}), zi = /* @__PURE__ */ p("$ZodISODuration", (e, t) => {
  t.pattern ?? (t.pattern = ls), E.init(e, t);
}), vi = /* @__PURE__ */ p("$ZodIPv4", (e, t) => {
  t.pattern ?? (t.pattern = ms), E.init(e, t), e._zod.bag.format = "ipv4";
}), $i = /* @__PURE__ */ p("$ZodIPv6", (e, t) => {
  t.pattern ?? (t.pattern = hs), E.init(e, t), e._zod.bag.format = "ipv6", e._zod.check = (r) => {
    try {
      new URL(`http://[${r.value}]`);
    } catch {
      r.issues.push({
        code: "invalid_format",
        format: "ipv6",
        input: r.value,
        inst: e,
        continue: !t.abort
      });
    }
  };
});
var ki = /* @__PURE__ */ p("$ZodCIDRv4", (e, t) => {
  t.pattern ?? (t.pattern = gs), E.init(e, t);
}), Si = /* @__PURE__ */ p("$ZodCIDRv6", (e, t) => {
  t.pattern ?? (t.pattern = ys), E.init(e, t), e._zod.check = (r) => {
    let n = r.value.split("/");
    try {
      if (n.length !== 2)
        throw new Error();
      let [o, i] = n;
      if (!i)
        throw new Error();
      let c = Number(i);
      if (`${c}` !== i)
        throw new Error();
      if (c < 0 || c > 128)
        throw new Error();
      new URL(`http://[${o}]`);
    } catch {
      r.issues.push({
        code: "invalid_format",
        format: "cidrv6",
        input: r.value,
        inst: e,
        continue: !t.abort
      });
    }
  };
});
function Zi(e) {
  if (e === "")
    return !0;
  if (/\s/.test(e) || e.length % 4 !== 0)
    return !1;
  try {
    return atob(e), !0;
  } catch {
    return !1;
  }
}
s(Zi, "isValidBase64");
var Pi = /* @__PURE__ */ p("$ZodBase64", (e, t) => {
  t.pattern ?? (t.pattern = _s), E.init(e, t), e._zod.bag.contentEncoding = "base64", e._zod.check = (r) => {
    Zi(r.value) || r.issues.push({
      code: "invalid_format",
      format: "base64",
      input: r.value,
      inst: e,
      continue: !t.abort
    });
  };
});
function Ha(e) {
  if (!un.test(e))
    return !1;
  let t = e.replace(/[-_]/g, (n) => n === "-" ? "+" : "/"), r = t.padEnd(Math.ceil(t.length / 4) * 4, "=");
  return Zi(r);
}
s(Ha, "isValidBase64URL");
var Oi = /* @__PURE__ */ p("$ZodBase64URL", (e, t) => {
  t.pattern ?? (t.pattern = un), E.init(e, t), e._zod.bag.contentEncoding = "base64url", e._zod.check = (r) => {
    Ha(r.value) || r.issues.push({
      code: "invalid_format",
      format: "base64url",
      input: r.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Ei = /* @__PURE__ */ p("$ZodE164", (e, t) => {
  t.pattern ?? (t.pattern = bs), E.init(e, t);
});
function Qa(e, t = null) {
  try {
    let r = e.split(".");
    if (r.length !== 3)
      return !1;
    let [n] = r;
    if (!n)
      return !1;
    let o = JSON.parse(atob(n));
    return !("typ" in o && o?.typ !== "JWT" || !o.alg || t && (!("alg" in o) || o.alg !== t));
  } catch {
    return !1;
  }
}
s(Qa, "isValidJWT");
var Ti = /* @__PURE__ */ p("$ZodJWT", (e, t) => {
  E.init(e, t), e._zod.check = (r) => {
    Qa(r.value, t.alg) || r.issues.push({
      code: "invalid_format",
      format: "jwt",
      input: r.value,
      inst: e,
      continue: !t.abort
    });
  };
});
var rt = /* @__PURE__ */ p("$ZodNumber", (e, t) => {
  x.init(e, t), e._zod.pattern = e._zod.bag.pattern ?? an, e._zod.parse = (r, n) => {
    if (t.coerce)
      try {
        r.value = Number(r.value);
      } catch {
      }
    let o = r.value;
    if (typeof o == "number" && !Number.isNaN(o) && Number.isFinite(o))
      return r;
    let i = typeof o == "number" ? Number.isNaN(o) ? "NaN" : Number.isFinite(o) ? void 0 : "Infinity" : void 0;
    return r.issues.push({
      expected: "number",
      code: "invalid_type",
      input: o,
      inst: e,
      ...i ? { received: i } : {}
    }), r;
  };
}), Ii = /* @__PURE__ */ p("$ZodNumberFormat", (e, t) => {
  js.init(e, t), rt.init(e, t);
}), Jt = /* @__PURE__ */ p("$ZodBoolean", (e, t) => {
  x.init(e, t), e._zod.pattern = Os, e._zod.parse = (r, n) => {
    if (t.coerce)
      try {
        r.value = !!r.value;
      } catch {
      }
    let o = r.value;
    return typeof o == "boolean" || r.issues.push({
      expected: "boolean",
      code: "invalid_type",
      input: o,
      inst: e
    }), r;
  };
}), dn = /* @__PURE__ */ p("$ZodBigInt", (e, t) => {
  x.init(e, t), e._zod.pattern = Zs, e._zod.parse = (r, n) => {
    if (t.coerce)
      try {
        r.value = BigInt(r.value);
      } catch {
      }
    return typeof r.value == "bigint" || r.issues.push({
      expected: "bigint",
      code: "invalid_type",
      input: r.value,
      inst: e
    }), r;
  };
});
var mn = /* @__PURE__ */ p("$ZodSymbol", (e, t) => {
  x.init(e, t), e._zod.parse = (r, n) => {
    let o = r.value;
    return typeof o == "symbol" || r.issues.push({
      expected: "symbol",
      code: "invalid_type",
      input: o,
      inst: e
    }), r;
  };
}), hn = /* @__PURE__ */ p("$ZodUndefined", (e, t) => {
  x.init(e, t), e._zod.pattern = Ts, e._zod.values = /* @__PURE__ */ new Set([void 0]), e._zod.parse = (r, n) => {
    let o = r.value;
    return typeof o > "u" || r.issues.push({
      expected: "undefined",
      code: "invalid_type",
      input: o,
      inst: e
    }), r;
  };
}), gn = /* @__PURE__ */ p("$ZodNull", (e, t) => {
  x.init(e, t), e._zod.pattern = Es, e._zod.values = /* @__PURE__ */ new Set([null]), e._zod.parse = (r, n) => {
    let o = r.value;
    return o === null || r.issues.push({
      expected: "null",
      code: "invalid_type",
      input: o,
      inst: e
    }), r;
  };
}), yn = /* @__PURE__ */ p("$ZodAny", (e, t) => {
  x.init(e, t), e._zod.parse = (r) => r;
}), Vt = /* @__PURE__ */ p("$ZodUnknown", (e, t) => {
  x.init(e, t), e._zod.parse = (r) => r;
}), qt = /* @__PURE__ */ p("$ZodNever", (e, t) => {
  x.init(e, t), e._zod.parse = (r, n) => (r.issues.push({
    expected: "never",
    code: "invalid_type",
    input: r.value,
    inst: e
  }), r);
}), _n = /* @__PURE__ */ p("$ZodVoid", (e, t) => {
  x.init(e, t), e._zod.parse = (r, n) => {
    let o = r.value;
    return typeof o > "u" || r.issues.push({
      expected: "void",
      code: "invalid_type",
      input: o,
      inst: e
    }), r;
  };
}), Wt = /* @__PURE__ */ p("$ZodDate", (e, t) => {
  x.init(e, t), e._zod.parse = (r, n) => {
    if (t.coerce)
      try {
        r.value = new Date(r.value);
      } catch {
      }
    let o = r.value, i = o instanceof Date;
    return i && !Number.isNaN(o.getTime()) || r.issues.push({
      expected: "date",
      code: "invalid_type",
      input: o,
      ...i ? { received: "Invalid Date" } : {},
      inst: e
    }), r;
  };
});
function Hs(e, t, r) {
  e.issues.length && t.issues.push(...H(r, e.issues)), t.value[r] = e.value;
}
s(Hs, "handleArrayResult");
var Gt = /* @__PURE__ */ p("$ZodArray", (e, t) => {
  x.init(e, t), e._zod.parse = (r, n) => {
    let o = r.value;
    if (!Array.isArray(o))
      return r.issues.push({
        expected: "array",
        code: "invalid_type",
        input: o,
        inst: e
      }), r;
    r.value = Array(o.length);
    let i = [];
    for (let c = 0; c < o.length; c++) {
      let u = o[c], a = t.element._zod.run({
        value: u,
        issues: []
      }, n);
      a instanceof Promise ? i.push(a.then((l) => Hs(l, r, c))) : Hs(a, r, c);
    }
    return i.length ? Promise.all(i).then(() => r) : r;
  };
});
function Bt(e, t, r, n, o, i) {
  let c = r in n;
  if (e.issues.length) {
    if (o && i && !c)
      return;
    t.issues.push(...H(r, e.issues));
  }
  if (!c && !o) {
    e.issues.length || t.issues.push({
      code: "invalid_type",
      expected: "nonoptional",
      input: void 0,
      path: [r]
    });
    return;
  }
  e.value === void 0 ? c && (t.value[r] = void 0) : t.value[r] = e.value;
}
s(Bt, "handlePropertyResult");
function Ai(e) {
  let t = Object.keys(e.shape);
  for (let n of t)
    if (!e.shape?.[n]?._zod?.traits?.has("$ZodType"))
      throw new Error(`Invalid element at key "${n}": expected a Zod schema`);
  let r = tn(e.shape);
  return {
    ...e,
    keys: t,
    keySet: new Set(t),
    numKeys: t.length,
    optionalKeys: new Set(r)
  };
}
s(Ai, "normalizeDef");
function Ni(e, t, r, n, o, i) {
  let c = [], u = o.keySet, a = o.catchall._zod, l = a.def.type, f = a.optin === "optional", h = a.optout === "optional";
  for (let g in t) {
    if (g === "__proto__" || u.has(g))
      continue;
    if (l === "never") {
      c.push(g);
      continue;
    }
    let m = a.run({ value: t[g], issues: [] }, n);
    m instanceof Promise ? e.push(m.then((b) => Bt(b, r, g, t, f, h))) : Bt(m, r, g, t, f, h);
  }
  return c.length && r.issues.push({
    code: "unrecognized_keys",
    keys: c,
    input: t,
    inst: i
  }), e.length ? Promise.all(e).then(() => r) : r;
}
s(Ni, "handleCatchall");
var Ht = /* @__PURE__ */ p("$ZodObject", (e, t) => {
  if (x.init(e, t), !Object.getOwnPropertyDescriptor(t, "shape")?.get) {
    let u = t.shape;
    Object.defineProperty(t, "shape", {
      get: /* @__PURE__ */ s(() => {
        let a = { ...u };
        return Object.defineProperty(t, "shape", {
          value: a
        }), a;
      }, "get")
    });
  }
  let n = Ve(() => Ai(t));
  w(e._zod, "propValues", () => {
    let u = t.shape, a = {};
    for (let l in u) {
      let f = u[l]._zod;
      if (f.values) {
        a[l] ?? (a[l] = /* @__PURE__ */ new Set());
        for (let h of f.values)
          a[l].add(h);
      }
    }
    return a;
  });
  let o = Ze, i = t.catchall, c;
  e._zod.parse = (u, a) => {
    c ?? (c = n.value);
    let l = u.value;
    if (!o(l))
      return u.issues.push({
        expected: "object",
        code: "invalid_type",
        input: l,
        inst: e
      }), u;
    u.value = {};
    let f = [], h = c.shape;
    for (let g of c.keys) {
      let m = h[g], b = m._zod.optin === "optional", A = m._zod.optout === "optional", v = m._zod.run({ value: l[g], issues: [] }, a);
      v instanceof Promise ? f.push(v.then((q) => Bt(q, u, g, l, b, A))) : Bt(v, u, g, l, b, A);
    }
    return i ? Ni(f, l, u, a, n.value, e) : f.length ? Promise.all(f).then(() => u) : u;
  };
}), Ci = /* @__PURE__ */ p("$ZodObjectJIT", (e, t) => {
  Ht.init(e, t);
  let r = e._zod.parse, n = Ve(() => Ai(t)), o = /* @__PURE__ */ s((g) => {
    let m = new Lt(["shape", "payload", "ctx"]), b = n.value, A = /* @__PURE__ */ s((R) => {
      let S = Ct(R);
      return `shape[${S}]._zod.run({ value: input[${S}], issues: [] }, ctx)`;
    }, "parseStr");
    m.write("const input = payload.value;");
    let v = /* @__PURE__ */ Object.create(null), q = 0;
    for (let R of b.keys)
      v[R] = `key_${q++}`;
    m.write("const newResult = {};");
    for (let R of b.keys) {
      let S = v[R], N = Ct(R), _ = g[R], z = _?._zod?.optin === "optional", F = _?._zod?.optout === "optional";
      m.write(`const ${S} = ${A(R)};`), z && F ? m.write(`
        if (${S}.issues.length) {
          if (${N} in input) {
            payload.issues = payload.issues.concat(${S}.issues.map(iss => ({
              ...iss,
              path: iss.path ? [${N}, ...iss.path] : [${N}]
            })));
          }
        }
        
        if (${S}.value === undefined) {
          if (${N} in input) {
            newResult[${N}] = undefined;
          }
        } else {
          newResult[${N}] = ${S}.value;
        }
        
      `) : z ? m.write(`
        if (${S}.issues.length) {
          payload.issues = payload.issues.concat(${S}.issues.map(iss => ({
            ...iss,
            path: iss.path ? [${N}, ...iss.path] : [${N}]
          })));
        }
        
        if (${S}.value === undefined) {
          if (${N} in input) {
            newResult[${N}] = undefined;
          }
        } else {
          newResult[${N}] = ${S}.value;
        }
        
      `) : m.write(`
        const ${S}_present = ${N} in input;
        if (${S}.issues.length) {
          payload.issues = payload.issues.concat(${S}.issues.map(iss => ({
            ...iss,
            path: iss.path ? [${N}, ...iss.path] : [${N}]
          })));
        }
        if (!${S}_present && !${S}.issues.length) {
          payload.issues.push({
            code: "invalid_type",
            expected: "nonoptional",
            input: undefined,
            path: [${N}]
          });
        }

        if (${S}_present) {
          if (${S}.value === undefined) {
            newResult[${N}] = undefined;
          } else {
            newResult[${N}] = ${S}.value;
          }
        }

      `);
    }
    m.write("payload.value = newResult;"), m.write("return payload;");
    let W = m.compile();
    return (R, S) => W(g, R, S);
  }, "generateFastpass"), i, c = Ze, u = !Se.jitless, l = u && Xr.value, f = t.catchall, h;
  e._zod.parse = (g, m) => {
    h ?? (h = n.value);
    let b = g.value;
    return c(b) ? u && l && m?.async === !1 && m.jitless !== !0 ? (i || (i = o(t.shape)), g = i(g, m), f ? Ni([], b, g, m, h, e) : g) : r(g, m) : (g.issues.push({
      expected: "object",
      code: "invalid_type",
      input: b,
      inst: e
    }), g);
  };
});
function Qs(e, t, r, n) {
  for (let i of e)
    if (i.issues.length === 0)
      return t.value = i.value, t;
  let o = e.filter((i) => !ae(i));
  return o.length === 1 ? (t.value = o[0].value, o[0]) : (t.issues.push({
    code: "invalid_union",
    input: t.value,
    inst: r,
    errors: e.map((i) => i.issues.map((c) => V(c, n, G())))
  }), t);
}
s(Qs, "handleUnionResults");
var Qt = /* @__PURE__ */ p("$ZodUnion", (e, t) => {
  x.init(e, t), w(e._zod, "optin", () => t.options.some((n) => n._zod.optin === "optional") ? "optional" : void 0), w(e._zod, "optout", () => t.options.some((n) => n._zod.optout === "optional") ? "optional" : void 0), w(e._zod, "values", () => {
    if (t.options.every((n) => n._zod.values))
      return new Set(t.options.flatMap((n) => Array.from(n._zod.values)));
  }), w(e._zod, "pattern", () => {
    if (t.options.every((n) => n._zod.pattern)) {
      let n = t.options.map((o) => o._zod.pattern);
      return new RegExp(`^(${n.map((o) => We(o.source)).join("|")})$`);
    }
  });
  let r = t.options.length === 1 ? t.options[0]._zod.run : null;
  e._zod.parse = (n, o) => {
    if (r)
      return r(n, o);
    let i = !1, c = [];
    for (let u of t.options) {
      let a = u._zod.run({
        value: n.value,
        issues: []
      }, o);
      if (a instanceof Promise)
        c.push(a), i = !0;
      else {
        if (a.issues.length === 0)
          return a;
        c.push(a);
      }
    }
    return i ? Promise.all(c).then((u) => Qs(u, n, e, o)) : Qs(c, n, e, o);
  };
});
var Kt = /* @__PURE__ */ p("$ZodIntersection", (e, t) => {
  x.init(e, t), e._zod.parse = (r, n) => {
    let o = r.value, i = t.left._zod.run({ value: o, issues: [] }, n), c = t.right._zod.run({ value: o, issues: [] }, n);
    return i instanceof Promise || c instanceof Promise ? Promise.all([i, c]).then(([a, l]) => Ks(r, a, l)) : Ks(r, i, c);
  };
});
function fn(e, t) {
  if (e === t)
    return { valid: !0, data: e };
  if (e instanceof Date && t instanceof Date && +e == +t)
    return { valid: !0, data: e };
  if (ue(e) && ue(t)) {
    let r = Object.keys(t), n = Object.keys(e).filter((i) => r.indexOf(i) !== -1), o = { ...e, ...t };
    for (let i of n) {
      let c = fn(e[i], t[i]);
      if (!c.valid)
        return {
          valid: !1,
          mergeErrorPath: [i, ...c.mergeErrorPath]
        };
      o[i] = c.data;
    }
    return { valid: !0, data: o };
  }
  if (Array.isArray(e) && Array.isArray(t)) {
    if (e.length !== t.length)
      return { valid: !1, mergeErrorPath: [] };
    let r = [];
    for (let n = 0; n < e.length; n++) {
      let o = e[n], i = t[n], c = fn(o, i);
      if (!c.valid)
        return {
          valid: !1,
          mergeErrorPath: [n, ...c.mergeErrorPath]
        };
      r.push(c.data);
    }
    return { valid: !0, data: r };
  }
  return { valid: !1, mergeErrorPath: [] };
}
s(fn, "mergeValues");
function Ks(e, t, r) {
  let n = /* @__PURE__ */ new Map(), o;
  for (let u of t.issues)
    if (u.code === "unrecognized_keys") {
      o ?? (o = u);
      for (let a of u.keys)
        n.has(a) || n.set(a, {}), n.get(a).l = !0;
    } else
      e.issues.push(u);
  for (let u of r.issues)
    if (u.code === "unrecognized_keys")
      for (let a of u.keys)
        n.has(a) || n.set(a, {}), n.get(a).r = !0;
    else
      e.issues.push(u);
  let i = [...n].filter(([, u]) => u.l && u.r).map(([u]) => u);
  if (i.length && o && e.issues.push({ ...o, keys: i }), ae(e))
    return e;
  let c = fn(t.value, r.value);
  if (!c.valid)
    throw new Error(`Unmergable intersection. Error path: ${JSON.stringify(c.mergeErrorPath)}`);
  return e.value = c.data, e;
}
s(Ks, "handleIntersectionResults");
var Yt = /* @__PURE__ */ p("$ZodTuple", (e, t) => {
  x.init(e, t);
  let r = t.items;
  e._zod.parse = (n, o) => {
    let i = n.value;
    if (!Array.isArray(i))
      return n.issues.push({
        input: i,
        inst: e,
        expected: "tuple",
        code: "invalid_type"
      }), n;
    n.value = [];
    let c = [], u = Ys(r, "optin"), a = Ys(r, "optout");
    if (!t.rest) {
      if (i.length < u)
        return n.issues.push({
          code: "too_small",
          minimum: u,
          inclusive: !0,
          input: i,
          inst: e,
          origin: "array"
        }), n;
      i.length > r.length && n.issues.push({
        code: "too_big",
        maximum: r.length,
        inclusive: !0,
        input: i,
        inst: e,
        origin: "array"
      });
    }
    let l = new Array(r.length);
    for (let f = 0; f < r.length; f++) {
      let h = r[f]._zod.run({ value: i[f], issues: [] }, o);
      h instanceof Promise ? c.push(h.then((g) => {
        l[f] = g;
      })) : l[f] = h;
    }
    if (t.rest) {
      let f = r.length - 1, h = i.slice(r.length);
      for (let g of h) {
        f++;
        let m = t.rest._zod.run({ value: g, issues: [] }, o);
        m instanceof Promise ? c.push(m.then((b) => Xs(b, n, f))) : Xs(m, n, f);
      }
    }
    return c.length ? Promise.all(c).then(() => ei(l, n, r, i, a)) : ei(l, n, r, i, a);
  };
});
function Ys(e, t) {
  for (let r = e.length - 1; r >= 0; r--)
    if (e[r]._zod[t] !== "optional")
      return r + 1;
  return 0;
}
s(Ys, "getTupleOptStart");
function Xs(e, t, r) {
  e.issues.length && t.issues.push(...H(r, e.issues)), t.value[r] = e.value;
}
s(Xs, "handleTupleResult");
function ei(e, t, r, n, o) {
  for (let i = 0; i < r.length; i++) {
    let c = e[i], u = i < n.length;
    if (c.issues.length) {
      if (!u && i >= o) {
        t.value.length = i;
        break;
      }
      t.issues.push(...H(i, c.issues));
    }
    t.value[i] = c.value;
  }
  for (let i = t.value.length - 1; i >= n.length && (r[i]._zod.optout === "optional" && t.value[i] === void 0); i--)
    t.value.length = i;
  return t;
}
s(ei, "handleTupleResults");
var xn = /* @__PURE__ */ p("$ZodRecord", (e, t) => {
  x.init(e, t), e._zod.parse = (r, n) => {
    let o = r.value;
    if (!ue(o))
      return r.issues.push({
        expected: "record",
        code: "invalid_type",
        input: o,
        inst: e
      }), r;
    let i = [], c = t.keyType._zod.values;
    if (c) {
      r.value = {};
      let u = /* @__PURE__ */ new Set();
      for (let l of c)
        if (typeof l == "string" || typeof l == "number" || typeof l == "symbol") {
          u.add(typeof l == "number" ? l.toString() : l);
          let f = t.keyType._zod.run({ value: l, issues: [] }, n);
          if (f instanceof Promise)
            throw new Error("Async schemas not supported in object keys currently");
          if (f.issues.length) {
            r.issues.push({
              code: "invalid_key",
              origin: "record",
              issues: f.issues.map((m) => V(m, n, G())),
              input: l,
              path: [l],
              inst: e
            });
            continue;
          }
          let h = f.value, g = t.valueType._zod.run({ value: o[l], issues: [] }, n);
          g instanceof Promise ? i.push(g.then((m) => {
            m.issues.length && r.issues.push(...H(l, m.issues)), r.value[h] = m.value;
          })) : (g.issues.length && r.issues.push(...H(l, g.issues)), r.value[h] = g.value);
        }
      let a;
      for (let l in o)
        u.has(l) || (a = a ?? [], a.push(l));
      a && a.length > 0 && r.issues.push({
        code: "unrecognized_keys",
        input: o,
        inst: e,
        keys: a
      });
    } else {
      r.value = {};
      for (let u of Reflect.ownKeys(o)) {
        if (u === "__proto__" || !Object.prototype.propertyIsEnumerable.call(o, u))
          continue;
        let a = t.keyType._zod.run({ value: u, issues: [] }, n);
        if (a instanceof Promise)
          throw new Error("Async schemas not supported in object keys currently");
        if (typeof u == "string" && an.test(u) && a.issues.length) {
          let h = t.keyType._zod.run({ value: Number(u), issues: [] }, n);
          if (h instanceof Promise)
            throw new Error("Async schemas not supported in object keys currently");
          h.issues.length === 0 && (a = h);
        }
        if (a.issues.length) {
          t.mode === "loose" ? r.value[u] = o[u] : r.issues.push({
            code: "invalid_key",
            origin: "record",
            issues: a.issues.map((h) => V(h, n, G())),
            input: u,
            path: [u],
            inst: e
          });
          continue;
        }
        let f = t.valueType._zod.run({ value: o[u], issues: [] }, n);
        f instanceof Promise ? i.push(f.then((h) => {
          h.issues.length && r.issues.push(...H(u, h.issues)), r.value[a.value] = h.value;
        })) : (f.issues.length && r.issues.push(...H(u, f.issues)), r.value[a.value] = f.value);
      }
    }
    return i.length ? Promise.all(i).then(() => r) : r;
  };
}), bn = /* @__PURE__ */ p("$ZodMap", (e, t) => {
  x.init(e, t), e._zod.parse = (r, n) => {
    let o = r.value;
    if (!(o instanceof Map))
      return r.issues.push({
        expected: "map",
        code: "invalid_type",
        input: o,
        inst: e
      }), r;
    let i = [];
    r.value = /* @__PURE__ */ new Map();
    for (let [c, u] of o) {
      let a = t.keyType._zod.run({ value: c, issues: [] }, n), l = t.valueType._zod.run({ value: u, issues: [] }, n);
      a instanceof Promise || l instanceof Promise ? i.push(Promise.all([a, l]).then(([f, h]) => {
        ti(f, h, r, c, o, e, n);
      })) : ti(a, l, r, c, o, e, n);
    }
    return i.length ? Promise.all(i).then(() => r) : r;
  };
});
function ti(e, t, r, n, o, i, c) {
  e.issues.length && (Ge.has(typeof n) ? r.issues.push(...H(n, e.issues)) : r.issues.push({
    code: "invalid_key",
    origin: "map",
    input: o,
    inst: i,
    issues: e.issues.map((u) => V(u, c, G()))
  })), t.issues.length && (Ge.has(typeof n) ? r.issues.push(...H(n, t.issues)) : r.issues.push({
    origin: "map",
    code: "invalid_element",
    input: o,
    inst: i,
    key: n,
    issues: t.issues.map((u) => V(u, c, G()))
  })), r.value.set(e.value, t.value);
}
s(ti, "handleMapResult");
var wn = /* @__PURE__ */ p("$ZodSet", (e, t) => {
  x.init(e, t), e._zod.parse = (r, n) => {
    let o = r.value;
    if (!(o instanceof Set))
      return r.issues.push({
        input: o,
        inst: e,
        expected: "set",
        code: "invalid_type"
      }), r;
    let i = [];
    r.value = /* @__PURE__ */ new Set();
    for (let c of o) {
      let u = t.valueType._zod.run({ value: c, issues: [] }, n);
      u instanceof Promise ? i.push(u.then((a) => ri(a, r))) : ri(u, r);
    }
    return i.length ? Promise.all(i).then(() => r) : r;
  };
});
function ri(e, t) {
  e.issues.length && t.issues.push(...e.issues), t.value.add(e.value);
}
s(ri, "handleSetResult");
var Xt = /* @__PURE__ */ p("$ZodEnum", (e, t) => {
  x.init(e, t);
  let r = Je(t.entries), n = new Set(r);
  e._zod.values = n, e._zod.pattern = new RegExp(`^(${r.filter((o) => Ge.has(typeof o)).map((o) => typeof o == "string" ? oe(o) : o.toString()).join("|")})$`), e._zod.parse = (o, i) => {
    let c = o.value;
    return n.has(c) || o.issues.push({
      code: "invalid_value",
      values: r,
      input: c,
      inst: e
    }), o;
  };
}), zn = /* @__PURE__ */ p("$ZodLiteral", (e, t) => {
  if (x.init(e, t), t.values.length === 0)
    throw new Error("Cannot create literal schema with no valid values");
  let r = new Set(t.values);
  e._zod.values = r, e._zod.pattern = new RegExp(`^(${t.values.map((n) => typeof n == "string" ? oe(n) : n ? oe(n.toString()) : String(n)).join("|")})$`), e._zod.parse = (n, o) => {
    let i = n.value;
    return r.has(i) || n.issues.push({
      code: "invalid_value",
      values: t.values,
      input: i,
      inst: e
    }), n;
  };
}), vn = /* @__PURE__ */ p("$ZodFile", (e, t) => {
  x.init(e, t), e._zod.parse = (r, n) => {
    let o = r.value;
    return o instanceof File || r.issues.push({
      expected: "file",
      code: "invalid_type",
      input: o,
      inst: e
    }), r;
  };
}), er = /* @__PURE__ */ p("$ZodTransform", (e, t) => {
  x.init(e, t), e._zod.optin = "optional", e._zod.parse = (r, n) => {
    if (n.direction === "backward")
      throw new ke(e.constructor.name);
    let o = t.transform(r.value, r);
    if (n.async)
      return (o instanceof Promise ? o : Promise.resolve(o)).then((c) => (r.value = c, r.fallback = !0, r));
    if (o instanceof Promise)
      throw new ne();
    return r.value = o, r.fallback = !0, r;
  };
});
function ni(e, t) {
  return t === void 0 && (e.issues.length || e.fallback) ? { issues: [], value: void 0 } : e;
}
s(ni, "handleOptionalResult");
var nt = /* @__PURE__ */ p("$ZodOptional", (e, t) => {
  x.init(e, t), e._zod.optin = "optional", e._zod.optout = "optional", w(e._zod, "values", () => t.innerType._zod.values ? /* @__PURE__ */ new Set([...t.innerType._zod.values, void 0]) : void 0), w(e._zod, "pattern", () => {
    let r = t.innerType._zod.pattern;
    return r ? new RegExp(`^(${We(r.source)})?$`) : void 0;
  }), e._zod.parse = (r, n) => {
    if (t.innerType._zod.optin === "optional") {
      let o = r.value, i = t.innerType._zod.run(r, n);
      return i instanceof Promise ? i.then((c) => ni(c, o)) : ni(i, o);
    }
    return r.value === void 0 ? r : t.innerType._zod.run(r, n);
  };
}), ji = /* @__PURE__ */ p("$ZodExactOptional", (e, t) => {
  nt.init(e, t), w(e._zod, "values", () => t.innerType._zod.values), w(e._zod, "pattern", () => t.innerType._zod.pattern), e._zod.parse = (r, n) => t.innerType._zod.run(r, n);
}), tr = /* @__PURE__ */ p("$ZodNullable", (e, t) => {
  x.init(e, t), w(e._zod, "optin", () => t.innerType._zod.optin), w(e._zod, "optout", () => t.innerType._zod.optout), w(e._zod, "pattern", () => {
    let r = t.innerType._zod.pattern;
    return r ? new RegExp(`^(${We(r.source)}|null)$`) : void 0;
  }), w(e._zod, "values", () => t.innerType._zod.values ? /* @__PURE__ */ new Set([...t.innerType._zod.values, null]) : void 0), e._zod.parse = (r, n) => r.value === null ? r : t.innerType._zod.run(r, n);
}), ot = /* @__PURE__ */ p("$ZodDefault", (e, t) => {
  x.init(e, t), e._zod.optin = "optional", w(e._zod, "values", () => t.innerType._zod.values), e._zod.parse = (r, n) => {
    if (n.direction === "backward")
      return t.innerType._zod.run(r, n);
    if (r.value === void 0)
      return r.value = t.defaultValue, r;
    let o = t.innerType._zod.run(r, n);
    return o instanceof Promise ? o.then((i) => oi(i, t)) : oi(o, t);
  };
});
function oi(e, t) {
  return e.value === void 0 && (e.value = t.defaultValue), e;
}
s(oi, "handleDefaultResult");
var Ri = /* @__PURE__ */ p("$ZodPrefault", (e, t) => {
  x.init(e, t), e._zod.optin = "optional", w(e._zod, "values", () => t.innerType._zod.values), e._zod.parse = (r, n) => (n.direction === "backward" || r.value === void 0 && (r.value = t.defaultValue), t.innerType._zod.run(r, n));
}), rr = /* @__PURE__ */ p("$ZodNonOptional", (e, t) => {
  x.init(e, t), w(e._zod, "values", () => {
    let r = t.innerType._zod.values;
    return r ? new Set([...r].filter((n) => n !== void 0)) : void 0;
  }), e._zod.parse = (r, n) => {
    let o = t.innerType._zod.run(r, n);
    return o instanceof Promise ? o.then((i) => si(i, e)) : si(o, e);
  };
});
function si(e, t) {
  return !e.issues.length && e.value === void 0 && e.issues.push({
    code: "invalid_type",
    expected: "nonoptional",
    input: e.value,
    inst: t
  }), e;
}
s(si, "handleNonOptionalResult");
var nr = /* @__PURE__ */ p("$ZodCatch", (e, t) => {
  x.init(e, t), e._zod.optin = "optional", w(e._zod, "optout", () => t.innerType._zod.optout), w(e._zod, "values", () => t.innerType._zod.values), e._zod.parse = (r, n) => {
    if (n.direction === "backward")
      return t.innerType._zod.run(r, n);
    let o = t.innerType._zod.run(r, n);
    return o instanceof Promise ? o.then((i) => (r.value = i.value, i.issues.length && (r.value = t.catchValue({
      ...r,
      error: {
        issues: i.issues.map((c) => V(c, n, G()))
      },
      input: r.value
    }), r.issues = [], r.fallback = !0), r)) : (r.value = o.value, o.issues.length && (r.value = t.catchValue({
      ...r,
      error: {
        issues: o.issues.map((i) => V(i, n, G()))
      },
      input: r.value
    }), r.issues = [], r.fallback = !0), r);
  };
}), $n = /* @__PURE__ */ p("$ZodNaN", (e, t) => {
  x.init(e, t), e._zod.parse = (r, n) => ((typeof r.value != "number" || !Number.isNaN(r.value)) && r.issues.push({
    input: r.value,
    inst: e,
    expected: "nan",
    code: "invalid_type"
  }), r);
}), st = /* @__PURE__ */ p("$ZodPipe", (e, t) => {
  x.init(e, t), w(e._zod, "values", () => t.in._zod.values), w(e._zod, "optin", () => t.in._zod.optin), w(e._zod, "optout", () => t.out._zod.optout), w(e._zod, "propValues", () => t.in._zod.propValues), e._zod.parse = (r, n) => {
    if (n.direction === "backward") {
      let i = t.out._zod.run(r, n);
      return i instanceof Promise ? i.then((c) => Mt(c, t.in, n)) : Mt(i, t.in, n);
    }
    let o = t.in._zod.run(r, n);
    return o instanceof Promise ? o.then((i) => Mt(i, t.out, n)) : Mt(o, t.out, n);
  };
});
function Mt(e, t, r) {
  return e.issues.length ? (e.aborted = !0, e) : t._zod.run({ value: e.value, issues: e.issues, fallback: e.fallback }, r);
}
s(Mt, "handlePipeResult");
var Fi = /* @__PURE__ */ p("$ZodCodec", (e, t) => {
  x.init(e, t), w(e._zod, "values", () => t.in._zod.values), w(e._zod, "optin", () => t.in._zod.optin), w(e._zod, "optout", () => t.out._zod.optout), w(e._zod, "propValues", () => t.in._zod.propValues), e._zod.parse = (r, n) => {
    if ((n.direction || "forward") === "forward") {
      let i = t.in._zod.run(r, n);
      return i instanceof Promise ? i.then((c) => Dt(c, t, n)) : Dt(i, t, n);
    } else {
      let i = t.out._zod.run(r, n);
      return i instanceof Promise ? i.then((c) => Dt(c, t, n)) : Dt(i, t, n);
    }
  };
});
function Dt(e, t, r) {
  if (e.issues.length)
    return e.aborted = !0, e;
  if ((r.direction || "forward") === "forward") {
    let o = t.transform(e.value, e);
    return o instanceof Promise ? o.then((i) => Ut(e, i, t.out, r)) : Ut(e, o, t.out, r);
  } else {
    let o = t.reverseTransform(e.value, e);
    return o instanceof Promise ? o.then((i) => Ut(e, i, t.in, r)) : Ut(e, o, t.in, r);
  }
}
s(Dt, "handleCodecAResult");
function Ut(e, t, r, n) {
  return e.issues.length ? (e.aborted = !0, e) : r._zod.run({ value: t, issues: e.issues }, n);
}
s(Ut, "handleCodecTxResult");
var or = /* @__PURE__ */ p("$ZodReadonly", (e, t) => {
  x.init(e, t), w(e._zod, "propValues", () => t.innerType._zod.propValues), w(e._zod, "values", () => t.innerType._zod.values), w(e._zod, "optin", () => t.innerType?._zod?.optin), w(e._zod, "optout", () => t.innerType?._zod?.optout), e._zod.parse = (r, n) => {
    if (n.direction === "backward")
      return t.innerType._zod.run(r, n);
    let o = t.innerType._zod.run(r, n);
    return o instanceof Promise ? o.then(ii) : ii(o);
  };
});
function ii(e) {
  return e.value = Object.freeze(e.value), e;
}
s(ii, "handleReadonlyResult");
var kn = /* @__PURE__ */ p("$ZodTemplateLiteral", (e, t) => {
  x.init(e, t);
  let r = [];
  for (let n of t.parts)
    if (typeof n == "object" && n !== null) {
      if (!n._zod.pattern)
        throw new Error(`Invalid template literal part, no pattern found: ${[...n._zod.traits].shift()}`);
      let o = n._zod.pattern instanceof RegExp ? n._zod.pattern.source : n._zod.pattern;
      if (!o)
        throw new Error(`Invalid template literal part: ${n._zod.traits}`);
      let i = o.startsWith("^") ? 1 : 0, c = o.endsWith("$") ? o.length - 1 : o.length;
      r.push(o.slice(i, c));
    } else if (n === null || en.has(typeof n))
      r.push(oe(`${n}`));
    else
      throw new Error(`Invalid template literal part: ${n}`);
  e._zod.pattern = new RegExp(`^${r.join("")}$`), e._zod.parse = (n, o) => typeof n.value != "string" ? (n.issues.push({
    input: n.value,
    inst: e,
    expected: "string",
    code: "invalid_type"
  }), n) : (e._zod.pattern.lastIndex = 0, e._zod.pattern.test(n.value) || n.issues.push({
    input: n.value,
    inst: e,
    code: "invalid_format",
    format: t.format ?? "template_literal",
    pattern: e._zod.pattern.source
  }), n);
}), Sn = /* @__PURE__ */ p("$ZodFunction", (e, t) => (x.init(e, t), e._def = t, e._zod.def = t, e.implement = (r) => {
  if (typeof r != "function")
    throw new Error("implement() must be called with a function");
  return function(...n) {
    let o = e._def.input ? on(e._def.input, n) : n, i = Reflect.apply(r, this, o);
    return e._def.output ? on(e._def.output, i) : i;
  };
}, e.implementAsync = (r) => {
  if (typeof r != "function")
    throw new Error("implementAsync() must be called with a function");
  return async function(...n) {
    let o = e._def.input ? await sn(e._def.input, n) : n, i = await Reflect.apply(r, this, o);
    return e._def.output ? await sn(e._def.output, i) : i;
  };
}, e._zod.parse = (r, n) => typeof r.value != "function" ? (r.issues.push({
  code: "invalid_type",
  expected: "function",
  input: r.value,
  inst: e
}), r) : (e._def.output && e._def.output._zod.def.type === "promise" ? r.value = e.implementAsync(r.value) : r.value = e.implement(r.value), r), e.input = (...r) => {
  let n = e.constructor;
  return Array.isArray(r[0]) ? new n({
    type: "function",
    input: new Yt({
      type: "tuple",
      items: r[0],
      rest: r[1]
    }),
    output: e._def.output
  }) : new n({
    type: "function",
    input: r[0],
    output: e._def.output
  });
}, e.output = (r) => {
  let n = e.constructor;
  return new n({
    type: "function",
    input: e._def.input,
    output: r
  });
}, e)), Zn = /* @__PURE__ */ p("$ZodPromise", (e, t) => {
  x.init(e, t), e._zod.parse = (r, n) => Promise.resolve(r.value).then((o) => t.innerType._zod.run({ value: o, issues: [] }, n));
}), Pn = /* @__PURE__ */ p("$ZodLazy", (e, t) => {
  x.init(e, t), w(e._zod, "innerType", () => {
    let r = t;
    return r._cachedInner || (r._cachedInner = t.getter()), r._cachedInner;
  }), w(e._zod, "pattern", () => e._zod.innerType?._zod?.pattern), w(e._zod, "propValues", () => e._zod.innerType?._zod?.propValues), w(e._zod, "optin", () => e._zod.innerType?._zod?.optin ?? void 0), w(e._zod, "optout", () => e._zod.innerType?._zod?.optout ?? void 0), e._zod.parse = (r, n) => e._zod.innerType._zod.run(r, n);
}), sr = /* @__PURE__ */ p("$ZodCustom", (e, t) => {
  U.init(e, t), x.init(e, t), e._zod.parse = (r, n) => r, e._zod.check = (r) => {
    let n = r.value, o = t.fn(n);
    if (o instanceof Promise)
      return o.then((i) => ci(i, r, n, e));
    ci(o, r, n, e);
  };
});
function ci(e, t, r, n) {
  if (!e) {
    let o = {
      code: "custom",
      input: r,
      inst: n,
      // incorporates params.error into issue reporting
      path: [...n._zod.def.path ?? []],
      // incorporates params.error into issue reporting
      continue: !n._zod.def.abort
      // params: inst._zod.def.params,
    };
    n._zod.def.params && (o.params = n._zod.def.params), t.issues.push(Oe(o));
  }
}
s(ci, "handleRefineResult");

// versions/4.4.3/node_modules/zod/v4/core/registries.js
var Li, sh = Symbol("ZodOutput"), ih = Symbol("ZodInput"), On = class {
  static {
    s(this, "$ZodRegistry");
  }
  constructor() {
    this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map();
  }
  add(t, ...r) {
    let n = r[0];
    return this._map.set(t, n), n && typeof n == "object" && "id" in n && this._idmap.set(n.id, t), this;
  }
  clear() {
    return this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map(), this;
  }
  remove(t) {
    let r = this._map.get(t);
    return r && typeof r == "object" && "id" in r && this._idmap.delete(r.id), this._map.delete(t), this;
  }
  get(t) {
    let r = t._zod.parent;
    if (r) {
      let n = { ...this.get(r) ?? {} };
      delete n.id;
      let o = { ...n, ...this._map.get(t) };
      return Object.keys(o).length ? o : void 0;
    }
    return this._map.get(t);
  }
  has(t) {
    return this._map.has(t);
  }
};
function En() {
  return new On();
}
s(En, "registry");
(Li = globalThis).__zod_globalRegistry ?? (Li.__zod_globalRegistry = En());
var he = globalThis.__zod_globalRegistry;

// versions/4.4.3/node_modules/zod/v4/core/api.js
// @__NO_SIDE_EFFECTS__
function Mi(e, t) {
  return new e({
    type: "string",
    ...y(t)
  });
}
s(Mi, "_string");
// @__NO_SIDE_EFFECTS__
function Di(e, t) {
  return new e({
    type: "string",
    format: "email",
    check: "string_format",
    abort: !1,
    ...y(t)
  });
}
s(Di, "_email");
// @__NO_SIDE_EFFECTS__
function Tn(e, t) {
  return new e({
    type: "string",
    format: "guid",
    check: "string_format",
    abort: !1,
    ...y(t)
  });
}
s(Tn, "_guid");
// @__NO_SIDE_EFFECTS__
function Ui(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    ...y(t)
  });
}
s(Ui, "_uuid");
// @__NO_SIDE_EFFECTS__
function Bi(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v4",
    ...y(t)
  });
}
s(Bi, "_uuidv4");
// @__NO_SIDE_EFFECTS__
function Ji(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v6",
    ...y(t)
  });
}
s(Ji, "_uuidv6");
// @__NO_SIDE_EFFECTS__
function Vi(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v7",
    ...y(t)
  });
}
s(Vi, "_uuidv7");
// @__NO_SIDE_EFFECTS__
function qi(e, t) {
  return new e({
    type: "string",
    format: "url",
    check: "string_format",
    abort: !1,
    ...y(t)
  });
}
s(qi, "_url");
// @__NO_SIDE_EFFECTS__
function Wi(e, t) {
  return new e({
    type: "string",
    format: "emoji",
    check: "string_format",
    abort: !1,
    ...y(t)
  });
}
s(Wi, "_emoji");
// @__NO_SIDE_EFFECTS__
function Gi(e, t) {
  return new e({
    type: "string",
    format: "nanoid",
    check: "string_format",
    abort: !1,
    ...y(t)
  });
}
s(Gi, "_nanoid");
// @__NO_SIDE_EFFECTS__
function Hi(e, t) {
  return new e({
    type: "string",
    format: "cuid",
    check: "string_format",
    abort: !1,
    ...y(t)
  });
}
s(Hi, "_cuid");
// @__NO_SIDE_EFFECTS__
function Qi(e, t) {
  return new e({
    type: "string",
    format: "cuid2",
    check: "string_format",
    abort: !1,
    ...y(t)
  });
}
s(Qi, "_cuid2");
// @__NO_SIDE_EFFECTS__
function Ki(e, t) {
  return new e({
    type: "string",
    format: "ulid",
    check: "string_format",
    abort: !1,
    ...y(t)
  });
}
s(Ki, "_ulid");
// @__NO_SIDE_EFFECTS__
function Yi(e, t) {
  return new e({
    type: "string",
    format: "xid",
    check: "string_format",
    abort: !1,
    ...y(t)
  });
}
s(Yi, "_xid");
// @__NO_SIDE_EFFECTS__
function Xi(e, t) {
  return new e({
    type: "string",
    format: "ksuid",
    check: "string_format",
    abort: !1,
    ...y(t)
  });
}
s(Xi, "_ksuid");
// @__NO_SIDE_EFFECTS__
function ec(e, t) {
  return new e({
    type: "string",
    format: "ipv4",
    check: "string_format",
    abort: !1,
    ...y(t)
  });
}
s(ec, "_ipv4");
// @__NO_SIDE_EFFECTS__
function tc(e, t) {
  return new e({
    type: "string",
    format: "ipv6",
    check: "string_format",
    abort: !1,
    ...y(t)
  });
}
s(tc, "_ipv6");
// @__NO_SIDE_EFFECTS__
function rc(e, t) {
  return new e({
    type: "string",
    format: "cidrv4",
    check: "string_format",
    abort: !1,
    ...y(t)
  });
}
s(rc, "_cidrv4");
// @__NO_SIDE_EFFECTS__
function nc(e, t) {
  return new e({
    type: "string",
    format: "cidrv6",
    check: "string_format",
    abort: !1,
    ...y(t)
  });
}
s(nc, "_cidrv6");
// @__NO_SIDE_EFFECTS__
function oc(e, t) {
  return new e({
    type: "string",
    format: "base64",
    check: "string_format",
    abort: !1,
    ...y(t)
  });
}
s(oc, "_base64");
// @__NO_SIDE_EFFECTS__
function sc(e, t) {
  return new e({
    type: "string",
    format: "base64url",
    check: "string_format",
    abort: !1,
    ...y(t)
  });
}
s(sc, "_base64url");
// @__NO_SIDE_EFFECTS__
function ic(e, t) {
  return new e({
    type: "string",
    format: "e164",
    check: "string_format",
    abort: !1,
    ...y(t)
  });
}
s(ic, "_e164");
// @__NO_SIDE_EFFECTS__
function cc(e, t) {
  return new e({
    type: "string",
    format: "jwt",
    check: "string_format",
    abort: !1,
    ...y(t)
  });
}
s(cc, "_jwt");
// @__NO_SIDE_EFFECTS__
function uc(e, t) {
  return new e({
    type: "string",
    format: "datetime",
    check: "string_format",
    offset: !1,
    local: !1,
    precision: null,
    ...y(t)
  });
}
s(uc, "_isoDateTime");
// @__NO_SIDE_EFFECTS__
function ac(e, t) {
  return new e({
    type: "string",
    format: "date",
    check: "string_format",
    ...y(t)
  });
}
s(ac, "_isoDate");
// @__NO_SIDE_EFFECTS__
function lc(e, t) {
  return new e({
    type: "string",
    format: "time",
    check: "string_format",
    precision: null,
    ...y(t)
  });
}
s(lc, "_isoTime");
// @__NO_SIDE_EFFECTS__
function pc(e, t) {
  return new e({
    type: "string",
    format: "duration",
    check: "string_format",
    ...y(t)
  });
}
s(pc, "_isoDuration");
// @__NO_SIDE_EFFECTS__
function fc(e, t) {
  return new e({
    type: "number",
    checks: [],
    ...y(t)
  });
}
s(fc, "_number");
// @__NO_SIDE_EFFECTS__
function dc(e, t) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "safeint",
    ...y(t)
  });
}
s(dc, "_int");
// @__NO_SIDE_EFFECTS__
function mc(e, t) {
  return new e({
    type: "boolean",
    ...y(t)
  });
}
s(mc, "_boolean");
// @__NO_SIDE_EFFECTS__
function hc(e) {
  return new e({
    type: "unknown"
  });
}
s(hc, "_unknown");
// @__NO_SIDE_EFFECTS__
function gc(e, t) {
  return new e({
    type: "never",
    ...y(t)
  });
}
s(gc, "_never");
// @__NO_SIDE_EFFECTS__
function yc(e, t) {
  return new e({
    type: "date",
    ...y(t)
  });
}
s(yc, "_date");
// @__NO_SIDE_EFFECTS__
function ir(e, t) {
  return new ln({
    check: "less_than",
    ...y(t),
    value: e,
    inclusive: !1
  });
}
s(ir, "_lt");
// @__NO_SIDE_EFFECTS__
function Te(e, t) {
  return new ln({
    check: "less_than",
    ...y(t),
    value: e,
    inclusive: !0
  });
}
s(Te, "_lte");
// @__NO_SIDE_EFFECTS__
function cr(e, t) {
  return new pn({
    check: "greater_than",
    ...y(t),
    value: e,
    inclusive: !1
  });
}
s(cr, "_gt");
// @__NO_SIDE_EFFECTS__
function Ie(e, t) {
  return new pn({
    check: "greater_than",
    ...y(t),
    value: e,
    inclusive: !0
  });
}
s(Ie, "_gte");
// @__NO_SIDE_EFFECTS__
function ur(e, t) {
  return new Cs({
    check: "multiple_of",
    ...y(t),
    value: e
  });
}
s(ur, "_multipleOf");
// @__NO_SIDE_EFFECTS__
function ar(e, t) {
  return new Rs({
    check: "max_length",
    ...y(t),
    maximum: e
  });
}
s(ar, "_maxLength");
// @__NO_SIDE_EFFECTS__
function Ae(e, t) {
  return new Fs({
    check: "min_length",
    ...y(t),
    minimum: e
  });
}
s(Ae, "_minLength");
// @__NO_SIDE_EFFECTS__
function lr(e, t) {
  return new Ls({
    check: "length_equals",
    ...y(t),
    length: e
  });
}
s(lr, "_length");
// @__NO_SIDE_EFFECTS__
function In(e, t) {
  return new Ms({
    check: "string_format",
    format: "regex",
    ...y(t),
    pattern: e
  });
}
s(In, "_regex");
// @__NO_SIDE_EFFECTS__
function An(e) {
  return new Ds({
    check: "string_format",
    format: "lowercase",
    ...y(e)
  });
}
s(An, "_lowercase");
// @__NO_SIDE_EFFECTS__
function Nn(e) {
  return new Us({
    check: "string_format",
    format: "uppercase",
    ...y(e)
  });
}
s(Nn, "_uppercase");
// @__NO_SIDE_EFFECTS__
function Cn(e, t) {
  return new Bs({
    check: "string_format",
    format: "includes",
    ...y(t),
    includes: e
  });
}
s(Cn, "_includes");
// @__NO_SIDE_EFFECTS__
function jn(e, t) {
  return new Js({
    check: "string_format",
    format: "starts_with",
    ...y(t),
    prefix: e
  });
}
s(jn, "_startsWith");
// @__NO_SIDE_EFFECTS__
function Rn(e, t) {
  return new Vs({
    check: "string_format",
    format: "ends_with",
    ...y(t),
    suffix: e
  });
}
s(Rn, "_endsWith");
// @__NO_SIDE_EFFECTS__
function le(e) {
  return new qs({
    check: "overwrite",
    tx: e
  });
}
s(le, "_overwrite");
// @__NO_SIDE_EFFECTS__
function Fn(e) {
  return /* @__PURE__ */ le((t) => t.normalize(e));
}
s(Fn, "_normalize");
// @__NO_SIDE_EFFECTS__
function Ln() {
  return /* @__PURE__ */ le((e) => e.trim());
}
s(Ln, "_trim");
// @__NO_SIDE_EFFECTS__
function Mn() {
  return /* @__PURE__ */ le((e) => e.toLowerCase());
}
s(Mn, "_toLowerCase");
// @__NO_SIDE_EFFECTS__
function Dn() {
  return /* @__PURE__ */ le((e) => e.toUpperCase());
}
s(Dn, "_toUpperCase");
// @__NO_SIDE_EFFECTS__
function Un() {
  return /* @__PURE__ */ le((e) => Yr(e));
}
s(Un, "_slugify");
// @__NO_SIDE_EFFECTS__
function _c(e, t, r) {
  return new e({
    type: "array",
    element: t,
    // get element() {
    //   return element;
    // },
    ...y(r)
  });
}
s(_c, "_array");
// @__NO_SIDE_EFFECTS__
function xc(e, t, r) {
  return new e({
    type: "custom",
    check: "custom",
    fn: t,
    ...y(r)
  });
}
s(xc, "_refine");
// @__NO_SIDE_EFFECTS__
function bc(e, t) {
  let r = /* @__PURE__ */ Ka((n) => (n.addIssue = (o) => {
    if (typeof o == "string")
      n.issues.push(Oe(o, n.value, r._zod.def));
    else {
      let i = o;
      i.fatal && (i.continue = !1), i.code ?? (i.code = "custom"), i.input ?? (i.input = n.value), i.inst ?? (i.inst = r), i.continue ?? (i.continue = !r._zod.def.abort), n.issues.push(Oe(i));
    }
  }, e(n.value, n)), t);
  return r;
}
s(bc, "_superRefine");
// @__NO_SIDE_EFFECTS__
function Ka(e, t) {
  let r = new U({
    check: "custom",
    ...y(t)
  });
  return r._zod.check = e, r;
}
s(Ka, "_check");

// versions/4.4.3/node_modules/zod/v4/core/to-json-schema.js
function Bn(e) {
  let t = e?.target ?? "draft-2020-12";
  return t === "draft-4" && (t = "draft-04"), t === "draft-7" && (t = "draft-07"), {
    processors: e.processors ?? {},
    metadataRegistry: e?.metadata ?? he,
    target: t,
    unrepresentable: e?.unrepresentable ?? "throw",
    override: e?.override ?? (() => {
    }),
    io: e?.io ?? "output",
    counter: 0,
    seen: /* @__PURE__ */ new Map(),
    cycles: e?.cycles ?? "ref",
    reused: e?.reused ?? "inline",
    external: e?.external ?? void 0
  };
}
s(Bn, "initializeContext");
function D(e, t, r = { path: [], schemaPath: [] }) {
  var n;
  let o = e._zod.def, i = t.seen.get(e);
  if (i)
    return i.count++, r.schemaPath.includes(e) && (i.cycle = r.path), i.schema;
  let c = { schema: {}, count: 1, cycle: void 0, path: r.path };
  t.seen.set(e, c);
  let u = e._zod.toJSONSchema?.();
  if (u)
    c.schema = u;
  else {
    let f = {
      ...r,
      schemaPath: [...r.schemaPath, e],
      path: r.path
    };
    if (e._zod.processJSONSchema)
      e._zod.processJSONSchema(t, c.schema, f);
    else {
      let g = c.schema, m = t.processors[o.type];
      if (!m)
        throw new Error(`[toJSONSchema]: Non-representable type encountered: ${o.type}`);
      m(e, t, g, f);
    }
    let h = e._zod.parent;
    h && (c.ref || (c.ref = h), D(h, t, f), t.seen.get(h).isParent = !0);
  }
  let a = t.metadataRegistry.get(e);
  return a && Object.assign(c.schema, a), t.io === "input" && J(e) && (delete c.schema.examples, delete c.schema.default), t.io === "input" && "_prefault" in c.schema && ((n = c.schema).default ?? (n.default = c.schema._prefault)), delete c.schema._prefault, t.seen.get(e).schema;
}
s(D, "process");
function Jn(e, t) {
  let r = e.seen.get(t);
  if (!r)
    throw new Error("Unprocessed schema. This is a bug in Zod.");
  let n = /* @__PURE__ */ new Map();
  for (let c of e.seen.entries()) {
    let u = e.metadataRegistry.get(c[0])?.id;
    if (u) {
      let a = n.get(u);
      if (a && a !== c[0])
        throw new Error(`Duplicate schema id "${u}" detected during JSON Schema conversion. Two different schemas cannot share the same id when converted together.`);
      n.set(u, c[0]);
    }
  }
  let o = /* @__PURE__ */ s((c) => {
    let u = e.target === "draft-2020-12" ? "$defs" : "definitions";
    if (e.external) {
      let h = e.external.registry.get(c[0])?.id, g = e.external.uri ?? ((b) => b);
      if (h)
        return { ref: g(h) };
      let m = c[1].defId ?? c[1].schema.id ?? `schema${e.counter++}`;
      return c[1].defId = m, { defId: m, ref: `${g("__shared")}#/${u}/${m}` };
    }
    if (c[1] === r)
      return { ref: "#" };
    let l = `#/${u}/`, f = c[1].schema.id ?? `__schema${e.counter++}`;
    return { defId: f, ref: l + f };
  }, "makeURI"), i = /* @__PURE__ */ s((c) => {
    if (c[1].schema.$ref)
      return;
    let u = c[1], { ref: a, defId: l } = o(c);
    u.def = { ...u.schema }, l && (u.defId = l);
    let f = u.schema;
    for (let h in f)
      delete f[h];
    f.$ref = a;
  }, "extractToDef");
  if (e.cycles === "throw")
    for (let c of e.seen.entries()) {
      let u = c[1];
      if (u.cycle)
        throw new Error(`Cycle detected: #/${u.cycle?.join("/")}/<root>

Set the \`cycles\` parameter to \`"ref"\` to resolve cyclical schemas with defs.`);
    }
  for (let c of e.seen.entries()) {
    let u = c[1];
    if (t === c[0]) {
      i(c);
      continue;
    }
    if (e.external) {
      let l = e.external.registry.get(c[0])?.id;
      if (t !== c[0] && l) {
        i(c);
        continue;
      }
    }
    if (e.metadataRegistry.get(c[0])?.id) {
      i(c);
      continue;
    }
    if (u.cycle) {
      i(c);
      continue;
    }
    if (u.count > 1 && e.reused === "ref") {
      i(c);
      continue;
    }
  }
}
s(Jn, "extractDefs");
function Vn(e, t) {
  let r = e.seen.get(t);
  if (!r)
    throw new Error("Unprocessed schema. This is a bug in Zod.");
  let n = /* @__PURE__ */ s((u) => {
    let a = e.seen.get(u);
    if (a.ref === null)
      return;
    let l = a.def ?? a.schema, f = { ...l }, h = a.ref;
    if (a.ref = null, h) {
      n(h);
      let m = e.seen.get(h), b = m.schema;
      if (b.$ref && (e.target === "draft-07" || e.target === "draft-04" || e.target === "openapi-3.0") ? (l.allOf = l.allOf ?? [], l.allOf.push(b)) : Object.assign(l, b), Object.assign(l, f), u._zod.parent === h)
        for (let v in l)
          v === "$ref" || v === "allOf" || v in f || delete l[v];
      if (b.$ref && m.def)
        for (let v in l)
          v === "$ref" || v === "allOf" || v in m.def && JSON.stringify(l[v]) === JSON.stringify(m.def[v]) && delete l[v];
    }
    let g = u._zod.parent;
    if (g && g !== h) {
      n(g);
      let m = e.seen.get(g);
      if (m?.schema.$ref && (l.$ref = m.schema.$ref, m.def))
        for (let b in l)
          b === "$ref" || b === "allOf" || b in m.def && JSON.stringify(l[b]) === JSON.stringify(m.def[b]) && delete l[b];
    }
    e.override({
      zodSchema: u,
      jsonSchema: l,
      path: a.path ?? []
    });
  }, "flattenRef");
  for (let u of [...e.seen.entries()].reverse())
    n(u[0]);
  let o = {};
  if (e.target === "draft-2020-12" ? o.$schema = "https://json-schema.org/draft/2020-12/schema" : e.target === "draft-07" ? o.$schema = "http://json-schema.org/draft-07/schema#" : e.target === "draft-04" ? o.$schema = "http://json-schema.org/draft-04/schema#" : e.target, e.external?.uri) {
    let u = e.external.registry.get(t)?.id;
    if (!u)
      throw new Error("Schema is missing an `id` property");
    o.$id = e.external.uri(u);
  }
  Object.assign(o, r.def ?? r.schema);
  let i = e.metadataRegistry.get(t)?.id;
  i !== void 0 && o.id === i && delete o.id;
  let c = e.external?.defs ?? {};
  for (let u of e.seen.entries()) {
    let a = u[1];
    a.def && a.defId && (a.def.id === a.defId && delete a.def.id, c[a.defId] = a.def);
  }
  e.external || Object.keys(c).length > 0 && (e.target === "draft-2020-12" ? o.$defs = c : o.definitions = c);
  try {
    let u = JSON.parse(JSON.stringify(o));
    return Object.defineProperty(u, "~standard", {
      value: {
        ...t["~standard"],
        jsonSchema: {
          input: it(t, "input", e.processors),
          output: it(t, "output", e.processors)
        }
      },
      enumerable: !1,
      writable: !1
    }), u;
  } catch {
    throw new Error("Error converting schema to JSON.");
  }
}
s(Vn, "finalize");
function J(e, t) {
  let r = t ?? { seen: /* @__PURE__ */ new Set() };
  if (r.seen.has(e))
    return !1;
  r.seen.add(e);
  let n = e._zod.def;
  if (n.type === "transform")
    return !0;
  if (n.type === "array")
    return J(n.element, r);
  if (n.type === "set")
    return J(n.valueType, r);
  if (n.type === "lazy")
    return J(n.getter(), r);
  if (n.type === "promise" || n.type === "optional" || n.type === "nonoptional" || n.type === "nullable" || n.type === "readonly" || n.type === "default" || n.type === "prefault")
    return J(n.innerType, r);
  if (n.type === "intersection")
    return J(n.left, r) || J(n.right, r);
  if (n.type === "record" || n.type === "map")
    return J(n.keyType, r) || J(n.valueType, r);
  if (n.type === "pipe")
    return e._zod.traits.has("$ZodCodec") ? !0 : J(n.in, r) || J(n.out, r);
  if (n.type === "object") {
    for (let o in n.shape)
      if (J(n.shape[o], r))
        return !0;
    return !1;
  }
  if (n.type === "union") {
    for (let o of n.options)
      if (J(o, r))
        return !0;
    return !1;
  }
  if (n.type === "tuple") {
    for (let o of n.items)
      if (J(o, r))
        return !0;
    return !!(n.rest && J(n.rest, r));
  }
  return !1;
}
s(J, "isTransforming");
var wc = /* @__PURE__ */ s((e, t = {}) => (r) => {
  let n = Bn({ ...r, processors: t });
  return D(e, n), Jn(n, e), Vn(n, e);
}, "createToJSONSchemaMethod"), it = /* @__PURE__ */ s((e, t, r = {}) => (n) => {
  let { libraryOptions: o, target: i } = n ?? {}, c = Bn({ ...o ?? {}, target: i, io: t, processors: r });
  return D(e, c), Jn(c, e), Vn(c, e);
}, "createStandardJSONSchemaMethod");

// versions/4.4.3/node_modules/zod/v4/core/json-schema-processors.js
var Ya = {
  guid: "uuid",
  url: "uri",
  datetime: "date-time",
  json_string: "json-string",
  regex: ""
  // do not set
}, zc = /* @__PURE__ */ s((e, t, r, n) => {
  let o = r;
  o.type = "string";
  let { minimum: i, maximum: c, format: u, patterns: a, contentEncoding: l } = e._zod.bag;
  if (typeof i == "number" && (o.minLength = i), typeof c == "number" && (o.maxLength = c), u && (o.format = Ya[u] ?? u, o.format === "" && delete o.format, u === "time" && delete o.format), l && (o.contentEncoding = l), a && a.size > 0) {
    let f = [...a];
    f.length === 1 ? o.pattern = f[0].source : f.length > 1 && (o.allOf = [
      ...f.map((h) => ({
        ...t.target === "draft-07" || t.target === "draft-04" || t.target === "openapi-3.0" ? { type: "string" } : {},
        pattern: h.source
      }))
    ]);
  }
}, "stringProcessor"), vc = /* @__PURE__ */ s((e, t, r, n) => {
  let o = r, { minimum: i, maximum: c, format: u, multipleOf: a, exclusiveMaximum: l, exclusiveMinimum: f } = e._zod.bag;
  typeof u == "string" && u.includes("int") ? o.type = "integer" : o.type = "number";
  let h = typeof f == "number" && f >= (i ?? Number.NEGATIVE_INFINITY), g = typeof l == "number" && l <= (c ?? Number.POSITIVE_INFINITY), m = t.target === "draft-04" || t.target === "openapi-3.0";
  h ? m ? (o.minimum = f, o.exclusiveMinimum = !0) : o.exclusiveMinimum = f : typeof i == "number" && (o.minimum = i), g ? m ? (o.maximum = l, o.exclusiveMaximum = !0) : o.exclusiveMaximum = l : typeof c == "number" && (o.maximum = c), typeof a == "number" && (o.multipleOf = a);
}, "numberProcessor"), $c = /* @__PURE__ */ s((e, t, r, n) => {
  r.type = "boolean";
}, "booleanProcessor");
var kc = /* @__PURE__ */ s((e, t, r, n) => {
  r.not = {};
}, "neverProcessor");
var Sc = /* @__PURE__ */ s((e, t, r, n) => {
}, "unknownProcessor"), Zc = /* @__PURE__ */ s((e, t, r, n) => {
  if (t.unrepresentable === "throw")
    throw new Error("Date cannot be represented in JSON Schema");
}, "dateProcessor"), Pc = /* @__PURE__ */ s((e, t, r, n) => {
  let o = e._zod.def, i = Je(o.entries);
  i.every((c) => typeof c == "number") && (r.type = "number"), i.every((c) => typeof c == "string") && (r.type = "string"), r.enum = i;
}, "enumProcessor");
var Oc = /* @__PURE__ */ s((e, t, r, n) => {
  if (t.unrepresentable === "throw")
    throw new Error("Custom types cannot be represented in JSON Schema");
}, "customProcessor");
var Ec = /* @__PURE__ */ s((e, t, r, n) => {
  if (t.unrepresentable === "throw")
    throw new Error("Transforms cannot be represented in JSON Schema");
}, "transformProcessor");
var Tc = /* @__PURE__ */ s((e, t, r, n) => {
  let o = r, i = e._zod.def, { minimum: c, maximum: u } = e._zod.bag;
  typeof c == "number" && (o.minItems = c), typeof u == "number" && (o.maxItems = u), o.type = "array", o.items = D(i.element, t, {
    ...n,
    path: [...n.path, "items"]
  });
}, "arrayProcessor"), Ic = /* @__PURE__ */ s((e, t, r, n) => {
  let o = r, i = e._zod.def;
  o.type = "object", o.properties = {};
  let c = i.shape;
  for (let l in c)
    o.properties[l] = D(c[l], t, {
      ...n,
      path: [...n.path, "properties", l]
    });
  let u = new Set(Object.keys(c)), a = new Set([...u].filter((l) => {
    let f = i.shape[l]._zod;
    return t.io === "input" ? f.optin === void 0 : f.optout === void 0;
  }));
  a.size > 0 && (o.required = Array.from(a)), i.catchall?._zod.def.type === "never" ? o.additionalProperties = !1 : i.catchall ? i.catchall && (o.additionalProperties = D(i.catchall, t, {
    ...n,
    path: [...n.path, "additionalProperties"]
  })) : t.io === "output" && (o.additionalProperties = !1);
}, "objectProcessor"), Ac = /* @__PURE__ */ s((e, t, r, n) => {
  let o = e._zod.def, i = o.inclusive === !1, c = o.options.map((u, a) => D(u, t, {
    ...n,
    path: [...n.path, i ? "oneOf" : "anyOf", a]
  }));
  i ? r.oneOf = c : r.anyOf = c;
}, "unionProcessor"), Nc = /* @__PURE__ */ s((e, t, r, n) => {
  let o = e._zod.def, i = D(o.left, t, {
    ...n,
    path: [...n.path, "allOf", 0]
  }), c = D(o.right, t, {
    ...n,
    path: [...n.path, "allOf", 1]
  }), u = /* @__PURE__ */ s((l) => "allOf" in l && Object.keys(l).length === 1, "isSimpleIntersection"), a = [
    ...u(i) ? i.allOf : [i],
    ...u(c) ? c.allOf : [c]
  ];
  r.allOf = a;
}, "intersectionProcessor");
var Cc = /* @__PURE__ */ s((e, t, r, n) => {
  let o = e._zod.def, i = D(o.innerType, t, n), c = t.seen.get(e);
  t.target === "openapi-3.0" ? (c.ref = o.innerType, r.nullable = !0) : r.anyOf = [i, { type: "null" }];
}, "nullableProcessor"), jc = /* @__PURE__ */ s((e, t, r, n) => {
  let o = e._zod.def;
  D(o.innerType, t, n);
  let i = t.seen.get(e);
  i.ref = o.innerType;
}, "nonoptionalProcessor"), Rc = /* @__PURE__ */ s((e, t, r, n) => {
  let o = e._zod.def;
  D(o.innerType, t, n);
  let i = t.seen.get(e);
  i.ref = o.innerType, r.default = JSON.parse(JSON.stringify(o.defaultValue));
}, "defaultProcessor"), Fc = /* @__PURE__ */ s((e, t, r, n) => {
  let o = e._zod.def;
  D(o.innerType, t, n);
  let i = t.seen.get(e);
  i.ref = o.innerType, t.io === "input" && (r._prefault = JSON.parse(JSON.stringify(o.defaultValue)));
}, "prefaultProcessor"), Lc = /* @__PURE__ */ s((e, t, r, n) => {
  let o = e._zod.def;
  D(o.innerType, t, n);
  let i = t.seen.get(e);
  i.ref = o.innerType;
  let c;
  try {
    c = o.catchValue(void 0);
  } catch {
    throw new Error("Dynamic catch values are not supported in JSON Schema");
  }
  r.default = c;
}, "catchProcessor"), Mc = /* @__PURE__ */ s((e, t, r, n) => {
  let o = e._zod.def, i = o.in._zod.traits.has("$ZodTransform"), c = t.io === "input" ? i ? o.out : o.in : o.out;
  D(c, t, n);
  let u = t.seen.get(e);
  u.ref = c;
}, "pipeProcessor"), Dc = /* @__PURE__ */ s((e, t, r, n) => {
  let o = e._zod.def;
  D(o.innerType, t, n);
  let i = t.seen.get(e);
  i.ref = o.innerType, r.readOnly = !0;
}, "readonlyProcessor");
var qn = /* @__PURE__ */ s((e, t, r, n) => {
  let o = e._zod.def;
  D(o.innerType, t, n);
  let i = t.seen.get(e);
  i.ref = o.innerType;
}, "optionalProcessor");

// versions/4.4.3/node_modules/zod/v4/classic/iso.js
var sl = /* @__PURE__ */ p("ZodISODateTime", (e, t) => {
  xi.init(e, t), I.init(e, t);
});
function Uc(e) {
  return uc(sl, e);
}
s(Uc, "datetime");
var il = /* @__PURE__ */ p("ZodISODate", (e, t) => {
  bi.init(e, t), I.init(e, t);
});
function Bc(e) {
  return ac(il, e);
}
s(Bc, "date");
var cl = /* @__PURE__ */ p("ZodISOTime", (e, t) => {
  wi.init(e, t), I.init(e, t);
});
function Jc(e) {
  return lc(cl, e);
}
s(Jc, "time");
var ul = /* @__PURE__ */ p("ZodISODuration", (e, t) => {
  zi.init(e, t), I.init(e, t);
});
function Vc(e) {
  return pc(ul, e);
}
s(Vc, "duration");

// versions/4.4.3/node_modules/zod/v4/classic/errors.js
var pl = /* @__PURE__ */ s((e, t) => {
  Rt.init(e, t), e.name = "ZodError", Object.defineProperties(e, {
    format: {
      value: /* @__PURE__ */ s((r) => Wo(e, r), "value")
      // enumerable: false,
    },
    flatten: {
      value: /* @__PURE__ */ s((r) => qo(e, r), "value")
      // enumerable: false,
    },
    addIssue: {
      value: /* @__PURE__ */ s((r) => {
        e.issues.push(r), e.message = JSON.stringify(e.issues, Pe, 2);
      }, "value")
      // enumerable: false,
    },
    addIssues: {
      value: /* @__PURE__ */ s((r) => {
        e.issues.push(...r), e.message = JSON.stringify(e.issues, Pe, 2);
      }, "value")
      // enumerable: false,
    },
    isEmpty: {
      get() {
        return e.issues.length === 0;
      }
      // enumerable: false,
    }
  });
}, "initializer");
var Q = /* @__PURE__ */ p("ZodError", pl, {
  Parent: Error
});

// versions/4.4.3/node_modules/zod/v4/classic/parse.js
var pr = /* @__PURE__ */ Ke(Q), qc = /* @__PURE__ */ Ye(Q), Wc = /* @__PURE__ */ Xe(Q), Gc = /* @__PURE__ */ et(Q), fr = /* @__PURE__ */ Qo(Q), Hc = /* @__PURE__ */ Ko(Q), Qc = /* @__PURE__ */ Yo(Q), Kc = /* @__PURE__ */ Xo(Q), Yc = /* @__PURE__ */ es(Q), Xc = /* @__PURE__ */ ts(Q), eu = /* @__PURE__ */ rs(Q), tu = /* @__PURE__ */ ns(Q);

// versions/4.4.3/node_modules/zod/v4/classic/schemas.js
var ru = /* @__PURE__ */ new WeakMap();
function at(e, t, r) {
  let n = Object.getPrototypeOf(e), o = ru.get(n);
  if (o || (o = /* @__PURE__ */ new Set(), ru.set(n, o)), !o.has(t)) {
    o.add(t);
    for (let i in r) {
      let c = r[i];
      Object.defineProperty(n, i, {
        configurable: !0,
        enumerable: !1,
        get() {
          let u = c.bind(this);
          return Object.defineProperty(this, i, {
            configurable: !0,
            writable: !0,
            enumerable: !0,
            value: u
          }), u;
        },
        set(u) {
          Object.defineProperty(this, i, {
            configurable: !0,
            writable: !0,
            enumerable: !0,
            value: u
          });
        }
      });
    }
  }
}
s(at, "_installLazyMethods");
var j = /* @__PURE__ */ p("ZodType", (e, t) => (x.init(e, t), Object.assign(e["~standard"], {
  jsonSchema: {
    input: it(e, "input"),
    output: it(e, "output")
  }
}), e.toJSONSchema = wc(e, {}), e.def = t, e.type = t.type, Object.defineProperty(e, "_def", { value: t }), e.parse = (r, n) => pr(e, r, n, { callee: e.parse }), e.safeParse = (r, n) => Wc(e, r, n), e.parseAsync = async (r, n) => qc(e, r, n, { callee: e.parseAsync }), e.safeParseAsync = async (r, n) => Gc(e, r, n), e.spa = e.safeParseAsync, e.encode = (r, n) => fr(e, r, n), e.decode = (r, n) => Hc(e, r, n), e.encodeAsync = async (r, n) => Qc(e, r, n), e.decodeAsync = async (r, n) => Kc(e, r, n), e.safeEncode = (r, n) => Yc(e, r, n), e.safeDecode = (r, n) => Xc(e, r, n), e.safeEncodeAsync = async (r, n) => eu(e, r, n), e.safeDecodeAsync = async (r, n) => tu(e, r, n), at(e, "ZodType", {
  check(...r) {
    let n = this.def;
    return this.clone(Z.mergeDefs(n, {
      checks: [
        ...n.checks ?? [],
        ...r.map((o) => typeof o == "function" ? { _zod: { check: o, def: { check: "custom" }, onattach: [] } } : o)
      ]
    }), { parent: !0 });
  },
  with(...r) {
    return this.check(...r);
  },
  clone(r, n) {
    return ee(this, r, n);
  },
  brand() {
    return this;
  },
  register(r, n) {
    return r.add(this, n), this;
  },
  refine(r, n) {
    return this.check(np(r, n));
  },
  superRefine(r, n) {
    return this.check(op(r, n));
  },
  overwrite(r) {
    return this.check(le(r));
  },
  optional() {
    return ut(this);
  },
  exactOptional() {
    return Vl(this);
  },
  nullable() {
    return mr(this);
  },
  nullish() {
    return ut(mr(this));
  },
  nonoptional(r) {
    return Kl(this, r);
  },
  array() {
    return hr(this);
  },
  or(r) {
    return gr([this, r]);
  },
  and(r) {
    return Ml(this, r);
  },
  transform(r) {
    return iu(this, Bl(r));
  },
  default(r) {
    return Gl(this, r);
  },
  prefault(r) {
    return Ql(this, r);
  },
  catch(r) {
    return Xl(this, r);
  },
  pipe(r) {
    return iu(this, r);
  },
  readonly() {
    return rp(this);
  },
  describe(r) {
    let n = this.clone();
    return he.add(n, { description: r }), n;
  },
  meta(...r) {
    if (r.length === 0)
      return he.get(this);
    let n = this.clone();
    return he.add(n, r[0]), n;
  },
  isOptional() {
    return this.safeParse(void 0).success;
  },
  isNullable() {
    return this.safeParse(null).success;
  },
  apply(r) {
    return r(this);
  }
}), Object.defineProperty(e, "description", {
  get() {
    return he.get(e)?.description;
  },
  configurable: !0
}), e)), cu = /* @__PURE__ */ p("_ZodString", (e, t) => {
  Ee.init(e, t), j.init(e, t), e._zod.processJSONSchema = (n, o, i) => zc(e, n, o, i);
  let r = e._zod.bag;
  e.format = r.format ?? null, e.minLength = r.minimum ?? null, e.maxLength = r.maximum ?? null, at(e, "_ZodString", {
    regex(...n) {
      return this.check(In(...n));
    },
    includes(...n) {
      return this.check(Cn(...n));
    },
    startsWith(...n) {
      return this.check(jn(...n));
    },
    endsWith(...n) {
      return this.check(Rn(...n));
    },
    min(...n) {
      return this.check(Ae(...n));
    },
    max(...n) {
      return this.check(ar(...n));
    },
    length(...n) {
      return this.check(lr(...n));
    },
    nonempty(...n) {
      return this.check(Ae(1, ...n));
    },
    lowercase(n) {
      return this.check(An(n));
    },
    uppercase(n) {
      return this.check(Nn(n));
    },
    trim() {
      return this.check(Ln());
    },
    normalize(...n) {
      return this.check(Fn(...n));
    },
    toLowerCase() {
      return this.check(Mn());
    },
    toUpperCase() {
      return this.check(Dn());
    },
    slugify() {
      return this.check(Un());
    }
  });
}), dl = /* @__PURE__ */ p("ZodString", (e, t) => {
  Ee.init(e, t), cu.init(e, t), e.email = (r) => e.check(Di(ml, r)), e.url = (r) => e.check(qi(hl, r)), e.jwt = (r) => e.check(cc(El, r)), e.emoji = (r) => e.check(Wi(gl, r)), e.guid = (r) => e.check(Tn(nu, r)), e.uuid = (r) => e.check(Ui(dr, r)), e.uuidv4 = (r) => e.check(Bi(dr, r)), e.uuidv6 = (r) => e.check(Ji(dr, r)), e.uuidv7 = (r) => e.check(Vi(dr, r)), e.nanoid = (r) => e.check(Gi(yl, r)), e.guid = (r) => e.check(Tn(nu, r)), e.cuid = (r) => e.check(Hi(_l, r)), e.cuid2 = (r) => e.check(Qi(xl, r)), e.ulid = (r) => e.check(Ki(bl, r)), e.base64 = (r) => e.check(oc(Zl, r)), e.base64url = (r) => e.check(sc(Pl, r)), e.xid = (r) => e.check(Yi(wl, r)), e.ksuid = (r) => e.check(Xi(zl, r)), e.ipv4 = (r) => e.check(ec(vl, r)), e.ipv6 = (r) => e.check(tc($l, r)), e.cidrv4 = (r) => e.check(rc(kl, r)), e.cidrv6 = (r) => e.check(nc(Sl, r)), e.e164 = (r) => e.check(ic(Ol, r)), e.datetime = (r) => e.check(Uc(r)), e.date = (r) => e.check(Bc(r)), e.time = (r) => e.check(Jc(r)), e.duration = (r) => e.check(Vc(r));
});
function Gn(e) {
  return Mi(dl, e);
}
s(Gn, "string");
var I = /* @__PURE__ */ p("ZodStringFormat", (e, t) => {
  E.init(e, t), cu.init(e, t);
}), ml = /* @__PURE__ */ p("ZodEmail", (e, t) => {
  li.init(e, t), I.init(e, t);
});
var nu = /* @__PURE__ */ p("ZodGUID", (e, t) => {
  ui.init(e, t), I.init(e, t);
});
var dr = /* @__PURE__ */ p("ZodUUID", (e, t) => {
  ai.init(e, t), I.init(e, t);
});
var hl = /* @__PURE__ */ p("ZodURL", (e, t) => {
  pi.init(e, t), I.init(e, t);
});
var gl = /* @__PURE__ */ p("ZodEmoji", (e, t) => {
  fi.init(e, t), I.init(e, t);
});
var yl = /* @__PURE__ */ p("ZodNanoID", (e, t) => {
  di.init(e, t), I.init(e, t);
});
var _l = /* @__PURE__ */ p("ZodCUID", (e, t) => {
  mi.init(e, t), I.init(e, t);
});
var xl = /* @__PURE__ */ p("ZodCUID2", (e, t) => {
  hi.init(e, t), I.init(e, t);
});
var bl = /* @__PURE__ */ p("ZodULID", (e, t) => {
  gi.init(e, t), I.init(e, t);
});
var wl = /* @__PURE__ */ p("ZodXID", (e, t) => {
  yi.init(e, t), I.init(e, t);
});
var zl = /* @__PURE__ */ p("ZodKSUID", (e, t) => {
  _i.init(e, t), I.init(e, t);
});
var vl = /* @__PURE__ */ p("ZodIPv4", (e, t) => {
  vi.init(e, t), I.init(e, t);
});
var $l = /* @__PURE__ */ p("ZodIPv6", (e, t) => {
  $i.init(e, t), I.init(e, t);
});
var kl = /* @__PURE__ */ p("ZodCIDRv4", (e, t) => {
  ki.init(e, t), I.init(e, t);
});
var Sl = /* @__PURE__ */ p("ZodCIDRv6", (e, t) => {
  Si.init(e, t), I.init(e, t);
});
var Zl = /* @__PURE__ */ p("ZodBase64", (e, t) => {
  Pi.init(e, t), I.init(e, t);
});
var Pl = /* @__PURE__ */ p("ZodBase64URL", (e, t) => {
  Oi.init(e, t), I.init(e, t);
});
var Ol = /* @__PURE__ */ p("ZodE164", (e, t) => {
  Ei.init(e, t), I.init(e, t);
});
var El = /* @__PURE__ */ p("ZodJWT", (e, t) => {
  Ti.init(e, t), I.init(e, t);
});
var uu = /* @__PURE__ */ p("ZodNumber", (e, t) => {
  rt.init(e, t), j.init(e, t), e._zod.processJSONSchema = (n, o, i) => vc(e, n, o, i), at(e, "ZodNumber", {
    gt(n, o) {
      return this.check(cr(n, o));
    },
    gte(n, o) {
      return this.check(Ie(n, o));
    },
    min(n, o) {
      return this.check(Ie(n, o));
    },
    lt(n, o) {
      return this.check(ir(n, o));
    },
    lte(n, o) {
      return this.check(Te(n, o));
    },
    max(n, o) {
      return this.check(Te(n, o));
    },
    int(n) {
      return this.check(ou(n));
    },
    safe(n) {
      return this.check(ou(n));
    },
    positive(n) {
      return this.check(cr(0, n));
    },
    nonnegative(n) {
      return this.check(Ie(0, n));
    },
    negative(n) {
      return this.check(ir(0, n));
    },
    nonpositive(n) {
      return this.check(Te(0, n));
    },
    multipleOf(n, o) {
      return this.check(ur(n, o));
    },
    step(n, o) {
      return this.check(ur(n, o));
    },
    finite() {
      return this;
    }
  });
  let r = e._zod.bag;
  e.minValue = Math.max(r.minimum ?? Number.NEGATIVE_INFINITY, r.exclusiveMinimum ?? Number.NEGATIVE_INFINITY) ?? null, e.maxValue = Math.min(r.maximum ?? Number.POSITIVE_INFINITY, r.exclusiveMaximum ?? Number.POSITIVE_INFINITY) ?? null, e.isInt = (r.format ?? "").includes("int") || Number.isSafeInteger(r.multipleOf ?? 0.5), e.isFinite = !0, e.format = r.format ?? null;
});
function Hn(e) {
  return fc(uu, e);
}
s(Hn, "number");
var Tl = /* @__PURE__ */ p("ZodNumberFormat", (e, t) => {
  Ii.init(e, t), uu.init(e, t);
});
function ou(e) {
  return dc(Tl, e);
}
s(ou, "int");
var Il = /* @__PURE__ */ p("ZodBoolean", (e, t) => {
  Jt.init(e, t), j.init(e, t), e._zod.processJSONSchema = (r, n, o) => $c(e, r, n, o);
});
function Qn(e) {
  return mc(Il, e);
}
s(Qn, "boolean");
var Al = /* @__PURE__ */ p("ZodUnknown", (e, t) => {
  Vt.init(e, t), j.init(e, t), e._zod.processJSONSchema = (r, n, o) => Sc(e, r, n, o);
});
function su() {
  return hc(Al);
}
s(su, "unknown");
var Nl = /* @__PURE__ */ p("ZodNever", (e, t) => {
  qt.init(e, t), j.init(e, t), e._zod.processJSONSchema = (r, n, o) => kc(e, r, n, o);
});
function au(e) {
  return gc(Nl, e);
}
s(au, "never");
var Cl = /* @__PURE__ */ p("ZodDate", (e, t) => {
  Wt.init(e, t), j.init(e, t), e._zod.processJSONSchema = (n, o, i) => Zc(e, n, o, i), e.min = (n, o) => e.check(Ie(n, o)), e.max = (n, o) => e.check(Te(n, o));
  let r = e._zod.bag;
  e.minDate = r.minimum ? new Date(r.minimum) : null, e.maxDate = r.maximum ? new Date(r.maximum) : null;
});
function lu(e) {
  return yc(Cl, e);
}
s(lu, "date");
var jl = /* @__PURE__ */ p("ZodArray", (e, t) => {
  Gt.init(e, t), j.init(e, t), e._zod.processJSONSchema = (r, n, o) => Tc(e, r, n, o), e.element = t.element, at(e, "ZodArray", {
    min(r, n) {
      return this.check(Ae(r, n));
    },
    nonempty(r) {
      return this.check(Ae(1, r));
    },
    max(r, n) {
      return this.check(ar(r, n));
    },
    length(r, n) {
      return this.check(lr(r, n));
    },
    unwrap() {
      return this.element;
    }
  });
});
function hr(e, t) {
  return _c(jl, e, t);
}
s(hr, "array");
var Rl = /* @__PURE__ */ p("ZodObject", (e, t) => {
  Ci.init(e, t), j.init(e, t), e._zod.processJSONSchema = (r, n, o) => Ic(e, r, n, o), Z.defineLazy(e, "shape", () => t.shape), at(e, "ZodObject", {
    keyof() {
      return Dl(Object.keys(this._zod.def.shape));
    },
    catchall(r) {
      return this.clone({ ...this._zod.def, catchall: r });
    },
    passthrough() {
      return this.clone({ ...this._zod.def, catchall: su() });
    },
    loose() {
      return this.clone({ ...this._zod.def, catchall: su() });
    },
    strict() {
      return this.clone({ ...this._zod.def, catchall: au() });
    },
    strip() {
      return this.clone({ ...this._zod.def, catchall: void 0 });
    },
    extend(r) {
      return Z.extend(this, r);
    },
    safeExtend(r) {
      return Z.safeExtend(this, r);
    },
    merge(r) {
      return Z.merge(this, r);
    },
    pick(r) {
      return Z.pick(this, r);
    },
    omit(r) {
      return Z.omit(this, r);
    },
    partial(...r) {
      return Z.partial(pu, this, r[0]);
    },
    required(...r) {
      return Z.required(fu, this, r[0]);
    }
  });
});
function lt(e, t) {
  let r = {
    type: "object",
    shape: e ?? {},
    ...Z.normalizeParams(t)
  };
  return new Rl(r);
}
s(lt, "object");
var Fl = /* @__PURE__ */ p("ZodUnion", (e, t) => {
  Qt.init(e, t), j.init(e, t), e._zod.processJSONSchema = (r, n, o) => Ac(e, r, n, o), e.options = t.options;
});
function gr(e, t) {
  return new Fl({
    type: "union",
    options: e,
    ...Z.normalizeParams(t)
  });
}
s(gr, "union");
var Ll = /* @__PURE__ */ p("ZodIntersection", (e, t) => {
  Kt.init(e, t), j.init(e, t), e._zod.processJSONSchema = (r, n, o) => Nc(e, r, n, o);
});
function Ml(e, t) {
  return new Ll({
    type: "intersection",
    left: e,
    right: t
  });
}
s(Ml, "intersection");
var Wn = /* @__PURE__ */ p("ZodEnum", (e, t) => {
  Xt.init(e, t), j.init(e, t), e._zod.processJSONSchema = (n, o, i) => Pc(e, n, o, i), e.enum = t.entries, e.options = Object.values(t.entries);
  let r = new Set(Object.keys(t.entries));
  e.extract = (n, o) => {
    let i = {};
    for (let c of n)
      if (r.has(c))
        i[c] = t.entries[c];
      else
        throw new Error(`Key ${c} not found in enum`);
    return new Wn({
      ...t,
      checks: [],
      ...Z.normalizeParams(o),
      entries: i
    });
  }, e.exclude = (n, o) => {
    let i = { ...t.entries };
    for (let c of n)
      if (r.has(c))
        delete i[c];
      else
        throw new Error(`Key ${c} not found in enum`);
    return new Wn({
      ...t,
      checks: [],
      ...Z.normalizeParams(o),
      entries: i
    });
  };
});
function Dl(e, t) {
  let r = Array.isArray(e) ? Object.fromEntries(e.map((n) => [n, n])) : e;
  return new Wn({
    type: "enum",
    entries: r,
    ...Z.normalizeParams(t)
  });
}
s(Dl, "_enum");
var Ul = /* @__PURE__ */ p("ZodTransform", (e, t) => {
  er.init(e, t), j.init(e, t), e._zod.processJSONSchema = (r, n, o) => Ec(e, r, n, o), e._zod.parse = (r, n) => {
    if (n.direction === "backward")
      throw new ke(e.constructor.name);
    r.addIssue = (i) => {
      if (typeof i == "string")
        r.issues.push(Z.issue(i, r.value, t));
      else {
        let c = i;
        c.fatal && (c.continue = !1), c.code ?? (c.code = "custom"), c.input ?? (c.input = r.value), c.inst ?? (c.inst = e), r.issues.push(Z.issue(c));
      }
    };
    let o = t.transform(r.value, r);
    return o instanceof Promise ? o.then((i) => (r.value = i, r.fallback = !0, r)) : (r.value = o, r.fallback = !0, r);
  };
});
function Bl(e) {
  return new Ul({
    type: "transform",
    transform: e
  });
}
s(Bl, "transform");
var pu = /* @__PURE__ */ p("ZodOptional", (e, t) => {
  nt.init(e, t), j.init(e, t), e._zod.processJSONSchema = (r, n, o) => qn(e, r, n, o), e.unwrap = () => e._zod.def.innerType;
});
function ut(e) {
  return new pu({
    type: "optional",
    innerType: e
  });
}
s(ut, "optional");
var Jl = /* @__PURE__ */ p("ZodExactOptional", (e, t) => {
  ji.init(e, t), j.init(e, t), e._zod.processJSONSchema = (r, n, o) => qn(e, r, n, o), e.unwrap = () => e._zod.def.innerType;
});
function Vl(e) {
  return new Jl({
    type: "optional",
    innerType: e
  });
}
s(Vl, "exactOptional");
var ql = /* @__PURE__ */ p("ZodNullable", (e, t) => {
  tr.init(e, t), j.init(e, t), e._zod.processJSONSchema = (r, n, o) => Cc(e, r, n, o), e.unwrap = () => e._zod.def.innerType;
});
function mr(e) {
  return new ql({
    type: "nullable",
    innerType: e
  });
}
s(mr, "nullable");
var Wl = /* @__PURE__ */ p("ZodDefault", (e, t) => {
  ot.init(e, t), j.init(e, t), e._zod.processJSONSchema = (r, n, o) => Rc(e, r, n, o), e.unwrap = () => e._zod.def.innerType, e.removeDefault = e.unwrap;
});
function Gl(e, t) {
  return new Wl({
    type: "default",
    innerType: e,
    get defaultValue() {
      return typeof t == "function" ? t() : Z.shallowClone(t);
    }
  });
}
s(Gl, "_default");
var Hl = /* @__PURE__ */ p("ZodPrefault", (e, t) => {
  Ri.init(e, t), j.init(e, t), e._zod.processJSONSchema = (r, n, o) => Fc(e, r, n, o), e.unwrap = () => e._zod.def.innerType;
});
function Ql(e, t) {
  return new Hl({
    type: "prefault",
    innerType: e,
    get defaultValue() {
      return typeof t == "function" ? t() : Z.shallowClone(t);
    }
  });
}
s(Ql, "prefault");
var fu = /* @__PURE__ */ p("ZodNonOptional", (e, t) => {
  rr.init(e, t), j.init(e, t), e._zod.processJSONSchema = (r, n, o) => jc(e, r, n, o), e.unwrap = () => e._zod.def.innerType;
});
function Kl(e, t) {
  return new fu({
    type: "nonoptional",
    innerType: e,
    ...Z.normalizeParams(t)
  });
}
s(Kl, "nonoptional");
var Yl = /* @__PURE__ */ p("ZodCatch", (e, t) => {
  nr.init(e, t), j.init(e, t), e._zod.processJSONSchema = (r, n, o) => Lc(e, r, n, o), e.unwrap = () => e._zod.def.innerType, e.removeCatch = e.unwrap;
});
function Xl(e, t) {
  return new Yl({
    type: "catch",
    innerType: e,
    catchValue: typeof t == "function" ? t : () => t
  });
}
s(Xl, "_catch");
var du = /* @__PURE__ */ p("ZodPipe", (e, t) => {
  st.init(e, t), j.init(e, t), e._zod.processJSONSchema = (r, n, o) => Mc(e, r, n, o), e.in = t.in, e.out = t.out;
});
function iu(e, t) {
  return new du({
    type: "pipe",
    in: e,
    out: t
    // ...util.normalizeParams(params),
  });
}
s(iu, "pipe");
var ep = /* @__PURE__ */ p("ZodCodec", (e, t) => {
  du.init(e, t), Fi.init(e, t);
});
function mu(e, t, r) {
  return new ep({
    type: "pipe",
    in: e,
    out: t,
    transform: r.decode,
    reverseTransform: r.encode
  });
}
s(mu, "codec");
var tp = /* @__PURE__ */ p("ZodReadonly", (e, t) => {
  or.init(e, t), j.init(e, t), e._zod.processJSONSchema = (r, n, o) => Dc(e, r, n, o), e.unwrap = () => e._zod.def.innerType;
});
function rp(e) {
  return new tp({
    type: "readonly",
    innerType: e
  });
}
s(rp, "readonly");
var hu = /* @__PURE__ */ p("ZodCustom", (e, t) => {
  sr.init(e, t), j.init(e, t), e._zod.processJSONSchema = (r, n, o) => Oc(e, r, n, o);
});
function np(e, t = {}) {
  return xc(hu, e, t);
}
s(np, "refine");
function op(e, t) {
  return bc(e, t);
}
s(op, "superRefine");
function gu(e, t = {}) {
  let r = new hu({
    type: "custom",
    check: "custom",
    fn: /* @__PURE__ */ s((n) => n instanceof e, "fn"),
    abort: !0,
    ...Z.normalizeParams(t)
  });
  return r._zod.bag.Class = e, r._zod.check = (n) => {
    n.value instanceof e || n.issues.push({
      code: "invalid_type",
      expected: e.name,
      input: n.value,
      inst: r,
      path: [...r._zod.def.path ?? []]
    });
  }, r;
}
s(gu, "_instanceof");

// ../zodvex-triage-20260909/node_modules/.bun/convex-helpers@0.1.113+b9ed8f5244cf7f28/node_modules/convex-helpers/index.js
function yr(e, t) {
  return Object.fromEntries(Object.entries(e).filter(([r]) => t.includes(r)));
}
s(yr, "pick");
var Lg = Symbol();

// ../zodvex-triage-20260909/node_modules/.bun/convex-helpers@0.1.113+b9ed8f5244cf7f28/node_modules/convex-helpers/validators.js
var Vg = d.string(), qg = d.float64(), Wg = d.float64(), Gg = d.boolean(), Hg = d.int64(), Qg = d.int64(), Kg = d.any(), Yg = d.null(), { id: Xg, object: ey, array: ty, bytes: ry, literal: ny, optional: oy, union: sy } = d, iy = d.bytes();
function _r(e, t) {
  let r = ye(e);
  if (Object.keys(t).length === 0)
    return r;
  switch (r.kind) {
    case "object":
      return d.object(sp(r.fields, t));
    case "union":
      return d.union(...r.members.map((n) => _r(n, t)));
    default:
      throw new Error("Cannot add arguments to a validator that is not an object or union.");
  }
}
s(_r, "addFieldsToValidator");
function sp(e, t) {
  let r = { ...e };
  for (let [n, o] of Object.entries(t)) {
    let i = r[n];
    if (i) {
      if (i.kind !== o.kind)
        throw new Error(`Cannot intersect validators with different kinds: ${i.kind} and ${o.kind}`);
      i.isOptional !== o.isOptional && i.isOptional === "optional" && (r[n] = o);
    } else
      r[n] = o;
  }
  return r;
}
s(sp, "intersectValidators");
var cy = d.optional(d.any());
function pt(e) {
  let { kind: t, isOptional: r } = e;
  if (r === "required")
    return e;
  switch (t) {
    case "id":
      return d.id(e.tableName);
    case "string":
      return d.string();
    case "float64":
      return d.float64();
    case "int64":
      return d.int64();
    case "boolean":
      return d.boolean();
    case "null":
      return d.null();
    case "any":
      return d.any();
    case "literal":
      return d.literal(e.value);
    case "bytes":
      return d.bytes();
    case "object":
      return d.object(e.fields);
    case "array":
      return d.array(e.element);
    case "record":
      return d.record(e.key, e.value);
    case "union":
      return d.union(...e.members);
    default:
      throw new Error("Unknown Convex validator type: " + t);
  }
}
s(pt, "vRequired");

// ../zodvex-triage-20260909/node_modules/.bun/convex-helpers@0.1.113+b9ed8f5244cf7f28/node_modules/convex-helpers/server/customFunctions.js
var ft = {
  args: {},
  input() {
    return { args: {}, ctx: {} };
  }
};

// ../zodvex-triage-20260909/node_modules/.bun/convex-helpers@0.1.113+b9ed8f5244cf7f28/node_modules/convex-helpers/server/zod4.js
function _u(e, t) {
  return ap(e, t);
}
s(_u, "zCustomQuery");
function ip(e) {
  let t = /* @__PURE__ */ new WeakSet();
  function r(n) {
    if (t.has(n))
      return d.any();
    t.add(n);
    let o = n instanceof ot ? d.optional(r(n._zod.def.innerType)) : n instanceof st ? r(n._zod.def.in) : xu(n, r);
    return t.delete(n), o;
  }
  return s(r, "zodToConvexInner"), r(e);
}
s(ip, "zodToConvex");
function cp(e) {
  let t = /* @__PURE__ */ new WeakSet();
  function r(n) {
    if (t.has(n))
      return d.any();
    t.add(n);
    let o = n instanceof ot ? r(n._zod.def.innerType) : n instanceof st ? r(n._zod.def.out) : n instanceof er ? d.any() : xu(n, r);
    return t.delete(n), o;
  }
  return s(r, "zodOutputToConvexInner"), r(e);
}
s(cp, "zodOutputToConvex");
function up(e) {
  return Object.fromEntries(Object.entries(e).map(([t, r]) => [t, ip(r)]));
}
s(up, "zodToConvexFields");
function ap(e, t) {
  let r = t.input ?? ft.input, n = t.args ?? ft.args;
  return /* @__PURE__ */ s(function(i) {
    let { args: c, handler: u = i, skipConvexValidation: a = !1, returns: l, ...f } = i, h = l && !(l instanceof x) ? lt(l) : l, g = h && !a ? { returns: cp(h) } : null;
    if (c) {
      let m = c;
      if (m instanceof x)
        if (m instanceof Ht)
          m = m._zod.def.shape;
        else
          throw new Error("Unsupported zod type as args validator: " + m.constructor.name);
      let b = up(m);
      return e({
        args: a ? void 0 : _r(b, n),
        ...g,
        handler: /* @__PURE__ */ s(async (A, v) => {
          let q = await r(A, yr(v, Object.keys(n)), f), W = yr(v, Object.keys(m)), R = await lt(m).safeParseAsync(W);
          if (!R.success)
            throw new _e({
              ZodError: JSON.parse(JSON.stringify(R.error.issues, null, 2))
            });
          let S = R.data, N = { ...A, ...q.ctx }, _ = { ...S, ...q.args }, z = await u(N, _), F = h ? await h.parseAsync(z === void 0 ? null : z) : z;
          return q.onSuccess && await q.onSuccess({ ctx: A, args: S, result: F }), F;
        }, "handler")
      });
    }
    if (a && Object.keys(n).length > 0)
      throw new Error("If you're using a custom function with arguments for the input customization, you cannot skip convex validation.");
    return e({
      ...g,
      handler: /* @__PURE__ */ s(async (m, b) => {
        let A = await r(m, b, f), v = { ...m, ...A.ctx }, q = { ...b, ...A.args }, W = await u(v, q), R = h ? await h.parseAsync(W === void 0 ? null : W) : W;
        return A.onSuccess && await A.onSuccess({ ctx: m, args: b, result: R }), R;
      }, "handler")
    });
  }, "customBuilder");
}
s(ap, "customFnBuilder");
function xu(e, t) {
  if (e instanceof Ee)
    return d.string();
  if (e instanceof rt || e instanceof $n)
    return d.number();
  if (e instanceof dn)
    return d.int64();
  if (e instanceof Jt)
    return d.boolean();
  if (e instanceof gn)
    return d.null();
  if (e instanceof yn || e instanceof Vt)
    return d.any();
  if (e instanceof Gt) {
    let r = t(e._zod.def.element);
    if (r.isOptional === "optional")
      throw new Error("Arrays of optional values are not supported");
    return d.array(r);
  }
  if (e instanceof Ht)
    return d.object(Object.fromEntries(Object.entries(e._zod.def.shape).map(([r, n]) => [
      r,
      t(n)
    ])));
  if (e instanceof Qt)
    return d.union(...e._zod.def.options.map(t));
  if (e instanceof qt)
    return d.union();
  if (e instanceof Yt) {
    let { items: r, rest: n } = e._zod.def;
    return d.array(d.union(...[
      ...r,
      // + rest if set
      ...n !== null ? [n] : []
    ].map(t)));
  }
  if (e instanceof zn) {
    let { values: r } = e._zod.def;
    return r.length === 1 ? yu(r[0]) : d.union(...r.map(yu));
  }
  if (e instanceof Xt)
    return d.union(...Object.entries(e._zod.def.entries).filter(([r, n]) => r === n || isNaN(Number(r))).map(([r, n]) => d.literal(n)));
  if (e instanceof nt)
    return d.optional(t(e._zod.def.innerType));
  if (e instanceof rr)
    return pt(t(e._zod.def.innerType));
  if (e instanceof tr) {
    let r = t(e._zod.def.innerType);
    return r.isOptional === "optional" ? d.optional(d.union(pt(r), d.null())) : d.union(r, d.null());
  }
  if (e instanceof xn) {
    let { keyType: r, valueType: n } = e._zod.def, o = r._zod.values === void 0, i = t(n), c = t(r), u = bu(c);
    if (u !== null) {
      let a = o || i.isOptional === "optional" ? d.optional(i) : pt(i), l = {};
      for (let f of u)
        l[f] = a;
      return d.object(l);
    }
    return d.record(wu(c) ? c : d.string(), pt(i));
  }
  if (e instanceof or)
    return t(e._zod.def.innerType);
  if (e instanceof Pn)
    return t(e._zod.def.getter());
  if (e instanceof kn)
    return d.string();
  if (e instanceof sr) {
    let r = lp.get(e);
    return r !== void 0 && typeof r.tableName == "string" ? d.id(r.tableName) : d.any();
  }
  if (e instanceof Kt)
    return d.any();
  if (e instanceof nr)
    return t(e._zod.def.innerType);
  if (e instanceof Wt || e instanceof mn || e instanceof bn || e instanceof wn || e instanceof Zn || e instanceof vn || e instanceof Sn || e instanceof _n || e instanceof hn)
    throw new Error(`Validator ${e.constructor.name} is not supported in Convex`);
  return d.any();
}
s(xu, "zodToConvexCommon");
function yu(e) {
  if (e === void 0)
    throw new Error("undefined is not a valid Convex value");
  return e === null ? d.null() : d.literal(e);
}
s(yu, "convexToZodLiteral");
function bu(e) {
  if (e.kind === "literal") {
    let t = e;
    return typeof t.value == "string" ? [t.value] : null;
  }
  if (e.kind === "union") {
    let t = e, r = [];
    for (let n of t.members) {
      let o = bu(n);
      if (o === null)
        return null;
      r.push(...o);
    }
    return r;
  }
  return null;
}
s(bu, "extractStringLiterals");
function wu(e) {
  return e.kind === "string" || e.kind === "id" ? !0 : e.kind === "union" ? e.members.every(wu) : !1;
}
s(wu, "isValidRecordKey");
var lp = En();

// graphProbe.ts
var zu = { query: Ur, mutation: Mr, action: Jr, internalQuery: Br, internalMutation: Dr, internalAction: Vr }, fp = { kind: "helpers", schemaHelpers: !1, server: zu, s: { number: Hn, string: Gn, boolean: Qn, optional: ut, nullable: mr, object: lt, array: hr, union: gr, date: lu, codec: mu, instanceof: gu, parse: pr, encode: fr }, makeBuilders: /* @__PURE__ */ s(() => ({ query: _u(zu.query, ft) }), "makeBuilders") }, dp = jo(fp), mp = { count: 16, width: 32, profile: "codec-rich", entries: 0 }, Kn = dp(mp), Ry = pp({ args: {}, returns: d.object({ checksum: d.number(), output: d.object({ seq: d.number(), at: d.number(), secret: d.string(), payload: d.string() }), manifest: d.any(), nonce: d.string() }), handler: /* @__PURE__ */ s(() => {
  let e = Kn.operation();
  return globalThis.gc(), globalThis.gc(), { checksum: Kn.checksum(), output: e, manifest: Kn.manifest, nonce: "bf36dade-b35f-4022-ab71-669b07653e75" };
}, "handler") });
export {
  Ry as default
};
