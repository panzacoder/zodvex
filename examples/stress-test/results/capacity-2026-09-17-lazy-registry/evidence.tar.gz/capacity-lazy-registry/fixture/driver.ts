import { action, internalAction, internalMutation, internalQuery } from './_generated/server'
import { makeFunctionReference } from 'convex/server'
import { v } from 'convex/values'
import { makeWireRow, assertWireResult } from './workload'
const paths: Record<string, string> = {"native":"native:read","helpers":"helpers/query:read","full_lean":"full_lean/query:read","full_models":"full_models/query:read","full_registry":"full_registry/query:read","full_registry_lazy":"full_registry_lazy/query:read","mini_lean":"mini_lean/query:read","mini_models":"mini_models/query:read","mini_registry":"mini_registry/query:read","mini_registry_lazy":"mini_registry_lazy/query:read"}
async function identityHash(rows: { seq: number; _id: string; _creationTime: number }[]) {
  const bytes = new TextEncoder().encode(JSON.stringify(rows.map(row => [row.seq, row._id, row._creationTime])))
  const hash = await crypto.subtle.digest('SHA-256', bytes)
  return Array.from(new Uint8Array(hash), b => b.toString(16).padStart(2, '0')).join('')
}
export const metadata = internalQuery({
  args: { count: v.number(), cursor: v.union(v.string(), v.null()) },
  returns: v.object({
    rows: v.array(v.object({ seq: v.number(), _id: v.id('benchmarkRows'), _creationTime: v.number() })),
    continueCursor: v.string(), isDone: v.boolean(),
  }),
  handler: async (ctx, { count, cursor }) => {
    if (!Number.isInteger(count) || count < 1 || count > 256) throw new Error('Invalid reference page size')
    const page = await ctx.db.query('benchmarkRows').withIndex('by_seq').paginate({ numItems: count, cursor, maximumRowsRead: count })
    return {
      rows: page.page.map(({ seq, _id, _creationTime }) => ({ seq, _id, _creationTime })),
      continueCursor: page.continueCursor, isDone: page.isDone,
    }
  },
})
export const reference = action({
  args: { limit: v.number() }, returns: v.string(),
  handler: async (ctx, { limit }) => {
    if (!Number.isInteger(limit) || limit < 1 || limit > 8192) throw new Error('Invalid reference size')
    // Reference setup must not inherit the measured query's full-batch read limit.
    const rows: { seq: number; _id: string; _creationTime: number }[] = []
    let cursor: string | null = null
    while (rows.length < limit) {
      const page: { rows: typeof rows; continueCursor: string; isDone: boolean } = await ctx.runQuery(makeFunctionReference<'query'>('driver:metadata'), {
        count: Math.min(256, limit - rows.length), cursor,
      })
      rows.push(...page.rows)
      if (rows.length < limit && (page.isDone || page.continueCursor === cursor)) {
        throw new Error('HARNESS: reference dataset has too few rows or cannot advance')
      }
      cursor = page.continueCursor
    }
    return identityHash(rows)
  },
})
export const seedBatch = internalMutation({
  args: { start: v.number(), count: v.number(), payloadBytes: v.number() }, returns: v.null(),
  handler: async (ctx, { start, count, payloadBytes }) => {
    if (start < 0 || count < 1 || count > 256 || start + count > 8192 || payloadBytes < 0 || payloadBytes > 2048) throw new Error('Invalid seed batch')
    const existing = await ctx.db.query('benchmarkRows').withIndex('by_seq', q => q.gte('seq', start).lt('seq', start + count)).take(count)
    const ids = new Map(existing.map(row => [row.seq, row._id]))
    for (let seq = start; seq < start + count; seq++) {
      const row = makeWireRow(seq, payloadBytes)
      const id = ids.get(seq)
      if (id) await ctx.db.replace('benchmarkRows', id, row)
      else await ctx.db.insert('benchmarkRows', row)
    }
    return null
  },
})
export const prepare = internalAction({
  args: { count: v.number(), payloadBytes: v.number() }, returns: v.null(),
  handler: async (ctx, a) => {
    if (!Number.isInteger(a.count) || a.count < 1 || a.count > 8192) throw new Error('Invalid dataset size')
    for (let start = 0; start < a.count; start += 256) await ctx.runMutation(makeFunctionReference<'mutation'>('driver:seedBatch'), { start, count: Math.min(256, a.count-start), payloadBytes: a.payloadBytes })
    return null
  },
})
export const sample = action({
  args: { variant: v.string(), limit: v.number(), run: v.string(), sample: v.string(), payloadBytes: v.number() },
  returns: v.object({ count: v.number(), digest: v.number(), jsonBytes: v.number(), identityHash: v.string() }),
  handler: async (ctx, a) => {
    const path = paths[a.variant]
    if (!path) throw new Error('Unknown benchmark variant')
    const result = await ctx.runQuery(makeFunctionReference<'query'>(path), { limit: a.limit, run: a.run, sample: a.sample })
    if (result.rows.length !== a.limit || result.nonce !== a.sample) throw new Error('HARNESS: wrong row count/nonce')
    const expected = result.rows.map((row: { _id: string; _creationTime: number }, seq: number) => ({ ...makeWireRow(seq, a.payloadBytes), _id: row._id, _creationTime: row._creationTime }))
    assertWireResult(expected, { rows: result.rows, digest: result.digest })
    // Only the driver crosses the client boundary; measured query returns full rows.
    return { count: result.rows.length, digest: result.digest, jsonBytes: new TextEncoder().encode(JSON.stringify(result)).byteLength, identityHash: await identityHash(result.rows) }
  },
})
