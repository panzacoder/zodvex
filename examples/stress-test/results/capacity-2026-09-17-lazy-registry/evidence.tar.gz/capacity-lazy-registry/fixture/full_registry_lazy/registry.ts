import { z as s } from 'zod'
import { model0, model1, model2, model3, model4, model5, model6, model7, model8, model9, model10, model11, model12, model13, model14, model15, model16, model17, model18, model19, model20, model21, model22, model23, model24, model25, model26, model27, model28, model29, model30, model31 } from './models'
// A controlled memoizing-getter (zodvex generate 0.7.11+ shape) registry fixture, not a count of deployed functions.
// Each entry's args is a ten-field argument schema (the local Zod baseline corpus), the
// size a generated entry typically inlines, so registry construction is measurable.
const __memo = new Map<string, unknown>()
const __lazy = <T,>(key: string, build: () => T): T => {
  let entry = __memo.get(key) as T | undefined
  if (entry === undefined) {
    entry = build()
    __memo.set(key, entry)
  }
  return entry
}
export const registry = {
  get 'unused/fn0'() {
    return __lazy('unused/fn0', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model0.schema.doc),
    }))
  },
  get 'unused/fn1'() {
    return __lazy('unused/fn1', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model1.schema.doc),
    }))
  },
  get 'unused/fn2'() {
    return __lazy('unused/fn2', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model2.schema.doc),
    }))
  },
  get 'unused/fn3'() {
    return __lazy('unused/fn3', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model3.schema.doc),
    }))
  },
  get 'unused/fn4'() {
    return __lazy('unused/fn4', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model4.schema.doc),
    }))
  },
  get 'unused/fn5'() {
    return __lazy('unused/fn5', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model5.schema.doc),
    }))
  },
  get 'unused/fn6'() {
    return __lazy('unused/fn6', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model6.schema.doc),
    }))
  },
  get 'unused/fn7'() {
    return __lazy('unused/fn7', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model7.schema.doc),
    }))
  },
  get 'unused/fn8'() {
    return __lazy('unused/fn8', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model8.schema.doc),
    }))
  },
  get 'unused/fn9'() {
    return __lazy('unused/fn9', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model9.schema.doc),
    }))
  },
  get 'unused/fn10'() {
    return __lazy('unused/fn10', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model10.schema.doc),
    }))
  },
  get 'unused/fn11'() {
    return __lazy('unused/fn11', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model11.schema.doc),
    }))
  },
  get 'unused/fn12'() {
    return __lazy('unused/fn12', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model12.schema.doc),
    }))
  },
  get 'unused/fn13'() {
    return __lazy('unused/fn13', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model13.schema.doc),
    }))
  },
  get 'unused/fn14'() {
    return __lazy('unused/fn14', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model14.schema.doc),
    }))
  },
  get 'unused/fn15'() {
    return __lazy('unused/fn15', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model15.schema.doc),
    }))
  },
  get 'unused/fn16'() {
    return __lazy('unused/fn16', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model16.schema.doc),
    }))
  },
  get 'unused/fn17'() {
    return __lazy('unused/fn17', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model17.schema.doc),
    }))
  },
  get 'unused/fn18'() {
    return __lazy('unused/fn18', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model18.schema.doc),
    }))
  },
  get 'unused/fn19'() {
    return __lazy('unused/fn19', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model19.schema.doc),
    }))
  },
  get 'unused/fn20'() {
    return __lazy('unused/fn20', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model20.schema.doc),
    }))
  },
  get 'unused/fn21'() {
    return __lazy('unused/fn21', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model21.schema.doc),
    }))
  },
  get 'unused/fn22'() {
    return __lazy('unused/fn22', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model22.schema.doc),
    }))
  },
  get 'unused/fn23'() {
    return __lazy('unused/fn23', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model23.schema.doc),
    }))
  },
  get 'unused/fn24'() {
    return __lazy('unused/fn24', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model24.schema.doc),
    }))
  },
  get 'unused/fn25'() {
    return __lazy('unused/fn25', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model25.schema.doc),
    }))
  },
  get 'unused/fn26'() {
    return __lazy('unused/fn26', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model26.schema.doc),
    }))
  },
  get 'unused/fn27'() {
    return __lazy('unused/fn27', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model27.schema.doc),
    }))
  },
  get 'unused/fn28'() {
    return __lazy('unused/fn28', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model28.schema.doc),
    }))
  },
  get 'unused/fn29'() {
    return __lazy('unused/fn29', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model29.schema.doc),
    }))
  },
  get 'unused/fn30'() {
    return __lazy('unused/fn30', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model30.schema.doc),
    }))
  },
  get 'unused/fn31'() {
    return __lazy('unused/fn31', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model31.schema.doc),
    }))
  },
  get 'unused/fn32'() {
    return __lazy('unused/fn32', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model0.schema.doc),
    }))
  },
  get 'unused/fn33'() {
    return __lazy('unused/fn33', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model1.schema.doc),
    }))
  },
  get 'unused/fn34'() {
    return __lazy('unused/fn34', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model2.schema.doc),
    }))
  },
  get 'unused/fn35'() {
    return __lazy('unused/fn35', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model3.schema.doc),
    }))
  },
  get 'unused/fn36'() {
    return __lazy('unused/fn36', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model4.schema.doc),
    }))
  },
  get 'unused/fn37'() {
    return __lazy('unused/fn37', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model5.schema.doc),
    }))
  },
  get 'unused/fn38'() {
    return __lazy('unused/fn38', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model6.schema.doc),
    }))
  },
  get 'unused/fn39'() {
    return __lazy('unused/fn39', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model7.schema.doc),
    }))
  },
  get 'unused/fn40'() {
    return __lazy('unused/fn40', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model8.schema.doc),
    }))
  },
  get 'unused/fn41'() {
    return __lazy('unused/fn41', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model9.schema.doc),
    }))
  },
  get 'unused/fn42'() {
    return __lazy('unused/fn42', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model10.schema.doc),
    }))
  },
  get 'unused/fn43'() {
    return __lazy('unused/fn43', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model11.schema.doc),
    }))
  },
  get 'unused/fn44'() {
    return __lazy('unused/fn44', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model12.schema.doc),
    }))
  },
  get 'unused/fn45'() {
    return __lazy('unused/fn45', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model13.schema.doc),
    }))
  },
  get 'unused/fn46'() {
    return __lazy('unused/fn46', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model14.schema.doc),
    }))
  },
  get 'unused/fn47'() {
    return __lazy('unused/fn47', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model15.schema.doc),
    }))
  },
  get 'unused/fn48'() {
    return __lazy('unused/fn48', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model16.schema.doc),
    }))
  },
  get 'unused/fn49'() {
    return __lazy('unused/fn49', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model17.schema.doc),
    }))
  },
  get 'unused/fn50'() {
    return __lazy('unused/fn50', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model18.schema.doc),
    }))
  },
  get 'unused/fn51'() {
    return __lazy('unused/fn51', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model19.schema.doc),
    }))
  },
  get 'unused/fn52'() {
    return __lazy('unused/fn52', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model20.schema.doc),
    }))
  },
  get 'unused/fn53'() {
    return __lazy('unused/fn53', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model21.schema.doc),
    }))
  },
  get 'unused/fn54'() {
    return __lazy('unused/fn54', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model22.schema.doc),
    }))
  },
  get 'unused/fn55'() {
    return __lazy('unused/fn55', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model23.schema.doc),
    }))
  },
  get 'unused/fn56'() {
    return __lazy('unused/fn56', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model24.schema.doc),
    }))
  },
  get 'unused/fn57'() {
    return __lazy('unused/fn57', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model25.schema.doc),
    }))
  },
  get 'unused/fn58'() {
    return __lazy('unused/fn58', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model26.schema.doc),
    }))
  },
  get 'unused/fn59'() {
    return __lazy('unused/fn59', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model27.schema.doc),
    }))
  },
  get 'unused/fn60'() {
    return __lazy('unused/fn60', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model28.schema.doc),
    }))
  },
  get 'unused/fn61'() {
    return __lazy('unused/fn61', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model29.schema.doc),
    }))
  },
  get 'unused/fn62'() {
    return __lazy('unused/fn62', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model30.schema.doc),
    }))
  },
  get 'unused/fn63'() {
    return __lazy('unused/fn63', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model31.schema.doc),
    }))
  },
  get 'unused/fn64'() {
    return __lazy('unused/fn64', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model0.schema.doc),
    }))
  },
  get 'unused/fn65'() {
    return __lazy('unused/fn65', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model1.schema.doc),
    }))
  },
  get 'unused/fn66'() {
    return __lazy('unused/fn66', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model2.schema.doc),
    }))
  },
  get 'unused/fn67'() {
    return __lazy('unused/fn67', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model3.schema.doc),
    }))
  },
  get 'unused/fn68'() {
    return __lazy('unused/fn68', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model4.schema.doc),
    }))
  },
  get 'unused/fn69'() {
    return __lazy('unused/fn69', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model5.schema.doc),
    }))
  },
  get 'unused/fn70'() {
    return __lazy('unused/fn70', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model6.schema.doc),
    }))
  },
  get 'unused/fn71'() {
    return __lazy('unused/fn71', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model7.schema.doc),
    }))
  },
  get 'unused/fn72'() {
    return __lazy('unused/fn72', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model8.schema.doc),
    }))
  },
  get 'unused/fn73'() {
    return __lazy('unused/fn73', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model9.schema.doc),
    }))
  },
  get 'unused/fn74'() {
    return __lazy('unused/fn74', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model10.schema.doc),
    }))
  },
  get 'unused/fn75'() {
    return __lazy('unused/fn75', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model11.schema.doc),
    }))
  },
  get 'unused/fn76'() {
    return __lazy('unused/fn76', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model12.schema.doc),
    }))
  },
  get 'unused/fn77'() {
    return __lazy('unused/fn77', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model13.schema.doc),
    }))
  },
  get 'unused/fn78'() {
    return __lazy('unused/fn78', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model14.schema.doc),
    }))
  },
  get 'unused/fn79'() {
    return __lazy('unused/fn79', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model15.schema.doc),
    }))
  },
  get 'unused/fn80'() {
    return __lazy('unused/fn80', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model16.schema.doc),
    }))
  },
  get 'unused/fn81'() {
    return __lazy('unused/fn81', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model17.schema.doc),
    }))
  },
  get 'unused/fn82'() {
    return __lazy('unused/fn82', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model18.schema.doc),
    }))
  },
  get 'unused/fn83'() {
    return __lazy('unused/fn83', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model19.schema.doc),
    }))
  },
  get 'unused/fn84'() {
    return __lazy('unused/fn84', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model20.schema.doc),
    }))
  },
  get 'unused/fn85'() {
    return __lazy('unused/fn85', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model21.schema.doc),
    }))
  },
  get 'unused/fn86'() {
    return __lazy('unused/fn86', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model22.schema.doc),
    }))
  },
  get 'unused/fn87'() {
    return __lazy('unused/fn87', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model23.schema.doc),
    }))
  },
  get 'unused/fn88'() {
    return __lazy('unused/fn88', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model24.schema.doc),
    }))
  },
  get 'unused/fn89'() {
    return __lazy('unused/fn89', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model25.schema.doc),
    }))
  },
  get 'unused/fn90'() {
    return __lazy('unused/fn90', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model26.schema.doc),
    }))
  },
  get 'unused/fn91'() {
    return __lazy('unused/fn91', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model27.schema.doc),
    }))
  },
  get 'unused/fn92'() {
    return __lazy('unused/fn92', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model28.schema.doc),
    }))
  },
  get 'unused/fn93'() {
    return __lazy('unused/fn93', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model29.schema.doc),
    }))
  },
  get 'unused/fn94'() {
    return __lazy('unused/fn94', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model30.schema.doc),
    }))
  },
  get 'unused/fn95'() {
    return __lazy('unused/fn95', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model31.schema.doc),
    }))
  },
  get 'unused/fn96'() {
    return __lazy('unused/fn96', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model0.schema.doc),
    }))
  },
  get 'unused/fn97'() {
    return __lazy('unused/fn97', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model1.schema.doc),
    }))
  },
  get 'unused/fn98'() {
    return __lazy('unused/fn98', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model2.schema.doc),
    }))
  },
  get 'unused/fn99'() {
    return __lazy('unused/fn99', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model3.schema.doc),
    }))
  },
  get 'unused/fn100'() {
    return __lazy('unused/fn100', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model4.schema.doc),
    }))
  },
  get 'unused/fn101'() {
    return __lazy('unused/fn101', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model5.schema.doc),
    }))
  },
  get 'unused/fn102'() {
    return __lazy('unused/fn102', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model6.schema.doc),
    }))
  },
  get 'unused/fn103'() {
    return __lazy('unused/fn103', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model7.schema.doc),
    }))
  },
  get 'unused/fn104'() {
    return __lazy('unused/fn104', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model8.schema.doc),
    }))
  },
  get 'unused/fn105'() {
    return __lazy('unused/fn105', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model9.schema.doc),
    }))
  },
  get 'unused/fn106'() {
    return __lazy('unused/fn106', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model10.schema.doc),
    }))
  },
  get 'unused/fn107'() {
    return __lazy('unused/fn107', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model11.schema.doc),
    }))
  },
  get 'unused/fn108'() {
    return __lazy('unused/fn108', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model12.schema.doc),
    }))
  },
  get 'unused/fn109'() {
    return __lazy('unused/fn109', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model13.schema.doc),
    }))
  },
  get 'unused/fn110'() {
    return __lazy('unused/fn110', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model14.schema.doc),
    }))
  },
  get 'unused/fn111'() {
    return __lazy('unused/fn111', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model15.schema.doc),
    }))
  },
  get 'unused/fn112'() {
    return __lazy('unused/fn112', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model16.schema.doc),
    }))
  },
  get 'unused/fn113'() {
    return __lazy('unused/fn113', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model17.schema.doc),
    }))
  },
  get 'unused/fn114'() {
    return __lazy('unused/fn114', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model18.schema.doc),
    }))
  },
  get 'unused/fn115'() {
    return __lazy('unused/fn115', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model19.schema.doc),
    }))
  },
  get 'unused/fn116'() {
    return __lazy('unused/fn116', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model20.schema.doc),
    }))
  },
  get 'unused/fn117'() {
    return __lazy('unused/fn117', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model21.schema.doc),
    }))
  },
  get 'unused/fn118'() {
    return __lazy('unused/fn118', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model22.schema.doc),
    }))
  },
  get 'unused/fn119'() {
    return __lazy('unused/fn119', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model23.schema.doc),
    }))
  },
  get 'unused/fn120'() {
    return __lazy('unused/fn120', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model24.schema.doc),
    }))
  },
  get 'unused/fn121'() {
    return __lazy('unused/fn121', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model25.schema.doc),
    }))
  },
  get 'unused/fn122'() {
    return __lazy('unused/fn122', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model26.schema.doc),
    }))
  },
  get 'unused/fn123'() {
    return __lazy('unused/fn123', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model27.schema.doc),
    }))
  },
  get 'unused/fn124'() {
    return __lazy('unused/fn124', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model28.schema.doc),
    }))
  },
  get 'unused/fn125'() {
    return __lazy('unused/fn125', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model29.schema.doc),
    }))
  },
  get 'unused/fn126'() {
    return __lazy('unused/fn126', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model30.schema.doc),
    }))
  },
  get 'unused/fn127'() {
    return __lazy('unused/fn127', () => ({
      args: s.object({
      title: s.string(), description: s.optional(s.string()), score: s.number(), active: s.boolean(),
      status: s.union([s.literal('new'), s.literal('active'), s.literal('done')]),
      profile: s.object({ name: s.string(), age: s.optional(s.number()) }),
      tags: s.array(s.string()), category: s.enum(['a', 'b', 'c']), priority: s.optional(s.number()), parent: s.nullable(s.string()),
    }),
      returns: s.nullable(model31.schema.doc),
    }))
  },
}
