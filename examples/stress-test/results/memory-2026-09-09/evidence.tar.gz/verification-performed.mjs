import {fileURLToPath} from 'node:url'
import {readFileSync,readdirSync} from 'node:fs'
import {createHash} from 'node:crypto'
import {assertGraphResult,decodeMcpResult} from './harness-source/oracle.mjs'
const root=fileURLToPath(new URL('.',import.meta.url))
const finalRuns=['hosted-runtime-control','hosted-width-control','local-heap-width8','local-heap-width32']
let verified=0,failures=0
for(const name of finalRuns){
 for(const line of readFileSync(root+name+'/calls.jsonl','utf8').trim().split('\n')){
  const row=JSON.parse(line), nonce=row.nonce??row.id
  const source=readFileSync(root+name+'/sources/'+nonce+'.js')
  if(createHash('sha256').update(source).digest('hex')!==row.bundleHash) throw new Error('Bundle hash mismatch '+name)
  if(row.diagnosticForcedGc){if(!row.valid)throw new Error('Invalid heap row');assertGraphResult(row.raw.value,{...row,nonce});verified++}
  else if(row.outcome==='ok'){assertGraphResult(decodeMcpResult(row.raw),{...row,nonce});verified++}
  else {if(row.outcome!=='memory'||row.phase!=='query'||!row.raw.isError||!/out of memory/.test(JSON.stringify(row.raw)))throw new Error('Invalid failure');failures++}
 }
}
const prototype=fileURLToPath(new URL('./exploratory/',import.meta.url))
for(const name of ['hosted-boundary.jsonl','hosted-runtime-boundary.jsonl','deployed-calibration.jsonl','deployed-construction-calibration.jsonl']){
 for(const line of readFileSync(prototype+name,'utf8').trim().split('\n')){
  const row=JSON.parse(line)
  if(row.outcome==='ok'){
   assertGraphResult(row.result??decodeMcpResult(row.raw),{...row,width:32,profile:'codec-rich',entries:0,nonce:row.nonce??row.id});verified++
  }else{if(row.outcome!=='memory'||!/out of memory/.test(JSON.stringify(row.raw??row.error)))throw new Error('Invalid exploratory failure '+name);failures++}
 }
}
console.log(JSON.stringify({verifiedOutputs:verified,confirmedMemoryErrors:failures,finalSourceHashesVerified:true}))
