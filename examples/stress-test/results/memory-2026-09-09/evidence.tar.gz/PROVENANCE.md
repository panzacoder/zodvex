# Evidence provenance

Final controls preserve exact emitted query sources and per-call SHA-256 hashes.
All successful final and exploratory outputs were independently rechecked using
memory/oracle.mjs; every reported memory error retains the backend response.

The local heap manifests predate shared dependency/Git provenance collection.
They preserve exact query bundles and the backend binary hash. The containing
summary records the library commit and resolved dependency versions used for
these local and hosted experiments. This supplement is post-run provenance.

Early exploratory boundary logs do not have per-call wall timestamps or emitted
source hashes. Their preserved prototype sources and final ordinary deployed
modules were collected after the experiments. Do not treat them as having the
stronger provenance of the final hosted controls. The final controls reproduce
the central Full-512 runtime failure and width-8 success with exact bundles.

harness-source is the final reviewable source snapshot, including later formatting,
path quoting, error handling and provenance improvements; it is not asserted to be
byte-identical to each earlier driver. Exact measured sources are under each
final run's sources/. No credentials or environment files are included.
