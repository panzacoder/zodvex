var _p = Object.defineProperty;
var s = (e, t) => _p(e, "name", { value: t, configurable: !0 });
var Be = (e, t) => {
  for (var n in t)
    _p(e, n, { get: t[n], enumerable: !0 });
};

// graphProbe.ts
import { query as rk } from "convex:/_system/repl/wrappers.js";

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/base64.js
var Ce = [], Ie = [], Dv = Uint8Array, _a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
for (ht = 0, xp = _a.length; ht < xp; ++ht)
  Ce[ht] = _a[ht], Ie[_a.charCodeAt(ht)] = ht;
var ht, xp;
Ie[45] = 62;
Ie[95] = 63;
function Nv(e) {
  var t = e.length;
  if (t % 4 > 0)
    throw new Error("Invalid string. Length must be a multiple of 4");
  var n = e.indexOf("=");
  n === -1 && (n = t);
  var o = n === t ? 0 : 4 - n % 4;
  return [n, o];
}
s(Nv, "getLens");
function Tv(e, t, n) {
  return (t + n) * 3 / 4 - n;
}
s(Tv, "_byteLength");
function Ar(e) {
  var t, n = Nv(e), o = n[0], r = n[1], i = new Dv(Tv(e, o, r)), a = 0, u = r > 0 ? o - 4 : o, c;
  for (c = 0; c < u; c += 4)
    t = Ie[e.charCodeAt(c)] << 18 | Ie[e.charCodeAt(c + 1)] << 12 | Ie[e.charCodeAt(c + 2)] << 6 | Ie[e.charCodeAt(c + 3)], i[a++] = t >> 16 & 255, i[a++] = t >> 8 & 255, i[a++] = t & 255;
  return r === 2 && (t = Ie[e.charCodeAt(c)] << 2 | Ie[e.charCodeAt(c + 1)] >> 4, i[a++] = t & 255), r === 1 && (t = Ie[e.charCodeAt(c)] << 10 | Ie[e.charCodeAt(c + 1)] << 4 | Ie[e.charCodeAt(c + 2)] >> 2, i[a++] = t >> 8 & 255, i[a++] = t & 255), i;
}
s(Ar, "toByteArray");
function Av(e) {
  return Ce[e >> 18 & 63] + Ce[e >> 12 & 63] + Ce[e >> 6 & 63] + Ce[e & 63];
}
s(Av, "tripletToBase64");
function Uv(e, t, n) {
  for (var o, r = [], i = t; i < n; i += 3)
    o = (e[i] << 16 & 16711680) + (e[i + 1] << 8 & 65280) + (e[i + 2] & 255), r.push(Av(o));
  return r.join("");
}
s(Uv, "encodeChunk");
function Ur(e) {
  for (var t, n = e.length, o = n % 3, r = [], i = 16383, a = 0, u = n - o; a < u; a += i)
    r.push(
      Uv(
        e,
        a,
        a + i > u ? u : a + i
      )
    );
  return o === 1 ? (t = e[n - 1], r.push(Ce[t >> 2] + Ce[t << 4 & 63] + "==")) : o === 2 && (t = (e[n - 2] << 8) + e[n - 1], r.push(
    Ce[t >> 10] + Ce[t >> 4 & 63] + Ce[t << 2 & 63] + "="
  )), r.join("");
}
s(Ur, "fromByteArray");

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/common/index.js
function Ke(e) {
  if (e === void 0)
    return {};
  if (!Fn(e))
    throw new Error(
      `The arguments to a Convex function must be an object. Received: ${e}`
    );
  return e;
}
s(Ke, "parseArgs");
function Fn(e) {
  let t = typeof e == "object", n = Object.getPrototypeOf(e), o = n === null || n === Object.prototype || // Objects generated from other contexts (e.g. across Node.js `vm` modules) will not satisfy the previous
  // conditions but are still simple objects.
  n?.constructor?.name === "Object";
  return t && o;
}
s(Fn, "isSimpleObject");

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/value.js
var zp = !0, Vt = BigInt("-9223372036854775808"), Ia = BigInt("9223372036854775807"), wa = BigInt("0"), Ev = BigInt("8"), Cv = BigInt("256");
function Sp(e) {
  return Number.isNaN(e) || !Number.isFinite(e) || Object.is(e, -0);
}
s(Sp, "isSpecial");
function Zv(e) {
  e < wa && (e -= Vt + Vt);
  let t = e.toString(16);
  t.length % 2 === 1 && (t = "0" + t);
  let n = new Uint8Array(new ArrayBuffer(8)), o = 0;
  for (let r of t.match(/.{2}/g).reverse())
    n.set([parseInt(r, 16)], o++), e >>= Ev;
  return Ur(n);
}
s(Zv, "slowBigIntToBase64");
function Rv(e) {
  let t = Ar(e);
  if (t.byteLength !== 8)
    throw new Error(
      `Received ${t.byteLength} bytes, expected 8 for $integer`
    );
  let n = wa, o = wa;
  for (let r of t)
    n += BigInt(r) * Cv ** o, o++;
  return n > Ia && (n += Vt + Vt), n;
}
s(Rv, "slowBase64ToBigInt");
function Fv(e) {
  if (e < Vt || Ia < e)
    throw new Error(
      `BigInt ${e} does not fit into a 64-bit signed integer.`
    );
  let t = new ArrayBuffer(8);
  return new DataView(t).setBigInt64(0, e, !0), Ur(new Uint8Array(t));
}
s(Fv, "modernBigIntToBase64");
function Lv(e) {
  let t = Ar(e);
  if (t.byteLength !== 8)
    throw new Error(
      `Received ${t.byteLength} bytes, expected 8 for $integer`
    );
  return new DataView(t.buffer).getBigInt64(0, !0);
}
s(Lv, "modernBase64ToBigInt");
var Vv = DataView.prototype.setBigInt64 ? Fv : Zv, Mv = DataView.prototype.getBigInt64 ? Lv : Rv, kp = 1024;
function ka(e) {
  if (e.length > kp)
    throw new Error(
      `Field name ${e} exceeds maximum field name length ${kp}.`
    );
  if (e.startsWith("$"))
    throw new Error(`Field name ${e} starts with a '$', which is reserved.`);
  for (let t = 0; t < e.length; t += 1) {
    let n = e.charCodeAt(t);
    if (n < 32 || n >= 127)
      throw new Error(
        `Field name ${e} has invalid character '${e[t]}': Field names can only contain non-control ASCII characters`
      );
  }
}
s(ka, "validateObjectField");
function Q(e) {
  if (e === null || typeof e == "boolean" || typeof e == "number" || typeof e == "string")
    return e;
  if (Array.isArray(e))
    return e.map((o) => Q(o));
  if (typeof e != "object")
    throw new Error(`Unexpected type of ${e}`);
  let t = Object.entries(e);
  if (t.length === 1) {
    let o = t[0][0];
    if (o === "$bytes") {
      if (typeof e.$bytes != "string")
        throw new Error(`Malformed $bytes field on ${e}`);
      return Ar(e.$bytes).buffer;
    }
    if (o === "$integer") {
      if (typeof e.$integer != "string")
        throw new Error(`Malformed $integer field on ${e}`);
      return Mv(e.$integer);
    }
    if (o === "$float") {
      if (typeof e.$float != "string")
        throw new Error(`Malformed $float field on ${e}`);
      let r = Ar(e.$float);
      if (r.byteLength !== 8)
        throw new Error(
          `Received ${r.byteLength} bytes, expected 8 for $float`
        );
      let a = new DataView(r.buffer).getFloat64(0, zp);
      if (!Sp(a))
        throw new Error(`Float ${a} should be encoded as a number`);
      return a;
    }
    if (o === "$set")
      throw new Error(
        "Received a Set which is no longer supported as a Convex type."
      );
    if (o === "$map")
      throw new Error(
        "Received a Map which is no longer supported as a Convex type."
      );
  }
  let n = {};
  for (let [o, r] of Object.entries(e))
    ka(o), n[o] = Q(r);
  return n;
}
s(Q, "jsonToConvex");
var Ip = 16384;
function vt(e) {
  let t = JSON.stringify(e, (n, o) => o === void 0 ? "undefined" : typeof o == "bigint" ? `${o.toString()}n` : o);
  if (t.length > Ip) {
    let n = "[...truncated]", o = Ip - n.length, r = t.codePointAt(o - 1);
    return r !== void 0 && r > 65535 && (o -= 1), t.substring(0, o) + n;
  }
  return t;
}
s(vt, "stringifyValueForError");
function Er(e, t, n, o) {
  if (e === void 0) {
    let a = n && ` (present at path ${n} in original object ${vt(
      t
    )})`;
    throw new Error(
      `undefined is not a valid Convex value${a}. To learn about Convex's supported types, see https://docs.convex.dev/using/types.`
    );
  }
  if (e === null)
    return e;
  if (typeof e == "bigint") {
    if (e < Vt || Ia < e)
      throw new Error(
        `BigInt ${e} does not fit into a 64-bit signed integer.`
      );
    return { $integer: Vv(e) };
  }
  if (typeof e == "number")
    if (Sp(e)) {
      let a = new ArrayBuffer(8);
      return new DataView(a).setFloat64(0, e, zp), { $float: Ur(new Uint8Array(a)) };
    } else
      return e;
  if (typeof e == "boolean" || typeof e == "string")
    return e;
  if (e instanceof ArrayBuffer)
    return { $bytes: Ur(new Uint8Array(e)) };
  if (Array.isArray(e))
    return e.map(
      (a, u) => Er(a, t, n + `[${u}]`, !1)
    );
  if (e instanceof Set)
    throw new Error(
      xa(n, "Set", [...e], t)
    );
  if (e instanceof Map)
    throw new Error(
      xa(n, "Map", [...e], t)
    );
  if (!Fn(e)) {
    let a = e?.constructor?.name, u = a ? `${a} ` : "";
    throw new Error(
      xa(n, u, e, t)
    );
  }
  let r = {}, i = Object.entries(e);
  i.sort(([a, u], [c, l]) => a === c ? 0 : a < c ? -1 : 1);
  for (let [a, u] of i)
    u !== void 0 ? (ka(a), r[a] = Er(u, t, n + `.${a}`, !1)) : o && (ka(a), r[a] = Op(
      u,
      t,
      n + `.${a}`
    ));
  return r;
}
s(Er, "convexToJsonInternal");
function xa(e, t, n, o) {
  return e ? `${t}${vt(
    n
  )} is not a supported Convex type (present at path ${e} in original object ${vt(
    o
  )}). To learn about Convex's supported types, see https://docs.convex.dev/using/types.` : `${t}${vt(
    n
  )} is not a supported Convex type.`;
}
s(xa, "errorMessageForUnsupportedType");
function Op(e, t, n) {
  if (e === void 0)
    return { $undefined: null };
  if (t === void 0)
    throw new Error(
      `Programming error. Current value is ${vt(
        e
      )} but original value is undefined`
    );
  return Er(e, t, n, !1);
}
s(Op, "convexOrUndefinedToJsonInternal");
function G(e) {
  return Er(e, e, "", !1);
}
s(G, "convexToJson");
function ze(e) {
  return Op(e, e, "");
}
s(ze, "convexOrUndefinedToJson");
function jp(e) {
  return Er(e, e, "", !0);
}
s(jp, "patchValueToJson");

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/validators.js
var Bv = Object.defineProperty, Jv = /* @__PURE__ */ s((e, t, n) => t in e ? Bv(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), X = /* @__PURE__ */ s((e, t, n) => Jv(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), qv = "https://docs.convex.dev/error#undefined-validator";
function Cr(e, t) {
  let n = t !== void 0 ? ` for field "${t}"` : "";
  throw new Error(
    `A validator is undefined${n} in ${e}. This is often caused by circular imports. See ${qv} for details.`
  );
}
s(Cr, "throwUndefinedValidatorError");
var ue = class {
  static {
    s(this, "BaseValidator");
  }
  constructor({ isOptional: t }) {
    X(this, "type"), X(this, "fieldPaths"), X(this, "isOptional"), X(this, "isConvexValidator"), this.isOptional = t, this.isConvexValidator = !0;
  }
}, Ln = class e extends ue {
  static {
    s(this, "VId");
  }
  /**
   * Usually you'd use `v.id(tableName)` instead.
   */
  constructor({
    isOptional: t,
    tableName: n
  }) {
    if (super({ isOptional: t }), X(this, "tableName"), X(this, "kind", "id"), typeof n != "string")
      throw new Error("v.id(tableName) requires a string");
    this.tableName = n;
  }
  /** @internal */
  get json() {
    return { type: "id", tableName: this.tableName };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      tableName: this.tableName
    });
  }
}, Zr = class e extends ue {
  static {
    s(this, "VFloat64");
  }
  constructor() {
    super(...arguments), X(this, "kind", "float64");
  }
  /** @internal */
  get json() {
    return { type: "number" };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, Rr = class e extends ue {
  static {
    s(this, "VInt64");
  }
  constructor() {
    super(...arguments), X(this, "kind", "int64");
  }
  /** @internal */
  get json() {
    return { type: "bigint" };
  }
  /** @internal */
  asOptional() {
    return new e({ isOptional: "optional" });
  }
}, Vn = class e extends ue {
  static {
    s(this, "VBoolean");
  }
  constructor() {
    super(...arguments), X(this, "kind", "boolean");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, Mn = class e extends ue {
  static {
    s(this, "VBytes");
  }
  constructor() {
    super(...arguments), X(this, "kind", "bytes");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({ isOptional: "optional" });
  }
}, Bn = class e extends ue {
  static {
    s(this, "VString");
  }
  constructor() {
    super(...arguments), X(this, "kind", "string");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, Jn = class e extends ue {
  static {
    s(this, "VNull");
  }
  constructor() {
    super(...arguments), X(this, "kind", "null");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({ isOptional: "optional" });
  }
}, qn = class e extends ue {
  static {
    s(this, "VAny");
  }
  constructor() {
    super(...arguments), X(this, "kind", "any");
  }
  /** @internal */
  get json() {
    return {
      type: this.kind
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, Wn = class e extends ue {
  static {
    s(this, "VObject");
  }
  /**
   * Usually you'd use `v.object({ ... })` instead.
   */
  constructor({
    isOptional: t,
    fields: n
  }) {
    super({ isOptional: t }), X(this, "fields"), X(this, "kind", "object"), globalThis.Object.entries(n).forEach(([o, r]) => {
      if (r === void 0 && Cr("v.object()", o), !r.isConvexValidator)
        throw new Error("v.object() entries must be validators");
    }), this.fields = n;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: globalThis.Object.fromEntries(
        globalThis.Object.entries(this.fields).map(([t, n]) => [
          t,
          {
            fieldType: n.json,
            optional: n.isOptional === "optional"
          }
        ])
      )
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      fields: this.fields
    });
  }
  /**
   * Create a new VObject with the specified fields omitted.
   * @param fields The field names to omit from this VObject.
   */
  omit(...t) {
    let n = { ...this.fields };
    for (let o of t)
      delete n[o];
    return new e({
      isOptional: this.isOptional,
      fields: n
    });
  }
  /**
   * Create a new VObject with only the specified fields.
   * @param fields The field names to pick from this VObject.
   */
  pick(...t) {
    let n = {};
    for (let o of t)
      n[o] = this.fields[o];
    return new e({
      isOptional: this.isOptional,
      fields: n
    });
  }
  /**
   * Create a new VObject with all fields marked as optional.
   */
  partial() {
    let t = {};
    for (let [n, o] of globalThis.Object.entries(this.fields))
      t[n] = o.asOptional();
    return new e({
      isOptional: this.isOptional,
      fields: t
    });
  }
  /**
   * Create a new VObject with additional fields merged in.
   * @param fields An object with additional validators to merge into this VObject.
   */
  extend(t) {
    return new e({
      isOptional: this.isOptional,
      fields: { ...this.fields, ...t }
    });
  }
}, Kn = class e extends ue {
  static {
    s(this, "VLiteral");
  }
  /**
   * Usually you'd use `v.literal(value)` instead.
   */
  constructor({ isOptional: t, value: n }) {
    if (super({ isOptional: t }), X(this, "value"), X(this, "kind", "literal"), typeof n != "string" && typeof n != "boolean" && typeof n != "number" && typeof n != "bigint")
      throw new Error("v.literal(value) must be a string, number, or boolean");
    this.value = n;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: G(this.value)
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      value: this.value
    });
  }
}, Gn = class e extends ue {
  static {
    s(this, "VArray");
  }
  /**
   * Usually you'd use `v.array(element)` instead.
   */
  constructor({
    isOptional: t,
    element: n
  }) {
    super({ isOptional: t }), X(this, "element"), X(this, "kind", "array"), n === void 0 && Cr("v.array()"), this.element = n;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: this.element.json
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      element: this.element
    });
  }
}, Xn = class e extends ue {
  static {
    s(this, "VRecord");
  }
  /**
   * Usually you'd use `v.record(key, value)` instead.
   */
  constructor({
    isOptional: t,
    key: n,
    value: o
  }) {
    if (super({ isOptional: t }), X(this, "key"), X(this, "value"), X(this, "kind", "record"), n === void 0 && Cr("v.record()", "key"), o === void 0 && Cr("v.record()", "value"), n.isOptional === "optional")
      throw new Error("Record validator cannot have optional keys");
    if (o.isOptional === "optional")
      throw new Error("Record validator cannot have optional values");
    if (!n.isConvexValidator || !o.isConvexValidator)
      throw new Error("Key and value of v.record() but be validators");
    this.key = n, this.value = o;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      // This cast is needed because TypeScript thinks the key type is too wide
      keys: this.key.json,
      values: {
        fieldType: this.value.json,
        optional: !1
      }
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      key: this.key,
      value: this.value
    });
  }
}, Hn = class e extends ue {
  static {
    s(this, "VUnion");
  }
  /**
   * Usually you'd use `v.union(...members)` instead.
   */
  constructor({ isOptional: t, members: n }) {
    super({ isOptional: t }), X(this, "members"), X(this, "kind", "union"), n.forEach((o, r) => {
      if (o === void 0 && Cr("v.union()", `member at index ${r}`), !o.isConvexValidator)
        throw new Error("All members of v.union() must be validators");
    }), this.members = n;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: this.members.map((t) => t.json)
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      members: this.members
    });
  }
};

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/validator.js
function za(e) {
  return !!e.isConvexValidator;
}
s(za, "isValidator");
function Fr(e) {
  return za(e) ? e : y.object(e);
}
s(Fr, "asObjectValidator");
var y = {
  /**
   * Validates that the value is a document ID for the given table.
   *
   * IDs are strings at runtime but are typed as `Id<"tableName">` in
   * TypeScript for type safety.
   *
   * @example
   * ```typescript
   * args: { userId: v.id("users") }
   * ```
   *
   * @param tableName The name of the table.
   */
  id: /* @__PURE__ */ s((e) => new Ln({
    isOptional: "required",
    tableName: e
  }), "id"),
  /**
   * Validates that the value is `null`.
   *
   * Use `returns: v.null()` for functions that don't return a meaningful value.
   * JavaScript `undefined` is not a valid Convex value, it is automatically
   * converted to `null`.
   */
  null: /* @__PURE__ */ s(() => new Jn({ isOptional: "required" }), "null"),
  /**
   * Validates that the value is a JavaScript `number` (Convex Float64).
   *
   * Supports all IEEE-754 double-precision floating point numbers including
   * NaN and Infinity.
   *
   * Alias for `v.float64()`.
   */
  number: /* @__PURE__ */ s(() => new Zr({ isOptional: "required" }), "number"),
  /**
   * Validates that the value is a JavaScript `number` (Convex Float64).
   *
   * Supports all IEEE-754 double-precision floating point numbers.
   */
  float64: /* @__PURE__ */ s(() => new Zr({ isOptional: "required" }), "float64"),
  /**
   * @deprecated Use `v.int64()` instead.
   */
  bigint: /* @__PURE__ */ s(() => new Rr({ isOptional: "required" }), "bigint"),
  /**
   * Validates that the value is a JavaScript `bigint` (Convex Int64).
   *
   * Supports BigInts between -2^63 and 2^63-1.
   *
   * @example
   * ```typescript
   * args: { timestamp: v.int64() }
   * // Usage: createDoc({ timestamp: 1234567890n })
   * ```
   */
  int64: /* @__PURE__ */ s(() => new Rr({ isOptional: "required" }), "int64"),
  /**
   * Validates that the value is a `boolean`.
   */
  boolean: /* @__PURE__ */ s(() => new Vn({ isOptional: "required" }), "boolean"),
  /**
   * Validates that the value is a `string`.
   *
   * Strings are stored as UTF-8 and their storage size is calculated as their
   * UTF-8 encoded size.
   */
  string: /* @__PURE__ */ s(() => new Bn({ isOptional: "required" }), "string"),
  /**
   * Validates that the value is an `ArrayBuffer` (Convex Bytes).
   *
   * Use for binary data.
   */
  bytes: /* @__PURE__ */ s(() => new Mn({ isOptional: "required" }), "bytes"),
  /**
   * Validates that the value is exactly equal to the given literal.
   *
   * Useful for discriminated unions and enum-like patterns.
   *
   * @example
   * ```typescript
   * // Discriminated union pattern:
   * v.union(
   *   v.object({ kind: v.literal("error"), message: v.string() }),
   *   v.object({ kind: v.literal("success"), value: v.number() }),
   * )
   * ```
   *
   * @param literal The literal value to compare against.
   */
  literal: /* @__PURE__ */ s((e) => new Kn({ isOptional: "required", value: e }), "literal"),
  /**
   * Validates that the value is an `Array` where every element matches the
   * given validator.
   *
   * Arrays can have at most 8192 elements.
   *
   * @example
   * ```typescript
   * args: { tags: v.array(v.string()) }
   * args: { coordinates: v.array(v.number()) }
   * args: { items: v.array(v.object({ name: v.string(), qty: v.number() })) }
   * ```
   *
   * @param element The validator for the elements of the array.
   */
  array: /* @__PURE__ */ s((e) => new Gn({ isOptional: "required", element: e }), "array"),
  /**
   * Validates that the value is an `Object` with the specified properties.
   *
   * Objects can have at most 1024 entries. Field names must be non-empty and
   * must not start with `"$"` or `"_"` (`_` is reserved for system fields
   * like `_id` and `_creationTime`; `$` is reserved for Convex internal use).
   *
   * @example
   * ```typescript
   * args: {
   *   user: v.object({
   *     name: v.string(),
   *     email: v.string(),
   *     age: v.optional(v.number()),
   *   })
   * }
   * ```
   *
   * @param fields An object mapping property names to their validators.
   */
  object: /* @__PURE__ */ s((e) => new Wn({ isOptional: "required", fields: e }), "object"),
  /**
   * Validates that the value is a `Record` (object with dynamic keys).
   *
   * Records are objects at runtime but allow dynamic keys, unlike `v.object()`
   * which requires known property names. Keys must be ASCII characters only,
   * non-empty, and not start with `"$"` or `"_"`.
   *
   * @example
   * ```typescript
   * // Map of user IDs to scores:
   * args: { scores: v.record(v.id("users"), v.number()) }
   *
   * // Map of string keys to string values:
   * args: { metadata: v.record(v.string(), v.string()) }
   * ```
   *
   * @param keys The validator for the keys of the record.
   * @param values The validator for the values of the record.
   */
  record: /* @__PURE__ */ s((e, t) => new Xn({
    isOptional: "required",
    key: e,
    value: t
  }), "record"),
  /**
   * Validates that the value matches at least one of the given validators.
   *
   * @example
   * ```typescript
   * // Allow string or number:
   * args: { value: v.union(v.string(), v.number()) }
   *
   * // Discriminated union (recommended pattern):
   * v.union(
   *   v.object({ kind: v.literal("text"), body: v.string() }),
   *   v.object({ kind: v.literal("image"), url: v.string() }),
   * )
   *
   * // Nullable value:
   * returns: v.union(v.object({ ... }), v.null())
   * ```
   *
   * @param members The validators to match against.
   */
  union: /* @__PURE__ */ s((...e) => new Hn({
    isOptional: "required",
    members: e
  }), "union"),
  /**
   * A validator that accepts any Convex value without validation.
   *
   * Prefer using specific validators when possible for better type safety
   * and runtime validation.
   */
  any: /* @__PURE__ */ s(() => new qn({ isOptional: "required" }), "any"),
  /**
   * Makes a property optional in an object validator.
   *
   * An optional property can be omitted entirely when creating a document or
   * calling a function. This is different from `v.nullable()` which requires
   * the property to be present but allows `null`.
   *
   * @example
   * ```typescript
   * v.object({
   *   name: v.string(),              // required
   *   nickname: v.optional(v.string()), // can be omitted
   * })
   *
   * // Valid: { name: "Alice" }
   * // Valid: { name: "Alice", nickname: "Ali" }
   * // Invalid: { name: "Alice", nickname: null }  - use v.nullable() for this
   * ```
   *
   * @param value The property value validator to make optional.
   */
  optional: /* @__PURE__ */ s((e) => e.asOptional(), "optional"),
  /**
   * Allows a value to be either the given type or `null`.
   *
   * This is shorthand for `v.union(value, v.null())`. Unlike `v.optional()`,
   * the property must still be present, but may be `null`.
   *
   * @example
   * ```typescript
   * v.object({
   *   name: v.string(),
   *   deletedAt: v.nullable(v.number()), // must be present, can be null
   * })
   *
   * // Valid: { name: "Alice", deletedAt: null }
   * // Valid: { name: "Alice", deletedAt: 1234567890 }
   * // Invalid: { name: "Alice" }  - deletedAt is required
   * ```
   */
  nullable: /* @__PURE__ */ s((e) => y.union(e, y.null()), "nullable")
};

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/errors.js
var Wv = Object.defineProperty, Kv = /* @__PURE__ */ s((e, t, n) => t in e ? Wv(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), Sa = /* @__PURE__ */ s((e, t, n) => Kv(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), Pp, Dp, Gv = Symbol.for("ConvexError"), Mt = class extends (Dp = Error, Pp = Gv, Dp) {
  static {
    s(this, "ConvexError");
  }
  constructor(t) {
    super(typeof t == "string" ? t : vt(t)), Sa(this, "name", "ConvexError"), Sa(this, "data"), Sa(this, Pp, !0), this.data = t;
  }
};

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/compare_utf8.js
var Np = /* @__PURE__ */ s(() => Array.from({ length: 4 }, () => 0), "arr"), wk = Np(), kk = Np();

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/index.js
var ne = "1.32.0";

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/syscall.js
function Lr(e, t) {
  if (typeof Convex > "u" || Convex.syscall === void 0)
    throw new Error(
      "The Convex database and auth objects are being used outside of a Convex backend. Did you mean to use `useQuery` or `useMutation` to call a Convex function?"
    );
  let n = Convex.syscall(e, JSON.stringify(t));
  return JSON.parse(n);
}
s(Lr, "performSyscall");
async function L(e, t) {
  if (typeof Convex > "u" || Convex.asyncSyscall === void 0)
    throw new Error(
      "The Convex database and auth objects are being used outside of a Convex backend. Did you mean to use `useQuery` or `useMutation` to call a Convex function?"
    );
  let n;
  try {
    n = await Convex.asyncSyscall(e, JSON.stringify(t));
  } catch (o) {
    if (o.data !== void 0) {
      let r = new Mt(o.message);
      throw r.data = Q(o.data), r;
    }
    throw new Error(o.message);
  }
  return JSON.parse(n);
}
s(L, "performAsyncSyscall");
function Qn(e, t) {
  if (typeof Convex > "u" || Convex.jsSyscall === void 0)
    throw new Error(
      "The Convex database and auth objects are being used outside of a Convex backend. Did you mean to use `useQuery` or `useMutation` to call a Convex function?"
    );
  return Convex.jsSyscall(e, t);
}
s(Qn, "performJsSyscall");

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/functionName.js
var Vr = Symbol.for("functionName");

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/components/paths.js
var Tp = Symbol.for("toReferencePath");
function Hv(e) {
  return e[Tp] ?? null;
}
s(Hv, "extractReferencePath");
function Qv(e) {
  return e.startsWith("function://");
}
s(Qv, "isFunctionHandle");
function je(e) {
  let t;
  if (typeof e == "string")
    Qv(e) ? t = { functionHandle: e } : t = { name: e };
  else if (e[Vr])
    t = { name: e[Vr] };
  else {
    let n = Hv(e);
    if (!n)
      throw new Error(`${e} is not a functionReference`);
    t = { reference: n };
  }
  return t;
}
s(je, "getFunctionAddress");

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/actions_impl.js
function Oa(e, t, n) {
  return {
    ...je(t),
    args: G(Ke(n)),
    version: ne,
    requestId: e
  };
}
s(Oa, "syscallArgs");
function Ap(e) {
  return {
    runQuery: /* @__PURE__ */ s(async (t, n) => {
      let o = await L(
        "1.0/actions/query",
        Oa(e, t, n)
      );
      return Q(o);
    }, "runQuery"),
    runMutation: /* @__PURE__ */ s(async (t, n) => {
      let o = await L(
        "1.0/actions/mutation",
        Oa(e, t, n)
      );
      return Q(o);
    }, "runMutation"),
    runAction: /* @__PURE__ */ s(async (t, n) => {
      let o = await L(
        "1.0/actions/action",
        Oa(e, t, n)
      );
      return Q(o);
    }, "runAction")
  };
}
s(Ap, "setupActionCalls");

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/vector_search.js
var Yv = Object.defineProperty, ey = /* @__PURE__ */ s((e, t, n) => t in e ? Yv(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), Up = /* @__PURE__ */ s((e, t, n) => ey(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), Yn = class {
  static {
    s(this, "FilterExpression");
  }
  /**
   * @internal
   */
  constructor() {
    Up(this, "_isExpression"), Up(this, "_value");
  }
};

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/validate.js
function F(e, t, n, o) {
  if (e === void 0)
    throw new TypeError(
      `Must provide arg ${t} \`${o}\` to \`${n}\``
    );
}
s(F, "validateArg");
function Ep(e, t, n, o) {
  if (!Number.isInteger(e) || e < 0)
    throw new TypeError(
      `Arg ${t} \`${o}\` to \`${n}\` must be a non-negative integer`
    );
}
s(Ep, "validateArgIsNonNegativeInteger");

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/vector_search_impl.js
var ty = Object.defineProperty, ry = /* @__PURE__ */ s((e, t, n) => t in e ? ty(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), ja = /* @__PURE__ */ s((e, t, n) => ry(e, typeof t != "symbol" ? t + "" : t, n), "__publicField");
function Cp(e) {
  return async (t, n, o) => {
    if (F(t, 1, "vectorSearch", "tableName"), F(n, 2, "vectorSearch", "indexName"), F(o, 3, "vectorSearch", "query"), !o.vector || !Array.isArray(o.vector) || o.vector.length === 0)
      throw Error("`vector` must be a non-empty Array in vectorSearch");
    return await new Pa(
      e,
      t + "." + n,
      o
    ).collect();
  };
}
s(Cp, "setupActionVectorSearch");
var Pa = class {
  static {
    s(this, "VectorQueryImpl");
  }
  constructor(t, n, o) {
    ja(this, "requestId"), ja(this, "state"), this.requestId = t;
    let r = o.filter ? ei(o.filter(ny)) : null;
    this.state = {
      type: "preparing",
      query: {
        indexName: n,
        limit: o.limit,
        vector: o.vector,
        expressions: r
      }
    };
  }
  async collect() {
    if (this.state.type === "consumed")
      throw new Error("This query is closed and can't emit any more values.");
    let t = this.state.query;
    this.state = { type: "consumed" };
    let { results: n } = await L("1.0/actions/vectorSearch", {
      requestId: this.requestId,
      version: ne,
      query: t
    });
    return n;
  }
}, Bt = class extends Yn {
  static {
    s(this, "ExpressionImpl");
  }
  constructor(t) {
    super(), ja(this, "inner"), this.inner = t;
  }
  serialize() {
    return this.inner;
  }
};
function ei(e) {
  return e instanceof Bt ? e.serialize() : { $literal: ze(e) };
}
s(ei, "serializeExpression");
var ny = {
  //  Comparisons  /////////////////////////////////////////////////////////////
  eq(e, t) {
    if (typeof e != "string")
      throw new Error("The first argument to `q.eq` must be a field name.");
    return new Bt({
      $eq: [
        ei(new Bt({ $field: e })),
        ei(t)
      ]
    });
  },
  //  Logic  ///////////////////////////////////////////////////////////////////
  or(...e) {
    return new Bt({ $or: e.map(ei) });
  }
};

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/authentication_impl.js
function ti(e) {
  return {
    getUserIdentity: /* @__PURE__ */ s(async () => await L("1.0/getUserIdentity", {
      requestId: e
    }), "getUserIdentity")
  };
}
s(ti, "setupAuth");

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/filter_builder.js
var iy = Object.defineProperty, oy = /* @__PURE__ */ s((e, t, n) => t in e ? iy(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), Zp = /* @__PURE__ */ s((e, t, n) => oy(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), ri = class {
  static {
    s(this, "Expression");
  }
  /**
   * @internal
   */
  constructor() {
    Zp(this, "_isExpression"), Zp(this, "_value");
  }
};

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/filter_builder_impl.js
var ay = Object.defineProperty, sy = /* @__PURE__ */ s((e, t, n) => t in e ? ay(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), uy = /* @__PURE__ */ s((e, t, n) => sy(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), ie = class extends ri {
  static {
    s(this, "ExpressionImpl");
  }
  constructor(t) {
    super(), uy(this, "inner"), this.inner = t;
  }
  serialize() {
    return this.inner;
  }
};
function J(e) {
  return e instanceof ie ? e.serialize() : { $literal: ze(e) };
}
s(J, "serializeExpression");
var Rp = {
  //  Comparisons  /////////////////////////////////////////////////////////////
  eq(e, t) {
    return new ie({
      $eq: [J(e), J(t)]
    });
  },
  neq(e, t) {
    return new ie({
      $neq: [J(e), J(t)]
    });
  },
  lt(e, t) {
    return new ie({
      $lt: [J(e), J(t)]
    });
  },
  lte(e, t) {
    return new ie({
      $lte: [J(e), J(t)]
    });
  },
  gt(e, t) {
    return new ie({
      $gt: [J(e), J(t)]
    });
  },
  gte(e, t) {
    return new ie({
      $gte: [J(e), J(t)]
    });
  },
  //  Arithmetic  //////////////////////////////////////////////////////////////
  add(e, t) {
    return new ie({
      $add: [J(e), J(t)]
    });
  },
  sub(e, t) {
    return new ie({
      $sub: [J(e), J(t)]
    });
  },
  mul(e, t) {
    return new ie({
      $mul: [J(e), J(t)]
    });
  },
  div(e, t) {
    return new ie({
      $div: [J(e), J(t)]
    });
  },
  mod(e, t) {
    return new ie({
      $mod: [J(e), J(t)]
    });
  },
  neg(e) {
    return new ie({ $neg: J(e) });
  },
  //  Logic  ///////////////////////////////////////////////////////////////////
  and(...e) {
    return new ie({ $and: e.map(J) });
  },
  or(...e) {
    return new ie({ $or: e.map(J) });
  },
  not(e) {
    return new ie({ $not: J(e) });
  },
  //  Other  ///////////////////////////////////////////////////////////////////
  field(e) {
    return new ie({ $field: e });
  }
};

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/index_range_builder.js
var cy = Object.defineProperty, ly = /* @__PURE__ */ s((e, t, n) => t in e ? cy(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), dy = /* @__PURE__ */ s((e, t, n) => ly(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), ni = class {
  static {
    s(this, "IndexRange");
  }
  /**
   * @internal
   */
  constructor() {
    dy(this, "_isIndexRange");
  }
};

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/index_range_builder_impl.js
var fy = Object.defineProperty, py = /* @__PURE__ */ s((e, t, n) => t in e ? fy(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), Fp = /* @__PURE__ */ s((e, t, n) => py(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), ii = class e extends ni {
  static {
    s(this, "IndexRangeBuilderImpl");
  }
  constructor(t) {
    super(), Fp(this, "rangeExpressions"), Fp(this, "isConsumed"), this.rangeExpressions = t, this.isConsumed = !1;
  }
  static new() {
    return new e([]);
  }
  consume() {
    if (this.isConsumed)
      throw new Error(
        "IndexRangeBuilder has already been used! Chain your method calls like `q => q.eq(...).eq(...)`. See https://docs.convex.dev/using/indexes"
      );
    this.isConsumed = !0;
  }
  eq(t, n) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Eq",
        fieldPath: t,
        value: ze(n)
      })
    );
  }
  gt(t, n) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Gt",
        fieldPath: t,
        value: ze(n)
      })
    );
  }
  gte(t, n) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Gte",
        fieldPath: t,
        value: ze(n)
      })
    );
  }
  lt(t, n) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Lt",
        fieldPath: t,
        value: ze(n)
      })
    );
  }
  lte(t, n) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Lte",
        fieldPath: t,
        value: ze(n)
      })
    );
  }
  export() {
    return this.consume(), this.rangeExpressions;
  }
};

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/search_filter_builder.js
var my = Object.defineProperty, gy = /* @__PURE__ */ s((e, t, n) => t in e ? my(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), hy = /* @__PURE__ */ s((e, t, n) => gy(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), oi = class {
  static {
    s(this, "SearchFilter");
  }
  /**
   * @internal
   */
  constructor() {
    hy(this, "_isSearchFilter");
  }
};

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/search_filter_builder_impl.js
var vy = Object.defineProperty, yy = /* @__PURE__ */ s((e, t, n) => t in e ? vy(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), Lp = /* @__PURE__ */ s((e, t, n) => yy(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), ai = class e extends oi {
  static {
    s(this, "SearchFilterBuilderImpl");
  }
  constructor(t) {
    super(), Lp(this, "filters"), Lp(this, "isConsumed"), this.filters = t, this.isConsumed = !1;
  }
  static new() {
    return new e([]);
  }
  consume() {
    if (this.isConsumed)
      throw new Error(
        "SearchFilterBuilder has already been used! Chain your method calls like `q => q.search(...).eq(...)`."
      );
    this.isConsumed = !0;
  }
  search(t, n) {
    return F(t, 1, "search", "fieldName"), F(n, 2, "search", "query"), this.consume(), new e(
      this.filters.concat({
        type: "Search",
        fieldPath: t,
        value: n
      })
    );
  }
  eq(t, n) {
    return F(t, 1, "eq", "fieldName"), arguments.length !== 2 && F(n, 2, "search", "value"), this.consume(), new e(
      this.filters.concat({
        type: "Eq",
        fieldPath: t,
        value: ze(n)
      })
    );
  }
  export() {
    return this.consume(), this.filters;
  }
};

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/query_impl.js
var $y = Object.defineProperty, by = /* @__PURE__ */ s((e, t, n) => t in e ? $y(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), Da = /* @__PURE__ */ s((e, t, n) => by(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), Vp = 256, Jt = class {
  static {
    s(this, "QueryInitializerImpl");
  }
  constructor(t) {
    Da(this, "tableName"), this.tableName = t;
  }
  withIndex(t, n) {
    F(t, 1, "withIndex", "indexName");
    let o = ii.new();
    return n !== void 0 && (o = n(o)), new yt({
      source: {
        type: "IndexRange",
        indexName: this.tableName + "." + t,
        range: o.export(),
        order: null
      },
      operators: []
    });
  }
  withSearchIndex(t, n) {
    F(t, 1, "withSearchIndex", "indexName"), F(n, 2, "withSearchIndex", "searchFilter");
    let o = ai.new();
    return new yt({
      source: {
        type: "Search",
        indexName: this.tableName + "." + t,
        filters: n(o).export()
      },
      operators: []
    });
  }
  fullTableScan() {
    return new yt({
      source: {
        type: "FullTableScan",
        tableName: this.tableName,
        order: null
      },
      operators: []
    });
  }
  order(t) {
    return this.fullTableScan().order(t);
  }
  // This is internal API and should not be exposed to developers yet.
  async count() {
    let t = await L("1.0/count", {
      table: this.tableName
    });
    return Q(t);
  }
  filter(t) {
    return this.fullTableScan().filter(t);
  }
  limit(t) {
    return this.fullTableScan().limit(t);
  }
  collect() {
    return this.fullTableScan().collect();
  }
  take(t) {
    return this.fullTableScan().take(t);
  }
  paginate(t) {
    return this.fullTableScan().paginate(t);
  }
  first() {
    return this.fullTableScan().first();
  }
  unique() {
    return this.fullTableScan().unique();
  }
  [Symbol.asyncIterator]() {
    return this.fullTableScan()[Symbol.asyncIterator]();
  }
};
function Mp(e) {
  throw new Error(
    e === "consumed" ? "This query is closed and can't emit any more values." : "This query has been chained with another operator and can't be reused."
  );
}
s(Mp, "throwClosedError");
var yt = class e {
  static {
    s(this, "QueryImpl");
  }
  constructor(t) {
    Da(this, "state"), Da(this, "tableNameForErrorMessages"), this.state = { type: "preparing", query: t }, t.source.type === "FullTableScan" ? this.tableNameForErrorMessages = t.source.tableName : this.tableNameForErrorMessages = t.source.indexName.split(".")[0];
  }
  takeQuery() {
    if (this.state.type !== "preparing")
      throw new Error(
        "A query can only be chained once and can't be chained after iteration begins."
      );
    let t = this.state.query;
    return this.state = { type: "closed" }, t;
  }
  startQuery() {
    if (this.state.type === "executing")
      throw new Error("Iteration can only begin on a query once.");
    (this.state.type === "closed" || this.state.type === "consumed") && Mp(this.state.type);
    let t = this.state.query, { queryId: n } = Lr("1.0/queryStream", { query: t, version: ne });
    return this.state = { type: "executing", queryId: n }, n;
  }
  closeQuery() {
    if (this.state.type === "executing") {
      let t = this.state.queryId;
      Lr("1.0/queryCleanup", { queryId: t });
    }
    this.state = { type: "consumed" };
  }
  order(t) {
    F(t, 1, "order", "order");
    let n = this.takeQuery();
    if (n.source.type === "Search")
      throw new Error(
        "Search queries must always be in relevance order. Can not set order manually."
      );
    if (n.source.order !== null)
      throw new Error("Queries may only specify order at most once");
    return n.source.order = t, new e(n);
  }
  filter(t) {
    F(t, 1, "filter", "predicate");
    let n = this.takeQuery();
    if (n.operators.length >= Vp)
      throw new Error(
        `Can't construct query with more than ${Vp} operators`
      );
    return n.operators.push({
      filter: J(t(Rp))
    }), new e(n);
  }
  limit(t) {
    F(t, 1, "limit", "n");
    let n = this.takeQuery();
    return n.operators.push({ limit: t }), new e(n);
  }
  [Symbol.asyncIterator]() {
    return this.startQuery(), this;
  }
  async next() {
    (this.state.type === "closed" || this.state.type === "consumed") && Mp(this.state.type);
    let t = this.state.type === "preparing" ? this.startQuery() : this.state.queryId, { value: n, done: o } = await L("1.0/queryStreamNext", {
      queryId: t
    });
    return o && this.closeQuery(), { value: Q(n), done: o };
  }
  return() {
    return this.closeQuery(), Promise.resolve({ done: !0, value: void 0 });
  }
  async paginate(t) {
    if (F(t, 1, "paginate", "options"), typeof t?.numItems != "number" || t.numItems < 0)
      throw new Error(
        `\`options.numItems\` must be a positive number. Received \`${t?.numItems}\`.`
      );
    let n = this.takeQuery(), o = t.numItems, r = t.cursor, i = t?.endCursor ?? null, a = t.maximumRowsRead ?? null, { page: u, isDone: c, continueCursor: l, splitCursor: d, pageStatus: f } = await L("1.0/queryPage", {
      query: n,
      cursor: r,
      endCursor: i,
      pageSize: o,
      maximumRowsRead: a,
      maximumBytesRead: t.maximumBytesRead,
      version: ne
    });
    return {
      page: u.map((p) => Q(p)),
      isDone: c,
      continueCursor: l,
      splitCursor: d,
      pageStatus: f
    };
  }
  async collect() {
    let t = [];
    for await (let n of this)
      t.push(n);
    return t;
  }
  async take(t) {
    return F(t, 1, "take", "n"), Ep(t, 1, "take", "n"), this.limit(t).collect();
  }
  async first() {
    let t = await this.take(1);
    return t.length === 0 ? null : t[0];
  }
  async unique() {
    let t = await this.take(2);
    if (t.length === 0)
      return null;
    if (t.length === 2)
      throw new Error(`unique() query returned more than one result from table ${this.tableNameForErrorMessages}:
 [${t[0]._id}, ${t[1]._id}, ...]`);
    return t[0];
  }
};

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/database_impl.js
async function Na(e, t, n) {
  if (F(t, 1, "get", "id"), typeof t != "string")
    throw new Error(
      `Invalid argument \`id\` for \`db.get\`, expected string but got '${typeof t}': ${t}`
    );
  let o = {
    id: G(t),
    isSystem: n,
    version: ne,
    table: e
  }, r = await L("1.0/get", o);
  return Q(r);
}
s(Na, "get");
function Ca() {
  let e = /* @__PURE__ */ s((r = !1) => ({
    get: /* @__PURE__ */ s(async (i, a) => a !== void 0 ? await Na(i, a, r) : await Na(void 0, i, r), "get"),
    query: /* @__PURE__ */ s((i) => new Mr(i, r).query(), "query"),
    normalizeId: /* @__PURE__ */ s((i, a) => {
      F(i, 1, "normalizeId", "tableName"), F(a, 2, "normalizeId", "id");
      let u = i.startsWith("_");
      if (u !== r)
        throw new Error(
          `${u ? "System" : "User"} tables can only be accessed from db.${r ? "" : "system."}normalizeId().`
        );
      let c = Lr("1.0/db/normalizeId", {
        table: i,
        idString: a
      });
      return Q(c).id;
    }, "normalizeId"),
    // We set the system reader on the next line
    system: null,
    table: /* @__PURE__ */ s((i) => new Mr(i, r), "table")
  }), "reader"), { system: t, ...n } = e(!0), o = e();
  return o.system = n, o;
}
s(Ca, "setupReader");
async function Bp(e, t) {
  if (e.startsWith("_"))
    throw new Error("System tables (prefixed with `_`) are read-only.");
  F(e, 1, "insert", "table"), F(t, 2, "insert", "value");
  let n = await L("1.0/insert", {
    table: e,
    value: G(t)
  });
  return Q(n)._id;
}
s(Bp, "insert");
async function Ta(e, t, n) {
  F(t, 1, "patch", "id"), F(n, 2, "patch", "value"), await L("1.0/shallowMerge", {
    id: G(t),
    value: jp(n),
    table: e
  });
}
s(Ta, "patch");
async function Aa(e, t, n) {
  F(t, 1, "replace", "id"), F(n, 2, "replace", "value"), await L("1.0/replace", {
    id: G(t),
    value: G(n),
    table: e
  });
}
s(Aa, "replace");
async function Ua(e, t) {
  F(t, 1, "delete", "id"), await L("1.0/remove", {
    id: G(t),
    table: e
  });
}
s(Ua, "delete_");
function Jp() {
  let e = Ca();
  return {
    get: e.get,
    query: e.query,
    normalizeId: e.normalizeId,
    system: e.system,
    insert: /* @__PURE__ */ s(async (t, n) => await Bp(t, n), "insert"),
    patch: /* @__PURE__ */ s(async (t, n, o) => o !== void 0 ? await Ta(t, n, o) : await Ta(void 0, t, n), "patch"),
    replace: /* @__PURE__ */ s(async (t, n, o) => o !== void 0 ? await Aa(t, n, o) : await Aa(void 0, t, n), "replace"),
    delete: /* @__PURE__ */ s(async (t, n) => n !== void 0 ? await Ua(t, n) : await Ua(void 0, t), "delete"),
    table: /* @__PURE__ */ s((t) => new Ea(t, !1), "table")
  };
}
s(Jp, "setupWriter");
var Mr = class {
  static {
    s(this, "TableReader");
  }
  constructor(t, n) {
    this.tableName = t, this.isSystem = n;
  }
  async get(t) {
    return Na(this.tableName, t, this.isSystem);
  }
  query() {
    let t = this.tableName.startsWith("_");
    if (t !== this.isSystem)
      throw new Error(
        `${t ? "System" : "User"} tables can only be accessed from db.${this.isSystem ? "" : "system."}query().`
      );
    return new Jt(this.tableName);
  }
}, Ea = class extends Mr {
  static {
    s(this, "TableWriter");
  }
  async insert(t) {
    return Bp(this.tableName, t);
  }
  async patch(t, n) {
    return Ta(this.tableName, t, n);
  }
  async replace(t, n) {
    return Aa(this.tableName, t, n);
  }
  async delete(t) {
    return Ua(this.tableName, t);
  }
};

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/scheduler_impl.js
function qp() {
  return {
    runAfter: /* @__PURE__ */ s(async (e, t, n) => {
      let o = Kp(e, t, n);
      return await L("1.0/schedule", o);
    }, "runAfter"),
    runAt: /* @__PURE__ */ s(async (e, t, n) => {
      let o = Gp(
        e,
        t,
        n
      );
      return await L("1.0/schedule", o);
    }, "runAt"),
    cancel: /* @__PURE__ */ s(async (e) => {
      F(e, 1, "cancel", "id");
      let t = { id: G(e) };
      await L("1.0/cancel_job", t);
    }, "cancel")
  };
}
s(qp, "setupMutationScheduler");
function Wp(e) {
  return {
    runAfter: /* @__PURE__ */ s(async (t, n, o) => {
      let r = {
        requestId: e,
        ...Kp(t, n, o)
      };
      return await L("1.0/actions/schedule", r);
    }, "runAfter"),
    runAt: /* @__PURE__ */ s(async (t, n, o) => {
      let r = {
        requestId: e,
        ...Gp(t, n, o)
      };
      return await L("1.0/actions/schedule", r);
    }, "runAt"),
    cancel: /* @__PURE__ */ s(async (t) => {
      F(t, 1, "cancel", "id");
      let n = {
        requestId: e,
        id: G(t)
      };
      return await L("1.0/actions/cancel_job", n);
    }, "cancel")
  };
}
s(Wp, "setupActionScheduler");
function Kp(e, t, n) {
  if (typeof e != "number")
    throw new Error("`delayMs` must be a number");
  if (!isFinite(e))
    throw new Error("`delayMs` must be a finite number");
  if (e < 0)
    throw new Error("`delayMs` must be non-negative");
  let o = Ke(n), r = je(t), i = (Date.now() + e) / 1e3;
  return {
    ...r,
    ts: i,
    args: G(o),
    version: ne
  };
}
s(Kp, "runAfterSyscallArgs");
function Gp(e, t, n) {
  let o;
  if (e instanceof Date)
    o = e.valueOf() / 1e3;
  else if (typeof e == "number")
    o = e / 1e3;
  else
    throw new Error("The invoke time must a Date or a timestamp");
  let r = je(t), i = Ke(n);
  return {
    ...r,
    ts: o,
    args: G(i),
    version: ne
  };
}
s(Gp, "runAtSyscallArgs");

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/storage_impl.js
function Za(e) {
  return {
    getUrl: /* @__PURE__ */ s(async (t) => (F(t, 1, "getUrl", "storageId"), await L("1.0/storageGetUrl", {
      requestId: e,
      version: ne,
      storageId: t
    })), "getUrl"),
    getMetadata: /* @__PURE__ */ s(async (t) => await L("1.0/storageGetMetadata", {
      requestId: e,
      version: ne,
      storageId: t
    }), "getMetadata")
  };
}
s(Za, "setupStorageReader");
function Ra(e) {
  let t = Za(e);
  return {
    generateUploadUrl: /* @__PURE__ */ s(async () => await L("1.0/storageGenerateUploadUrl", {
      requestId: e,
      version: ne
    }), "generateUploadUrl"),
    delete: /* @__PURE__ */ s(async (n) => {
      await L("1.0/storageDelete", {
        requestId: e,
        version: ne,
        storageId: n
      });
    }, "delete"),
    getUrl: t.getUrl,
    getMetadata: t.getMetadata
  };
}
s(Ra, "setupStorageWriter");
function Xp(e) {
  return {
    ...Ra(e),
    store: /* @__PURE__ */ s(async (n, o) => await Qn("storage/storeBlob", {
      requestId: e,
      version: ne,
      blob: n,
      options: o
    }), "store"),
    get: /* @__PURE__ */ s(async (n) => await Qn("storage/getBlob", {
      requestId: e,
      version: ne,
      storageId: n
    }), "get")
  };
}
s(Xp, "setupStorageActionWriter");

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/registration_impl.js
async function Hp(e, t) {
  let o = Q(JSON.parse(t)), r = {
    db: Jp(),
    auth: ti(""),
    storage: Ra(""),
    scheduler: qp(),
    runQuery: /* @__PURE__ */ s((a, u) => Fa("query", a, u), "runQuery"),
    runMutation: /* @__PURE__ */ s((a, u) => Fa("mutation", a, u), "runMutation")
  }, i = await La(e, r, o);
  return Qp(i), JSON.stringify(G(i === void 0 ? null : i));
}
s(Hp, "invokeMutation");
function Qp(e) {
  if (e instanceof Jt || e instanceof yt)
    throw new Error(
      "Return value is a Query. Results must be retrieved with `.collect()`, `.take(n), `.unique()`, or `.first()`."
    );
}
s(Qp, "validateReturnValue");
async function La(e, t, n) {
  let o;
  try {
    o = await Promise.resolve(e(t, ...n));
  } catch (r) {
    throw _y(r);
  }
  return o;
}
s(La, "invokeFunction");
function qt(e, t) {
  return (n, o) => (globalThis.console.warn(
    `Convex functions should not directly call other Convex functions. Consider calling a helper function instead. e.g. \`export const foo = ${e}(...); await foo(ctx);\` is not supported. See https://docs.convex.dev/production/best-practices/#use-helper-functions-to-write-shared-code`
  ), t(n, o));
}
s(qt, "dontCallDirectly");
function _y(e) {
  if (typeof e == "object" && e !== null && Symbol.for("ConvexError") in e) {
    let t = e;
    return t.data = JSON.stringify(
      G(t.data === void 0 ? null : t.data)
    ), t.ConvexErrorSymbol = Symbol.for("ConvexError"), t;
  } else
    return e;
}
s(_y, "serializeConvexErrorData");
function Wt() {
  if (typeof window > "u" || window.__convexAllowFunctionsInBrowser)
    return;
  (Object.getOwnPropertyDescriptor(globalThis, "window")?.get?.toString().includes("[native code]") ?? !1) && console.error(
    "Convex functions should not be imported in the browser. This will throw an error in future versions of `convex`. If this is a false negative, please report it to Convex support."
  );
}
s(Wt, "assertNotBrowser");
function Yp(e, t) {
  if (t === void 0)
    throw new Error(
      `A validator is undefined for field "${e}". This is often caused by circular imports. See https://docs.convex.dev/error#undefined-validator for details.`
    );
  return t;
}
s(Yp, "strictReplacer");
function Kt(e) {
  return () => {
    let t = y.any();
    return typeof e == "object" && e.args !== void 0 && (t = Fr(e.args)), JSON.stringify(t.json, Yp);
  };
}
s(Kt, "exportArgs");
function Gt(e) {
  return () => {
    let t;
    return typeof e == "object" && e.returns !== void 0 && (t = Fr(e.returns)), JSON.stringify(t ? t.json : null, Yp);
  };
}
s(Gt, "exportReturns");
var Va = /* @__PURE__ */ s(((e) => {
  let t = typeof e == "function" ? e : e.handler, n = qt("mutation", t);
  return Wt(), n.isMutation = !0, n.isPublic = !0, n.invokeMutation = (o) => Hp(t, o), n.exportArgs = Kt(e), n.exportReturns = Gt(e), n._handler = t, n;
}), "mutationGeneric"), Ma = /* @__PURE__ */ s(((e) => {
  let t = typeof e == "function" ? e : e.handler, n = qt(
    "internalMutation",
    t
  );
  return Wt(), n.isMutation = !0, n.isInternal = !0, n.invokeMutation = (o) => Hp(t, o), n.exportArgs = Kt(e), n.exportReturns = Gt(e), n._handler = t, n;
}), "internalMutationGeneric");
async function em(e, t) {
  let o = Q(JSON.parse(t)), r = {
    db: Ca(),
    auth: ti(""),
    storage: Za(""),
    runQuery: /* @__PURE__ */ s((a, u) => Fa("query", a, u), "runQuery")
  }, i = await La(e, r, o);
  return Qp(i), JSON.stringify(G(i === void 0 ? null : i));
}
s(em, "invokeQuery");
var Ba = /* @__PURE__ */ s(((e) => {
  let t = typeof e == "function" ? e : e.handler, n = qt("query", t);
  return Wt(), n.isQuery = !0, n.isPublic = !0, n.invokeQuery = (o) => em(t, o), n.exportArgs = Kt(e), n.exportReturns = Gt(e), n._handler = t, n;
}), "queryGeneric"), Ja = /* @__PURE__ */ s(((e) => {
  let t = typeof e == "function" ? e : e.handler, n = qt("internalQuery", t);
  return Wt(), n.isQuery = !0, n.isInternal = !0, n.invokeQuery = (o) => em(t, o), n.exportArgs = Kt(e), n.exportReturns = Gt(e), n._handler = t, n;
}), "internalQueryGeneric");
async function tm(e, t, n) {
  let o = Q(JSON.parse(n)), i = {
    ...Ap(t),
    auth: ti(t),
    scheduler: Wp(t),
    storage: Xp(t),
    vectorSearch: Cp(t)
  }, a = await La(e, i, o);
  return JSON.stringify(G(a === void 0 ? null : a));
}
s(tm, "invokeAction");
var qa = /* @__PURE__ */ s(((e) => {
  let t = typeof e == "function" ? e : e.handler, n = qt("action", t);
  return Wt(), n.isAction = !0, n.isPublic = !0, n.invokeAction = (o, r) => tm(t, o, r), n.exportArgs = Kt(e), n.exportReturns = Gt(e), n._handler = t, n;
}), "actionGeneric"), Wa = /* @__PURE__ */ s(((e) => {
  let t = typeof e == "function" ? e : e.handler, n = qt("internalAction", t);
  return Wt(), n.isAction = !0, n.isInternal = !0, n.invokeAction = (o, r) => tm(t, o, r), n.exportArgs = Kt(e), n.exportReturns = Gt(e), n._handler = t, n;
}), "internalActionGeneric");
async function Fa(e, t, n) {
  let o = Ke(n), r = {
    udfType: e,
    args: G(o),
    ...je(t)
  }, i = await L("1.0/runUdf", r);
  return Q(i);
}
s(Fa, "runUdf");

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/pagination.js
var xy = y.object({
  numItems: y.number(),
  cursor: y.union(y.string(), y.null()),
  endCursor: y.optional(y.union(y.string(), y.null())),
  id: y.optional(y.number()),
  maximumRowsRead: y.optional(y.number()),
  maximumBytesRead: y.optional(y.number())
});

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/api.js
function rm(e = []) {
  let t = {
    get(n, o) {
      if (typeof o == "string") {
        let r = [...e, o];
        return rm(r);
      } else if (o === Vr) {
        if (e.length < 2) {
          let a = ["api", ...e].join(".");
          throw new Error(
            `API path is expected to be of the form \`api.moduleName.functionName\`. Found: \`${a}\``
          );
        }
        let r = e.slice(0, -1).join("/"), i = e[e.length - 1];
        return i === "default" ? r : r + ":" + i;
      } else return o === Symbol.toStringTag ? "FunctionReference" : void 0;
    }
  };
  return new Proxy({}, t);
}
s(rm, "createApi");
var wy = rm();

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/schema.js
var Iy = Object.defineProperty, zy = /* @__PURE__ */ s((e, t, n) => t in e ? Iy(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, "__defNormalProp"), Ze = /* @__PURE__ */ s((e, t, n) => zy(e, typeof t != "symbol" ? t + "" : t, n), "__publicField"), si = class {
  static {
    s(this, "TableDefinition");
  }
  /**
   * @internal
   */
  constructor(t) {
    Ze(this, "indexes"), Ze(this, "stagedDbIndexes"), Ze(this, "searchIndexes"), Ze(this, "stagedSearchIndexes"), Ze(this, "vectorIndexes"), Ze(this, "stagedVectorIndexes"), Ze(this, "validator"), this.indexes = [], this.stagedDbIndexes = [], this.searchIndexes = [], this.stagedSearchIndexes = [], this.vectorIndexes = [], this.stagedVectorIndexes = [], this.validator = t;
  }
  /**
   * This API is experimental: it may change or disappear.
   *
   * Returns indexes defined on this table.
   * Intended for the advanced use cases of dynamically deciding which index to use for a query.
   * If you think you need this, please chime in on ths issue in the Convex JS GitHub repo.
   * https://github.com/get-convex/convex-js/issues/49
   */
  " indexes"() {
    return this.indexes;
  }
  index(t, n) {
    return Array.isArray(n) ? this.indexes.push({
      indexDescriptor: t,
      fields: n
    }) : n.staged ? this.stagedDbIndexes.push({
      indexDescriptor: t,
      fields: n.fields
    }) : this.indexes.push({
      indexDescriptor: t,
      fields: n.fields
    }), this;
  }
  searchIndex(t, n) {
    return n.staged ? this.stagedSearchIndexes.push({
      indexDescriptor: t,
      searchField: n.searchField,
      filterFields: n.filterFields || []
    }) : this.searchIndexes.push({
      indexDescriptor: t,
      searchField: n.searchField,
      filterFields: n.filterFields || []
    }), this;
  }
  vectorIndex(t, n) {
    return n.staged ? this.stagedVectorIndexes.push({
      indexDescriptor: t,
      vectorField: n.vectorField,
      dimensions: n.dimensions,
      filterFields: n.filterFields || []
    }) : this.vectorIndexes.push({
      indexDescriptor: t,
      vectorField: n.vectorField,
      dimensions: n.dimensions,
      filterFields: n.filterFields || []
    }), this;
  }
  /**
   * Work around for https://github.com/microsoft/TypeScript/issues/57035
   */
  self() {
    return this;
  }
  /**
   * Export the contents of this definition.
   *
   * This is called internally by the Convex framework.
   * @internal
   */
  export() {
    let t = this.validator.json;
    if (typeof t != "object")
      throw new Error(
        "Invalid validator: please make sure that the parameter of `defineTable` is valid (see https://docs.convex.dev/database/schemas)"
      );
    return {
      indexes: this.indexes,
      stagedDbIndexes: this.stagedDbIndexes,
      searchIndexes: this.searchIndexes,
      stagedSearchIndexes: this.stagedSearchIndexes,
      vectorIndexes: this.vectorIndexes,
      stagedVectorIndexes: this.stagedVectorIndexes,
      documentType: t
    };
  }
};
function $t(e) {
  return za(e) ? new si(e) : new si(y.object(e));
}
s($t, "defineTable");
var Ka = class {
  static {
    s(this, "SchemaDefinition");
  }
  /**
   * @internal
   */
  constructor(t, n) {
    Ze(this, "tables"), Ze(this, "strictTableNameTypes"), Ze(this, "schemaValidation"), this.tables = t, this.schemaValidation = n?.schemaValidation === void 0 ? !0 : n.schemaValidation;
  }
  /**
   * Export the contents of this definition.
   *
   * This is called internally by the Convex framework.
   * @internal
   */
  export() {
    return JSON.stringify({
      tables: Object.entries(this.tables).map(([t, n]) => {
        let {
          indexes: o,
          stagedDbIndexes: r,
          searchIndexes: i,
          stagedSearchIndexes: a,
          vectorIndexes: u,
          stagedVectorIndexes: c,
          documentType: l
        } = n.export();
        return {
          tableName: t,
          indexes: o,
          stagedDbIndexes: r,
          searchIndexes: i,
          stagedSearchIndexes: a,
          vectorIndexes: u,
          stagedVectorIndexes: c,
          documentType: l
        };
      }),
      schemaValidation: this.schemaValidation
    });
  }
};
function ui(e, t) {
  return new Ka(e, t);
}
s(ui, "defineSchema");
var Hz = ui({
  _scheduled_functions: $t({
    name: y.string(),
    args: y.array(y.any()),
    scheduledTime: y.float64(),
    completedTime: y.optional(y.float64()),
    state: y.union(
      y.object({ kind: y.literal("pending") }),
      y.object({ kind: y.literal("inProgress") }),
      y.object({ kind: y.literal("success") }),
      y.object({ kind: y.literal("failed"), error: y.string() }),
      y.object({ kind: y.literal("canceled") })
    )
  }),
  _storage: $t({
    sha256: y.string(),
    size: y.float64(),
    contentType: y.optional(y.string())
  })
});

// memory/profile.mjs
var bt = class {
  static {
    s(this, "SecretText");
  }
  constructor(t) {
    this.value = t;
  }
  toWire() {
    return this.value;
  }
}, Ga = { seq: 1, at: 17e11, secret: "capacity", payload: "tiny" };
function nm(e) {
  let t = e.kind === "native", n = e.kind === "full" || e.kind === "mini", o = t ? e.v : e.s;
  return /* @__PURE__ */ s(function({ count: i, width: a, profile: u, entries: c = 0 }) {
    if (!Number.isInteger(i) || i < 0 || !Number.isInteger(a) || a < 1 || !Number.isInteger(c) || c < 0 || !["fields-only", "codec-rich"].includes(u))
      throw new Error("Invalid graph fixture arguments");
    let l = { schemaConstructors: 0, fields: 0, codecSites: 0, allocatedCodecs: 0 }, d = /* @__PURE__ */ s((I, ...T) => (l.schemaConstructors++, o[I](...T)), "make"), f = /* @__PURE__ */ s((I) => (l.fields += Object.keys(I).length, d("object", I)), "object"), p = /* @__PURE__ */ s(() => (l.codecSites++, t ? d("number") : (l.allocatedCodecs++, d("codec", d("number"), d("date"), {
      decode: /* @__PURE__ */ s((I) => new Date(I), "decode"),
      encode: /* @__PURE__ */ s((I) => I.getTime(), "encode")
    }))), "date"), m = /* @__PURE__ */ s(() => (l.codecSites++, t ? d("string") : (l.allocatedCodecs++, d("codec", d("string"), d("instanceof", bt), {
      decode: /* @__PURE__ */ s((I) => new bt(I), "decode"),
      encode: /* @__PURE__ */ s((I) => I.toWire(), "encode")
    }))), "secret"), v = /* @__PURE__ */ s((I) => {
      if (u === "fields-only")
        switch (I % 4) {
          case 0:
            return d("string");
          case 1:
            return d("number");
          case 2:
            return d("boolean");
          case 3:
            return d("optional", d("string"));
        }
      switch (I % 4) {
        case 0:
          return p();
        case 1:
          return m();
        case 2:
          return f({ at: p(), tag: d("optional", d("string")) });
        case 3:
          return d("array", t ? d("union", d("string"), d("number")) : d("union", [d("string"), d("number")]));
      }
    }, "field"), x = {}, k = {}, R = /* @__PURE__ */ s((I, T) => {
      n ? (l.fields += Object.keys(T).length, x[I] = e.defineZodModel(I, T), k[I] = x[I].schema.insert) : (k[I] = f(T), x[I] = t ? e.defineTable(k[I]) : k[I]);
    }, "add");
    R("benchmarkRows", { seq: d("number"), at: p(), secret: m(), payload: d("string") });
    for (let I = 0; I < i; I++) {
      let T = {};
      for (let W = 0; W < a; W++) T[`f${W}`] = v(W);
      R(`unused${I}`, T);
    }
    let j = n ? e.defineZodSchema(x) : t ? e.defineSchema(x) : null, P = Object.keys(x), U = {};
    for (let I = 0; I < c; I++) {
      let T = P[I % P.length], W = n ? x[T].schema.doc : k[T], Me = f({ id: d("string"), label: d("optional", d("string")) }), gt = t ? d("union", W, d("null")) : d("nullable", W);
      U[`unused/fn${I}`] = { args: Me, returns: gt };
    }
    let V = n ? e.initZodvex(j, e.server, c ? { registry: /* @__PURE__ */ s(() => U, "registry") } : void 0) : e.makeBuilders();
    return {
      kind: e.kind,
      options: { count: i, width: a, profile: u, entries: c },
      models: x,
      sourceSchemas: k,
      schema: j,
      registry: U,
      builders: V,
      manifest: {
        backgroundModels: i,
        totalModels: i + 1,
        backgroundTopLevelFields: i * a,
        fixedProbeFields: 4,
        profile: u,
        registryEntries: c,
        ...l,
        counterScope: "Explicit fixture constructor calls and source fields/codecs; excludes library-generated helper schemas and runtime heap objects."
      },
      operation() {
        let I = { ...Ga }, T = t ? { ...I, at: new Date(I.at), secret: new bt(I.secret) } : e.s.parse(k.benchmarkRows, I);
        if (!(T.at instanceof Date) || !(T.secret instanceof bt)) throw new Error("Codec decode failed");
        T.at = new Date(T.at.getTime() + 1e3), T.secret = new bt(T.secret.toWire().toUpperCase());
        let W = t ? { ...T, at: T.at.getTime(), secret: T.secret.toWire() } : e.s.encode(k.benchmarkRows, T);
        if (JSON.stringify(W) !== JSON.stringify({ ...Ga, at: Ga.at + 1e3, secret: "CAPACITY" }))
          throw new Error("Codec round trip mismatch");
        return W;
      },
      // Call after the operation and after GC measurements. The retained graph
      // includes every model, table schema, registry entry and builder closure.
      checksum() {
        let I = 0;
        for (let [T, W] of Object.entries(x)) {
          if (!W || !k[T]) throw new Error("Missing model");
          if (I += T.length, n && j.__zodTableMap[T].insert !== k[T]) throw new Error("Lost table-map alias");
        }
        for (let [T, W] of Object.entries(U)) {
          if (!W.args || !W.returns) throw new Error("Missing registry schema");
          I += T.length;
        }
        if (Object.keys(V).length === 0) throw new Error("Lost builders");
        return I;
      }
    };
  }, "buildGraph");
}
s(nm, "createGraphFactory");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/external.js
var S = {};
Be(S, {
  $brand: () => ds,
  $input: () => jl,
  $output: () => Ol,
  NEVER: () => ls,
  TimePrecision: () => Rl,
  ZodAny: () => xf,
  ZodArray: () => zf,
  ZodBase64: () => Go,
  ZodBase64URL: () => Xo,
  ZodBigInt: () => Dr,
  ZodBigIntFormat: () => Yo,
  ZodBoolean: () => Pr,
  ZodCIDRv4: () => Wo,
  ZodCIDRv6: () => Ko,
  ZodCUID: () => Fo,
  ZodCUID2: () => Lo,
  ZodCatch: () => Wf,
  ZodCodec: () => Dn,
  ZodCompileAsyncError: () => Ue,
  ZodCompileUnsupportedError: () => Z,
  ZodCreditCard: () => vf,
  ZodCustom: () => Nn,
  ZodCustomStringFormat: () => Or,
  ZodDate: () => zn,
  ZodDefault: () => Lf,
  ZodDiscriminatedUnion: () => Of,
  ZodE164: () => Ho,
  ZodEmail: () => Eo,
  ZodEmoji: () => Zo,
  ZodEnum: () => zr,
  ZodError: () => Nx,
  ZodExactOptional: () => oa,
  ZodFile: () => Cf,
  ZodFirstPartyTypeKind: () => ap,
  ZodFunction: () => np,
  ZodGUID: () => Co,
  ZodIPv4: () => Jo,
  ZodIPv6: () => qo,
  ZodISODate: () => lt,
  ZodISODateTime: () => ct,
  ZodISODuration: () => ft,
  ZodISOTime: () => dt,
  ZodIntersection: () => jf,
  ZodIssueCode: () => Ux,
  ZodJWT: () => Qo,
  ZodKSUID: () => Bo,
  ZodLazy: () => ep,
  ZodLiteral: () => Ef,
  ZodMAC: () => hf,
  ZodMap: () => Af,
  ZodNaN: () => Gf,
  ZodNanoID: () => Ro,
  ZodNever: () => kf,
  ZodNonOptional: () => aa,
  ZodNull: () => bf,
  ZodNullable: () => Ff,
  ZodNumber: () => jr,
  ZodNumberFormat: () => Rt,
  ZodObject: () => Sn,
  ZodOptional: () => jn,
  ZodPipe: () => Pn,
  ZodPrefault: () => Mf,
  ZodPreprocess: () => Xf,
  ZodPromise: () => rp,
  ZodReadonly: () => Hf,
  ZodRealError: () => ye,
  ZodRecord: () => Ir,
  ZodSet: () => Uf,
  ZodString: () => Sr,
  ZodStringFormat: () => q,
  ZodSuccess: () => qf,
  ZodSymbol: () => yf,
  ZodTemplateLiteral: () => Yf,
  ZodTransform: () => Zf,
  ZodTuple: () => Df,
  ZodType: () => A,
  ZodULID: () => Vo,
  ZodURL: () => wn,
  ZodUUID: () => Ve,
  ZodUndefined: () => $f,
  ZodUnion: () => On,
  ZodUnknown: () => wf,
  ZodVoid: () => If,
  ZodXID: () => Mo,
  ZodXor: () => Sf,
  _ZodString: () => Uo,
  _default: () => Vf,
  _function: () => uh,
  any: () => Vg,
  array: () => Ft,
  base64: () => kg,
  base64url: () => Ig,
  bigint: () => Cg,
  boolean: () => In,
  catch: () => Kf,
  check: () => ch,
  cidrv4: () => xg,
  cidrv6: () => wg,
  clone: () => C,
  codec: () => sa,
  coerce: () => sp,
  compile: () => Tl,
  config: () => te,
  core: () => qe,
  creditCard: () => Sg,
  cuid: () => mg,
  cuid2: () => gg,
  custom: () => lh,
  date: () => ta,
  decode: () => cf,
  decodeAsync: () => df,
  deepPartial: () => _h,
  describe: () => dh,
  discriminatedUnion: () => Kg,
  e164: () => zg,
  email: () => ig,
  emoji: () => fg,
  encode: () => xn,
  encodeAsync: () => lf,
  endsWith: () => hr,
  enum: () => na,
  exactOptional: () => Rf,
  file: () => th,
  flattenError: () => Qr,
  float32: () => Tg,
  float64: () => Ag,
  formatError: () => Yr,
  fromJSONSchema: () => $h,
  function: () => uh,
  getDiscriminatedOption: () => rc,
  getErrorMap: () => Cx,
  globalRegistry: () => se,
  gt: () => Fe,
  gte: () => ke,
  guid: () => og,
  hash: () => Ng,
  hex: () => Dg,
  hostname: () => Pg,
  httpUrl: () => dg,
  includes: () => mr,
  input: () => wh,
  instanceof: () => ua,
  int: () => To,
  int32: () => Ug,
  int64: () => Zg,
  intersection: () => Pf,
  invertCodec: () => oh,
  ipv4: () => $g,
  ipv6: () => _g,
  iso: () => Tn,
  json: () => mh,
  jwt: () => Og,
  keyof: () => Bg,
  ksuid: () => yg,
  lazy: () => tp,
  length: () => At,
  literal: () => eh,
  locales: () => pn,
  looseObject: () => qg,
  looseRecord: () => Xg,
  lowercase: () => fr,
  lt: () => Re,
  lte: () => we,
  mac: () => bg,
  map: () => Hg,
  maxLength: () => Tt,
  maxSize: () => ot,
  memoizer: () => un,
  meta: () => fh,
  mime: () => vr,
  minLength: () => Je,
  minSize: () => Le,
  multipleOf: () => it,
  nan: () => ih,
  nanoid: () => pg,
  nativeEnum: () => Yg,
  negative: () => _o,
  never: () => ea,
  nonnegative: () => wo,
  nonoptional: () => Jf,
  nonpositive: () => xo,
  normalize: () => yr,
  null: () => _f,
  nullable: () => Ct,
  nullish: () => rh,
  number: () => kn,
  object: () => ra,
  optional: () => We,
  output: () => kh,
  overwrite: () => Ee,
  parse: () => _n,
  parseAsync: () => af,
  partialRecord: () => Gg,
  pipe: () => Ao,
  positive: () => bo,
  prefault: () => Bf,
  preprocess: () => gh,
  prettifyError: () => hs,
  promise: () => sh,
  properties: () => Io,
  property: () => ko,
  readonly: () => Qf,
  record: () => Tf,
  refine: () => ip,
  regex: () => dr,
  regexes: () => ce,
  registry: () => Xi,
  safeDecode: () => pf,
  safeDecodeAsync: () => gf,
  safeEncode: () => ff,
  safeEncodeAsync: () => mf,
  safeParse: () => sf,
  safeParseAsync: () => uf,
  set: () => Qg,
  setErrorMap: () => Ex,
  size: () => Nt,
  slugify: () => xr,
  startsWith: () => gr,
  strictObject: () => Jg,
  string: () => Ut,
  stringFormat: () => jg,
  stringbool: () => ph,
  success: () => nh,
  superRefine: () => op,
  symbol: () => Fg,
  templateLiteral: () => ah,
  toJSONSchema: () => jo,
  toLowerCase: () => br,
  toUpperCase: () => _r,
  toZod: () => Br,
  transform: () => ia,
  treeifyError: () => gs,
  trim: () => $r,
  tuple: () => Nf,
  uint32: () => Eg,
  uint64: () => Rg,
  ulid: () => hg,
  undefined: () => Lg,
  union: () => pt,
  unknown: () => Et,
  uppercase: () => pr,
  url: () => lg,
  util: () => _,
  uuid: () => ag,
  uuidv4: () => sg,
  uuidv6: () => ug,
  uuidv7: () => cg,
  validate: () => ys,
  validateAsync: () => $s,
  void: () => Mg,
  xid: () => vg,
  xor: () => Wg
});

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/index.js
var qe = {};
Be(qe, {
  $ZodAny: () => Xu,
  $ZodArray: () => et,
  $ZodAsyncError: () => he,
  $ZodBase64: () => Ru,
  $ZodBase64URL: () => Fu,
  $ZodBigInt: () => Mi,
  $ZodBigIntFormat: () => qu,
  $ZodBoolean: () => an,
  $ZodCIDRv4: () => Cu,
  $ZodCIDRv6: () => Zu,
  $ZodCUID: () => Iu,
  $ZodCUID2: () => zu,
  $ZodCatch: () => fc,
  $ZodCheck: () => K,
  $ZodCheckBigIntFormat: () => eu,
  $ZodCheckEndsWith: () => fu,
  $ZodCheckGreaterThan: () => Si,
  $ZodCheckIncludes: () => lu,
  $ZodCheckLengthEquals: () => au,
  $ZodCheckLessThan: () => zi,
  $ZodCheckLowerCase: () => uu,
  $ZodCheckMaxLength: () => iu,
  $ZodCheckMaxSize: () => tu,
  $ZodCheckMimeType: () => pu,
  $ZodCheckMinLength: () => ou,
  $ZodCheckMinSize: () => ru,
  $ZodCheckMultipleOf: () => Qs,
  $ZodCheckNumberFormat: () => Ys,
  $ZodCheckOverwrite: () => mu,
  $ZodCheckProperty: () => Oi,
  $ZodCheckRegex: () => su,
  $ZodCheckSizeEquals: () => nu,
  $ZodCheckStartsWith: () => du,
  $ZodCheckStringFormat: () => or,
  $ZodCheckUpperCase: () => cu,
  $ZodCodec: () => Ae,
  $ZodCreditCard: () => Vu,
  $ZodCustom: () => sn,
  $ZodCustomStringFormat: () => Bu,
  $ZodCyclicError: () => Wi,
  $ZodDate: () => sr,
  $ZodDefault: () => _e,
  $ZodDiscriminatedUnion: () => tt,
  $ZodE164: () => Lu,
  $ZodEmail: () => $u,
  $ZodEmoji: () => wu,
  $ZodEncodeError: () => He,
  $ZodEnum: () => ur,
  $ZodError: () => De,
  $ZodExactOptional: () => uc,
  $ZodFile: () => ac,
  $ZodFunction: () => vc,
  $ZodGUID: () => vu,
  $ZodIPv4: () => Au,
  $ZodIPv6: () => Uu,
  $ZodISODate: () => Du,
  $ZodISODateTime: () => Pu,
  $ZodISODuration: () => Tu,
  $ZodISOTime: () => Nu,
  $ZodIntersection: () => nc,
  $ZodJWT: () => Mu,
  $ZodKSUID: () => ju,
  $ZodLazy: () => nt,
  $ZodLiteral: () => cr,
  $ZodMAC: () => Eu,
  $ZodMap: () => ic,
  $ZodNaN: () => pc,
  $ZodNanoID: () => ku,
  $ZodNever: () => Qu,
  $ZodNonOptional: () => lc,
  $ZodNull: () => Gu,
  $ZodNullable: () => Te,
  $ZodNumber: () => Vi,
  $ZodNumberFormat: () => Ju,
  $ZodObject: () => re,
  $ZodObjectJIT: () => ec,
  $ZodOptional: () => ee,
  $ZodPipe: () => Bi,
  $ZodPrefault: () => cc,
  $ZodPreprocess: () => mc,
  $ZodPromise: () => yc,
  $ZodReadonly: () => gc,
  $ZodRealError: () => ve,
  $ZodRecord: () => St,
  $ZodRegistry: () => Gi,
  $ZodSet: () => oc,
  $ZodString: () => zt,
  $ZodStringFormat: () => B,
  $ZodSuccess: () => dc,
  $ZodSymbol: () => Wu,
  $ZodTemplateLiteral: () => hc,
  $ZodTransform: () => sc,
  $ZodTuple: () => rt,
  $ZodType: () => O,
  $ZodULID: () => Su,
  $ZodURL: () => xu,
  $ZodUUID: () => yu,
  $ZodUndefined: () => Ku,
  $ZodUnion: () => le,
  $ZodUnknown: () => Hu,
  $ZodVoid: () => Yu,
  $ZodXID: () => Ou,
  $ZodXor: () => tc,
  $brand: () => ds,
  $constructor: () => g,
  $input: () => jl,
  $output: () => Ol,
  Doc: () => It,
  INVALID: () => xe,
  JSONSchema: () => tg,
  JSONSchemaGenerator: () => Po,
  NEVER: () => ls,
  TimePrecision: () => Rl,
  URL_BAD_FORMAT: () => bu,
  URL_UNPARSEABLE: () => _u,
  ZodCompileAsyncError: () => Ue,
  ZodCompileUnsupportedError: () => Z,
  _any: () => rd,
  _array: () => cd,
  _base64: () => ho,
  _base64url: () => vo,
  _bigint: () => Gl,
  _boolean: () => Wl,
  _catch: () => xx,
  _check: () => Km,
  _cidrv4: () => mo,
  _cidrv6: () => go,
  _coercedBigint: () => Xl,
  _coercedBoolean: () => Kl,
  _coercedDate: () => sd,
  _coercedNumber: () => Ll,
  _coercedString: () => El,
  _creditCard: () => Zl,
  _cuid: () => ao,
  _cuid2: () => so,
  _custom: () => dd,
  _date: () => ad,
  _decode: () => hi,
  _decodeAsync: () => yi,
  _default: () => $x,
  _discriminatedUnion: () => sx,
  _e164: () => yo,
  _email: () => Qi,
  _emoji: () => io,
  _encode: () => gi,
  _encodeAsync: () => vi,
  _endsWith: () => hr,
  _enum: () => px,
  _file: () => ld,
  _float32: () => Ml,
  _float64: () => Bl,
  _gt: () => Fe,
  _gte: () => ke,
  _guid: () => Yi,
  _includes: () => mr,
  _int: () => Vl,
  _int32: () => Jl,
  _int64: () => Hl,
  _intersection: () => ux,
  _ipv4: () => fo,
  _ipv6: () => po,
  _isoDate: () => hn,
  _isoDateTime: () => gn,
  _isoDuration: () => yn,
  _isoTime: () => vn,
  _jwt: () => $o,
  _ksuid: () => lo,
  _lazy: () => zx,
  _length: () => At,
  _literal: () => gx,
  _lowercase: () => fr,
  _lt: () => Re,
  _lte: () => we,
  _mac: () => Cl,
  _map: () => dx,
  _max: () => we,
  _maxLength: () => Tt,
  _maxSize: () => ot,
  _mime: () => vr,
  _min: () => ke,
  _minLength: () => Je,
  _minSize: () => Le,
  _multipleOf: () => it,
  _nan: () => ud,
  _nanoid: () => oo,
  _nativeEnum: () => mx,
  _negative: () => _o,
  _never: () => id,
  _nonnegative: () => wo,
  _nonoptional: () => bx,
  _nonpositive: () => xo,
  _normalize: () => yr,
  _null: () => td,
  _nullable: () => yx,
  _number: () => Fl,
  _optional: () => vx,
  _overwrite: () => Ee,
  _parse: () => tr,
  _parseAsync: () => rr,
  _pipe: () => wx,
  _positive: () => bo,
  _promise: () => Sx,
  _properties: () => Io,
  _property: () => ko,
  _readonly: () => kx,
  _record: () => lx,
  _refine: () => fd,
  _regex: () => dr,
  _safeDecode: () => bi,
  _safeDecodeAsync: () => xi,
  _safeEncode: () => $i,
  _safeEncodeAsync: () => _i,
  _safeParse: () => nr,
  _safeParseAsync: () => ir,
  _set: () => fx,
  _size: () => Nt,
  _slugify: () => xr,
  _startsWith: () => gr,
  _string: () => Ul,
  _stringFormat: () => wr,
  _stringbool: () => hd,
  _success: () => _x,
  _superRefine: () => pd,
  _symbol: () => Yl,
  _templateLiteral: () => Ix,
  _toLowerCase: () => br,
  _toUpperCase: () => _r,
  _transform: () => hx,
  _trim: () => $r,
  _tuple: () => cx,
  _uint32: () => ql,
  _uint64: () => Ql,
  _ulid: () => uo,
  _undefined: () => ed,
  _union: () => ox,
  _unknown: () => nd,
  _uppercase: () => pr,
  _url: () => mn,
  _uuid: () => eo,
  _uuidv4: () => to,
  _uuidv6: () => ro,
  _uuidv7: () => no,
  _void: () => od,
  _xid: () => co,
  _xor: () => ax,
  clone: () => C,
  compile: () => Tl,
  compileFn: () => Hi,
  config: () => te,
  createStandardJSONSchemaMethod: () => kr,
  createToJSONSchemaMethod: () => yd,
  decode: () => f$,
  decodeAsync: () => m$,
  describe: () => md,
  encode: () => Ne,
  encodeAsync: () => p$,
  extractDefs: () => st,
  finalize: () => ut,
  flattenError: () => Qr,
  formatError: () => Yr,
  getDiscriminatedOption: () => rc,
  globalConfig: () => ae,
  globalRegistry: () => se,
  handleUnrepresentable: () => oe,
  initializeContext: () => at,
  isBackEdge: () => Ki,
  isRecursiveSchema: () => xc,
  isValidBase64: () => on,
  isValidBase64URL: () => Ri,
  isValidCIDRv6: () => Zi,
  isValidCreditCard: () => Fi,
  isValidIPv6: () => nn,
  isValidJWT: () => Li,
  locales: () => pn,
  memoizer: () => un,
  mergeValues: () => ar,
  meta: () => gd,
  parse: () => Qe,
  parseAsync: () => mi,
  parseURLObject: () => Ai,
  prettifyError: () => hs,
  process: () => M,
  regexes: () => ce,
  registry: () => Xi,
  safeDecode: () => h$,
  safeDecodeAsync: () => y$,
  safeEncode: () => g$,
  safeEncodeAsync: () => v$,
  safeParse: () => wt,
  safeParseAsync: () => vs,
  standardProps: () => Ti,
  stripTabAndNewline: () => Ui,
  toDotPath: () => dm,
  toJSONSchema: () => jo,
  toZod: () => Br,
  treeifyError: () => gs,
  urlHostnameOk: () => Ei,
  urlProtocolOk: () => Ci,
  util: () => _,
  validate: () => ys,
  validateAsync: () => $s,
  version: () => gu
});

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/util.js
var _ = {};
Be(_, {
  BIGINT_FORMAT_RANGES: () => is,
  CONSTANT_CATCH: () => fi,
  Class: () => Ha,
  NUMBER_FORMAT_RANGES: () => ns,
  aborted: () => Xe,
  allowsEval: () => es,
  assert: () => Dy,
  assertEqual: () => Sy,
  assertIs: () => jy,
  assertNever: () => Py,
  assertNotEqual: () => Oy,
  assignProp: () => Y,
  attachSchema: () => di,
  base64ToUint8Array: () => om,
  base64urlToUint8Array: () => Gy,
  cached: () => Yt,
  captureStackTrace: () => li,
  cleanEnum: () => Ky,
  cleanRegex: () => qr,
  clone: () => C,
  cloneDef: () => Ty,
  codePointLength: () => xt,
  constantCatch: () => us,
  createTransparentProxy: () => Ry,
  defineLazy: () => Qa,
  defineLazyInternal: () => E,
  esc: () => pe,
  escapeRegex: () => Oe,
  explicitlyAborted: () => os,
  extend: () => Vy,
  finalizeIssue: () => ge,
  floatSafeRemainder: () => Wr,
  getElementAtPath: () => Ay,
  getEnumValues: () => Jr,
  getLengthableOrigin: () => Hr,
  getParsedType: () => Zy,
  getSizableOrigin: () => Xr,
  hexToUint8Array: () => Hy,
  hide: () => ss,
  installLazyProp: () => r$,
  isObject: () => _t,
  isPlainObject: () => Se,
  issue: () => er,
  joinValues: () => h,
  jsonStringifyReplacer: () => Qt,
  members: () => as,
  merge: () => By,
  mergeDefs: () => Pe,
  normalizeParams: () => w,
  nullish: () => ci,
  numKeys: () => Cy,
  objectClone: () => Ny,
  omit: () => Ly,
  optionalKeys: () => rs,
  own: () => Ht,
  parsedType: () => b,
  partial: () => Jy,
  pick: () => Fy,
  prefixIssues: () => me,
  primitiveTypes: () => ts,
  promiseAllObject: () => Uy,
  propertyKeyTypes: () => Gr,
  randomString: () => Ey,
  required: () => qy,
  safeExtend: () => My,
  shallowClone: () => Kr,
  slugify: () => Ya,
  stringifyPrimitive: () => $,
  toZod: () => Br,
  uint8ArrayToBase64: () => am,
  uint8ArrayToBase64url: () => Xy,
  uint8ArrayToHex: () => Qy,
  unwrapMessage: () => Xt
});
function Sy(e) {
  return e;
}
s(Sy, "assertEqual");
function Oy(e) {
  return e;
}
s(Oy, "assertNotEqual");
function Br() {
  return (e) => e;
}
s(Br, "toZod");
function jy(e) {
}
s(jy, "assertIs");
function Py(e) {
  throw new Error("Unexpected value in exhaustive check");
}
s(Py, "assertNever");
function Dy(e) {
}
s(Dy, "assert");
function Jr(e) {
  let t = Object.values(e).filter((o) => typeof o == "number");
  return Object.entries(e).filter(([o, r]) => t.indexOf(+o) === -1).map(([o, r]) => r);
}
s(Jr, "getEnumValues");
function h(e, t = "|") {
  return e.map((n) => $(n)).join(t);
}
s(h, "joinValues");
function Qt(e, t) {
  return typeof t == "bigint" ? t.toString() : t;
}
s(Qt, "jsonStringifyReplacer");
function Yt(e) {
  return {
    get value() {
      {
        let n = e();
        return Object.defineProperty(this, "value", { value: n }), n;
      }
      throw new Error("cached value already set");
    }
  };
}
s(Yt, "cached");
function ci(e) {
  return e == null;
}
s(ci, "nullish");
function qr(e) {
  let t = e.startsWith("^") ? 1 : 0, n = e.endsWith("$") ? e.length - 1 : e.length;
  return e.slice(t, n);
}
s(qr, "cleanRegex");
function Wr(e, t) {
  let n = e / t, o = Math.round(n), r = 4 * Number.EPSILON * Math.max(Math.abs(n), 1);
  return Math.abs(n - o) < r ? 0 : n - o;
}
s(Wr, "floatSafeRemainder");
var im = /* @__PURE__ */ Symbol("evaluating");
function Qa(e, t, n) {
  let o;
  Object.defineProperty(e, t, {
    get() {
      if (o !== im)
        return o === void 0 && (o = im, o = n()), o;
    },
    set(r) {
      Object.defineProperty(e, t, {
        value: r
        // configurable: true,
      });
    },
    configurable: !0
  });
}
s(Qa, "defineLazy");
function Ny(e) {
  return Object.create(Object.getPrototypeOf(e), Object.getOwnPropertyDescriptors(e));
}
s(Ny, "objectClone");
function Y(e, t, n) {
  Object.defineProperty(e, t, {
    value: n,
    writable: !0,
    enumerable: !0,
    configurable: !0
  });
}
s(Y, "assignProp");
function Pe(...e) {
  let t = {};
  for (let n of e) {
    let o = Object.getOwnPropertyDescriptors(n);
    Object.assign(t, o);
  }
  return Object.defineProperties({}, t);
}
s(Pe, "mergeDefs");
function Ty(e) {
  return Pe(e._zod.def);
}
s(Ty, "cloneDef");
function Ay(e, t) {
  return t ? t.reduce((n, o) => n?.[o], e) : e;
}
s(Ay, "getElementAtPath");
function Uy(e) {
  let t = Object.keys(e), n = t.map((o) => e[o]);
  return Promise.all(n).then((o) => {
    let r = {};
    for (let i = 0; i < t.length; i++)
      r[t[i]] = o[i];
    return r;
  });
}
s(Uy, "promiseAllObject");
function Ey(e = 10) {
  let t = "abcdefghijklmnopqrstuvwxyz", n = "";
  for (let o = 0; o < e; o++)
    n += t[Math.floor(Math.random() * t.length)];
  return n;
}
s(Ey, "randomString");
function pe(e) {
  return JSON.stringify(e);
}
s(pe, "esc");
function Ya(e) {
  return e.toLowerCase().trim().replace(/[^\w\s-]/g, "").replace(/[\s_-]+/g, "-").replace(/^-+|-+$/g, "");
}
s(Ya, "slugify");
var li = "captureStackTrace" in Error ? Error.captureStackTrace : (...e) => {
};
function _t(e) {
  return typeof e == "object" && e !== null && !Array.isArray(e);
}
s(_t, "isObject");
var es = /* @__PURE__ */ Yt(() => {
  if (ae.jitless || typeof navigator < "u" && navigator?.userAgent?.includes("Cloudflare"))
    return !1;
  try {
    let e = Function;
    return new e(""), !0;
  } catch {
    return !1;
  }
});
function Se(e) {
  if (_t(e) === !1)
    return !1;
  let t = e.constructor;
  if (t === void 0 || typeof t != "function")
    return !0;
  let n = t.prototype;
  return !(_t(n) === !1 || Object.prototype.hasOwnProperty.call(n, "isPrototypeOf") === !1);
}
s(Se, "isPlainObject");
function Kr(e) {
  return Se(e) ? { ...e } : Array.isArray(e) ? [...e] : e instanceof Map ? new Map(e) : e instanceof Set ? new Set(e) : e;
}
s(Kr, "shallowClone");
function Cy(e) {
  let t = 0;
  for (let n in e)
    Object.prototype.hasOwnProperty.call(e, n) && t++;
  return t;
}
s(Cy, "numKeys");
var Zy = /* @__PURE__ */ s((e) => {
  let t = typeof e;
  switch (t) {
    case "undefined":
      return "undefined";
    case "string":
      return "string";
    case "number":
      return Number.isNaN(e) ? "nan" : "number";
    case "boolean":
      return "boolean";
    case "function":
      return "function";
    case "bigint":
      return "bigint";
    case "symbol":
      return "symbol";
    case "object":
      return Array.isArray(e) ? "array" : e === null ? "null" : e.then && typeof e.then == "function" && e.catch && typeof e.catch == "function" ? "promise" : typeof Map < "u" && e instanceof Map ? "map" : typeof Set < "u" && e instanceof Set ? "set" : typeof Date < "u" && e instanceof Date ? "date" : typeof File < "u" && e instanceof File ? "file" : "object";
    default:
      throw new Error(`Unknown data type: ${t}`);
  }
}, "getParsedType"), Gr = /* @__PURE__ */ new Set(["string", "number", "symbol"]), ts = /* @__PURE__ */ new Set([
  "string",
  "number",
  "bigint",
  "boolean",
  "symbol",
  "undefined"
]);
function Oe(e) {
  return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
s(Oe, "escapeRegex");
function C(e, t, n) {
  let o = new e._zod.constr(t ?? e._zod.def);
  return (!t || n?.parent) && (o._zod.parent = e), o;
}
s(C, "clone");
function w(e) {
  let t = e;
  if (!t)
    return {};
  if (typeof t == "string")
    return { error: /* @__PURE__ */ s(() => t, "error") };
  if (t?.message !== void 0) {
    if (t?.error !== void 0)
      throw new Error("Cannot specify both `message` and `error` params");
    t.error = t.message;
  }
  return delete t.message, typeof t.error == "string" ? { ...t, error: /* @__PURE__ */ s(() => t.error, "error") } : t;
}
s(w, "normalizeParams");
function Ry(e) {
  let t;
  return new Proxy({}, {
    get(n, o, r) {
      return t ?? (t = e()), Reflect.get(t, o, r);
    },
    set(n, o, r, i) {
      return t ?? (t = e()), Reflect.set(t, o, r, i);
    },
    has(n, o) {
      return t ?? (t = e()), Reflect.has(t, o);
    },
    deleteProperty(n, o) {
      return t ?? (t = e()), Reflect.deleteProperty(t, o);
    },
    ownKeys(n) {
      return t ?? (t = e()), Reflect.ownKeys(t);
    },
    getOwnPropertyDescriptor(n, o) {
      return t ?? (t = e()), Reflect.getOwnPropertyDescriptor(t, o);
    },
    defineProperty(n, o, r) {
      return t ?? (t = e()), Reflect.defineProperty(t, o, r);
    }
  });
}
s(Ry, "createTransparentProxy");
function $(e) {
  return typeof e == "bigint" ? e.toString() + "n" : typeof e == "string" ? `"${e}"` : `${e}`;
}
s($, "stringifyPrimitive");
function rs(e) {
  return Object.keys(e).filter((t) => e[t]._zod.optin !== void 0 && e[t]._zod.optout === "optional");
}
s(rs, "optionalKeys");
var ns = {
  safeint: [Number.MIN_SAFE_INTEGER, Number.MAX_SAFE_INTEGER],
  int32: [-2147483648, 2147483647],
  uint32: [0, 4294967295],
  float32: [-34028234663852886e22, 34028234663852886e22],
  float64: [-Number.MAX_VALUE, Number.MAX_VALUE]
}, is = {
  int64: [/* @__PURE__ */ BigInt("-9223372036854775808"), /* @__PURE__ */ BigInt("9223372036854775807")],
  uint64: [/* @__PURE__ */ BigInt(0), /* @__PURE__ */ BigInt("18446744073709551615")]
};
function Fy(e, t) {
  let n = e._zod.def, o = n.checks;
  if (o && o.length > 0)
    throw new Error(".pick() cannot be used on object schemas containing refinements");
  let i = Pe(e._zod.def, {
    get shape() {
      let a = {};
      for (let u of Reflect.ownKeys(t)) {
        if (!Object.prototype.hasOwnProperty.call(n.shape, u))
          throw new Error(`Unrecognized key: "${String(u)}"`);
        t[u] && Y(a, u, n.shape[u]);
      }
      return Y(this, "shape", a), a;
    },
    checks: []
  });
  return C(e, i);
}
s(Fy, "pick");
function Ly(e, t) {
  let n = e._zod.def, o = n.checks;
  if (o && o.length > 0)
    throw new Error(".omit() cannot be used on object schemas containing refinements");
  let i = Pe(e._zod.def, {
    get shape() {
      let a = { ...e._zod.def.shape };
      for (let u of Reflect.ownKeys(t)) {
        if (!Object.prototype.hasOwnProperty.call(n.shape, u))
          throw new Error(`Unrecognized key: "${String(u)}"`);
        t[u] && delete a[u];
      }
      return Y(this, "shape", a), a;
    },
    checks: []
  });
  return C(e, i);
}
s(Ly, "omit");
function Vy(e, t) {
  if (!Se(t))
    throw new Error("Invalid input to extend: expected a plain object");
  let n = e._zod.def.checks;
  if (n && n.length > 0) {
    let i = e._zod.def.shape;
    for (let a of Reflect.ownKeys(t))
      if (Object.getOwnPropertyDescriptor(i, a) !== void 0)
        throw new Error("Cannot overwrite keys on object schemas containing refinements. Use `.safeExtend()` instead.");
  }
  let r = Pe(e._zod.def, {
    get shape() {
      let i = { ...e._zod.def.shape, ...t };
      return Y(this, "shape", i), i;
    }
  });
  return C(e, r);
}
s(Vy, "extend");
function My(e, t) {
  if (!Se(t))
    throw new Error("Invalid input to safeExtend: expected a plain object");
  let n = Pe(e._zod.def, {
    get shape() {
      let o = { ...e._zod.def.shape, ...t };
      return Y(this, "shape", o), o;
    }
  });
  return C(e, n);
}
s(My, "safeExtend");
function By(e, t) {
  if (!t?._zod?.def)
    throw new Error("Invalid input to merge: expected an object schema. To merge a plain shape, use `.extend()`.");
  if (e._zod.def.checks?.length)
    throw new Error(".merge() cannot be used on object schemas containing refinements. Use .safeExtend() instead.");
  let n = Pe(e._zod.def, {
    get shape() {
      let o = { ...e._zod.def.shape, ...t._zod.def.shape };
      return Y(this, "shape", o), o;
    },
    get catchall() {
      return t._zod.def.catchall;
    },
    checks: t._zod.def.checks ?? []
  });
  return C(e, n);
}
s(By, "merge");
function Jy(e, t, n, o = "partial") {
  let i = t._zod.def.checks;
  if (i && i.length > 0)
    throw new Error(`.${o}() cannot be used on object schemas containing refinements`);
  let u = Pe(t._zod.def, {
    get shape() {
      let c = t._zod.def.shape, l = { ...c };
      if (n)
        for (let d of Reflect.ownKeys(n)) {
          if (!Object.prototype.hasOwnProperty.call(c, d))
            throw new Error(`Unrecognized key: "${String(d)}"`);
          n[d] && (l[d] = e ? new e({
            type: "optional",
            innerType: c[d]
          }) : c[d]);
        }
      else
        for (let d of Reflect.ownKeys(c))
          l[d] = e ? new e({
            type: "optional",
            innerType: c[d]
          }) : c[d];
      return Y(this, "shape", l), l;
    },
    checks: []
  });
  return C(t, u);
}
s(Jy, "partial");
function qy(e, t, n) {
  let o = Pe(t._zod.def, {
    get shape() {
      let r = t._zod.def.shape, i = { ...r };
      if (n)
        for (let a of Reflect.ownKeys(n)) {
          if (!Object.prototype.hasOwnProperty.call(i, a))
            throw new Error(`Unrecognized key: "${String(a)}"`);
          n[a] && (i[a] = new e({
            type: "nonoptional",
            innerType: r[a]
          }));
        }
      else
        for (let a of Reflect.ownKeys(r))
          i[a] = new e({
            type: "nonoptional",
            innerType: r[a]
          });
      return Y(this, "shape", i), i;
    }
  });
  return C(t, o);
}
s(qy, "required");
function Xe(e, t = 0) {
  if (e.aborted === !0)
    return !0;
  for (let n = t; n < e.issues.length; n++)
    if (e.issues[n]?.continue !== !0)
      return !0;
  return !1;
}
s(Xe, "aborted");
function os(e, t = 0) {
  if (e.aborted === !0)
    return !0;
  for (let n = t; n < e.issues.length; n++)
    if (e.issues[n]?.continue === !1)
      return !0;
  return !1;
}
s(os, "explicitlyAborted");
function me(e, t) {
  return t.map((n) => {
    var o;
    return (o = n).path ?? (o.path = []), n.path.unshift(e), n;
  });
}
s(me, "prefixIssues");
function Xt(e) {
  return typeof e == "string" ? e : e?.message;
}
s(Xt, "unwrapMessage");
function di(e, t, n) {
  var o;
  for (let r = t; r < e.length; r++)
    (o = e[r]).schema ?? (o.schema = n);
}
s(di, "attachSchema");
function ge(e, t, n) {
  var o;
  let r = e.inst?._zod?.traits;
  r?.has("$ZodType") && (r.has("$ZodCheck") ? (o = e).schema ?? (o.schema = e.inst) : e.schema = e.inst);
  let i = e.schema !== e.inst ? e.schema?._zod.def?.error : void 0, a = e.message ? e.message : Xt(e.inst?._zod.def?.error?.(e)) ?? Xt(i?.(e)) ?? Xt(t?.error?.(e)) ?? Xt(n.customError?.(e)) ?? Xt(n.localeError?.(e)) ?? "Invalid input", { inst: u, schema: c, continue: l, input: d, ...f } = e;
  return f.path ?? (f.path = []), f.message = a, t?.reportInput && (f.input = d), f;
}
s(ge, "finalizeIssue");
function Xr(e) {
  return e instanceof Set ? "set" : e instanceof Map ? "map" : e instanceof File ? "file" : "unknown";
}
s(Xr, "getSizableOrigin");
var Wy = /[\uD800-\uDBFF]/;
function xt(e) {
  let t = e.length;
  if (!Wy.test(e))
    return t;
  let n = t;
  for (let o = 0; o < t - 1; o++)
    (e.charCodeAt(o) & 64512) === 55296 && (e.charCodeAt(o + 1) & 64512) === 56320 && (n--, o++);
  return n;
}
s(xt, "codePointLength");
function Hr(e) {
  return Array.isArray(e) ? "array" : typeof e == "string" ? "string" : "unknown";
}
s(Hr, "getLengthableOrigin");
function b(e) {
  let t = typeof e;
  switch (t) {
    case "number":
      return Number.isNaN(e) ? "nan" : "number";
    case "object": {
      if (e === null)
        return "null";
      if (Array.isArray(e))
        return "array";
      let n = e;
      if (n && Object.getPrototypeOf(n) !== Object.prototype && "constructor" in n && n.constructor)
        return n.constructor.name;
    }
  }
  return t;
}
s(b, "parsedType");
function er(...e) {
  let [t, n, o] = e;
  return typeof t == "string" ? {
    message: t,
    code: "custom",
    input: n,
    inst: o
  } : { ...t };
}
s(er, "issue");
function Ky(e) {
  return Object.entries(e).filter(([t, n]) => Number.isNaN(Number.parseInt(t, 10))).map((t) => t[1]);
}
s(Ky, "cleanEnum");
function om(e) {
  let t = atob(e), n = new Uint8Array(t.length);
  for (let o = 0; o < t.length; o++)
    n[o] = t.charCodeAt(o);
  return n;
}
s(om, "base64ToUint8Array");
function am(e) {
  let t = "";
  for (let n = 0; n < e.length; n++)
    t += String.fromCharCode(e[n]);
  return btoa(t);
}
s(am, "uint8ArrayToBase64");
function Gy(e) {
  let t = e.replace(/-/g, "+").replace(/_/g, "/"), n = "=".repeat((4 - t.length % 4) % 4);
  return om(t + n);
}
s(Gy, "base64urlToUint8Array");
function Xy(e) {
  return am(e).replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, "");
}
s(Xy, "uint8ArrayToBase64url");
function Hy(e) {
  let t = e.replace(/^0x/, "");
  if (t.length % 2 !== 0)
    throw new Error("Invalid hex string length");
  let n = new Uint8Array(t.length / 2);
  for (let o = 0; o < t.length; o += 2)
    n[o / 2] = Number.parseInt(t.slice(o, o + 2), 16);
  return n;
}
s(Hy, "hexToUint8Array");
function Qy(e) {
  return Array.from(e).map((t) => t.toString(16).padStart(2, "0")).join("");
}
s(Qy, "uint8ArrayToHex");
var Ha = class {
  static {
    s(this, "Class");
  }
  constructor(...t) {
  }
};
function as(e, t) {
  for (let n in t) {
    let o = Object.getOwnPropertyDescriptor(t, n);
    o.get ? Object.defineProperty(e, n, { ...o, enumerable: !1 }) : Yy(e, n, o.value);
  }
}
s(as, "members");
function Ht(e, t, n, o = !0) {
  return Object.defineProperty(e, t, { configurable: !0, writable: !0, enumerable: o, value: n }), n;
}
s(Ht, "own");
function ss(e, t, n) {
  return Ht(e, t, n, !1);
}
s(ss, "hide");
function Yy(e, t, n) {
  Object.defineProperty(e, t, {
    configurable: !0,
    get() {
      return this == null ? n : Ht(this, t, n.bind(this));
    },
    set(o) {
      Ht(this, t, o);
    }
  });
}
s(Yy, "defineBound");
function e$(e, t) {
  let n = Object.getPrototypeOf(e);
  return t in n ? void 0 : n;
}
s(e$, "claim");
var Xa, Ge = !1, t$ = {
  configurable: !0,
  get() {
    Ge = !0;
  }
};
function E(e, t, n) {
  let o = Object.getPrototypeOf(e._zod);
  if (t in o && Xa !== e._zod) {
    Xa = void 0;
    return;
  }
  Xa = e._zod, Object.defineProperty(o, t, {
    configurable: !0,
    get() {
      Object.defineProperty(this, t, t$);
      let r = Ge;
      Ge = !1;
      try {
        let i = n(this);
        return Ge ? delete this[t] : Object.defineProperty(this, t, { configurable: !0, writable: !0, value: i }), Ge = Ge || r, i;
      } catch (i) {
        throw delete this[t], Ge = Ge || r, i;
      }
    },
    set(r) {
      Object.defineProperty(this, t, { configurable: !0, writable: !0, value: r });
    }
  });
}
s(E, "defineLazyInternal");
function r$(e, t, n, o) {
  let r = e$(e, t);
  r && Object.defineProperty(r, t, {
    configurable: !0,
    get() {
      let i = { configurable: !0, writable: !0, enumerable: o, value: void 0 };
      return Object.defineProperty(this, t, i), i.value = n(this), Object.defineProperty(this, t, i), i.value;
    },
    set(i) {
      Object.defineProperty(this, t, { configurable: !0, writable: !0, enumerable: o, value: i });
    }
  });
}
s(r$, "installLazyProp");
var fi = "~constantCatch";
function us(e) {
  let t = /* @__PURE__ */ s(() => e, "fn");
  return t[fi] = !0, t;
}
s(us, "constantCatch");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/core.js
var sm, ls = /* @__PURE__ */ Object.freeze({
  status: "aborted"
}), cs = { value: void 0, enumerable: !1 }, um = "captureStackTrace" in Error ? Error : null;
function n$(e) {
  let t = um;
  if (t) {
    let n = t.stackTraceLimit;
    if (typeof n == "number") {
      try {
        t.stackTraceLimit = 0;
      } catch {
        return um = null, new e();
      }
      try {
        return new e();
      } finally {
        t.stackTraceLimit = n;
      }
    }
  }
  return new e();
}
s(n$, "newError");
// @__NO_SIDE_EFFECTS__
function g(e, t, n, o) {
  let r = {};
  function i(p) {
    this.def = p, this.constr = f, this.traits = /* @__PURE__ */ new Set();
  }
  s(i, "Internals"), i.prototype = r;
  let a = n, u = a && /* @__PURE__ */ new WeakSet();
  function c(p, m) {
    if (!p._zod) {
      cs.value = new i(m);
      try {
        Object.defineProperty(p, "_zod", cs);
      } finally {
        cs.value = void 0;
      }
    }
    if (p._zod.traits.has(e))
      return;
    if (p._zod.traits.add(e), t(p, m), u) {
      let x = Object.getPrototypeOf(p), k = p._zod.constr.prototype, R = x;
      for (; R && R !== k; )
        R = Object.getPrototypeOf(R);
      let j = R ?? x;
      u.has(j) || (u.add(j), as(j, a));
    }
    let v = f.prototype;
    for (let x in v)
      Object.prototype.hasOwnProperty.call(v, x) && (x in p || (p[x] = v[x].bind(p)));
  }
  s(c, "init");
  let l = o?.Parent ?? Object;
  class d extends l {
    static {
      s(this, "Definition");
    }
  }
  Object.defineProperty(d, "name", { value: e });
  function f(p) {
    let m = o?.Parent ? n$(d) : this;
    c(m, p);
    let v = m._zod.deferred;
    if (v) {
      for (let k of v)
        k();
      m._zod.deferred = void 0;
    }
    let x = globalThis.__zod_globalConfig?.postProcessor;
    return x && x(m), m;
  }
  return s(f, "_"), Object.defineProperty(f, "init", { value: c }), Object.defineProperty(f, Symbol.hasInstance, {
    value: /* @__PURE__ */ s((p) => o?.Parent && p instanceof o.Parent ? !0 : p?._zod?.traits?.has(e), "value")
  }), Object.defineProperty(f, "name", { value: e }), f;
}
s(g, "$constructor");
var ds = /* @__PURE__ */ Symbol("zod_brand"), he = class extends Error {
  static {
    s(this, "$ZodAsyncError");
  }
  constructor() {
    super("Encountered Promise during synchronous parse. Use .parseAsync() instead.");
  }
}, He = class extends Error {
  static {
    s(this, "$ZodEncodeError");
  }
  constructor(t) {
    super(`Encountered unidirectional transform during encode: ${t}`), this.name = "ZodEncodeError";
  }
};
(sm = globalThis).__zod_globalConfig ?? (sm.__zod_globalConfig = {});
var ae = globalThis.__zod_globalConfig;
function te(e) {
  return e && Object.assign(ae, e), ae;
}
s(te, "config");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/errors.js
function i$() {
  let e = this._zod;
  return e.message ?? (e.message = JSON.stringify(e.def, Qt, 2)), e.message;
}
s(i$, "_getMessage");
function o$(e) {
  this._zod.message = e;
}
s(o$, "_setMessage");
var a$ = {
  get: i$,
  set: o$,
  enumerable: !0,
  configurable: !0
}, ps = { value: void 0, enumerable: !1 }, ms = { value: void 0, enumerable: !1 }, cm = /* @__PURE__ */ new WeakSet([Object.prototype, Error.prototype]), lm = /* @__PURE__ */ s((e, t) => {
  e.name = "$ZodError", ps.value = e._zod, Object.defineProperty(e, "_zod", ps), ms.value = t, Object.defineProperty(e, "issues", ms), ps.value = void 0, ms.value = void 0, Object.defineProperty(e, "message", a$);
  let n = Object.getPrototypeOf(e);
  cm.has(n) || (cm.add(n), Object.defineProperty(n, "toString", {
    configurable: !0,
    enumerable: !1,
    get() {
      let o = /* @__PURE__ */ s(() => this.message, "value");
      return Object.defineProperty(this, "toString", { value: o, configurable: !0, writable: !0 }), o;
    },
    set(o) {
      Object.defineProperty(this, "toString", { value: o, configurable: !0, writable: !0 });
    }
  }));
}, "initializer"), De = g("$ZodError", lm), ve = g("$ZodError", lm, void 0, {
  Parent: Error
});
function s$(e, t, n) {
  return Object.prototype.hasOwnProperty.call(e, t) || (t === "__proto__" ? Object.defineProperty(e, t, { value: n(), writable: !0, enumerable: !0, configurable: !0 }) : e[t] = n()), e[t];
}
s(s$, "node");
function Qr(e, t = (n) => n.message) {
  let n = {}, o = [];
  for (let r of e.issues)
    r.path.length > 0 ? s$(n, r.path[0], () => []).push(t(r)) : o.push(t(r));
  return { formErrors: o, fieldErrors: n };
}
s(Qr, "flattenError");
function Yr(e, t = (n) => n.message) {
  let n = { _errors: [] }, o = /* @__PURE__ */ s((r, i = []) => {
    for (let a of r.issues)
      if (a.code === "invalid_union" && a.errors.length)
        a.errors.map((u) => o({ issues: u }, [...i, ...a.path]));
      else if (a.code === "invalid_key")
        o({ issues: a.issues }, [...i, ...a.path]);
      else if (a.code === "invalid_element")
        o({ issues: a.issues }, [...i, ...a.path]);
      else {
        let u = [...i, ...a.path];
        if (u.length === 0)
          n._errors.push(t(a));
        else {
          let c = n, l = 0;
          for (; l < u.length; ) {
            let d = u[l], f = l === u.length - 1;
            if (d === "_errors") {
              f && c._errors.push(t(a)), l++;
              continue;
            }
            Object.prototype.hasOwnProperty.call(c, d) || Object.defineProperty(c, d, {
              value: { _errors: [] },
              enumerable: !0,
              writable: !0,
              configurable: !0
            });
            let p = c[d];
            f && p._errors.push(t(a)), c = p, l++;
          }
        }
      }
  }, "processError");
  return o(e), n;
}
s(Yr, "formatError");
function gs(e, t = (n) => n.message) {
  let n = { errors: [] }, o = /* @__PURE__ */ s((r, i = []) => {
    var a;
    for (let u of r.issues)
      if (u.code === "invalid_union" && u.errors.length)
        u.errors.map((c) => o({ issues: c }, [...i, ...u.path]));
      else if (u.code === "invalid_key")
        o({ issues: u.issues }, [...i, ...u.path]);
      else if (u.code === "invalid_element")
        o({ issues: u.issues }, [...i, ...u.path]);
      else {
        let c = [...i, ...u.path];
        if (c.length === 0) {
          n.errors.push(t(u));
          continue;
        }
        let l = n, d = 0;
        for (; d < c.length; ) {
          let f = c[d], p = d === c.length - 1;
          typeof f == "string" ? (l.properties ?? (l.properties = {}), Object.prototype.hasOwnProperty.call(l.properties, f) || Object.defineProperty(l.properties, f, {
            value: { errors: [] },
            enumerable: !0,
            writable: !0,
            configurable: !0
          }), l = l.properties[f]) : (l.items ?? (l.items = []), (a = l.items)[f] ?? (a[f] = { errors: [] }), l = l.items[f]), p && l.errors.push(t(u)), d++;
        }
      }
  }, "processError");
  return o(e), n;
}
s(gs, "treeifyError");
function dm(e) {
  let t = [], n = e.map((o) => typeof o == "object" ? o.key : o);
  for (let o of n)
    typeof o == "number" ? t.push(`[${o}]`) : typeof o == "symbol" ? t.push(`[${JSON.stringify(String(o))}]`) : /[^\w$]/.test(o) ? t.push(`[${JSON.stringify(o)}]`) : (t.length && t.push("."), t.push(o));
  return t.join("");
}
s(dm, "toDotPath");
function hs(e) {
  let t = [], n = [...e.issues].sort((o, r) => (o.path ?? []).length - (r.path ?? []).length);
  for (let o of n)
    t.push(`\u2716 ${o.message}`), o.path?.length && t.push(`  \u2192 at ${dm(o.path)}`);
  return t.join(`
`);
}
s(hs, "prettifyError");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/parse.js
function pi(e, t) {
  return { callee: t?.callee ?? e, Err: t?.Err };
}
s(pi, "finalizeParams");
var tr = /* @__PURE__ */ s((e) => {
  let t = /* @__PURE__ */ s((n, o, r, i) => {
    let a = r ? { ...r, async: !1 } : { async: !1 }, u = n._zod.run({ value: o, issues: [] }, a);
    if (u instanceof Promise)
      throw new he();
    if (u.issues.length) {
      let c = new (i?.Err ?? e)(u.issues.map((l) => ge(l, a, te())));
      throw li(c, i?.callee ?? t), c;
    }
    return u.value;
  }, "fn");
  return t;
}, "_parse"), Qe = /* @__PURE__ */ tr(ve), rr = /* @__PURE__ */ s((e) => {
  let t = /* @__PURE__ */ s(async (n, o, r, i) => {
    let a = r ? { ...r, async: !0 } : { async: !0 }, u = n._zod.run({ value: o, issues: [] }, a);
    if (u instanceof Promise && (u = await u), u.issues.length) {
      let c = new (i?.Err ?? e)(u.issues.map((l) => ge(l, a, te())));
      throw li(c, i?.callee ?? t), c;
    }
    return u.value;
  }, "fn");
  return t;
}, "_parseAsync"), mi = /* @__PURE__ */ rr(ve), nr = /* @__PURE__ */ s((e) => (t, n, o) => {
  let r = o ? { ...o, async: !1 } : { async: !1 }, i = t._zod.run({ value: n, issues: [] }, r);
  if (i instanceof Promise)
    throw new he();
  return i.issues.length ? {
    success: !1,
    error: new (e ?? De)(i.issues.map((a) => ge(a, r, te())))
  } : { success: !0, data: i.value };
}, "_safeParse"), wt = /* @__PURE__ */ nr(ve), ir = /* @__PURE__ */ s((e) => async (t, n, o) => {
  let r = o ? { ...o, async: !0 } : { async: !0 }, i = t._zod.run({ value: n, issues: [] }, r);
  return i instanceof Promise && (i = await i), i.issues.length ? {
    success: !1,
    error: new e(i.issues.map((a) => ge(a, r, te())))
  } : { success: !0, data: i.value };
}, "_safeParseAsync"), vs = /* @__PURE__ */ ir(ve), c$ = /* @__PURE__ */ Symbol.for("zod.compile.invalid"), l$ = /* @__PURE__ */ Symbol.for("zod.compile.fallback"), ys = /* @__PURE__ */ s(((e, t, n) => {
  let o = e._zod.bag.validator;
  return o !== void 0 && o(t) !== c$ ? !0 : d$(e, t, n);
}), "validate");
function d$(e, t, n) {
  let o = n ? { ...n, async: !1 } : { async: !1 }, r = e._zod.bag.fallbackRun, i;
  if (r ? (o[l$] = !0, i = r({ value: t, issues: [] }, o)) : i = e._zod.run({ value: t, issues: [] }, o), i instanceof Promise)
    throw new he();
  return i.issues.length === 0;
}
s(d$, "validateFallback");
var $s = /* @__PURE__ */ s(async (e, t, n) => {
  let o = n ? { ...n, async: !0 } : { async: !0 }, r = e._zod.run({ value: t, issues: [] }, o);
  return r instanceof Promise && (r = await r), r.issues.length === 0;
}, "validateAsync"), gi = /* @__PURE__ */ s((e) => {
  let t = tr(e), n = /* @__PURE__ */ s((o, r, i, a) => {
    let u = i ? { ...i, direction: "backward" } : { direction: "backward" };
    return t(o, r, u, pi(n, a));
  }, "fn");
  return n;
}, "_encode"), Ne = /* @__PURE__ */ gi(ve), hi = /* @__PURE__ */ s((e) => {
  let t = tr(e), n = /* @__PURE__ */ s((o, r, i, a) => t(o, r, i, pi(n, a)), "fn");
  return n;
}, "_decode"), f$ = /* @__PURE__ */ hi(ve), vi = /* @__PURE__ */ s((e) => {
  let t = rr(e), n = /* @__PURE__ */ s(async (o, r, i, a) => {
    let u = i ? { ...i, direction: "backward" } : { direction: "backward" };
    return await t(o, r, u, pi(n, a));
  }, "fn");
  return n;
}, "_encodeAsync"), p$ = /* @__PURE__ */ vi(ve), yi = /* @__PURE__ */ s((e) => {
  let t = rr(e), n = /* @__PURE__ */ s(async (o, r, i, a) => await t(o, r, i, pi(n, a)), "fn");
  return n;
}, "_decodeAsync"), m$ = /* @__PURE__ */ yi(ve), $i = /* @__PURE__ */ s((e) => (t, n, o) => {
  let r = o ? { ...o, direction: "backward" } : { direction: "backward" };
  return nr(e)(t, n, r);
}, "_safeEncode"), g$ = /* @__PURE__ */ $i(ve), bi = /* @__PURE__ */ s((e) => (t, n, o) => nr(e)(t, n, o), "_safeDecode"), h$ = /* @__PURE__ */ bi(ve), _i = /* @__PURE__ */ s((e) => async (t, n, o) => {
  let r = o ? { ...o, direction: "backward" } : { direction: "backward" };
  return ir(e)(t, n, r);
}, "_safeEncodeAsync"), v$ = /* @__PURE__ */ _i(ve), xi = /* @__PURE__ */ s((e) => async (t, n, o) => ir(e)(t, n, o), "_safeDecodeAsync"), y$ = /* @__PURE__ */ xi(ve);

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/regexes.js
var ce = {};
Be(ce, {
  base64: () => Cs,
  base64url: () => wi,
  bigint: () => Bs,
  boolean: () => Js,
  browserEmail: () => z$,
  cidrv4: () => Us,
  cidrv6: () => Es,
  creditCard: () => ki,
  cuid: () => _s,
  cuid2: () => xs,
  date: () => Fs,
  datetime: () => Vs,
  domain: () => j$,
  duration: () => Os,
  e164: () => Rs,
  email: () => Ps,
  emoji: () => Ds,
  extendedDuration: () => $$,
  guid: () => js,
  hex: () => D$,
  hostname: () => O$,
  html5Email: () => w$,
  httpProtocol: () => Zs,
  idnEmail: () => I$,
  integer: () => en,
  ipv4: () => Ns,
  ipv6: () => Ts,
  ksuid: () => Is,
  lowercase: () => Ks,
  mac: () => As,
  md5_base64: () => T$,
  md5_base64url: () => A$,
  md5_hex: () => N$,
  nanoid: () => zs,
  nanoidOfLength: () => Ss,
  null: () => qs,
  number: () => Ye,
  rfc5322Email: () => k$,
  sha1_base64: () => E$,
  sha1_base64url: () => C$,
  sha1_hex: () => U$,
  sha256_base64: () => R$,
  sha256_base64url: () => F$,
  sha256_hex: () => Z$,
  sha384_base64: () => V$,
  sha384_base64url: () => M$,
  sha384_hex: () => L$,
  sha512_base64: () => J$,
  sha512_base64url: () => q$,
  sha512_hex: () => B$,
  string: () => Ms,
  time: () => Ls,
  ulid: () => ws,
  undefined: () => Ws,
  unicodeEmail: () => fm,
  uppercase: () => Gs,
  uuid: () => kt,
  uuid4: () => b$,
  uuid6: () => _$,
  uuid7: () => x$,
  xid: () => ks
});
var _s = /^[cC][0-9a-z]{6,}$/, xs = /^[0-9a-z]+$/, ws = /^[0-7][0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{25}$/, ks = /^[0-9a-vA-V]{20}$/, Is = /^[A-Za-z0-9]{27}$/, zs = /^[a-zA-Z0-9_-]{21}$/;
function Ss(e) {
  return new RegExp(`^[a-zA-Z0-9_-]{${e}}$`);
}
s(Ss, "nanoidOfLength");
var Os = /^P(?:(\d+W)|(?!.*W)(?=\d|T\d)(\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+([.,]\d+)?S)?)?)$/, $$ = /^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/, js = /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/, kt = /* @__PURE__ */ s((e) => e ? new RegExp(`^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${e}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`) : /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/, "uuid"), b$ = /* @__PURE__ */ kt(4), _$ = /* @__PURE__ */ kt(6), x$ = /* @__PURE__ */ kt(7), Ps = /^(?!\.)(?!.*\.\.)([A-Za-z0-9_'+\-\.]*)[A-Za-z0-9_+-]@([A-Za-z0-9][A-Za-z0-9\-]*\.)+[A-Za-z]{2,}$/, w$ = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/, k$ = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/, fm = /^[^\s@"]{1,64}@[^\s@]{1,255}$/u, I$ = fm, z$ = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/, S$ = "^[\\p{Extended_Pictographic}\\p{Emoji_Component}]+$";
function Ds() {
  return new RegExp(S$, "u");
}
s(Ds, "emoji");
var Ns = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/, Ts = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))$/, As = /* @__PURE__ */ s((e) => {
  let t = Oe(e ?? ":");
  return new RegExp(`^(?:[0-9A-F]{2}${t}){5}[0-9A-F]{2}$|^(?:[0-9a-f]{2}${t}){5}[0-9a-f]{2}$`);
}, "mac"), Us = /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/([0-9]|[1-2][0-9]|3[0-2])$/, Es = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/, Cs = /^$|^(?:[0-9a-zA-Z+/]{4})*(?:(?:[0-9a-zA-Z+/]{2}==)|(?:[0-9a-zA-Z+/]{3}=))?$/, wi = /^[A-Za-z0-9_-]*$/, O$ = /^(?=.{1,253}\.?$)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[-0-9a-zA-Z]{0,61}[0-9a-zA-Z])?)*\.?$/, j$ = /^(?=.{1,253}$)([a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,63}$/, Zs = /^https?$/, Rs = /^\+[1-9]\d{6,14}$/, ki = /^\d(?:[ -]?\d){11,18}$/, pm = "(?:(?:\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-(?:(?:0[13578]|1[02])-(?:0[1-9]|[12]\\d|3[01])|(?:0[469]|11)-(?:0[1-9]|[12]\\d|30)|(?:02)-(?:0[1-9]|1\\d|2[0-8])))";
function P$(e) {
  return new RegExp(`^${e}$`);
}
s(P$, "anchor");
var Fs = /* @__PURE__ */ P$(pm);
function bs(e) {
  let t = "(?:[01]\\d|2[0-3]):[0-5]\\d";
  return typeof e.precision == "number" ? e.precision === -1 ? `${t}` : e.precision === 0 ? `${t}:[0-5]\\d` : `${t}:[0-5]\\d\\.\\d{${e.precision}}` : e.seconds ? `${t}:[0-5]\\d(?:\\.\\d+)?` : `${t}(?::[0-5]\\d(?:\\.\\d+)?)?`;
}
s(bs, "timeSource");
function Ls(e) {
  return new RegExp(`^${bs(e)}$`);
}
s(Ls, "time");
function Vs(e) {
  let t = ["Z"];
  e.offset && t.push("([+-](?:[01]\\d|2[0-3]):[0-5]\\d)");
  let n = `${bs({ precision: e.precision, seconds: !0 })}(?:${t.join("|")})`, o = e.local ? `${n}|${bs({ precision: e.precision })}` : n;
  return new RegExp(`^${pm}T(?:${o})$`);
}
s(Vs, "datetime");
var Ms = /* @__PURE__ */ s((e) => {
  let t = e ? `[\\s\\S]{${e?.minimum ?? 0},${e?.maximum ?? ""}}` : "[\\s\\S]*";
  return new RegExp(`^${t}$`);
}, "string"), Bs = /^-?\d+n?$/, en = /^-?\d+$/, Ye = /^-?\d+(?:\.\d+)?$/, Js = /^(?:true|false)$/i, qs = /^null$/i;
var Ws = /^undefined$/i;
var Ks = /^[^A-Z]*$/, Gs = /^[^a-z]*$/, D$ = /^[0-9a-fA-F]*$/;
function tn(e, t) {
  return new RegExp(`^[A-Za-z0-9+/]{${e}}${t}$`);
}
s(tn, "fixedBase64");
function rn(e) {
  return new RegExp(`^[A-Za-z0-9_-]{${e}}$`);
}
s(rn, "fixedBase64url");
var N$ = /^[0-9a-fA-F]{32}$/, T$ = /* @__PURE__ */ tn(22, "=="), A$ = /* @__PURE__ */ rn(22), U$ = /^[0-9a-fA-F]{40}$/, E$ = /* @__PURE__ */ tn(27, "="), C$ = /* @__PURE__ */ rn(27), Z$ = /^[0-9a-fA-F]{64}$/, R$ = /* @__PURE__ */ tn(43, "="), F$ = /* @__PURE__ */ rn(43), L$ = /^[0-9a-fA-F]{96}$/, V$ = /* @__PURE__ */ tn(64, ""), M$ = /* @__PURE__ */ rn(64), B$ = /^[0-9a-fA-F]{128}$/, J$ = /* @__PURE__ */ tn(86, "=="), q$ = /* @__PURE__ */ rn(86);

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/checks.js
var K = /* @__PURE__ */ g("$ZodCheck", (e, t) => {
  var n;
  e._zod ?? (e._zod = {}), e._zod.def = t, (n = e._zod).onattach ?? (n.onattach = []);
}), Xs = /* @__PURE__ */ s((e) => {
  let t = e.value;
  return !ci(t) && t.size !== void 0;
}, "_whenHasSize"), Hs = /* @__PURE__ */ s((e) => {
  let t = e.value;
  return !ci(t) && t.length !== void 0;
}, "_whenHasLength"), Ii = {
  number: "number",
  bigint: "bigint",
  object: "date"
}, zi = /* @__PURE__ */ g("$ZodCheckLessThan", (e, t) => {
  K.init(e, t);
  let n = Ii[typeof t.value];
  e._zod.onattach.push((o) => {
    let r = o._zod.bag, i = (t.inclusive ? r.maximum : r.exclusiveMaximum) ?? Number.POSITIVE_INFINITY;
    t.value < i && (t.inclusive ? r.maximum = t.value : r.exclusiveMaximum = t.value);
  }), e._zod.check = (o) => {
    (t.inclusive ? o.value <= t.value : o.value < t.value) || o.issues.push({
      origin: Ii[typeof o.value] ?? n,
      code: "too_big",
      maximum: typeof t.value == "object" ? t.value.getTime() : t.value,
      input: o.value,
      inclusive: t.inclusive,
      inst: e,
      continue: !t.abort
    });
  };
}), Si = /* @__PURE__ */ g("$ZodCheckGreaterThan", (e, t) => {
  K.init(e, t);
  let n = Ii[typeof t.value];
  e._zod.onattach.push((o) => {
    let r = o._zod.bag, i = (t.inclusive ? r.minimum : r.exclusiveMinimum) ?? Number.NEGATIVE_INFINITY;
    t.value > i && (t.inclusive ? r.minimum = t.value : r.exclusiveMinimum = t.value);
  }), e._zod.check = (o) => {
    (t.inclusive ? o.value >= t.value : o.value > t.value) || o.issues.push({
      origin: Ii[typeof o.value] ?? n,
      code: "too_small",
      minimum: typeof t.value == "object" ? t.value.getTime() : t.value,
      input: o.value,
      inclusive: t.inclusive,
      inst: e,
      continue: !t.abort
    });
  };
}), Qs = /* @__PURE__ */ g("$ZodCheckMultipleOf", (e, t) => {
  K.init(e, t), e._zod.onattach.push((n) => {
    var o;
    (o = n._zod.bag).multipleOf ?? (o.multipleOf = t.value);
  }), e._zod.check = (n) => {
    if (typeof n.value != typeof t.value)
      throw new Error("Cannot mix number and bigint in multiple_of check.");
    (typeof n.value == "bigint" ? (
      // `value % 0n` throws, and nothing is a multiple of zero — the number branch already fails this way via NaN
      t.value !== BigInt(0) && n.value % t.value === BigInt(0)
    ) : Wr(n.value, t.value) === 0) || n.issues.push({
      origin: typeof n.value,
      code: "not_multiple_of",
      divisor: t.value,
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Ys = /* @__PURE__ */ g("$ZodCheckNumberFormat", (e, t) => {
  K.init(e, t), t.format = t.format || "float64";
  let n = t.format?.includes("int"), o = n ? "int" : "number", [r, i] = ns[t.format];
  e._zod.onattach.push((a) => {
    let u = a._zod.bag;
    u.format = t.format, u.minimum = r, u.maximum = i, n && (u.pattern = en);
  }), e._zod.check = (a) => {
    let u = a.value;
    if (n) {
      if (!Number.isInteger(u)) {
        a.issues.push({
          expected: o,
          format: t.format,
          code: "invalid_type",
          continue: !1,
          input: u,
          inst: e
        });
        return;
      }
      if (!Number.isSafeInteger(u)) {
        u > 0 ? a.issues.push({
          input: u,
          code: "too_big",
          maximum: Number.MAX_SAFE_INTEGER,
          note: "Integers must be within the safe integer range.",
          inst: e,
          origin: o,
          inclusive: !0,
          continue: !t.abort
        }) : a.issues.push({
          input: u,
          code: "too_small",
          minimum: Number.MIN_SAFE_INTEGER,
          note: "Integers must be within the safe integer range.",
          inst: e,
          origin: o,
          inclusive: !0,
          continue: !t.abort
        });
        return;
      }
    }
    u < r && a.issues.push({
      origin: "number",
      input: u,
      code: "too_small",
      minimum: r,
      inclusive: !0,
      inst: e,
      continue: !t.abort
    }), u > i && a.issues.push({
      origin: "number",
      input: u,
      code: "too_big",
      maximum: i,
      inclusive: !0,
      inst: e,
      continue: !t.abort
    });
  };
}), eu = /* @__PURE__ */ g("$ZodCheckBigIntFormat", (e, t) => {
  K.init(e, t);
  let [n, o] = is[t.format];
  e._zod.onattach.push((r) => {
    let i = r._zod.bag;
    i.format = t.format, i.minimum = n, i.maximum = o;
  }), e._zod.check = (r) => {
    let i = r.value;
    i < n && r.issues.push({
      origin: "bigint",
      input: i,
      code: "too_small",
      minimum: n,
      inclusive: !0,
      inst: e,
      continue: !t.abort
    }), i > o && r.issues.push({
      origin: "bigint",
      input: i,
      code: "too_big",
      maximum: o,
      inclusive: !0,
      inst: e,
      continue: !t.abort
    });
  };
}), tu = /* @__PURE__ */ g("$ZodCheckMaxSize", (e, t) => {
  var n;
  K.init(e, t), (n = e._zod.def).when ?? (n.when = Xs), e._zod.onattach.push((o) => {
    let r = o._zod.bag.maximum ?? Number.POSITIVE_INFINITY;
    t.maximum < r && (o._zod.bag.maximum = t.maximum);
  }), e._zod.check = (o) => {
    let r = o.value;
    r.size <= t.maximum || o.issues.push({
      origin: Xr(r),
      code: "too_big",
      maximum: t.maximum,
      inclusive: !0,
      input: r,
      inst: e,
      continue: !t.abort
    });
  };
}), ru = /* @__PURE__ */ g("$ZodCheckMinSize", (e, t) => {
  var n;
  K.init(e, t), (n = e._zod.def).when ?? (n.when = Xs), e._zod.onattach.push((o) => {
    let r = o._zod.bag.minimum ?? Number.NEGATIVE_INFINITY;
    t.minimum > r && (o._zod.bag.minimum = t.minimum);
  }), e._zod.check = (o) => {
    let r = o.value;
    r.size >= t.minimum || o.issues.push({
      origin: Xr(r),
      code: "too_small",
      minimum: t.minimum,
      inclusive: !0,
      input: r,
      inst: e,
      continue: !t.abort
    });
  };
}), nu = /* @__PURE__ */ g("$ZodCheckSizeEquals", (e, t) => {
  var n;
  K.init(e, t), (n = e._zod.def).when ?? (n.when = Xs), e._zod.onattach.push((o) => {
    let r = o._zod.bag;
    r.minimum = t.size, r.maximum = t.size, r.size = t.size;
  }), e._zod.check = (o) => {
    let r = o.value, i = r.size;
    if (i === t.size)
      return;
    let a = i > t.size;
    o.issues.push({
      origin: Xr(r),
      ...a ? { code: "too_big", maximum: t.size } : { code: "too_small", minimum: t.size },
      inclusive: !0,
      exact: !0,
      input: o.value,
      inst: e,
      continue: !t.abort
    });
  };
}), iu = /* @__PURE__ */ g("$ZodCheckMaxLength", (e, t) => {
  var n;
  K.init(e, t), (n = e._zod.def).when ?? (n.when = Hs), e._zod.onattach.push((o) => {
    let r = o._zod.bag.maximum ?? Number.POSITIVE_INFINITY;
    t.maximum < r && (o._zod.bag.maximum = t.maximum);
  }), e._zod.check = (o) => {
    let r = o.value, i = r.length;
    if ((typeof r == "string" && i > t.maximum ? xt(r) : i) <= t.maximum)
      return;
    let u = Hr(r);
    o.issues.push({
      origin: u,
      code: "too_big",
      maximum: t.maximum,
      inclusive: !0,
      input: r,
      inst: e,
      continue: !t.abort
    });
  };
}), ou = /* @__PURE__ */ g("$ZodCheckMinLength", (e, t) => {
  var n;
  K.init(e, t), (n = e._zod.def).when ?? (n.when = Hs), e._zod.onattach.push((o) => {
    let r = o._zod.bag.minimum ?? Number.NEGATIVE_INFINITY;
    t.minimum > r && (o._zod.bag.minimum = t.minimum);
  }), e._zod.check = (o) => {
    let r = o.value, i = r.length;
    if ((typeof r == "string" && i >= t.minimum && i < t.minimum * 2 ? xt(r) : i) >= t.minimum)
      return;
    let u = Hr(r);
    o.issues.push({
      origin: u,
      code: "too_small",
      minimum: t.minimum,
      inclusive: !0,
      input: r,
      inst: e,
      continue: !t.abort
    });
  };
}), au = /* @__PURE__ */ g("$ZodCheckLengthEquals", (e, t) => {
  var n;
  K.init(e, t), (n = e._zod.def).when ?? (n.when = Hs), e._zod.onattach.push((o) => {
    let r = o._zod.bag;
    r.minimum = t.length, r.maximum = t.length, r.length = t.length;
  }), e._zod.check = (o) => {
    let r = o.value, i = r.length, a = typeof r == "string" && i >= t.length && i <= t.length * 2 ? xt(r) : i;
    if (a === t.length)
      return;
    let u = Hr(r), c = a > t.length;
    o.issues.push({
      origin: u,
      ...c ? { code: "too_big", maximum: t.length } : { code: "too_small", minimum: t.length },
      inclusive: !0,
      exact: !0,
      input: o.value,
      inst: e,
      continue: !t.abort
    });
  };
}), or = /* @__PURE__ */ g("$ZodCheckStringFormat", (e, t) => {
  var n, o;
  K.init(e, t), e._zod.onattach.push((r) => {
    let i = r._zod.bag;
    i.format = t.format, t.pattern && (i.patterns ?? (i.patterns = /* @__PURE__ */ new Set()), i.patterns.add(t.pattern));
  }), t.pattern ? (n = e._zod).check ?? (n.check = (r) => {
    t.pattern.lastIndex = 0, !t.pattern.test(r.value) && r.issues.push({
      origin: "string",
      code: "invalid_format",
      format: t.format,
      input: r.value,
      ...t.pattern ? { pattern: t.pattern.toString() } : {},
      inst: e,
      continue: !t.abort
    });
  }) : (o = e._zod).check ?? (o.check = () => {
  });
}), su = /* @__PURE__ */ g("$ZodCheckRegex", (e, t) => {
  or.init(e, t), e._zod.check = (n) => {
    t.pattern.lastIndex = 0, !t.pattern.test(n.value) && n.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "regex",
      input: n.value,
      pattern: t.pattern.toString(),
      inst: e,
      continue: !t.abort
    });
  };
}), uu = /* @__PURE__ */ g("$ZodCheckLowerCase", (e, t) => {
  t.pattern ?? (t.pattern = Ks), or.init(e, t);
}), cu = /* @__PURE__ */ g("$ZodCheckUpperCase", (e, t) => {
  t.pattern ?? (t.pattern = Gs), or.init(e, t);
}), lu = /* @__PURE__ */ g("$ZodCheckIncludes", (e, t) => {
  K.init(e, t);
  let n = Oe(t.includes), o = new RegExp(typeof t.position == "number" ? `^.{${t.position},}${n}` : n);
  t.pattern = o, e._zod.onattach.push((r) => {
    let i = r._zod.bag;
    i.patterns ?? (i.patterns = /* @__PURE__ */ new Set()), i.patterns.add(o);
  }), e._zod.check = (r) => {
    r.value.includes(t.includes, t.position) || r.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "includes",
      includes: t.includes,
      input: r.value,
      inst: e,
      continue: !t.abort
    });
  };
}), du = /* @__PURE__ */ g("$ZodCheckStartsWith", (e, t) => {
  K.init(e, t);
  let n = new RegExp(`^${Oe(t.prefix)}.*`);
  t.pattern ?? (t.pattern = n), e._zod.onattach.push((o) => {
    let r = o._zod.bag;
    r.patterns ?? (r.patterns = /* @__PURE__ */ new Set()), r.patterns.add(n);
  }), e._zod.check = (o) => {
    o.value.startsWith(t.prefix) || o.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "starts_with",
      prefix: t.prefix,
      input: o.value,
      inst: e,
      continue: !t.abort
    });
  };
}), fu = /* @__PURE__ */ g("$ZodCheckEndsWith", (e, t) => {
  K.init(e, t);
  let n = new RegExp(`.*${Oe(t.suffix)}$`);
  t.pattern ?? (t.pattern = n), e._zod.onattach.push((o) => {
    let r = o._zod.bag;
    r.patterns ?? (r.patterns = /* @__PURE__ */ new Set()), r.patterns.add(n);
  }), e._zod.check = (o) => {
    o.value.endsWith(t.suffix) || o.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "ends_with",
      suffix: t.suffix,
      input: o.value,
      inst: e,
      continue: !t.abort
    });
  };
});
function mm(e, t, n) {
  e.issues.length && t.issues.push(...me(n, e.issues));
}
s(mm, "handleCheckPropertyResult");
var Oi = /* @__PURE__ */ g("$ZodCheckProperty", (e, t) => {
  K.init(e, t), e._zod.check = (n) => {
    let o = t.schema._zod.run({
      value: n.value[t.property],
      issues: []
    }, {});
    if (o instanceof Promise)
      return o.then((r) => mm(r, n, t.property));
    mm(o, n, t.property);
  };
}), pu = /* @__PURE__ */ g("$ZodCheckMimeType", (e, t) => {
  K.init(e, t);
  let n = new Set(t.mime);
  e._zod.onattach.push((o) => {
    o._zod.bag.mime = t.mime;
  }), e._zod.check = (o) => {
    n.has(o.value.type) || o.issues.push({
      code: "invalid_value",
      values: t.mime,
      input: o.value.type,
      inst: e,
      continue: !t.abort
    });
  };
}), mu = /* @__PURE__ */ g("$ZodCheckOverwrite", (e, t) => {
  K.init(e, t), e._zod.check = (n) => {
    n.value = t.tx(n.value);
  };
});

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/doc.js
var It = class {
  static {
    s(this, "Doc");
  }
  constructor(t = [], n = {}) {
    this.content = [], this.indent = 0, this.args = t, this.closed = n;
  }
  indented(t) {
    this.indent += 1, t(this), this.indent -= 1;
  }
  write(t) {
    if (typeof t == "function") {
      t(this, { execution: "sync" }), t(this, { execution: "async" });
      return;
    }
    let o = t.split(`
`).filter((a) => a), r = Math.min(...o.map((a) => a.length - a.trimStart().length)), i = o.map((a) => a.slice(r)).map((a) => " ".repeat(this.indent * 2) + a);
    for (let a of i)
      this.content.push(a);
  }
  compile() {
    let t = Function, n = this?.content ?? [""];
    return new t(...Object.keys(this.closed), `return function (${this.args.join(", ")}) {
${n.join(`
`)}
};`)(...Object.values(this.closed));
  }
};

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/versions.js
var gu = {
  major: 4,
  minor: 5,
  patch: 4
};

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/schemas.js
var O = /* @__PURE__ */ g("$ZodType", (e, t) => {
  var n;
  e ?? (e = {}), e._zod.def = t, e._zod.bag = e._zod.bag || {}, e._zod.version = gu;
  let o = e._zod.def.checks, r = e._zod.traits.has("$ZodCheck") ? [e, ...o ?? []] : o?.length ? [...o] : [];
  for (let i of r)
    for (let a of i._zod.onattach)
      a(e);
  if (r.length === 0)
    (n = e._zod).deferred ?? (n.deferred = []), e._zod.deferred?.push(() => {
      e._zod.run = e._zod.parse;
    });
  else {
    let i = /* @__PURE__ */ s((u, c, l) => {
      if (u.memo)
        return u;
      let d = Xe(u), f;
      for (let p of c) {
        if (p._zod.def.when) {
          if (os(u) || !p._zod.def.when(u))
            continue;
        } else if (d)
          continue;
        let m = u.issues.length, v = p._zod.check(u);
        if (v instanceof Promise && l?.async === !1)
          throw new he();
        if (f || v instanceof Promise)
          f = (f ?? Promise.resolve()).then(async () => {
            await v, u.issues.length !== m && (di(u.issues, m, e), d || (d = Xe(u, m)));
          });
        else {
          if (u.issues.length === m)
            continue;
          di(u.issues, m, e), d || (d = Xe(u, m));
        }
      }
      return f ? f.then(() => u) : u;
    }, "runChecks"), a = /* @__PURE__ */ s((u, c, l) => {
      if (Xe(u))
        return u.aborted = !0, u;
      let d = i(c, r, l);
      if (d instanceof Promise) {
        if (l.async === !1)
          throw new he();
        return d.then((f) => e._zod.parse(f, l));
      }
      return e._zod.parse(d, l);
    }, "handleCanaryResult");
    e._zod.run = (u, c) => {
      if (c.skipChecks)
        return e._zod.parse(u, c);
      if (c.direction === "backward") {
        let d = e._zod.parse({ value: u.value, issues: [] }, { ...c, skipChecks: !0 });
        return d instanceof Promise ? d.then((f) => a(f, u, c)) : a(d, u, c);
      }
      let l = e._zod.parse(u, c);
      if (l instanceof Promise) {
        if (c.async === !1)
          throw new he();
        return l.then((d) => i(d, r, c));
      }
      return i(l, r, c);
    };
  }
}, {
  // Wrappers extend this by installing a richer factory over it; reading it eagerly would defeat the laziness.
  get "~standard"() {
    return ss(this, "~standard", Ti(this));
  },
  set "~standard"(e) {
    Ht(this, "~standard", e);
  }
}), hm = /* @__PURE__ */ s((e) => e.success ? { value: e.data } : { issues: e.error?.issues }, "toStandardResult");
function Ti(e) {
  return {
    validate: /* @__PURE__ */ s((t) => {
      try {
        return hm(wt(e, t));
      } catch {
        return vs(e, t).then(hm);
      }
    }, "validate"),
    vendor: "zod",
    version: 1
  };
}
s(Ti, "standardProps");
var zt = /* @__PURE__ */ g("$ZodString", (e, t) => {
  O.init(e, t), e._zod.pattern = [...e?._zod.bag?.patterns ?? []].pop() ?? Ms(e._zod.bag), e._zod.parse = (n, o) => {
    if (t.coerce)
      try {
        n.value = String(n.value);
      } catch {
      }
    return typeof n.value == "string" || n.issues.push({
      expected: "string",
      code: "invalid_type",
      input: n.value,
      inst: e
    }), n;
  };
}), B = /* @__PURE__ */ g("$ZodStringFormat", (e, t) => {
  or.init(e, t), zt.init(e, t);
}), vu = /* @__PURE__ */ g("$ZodGUID", (e, t) => {
  t.pattern ?? (t.pattern = js), B.init(e, t);
}), yu = /* @__PURE__ */ g("$ZodUUID", (e, t) => {
  if (t.version) {
    let o = {
      v1: 1,
      v2: 2,
      v3: 3,
      v4: 4,
      v5: 5,
      v6: 6,
      v7: 7,
      v8: 8
    }[t.version];
    if (o === void 0)
      throw new Error(`Invalid UUID version: "${t.version}"`);
    t.pattern ?? (t.pattern = kt(o));
  } else
    t.pattern ?? (t.pattern = kt());
  B.init(e, t);
}), $u = /* @__PURE__ */ g("$ZodEmail", (e, t) => {
  t.pattern ?? (t.pattern = Ps), B.init(e, t);
}), bu = 1, _u = 2;
function Ai(e, t) {
  if (!t.normalize && t.protocol?.source === Zs.source && !/^https?:\/\//i.test(e))
    return bu;
  try {
    return new URL(e);
  } catch {
    return _u;
  }
}
s(Ai, "parseURLObject");
var W$ = /[\t\n\r]/g;
function Ui(e) {
  return e.replace(W$, "");
}
s(Ui, "stripTabAndNewline");
function Ei(e, t) {
  return t.lastIndex = 0, t.test(e.hostname);
}
s(Ei, "urlHostnameOk");
function Ci(e, t) {
  return t.lastIndex = 0, t.test(e.protocol.endsWith(":") ? e.protocol.slice(0, -1) : e.protocol);
}
s(Ci, "urlProtocolOk");
var xu = /* @__PURE__ */ g("$ZodURL", (e, t) => {
  B.init(e, t), e._zod.check = (n) => {
    try {
      let o = n.value.trim(), r = Ai(o, t);
      if (r === bu) {
        n.issues.push({
          code: "invalid_format",
          format: "url",
          note: "Invalid URL format",
          input: n.value,
          inst: e,
          continue: !t.abort
        });
        return;
      }
      if (r === _u) {
        n.issues.push({
          code: "invalid_format",
          format: "url",
          input: n.value,
          inst: e,
          continue: !t.abort
        });
        return;
      }
      t.hostname && !Ei(r, t.hostname) && n.issues.push({
        code: "invalid_format",
        format: "url",
        note: "Invalid hostname",
        pattern: t.hostname.source,
        input: n.value,
        inst: e,
        continue: !t.abort
      }), t.protocol && !Ci(r, t.protocol) && n.issues.push({
        code: "invalid_format",
        format: "url",
        note: "Invalid protocol",
        pattern: t.protocol.source,
        input: n.value,
        inst: e,
        continue: !t.abort
      }), n.value = t.normalize ? r.href : Ui(o);
      return;
    } catch {
      n.issues.push({
        code: "invalid_format",
        format: "url",
        input: n.value,
        inst: e,
        continue: !t.abort
      });
    }
  };
}), wu = /* @__PURE__ */ g("$ZodEmoji", (e, t) => {
  t.pattern ?? (t.pattern = Ds()), B.init(e, t);
}), ku = /* @__PURE__ */ g("$ZodNanoID", (e, t) => {
  if (t.length !== void 0 && (!Number.isInteger(t.length) || t.length < 1))
    throw new Error(`Invalid nanoid length: ${t.length}`);
  t.pattern ?? (t.pattern = t.length === void 0 ? zs : Ss(t.length)), B.init(e, t);
}), Iu = /* @__PURE__ */ g("$ZodCUID", (e, t) => {
  t.pattern ?? (t.pattern = _s), B.init(e, t);
}), zu = /* @__PURE__ */ g("$ZodCUID2", (e, t) => {
  t.pattern ?? (t.pattern = xs), B.init(e, t);
}), Su = /* @__PURE__ */ g("$ZodULID", (e, t) => {
  t.pattern ?? (t.pattern = ws), B.init(e, t);
}), Ou = /* @__PURE__ */ g("$ZodXID", (e, t) => {
  t.pattern ?? (t.pattern = ks), B.init(e, t);
}), ju = /* @__PURE__ */ g("$ZodKSUID", (e, t) => {
  t.pattern ?? (t.pattern = Is), B.init(e, t);
}), Pu = /* @__PURE__ */ g("$ZodISODateTime", (e, t) => {
  t.pattern ?? (t.pattern = Vs(t)), B.init(e, t), (t.local || t.precision === -1) && (e._zod.bag.laxFormat = !0, e._zod.onattach.push((n) => {
    n._zod.bag.laxFormat = !0;
  }));
}), Du = /* @__PURE__ */ g("$ZodISODate", (e, t) => {
  t.pattern ?? (t.pattern = Fs), B.init(e, t);
}), Nu = /* @__PURE__ */ g("$ZodISOTime", (e, t) => {
  t.pattern ?? (t.pattern = Ls(t)), B.init(e, t);
}), Tu = /* @__PURE__ */ g("$ZodISODuration", (e, t) => {
  t.pattern ?? (t.pattern = Os), B.init(e, t);
}), Au = /* @__PURE__ */ g("$ZodIPv4", (e, t) => {
  t.pattern ?? (t.pattern = Ns), B.init(e, t), e._zod.bag.format = "ipv4";
}), K$ = /^[0-9a-fA-F:.]+$/;
function nn(e) {
  if (!K$.test(e))
    return !1;
  try {
    return new URL(`http://[${e}]`), !0;
  } catch {
    return !1;
  }
}
s(nn, "isValidIPv6");
var Uu = /* @__PURE__ */ g("$ZodIPv6", (e, t) => {
  t.pattern ?? (t.pattern = Ts), B.init(e, t), e._zod.bag.format = "ipv6", e._zod.check = (n) => {
    nn(n.value) || n.issues.push({
      code: "invalid_format",
      format: "ipv6",
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Eu = /* @__PURE__ */ g("$ZodMAC", (e, t) => {
  t.pattern ?? (t.pattern = As(t.delimiter)), B.init(e, t), e._zod.bag.format = "mac";
}), Cu = /* @__PURE__ */ g("$ZodCIDRv4", (e, t) => {
  t.pattern ?? (t.pattern = Us), B.init(e, t);
});
function Zi(e) {
  let t = e.split("/");
  if (t.length !== 2)
    return !1;
  let [n, o] = t;
  if (!o)
    return !1;
  let r = Number(o);
  return `${r}` !== o || r < 0 || r > 128 ? !1 : nn(n);
}
s(Zi, "isValidCIDRv6");
var Zu = /* @__PURE__ */ g("$ZodCIDRv6", (e, t) => {
  t.pattern ?? (t.pattern = Es), B.init(e, t), e._zod.check = (n) => {
    Zi(n.value) || n.issues.push({
      code: "invalid_format",
      format: "cidrv6",
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
});
function on(e) {
  if (e === "")
    return !0;
  if (/\s/.test(e) || e.length % 4 !== 0)
    return !1;
  try {
    return atob(e), !0;
  } catch {
    return !1;
  }
}
s(on, "isValidBase64");
var Ru = /* @__PURE__ */ g("$ZodBase64", (e, t) => {
  t.pattern ?? (t.pattern = Cs), B.init(e, t), e._zod.bag.contentEncoding = "base64", e._zod.check = (n) => {
    on(n.value) || n.issues.push({
      code: "invalid_format",
      format: "base64",
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
});
function Ri(e) {
  if (!wi.test(e))
    return !1;
  let t = e.replace(/[-_]/g, (o) => o === "-" ? "+" : "/"), n = t.padEnd(Math.ceil(t.length / 4) * 4, "=");
  return on(n);
}
s(Ri, "isValidBase64URL");
var Fu = /* @__PURE__ */ g("$ZodBase64URL", (e, t) => {
  t.pattern ?? (t.pattern = wi), B.init(e, t), e._zod.bag.contentEncoding = "base64url", e._zod.check = (n) => {
    Ri(n.value) || n.issues.push({
      code: "invalid_format",
      format: "base64url",
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Lu = /* @__PURE__ */ g("$ZodE164", (e, t) => {
  t.pattern ?? (t.pattern = Rs), B.init(e, t);
}), G$ = /[- ]/g;
function X$(e) {
  let t = e.length, n = 1, o = 0;
  for (; t; ) {
    let r = +e[--t];
    n ^= 1, o += n ? [0, 2, 4, 6, 8, 1, 3, 5, 7, 9][r] : r;
  }
  return o % 10 === 0;
}
s(X$, "isLuhnAlgo");
function Fi(e) {
  return ki.test(e) ? X$(e.replace(G$, "")) : !1;
}
s(Fi, "isValidCreditCard");
var Vu = /* @__PURE__ */ g("$ZodCreditCard", (e, t) => {
  t.pattern ?? (t.pattern = ki), B.init(e, t), e._zod.check = (n) => {
    Fi(n.value) || n.issues.push({
      code: "invalid_format",
      format: "credit_card",
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
});
function Li(e, t = null) {
  try {
    let n = e.split(".");
    if (n.length !== 3)
      return !1;
    let [o] = n;
    if (!o)
      return !1;
    let r = JSON.parse(atob(o));
    return !("typ" in r && r?.typ !== "JWT" || !r.alg || t && (!("alg" in r) || r.alg !== t));
  } catch {
    return !1;
  }
}
s(Li, "isValidJWT");
var Mu = /* @__PURE__ */ g("$ZodJWT", (e, t) => {
  B.init(e, t), e._zod.check = (n) => {
    Li(n.value, t.alg) || n.issues.push({
      code: "invalid_format",
      format: "jwt",
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Bu = /* @__PURE__ */ g("$ZodCustomStringFormat", (e, t) => {
  B.init(e, t), e._zod.check = (n) => {
    t.fn(n.value) || n.issues.push({
      code: "invalid_format",
      format: t.format,
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Vi = /* @__PURE__ */ g("$ZodNumber", (e, t) => {
  O.init(e, t), e._zod.pattern = e._zod.bag.pattern ?? Ye, e._zod.parse = (n, o) => {
    if (t.coerce)
      try {
        n.value = Number(n.value);
      } catch {
      }
    let r = n.value;
    if (typeof r == "number" && !Number.isNaN(r) && Number.isFinite(r))
      return n;
    let i = typeof r == "number" ? Number.isNaN(r) ? "NaN" : Number.isFinite(r) ? void 0 : String(r) : void 0;
    return n.issues.push({
      expected: "number",
      code: "invalid_type",
      input: r,
      inst: e,
      ...i ? { received: i } : {}
    }), n;
  };
}), Ju = /* @__PURE__ */ g("$ZodNumberFormat", (e, t) => {
  Ys.init(e, t), Vi.init(e, t);
}), an = /* @__PURE__ */ g("$ZodBoolean", (e, t) => {
  O.init(e, t), e._zod.pattern = Js, e._zod.parse = (n, o) => {
    if (t.coerce)
      try {
        n.value = !!n.value;
      } catch {
      }
    let r = n.value;
    return typeof r == "boolean" || n.issues.push({
      expected: "boolean",
      code: "invalid_type",
      input: r,
      inst: e
    }), n;
  };
}), Mi = /* @__PURE__ */ g("$ZodBigInt", (e, t) => {
  O.init(e, t), e._zod.pattern = Bs, e._zod.parse = (n, o) => {
    if (t.coerce)
      try {
        n.value = BigInt(n.value);
      } catch {
      }
    return typeof n.value == "bigint" || n.issues.push({
      expected: "bigint",
      code: "invalid_type",
      input: n.value,
      inst: e
    }), n;
  };
}), qu = /* @__PURE__ */ g("$ZodBigIntFormat", (e, t) => {
  eu.init(e, t), Mi.init(e, t);
}), Wu = /* @__PURE__ */ g("$ZodSymbol", (e, t) => {
  O.init(e, t), e._zod.parse = (n, o) => {
    let r = n.value;
    return typeof r == "symbol" || n.issues.push({
      expected: "symbol",
      code: "invalid_type",
      input: r,
      inst: e
    }), n;
  };
}), Ku = /* @__PURE__ */ g("$ZodUndefined", (e, t) => {
  O.init(e, t), e._zod.pattern = Ws, e._zod.values = /* @__PURE__ */ new Set([void 0]), e._zod.parse = (n, o) => {
    let r = n.value;
    return typeof r > "u" || n.issues.push({
      expected: "undefined",
      code: "invalid_type",
      input: r,
      inst: e
    }), n;
  };
}), Gu = /* @__PURE__ */ g("$ZodNull", (e, t) => {
  O.init(e, t), e._zod.pattern = qs, e._zod.values = /* @__PURE__ */ new Set([null]), e._zod.parse = (n, o) => {
    let r = n.value;
    return r === null || n.issues.push({
      expected: "null",
      code: "invalid_type",
      input: r,
      inst: e
    }), n;
  };
}), Xu = /* @__PURE__ */ g("$ZodAny", (e, t) => {
  O.init(e, t), e._zod.parse = (n) => n;
}), Hu = /* @__PURE__ */ g("$ZodUnknown", (e, t) => {
  O.init(e, t), e._zod.parse = (n) => n;
}), Qu = /* @__PURE__ */ g("$ZodNever", (e, t) => {
  O.init(e, t), e._zod.parse = (n, o) => (n.issues.push({
    expected: "never",
    code: "invalid_type",
    input: n.value,
    inst: e
  }), n);
}), Yu = /* @__PURE__ */ g("$ZodVoid", (e, t) => {
  O.init(e, t), e._zod.parse = (n, o) => {
    let r = n.value;
    return typeof r > "u" || n.issues.push({
      expected: "void",
      code: "invalid_type",
      input: r,
      inst: e
    }), n;
  };
}), sr = /* @__PURE__ */ g("$ZodDate", (e, t) => {
  O.init(e, t), e._zod.parse = (n, o) => {
    if (t.coerce)
      try {
        n.value = new Date(n.value);
      } catch {
      }
    let r = n.value, i = r instanceof Date;
    return i && !Number.isNaN(r.getTime()) || n.issues.push({
      expected: "date",
      code: "invalid_type",
      input: r,
      ...i ? { received: "Invalid Date" } : {},
      inst: e
    }), n;
  };
});
function vm(e, t, n) {
  e.issues.length && t.issues.push(...me(n, e.issues)), t.value[n] = e.value;
}
s(vm, "handleArrayResult");
var et = /* @__PURE__ */ g("$ZodArray", (e, t) => {
  O.init(e, t);
  let n = ae.memoizer;
  n?.attach(e), e._zod.parse = (o, r) => {
    let i = o.value;
    if (!Array.isArray(i))
      return o.issues.push({
        expected: "array",
        code: "invalid_type",
        input: i,
        inst: e
      }), o;
    o.value = n ? n.alloc(e, o, Array(i.length), r) : Array(i.length);
    let a = [];
    for (let u = 0; u < i.length; u++) {
      let c = i[u], l = t.element._zod.run({
        value: c,
        issues: []
      }, r);
      l instanceof Promise ? a.push(l.then((d) => vm(d, o, u))) : vm(l, o, u);
    }
    return a.length ? Promise.all(a).then(() => o) : o;
  };
});
function Ni(e, t, n, o, r, i) {
  let a = n in o, u = i === "optional";
  if (!(!a && u && r === "optional")) {
    if (e.issues.length) {
      if (r !== void 0 && u && !a)
        return;
      t.issues.push(...me(n, e.issues));
    }
    if (!a && r === void 0) {
      e.issues.length || t.issues.push({
        code: "invalid_type",
        expected: "nonoptional",
        input: void 0,
        path: [n]
      });
      return;
    }
    e.value === void 0 ? a && (t.value[n] = void 0) : t.value[n] = e.value;
  }
}
s(Ni, "handlePropertyResult");
var H$ = [];
function Nm(e) {
  let t = Object.keys(e.shape), n = Object.getOwnPropertySymbols(e.shape), o = n.length ? n : H$, r = o.length ? [...t, ...o] : t;
  for (let a of r)
    if (!e.shape?.[a]?._zod?.traits?.has("$ZodType"))
      throw new Error(`Invalid element at key "${String(a)}": expected a Zod schema`);
  let i = rs(e.shape);
  return {
    ...e,
    allKeys: r,
    symbolKeys: o,
    // string-only: handleCatchall matches it against `for...in`, which never yields a symbol
    keySet: new Set(t),
    numKeys: t.length,
    optionalKeys: new Set(i)
  };
}
s(Nm, "normalizeDef");
function Tm(e, t, n, o, r, i) {
  let a = [], u = r.keySet, c = r.catchall._zod, l = c.def.type, d = c.optin, f = c.optout;
  for (let p in t) {
    if (u.has(p))
      continue;
    if (p === "__proto__") {
      l === "never" && a.push(p);
      continue;
    }
    if (l === "never") {
      a.push(p);
      continue;
    }
    let m = c.run({ value: t[p], issues: [] }, o);
    m instanceof Promise ? e.push(m.then((v) => Ni(v, n, p, t, d, f))) : Ni(m, n, p, t, d, f);
  }
  return a.length && n.issues.push({
    code: "unrecognized_keys",
    keys: a,
    input: t,
    inst: i,
    // Describes the shape of the input, not the validity of the parsed value, so it never aborts. The parse still fails; the schema's own checks just get to run first, and an enclosing intersection can reconcile the key against a sibling operand.
    continue: !0
  }), e.length ? Promise.all(e).then(() => n) : n;
}
s(Tm, "handleCatchall");
var hu = /* @__PURE__ */ new WeakMap(), re = /* @__PURE__ */ g("$ZodObject", (e, t) => {
  if (O.init(e, t), !Object.getOwnPropertyDescriptor(t, "shape")?.get) {
    let c = t.shape;
    hu.set(t, c), Object.defineProperty(t, "shape", {
      get: /* @__PURE__ */ s(() => {
        let l = { ...c };
        return Object.defineProperty(t, "shape", {
          value: l
        }), hu.set(t, l), l;
      }, "get")
    });
  }
  let o = Yt(() => Nm(t));
  E(e, "propValues", (c) => {
    let l = c.def.shape, d = {};
    for (let f in l) {
      let p = l[f]._zod;
      if (p.values) {
        Object.prototype.hasOwnProperty.call(d, f) || Y(d, f, /* @__PURE__ */ new Set());
        for (let m of p.values)
          d[f].add(m);
        p.optin !== void 0 && d[f].add(void 0);
      }
    }
    return d;
  });
  let r = _t, i = t.catchall, a, u = ae.memoizer;
  u?.attach(e), e._zod.parse = (c, l) => {
    a ?? (a = o.value);
    let d = c.value;
    if (!r(d))
      return c.issues.push({
        expected: "object",
        code: "invalid_type",
        input: d,
        inst: e
      }), c;
    c.value = u ? u.alloc(e, c, {}, l) : {};
    let f = [], p = a.shape;
    for (let m of a.allKeys) {
      if (m === "__proto__")
        continue;
      let v = p[m], x = v._zod.optin, k = v._zod.optout, R = v._zod.run({ value: d[m], issues: [] }, l);
      R instanceof Promise ? f.push(R.then((j) => Ni(j, c, m, d, x, k))) : Ni(R, c, m, d, x, k);
    }
    return i ? Tm(f, d, c, l, o.value, e) : f.length ? Promise.all(f).then(() => c) : c;
  };
}), ec = /* @__PURE__ */ g("$ZodObjectJIT", (e, t) => {
  re.init(e, t);
  let n = e._zod.parse, o = Yt(() => Nm(t)), r = ae.memoizer, i = /* @__PURE__ */ s((m) => {
    let v = o.value, x = v.symbolKeys, k = new It(["payload", "ctx"], { shape: m, inst: e, memo: r, syms: x }), R = /* @__PURE__ */ s((V) => `shape[${V}]._zod.run({ value: input[${V}], issues: [] }, ctx)`, "parseStr"), j = /* @__PURE__ */ s((V, I) => `
          for (let i = 0; i < ${V}.issues.length; i++) {
            const iss = ${V}.issues[i];
            iss.path = iss.path ? [${I}, ...iss.path] : [${I}];
            payload.issues.push(iss);
          }`, "prefixStr");
    k.write("const input = payload.value;");
    let P = /* @__PURE__ */ Object.create(null), U = 0;
    for (let V of v.allKeys)
      P[V] = `key_${U++}`;
    k.write(r ? "const newResult = memo.alloc(inst, payload, {}, ctx);" : "const newResult = {};");
    for (let V of v.allKeys) {
      if (V === "__proto__")
        continue;
      let I = P[V], T = typeof V == "symbol" ? `syms[${x.indexOf(V)}]` : pe(V), W = `${T} in input`, Me = m[V], gt = Me?._zod?.optin, Zn = gt !== void 0, ba = Me?._zod?.optout === "optional";
      if (k.write(`const ${I} = ${R(T)};`), Zn && ba) {
        let Rn = gt === "optional" ? `${I}_present` : `${I}.value !== undefined || ${I}_present`;
        k.write(`
        const ${I}_present = ${W};
        if (!${I}.issues.length || ${I}_present) {
          if (${I}.issues.length) {${j(I, T)}
          }

          if (${Rn}) {
            newResult[${T}] = ${I}.value;
          }
        }

      `);
      } else Zn ? k.write(`
        if (${I}.issues.length) {${j(I, T)}
        }
        
        if (${I}.value === undefined) {
          if (${W}) {
            newResult[${T}] = undefined;
          }
        } else {
          newResult[${T}] = ${I}.value;
        }

      `) : k.write(`
        const ${I}_present = ${W};
        if (${I}.issues.length) {${j(I, T)}
        }
        if (!${I}_present && !${I}.issues.length) {
          payload.issues.push({
            code: "invalid_type",
            expected: "nonoptional",
            input: undefined,
            path: [${T}]
          });
        }

        if (${I}_present) {
          newResult[${T}] = ${I}.value;
        }

      `);
    }
    return k.write("payload.value = newResult;"), k.write("return payload;"), k.compile();
  }, "generateFastpass"), a, u = _t, c = !ae.jitless, d = c && es.value, f = t.catchall, p;
  e._zod.parse = (m, v) => {
    p ?? (p = o.value);
    let x = m.value;
    return u(x) ? c && d && v?.async === !1 && v.jitless !== !0 ? (a || (a = i(t.shape)), m = a(m, v), f ? Tm([], x, m, v, p, e) : m) : n(m, v) : (m.issues.push({
      expected: "object",
      code: "invalid_type",
      input: x,
      inst: e
    }), m);
  };
});
function ym(e, t, n, o) {
  for (let i of e)
    if (i.issues.length === 0)
      return t.value = i.value, t;
  let r = e.filter((i) => !Xe(i));
  return r.length === 1 ? (t.value = r[0].value, r[0]) : (t.issues.push({
    code: "invalid_union",
    input: t.value,
    inst: n,
    errors: e.map((i) => i.issues.map((a) => ge(a, o, te())))
  }), t);
}
s(ym, "handleUnionResults");
var le = /* @__PURE__ */ g("$ZodUnion", (e, t) => {
  O.init(e, t), E(e, "optin", (o) => o.def.options.some((r) => r._zod.optin === "defaulted") ? "defaulted" : o.def.options.some((r) => r._zod.optin !== void 0) ? "optional" : void 0), E(e, "optout", (o) => o.def.options.some((r) => r._zod.optout === "optional") ? "optional" : void 0), E(e, "values", (o) => {
    if (o.def.options.every((r) => r._zod.values))
      return new Set(o.def.options.flatMap((r) => Array.from(r._zod.values)));
  }), E(e, "pattern", (o) => {
    if (o.def.options.every((r) => r._zod.pattern)) {
      let r = o.def.options.map((i) => i._zod.pattern);
      return new RegExp(`^(${r.map((i) => qr(i.source)).join("|")})$`);
    }
  });
  let n = t.options.length === 1 ? t.options[0]._zod.run : null;
  e._zod.parse = (o, r) => {
    if (n)
      return n(o, r);
    let i = !1, a = [];
    for (let u of t.options) {
      let c = u._zod.run({
        value: o.value,
        issues: []
      }, r);
      if (c instanceof Promise)
        a.push(c), i = !0;
      else {
        if (c.issues.length === 0)
          return c;
        a.push(c);
      }
    }
    return i ? Promise.all(a).then((u) => ym(u, o, e, r)) : ym(a, o, e, r);
  };
});
function $m(e, t, n, o) {
  let r = [];
  for (let i = 0; i < e.length; i++)
    e[i].issues.length === 0 && r.push(i);
  return r.length === 1 ? (t.value = e[r[0]].value, t) : (r.length === 0 ? t.issues.push({
    code: "invalid_union",
    input: t.value,
    inst: n,
    errors: e.map((i) => i.issues.map((a) => ge(a, o, te())))
  }) : t.issues.push({
    code: "invalid_union",
    input: t.value,
    inst: n,
    errors: [],
    inclusive: !1,
    matches: r
  }), t);
}
s($m, "handleExclusiveUnionResults");
var tc = /* @__PURE__ */ g("$ZodXor", (e, t) => {
  le.init(e, t), t.inclusive = !1;
  let n = t.options.length === 1 ? t.options[0]._zod.run : null;
  e._zod.parse = (o, r) => {
    if (n)
      return n(o, r);
    let i = !1, a = [];
    for (let u of t.options) {
      let c = u._zod.run({
        value: o.value,
        issues: []
      }, r);
      c instanceof Promise ? (a.push(c), i = !0) : a.push(c);
    }
    return i ? Promise.all(a).then((u) => $m(u, o, e, r)) : $m(a, o, e, r);
  };
});
function rc(e, t) {
  let n = e._zod, o = n.bag.optionsMap;
  if (!o) {
    o = /* @__PURE__ */ new Map();
    let { options: r, discriminator: i } = n.def;
    for (let a of r)
      for (let u of a._zod.propValues?.[i] ?? [])
        o.has(u) || o.set(u, a);
    n.bag.optionsMap = o;
  }
  return o.get(t);
}
s(rc, "getDiscriminatedOption");
var tt = /* @__PURE__ */ g("$ZodDiscriminatedUnion", (e, t) => {
  t.inclusive = !1, le.init(e, t);
  let n = e._zod.parse;
  E(e, "propValues", (r) => {
    let i = {};
    for (let a of r.def.options) {
      let u = a._zod.propValues;
      if (!u || Object.keys(u).length === 0)
        throw new Error(`Invalid discriminated union option at index "${r.def.options.indexOf(a)}"`);
      for (let [c, l] of Object.entries(u)) {
        Object.prototype.hasOwnProperty.call(i, c) || Y(i, c, /* @__PURE__ */ new Set());
        for (let d of l)
          i[c].add(d);
      }
    }
    return i;
  }), t.options.forEach((r, i) => {
    let a = hu.get(r._zod.def);
    if (a && !Object.prototype.hasOwnProperty.call(a, t.discriminator))
      throw new Error(`Invalid discriminated union option at index "${i}"`);
  });
  let o = Yt(() => {
    let r = t.options, i = /* @__PURE__ */ new Map();
    for (let a of r) {
      let u = a._zod.propValues?.[t.discriminator];
      if (!u || u.size === 0)
        throw new Error(`Invalid discriminated union option at index "${t.options.indexOf(a)}"`);
      for (let c of u) {
        if (i.has(c))
          throw new Error(`Duplicate discriminator value "${String(c)}"`);
        i.set(c, a);
      }
    }
    return i;
  });
  e._zod.parse = (r, i) => {
    let a = r.value;
    if (!_t(a))
      return r.issues.push({
        code: "invalid_type",
        expected: "object",
        input: a,
        inst: e
      }), r;
    let u = o.value.get(a?.[t.discriminator]);
    return u ? u._zod.run(r, i) : t.unionFallback || i.direction === "backward" ? n(r, i) : (r.issues.push({
      code: "invalid_union",
      errors: [],
      note: "No matching discriminator",
      discriminator: t.discriminator,
      options: Array.from(o.value.keys()),
      input: a,
      path: [t.discriminator],
      inst: e
    }), r);
  };
}), nc = /* @__PURE__ */ g("$ZodIntersection", (e, t) => {
  O.init(e, t), e._zod.parse = (n, o) => {
    let r = n.value, i = t.left._zod.run({ value: r, issues: [] }, o), a = t.right._zod.run({ value: r, issues: [] }, o);
    return i instanceof Promise || a instanceof Promise ? Promise.all([i, a]).then(([c, l]) => bm(n, c, l)) : bm(n, i, a);
  };
});
function ar(e, t) {
  if (e === t)
    return { valid: !0, data: e };
  if (e instanceof Date && t instanceof Date && +e == +t)
    return { valid: !0, data: e };
  if (Se(e) && Se(t)) {
    let n = Object.keys(t), o = Object.keys(e).filter((i) => n.indexOf(i) !== -1), r = { ...e, ...t };
    Object.prototype.hasOwnProperty.call(r, "__proto__") && delete r.__proto__;
    for (let i of o) {
      if (i === "__proto__")
        continue;
      let a = ar(e[i], t[i]);
      if (!a.valid)
        return {
          valid: !1,
          mergeErrorPath: [i, ...a.mergeErrorPath]
        };
      r[i] = a.data;
    }
    return { valid: !0, data: r };
  }
  if (Array.isArray(e) && Array.isArray(t)) {
    if (e.length !== t.length)
      return { valid: !1, mergeErrorPath: [] };
    let n = [];
    for (let o = 0; o < e.length; o++) {
      let r = e[o], i = t[o], a = ar(r, i);
      if (!a.valid)
        return {
          valid: !1,
          mergeErrorPath: [o, ...a.mergeErrorPath]
        };
      n.push(a.data);
    }
    return { valid: !0, data: n };
  }
  return { valid: !1, mergeErrorPath: [] };
}
s(ar, "mergeValues");
function bm(e, t, n) {
  let o = /* @__PURE__ */ new Map(), r, i = /* @__PURE__ */ new Map(), a = /* @__PURE__ */ s((l, d) => {
    let f;
    if (l.code === "unrecognized_keys" && !l.path?.length)
      r ?? (r = l), f = l.keys;
    else if (l.code === "invalid_key" && l.origin === "record" && l.path?.length === 1) {
      let p = String(l.path[0]);
      i.has(p) || i.set(p, l), f = [p];
    } else
      return !1;
    for (let p of f)
      o.has(p) || o.set(p, {}), o.get(p)[d] = !0;
    return !0;
  }, "collect");
  for (let l of t.issues)
    a(l, "l") || e.issues.push(l);
  for (let l of n.issues)
    a(l, "r") || e.issues.push(l);
  let u = [...o].filter(([, l]) => l.l && l.r).map(([l]) => l);
  if (u.length) {
    let l = r ? u.filter((d) => r.keys.includes(d)) : [];
    l.length && e.issues.push({ ...r, keys: l });
    for (let d of u)
      !l.includes(d) && i.has(d) && e.issues.push(i.get(d));
  }
  let c = ar(t.value, n.value);
  if (!c.valid) {
    if (Xe(e))
      return e;
    throw new Error(`Unmergable intersection. Error path: ${JSON.stringify(c.mergeErrorPath)}`);
  }
  return e.value = c.data, e;
}
s(bm, "handleIntersectionResults");
var rt = /* @__PURE__ */ g("$ZodTuple", (e, t) => {
  O.init(e, t);
  let n = t.items, o = ae.memoizer;
  o?.attach(e), e._zod.parse = (r, i) => {
    let a = r.value;
    if (!Array.isArray(a))
      return r.issues.push({
        input: a,
        inst: e,
        expected: "tuple",
        code: "invalid_type"
      }), r;
    r.value = o ? o.alloc(e, r, [], i) : [];
    let u = [], c = _m(n, "optin"), l = _m(n, "optout");
    if (!t.rest) {
      if (a.length < c)
        return r.issues.push({
          code: "too_small",
          minimum: c,
          inclusive: !0,
          input: a,
          inst: e,
          origin: "array"
        }), r;
      a.length > n.length && r.issues.push({
        code: "too_big",
        maximum: n.length,
        inclusive: !0,
        input: a,
        inst: e,
        origin: "array"
      });
    }
    let d = new Array(n.length);
    for (let f = 0; f < n.length; f++) {
      let p = n[f]._zod.run({ value: a[f], issues: [] }, i);
      p instanceof Promise ? u.push(p.then((m) => {
        d[f] = m;
      })) : d[f] = p;
    }
    if (t.rest) {
      let f = n.length - 1, p = a.slice(n.length);
      for (let m of p) {
        f++;
        let v = t.rest._zod.run({ value: m, issues: [] }, i);
        v instanceof Promise ? u.push(v.then((x) => xm(x, r, f))) : xm(v, r, f);
      }
    }
    return u.length ? Promise.all(u).then(() => wm(d, r, n, a, l)) : wm(d, r, n, a, l);
  };
});
function _m(e, t) {
  for (let n = e.length - 1; n >= 0; n--)
    if (!(t === "optin" ? e[n]._zod.optin !== void 0 : e[n]._zod.optout === "optional"))
      return n + 1;
  return 0;
}
s(_m, "getTupleOptStart");
function xm(e, t, n) {
  e.issues.length && t.issues.push(...me(n, e.issues)), t.value[n] = e.value;
}
s(xm, "handleTupleResult");
function wm(e, t, n, o, r) {
  for (let i = 0; i < n.length; i++) {
    let a = e[i], u = i < o.length;
    if (!u && i >= r && n[i]._zod.optin === "optional") {
      t.value.length = i;
      break;
    }
    if (a.issues.length) {
      if (!u && i >= r) {
        t.value.length = i;
        break;
      }
      t.issues.push(...me(i, a.issues));
    }
    t.value[i] = a.value;
  }
  for (let i = t.value.length - 1; i >= o.length && (n[i]._zod.optout === "optional" && t.value[i] === void 0); i--)
    t.value.length = i;
  return t;
}
s(wm, "handleTupleResults");
var St = /* @__PURE__ */ g("$ZodRecord", (e, t) => {
  O.init(e, t);
  let n = ae.memoizer;
  n?.attach(e), e._zod.parse = (o, r) => {
    let i = o.value;
    if (!Se(i))
      return o.issues.push({
        expected: "record",
        code: "invalid_type",
        input: i,
        inst: e
      }), o;
    let a = [], u = t.keyType._zod.values;
    if (u && !t.partial) {
      o.value = n ? n.alloc(e, o, {}, r) : {};
      let c = /* @__PURE__ */ new Set();
      for (let d of u)
        if (typeof d == "string" || typeof d == "number" || typeof d == "symbol") {
          if (c.add(typeof d == "number" ? d.toString() : d), d === "__proto__")
            continue;
          let f = t.keyType._zod.run({ value: d, issues: [] }, r);
          if (f instanceof Promise)
            throw new Error("Async schemas not supported in object keys currently");
          if (f.issues.length) {
            o.issues.push({
              code: "invalid_key",
              origin: "record",
              issues: f.issues.map((v) => ge(v, r, te())),
              input: d,
              path: [d],
              inst: e
            });
            continue;
          }
          let p = f.value;
          if (p === "__proto__")
            continue;
          let m = t.valueType._zod.run({ value: i[d], issues: [] }, r);
          m instanceof Promise ? a.push(m.then((v) => {
            v.issues.length && o.issues.push(...me(d, v.issues)), o.value[p] = v.value;
          })) : (m.issues.length && o.issues.push(...me(d, m.issues)), o.value[p] = m.value);
        }
      let l;
      for (let d in i)
        if (!c.has(d))
          if (t.mode === "loose") {
            if (d === "__proto__")
              continue;
            o.value[d] = i[d];
          } else
            l = l ?? [], l.push(d);
      l && l.length > 0 && o.issues.push({
        code: "unrecognized_keys",
        input: i,
        inst: e,
        keys: l,
        continue: !0
      });
    } else {
      o.value = n ? n.alloc(e, o, {}, r) : {};
      let c;
      for (let l of Reflect.ownKeys(i)) {
        if (l === "__proto__" || !Object.prototype.propertyIsEnumerable.call(i, l))
          continue;
        let d = t.keyType._zod.run({ value: l, issues: [] }, r);
        if (d instanceof Promise)
          throw new Error("Async schemas not supported in object keys currently");
        if (typeof l == "string" && Ye.test(l) && d.issues.length) {
          let v = t.keyType._zod.run({ value: Number(l), issues: [] }, r);
          if (v instanceof Promise)
            throw new Error("Async schemas not supported in object keys currently");
          v.issues.length === 0 && (d = v);
        }
        if (d.issues.length) {
          t.mode === "loose" ? o.value[l] = i[l] : u ? (c = c ?? [], c.push(l)) : o.issues.push({
            code: "invalid_key",
            origin: "record",
            issues: d.issues.map((v) => ge(v, r, te())),
            input: l,
            path: [l],
            inst: e
          });
          continue;
        }
        let p = d.value;
        if (p === "__proto__")
          continue;
        let m = t.valueType._zod.run({ value: i[l], issues: [] }, r);
        m instanceof Promise ? a.push(m.then((v) => {
          v.issues.length && o.issues.push(...me(l, v.issues)), o.value[p] = v.value;
        })) : (m.issues.length && o.issues.push(...me(l, m.issues)), o.value[p] = m.value);
      }
      c && c.length > 0 && o.issues.push({
        code: "unrecognized_keys",
        input: i,
        inst: e,
        keys: c,
        continue: !0
      });
    }
    return a.length ? Promise.all(a).then(() => o) : o;
  };
}), ic = /* @__PURE__ */ g("$ZodMap", (e, t) => {
  O.init(e, t);
  let n = ae.memoizer;
  n?.attach(e), e._zod.parse = (o, r) => {
    let i = o.value;
    if (!(i instanceof Map))
      return o.issues.push({
        expected: "map",
        code: "invalid_type",
        input: i,
        inst: e
      }), o;
    let a = [];
    o.value = n ? n.alloc(e, o, /* @__PURE__ */ new Map(), r) : /* @__PURE__ */ new Map();
    for (let [u, c] of i) {
      let l = t.keyType._zod.run({ value: u, issues: [] }, r), d = t.valueType._zod.run({ value: c, issues: [] }, r);
      l instanceof Promise || d instanceof Promise ? a.push(Promise.all([l, d]).then(([f, p]) => {
        km(f, p, o, u, i, e, r);
      })) : km(l, d, o, u, i, e, r);
    }
    return a.length ? Promise.all(a).then(() => o) : o;
  };
});
function km(e, t, n, o, r, i, a) {
  e.issues.length && (Gr.has(typeof o) ? n.issues.push(...me(o, e.issues)) : n.issues.push({
    code: "invalid_key",
    origin: "map",
    input: r,
    inst: i,
    issues: e.issues.map((u) => ge(u, a, te()))
  })), t.issues.length && (Gr.has(typeof o) ? n.issues.push(...me(o, t.issues)) : n.issues.push({
    origin: "map",
    code: "invalid_element",
    input: r,
    inst: i,
    key: o,
    issues: t.issues.map((u) => ge(u, a, te()))
  })), n.value.set(e.value, t.value);
}
s(km, "handleMapResult");
var oc = /* @__PURE__ */ g("$ZodSet", (e, t) => {
  O.init(e, t);
  let n = ae.memoizer;
  n?.attach(e), e._zod.parse = (o, r) => {
    let i = o.value;
    if (!(i instanceof Set))
      return o.issues.push({
        input: i,
        inst: e,
        expected: "set",
        code: "invalid_type"
      }), o;
    let a = [];
    o.value = n ? n.alloc(e, o, /* @__PURE__ */ new Set(), r) : /* @__PURE__ */ new Set();
    for (let u of i) {
      let c = t.valueType._zod.run({ value: u, issues: [] }, r);
      c instanceof Promise ? a.push(c.then((l) => Im(l, o))) : Im(c, o);
    }
    return a.length ? Promise.all(a).then(() => o) : o;
  };
});
function Im(e, t) {
  e.issues.length && t.issues.push(...e.issues), t.value.add(e.value);
}
s(Im, "handleSetResult");
var ur = /* @__PURE__ */ g("$ZodEnum", (e, t) => {
  O.init(e, t);
  let n = Jr(t.entries), o = new Set(n);
  e._zod.values = o;
  let r = n.filter((i) => Gr.has(typeof i));
  e._zod.pattern = new RegExp(r.length ? `^(${r.map((i) => Oe(i.toString())).join("|")})$` : "^[^\\s\\S]$"), e._zod.parse = (i, a) => {
    let u = i.value;
    return o.has(u) || i.issues.push({
      code: "invalid_value",
      values: n,
      input: u,
      inst: e
    }), i;
  };
}), cr = /* @__PURE__ */ g("$ZodLiteral", (e, t) => {
  O.init(e, t);
  let n = new Set(t.values);
  e._zod.values = n, e._zod.pattern = new RegExp(t.values.length ? `^(${t.values.map((o) => typeof o == "string" ? Oe(o) : o ? Oe(o.toString()) : String(o)).join("|")})$` : "^[^\\s\\S]$"), e._zod.parse = (o, r) => {
    let i = o.value;
    return n.has(i) || o.issues.push({
      code: "invalid_value",
      values: t.values,
      input: i,
      inst: e
    }), o;
  };
}), ac = /* @__PURE__ */ g("$ZodFile", (e, t) => {
  O.init(e, t), e._zod.parse = (n, o) => {
    let r = n.value;
    return r instanceof File || n.issues.push({
      expected: "file",
      code: "invalid_type",
      input: r,
      inst: e
    }), n;
  };
}), sc = /* @__PURE__ */ g("$ZodTransform", (e, t) => {
  O.init(e, t), e._zod.optin = "optional", ae.memoizer?.guard(e), e._zod.parse = (n, o) => {
    if (o.direction === "backward")
      throw new He(e.constructor.name);
    let r = t.transform(n.value, n);
    if (o.async)
      return (r instanceof Promise ? r : Promise.resolve(r)).then((a) => (n.value = a, n));
    if (r instanceof Promise)
      throw new he();
    return n.value = r, n;
  };
});
function zm(e, t) {
  return e.value = t.issues.length ? void 0 : t.value, e;
}
s(zm, "handleOptionalResult");
var ee = /* @__PURE__ */ g("$ZodOptional", (e, t) => {
  O.init(e, t), E(e, "optin", (n) => n.def.innerType._zod.optin === "defaulted" ? "defaulted" : "optional"), e._zod.optout = "optional", E(e, "values", (n) => {
    let o = n.def.innerType._zod.values;
    return o ? /* @__PURE__ */ new Set([...o, void 0]) : void 0;
  }), E(e, "pattern", (n) => {
    let o = n.def.innerType._zod.pattern;
    return o ? new RegExp(`^(${qr(o.source)})?$`) : void 0;
  }), e._zod.parse = (n, o) => {
    if (n.value === void 0) {
      if (t.innerType._zod.optin !== "defaulted")
        return n;
      let r = t.innerType._zod.run({ value: n.value, issues: [] }, o);
      return r instanceof Promise ? r.then((i) => zm(n, i)) : zm(n, r);
    }
    return t.innerType._zod.run(n, o);
  };
}), uc = /* @__PURE__ */ g("$ZodExactOptional", (e, t) => {
  ee.init(e, t), E(e, "values", (n) => n.def.innerType._zod.values), E(e, "pattern", (n) => n.def.innerType._zod.pattern), e._zod.parse = (n, o) => t.innerType._zod.run(n, o);
}), Te = /* @__PURE__ */ g("$ZodNullable", (e, t) => {
  O.init(e, t), E(e, "optin", (n) => n.def.innerType._zod.optin), E(e, "optout", (n) => n.def.innerType._zod.optout), E(e, "pattern", (n) => {
    let o = n.def.innerType._zod.pattern;
    return o ? new RegExp(`^(${qr(o.source)}|null)$`) : void 0;
  }), E(e, "values", (n) => n.def.innerType._zod.values ? /* @__PURE__ */ new Set([...n.def.innerType._zod.values, null]) : void 0), e._zod.parse = (n, o) => n.value === null ? n : t.innerType._zod.run(n, o);
}), _e = /* @__PURE__ */ g("$ZodDefault", (e, t) => {
  O.init(e, t), e._zod.optin = "defaulted", E(e, "values", (n) => n.def.innerType._zod.values), e._zod.parse = (n, o) => {
    if (o.direction === "backward")
      return t.innerType._zod.run(n, o);
    if (n.value === void 0)
      return n.value = t.defaultValue, n;
    let r = t.innerType._zod.run(n, o);
    return r instanceof Promise ? r.then((i) => Sm(i, t)) : Sm(r, t);
  };
});
function Sm(e, t) {
  return e.value === void 0 && (e.value = t.defaultValue), e;
}
s(Sm, "handleDefaultResult");
var cc = /* @__PURE__ */ g("$ZodPrefault", (e, t) => {
  O.init(e, t), e._zod.optin = "defaulted", E(e, "values", (n) => n.def.innerType._zod.values), e._zod.parse = (n, o) => (o.direction === "backward" || n.value === void 0 && (n.value = t.defaultValue), t.innerType._zod.run(n, o));
}), lc = /* @__PURE__ */ g("$ZodNonOptional", (e, t) => {
  O.init(e, t), E(e, "values", (n) => {
    let o = n.def.innerType._zod.values;
    return o ? new Set([...o].filter((r) => r !== void 0)) : void 0;
  }), e._zod.parse = (n, o) => {
    let r = t.innerType._zod.run(n, o);
    return r instanceof Promise ? r.then((i) => Om(i, e)) : Om(r, e);
  };
});
function Om(e, t) {
  return !e.issues.length && e.value === void 0 && e.issues.push({
    code: "invalid_type",
    expected: "nonoptional",
    input: e.value,
    inst: t
  }), e;
}
s(Om, "handleNonOptionalResult");
var dc = /* @__PURE__ */ g("$ZodSuccess", (e, t) => {
  O.init(e, t), e._zod.parse = (n, o) => {
    if (o.direction === "backward")
      throw new He("ZodSuccess");
    let r = t.innerType._zod.run(n, o);
    return r instanceof Promise ? r.then((i) => (n.value = i.issues.length === 0, n)) : (n.value = r.issues.length === 0, n);
  };
});
function jm(e, t, n, o) {
  return t.issues.length ? (e.value = n.catchValue({
    ...t,
    value: e.value,
    error: {
      issues: t.issues.map((r) => ge(r, o, te()))
    },
    input: e.value
  }), e) : (e.value = t.value, t.memo && (e.memo = !0), e);
}
s(jm, "handleCatchResult");
var fc = /* @__PURE__ */ g("$ZodCatch", (e, t) => {
  O.init(e, t), E(e, "optin", (n) => n.def.innerType._zod.optin === "defaulted" ? "defaulted" : "optional"), E(e, "optout", (n) => n.def.innerType._zod.optout), E(e, "values", (n) => n.def.innerType._zod.values), e._zod.parse = (n, o) => {
    if (o.direction === "backward")
      return t.innerType._zod.run(n, o);
    let r = t.innerType._zod.run({ value: n.value, issues: [] }, o);
    return r instanceof Promise ? r.then((i) => jm(n, i, t, o)) : jm(n, r, t, o);
  };
}), pc = /* @__PURE__ */ g("$ZodNaN", (e, t) => {
  O.init(e, t), e._zod.parse = (n, o) => ((typeof n.value != "number" || !Number.isNaN(n.value)) && n.issues.push({
    input: n.value,
    inst: e,
    expected: "nan",
    code: "invalid_type"
  }), n);
}), Bi = /* @__PURE__ */ g("$ZodPipe", (e, t) => {
  O.init(e, t), E(e, "values", (n) => n.def.in._zod.values), E(e, "optin", (n) => n.def.in._zod.optin), E(e, "optout", (n) => n.def.out._zod.optout), E(e, "propValues", (n) => n.def.in._zod.propValues), e._zod.parse = (n, o) => {
    if (o.direction === "backward") {
      let i = t.out._zod.run(n, o);
      return i instanceof Promise ? i.then((a) => ji(a, t.in, o)) : ji(i, t.in, o);
    }
    let r = t.in._zod.run(n, o);
    return r instanceof Promise ? r.then((i) => ji(i, t.out, o)) : ji(r, t.out, o);
  };
});
function ji(e, t, n) {
  return e.issues.some((o) => o.code !== "unrecognized_keys") ? (e.aborted = !0, e) : t._zod.run({ value: e.value, issues: e.issues }, n);
}
s(ji, "handlePipeResult");
var Ae = /* @__PURE__ */ g("$ZodCodec", (e, t) => {
  O.init(e, t), E(e, "values", (n) => n.def.in._zod.values), E(e, "optin", (n) => n.def.in._zod.optin), E(e, "optout", (n) => n.def.out._zod.optout), E(e, "propValues", (n) => n.def.in._zod.propValues), e._zod.parse = (n, o) => {
    if ((o.direction || "forward") === "forward") {
      let i = t.in._zod.run(n, o);
      return i instanceof Promise ? i.then((a) => Pi(a, t, o)) : Pi(i, t, o);
    } else {
      let i = t.out._zod.run(n, o);
      return i instanceof Promise ? i.then((a) => Pi(a, t, o)) : Pi(i, t, o);
    }
  };
});
function Pi(e, t, n) {
  if (e.issues.length)
    return e.aborted = !0, e;
  if ((n.direction || "forward") === "forward") {
    let r = t.transform(e.value, e);
    return r instanceof Promise ? r.then((i) => Di(e, i, t.out, n)) : Di(e, r, t.out, n);
  } else {
    let r = t.reverseTransform(e.value, e);
    return r instanceof Promise ? r.then((i) => Di(e, i, t.in, n)) : Di(e, r, t.in, n);
  }
}
s(Pi, "handleCodecAResult");
function Di(e, t, n, o) {
  return e.issues.length ? (e.aborted = !0, e) : n._zod.run({ value: t, issues: e.issues }, o);
}
s(Di, "handleCodecTxResult");
var mc = /* @__PURE__ */ g("$ZodPreprocess", (e, t) => {
  Bi.init(e, t);
}), gc = /* @__PURE__ */ g("$ZodReadonly", (e, t) => {
  O.init(e, t), E(e, "propValues", (n) => n.def.innerType._zod.propValues), E(e, "values", (n) => n.def.innerType._zod.values), E(e, "optin", (n) => n.def.innerType?._zod?.optin), E(e, "optout", (n) => n.def.innerType?._zod?.optout), e._zod.parse = (n, o) => {
    if (o.direction === "backward")
      return t.innerType._zod.run(n, o);
    let r = t.innerType._zod.run(n, o);
    return r instanceof Promise ? r.then(Pm) : Pm(r);
  };
});
function Pm(e) {
  return e.memo || (e.value = Object.freeze(e.value)), e;
}
s(Pm, "handleReadonlyResult");
var hc = /* @__PURE__ */ g("$ZodTemplateLiteral", (e, t) => {
  O.init(e, t);
  let n = [];
  for (let o of t.parts)
    if (typeof o == "object" && o !== null) {
      if (!o._zod.pattern)
        throw new Error(`Invalid template literal part, no pattern found: ${[...o._zod.traits].shift()}`);
      let r = o._zod.pattern instanceof RegExp ? o._zod.pattern.source : o._zod.pattern;
      if (!r)
        throw new Error(`Invalid template literal part: ${o._zod.traits}`);
      let i = r.startsWith("^") ? 1 : 0, a = r.endsWith("$") ? r.length - 1 : r.length;
      n.push(r.slice(i, a));
    } else if (o === null || ts.has(typeof o))
      n.push(Oe(`${o}`));
    else
      throw new Error(`Invalid template literal part: ${o}`);
  e._zod.pattern = new RegExp(`^${n.join("")}$`), e._zod.parse = (o, r) => typeof o.value != "string" ? (o.issues.push({
    input: o.value,
    inst: e,
    expected: "string",
    code: "invalid_type"
  }), o) : (e._zod.pattern.lastIndex = 0, e._zod.pattern.test(o.value) || o.issues.push({
    input: o.value,
    inst: e,
    code: "invalid_format",
    format: t.format ?? "template_literal",
    pattern: e._zod.pattern.source
  }), o);
}), vc = /* @__PURE__ */ g("$ZodFunction", (e, t) => (O.init(e, t), Object.defineProperty(e, "_def", { value: t }), e._zod.def = t, e.implement = (n) => {
  if (typeof n != "function")
    throw new Error("implement() must be called with a function");
  return Object.defineProperty(function(...o) {
    let r = e._def.input ? Qe(e._def.input, o) : o, i = Reflect.apply(n, this, r);
    return e._def.output ? Qe(e._def.output, i) : i;
  }, "_zod", { value: e._zod, enumerable: !1 });
}, e.implementAsync = (n) => {
  if (typeof n != "function")
    throw new Error("implementAsync() must be called with a function");
  return Object.defineProperty(async function(...o) {
    let r = e._def.input ? await mi(e._def.input, o) : o, i = await Reflect.apply(n, this, r);
    return e._def.output ? await mi(e._def.output, i) : i;
  }, "_zod", { value: e._zod, enumerable: !1 });
}, e._zod.parse = (n, o) => typeof n.value != "function" ? (n.issues.push({
  code: "invalid_type",
  expected: "function",
  input: n.value,
  inst: e
}), n) : (e._def.output && e._def.output._zod.def.type === "promise" ? n.value = e.implementAsync(n.value) : n.value = e.implement(n.value), n), e.input = (...n) => {
  let o = e.constructor;
  return Array.isArray(n[0]) ? new o({
    type: "function",
    input: new rt({
      type: "tuple",
      items: n[0],
      rest: n[1]
    }),
    output: e._def.output
  }) : new o({
    type: "function",
    input: n[0],
    output: e._def.output
  });
}, e.output = (n) => {
  let o = e.constructor;
  return new o({
    type: "function",
    input: e._def.input,
    output: n
  });
}, e)), yc = /* @__PURE__ */ g("$ZodPromise", (e, t) => {
  O.init(e, t), e._zod.parse = (n, o) => Promise.resolve(n.value).then((r) => t.innerType._zod.run({ value: r, issues: [] }, o));
}), nt = /* @__PURE__ */ g("$ZodLazy", (e, t) => {
  O.init(e, t), Qa(e._zod, "innerType", () => {
    let n = t;
    return n._cachedInner || (n._cachedInner = t.getter()), n._cachedInner;
  }), E(e, "pattern", (n) => n.innerType?._zod?.pattern), E(e, "propValues", (n) => n.innerType?._zod?.propValues), E(e, "optin", (n) => n.innerType?._zod?.optin ?? void 0), E(e, "optout", (n) => n.innerType?._zod?.optout ?? void 0), e._zod.parse = (n, o) => e._zod.innerType._zod.run(n, o);
}), sn = /* @__PURE__ */ g("$ZodCustom", (e, t) => {
  K.init(e, t), O.init(e, t), e._zod.parse = (n, o) => n, e._zod.check = (n) => {
    let o = n.value, r = t.fn(o);
    if (r instanceof Promise)
      return r.then((i) => Dm(i, n, o, e));
    Dm(r, n, o, e);
  };
});
function Dm(e, t, n, o) {
  if (!e) {
    let r = {
      code: "custom",
      input: n,
      inst: o,
      // incorporates params.error into issue reporting
      path: [...o._zod.def.path ?? []],
      // incorporates params.error into issue reporting
      continue: !o._zod.def.abort
      // params: inst._zod.def.params,
    };
    o._zod.def.params && (r.params = o._zod.def.params), t.issues.push(er(r));
  }
}
s(Dm, "handleRefineResult");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/memoizer.js
var Wi = class extends Error {
  static {
    s(this, "$ZodCyclicError");
  }
  constructor() {
    super("Cannot parse a reference cycle that closes through a transform"), this.name = "ZodCyclicError";
  }
}, bc = "~memo", Um = [];
function $c(e) {
  return e.map((t) => t.path ? { ...t, path: t.path.slice() } : { ...t });
}
s($c, "cloneIssues");
var Em = /* @__PURE__ */ new WeakMap();
function _c(e, t) {
  let n = Em.get(e);
  if (n !== void 0)
    return n;
  if (t.has(e))
    return !0;
  t.add(e);
  let o = !1, r = /* @__PURE__ */ s((u) => {
    !o && u?._zod && _c(u, t) && (o = !0);
  }, "check"), i = e._zod.def, a = i.type;
  switch (a) {
    case "object": {
      for (let u of Reflect.ownKeys(i.shape))
        r(i.shape[u]);
      r(i.catchall);
      break;
    }
    case "array":
      r(i.element);
      break;
    case "tuple":
      for (let u of i.items)
        r(u);
      r(i.rest);
      break;
    case "record":
    case "map":
      r(i.keyType), r(i.valueType);
      break;
    case "set":
      r(i.valueType);
      break;
    case "union":
      for (let u of i.options)
        r(u);
      break;
    case "intersection":
      r(i.left), r(i.right);
      break;
    case "optional":
    case "nullable":
    case "default":
    case "prefault":
    case "catch":
    case "readonly":
    case "nonoptional":
    case "promise":
    case "success":
      r(i.innerType);
      break;
    case "pipe":
      r(i.in), r(i.out);
      break;
    case "function":
      r(i.input), r(i.output);
      break;
    // reading `_zod.innerType` resolves the getter once and caches it
    case "lazy":
      r(e._zod.innerType);
      break;
    // a leaf by choice: `parts` are regex fragments, not data positions
    case "template_literal":
    // leaves
    case "string":
    case "number":
    case "int":
    case "boolean":
    case "bigint":
    case "symbol":
    case "undefined":
    case "null":
    case "void":
    case "never":
    case "any":
    case "unknown":
    case "date":
    case "nan":
    case "enum":
    case "literal":
    case "file":
    case "transform":
    case "custom":
      break;
    default:
      for (let u in i) {
        let c = Object.getOwnPropertyDescriptor(i, u);
        if (!c || c.get)
          continue;
        let l = c.value;
        if (!(!l || typeof l != "object")) {
          if (l._zod)
            r(l);
          else if (Array.isArray(l))
            for (let d of l)
              r(d);
        }
      }
  }
  return t.delete(e), Em.set(e, o), o;
}
s(_c, "isRecursive");
function xc(e) {
  return _c(e, /* @__PURE__ */ new Set());
}
s(xc, "isRecursiveSchema");
function Q$(e, t) {
  let n = e.buckets.get(t);
  return n || (n = /* @__PURE__ */ new Map(), e.buckets.set(t, n)), n;
}
s(Q$, "bucketFor");
var Ji, qi = [], Y$ = {
  alloc(e, t, n) {
    let o = Ji;
    if (!o)
      return n;
    Ji = void 0;
    let r = { value: n, issues: null };
    return o.set(t.value, r), qi.push(r), n;
  },
  guard(e) {
    var t;
    (t = e._zod).deferred ?? (t.deferred = []), e._zod.deferred.push(() => {
      let n = e._zod.parse, o = /* @__PURE__ */ s((r, i) => {
        if (i.direction !== "backward" && Ki(i, r.value))
          throw new Wi();
        return n(r, i);
      }, "wrapped");
      e._zod.parse = o, e._zod.run === n && (e._zod.run = o);
    });
  },
  attach(e) {
    var t;
    let n, o, r;
    (t = e._zod).deferred ?? (t.deferred = []), e._zod.deferred.push(() => {
      let i = e._zod.parse, a = /* @__PURE__ */ s((u, c) => {
        if (n === void 0 && (n = _c(e, /* @__PURE__ */ new Set()), !n))
          return e._zod.parse = i, e._zod.run === a && (e._zod.run = i), i(u, c);
        let l = u.value;
        if (l === null || typeof l != "object")
          return i(u, c);
        let d = c[bc];
        d || (d = { buckets: /* @__PURE__ */ new Map(), backEdges: void 0 }, c[bc] = d);
        let f;
        o === c ? f = r : (f = Q$(d, e), o = c, r = f);
        let p = f.get(l);
        if (p)
          return u.value = p.value, p.issues ? p.issues.length && u.issues.push(...$c(p.issues)) : (u.memo = !0, d.backEdges ?? (d.backEdges = /* @__PURE__ */ new Set()), d.backEdges.add(p.value)), u;
        Ji = f;
        let m = qi.length, v = i(u, c);
        Ji = void 0;
        let x = qi.length > m ? qi.pop() : void 0;
        return v instanceof Promise ? v.then((k) => (x && (x.issues = k.issues.length ? $c(k.issues) : Um), k)) : (x && (x.issues = v.issues.length ? $c(v.issues) : Um), v);
      }, "wrapped");
      e._zod.parse = a, e._zod.run === i && (e._zod.run = a);
    });
  }
};
function un() {
  return Y$;
}
s(un, "memoizer");
function Ki(e, t) {
  let n = e[bc]?.backEdges;
  return n !== void 0 && t !== null && typeof t == "object" && n.has(t);
}
s(Ki, "isBackEdge");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/index.js
var pn = {};
Be(pn, {
  ar: () => wc,
  az: () => kc,
  be: () => Ic,
  bg: () => zc,
  bn: () => Sc,
  ca: () => Oc,
  ckb: () => jc,
  cs: () => Pc,
  da: () => Dc,
  de: () => Nc,
  el: () => Tc,
  en: () => cn,
  eo: () => Ac,
  es: () => Uc,
  fa: () => Ec,
  fi: () => Cc,
  fr: () => Zc,
  frCA: () => Rc,
  gu: () => Fc,
  he: () => Lc,
  hi: () => Vc,
  hr: () => Mc,
  hu: () => Bc,
  hy: () => Jc,
  id: () => qc,
  is: () => Wc,
  it: () => Kc,
  ja: () => Gc,
  ka: () => Xc,
  kh: () => Hc,
  km: () => ln,
  kn: () => Qc,
  ko: () => Yc,
  lt: () => el,
  mk: () => tl,
  ms: () => rl,
  ne: () => nl,
  nl: () => il,
  nn: () => ol,
  no: () => al,
  ota: () => sl,
  pl: () => cl,
  ps: () => ul,
  pt: () => ll,
  ptBR: () => dl,
  ro: () => fl,
  ru: () => pl,
  sk: () => ml,
  sl: () => gl,
  sv: () => hl,
  ta: () => vl,
  th: () => yl,
  tk: () => $l,
  tr: () => bl,
  ua: () => _l,
  uk: () => fn,
  ur: () => xl,
  uz: () => wl,
  vi: () => kl,
  yo: () => Sl,
  zhCN: () => Il,
  zhTW: () => zl
});

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ar.js
var eb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u062D\u0631\u0641", verb: "\u0623\u0646 \u064A\u062D\u0648\u064A" },
    file: { unit: "\u0628\u0627\u064A\u062A", verb: "\u0623\u0646 \u064A\u062D\u0648\u064A" },
    array: { unit: "\u0639\u0646\u0635\u0631", verb: "\u0623\u0646 \u064A\u062D\u0648\u064A" },
    set: { unit: "\u0639\u0646\u0635\u0631", verb: "\u0623\u0646 \u064A\u062D\u0648\u064A" },
    map: { unit: "\u0639\u0646\u0635\u0631", verb: "\u0623\u0646 \u064A\u062D\u0648\u064A" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u0645\u062F\u062E\u0644",
    email: "\u0628\u0631\u064A\u062F \u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A",
    url: "\u0631\u0627\u0628\u0637",
    emoji: "\u0625\u064A\u0645\u0648\u062C\u064A",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u062A\u0627\u0631\u064A\u062E \u0648\u0648\u0642\u062A \u0628\u0645\u0639\u064A\u0627\u0631 ISO",
    date: "\u062A\u0627\u0631\u064A\u062E \u0628\u0645\u0639\u064A\u0627\u0631 ISO",
    time: "\u0648\u0642\u062A \u0628\u0645\u0639\u064A\u0627\u0631 ISO",
    duration: "\u0645\u062F\u0629 \u0628\u0645\u0639\u064A\u0627\u0631 ISO",
    ipv4: "\u0639\u0646\u0648\u0627\u0646 IPv4",
    ipv6: "\u0639\u0646\u0648\u0627\u0646 IPv6",
    mac: "\u0639\u0646\u0648\u0627\u0646 MAC",
    cidrv4: "\u0645\u062F\u0649 \u0639\u0646\u0627\u0648\u064A\u0646 \u0628\u0635\u064A\u063A\u0629 IPv4",
    cidrv6: "\u0645\u062F\u0649 \u0639\u0646\u0627\u0648\u064A\u0646 \u0628\u0635\u064A\u063A\u0629 IPv6",
    base64: "\u0646\u064E\u0635 \u0628\u062A\u0631\u0645\u064A\u0632 base64-encoded",
    base64url: "\u0646\u064E\u0635 \u0628\u062A\u0631\u0645\u064A\u0632 base64url-encoded",
    json_string: "\u0646\u064E\u0635 \u0639\u0644\u0649 \u0647\u064A\u0626\u0629 JSON",
    e164: "\u0631\u0642\u0645 \u0647\u0627\u062A\u0641 \u0628\u0645\u0639\u064A\u0627\u0631 E.164",
    credit_card: "\u0631\u0642\u0645 \u0628\u0637\u0627\u0642\u0629 \u0627\u0644\u0627\u0626\u062A\u0645\u0627\u0646",
    jwt: "JWT",
    template_literal: "\u0645\u062F\u062E\u0644"
  }, o = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u0645\u062F\u062E\u0644\u0627\u062A \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644\u0629: \u064A\u0641\u062A\u0631\u0636 \u0625\u062F\u062E\u0627\u0644 instanceof ${r.expected}\u060C \u0648\u0644\u0643\u0646 \u062A\u0645 \u0625\u062F\u062E\u0627\u0644 ${u}` : `\u0645\u062F\u062E\u0644\u0627\u062A \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644\u0629: \u064A\u0641\u062A\u0631\u0636 \u0625\u062F\u062E\u0627\u0644 ${i}\u060C \u0648\u0644\u0643\u0646 \u062A\u0645 \u0625\u062F\u062E\u0627\u0644 ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u0645\u062F\u062E\u0644\u0627\u062A \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644\u0629: \u064A\u0641\u062A\u0631\u0636 \u0625\u062F\u062E\u0627\u0644 ${$(r.values[0])}` : `\u0627\u062E\u062A\u064A\u0627\u0631 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062A\u0648\u0642\u0639 \u0627\u0646\u062A\u0642\u0627\u0621 \u0623\u062D\u062F \u0647\u0630\u0647 \u0627\u0644\u062E\u064A\u0627\u0631\u0627\u062A: ${h(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? ` \u0623\u0643\u0628\u0631 \u0645\u0646 \u0627\u0644\u0644\u0627\u0632\u0645: \u064A\u0641\u062A\u0631\u0636 \u0623\u0646 \u062A\u0643\u0648\u0646 ${r.origin ?? "\u0627\u0644\u0642\u064A\u0645\u0629"} ${i} ${r.maximum.toString()} ${a.unit ?? "\u0639\u0646\u0635\u0631"}` : `\u0623\u0643\u0628\u0631 \u0645\u0646 \u0627\u0644\u0644\u0627\u0632\u0645: \u064A\u0641\u062A\u0631\u0636 \u0623\u0646 \u062A\u0643\u0648\u0646 ${r.origin ?? "\u0627\u0644\u0642\u064A\u0645\u0629"} ${i} ${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\u0623\u0635\u063A\u0631 \u0645\u0646 \u0627\u0644\u0644\u0627\u0632\u0645: \u064A\u0641\u062A\u0631\u0636 \u0644\u0640 ${r.origin} \u0623\u0646 \u064A\u0643\u0648\u0646 ${i} ${r.minimum.toString()} ${a.unit}` : `\u0623\u0635\u063A\u0631 \u0645\u0646 \u0627\u0644\u0644\u0627\u0632\u0645: \u064A\u0641\u062A\u0631\u0636 \u0644\u0640 ${r.origin} \u0623\u0646 \u064A\u0643\u0648\u0646 ${i} ${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u0646\u064E\u0635 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u0628\u062F\u0623 \u0628\u0640 "${r.prefix}"` : i.format === "ends_with" ? `\u0646\u064E\u0635 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u0646\u062A\u0647\u064A \u0628\u0640 "${i.suffix}"` : i.format === "includes" ? `\u0646\u064E\u0635 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u062A\u0636\u0645\u0651\u064E\u0646 "${i.includes}"` : i.format === "regex" ? `\u0646\u064E\u0635 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u0637\u0627\u0628\u0642 \u0627\u0644\u0646\u0645\u0637 ${i.pattern}` : `${n[i.format] ?? r.format} \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644`;
      }
      case "not_multiple_of":
        return `\u0631\u0642\u0645 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u0643\u0648\u0646 \u0645\u0646 \u0645\u0636\u0627\u0639\u0641\u0627\u062A ${r.divisor}`;
      case "unrecognized_keys":
        return `\u0645\u0639\u0631\u0641${r.keys.length > 1 ? "\u0627\u062A" : ""} \u063A\u0631\u064A\u0628${r.keys.length > 1 ? "\u0629" : ""}: ${h(r.keys, "\u060C ")}`;
      case "invalid_key":
        return `\u0645\u0639\u0631\u0641 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644 \u0641\u064A ${r.origin}`;
      case "invalid_union":
        return "\u0645\u062F\u062E\u0644 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644";
      case "invalid_element":
        return `\u0645\u062F\u062E\u0644 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644 \u0641\u064A ${r.origin}`;
      default:
        return "\u0645\u062F\u062E\u0644 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644";
    }
  };
}, "error");
function wc() {
  return {
    localeError: eb()
  };
}
s(wc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/az.js
var tb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "simvol", verb: "olmal\u0131d\u0131r" },
    file: { unit: "bayt", verb: "olmal\u0131d\u0131r" },
    array: { unit: "element", verb: "olmal\u0131d\u0131r" },
    set: { unit: "element", verb: "olmal\u0131d\u0131r" },
    map: { unit: "element", verb: "olmal\u0131d\u0131r" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "input",
    email: "email address",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datetime",
    date: "ISO date",
    time: "ISO time",
    duration: "ISO duration",
    ipv4: "IPv4 address",
    ipv6: "IPv6 address",
    mac: "MAC address",
    cidrv4: "IPv4 range",
    cidrv6: "IPv6 range",
    base64: "base64-encoded string",
    base64url: "base64url-encoded string",
    json_string: "JSON string",
    e164: "E.164 number",
    credit_card: "kredit kart\u0131 n\xF6mr\u0259si",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Yanl\u0131\u015F d\u0259y\u0259r: g\xF6zl\u0259nil\u0259n instanceof ${r.expected}, daxil olan ${u}` : `Yanl\u0131\u015F d\u0259y\u0259r: g\xF6zl\u0259nil\u0259n ${i}, daxil olan ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Yanl\u0131\u015F d\u0259y\u0259r: g\xF6zl\u0259nil\u0259n ${$(r.values[0])}` : `Yanl\u0131\u015F se\xE7im: a\u015Fa\u011F\u0131dak\u0131lardan biri olmal\u0131d\u0131r: ${h(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `\xC7ox b\xF6y\xFCk: g\xF6zl\u0259nil\u0259n ${r.origin ?? "d\u0259y\u0259r"} ${i}${r.maximum.toString()} ${a.unit ?? "element"}` : `\xC7ox b\xF6y\xFCk: g\xF6zl\u0259nil\u0259n ${r.origin ?? "d\u0259y\u0259r"} ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\xC7ox ki\xE7ik: g\xF6zl\u0259nil\u0259n ${r.origin} ${i}${r.minimum.toString()} ${a.unit}` : `\xC7ox ki\xE7ik: g\xF6zl\u0259nil\u0259n ${r.origin} ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Yanl\u0131\u015F m\u0259tn: "${i.prefix}" il\u0259 ba\u015Flamal\u0131d\u0131r` : i.format === "ends_with" ? `Yanl\u0131\u015F m\u0259tn: "${i.suffix}" il\u0259 bitm\u0259lidir` : i.format === "includes" ? `Yanl\u0131\u015F m\u0259tn: "${i.includes}" daxil olmal\u0131d\u0131r` : i.format === "regex" ? `Yanl\u0131\u015F m\u0259tn: ${i.pattern} \u015Fablonuna uy\u011Fun olmal\u0131d\u0131r` : `Yanl\u0131\u015F ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Yanl\u0131\u015F \u0259d\u0259d: ${r.divisor} il\u0259 b\xF6l\xFCn\u0259 bil\u0259n olmal\u0131d\u0131r`;
      case "unrecognized_keys":
        return `Tan\u0131nmayan a\xE7ar${r.keys.length > 1 ? "lar" : ""}: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `${r.origin} daxilind\u0259 yanl\u0131\u015F a\xE7ar`;
      case "invalid_union":
        return "Yanl\u0131\u015F d\u0259y\u0259r";
      case "invalid_element":
        return `${r.origin} daxilind\u0259 yanl\u0131\u015F d\u0259y\u0259r`;
      default:
        return "Yanl\u0131\u015F d\u0259y\u0259r";
    }
  };
}, "error");
function kc() {
  return {
    localeError: tb()
  };
}
s(kc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/be.js
function Cm(e, t, n, o) {
  let r = Math.abs(e), i = r % 10, a = r % 100;
  return a >= 11 && a <= 19 ? o : i === 1 ? t : i >= 2 && i <= 4 ? n : o;
}
s(Cm, "getBelarusianPlural");
var rb = /* @__PURE__ */ s(() => {
  let e = {
    string: {
      unit: {
        one: "\u0441\u0456\u043C\u0432\u0430\u043B",
        few: "\u0441\u0456\u043C\u0432\u0430\u043B\u044B",
        many: "\u0441\u0456\u043C\u0432\u0430\u043B\u0430\u045E"
      },
      verb: "\u043C\u0435\u0446\u044C"
    },
    array: {
      unit: {
        one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
        few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u044B",
        many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430\u045E"
      },
      verb: "\u043C\u0435\u0446\u044C"
    },
    set: {
      unit: {
        one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
        few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u044B",
        many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430\u045E"
      },
      verb: "\u043C\u0435\u0446\u044C"
    },
    map: {
      unit: {
        one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
        few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u044B",
        many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430\u045E"
      },
      verb: "\u043C\u0435\u0446\u044C"
    },
    file: {
      unit: {
        one: "\u0431\u0430\u0439\u0442",
        few: "\u0431\u0430\u0439\u0442\u044B",
        many: "\u0431\u0430\u0439\u0442\u0430\u045E"
      },
      verb: "\u043C\u0435\u0446\u044C"
    }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u0443\u0432\u043E\u0434",
    email: "email \u0430\u0434\u0440\u0430\u0441",
    url: "URL",
    emoji: "\u044D\u043C\u043E\u0434\u0437\u0456",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0434\u0430\u0442\u0430 \u0456 \u0447\u0430\u0441",
    date: "ISO \u0434\u0430\u0442\u0430",
    time: "ISO \u0447\u0430\u0441",
    duration: "ISO \u043F\u0440\u0430\u0446\u044F\u0433\u043B\u0430\u0441\u0446\u044C",
    ipv4: "IPv4 \u0430\u0434\u0440\u0430\u0441",
    ipv6: "IPv6 \u0430\u0434\u0440\u0430\u0441",
    mac: "MAC \u0430\u0434\u0440\u0430\u0441",
    cidrv4: "IPv4 \u0434\u044B\u044F\u043F\u0430\u0437\u043E\u043D",
    cidrv6: "IPv6 \u0434\u044B\u044F\u043F\u0430\u0437\u043E\u043D",
    base64: "\u0440\u0430\u0434\u043E\u043A \u0443 \u0444\u0430\u0440\u043C\u0430\u0446\u0435 base64",
    base64url: "\u0440\u0430\u0434\u043E\u043A \u0443 \u0444\u0430\u0440\u043C\u0430\u0446\u0435 base64url",
    json_string: "JSON \u0440\u0430\u0434\u043E\u043A",
    e164: "\u043D\u0443\u043C\u0430\u0440 E.164",
    credit_card: "\u043D\u0443\u043C\u0430\u0440 \u043A\u0440\u044D\u0434\u044B\u0442\u043D\u0430\u0439 \u043A\u0430\u0440\u0442\u044B",
    jwt: "JWT",
    template_literal: "\u0443\u0432\u043E\u0434"
  }, o = {
    nan: "NaN",
    number: "\u043B\u0456\u043A",
    array: "\u043C\u0430\u0441\u0456\u045E"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434: \u0447\u0430\u043A\u0430\u045E\u0441\u044F instanceof ${r.expected}, \u0430\u0442\u0440\u044B\u043C\u0430\u043D\u0430 ${u}` : `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434: \u0447\u0430\u043A\u0430\u045E\u0441\u044F ${i}, \u0430\u0442\u0440\u044B\u043C\u0430\u043D\u0430 ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F ${$(r.values[0])}` : `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0432\u0430\u0440\u044B\u044F\u043D\u0442: \u0447\u0430\u043A\u0430\u045E\u0441\u044F \u0430\u0434\u0437\u0456\u043D \u0437 ${h(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        if (a) {
          let u = Number(r.maximum), c = Cm(u, a.unit.one, a.unit.few, a.unit.many);
          return `\u0417\u0430\u043D\u0430\u0434\u0442\u0430 \u0432\u044F\u043B\u0456\u043A\u0456: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F, \u0448\u0442\u043E ${r.origin ?? "\u0437\u043D\u0430\u0447\u044D\u043D\u043D\u0435"} \u043F\u0430\u0432\u0456\u043D\u043D\u0430 ${a.verb} ${i}${r.maximum.toString()} ${c}`;
        }
        return `\u0417\u0430\u043D\u0430\u0434\u0442\u0430 \u0432\u044F\u043B\u0456\u043A\u0456: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F, \u0448\u0442\u043E ${r.origin ?? "\u0437\u043D\u0430\u0447\u044D\u043D\u043D\u0435"} \u043F\u0430\u0432\u0456\u043D\u043D\u0430 \u0431\u044B\u0446\u044C ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        if (a) {
          let u = Number(r.minimum), c = Cm(u, a.unit.one, a.unit.few, a.unit.many);
          return `\u0417\u0430\u043D\u0430\u0434\u0442\u0430 \u043C\u0430\u043B\u044B: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F, \u0448\u0442\u043E ${r.origin} \u043F\u0430\u0432\u0456\u043D\u043D\u0430 ${a.verb} ${i}${r.minimum.toString()} ${c}`;
        }
        return `\u0417\u0430\u043D\u0430\u0434\u0442\u0430 \u043C\u0430\u043B\u044B: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F, \u0448\u0442\u043E ${r.origin} \u043F\u0430\u0432\u0456\u043D\u043D\u0430 \u0431\u044B\u0446\u044C ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0440\u0430\u0434\u043E\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u043F\u0430\u0447\u044B\u043D\u0430\u0446\u0446\u0430 \u0437 "${i.prefix}"` : i.format === "ends_with" ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0440\u0430\u0434\u043E\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u0437\u0430\u043A\u0430\u043D\u0447\u0432\u0430\u0446\u0446\u0430 \u043D\u0430 "${i.suffix}"` : i.format === "includes" ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0440\u0430\u0434\u043E\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u0437\u043C\u044F\u0448\u0447\u0430\u0446\u044C "${i.includes}"` : i.format === "regex" ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0440\u0430\u0434\u043E\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u0430\u0434\u043F\u0430\u0432\u044F\u0434\u0430\u0446\u044C \u0448\u0430\u0431\u043B\u043E\u043D\u0443 ${i.pattern}` : `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u043B\u0456\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u0431\u044B\u0446\u044C \u043A\u0440\u0430\u0442\u043D\u044B\u043C ${r.divisor}`;
      case "unrecognized_keys":
        return `\u041D\u0435\u0440\u0430\u0441\u043F\u0430\u0437\u043D\u0430\u043D\u044B ${r.keys.length > 1 ? "\u043A\u043B\u044E\u0447\u044B" : "\u043A\u043B\u044E\u0447"}: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u043A\u043B\u044E\u0447 \u0443 ${r.origin}`;
      case "invalid_union":
        return "\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434";
      case "invalid_element":
        return `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u0430\u0435 \u0437\u043D\u0430\u0447\u044D\u043D\u043D\u0435 \u045E ${r.origin}`;
      default:
        return "\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434";
    }
  };
}, "error");
function Ic() {
  return {
    localeError: rb()
  };
}
s(Ic, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/bg.js
var nb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0441\u0438\u043C\u0432\u043E\u043B\u0430", verb: "\u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430" },
    file: { unit: "\u0431\u0430\u0439\u0442\u0430", verb: "\u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430" },
    array: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0430", verb: "\u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430" },
    set: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0430", verb: "\u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430" },
    map: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0430", verb: "\u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u0432\u0445\u043E\u0434",
    email: "\u0438\u043C\u0435\u0439\u043B \u0430\u0434\u0440\u0435\u0441",
    url: "URL",
    emoji: "\u0435\u043C\u043E\u0434\u0436\u0438",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0432\u0440\u0435\u043C\u0435",
    date: "ISO \u0434\u0430\u0442\u0430",
    time: "ISO \u0432\u0440\u0435\u043C\u0435",
    duration: "ISO \u043F\u0440\u043E\u0434\u044A\u043B\u0436\u0438\u0442\u0435\u043B\u043D\u043E\u0441\u0442",
    ipv4: "IPv4 \u0430\u0434\u0440\u0435\u0441",
    ipv6: "IPv6 \u0430\u0434\u0440\u0435\u0441",
    mac: "MAC \u0430\u0434\u0440\u0435\u0441",
    cidrv4: "IPv4 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D",
    cidrv6: "IPv6 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D",
    base64: "base64-\u043A\u043E\u0434\u0438\u0440\u0430\u043D \u043D\u0438\u0437",
    base64url: "base64url-\u043A\u043E\u0434\u0438\u0440\u0430\u043D \u043D\u0438\u0437",
    json_string: "JSON \u043D\u0438\u0437",
    e164: "E.164 \u043D\u043E\u043C\u0435\u0440",
    credit_card: "\u043D\u043E\u043C\u0435\u0440 \u043D\u0430 \u043A\u0440\u0435\u0434\u0438\u0442\u043D\u0430 \u043A\u0430\u0440\u0442\u0430",
    jwt: "JWT",
    template_literal: "\u0432\u0445\u043E\u0434"
  }, o = {
    nan: "NaN",
    number: "\u0447\u0438\u0441\u043B\u043E",
    array: "\u043C\u0430\u0441\u0438\u0432"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434: \u043E\u0447\u0430\u043A\u0432\u0430\u043D instanceof ${r.expected}, \u043F\u043E\u043B\u0443\u0447\u0435\u043D ${u}` : `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434: \u043E\u0447\u0430\u043A\u0432\u0430\u043D ${i}, \u043F\u043E\u043B\u0443\u0447\u0435\u043D ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434: \u043E\u0447\u0430\u043A\u0432\u0430\u043D ${$(r.values[0])}` : `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u0430 \u043E\u043F\u0446\u0438\u044F: \u043E\u0447\u0430\u043A\u0432\u0430\u043D\u043E \u0435\u0434\u043D\u043E \u043E\u0442 ${h(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `\u0422\u0432\u044A\u0440\u0434\u0435 \u0433\u043E\u043B\u044F\u043C\u043E: \u043E\u0447\u0430\u043A\u0432\u0430 \u0441\u0435 ${r.origin ?? "\u0441\u0442\u043E\u0439\u043D\u043E\u0441\u0442"} \u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430 ${i}${r.maximum.toString()} ${a.unit ?? "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0430"}` : `\u0422\u0432\u044A\u0440\u0434\u0435 \u0433\u043E\u043B\u044F\u043C\u043E: \u043E\u0447\u0430\u043A\u0432\u0430 \u0441\u0435 ${r.origin ?? "\u0441\u0442\u043E\u0439\u043D\u043E\u0441\u0442"} \u0434\u0430 \u0431\u044A\u0434\u0435 ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\u0422\u0432\u044A\u0440\u0434\u0435 \u043C\u0430\u043B\u043A\u043E: \u043E\u0447\u0430\u043A\u0432\u0430 \u0441\u0435 ${r.origin} \u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430 ${i}${r.minimum.toString()} ${a.unit}` : `\u0422\u0432\u044A\u0440\u0434\u0435 \u043C\u0430\u043B\u043A\u043E: \u043E\u0447\u0430\u043A\u0432\u0430 \u0441\u0435 ${r.origin} \u0434\u0430 \u0431\u044A\u0434\u0435 ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        if (i.format === "starts_with")
          return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043D\u0438\u0437: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0437\u0430\u043F\u043E\u0447\u0432\u0430 \u0441 "${i.prefix}"`;
        if (i.format === "ends_with")
          return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043D\u0438\u0437: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0437\u0430\u0432\u044A\u0440\u0448\u0432\u0430 \u0441 "${i.suffix}"`;
        if (i.format === "includes")
          return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043D\u0438\u0437: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0432\u043A\u043B\u044E\u0447\u0432\u0430 "${i.includes}"`;
        if (i.format === "regex")
          return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043D\u0438\u0437: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0441\u044A\u0432\u043F\u0430\u0434\u0430 \u0441 ${i.pattern}`;
        let a = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D";
        return i.format === "emoji" && (a = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u043E"), i.format === "datetime" && (a = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u043E"), i.format === "date" && (a = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u0430"), i.format === "time" && (a = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u043E"), i.format === "duration" && (a = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u0430"), `${a} ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u043E \u0447\u0438\u0441\u043B\u043E: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0431\u044A\u0434\u0435 \u043A\u0440\u0430\u0442\u043D\u043E \u043D\u0430 ${r.divisor}`;
      case "unrecognized_keys":
        return `\u041D\u0435\u0440\u0430\u0437\u043F\u043E\u0437\u043D\u0430\u0442${r.keys.length > 1 ? "\u0438" : ""} \u043A\u043B\u044E\u0447${r.keys.length > 1 ? "\u043E\u0432\u0435" : ""}: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043A\u043B\u044E\u0447 \u0432 ${r.origin}`;
      case "invalid_union":
        return "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434";
      case "invalid_element":
        return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u0430 \u0441\u0442\u043E\u0439\u043D\u043E\u0441\u0442 \u0432 ${r.origin}`;
      default:
        return "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434";
    }
  };
}, "error");
function zc() {
  return {
    localeError: nb()
  };
}
s(zc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/bn.js
var ib = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0985\u0995\u09CD\u09B7\u09B0", verb: "\u09A5\u09BE\u0995\u09A4\u09C7 \u09B9\u09AC\u09C7" },
    file: { unit: "\u09AC\u09BE\u0987\u099F", verb: "\u09A5\u09BE\u0995\u09A4\u09C7 \u09B9\u09AC\u09C7" },
    array: { unit: "\u0986\u0987\u099F\u09C7\u09AE", verb: "\u09A5\u09BE\u0995\u09A4\u09C7 \u09B9\u09AC\u09C7" },
    set: { unit: "\u0986\u0987\u099F\u09C7\u09AE", verb: "\u09A5\u09BE\u0995\u09A4\u09C7 \u09B9\u09AC\u09C7" },
    map: { unit: "\u098F\u09A8\u09CD\u099F\u09CD\u09B0\u09BF", verb: "\u09A5\u09BE\u0995\u09A4\u09C7 \u09B9\u09AC\u09C7" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u0987\u09A8\u09AA\u09C1\u099F",
    email: "\u0987\u09AE\u09C7\u0987\u09B2 \u09A0\u09BF\u0995\u09BE\u09A8\u09BE",
    url: "URL",
    emoji: "\u0987\u09AE\u09CB\u099C\u09BF",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u09A4\u09BE\u09B0\u09BF\u0996 \u0993 \u09B8\u09AE\u09AF\u09BC",
    date: "ISO \u09A4\u09BE\u09B0\u09BF\u0996",
    time: "ISO \u09B8\u09AE\u09AF\u09BC",
    duration: "ISO \u09B8\u09AE\u09AF\u09BC\u0995\u09BE\u09B2",
    ipv4: "IPv4 \u09A0\u09BF\u0995\u09BE\u09A8\u09BE",
    ipv6: "IPv6 \u09A0\u09BF\u0995\u09BE\u09A8\u09BE",
    mac: "MAC \u09A0\u09BF\u0995\u09BE\u09A8\u09BE",
    cidrv4: "IPv4 \u09B0\u09C7\u099E\u09CD\u099C",
    cidrv6: "IPv6 \u09B0\u09C7\u099E\u09CD\u099C",
    base64: "base64-\u098F\u09A8\u0995\u09CB\u09A1\u09C7\u09A1 \u09B8\u09CD\u099F\u09CD\u09B0\u09BF\u0982",
    base64url: "base64url-\u098F\u09A8\u0995\u09CB\u09A1\u09C7\u09A1 \u09B8\u09CD\u099F\u09CD\u09B0\u09BF\u0982",
    json_string: "JSON \u09B8\u09CD\u099F\u09CD\u09B0\u09BF\u0982",
    e164: "E.164 \u09A8\u09AE\u09CD\u09AC\u09B0",
    credit_card: "\u0995\u09CD\u09B0\u09C7\u09A1\u09BF\u099F \u0995\u09BE\u09B0\u09CD\u09A1 \u09A8\u09AE\u09CD\u09AC\u09B0",
    jwt: "JWT",
    template_literal: "\u0987\u09A8\u09AA\u09C1\u099F"
  }, o = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return `\u0985\u09AC\u09C8\u09A7 \u0987\u09A8\u09AA\u09C1\u099F: \u09AA\u09CD\u09B0\u09A4\u09CD\u09AF\u09BE\u09B6\u09BF\u09A4 ${i}, \u09AA\u09CD\u09B0\u09BE\u09AA\u09CD\u09A4 ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u0985\u09AC\u09C8\u09A7 \u0987\u09A8\u09AA\u09C1\u099F: \u09AA\u09CD\u09B0\u09A4\u09CD\u09AF\u09BE\u09B6\u09BF\u09A4 ${$(r.values[0])}` : `\u0985\u09AC\u09C8\u09A7 \u0985\u09AA\u09B6\u09A8: ${h(r.values, " | ")} \u098F\u09B0 \u09AE\u09A7\u09CD\u09AF\u09C7 \u098F\u0995\u099F\u09BF \u09AA\u09CD\u09B0\u09A4\u09CD\u09AF\u09BE\u09B6\u09BF\u09A4`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `\u0985\u09A8\u09C7\u0995 \u09AC\u09A1\u09BC: ${r.origin ?? "\u09AE\u09BE\u09A8"} ${i}${r.maximum.toString()} ${a.unit ?? "\u098F\u09B2\u09BF\u09AE\u09C7\u09A8\u09CD\u099F"} \u09B9\u09A4\u09C7 \u09B9\u09AC\u09C7` : `\u0985\u09A8\u09C7\u0995 \u09AC\u09A1\u09BC: ${r.origin ?? "\u09AE\u09BE\u09A8"} ${i}${r.maximum.toString()} \u09B9\u09A4\u09C7 \u09B9\u09AC\u09C7`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\u0985\u09A8\u09C7\u0995 \u099B\u09CB\u099F: ${r.origin} ${i}${r.minimum.toString()} ${a.unit} \u09B9\u09A4\u09C7 \u09B9\u09AC\u09C7` : `\u0985\u09A8\u09C7\u0995 \u099B\u09CB\u099F: ${r.origin} ${i}${r.minimum.toString()} \u09B9\u09A4\u09C7 \u09B9\u09AC\u09C7`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u0985\u09AC\u09C8\u09A7 \u09B8\u09CD\u099F\u09CD\u09B0\u09BF\u0982: "${i.prefix}" \u09A6\u09BF\u09AF\u09BC\u09C7 \u09B6\u09C1\u09B0\u09C1 \u09B9\u09A4\u09C7 \u09B9\u09AC\u09C7` : i.format === "ends_with" ? `\u0985\u09AC\u09C8\u09A7 \u09B8\u09CD\u099F\u09CD\u09B0\u09BF\u0982: "${i.suffix}" \u09A6\u09BF\u09AF\u09BC\u09C7 \u09B6\u09C7\u09B7 \u09B9\u09A4\u09C7 \u09B9\u09AC\u09C7` : i.format === "includes" ? `\u0985\u09AC\u09C8\u09A7 \u09B8\u09CD\u099F\u09CD\u09B0\u09BF\u0982: "${i.includes}" \u0985\u09A8\u09CD\u09A4\u09B0\u09CD\u09AD\u09C1\u0995\u09CD\u09A4 \u09A5\u09BE\u0995\u09A4\u09C7 \u09B9\u09AC\u09C7` : i.format === "regex" ? `\u0985\u09AC\u09C8\u09A7 \u09B8\u09CD\u099F\u09CD\u09B0\u09BF\u0982: ${i.pattern} \u09AA\u09CD\u09AF\u09BE\u099F\u09BE\u09B0\u09CD\u09A8 \u09AE\u09BF\u09B2\u09A4\u09C7 \u09B9\u09AC\u09C7` : `\u0985\u09AC\u09C8\u09A7 ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u0985\u09AC\u09C8\u09A7 \u09A8\u09AE\u09CD\u09AC\u09B0: ${r.divisor} \u098F\u09B0 \u0997\u09C1\u09A3\u09BF\u09A4\u0995 \u09B9\u09A4\u09C7 \u09B9\u09AC\u09C7`;
      case "unrecognized_keys":
        return `\u0985\u099A\u09C7\u09A8\u09BE \u0995\u09C0${r.keys.length > 1 ? "\u0997\u09C1\u09B2\u09CB" : ""}: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `${r.origin} \u098F \u0985\u09AC\u09C8\u09A7 \u0995\u09C0`;
      case "invalid_union":
        return r.options && Array.isArray(r.options) && r.options.length > 0 ? `\u0985\u09AC\u09C8\u09A7 \u09A1\u09BF\u09B8\u0995\u09CD\u09B0\u09BF\u09AE\u09BF\u09A8\u09C7\u099F\u09B0 \u09AE\u09BE\u09A8\u0964 \u09AA\u09CD\u09B0\u09A4\u09CD\u09AF\u09BE\u09B6\u09BF\u09A4 ${r.options.map((a) => `'${a}'`).join(" | ")}` : "\u0985\u09AC\u09C8\u09A7 \u0987\u09A8\u09AA\u09C1\u099F";
      case "invalid_element":
        return `${r.origin} \u098F \u0985\u09AC\u09C8\u09A7 \u09AE\u09BE\u09A8`;
      default:
        return "\u0985\u09AC\u09C8\u09A7 \u0987\u09A8\u09AA\u09C1\u099F";
    }
  };
}, "error");
function Sc() {
  return {
    localeError: ib()
  };
}
s(Sc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ca.js
var ob = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "car\xE0cters", verb: "contenir" },
    file: { unit: "bytes", verb: "contenir" },
    array: { unit: "elements", verb: "contenir" },
    set: { unit: "elements", verb: "contenir" },
    map: { unit: "elements", verb: "contenir" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "entrada",
    email: "adre\xE7a electr\xF2nica",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "data i hora ISO",
    date: "data ISO",
    time: "hora ISO",
    duration: "durada ISO",
    ipv4: "adre\xE7a IPv4",
    ipv6: "adre\xE7a IPv6",
    mac: "adre\xE7a MAC",
    cidrv4: "rang IPv4",
    cidrv6: "rang IPv6",
    base64: "cadena codificada en base64",
    base64url: "cadena codificada en base64url",
    json_string: "cadena JSON",
    e164: "n\xFAmero E.164",
    credit_card: "n\xFAmero de targeta de cr\xE8dit",
    jwt: "JWT",
    template_literal: "entrada"
  }, o = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Tipus inv\xE0lid: s'esperava instanceof ${r.expected}, s'ha rebut ${u}` : `Tipus inv\xE0lid: s'esperava ${i}, s'ha rebut ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Valor inv\xE0lid: s'esperava ${$(r.values[0])}` : `Opci\xF3 inv\xE0lida: s'esperava una de ${h(r.values, " o ")}`;
      case "too_big": {
        let i = r.inclusive ? "com a m\xE0xim" : "menys de", a = t(r.origin);
        return a ? `Massa gran: s'esperava que ${r.origin ?? "el valor"} contingu\xE9s ${i} ${r.maximum.toString()} ${a.unit ?? "elements"}` : `Massa gran: s'esperava que ${r.origin ?? "el valor"} fos ${i} ${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? "com a m\xEDnim" : "m\xE9s de", a = t(r.origin);
        return a ? `Massa petit: s'esperava que ${r.origin} contingu\xE9s ${i} ${r.minimum.toString()} ${a.unit}` : `Massa petit: s'esperava que ${r.origin} fos ${i} ${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Format inv\xE0lid: ha de comen\xE7ar amb "${i.prefix}"` : i.format === "ends_with" ? `Format inv\xE0lid: ha d'acabar amb "${i.suffix}"` : i.format === "includes" ? `Format inv\xE0lid: ha d'incloure "${i.includes}"` : i.format === "regex" ? `Format inv\xE0lid: ha de coincidir amb el patr\xF3 ${i.pattern}` : `Format inv\xE0lid per a ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `N\xFAmero inv\xE0lid: ha de ser m\xFAltiple de ${r.divisor}`;
      case "unrecognized_keys":
        return `Clau${r.keys.length > 1 ? "s" : ""} no reconeguda${r.keys.length > 1 ? "s" : ""}: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `Clau inv\xE0lida a ${r.origin}`;
      case "invalid_union":
        return "Entrada inv\xE0lida";
      // Could also be "Tipus d'unió invàlid" but "Entrada invàlida" is more general
      case "invalid_element":
        return `Element inv\xE0lid a ${r.origin}`;
      default:
        return "Entrada inv\xE0lida";
    }
  };
}, "error");
function Oc() {
  return {
    localeError: ob()
  };
}
s(Oc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ckb.js
var ab = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u067E\u06CC\u062A", verb: "\u0628\u06CE\u062A" },
    file: { unit: "\u0628\u0627\u06CC\u062A", verb: "\u0628\u06CE\u062A" },
    array: { unit: "\u062F\u0627\u0646\u06D5", verb: "\u0628\u06CE\u062A" },
    set: { unit: "\u062F\u0627\u0646\u06D5", verb: "\u0628\u06CE\u062A" },
    map: { unit: "\u062F\u0627\u0646\u06D5", verb: "\u0628\u06CE\u062A" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "regex",
    email: "\u0626\u06CC\u0645\u06D5\u06CC\u06B5",
    url: "\u0628\u06D5\u0633\u062A\u06D5\u0631 (URL)",
    emoji: "\u0626\u06CC\u0645\u06C6\u062C\u06CC",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u0695\u06CE\u06A9\u06D5\u0648\u062A \u0648 \u06A9\u0627\u062A",
    date: "\u0695\u06CE\u06A9\u06D5\u0648\u062A",
    time: "\u06A9\u0627\u062A",
    duration: "\u0645\u0627\u0648\u06D5",
    ipv4: "\u0646\u0627\u0648\u0646\u06CC\u0634\u0627\u0646\u06CC IPv4",
    ipv6: "\u0646\u0627\u0648\u0646\u06CC\u0634\u0627\u0646\u06CC IPv6",
    mac: "\u0646\u0627\u0648\u0646\u06CC\u0634\u0627\u0646\u06CC MAC",
    cidrv4: "\u0645\u06D5\u0648\u062F\u0627\u06CC IPv4",
    cidrv6: "\u0645\u06D5\u0648\u062F\u0627\u06CC IPv6",
    base64: "\u062F\u06D5\u0642\u06CC base64",
    base64url: "\u062F\u06D5\u0642\u06CC base64url",
    json_string: "\u062F\u06D5\u0642\u06CC JSON",
    e164: "\u0698\u0645\u0627\u0631\u06D5\u06CC E.164",
    credit_card: "\u0698\u0645\u0627\u0631\u06D5\u06CC \u06A9\u0627\u0631\u062A\u06CC \u06A9\u0631\u06CE\u062F\u06CC\u062A",
    jwt: "JWT",
    template_literal: "\u062A\u06CE\u06A9\u0631\u062F\u06D5"
  }, o = {
    nan: "NaN",
    string: "\u0646\u0648\u0648\u0633\u06CC\u0646",
    number: "\u0698\u0645\u0627\u0631\u06D5",
    boolean: "boolean",
    array: "array",
    object: "object",
    date: "\u0695\u06CE\u06A9\u06D5\u0648\u062A",
    integer: "\u0698\u0645\u0627\u0631\u06D5",
    float: "\u0698\u0645\u0627\u0631\u06D5",
    null: "null",
    undefined: "undefined",
    function: "function",
    symbol: "symbol",
    unknown: "unknown",
    promise: "promise",
    void: "void",
    never: "never",
    map: "map",
    set: "set"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a, c = ["\u0627", "\u0648", "\u06C6", "\u0648\u0648", "\u06D5", "\u06CC", "\u06CE"].some((d) => u.endsWith(d)) ? "\u06CC\u06D5" : "\u06D5", l = /^[a-zA-Z]+$/.test(u);
        return a === "null" || a === "undefined" ? "\u062F\u0627\u0648\u0627\u06A9\u0631\u0627\u0648\u06D5" : `\u0686\u0627\u0648\u06D5\u0695\u0648\u0627\u0646\u06A9\u0631\u0627\u0648\u06D5 ${i} \u0628\u06CE\u062A\u060C \u0628\u06D5\u06B5\u0627\u0645 ${u}${l ? "" : c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u0628\u06D5\u0647\u0627\u06A9\u06D5 \u0646\u0627\u062F\u0631\u0648\u0648\u0633\u062A\u06D5: \u0686\u0627\u0648\u06D5\u0695\u0648\u0627\u0646\u06A9\u0631\u0627\u0648\u06D5 ${$(r.values[0])} \u0628\u06CE\u062A` : `\u0647\u06D5\u06B5\u0628\u0698\u0627\u0631\u062F\u06D5\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A: \u0686\u0627\u0648\u06D5\u0695\u0648\u0627\u0646\u06A9\u0631\u0627\u0648\u06D5 \u06CC\u06D5\u06A9\u06CE\u06A9 \u0628\u06CE\u062A \u0644\u06D5 ${h(r.values, "|")}`;
      case "too_big": {
        let i = t(r.origin);
        return i ? `\u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 \u0628\u06D5 \u0644\u0627\u06CC\u06D5\u0646\u06CC \u0632\u06C6\u0631\u06D5\u0648\u06D5 ${r.maximum.toString()} ${i.unit} ${i.verb}` : `\u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 \u0628\u06D5 \u0644\u0627\u06CC\u06D5\u0646\u06CC \u0632\u06C6\u0631\u06D5\u0648\u06D5 ${r.maximum.toString()} \u0628\u06CE\u062A`;
      }
      case "too_small": {
        let i = t(r.origin);
        return i ? `\u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 \u0628\u06D5 \u0644\u0627\u06CC\u06D5\u0646\u06CC \u06A9\u06D5\u0645\u06D5\u0648\u06D5 ${r.minimum.toString()} ${i.unit} ${i.verb}` : `\u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 \u0628\u06D5 \u0644\u0627\u06CC\u06D5\u0646\u06CC \u06A9\u06D5\u0645\u06D5\u0648\u06D5 ${r.minimum.toString()} \u0628\u06CE\u062A`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u062F\u06D5\u0642\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A: \u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 \u062F\u06D5\u0633\u062A\u067E\u06CE\u0628\u06A9\u0627\u062A \u0628\u06D5 "${i.prefix}"` : i.format === "ends_with" ? `\u062F\u06D5\u0642\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A: \u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 \u06A9\u06C6\u062A\u0627\u06CC\u06CC\u0628\u06CE\u062A \u0628\u06D5 "${i.suffix}"` : i.format === "includes" ? `\u062F\u06D5\u0642\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A: \u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 "${i.includes}" \u0644\u06D5\u062E\u06C6\u0628\u06AF\u0631\u06CE\u062A` : i.format === "regex" ? `\u062F\u06D5\u0642\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A: \u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 \u0644\u06D5\u06AF\u06D5\u06B5 \u067E\u0627\u062A\u06CE\u0631\u0646\u06CC ${i.pattern} \u0628\u06AF\u0648\u0646\u062C\u06CE\u062A` : `\u0628\u06D5\u0647\u0627\u06CC ${n[i.format] ?? r.format} \u0646\u0627\u062F\u0631\u0648\u0633\u062A\u06D5`;
      }
      case "not_multiple_of":
        return `\u0698\u0645\u0627\u0631\u06D5\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A: \u062F\u06D5\u0628\u06CE\u062A \u0686\u06D5\u0646\u062F \u0647\u06CE\u0646\u062F\u06D5 \u0628\u06CE\u062A \u0628\u06C6 ${r.divisor}`;
      case "unrecognized_keys":
        return `\u06A9\u0644\u06CC\u0644\u06CC \u0646\u06D5\u0646\u0627\u0633\u0631\u0627\u0648: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `\u06A9\u0644\u06CC\u0644\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A \u0644\u06D5 ${r.origin}`;
      case "invalid_union":
        return r.options && Array.isArray(r.options) && r.options.length > 0 ? `\u0628\u06D5\u0647\u0627\u06CC \u0646\u06D5\u0646\u0627\u0633\u0631\u0627\u0648 \u0647\u06D5\u06CC\u06D5. \u0628\u06D5\u0647\u0627\u06CC \u0686\u0627\u0648\u06D5\u0695\u0648\u0627\u0646\u06A9\u0631\u0627\u0648: ${r.options.map((a) => `'${a}'`).join(" | ")}` : "\u06CC\u06D5\u06A9\u06AF\u0631\u062A\u0646\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A";
      case "invalid_element":
        return `${r.origin} \u0628\u06D5\u0647\u0627\u06A9\u06D5 \u0646\u0627\u062F\u0631\u0648\u0633\u062A\u06D5`;
      default:
        return "\u062A\u06CE\u06A9\u0631\u062F\u06D5\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A";
    }
  };
}, "error");
function jc() {
  return {
    localeError: ab()
  };
}
s(jc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/cs.js
var sb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "znak\u016F", verb: "m\xEDt" },
    file: { unit: "bajt\u016F", verb: "m\xEDt" },
    array: { unit: "prvk\u016F", verb: "m\xEDt" },
    set: { unit: "prvk\u016F", verb: "m\xEDt" },
    map: { unit: "prvk\u016F", verb: "m\xEDt" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "regul\xE1rn\xED v\xFDraz",
    email: "e-mailov\xE1 adresa",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "datum a \u010Das ve form\xE1tu ISO",
    date: "datum ve form\xE1tu ISO",
    time: "\u010Das ve form\xE1tu ISO",
    duration: "doba trv\xE1n\xED ISO",
    ipv4: "IPv4 adresa",
    ipv6: "IPv6 adresa",
    mac: "MAC adresa",
    cidrv4: "rozsah IPv4",
    cidrv6: "rozsah IPv6",
    base64: "\u0159et\u011Bzec zak\xF3dovan\xFD ve form\xE1tu base64",
    base64url: "\u0159et\u011Bzec zak\xF3dovan\xFD ve form\xE1tu base64url",
    json_string: "\u0159et\u011Bzec ve form\xE1tu JSON",
    e164: "\u010D\xEDslo E.164",
    credit_card: "\u010D\xEDslo kreditn\xED karty",
    jwt: "JWT",
    template_literal: "vstup"
  }, o = {
    nan: "NaN",
    number: "\u010D\xEDslo",
    string: "\u0159et\u011Bzec",
    function: "funkce",
    array: "pole"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Neplatn\xFD vstup: o\u010Dek\xE1v\xE1no instanceof ${r.expected}, obdr\u017Eeno ${u}` : `Neplatn\xFD vstup: o\u010Dek\xE1v\xE1no ${i}, obdr\u017Eeno ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Neplatn\xFD vstup: o\u010Dek\xE1v\xE1no ${$(r.values[0])}` : `Neplatn\xE1 mo\u017Enost: o\u010Dek\xE1v\xE1na jedna z hodnot ${h(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Hodnota je p\u0159\xEDli\u0161 velk\xE1: ${r.origin ?? "hodnota"} mus\xED m\xEDt ${i}${r.maximum.toString()} ${a.unit ?? "prvk\u016F"}` : `Hodnota je p\u0159\xEDli\u0161 velk\xE1: ${r.origin ?? "hodnota"} mus\xED b\xFDt ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Hodnota je p\u0159\xEDli\u0161 mal\xE1: ${r.origin ?? "hodnota"} mus\xED m\xEDt ${i}${r.minimum.toString()} ${a.unit ?? "prvk\u016F"}` : `Hodnota je p\u0159\xEDli\u0161 mal\xE1: ${r.origin ?? "hodnota"} mus\xED b\xFDt ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Neplatn\xFD \u0159et\u011Bzec: mus\xED za\u010D\xEDnat na "${i.prefix}"` : i.format === "ends_with" ? `Neplatn\xFD \u0159et\u011Bzec: mus\xED kon\u010Dit na "${i.suffix}"` : i.format === "includes" ? `Neplatn\xFD \u0159et\u011Bzec: mus\xED obsahovat "${i.includes}"` : i.format === "regex" ? `Neplatn\xFD \u0159et\u011Bzec: mus\xED odpov\xEDdat vzoru ${i.pattern}` : `Neplatn\xFD form\xE1t ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Neplatn\xE9 \u010D\xEDslo: mus\xED b\xFDt n\xE1sobkem ${r.divisor}`;
      case "unrecognized_keys":
        return `Nezn\xE1m\xE9 kl\xED\u010De: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `Neplatn\xFD kl\xED\u010D v ${r.origin}`;
      case "invalid_union":
        return "Neplatn\xFD vstup";
      case "invalid_element":
        return `Neplatn\xE1 hodnota v ${r.origin}`;
      default:
        return "Neplatn\xFD vstup";
    }
  };
}, "error");
function Pc() {
  return {
    localeError: sb()
  };
}
s(Pc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/da.js
var ub = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "tegn", verb: "havde" },
    file: { unit: "bytes", verb: "havde" },
    array: { unit: "elementer", verb: "indeholdt" },
    set: { unit: "elementer", verb: "indeholdt" },
    map: { unit: "elementer", verb: "indeholdt" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "input",
    email: "e-mailadresse",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO dato- og klokkesl\xE6t",
    date: "ISO-dato",
    time: "ISO-klokkesl\xE6t",
    duration: "ISO-varighed",
    ipv4: "IPv4-adresse",
    ipv6: "IPv6-adresse",
    mac: "MAC-adresse",
    cidrv4: "IPv4-spektrum",
    cidrv6: "IPv6-spektrum",
    base64: "base64-kodet streng",
    base64url: "base64url-kodet streng",
    json_string: "JSON-streng",
    e164: "E.164-nummer",
    credit_card: "kreditkortnummer",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN",
    string: "streng",
    number: "tal",
    boolean: "boolean",
    array: "liste",
    object: "objekt",
    set: "s\xE6t",
    file: "fil"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Ugyldigt input: forventede instanceof ${r.expected}, fik ${u}` : `Ugyldigt input: forventede ${i}, fik ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Ugyldig v\xE6rdi: forventede ${$(r.values[0])}` : `Ugyldigt valg: forventede en af f\xF8lgende ${h(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin), u = o[r.origin] ?? r.origin;
        return a ? `For stor: forventede ${u ?? "value"} ${a.verb} ${i} ${r.maximum.toString()} ${a.unit ?? "elementer"}` : `For stor: forventede ${u ?? "value"} havde ${i} ${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin), u = o[r.origin] ?? r.origin;
        return a ? `For lille: forventede ${u} ${a.verb} ${i} ${r.minimum.toString()} ${a.unit}` : `For lille: forventede ${u} havde ${i} ${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Ugyldig streng: skal starte med "${i.prefix}"` : i.format === "ends_with" ? `Ugyldig streng: skal ende med "${i.suffix}"` : i.format === "includes" ? `Ugyldig streng: skal indeholde "${i.includes}"` : i.format === "regex" ? `Ugyldig streng: skal matche m\xF8nsteret ${i.pattern}` : `Ugyldig ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Ugyldigt tal: skal v\xE6re deleligt med ${r.divisor}`;
      case "unrecognized_keys":
        return `${r.keys.length > 1 ? "Ukendte n\xF8gler" : "Ukendt n\xF8gle"}: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `Ugyldig n\xF8gle i ${r.origin}`;
      case "invalid_union":
        return "Ugyldigt input: matcher ingen af de tilladte typer";
      case "invalid_element":
        return `Ugyldig v\xE6rdi i ${r.origin}`;
      default:
        return "Ugyldigt input";
    }
  };
}, "error");
function Dc() {
  return {
    localeError: ub()
  };
}
s(Dc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/de.js
var cb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "Zeichen", verb: "zu haben" },
    file: { unit: "Bytes", verb: "zu haben" },
    array: { unit: "Elemente", verb: "zu haben" },
    set: { unit: "Elemente", verb: "zu haben" },
    map: { unit: "Elemente", verb: "zu haben" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "Eingabe",
    email: "E-Mail-Adresse",
    url: "URL",
    emoji: "Emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO-Datum und -Uhrzeit",
    date: "ISO-Datum",
    time: "ISO-Uhrzeit",
    duration: "ISO-Dauer",
    ipv4: "IPv4-Adresse",
    ipv6: "IPv6-Adresse",
    mac: "MAC-Adresse",
    cidrv4: "IPv4-Bereich",
    cidrv6: "IPv6-Bereich",
    base64: "Base64-codierter String",
    base64url: "Base64-URL-codierter String",
    json_string: "JSON-String",
    e164: "E.164-Nummer",
    credit_card: "Kreditkartennummer",
    jwt: "JWT",
    template_literal: "Eingabe"
  }, o = {
    nan: "NaN",
    number: "Zahl",
    array: "Array"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Ung\xFCltige Eingabe: erwartet instanceof ${r.expected}, erhalten ${u}` : `Ung\xFCltige Eingabe: erwartet ${i}, erhalten ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Ung\xFCltige Eingabe: erwartet ${$(r.values[0])}` : `Ung\xFCltige Option: erwartet eine von ${h(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Zu gro\xDF: erwartet, dass ${r.origin ?? "Wert"} ${i}${r.maximum.toString()} ${a.unit ?? "Elemente"} hat` : `Zu gro\xDF: erwartet, dass ${r.origin ?? "Wert"} ${i}${r.maximum.toString()} ist`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Zu klein: erwartet, dass ${r.origin} ${i}${r.minimum.toString()} ${a.unit} hat` : `Zu klein: erwartet, dass ${r.origin} ${i}${r.minimum.toString()} ist`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Ung\xFCltiger String: muss mit "${i.prefix}" beginnen` : i.format === "ends_with" ? `Ung\xFCltiger String: muss mit "${i.suffix}" enden` : i.format === "includes" ? `Ung\xFCltiger String: muss "${i.includes}" enthalten` : i.format === "regex" ? `Ung\xFCltiger String: muss dem Muster ${i.pattern} entsprechen` : `Ung\xFCltig: ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Ung\xFCltige Zahl: muss ein Vielfaches von ${r.divisor} sein`;
      case "unrecognized_keys":
        return `${r.keys.length > 1 ? "Unbekannte Schl\xFCssel" : "Unbekannter Schl\xFCssel"}: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `Ung\xFCltiger Schl\xFCssel in ${r.origin}`;
      case "invalid_union":
        return "Ung\xFCltige Eingabe";
      case "invalid_element":
        return `Ung\xFCltiger Wert in ${r.origin}`;
      default:
        return "Ung\xFCltige Eingabe";
    }
  };
}, "error");
function Nc() {
  return {
    localeError: cb()
  };
}
s(Nc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/el.js
var lb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u03C7\u03B1\u03C1\u03B1\u03BA\u03C4\u03AE\u03C1\u03B5\u03C2", verb: "\u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9" },
    file: { unit: "bytes", verb: "\u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9" },
    array: { unit: "\u03C3\u03C4\u03BF\u03B9\u03C7\u03B5\u03AF\u03B1", verb: "\u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9" },
    set: { unit: "\u03C3\u03C4\u03BF\u03B9\u03C7\u03B5\u03AF\u03B1", verb: "\u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9" },
    map: { unit: "\u03BA\u03B1\u03C4\u03B1\u03C7\u03C9\u03C1\u03AE\u03C3\u03B5\u03B9\u03C2", verb: "\u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2",
    email: "\u03B4\u03B9\u03B5\u03CD\u03B8\u03C5\u03BD\u03C3\u03B7 email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u03B7\u03BC\u03B5\u03C1\u03BF\u03BC\u03B7\u03BD\u03AF\u03B1 \u03BA\u03B1\u03B9 \u03CE\u03C1\u03B1",
    date: "ISO \u03B7\u03BC\u03B5\u03C1\u03BF\u03BC\u03B7\u03BD\u03AF\u03B1",
    time: "ISO \u03CE\u03C1\u03B1",
    duration: "ISO \u03B4\u03B9\u03AC\u03C1\u03BA\u03B5\u03B9\u03B1",
    ipv4: "\u03B4\u03B9\u03B5\u03CD\u03B8\u03C5\u03BD\u03C3\u03B7 IPv4",
    ipv6: "\u03B4\u03B9\u03B5\u03CD\u03B8\u03C5\u03BD\u03C3\u03B7 IPv6",
    mac: "\u03B4\u03B9\u03B5\u03CD\u03B8\u03C5\u03BD\u03C3\u03B7 MAC",
    cidrv4: "\u03B5\u03CD\u03C1\u03BF\u03C2 IPv4",
    cidrv6: "\u03B5\u03CD\u03C1\u03BF\u03C2 IPv6",
    base64: "\u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC \u03BA\u03C9\u03B4\u03B9\u03BA\u03BF\u03C0\u03BF\u03B9\u03B7\u03BC\u03AD\u03BD\u03B7 \u03C3\u03B5 base64",
    base64url: "\u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC \u03BA\u03C9\u03B4\u03B9\u03BA\u03BF\u03C0\u03BF\u03B9\u03B7\u03BC\u03AD\u03BD\u03B7 \u03C3\u03B5 base64url",
    json_string: "\u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC JSON",
    e164: "\u03B1\u03C1\u03B9\u03B8\u03BC\u03CC\u03C2 E.164",
    credit_card: "\u03B1\u03C1\u03B9\u03B8\u03BC\u03CC\u03C2 \u03C0\u03B9\u03C3\u03C4\u03C9\u03C4\u03B9\u03BA\u03AE\u03C2 \u03BA\u03AC\u03C1\u03C4\u03B1\u03C2",
    jwt: "JWT",
    template_literal: "\u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2"
  }, o = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return typeof r.expected == "string" && /^[A-Z]/.test(r.expected) ? `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD instanceof ${r.expected}, \u03BB\u03AE\u03C6\u03B8\u03B7\u03BA\u03B5 ${u}` : `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${i}, \u03BB\u03AE\u03C6\u03B8\u03B7\u03BA\u03B5 ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${$(r.values[0])}` : `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03C0\u03B9\u03BB\u03BF\u03B3\u03AE: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD \u03AD\u03BD\u03B1 \u03B1\u03C0\u03CC ${h(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `\u03A0\u03BF\u03BB\u03CD \u03BC\u03B5\u03B3\u03AC\u03BB\u03BF: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${r.origin ?? "\u03C4\u03B9\u03BC\u03AE"} \u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9 ${i}${r.maximum.toString()} ${a.unit ?? "\u03C3\u03C4\u03BF\u03B9\u03C7\u03B5\u03AF\u03B1"}` : `\u03A0\u03BF\u03BB\u03CD \u03BC\u03B5\u03B3\u03AC\u03BB\u03BF: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${r.origin ?? "\u03C4\u03B9\u03BC\u03AE"} \u03BD\u03B1 \u03B5\u03AF\u03BD\u03B1\u03B9 ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\u03A0\u03BF\u03BB\u03CD \u03BC\u03B9\u03BA\u03C1\u03CC: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${r.origin} \u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9 ${i}${r.minimum.toString()} ${a.unit}` : `\u03A0\u03BF\u03BB\u03CD \u03BC\u03B9\u03BA\u03C1\u03CC: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${r.origin} \u03BD\u03B1 \u03B5\u03AF\u03BD\u03B1\u03B9 ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC: \u03C0\u03C1\u03AD\u03C0\u03B5\u03B9 \u03BD\u03B1 \u03BE\u03B5\u03BA\u03B9\u03BD\u03AC \u03BC\u03B5 "${i.prefix}"` : i.format === "ends_with" ? `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC: \u03C0\u03C1\u03AD\u03C0\u03B5\u03B9 \u03BD\u03B1 \u03C4\u03B5\u03BB\u03B5\u03B9\u03CE\u03BD\u03B5\u03B9 \u03BC\u03B5 "${i.suffix}"` : i.format === "includes" ? `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC: \u03C0\u03C1\u03AD\u03C0\u03B5\u03B9 \u03BD\u03B1 \u03C0\u03B5\u03C1\u03B9\u03AD\u03C7\u03B5\u03B9 "${i.includes}"` : i.format === "regex" ? `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC: \u03C0\u03C1\u03AD\u03C0\u03B5\u03B9 \u03BD\u03B1 \u03C4\u03B1\u03B9\u03C1\u03B9\u03AC\u03B6\u03B5\u03B9 \u03BC\u03B5 \u03C4\u03BF \u03BC\u03BF\u03C4\u03AF\u03B2\u03BF ${i.pattern}` : `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03BF: ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03BF\u03C2 \u03B1\u03C1\u03B9\u03B8\u03BC\u03CC\u03C2: \u03C0\u03C1\u03AD\u03C0\u03B5\u03B9 \u03BD\u03B1 \u03B5\u03AF\u03BD\u03B1\u03B9 \u03C0\u03BF\u03BB\u03BB\u03B1\u03C0\u03BB\u03AC\u03C3\u03B9\u03BF \u03C4\u03BF\u03C5 ${r.divisor}`;
      case "unrecognized_keys":
        return `\u0386\u03B3\u03BD\u03C9\u03C3\u03C4${r.keys.length > 1 ? "\u03B1" : "\u03BF"} \u03BA\u03BB\u03B5\u03B9\u03B4${r.keys.length > 1 ? "\u03B9\u03AC" : "\u03AF"}: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03BF \u03BA\u03BB\u03B5\u03B9\u03B4\u03AF \u03C3\u03C4\u03BF ${r.origin}`;
      case "invalid_union":
        return "\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2";
      case "invalid_element":
        return `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03C4\u03B9\u03BC\u03AE \u03C3\u03C4\u03BF ${r.origin}`;
      default:
        return "\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2";
    }
  };
}, "error");
function Tc() {
  return {
    localeError: lb()
  };
}
s(Tc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/en.js
var db = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "characters", verb: "to have" },
    file: { unit: "bytes", verb: "to have" },
    array: { unit: "items", verb: "to have" },
    set: { unit: "items", verb: "to have" },
    map: { unit: "entries", verb: "to have" }
  };
  function t(i) {
    return e[i] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "input",
    email: "email address",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datetime",
    date: "ISO date",
    time: "ISO time",
    duration: "ISO duration",
    ipv4: "IPv4 address",
    ipv6: "IPv6 address",
    mac: "MAC address",
    cidrv4: "IPv4 range",
    cidrv6: "IPv6 range",
    base64: "base64-encoded string",
    base64url: "base64url-encoded string",
    json_string: "JSON string",
    e164: "E.164 number",
    credit_card: "credit card number",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    // Compatibility: "nan" -> "NaN" for display
    nan: "NaN"
    // All other type names omitted - they fall back to raw values via ?? operator
  };
  function r(i, a) {
    return i === "number" && typeof a == "number" && !Number.isFinite(a) ? String(a) : o[i] ?? i;
  }
  return s(r, "getTypeName"), (i) => {
    switch (i.code) {
      case "invalid_type": {
        let a = r(i.expected), u = b(i.input), c = r(u, i.input);
        return `Invalid input: expected ${a}, received ${c}`;
      }
      case "invalid_value":
        return i.values.length === 1 ? `Invalid input: expected ${$(i.values[0])}` : `Invalid option: expected one of ${h(i.values, "|")}`;
      case "too_big": {
        let a = i.exact ? "exactly " : i.inclusive ? "<=" : "<", u = t(i.origin);
        return u ? `Too big: expected ${i.origin ?? "value"} to have ${a}${i.maximum.toString()} ${u.unit ?? "elements"}` : `Too big: expected ${i.origin ?? "value"} to be ${a}${i.maximum.toString()}`;
      }
      case "too_small": {
        let a = i.exact ? "exactly " : i.inclusive ? ">=" : ">", u = t(i.origin);
        return u ? `Too small: expected ${i.origin} to have ${a}${i.minimum.toString()} ${u.unit}` : `Too small: expected ${i.origin} to be ${a}${i.minimum.toString()}`;
      }
      case "invalid_format": {
        let a = i;
        return a.format === "starts_with" ? `Invalid string: must start with "${a.prefix}"` : a.format === "ends_with" ? `Invalid string: must end with "${a.suffix}"` : a.format === "includes" ? `Invalid string: must include "${a.includes}"` : a.format === "regex" ? `Invalid string: must match pattern ${a.pattern}` : `Invalid ${n[a.format] ?? i.format}`;
      }
      case "not_multiple_of":
        return `Invalid number: must be a multiple of ${i.divisor}`;
      case "unrecognized_keys":
        return `Unrecognized key${i.keys.length > 1 ? "s" : ""}: ${h(i.keys, ", ")}`;
      case "invalid_key":
        return `Invalid key in ${i.origin}`;
      case "invalid_union":
        return i.options && Array.isArray(i.options) && i.options.length > 0 ? `Invalid discriminator value. Expected ${i.options.map((u) => `'${u}'`).join(" | ")}` : i.inclusive === !1 ? "Invalid input: more than one option matched" : "Invalid input";
      case "invalid_element":
        return `Invalid value in ${i.origin}`;
      default:
        return "Invalid input";
    }
  };
}, "error");
function cn() {
  return {
    localeError: db()
  };
}
s(cn, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/eo.js
var fb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "karaktrojn", verb: "havi" },
    file: { unit: "bajtojn", verb: "havi" },
    array: { unit: "elementojn", verb: "havi" },
    set: { unit: "elementojn", verb: "havi" },
    map: { unit: "elementojn", verb: "havi" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "enigo",
    email: "retadreso",
    url: "URL",
    emoji: "emo\u011Dio",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO-datotempo",
    date: "ISO-dato",
    time: "ISO-tempo",
    duration: "ISO-da\u016Dro",
    ipv4: "IPv4-adreso",
    ipv6: "IPv6-adreso",
    mac: "MAC-adreso",
    cidrv4: "IPv4-rango",
    cidrv6: "IPv6-rango",
    base64: "64-ume kodita karaktraro",
    base64url: "URL-64-ume kodita karaktraro",
    json_string: "JSON-karaktraro",
    e164: "E.164-nombro",
    credit_card: "kreditkarta numero",
    jwt: "JWT",
    template_literal: "enigo"
  }, o = {
    nan: "NaN",
    number: "nombro",
    array: "tabelo",
    null: "senvalora"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Nevalida enigo: atendi\u011Dis instanceof ${r.expected}, ricevi\u011Dis ${u}` : `Nevalida enigo: atendi\u011Dis ${i}, ricevi\u011Dis ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Nevalida enigo: atendi\u011Dis ${$(r.values[0])}` : `Nevalida opcio: atendi\u011Dis unu el ${h(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Tro granda: atendi\u011Dis ke ${r.origin ?? "valoro"} havu ${i}${r.maximum.toString()} ${a.unit ?? "elementojn"}` : `Tro granda: atendi\u011Dis ke ${r.origin ?? "valoro"} havu ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Tro malgranda: atendi\u011Dis ke ${r.origin} havu ${i}${r.minimum.toString()} ${a.unit}` : `Tro malgranda: atendi\u011Dis ke ${r.origin} estu ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Nevalida karaktraro: devas komenci\u011Di per "${i.prefix}"` : i.format === "ends_with" ? `Nevalida karaktraro: devas fini\u011Di per "${i.suffix}"` : i.format === "includes" ? `Nevalida karaktraro: devas inkluzivi "${i.includes}"` : i.format === "regex" ? `Nevalida karaktraro: devas kongrui kun la modelo ${i.pattern}` : `Nevalida ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Nevalida nombro: devas esti oblo de ${r.divisor}`;
      case "unrecognized_keys":
        return `Nekonata${r.keys.length > 1 ? "j" : ""} \u015Dlosilo${r.keys.length > 1 ? "j" : ""}: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `Nevalida \u015Dlosilo en ${r.origin}`;
      case "invalid_union":
        return "Nevalida enigo";
      case "invalid_element":
        return `Nevalida valoro en ${r.origin}`;
      default:
        return "Nevalida enigo";
    }
  };
}, "error");
function Ac() {
  return {
    localeError: fb()
  };
}
s(Ac, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/es.js
var pb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "caracteres", verb: "tener" },
    file: { unit: "bytes", verb: "tener" },
    array: { unit: "elementos", verb: "tener" },
    set: { unit: "elementos", verb: "tener" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "entrada",
    email: "direcci\xF3n de correo electr\xF3nico",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "fecha y hora ISO",
    date: "fecha ISO",
    time: "hora ISO",
    duration: "duraci\xF3n ISO",
    ipv4: "direcci\xF3n IPv4",
    ipv6: "direcci\xF3n IPv6",
    mac: "direcci\xF3n MAC",
    cidrv4: "rango IPv4",
    cidrv6: "rango IPv6",
    base64: "cadena codificada en base64",
    base64url: "URL codificada en base64",
    json_string: "cadena JSON",
    e164: "n\xFAmero E.164",
    credit_card: "n\xFAmero de tarjeta de cr\xE9dito",
    jwt: "JWT",
    template_literal: "entrada"
  }, o = {
    nan: "NaN",
    string: "texto",
    number: "n\xFAmero",
    boolean: "booleano",
    array: "arreglo",
    object: "objeto",
    set: "conjunto",
    file: "archivo",
    date: "fecha",
    bigint: "n\xFAmero grande",
    symbol: "s\xEDmbolo",
    undefined: "indefinido",
    null: "nulo",
    function: "funci\xF3n",
    map: "mapa",
    record: "registro",
    tuple: "tupla",
    enum: "enumeraci\xF3n",
    union: "uni\xF3n",
    literal: "literal",
    promise: "promesa",
    void: "vac\xEDo",
    never: "nunca",
    unknown: "desconocido",
    any: "cualquiera"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Entrada inv\xE1lida: se esperaba instanceof ${r.expected}, recibido ${u}` : `Entrada inv\xE1lida: se esperaba ${i}, recibido ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Entrada inv\xE1lida: se esperaba ${$(r.values[0])}` : `Opci\xF3n inv\xE1lida: se esperaba una de ${h(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin), u = o[r.origin] ?? r.origin;
        return a ? `Demasiado grande: se esperaba que ${u ?? "valor"} tuviera ${i}${r.maximum.toString()} ${a.unit ?? "elementos"}` : `Demasiado grande: se esperaba que ${u ?? "valor"} fuera ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin), u = o[r.origin] ?? r.origin;
        return a ? `Demasiado peque\xF1o: se esperaba que ${u} tuviera ${i}${r.minimum.toString()} ${a.unit}` : `Demasiado peque\xF1o: se esperaba que ${u} fuera ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Cadena inv\xE1lida: debe comenzar con "${i.prefix}"` : i.format === "ends_with" ? `Cadena inv\xE1lida: debe terminar en "${i.suffix}"` : i.format === "includes" ? `Cadena inv\xE1lida: debe incluir "${i.includes}"` : i.format === "regex" ? `Cadena inv\xE1lida: debe coincidir con el patr\xF3n ${i.pattern}` : `Inv\xE1lido ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `N\xFAmero inv\xE1lido: debe ser m\xFAltiplo de ${r.divisor}`;
      case "unrecognized_keys":
        return `Llave${r.keys.length > 1 ? "s" : ""} desconocida${r.keys.length > 1 ? "s" : ""}: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `Llave inv\xE1lida en ${o[r.origin] ?? r.origin}`;
      case "invalid_union":
        return "Entrada inv\xE1lida";
      case "invalid_element":
        return `Valor inv\xE1lido en ${o[r.origin] ?? r.origin}`;
      default:
        return "Entrada inv\xE1lida";
    }
  };
}, "error");
function Uc() {
  return {
    localeError: pb()
  };
}
s(Uc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/fa.js
var mb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u06A9\u0627\u0631\u0627\u06A9\u062A\u0631", verb: "\u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F" },
    file: { unit: "\u0628\u0627\u06CC\u062A", verb: "\u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F" },
    array: { unit: "\u0622\u06CC\u062A\u0645", verb: "\u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F" },
    set: { unit: "\u0622\u06CC\u062A\u0645", verb: "\u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F" },
    map: { unit: "\u0622\u06CC\u062A\u0645", verb: "\u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u0648\u0631\u0648\u062F\u06CC",
    email: "\u0622\u062F\u0631\u0633 \u0627\u06CC\u0645\u06CC\u0644",
    url: "URL",
    emoji: "\u0627\u06CC\u0645\u0648\u062C\u06CC",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u062A\u0627\u0631\u06CC\u062E \u0648 \u0632\u0645\u0627\u0646 \u0627\u06CC\u0632\u0648",
    date: "\u062A\u0627\u0631\u06CC\u062E \u0627\u06CC\u0632\u0648",
    time: "\u0632\u0645\u0627\u0646 \u0627\u06CC\u0632\u0648",
    duration: "\u0645\u062F\u062A \u0632\u0645\u0627\u0646 \u0627\u06CC\u0632\u0648",
    ipv4: "IPv4 \u0622\u062F\u0631\u0633",
    ipv6: "IPv6 \u0622\u062F\u0631\u0633",
    mac: "MAC \u0622\u062F\u0631\u0633",
    cidrv4: "IPv4 \u062F\u0627\u0645\u0646\u0647",
    cidrv6: "IPv6 \u062F\u0627\u0645\u0646\u0647",
    base64: "base64-encoded \u0631\u0634\u062A\u0647",
    base64url: "base64url-encoded \u0631\u0634\u062A\u0647",
    json_string: "JSON \u0631\u0634\u062A\u0647",
    e164: "E.164 \u0639\u062F\u062F",
    credit_card: "\u0634\u0645\u0627\u0631\u0647 \u06A9\u0627\u0631\u062A \u0627\u0639\u062A\u0628\u0627\u0631\u06CC",
    jwt: "JWT",
    template_literal: "\u0648\u0631\u0648\u062F\u06CC"
  }, o = {
    nan: "NaN",
    number: "\u0639\u062F\u062F",
    array: "\u0622\u0631\u0627\u06CC\u0647"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0645\u06CC\u200C\u0628\u0627\u06CC\u0633\u062A instanceof ${r.expected} \u0645\u06CC\u200C\u0628\u0648\u062F\u060C ${u} \u062F\u0631\u06CC\u0627\u0641\u062A \u0634\u062F` : `\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0645\u06CC\u200C\u0628\u0627\u06CC\u0633\u062A ${i} \u0645\u06CC\u200C\u0628\u0648\u062F\u060C ${u} \u062F\u0631\u06CC\u0627\u0641\u062A \u0634\u062F`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0645\u06CC\u200C\u0628\u0627\u06CC\u0633\u062A ${$(r.values[0])} \u0645\u06CC\u200C\u0628\u0648\u062F` : `\u06AF\u0632\u06CC\u0646\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0645\u06CC\u200C\u0628\u0627\u06CC\u0633\u062A \u06CC\u06A9\u06CC \u0627\u0632 ${h(r.values, "|")} \u0645\u06CC\u200C\u0628\u0648\u062F`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `\u062E\u06CC\u0644\u06CC \u0628\u0632\u0631\u06AF: ${r.origin ?? "\u0645\u0642\u062F\u0627\u0631"} \u0628\u0627\u06CC\u062F ${i}${r.maximum.toString()} ${a.unit ?? "\u0639\u0646\u0635\u0631"} \u0628\u0627\u0634\u062F` : `\u062E\u06CC\u0644\u06CC \u0628\u0632\u0631\u06AF: ${r.origin ?? "\u0645\u0642\u062F\u0627\u0631"} \u0628\u0627\u06CC\u062F ${i}${r.maximum.toString()} \u0628\u0627\u0634\u062F`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\u062E\u06CC\u0644\u06CC \u06A9\u0648\u0686\u06A9: ${r.origin} \u0628\u0627\u06CC\u062F ${i}${r.minimum.toString()} ${a.unit} \u0628\u0627\u0634\u062F` : `\u062E\u06CC\u0644\u06CC \u06A9\u0648\u0686\u06A9: ${r.origin} \u0628\u0627\u06CC\u062F ${i}${r.minimum.toString()} \u0628\u0627\u0634\u062F`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u0631\u0634\u062A\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0628\u0627 "${i.prefix}" \u0634\u0631\u0648\u0639 \u0634\u0648\u062F` : i.format === "ends_with" ? `\u0631\u0634\u062A\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0628\u0627 "${i.suffix}" \u062A\u0645\u0627\u0645 \u0634\u0648\u062F` : i.format === "includes" ? `\u0631\u0634\u062A\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0634\u0627\u0645\u0644 "${i.includes}" \u0628\u0627\u0634\u062F` : i.format === "regex" ? `\u0631\u0634\u062A\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0628\u0627 \u0627\u0644\u06AF\u0648\u06CC ${i.pattern} \u0645\u0637\u0627\u0628\u0642\u062A \u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F` : `${n[i.format] ?? r.format} \u0646\u0627\u0645\u0639\u062A\u0628\u0631`;
      }
      case "not_multiple_of":
        return `\u0639\u062F\u062F \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0645\u0636\u0631\u0628 ${r.divisor} \u0628\u0627\u0634\u062F`;
      case "unrecognized_keys":
        return `\u06A9\u0644\u06CC\u062F${r.keys.length > 1 ? "\u0647\u0627\u06CC" : ""} \u0646\u0627\u0634\u0646\u0627\u0633: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `\u06A9\u0644\u06CC\u062F \u0646\u0627\u0634\u0646\u0627\u0633 \u062F\u0631 ${r.origin}`;
      case "invalid_union":
        return "\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631";
      case "invalid_element":
        return `\u0645\u0642\u062F\u0627\u0631 \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u062F\u0631 ${r.origin}`;
      default:
        return "\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631";
    }
  };
}, "error");
function Ec() {
  return {
    localeError: mb()
  };
}
s(Ec, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/fi.js
var gb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "merkki\xE4", subject: "merkkijonon" },
    file: { unit: "tavua", subject: "tiedoston" },
    array: { unit: "alkiota", subject: "listan" },
    set: { unit: "alkiota", subject: "joukon" },
    map: { unit: "alkiota", subject: "kuvauksen" },
    number: { unit: "", subject: "luvun" },
    bigint: { unit: "", subject: "suuren kokonaisluvun" },
    int: { unit: "", subject: "kokonaisluvun" },
    date: { unit: "", subject: "p\xE4iv\xE4m\xE4\xE4r\xE4n" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "s\xE4\xE4nn\xF6llinen lauseke",
    email: "s\xE4hk\xF6postiosoite",
    url: "URL-osoite",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO-aikaleima",
    date: "ISO-p\xE4iv\xE4m\xE4\xE4r\xE4",
    time: "ISO-aika",
    duration: "ISO-kesto",
    ipv4: "IPv4-osoite",
    ipv6: "IPv6-osoite",
    mac: "MAC-osoite",
    cidrv4: "IPv4-alue",
    cidrv6: "IPv6-alue",
    base64: "base64-koodattu merkkijono",
    base64url: "base64url-koodattu merkkijono",
    json_string: "JSON-merkkijono",
    e164: "E.164-luku",
    credit_card: "luottokortin numero",
    jwt: "JWT",
    template_literal: "templaattimerkkijono"
  }, o = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Virheellinen tyyppi: odotettiin instanceof ${r.expected}, oli ${u}` : `Virheellinen tyyppi: odotettiin ${i}, oli ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Virheellinen sy\xF6te: t\xE4ytyy olla ${$(r.values[0])}` : `Virheellinen valinta: t\xE4ytyy olla yksi seuraavista: ${h(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Liian suuri: ${a.subject} t\xE4ytyy olla ${i}${r.maximum.toString()} ${a.unit}`.trim() : `Liian suuri: arvon t\xE4ytyy olla ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Liian pieni: ${a.subject} t\xE4ytyy olla ${i}${r.minimum.toString()} ${a.unit}`.trim() : `Liian pieni: arvon t\xE4ytyy olla ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Virheellinen sy\xF6te: t\xE4ytyy alkaa "${i.prefix}"` : i.format === "ends_with" ? `Virheellinen sy\xF6te: t\xE4ytyy loppua "${i.suffix}"` : i.format === "includes" ? `Virheellinen sy\xF6te: t\xE4ytyy sis\xE4lt\xE4\xE4 "${i.includes}"` : i.format === "regex" ? `Virheellinen sy\xF6te: t\xE4ytyy vastata s\xE4\xE4nn\xF6llist\xE4 lauseketta ${i.pattern}` : `Virheellinen ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Virheellinen luku: t\xE4ytyy olla luvun ${r.divisor} monikerta`;
      case "unrecognized_keys":
        return `${r.keys.length > 1 ? "Tuntemattomat avaimet" : "Tuntematon avain"}: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return "Virheellinen avain tietueessa";
      case "invalid_union":
        return "Virheellinen unioni";
      case "invalid_element":
        return "Virheellinen arvo joukossa";
      default:
        return "Virheellinen sy\xF6te";
    }
  };
}, "error");
function Cc() {
  return {
    localeError: gb()
  };
}
s(Cc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/fr.js
var hb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "caract\xE8res", verb: "avoir" },
    file: { unit: "octets", verb: "avoir" },
    array: { unit: "\xE9l\xE9ments", verb: "avoir" },
    set: { unit: "\xE9l\xE9ments", verb: "avoir" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "expression r\xE9guli\xE8re",
    email: "adresse e-mail",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "date et heure ISO",
    date: "date ISO",
    time: "heure ISO",
    duration: "dur\xE9e ISO",
    ipv4: "adresse IPv4",
    ipv6: "adresse IPv6",
    mac: "adresse MAC",
    cidrv4: "plage IPv4",
    cidrv6: "plage IPv6",
    base64: "cha\xEEne de caract\xE8res encod\xE9e en base64",
    base64url: "cha\xEEne de caract\xE8res encod\xE9e en base64url",
    json_string: "cha\xEEne de caract\xE8res JSON",
    e164: "num\xE9ro au format E.164",
    credit_card: "num\xE9ro de carte de cr\xE9dit",
    jwt: "JWT",
    template_literal: "entr\xE9e"
  }, o = {
    string: "cha\xEEne de caract\xE8res",
    number: "nombre",
    int: "entier",
    boolean: "bool\xE9en",
    bigint: "grand entier",
    symbol: "symbole",
    undefined: "ind\xE9fini",
    null: "null",
    never: "jamais",
    void: "vide",
    date: "date",
    array: "tableau",
    object: "objet",
    tuple: "tuple",
    record: "record",
    map: "map",
    set: "ensemble",
    file: "fichier",
    nonoptional: "non optionnel",
    nan: "NaN",
    function: "fonction"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Entr\xE9e invalide : instance de ${r.expected} attendu, ${u} re\xE7u` : `Entr\xE9e invalide : ${i} attendu, ${u} re\xE7u`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Entr\xE9e invalide : ${$(r.values[0])} attendu` : `Option invalide : une valeur parmi ${h(r.values, "|")} attendue`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Trop grand : ${o[r.origin] ?? "valeur"} doit ${a.verb} ${i}${r.maximum.toString()} ${a.unit ?? "\xE9l\xE9ment(s)"}` : `Trop grand : ${o[r.origin] ?? "valeur"} doit \xEAtre ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Trop petit : ${o[r.origin] ?? "valeur"} doit ${a.verb} ${i}${r.minimum.toString()} ${a.unit}` : `Trop petit : ${o[r.origin] ?? "valeur"} doit \xEAtre ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Cha\xEEne de caract\xE8res invalide : doit commencer par "${i.prefix}"` : i.format === "ends_with" ? `Cha\xEEne de caract\xE8res invalide : doit se terminer par "${i.suffix}"` : i.format === "includes" ? `Cha\xEEne de caract\xE8res invalide : doit inclure "${i.includes}"` : i.format === "regex" ? `Cha\xEEne de caract\xE8res invalide : doit correspondre au motif ${i.pattern}` : `${n[i.format] ?? r.format} invalide`;
      }
      case "not_multiple_of":
        return `Nombre invalide : doit \xEAtre un multiple de ${r.divisor}`;
      case "unrecognized_keys":
        return `Cl\xE9${r.keys.length > 1 ? "s" : ""} non reconnue${r.keys.length > 1 ? "s" : ""} : ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `Cl\xE9 invalide dans ${r.origin}`;
      case "invalid_union":
        return "Entr\xE9e invalide";
      case "invalid_element":
        return `Valeur invalide dans ${r.origin}`;
      default:
        return "Entr\xE9e invalide";
    }
  };
}, "error");
function Zc() {
  return {
    localeError: hb()
  };
}
s(Zc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/fr-CA.js
var vb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "caract\xE8res", verb: "avoir" },
    file: { unit: "octets", verb: "avoir" },
    array: { unit: "\xE9l\xE9ments", verb: "avoir" },
    set: { unit: "\xE9l\xE9ments", verb: "avoir" },
    map: { unit: "\xE9l\xE9ments", verb: "avoir" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "entr\xE9e",
    email: "adresse courriel",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "date-heure ISO",
    date: "date ISO",
    time: "heure ISO",
    duration: "dur\xE9e ISO",
    ipv4: "adresse IPv4",
    ipv6: "adresse IPv6",
    mac: "adresse MAC",
    cidrv4: "plage IPv4",
    cidrv6: "plage IPv6",
    base64: "cha\xEEne encod\xE9e en base64",
    base64url: "cha\xEEne encod\xE9e en base64url",
    json_string: "cha\xEEne JSON",
    e164: "num\xE9ro E.164",
    credit_card: "num\xE9ro de carte de cr\xE9dit",
    jwt: "JWT",
    template_literal: "entr\xE9e"
  }, o = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Entr\xE9e invalide : attendu instanceof ${r.expected}, re\xE7u ${u}` : `Entr\xE9e invalide : attendu ${i}, re\xE7u ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Entr\xE9e invalide : attendu ${$(r.values[0])}` : `Option invalide : attendu l'une des valeurs suivantes ${h(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "\u2264" : "<", a = t(r.origin);
        return a ? `Trop grand : attendu que ${r.origin ?? "la valeur"} ait ${i}${r.maximum.toString()} ${a.unit}` : `Trop grand : attendu que ${r.origin ?? "la valeur"} soit ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? "\u2265" : ">", a = t(r.origin);
        return a ? `Trop petit : attendu que ${r.origin} ait ${i}${r.minimum.toString()} ${a.unit}` : `Trop petit : attendu que ${r.origin} soit ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Cha\xEEne invalide : doit commencer par "${i.prefix}"` : i.format === "ends_with" ? `Cha\xEEne invalide : doit se terminer par "${i.suffix}"` : i.format === "includes" ? `Cha\xEEne invalide : doit inclure "${i.includes}"` : i.format === "regex" ? `Cha\xEEne invalide : doit correspondre au motif ${i.pattern}` : `${n[i.format] ?? r.format} invalide`;
      }
      case "not_multiple_of":
        return `Nombre invalide : doit \xEAtre un multiple de ${r.divisor}`;
      case "unrecognized_keys":
        return `Cl\xE9${r.keys.length > 1 ? "s" : ""} non reconnue${r.keys.length > 1 ? "s" : ""} : ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `Cl\xE9 invalide dans ${r.origin}`;
      case "invalid_union":
        return "Entr\xE9e invalide";
      case "invalid_element":
        return `Valeur invalide dans ${r.origin}`;
      default:
        return "Entr\xE9e invalide";
    }
  };
}, "error");
function Rc() {
  return {
    localeError: vb()
  };
}
s(Rc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/gu.js
var yb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0A85\u0A95\u0ACD\u0AB7\u0AB0", verb: "\u0AB9\u0ACB\u0AB5\u0ABE \u0A9C\u0ACB\u0A88\u0A8F" },
    file: { unit: "\u0AAC\u0ABE\u0AAF\u0A9F", verb: "\u0AB9\u0ACB\u0AB5\u0ABE \u0A9C\u0ACB\u0A88\u0A8F" },
    array: { unit: "\u0A86\u0A87\u0A9F\u0AAE", verb: "\u0AB9\u0ACB\u0AB5\u0ABE \u0A9C\u0ACB\u0A88\u0A8F" },
    set: { unit: "\u0A86\u0A87\u0A9F\u0AAE", verb: "\u0AB9\u0ACB\u0AB5\u0ABE \u0A9C\u0ACB\u0A88\u0A8F" },
    map: { unit: "\u0A8F\u0AA8\u0ACD\u0A9F\u0ACD\u0AB0\u0AC0", verb: "\u0AB9\u0ACB\u0AB5\u0ABE \u0A9C\u0ACB\u0A88\u0A8F" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u0A87\u0AA8\u0AAA\u0AC1\u0A9F",
    email: "\u0A88\u0AAE\u0AC7\u0A87\u0AB2 \u0A8F\u0AA1\u0ACD\u0AB0\u0AC7\u0AB8",
    url: "URL",
    emoji: "\u0A87\u0AAE\u0ACB\u0A9C\u0AC0",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0AA4\u0ABE\u0AB0\u0AC0\u0A96 \u0A85\u0AA8\u0AC7 \u0AB8\u0AAE\u0AAF",
    date: "ISO \u0AA4\u0ABE\u0AB0\u0AC0\u0A96",
    time: "ISO \u0AB8\u0AAE\u0AAF",
    duration: "ISO \u0A85\u0AB5\u0AA7\u0ABF",
    ipv4: "IPv4 \u0A8F\u0AA1\u0ACD\u0AB0\u0AC7\u0AB8",
    ipv6: "IPv6 \u0A8F\u0AA1\u0ACD\u0AB0\u0AC7\u0AB8",
    mac: "MAC \u0A8F\u0AA1\u0ACD\u0AB0\u0AC7\u0AB8",
    cidrv4: "IPv4 \u0AB6\u0ACD\u0AB0\u0AC7\u0AA3\u0AC0",
    cidrv6: "IPv6 \u0AB6\u0ACD\u0AB0\u0AC7\u0AA3\u0AC0",
    base64: "base64-\u0A8F\u0AA8\u0ACD\u0A95\u0ACB\u0AA1\u0AC7\u0AA1 \u0AB8\u0ACD\u0A9F\u0ACD\u0AB0\u0ABF\u0A82\u0A97",
    base64url: "base64url-\u0A8F\u0AA8\u0ACD\u0A95\u0ACB\u0AA1\u0AC7\u0AA1 \u0AB8\u0ACD\u0A9F\u0ACD\u0AB0\u0ABF\u0A82\u0A97",
    json_string: "JSON \u0AB8\u0ACD\u0A9F\u0ACD\u0AB0\u0ABF\u0A82\u0A97",
    e164: "E.164 \u0AA8\u0A82\u0AAC\u0AB0",
    credit_card: "\u0A95\u0ACD\u0AB0\u0AC7\u0AA1\u0ABF\u0A9F \u0A95\u0ABE\u0AB0\u0ACD\u0AA1 \u0AA8\u0A82\u0AAC\u0AB0",
    jwt: "JWT",
    template_literal: "\u0A87\u0AA8\u0AAA\u0AC1\u0A9F"
  }, o = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0A87\u0AA8\u0AAA\u0AC1\u0A9F: \u0A85\u0AAA\u0AC7\u0A95\u0ACD\u0AB7\u0ABF\u0AA4 ${i}, \u0AAA\u0ACD\u0AB0\u0ABE\u0AAA\u0ACD\u0AA4 ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0A87\u0AA8\u0AAA\u0AC1\u0A9F: \u0A85\u0AAA\u0AC7\u0A95\u0ACD\u0AB7\u0ABF\u0AA4 ${$(r.values[0])}` : `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AB5\u0ABF\u0A95\u0AB2\u0ACD\u0AAA: ${h(r.values, " | ")} \u0AAE\u0ABE\u0AA7\u0ACD\u0AAF\u0AAE\u0AA5\u0AC0 \u0A8F\u0A95 \u0A85\u0AAA\u0AC7\u0A95\u0ACD\u0AB7\u0ABF\u0AA4`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `\u0A96\u0AC2\u0AAC \u0AAE\u0ACB\u0A9F\u0AC1\u0A82: ${r.origin ?? "\u0AAE\u0AC2\u0AB2\u0ACD\u0AAF"} ${i}${r.maximum.toString()} ${a.unit ?? "\u0A8F\u0AB2\u0ABF\u0AAE\u0AC7\u0AA8\u0ACD\u0A9F"} \u0AB9\u0ACB\u0AB5\u0ABE \u0A9C\u0ACB\u0A88\u0A8F` : `\u0A96\u0AC2\u0AAC \u0AAE\u0ACB\u0A9F\u0AC1\u0A82: ${r.origin ?? "\u0AAE\u0AC2\u0AB2\u0ACD\u0AAF"} ${i}${r.maximum.toString()} \u0AB9\u0ACB\u0AB5\u0AC1\u0A82 \u0A9C\u0ACB\u0A88\u0A8F`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\u0A96\u0AC2\u0AAC \u0AA8\u0ABE\u0AA8\u0AC1\u0A82: ${r.origin} ${i}${r.minimum.toString()} ${a.unit} \u0AB9\u0ACB\u0AB5\u0ABE \u0A9C\u0ACB\u0A88\u0A8F` : `\u0A96\u0AC2\u0AAC \u0AA8\u0ABE\u0AA8\u0AC1\u0A82: ${r.origin} ${i}${r.minimum.toString()} \u0AB9\u0ACB\u0AB5\u0AC1\u0A82 \u0A9C\u0ACB\u0A88\u0A8F`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AB8\u0ACD\u0A9F\u0ACD\u0AB0\u0ABF\u0A82\u0A97: "${i.prefix}" \u0AA5\u0AC0 \u0AB6\u0AB0\u0AC2 \u0AA5\u0AB5\u0AC1\u0A82 \u0A9C\u0ACB\u0A88\u0A8F` : i.format === "ends_with" ? `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AB8\u0ACD\u0A9F\u0ACD\u0AB0\u0ABF\u0A82\u0A97: "${i.suffix}" \u0AAA\u0AB0 \u0AB8\u0AAE\u0ABE\u0AAA\u0ACD\u0AA4 \u0AA5\u0AB5\u0AC1\u0A82 \u0A9C\u0ACB\u0A88\u0A8F` : i.format === "includes" ? `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AB8\u0ACD\u0A9F\u0ACD\u0AB0\u0ABF\u0A82\u0A97: "${i.includes}" \u0AB6\u0ABE\u0AAE\u0AC7\u0AB2 \u0AB9\u0ACB\u0AB5\u0AC1\u0A82 \u0A9C\u0ACB\u0A88\u0A8F` : i.format === "regex" ? `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AB8\u0ACD\u0A9F\u0ACD\u0AB0\u0ABF\u0A82\u0A97: \u0AAA\u0AC7\u0A9F\u0AB0\u0ACD\u0AA8 ${i.pattern} \u0AB8\u0ABE\u0AA5\u0AC7 \u0AAE\u0AC7\u0AB3 \u0A96\u0ABE\u0AB5\u0AC1\u0A82 \u0A9C\u0ACB\u0A88\u0A8F` : `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AA8\u0A82\u0AAC\u0AB0: ${r.divisor} \u0AA8\u0ACB \u0A97\u0AC1\u0AA3\u0ABE\u0A82\u0A95 \u0AB9\u0ACB\u0AB5\u0ACB \u0A9C\u0ACB\u0A88\u0A8F`;
      case "unrecognized_keys":
        return `\u0A93\u0AB3\u0A96\u0AC0 \u0AB6\u0A95\u0ABE\u0AA4\u0ABE \u0AA8\u0AB9\u0AC0\u0A82 \u0AA4\u0AC7 \u0A95\u0AC0${r.keys.length > 1 ? "\u0A93" : ""}: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `${r.origin} \u0AAE\u0ABE\u0A82 \u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0A95\u0AC0`;
      case "invalid_union":
        return r.options && Array.isArray(r.options) && r.options.length > 0 ? `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AA1\u0ABF\u0AB8\u0ACD\u0A95\u0ACD\u0AB0\u0ABF\u0AAE\u0ABF\u0AA8\u0AC7\u0A9F\u0AB0 \u0AAE\u0AC2\u0AB2\u0ACD\u0AAF. \u0A85\u0AAA\u0AC7\u0A95\u0ACD\u0AB7\u0ABF\u0AA4 ${r.options.map((a) => `'${a}'`).join(" | ")}` : "\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0A87\u0AA8\u0AAA\u0AC1\u0A9F";
      case "invalid_element":
        return `${r.origin} \u0AAE\u0ABE\u0A82 \u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AAE\u0AC2\u0AB2\u0ACD\u0AAF`;
      default:
        return "\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0A87\u0AA8\u0AAA\u0AC1\u0A9F";
    }
  };
}, "error");
function Fc() {
  return {
    localeError: yb()
  };
}
s(Fc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/he.js
var $b = /* @__PURE__ */ s(() => {
  let e = {
    string: { label: "\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA", gender: "f" },
    number: { label: "\u05DE\u05E1\u05E4\u05E8", gender: "m" },
    boolean: { label: "\u05E2\u05E8\u05DA \u05D1\u05D5\u05DC\u05D9\u05D0\u05E0\u05D9", gender: "m" },
    bigint: { label: "BigInt", gender: "m" },
    date: { label: "\u05EA\u05D0\u05E8\u05D9\u05DA", gender: "m" },
    array: { label: "\u05DE\u05E2\u05E8\u05DA", gender: "m" },
    object: { label: "\u05D0\u05D5\u05D1\u05D9\u05D9\u05E7\u05D8", gender: "m" },
    null: { label: "\u05E2\u05E8\u05DA \u05E8\u05D9\u05E7 (null)", gender: "m" },
    undefined: { label: "\u05E2\u05E8\u05DA \u05DC\u05D0 \u05DE\u05D5\u05D2\u05D3\u05E8 (undefined)", gender: "m" },
    symbol: { label: "\u05E1\u05D9\u05DE\u05D1\u05D5\u05DC (Symbol)", gender: "m" },
    function: { label: "\u05E4\u05D5\u05E0\u05E7\u05E6\u05D9\u05D4", gender: "f" },
    map: { label: "\u05DE\u05E4\u05D4 (Map)", gender: "f" },
    set: { label: "\u05E7\u05D1\u05D5\u05E6\u05D4 (Set)", gender: "f" },
    file: { label: "\u05E7\u05D5\u05D1\u05E5", gender: "m" },
    promise: { label: "Promise", gender: "m" },
    NaN: { label: "NaN", gender: "m" },
    unknown: { label: "\u05E2\u05E8\u05DA \u05DC\u05D0 \u05D9\u05D3\u05D5\u05E2", gender: "m" },
    value: { label: "\u05E2\u05E8\u05DA", gender: "m" }
  }, t = {
    string: { unit: "\u05EA\u05D5\u05D5\u05D9\u05DD", shortLabel: "\u05E7\u05E6\u05E8", longLabel: "\u05D0\u05E8\u05D5\u05DA" },
    file: { unit: "\u05D1\u05D9\u05D9\u05D8\u05D9\u05DD", shortLabel: "\u05E7\u05D8\u05DF", longLabel: "\u05D2\u05D3\u05D5\u05DC" },
    array: { unit: "\u05E4\u05E8\u05D9\u05D8\u05D9\u05DD", shortLabel: "\u05E7\u05D8\u05DF", longLabel: "\u05D2\u05D3\u05D5\u05DC" },
    set: { unit: "\u05E4\u05E8\u05D9\u05D8\u05D9\u05DD", shortLabel: "\u05E7\u05D8\u05DF", longLabel: "\u05D2\u05D3\u05D5\u05DC" },
    number: { unit: "", shortLabel: "\u05E7\u05D8\u05DF", longLabel: "\u05D2\u05D3\u05D5\u05DC" }
    // no unit
  }, n = /* @__PURE__ */ s((l) => l ? e[l] : void 0, "typeEntry"), o = /* @__PURE__ */ s((l) => {
    let d = n(l);
    return d ? d.label : l ?? e.unknown.label;
  }, "typeLabel"), r = /* @__PURE__ */ s((l) => `\u05D4${o(l)}`, "withDefinite"), i = /* @__PURE__ */ s((l) => (n(l)?.gender ?? "m") === "f" ? "\u05E6\u05E8\u05D9\u05DB\u05D4 \u05DC\u05D4\u05D9\u05D5\u05EA" : "\u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA", "verbFor"), a = /* @__PURE__ */ s((l) => l ? t[l] ?? null : null, "getSizing"), u = {
    regex: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    email: { label: "\u05DB\u05EA\u05D5\u05D1\u05EA \u05D0\u05D9\u05DE\u05D9\u05D9\u05DC", gender: "f" },
    url: { label: "\u05DB\u05EA\u05D5\u05D1\u05EA \u05E8\u05E9\u05EA", gender: "f" },
    emoji: { label: "\u05D0\u05D9\u05DE\u05D5\u05D2'\u05D9", gender: "m" },
    uuid: { label: "UUID", gender: "m" },
    uuidv4: { label: "UUIDv4", gender: "m" },
    uuidv6: { label: "UUIDv6", gender: "m" },
    nanoid: { label: "nanoid", gender: "m" },
    guid: { label: "GUID", gender: "m" },
    cuid: { label: "cuid", gender: "m" },
    cuid2: { label: "cuid2", gender: "m" },
    ulid: { label: "ULID", gender: "m" },
    xid: { label: "XID", gender: "m" },
    ksuid: { label: "KSUID", gender: "m" },
    datetime: { label: "\u05EA\u05D0\u05E8\u05D9\u05DA \u05D5\u05D6\u05DE\u05DF ISO", gender: "m" },
    date: { label: "\u05EA\u05D0\u05E8\u05D9\u05DA ISO", gender: "m" },
    time: { label: "\u05D6\u05DE\u05DF ISO", gender: "m" },
    duration: { label: "\u05DE\u05E9\u05DA \u05D6\u05DE\u05DF ISO", gender: "m" },
    ipv4: { label: "\u05DB\u05EA\u05D5\u05D1\u05EA IPv4", gender: "f" },
    ipv6: { label: "\u05DB\u05EA\u05D5\u05D1\u05EA IPv6", gender: "f" },
    mac: { label: "\u05DB\u05EA\u05D5\u05D1\u05EA MAC", gender: "f" },
    cidrv4: { label: "\u05D8\u05D5\u05D5\u05D7 IPv4", gender: "m" },
    cidrv6: { label: "\u05D8\u05D5\u05D5\u05D7 IPv6", gender: "m" },
    base64: { label: "\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D1\u05D1\u05E1\u05D9\u05E1 64", gender: "f" },
    base64url: { label: "\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D1\u05D1\u05E1\u05D9\u05E1 64 \u05DC\u05DB\u05EA\u05D5\u05D1\u05D5\u05EA \u05E8\u05E9\u05EA", gender: "f" },
    json_string: { label: "\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA JSON", gender: "f" },
    e164: { label: "\u05DE\u05E1\u05E4\u05E8 E.164", gender: "m" },
    credit_card: { label: "\u05DE\u05E1\u05E4\u05E8 \u05DB\u05E8\u05D8\u05D9\u05E1 \u05D0\u05E9\u05E8\u05D0\u05D9", gender: "m" },
    jwt: { label: "JWT", gender: "m" },
    template_literal: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    ends_with: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    includes: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    lowercase: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    starts_with: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    uppercase: { label: "\u05E7\u05DC\u05D8", gender: "m" }
  }, c = {
    nan: "NaN"
  };
  return (l) => {
    switch (l.code) {
      case "invalid_type": {
        let d = l.expected, f = c[d ?? ""] ?? o(d), p = b(l.input), m = c[p] ?? e[p]?.label ?? p;
        return /^[A-Z]/.test(l.expected) ? `\u05E7\u05DC\u05D8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA instanceof ${l.expected}, \u05D4\u05EA\u05E7\u05D1\u05DC ${m}` : `\u05E7\u05DC\u05D8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA ${f}, \u05D4\u05EA\u05E7\u05D1\u05DC ${m}`;
      }
      case "invalid_value": {
        if (l.values.length === 1)
          return `\u05E2\u05E8\u05DA \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05D4\u05E2\u05E8\u05DA \u05D7\u05D9\u05D9\u05D1 \u05DC\u05D4\u05D9\u05D5\u05EA ${$(l.values[0])}`;
        let d = l.values.map((m) => $(m));
        if (l.values.length === 2)
          return `\u05E2\u05E8\u05DA \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05D4\u05D0\u05E4\u05E9\u05E8\u05D5\u05D9\u05D5\u05EA \u05D4\u05DE\u05EA\u05D0\u05D9\u05DE\u05D5\u05EA \u05D4\u05DF ${d[0]} \u05D0\u05D5 ${d[1]}`;
        let f = d[d.length - 1];
        return `\u05E2\u05E8\u05DA \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05D4\u05D0\u05E4\u05E9\u05E8\u05D5\u05D9\u05D5\u05EA \u05D4\u05DE\u05EA\u05D0\u05D9\u05DE\u05D5\u05EA \u05D4\u05DF ${d.slice(0, -1).join(", ")} \u05D0\u05D5 ${f}`;
      }
      case "too_big": {
        let d = a(l.origin), f = r(l.origin ?? "value");
        if (l.origin === "string")
          return `${d?.longLabel ?? "\u05D0\u05E8\u05D5\u05DA"} \u05DE\u05D3\u05D9: ${f} \u05E6\u05E8\u05D9\u05DB\u05D4 \u05DC\u05D4\u05DB\u05D9\u05DC ${l.maximum.toString()} ${d?.unit ?? ""} ${l.inclusive ? "\u05D0\u05D5 \u05E4\u05D7\u05D5\u05EA" : "\u05DC\u05DB\u05DC \u05D4\u05D9\u05D5\u05EA\u05E8"}`.trim();
        if (l.origin === "number") {
          let v = l.inclusive ? `\u05E7\u05D8\u05DF \u05D0\u05D5 \u05E9\u05D5\u05D5\u05D4 \u05DC-${l.maximum}` : `\u05E7\u05D8\u05DF \u05DE-${l.maximum}`;
          return `\u05D2\u05D3\u05D5\u05DC \u05DE\u05D3\u05D9: ${f} \u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA ${v}`;
        }
        if (l.origin === "array" || l.origin === "set") {
          let v = l.origin === "set" ? "\u05E6\u05E8\u05D9\u05DB\u05D4" : "\u05E6\u05E8\u05D9\u05DA", x = l.inclusive ? `${l.maximum} ${d?.unit ?? ""} \u05D0\u05D5 \u05E4\u05D7\u05D5\u05EA` : `\u05E4\u05D7\u05D5\u05EA \u05DE-${l.maximum} ${d?.unit ?? ""}`;
          return `\u05D2\u05D3\u05D5\u05DC \u05DE\u05D3\u05D9: ${f} ${v} \u05DC\u05D4\u05DB\u05D9\u05DC ${x}`.trim();
        }
        let p = l.inclusive ? "<=" : "<", m = i(l.origin ?? "value");
        return d?.unit ? `${d.longLabel} \u05DE\u05D3\u05D9: ${f} ${m} ${p}${l.maximum.toString()} ${d.unit}` : `${d?.longLabel ?? "\u05D2\u05D3\u05D5\u05DC"} \u05DE\u05D3\u05D9: ${f} ${m} ${p}${l.maximum.toString()}`;
      }
      case "too_small": {
        let d = a(l.origin), f = r(l.origin ?? "value");
        if (l.origin === "string")
          return `${d?.shortLabel ?? "\u05E7\u05E6\u05E8"} \u05DE\u05D3\u05D9: ${f} \u05E6\u05E8\u05D9\u05DB\u05D4 \u05DC\u05D4\u05DB\u05D9\u05DC ${l.minimum.toString()} ${d?.unit ?? ""} ${l.inclusive ? "\u05D0\u05D5 \u05D9\u05D5\u05EA\u05E8" : "\u05DC\u05E4\u05D7\u05D5\u05EA"}`.trim();
        if (l.origin === "number") {
          let v = l.inclusive ? `\u05D2\u05D3\u05D5\u05DC \u05D0\u05D5 \u05E9\u05D5\u05D5\u05D4 \u05DC-${l.minimum}` : `\u05D2\u05D3\u05D5\u05DC \u05DE-${l.minimum}`;
          return `\u05E7\u05D8\u05DF \u05DE\u05D3\u05D9: ${f} \u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA ${v}`;
        }
        if (l.origin === "array" || l.origin === "set") {
          let v = l.origin === "set" ? "\u05E6\u05E8\u05D9\u05DB\u05D4" : "\u05E6\u05E8\u05D9\u05DA";
          if (l.minimum === 1 && l.inclusive) {
            let k = (l.origin === "set", "\u05DC\u05E4\u05D7\u05D5\u05EA \u05E4\u05E8\u05D9\u05D8 \u05D0\u05D7\u05D3");
            return `\u05E7\u05D8\u05DF \u05DE\u05D3\u05D9: ${f} ${v} \u05DC\u05D4\u05DB\u05D9\u05DC ${k}`;
          }
          let x = l.inclusive ? `${l.minimum} ${d?.unit ?? ""} \u05D0\u05D5 \u05D9\u05D5\u05EA\u05E8` : `\u05D9\u05D5\u05EA\u05E8 \u05DE-${l.minimum} ${d?.unit ?? ""}`;
          return `\u05E7\u05D8\u05DF \u05DE\u05D3\u05D9: ${f} ${v} \u05DC\u05D4\u05DB\u05D9\u05DC ${x}`.trim();
        }
        let p = l.inclusive ? ">=" : ">", m = i(l.origin ?? "value");
        return d?.unit ? `${d.shortLabel} \u05DE\u05D3\u05D9: ${f} ${m} ${p}${l.minimum.toString()} ${d.unit}` : `${d?.shortLabel ?? "\u05E7\u05D8\u05DF"} \u05DE\u05D3\u05D9: ${f} ${m} ${p}${l.minimum.toString()}`;
      }
      case "invalid_format": {
        let d = l;
        if (d.format === "starts_with")
          return `\u05D4\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D7\u05D9\u05D9\u05D1\u05EA \u05DC\u05D4\u05EA\u05D7\u05D9\u05DC \u05D1 "${d.prefix}"`;
        if (d.format === "ends_with")
          return `\u05D4\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D7\u05D9\u05D9\u05D1\u05EA \u05DC\u05D4\u05E1\u05EA\u05D9\u05D9\u05DD \u05D1 "${d.suffix}"`;
        if (d.format === "includes")
          return `\u05D4\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D7\u05D9\u05D9\u05D1\u05EA \u05DC\u05DB\u05DC\u05D5\u05DC "${d.includes}"`;
        if (d.format === "regex")
          return `\u05D4\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D7\u05D9\u05D9\u05D1\u05EA \u05DC\u05D4\u05EA\u05D0\u05D9\u05DD \u05DC\u05EA\u05D1\u05E0\u05D9\u05EA ${d.pattern}`;
        let f = u[d.format], p = f?.label ?? d.format, v = (f?.gender ?? "m") === "f" ? "\u05EA\u05E7\u05D9\u05E0\u05D4" : "\u05EA\u05E7\u05D9\u05DF";
        return `${p} \u05DC\u05D0 ${v}`;
      }
      case "not_multiple_of":
        return `\u05DE\u05E1\u05E4\u05E8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05D7\u05D9\u05D9\u05D1 \u05DC\u05D4\u05D9\u05D5\u05EA \u05DE\u05DB\u05E4\u05DC\u05D4 \u05E9\u05DC ${l.divisor}`;
      case "unrecognized_keys":
        return `\u05DE\u05E4\u05EA\u05D7${l.keys.length > 1 ? "\u05D5\u05EA" : ""} \u05DC\u05D0 \u05DE\u05D6\u05D5\u05D4${l.keys.length > 1 ? "\u05D9\u05DD" : "\u05D4"}: ${h(l.keys, ", ")}`;
      case "invalid_key":
        return "\u05E9\u05D3\u05D4 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF \u05D1\u05D0\u05D5\u05D1\u05D9\u05D9\u05E7\u05D8";
      case "invalid_union":
        return "\u05E7\u05DC\u05D8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF";
      case "invalid_element":
        return `\u05E2\u05E8\u05DA \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF \u05D1${r(l.origin ?? "array")}`;
      default:
        return "\u05E7\u05DC\u05D8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF";
    }
  };
}, "error");
function Lc() {
  return {
    localeError: $b()
  };
}
s(Lc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/hi.js
var bb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0905\u0915\u094D\u0937\u0930", verb: "\u0930\u0916\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F" },
    file: { unit: "\u092C\u093E\u0907\u091F\u094D\u0938", verb: "\u0930\u0916\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F" },
    array: { unit: "\u0924\u0924\u094D\u0935", verb: "\u0930\u0916\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F" },
    set: { unit: "\u0924\u0924\u094D\u0935", verb: "\u0930\u0916\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F" },
    map: { unit: "\u092A\u094D\u0930\u0935\u093F\u0937\u094D\u091F\u093F\u092F\u093E\u0901", verb: "\u0930\u0916\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u0907\u0928\u092A\u0941\u091F",
    email: "\u0908\u092E\u0947\u0932 \u092A\u0924\u093E",
    url: "URL",
    emoji: "\u0907\u092E\u094B\u091C\u0940",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0924\u093F\u0925\u093F \u0914\u0930 \u0938\u092E\u092F",
    date: "ISO \u0924\u093F\u0925\u093F",
    time: "ISO \u0938\u092E\u092F",
    duration: "ISO \u0905\u0935\u0927\u093F",
    ipv4: "IPv4 \u092A\u0924\u093E",
    ipv6: "IPv6 \u092A\u0924\u093E",
    mac: "MAC \u092A\u0924\u093E",
    cidrv4: "IPv4 \u0936\u094D\u0930\u0947\u0923\u0940",
    cidrv6: "IPv6 \u0936\u094D\u0930\u0947\u0923\u0940",
    base64: "Base64-\u090F\u0928\u094D\u0915\u094B\u0921\u0947\u0921 \u0938\u094D\u091F\u094D\u0930\u093F\u0902\u0917",
    base64url: "Base64URL-\u090F\u0928\u094D\u0915\u094B\u0921\u0947\u0921 \u0938\u094D\u091F\u094D\u0930\u093F\u0902\u0917",
    json_string: "JSON \u0938\u094D\u091F\u094D\u0930\u093F\u0902\u0917",
    e164: "E.164 \u0938\u0902\u0916\u094D\u092F\u093E",
    credit_card: "\u0915\u094D\u0930\u0947\u0921\u093F\u091F \u0915\u093E\u0930\u094D\u0921 \u0938\u0902\u0916\u094D\u092F\u093E",
    jwt: "JWT",
    template_literal: "\u0907\u0928\u092A\u0941\u091F"
  }, o = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return `\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 ${i}, \u092A\u094D\u0930\u093E\u092A\u094D\u0924 ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 ${$(r.values[0])}` : `\u0905\u092E\u093E\u0928\u094D\u092F \u0935\u093F\u0915\u0932\u094D\u092A: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 \u092E\u093E\u0928\u094B\u0902 \u092E\u0947\u0902 \u0938\u0947 \u090F\u0915 ${h(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `\u092C\u0939\u0941\u0924 \u092C\u0921\u093C\u093E: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 \u0925\u093E \u0915\u093F ${r.origin ?? "\u092E\u093E\u0928"} \u092E\u0947\u0902 ${i}${r.maximum} ${a.unit} \u0939\u094B\u0902` : `\u092C\u0939\u0941\u0924 \u092C\u0921\u093C\u093E: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 \u0925\u093E \u0915\u093F ${r.origin ?? "\u092E\u093E\u0928"} ${i}${r.maximum} \u0939\u094B`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\u092C\u0939\u0941\u0924 \u091B\u094B\u091F\u093E: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 \u0925\u093E \u0915\u093F ${r.origin} \u092E\u0947\u0902 ${i}${r.minimum} ${a.unit} \u0939\u094B\u0902` : `\u092C\u0939\u0941\u0924 \u091B\u094B\u091F\u093E: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 \u0925\u093E \u0915\u093F ${r.origin} ${i}${r.minimum} \u0939\u094B`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0902\u0917: "${i.prefix}" \u0938\u0947 \u0936\u0941\u0930\u0942 \u0939\u094B\u0928\u093E \u091A\u093E\u0939\u093F\u090F` : i.format === "ends_with" ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0902\u0917: "${i.suffix}" \u092A\u0930 \u0938\u092E\u093E\u092A\u094D\u0924 \u0939\u094B\u0928\u093E \u091A\u093E\u0939\u093F\u090F` : i.format === "includes" ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0902\u0917: \u0907\u0938\u092E\u0947\u0902 "${i.includes}" \u0936\u093E\u092E\u093F\u0932 \u0939\u094B\u0928\u093E \u091A\u093E\u0939\u093F\u090F` : i.format === "regex" ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0902\u0917: \u092A\u0948\u091F\u0930\u094D\u0928 ${i.pattern} \u0938\u0947 \u092E\u0947\u0932 \u0916\u093E\u0928\u093E \u091A\u093E\u0939\u093F\u090F` : `\u0905\u092E\u093E\u0928\u094D\u092F ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u0902\u0916\u094D\u092F\u093E: \u092F\u0939 ${r.divisor} \u0915\u093E \u0917\u0941\u0923\u091C \u0939\u094B\u0928\u093E \u091A\u093E\u0939\u093F\u090F`;
      case "unrecognized_keys":
        return `\u0905\u092A\u0930\u093F\u091A\u093F\u0924 \u0915\u0941\u0902\u091C\u0940${r.keys.length > 1 ? "\u092F\u093E\u0901" : ""}: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `\u0905\u092E\u093E\u0928\u094D\u092F \u0915\u0941\u0902\u091C\u0940: ${r.origin} \u092E\u0947\u0902`;
      case "invalid_union":
        return r.options && Array.isArray(r.options) && r.options.length > 0 ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0921\u093F\u0938\u094D\u0915\u094D\u0930\u093F\u092E\u093F\u0928\u0947\u091F\u0930 \u092E\u093E\u0928: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 ${r.options.map((a) => `'${a}'`).join(" | ")}` : "\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F";
      case "invalid_element":
        return `\u0905\u092E\u093E\u0928\u094D\u092F \u092E\u093E\u0928: ${r.origin} \u092E\u0947\u0902`;
      default:
        return "\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F";
    }
  };
}, "error");
function Vc() {
  return {
    localeError: bb()
  };
}
s(Vc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/hr.js
var _b = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "znakova", verb: "imati" },
    file: { unit: "bajtova", verb: "imati" },
    array: { unit: "stavki", verb: "imati" },
    set: { unit: "stavki", verb: "imati" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "unos",
    email: "email adresa",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datum i vrijeme",
    date: "ISO datum",
    time: "ISO vrijeme",
    duration: "ISO trajanje",
    ipv4: "IPv4 adresa",
    ipv6: "IPv6 adresa",
    mac: "MAC adresa",
    cidrv4: "IPv4 raspon",
    cidrv6: "IPv6 raspon",
    base64: "base64 kodirani tekst",
    base64url: "base64url kodirani tekst",
    json_string: "JSON tekst",
    e164: "E.164 broj",
    credit_card: "broj kreditne kartice",
    jwt: "JWT",
    template_literal: "unos"
  }, o = {
    nan: "NaN",
    string: "tekst",
    number: "broj",
    boolean: "boolean",
    array: "niz",
    object: "objekt",
    set: "skup",
    file: "datoteka",
    date: "datum",
    bigint: "bigint",
    symbol: "simbol",
    undefined: "undefined",
    null: "null",
    function: "funkcija",
    map: "mapa"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Neispravan unos: o\u010Dekuje se instanceof ${r.expected}, a primljeno je ${u}` : `Neispravan unos: o\u010Dekuje se ${i}, a primljeno je ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Neispravna vrijednost: o\u010Dekivano ${$(r.values[0])}` : `Neispravna opcija: o\u010Dekivano jedno od ${h(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin), u = o[r.origin] ?? r.origin;
        return a ? `Preveliko: o\u010Dekivano da ${u ?? "vrijednost"} ima ${i}${r.maximum.toString()} ${a.unit ?? "elemenata"}` : `Preveliko: o\u010Dekivano da ${u ?? "vrijednost"} bude ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin), u = o[r.origin] ?? r.origin;
        return a ? `Premalo: o\u010Dekivano da ${u} ima ${i}${r.minimum.toString()} ${a.unit}` : `Premalo: o\u010Dekivano da ${u} bude ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Neispravan tekst: mora zapo\u010Dinjati s "${i.prefix}"` : i.format === "ends_with" ? `Neispravan tekst: mora zavr\u0161avati s "${i.suffix}"` : i.format === "includes" ? `Neispravan tekst: mora sadr\u017Eavati "${i.includes}"` : i.format === "regex" ? `Neispravan tekst: mora odgovarati uzorku ${i.pattern}` : `Neispravna ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Neispravan broj: mora biti vi\u0161ekratnik od ${r.divisor}`;
      case "unrecognized_keys":
        return `Neprepoznat${r.keys.length > 1 ? "i klju\u010Devi" : " klju\u010D"}: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `Neispravan klju\u010D u ${o[r.origin] ?? r.origin}`;
      case "invalid_union":
        return "Neispravan unos";
      case "invalid_element":
        return `Neispravna vrijednost u ${o[r.origin] ?? r.origin}`;
      default:
        return "Neispravan unos";
    }
  };
}, "error");
function Mc() {
  return {
    localeError: _b()
  };
}
s(Mc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/hu.js
var xb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "karakter", verb: "legyen" },
    file: { unit: "byte", verb: "legyen" },
    array: { unit: "elem", verb: "legyen" },
    set: { unit: "elem", verb: "legyen" },
    map: { unit: "elem", verb: "legyen" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "bemenet",
    email: "email c\xEDm",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO id\u0151b\xE9lyeg",
    date: "ISO d\xE1tum",
    time: "ISO id\u0151",
    duration: "ISO id\u0151intervallum",
    ipv4: "IPv4 c\xEDm",
    ipv6: "IPv6 c\xEDm",
    mac: "MAC c\xEDm",
    cidrv4: "IPv4 tartom\xE1ny",
    cidrv6: "IPv6 tartom\xE1ny",
    base64: "base64-k\xF3dolt string",
    base64url: "base64url-k\xF3dolt string",
    json_string: "JSON string",
    e164: "E.164 sz\xE1m",
    credit_card: "hitelk\xE1rtyasz\xE1m",
    jwt: "JWT",
    template_literal: "bemenet"
  }, o = {
    nan: "NaN",
    number: "sz\xE1m",
    array: "t\xF6mb"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\xC9rv\xE9nytelen bemenet: a v\xE1rt \xE9rt\xE9k instanceof ${r.expected}, a kapott \xE9rt\xE9k ${u}` : `\xC9rv\xE9nytelen bemenet: a v\xE1rt \xE9rt\xE9k ${i}, a kapott \xE9rt\xE9k ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\xC9rv\xE9nytelen bemenet: a v\xE1rt \xE9rt\xE9k ${$(r.values[0])}` : `\xC9rv\xE9nytelen opci\xF3: valamelyik \xE9rt\xE9k v\xE1rt ${h(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `T\xFAl nagy: ${r.origin ?? "\xE9rt\xE9k"} m\xE9rete t\xFAl nagy ${i}${r.maximum.toString()} ${a.unit ?? "elem"}` : `T\xFAl nagy: a bemeneti \xE9rt\xE9k ${r.origin ?? "\xE9rt\xE9k"} t\xFAl nagy: ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `T\xFAl kicsi: a bemeneti \xE9rt\xE9k ${r.origin} m\xE9rete t\xFAl kicsi ${i}${r.minimum.toString()} ${a.unit}` : `T\xFAl kicsi: a bemeneti \xE9rt\xE9k ${r.origin} t\xFAl kicsi ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\xC9rv\xE9nytelen string: "${i.prefix}" \xE9rt\xE9kkel kell kezd\u0151dnie` : i.format === "ends_with" ? `\xC9rv\xE9nytelen string: "${i.suffix}" \xE9rt\xE9kkel kell v\xE9gz\u0151dnie` : i.format === "includes" ? `\xC9rv\xE9nytelen string: "${i.includes}" \xE9rt\xE9ket kell tartalmaznia` : i.format === "regex" ? `\xC9rv\xE9nytelen string: ${i.pattern} mint\xE1nak kell megfelelnie` : `\xC9rv\xE9nytelen ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\xC9rv\xE9nytelen sz\xE1m: ${r.divisor} t\xF6bbsz\xF6r\xF6s\xE9nek kell lennie`;
      case "unrecognized_keys":
        return `Ismeretlen kulcs${r.keys.length > 1 ? "s" : ""}: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `\xC9rv\xE9nytelen kulcs ${r.origin}`;
      case "invalid_union":
        return "\xC9rv\xE9nytelen bemenet";
      case "invalid_element":
        return `\xC9rv\xE9nytelen \xE9rt\xE9k: ${r.origin}`;
      default:
        return "\xC9rv\xE9nytelen bemenet";
    }
  };
}, "error");
function Bc() {
  return {
    localeError: xb()
  };
}
s(Bc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/hy.js
function Zm(e, t, n) {
  return Math.abs(e) === 1 ? t : n;
}
s(Zm, "getArmenianPlural");
function lr(e) {
  if (!e)
    return "";
  let t = ["\u0561", "\u0565", "\u0568", "\u056B", "\u0578", "\u0578\u0582", "\u0585"], n = e[e.length - 1];
  return e + (t.includes(n) ? "\u0576" : "\u0568");
}
s(lr, "withDefiniteArticle");
var wb = /* @__PURE__ */ s(() => {
  let e = {
    string: {
      unit: {
        one: "\u0576\u0577\u0561\u0576",
        many: "\u0576\u0577\u0561\u0576\u0576\u0565\u0580"
      },
      verb: "\u0578\u0582\u0576\u0565\u0576\u0561\u056C"
    },
    file: {
      unit: {
        one: "\u0562\u0561\u0575\u0569",
        many: "\u0562\u0561\u0575\u0569\u0565\u0580"
      },
      verb: "\u0578\u0582\u0576\u0565\u0576\u0561\u056C"
    },
    array: {
      unit: {
        one: "\u057F\u0561\u0580\u0580",
        many: "\u057F\u0561\u0580\u0580\u0565\u0580"
      },
      verb: "\u0578\u0582\u0576\u0565\u0576\u0561\u056C"
    },
    set: {
      unit: {
        one: "\u057F\u0561\u0580\u0580",
        many: "\u057F\u0561\u0580\u0580\u0565\u0580"
      },
      verb: "\u0578\u0582\u0576\u0565\u0576\u0561\u056C"
    },
    map: {
      unit: {
        one: "\u057F\u0561\u0580\u0580",
        many: "\u057F\u0561\u0580\u0580\u0565\u0580"
      },
      verb: "\u0578\u0582\u0576\u0565\u0576\u0561\u056C"
    }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u0574\u0578\u0582\u057F\u0584",
    email: "\u0567\u056C. \u0570\u0561\u057D\u0581\u0565",
    url: "URL",
    emoji: "\u0567\u0574\u0578\u057B\u056B",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0561\u0574\u057D\u0561\u0569\u056B\u057E \u0587 \u056A\u0561\u0574",
    date: "ISO \u0561\u0574\u057D\u0561\u0569\u056B\u057E",
    time: "ISO \u056A\u0561\u0574",
    duration: "ISO \u057F\u0587\u0578\u0572\u0578\u0582\u0569\u0575\u0578\u0582\u0576",
    ipv4: "IPv4 \u0570\u0561\u057D\u0581\u0565",
    ipv6: "IPv6 \u0570\u0561\u057D\u0581\u0565",
    mac: "MAC \u0570\u0561\u057D\u0581\u0565",
    cidrv4: "IPv4 \u0574\u056B\u057B\u0561\u056F\u0561\u0575\u0584",
    cidrv6: "IPv6 \u0574\u056B\u057B\u0561\u056F\u0561\u0575\u0584",
    base64: "base64 \u0571\u0587\u0561\u0579\u0561\u0583\u0578\u057E \u057F\u0578\u0572",
    base64url: "base64url \u0571\u0587\u0561\u0579\u0561\u0583\u0578\u057E \u057F\u0578\u0572",
    json_string: "JSON \u057F\u0578\u0572",
    e164: "E.164 \u0570\u0561\u0574\u0561\u0580",
    credit_card: "\u056F\u0580\u0565\u0564\u056B\u057F \u0584\u0561\u0580\u057F\u056B \u0570\u0561\u0574\u0561\u0580",
    jwt: "JWT",
    template_literal: "\u0574\u0578\u0582\u057F\u0584"
  }, o = {
    nan: "NaN",
    number: "\u0569\u056B\u057E",
    array: "\u0566\u0561\u0576\u0563\u057E\u0561\u056E"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567\u0580 instanceof ${r.expected}, \u057D\u057F\u0561\u0581\u057E\u0565\u056C \u0567 ${u}` : `\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567\u0580 ${i}, \u057D\u057F\u0561\u0581\u057E\u0565\u056C \u0567 ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567\u0580 ${$(r.values[1])}` : `\u054D\u056D\u0561\u056C \u057F\u0561\u0580\u0562\u0565\u0580\u0561\u056F\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567\u0580 \u0570\u0565\u057F\u0587\u0575\u0561\u056C\u0576\u0565\u0580\u056B\u0581 \u0574\u0565\u056F\u0568\u055D ${h(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        if (a) {
          let u = Number(r.maximum), c = Zm(u, a.unit.one, a.unit.many);
          return `\u0549\u0561\u0583\u0561\u0566\u0561\u0576\u0581 \u0574\u0565\u056E \u0561\u0580\u056A\u0565\u0584\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567, \u0578\u0580 ${lr(r.origin ?? "\u0561\u0580\u056A\u0565\u0584")} \u056F\u0578\u0582\u0576\u0565\u0576\u0561 ${i}${r.maximum.toString()} ${c}`;
        }
        return `\u0549\u0561\u0583\u0561\u0566\u0561\u0576\u0581 \u0574\u0565\u056E \u0561\u0580\u056A\u0565\u0584\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567, \u0578\u0580 ${lr(r.origin ?? "\u0561\u0580\u056A\u0565\u0584")} \u056C\u056B\u0576\u056B ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        if (a) {
          let u = Number(r.minimum), c = Zm(u, a.unit.one, a.unit.many);
          return `\u0549\u0561\u0583\u0561\u0566\u0561\u0576\u0581 \u0583\u0578\u0584\u0580 \u0561\u0580\u056A\u0565\u0584\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567, \u0578\u0580 ${lr(r.origin)} \u056F\u0578\u0582\u0576\u0565\u0576\u0561 ${i}${r.minimum.toString()} ${c}`;
        }
        return `\u0549\u0561\u0583\u0561\u0566\u0561\u0576\u0581 \u0583\u0578\u0584\u0580 \u0561\u0580\u056A\u0565\u0584\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567, \u0578\u0580 ${lr(r.origin)} \u056C\u056B\u0576\u056B ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u054D\u056D\u0561\u056C \u057F\u0578\u0572\u2024 \u057A\u0565\u057F\u0584 \u0567 \u057D\u056F\u057D\u057E\u056B "${i.prefix}"-\u0578\u057E` : i.format === "ends_with" ? `\u054D\u056D\u0561\u056C \u057F\u0578\u0572\u2024 \u057A\u0565\u057F\u0584 \u0567 \u0561\u057E\u0561\u0580\u057F\u057E\u056B "${i.suffix}"-\u0578\u057E` : i.format === "includes" ? `\u054D\u056D\u0561\u056C \u057F\u0578\u0572\u2024 \u057A\u0565\u057F\u0584 \u0567 \u057A\u0561\u0580\u0578\u0582\u0576\u0561\u056F\u056B "${i.includes}"` : i.format === "regex" ? `\u054D\u056D\u0561\u056C \u057F\u0578\u0572\u2024 \u057A\u0565\u057F\u0584 \u0567 \u0570\u0561\u0574\u0561\u057A\u0561\u057F\u0561\u057D\u056D\u0561\u0576\u056B ${i.pattern} \u0571\u0587\u0561\u0579\u0561\u0583\u056B\u0576` : `\u054D\u056D\u0561\u056C ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u054D\u056D\u0561\u056C \u0569\u056B\u057E\u2024 \u057A\u0565\u057F\u0584 \u0567 \u0562\u0561\u0566\u0574\u0561\u057A\u0561\u057F\u056B\u056F \u056C\u056B\u0576\u056B ${r.divisor}-\u056B`;
      case "unrecognized_keys":
        return `\u0549\u0573\u0561\u0576\u0561\u0579\u057E\u0561\u056E \u0562\u0561\u0576\u0561\u056C\u056B${r.keys.length > 1 ? "\u0576\u0565\u0580" : ""}. ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `\u054D\u056D\u0561\u056C \u0562\u0561\u0576\u0561\u056C\u056B ${lr(r.origin)}-\u0578\u0582\u0574`;
      case "invalid_union":
        return "\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574";
      case "invalid_element":
        return `\u054D\u056D\u0561\u056C \u0561\u0580\u056A\u0565\u0584 ${lr(r.origin)}-\u0578\u0582\u0574`;
      default:
        return "\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574";
    }
  };
}, "error");
function Jc() {
  return {
    localeError: wb()
  };
}
s(Jc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/id.js
var kb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "karakter", verb: "memiliki" },
    file: { unit: "byte", verb: "memiliki" },
    array: { unit: "item", verb: "memiliki" },
    set: { unit: "item", verb: "memiliki" },
    map: { unit: "item", verb: "memiliki" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "input",
    email: "alamat email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "tanggal dan waktu format ISO",
    date: "tanggal format ISO",
    time: "jam format ISO",
    duration: "durasi format ISO",
    ipv4: "alamat IPv4",
    ipv6: "alamat IPv6",
    mac: "alamat MAC",
    cidrv4: "rentang alamat IPv4",
    cidrv6: "rentang alamat IPv6",
    base64: "string dengan enkode base64",
    base64url: "string dengan enkode base64url",
    json_string: "string JSON",
    e164: "angka E.164",
    credit_card: "nomor kartu kredit",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Input tidak valid: diharapkan instanceof ${r.expected}, diterima ${u}` : `Input tidak valid: diharapkan ${i}, diterima ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Input tidak valid: diharapkan ${$(r.values[0])}` : `Pilihan tidak valid: diharapkan salah satu dari ${h(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Terlalu besar: diharapkan ${r.origin ?? "value"} memiliki ${i}${r.maximum.toString()} ${a.unit ?? "elemen"}` : `Terlalu besar: diharapkan ${r.origin ?? "value"} menjadi ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Terlalu kecil: diharapkan ${r.origin} memiliki ${i}${r.minimum.toString()} ${a.unit}` : `Terlalu kecil: diharapkan ${r.origin} menjadi ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `String tidak valid: harus dimulai dengan "${i.prefix}"` : i.format === "ends_with" ? `String tidak valid: harus berakhir dengan "${i.suffix}"` : i.format === "includes" ? `String tidak valid: harus menyertakan "${i.includes}"` : i.format === "regex" ? `String tidak valid: harus sesuai pola ${i.pattern}` : `${n[i.format] ?? r.format} tidak valid`;
      }
      case "not_multiple_of":
        return `Angka tidak valid: harus kelipatan dari ${r.divisor}`;
      case "unrecognized_keys":
        return `Kunci tidak dikenali ${r.keys.length > 1 ? "s" : ""}: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `Kunci tidak valid di ${r.origin}`;
      case "invalid_union":
        return "Input tidak valid";
      case "invalid_element":
        return `Nilai tidak valid di ${r.origin}`;
      default:
        return "Input tidak valid";
    }
  };
}, "error");
function qc() {
  return {
    localeError: kb()
  };
}
s(qc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/is.js
var Ib = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "stafi", verb: "a\xF0 hafa" },
    file: { unit: "b\xE6ti", verb: "a\xF0 hafa" },
    array: { unit: "hluti", verb: "a\xF0 hafa" },
    set: { unit: "hluti", verb: "a\xF0 hafa" },
    map: { unit: "hluti", verb: "a\xF0 hafa" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "gildi",
    email: "netfang",
    url: "vefsl\xF3\xF0",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO dagsetning og t\xEDmi",
    date: "ISO dagsetning",
    time: "ISO t\xEDmi",
    duration: "ISO t\xEDmalengd",
    ipv4: "IPv4 address",
    ipv6: "IPv6 address",
    mac: "MAC address",
    cidrv4: "IPv4 range",
    cidrv6: "IPv6 range",
    base64: "base64-encoded strengur",
    base64url: "base64url-encoded strengur",
    json_string: "JSON strengur",
    e164: "E.164 t\xF6lugildi",
    credit_card: "kreditkortan\xFAmer",
    jwt: "JWT",
    template_literal: "gildi"
  }, o = {
    nan: "NaN",
    number: "n\xFAmer",
    array: "fylki"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Rangt gildi: \xDE\xFA sl\xF3st inn ${u} \xFEar sem \xE1 a\xF0 vera instanceof ${r.expected}` : `Rangt gildi: \xDE\xFA sl\xF3st inn ${u} \xFEar sem \xE1 a\xF0 vera ${i}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Rangt gildi: gert r\xE1\xF0 fyrir ${$(r.values[0])}` : `\xD3gilt val: m\xE1 vera eitt af eftirfarandi ${h(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Of st\xF3rt: gert er r\xE1\xF0 fyrir a\xF0 ${r.origin ?? "gildi"} hafi ${i}${r.maximum.toString()} ${a.unit ?? "hluti"}` : `Of st\xF3rt: gert er r\xE1\xF0 fyrir a\xF0 ${r.origin ?? "gildi"} s\xE9 ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Of l\xEDti\xF0: gert er r\xE1\xF0 fyrir a\xF0 ${r.origin} hafi ${i}${r.minimum.toString()} ${a.unit}` : `Of l\xEDti\xF0: gert er r\xE1\xF0 fyrir a\xF0 ${r.origin} s\xE9 ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\xD3gildur strengur: ver\xF0ur a\xF0 byrja \xE1 "${i.prefix}"` : i.format === "ends_with" ? `\xD3gildur strengur: ver\xF0ur a\xF0 enda \xE1 "${i.suffix}"` : i.format === "includes" ? `\xD3gildur strengur: ver\xF0ur a\xF0 innihalda "${i.includes}"` : i.format === "regex" ? `\xD3gildur strengur: ver\xF0ur a\xF0 fylgja mynstri ${i.pattern}` : `Rangt ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `R\xF6ng tala: ver\xF0ur a\xF0 vera margfeldi af ${r.divisor}`;
      case "unrecognized_keys":
        return `\xD3\xFEekkt ${r.keys.length > 1 ? "ir lyklar" : "ur lykill"}: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `Rangur lykill \xED ${r.origin}`;
      case "invalid_union":
        return "Rangt gildi";
      case "invalid_element":
        return `Rangt gildi \xED ${r.origin}`;
      default:
        return "Rangt gildi";
    }
  };
}, "error");
function Wc() {
  return {
    localeError: Ib()
  };
}
s(Wc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/it.js
var zb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "caratteri", verb: "avere" },
    file: { unit: "byte", verb: "avere" },
    array: { unit: "elementi", verb: "avere" },
    set: { unit: "elementi", verb: "avere" },
    map: { unit: "elementi", verb: "avere" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "input",
    email: "indirizzo email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "data e ora ISO",
    date: "data ISO",
    time: "ora ISO",
    duration: "durata ISO",
    ipv4: "indirizzo IPv4",
    ipv6: "indirizzo IPv6",
    mac: "indirizzo MAC",
    cidrv4: "intervallo IPv4",
    cidrv6: "intervallo IPv6",
    base64: "stringa codificata in base64",
    base64url: "URL codificata in base64",
    json_string: "stringa JSON",
    e164: "numero E.164",
    credit_card: "numero di carta di credito",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN",
    number: "numero",
    array: "vettore"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Input non valido: atteso instanceof ${r.expected}, ricevuto ${u}` : `Input non valido: atteso ${i}, ricevuto ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Input non valido: atteso ${$(r.values[0])}` : `Opzione non valida: atteso uno tra ${h(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Troppo grande: ${r.origin ?? "valore"} deve avere ${i}${r.maximum.toString()} ${a.unit ?? "elementi"}` : `Troppo grande: ${r.origin ?? "valore"} deve essere ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Troppo piccolo: ${r.origin} deve avere ${i}${r.minimum.toString()} ${a.unit}` : `Troppo piccolo: ${r.origin} deve essere ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Stringa non valida: deve iniziare con "${i.prefix}"` : i.format === "ends_with" ? `Stringa non valida: deve terminare con "${i.suffix}"` : i.format === "includes" ? `Stringa non valida: deve includere "${i.includes}"` : i.format === "regex" ? `Stringa non valida: deve corrispondere al pattern ${i.pattern}` : `Input non valido: ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Numero non valido: deve essere un multiplo di ${r.divisor}`;
      case "unrecognized_keys":
        return `Chiav${r.keys.length > 1 ? "i" : "e"} non riconosciut${r.keys.length > 1 ? "e" : "a"}: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `Chiave non valida in ${r.origin}`;
      case "invalid_union":
        return "Input non valido";
      case "invalid_element":
        return `Valore non valido in ${r.origin}`;
      default:
        return "Input non valido";
    }
  };
}, "error");
function Kc() {
  return {
    localeError: zb()
  };
}
s(Kc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ja.js
var Sb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u6587\u5B57", verb: "\u3067\u3042\u308B" },
    file: { unit: "\u30D0\u30A4\u30C8", verb: "\u3067\u3042\u308B" },
    array: { unit: "\u8981\u7D20", verb: "\u3067\u3042\u308B" },
    set: { unit: "\u8981\u7D20", verb: "\u3067\u3042\u308B" },
    map: { unit: "\u8981\u7D20", verb: "\u3067\u3042\u308B" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u5165\u529B\u5024",
    email: "\u30E1\u30FC\u30EB\u30A2\u30C9\u30EC\u30B9",
    url: "URL",
    emoji: "\u7D75\u6587\u5B57",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO\u65E5\u6642",
    date: "ISO\u65E5\u4ED8",
    time: "ISO\u6642\u523B",
    duration: "ISO\u671F\u9593",
    ipv4: "IPv4\u30A2\u30C9\u30EC\u30B9",
    ipv6: "IPv6\u30A2\u30C9\u30EC\u30B9",
    mac: "MAC\u30A2\u30C9\u30EC\u30B9",
    cidrv4: "IPv4\u7BC4\u56F2",
    cidrv6: "IPv6\u7BC4\u56F2",
    base64: "base64\u30A8\u30F3\u30B3\u30FC\u30C9\u6587\u5B57\u5217",
    base64url: "base64url\u30A8\u30F3\u30B3\u30FC\u30C9\u6587\u5B57\u5217",
    json_string: "JSON\u6587\u5B57\u5217",
    e164: "E.164\u756A\u53F7",
    credit_card: "\u30AF\u30EC\u30B8\u30C3\u30C8\u30AB\u30FC\u30C9\u756A\u53F7",
    jwt: "JWT",
    template_literal: "\u5165\u529B\u5024"
  }, o = {
    nan: "NaN",
    number: "\u6570\u5024",
    array: "\u914D\u5217"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u7121\u52B9\u306A\u5165\u529B: instanceof ${r.expected}\u304C\u671F\u5F85\u3055\u308C\u307E\u3057\u305F\u304C\u3001${u}\u304C\u5165\u529B\u3055\u308C\u307E\u3057\u305F` : `\u7121\u52B9\u306A\u5165\u529B: ${i}\u304C\u671F\u5F85\u3055\u308C\u307E\u3057\u305F\u304C\u3001${u}\u304C\u5165\u529B\u3055\u308C\u307E\u3057\u305F`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u7121\u52B9\u306A\u5165\u529B: ${$(r.values[0])}\u304C\u671F\u5F85\u3055\u308C\u307E\u3057\u305F` : `\u7121\u52B9\u306A\u9078\u629E: ${h(r.values, "\u3001")}\u306E\u3044\u305A\u308C\u304B\u3067\u3042\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`;
      case "too_big": {
        let i = r.inclusive ? "\u4EE5\u4E0B\u3067\u3042\u308B" : "\u3088\u308A\u5C0F\u3055\u3044", a = t(r.origin);
        return a ? `\u5927\u304D\u3059\u304E\u308B\u5024: ${r.origin ?? "\u5024"}\u306F${r.maximum.toString()}${a.unit ?? "\u8981\u7D20"}${i}\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : `\u5927\u304D\u3059\u304E\u308B\u5024: ${r.origin ?? "\u5024"}\u306F${r.maximum.toString()}${i}\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`;
      }
      case "too_small": {
        let i = r.inclusive ? "\u4EE5\u4E0A\u3067\u3042\u308B" : "\u3088\u308A\u5927\u304D\u3044", a = t(r.origin);
        return a ? `\u5C0F\u3055\u3059\u304E\u308B\u5024: ${r.origin}\u306F${r.minimum.toString()}${a.unit}${i}\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : `\u5C0F\u3055\u3059\u304E\u308B\u5024: ${r.origin}\u306F${r.minimum.toString()}${i}\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u7121\u52B9\u306A\u6587\u5B57\u5217: "${i.prefix}"\u3067\u59CB\u307E\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : i.format === "ends_with" ? `\u7121\u52B9\u306A\u6587\u5B57\u5217: "${i.suffix}"\u3067\u7D42\u308F\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : i.format === "includes" ? `\u7121\u52B9\u306A\u6587\u5B57\u5217: "${i.includes}"\u3092\u542B\u3080\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : i.format === "regex" ? `\u7121\u52B9\u306A\u6587\u5B57\u5217: \u30D1\u30BF\u30FC\u30F3${i.pattern}\u306B\u4E00\u81F4\u3059\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : `\u7121\u52B9\u306A${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u7121\u52B9\u306A\u6570\u5024: ${r.divisor}\u306E\u500D\u6570\u3067\u3042\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`;
      case "unrecognized_keys":
        return `\u8A8D\u8B58\u3055\u308C\u3066\u3044\u306A\u3044\u30AD\u30FC${r.keys.length > 1 ? "\u7FA4" : ""}: ${h(r.keys, "\u3001")}`;
      case "invalid_key":
        return `${r.origin}\u5185\u306E\u7121\u52B9\u306A\u30AD\u30FC`;
      case "invalid_union":
        return "\u7121\u52B9\u306A\u5165\u529B";
      case "invalid_element":
        return `${r.origin}\u5185\u306E\u7121\u52B9\u306A\u5024`;
      default:
        return "\u7121\u52B9\u306A\u5165\u529B";
    }
  };
}, "error");
function Gc() {
  return {
    localeError: Sb()
  };
}
s(Gc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ka.js
var Ob = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u10E1\u10D8\u10DB\u10D1\u10DD\u10DA\u10DD", verb: "\u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1" },
    file: { unit: "\u10D1\u10D0\u10D8\u10E2\u10D8", verb: "\u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1" },
    array: { unit: "\u10D4\u10DA\u10D4\u10DB\u10D4\u10DC\u10E2\u10D8", verb: "\u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1" },
    set: { unit: "\u10D4\u10DA\u10D4\u10DB\u10D4\u10DC\u10E2\u10D8", verb: "\u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1" },
    map: { unit: "\u10D4\u10DA\u10D4\u10DB\u10D4\u10DC\u10E2\u10D8", verb: "\u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0",
    email: "\u10D4\u10DA-\u10E4\u10DD\u10E1\u10E2\u10D8\u10E1 \u10DB\u10D8\u10E1\u10D0\u10DB\u10D0\u10E0\u10D7\u10D8",
    url: "URL",
    emoji: "\u10D4\u10DB\u10DD\u10EF\u10D8",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u10D7\u10D0\u10E0\u10D8\u10E6\u10D8-\u10D3\u10E0\u10DD",
    date: "\u10D7\u10D0\u10E0\u10D8\u10E6\u10D8",
    time: "\u10D3\u10E0\u10DD",
    duration: "\u10EE\u10D0\u10DC\u10D2\u10E0\u10EB\u10DA\u10D8\u10D5\u10DD\u10D1\u10D0",
    ipv4: "IPv4 \u10DB\u10D8\u10E1\u10D0\u10DB\u10D0\u10E0\u10D7\u10D8",
    ipv6: "IPv6 \u10DB\u10D8\u10E1\u10D0\u10DB\u10D0\u10E0\u10D7\u10D8",
    mac: "MAC \u10DB\u10D8\u10E1\u10D0\u10DB\u10D0\u10E0\u10D7\u10D8",
    cidrv4: "IPv4 \u10D3\u10D8\u10D0\u10DE\u10D0\u10D6\u10DD\u10DC\u10D8",
    cidrv6: "IPv6 \u10D3\u10D8\u10D0\u10DE\u10D0\u10D6\u10DD\u10DC\u10D8",
    base64: "base64-\u10D9\u10DD\u10D3\u10D8\u10E0\u10D4\u10D1\u10E3\u10DA\u10D8 \u10D5\u10D4\u10DA\u10D8",
    base64url: "base64url-\u10D9\u10DD\u10D3\u10D8\u10E0\u10D4\u10D1\u10E3\u10DA\u10D8 \u10D5\u10D4\u10DA\u10D8",
    json_string: "JSON \u10D5\u10D4\u10DA\u10D8",
    e164: "E.164 \u10DC\u10DD\u10DB\u10D4\u10E0\u10D8",
    credit_card: "\u10E1\u10D0\u10D9\u10E0\u10D4\u10D3\u10D8\u10E2\u10DD \u10D1\u10D0\u10E0\u10D0\u10D7\u10D8\u10E1 \u10DC\u10DD\u10DB\u10D4\u10E0\u10D8",
    jwt: "JWT",
    template_literal: "\u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0"
  }, o = {
    nan: "NaN",
    number: "\u10E0\u10D8\u10EA\u10EE\u10D5\u10D8",
    string: "\u10D5\u10D4\u10DA\u10D8",
    boolean: "\u10D1\u10E3\u10DA\u10D4\u10D0\u10DC\u10D8",
    function: "\u10E4\u10E3\u10DC\u10E5\u10EA\u10D8\u10D0",
    array: "\u10DB\u10D0\u10E1\u10D8\u10D5\u10D8"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 instanceof ${r.expected}, \u10DB\u10D8\u10E6\u10D4\u10D1\u10E3\u10DA\u10D8 ${u}` : `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${i}, \u10DB\u10D8\u10E6\u10D4\u10D1\u10E3\u10DA\u10D8 ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${$(r.values[0])}` : `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D5\u10D0\u10E0\u10D8\u10D0\u10DC\u10E2\u10D8: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8\u10D0 \u10D4\u10E0\u10D7-\u10D4\u10E0\u10D7\u10D8 ${h(r.values, "|")}-\u10D3\u10D0\u10DC`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `\u10D6\u10D4\u10D3\u10DB\u10D4\u10E2\u10D0\u10D3 \u10D3\u10D8\u10D3\u10D8: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${r.origin ?? "\u10DB\u10DC\u10D8\u10E8\u10D5\u10DC\u10D4\u10DA\u10DD\u10D1\u10D0"} ${a.verb} ${i}${r.maximum.toString()} ${a.unit}` : `\u10D6\u10D4\u10D3\u10DB\u10D4\u10E2\u10D0\u10D3 \u10D3\u10D8\u10D3\u10D8: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${r.origin ?? "\u10DB\u10DC\u10D8\u10E8\u10D5\u10DC\u10D4\u10DA\u10DD\u10D1\u10D0"} \u10D8\u10E7\u10DD\u10E1 ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\u10D6\u10D4\u10D3\u10DB\u10D4\u10E2\u10D0\u10D3 \u10DE\u10D0\u10E2\u10D0\u10E0\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${r.origin} ${a.verb} ${i}${r.minimum.toString()} ${a.unit}` : `\u10D6\u10D4\u10D3\u10DB\u10D4\u10E2\u10D0\u10D3 \u10DE\u10D0\u10E2\u10D0\u10E0\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${r.origin} \u10D8\u10E7\u10DD\u10E1 ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D5\u10D4\u10DA\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10D8\u10EC\u10E7\u10D4\u10D1\u10DD\u10D3\u10D4\u10E1 "${i.prefix}"-\u10D8\u10D7` : i.format === "ends_with" ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D5\u10D4\u10DA\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10DB\u10D7\u10D0\u10D5\u10E0\u10D3\u10D4\u10D1\u10DD\u10D3\u10D4\u10E1 "${i.suffix}"-\u10D8\u10D7` : i.format === "includes" ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D5\u10D4\u10DA\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1 "${i.includes}"-\u10E1` : i.format === "regex" ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D5\u10D4\u10DA\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D4\u10E1\u10D0\u10D1\u10D0\u10DB\u10D4\u10D1\u10DD\u10D3\u10D4\u10E1 \u10E8\u10D0\u10D1\u10DA\u10DD\u10DC\u10E1 ${i.pattern}` : `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E0\u10D8\u10EA\u10EE\u10D5\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10D8\u10E7\u10DD\u10E1 ${r.divisor}-\u10D8\u10E1 \u10EF\u10D4\u10E0\u10D0\u10D3\u10D8`;
      case "unrecognized_keys":
        return `\u10E3\u10EA\u10DC\u10DD\u10D1\u10D8 \u10D2\u10D0\u10E1\u10D0\u10E6\u10D4\u10D1${r.keys.length > 1 ? "\u10D4\u10D1\u10D8" : "\u10D8"}: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D2\u10D0\u10E1\u10D0\u10E6\u10D4\u10D1\u10D8 ${r.origin}-\u10E8\u10D8`;
      case "invalid_union":
        return "\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0";
      case "invalid_element":
        return `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10DB\u10DC\u10D8\u10E8\u10D5\u10DC\u10D4\u10DA\u10DD\u10D1\u10D0 ${r.origin}-\u10E8\u10D8`;
      default:
        return "\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0";
    }
  };
}, "error");
function Xc() {
  return {
    localeError: Ob()
  };
}
s(Xc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/km.js
var jb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u178F\u17BD\u17A2\u1780\u17D2\u179F\u179A", verb: "\u1782\u17BD\u179A\u1798\u17B6\u1793" },
    file: { unit: "\u1794\u17C3", verb: "\u1782\u17BD\u179A\u1798\u17B6\u1793" },
    array: { unit: "\u1792\u17B6\u178F\u17BB", verb: "\u1782\u17BD\u179A\u1798\u17B6\u1793" },
    set: { unit: "\u1792\u17B6\u178F\u17BB", verb: "\u1782\u17BD\u179A\u1798\u17B6\u1793" },
    map: { unit: "\u1792\u17B6\u178F\u17BB", verb: "\u1782\u17BD\u179A\u1798\u17B6\u1793" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B",
    email: "\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793\u17A2\u17CA\u17B8\u1798\u17C2\u179B",
    url: "URL",
    emoji: "\u179F\u1789\u17D2\u1789\u17B6\u17A2\u17B6\u179A\u1798\u17D2\u1798\u178E\u17CD",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u1780\u17B6\u179B\u1794\u179A\u17B7\u1785\u17D2\u1786\u17C1\u1791 \u1793\u17B7\u1784\u1798\u17C9\u17C4\u1784 ISO",
    date: "\u1780\u17B6\u179B\u1794\u179A\u17B7\u1785\u17D2\u1786\u17C1\u1791 ISO",
    time: "\u1798\u17C9\u17C4\u1784 ISO",
    duration: "\u179A\u1799\u17C8\u1796\u17C1\u179B ISO",
    ipv4: "\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793 IPv4",
    ipv6: "\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793 IPv6",
    mac: "\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793 MAC",
    cidrv4: "\u178A\u17C2\u1793\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793 IPv4",
    cidrv6: "\u178A\u17C2\u1793\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793 IPv6",
    base64: "\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u17A2\u17CA\u17B7\u1780\u17BC\u178A base64",
    base64url: "\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u17A2\u17CA\u17B7\u1780\u17BC\u178A base64url",
    json_string: "\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A JSON",
    e164: "\u179B\u17C1\u1781 E.164",
    credit_card: "\u179B\u17C1\u1781\u1794\u17D0\u178E\u17D2\u178E\u17A5\u178E\u1791\u17B6\u1793",
    jwt: "JWT",
    template_literal: "\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B"
  }, o = {
    nan: "NaN",
    number: "\u179B\u17C1\u1781",
    array: "\u17A2\u17B6\u179A\u17C1 (Array)",
    null: "\u1782\u17D2\u1798\u17B6\u1793\u178F\u1798\u17D2\u179B\u17C3 (null)"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A instanceof ${r.expected} \u1794\u17C9\u17BB\u1793\u17D2\u178F\u17C2\u1791\u1791\u17BD\u179B\u1794\u17B6\u1793 ${u}` : `\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${i} \u1794\u17C9\u17BB\u1793\u17D2\u178F\u17C2\u1791\u1791\u17BD\u179B\u1794\u17B6\u1793 ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${$(r.values[0])}` : `\u1787\u1798\u17D2\u179A\u17BE\u179F\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1787\u17B6\u1798\u17BD\u1799\u1780\u17D2\u1793\u17BB\u1784\u1785\u17C6\u178E\u17C4\u1798 ${h(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `\u1792\u17C6\u1796\u17C1\u1780\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${r.origin ?? "\u178F\u1798\u17D2\u179B\u17C3"} ${i} ${r.maximum.toString()} ${a.unit ?? "\u1792\u17B6\u178F\u17BB"}` : `\u1792\u17C6\u1796\u17C1\u1780\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${r.origin ?? "\u178F\u1798\u17D2\u179B\u17C3"} ${i} ${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\u178F\u17BC\u1785\u1796\u17C1\u1780\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${r.origin} ${i} ${r.minimum.toString()} ${a.unit}` : `\u178F\u17BC\u1785\u1796\u17C1\u1780\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${r.origin} ${i} ${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1785\u17B6\u1794\u17CB\u1795\u17D2\u178F\u17BE\u1798\u178A\u17C4\u1799 "${i.prefix}"` : i.format === "ends_with" ? `\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1794\u1789\u17D2\u1785\u1794\u17CB\u178A\u17C4\u1799 "${i.suffix}"` : i.format === "includes" ? `\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1798\u17B6\u1793 "${i.includes}"` : i.format === "regex" ? `\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u178F\u17C2\u1795\u17D2\u1782\u17BC\u1795\u17D2\u1782\u1784\u1793\u17B9\u1784\u1791\u1798\u17D2\u179A\u1784\u17CB\u178A\u17C2\u179B\u1794\u17B6\u1793\u1780\u17C6\u178E\u178F\u17CB ${i.pattern}` : `\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u179B\u17C1\u1781\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u178F\u17C2\u1787\u17B6\u1796\u17A0\u17BB\u1782\u17BB\u178E\u1793\u17C3 ${r.divisor}`;
      case "unrecognized_keys":
        return `\u179A\u1780\u1783\u17BE\u1789\u179F\u17C4\u1798\u17B7\u1793\u179F\u17D2\u1782\u17B6\u179B\u17CB\u17D6 ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `\u179F\u17C4\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u1793\u17C5\u1780\u17D2\u1793\u17BB\u1784 ${r.origin}`;
      case "invalid_union":
        return "\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C";
      case "invalid_element":
        return `\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u1793\u17C5\u1780\u17D2\u1793\u17BB\u1784 ${r.origin}`;
      default:
        return "\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C";
    }
  };
}, "error");
function ln() {
  return {
    localeError: jb()
  };
}
s(ln, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/kh.js
function Hc() {
  return ln();
}
s(Hc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/kn.js
var Pb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0C85\u0C95\u0CCD\u0CB7\u0CB0\u0C97\u0CB3\u0CC1", verb: "\u0CB9\u0CCA\u0C82\u0CA6\u0CB2\u0CC1" },
    file: { unit: "\u0CAC\u0CC8\u0C9F\u0CCD\u200C\u0C97\u0CB3\u0CC1", verb: "\u0CB9\u0CCA\u0C82\u0CA6\u0CB2\u0CC1" },
    array: { unit: "\u0CB5\u0CB8\u0CCD\u0CA4\u0CC1\u0C97\u0CB3\u0CC1", verb: "\u0CB9\u0CCA\u0C82\u0CA6\u0CB2\u0CC1" },
    set: { unit: "\u0CB5\u0CB8\u0CCD\u0CA4\u0CC1\u0C97\u0CB3\u0CC1", verb: "\u0CB9\u0CCA\u0C82\u0CA6\u0CB2\u0CC1" },
    map: { unit: "entries", verb: "\u0CB9\u0CCA\u0C82\u0CA6\u0CB2\u0CC1" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u0C87\u0CA8\u0CCD\u0CAA\u0CC1\u0C9F\u0CCD",
    email: "email \u0CB5\u0CBF\u0CB3\u0CBE\u0CB8",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0CA6\u0CBF\u0CA8\u0CBE\u0C82\u0C95\u0CA6 \u0CB8\u0CAE\u0CAF",
    date: "ISO \u0CA6\u0CBF\u0CA8\u0CBE\u0C82\u0C95",
    time: "ISO \u0CB8\u0CAE\u0CAF",
    duration: "ISO \u0C85\u0CB5\u0CA7\u0CBF",
    ipv4: "IPv4 \u0CB5\u0CBF\u0CB3\u0CBE\u0CB8",
    ipv6: "IPv6 \u0CB5\u0CBF\u0CB3\u0CBE\u0CB8",
    mac: "MAC \u0CB5\u0CBF\u0CB3\u0CBE\u0CB8",
    cidrv4: "IPv4 \u0CB5\u0CCD\u0CAF\u0CBE\u0CAA\u0CCD\u0CA4\u0CBF\u0CAF",
    cidrv6: "IPv6 \u0CB5\u0CCD\u0CAF\u0CBE\u0CAA\u0CCD\u0CA4\u0CBF\u0CAF",
    base64: "base64-encoded\u0CB8\u0CCD\u0C9F\u0CCD\u0CB0\u0CBF\u0C82\u0C97\u0CCD",
    base64url: "base64url-encoded\u0CB8\u0CCD\u0C9F\u0CCD\u0CB0\u0CBF\u0C82\u0C97\u0CCD",
    json_string: "JSON\u0CB8\u0CCD\u0C9F\u0CCD\u0CB0\u0CBF\u0C82\u0C97\u0CCD",
    e164: "E.164 \u0CB8\u0C82\u0C96\u0CCD\u0CAF\u0CC6",
    credit_card: "\u0C95\u0CCD\u0CB0\u0CC6\u0CA1\u0CBF\u0C9F\u0CCD \u0C95\u0CBE\u0CB0\u0CCD\u0CA1\u0CCD \u0CB8\u0C82\u0C96\u0CCD\u0CAF\u0CC6",
    jwt: "JWT",
    template_literal: "\u0C87\u0CA8\u0CCD\u0CAA\u0CC1\u0C9F\u0CCD"
  }, o = {
    // Compatibility: "nan" -> "NaN" for display
    nan: "NaN"
    // All other type names omitted - they fall back to raw values via ?? operator
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0C87\u0CA8\u0CCD\u200C\u0CAA\u0CC1\u0C9F\u0CCD: \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${i}, \u0CB8\u0CCD\u0CB5\u0CC0\u0C95\u0CB0\u0CBF\u0CB8\u0CBF\u0CA6\u0CA8\u0CC1 ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0C87\u0CA8\u0CCD\u200C\u0CAA\u0CC1\u0C9F\u0CCD: \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${$(r.values[0])}` : `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0C86\u0CAF\u0CCD\u0C95\u0CC6: \u0C87\u0CB5\u0CC1\u0C97\u0CB3\u0CB2\u0CCD\u0CB2\u0CBF \u0C92\u0C82\u0CA6\u0CA8\u0CCD\u0CA8\u0CC1 \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${h(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `\u0CA4\u0CC1\u0C82\u0CAC\u0CBE \u0CA6\u0CCA\u0CA1\u0CCD\u0CA1\u0CA6\u0CC1: \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${r.origin ?? "value"} \u0CB9\u0CCA\u0C82\u0CA6\u0CB2\u0CC1 ${i}${r.maximum.toString()} ${a.unit ?? "\u0C85\u0C82\u0CB6\u0C97\u0CB3\u0CC1"}` : `\u0CA4\u0CC1\u0C82\u0CAC\u0CBE \u0CA6\u0CCA\u0CA1\u0CCD\u0CA1\u0CA6\u0CC1: \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${r.origin ?? "value"} \u0C8E\u0C82\u0CA6\u0CC1 ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\u0CA4\u0CC1\u0C82\u0CAC\u0CBE \u0C9A\u0CBF\u0C95\u0CCD\u0C95\u0CA6\u0CC1: \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${r.origin} \u0CB9\u0CCA\u0C82\u0CA6\u0CB2\u0CC1 ${i}${r.minimum.toString()} ${a.unit}` : `\u0CA4\u0CC1\u0C82\u0CAC\u0CBE \u0C9A\u0CBF\u0C95\u0CCD\u0C95\u0CA6\u0CC1: \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${r.origin} \u0C8E\u0C82\u0CA6\u0CC1 ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF\u0CB5\u0CBE\u0CA6 \u0CB8\u0CCD\u0C9F\u0CCD\u0CB0\u0CBF\u0C82\u0C97\u0CCD: \u0C87\u0CA6\u0CB0\u0CCA\u0C82\u0CA6\u0CBF\u0C97\u0CC6 \u0CAA\u0CCD\u0CB0\u0CBE\u0CB0\u0C82\u0CAD\u0CBF\u0CB8\u0CAC\u0CC7\u0C95\u0CC1 "${i.prefix}"` : i.format === "ends_with" ? `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF\u0CB5\u0CBE\u0CA6 \u0CB8\u0CCD\u0C9F\u0CCD\u0CB0\u0CBF\u0C82\u0C97\u0CCD: \u0C87\u0CA6\u0CB0\u0CCA\u0C82\u0CA6\u0CBF\u0C97\u0CC6 \u0C95\u0CCA\u0CA8\u0CC6\u0C97\u0CCA\u0CB3\u0CCD\u0CB3\u0CAC\u0CC7\u0C95\u0CC1 "${i.suffix}"` : i.format === "includes" ? `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0CB8\u0CCD\u0C9F\u0CCD\u0CB0\u0CBF\u0C82\u0C97\u0CCD: \u0C92\u0CB3\u0C97\u0CCA\u0C82\u0CA1\u0CBF\u0CB0\u0CAC\u0CC7\u0C95\u0CC1 "${i.includes}"` : i.format === "regex" ? `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF\u0CB5\u0CBE\u0CA6 \u0CB8\u0CCD\u0C9F\u0CCD\u0CB0\u0CBF\u0C82\u0C97\u0CCD: \u0CAE\u0CBE\u0CA6\u0CB0\u0CBF\u0C97\u0CC6 \u0CB9\u0CCA\u0C82\u0CA6\u0CBF\u0C95\u0CC6\u0CAF\u0CBE\u0C97\u0CAC\u0CC7\u0C95\u0CC1 ${i.pattern}` : `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0CB8\u0C82\u0C96\u0CCD\u0CAF\u0CC6: \u0CAC\u0CB9\u0CC1\u0CB8\u0C82\u0C96\u0CCD\u0CAF\u0CC6\u0CAF\u0CBE\u0C97\u0CBF\u0CB0\u0CAC\u0CC7\u0C95\u0CC1 ${r.divisor}`;
      case "unrecognized_keys":
        return `\u0C97\u0CC1\u0CB0\u0CC1\u0CA4\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CA6 \u0C95\u0CC0 ${r.keys.length > 1 ? "s" : ""}: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF\u0CB5\u0CBE\u0CA6 \u0C95\u0CC0 \u0C87\u0CA8\u0CCD ${r.origin}`;
      case "invalid_union":
        return r.options && Array.isArray(r.options) && r.options.length > 0 ? `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0CA4\u0CBE\u0CB0\u0CA4\u0CAE\u0CCD\u0CAF \u0CAE\u0CCC\u0CB2\u0CCD\u0CAF. \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${r.options.map((a) => `'${a}'`).join(" | ")}` : "\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0C87\u0CA8\u0CCD\u200C\u0CAA\u0CC1\u0C9F\u0CCD";
      case "invalid_element":
        return `\u0CB0\u0CB2\u0CCD\u0CB2\u0CBF \u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0CAE\u0CCC\u0CB2\u0CCD\u0CAF ${r.origin}`;
      default:
        return "\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0C87\u0CA8\u0CCD\u200C\u0CAA\u0CC1\u0C9F\u0CCD";
    }
  };
}, "error");
function Qc() {
  return {
    localeError: Pb()
  };
}
s(Qc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ko.js
var Db = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\uBB38\uC790", verb: "to have" },
    file: { unit: "\uBC14\uC774\uD2B8", verb: "to have" },
    array: { unit: "\uAC1C", verb: "to have" },
    set: { unit: "\uAC1C", verb: "to have" },
    map: { unit: "\uAC1C", verb: "to have" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\uC785\uB825",
    email: "\uC774\uBA54\uC77C \uC8FC\uC18C",
    url: "URL",
    emoji: "\uC774\uBAA8\uC9C0",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \uB0A0\uC9DC\uC2DC\uAC04",
    date: "ISO \uB0A0\uC9DC",
    time: "ISO \uC2DC\uAC04",
    duration: "ISO \uAE30\uAC04",
    ipv4: "IPv4 \uC8FC\uC18C",
    ipv6: "IPv6 \uC8FC\uC18C",
    mac: "MAC \uC8FC\uC18C",
    cidrv4: "IPv4 \uBC94\uC704",
    cidrv6: "IPv6 \uBC94\uC704",
    base64: "base64 \uC778\uCF54\uB529 \uBB38\uC790\uC5F4",
    base64url: "base64url \uC778\uCF54\uB529 \uBB38\uC790\uC5F4",
    json_string: "JSON \uBB38\uC790\uC5F4",
    e164: "E.164 \uBC88\uD638",
    credit_card: "\uC2E0\uC6A9\uCE74\uB4DC \uBC88\uD638",
    jwt: "JWT",
    template_literal: "\uC785\uB825"
  }, o = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\uC798\uBABB\uB41C \uC785\uB825: \uC608\uC0C1 \uD0C0\uC785\uC740 instanceof ${r.expected}, \uBC1B\uC740 \uD0C0\uC785\uC740 ${u}\uC785\uB2C8\uB2E4` : `\uC798\uBABB\uB41C \uC785\uB825: \uC608\uC0C1 \uD0C0\uC785\uC740 ${i}, \uBC1B\uC740 \uD0C0\uC785\uC740 ${u}\uC785\uB2C8\uB2E4`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\uC798\uBABB\uB41C \uC785\uB825: \uAC12\uC740 ${$(r.values[0])} \uC774\uC5B4\uC57C \uD569\uB2C8\uB2E4` : `\uC798\uBABB\uB41C \uC635\uC158: ${h(r.values, "\uB610\uB294 ")} \uC911 \uD558\uB098\uC5EC\uC57C \uD569\uB2C8\uB2E4`;
      case "too_big": {
        let i = r.inclusive ? "\uC774\uD558" : "\uBBF8\uB9CC", a = i === "\uBBF8\uB9CC" ? "\uC774\uC5B4\uC57C \uD569\uB2C8\uB2E4" : "\uC5EC\uC57C \uD569\uB2C8\uB2E4", u = t(r.origin), c = u?.unit ?? "\uC694\uC18C";
        return u ? `${r.origin ?? "\uAC12"}\uC774 \uB108\uBB34 \uD07D\uB2C8\uB2E4: ${r.maximum.toString()}${c} ${i}${a}` : `${r.origin ?? "\uAC12"}\uC774 \uB108\uBB34 \uD07D\uB2C8\uB2E4: ${r.maximum.toString()} ${i}${a}`;
      }
      case "too_small": {
        let i = r.inclusive ? "\uC774\uC0C1" : "\uCD08\uACFC", a = i === "\uC774\uC0C1" ? "\uC774\uC5B4\uC57C \uD569\uB2C8\uB2E4" : "\uC5EC\uC57C \uD569\uB2C8\uB2E4", u = t(r.origin), c = u?.unit ?? "\uC694\uC18C";
        return u ? `${r.origin ?? "\uAC12"}\uC774 \uB108\uBB34 \uC791\uC2B5\uB2C8\uB2E4: ${r.minimum.toString()}${c} ${i}${a}` : `${r.origin ?? "\uAC12"}\uC774 \uB108\uBB34 \uC791\uC2B5\uB2C8\uB2E4: ${r.minimum.toString()} ${i}${a}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\uC798\uBABB\uB41C \uBB38\uC790\uC5F4: "${i.prefix}"(\uC73C)\uB85C \uC2DC\uC791\uD574\uC57C \uD569\uB2C8\uB2E4` : i.format === "ends_with" ? `\uC798\uBABB\uB41C \uBB38\uC790\uC5F4: "${i.suffix}"(\uC73C)\uB85C \uB05D\uB098\uC57C \uD569\uB2C8\uB2E4` : i.format === "includes" ? `\uC798\uBABB\uB41C \uBB38\uC790\uC5F4: "${i.includes}"\uC744(\uB97C) \uD3EC\uD568\uD574\uC57C \uD569\uB2C8\uB2E4` : i.format === "regex" ? `\uC798\uBABB\uB41C \uBB38\uC790\uC5F4: \uC815\uADDC\uC2DD ${i.pattern} \uD328\uD134\uACFC \uC77C\uCE58\uD574\uC57C \uD569\uB2C8\uB2E4` : `\uC798\uBABB\uB41C ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\uC798\uBABB\uB41C \uC22B\uC790: ${r.divisor}\uC758 \uBC30\uC218\uC5EC\uC57C \uD569\uB2C8\uB2E4`;
      case "unrecognized_keys":
        return `\uC778\uC2DD\uD560 \uC218 \uC5C6\uB294 \uD0A4: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `\uC798\uBABB\uB41C \uD0A4: ${r.origin}`;
      case "invalid_union":
        return "\uC798\uBABB\uB41C \uC785\uB825";
      case "invalid_element":
        return `\uC798\uBABB\uB41C \uAC12: ${r.origin}`;
      default:
        return "\uC798\uBABB\uB41C \uC785\uB825";
    }
  };
}, "error");
function Yc() {
  return {
    localeError: Db()
  };
}
s(Yc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/lt.js
var dn = /* @__PURE__ */ s((e) => e.charAt(0).toUpperCase() + e.slice(1), "capitalizeFirstCharacter");
function Rm(e) {
  let t = Math.abs(e), n = t % 10, o = t % 100;
  return o >= 11 && o <= 19 || n === 0 ? "many" : n === 1 ? "one" : "few";
}
s(Rm, "getUnitTypeFromNumber");
var Nb = /* @__PURE__ */ s(() => {
  let e = {
    string: {
      unit: {
        one: "simbolis",
        few: "simboliai",
        many: "simboli\u0173"
      },
      verb: {
        smaller: {
          inclusive: "turi b\u016Bti ne ilgesn\u0117 kaip",
          notInclusive: "turi b\u016Bti trumpesn\u0117 kaip"
        },
        bigger: {
          inclusive: "turi b\u016Bti ne trumpesn\u0117 kaip",
          notInclusive: "turi b\u016Bti ilgesn\u0117 kaip"
        }
      }
    },
    file: {
      unit: {
        one: "baitas",
        few: "baitai",
        many: "bait\u0173"
      },
      verb: {
        smaller: {
          inclusive: "turi b\u016Bti ne didesnis kaip",
          notInclusive: "turi b\u016Bti ma\u017Eesnis kaip"
        },
        bigger: {
          inclusive: "turi b\u016Bti ne ma\u017Eesnis kaip",
          notInclusive: "turi b\u016Bti didesnis kaip"
        }
      }
    },
    array: {
      unit: {
        one: "element\u0105",
        few: "elementus",
        many: "element\u0173"
      },
      verb: {
        smaller: {
          inclusive: "turi tur\u0117ti ne daugiau kaip",
          notInclusive: "turi tur\u0117ti ma\u017Eiau kaip"
        },
        bigger: {
          inclusive: "turi tur\u0117ti ne ma\u017Eiau kaip",
          notInclusive: "turi tur\u0117ti daugiau kaip"
        }
      }
    },
    set: {
      unit: {
        one: "element\u0105",
        few: "elementus",
        many: "element\u0173"
      },
      verb: {
        smaller: {
          inclusive: "turi tur\u0117ti ne daugiau kaip",
          notInclusive: "turi tur\u0117ti ma\u017Eiau kaip"
        },
        bigger: {
          inclusive: "turi tur\u0117ti ne ma\u017Eiau kaip",
          notInclusive: "turi tur\u0117ti daugiau kaip"
        }
      }
    }
  };
  function t(r, i, a, u) {
    let c = e[r] ?? null;
    return c === null ? c : {
      unit: c.unit[i],
      verb: c.verb[u][a ? "inclusive" : "notInclusive"]
    };
  }
  s(t, "getSizing");
  let n = {
    regex: "\u012Fvestis",
    email: "el. pa\u0161to adresas",
    url: "URL",
    emoji: "jaustukas",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO data ir laikas",
    date: "ISO data",
    time: "ISO laikas",
    duration: "ISO trukm\u0117",
    ipv4: "IPv4 adresas",
    ipv6: "IPv6 adresas",
    mac: "MAC adresas",
    cidrv4: "IPv4 tinklo prefiksas (CIDR)",
    cidrv6: "IPv6 tinklo prefiksas (CIDR)",
    base64: "base64 u\u017Ekoduota eilut\u0117",
    base64url: "base64url u\u017Ekoduota eilut\u0117",
    json_string: "JSON eilut\u0117",
    e164: "E.164 numeris",
    credit_card: "kredito kortel\u0117s numeris",
    jwt: "JWT",
    template_literal: "\u012Fvestis"
  }, o = {
    nan: "NaN",
    number: "skai\u010Dius",
    bigint: "sveikasis skai\u010Dius",
    string: "eilut\u0117",
    boolean: "login\u0117 reik\u0161m\u0117",
    undefined: "neapibr\u0117\u017Eta reik\u0161m\u0117",
    function: "funkcija",
    symbol: "simbolis",
    array: "masyvas",
    object: "objektas",
    null: "nulin\u0117 reik\u0161m\u0117"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Gautas tipas ${u}, o tik\u0117tasi - instanceof ${r.expected}` : `Gautas tipas ${u}, o tik\u0117tasi - ${i}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Privalo b\u016Bti ${$(r.values[0])}` : `Privalo b\u016Bti vienas i\u0161 ${h(r.values, "|")} pasirinkim\u0173`;
      case "too_big": {
        let i = o[r.origin] ?? r.origin, a = t(r.origin, Rm(Number(r.maximum)), r.inclusive ?? !1, "smaller");
        if (a?.verb)
          return `${dn(i ?? r.origin ?? "reik\u0161m\u0117")} ${a.verb} ${r.maximum.toString()} ${a.unit ?? "element\u0173"}`;
        let u = r.inclusive ? "ne didesnis kaip" : "ma\u017Eesnis kaip";
        return `${dn(i ?? r.origin ?? "reik\u0161m\u0117")} turi b\u016Bti ${u} ${r.maximum.toString()} ${a?.unit}`;
      }
      case "too_small": {
        let i = o[r.origin] ?? r.origin, a = t(r.origin, Rm(Number(r.minimum)), r.inclusive ?? !1, "bigger");
        if (a?.verb)
          return `${dn(i ?? r.origin ?? "reik\u0161m\u0117")} ${a.verb} ${r.minimum.toString()} ${a.unit ?? "element\u0173"}`;
        let u = r.inclusive ? "ne ma\u017Eesnis kaip" : "didesnis kaip";
        return `${dn(i ?? r.origin ?? "reik\u0161m\u0117")} turi b\u016Bti ${u} ${r.minimum.toString()} ${a?.unit}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Eilut\u0117 privalo prasid\u0117ti "${i.prefix}"` : i.format === "ends_with" ? `Eilut\u0117 privalo pasibaigti "${i.suffix}"` : i.format === "includes" ? `Eilut\u0117 privalo \u012Ftraukti "${i.includes}"` : i.format === "regex" ? `Eilut\u0117 privalo atitikti ${i.pattern}` : `Neteisingas ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Skai\u010Dius privalo b\u016Bti ${r.divisor} kartotinis.`;
      case "unrecognized_keys":
        return `Neatpa\u017Eint${r.keys.length > 1 ? "i" : "as"} rakt${r.keys.length > 1 ? "ai" : "as"}: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return "Rastas klaidingas raktas";
      case "invalid_union":
        return "Klaidinga \u012Fvestis";
      case "invalid_element": {
        let i = o[r.origin] ?? r.origin;
        return `${dn(i ?? r.origin ?? "reik\u0161m\u0117")} turi klaiding\u0105 \u012Fvest\u012F`;
      }
      default:
        return "Klaidinga \u012Fvestis";
    }
  };
}, "error");
function el() {
  return {
    localeError: Nb()
  };
}
s(el, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/mk.js
var Tb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0437\u043D\u0430\u0446\u0438", verb: "\u0434\u0430 \u0438\u043C\u0430\u0430\u0442" },
    file: { unit: "\u0431\u0430\u0458\u0442\u0438", verb: "\u0434\u0430 \u0438\u043C\u0430\u0430\u0442" },
    array: { unit: "\u0441\u0442\u0430\u0432\u043A\u0438", verb: "\u0434\u0430 \u0438\u043C\u0430\u0430\u0442" },
    set: { unit: "\u0441\u0442\u0430\u0432\u043A\u0438", verb: "\u0434\u0430 \u0438\u043C\u0430\u0430\u0442" },
    map: { unit: "\u0441\u0442\u0430\u0432\u043A\u0438", verb: "\u0434\u0430 \u0438\u043C\u0430\u0430\u0442" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u0432\u043D\u0435\u0441",
    email: "\u0430\u0434\u0440\u0435\u0441\u0430 \u043D\u0430 \u0435-\u043F\u043E\u0448\u0442\u0430",
    url: "URL",
    emoji: "\u0435\u043C\u043E\u045F\u0438",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0434\u0430\u0442\u0443\u043C \u0438 \u0432\u0440\u0435\u043C\u0435",
    date: "ISO \u0434\u0430\u0442\u0443\u043C",
    time: "ISO \u0432\u0440\u0435\u043C\u0435",
    duration: "ISO \u0432\u0440\u0435\u043C\u0435\u0442\u0440\u0430\u0435\u045A\u0435",
    ipv4: "IPv4 \u0430\u0434\u0440\u0435\u0441\u0430",
    ipv6: "IPv6 \u0430\u0434\u0440\u0435\u0441\u0430",
    mac: "MAC \u0430\u0434\u0440\u0435\u0441\u0430",
    cidrv4: "IPv4 \u043E\u043F\u0441\u0435\u0433",
    cidrv6: "IPv6 \u043E\u043F\u0441\u0435\u0433",
    base64: "base64-\u0435\u043D\u043A\u043E\u0434\u0438\u0440\u0430\u043D\u0430 \u043D\u0438\u0437\u0430",
    base64url: "base64url-\u0435\u043D\u043A\u043E\u0434\u0438\u0440\u0430\u043D\u0430 \u043D\u0438\u0437\u0430",
    json_string: "JSON \u043D\u0438\u0437\u0430",
    e164: "E.164 \u0431\u0440\u043E\u0458",
    credit_card: "\u0431\u0440\u043E\u0458 \u043D\u0430 \u043A\u0440\u0435\u0434\u0438\u0442\u043D\u0430 \u043A\u0430\u0440\u0442\u0438\u0447\u043A\u0430",
    jwt: "JWT",
    template_literal: "\u0432\u043D\u0435\u0441"
  }, o = {
    nan: "NaN",
    number: "\u0431\u0440\u043E\u0458",
    array: "\u043D\u0438\u0437\u0430"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u0413\u0440\u0435\u0448\u0435\u043D \u0432\u043D\u0435\u0441: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 instanceof ${r.expected}, \u043F\u0440\u0438\u043C\u0435\u043D\u043E ${u}` : `\u0413\u0440\u0435\u0448\u0435\u043D \u0432\u043D\u0435\u0441: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${i}, \u043F\u0440\u0438\u043C\u0435\u043D\u043E ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Invalid input: expected ${$(r.values[0])}` : `\u0413\u0440\u0435\u0448\u0430\u043D\u0430 \u043E\u043F\u0446\u0438\u0458\u0430: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 \u0435\u0434\u043D\u0430 ${h(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `\u041F\u0440\u0435\u043C\u043D\u043E\u0433\u0443 \u0433\u043E\u043B\u0435\u043C: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${r.origin ?? "\u0432\u0440\u0435\u0434\u043D\u043E\u0441\u0442\u0430"} \u0434\u0430 \u0438\u043C\u0430 ${i}${r.maximum.toString()} ${a.unit ?? "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0438"}` : `\u041F\u0440\u0435\u043C\u043D\u043E\u0433\u0443 \u0433\u043E\u043B\u0435\u043C: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${r.origin ?? "\u0432\u0440\u0435\u0434\u043D\u043E\u0441\u0442\u0430"} \u0434\u0430 \u0431\u0438\u0434\u0435 ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\u041F\u0440\u0435\u043C\u043D\u043E\u0433\u0443 \u043C\u0430\u043B: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${r.origin} \u0434\u0430 \u0438\u043C\u0430 ${i}${r.minimum.toString()} ${a.unit}` : `\u041F\u0440\u0435\u043C\u043D\u043E\u0433\u0443 \u043C\u0430\u043B: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${r.origin} \u0434\u0430 \u0431\u0438\u0434\u0435 ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u041D\u0435\u0432\u0430\u0436\u0435\u0447\u043A\u0430 \u043D\u0438\u0437\u0430: \u043C\u043E\u0440\u0430 \u0434\u0430 \u0437\u0430\u043F\u043E\u0447\u043D\u0443\u0432\u0430 \u0441\u043E "${i.prefix}"` : i.format === "ends_with" ? `\u041D\u0435\u0432\u0430\u0436\u0435\u0447\u043A\u0430 \u043D\u0438\u0437\u0430: \u043C\u043E\u0440\u0430 \u0434\u0430 \u0437\u0430\u0432\u0440\u0448\u0443\u0432\u0430 \u0441\u043E "${i.suffix}"` : i.format === "includes" ? `\u041D\u0435\u0432\u0430\u0436\u0435\u0447\u043A\u0430 \u043D\u0438\u0437\u0430: \u043C\u043E\u0440\u0430 \u0434\u0430 \u0432\u043A\u043B\u0443\u0447\u0443\u0432\u0430 "${i.includes}"` : i.format === "regex" ? `\u041D\u0435\u0432\u0430\u0436\u0435\u0447\u043A\u0430 \u043D\u0438\u0437\u0430: \u043C\u043E\u0440\u0430 \u0434\u0430 \u043E\u0434\u0433\u043E\u0430\u0440\u0430 \u043D\u0430 \u043F\u0430\u0442\u0435\u0440\u043D\u043E\u0442 ${i.pattern}` : `Invalid ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u0413\u0440\u0435\u0448\u0435\u043D \u0431\u0440\u043E\u0458: \u043C\u043E\u0440\u0430 \u0434\u0430 \u0431\u0438\u0434\u0435 \u0434\u0435\u043B\u0438\u0432 \u0441\u043E ${r.divisor}`;
      case "unrecognized_keys":
        return `${r.keys.length > 1 ? "\u041D\u0435\u043F\u0440\u0435\u043F\u043E\u0437\u043D\u0430\u0435\u043D\u0438 \u043A\u043B\u0443\u0447\u0435\u0432\u0438" : "\u041D\u0435\u043F\u0440\u0435\u043F\u043E\u0437\u043D\u0430\u0435\u043D \u043A\u043B\u0443\u0447"}: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `\u0413\u0440\u0435\u0448\u0435\u043D \u043A\u043B\u0443\u0447 \u0432\u043E ${r.origin}`;
      case "invalid_union":
        return "\u0413\u0440\u0435\u0448\u0435\u043D \u0432\u043D\u0435\u0441";
      case "invalid_element":
        return `\u0413\u0440\u0435\u0448\u043D\u0430 \u0432\u0440\u0435\u0434\u043D\u043E\u0441\u0442 \u0432\u043E ${r.origin}`;
      default:
        return "\u0413\u0440\u0435\u0448\u0435\u043D \u0432\u043D\u0435\u0441";
    }
  };
}, "error");
function tl() {
  return {
    localeError: Tb()
  };
}
s(tl, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ms.js
var Ab = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "aksara", verb: "mempunyai" },
    file: { unit: "bait", verb: "mempunyai" },
    array: { unit: "elemen", verb: "mempunyai" },
    set: { unit: "elemen", verb: "mempunyai" },
    map: { unit: "elemen", verb: "mempunyai" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "input",
    email: "alamat e-mel",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "tarikh masa ISO",
    date: "tarikh ISO",
    time: "masa ISO",
    duration: "tempoh ISO",
    ipv4: "alamat IPv4",
    ipv6: "alamat IPv6",
    mac: "alamat MAC",
    cidrv4: "julat IPv4",
    cidrv6: "julat IPv6",
    base64: "string dikodkan base64",
    base64url: "string dikodkan base64url",
    json_string: "string JSON",
    e164: "nombor E.164",
    credit_card: "nombor kad kredit",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN",
    number: "nombor"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Input tidak sah: dijangka instanceof ${r.expected}, diterima ${u}` : `Input tidak sah: dijangka ${i}, diterima ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Input tidak sah: dijangka ${$(r.values[0])}` : `Pilihan tidak sah: dijangka salah satu daripada ${h(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Terlalu besar: dijangka ${r.origin ?? "nilai"} ${a.verb} ${i}${r.maximum.toString()} ${a.unit ?? "elemen"}` : `Terlalu besar: dijangka ${r.origin ?? "nilai"} adalah ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Terlalu kecil: dijangka ${r.origin} ${a.verb} ${i}${r.minimum.toString()} ${a.unit}` : `Terlalu kecil: dijangka ${r.origin} adalah ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `String tidak sah: mesti bermula dengan "${i.prefix}"` : i.format === "ends_with" ? `String tidak sah: mesti berakhir dengan "${i.suffix}"` : i.format === "includes" ? `String tidak sah: mesti mengandungi "${i.includes}"` : i.format === "regex" ? `String tidak sah: mesti sepadan dengan corak ${i.pattern}` : `${n[i.format] ?? r.format} tidak sah`;
      }
      case "not_multiple_of":
        return `Nombor tidak sah: perlu gandaan ${r.divisor}`;
      case "unrecognized_keys":
        return `Kunci tidak dikenali: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `Kunci tidak sah dalam ${r.origin}`;
      case "invalid_union":
        return "Input tidak sah";
      case "invalid_element":
        return `Nilai tidak sah dalam ${r.origin}`;
      default:
        return "Input tidak sah";
    }
  };
}, "error");
function rl() {
  return {
    localeError: Ab()
  };
}
s(rl, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ne.js
var Ub = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0905\u0915\u094D\u0937\u0930", verb: "\u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B" },
    file: { unit: "\u092C\u093E\u0907\u091F", verb: "\u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B" },
    array: { unit: "\u0924\u0924\u094D\u0935", verb: "\u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B" },
    set: { unit: "\u0924\u0924\u094D\u0935", verb: "\u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B" },
    map: { unit: "\u092A\u094D\u0930\u0935\u093F\u0937\u094D\u091F\u093F", verb: "\u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u0907\u0928\u092A\u0941\u091F",
    email: "\u0907\u092E\u0947\u0932 \u0920\u0947\u0917\u093E\u0928\u093E",
    url: "URL",
    emoji: "\u0907\u092E\u094B\u091C\u0940",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u092E\u093F\u0924\u093F \u0930 \u0938\u092E\u092F",
    date: "ISO \u092E\u093F\u0924\u093F",
    time: "ISO \u0938\u092E\u092F",
    duration: "ISO \u0905\u0935\u0927\u093F",
    ipv4: "IPv4 \u0920\u0947\u0917\u093E\u0928\u093E",
    ipv6: "IPv6 \u0920\u0947\u0917\u093E\u0928\u093E",
    mac: "MAC \u0920\u0947\u0917\u093E\u0928\u093E",
    cidrv4: "IPv4 \u0926\u093E\u092F\u0930\u093E",
    cidrv6: "IPv6 \u0926\u093E\u092F\u0930\u093E",
    base64: "base64-\u0907\u0928\u094D\u0915\u094B\u0921 \u0917\u0930\u093F\u090F\u0915\u094B \u0938\u094D\u091F\u094D\u0930\u093F\u0919",
    base64url: "base64url-\u0907\u0928\u094D\u0915\u094B\u0921 \u0917\u0930\u093F\u090F\u0915\u094B \u0938\u094D\u091F\u094D\u0930\u093F\u0919",
    json_string: "JSON \u0938\u094D\u091F\u094D\u0930\u093F\u0919",
    e164: "E.164 \u0928\u092E\u094D\u092C\u0930",
    credit_card: "\u0915\u094D\u0930\u0947\u0921\u093F\u091F \u0915\u093E\u0930\u094D\u0921 \u0928\u092E\u094D\u092C\u0930",
    jwt: "JWT",
    template_literal: "\u0907\u0928\u092A\u0941\u091F"
  }, o = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return `\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 ${i}, \u092A\u094D\u0930\u093E\u092A\u094D\u0924 ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 ${$(r.values[0])}` : `\u0905\u092E\u093E\u0928\u094D\u092F \u0935\u093F\u0915\u0932\u094D\u092A: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 \u092E\u093E\u0928\u0939\u0930\u0942 \u092E\u0927\u094D\u092F\u0947 \u090F\u0915 ${h(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `\u0927\u0947\u0930\u0948 \u0920\u0942\u0932\u094B: ${r.origin ?? "\u092E\u093E\u0928"} \u092E\u093E ${i}${r.maximum.toString()} ${a.unit} ${a.verb}` : `\u0927\u0947\u0930\u0948 \u0920\u0942\u0932\u094B: ${r.origin ?? "\u092E\u093E\u0928"} ${i}${r.maximum.toString()} \u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\u0927\u0947\u0930\u0948 \u0938\u093E\u0928\u094B: ${r.origin} \u092E\u093E ${i}${r.minimum.toString()} ${a.unit} ${a.verb}` : `\u0927\u0947\u0930\u0948 \u0938\u093E\u0928\u094B: ${r.origin} ${i}${r.minimum.toString()} \u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0919: "${i.prefix}" \u092C\u093E\u091F \u0938\u0941\u0930\u0941 \u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B` : i.format === "ends_with" ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0919: "${i.suffix}" \u092E\u093E \u0938\u092E\u093E\u092A\u094D\u0924 \u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B` : i.format === "includes" ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0919: "${i.includes}" \u0938\u092E\u093E\u0935\u0947\u0936 \u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B` : i.format === "regex" ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0919: \u0922\u093E\u0901\u091A\u093E ${i.pattern} \u0938\u0901\u0917 \u092E\u0947\u0932 \u0916\u093E\u0928\u0941\u092A\u0930\u094D\u091B` : `\u0905\u092E\u093E\u0928\u094D\u092F ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u0902\u0916\u094D\u092F\u093E: ${r.divisor} \u0915\u094B \u0917\u0941\u0923\u091C \u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B`;
      case "unrecognized_keys":
        return `\u0905\u092A\u0930\u093F\u091A\u093F\u0924 \u0915\u0941\u091E\u094D\u091C\u0940${r.keys.length > 1 ? "\u0939\u0930\u0942" : ""}: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `\u0905\u092E\u093E\u0928\u094D\u092F \u0915\u0941\u091E\u094D\u091C\u0940: ${r.origin} \u092E\u093E`;
      case "invalid_union":
        return r.options && Array.isArray(r.options) && r.options.length > 0 ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0921\u093F\u0938\u094D\u0915\u094D\u0930\u093F\u092E\u093F\u0928\u0947\u091F\u0930 \u092E\u093E\u0928: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 ${r.options.map((a) => `'${a}'`).join(" | ")}` : "\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F";
      case "invalid_element":
        return `\u0905\u092E\u093E\u0928\u094D\u092F \u092E\u093E\u0928: ${r.origin} \u092E\u093E`;
      default:
        return "\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F";
    }
  };
}, "error");
function nl() {
  return {
    localeError: Ub()
  };
}
s(nl, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/nl.js
var Eb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "tekens", verb: "heeft" },
    file: { unit: "bytes", verb: "heeft" },
    array: { unit: "elementen", verb: "heeft" },
    set: { unit: "elementen", verb: "heeft" },
    map: { unit: "elementen", verb: "heeft" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "invoer",
    email: "emailadres",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datum en tijd",
    date: "ISO datum",
    time: "ISO tijd",
    duration: "ISO duur",
    ipv4: "IPv4-adres",
    ipv6: "IPv6-adres",
    mac: "MAC-adres",
    cidrv4: "IPv4-bereik",
    cidrv6: "IPv6-bereik",
    base64: "base64-gecodeerde tekst",
    base64url: "base64 URL-gecodeerde tekst",
    json_string: "JSON string",
    e164: "E.164-nummer",
    credit_card: "creditcardnummer",
    jwt: "JWT",
    template_literal: "invoer"
  }, o = {
    nan: "NaN",
    number: "getal"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Ongeldige invoer: verwacht instanceof ${r.expected}, ontving ${u}` : `Ongeldige invoer: verwacht ${i}, ontving ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Ongeldige invoer: verwacht ${$(r.values[0])}` : `Ongeldige optie: verwacht \xE9\xE9n van ${h(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin), u = r.origin === "date" ? "laat" : r.origin === "string" ? "lang" : "groot";
        return a ? `Te ${u}: verwacht dat ${r.origin ?? "waarde"} ${i}${r.maximum.toString()} ${a.unit ?? "elementen"} ${a.verb}` : `Te ${u}: verwacht dat ${r.origin ?? "waarde"} ${i}${r.maximum.toString()} is`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin), u = r.origin === "date" ? "vroeg" : r.origin === "string" ? "kort" : "klein";
        return a ? `Te ${u}: verwacht dat ${r.origin} ${i}${r.minimum.toString()} ${a.unit} ${a.verb}` : `Te ${u}: verwacht dat ${r.origin} ${i}${r.minimum.toString()} is`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Ongeldige tekst: moet met "${i.prefix}" beginnen` : i.format === "ends_with" ? `Ongeldige tekst: moet op "${i.suffix}" eindigen` : i.format === "includes" ? `Ongeldige tekst: moet "${i.includes}" bevatten` : i.format === "regex" ? `Ongeldige tekst: moet overeenkomen met patroon ${i.pattern}` : `Ongeldig: ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Ongeldig getal: moet een veelvoud van ${r.divisor} zijn`;
      case "unrecognized_keys":
        return `Onbekende key${r.keys.length > 1 ? "s" : ""}: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `Ongeldige key in ${r.origin}`;
      case "invalid_union":
        return "Ongeldige invoer";
      case "invalid_element":
        return `Ongeldige waarde in ${r.origin}`;
      default:
        return "Ongeldige invoer";
    }
  };
}, "error");
function il() {
  return {
    localeError: Eb()
  };
}
s(il, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/nn.js
var Cb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "teikn", verb: "\xE5 ha" },
    file: { unit: "bytes", verb: "\xE5 ha" },
    array: { unit: "element", verb: "\xE5 innehalde" },
    set: { unit: "element", verb: "\xE5 innehalde" },
    map: { unit: "element", verb: "\xE5 innehalde" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "input",
    email: "e-postadresse",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO dato- og klokkeslett",
    date: "ISO-dato",
    time: "ISO-klokkeslett",
    duration: "ISO-varigheit",
    ipv4: "IPv4-adresse",
    ipv6: "IPv6-adresse",
    mac: "MAC-adresse",
    cidrv4: "IPv4-spekter",
    cidrv6: "IPv6-spekter",
    base64: "base64-enkoda streng",
    base64url: "base64url-enkoda streng",
    json_string: "JSON-streng",
    e164: "E.164-nummer",
    credit_card: "kredittkortnummer",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN",
    number: "tal",
    array: "liste"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Ugyldig input: forventa instanceof ${r.expected}, fekk ${u}` : `Ugyldig input: forventa ${i}, fekk ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Ugyldig verdi: forventa ${$(r.values[0])}` : `Ugyldig val: forventa eitt av ${h(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `For stor(t): forventa ${r.origin ?? "value"} til \xE5 ha ${i}${r.maximum.toString()} ${a.unit ?? "element"}` : `For stor(t): forventa ${r.origin ?? "value"} til \xE5 ha ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `For lite(n): forventa ${r.origin} til \xE5 ha ${i}${r.minimum.toString()} ${a.unit}` : `For lite(n): forventa ${r.origin} til \xE5 ha ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Ugyldig streng: m\xE5 starte med "${i.prefix}"` : i.format === "ends_with" ? `Ugyldig streng: m\xE5 slutte med "${i.suffix}"` : i.format === "includes" ? `Ugyldig streng: m\xE5 innehalde "${i.includes}"` : i.format === "regex" ? `Ugyldig streng: m\xE5 matche m\xF8nsteret ${i.pattern}` : `Ugyldig ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Ugyldig tal: m\xE5 vere eit multiplum av ${r.divisor}`;
      case "unrecognized_keys":
        return `${r.keys.length > 1 ? "Ukjende n\xF8klar" : "Ukjend n\xF8kkel"}: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `Ugyldig n\xF8kkel i ${r.origin}`;
      case "invalid_union":
        return "Ugyldig input";
      case "invalid_element":
        return `Ugyldig verdi i ${r.origin}`;
      default:
        return "Ugyldig input";
    }
  };
}, "error");
function ol() {
  return {
    localeError: Cb()
  };
}
s(ol, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/no.js
var Zb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "tegn", verb: "\xE5 ha" },
    file: { unit: "bytes", verb: "\xE5 ha" },
    array: { unit: "elementer", verb: "\xE5 inneholde" },
    set: { unit: "elementer", verb: "\xE5 inneholde" },
    map: { unit: "elementer", verb: "\xE5 inneholde" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "input",
    email: "e-postadresse",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO dato- og klokkeslett",
    date: "ISO-dato",
    time: "ISO-klokkeslett",
    duration: "ISO-varighet",
    ipv4: "IPv4-adresse",
    ipv6: "IPv6-adresse",
    mac: "MAC-adresse",
    cidrv4: "IPv4-spekter",
    cidrv6: "IPv6-spekter",
    base64: "base64-enkodet streng",
    base64url: "base64url-enkodet streng",
    json_string: "JSON-streng",
    e164: "E.164-nummer",
    credit_card: "kredittkortnummer",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN",
    number: "tall",
    array: "liste"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Ugyldig input: forventet instanceof ${r.expected}, fikk ${u}` : `Ugyldig input: forventet ${i}, fikk ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Ugyldig verdi: forventet ${$(r.values[0])}` : `Ugyldig valg: forventet en av ${h(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `For stor(t): forventet ${r.origin ?? "value"} til \xE5 ha ${i}${r.maximum.toString()} ${a.unit ?? "elementer"}` : `For stor(t): forventet ${r.origin ?? "value"} til \xE5 ha ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `For lite(n): forventet ${r.origin} til \xE5 ha ${i}${r.minimum.toString()} ${a.unit}` : `For lite(n): forventet ${r.origin} til \xE5 ha ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Ugyldig streng: m\xE5 starte med "${i.prefix}"` : i.format === "ends_with" ? `Ugyldig streng: m\xE5 ende med "${i.suffix}"` : i.format === "includes" ? `Ugyldig streng: m\xE5 inneholde "${i.includes}"` : i.format === "regex" ? `Ugyldig streng: m\xE5 matche m\xF8nsteret ${i.pattern}` : `Ugyldig ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Ugyldig tall: m\xE5 v\xE6re et multiplum av ${r.divisor}`;
      case "unrecognized_keys":
        return `${r.keys.length > 1 ? "Ukjente n\xF8kler" : "Ukjent n\xF8kkel"}: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `Ugyldig n\xF8kkel i ${r.origin}`;
      case "invalid_union":
        return "Ugyldig input";
      case "invalid_element":
        return `Ugyldig verdi i ${r.origin}`;
      default:
        return "Ugyldig input";
    }
  };
}, "error");
function al() {
  return {
    localeError: Zb()
  };
}
s(al, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ota.js
var Rb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "harf", verb: "olmal\u0131d\u0131r" },
    file: { unit: "bayt", verb: "olmal\u0131d\u0131r" },
    array: { unit: "unsur", verb: "olmal\u0131d\u0131r" },
    set: { unit: "unsur", verb: "olmal\u0131d\u0131r" },
    map: { unit: "unsur", verb: "olmal\u0131d\u0131r" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "giren",
    email: "epostag\xE2h",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO heng\xE2m\u0131",
    date: "ISO tarihi",
    time: "ISO zaman\u0131",
    duration: "ISO m\xFCddeti",
    ipv4: "IPv4 ni\u015F\xE2n\u0131",
    ipv6: "IPv6 ni\u015F\xE2n\u0131",
    mac: "MAC ni\u015F\xE2n\u0131",
    cidrv4: "IPv4 menzili",
    cidrv6: "IPv6 menzili",
    base64: "base64-\u015Fifreli metin",
    base64url: "base64url-\u015Fifreli metin",
    json_string: "JSON metin",
    e164: "E.164 say\u0131s\u0131",
    credit_card: "i'tib\xE2r kart\u0131 numaras\u0131",
    jwt: "JWT",
    template_literal: "giren"
  }, o = {
    nan: "NaN",
    number: "numara",
    array: "saf",
    null: "gayb"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `F\xE2sit giren: umulan instanceof ${r.expected}, al\u0131nan ${u}` : `F\xE2sit giren: umulan ${i}, al\u0131nan ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `F\xE2sit giren: umulan ${$(r.values[0])}` : `F\xE2sit tercih: m\xFBteberler ${h(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Fazla b\xFCy\xFCk: ${r.origin ?? "value"}, ${i}${r.maximum.toString()} ${a.unit ?? "elements"} sahip olmal\u0131yd\u0131.` : `Fazla b\xFCy\xFCk: ${r.origin ?? "value"}, ${i}${r.maximum.toString()} olmal\u0131yd\u0131.`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Fazla k\xFC\xE7\xFCk: ${r.origin}, ${i}${r.minimum.toString()} ${a.unit} sahip olmal\u0131yd\u0131.` : `Fazla k\xFC\xE7\xFCk: ${r.origin}, ${i}${r.minimum.toString()} olmal\u0131yd\u0131.`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `F\xE2sit metin: "${i.prefix}" ile ba\u015Flamal\u0131.` : i.format === "ends_with" ? `F\xE2sit metin: "${i.suffix}" ile bitmeli.` : i.format === "includes" ? `F\xE2sit metin: "${i.includes}" ihtiv\xE2 etmeli.` : i.format === "regex" ? `F\xE2sit metin: ${i.pattern} nak\u015F\u0131na uymal\u0131.` : `F\xE2sit ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `F\xE2sit say\u0131: ${r.divisor} kat\u0131 olmal\u0131yd\u0131.`;
      case "unrecognized_keys":
        return `Tan\u0131nmayan anahtar ${r.keys.length > 1 ? "s" : ""}: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `${r.origin} i\xE7in tan\u0131nmayan anahtar var.`;
      case "invalid_union":
        return "Giren tan\u0131namad\u0131.";
      case "invalid_element":
        return `${r.origin} i\xE7in tan\u0131nmayan k\u0131ymet var.`;
      default:
        return "K\u0131ymet tan\u0131namad\u0131.";
    }
  };
}, "error");
function sl() {
  return {
    localeError: Rb()
  };
}
s(sl, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ps.js
var Fb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u062A\u0648\u06A9\u064A", verb: "\u0648\u0644\u0631\u064A" },
    file: { unit: "\u0628\u0627\u06CC\u067C\u0633", verb: "\u0648\u0644\u0631\u064A" },
    array: { unit: "\u062A\u0648\u06A9\u064A", verb: "\u0648\u0644\u0631\u064A" },
    set: { unit: "\u062A\u0648\u06A9\u064A", verb: "\u0648\u0644\u0631\u064A" },
    map: { unit: "\u062A\u0648\u06A9\u064A", verb: "\u0648\u0644\u0631\u064A" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u0648\u0631\u0648\u062F\u064A",
    email: "\u0628\u0631\u06CC\u069A\u0646\u0627\u0644\u06CC\u06A9",
    url: "\u06CC\u0648 \u0622\u0631 \u0627\u0644",
    emoji: "\u0627\u06CC\u0645\u0648\u062C\u064A",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u0646\u06CC\u067C\u0647 \u0627\u0648 \u0648\u062E\u062A",
    date: "\u0646\u06D0\u067C\u0647",
    time: "\u0648\u062E\u062A",
    duration: "\u0645\u0648\u062F\u0647",
    ipv4: "\u062F IPv4 \u067E\u062A\u0647",
    ipv6: "\u062F IPv6 \u067E\u062A\u0647",
    mac: "\u062F MAC \u067E\u062A\u0647",
    cidrv4: "\u062F IPv4 \u0633\u0627\u062D\u0647",
    cidrv6: "\u062F IPv6 \u0633\u0627\u062D\u0647",
    base64: "base64-encoded \u0645\u062A\u0646",
    base64url: "base64url-encoded \u0645\u062A\u0646",
    json_string: "JSON \u0645\u062A\u0646",
    e164: "\u062F E.164 \u0634\u0645\u06D0\u0631\u0647",
    credit_card: "\u062F \u06A9\u0631\u06CC\u0689\u06CC\u067C \u06A9\u0627\u0631\u062A \u0634\u0645\u06CC\u0631\u0647",
    jwt: "JWT",
    template_literal: "\u0648\u0631\u0648\u062F\u064A"
  }, o = {
    nan: "NaN",
    number: "\u0639\u062F\u062F",
    array: "\u0627\u0631\u06D0"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u0646\u0627\u0633\u0645 \u0648\u0631\u0648\u062F\u064A: \u0628\u0627\u06CC\u062F instanceof ${r.expected} \u0648\u0627\u06CC, \u0645\u06AB\u0631 ${u} \u062A\u0631\u0644\u0627\u0633\u0647 \u0634\u0648` : `\u0646\u0627\u0633\u0645 \u0648\u0631\u0648\u062F\u064A: \u0628\u0627\u06CC\u062F ${i} \u0648\u0627\u06CC, \u0645\u06AB\u0631 ${u} \u062A\u0631\u0644\u0627\u0633\u0647 \u0634\u0648`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u0646\u0627\u0633\u0645 \u0648\u0631\u0648\u062F\u064A: \u0628\u0627\u06CC\u062F ${$(r.values[0])} \u0648\u0627\u06CC` : `\u0646\u0627\u0633\u0645 \u0627\u0646\u062A\u062E\u0627\u0628: \u0628\u0627\u06CC\u062F \u06CC\u0648 \u0644\u0647 ${h(r.values, "|")} \u0685\u062E\u0647 \u0648\u0627\u06CC`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `\u0689\u06CC\u0631 \u0644\u0648\u06CC: ${r.origin ?? "\u0627\u0631\u0632\u069A\u062A"} \u0628\u0627\u06CC\u062F ${i}${r.maximum.toString()} ${a.unit ?? "\u0639\u0646\u0635\u0631\u0648\u0646\u0647"} \u0648\u0644\u0631\u064A` : `\u0689\u06CC\u0631 \u0644\u0648\u06CC: ${r.origin ?? "\u0627\u0631\u0632\u069A\u062A"} \u0628\u0627\u06CC\u062F ${i}${r.maximum.toString()} \u0648\u064A`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\u0689\u06CC\u0631 \u06A9\u0648\u0686\u0646\u06CC: ${r.origin} \u0628\u0627\u06CC\u062F ${i}${r.minimum.toString()} ${a.unit} \u0648\u0644\u0631\u064A` : `\u0689\u06CC\u0631 \u06A9\u0648\u0686\u0646\u06CC: ${r.origin} \u0628\u0627\u06CC\u062F ${i}${r.minimum.toString()} \u0648\u064A`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u0646\u0627\u0633\u0645 \u0645\u062A\u0646: \u0628\u0627\u06CC\u062F \u062F "${i.prefix}" \u0633\u0631\u0647 \u067E\u06CC\u0644 \u0634\u064A` : i.format === "ends_with" ? `\u0646\u0627\u0633\u0645 \u0645\u062A\u0646: \u0628\u0627\u06CC\u062F \u062F "${i.suffix}" \u0633\u0631\u0647 \u067E\u0627\u06CC \u062A\u0647 \u0648\u0631\u0633\u064A\u0696\u064A` : i.format === "includes" ? `\u0646\u0627\u0633\u0645 \u0645\u062A\u0646: \u0628\u0627\u06CC\u062F "${i.includes}" \u0648\u0644\u0631\u064A` : i.format === "regex" ? `\u0646\u0627\u0633\u0645 \u0645\u062A\u0646: \u0628\u0627\u06CC\u062F \u062F ${i.pattern} \u0633\u0631\u0647 \u0645\u0637\u0627\u0628\u0642\u062A \u0648\u0644\u0631\u064A` : `${n[i.format] ?? r.format} \u0646\u0627\u0633\u0645 \u062F\u06CC`;
      }
      case "not_multiple_of":
        return `\u0646\u0627\u0633\u0645 \u0639\u062F\u062F: \u0628\u0627\u06CC\u062F \u062F ${r.divisor} \u0645\u0636\u0631\u0628 \u0648\u064A`;
      case "unrecognized_keys":
        return `\u0646\u0627\u0633\u0645 ${r.keys.length > 1 ? "\u06A9\u0644\u06CC\u0689\u0648\u0646\u0647" : "\u06A9\u0644\u06CC\u0689"}: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `\u0646\u0627\u0633\u0645 \u06A9\u0644\u06CC\u0689 \u067E\u0647 ${r.origin} \u06A9\u06D0`;
      case "invalid_union":
        return "\u0646\u0627\u0633\u0645\u0647 \u0648\u0631\u0648\u062F\u064A";
      case "invalid_element":
        return `\u0646\u0627\u0633\u0645 \u0639\u0646\u0635\u0631 \u067E\u0647 ${r.origin} \u06A9\u06D0`;
      default:
        return "\u0646\u0627\u0633\u0645\u0647 \u0648\u0631\u0648\u062F\u064A";
    }
  };
}, "error");
function ul() {
  return {
    localeError: Fb()
  };
}
s(ul, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/pl.js
var Lb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "znak\xF3w", verb: "mie\u0107" },
    file: { unit: "bajt\xF3w", verb: "mie\u0107" },
    array: { unit: "element\xF3w", verb: "mie\u0107" },
    set: { unit: "element\xF3w", verb: "mie\u0107" },
    map: { unit: "element\xF3w", verb: "mie\u0107" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "wyra\u017Cenie",
    email: "adres email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "data i godzina w formacie ISO",
    date: "data w formacie ISO",
    time: "godzina w formacie ISO",
    duration: "czas trwania ISO",
    ipv4: "adres IPv4",
    ipv6: "adres IPv6",
    mac: "adres MAC",
    cidrv4: "zakres IPv4",
    cidrv6: "zakres IPv6",
    base64: "ci\u0105g znak\xF3w zakodowany w formacie base64",
    base64url: "ci\u0105g znak\xF3w zakodowany w formacie base64url",
    json_string: "ci\u0105g znak\xF3w w formacie JSON",
    e164: "liczba E.164",
    credit_card: "numer karty kredytowej",
    jwt: "JWT",
    template_literal: "wej\u015Bcie"
  }, o = {
    nan: "NaN",
    number: "liczba",
    array: "tablica"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Nieprawid\u0142owe dane wej\u015Bciowe: oczekiwano instanceof ${r.expected}, otrzymano ${u}` : `Nieprawid\u0142owe dane wej\u015Bciowe: oczekiwano ${i}, otrzymano ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Nieprawid\u0142owe dane wej\u015Bciowe: oczekiwano ${$(r.values[0])}` : `Nieprawid\u0142owa opcja: oczekiwano jednej z warto\u015Bci ${h(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Za du\u017Ca warto\u015B\u0107: oczekiwano, \u017Ce ${r.origin ?? "warto\u015B\u0107"} b\u0119dzie mie\u0107 ${i}${r.maximum.toString()} ${a.unit ?? "element\xF3w"}` : `Zbyt du\u017C(y/a/e): oczekiwano, \u017Ce ${r.origin ?? "warto\u015B\u0107"} b\u0119dzie wynosi\u0107 ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Za ma\u0142a warto\u015B\u0107: oczekiwano, \u017Ce ${r.origin ?? "warto\u015B\u0107"} b\u0119dzie mie\u0107 ${i}${r.minimum.toString()} ${a.unit ?? "element\xF3w"}` : `Zbyt ma\u0142(y/a/e): oczekiwano, \u017Ce ${r.origin ?? "warto\u015B\u0107"} b\u0119dzie wynosi\u0107 ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Nieprawid\u0142owy ci\u0105g znak\xF3w: musi zaczyna\u0107 si\u0119 od "${i.prefix}"` : i.format === "ends_with" ? `Nieprawid\u0142owy ci\u0105g znak\xF3w: musi ko\u0144czy\u0107 si\u0119 na "${i.suffix}"` : i.format === "includes" ? `Nieprawid\u0142owy ci\u0105g znak\xF3w: musi zawiera\u0107 "${i.includes}"` : i.format === "regex" ? `Nieprawid\u0142owy ci\u0105g znak\xF3w: musi odpowiada\u0107 wzorcowi ${i.pattern}` : `Nieprawid\u0142ow(y/a/e) ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Nieprawid\u0142owa liczba: musi by\u0107 wielokrotno\u015Bci\u0105 ${r.divisor}`;
      case "unrecognized_keys":
        return `Nierozpoznane klucze${r.keys.length > 1 ? "s" : ""}: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `Nieprawid\u0142owy klucz w ${r.origin}`;
      case "invalid_union":
        return "Nieprawid\u0142owe dane wej\u015Bciowe";
      case "invalid_element":
        return `Nieprawid\u0142owa warto\u015B\u0107 w ${r.origin}`;
      default:
        return "Nieprawid\u0142owe dane wej\u015Bciowe";
    }
  };
}, "error");
function cl() {
  return {
    localeError: Lb()
  };
}
s(cl, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/pt.js
var Vb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "caracteres" },
    file: { unit: "bytes" },
    array: { unit: "elementos" },
    set: { unit: "elementos" },
    map: { unit: "entradas" }
  };
  function t(a) {
    return e[a] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "a entrada",
    email: "o endere\xE7o de e-mail",
    url: "o URL",
    emoji: "o emoji",
    uuid: "o UUID",
    uuidv4: "o UUIDv4",
    uuidv6: "o UUIDv6",
    nanoid: "o nanoid",
    guid: "o GUID",
    cuid: "o cuid",
    cuid2: "o cuid2",
    ulid: "o ULID",
    xid: "o XID",
    ksuid: "o KSUID",
    datetime: "a data e hora ISO",
    date: "a data ISO",
    time: "a hora ISO",
    duration: "a dura\xE7\xE3o ISO",
    ipv4: "o endere\xE7o IPv4",
    ipv6: "o endere\xE7o IPv6",
    mac: "o endere\xE7o MAC",
    cidrv4: "o intervalo de endere\xE7os IPv4",
    cidrv6: "o intervalo de endere\xE7os IPv6",
    base64: "o texto codificado em base64",
    base64url: "o texto codificado em base64url",
    json_string: "o texto JSON",
    e164: "o n\xFAmero E.164",
    credit_card: "o n\xFAmero de cart\xE3o de cr\xE9dito",
    jwt: "o JWT",
    template_literal: "a entrada"
  }, o = {
    masculine: { definite: "o", indefinite: "um" },
    feminine: { definite: "a", indefinite: "uma" }
  }, r = {
    string: { name: "texto", articles: o.masculine },
    number: { name: "n\xFAmero", articles: o.masculine },
    int: { name: "n\xFAmero inteiro", articles: o.masculine },
    boolean: { name: "valor booleano", articles: o.masculine },
    bigint: { name: "n\xFAmero bigint", articles: o.masculine },
    symbol: { name: "s\xEDmbolo", articles: o.masculine },
    undefined: { name: 'valor "undefined"', articles: o.masculine },
    null: { name: 'valor "nulo"', articles: o.masculine },
    never: { name: 'valor "never"', articles: o.masculine },
    void: { name: 'valor "void"', articles: o.masculine },
    date: { name: "data", articles: o.feminine },
    array: { name: "vetor", articles: o.masculine },
    object: { name: "objeto", articles: o.masculine },
    tuple: { name: "tuplo", articles: o.masculine },
    record: { name: "registo", articles: o.masculine },
    map: { name: "mapa", articles: o.masculine },
    set: { name: "conjunto", articles: o.masculine },
    file: { name: "ficheiro", articles: o.masculine },
    nonoptional: { name: "valor n\xE3o opcional", articles: o.masculine },
    nan: { name: 'valor "NaN"', articles: o.masculine },
    // Compatibility: "nan" -> "NaN" for display
    function: { name: "fun\xE7\xE3o", articles: o.feminine }
  };
  function i(a, u) {
    let c = r[a] ?? { name: `valor "${a}"`, articles: o.masculine };
    return `${c.articles[u]} ${c.name}`;
  }
  return s(i, "translateOriginWithArticle"), (a) => {
    switch (a.code) {
      case "invalid_type": {
        let u = i(a.expected, "indefinite"), c = b(a.input), l = i(c, "indefinite");
        return `Entrada inv\xE1lida: esperava ${u}, recebeu ${l}`;
      }
      case "invalid_value":
        return a.values.length === 1 ? `Entrada inv\xE1lida: esperava ${$(a.values[0])}` : `Op\xE7\xE3o inv\xE1lida: esperava uma das seguintes op\xE7\xF5es: ${h(a.values, "|")}`;
      case "too_big": {
        let u = a.inclusive ? "<=" : "<", c = t(a.origin);
        return c ? `Demasiado grande: esperava que ${i(a.origin, "definite")} tivesse ${u} ${a.maximum.toString()} ${c.unit ?? "elementos"}` : `Demasiado grande: esperava que ${i(a.origin, "definite")} fosse ${u} ${a.maximum.toString()}`;
      }
      case "too_small": {
        let u = a.inclusive ? ">=" : ">", c = t(a.origin);
        return c ? `Demasiado pequeno: esperava que ${i(a.origin, "definite")} tivesse ${u} ${a.minimum.toString()} ${c.unit ?? "elementos"}` : `Demasiado pequeno: esperava que ${i(a.origin, "definite")} fosse ${u} ${a.minimum.toString()}`;
      }
      case "invalid_format": {
        let u = a;
        return u.format === "starts_with" ? `Texto inv\xE1lido: deve come\xE7ar por "${u.prefix}"` : u.format === "ends_with" ? `Texto inv\xE1lido: deve terminar em "${u.suffix}"` : u.format === "includes" ? `Texto inv\xE1lido: deve incluir "${u.includes}"` : u.format === "regex" ? `Texto inv\xE1lido: deve corresponder ao padr\xE3o ${u.pattern}` : `Formato d${n[u.format] ?? a.format} inv\xE1lido`;
      }
      case "not_multiple_of":
        return `N\xFAmero inv\xE1lido: deve ser m\xFAltiplo de ${a.divisor}`;
      case "unrecognized_keys": {
        let u = a.keys.length > 1 ? "s" : "";
        return `Chave${u} inv\xE1lida${u}: ${h(a.keys, ", ")}`;
      }
      case "invalid_key":
        return `Entrada inv\xE1lida n${i(a.origin, "definite")}`;
      case "invalid_union":
        return a.options && Array.isArray(a.options) && a.options.length > 0 ? `Valor de discrimina\xE7\xE3o inv\xE1lido. Esperava ${a.options.map((c) => `'${c}'`).join(" | ")}` : "Entrada inv\xE1lida";
      case "invalid_element":
        return `Entrada inv\xE1lida n${i(a.origin, "definite")}`;
      default:
        return "Entrada inv\xE1lida";
    }
  };
}, "error");
function ll() {
  return {
    localeError: Vb()
  };
}
s(ll, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/pt-BR.js
var Mb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "caracteres" },
    file: { unit: "bytes" },
    array: { unit: "elementos" },
    set: { unit: "elementos" },
    map: { unit: "entradas" }
  };
  function t(a) {
    return e[a] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "a entrada",
    email: "o endere\xE7o de e-mail",
    url: "o URL",
    emoji: "o emoji",
    uuid: "o UUID",
    uuidv4: "o UUIDv4",
    uuidv6: "o UUIDv6",
    nanoid: "o nanoid",
    guid: "o GUID",
    cuid: "o cuid",
    cuid2: "o cuid2",
    ulid: "o ULID",
    xid: "o XID",
    ksuid: "o KSUID",
    datetime: "a data e hora ISO",
    date: "a data ISO",
    time: "a hora ISO",
    duration: "a dura\xE7\xE3o ISO",
    ipv4: "o endere\xE7o IPv4",
    ipv6: "o endere\xE7o IPv6",
    mac: "o endere\xE7o MAC",
    cidrv4: "a faixa de endere\xE7os IPv4",
    cidrv6: "a faixa de endere\xE7os IPv6",
    base64: "o texto codificado em base64",
    base64url: "o texto codificado em base64url",
    json_string: "o texto JSON",
    e164: "o n\xFAmero E.164",
    credit_card: "o n\xFAmero de cart\xE3o de cr\xE9dito",
    jwt: "o JWT",
    template_literal: "a entrada"
  }, o = {
    masculine: { definite: "o", indefinite: "um" },
    feminine: { definite: "a", indefinite: "uma" }
  }, r = {
    string: { name: "texto", articles: o.masculine },
    number: { name: "n\xFAmero", articles: o.masculine },
    int: { name: "n\xFAmero inteiro", articles: o.masculine },
    boolean: { name: "valor booleano", articles: o.masculine },
    bigint: { name: "n\xFAmero bigint", articles: o.masculine },
    symbol: { name: "s\xEDmbolo", articles: o.masculine },
    undefined: { name: 'valor "undefined"', articles: o.masculine },
    null: { name: 'valor "nulo"', articles: o.masculine },
    never: { name: 'valor "never"', articles: o.masculine },
    void: { name: 'valor "void"', articles: o.masculine },
    date: { name: "data", articles: o.feminine },
    array: { name: "vetor", articles: o.masculine },
    object: { name: "objeto", articles: o.masculine },
    tuple: { name: "tupla", articles: o.feminine },
    record: { name: "registro", articles: o.masculine },
    map: { name: "mapa", articles: o.masculine },
    set: { name: "conjunto", articles: o.masculine },
    file: { name: "arquivo", articles: o.masculine },
    nonoptional: { name: "valor n\xE3o opcional", articles: o.masculine },
    nan: { name: 'valor "NaN"', articles: o.masculine },
    // Compatibility: "nan" -> "NaN" for display
    function: { name: "fun\xE7\xE3o", articles: o.feminine }
  };
  function i(a, u) {
    let c = r[a] ?? { name: `valor "${a}"`, articles: o.masculine };
    return `${c.articles[u]} ${c.name}`;
  }
  return s(i, "translateOriginWithArticle"), (a) => {
    switch (a.code) {
      case "invalid_type": {
        let u = i(a.expected, "indefinite"), c = b(a.input), l = i(c, "indefinite");
        return `Entrada inv\xE1lida: esperava ${u}, recebeu ${l}`;
      }
      case "invalid_value":
        return a.values.length === 1 ? `Entrada inv\xE1lida: esperava ${$(a.values[0])}` : `Op\xE7\xE3o inv\xE1lida: esperava uma das seguintes op\xE7\xF5es: ${h(a.values, "|")}`;
      case "too_big": {
        let u = a.inclusive ? "<=" : "<", c = t(a.origin);
        return c ? `Grande demais: esperava que ${i(a.origin, "definite")} tivesse ${u} ${a.maximum.toString()} ${c.unit ?? "elementos"}` : `Grande demais: esperava que ${i(a.origin, "definite")} fosse ${u} ${a.maximum.toString()}`;
      }
      case "too_small": {
        let u = a.inclusive ? ">=" : ">", c = t(a.origin);
        return c ? `Pequeno demais: esperava que ${i(a.origin, "definite")} tivesse ${u} ${a.minimum.toString()} ${c.unit ?? "elementos"}` : `Pequeno demais: esperava que ${i(a.origin, "definite")} fosse ${u} ${a.minimum.toString()}`;
      }
      case "invalid_format": {
        let u = a;
        return u.format === "starts_with" ? `Texto inv\xE1lido: deve come\xE7ar com "${u.prefix}"` : u.format === "ends_with" ? `Texto inv\xE1lido: deve terminar com "${u.suffix}"` : u.format === "includes" ? `Texto inv\xE1lido: deve incluir "${u.includes}"` : u.format === "regex" ? `Texto inv\xE1lido: deve corresponder ao padr\xE3o ${u.pattern}` : `Formato d${n[u.format] ?? a.format} inv\xE1lido`;
      }
      case "not_multiple_of":
        return `N\xFAmero inv\xE1lido: deve ser m\xFAltiplo de ${a.divisor}`;
      case "unrecognized_keys": {
        let u = a.keys.length > 1 ? "s" : "";
        return `Chave${u} inv\xE1lida${u}: ${h(a.keys, ", ")}`;
      }
      case "invalid_key":
        return `Entrada inv\xE1lida n${i(a.origin, "definite")}`;
      case "invalid_union":
        return a.options && Array.isArray(a.options) && a.options.length > 0 ? `Valor de discrimina\xE7\xE3o inv\xE1lido. Esperava ${a.options.map((c) => `'${c}'`).join(" | ")}` : "Entrada inv\xE1lida";
      case "invalid_element":
        return `Entrada inv\xE1lida n${i(a.origin, "definite")}`;
      default:
        return "Entrada inv\xE1lida";
    }
  };
}, "error");
function dl() {
  return {
    localeError: Mb()
  };
}
s(dl, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ro.js
var Bb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "caractere", verb: "s\u0103 aib\u0103" },
    file: { unit: "octe\u021Bi", verb: "s\u0103 aib\u0103" },
    array: { unit: "elemente", verb: "s\u0103 aib\u0103" },
    set: { unit: "elemente", verb: "s\u0103 aib\u0103" },
    map: { unit: "intr\u0103ri", verb: "s\u0103 aib\u0103" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "intrare",
    email: "adres\u0103 de email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "dat\u0103 \u0219i or\u0103 ISO",
    date: "dat\u0103 ISO",
    time: "or\u0103 ISO",
    duration: "durat\u0103 ISO",
    ipv4: "adres\u0103 IPv4",
    ipv6: "adres\u0103 IPv6",
    mac: "adres\u0103 MAC",
    cidrv4: "interval IPv4",
    cidrv6: "interval IPv6",
    base64: "\u0219ir codat base64",
    base64url: "\u0219ir codat base64url",
    json_string: "\u0219ir JSON",
    e164: "num\u0103r E.164",
    credit_card: "num\u0103r de card de credit",
    jwt: "JWT",
    template_literal: "intrare"
  }, o = {
    nan: "NaN",
    string: "\u0219ir",
    number: "num\u0103r",
    boolean: "boolean",
    function: "func\u021Bie",
    array: "matrice",
    object: "obiect",
    undefined: "nedefinit",
    symbol: "simbol",
    bigint: "num\u0103r mare",
    void: "void",
    never: "never",
    map: "hart\u0103",
    set: "set"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return `Intrare invalid\u0103: a\u0219teptat ${i}, primit ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Intrare invalid\u0103: a\u0219teptat ${$(r.values[0])}` : `Op\u021Biune invalid\u0103: a\u0219teptat una dintre ${h(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Prea mare: a\u0219teptat ca ${r.origin ?? "valoarea"} ${a.verb} ${i}${r.maximum.toString()} ${a.unit ?? "elemente"}` : `Prea mare: a\u0219teptat ca ${r.origin ?? "valoarea"} s\u0103 fie ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Prea mic: a\u0219teptat ca ${r.origin} ${a.verb} ${i}${r.minimum.toString()} ${a.unit}` : `Prea mic: a\u0219teptat ca ${r.origin} s\u0103 fie ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u0218ir invalid: trebuie s\u0103 \xEEnceap\u0103 cu "${i.prefix}"` : i.format === "ends_with" ? `\u0218ir invalid: trebuie s\u0103 se termine cu "${i.suffix}"` : i.format === "includes" ? `\u0218ir invalid: trebuie s\u0103 includ\u0103 "${i.includes}"` : i.format === "regex" ? `\u0218ir invalid: trebuie s\u0103 se potriveasc\u0103 cu modelul ${i.pattern}` : `Format invalid: ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Num\u0103r invalid: trebuie s\u0103 fie multiplu de ${r.divisor}`;
      case "unrecognized_keys":
        return `Chei nerecunoscute: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `Cheie invalid\u0103 \xEEn ${r.origin}`;
      case "invalid_union":
        return "Intrare invalid\u0103";
      case "invalid_element":
        return `Valoare invalid\u0103 \xEEn ${r.origin}`;
      default:
        return "Intrare invalid\u0103";
    }
  };
}, "error");
function fl() {
  return {
    localeError: Bb()
  };
}
s(fl, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ru.js
function Fm(e, t, n, o) {
  let r = Math.abs(e), i = r % 10, a = r % 100;
  return a >= 11 && a <= 19 ? o : i === 1 ? t : i >= 2 && i <= 4 ? n : o;
}
s(Fm, "getRussianPlural");
var Jb = /* @__PURE__ */ s(() => {
  let e = {
    string: {
      unit: {
        one: "\u0441\u0438\u043C\u0432\u043E\u043B",
        few: "\u0441\u0438\u043C\u0432\u043E\u043B\u0430",
        many: "\u0441\u0438\u043C\u0432\u043E\u043B\u043E\u0432"
      },
      verb: "\u0438\u043C\u0435\u0442\u044C"
    },
    file: {
      unit: {
        one: "\u0431\u0430\u0439\u0442",
        few: "\u0431\u0430\u0439\u0442\u0430",
        many: "\u0431\u0430\u0439\u0442"
      },
      verb: "\u0438\u043C\u0435\u0442\u044C"
    },
    array: {
      unit: {
        one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
        few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430",
        many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u043E\u0432"
      },
      verb: "\u0438\u043C\u0435\u0442\u044C"
    },
    set: {
      unit: {
        one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
        few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430",
        many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u043E\u0432"
      },
      verb: "\u0438\u043C\u0435\u0442\u044C"
    },
    map: {
      unit: {
        one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
        few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430",
        many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u043E\u0432"
      },
      verb: "\u0438\u043C\u0435\u0442\u044C"
    }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u0432\u0432\u043E\u0434",
    email: "email \u0430\u0434\u0440\u0435\u0441",
    url: "URL",
    emoji: "\u044D\u043C\u043E\u0434\u0437\u0438",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0434\u0430\u0442\u0430 \u0438 \u0432\u0440\u0435\u043C\u044F",
    date: "ISO \u0434\u0430\u0442\u0430",
    time: "ISO \u0432\u0440\u0435\u043C\u044F",
    duration: "ISO \u0434\u043B\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C",
    ipv4: "IPv4 \u0430\u0434\u0440\u0435\u0441",
    ipv6: "IPv6 \u0430\u0434\u0440\u0435\u0441",
    mac: "MAC \u0430\u0434\u0440\u0435\u0441",
    cidrv4: "IPv4 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D",
    cidrv6: "IPv6 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D",
    base64: "\u0441\u0442\u0440\u043E\u043A\u0430 \u0432 \u0444\u043E\u0440\u043C\u0430\u0442\u0435 base64",
    base64url: "\u0441\u0442\u0440\u043E\u043A\u0430 \u0432 \u0444\u043E\u0440\u043C\u0430\u0442\u0435 base64url",
    json_string: "JSON \u0441\u0442\u0440\u043E\u043A\u0430",
    e164: "\u043D\u043E\u043C\u0435\u0440 E.164",
    credit_card: "\u043D\u043E\u043C\u0435\u0440 \u043A\u0440\u0435\u0434\u0438\u0442\u043D\u043E\u0439 \u043A\u0430\u0440\u0442\u044B",
    jwt: "JWT",
    template_literal: "\u0432\u0432\u043E\u0434"
  }, o = {
    nan: "NaN",
    number: "\u0447\u0438\u0441\u043B\u043E",
    array: "\u043C\u0430\u0441\u0441\u0438\u0432"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0432\u0432\u043E\u0434: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C instanceof ${r.expected}, \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u043E ${u}` : `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0432\u0432\u043E\u0434: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C ${i}, \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u043E ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0432\u0432\u043E\u0434: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C ${$(r.values[0])}` : `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0432\u0430\u0440\u0438\u0430\u043D\u0442: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C \u043E\u0434\u043D\u043E \u0438\u0437 ${h(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        if (a) {
          let u = Number(r.maximum), c = Fm(u, a.unit.one, a.unit.few, a.unit.many);
          return `\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C, \u0447\u0442\u043E ${r.origin ?? "\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435"} \u0431\u0443\u0434\u0435\u0442 \u0438\u043C\u0435\u0442\u044C ${i}${r.maximum.toString()} ${c}`;
        }
        return `\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C, \u0447\u0442\u043E ${r.origin ?? "\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435"} \u0431\u0443\u0434\u0435\u0442 ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        if (a) {
          let u = Number(r.minimum), c = Fm(u, a.unit.one, a.unit.few, a.unit.many);
          return `\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u043C\u0430\u043B\u0435\u043D\u044C\u043A\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C, \u0447\u0442\u043E ${r.origin} \u0431\u0443\u0434\u0435\u0442 \u0438\u043C\u0435\u0442\u044C ${i}${r.minimum.toString()} ${c}`;
        }
        return `\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u043C\u0430\u043B\u0435\u043D\u044C\u043A\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C, \u0447\u0442\u043E ${r.origin} \u0431\u0443\u0434\u0435\u0442 ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u0441\u0442\u0440\u043E\u043A\u0430: \u0434\u043E\u043B\u0436\u043D\u0430 \u043D\u0430\u0447\u0438\u043D\u0430\u0442\u044C\u0441\u044F \u0441 "${i.prefix}"` : i.format === "ends_with" ? `\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u0441\u0442\u0440\u043E\u043A\u0430: \u0434\u043E\u043B\u0436\u043D\u0430 \u0437\u0430\u043A\u0430\u043D\u0447\u0438\u0432\u0430\u0442\u044C\u0441\u044F \u043D\u0430 "${i.suffix}"` : i.format === "includes" ? `\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u0441\u0442\u0440\u043E\u043A\u0430: \u0434\u043E\u043B\u0436\u043D\u0430 \u0441\u043E\u0434\u0435\u0440\u0436\u0430\u0442\u044C "${i.includes}"` : i.format === "regex" ? `\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u0441\u0442\u0440\u043E\u043A\u0430: \u0434\u043E\u043B\u0436\u043D\u0430 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u043E\u0432\u0430\u0442\u044C \u0448\u0430\u0431\u043B\u043E\u043D\u0443 ${i.pattern}` : `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u041D\u0435\u0432\u0435\u0440\u043D\u043E\u0435 \u0447\u0438\u0441\u043B\u043E: \u0434\u043E\u043B\u0436\u043D\u043E \u0431\u044B\u0442\u044C \u043A\u0440\u0430\u0442\u043D\u044B\u043C ${r.divisor}`;
      case "unrecognized_keys":
        return `\u041D\u0435\u0440\u0430\u0441\u043F\u043E\u0437\u043D\u0430\u043D\u043D${r.keys.length > 1 ? "\u044B\u0435" : "\u044B\u0439"} \u043A\u043B\u044E\u0447${r.keys.length > 1 ? "\u0438" : ""}: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u043A\u043B\u044E\u0447 \u0432 ${r.origin}`;
      case "invalid_union":
        return "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0435 \u0432\u0445\u043E\u0434\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435";
      case "invalid_element":
        return `\u041D\u0435\u0432\u0435\u0440\u043D\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u0432 ${r.origin}`;
      default:
        return "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0435 \u0432\u0445\u043E\u0434\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435";
    }
  };
}, "error");
function pl() {
  return {
    localeError: Jb()
  };
}
s(pl, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/sk.js
var qb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "znakov", verb: "ma\u0165" },
    file: { unit: "bajtov", verb: "ma\u0165" },
    array: { unit: "prvkov", verb: "ma\u0165" },
    set: { unit: "prvkov", verb: "ma\u0165" },
    map: { unit: "polo\u017Eiek", verb: "ma\u0165" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "regul\xE1rny v\xFDraz",
    email: "e-mailov\xE1 adresa",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "d\xE1tum a \u010Das vo form\xE1te ISO",
    date: "d\xE1tum vo form\xE1te ISO",
    time: "\u010Das vo form\xE1te ISO",
    duration: "doba trvania ISO",
    ipv4: "IPv4 adresa",
    ipv6: "IPv6 adresa",
    mac: "MAC adresa",
    cidrv4: "rozsah IPv4",
    cidrv6: "rozsah IPv6",
    base64: "re\u0165azec zak\xF3dovan\xFD vo form\xE1te base64",
    base64url: "re\u0165azec zak\xF3dovan\xFD vo form\xE1te base64url",
    json_string: "re\u0165azec vo form\xE1te JSON",
    e164: "\u010D\xEDslo E.164",
    credit_card: "\u010D\xEDslo kreditnej karty",
    jwt: "JWT",
    template_literal: "vstup"
  }, o = {
    nan: "NaN",
    number: "\u010D\xEDslo",
    string: "re\u0165azec",
    function: "funkcia",
    array: "pole"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Neplatn\xFD vstup: o\u010Dak\xE1van\xE9 instanceof ${r.expected}, obdr\u017Ean\xE9 ${u}` : `Neplatn\xFD vstup: o\u010Dak\xE1van\xE9 ${i}, obdr\u017Ean\xE9 ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Neplatn\xFD vstup: o\u010Dak\xE1van\xE9 ${$(r.values[0])}` : `Neplatn\xFD vstup: o\u010Dak\xE1van\xE1 jedna z hodn\xF4t ${h(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Hodnota je pr\xEDli\u0161 ve\u013Ek\xE1: ${r.origin ?? "hodnota"} mus\xED ma\u0165 ${i}${r.maximum.toString()} ${a.unit ?? "prvkov"}` : `Hodnota je pr\xEDli\u0161 ve\u013Ek\xE1: ${r.origin ?? "hodnota"} mus\xED by\u0165 ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Hodnota je pr\xEDli\u0161 mal\xE1: ${r.origin ?? "hodnota"} mus\xED ma\u0165 ${i}${r.minimum.toString()} ${a.unit ?? "prvkov"}` : `Hodnota je pr\xEDli\u0161 mal\xE1: ${r.origin ?? "hodnota"} mus\xED by\u0165 ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Neplatn\xFD re\u0165azec: mus\xED za\u010D\xEDna\u0165 na "${i.prefix}"` : i.format === "ends_with" ? `Neplatn\xFD re\u0165azec: mus\xED kon\u010Di\u0165 na "${i.suffix}"` : i.format === "includes" ? `Neplatn\xFD re\u0165azec: mus\xED obsahova\u0165 "${i.includes}"` : i.format === "regex" ? `Neplatn\xFD re\u0165azec: mus\xED zodpoveda\u0165 vzoru ${i.pattern}` : `Neplatn\xFD form\xE1t ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Neplatn\xE9 \u010D\xEDslo: mus\xED by\u0165 n\xE1sobkom ${r.divisor}`;
      case "unrecognized_keys":
        return `Nezn\xE1me kl\xFA\u010De: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `Neplatn\xFD kl\xFA\u010D v ${r.origin}`;
      case "invalid_union":
        return "Neplatn\xFD vstup";
      case "invalid_element":
        return `Neplatn\xE1 hodnota v ${r.origin}`;
      default:
        return "Neplatn\xFD vstup";
    }
  };
}, "error");
function ml() {
  return {
    localeError: qb()
  };
}
s(ml, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/sl.js
var Wb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "znakov", verb: "imeti" },
    file: { unit: "bajtov", verb: "imeti" },
    array: { unit: "elementov", verb: "imeti" },
    set: { unit: "elementov", verb: "imeti" },
    map: { unit: "elementov", verb: "imeti" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "vnos",
    email: "e-po\u0161tni naslov",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datum in \u010Das",
    date: "ISO datum",
    time: "ISO \u010Das",
    duration: "ISO trajanje",
    ipv4: "IPv4 naslov",
    ipv6: "IPv6 naslov",
    mac: "MAC naslov",
    cidrv4: "obseg IPv4",
    cidrv6: "obseg IPv6",
    base64: "base64 kodiran niz",
    base64url: "base64url kodiran niz",
    json_string: "JSON niz",
    e164: "E.164 \u0161tevilka",
    credit_card: "\u0161tevilka kreditne kartice",
    jwt: "JWT",
    template_literal: "vnos"
  }, o = {
    nan: "NaN",
    number: "\u0161tevilo",
    array: "tabela"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Neveljaven vnos: pri\u010Dakovano instanceof ${r.expected}, prejeto ${u}` : `Neveljaven vnos: pri\u010Dakovano ${i}, prejeto ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Neveljaven vnos: pri\u010Dakovano ${$(r.values[0])}` : `Neveljavna mo\u017Enost: pri\u010Dakovano eno izmed ${h(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Preveliko: pri\u010Dakovano, da bo ${r.origin ?? "vrednost"} imelo ${i}${r.maximum.toString()} ${a.unit ?? "elementov"}` : `Preveliko: pri\u010Dakovano, da bo ${r.origin ?? "vrednost"} ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Premajhno: pri\u010Dakovano, da bo ${r.origin} imelo ${i}${r.minimum.toString()} ${a.unit}` : `Premajhno: pri\u010Dakovano, da bo ${r.origin} ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Neveljaven niz: mora se za\u010Deti z "${i.prefix}"` : i.format === "ends_with" ? `Neveljaven niz: mora se kon\u010Dati z "${i.suffix}"` : i.format === "includes" ? `Neveljaven niz: mora vsebovati "${i.includes}"` : i.format === "regex" ? `Neveljaven niz: mora ustrezati vzorcu ${i.pattern}` : `Neveljaven ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Neveljavno \u0161tevilo: mora biti ve\u010Dkratnik ${r.divisor}`;
      case "unrecognized_keys":
        return `Neprepoznan${r.keys.length > 1 ? "i klju\u010Di" : " klju\u010D"}: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `Neveljaven klju\u010D v ${r.origin}`;
      case "invalid_union":
        return "Neveljaven vnos";
      case "invalid_element":
        return `Neveljavna vrednost v ${r.origin}`;
      default:
        return "Neveljaven vnos";
    }
  };
}, "error");
function gl() {
  return {
    localeError: Wb()
  };
}
s(gl, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/sv.js
var Kb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "tecken", verb: "att ha" },
    file: { unit: "bytes", verb: "att ha" },
    array: { unit: "objekt", verb: "att inneh\xE5lla" },
    set: { unit: "objekt", verb: "att inneh\xE5lla" },
    map: { unit: "objekt", verb: "att inneh\xE5lla" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "regulj\xE4rt uttryck",
    email: "e-postadress",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO-datum och tid",
    date: "ISO-datum",
    time: "ISO-tid",
    duration: "ISO-varaktighet",
    ipv4: "IPv4-adress",
    ipv6: "IPv6-adress",
    mac: "MAC-adress",
    cidrv4: "IPv4-spektrum",
    cidrv6: "IPv6-spektrum",
    base64: "base64-kodad str\xE4ng",
    base64url: "base64url-kodad str\xE4ng",
    json_string: "JSON-str\xE4ng",
    e164: "E.164-nummer",
    credit_card: "kreditkortsnummer",
    jwt: "JWT",
    template_literal: "mall-literal"
  }, o = {
    nan: "NaN",
    number: "antal",
    array: "lista"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Ogiltig inmatning: f\xF6rv\xE4ntat instanceof ${r.expected}, fick ${u}` : `Ogiltig inmatning: f\xF6rv\xE4ntat ${i}, fick ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Ogiltig inmatning: f\xF6rv\xE4ntat ${$(r.values[0])}` : `Ogiltigt val: f\xF6rv\xE4ntade en av ${h(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `F\xF6r stor(t): f\xF6rv\xE4ntade ${r.origin ?? "v\xE4rdet"} att ha ${i}${r.maximum.toString()} ${a.unit ?? "element"}` : `F\xF6r stor(t): f\xF6rv\xE4ntat ${r.origin ?? "v\xE4rdet"} att ha ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `F\xF6r lite(t): f\xF6rv\xE4ntade ${r.origin ?? "v\xE4rdet"} att ha ${i}${r.minimum.toString()} ${a.unit}` : `F\xF6r lite(t): f\xF6rv\xE4ntade ${r.origin ?? "v\xE4rdet"} att ha ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Ogiltig str\xE4ng: m\xE5ste b\xF6rja med "${i.prefix}"` : i.format === "ends_with" ? `Ogiltig str\xE4ng: m\xE5ste sluta med "${i.suffix}"` : i.format === "includes" ? `Ogiltig str\xE4ng: m\xE5ste inneh\xE5lla "${i.includes}"` : i.format === "regex" ? `Ogiltig str\xE4ng: m\xE5ste matcha m\xF6nstret "${i.pattern}"` : `Ogiltig(t) ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Ogiltigt tal: m\xE5ste vara en multipel av ${r.divisor}`;
      case "unrecognized_keys":
        return `${r.keys.length > 1 ? "Ok\xE4nda nycklar" : "Ok\xE4nd nyckel"}: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `Ogiltig nyckel i ${r.origin ?? "v\xE4rdet"}`;
      case "invalid_union":
        return "Ogiltig input";
      case "invalid_element":
        return `Ogiltigt v\xE4rde i ${r.origin ?? "v\xE4rdet"}`;
      default:
        return "Ogiltig input";
    }
  };
}, "error");
function hl() {
  return {
    localeError: Kb()
  };
}
s(hl, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ta.js
var Gb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0B8E\u0BB4\u0BC1\u0BA4\u0BCD\u0BA4\u0BC1\u0B95\u0BCD\u0B95\u0BB3\u0BCD", verb: "\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD" },
    file: { unit: "\u0BAA\u0BC8\u0B9F\u0BCD\u0B9F\u0BC1\u0B95\u0BB3\u0BCD", verb: "\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD" },
    array: { unit: "\u0B89\u0BB1\u0BC1\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD", verb: "\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD" },
    set: { unit: "\u0B89\u0BB1\u0BC1\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD", verb: "\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD" },
    map: { unit: "\u0B89\u0BB1\u0BC1\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD", verb: "\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1",
    email: "\u0BAE\u0BBF\u0BA9\u0BCD\u0BA9\u0B9E\u0BCD\u0B9A\u0BB2\u0BCD \u0BAE\u0BC1\u0B95\u0BB5\u0BB0\u0BBF",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0BA4\u0BC7\u0BA4\u0BBF \u0BA8\u0BC7\u0BB0\u0BAE\u0BCD",
    date: "ISO \u0BA4\u0BC7\u0BA4\u0BBF",
    time: "ISO \u0BA8\u0BC7\u0BB0\u0BAE\u0BCD",
    duration: "ISO \u0B95\u0BBE\u0BB2 \u0B85\u0BB3\u0BB5\u0BC1",
    ipv4: "IPv4 \u0BAE\u0BC1\u0B95\u0BB5\u0BB0\u0BBF",
    ipv6: "IPv6 \u0BAE\u0BC1\u0B95\u0BB5\u0BB0\u0BBF",
    mac: "MAC \u0BAE\u0BC1\u0B95\u0BB5\u0BB0\u0BBF",
    cidrv4: "IPv4 \u0BB5\u0BB0\u0BAE\u0BCD\u0BAA\u0BC1",
    cidrv6: "IPv6 \u0BB5\u0BB0\u0BAE\u0BCD\u0BAA\u0BC1",
    base64: "base64-encoded \u0B9A\u0BB0\u0BAE\u0BCD",
    base64url: "base64url-encoded \u0B9A\u0BB0\u0BAE\u0BCD",
    json_string: "JSON \u0B9A\u0BB0\u0BAE\u0BCD",
    e164: "E.164 \u0B8E\u0BA3\u0BCD",
    credit_card: "\u0B95\u0B9F\u0BA9\u0BCD \u0B85\u0B9F\u0BCD\u0B9F\u0BC8 \u0B8E\u0BA3\u0BCD",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN",
    number: "\u0B8E\u0BA3\u0BCD",
    array: "\u0B85\u0BA3\u0BBF",
    null: "\u0BB5\u0BC6\u0BB1\u0BC1\u0BAE\u0BC8"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 instanceof ${r.expected}, \u0BAA\u0BC6\u0BB1\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${u}` : `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${i}, \u0BAA\u0BC6\u0BB1\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${$(r.values[0])}` : `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0BB5\u0BBF\u0BB0\u0BC1\u0BAA\u0BCD\u0BAA\u0BAE\u0BCD: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${h(r.values, "|")} \u0B87\u0BB2\u0BCD \u0B92\u0BA9\u0BCD\u0BB1\u0BC1`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `\u0BAE\u0BBF\u0B95 \u0BAA\u0BC6\u0BB0\u0BBF\u0BAF\u0BA4\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${r.origin ?? "\u0BAE\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1"} ${i}${r.maximum.toString()} ${a.unit ?? "\u0B89\u0BB1\u0BC1\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD"} \u0B86\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : `\u0BAE\u0BBF\u0B95 \u0BAA\u0BC6\u0BB0\u0BBF\u0BAF\u0BA4\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${r.origin ?? "\u0BAE\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1"} ${i}${r.maximum.toString()} \u0B86\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\u0BAE\u0BBF\u0B95\u0B9A\u0BCD \u0B9A\u0BBF\u0BB1\u0BBF\u0BAF\u0BA4\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${r.origin} ${i}${r.minimum.toString()} ${a.unit} \u0B86\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : `\u0BAE\u0BBF\u0B95\u0B9A\u0BCD \u0B9A\u0BBF\u0BB1\u0BBF\u0BAF\u0BA4\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${r.origin} ${i}${r.minimum.toString()} \u0B86\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B9A\u0BB0\u0BAE\u0BCD: "${i.prefix}" \u0B87\u0BB2\u0BCD \u0BA4\u0BCA\u0B9F\u0B99\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : i.format === "ends_with" ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B9A\u0BB0\u0BAE\u0BCD: "${i.suffix}" \u0B87\u0BB2\u0BCD \u0BAE\u0BC1\u0B9F\u0BBF\u0BB5\u0B9F\u0BC8\u0BAF \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : i.format === "includes" ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B9A\u0BB0\u0BAE\u0BCD: "${i.includes}" \u0B90 \u0B89\u0BB3\u0BCD\u0BB3\u0B9F\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : i.format === "regex" ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B9A\u0BB0\u0BAE\u0BCD: ${i.pattern} \u0BAE\u0BC1\u0BB1\u0BC8\u0BAA\u0BBE\u0B9F\u0BCD\u0B9F\u0BC1\u0B9F\u0BA9\u0BCD \u0BAA\u0BCA\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B8E\u0BA3\u0BCD: ${r.divisor} \u0B87\u0BA9\u0BCD \u0BAA\u0BB2\u0BAE\u0BBE\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD`;
      case "unrecognized_keys":
        return `\u0B85\u0B9F\u0BC8\u0BAF\u0BBE\u0BB3\u0BAE\u0BCD \u0BA4\u0BC6\u0BB0\u0BBF\u0BAF\u0BBE\u0BA4 \u0BB5\u0BBF\u0B9A\u0BC8${r.keys.length > 1 ? "\u0B95\u0BB3\u0BCD" : ""}: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `${r.origin} \u0B87\u0BB2\u0BCD \u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0BB5\u0BBF\u0B9A\u0BC8`;
      case "invalid_union":
        return "\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1";
      case "invalid_element":
        return `${r.origin} \u0B87\u0BB2\u0BCD \u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0BAE\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1`;
      default:
        return "\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1";
    }
  };
}, "error");
function vl() {
  return {
    localeError: Gb()
  };
}
s(vl, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/th.js
var Xb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0E15\u0E31\u0E27\u0E2D\u0E31\u0E01\u0E29\u0E23", verb: "\u0E04\u0E27\u0E23\u0E21\u0E35" },
    file: { unit: "\u0E44\u0E1A\u0E15\u0E4C", verb: "\u0E04\u0E27\u0E23\u0E21\u0E35" },
    array: { unit: "\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23", verb: "\u0E04\u0E27\u0E23\u0E21\u0E35" },
    set: { unit: "\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23", verb: "\u0E04\u0E27\u0E23\u0E21\u0E35" },
    map: { unit: "\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23", verb: "\u0E04\u0E27\u0E23\u0E21\u0E35" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E17\u0E35\u0E48\u0E1B\u0E49\u0E2D\u0E19",
    email: "\u0E17\u0E35\u0E48\u0E2D\u0E22\u0E39\u0E48\u0E2D\u0E35\u0E40\u0E21\u0E25",
    url: "URL",
    emoji: "\u0E2D\u0E34\u0E42\u0E21\u0E08\u0E34",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48\u0E40\u0E27\u0E25\u0E32\u0E41\u0E1A\u0E1A ISO",
    date: "\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48\u0E41\u0E1A\u0E1A ISO",
    time: "\u0E40\u0E27\u0E25\u0E32\u0E41\u0E1A\u0E1A ISO",
    duration: "\u0E0A\u0E48\u0E27\u0E07\u0E40\u0E27\u0E25\u0E32\u0E41\u0E1A\u0E1A ISO",
    ipv4: "\u0E17\u0E35\u0E48\u0E2D\u0E22\u0E39\u0E48 IPv4",
    ipv6: "\u0E17\u0E35\u0E48\u0E2D\u0E22\u0E39\u0E48 IPv6",
    mac: "\u0E17\u0E35\u0E48\u0E2D\u0E22\u0E39\u0E48 MAC",
    cidrv4: "\u0E0A\u0E48\u0E27\u0E07 IP \u0E41\u0E1A\u0E1A IPv4",
    cidrv6: "\u0E0A\u0E48\u0E27\u0E07 IP \u0E41\u0E1A\u0E1A IPv6",
    base64: "\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E41\u0E1A\u0E1A Base64",
    base64url: "\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E41\u0E1A\u0E1A Base64 \u0E2A\u0E33\u0E2B\u0E23\u0E31\u0E1A URL",
    json_string: "\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E41\u0E1A\u0E1A JSON",
    e164: "\u0E40\u0E1A\u0E2D\u0E23\u0E4C\u0E42\u0E17\u0E23\u0E28\u0E31\u0E1E\u0E17\u0E4C\u0E23\u0E30\u0E2B\u0E27\u0E48\u0E32\u0E07\u0E1B\u0E23\u0E30\u0E40\u0E17\u0E28 (E.164)",
    credit_card: "\u0E2B\u0E21\u0E32\u0E22\u0E40\u0E25\u0E02\u0E1A\u0E31\u0E15\u0E23\u0E40\u0E04\u0E23\u0E14\u0E34\u0E15",
    jwt: "\u0E42\u0E17\u0E40\u0E04\u0E19 JWT",
    template_literal: "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E17\u0E35\u0E48\u0E1B\u0E49\u0E2D\u0E19"
  }, o = {
    nan: "NaN",
    number: "\u0E15\u0E31\u0E27\u0E40\u0E25\u0E02",
    array: "\u0E2D\u0E32\u0E23\u0E4C\u0E40\u0E23\u0E22\u0E4C (Array)",
    null: "\u0E44\u0E21\u0E48\u0E21\u0E35\u0E04\u0E48\u0E32 (null)"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u0E1B\u0E23\u0E30\u0E40\u0E20\u0E17\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E04\u0E27\u0E23\u0E40\u0E1B\u0E47\u0E19 instanceof ${r.expected} \u0E41\u0E15\u0E48\u0E44\u0E14\u0E49\u0E23\u0E31\u0E1A ${u}` : `\u0E1B\u0E23\u0E30\u0E40\u0E20\u0E17\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E04\u0E27\u0E23\u0E40\u0E1B\u0E47\u0E19 ${i} \u0E41\u0E15\u0E48\u0E44\u0E14\u0E49\u0E23\u0E31\u0E1A ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u0E04\u0E48\u0E32\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E04\u0E27\u0E23\u0E40\u0E1B\u0E47\u0E19 ${$(r.values[0])}` : `\u0E15\u0E31\u0E27\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E04\u0E27\u0E23\u0E40\u0E1B\u0E47\u0E19\u0E2B\u0E19\u0E36\u0E48\u0E07\u0E43\u0E19 ${h(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "\u0E44\u0E21\u0E48\u0E40\u0E01\u0E34\u0E19" : "\u0E19\u0E49\u0E2D\u0E22\u0E01\u0E27\u0E48\u0E32", a = t(r.origin);
        return a ? `\u0E40\u0E01\u0E34\u0E19\u0E01\u0E33\u0E2B\u0E19\u0E14: ${r.origin ?? "\u0E04\u0E48\u0E32"} \u0E04\u0E27\u0E23\u0E21\u0E35${i} ${r.maximum.toString()} ${a.unit ?? "\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23"}` : `\u0E40\u0E01\u0E34\u0E19\u0E01\u0E33\u0E2B\u0E19\u0E14: ${r.origin ?? "\u0E04\u0E48\u0E32"} \u0E04\u0E27\u0E23\u0E21\u0E35${i} ${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? "\u0E2D\u0E22\u0E48\u0E32\u0E07\u0E19\u0E49\u0E2D\u0E22" : "\u0E21\u0E32\u0E01\u0E01\u0E27\u0E48\u0E32", a = t(r.origin);
        return a ? `\u0E19\u0E49\u0E2D\u0E22\u0E01\u0E27\u0E48\u0E32\u0E01\u0E33\u0E2B\u0E19\u0E14: ${r.origin} \u0E04\u0E27\u0E23\u0E21\u0E35${i} ${r.minimum.toString()} ${a.unit}` : `\u0E19\u0E49\u0E2D\u0E22\u0E01\u0E27\u0E48\u0E32\u0E01\u0E33\u0E2B\u0E19\u0E14: ${r.origin} \u0E04\u0E27\u0E23\u0E21\u0E35${i} ${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E15\u0E49\u0E2D\u0E07\u0E02\u0E36\u0E49\u0E19\u0E15\u0E49\u0E19\u0E14\u0E49\u0E27\u0E22 "${i.prefix}"` : i.format === "ends_with" ? `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E15\u0E49\u0E2D\u0E07\u0E25\u0E07\u0E17\u0E49\u0E32\u0E22\u0E14\u0E49\u0E27\u0E22 "${i.suffix}"` : i.format === "includes" ? `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E15\u0E49\u0E2D\u0E07\u0E21\u0E35 "${i.includes}" \u0E2D\u0E22\u0E39\u0E48\u0E43\u0E19\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21` : i.format === "regex" ? `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E15\u0E49\u0E2D\u0E07\u0E15\u0E23\u0E07\u0E01\u0E31\u0E1A\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E17\u0E35\u0E48\u0E01\u0E33\u0E2B\u0E19\u0E14 ${i.pattern}` : `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u0E15\u0E31\u0E27\u0E40\u0E25\u0E02\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E15\u0E49\u0E2D\u0E07\u0E40\u0E1B\u0E47\u0E19\u0E08\u0E33\u0E19\u0E27\u0E19\u0E17\u0E35\u0E48\u0E2B\u0E32\u0E23\u0E14\u0E49\u0E27\u0E22 ${r.divisor} \u0E44\u0E14\u0E49\u0E25\u0E07\u0E15\u0E31\u0E27`;
      case "unrecognized_keys":
        return `\u0E1E\u0E1A\u0E04\u0E35\u0E22\u0E4C\u0E17\u0E35\u0E48\u0E44\u0E21\u0E48\u0E23\u0E39\u0E49\u0E08\u0E31\u0E01: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `\u0E04\u0E35\u0E22\u0E4C\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07\u0E43\u0E19 ${r.origin}`;
      case "invalid_union":
        return "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E44\u0E21\u0E48\u0E15\u0E23\u0E07\u0E01\u0E31\u0E1A\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E22\u0E39\u0E40\u0E19\u0E35\u0E22\u0E19\u0E17\u0E35\u0E48\u0E01\u0E33\u0E2B\u0E19\u0E14\u0E44\u0E27\u0E49";
      case "invalid_element":
        return `\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07\u0E43\u0E19 ${r.origin}`;
      default:
        return "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07";
    }
  };
}, "error");
function yl() {
  return {
    localeError: Xb()
  };
}
s(yl, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/tk.js
var Hb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "simwol", verb: "bolmaly" },
    file: { unit: "ba\xFDt", verb: "bolmaly" },
    array: { unit: "elementler", verb: "bolmaly" },
    set: { unit: "elementler", verb: "bolmaly" },
    map: { unit: "elementler", verb: "bolmaly" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "giri\u015F",
    email: "e-po\xE7ta salgysy",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO sene we wagt",
    date: "ISO sene",
    time: "ISO wagt",
    duration: "ISO wagt aralygy",
    ipv4: "IPv4 salgysy",
    ipv6: "IPv6 salgysy",
    mac: "MAC salgysy",
    cidrv4: "IPv4 aralygy",
    cidrv6: "IPv6 aralygy",
    base64: "base64 bilen \u015Fifrlenen setir",
    base64url: "base64url bilen \u015Fifrlenen setir",
    json_string: "JSON setiri",
    e164: "E.164 nomeri",
    credit_card: "kredit kartyny\u0148 nomeri",
    jwt: "JWT",
    template_literal: "\u015Fablon"
  }, o = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return `N\xE4dogry baha: gara\u015Fylan ${i} \xFDerine ${u} alyndy`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `N\xE4dogry baha: ${$(r.values[0])} bolmaly` : `N\xE4dogry sa\xFDlaw: a\u015Fakdakylardan biri bolmaly: ${h(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Has uly: gara\u015Fyl\xFDan ${r.origin ?? "baha"} ${i} ${r.maximum.toString()} ${a.unit ?? "element"}` : `Has uly: gara\u015Fyl\xFDan ${r.origin ?? "baha"} ${i} ${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Has ki\xE7i: gara\u015Fyl\xFDan ${r.origin} ${i} ${r.minimum.toString()} ${a.unit}` : `Has ki\xE7i: gara\u015Fyl\xFDan ${r.origin} ${i} ${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `N\xE4dogry setir: "${i.prefix}" bilen ba\u015Flamaly` : i.format === "ends_with" ? `N\xE4dogry setir: "${i.suffix}" bilen gutarmaly` : i.format === "includes" ? `N\xE4dogry setir: "${i.includes}" saklamaly` : i.format === "regex" ? `N\xE4dogry setir: ${i.pattern} nusga la\xFDyk bolmaly` : `N\xE4dogry ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `N\xE4dogry san: ${r.divisor} bilen galyndysyz b\xF6l\xFCnmeli`;
      case "unrecognized_keys":
        return `Tanalma\xFDan a\xE7ar${r.keys.length > 1 ? "lar" : ""}: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `${r.origin} i\xE7inde n\xE4dogry a\xE7ar`;
      case "invalid_union":
        return "N\xE4dogry baha";
      case "invalid_element":
        return `${r.origin} i\xE7inde n\xE4dogry baha`;
      default:
        return "N\xE4dogry baha";
    }
  };
}, "error");
function $l() {
  return {
    localeError: Hb()
  };
}
s($l, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/tr.js
var Qb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "karakter", verb: "olmal\u0131" },
    file: { unit: "bayt", verb: "olmal\u0131" },
    array: { unit: "\xF6\u011Fe", verb: "olmal\u0131" },
    set: { unit: "\xF6\u011Fe", verb: "olmal\u0131" },
    map: { unit: "\xF6\u011Fe", verb: "olmal\u0131" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "girdi",
    email: "e-posta adresi",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO tarih ve saat",
    date: "ISO tarih",
    time: "ISO saat",
    duration: "ISO s\xFCre",
    ipv4: "IPv4 adresi",
    ipv6: "IPv6 adresi",
    mac: "MAC adresi",
    cidrv4: "IPv4 aral\u0131\u011F\u0131",
    cidrv6: "IPv6 aral\u0131\u011F\u0131",
    base64: "base64 ile \u015Fifrelenmi\u015F metin",
    base64url: "base64url ile \u015Fifrelenmi\u015F metin",
    json_string: "JSON dizesi",
    e164: "E.164 say\u0131s\u0131",
    credit_card: "kredi kart\u0131 numaras\u0131",
    jwt: "JWT",
    template_literal: "\u015Eablon dizesi"
  }, o = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Ge\xE7ersiz de\u011Fer: beklenen instanceof ${r.expected}, al\u0131nan ${u}` : `Ge\xE7ersiz de\u011Fer: beklenen ${i}, al\u0131nan ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Ge\xE7ersiz de\u011Fer: beklenen ${$(r.values[0])}` : `Ge\xE7ersiz se\xE7enek: a\u015Fa\u011F\u0131dakilerden biri olmal\u0131: ${h(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `\xC7ok b\xFCy\xFCk: beklenen ${r.origin ?? "de\u011Fer"} ${i}${r.maximum.toString()} ${a.unit ?? "\xF6\u011Fe"}` : `\xC7ok b\xFCy\xFCk: beklenen ${r.origin ?? "de\u011Fer"} ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\xC7ok k\xFC\xE7\xFCk: beklenen ${r.origin} ${i}${r.minimum.toString()} ${a.unit}` : `\xC7ok k\xFC\xE7\xFCk: beklenen ${r.origin} ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Ge\xE7ersiz metin: "${i.prefix}" ile ba\u015Flamal\u0131` : i.format === "ends_with" ? `Ge\xE7ersiz metin: "${i.suffix}" ile bitmeli` : i.format === "includes" ? `Ge\xE7ersiz metin: "${i.includes}" i\xE7ermeli` : i.format === "regex" ? `Ge\xE7ersiz metin: ${i.pattern} desenine uymal\u0131` : `Ge\xE7ersiz ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Ge\xE7ersiz say\u0131: ${r.divisor} ile tam b\xF6l\xFCnebilmeli`;
      case "unrecognized_keys":
        return `Tan\u0131nmayan anahtar${r.keys.length > 1 ? "lar" : ""}: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `${r.origin} i\xE7inde ge\xE7ersiz anahtar`;
      case "invalid_union":
        return "Ge\xE7ersiz de\u011Fer";
      case "invalid_element":
        return `${r.origin} i\xE7inde ge\xE7ersiz de\u011Fer`;
      default:
        return "Ge\xE7ersiz de\u011Fer";
    }
  };
}, "error");
function bl() {
  return {
    localeError: Qb()
  };
}
s(bl, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/uk.js
var Yb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0441\u0438\u043C\u0432\u043E\u043B\u0456\u0432", verb: "\u043C\u0430\u0442\u0438\u043C\u0435" },
    file: { unit: "\u0431\u0430\u0439\u0442\u0456\u0432", verb: "\u043C\u0430\u0442\u0438\u043C\u0435" },
    array: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0456\u0432", verb: "\u043C\u0430\u0442\u0438\u043C\u0435" },
    set: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0456\u0432", verb: "\u043C\u0430\u0442\u0438\u043C\u0435" },
    map: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0456\u0432", verb: "\u043C\u0430\u0442\u0438\u043C\u0435" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456",
    email: "\u0430\u0434\u0440\u0435\u0441\u0430 \u0435\u043B\u0435\u043A\u0442\u0440\u043E\u043D\u043D\u043E\u0457 \u043F\u043E\u0448\u0442\u0438",
    url: "URL",
    emoji: "\u0435\u043C\u043E\u0434\u0437\u0456",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u0434\u0430\u0442\u0430 \u0442\u0430 \u0447\u0430\u0441 ISO",
    date: "\u0434\u0430\u0442\u0430 ISO",
    time: "\u0447\u0430\u0441 ISO",
    duration: "\u0442\u0440\u0438\u0432\u0430\u043B\u0456\u0441\u0442\u044C ISO",
    ipv4: "\u0430\u0434\u0440\u0435\u0441\u0430 IPv4",
    ipv6: "\u0430\u0434\u0440\u0435\u0441\u0430 IPv6",
    mac: "\u0430\u0434\u0440\u0435\u0441\u0430 MAC",
    cidrv4: "\u0434\u0456\u0430\u043F\u0430\u0437\u043E\u043D IPv4",
    cidrv6: "\u0434\u0456\u0430\u043F\u0430\u0437\u043E\u043D IPv6",
    base64: "\u0440\u044F\u0434\u043E\u043A \u0443 \u043A\u043E\u0434\u0443\u0432\u0430\u043D\u043D\u0456 base64",
    base64url: "\u0440\u044F\u0434\u043E\u043A \u0443 \u043A\u043E\u0434\u0443\u0432\u0430\u043D\u043D\u0456 base64url",
    json_string: "\u0440\u044F\u0434\u043E\u043A JSON",
    e164: "\u043D\u043E\u043C\u0435\u0440 E.164",
    credit_card: "\u043D\u043E\u043C\u0435\u0440 \u043A\u0440\u0435\u0434\u0438\u0442\u043D\u043E\u0457 \u043A\u0430\u0440\u0442\u043A\u0438",
    jwt: "JWT",
    template_literal: "\u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456"
  }, o = {
    nan: "NaN",
    number: "\u0447\u0438\u0441\u043B\u043E",
    array: "\u043C\u0430\u0441\u0438\u0432"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F instanceof ${r.expected}, \u043E\u0442\u0440\u0438\u043C\u0430\u043D\u043E ${u}` : `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F ${i}, \u043E\u0442\u0440\u0438\u043C\u0430\u043D\u043E ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F ${$(r.values[0])}` : `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0430 \u043E\u043F\u0446\u0456\u044F: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F \u043E\u0434\u043D\u0435 \u0437 ${h(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `\u0417\u0430\u043D\u0430\u0434\u0442\u043E \u0432\u0435\u043B\u0438\u043A\u0435: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F, \u0449\u043E ${r.origin ?? "\u0437\u043D\u0430\u0447\u0435\u043D\u043D\u044F"} ${a.verb} ${i}${r.maximum.toString()} ${a.unit ?? "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0456\u0432"}` : `\u0417\u0430\u043D\u0430\u0434\u0442\u043E \u0432\u0435\u043B\u0438\u043A\u0435: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F, \u0449\u043E ${r.origin ?? "\u0437\u043D\u0430\u0447\u0435\u043D\u043D\u044F"} \u0431\u0443\u0434\u0435 ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\u0417\u0430\u043D\u0430\u0434\u0442\u043E \u043C\u0430\u043B\u0435: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F, \u0449\u043E ${r.origin} ${a.verb} ${i}${r.minimum.toString()} ${a.unit}` : `\u0417\u0430\u043D\u0430\u0434\u0442\u043E \u043C\u0430\u043B\u0435: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F, \u0449\u043E ${r.origin} \u0431\u0443\u0434\u0435 ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u0440\u044F\u0434\u043E\u043A: \u043F\u043E\u0432\u0438\u043D\u0435\u043D \u043F\u043E\u0447\u0438\u043D\u0430\u0442\u0438\u0441\u044F \u0437 "${i.prefix}"` : i.format === "ends_with" ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u0440\u044F\u0434\u043E\u043A: \u043F\u043E\u0432\u0438\u043D\u0435\u043D \u0437\u0430\u043A\u0456\u043D\u0447\u0443\u0432\u0430\u0442\u0438\u0441\u044F \u043D\u0430 "${i.suffix}"` : i.format === "includes" ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u0440\u044F\u0434\u043E\u043A: \u043F\u043E\u0432\u0438\u043D\u0435\u043D \u043C\u0456\u0441\u0442\u0438\u0442\u0438 "${i.includes}"` : i.format === "regex" ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u0440\u044F\u0434\u043E\u043A: \u043F\u043E\u0432\u0438\u043D\u0435\u043D \u0432\u0456\u0434\u043F\u043E\u0432\u0456\u0434\u0430\u0442\u0438 \u0448\u0430\u0431\u043B\u043E\u043D\u0443 ${i.pattern}` : `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0435 \u0447\u0438\u0441\u043B\u043E: \u043F\u043E\u0432\u0438\u043D\u043D\u043E \u0431\u0443\u0442\u0438 \u043A\u0440\u0430\u0442\u043D\u0438\u043C ${r.divisor}`;
      case "unrecognized_keys":
        return `\u041D\u0435\u0440\u043E\u0437\u043F\u0456\u0437\u043D\u0430\u043D\u0438\u0439 \u043A\u043B\u044E\u0447${r.keys.length > 1 ? "\u0456" : ""}: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u043A\u043B\u044E\u0447 \u0443 ${r.origin}`;
      case "invalid_union":
        return "\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456";
      case "invalid_element":
        return `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u043D\u044F \u0443 ${r.origin}`;
      default:
        return "\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456";
    }
  };
}, "error");
function fn() {
  return {
    localeError: Yb()
  };
}
s(fn, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ua.js
function _l() {
  return fn();
}
s(_l, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ur.js
var e_ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u062D\u0631\u0648\u0641", verb: "\u06C1\u0648\u0646\u0627" },
    file: { unit: "\u0628\u0627\u0626\u0679\u0633", verb: "\u06C1\u0648\u0646\u0627" },
    array: { unit: "\u0622\u0626\u0679\u0645\u0632", verb: "\u06C1\u0648\u0646\u0627" },
    set: { unit: "\u0622\u0626\u0679\u0645\u0632", verb: "\u06C1\u0648\u0646\u0627" },
    map: { unit: "\u0622\u0626\u0679\u0645\u0632", verb: "\u06C1\u0648\u0646\u0627" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u0627\u0646 \u067E\u0679",
    email: "\u0627\u06CC \u0645\u06CC\u0644 \u0627\u06CC\u0688\u0631\u06CC\u0633",
    url: "\u06CC\u0648 \u0622\u0631 \u0627\u06CC\u0644",
    emoji: "\u0627\u06CC\u0645\u0648\u062C\u06CC",
    uuid: "\u06CC\u0648 \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC",
    uuidv4: "\u06CC\u0648 \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC \u0648\u06CC 4",
    uuidv6: "\u06CC\u0648 \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC \u0648\u06CC 6",
    nanoid: "\u0646\u06CC\u0646\u0648 \u0622\u0626\u06CC \u0688\u06CC",
    guid: "\u062C\u06CC \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC",
    cuid: "\u0633\u06CC \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC",
    cuid2: "\u0633\u06CC \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC 2",
    ulid: "\u06CC\u0648 \u0627\u06CC\u0644 \u0622\u0626\u06CC \u0688\u06CC",
    xid: "\u0627\u06CC\u06A9\u0633 \u0622\u0626\u06CC \u0688\u06CC",
    ksuid: "\u06A9\u06D2 \u0627\u06CC\u0633 \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC",
    datetime: "\u0622\u0626\u06CC \u0627\u06CC\u0633 \u0627\u0648 \u0688\u06CC\u0679 \u0679\u0627\u0626\u0645",
    date: "\u0622\u0626\u06CC \u0627\u06CC\u0633 \u0627\u0648 \u062A\u0627\u0631\u06CC\u062E",
    time: "\u0622\u0626\u06CC \u0627\u06CC\u0633 \u0627\u0648 \u0648\u0642\u062A",
    duration: "\u0622\u0626\u06CC \u0627\u06CC\u0633 \u0627\u0648 \u0645\u062F\u062A",
    ipv4: "\u0622\u0626\u06CC \u067E\u06CC \u0648\u06CC 4 \u0627\u06CC\u0688\u0631\u06CC\u0633",
    ipv6: "\u0622\u0626\u06CC \u067E\u06CC \u0648\u06CC 6 \u0627\u06CC\u0688\u0631\u06CC\u0633",
    mac: "\u0627\u06CC\u0645 \u0627\u06D2 \u0633\u06CC \u0627\u06CC\u0688\u0631\u06CC\u0633",
    cidrv4: "\u0622\u0626\u06CC \u067E\u06CC \u0648\u06CC 4 \u0631\u06CC\u0646\u062C",
    cidrv6: "\u0622\u0626\u06CC \u067E\u06CC \u0648\u06CC 6 \u0631\u06CC\u0646\u062C",
    base64: "\u0628\u06CC\u0633 64 \u0627\u0646 \u06A9\u0648\u0688\u0688 \u0633\u0679\u0631\u0646\u06AF",
    base64url: "\u0628\u06CC\u0633 64 \u06CC\u0648 \u0622\u0631 \u0627\u06CC\u0644 \u0627\u0646 \u06A9\u0648\u0688\u0688 \u0633\u0679\u0631\u0646\u06AF",
    json_string: "\u062C\u06D2 \u0627\u06CC\u0633 \u0627\u0648 \u0627\u06CC\u0646 \u0633\u0679\u0631\u0646\u06AF",
    e164: "\u0627\u06CC 164 \u0646\u0645\u0628\u0631",
    credit_card: "\u06A9\u0631\u06CC\u0688\u0679 \u06A9\u0627\u0631\u0688 \u0646\u0645\u0628\u0631",
    jwt: "\u062C\u06D2 \u0688\u0628\u0644\u06CC\u0648 \u0679\u06CC",
    template_literal: "\u0627\u0646 \u067E\u0679"
  }, o = {
    nan: "NaN",
    number: "\u0646\u0645\u0628\u0631",
    array: "\u0622\u0631\u06D2",
    null: "\u0646\u0644"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679: instanceof ${r.expected} \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627\u060C ${u} \u0645\u0648\u0635\u0648\u0644 \u06C1\u0648\u0627` : `\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679: ${i} \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627\u060C ${u} \u0645\u0648\u0635\u0648\u0644 \u06C1\u0648\u0627`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679: ${$(r.values[0])} \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627` : `\u063A\u0644\u0637 \u0622\u067E\u0634\u0646: ${h(r.values, "|")} \u0645\u06CC\u06BA \u0633\u06D2 \u0627\u06CC\u06A9 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `\u0628\u06C1\u062A \u0628\u0691\u0627: ${r.origin ?? "\u0648\u06CC\u0644\u06CC\u0648"} \u06A9\u06D2 ${i}${r.maximum.toString()} ${a.unit ?? "\u0639\u0646\u0627\u0635\u0631"} \u06C1\u0648\u0646\u06D2 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u06D2` : `\u0628\u06C1\u062A \u0628\u0691\u0627: ${r.origin ?? "\u0648\u06CC\u0644\u06CC\u0648"} \u06A9\u0627 ${i}${r.maximum.toString()} \u06C1\u0648\u0646\u0627 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\u0628\u06C1\u062A \u0686\u06BE\u0648\u0679\u0627: ${r.origin} \u06A9\u06D2 ${i}${r.minimum.toString()} ${a.unit} \u06C1\u0648\u0646\u06D2 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u06D2` : `\u0628\u06C1\u062A \u0686\u06BE\u0648\u0679\u0627: ${r.origin} \u06A9\u0627 ${i}${r.minimum.toString()} \u06C1\u0648\u0646\u0627 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u063A\u0644\u0637 \u0633\u0679\u0631\u0646\u06AF: "${i.prefix}" \u0633\u06D2 \u0634\u0631\u0648\u0639 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2` : i.format === "ends_with" ? `\u063A\u0644\u0637 \u0633\u0679\u0631\u0646\u06AF: "${i.suffix}" \u067E\u0631 \u062E\u062A\u0645 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2` : i.format === "includes" ? `\u063A\u0644\u0637 \u0633\u0679\u0631\u0646\u06AF: "${i.includes}" \u0634\u0627\u0645\u0644 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2` : i.format === "regex" ? `\u063A\u0644\u0637 \u0633\u0679\u0631\u0646\u06AF: \u067E\u06CC\u0679\u0631\u0646 ${i.pattern} \u0633\u06D2 \u0645\u06CC\u0686 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2` : `\u063A\u0644\u0637 ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u063A\u0644\u0637 \u0646\u0645\u0628\u0631: ${r.divisor} \u06A9\u0627 \u0645\u0636\u0627\u0639\u0641 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2`;
      case "unrecognized_keys":
        return `\u063A\u06CC\u0631 \u062A\u0633\u0644\u06CC\u0645 \u0634\u062F\u06C1 \u06A9\u06CC${r.keys.length > 1 ? "\u0632" : ""}: ${h(r.keys, "\u060C ")}`;
      case "invalid_key":
        return `${r.origin} \u0645\u06CC\u06BA \u063A\u0644\u0637 \u06A9\u06CC`;
      case "invalid_union":
        return "\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679";
      case "invalid_element":
        return `${r.origin} \u0645\u06CC\u06BA \u063A\u0644\u0637 \u0648\u06CC\u0644\u06CC\u0648`;
      default:
        return "\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679";
    }
  };
}, "error");
function xl() {
  return {
    localeError: e_()
  };
}
s(xl, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/uz.js
var t_ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "belgi", verb: "bo\u2018lishi kerak" },
    file: { unit: "bayt", verb: "bo\u2018lishi kerak" },
    array: { unit: "element", verb: "bo\u2018lishi kerak" },
    set: { unit: "element", verb: "bo\u2018lishi kerak" },
    map: { unit: "yozuv", verb: "bo\u2018lishi kerak" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "kirish",
    email: "elektron pochta manzili",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO sana va vaqti",
    date: "ISO sana",
    time: "ISO vaqt",
    duration: "ISO davomiylik",
    ipv4: "IPv4 manzil",
    ipv6: "IPv6 manzil",
    mac: "MAC manzil",
    cidrv4: "IPv4 diapazon",
    cidrv6: "IPv6 diapazon",
    base64: "base64 kodlangan satr",
    base64url: "base64url kodlangan satr",
    json_string: "JSON satr",
    e164: "E.164 raqam",
    credit_card: "kredit karta raqami",
    jwt: "JWT",
    template_literal: "kirish"
  }, o = {
    nan: "NaN",
    number: "raqam",
    array: "massiv"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `Noto\u2018g\u2018ri kirish: kutilgan instanceof ${r.expected}, qabul qilingan ${u}` : `Noto\u2018g\u2018ri kirish: kutilgan ${i}, qabul qilingan ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Noto\u2018g\u2018ri kirish: kutilgan ${$(r.values[0])}` : `Noto\u2018g\u2018ri variant: quyidagilardan biri kutilgan ${h(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Juda katta: kutilgan ${r.origin ?? "qiymat"} ${i}${r.maximum.toString()} ${a.unit} ${a.verb}` : `Juda katta: kutilgan ${r.origin ?? "qiymat"} ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Juda kichik: kutilgan ${r.origin} ${i}${r.minimum.toString()} ${a.unit} ${a.verb}` : `Juda kichik: kutilgan ${r.origin} ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Noto\u2018g\u2018ri satr: "${i.prefix}" bilan boshlanishi kerak` : i.format === "ends_with" ? `Noto\u2018g\u2018ri satr: "${i.suffix}" bilan tugashi kerak` : i.format === "includes" ? `Noto\u2018g\u2018ri satr: "${i.includes}" ni o\u2018z ichiga olishi kerak` : i.format === "regex" ? `Noto\u2018g\u2018ri satr: ${i.pattern} shabloniga mos kelishi kerak` : `Noto\u2018g\u2018ri ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Noto\u2018g\u2018ri raqam: ${r.divisor} ning karralisi bo\u2018lishi kerak`;
      case "unrecognized_keys":
        return `Noma\u2019lum kalit${r.keys.length > 1 ? "lar" : ""}: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `${r.origin} dagi kalit noto\u2018g\u2018ri`;
      case "invalid_union":
        return "Noto\u2018g\u2018ri kirish";
      case "invalid_element":
        return `${r.origin} da noto\u2018g\u2018ri qiymat`;
      default:
        return "Noto\u2018g\u2018ri kirish";
    }
  };
}, "error");
function wl() {
  return {
    localeError: t_()
  };
}
s(wl, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/vi.js
var r_ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "k\xFD t\u1EF1", verb: "c\xF3" },
    file: { unit: "byte", verb: "c\xF3" },
    array: { unit: "ph\u1EA7n t\u1EED", verb: "c\xF3" },
    set: { unit: "ph\u1EA7n t\u1EED", verb: "c\xF3" },
    map: { unit: "ph\u1EA7n t\u1EED", verb: "c\xF3" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u0111\u1EA7u v\xE0o",
    email: "\u0111\u1ECBa ch\u1EC9 email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ng\xE0y gi\u1EDD ISO",
    date: "ng\xE0y ISO",
    time: "gi\u1EDD ISO",
    duration: "kho\u1EA3ng th\u1EDDi gian ISO",
    ipv4: "\u0111\u1ECBa ch\u1EC9 IPv4",
    ipv6: "\u0111\u1ECBa ch\u1EC9 IPv6",
    mac: "\u0111\u1ECBa ch\u1EC9 MAC",
    cidrv4: "d\u1EA3i IPv4",
    cidrv6: "d\u1EA3i IPv6",
    base64: "chu\u1ED7i m\xE3 h\xF3a base64",
    base64url: "chu\u1ED7i m\xE3 h\xF3a base64url",
    json_string: "chu\u1ED7i JSON",
    e164: "s\u1ED1 E.164",
    credit_card: "s\u1ED1 th\u1EBB t\xEDn d\u1EE5ng",
    jwt: "JWT",
    template_literal: "\u0111\u1EA7u v\xE0o"
  }, o = {
    nan: "NaN",
    number: "s\u1ED1",
    array: "m\u1EA3ng"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7: mong \u0111\u1EE3i instanceof ${r.expected}, nh\u1EADn \u0111\u01B0\u1EE3c ${u}` : `\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7: mong \u0111\u1EE3i ${i}, nh\u1EADn \u0111\u01B0\u1EE3c ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7: mong \u0111\u1EE3i ${$(r.values[0])}` : `T\xF9y ch\u1ECDn kh\xF4ng h\u1EE3p l\u1EC7: mong \u0111\u1EE3i m\u1ED9t trong c\xE1c gi\xE1 tr\u1ECB ${h(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Qu\xE1 l\u1EDBn: mong \u0111\u1EE3i ${r.origin ?? "gi\xE1 tr\u1ECB"} ${a.verb} ${i}${r.maximum.toString()} ${a.unit ?? "ph\u1EA7n t\u1EED"}` : `Qu\xE1 l\u1EDBn: mong \u0111\u1EE3i ${r.origin ?? "gi\xE1 tr\u1ECB"} ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Qu\xE1 nh\u1ECF: mong \u0111\u1EE3i ${r.origin} ${a.verb} ${i}${r.minimum.toString()} ${a.unit}` : `Qu\xE1 nh\u1ECF: mong \u0111\u1EE3i ${r.origin} ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `Chu\u1ED7i kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i b\u1EAFt \u0111\u1EA7u b\u1EB1ng "${i.prefix}"` : i.format === "ends_with" ? `Chu\u1ED7i kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i k\u1EBFt th\xFAc b\u1EB1ng "${i.suffix}"` : i.format === "includes" ? `Chu\u1ED7i kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i bao g\u1ED3m "${i.includes}"` : i.format === "regex" ? `Chu\u1ED7i kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i kh\u1EDBp v\u1EDBi m\u1EABu ${i.pattern}` : `${n[i.format] ?? r.format} kh\xF4ng h\u1EE3p l\u1EC7`;
      }
      case "not_multiple_of":
        return `S\u1ED1 kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i l\xE0 b\u1ED9i s\u1ED1 c\u1EE7a ${r.divisor}`;
      case "unrecognized_keys":
        return `Kh\xF3a kh\xF4ng \u0111\u01B0\u1EE3c nh\u1EADn d\u1EA1ng: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `Kh\xF3a kh\xF4ng h\u1EE3p l\u1EC7 trong ${r.origin}`;
      case "invalid_union":
        return "\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7";
      case "invalid_element":
        return `Gi\xE1 tr\u1ECB kh\xF4ng h\u1EE3p l\u1EC7 trong ${r.origin}`;
      default:
        return "\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7";
    }
  };
}, "error");
function kl() {
  return {
    localeError: r_()
  };
}
s(kl, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/zh-CN.js
var n_ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u5B57\u7B26", verb: "\u5305\u542B" },
    file: { unit: "\u5B57\u8282", verb: "\u5305\u542B" },
    array: { unit: "\u9879", verb: "\u5305\u542B" },
    set: { unit: "\u9879", verb: "\u5305\u542B" },
    map: { unit: "\u9879", verb: "\u5305\u542B" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u8F93\u5165",
    email: "\u7535\u5B50\u90AE\u4EF6",
    url: "URL",
    emoji: "\u8868\u60C5\u7B26\u53F7",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO\u65E5\u671F\u65F6\u95F4",
    date: "ISO\u65E5\u671F",
    time: "ISO\u65F6\u95F4",
    duration: "ISO\u65F6\u957F",
    ipv4: "IPv4\u5730\u5740",
    ipv6: "IPv6\u5730\u5740",
    mac: "MAC\u5730\u5740",
    cidrv4: "IPv4\u7F51\u6BB5",
    cidrv6: "IPv6\u7F51\u6BB5",
    base64: "base64\u7F16\u7801\u5B57\u7B26\u4E32",
    base64url: "base64url\u7F16\u7801\u5B57\u7B26\u4E32",
    json_string: "JSON\u5B57\u7B26\u4E32",
    e164: "E.164\u53F7\u7801",
    credit_card: "\u4FE1\u7528\u5361\u53F7",
    jwt: "JWT",
    template_literal: "\u8F93\u5165"
  }, o = {
    nan: "NaN",
    number: "\u6570\u5B57",
    array: "\u6570\u7EC4",
    null: "\u7A7A\u503C(null)"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u65E0\u6548\u8F93\u5165\uFF1A\u671F\u671B instanceof ${r.expected}\uFF0C\u5B9E\u9645\u63A5\u6536 ${u}` : `\u65E0\u6548\u8F93\u5165\uFF1A\u671F\u671B ${i}\uFF0C\u5B9E\u9645\u63A5\u6536 ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u65E0\u6548\u8F93\u5165\uFF1A\u671F\u671B ${$(r.values[0])}` : `\u65E0\u6548\u9009\u9879\uFF1A\u671F\u671B\u4EE5\u4E0B\u4E4B\u4E00 ${h(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `\u6570\u503C\u8FC7\u5927\uFF1A\u671F\u671B ${r.origin ?? "\u503C"} ${i}${r.maximum.toString()} ${a.unit ?? "\u4E2A\u5143\u7D20"}` : `\u6570\u503C\u8FC7\u5927\uFF1A\u671F\u671B ${r.origin ?? "\u503C"} ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\u6570\u503C\u8FC7\u5C0F\uFF1A\u671F\u671B ${r.origin} ${i}${r.minimum.toString()} ${a.unit}` : `\u6570\u503C\u8FC7\u5C0F\uFF1A\u671F\u671B ${r.origin} ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u65E0\u6548\u5B57\u7B26\u4E32\uFF1A\u5FC5\u987B\u4EE5 "${i.prefix}" \u5F00\u5934` : i.format === "ends_with" ? `\u65E0\u6548\u5B57\u7B26\u4E32\uFF1A\u5FC5\u987B\u4EE5 "${i.suffix}" \u7ED3\u5C3E` : i.format === "includes" ? `\u65E0\u6548\u5B57\u7B26\u4E32\uFF1A\u5FC5\u987B\u5305\u542B "${i.includes}"` : i.format === "regex" ? `\u65E0\u6548\u5B57\u7B26\u4E32\uFF1A\u5FC5\u987B\u6EE1\u8DB3\u6B63\u5219\u8868\u8FBE\u5F0F ${i.pattern}` : `\u65E0\u6548${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u65E0\u6548\u6570\u5B57\uFF1A\u5FC5\u987B\u662F ${r.divisor} \u7684\u500D\u6570`;
      case "unrecognized_keys":
        return `\u51FA\u73B0\u672A\u77E5\u7684\u952E(key): ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `${r.origin} \u4E2D\u7684\u952E(key)\u65E0\u6548`;
      case "invalid_union":
        return "\u65E0\u6548\u8F93\u5165";
      case "invalid_element":
        return `${r.origin} \u4E2D\u5305\u542B\u65E0\u6548\u503C(value)`;
      default:
        return "\u65E0\u6548\u8F93\u5165";
    }
  };
}, "error");
function Il() {
  return {
    localeError: n_()
  };
}
s(Il, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/zh-TW.js
var i_ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u5B57\u5143", verb: "\u64C1\u6709" },
    file: { unit: "\u4F4D\u5143\u7D44", verb: "\u64C1\u6709" },
    array: { unit: "\u9805\u76EE", verb: "\u64C1\u6709" },
    set: { unit: "\u9805\u76EE", verb: "\u64C1\u6709" },
    map: { unit: "\u9805\u76EE", verb: "\u64C1\u6709" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u8F38\u5165",
    email: "\u90F5\u4EF6\u5730\u5740",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u65E5\u671F\u6642\u9593",
    date: "ISO \u65E5\u671F",
    time: "ISO \u6642\u9593",
    duration: "ISO \u671F\u9593",
    ipv4: "IPv4 \u4F4D\u5740",
    ipv6: "IPv6 \u4F4D\u5740",
    mac: "MAC \u4F4D\u5740",
    cidrv4: "IPv4 \u7BC4\u570D",
    cidrv6: "IPv6 \u7BC4\u570D",
    base64: "base64 \u7DE8\u78BC\u5B57\u4E32",
    base64url: "base64url \u7DE8\u78BC\u5B57\u4E32",
    json_string: "JSON \u5B57\u4E32",
    e164: "E.164 \u6578\u503C",
    credit_card: "\u4FE1\u7528\u5361\u865F",
    jwt: "JWT",
    template_literal: "\u8F38\u5165"
  }, o = {
    nan: "NaN"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\u7121\u6548\u7684\u8F38\u5165\u503C\uFF1A\u9810\u671F\u70BA instanceof ${r.expected}\uFF0C\u4F46\u6536\u5230 ${u}` : `\u7121\u6548\u7684\u8F38\u5165\u503C\uFF1A\u9810\u671F\u70BA ${i}\uFF0C\u4F46\u6536\u5230 ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\u7121\u6548\u7684\u8F38\u5165\u503C\uFF1A\u9810\u671F\u70BA ${$(r.values[0])}` : `\u7121\u6548\u7684\u9078\u9805\uFF1A\u9810\u671F\u70BA\u4EE5\u4E0B\u5176\u4E2D\u4E4B\u4E00 ${h(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `\u6578\u503C\u904E\u5927\uFF1A\u9810\u671F ${r.origin ?? "\u503C"} \u61C9\u70BA ${i}${r.maximum.toString()} ${a.unit ?? "\u500B\u5143\u7D20"}` : `\u6578\u503C\u904E\u5927\uFF1A\u9810\u671F ${r.origin ?? "\u503C"} \u61C9\u70BA ${i}${r.maximum.toString()}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `\u6578\u503C\u904E\u5C0F\uFF1A\u9810\u671F ${r.origin} \u61C9\u70BA ${i}${r.minimum.toString()} ${a.unit}` : `\u6578\u503C\u904E\u5C0F\uFF1A\u9810\u671F ${r.origin} \u61C9\u70BA ${i}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u7121\u6548\u7684\u5B57\u4E32\uFF1A\u5FC5\u9808\u4EE5 "${i.prefix}" \u958B\u982D` : i.format === "ends_with" ? `\u7121\u6548\u7684\u5B57\u4E32\uFF1A\u5FC5\u9808\u4EE5 "${i.suffix}" \u7D50\u5C3E` : i.format === "includes" ? `\u7121\u6548\u7684\u5B57\u4E32\uFF1A\u5FC5\u9808\u5305\u542B "${i.includes}"` : i.format === "regex" ? `\u7121\u6548\u7684\u5B57\u4E32\uFF1A\u5FC5\u9808\u7B26\u5408\u683C\u5F0F ${i.pattern}` : `\u7121\u6548\u7684 ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `\u7121\u6548\u7684\u6578\u5B57\uFF1A\u5FC5\u9808\u70BA ${r.divisor} \u7684\u500D\u6578`;
      case "unrecognized_keys":
        return `\u7121\u6CD5\u8B58\u5225\u7684\u9375\u503C${r.keys.length > 1 ? "\u5011" : ""}\uFF1A${h(r.keys, "\u3001")}`;
      case "invalid_key":
        return `${r.origin} \u4E2D\u6709\u7121\u6548\u7684\u9375\u503C`;
      case "invalid_union":
        return "\u7121\u6548\u7684\u8F38\u5165\u503C";
      case "invalid_element":
        return `${r.origin} \u4E2D\u6709\u7121\u6548\u7684\u503C`;
      default:
        return "\u7121\u6548\u7684\u8F38\u5165\u503C";
    }
  };
}, "error");
function zl() {
  return {
    localeError: i_()
  };
}
s(zl, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/yo.js
var o_ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\xE0mi", verb: "n\xED" },
    file: { unit: "bytes", verb: "n\xED" },
    array: { unit: "nkan", verb: "n\xED" },
    set: { unit: "nkan", verb: "n\xED" },
    map: { unit: "nkan", verb: "n\xED" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  s(t, "getSizing");
  let n = {
    regex: "\u1EB9\u0300r\u1ECD \xECb\xE1w\u1ECDl\xE9",
    email: "\xE0d\xEDr\u1EB9\u0301s\xEC \xECm\u1EB9\u0301l\xEC",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\xE0k\xF3k\xF2 ISO",
    date: "\u1ECDj\u1ECD\u0301 ISO",
    time: "\xE0k\xF3k\xF2 ISO",
    duration: "\xE0k\xF3k\xF2 t\xF3 p\xE9 ISO",
    ipv4: "\xE0d\xEDr\u1EB9\u0301s\xEC IPv4",
    ipv6: "\xE0d\xEDr\u1EB9\u0301s\xEC IPv6",
    mac: "\xE0d\xEDr\u1EB9\u0301s\xEC MAC",
    cidrv4: "\xE0gb\xE8gb\xE8 IPv4",
    cidrv6: "\xE0gb\xE8gb\xE8 IPv6",
    base64: "\u1ECD\u0300r\u1ECD\u0300 t\xED a k\u1ECD\u0301 n\xED base64",
    base64url: "\u1ECD\u0300r\u1ECD\u0300 base64url",
    json_string: "\u1ECD\u0300r\u1ECD\u0300 JSON",
    e164: "n\u1ECD\u0301mb\xE0 E.164",
    credit_card: "n\u1ECDmba kaadi gbese",
    jwt: "JWT",
    template_literal: "\u1EB9\u0300r\u1ECD \xECb\xE1w\u1ECDl\xE9"
  }, o = {
    nan: "NaN",
    number: "n\u1ECD\u0301mb\xE0",
    array: "akop\u1ECD"
  };
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        let i = o[r.expected] ?? r.expected, a = b(r.input), u = o[a] ?? a;
        return /^[A-Z]/.test(r.expected) ? `\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e: a n\xED l\xE1ti fi instanceof ${r.expected}, \xE0m\u1ECD\u0300 a r\xED ${u}` : `\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e: a n\xED l\xE1ti fi ${i}, \xE0m\u1ECD\u0300 a r\xED ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e: a n\xED l\xE1ti fi ${$(r.values[0])}` : `\xC0\u1E63\xE0y\xE0n a\u1E63\xEC\u1E63e: yan \u1ECD\u0300kan l\xE1ra ${h(r.values, "|")}`;
      case "too_big": {
        let i = r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `T\xF3 p\u1ECD\u0300 j\xF9: a n\xED l\xE1ti j\u1EB9\u0301 p\xE9 ${r.origin ?? "iye"} ${a.verb} ${i}${r.maximum} ${a.unit}` : `T\xF3 p\u1ECD\u0300 j\xF9: a n\xED l\xE1ti j\u1EB9\u0301 ${i}${r.maximum}`;
      }
      case "too_small": {
        let i = r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `K\xE9r\xE9 ju: a n\xED l\xE1ti j\u1EB9\u0301 p\xE9 ${r.origin} ${a.verb} ${i}${r.minimum} ${a.unit}` : `K\xE9r\xE9 ju: a n\xED l\xE1ti j\u1EB9\u0301 ${i}${r.minimum}`;
      }
      case "invalid_format": {
        let i = r;
        return i.format === "starts_with" ? `\u1ECC\u0300r\u1ECD\u0300 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 b\u1EB9\u0300r\u1EB9\u0300 p\u1EB9\u0300l\xFA "${i.prefix}"` : i.format === "ends_with" ? `\u1ECC\u0300r\u1ECD\u0300 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 par\xED p\u1EB9\u0300l\xFA "${i.suffix}"` : i.format === "includes" ? `\u1ECC\u0300r\u1ECD\u0300 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 n\xED "${i.includes}"` : i.format === "regex" ? `\u1ECC\u0300r\u1ECD\u0300 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 b\xE1 \xE0p\u1EB9\u1EB9r\u1EB9 mu ${i.pattern}` : `A\u1E63\xEC\u1E63e: ${n[i.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `N\u1ECD\u0301mb\xE0 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 j\u1EB9\u0301 \xE8y\xE0 p\xEDp\xEDn ti ${r.divisor}`;
      case "unrecognized_keys":
        return `B\u1ECDt\xECn\xEC \xE0\xECm\u1ECD\u0300: ${h(r.keys, ", ")}`;
      case "invalid_key":
        return `B\u1ECDt\xECn\xEC a\u1E63\xEC\u1E63e n\xEDn\xFA ${r.origin}`;
      case "invalid_union":
        return "\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e";
      case "invalid_element":
        return `Iye a\u1E63\xEC\u1E63e n\xEDn\xFA ${r.origin}`;
      default:
        return "\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e";
    }
  };
}, "error");
function Sl() {
  return {
    localeError: o_()
  };
}
s(Sl, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/registries.js
var Lm, Ol = /* @__PURE__ */ Symbol("ZodOutput"), jl = /* @__PURE__ */ Symbol("ZodInput"), Gi = class {
  static {
    s(this, "$ZodRegistry");
  }
  constructor() {
    this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map();
  }
  add(t, ...n) {
    let o = n[0];
    return this._map.set(t, o), o && typeof o == "object" && "id" in o && this._idmap.set(o.id, t), this;
  }
  clear() {
    return this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map(), this;
  }
  remove(t) {
    let n = this._map.get(t);
    return n && typeof n == "object" && "id" in n && this._idmap.delete(n.id), this._map.delete(t), this;
  }
  get(t) {
    let n = t._zod.parent;
    if (n) {
      let o = { ...this.get(n) ?? {} };
      delete o.id;
      let r = { ...o, ...this._map.get(t) };
      return Object.keys(r).length ? r : void 0;
    }
    return this._map.get(t);
  }
  has(t) {
    return this._map.has(t);
  }
};
function Xi() {
  return new Gi();
}
s(Xi, "registry");
(Lm = globalThis).__zod_globalRegistry ?? (Lm.__zod_globalRegistry = Xi());
var se = globalThis.__zod_globalRegistry;

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/compile.js
var xe = Symbol.for("zod.compile.invalid"), Vm = Symbol.for("zod.compile.fallback"), Ue = class extends Error {
  static {
    s(this, "ZodCompileAsyncError");
  }
  constructor(t = "z.compile does not support async refinements, transforms, or checks") {
    super(t), this.name = "ZodCompileAsyncError";
  }
}, Z = class extends Error {
  static {
    s(this, "ZodCompileUnsupportedError");
  }
  constructor(t, n = !0) {
    super(`z.compile does not support ${t}; this schema must use the runtime parser`), this.name = "ZodCompileUnsupportedError", this.islandable = n;
  }
};
function s_(e, t) {
  try {
    return Hi(e, { assertOnly: !0 });
  } catch {
    return t;
  }
}
s(s_, "compileValidator");
function Tl(e, t) {
  try {
    let n = Hi(e), o = C(e), r = e._zod.run, i = r.__originalRun ?? r, a = /* @__PURE__ */ s((u, c) => {
      if (c?.async || c?.direction === "backward" || c?.skipChecks || c?.[Vm] || c && Ki(c, u.value))
        return i(u, c);
      let l = n(u.value);
      return l !== xe ? (u.value = l, u) : (c && (c[Vm] = !0), i(u, c));
    }, "wrapped");
    return a.__originalRun = i, o._zod.bag.fallbackRun = i, o._zod.bag.validator = s_(e, n), o._zod.run = a, r.__originalRun || u_(o, e, n), o;
  } catch (n) {
    if (t?.strict)
      throw n;
    return e;
  }
}
s(Tl, "compile");
function u_(e, t, n) {
  let o = e, r = t;
  if (typeof r.safeParse == "function") {
    let i = r.safeParse;
    o.safeParse = (a, u) => {
      let c = n(a);
      return c !== xe ? { success: !0, data: c } : i(a, u);
    };
  }
  if (typeof r.parse == "function") {
    let i = r.parse;
    o.parse = (a, u) => {
      let c = n(a);
      return c !== xe ? c : i(a, u);
    };
  }
}
s(u_, "installCompiledUserMethods");
function Hi(e, t) {
  let n = !0;
  try {
    n = xc(e);
  } catch {
  }
  if (n)
    throw new Z("a schema whose subtree contains a reference cycle");
  let o = {
    constants: /* @__PURE__ */ new Map(),
    constantCounter: 0,
    varCounter: 0
  }, r = new It(["input"]), i = H(r, o, e, "input", !t?.assertOnly);
  r.write(i === null ? "return true;" : `return ${i};`);
  let a = ["INVALID", ...o.constants.keys()], u = [xe, ...o.constants.values()], c = r.content.join(`
`), l = t?.debug ? a.length > 0 ? `// Constants: ${a.join(", ")}
${c}` : c : "", d = Function, f = `return (input) => {
${c}
}`, p;
  try {
    p = new d(...a, f)(...u);
  } catch (m) {
    throw new Z(`this schema (generated code failed to evaluate: ${m.message})`);
  }
  return t?.debug && (p.code = l), p;
}
s(Hi, "compileFn");
function D(e, t) {
  for (let [o, r] of e.constants)
    if (r === t)
      return o;
  let n = `c${e.constantCounter++}`;
  return e.constants.set(n, t), n;
}
s(D, "addConstant");
function N(e) {
  return `v${e.varCounter++}`;
}
s(N, "newVar");
function c_(e, t) {
  let n = e._zod.run({ value: t, issues: [] }, {});
  if (n && typeof n.then == "function")
    return xe;
  let o = n;
  return o.issues.length === 0 ? o.value : xe;
}
s(c_, "runtimeRun");
function de(e, t, n, o, r = !0) {
  let i = e.content.length, a = t.constants.size, u = t.constantCounter, c = t.varCounter;
  try {
    return H(e, t, n, o, r);
  } catch (l) {
    if (!(l instanceof Z) || !l.islandable)
      throw l;
    if (e.content.length = i, t.constants.size > a) {
      let d = Array.from(t.constants.keys()).slice(a);
      for (let f of d)
        t.constants.delete(f);
    }
    return t.constantCounter = u, t.varCounter = c, l_(e, t, n, o);
  }
}
s(de, "compileChild");
function l_(e, t, n, o) {
  let r = D(t, n), i = D(t, c_), a = N(t);
  return e.write(`const ${a} = ${i}(${r}, ${o});`), e.write(`if (${a} === INVALID) return INVALID;`), a;
}
s(l_, "emitRuntimeIsland");
var d_ = /* @__PURE__ */ new Set([
  "max_size",
  "min_size",
  "size_equals",
  "max_length",
  "min_length",
  "length_equals"
]);
function f_(e, t, n, o) {
  let r = n._zod.def.checks;
  if (!r || r.length === 0)
    return o;
  let i = o;
  for (let a of r) {
    let u = a._zod.def;
    if (u.when && !d_.has(u.check))
      throw new Z('check with a custom "when" condition');
    switch (u.check) {
      case "greater_than":
        p_(e, t, u, i);
        break;
      case "less_than":
        m_(e, t, u, i);
        break;
      case "multiple_of":
        g_(e, t, u, i);
        break;
      case "number_format":
        qm(e, u, i);
        break;
      case "min_length": {
        let c = Ot(u.minimum, "min_length"), l = Pl(e, t, i, `${i}.length >= ${c} && ${i}.length < ${u.minimum * 2}`);
        e.write(`if (${l} < ${c}) return INVALID;`);
        break;
      }
      case "max_length": {
        let c = Ot(u.maximum, "max_length"), l = Pl(e, t, i, `${i}.length > ${c}`);
        e.write(`if (${l} > ${c}) return INVALID;`);
        break;
      }
      case "length_equals": {
        let c = Ot(u.length, "length_equals"), l = Pl(e, t, i, `${i}.length >= ${c} && ${i}.length <= ${u.length * 2}`);
        e.write(`if (${l} !== ${c}) return INVALID;`);
        break;
      }
      case "min_size":
        e.write(`if (${i}.size < ${Ot(u.minimum, "min_size")}) return INVALID;`);
        break;
      case "max_size":
        e.write(`if (${i}.size > ${Ot(u.maximum, "max_size")}) return INVALID;`);
        break;
      case "size_equals":
        e.write(`if (${i}.size !== ${Ot(u.size, "size_equals")}) return INVALID;`);
        break;
      case "string_format":
        i = Wm(e, t, u, i);
        break;
      case "custom":
        i = b_(e, t, a, i);
        break;
      case "bigint_format":
        h_(e, u, i);
        break;
      case "mime_type":
        v_(e, t, u, i);
        break;
      case "property":
        y_(e, t, u, i);
        break;
      case "overwrite": {
        let c = N(t);
        $_(e, t, a, i, c), i = c;
        break;
      }
      default:
        throw new Z(`check type ${u.check}`);
    }
  }
  return i;
}
s(f_, "generateChecks");
function Pl(e, t, n, o) {
  let r = D(t, xt), i = N(t);
  return e.write(`const ${i} = typeof ${n} === "string" && ${o} ? ${r}(${n}) : ${n}.length;`), i;
}
s(Pl, "codePointLengthVar");
function Ot(e, t) {
  if (typeof e != "number" || !Number.isFinite(e))
    throw new Z(`${t} bound of type ${typeof e}`);
  return `${e}`;
}
s(Ot, "numericOperand");
function Jm(e, t) {
  if (typeof t == "bigint")
    return `${t}n`;
  if (typeof t == "number") {
    if (Number.isNaN(t))
      throw new Z("comparison check with NaN bound");
    return `${t}`;
  }
  if (t instanceof Date) {
    if (Number.isNaN(t.getTime()))
      throw new Z("comparison check with Invalid Date bound");
    return D(e, t);
  }
  throw new Z(`comparison check bound of type ${typeof t}`);
}
s(Jm, "comparisonOperand");
function p_(e, t, n, o) {
  let r = n.inclusive ? "<" : "<=";
  e.write(`if (${o} ${r} ${Jm(t, n.value)}) return INVALID;`);
}
s(p_, "generateGreaterThanCheck");
function m_(e, t, n, o) {
  let r = n.inclusive ? ">" : ">=";
  e.write(`if (${o} ${r} ${Jm(t, n.value)}) return INVALID;`);
}
s(m_, "generateLessThanCheck");
function g_(e, t, n, o) {
  if (typeof n.value == "bigint") {
    if (n.value === BigInt(0))
      throw new Z("multiple_of check with a zero divisor");
    e.write(`if (${o} % ${n.value}n !== 0n) return INVALID;`);
  } else {
    let r = D(t, Wr);
    e.write(`if (${r}(${o}, ${Ot(n.value, "multiple_of")}) !== 0) return INVALID;`);
  }
}
s(g_, "generateMultipleOfCheck");
function qm(e, t, n) {
  let o = t.format;
  switch (o) {
    case "safeint":
      e.write(`if (!Number.isSafeInteger(${n})) return INVALID;`);
      break;
    case "int32":
      e.write(`if (!Number.isInteger(${n}) || ${n} < -2147483648 || ${n} > 2147483647) return INVALID;`);
      break;
    case "uint32":
      e.write(`if (!Number.isInteger(${n}) || ${n} < 0 || ${n} > 4294967295) return INVALID;`);
      break;
    case "float32":
      e.write(`if (!Number.isFinite(${n}) || ${n} < -3.4028234663852886e38 || ${n} > 3.4028234663852886e38) return INVALID;`);
      break;
    case "float64":
      e.write(`if (!Number.isFinite(${n})) return INVALID;`);
      break;
    default:
      throw new Z(`number format ${o}`);
  }
}
s(qm, "generateNumberFormatCheck");
function h_(e, t, n) {
  let o = t.format;
  if (o)
    switch (o) {
      case "int64":
        e.write(`if (${n} < -9223372036854775808n || ${n} > 9223372036854775807n) return INVALID;`);
        break;
      case "uint64":
        e.write(`if (${n} < 0n || ${n} > 18446744073709551615n) return INVALID;`);
        break;
      default:
        throw new Z(`bigint format ${o}`);
    }
}
s(h_, "generateBigIntFormatCheck");
function v_(e, t, n, o) {
  let r = n.mime;
  if (r && r.length > 0) {
    let i = D(t, new Set(r));
    e.write(`if (!${i}.has(${o}.type)) return INVALID;`);
  }
}
s(v_, "generateMimeTypeCheck");
function y_(e, t, n, o) {
  let r = `${o}[${JSON.stringify(n.property)}]`;
  H(e, t, n.schema, r);
}
s(y_, "generatePropertyCheck");
function $_(e, t, n, o, r) {
  let i = n._zod.def.tx;
  if (!i)
    throw new Z("overwrite check without a transform function");
  if (Dt(i))
    throw new Ue("z.compile: async overwrite transforms are not supported");
  let a = D(t, i);
  e.write(`const ${r} = ${a}(${o});`);
}
s($_, "generateOverwriteCheck");
function Dl() {
  throw new he();
}
s(Dl, "throwAsync");
function Al(e) {
  this.issues.push(e);
}
s(Al, "pushIssue");
function b_(e, t, n, o) {
  let r = n._zod.def;
  if (r.fn) {
    if (Dt(r.fn))
      throw new Ue("z.compile: async .refine() predicates are not supported");
    let i = D(t, r.fn), a = D(t, Dl), u = N(t);
    return e.write(`const ${u} = ${i}(${o});`), e.write(`if (${u} instanceof Promise) ${a}();`), e.write(`if (!${u}) return INVALID;`), o;
  }
  if (n._zod.check) {
    if (Dt(n._zod.check))
      throw new Ue("z.compile: async .superRefine() / check functions are not supported");
    let i = n._zod.check, u = D(t, /* @__PURE__ */ s((l) => {
      let d = { value: l, issues: [], addIssue: Al };
      return i(d) instanceof Promise && Dl(), d.issues.length === 0 ? d.value : xe;
    }, "helperFn")), c = N(t);
    return e.write(`const ${c} = ${u}(${o});`), e.write(`if (${c} === INVALID) return INVALID;`), c;
  }
  throw new Z("custom check without a predicate or check function");
}
s(b_, "generateCustomRefineCheck");
var __ = /* @__PURE__ */ new Set([
  "cidrv4",
  "cuid",
  "cuid2",
  "date",
  "datetime",
  "duration",
  "e164",
  "email",
  "emoji",
  "ends_with",
  "guid",
  "includes",
  "ipv4",
  "ksuid",
  "lowercase",
  "mac",
  "nanoid",
  "regex",
  "starts_with",
  "time",
  "ulid",
  "uppercase",
  "uuid",
  "xid"
]);
function Wm(e, t, n, o) {
  let r = n.format;
  if (r === "base64") {
    let c = D(t, on);
    return e.write(`if (!${c}(${o})) return INVALID;`), o;
  }
  if (r === "base64url") {
    let c = D(t, Ri);
    return e.write(`if (!${c}(${o})) return INVALID;`), o;
  }
  if (r === "jwt") {
    let c = D(t, Li), l = D(t, n.alg ?? null);
    return e.write(`if (!${c}(${o}, ${l})) return INVALID;`), o;
  }
  if (r === "ipv6") {
    let c = D(t, nn);
    return e.write(`if (!${c}(${o})) return INVALID;`), o;
  }
  if (r === "cidrv6") {
    let c = D(t, Zi);
    return e.write(`if (!${c}(${o})) return INVALID;`), o;
  }
  if (r === "credit_card") {
    let c = D(t, Fi);
    return e.write(`if (!${c}(${o})) return INVALID;`), o;
  }
  let i = n;
  if (r === "url" || r === "httpurl" || i.normalize || i.hostname !== void 0 || i.protocol !== void 0) {
    let c = D(t, Ai), l = D(t, n), d = N(t), f = N(t);
    if (e.write(`const ${d} = ${o}.trim();`), e.write(`const ${f} = ${c}(${d}, ${l});`), e.write(`if (typeof ${f} === "number") return INVALID;`), i.hostname !== void 0) {
      let v = D(t, Ei);
      e.write(`if (!${v}(${f}, ${l}.hostname)) return INVALID;`);
    }
    if (i.protocol !== void 0) {
      let v = D(t, Ci);
      e.write(`if (!${v}(${f}, ${l}.protocol)) return INVALID;`);
    }
    let p = N(t), m = i.normalize ? `${f}.href` : `${D(t, Ui)}(${d})`;
    return e.write(`const ${p} = ${m};`), p;
  }
  let a = n.fn;
  if (a) {
    if (Dt(a))
      throw new Z(`async string format ${r}`);
    let c = D(t, a);
    return e.write(`if (!${c}(${o})) return INVALID;`), o;
  }
  if (__.has(r) && n.pattern) {
    let c = D(t, n.pattern);
    return e.write(`${c}.lastIndex = 0;`), e.write(`if (!${c}.test(${o})) return INVALID;`), o;
  }
  let u = n.format;
  switch (u) {
    case "regex":
      throw new Z("regex format without a pattern");
    case "lowercase":
      e.write(`if (${o} !== ${o}.toLowerCase()) return INVALID;`);
      break;
    case "uppercase":
      e.write(`if (${o} !== ${o}.toUpperCase()) return INVALID;`);
      break;
    case "includes":
      e.write(`if (!${o}.includes(${pe(n.includes)})) return INVALID;`);
      break;
    case "starts_with": {
      let c = n.prefix;
      e.write(`if (${o}.slice(0, ${c.length}) !== ${pe(c)}) return INVALID;`);
      break;
    }
    case "ends_with": {
      let c = n.suffix;
      e.write(`if (${o}.slice(-${c.length}) !== ${pe(c)}) return INVALID;`);
      break;
    }
    default:
      throw new Z(`string format ${u}`);
  }
  return o;
}
s(Wm, "generateStringFormatCheck");
function H(e, t, n, o, r = !0) {
  let i = n._zod.def, a = i.type;
  if (i.coerce)
    throw new Z(`coercion (z.coerce.${a}())`);
  let u = r || !!i.checks?.length, c;
  switch (a) {
    case "string":
      c = x_(e, t, n, o);
      break;
    case "number":
      c = w_(e, n, o);
      break;
    case "boolean":
      c = k_(e, o);
      break;
    case "bigint":
      c = I_(e, n, o);
      break;
    case "symbol":
      c = z_(e, o);
      break;
    case "undefined":
      c = S_(e, o);
      break;
    case "null":
      c = O_(e, o);
      break;
    case "any":
    case "unknown":
      c = o;
      break;
    case "never":
      e.write("return INVALID;"), c = o;
      break;
    case "void":
      c = j_(e, o);
      break;
    case "nan":
      c = P_(e, o);
      break;
    case "date":
      c = D_(e, o);
      break;
    case "object":
      c = N_(e, t, n, o, u);
      break;
    case "optional":
      c = T_(e, t, n, o, u);
      break;
    case "nullable":
      c = E_(e, t, n, o, u);
      break;
    case "array":
      c = C_(e, t, n, o, u);
      break;
    case "literal":
      c = Z_(e, t, n, o);
      break;
    case "enum":
      c = R_(e, t, n, o);
      break;
    case "readonly": {
      let l = Mm(e, t, n, o), d = N(t);
      e.write(`const ${d} = Object.freeze(${l});`), c = d;
      break;
    }
    case "success":
      Mm(e, t, n, o), c = "true";
      break;
    case "default":
    case "prefault":
      c = F_(e, t, n, o);
      break;
    case "nonoptional":
      c = L_(e, t, n, o);
      break;
    case "tuple":
      c = V_(e, t, n, o);
      break;
    case "union":
      c = M_(e, t, n, o);
      break;
    case "intersection":
      c = q_(e, t, n, o);
      break;
    case "record":
      c = W_(e, t, n, o);
      break;
    case "map":
      c = G_(e, t, n, o);
      break;
    case "set":
      c = X_(e, t, n, o);
      break;
    case "file":
      c = H_(e, o);
      break;
    case "template_literal":
      c = Q_(e, t, n, o);
      break;
    case "lazy":
      c = Y_(e, t, n, o);
      break;
    case "pipe":
      c = ex(e, t, n, o);
      break;
    case "custom":
      c = tx(e, t, n, o);
      break;
    case "transform":
      c = ix(e, t, n, o);
      break;
    case "catch":
      c = nx(e, t, n, o);
      break;
    default:
      throw new Z(`schema type ${a}`);
  }
  return c === null ? null : f_(e, t, n, c);
}
s(H, "generateCheck");
function x_(e, t, n, o) {
  e.write(`if (typeof ${o} !== "string") return INVALID;`);
  let r = n._zod.def;
  return r.format === void 0 ? o : Wm(e, t, r, o);
}
s(x_, "generateStringCheck");
function w_(e, t, n) {
  e.write(`if (typeof ${n} !== "number" || !Number.isFinite(${n})) return INVALID;`);
  let o = t._zod.def;
  return o.check === "number_format" && o.format && qm(e, { format: o.format }, n), n;
}
s(w_, "generateNumberCheck");
function k_(e, t) {
  return e.write(`if (typeof ${t} !== "boolean") return INVALID;`), t;
}
s(k_, "generateBooleanCheck");
function I_(e, t, n) {
  e.write(`if (typeof ${n} !== "bigint") return INVALID;`);
  let o = t._zod.def;
  if (o.format)
    switch (o.format) {
      case "int64":
        e.write(`if (${n} < -9223372036854775808n || ${n} > 9223372036854775807n) return INVALID;`);
        break;
      case "uint64":
        e.write(`if (${n} < 0n || ${n} > 18446744073709551615n) return INVALID;`);
        break;
    }
  return n;
}
s(I_, "generateBigIntCheck");
function z_(e, t) {
  return e.write(`if (typeof ${t} !== "symbol") return INVALID;`), t;
}
s(z_, "generateSymbolCheck");
function S_(e, t) {
  return e.write(`if (${t} !== undefined) return INVALID;`), t;
}
s(S_, "generateUndefinedCheck");
function O_(e, t) {
  return e.write(`if (${t} !== null) return INVALID;`), t;
}
s(O_, "generateNullCheck");
function j_(e, t) {
  return e.write(`if (${t} !== undefined) return INVALID;`), t;
}
s(j_, "generateVoidCheck");
function P_(e, t) {
  return e.write(`if (typeof ${t} !== "number" || !Number.isNaN(${t})) return INVALID;`), t;
}
s(P_, "generateNaNCheck");
function D_(e, t) {
  return e.write(`if (!(${t} instanceof Date) || Number.isNaN(${t}.getTime())) return INVALID;`), t;
}
s(D_, "generateDateCheck");
function N_(e, t, n, o, r = !0) {
  let i = n._zod.def;
  e.write(`if (typeof ${o} !== "object" || ${o} === null || Array.isArray(${o})) return INVALID;`);
  let a = i.shape, u = Object.keys(a), c = Object.getOwnPropertySymbols(a), l = c.length ? [...u, ...c] : u, d = /* @__PURE__ */ s((j) => typeof j == "symbol" ? D(t, j) : pe(j), "keyExpr"), f = /* @__PURE__ */ s((j) => typeof j == "symbol" ? `[${d(j)}]` : pe(j), "propKey"), p = a;
  if (u.includes("__proto__"))
    throw new Z('object shape key "__proto__"');
  let m = /* @__PURE__ */ new Map();
  for (let j of l) {
    let P = p[j], U = d(j), V = N(t);
    if (e.write(`const ${V} = ${o}[${U}];`), P._zod.optin !== void 0) {
      let I = N(t);
      e.write(`let ${I} = (() => {`), e.indented((T) => {
        let W = de(T, t, P, V);
        T.write(`return ${W};`);
      }), e.write("})();"), P._zod.optout === "optional" ? (e.write(`if (${I} === INVALID) {`), e.indented((T) => {
        T.write(`if (${U} in ${o}) return INVALID;`), T.write(`${I} = undefined;`);
      }), e.write("}")) : e.write(`if (${I} === INVALID) return INVALID;`), m.set(j, I);
    } else {
      U_(P) && e.write(`if (!(${U} in ${o})) return INVALID;`);
      let I = de(e, t, P, V, r);
      I !== null && m.set(j, I);
    }
  }
  let v = i.catchall, x = "none";
  if (v) {
    let j = v._zod.def.type;
    if (j === "never") {
      let P = u.map((U) => `k !== ${pe(U)}`).join(" && ") || "true";
      e.write(`for (const k in ${o}) {`), e.indented((U) => {
        U.write(`if (${P}) return INVALID;`);
      }), e.write("}");
    } else (j === "unknown" || j === "any") && !v._zod.def.checks?.length ? x = "passthrough" : x = "schema";
  }
  let k = N(t), R = l.some((j) => Pt(p[j]) || Nl(p[j]));
  if (!r) {
    if (x === "schema") {
      let j = u.length > 0 ? D(t, new Set(u)) : null;
      e.write(`for (const k in ${o}) {`), e.indented((P) => {
        P.write('if (k === "__proto__") continue;'), j && P.write(`if (${j}.has(k)) continue;`);
        let U = N(t);
        P.write(`const ${U} = ${o}[k];`), de(P, t, v, U, !1);
      }), e.write("}");
    }
    return null;
  }
  if (R) {
    e.write(`const ${k} = {};`);
    for (let j of l) {
      let P = d(j), U = m.get(j);
      Nl(p[j]) ? e.write(`if (${P} in ${o}) ${k}[${P}] = ${U};`) : Pt(p[j]) ? e.write(`if (${U} !== undefined || ${P} in ${o}) ${k}[${P}] = ${U};`) : e.write(`${k}[${P}] = ${U};`);
    }
  } else {
    let j = l.map((P) => `${f(P)}: ${m.get(P)}`).join(", ");
    e.write(`const ${k} = { ${j} };`);
  }
  if (x !== "none") {
    let j = u.length > 0 ? D(t, new Set(u)) : null;
    e.write(`for (const k in ${o}) {`), e.indented((P) => {
      if (P.write('if (k === "__proto__") continue;'), j && P.write(`if (${j}.has(k)) continue;`), x === "passthrough")
        P.write(`${k}[k] = ${o}[k];`);
      else {
        let U = N(t);
        P.write(`const ${U} = ${o}[k];`);
        let V = de(P, t, v, U);
        P.write(`${k}[k] = ${V};`);
      }
    }), e.write("}");
  }
  return k;
}
s(N_, "generateObjectCheck");
function T_(e, t, n, o, r = !0) {
  let i = n._zod.def;
  if (A_(n))
    return H(e, t, i.innerType, o, r);
  if (i.innerType._zod.optin === "defaulted") {
    let u = N(t), c = N(t);
    return e.write(`let ${u};`), e.write(`if (${o} === undefined) {`), e.indented((l) => {
      l.write(`const ${c} = (() => {`), l.indented((d) => {
        let f = H(d, t, i.innerType, o);
        d.write(`return ${f};`);
      }), l.write("})();"), l.write(`if (${c} !== INVALID) ${u} = ${c};`);
    }), e.write("} else {"), e.indented((l) => {
      let d = H(l, t, i.innerType, o);
      l.write(`${u} = ${d};`);
    }), e.write("}"), u;
  }
  let a = r ? N(t) : null;
  return a && e.write(`let ${a};`), e.write(`if (${o} !== undefined) {`), e.indented((u) => {
    let c = H(u, t, i.innerType, o, r);
    a && c !== null && u.write(`${a} = ${c};`);
  }), e.write("}"), a;
}
s(T_, "generateOptionalCheck");
function A_(e) {
  return e._zod.traits?.has("$ZodExactOptional") === !0;
}
s(A_, "isExactOptional");
function U_(e) {
  return e._zod.optin === void 0 && jt(e);
}
s(U_, "requiresPresenceCheck");
function jt(e) {
  if (e._zod.def.coerce)
    return !0;
  let t = e._zod.def;
  switch (t.type) {
    case "any":
    case "unknown":
    case "undefined":
    case "void":
    case "default":
    case "prefault":
    case "transform":
    case "custom":
    case "lazy":
      return !0;
    case "string":
    case "number":
    case "boolean":
    case "bigint":
    case "symbol":
    case "null":
    case "never":
    case "nan":
    case "date":
    case "object":
    case "array":
    case "tuple":
    case "record":
    case "map":
    case "set":
    case "file":
    case "template_literal":
      return !1;
    case "nonoptional":
      return t.innerType ? jt(t.innerType) : !1;
    case "literal":
      return !!t.values?.includes(void 0);
    case "enum":
      return !!e._zod.values?.has(void 0);
    case "optional":
    case "nullable":
    case "readonly":
    case "success":
      return t.innerType ? jt(t.innerType) : !0;
    case "catch":
      return !0;
    case "union":
      return t.options ? t.options.some(jt) : !0;
    case "intersection":
      return !t.left || !t.right ? !0 : jt(t.left) && jt(t.right);
    case "pipe":
      return t.in ? jt(t.in) : !0;
    default:
      return !0;
  }
}
s(jt, "fastPathAcceptsAbsence");
function Nl(e) {
  return e._zod.optin === "optional" && e._zod.optout === "optional";
}
s(Nl, "dropsWhenAbsent");
function Pt(e) {
  let t = e._zod.def;
  switch (t.type) {
    case "string":
    case "number":
    case "boolean":
    case "bigint":
    case "symbol":
    case "null":
    case "nan":
    case "date":
    case "object":
    case "array":
    case "tuple":
    case "record":
    case "map":
    case "set":
    case "file":
    case "template_literal":
    case "never":
    case "success":
      return !1;
    case "literal":
      return !!t.values?.includes(void 0);
    case "enum":
      return !!e._zod.values?.has(void 0);
    case "optional":
      return !0;
    case "nullable":
    case "readonly":
    case "nonoptional":
      return t.innerType ? Pt(t.innerType) : !0;
    case "union":
      return t.options ? t.options.some(Pt) : !0;
    case "intersection":
      return !t.left || !t.right || Pt(t.left) || Pt(t.right);
    case "pipe":
      return t.out ? Pt(t.out) : !0;
    default:
      return !0;
  }
}
s(Pt, "mayOutputUndefined");
function E_(e, t, n, o, r = !0) {
  let i = n._zod.def, a = r ? N(t) : null;
  return a && e.write(`let ${a} = null;`), e.write(`if (${o} !== null) {`), e.indented((u) => {
    let c = H(u, t, i.innerType, o, r);
    a && c !== null && u.write(`${a} = ${c};`);
  }), e.write("}"), a;
}
s(E_, "generateNullableCheck");
function C_(e, t, n, o, r = !0) {
  let i = n._zod.def;
  e.write(`if (!Array.isArray(${o})) return INVALID;`);
  let a = r ? N(t) : null, u = N(t), c = N(t);
  return a && e.write(`const ${a} = new Array(${o}.length);`), e.write(`for (let ${u} = 0; ${u} < ${o}.length; ${u}++) {`), e.indented((l) => {
    l.write(`const ${c} = ${o}[${u}];`);
    let d = de(l, t, i.element, c, r);
    a && d !== null && l.write(`${a}[${u}] = ${d};`);
  }), e.write("}"), a;
}
s(C_, "generateArrayCheck");
function Z_(e, t, n, o) {
  let i = n._zod.def.values;
  if (i.length !== 1) {
    let u = D(t, new Set(i));
    return e.write(`if (!${u}.has(${o})) return INVALID;`), o;
  }
  let a = i[0];
  if (typeof a == "number" && Number.isNaN(a)) {
    let u = D(t, new Set(i));
    return e.write(`if (!${u}.has(${o})) return INVALID;`), o;
  }
  if (typeof a == "string")
    e.write(`if (${o} !== ${pe(a)}) return INVALID;`);
  else if (typeof a == "number" || typeof a == "boolean")
    e.write(`if (${o} !== ${a}) return INVALID;`);
  else if (a === null)
    e.write(`if (${o} !== null) return INVALID;`);
  else if (a === void 0)
    e.write(`if (${o} !== undefined) return INVALID;`);
  else if (typeof a == "bigint")
    e.write(`if (${o} !== ${a}n) return INVALID;`);
  else
    throw new Z(`literal type ${typeof a}`);
  return o;
}
s(Z_, "generateLiteralCheck");
function R_(e, t, n, o) {
  let r = n._zod.values;
  if (!r)
    throw new Z("enum schema without enumerated values");
  let i = D(t, r);
  return e.write(`if (!${i}.has(${o})) return INVALID;`), o;
}
s(R_, "generateEnumCheck");
function Mm(e, t, n, o) {
  let r = n._zod.def;
  return H(e, t, r.innerType, o);
}
s(Mm, "generateWrapperCheck");
function F_(e, t, n, o) {
  let r = n._zod.def, a = Object.getOwnPropertyDescriptor(n._zod.def, "defaultValue") ? () => n._zod.def.defaultValue : void 0;
  if (n._zod.def.type === "prefault") {
    if (!a)
      return H(e, t, r.innerType, o);
    let c = D(t, a), l = N(t);
    return e.write(`let ${l} = ${o};`), e.write(`if (${o} === undefined) ${l} = ${c}();`), H(e, t, r.innerType, l);
  }
  let u = N(t);
  if (a) {
    let c = D(t, a), l = D(t, Kr);
    e.write(`let ${u};`), e.write(`if (${o} === undefined) {`), e.indented((d) => {
      d.write(`${u} = ${l}(${c}());`);
    }), e.write("} else {"), e.indented((d) => {
      let f = H(d, t, r.innerType, o);
      d.write(`${u} = ${f} === undefined ? ${l}(${c}()) : ${f};`);
    }), e.write("}");
  } else
    e.write(`let ${u};`), e.write(`if (${o} !== undefined) {`), e.indented((c) => {
      let l = H(c, t, r.innerType, o);
      c.write(`${u} = ${l};`);
    }), e.write("}");
  return u;
}
s(F_, "generateDefaultCheck");
function L_(e, t, n, o) {
  let r = n._zod.def, i = H(e, t, r.innerType, o), a = N(t);
  return e.write(`const ${a} = ${i};`), e.write(`if (${a} === undefined) return INVALID;`), a;
}
s(L_, "generateNonOptionalCheck");
function V_(e, t, n, o) {
  let r = n._zod.def, i = r.items, a = r.rest;
  e.write(`if (!Array.isArray(${o})) return INVALID;`);
  let u = Bm(i, "optin"), c = Bm(i, "optout");
  a ? e.write(`if (${o}.length < ${u}) return INVALID;`) : e.write(`if (${o}.length < ${u} || ${o}.length > ${i.length}) return INVALID;`);
  let l = N(t);
  e.write(`const ${l} = [];`);
  for (let d = 0; d < i.length; d++) {
    let f = i[d];
    if (d >= c)
      e.write(`if (${l}.length === ${d}) {`), e.indented((p) => {
        p.write(`if (${d} < ${o}.length) {`), p.indented((m) => {
          let v = N(t);
          m.write(`const ${v} = ${o}[${d}];`);
          let x = de(m, t, f, v);
          m.write(`${l}[${d}] = ${x};`);
        }), p.write("} else {"), p.indented((m) => {
          if (Nl(f)) {
            m.write(`${l}.length = ${d};`);
            return;
          }
          let v = N(t), x = N(t);
          m.write(`const ${v} = undefined;`), m.write(`const ${x} = (() => {`), m.indented((k) => {
            let R = de(k, t, f, v);
            k.write(`return ${R};`);
          }), m.write("})();"), m.write(`if (${x} === INVALID || ${x} === undefined) ${l}.length = ${d};`), m.write(`else ${l}[${d}] = ${x};`);
        }), p.write("}");
      }), e.write("}");
    else {
      let p = N(t);
      e.write(`const ${p} = ${o}[${d}];`);
      let m = de(e, t, f, p);
      e.write(`${l}[${d}] = ${m};`);
    }
  }
  if (a) {
    let d = N(t), f = N(t);
    e.write(`for (let ${d} = ${i.length}; ${d} < ${o}.length; ${d}++) {`), e.indented((p) => {
      p.write(`const ${f} = ${o}[${d}];`);
      let m = de(p, t, a, f);
      p.write(`${l}[${d}] = ${m};`);
    }), e.write("}");
  }
  return l;
}
s(V_, "generateTupleCheck");
function Bm(e, t) {
  for (let n = e.length - 1; n >= 0; n--)
    if (!(t === "optin" ? e[n]._zod.optin !== void 0 : e[n]._zod.optout === "optional"))
      return n + 1;
  return 0;
}
s(Bm, "getTupleOptStart");
function M_(e, t, n, o) {
  let r = n._zod.def, i = r.options;
  if (r.discriminator)
    return B_(e, t, r, o);
  if (r.inclusive === !1)
    throw new Z("exclusive unions (z.xor)");
  if (i.length === 0)
    return e.write("return INVALID;"), o;
  if (i.length === 1)
    return H(e, t, i[0], o);
  if (i.every((c) => c._zod.def.type === "literal" && !c._zod.def.checks?.length)) {
    let c = new Set(i.flatMap((d) => d._zod.def.values)), l = D(t, c);
    return e.write(`if (!${l}.has(${o})) return INVALID;`), o;
  }
  let u = N(t);
  e.write(`let ${u};`);
  for (let c = 0; c < i.length; c++) {
    let l = i[c];
    c === 0 ? e.write(`${u} = (() => {`) : e.write(`if (${u} === INVALID) ${u} = (() => {`), e.indented((d) => {
      let f = H(d, t, l, o);
      d.write(`return ${f};`);
    }), e.write("})();");
  }
  return e.write(`if (${u} === INVALID) return INVALID;`), u;
}
s(M_, "generateUnionCheck");
function B_(e, t, n, o) {
  if (n.unionFallback)
    throw new Z("discriminated union with unionFallback");
  if (n.options.length === 0)
    return e.write("return INVALID;"), o;
  let r = N(t), i = N(t);
  e.write(`const ${r} = ${o}?.[${pe(n.discriminator)}];`), e.write(`let ${i};`);
  let a = !0, u = /* @__PURE__ */ new Set();
  for (let c of n.options) {
    let l = c._zod.propValues?.[n.discriminator];
    if (!l || l.size === 0)
      throw new Z("discriminated union option without static discriminator values");
    for (let p of l) {
      if (u.has(p))
        throw new Z(`duplicate discriminator value ${String(p)}`);
      u.add(p);
    }
    let d = Array.from(l, (p) => J_(t, r, p)), f = a ? "if" : "else if";
    e.write(`${f} (${d.join(" || ")}) {`), e.indented((p) => {
      let m = H(p, t, c, o);
      p.write(`${i} = ${m};`);
    }), e.write("}"), a = !1;
  }
  return e.write("else { return INVALID; }"), i;
}
s(B_, "generateDiscriminatedUnionCheck");
function J_(e, t, n) {
  if (typeof n == "string")
    return `${t} === ${pe(n)}`;
  if (typeof n == "number")
    return Number.isNaN(n) ? `Number.isNaN(${t})` : `${t} === ${n}`;
  if (typeof n == "boolean")
    return `${t} === ${n}`;
  if (n === null)
    return `${t} === null`;
  if (n === void 0)
    return `${t} === undefined`;
  if (typeof n == "bigint")
    return `${t} === ${n}n`;
  if (typeof n == "symbol") {
    let o = D(e, n);
    return `${t} === ${o}`;
  }
  throw new Z(`literal discriminator value ${String(n)}`);
}
s(J_, "literalEquality");
function q_(e, t, n, o) {
  let r = n._zod.def, i = de(e, t, r.left, o), a = de(e, t, r.right, o), u = D(t, ar), c = N(t);
  return e.write(`const ${c} = ${u}(${i}, ${a});`), e.write(`if (!${c}.valid) return INVALID;`), `${c}.data`;
}
s(q_, "generateIntersectionCheck");
function W_(e, t, n, o) {
  let r = n._zod.def, i = D(t, Se);
  e.write(`if (!${i}(${o})) return INVALID;`);
  let a = N(t), u = N(t), c = N(t);
  e.write(`const ${a} = {};`);
  let l = r, d = l.partial ? void 0 : r.keyType._zod.values;
  if (d) {
    let v = [];
    for (let k of d) {
      if (!(typeof k == "string" || typeof k == "number" || typeof k == "symbol"))
        throw new Z(`record key value ${String(k)}`);
      let R = typeof k == "number" ? k.toString() : k;
      if (R === "__proto__")
        throw new Z('record key "__proto__"');
      v.push(R);
      let j = D(t, k), P = H(e, t, r.keyType, j), U = N(t);
      e.write(`const ${U} = ${o}[${K_(t, R)}];`);
      let V = de(e, t, r.valueType, U);
      e.write(`${a}[${P}] = ${V};`);
    }
    let x = D(t, new Set(v));
    return e.write(`for (const ${u} in ${o}) {`), e.indented((k) => {
      k.write(`if (${x}.has(${u})) continue;`), l.mode === "loose" ? k.write(`if (${u} !== "__proto__") ${a}[${u}] = ${o}[${u}];`) : k.write("return INVALID;");
    }), e.write("}"), a;
  }
  let f = r.keyType._zod.def;
  if (!(f.type === "string" && f.format === void 0 && !f.coerce && (f.checks?.length ?? 0) === 0)) {
    let v = r.mode === "loose", x = D(t, Hi(r.keyType)), k = D(t, Ye), R = D(t, Object.prototype.propertyIsEnumerable), j = N(t);
    return e.write(`for (const ${u} of Reflect.ownKeys(${o})) {`), e.indented((P) => {
      P.write(`if (${u} === "__proto__") continue;`), P.write(`if (!${R}.call(${o}, ${u})) continue;`), P.write(`let ${j} = ${x}(${u});`), P.write(`if (${j} === INVALID && typeof ${u} === "string" && ${k}.test(${u})) ${j} = ${x}(Number(${u}));`), v ? P.write(`if (${j} === INVALID) { ${a}[${u}] = ${o}[${u}]; continue; }`) : P.write(`if (${j} === INVALID) return INVALID;`), P.write(`if (${j} === "__proto__") continue;`);
      let U = N(t);
      P.write(`const ${U} = ${o}[${u}];`);
      let V = de(P, t, r.valueType, U);
      P.write(`${a}[${j}] = ${V};`);
    }), e.write("}"), a;
  }
  let m = D(t, Object.prototype.propertyIsEnumerable);
  return e.write(`for (const ${u} of Reflect.ownKeys(${o})) {`), e.indented((v) => {
    v.write(`if (${u} === "__proto__") continue;`), v.write(`if (!${m}.call(${o}, ${u})) continue;`), v.write(`if (typeof ${u} !== "string") return INVALID;`), v.write(`const ${c} = ${o}[${u}];`);
    let x = de(v, t, r.valueType, c);
    v.write(`${a}[${u}] = ${x};`);
  }), e.write("}"), a;
}
s(W_, "generateRecordCheck");
function K_(e, t) {
  return typeof t == "string" ? pe(t) : D(e, t);
}
s(K_, "literalPropertyKey");
function G_(e, t, n, o) {
  let r = n._zod.def;
  e.write(`if (!(${o} instanceof Map)) return INVALID;`);
  let i = N(t), a = N(t), u = N(t);
  return e.write(`const ${i} = new Map();`), e.write(`for (const [${a}, ${u}] of ${o}) {`), e.indented((c) => {
    let l = H(c, t, r.keyType, a), d = H(c, t, r.valueType, u);
    c.write(`${i}.set(${l}, ${d});`);
  }), e.write("}"), i;
}
s(G_, "generateMapCheck");
function X_(e, t, n, o) {
  let r = n._zod.def;
  e.write(`if (!(${o} instanceof Set)) return INVALID;`);
  let i = N(t), a = N(t);
  return e.write(`const ${i} = new Set();`), e.write(`for (const ${a} of ${o}) {`), e.indented((u) => {
    let c = H(u, t, r.valueType, a);
    u.write(`${i}.add(${c});`);
  }), e.write("}"), i;
}
s(X_, "generateSetCheck");
function H_(e, t) {
  return e.write(`if (!(${t} instanceof File)) return INVALID;`), t;
}
s(H_, "generateFileCheck");
function Q_(e, t, n, o) {
  e.write(`if (typeof ${o} !== "string") return INVALID;`);
  let r = n._zod.pattern;
  if (r) {
    let i = D(t, r);
    e.write(`${i}.lastIndex = 0;`), e.write(`if (!${i}.test(${o})) return INVALID;`);
  }
  return o;
}
s(Q_, "generateTemplateLiteralCheck");
function Y_(e, t, n, o) {
  let r = n._zod.def, i = D(t, r.getter), a = D(t, { parser: null });
  e.write(`if (!${a}.parser) {`), e.indented((c) => {
    c.write(`const inner = ${i}();`), c.write(`${a}.parser = function(input) {`), c.indented((l) => {
      l.write("const result = inner._zod.run({ value: input, issues: [] }, {});"), l.write("return result.issues.length === 0 ? result.value : INVALID;");
    }), c.write("};");
  }), e.write("}");
  let u = N(t);
  return e.write(`const ${u} = ${a}.parser(${o});`), e.write(`if (${u} === INVALID) return INVALID;`), u;
}
s(Y_, "generateLazyCheck");
function ex(e, t, n, o) {
  let r = n._zod.def, i = H(e, t, r.in, o);
  if (r.transform) {
    if (Dt(r.transform))
      throw new Ue("z.compile: async transforms in pipes are not supported");
    let a = r.transform, c = D(t, /* @__PURE__ */ s((d) => {
      let f = { value: d, issues: [], addIssue: Al }, p = a(d, f);
      return p instanceof Promise ? xe : f.issues.length === 0 ? p : xe;
    }, "helperFn")), l = N(t);
    return e.write(`const ${l} = ${c}(${i});`), e.write(`if (${l} === INVALID) return INVALID;`), H(e, t, r.out, l);
  } else
    return H(e, t, r.out, i);
}
s(ex, "generatePipeCheck");
function Dt(e) {
  return typeof e == "function" && (e.constructor.name === "AsyncFunction" || e[Symbol.toStringTag] === "AsyncFunction");
}
s(Dt, "isAsyncFunction");
function tx(e, t, n, o) {
  let r = n._zod.def;
  if (r.fn) {
    if (Dt(r.fn))
      throw new Ue("z.compile: async custom predicates are not supported");
    let i = D(t, r.fn), a = D(t, Dl), u = N(t);
    e.write(`const ${u} = ${i}(${o});`), e.write(`if (${u} instanceof Promise) ${a}();`), e.write(`if (!${u}) return INVALID;`);
  } else
    throw new Z("custom schema without a predicate function");
  return o;
}
s(tx, "generateCustomCheck");
function rx(e, t, n) {
  let o = e._zod.run({ value: n, issues: [] }, {});
  if (o && typeof o.then == "function")
    return xe;
  let r = o;
  return r.issues.length === 0 ? r.value : t();
}
s(rx, "runtimeCatch");
function nx(e, t, n, o) {
  let r = n._zod.def;
  if (!r.catchValue[fi])
    throw new Z("catch with a callback (only a constant catch value compiles)", !1);
  let i = N(t);
  e.write(`let ${i} = (() => {`), e.indented((l) => {
    let d = de(l, t, r.innerType, o);
    l.write(`return ${d};`);
  }), e.write("})();");
  let a = D(t, r.innerType), u = D(t, r.catchValue), c = D(t, rx);
  return e.write(`if (${i} === INVALID) {`), e.indented((l) => {
    l.write(`${i} = ${c}(${a}, ${u}, ${o});`), l.write(`if (${i} === INVALID) return INVALID;`);
  }), e.write("}"), i;
}
s(nx, "generateCatchCheck");
function ix(e, t, n, o) {
  let r = n._zod.def;
  if (r.transform) {
    if (Dt(r.transform))
      throw new Ue("z.compile: async transforms are not supported");
    let i = r.transform, u = D(t, /* @__PURE__ */ s((l) => {
      let d = { value: l, issues: [], addIssue: Al }, f = i(l, d);
      return f instanceof Promise ? xe : d.issues.length === 0 ? f : xe;
    }, "helperFn")), c = N(t);
    return e.write(`const ${c} = ${u}(${o});`), e.write(`if (${c} === INVALID) return INVALID;`), c;
  }
  return o;
}
s(ix, "generateTransformCheck");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/api.js
// @__NO_SIDE_EFFECTS__
function Ul(e, t) {
  return new e({
    type: "string",
    ...w(t)
  });
}
s(Ul, "_string");
// @__NO_SIDE_EFFECTS__
function El(e, t) {
  return new e({
    type: "string",
    coerce: !0,
    ...w(t)
  });
}
s(El, "_coercedString");
// @__NO_SIDE_EFFECTS__
function Qi(e, t) {
  return new e({
    type: "string",
    format: "email",
    check: "string_format",
    abort: !1,
    ...w(t)
  });
}
s(Qi, "_email");
// @__NO_SIDE_EFFECTS__
function Yi(e, t) {
  return new e({
    type: "string",
    format: "guid",
    check: "string_format",
    abort: !1,
    ...w(t)
  });
}
s(Yi, "_guid");
// @__NO_SIDE_EFFECTS__
function eo(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    ...w(t)
  });
}
s(eo, "_uuid");
// @__NO_SIDE_EFFECTS__
function to(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v4",
    ...w(t)
  });
}
s(to, "_uuidv4");
// @__NO_SIDE_EFFECTS__
function ro(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v6",
    ...w(t)
  });
}
s(ro, "_uuidv6");
// @__NO_SIDE_EFFECTS__
function no(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v7",
    ...w(t)
  });
}
s(no, "_uuidv7");
// @__NO_SIDE_EFFECTS__
function mn(e, t) {
  return new e({
    type: "string",
    format: "url",
    check: "string_format",
    abort: !1,
    ...w(t)
  });
}
s(mn, "_url");
// @__NO_SIDE_EFFECTS__
function io(e, t) {
  return new e({
    type: "string",
    format: "emoji",
    check: "string_format",
    abort: !1,
    ...w(t)
  });
}
s(io, "_emoji");
// @__NO_SIDE_EFFECTS__
function oo(e, t) {
  return new e({
    type: "string",
    format: "nanoid",
    check: "string_format",
    abort: !1,
    ...w(t)
  });
}
s(oo, "_nanoid");
// @__NO_SIDE_EFFECTS__
function ao(e, t) {
  return new e({
    type: "string",
    format: "cuid",
    check: "string_format",
    abort: !1,
    ...w(t)
  });
}
s(ao, "_cuid");
// @__NO_SIDE_EFFECTS__
function so(e, t) {
  return new e({
    type: "string",
    format: "cuid2",
    check: "string_format",
    abort: !1,
    ...w(t)
  });
}
s(so, "_cuid2");
// @__NO_SIDE_EFFECTS__
function uo(e, t) {
  return new e({
    type: "string",
    format: "ulid",
    check: "string_format",
    abort: !1,
    ...w(t)
  });
}
s(uo, "_ulid");
// @__NO_SIDE_EFFECTS__
function co(e, t) {
  return new e({
    type: "string",
    format: "xid",
    check: "string_format",
    abort: !1,
    ...w(t)
  });
}
s(co, "_xid");
// @__NO_SIDE_EFFECTS__
function lo(e, t) {
  return new e({
    type: "string",
    format: "ksuid",
    check: "string_format",
    abort: !1,
    ...w(t)
  });
}
s(lo, "_ksuid");
// @__NO_SIDE_EFFECTS__
function fo(e, t) {
  return new e({
    type: "string",
    format: "ipv4",
    check: "string_format",
    abort: !1,
    ...w(t)
  });
}
s(fo, "_ipv4");
// @__NO_SIDE_EFFECTS__
function po(e, t) {
  return new e({
    type: "string",
    format: "ipv6",
    check: "string_format",
    abort: !1,
    ...w(t)
  });
}
s(po, "_ipv6");
// @__NO_SIDE_EFFECTS__
function Cl(e, t) {
  return new e({
    type: "string",
    format: "mac",
    check: "string_format",
    abort: !1,
    ...w(t)
  });
}
s(Cl, "_mac");
// @__NO_SIDE_EFFECTS__
function mo(e, t) {
  return new e({
    type: "string",
    format: "cidrv4",
    check: "string_format",
    abort: !1,
    ...w(t)
  });
}
s(mo, "_cidrv4");
// @__NO_SIDE_EFFECTS__
function go(e, t) {
  return new e({
    type: "string",
    format: "cidrv6",
    check: "string_format",
    abort: !1,
    ...w(t)
  });
}
s(go, "_cidrv6");
// @__NO_SIDE_EFFECTS__
function ho(e, t) {
  return new e({
    type: "string",
    format: "base64",
    check: "string_format",
    abort: !1,
    ...w(t)
  });
}
s(ho, "_base64");
// @__NO_SIDE_EFFECTS__
function vo(e, t) {
  return new e({
    type: "string",
    format: "base64url",
    check: "string_format",
    abort: !1,
    ...w(t)
  });
}
s(vo, "_base64url");
// @__NO_SIDE_EFFECTS__
function yo(e, t) {
  return new e({
    type: "string",
    format: "e164",
    check: "string_format",
    abort: !1,
    ...w(t)
  });
}
s(yo, "_e164");
// @__NO_SIDE_EFFECTS__
function Zl(e, t) {
  return new e({
    type: "string",
    format: "credit_card",
    check: "string_format",
    abort: !1,
    ...w(t)
  });
}
s(Zl, "_creditCard");
// @__NO_SIDE_EFFECTS__
function $o(e, t) {
  return new e({
    type: "string",
    format: "jwt",
    check: "string_format",
    abort: !1,
    ...w(t)
  });
}
s($o, "_jwt");
var Rl = {
  Any: null,
  Minute: -1,
  Second: 0,
  Millisecond: 3,
  Microsecond: 6
};
// @__NO_SIDE_EFFECTS__
function gn(e, t) {
  return new e({
    type: "string",
    format: "datetime",
    check: "string_format",
    offset: !1,
    local: !1,
    precision: null,
    ...w(t)
  });
}
s(gn, "_isoDateTime");
// @__NO_SIDE_EFFECTS__
function hn(e, t) {
  return new e({
    type: "string",
    format: "date",
    check: "string_format",
    ...w(t)
  });
}
s(hn, "_isoDate");
// @__NO_SIDE_EFFECTS__
function vn(e, t) {
  return new e({
    type: "string",
    format: "time",
    check: "string_format",
    precision: null,
    ...w(t)
  });
}
s(vn, "_isoTime");
// @__NO_SIDE_EFFECTS__
function yn(e, t) {
  return new e({
    type: "string",
    format: "duration",
    check: "string_format",
    ...w(t)
  });
}
s(yn, "_isoDuration");
// @__NO_SIDE_EFFECTS__
function Fl(e, t) {
  return new e({
    type: "number",
    checks: [],
    ...w(t)
  });
}
s(Fl, "_number");
// @__NO_SIDE_EFFECTS__
function Ll(e, t) {
  return new e({
    type: "number",
    coerce: !0,
    checks: [],
    ...w(t)
  });
}
s(Ll, "_coercedNumber");
// @__NO_SIDE_EFFECTS__
function Vl(e, t) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "safeint",
    ...w(t)
  });
}
s(Vl, "_int");
// @__NO_SIDE_EFFECTS__
function Ml(e, t) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "float32",
    ...w(t)
  });
}
s(Ml, "_float32");
// @__NO_SIDE_EFFECTS__
function Bl(e, t) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "float64",
    ...w(t)
  });
}
s(Bl, "_float64");
// @__NO_SIDE_EFFECTS__
function Jl(e, t) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "int32",
    ...w(t)
  });
}
s(Jl, "_int32");
// @__NO_SIDE_EFFECTS__
function ql(e, t) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "uint32",
    ...w(t)
  });
}
s(ql, "_uint32");
// @__NO_SIDE_EFFECTS__
function Wl(e, t) {
  return new e({
    type: "boolean",
    ...w(t)
  });
}
s(Wl, "_boolean");
// @__NO_SIDE_EFFECTS__
function Kl(e, t) {
  return new e({
    type: "boolean",
    coerce: !0,
    ...w(t)
  });
}
s(Kl, "_coercedBoolean");
// @__NO_SIDE_EFFECTS__
function Gl(e, t) {
  return new e({
    type: "bigint",
    ...w(t)
  });
}
s(Gl, "_bigint");
// @__NO_SIDE_EFFECTS__
function Xl(e, t) {
  return new e({
    type: "bigint",
    coerce: !0,
    ...w(t)
  });
}
s(Xl, "_coercedBigint");
// @__NO_SIDE_EFFECTS__
function Hl(e, t) {
  return new e({
    type: "bigint",
    check: "bigint_format",
    abort: !1,
    format: "int64",
    ...w(t)
  });
}
s(Hl, "_int64");
// @__NO_SIDE_EFFECTS__
function Ql(e, t) {
  return new e({
    type: "bigint",
    check: "bigint_format",
    abort: !1,
    format: "uint64",
    ...w(t)
  });
}
s(Ql, "_uint64");
// @__NO_SIDE_EFFECTS__
function Yl(e, t) {
  return new e({
    type: "symbol",
    ...w(t)
  });
}
s(Yl, "_symbol");
// @__NO_SIDE_EFFECTS__
function ed(e, t) {
  return new e({
    type: "undefined",
    ...w(t)
  });
}
s(ed, "_undefined");
// @__NO_SIDE_EFFECTS__
function td(e, t) {
  return new e({
    type: "null",
    ...w(t)
  });
}
s(td, "_null");
// @__NO_SIDE_EFFECTS__
function rd(e) {
  return new e({
    type: "any"
  });
}
s(rd, "_any");
// @__NO_SIDE_EFFECTS__
function nd(e) {
  return new e({
    type: "unknown"
  });
}
s(nd, "_unknown");
// @__NO_SIDE_EFFECTS__
function id(e, t) {
  return new e({
    type: "never",
    ...w(t)
  });
}
s(id, "_never");
// @__NO_SIDE_EFFECTS__
function od(e, t) {
  return new e({
    type: "void",
    ...w(t)
  });
}
s(od, "_void");
// @__NO_SIDE_EFFECTS__
function ad(e, t) {
  return new e({
    type: "date",
    ...w(t)
  });
}
s(ad, "_date");
// @__NO_SIDE_EFFECTS__
function sd(e, t) {
  return new e({
    type: "date",
    coerce: !0,
    ...w(t)
  });
}
s(sd, "_coercedDate");
// @__NO_SIDE_EFFECTS__
function ud(e, t) {
  return new e({
    type: "nan",
    ...w(t)
  });
}
s(ud, "_nan");
// @__NO_SIDE_EFFECTS__
function Re(e, t) {
  return new zi({
    check: "less_than",
    ...w(t),
    value: e,
    inclusive: !1
  });
}
s(Re, "_lt");
// @__NO_SIDE_EFFECTS__
function we(e, t) {
  return new zi({
    check: "less_than",
    ...w(t),
    value: e,
    inclusive: !0
  });
}
s(we, "_lte");
// @__NO_SIDE_EFFECTS__
function Fe(e, t) {
  return new Si({
    check: "greater_than",
    ...w(t),
    value: e,
    inclusive: !1
  });
}
s(Fe, "_gt");
// @__NO_SIDE_EFFECTS__
function ke(e, t) {
  return new Si({
    check: "greater_than",
    ...w(t),
    value: e,
    inclusive: !0
  });
}
s(ke, "_gte");
// @__NO_SIDE_EFFECTS__
function bo(e) {
  return /* @__PURE__ */ Fe(0, e);
}
s(bo, "_positive");
// @__NO_SIDE_EFFECTS__
function _o(e) {
  return /* @__PURE__ */ Re(0, e);
}
s(_o, "_negative");
// @__NO_SIDE_EFFECTS__
function xo(e) {
  return /* @__PURE__ */ we(0, e);
}
s(xo, "_nonpositive");
// @__NO_SIDE_EFFECTS__
function wo(e) {
  return /* @__PURE__ */ ke(0, e);
}
s(wo, "_nonnegative");
// @__NO_SIDE_EFFECTS__
function it(e, t) {
  return new Qs({
    check: "multiple_of",
    ...w(t),
    value: e
  });
}
s(it, "_multipleOf");
// @__NO_SIDE_EFFECTS__
function ot(e, t) {
  return new tu({
    check: "max_size",
    ...w(t),
    maximum: e
  });
}
s(ot, "_maxSize");
// @__NO_SIDE_EFFECTS__
function Le(e, t) {
  return new ru({
    check: "min_size",
    ...w(t),
    minimum: e
  });
}
s(Le, "_minSize");
// @__NO_SIDE_EFFECTS__
function Nt(e, t) {
  return new nu({
    check: "size_equals",
    ...w(t),
    size: e
  });
}
s(Nt, "_size");
// @__NO_SIDE_EFFECTS__
function Tt(e, t) {
  return new iu({
    check: "max_length",
    ...w(t),
    maximum: e
  });
}
s(Tt, "_maxLength");
// @__NO_SIDE_EFFECTS__
function Je(e, t) {
  return new ou({
    check: "min_length",
    ...w(t),
    minimum: e
  });
}
s(Je, "_minLength");
// @__NO_SIDE_EFFECTS__
function At(e, t) {
  return new au({
    check: "length_equals",
    ...w(t),
    length: e
  });
}
s(At, "_length");
// @__NO_SIDE_EFFECTS__
function dr(e, t) {
  return new su({
    check: "string_format",
    format: "regex",
    ...w(t),
    pattern: e
  });
}
s(dr, "_regex");
// @__NO_SIDE_EFFECTS__
function fr(e) {
  return new uu({
    check: "string_format",
    format: "lowercase",
    ...w(e)
  });
}
s(fr, "_lowercase");
// @__NO_SIDE_EFFECTS__
function pr(e) {
  return new cu({
    check: "string_format",
    format: "uppercase",
    ...w(e)
  });
}
s(pr, "_uppercase");
// @__NO_SIDE_EFFECTS__
function mr(e, t) {
  return new lu({
    check: "string_format",
    format: "includes",
    ...w(t),
    includes: e
  });
}
s(mr, "_includes");
// @__NO_SIDE_EFFECTS__
function gr(e, t) {
  return new du({
    check: "string_format",
    format: "starts_with",
    ...w(t),
    prefix: e
  });
}
s(gr, "_startsWith");
// @__NO_SIDE_EFFECTS__
function hr(e, t) {
  return new fu({
    check: "string_format",
    format: "ends_with",
    ...w(t),
    suffix: e
  });
}
s(hr, "_endsWith");
// @__NO_SIDE_EFFECTS__
function ko(e, t, n) {
  return new Oi({
    check: "property",
    property: e,
    schema: t,
    ...w(n)
  });
}
s(ko, "_property");
// @__NO_SIDE_EFFECTS__
function Io(e) {
  return Object.entries(e).map(([t, n]) => new Oi({ check: "property", property: t, schema: n }));
}
s(Io, "_properties");
// @__NO_SIDE_EFFECTS__
function vr(e, t) {
  return new pu({
    check: "mime_type",
    mime: e,
    ...w(t)
  });
}
s(vr, "_mime");
// @__NO_SIDE_EFFECTS__
function Ee(e) {
  return new mu({
    check: "overwrite",
    tx: e
  });
}
s(Ee, "_overwrite");
// @__NO_SIDE_EFFECTS__
function yr(e) {
  return /* @__PURE__ */ Ee((t) => t.normalize(e));
}
s(yr, "_normalize");
// @__NO_SIDE_EFFECTS__
function $r() {
  return /* @__PURE__ */ Ee((e) => e.trim());
}
s($r, "_trim");
// @__NO_SIDE_EFFECTS__
function br() {
  return /* @__PURE__ */ Ee((e) => e.toLowerCase());
}
s(br, "_toLowerCase");
// @__NO_SIDE_EFFECTS__
function _r() {
  return /* @__PURE__ */ Ee((e) => e.toUpperCase());
}
s(_r, "_toUpperCase");
// @__NO_SIDE_EFFECTS__
function xr() {
  return /* @__PURE__ */ Ee((e) => Ya(e));
}
s(xr, "_slugify");
// @__NO_SIDE_EFFECTS__
function cd(e, t, n) {
  return new e({
    type: "array",
    element: t,
    // get element() {
    //   return element;
    // },
    ...w(n)
  });
}
s(cd, "_array");
// @__NO_SIDE_EFFECTS__
function ox(e, t, n) {
  return new e({
    type: "union",
    options: t,
    ...w(n)
  });
}
s(ox, "_union");
function ax(e, t, n) {
  return new e({
    type: "union",
    options: t,
    inclusive: !1,
    ...w(n)
  });
}
s(ax, "_xor");
// @__NO_SIDE_EFFECTS__
function sx(e, t, n, o) {
  return new e({
    type: "union",
    options: n,
    discriminator: t,
    ...w(o)
  });
}
s(sx, "_discriminatedUnion");
// @__NO_SIDE_EFFECTS__
function ux(e, t, n) {
  return new e({
    type: "intersection",
    left: t,
    right: n
  });
}
s(ux, "_intersection");
// @__NO_SIDE_EFFECTS__
function cx(e, t, n, o) {
  let r = n instanceof O, i = r ? o : n, a = r ? n : null;
  return new e({
    type: "tuple",
    items: t,
    rest: a,
    ...w(i)
  });
}
s(cx, "_tuple");
// @__NO_SIDE_EFFECTS__
function lx(e, t, n, o) {
  return new e({
    type: "record",
    keyType: t,
    valueType: n,
    ...w(o)
  });
}
s(lx, "_record");
// @__NO_SIDE_EFFECTS__
function dx(e, t, n, o) {
  return new e({
    type: "map",
    keyType: t,
    valueType: n,
    ...w(o)
  });
}
s(dx, "_map");
// @__NO_SIDE_EFFECTS__
function fx(e, t, n) {
  return new e({
    type: "set",
    valueType: t,
    ...w(n)
  });
}
s(fx, "_set");
// @__NO_SIDE_EFFECTS__
function px(e, t, n) {
  let o = Array.isArray(t) ? Object.fromEntries(t.map((r) => [r, r])) : t;
  return new e({
    type: "enum",
    entries: o,
    ...w(n)
  });
}
s(px, "_enum");
// @__NO_SIDE_EFFECTS__
function mx(e, t, n) {
  return new e({
    type: "enum",
    entries: t,
    ...w(n)
  });
}
s(mx, "_nativeEnum");
// @__NO_SIDE_EFFECTS__
function gx(e, t, n) {
  return new e({
    type: "literal",
    values: Array.isArray(t) ? t : [t],
    ...w(n)
  });
}
s(gx, "_literal");
// @__NO_SIDE_EFFECTS__
function ld(e, t) {
  return new e({
    type: "file",
    ...w(t)
  });
}
s(ld, "_file");
// @__NO_SIDE_EFFECTS__
function hx(e, t) {
  return new e({
    type: "transform",
    transform: t
  });
}
s(hx, "_transform");
// @__NO_SIDE_EFFECTS__
function vx(e, t) {
  return new e({
    type: "optional",
    innerType: t
  });
}
s(vx, "_optional");
// @__NO_SIDE_EFFECTS__
function yx(e, t) {
  return new e({
    type: "nullable",
    innerType: t
  });
}
s(yx, "_nullable");
// @__NO_SIDE_EFFECTS__
function $x(e, t, n) {
  return new e({
    type: "default",
    innerType: t,
    get defaultValue() {
      return typeof n == "function" ? n() : Kr(n);
    }
  });
}
s($x, "_default");
// @__NO_SIDE_EFFECTS__
function bx(e, t, n) {
  return new e({
    type: "nonoptional",
    innerType: t,
    ...w(n)
  });
}
s(bx, "_nonoptional");
// @__NO_SIDE_EFFECTS__
function _x(e, t) {
  return new e({
    type: "success",
    innerType: t
  });
}
s(_x, "_success");
// @__NO_SIDE_EFFECTS__
function xx(e, t, n) {
  return new e({
    type: "catch",
    innerType: t,
    catchValue: typeof n == "function" ? n : us(n)
  });
}
s(xx, "_catch");
// @__NO_SIDE_EFFECTS__
function wx(e, t, n) {
  return new e({
    type: "pipe",
    in: t,
    out: n
  });
}
s(wx, "_pipe");
// @__NO_SIDE_EFFECTS__
function kx(e, t) {
  return new e({
    type: "readonly",
    innerType: t
  });
}
s(kx, "_readonly");
// @__NO_SIDE_EFFECTS__
function Ix(e, t, n) {
  return new e({
    type: "template_literal",
    parts: t,
    ...w(n)
  });
}
s(Ix, "_templateLiteral");
// @__NO_SIDE_EFFECTS__
function zx(e, t) {
  return new e({
    type: "lazy",
    getter: t
  });
}
s(zx, "_lazy");
// @__NO_SIDE_EFFECTS__
function Sx(e, t) {
  return new e({
    type: "promise",
    innerType: t
  });
}
s(Sx, "_promise");
// @__NO_SIDE_EFFECTS__
function dd(e, t, n) {
  let o = w(n);
  return o.abort ?? (o.abort = !0), new e({
    type: "custom",
    check: "custom",
    fn: t,
    ...o
  });
}
s(dd, "_custom");
// @__NO_SIDE_EFFECTS__
function fd(e, t, n) {
  return new e({
    type: "custom",
    check: "custom",
    fn: t,
    ...w(n)
  });
}
s(fd, "_refine");
// @__NO_SIDE_EFFECTS__
function pd(e, t) {
  let n = /* @__PURE__ */ Km((o) => (o.addIssue = (r) => {
    if (typeof r == "string")
      o.issues.push(er(r, o.value, n._zod.def));
    else {
      let i = r;
      i.fatal && (i.continue = !1), i.code ?? (i.code = "custom"), "input" in i || (i.input = o.value), i.inst ?? (i.inst = n), i.continue ?? (i.continue = !n._zod.def.abort), o.issues.push(er(i));
    }
  }, e(o.value, o)), t);
  return n;
}
s(pd, "_superRefine");
// @__NO_SIDE_EFFECTS__
function Km(e, t) {
  let n = new K({
    check: "custom",
    ...w(t)
  });
  return n._zod.check = e, n;
}
s(Km, "_check");
// @__NO_SIDE_EFFECTS__
function md(e) {
  let t = new K({ check: "describe" });
  return t._zod.onattach = [
    (n) => {
      let o = se.get(n) ?? {};
      se.add(n, { ...o, description: e });
    }
  ], t._zod.check = () => {
  }, t;
}
s(md, "describe");
// @__NO_SIDE_EFFECTS__
function gd(e) {
  let t = new K({ check: "meta" });
  return t._zod.onattach = [
    (n) => {
      let o = se.get(n) ?? {};
      se.add(n, { ...o, ...e });
    }
  ], t._zod.check = () => {
  }, t;
}
s(gd, "meta");
// @__NO_SIDE_EFFECTS__
function hd(e, t) {
  let n = w(t), o = n.truthy ?? ["true", "1", "yes", "on", "y", "enabled"], r = n.falsy ?? ["false", "0", "no", "off", "n", "disabled"];
  n.case !== "sensitive" && (o = o.map((m) => typeof m == "string" ? m.toLowerCase() : m), r = r.map((m) => typeof m == "string" ? m.toLowerCase() : m));
  let i = new Set(o), a = new Set(r), u = e.Codec ?? Ae, c = e.Boolean ?? an, l = e.String ?? zt, d = new l({ type: "string", error: n.error }), f = new c({ type: "boolean", error: n.error }), p = new u({
    type: "pipe",
    in: d,
    out: f,
    transform: /* @__PURE__ */ s(((m, v) => {
      let x = m;
      return n.case !== "sensitive" && (x = x.toLowerCase()), i.has(x) ? !0 : a.has(x) ? !1 : (v.issues.push({
        code: "invalid_value",
        expected: "stringbool",
        values: [...i, ...a],
        input: v.value,
        inst: p,
        continue: !1
      }), {});
    }), "transform"),
    reverseTransform: /* @__PURE__ */ s(((m, v) => m === !0 ? o[0] || "true" : r[0] || "false"), "reverseTransform"),
    error: n.error
  });
  return p._zod.bag.truthy = o, p._zod.bag.falsy = r, p._zod.bag.case = n.case ?? "insensitive", p;
}
s(hd, "_stringbool");
// @__NO_SIDE_EFFECTS__
function wr(e, t, n, o = {}) {
  let r = w(o), i = {
    check: "string_format",
    type: "string",
    format: t,
    fn: typeof n == "function" ? n : (u) => n.test(u),
    ...r
  };
  return n instanceof RegExp && (i.pattern = n), new e(i);
}
s(wr, "_stringFormat");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/to-json-schema.js
function $n(e, ...t) {
  for (let n of t)
    for (let o of Reflect.ownKeys(n))
      Object.prototype.propertyIsEnumerable.call(n, o) && Y(e, o, n[o]);
  return e;
}
s($n, "assignProps");
function at(e) {
  let t = e?.target ?? "draft-2020-12";
  return t === "draft-4" && (t = "draft-04"), t === "draft-7" && (t = "draft-07"), {
    processors: e.processors ?? {},
    metadataRegistry: e?.metadata ?? se,
    target: t,
    unrepresentable: e?.unrepresentable ?? "throw",
    override: e?.override ?? (() => {
    }),
    io: e?.io ?? "output",
    counter: 0,
    seen: /* @__PURE__ */ new Map(),
    sharedDefsExtractedFor: void 0,
    sharedEmitDoneFor: void 0,
    cycles: e?.cycles ?? "ref",
    reused: e?.reused ?? "inline",
    intersections: [],
    deferred: [],
    external: e?.external ?? void 0
  };
}
s(at, "initializeContext");
function oe(e, t, n, o, r) {
  let i = typeof t.unrepresentable == "function" ? t.unrepresentable({ zodSchema: e, path: o.path, message: r }) : t.unrepresentable;
  if (i === "any")
    return !1;
  if (i === void 0 || i === "throw")
    throw new Error(r);
  return Object.assign(n, i), !0;
}
s(oe, "handleUnrepresentable");
function M(e, t, n = { path: [], schemaPath: [] }) {
  var o;
  let r = e._zod.def, i = t.seen.get(e);
  if (i)
    return i.count++, n.schemaPath.includes(e) && (i.cycle = n.path), i.schema;
  let a = { schema: {}, count: 1, cycle: void 0, path: n.path };
  t.seen.set(e, a), t.sharedDefsExtractedFor = void 0, t.sharedEmitDoneFor = void 0;
  let u = e._zod.toJSONSchema?.();
  if (u)
    a.schema = u;
  else {
    let d = {
      ...n,
      schemaPath: [...n.schemaPath, e],
      path: n.path
    };
    if (e._zod.processJSONSchema)
      e._zod.processJSONSchema(t, a.schema, d);
    else {
      let p = a.schema, m = t.processors[r.type];
      if (!m)
        throw new Error(`[toJSONSchema]: Non-representable type encountered: ${r.type}`);
      m(e, t, p, d);
    }
    let f = e._zod.parent;
    f && (a.ref || (a.ref = f), M(f, t, d), t.seen.get(f).isParent = !0);
  }
  let c = t.metadataRegistry.get(e);
  return c && $n(a.schema, c), t.io === "input" && fe(e) && (delete a.schema.examples, delete a.schema.default), t.io === "input" && "_prefault" in a.schema && ((o = a.schema).default ?? (o.default = a.schema._prefault)), delete a.schema._prefault, t.seen.get(e).schema;
}
s(M, "process");
function Gm(e) {
  return e.replace(/~/g, "~0").replace(/\//g, "~1");
}
s(Gm, "encodeJSONPointerSegment");
function st(e, t) {
  let n = e.seen.get(t);
  if (!n)
    throw new Error("Unprocessed schema. This is a bug in Zod.");
  if (e.external && e.sharedDefsExtractedFor === e.external)
    return;
  let o = /* @__PURE__ */ new Map();
  for (let a of e.seen.entries()) {
    let u = e.metadataRegistry.get(a[0])?.id;
    if (u) {
      let c = o.get(u);
      if (c && c !== a[0])
        throw new Error(`Duplicate schema id "${u}" detected during JSON Schema conversion. Two different schemas cannot share the same id when converted together.`);
      o.set(u, a[0]);
    }
  }
  let r = /* @__PURE__ */ s((a) => {
    let u = e.target === "draft-2020-12" ? "$defs" : "definitions";
    if (e.external) {
      let f = e.external.registry.get(a[0])?.id, p = e.external.uri ?? ((v) => v);
      if (f)
        return { ref: p(f) };
      let m = a[1].defId ?? a[1].schema.id ?? `schema${e.counter++}`;
      return a[1].defId = m, { defId: m, ref: `${p("__shared")}#/${u}/${Gm(m)}` };
    }
    let c = "#", l = `${c}/${u}/`;
    if (a[1] === n && !a[1].schema.id)
      return { ref: c };
    let d = a[1].schema.id ?? `__schema${e.counter++}`;
    return { defId: d, ref: l + Gm(d) };
  }, "makeURI"), i = /* @__PURE__ */ s((a) => {
    if (a[1].schema.$ref)
      return;
    let u = a[1], { ref: c, defId: l } = r(a);
    u.def = { ...u.schema }, l && (u.defId = l);
    let d = u.schema;
    for (let f in d)
      delete d[f];
    d.$ref = c;
  }, "extractToDef");
  if (e.cycles === "throw")
    for (let a of e.seen.entries()) {
      let u = a[1];
      if (u.cycle)
        throw new Error(`Cycle detected: #/${u.cycle?.join("/")}/<root>

Set the \`cycles\` parameter to \`"ref"\` to resolve cyclical schemas with defs.`);
    }
  for (let a of e.seen.entries()) {
    let u = a[1];
    if (t === a[0]) {
      i(a);
      continue;
    }
    if (e.external) {
      let l = e.external.registry.get(a[0])?.id;
      if (t !== a[0] && l) {
        i(a);
        continue;
      }
    }
    if (e.metadataRegistry.get(a[0])?.id) {
      i(a);
      continue;
    }
    if (u.cycle) {
      i(a);
      continue;
    }
    if (u.count > 1 && e.reused === "ref") {
      i(a);
      continue;
    }
  }
  e.external && (e.sharedDefsExtractedFor = e.external);
}
s(st, "extractDefs");
function Qm(e) {
  let t = e.anyOf;
  if (!Array.isArray(t) || t.length === 0 || e.type !== void 0)
    return;
  let n = [];
  for (let o of t) {
    if (!o || typeof o != "object")
      return;
    Qm(o);
    let r = Object.keys(o);
    if (r.length !== 1 || r[0] !== "type")
      return;
    let i = o.type;
    for (let a of Array.isArray(i) ? i : [i]) {
      if (typeof a != "string")
        return;
      n.includes(a) || n.push(a);
    }
  }
  delete e.anyOf, e.type = n.length === 1 ? n[0] : n;
}
s(Qm, "compactTypeUnion");
var Ym = /* @__PURE__ */ new Set(["type", "properties", "required", "additionalProperties"]), Xm = ["oneOf", "anyOf"];
function Hm(e) {
  let t = e.additionalProperties;
  return t === void 0 || t === !1 || typeof t != "object" || t === null ? null : Object.keys(t).length ? t : null;
}
s(Hm, "undeclaredConstraint");
function vd(e) {
  let t = [];
  for (let i of e) {
    if (typeof i != "object" || i.type !== "object")
      return null;
    for (let a in i)
      if (!Ym.has(a))
        return null;
    t.push(i);
  }
  let n = {}, o = /* @__PURE__ */ new Set();
  for (let i of t) {
    for (let a in i.properties) {
      if (Object.prototype.hasOwnProperty.call(n, a))
        continue;
      let u = [];
      for (let l of t) {
        let d = l.properties?.[a] ?? Hm(l);
        d != null && (u.some((f) => JSON.stringify(f) === JSON.stringify(d)) || u.push(d));
      }
      let c = u.length === 1 ? u[0] : vd(u) ?? { allOf: u };
      Y(n, a, c);
    }
    for (let a of i.required ?? [])
      o.add(a);
  }
  let r = { type: "object", properties: n };
  if (o.size && (r.required = [...o]), t.every((i) => i.additionalProperties === !1))
    r.additionalProperties = !1;
  else {
    let i = [];
    for (let a of t) {
      let u = Hm(a);
      u && !i.some((c) => JSON.stringify(c) === JSON.stringify(u)) && i.push(u);
    }
    i.length === 1 ? r.additionalProperties = i[0] : i.length > 1 && (r.additionalProperties = { allOf: i });
  }
  return r;
}
s(vd, "foldObjects");
function Ox(e) {
  let t = e.allOf;
  if (!Array.isArray(t) || t.length < 2)
    return;
  for (let r of Ym)
    if (r in e)
      return;
  let n = t.filter((r) => Xm.some((i) => Array.isArray(r[i]))), o = null;
  if (!n.length)
    o = vd(t);
  else {
    let r = n[0], i = Xm.find((c) => Array.isArray(r[c]));
    if (Object.keys(r).length !== 1)
      return;
    let a = t.filter((c) => c !== r), u = r[i].map((c) => vd([...a, c]));
    if (u.some((c) => !c))
      return;
    o = { [i]: u };
  }
  o && (delete e.allOf, $n(e, o));
}
s(Ox, "foldIntersection");
function ut(e, t) {
  let n = e.seen.get(t);
  if (!n)
    throw new Error("Unprocessed schema. This is a bug in Zod.");
  let o = /* @__PURE__ */ s((u) => {
    let c = e.seen.get(u);
    if (c.ref === null)
      return;
    let l = c.def ?? c.schema, d = { ...l }, f = c.ref;
    if (c.ref = null, f) {
      o(f);
      let m = e.seen.get(f), v = m.schema;
      if (v.$ref && (e.target === "draft-07" || e.target === "draft-04" || e.target === "openapi-3.0") ? (l.allOf = l.allOf ?? [], l.allOf.push(v)) : $n(l, v), $n(l, d), u._zod.parent === f)
        for (let k in l)
          k === "$ref" || k === "allOf" || k in d || delete l[k];
      if (v.$ref && m.def)
        for (let k in l)
          k === "$ref" || k === "allOf" || k in m.def && JSON.stringify(l[k]) === JSON.stringify(m.def[k]) && delete l[k];
    }
    let p = u._zod.parent;
    if (p && p !== f) {
      o(p);
      let m = e.seen.get(p);
      if (m?.schema.$ref && (l.$ref = m.schema.$ref, m.def))
        for (let v in l)
          v === "$ref" || v === "allOf" || v in m.def && JSON.stringify(l[v]) === JSON.stringify(m.def[v]) && delete l[v];
    }
    e.override({
      zodSchema: u,
      jsonSchema: l,
      path: c.path ?? []
    });
  }, "flattenRef");
  if (!e.external || e.sharedEmitDoneFor !== e.external) {
    for (let u of [...e.seen.entries()].reverse())
      o(u[0]);
    if (e.target !== "openapi-3.0")
      for (let u of e.seen.entries())
        Qm(u[1].def ?? u[1].schema);
    for (let u of e.deferred)
      u();
    if (e.intersections.length) {
      let u = /* @__PURE__ */ new Map();
      for (let c of e.seen.values())
        for (let l of [c.schema, c.def]) {
          let d = l?.allOf;
          if (!Array.isArray(d))
            continue;
          let f = u.get(d);
          f ? f.push(l) : u.set(d, [l]);
        }
      for (let c of e.intersections)
        for (let l of u.get(c) ?? [])
          Ox(l);
    }
  }
  let r = {};
  if (e.target === "draft-2020-12" ? r.$schema = "https://json-schema.org/draft/2020-12/schema" : e.target === "draft-07" ? r.$schema = "http://json-schema.org/draft-07/schema#" : e.target === "draft-04" ? r.$schema = "http://json-schema.org/draft-04/schema#" : e.target, e.external?.uri) {
    let u = e.external.registry.get(t)?.id;
    if (!u)
      throw new Error("Schema is missing an `id` property");
    r.$id = e.external.uri(u);
  }
  $n(r, n.defId ? n.schema : n.def ?? n.schema);
  let i = e.metadataRegistry.get(t)?.id;
  i !== void 0 && r.id === i && delete r.id;
  let a = e.external?.defs ?? {};
  if (!e.external || e.sharedEmitDoneFor !== e.external)
    for (let u of e.seen.entries()) {
      let c = u[1];
      c.def && c.defId && (c.def.id === c.defId && delete c.def.id, Y(a, c.defId, c.def));
    }
  e.external && (e.sharedEmitDoneFor = e.external), e.external || Object.keys(a).length > 0 && (e.target === "draft-2020-12" ? r.$defs = a : r.definitions = a);
  try {
    let u = JSON.parse(JSON.stringify(r));
    return Object.defineProperty(u, "~standard", {
      value: {
        ...t["~standard"],
        jsonSchema: {
          input: kr(t, "input", e.processors),
          output: kr(t, "output", e.processors)
        }
      },
      enumerable: !1,
      writable: !1
    }), u;
  } catch {
    throw new Error("Error converting schema to JSON.");
  }
}
s(ut, "finalize");
function fe(e, t) {
  let n = t ?? { seen: /* @__PURE__ */ new Set() };
  if (n.seen.has(e))
    return !1;
  n.seen.add(e);
  let o = e._zod.def;
  if (o.type === "transform")
    return !0;
  if (o.type === "array")
    return fe(o.element, n);
  if (o.type === "set")
    return fe(o.valueType, n);
  if (o.type === "lazy")
    return fe(o.getter(), n);
  if (o.type === "promise" || o.type === "optional" || o.type === "nonoptional" || o.type === "nullable" || o.type === "readonly" || o.type === "default" || o.type === "prefault" || o.type === "catch")
    return fe(o.innerType, n);
  if (o.type === "intersection")
    return fe(o.left, n) || fe(o.right, n);
  if (o.type === "record" || o.type === "map")
    return fe(o.keyType, n) || fe(o.valueType, n);
  if (o.type === "pipe")
    return e._zod.traits.has("$ZodCodec") ? !0 : fe(o.in, n) || fe(o.out, n);
  if (o.type === "object") {
    for (let r in o.shape)
      if (fe(o.shape[r], n))
        return !0;
    return !1;
  }
  if (o.type === "union") {
    for (let r of o.options)
      if (fe(r, n))
        return !0;
    return !1;
  }
  if (o.type === "tuple") {
    for (let r of o.items)
      if (fe(r, n))
        return !0;
    return !!(o.rest && fe(o.rest, n));
  }
  return !1;
}
s(fe, "isTransforming");
var yd = /* @__PURE__ */ s((e, t = {}) => (n) => {
  let o = at({ ...n, processors: t });
  return M(e, o), st(o, e), ut(o, e);
}, "createToJSONSchemaMethod"), kr = /* @__PURE__ */ s((e, t, n = {}) => (o) => {
  let { libraryOptions: r, target: i } = o ?? {}, a = at({ ...r ?? {}, target: i, io: t, processors: n });
  return M(e, a), st(a, e), ut(a, e);
}, "createStandardJSONSchemaMethod");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/json-schema-processors.js
var jx = {
  guid: "uuid",
  url: "uri",
  datetime: "date-time",
  json_string: "json-string",
  regex: ""
  // do not set
}, _d = /* @__PURE__ */ s((e, t, n, o) => {
  let r = n;
  r.type = "string";
  let { minimum: i, maximum: a, format: u, patterns: c, contentEncoding: l, laxFormat: d } = e._zod.bag;
  if (typeof i == "number" && (r.minLength = i), typeof a == "number" && (r.maxLength = a), u && (r.format = jx[u] ?? u, r.format === "" && delete r.format, (u === "time" || d) && delete r.format), l && (r.contentEncoding = l), c && c.size > 0) {
    let f = [...c];
    f.length === 1 ? r.pattern = f[0].source : f.length > 1 && (r.allOf = [
      ...f.map((p) => ({
        ...t.target === "draft-07" || t.target === "draft-04" || t.target === "openapi-3.0" ? { type: "string" } : {},
        pattern: p.source
      }))
    ]);
  }
}, "stringProcessor"), xd = /* @__PURE__ */ s((e, t, n, o) => {
  let r = n, { minimum: i, maximum: a, format: u, multipleOf: c, exclusiveMaximum: l, exclusiveMinimum: d } = e._zod.bag;
  typeof u == "string" && u.includes("int") ? r.type = "integer" : r.type = "number";
  let f = typeof d == "number" && d >= (i ?? Number.NEGATIVE_INFINITY), p = typeof l == "number" && l <= (a ?? Number.POSITIVE_INFINITY), m = t.target === "draft-04" || t.target === "openapi-3.0";
  f ? m ? (r.minimum = d, r.exclusiveMinimum = !0) : r.exclusiveMinimum = d : typeof i == "number" && (r.minimum = i), p ? m ? (r.maximum = l, r.exclusiveMaximum = !0) : r.exclusiveMaximum = l : typeof a == "number" && (r.maximum = a), typeof c == "number" && (Number.isFinite(c) && c !== 0 ? r.multipleOf = Math.abs(c) : oe(e, t, r, o, `A multipleOf divisor of ${c} cannot be represented in JSON Schema`));
}, "numberProcessor"), wd = /* @__PURE__ */ s((e, t, n, o) => {
  n.type = "boolean";
}, "booleanProcessor"), kd = /* @__PURE__ */ s((e, t, n, o) => {
  oe(e, t, n, o, "BigInt cannot be represented in JSON Schema");
}, "bigintProcessor"), Id = /* @__PURE__ */ s((e, t, n, o) => {
  oe(e, t, n, o, "Symbols cannot be represented in JSON Schema");
}, "symbolProcessor"), zd = /* @__PURE__ */ s((e, t, n, o) => {
  t.target === "openapi-3.0" ? (n.type = "string", n.nullable = !0, n.enum = [null]) : n.type = "null";
}, "nullProcessor"), Sd = /* @__PURE__ */ s((e, t, n, o) => {
  oe(e, t, n, o, "Undefined cannot be represented in JSON Schema");
}, "undefinedProcessor"), Od = /* @__PURE__ */ s((e, t, n, o) => {
  oe(e, t, n, o, "Void cannot be represented in JSON Schema");
}, "voidProcessor"), jd = /* @__PURE__ */ s((e, t, n, o) => {
  n.not = {};
}, "neverProcessor"), Pd = /* @__PURE__ */ s((e, t, n, o) => {
}, "anyProcessor"), Dd = /* @__PURE__ */ s((e, t, n, o) => {
}, "unknownProcessor"), Nd = /* @__PURE__ */ s((e, t, n, o) => {
  oe(e, t, n, o, "Date cannot be represented in JSON Schema");
}, "dateProcessor"), Td = /* @__PURE__ */ s((e, t, n, o) => {
  let r = e._zod.def, i = Jr(r.entries);
  if (i.length === 0) {
    n.not = {};
    return;
  }
  i.every((a) => typeof a == "number") && (n.type = "number"), i.every((a) => typeof a == "string") && (n.type = "string"), n.enum = i;
}, "enumProcessor"), Ad = /* @__PURE__ */ s((e, t, n, o) => {
  let r = e._zod.def;
  if (r.values.length === 0) {
    n.not = {};
    return;
  }
  let i = [];
  for (let a of r.values)
    if (a === void 0) {
      if (oe(e, t, n, o, "Literal `undefined` cannot be represented in JSON Schema"))
        return;
    } else if (typeof a == "bigint") {
      if (oe(e, t, n, o, "BigInt literals cannot be represented in JSON Schema"))
        return;
      i.push(Number(a));
    } else
      i.push(a);
  if (i.length !== 0)
    if (i.length === 1) {
      let a = i[0];
      n.type = a === null ? "null" : typeof a, t.target === "draft-04" || t.target === "openapi-3.0" ? n.enum = [a] : n.const = a;
    } else
      i.every((a) => typeof a == "number") && (n.type = "number"), i.every((a) => typeof a == "string") && (n.type = "string"), i.every((a) => typeof a == "boolean") && (n.type = "boolean"), i.every((a) => a === null) && (n.type = "null"), n.enum = i;
}, "literalProcessor"), Ud = /* @__PURE__ */ s((e, t, n, o) => {
  oe(e, t, n, o, "NaN cannot be represented in JSON Schema");
}, "nanProcessor"), Ed = /* @__PURE__ */ s((e, t, n, o) => {
  let r = n, i = e._zod.pattern;
  if (!i)
    throw new Error("Pattern not found in template literal");
  r.type = "string", r.pattern = i.source;
}, "templateLiteralProcessor"), Cd = /* @__PURE__ */ s((e, t, n, o) => {
  let r = n, i = {
    type: "string",
    format: "binary",
    contentEncoding: "binary"
  }, { minimum: a, maximum: u, mime: c } = e._zod.bag;
  a !== void 0 && (i.minLength = a), u !== void 0 && (i.maxLength = u), c ? c.length === 1 ? (i.contentMediaType = c[0], Object.assign(r, i)) : (Object.assign(r, i), r.anyOf = c.map((l) => ({ contentMediaType: l }))) : Object.assign(r, i);
}, "fileProcessor"), Zd = /* @__PURE__ */ s((e, t, n, o) => {
  n.type = "boolean";
}, "successProcessor"), Rd = /* @__PURE__ */ s((e, t, n, o) => {
  oe(e, t, n, o, "Custom types cannot be represented in JSON Schema");
}, "customProcessor"), Fd = /* @__PURE__ */ s((e, t, n, o) => {
  oe(e, t, n, o, "Function types cannot be represented in JSON Schema");
}, "functionProcessor"), Ld = /* @__PURE__ */ s((e, t, n, o) => {
  oe(e, t, n, o, "Transforms cannot be represented in JSON Schema");
}, "transformProcessor"), Vd = /* @__PURE__ */ s((e, t, n, o) => {
  oe(e, t, n, o, "Map cannot be represented in JSON Schema");
}, "mapProcessor"), Md = /* @__PURE__ */ s((e, t, n, o) => {
  oe(e, t, n, o, "Set cannot be represented in JSON Schema");
}, "setProcessor"), Bd = /* @__PURE__ */ s((e, t, n, o) => {
  let r = n, i = e._zod.def, { minimum: a, maximum: u } = e._zod.bag;
  typeof a == "number" && (r.minItems = a), typeof u == "number" && (r.maxItems = u), r.type = "array", r.items = M(i.element, t, {
    ...o,
    path: [...o.path, "items"]
  });
}, "arrayProcessor");
function bn(e) {
  let t = e._zod.def;
  return t.type === "pipe" && t.in._zod.traits.has("$ZodTransform") ? bn(t.out) : t.type === "catch" ? bn(t.innerType) : e._zod.optin;
}
s(bn, "inputOptin");
var Jd = /* @__PURE__ */ s((e, t, n, o) => {
  let r = n, i = e._zod.def, a = i.shape;
  if (Object.getOwnPropertySymbols(a).length && oe(e, t, r, o, "Symbol keys cannot be represented in JSON Schema"))
    return;
  r.type = "object", r.properties = {};
  for (let d in a)
    Y(r.properties, d, M(a[d], t, {
      ...o,
      path: [...o.path, "properties", d]
    }));
  let c = new Set(Object.keys(a)), l = new Set([...c].filter((d) => {
    let f = i.shape[d];
    return t.io === "input" ? bn(f) === void 0 : f._zod.optout === void 0;
  }));
  l.size > 0 && (r.required = Array.from(l)), i.catchall?._zod.def.type === "never" ? r.additionalProperties = !1 : i.catchall ? i.catchall && (r.additionalProperties = M(i.catchall, t, {
    ...o,
    path: [...o.path, "additionalProperties"]
  })) : t.io === "output" && (r.additionalProperties = !1);
}, "objectProcessor"), So = /* @__PURE__ */ s((e, t, n, o) => {
  let r = e._zod.def, i = r.inclusive === !1, a = r.options.map((u, c) => M(u, t, {
    ...o,
    path: [...o.path, i ? "oneOf" : "anyOf", c]
  }));
  i ? n.oneOf = a : n.anyOf = a;
}, "unionProcessor"), qd = /* @__PURE__ */ s((e, t, n, o) => {
  let r = e._zod.def, i = M(r.left, t, {
    ...o,
    path: [...o.path, "allOf", 0]
  }), a = M(r.right, t, {
    ...o,
    path: [...o.path, "allOf", 1]
  }), u = /* @__PURE__ */ s((l) => "allOf" in l && Object.keys(l).length === 1, "isSimpleIntersection"), c = [
    ...u(i) ? i.allOf : [i],
    ...u(a) ? a.allOf : [a]
  ];
  n.allOf = c, t.intersections.push(c);
}, "intersectionProcessor"), Wd = /* @__PURE__ */ s((e, t, n, o) => {
  let r = n, i = e._zod.def;
  r.type = "array";
  let a = t.target === "draft-2020-12" ? "prefixItems" : "items", u = t.target === "draft-2020-12" || t.target === "openapi-3.0" ? "items" : "additionalItems", c = i.items.map((x, k) => M(x, t, {
    ...o,
    path: [...o.path, a, k]
  })), l = i.rest ? M(i.rest, t, {
    ...o,
    path: [...o.path, u, ...t.target === "openapi-3.0" ? [i.items.length] : []]
  }) : null, d = i.items.length;
  for (; d > 0; ) {
    let x = i.items[d - 1];
    if (!(t.io === "input" ? bn(x) !== void 0 : x._zod.optout === "optional"))
      break;
    d--;
  }
  let f = i.items.length, p = !i.rest;
  t.target === "draft-2020-12" ? (r.prefixItems = c, p ? r.items = !1 : l && (r.items = l), d > 0 && (r.minItems = d), p && (r.maxItems = f)) : t.target === "openapi-3.0" ? (r.items = {
    anyOf: c
  }, l && r.items.anyOf.push(l), d > 0 && (r.minItems = d), p && (r.maxItems = f)) : (r.items = c, p ? r.additionalItems = !1 : l && (r.additionalItems = l), d > 0 && (r.minItems = d), p && (r.maxItems = f));
  let { minimum: m, maximum: v } = e._zod.bag;
  typeof m == "number" && (r.minItems = m), typeof v == "number" && (r.maxItems = v);
}, "tupleProcessor");
function $d(e, t, n) {
  if (t.$ref) {
    if (n.has(t))
      return t;
    n.add(t);
    let v = e.get(t)?.def;
    if (!v)
      return t;
    let x = $d(e, v, n);
    return x === v ? t : x;
  }
  for (let v of ["anyOf", "oneOf"]) {
    let x = t[v];
    if (!Array.isArray(x))
      continue;
    let k = x.map((R) => $d(e, R, n));
    k.some((R, j) => R !== x[j]) && (t = { ...t, [v]: k });
  }
  let o = Array.isArray(t.type) ? t.type : [t.type], r = !o.includes("string") && o.some((v) => v === "number" || v === "integer"), i = t.enum ?? (t.const !== void 0 ? [t.const] : void 0);
  if (!r && !i?.some((v) => typeof v == "number"))
    return t;
  let { minimum: a, maximum: u, exclusiveMinimum: c, exclusiveMaximum: l, multipleOf: d, format: f, id: p, ...m } = t;
  return m.enum ? m.enum = m.enum.map((v) => typeof v == "number" ? String(v) : v) : typeof m.const == "number" && (m.const = String(m.const)), r && (m.type = "string", i || (m.pattern = (o.includes("number") ? Ye : en).source)), m;
}
s($d, "stringifyKeyNames");
var bd = /* @__PURE__ */ new WeakMap();
function Px(e) {
  let t = /* @__PURE__ */ new Map();
  for (let o of e.seen.values())
    o.def && !t.has(o.schema) && t.set(o.schema, o);
  let n = /* @__PURE__ */ new Map();
  for (let o of bd.get(e) ?? []) {
    let r = e.seen.get(o), i = (r?.def ?? r?.schema)?.propertyNames;
    if (!i || i === !0 || n.has(i))
      continue;
    let a = $d(t, i, /* @__PURE__ */ new Set());
    a !== i && n.set(i, a);
  }
  if (n.size)
    for (let o of e.seen.values())
      for (let r of [o.schema, o.def]) {
        let i = r && n.get(r.propertyNames);
        i && (r.propertyNames = i);
      }
}
s(Px, "rewriteKeyNames");
var Kd = /* @__PURE__ */ s((e, t, n, o) => {
  let r = n, i = e._zod.def;
  r.type = "object";
  let a = i.keyType, c = a._zod.bag?.patterns;
  if (i.mode === "loose" && c && c.size > 0) {
    let f = M(i.valueType, t, {
      ...o,
      path: [...o.path, "patternProperties", "*"]
    });
    r.patternProperties = {};
    for (let p of c)
      Y(r.patternProperties, p.source, f);
  } else {
    if (t.target === "draft-07" || t.target === "draft-2020-12") {
      r.propertyNames = M(i.keyType, t, {
        ...o,
        path: [...o.path, "propertyNames"]
      });
      let f = bd.get(t);
      f || (f = [], bd.set(t, f), t.deferred.push(() => Px(t))), f.push(e);
    }
    r.additionalProperties = M(i.valueType, t, {
      ...o,
      path: [...o.path, "additionalProperties"]
    });
  }
  let l = a._zod.values, d = t.io === "input" && bn(i.valueType) !== void 0;
  if (l && !i.partial && !d) {
    let f = [...l].filter((p) => typeof p == "string" || typeof p == "number");
    f.length > 0 && (r.required = f.map(String));
  }
}, "recordProcessor"), Gd = /* @__PURE__ */ s((e, t, n, o) => {
  let r = e._zod.def, i = M(r.innerType, t, o), a = t.seen.get(e);
  t.target === "openapi-3.0" ? (a.ref = r.innerType, n.nullable = !0) : n.anyOf = [i, { type: "null" }];
}, "nullableProcessor"), Xd = /* @__PURE__ */ s((e, t, n, o) => {
  let r = e._zod.def;
  M(r.innerType, t, o);
  let i = t.seen.get(e);
  i.ref = r.innerType;
}, "nonoptionalProcessor"), Hd = Symbol();
function eg(e, t, n, o, r) {
  let i = !1, a = JSON.stringify(e, (u, c) => typeof c != "bigint" ? c : (i = !0, null));
  return i ? (oe(t, n, o, r, "BigInt defaults cannot be represented in JSON Schema"), Hd) : JSON.parse(a);
}
s(eg, "serializeDefaultValue");
var Qd = /* @__PURE__ */ s((e, t, n, o) => {
  let r = e._zod.def;
  M(r.innerType, t, o);
  let i = t.seen.get(e);
  i.ref = r.innerType;
  let a = eg(r.defaultValue, e, t, n, o);
  a !== Hd && (n.default = a);
}, "defaultProcessor"), Yd = /* @__PURE__ */ s((e, t, n, o) => {
  let r = e._zod.def;
  M(r.innerType, t, o);
  let i = t.seen.get(e);
  if (i.ref = r.innerType, t.io !== "input")
    return;
  let a = eg(r.defaultValue, e, t, n, o);
  a !== Hd && (n._prefault = a);
}, "prefaultProcessor"), ef = /* @__PURE__ */ s((e, t, n, o) => {
  let r = e._zod.def;
  M(r.innerType, t, o);
  let i = t.seen.get(e);
  i.ref = r.innerType;
  let a;
  try {
    a = r.catchValue(void 0);
  } catch {
    oe(e, t, n, o, "Dynamic catch values are not supported in JSON Schema");
    return;
  }
  n.default = a;
}, "catchProcessor"), tf = /* @__PURE__ */ s((e, t, n, o) => {
  let r = e._zod.def, i = r.in._zod.traits.has("$ZodTransform"), a = t.io === "input" ? i ? r.out : r.in : r.out;
  M(a, t, o);
  let u = t.seen.get(e);
  u.ref = a;
}, "pipeProcessor"), rf = /* @__PURE__ */ s((e, t, n, o) => {
  let r = e._zod.def;
  M(r.innerType, t, o);
  let i = t.seen.get(e);
  i.ref = r.innerType, n.readOnly = !0;
}, "readonlyProcessor"), nf = /* @__PURE__ */ s((e, t, n, o) => {
  let r = e._zod.def;
  M(r.innerType, t, o);
  let i = t.seen.get(e);
  i.ref = r.innerType;
}, "promiseProcessor"), Oo = /* @__PURE__ */ s((e, t, n, o) => {
  let r = e._zod.def;
  M(r.innerType, t, o);
  let i = t.seen.get(e);
  i.ref = r.innerType;
}, "optionalProcessor"), of = /* @__PURE__ */ s((e, t, n, o) => {
  let r = e._zod.innerType;
  M(r, t, o);
  let i = t.seen.get(e);
  i.ref = r;
}, "lazyProcessor"), zo = {
  string: _d,
  number: xd,
  boolean: wd,
  bigint: kd,
  symbol: Id,
  null: zd,
  undefined: Sd,
  void: Od,
  never: jd,
  any: Pd,
  unknown: Dd,
  date: Nd,
  enum: Td,
  literal: Ad,
  nan: Ud,
  template_literal: Ed,
  file: Cd,
  success: Zd,
  custom: Rd,
  function: Fd,
  transform: Ld,
  map: Vd,
  set: Md,
  array: Bd,
  object: Jd,
  union: So,
  intersection: qd,
  tuple: Wd,
  record: Kd,
  nullable: Gd,
  nonoptional: Xd,
  default: Qd,
  prefault: Yd,
  catch: ef,
  pipe: tf,
  readonly: rf,
  promise: nf,
  optional: Oo,
  lazy: of
};
function jo(e, t) {
  if ("_idmap" in e) {
    let o = e, r = at({ ...t, processors: zo }), i = {};
    for (let c of o._idmap.entries()) {
      let [l, d] = c;
      M(d, r);
    }
    let a = {}, u = {
      registry: o,
      uri: t?.uri,
      defs: i
    };
    r.external = u;
    for (let c of o._idmap.entries()) {
      let [l, d] = c;
      st(r, d), Y(a, l, ut(r, d));
    }
    if (Object.keys(i).length > 0) {
      let c = r.target === "draft-2020-12" ? "$defs" : "definitions";
      a.__shared = {
        [c]: i
      };
    }
    return { schemas: a };
  }
  let n = at({ ...t, processors: zo });
  return M(e, n), st(n, e), ut(n, e);
}
s(jo, "toJSONSchema");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/json-schema-generator.js
var Po = class {
  static {
    s(this, "JSONSchemaGenerator");
  }
  /** @deprecated Access via ctx instead */
  get metadataRegistry() {
    return this.ctx.metadataRegistry;
  }
  /** @deprecated Access via ctx instead */
  get target() {
    return this.ctx.target;
  }
  // annotated so the .d.cts emits an indexed access rather than an inline `import()` of an ESM path
  /** @deprecated Access via ctx instead */
  get unrepresentable() {
    return this.ctx.unrepresentable;
  }
  /** @deprecated Access via ctx instead */
  get override() {
    return this.ctx.override;
  }
  /** @deprecated Access via ctx instead */
  get io() {
    return this.ctx.io;
  }
  /** @deprecated Access via ctx instead */
  get counter() {
    return this.ctx.counter;
  }
  set counter(t) {
    this.ctx.counter = t;
  }
  /** @deprecated Access via ctx instead */
  get seen() {
    return this.ctx.seen;
  }
  constructor(t) {
    let n = t?.target ?? "draft-2020-12";
    n === "draft-4" && (n = "draft-04"), n === "draft-7" && (n = "draft-07"), this.ctx = at({
      processors: zo,
      target: n,
      ...t?.metadata && { metadata: t.metadata },
      ...t?.unrepresentable && { unrepresentable: t.unrepresentable },
      ...t?.override && { override: t.override },
      ...t?.io && { io: t.io }
    });
  }
  /**
   * Process a schema to prepare it for JSON Schema generation.
   * This must be called before emit().
   */
  process(t, n = { path: [], schemaPath: [] }) {
    return M(t, this.ctx, n);
  }
  /**
   * Emit the final JSON Schema after processing.
   * Must call process() first.
   */
  emit(t, n) {
    n && (n.cycles && (this.ctx.cycles = n.cycles), n.reused && (this.ctx.reused = n.reused), n.external && (this.ctx.external = n.external)), this.ctx.sharedDefsExtractedFor = void 0, this.ctx.sharedEmitDoneFor = void 0, st(this.ctx, t);
    let o = ut(this.ctx, t), { "~standard": r, ...i } = o;
    return i;
  }
};

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/json-schema.js
var tg = {};

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/schemas.js
var Nr = {};
Be(Nr, {
  ZodAny: () => xf,
  ZodArray: () => zf,
  ZodBase64: () => Go,
  ZodBase64URL: () => Xo,
  ZodBigInt: () => Dr,
  ZodBigIntFormat: () => Yo,
  ZodBoolean: () => Pr,
  ZodCIDRv4: () => Wo,
  ZodCIDRv6: () => Ko,
  ZodCUID: () => Fo,
  ZodCUID2: () => Lo,
  ZodCatch: () => Wf,
  ZodCodec: () => Dn,
  ZodCreditCard: () => vf,
  ZodCustom: () => Nn,
  ZodCustomStringFormat: () => Or,
  ZodDate: () => zn,
  ZodDefault: () => Lf,
  ZodDiscriminatedUnion: () => Of,
  ZodE164: () => Ho,
  ZodEmail: () => Eo,
  ZodEmoji: () => Zo,
  ZodEnum: () => zr,
  ZodExactOptional: () => oa,
  ZodFile: () => Cf,
  ZodFunction: () => np,
  ZodGUID: () => Co,
  ZodIPv4: () => Jo,
  ZodIPv6: () => qo,
  ZodISODate: () => lt,
  ZodISODateTime: () => ct,
  ZodISODuration: () => ft,
  ZodISOTime: () => dt,
  ZodIntersection: () => jf,
  ZodJWT: () => Qo,
  ZodKSUID: () => Bo,
  ZodLazy: () => ep,
  ZodLiteral: () => Ef,
  ZodMAC: () => hf,
  ZodMap: () => Af,
  ZodNaN: () => Gf,
  ZodNanoID: () => Ro,
  ZodNever: () => kf,
  ZodNonOptional: () => aa,
  ZodNull: () => bf,
  ZodNullable: () => Ff,
  ZodNumber: () => jr,
  ZodNumberFormat: () => Rt,
  ZodObject: () => Sn,
  ZodOptional: () => jn,
  ZodPipe: () => Pn,
  ZodPrefault: () => Mf,
  ZodPreprocess: () => Xf,
  ZodPromise: () => rp,
  ZodReadonly: () => Hf,
  ZodRecord: () => Ir,
  ZodSet: () => Uf,
  ZodString: () => Sr,
  ZodStringFormat: () => q,
  ZodSuccess: () => qf,
  ZodSymbol: () => yf,
  ZodTemplateLiteral: () => Yf,
  ZodTransform: () => Zf,
  ZodTuple: () => Df,
  ZodType: () => A,
  ZodULID: () => Vo,
  ZodURL: () => wn,
  ZodUUID: () => Ve,
  ZodUndefined: () => $f,
  ZodUnion: () => On,
  ZodUnknown: () => wf,
  ZodVoid: () => If,
  ZodXID: () => Mo,
  ZodXor: () => Sf,
  _ZodString: () => Uo,
  _default: () => Vf,
  _function: () => uh,
  any: () => Vg,
  array: () => Ft,
  base64: () => kg,
  base64url: () => Ig,
  bigint: () => Cg,
  boolean: () => In,
  catch: () => Kf,
  check: () => ch,
  cidrv4: () => xg,
  cidrv6: () => wg,
  codec: () => sa,
  creditCard: () => Sg,
  cuid: () => mg,
  cuid2: () => gg,
  custom: () => lh,
  date: () => ta,
  describe: () => dh,
  discriminatedUnion: () => Kg,
  e164: () => zg,
  email: () => ig,
  emoji: () => fg,
  enum: () => na,
  exactOptional: () => Rf,
  file: () => th,
  float32: () => Tg,
  float64: () => Ag,
  function: () => uh,
  guid: () => og,
  hash: () => Ng,
  hex: () => Dg,
  hostname: () => Pg,
  httpUrl: () => dg,
  instanceof: () => ua,
  int: () => To,
  int32: () => Ug,
  int64: () => Zg,
  intersection: () => Pf,
  invertCodec: () => oh,
  ipv4: () => $g,
  ipv6: () => _g,
  json: () => mh,
  jwt: () => Og,
  keyof: () => Bg,
  ksuid: () => yg,
  lazy: () => tp,
  literal: () => eh,
  looseObject: () => qg,
  looseRecord: () => Xg,
  mac: () => bg,
  map: () => Hg,
  meta: () => fh,
  nan: () => ih,
  nanoid: () => pg,
  nativeEnum: () => Yg,
  never: () => ea,
  nonoptional: () => Jf,
  null: () => _f,
  nullable: () => Ct,
  nullish: () => rh,
  number: () => kn,
  object: () => ra,
  optional: () => We,
  partialRecord: () => Gg,
  pipe: () => Ao,
  prefault: () => Bf,
  preprocess: () => gh,
  promise: () => sh,
  readonly: () => Qf,
  record: () => Tf,
  refine: () => ip,
  set: () => Qg,
  strictObject: () => Jg,
  string: () => Ut,
  stringFormat: () => jg,
  stringbool: () => ph,
  success: () => nh,
  superRefine: () => op,
  symbol: () => Fg,
  templateLiteral: () => ah,
  transform: () => ia,
  tuple: () => Nf,
  uint32: () => Eg,
  uint64: () => Rg,
  ulid: () => hg,
  undefined: () => Lg,
  union: () => pt,
  unknown: () => Et,
  url: () => lg,
  uuid: () => ag,
  uuidv4: () => sg,
  uuidv6: () => ug,
  uuidv7: () => cg,
  void: () => Mg,
  xid: () => vg,
  xor: () => Wg
});

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/checks.js
var Do = {};
Be(Do, {
  endsWith: () => hr,
  gt: () => Fe,
  gte: () => ke,
  includes: () => mr,
  length: () => At,
  lowercase: () => fr,
  lt: () => Re,
  lte: () => we,
  maxLength: () => Tt,
  maxSize: () => ot,
  mime: () => vr,
  minLength: () => Je,
  minSize: () => Le,
  multipleOf: () => it,
  negative: () => _o,
  nonnegative: () => wo,
  nonpositive: () => xo,
  normalize: () => yr,
  overwrite: () => Ee,
  positive: () => bo,
  properties: () => Io,
  property: () => ko,
  regex: () => dr,
  size: () => Nt,
  slugify: () => xr,
  startsWith: () => gr,
  toLowerCase: () => br,
  toUpperCase: () => _r,
  trim: () => $r,
  uppercase: () => pr
});

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/errors.js
var rg = /* @__PURE__ */ new WeakSet([Object.prototype, Error.prototype]);
function No(e, t, n) {
  Object.defineProperty(e, t, {
    configurable: !0,
    enumerable: !1,
    get() {
      let o = n(this);
      return Object.defineProperty(this, t, { value: o, configurable: !0, writable: !0 }), o;
    },
    set(o) {
      Object.defineProperty(this, t, { value: o, configurable: !0, writable: !0 });
    }
  });
}
s(No, "_lazyMethod");
var ng = /* @__PURE__ */ s((e, t) => {
  De.init(e, t), e.name = "ZodError";
  let n = Object.getPrototypeOf(e);
  rg.has(n) || (rg.add(n), No(n, "format", (o) => (r) => Yr(o, r)), No(n, "flatten", (o) => (r) => Qr(o, r)), No(n, "addIssue", (o) => (r) => {
    o.issues.push(r), o.message = JSON.stringify(o.issues, Qt, 2);
  }), No(n, "addIssues", (o) => (r) => {
    o.issues.push(...r), o.message = JSON.stringify(o.issues, Qt, 2);
  }), Object.defineProperty(n, "isEmpty", {
    configurable: !0,
    enumerable: !1,
    get() {
      return this.issues.length === 0;
    }
  }));
}, "initializer"), Nx = /* @__PURE__ */ g("ZodError", ng), ye = /* @__PURE__ */ g("ZodError", ng, void 0, {
  Parent: Error
});

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/parse.js
var _n = /* @__PURE__ */ tr(ye), af = /* @__PURE__ */ rr(ye), sf = /* @__PURE__ */ nr(ye), uf = /* @__PURE__ */ ir(ye), xn = /* @__PURE__ */ gi(ye), cf = /* @__PURE__ */ hi(ye), lf = /* @__PURE__ */ vi(ye), df = /* @__PURE__ */ yi(ye), ff = /* @__PURE__ */ $i(ye), pf = /* @__PURE__ */ bi(ye), mf = /* @__PURE__ */ _i(ye), gf = /* @__PURE__ */ xi(ye);

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/schemas.js
function Ax() {
  ae.localeError || te(cn());
}
s(Ax, "_ensureDefaultLocale");
function Zt() {
  ae.memoizer || te({ memoizer: un() });
}
s(Zt, "_ensureDefaultMemoizer");
var A = /* @__PURE__ */ g("ZodType", (e, t) => (Ax(), O.init(e, t), e.def = t, e.type = t.type, e), {
  check(...e) {
    let t = this.def;
    return this.clone(_.mergeDefs(t, {
      checks: [
        ...t.checks ?? [],
        ...e.map((n) => typeof n == "function" ? { _zod: { check: n, def: { check: "custom" }, onattach: [] } } : n)
      ]
    }), { parent: !0 });
  },
  with(...e) {
    return this.check(...e);
  },
  clone(e, t) {
    return C(this, e, t);
  },
  brand() {
    return this;
  },
  register(e, t) {
    return e.add(this, t), this;
  },
  refine(e, t) {
    return this.check(ip(e, t));
  },
  superRefine(e, t) {
    return this.check(op(e, t));
  },
  overwrite(e) {
    return this.check(Ee(e));
  },
  optional() {
    return We(this);
  },
  exactOptional() {
    return Rf(this);
  },
  nullable() {
    return Ct(this);
  },
  nullish() {
    return We(Ct(this));
  },
  nonoptional(e) {
    return Jf(this, e);
  },
  array() {
    return Ft(this);
  },
  or(e) {
    return pt([this, e]);
  },
  and(e) {
    return Pf(this, e);
  },
  transform(e) {
    return Ao(this, ia(e));
  },
  default(e) {
    return Vf(this, e);
  },
  prefault(e) {
    return Bf(this, e);
  },
  catch(e) {
    return Kf(this, e);
  },
  pipe(e) {
    return Ao(this, e);
  },
  readonly() {
    return Qf(this);
  },
  describe(e) {
    let t = this.clone();
    return se.add(t, { description: e }), t;
  },
  meta(...e) {
    if (e.length === 0)
      return se.get(this);
    let t = this.clone();
    return se.add(t, e[0]), t;
  },
  isOptional() {
    return this.safeParse(void 0).success;
  },
  isNullable() {
    return this.safeParse(null).success;
  },
  apply(e, ...t) {
    return t.length === 0 ? e(this) : e(this, ...t);
  },
  // Overrides core's `~standard` to add `jsonSchema`. Must stay a prototype entry: redefining it per instance demotes instances to dictionary mode.
  get "~standard"() {
    return _.hide(this, "~standard", {
      ...Ti(this),
      jsonSchema: {
        input: kr(this, "input"),
        output: kr(this, "output")
      }
    });
  },
  set "~standard"(e) {
    _.own(this, "~standard", e);
  },
  parse: /* @__PURE__ */ s(function e(t, n) {
    return _n(this, t, n, { callee: e });
  }, "_parse"),
  parseAsync: /* @__PURE__ */ s(async function e(t, n) {
    return await af(this, t, n, { callee: e });
  }, "_parseAsync"),
  safeParse(e, t) {
    return sf(this, e, t);
  },
  async safeParseAsync(e, t) {
    return uf(this, e, t);
  },
  // `spa` is an alias: same function object as `safeParseAsync`, as before.
  get spa() {
    return this?.safeParseAsync;
  },
  set spa(e) {
    _.own(this, "spa", e);
  },
  encode: /* @__PURE__ */ s(function e(t, n) {
    return xn(this, t, n, { callee: e });
  }, "_encode"),
  decode: /* @__PURE__ */ s(function e(t, n) {
    return cf(this, t, n, { callee: e });
  }, "_decode"),
  encodeAsync: /* @__PURE__ */ s(async function e(t, n) {
    return await lf(this, t, n, { callee: e });
  }, "_encodeAsync"),
  decodeAsync: /* @__PURE__ */ s(async function e(t, n) {
    return await df(this, t, n, { callee: e });
  }, "_decodeAsync"),
  safeEncode(e, t) {
    return ff(this, e, t);
  },
  safeDecode(e, t) {
    return pf(this, e, t);
  },
  async safeEncodeAsync(e, t) {
    return mf(this, e, t);
  },
  async safeDecodeAsync(e, t) {
    return gf(this, e, t);
  },
  toJSONSchema(e) {
    return yd(this, {})(e);
  },
  // Reads through to the registry on every access, so it must not cache.
  get description() {
    return se.get(this)?.description;
  },
  // No setter: `schema._def = x` throws, as it did when `_def` was a non-writable own property.
  get _def() {
    return this._zod.def;
  }
}), Uo = /* @__PURE__ */ g("_ZodString", (e, t) => {
  zt.init(e, t), A.init(e, t), e._zod.processJSONSchema = (o, r, i) => _d(e, o, r, i);
  let n = e._zod.bag;
  e.format = n.format ?? null, e.minLength = n.minimum ?? null, e.maxLength = n.maximum ?? null;
}, {
  regex(...e) {
    return this.check(dr(...e));
  },
  includes(...e) {
    return this.check(mr(...e));
  },
  startsWith(...e) {
    return this.check(gr(...e));
  },
  endsWith(...e) {
    return this.check(hr(...e));
  },
  min(...e) {
    return this.check(Je(...e));
  },
  max(...e) {
    return this.check(Tt(...e));
  },
  length(...e) {
    return this.check(At(...e));
  },
  nonempty(...e) {
    return this.check(Je(1, ...e));
  },
  lowercase(e) {
    return this.check(fr(e));
  },
  uppercase(e) {
    return this.check(pr(e));
  },
  trim() {
    return this.check($r());
  },
  normalize(...e) {
    return this.check(yr(...e));
  },
  toLowerCase() {
    return this.check(br());
  },
  toUpperCase() {
    return this.check(_r());
  },
  slugify() {
    return this.check(xr());
  }
}), Sr = /* @__PURE__ */ g("ZodString", (e, t) => {
  zt.init(e, t), Uo.init(e, t);
}, {
  email(e) {
    return this.check(Qi(Eo, e));
  },
  url(e) {
    return this.check(mn(wn, e));
  },
  jwt(e) {
    return this.check($o(Qo, e));
  },
  emoji(e) {
    return this.check(io(Zo, e));
  },
  guid(e) {
    return this.check(Yi(Co, e));
  },
  uuid(e) {
    return this.check(eo(Ve, e));
  },
  uuidv4(e) {
    return this.check(to(Ve, e));
  },
  uuidv6(e) {
    return this.check(ro(Ve, e));
  },
  uuidv7(e) {
    return this.check(no(Ve, e));
  },
  nanoid(e) {
    return this.check(oo(Ro, e));
  },
  cuid(e) {
    return this.check(ao(Fo, e));
  },
  cuid2(e) {
    return this.check(so(Lo, e));
  },
  ulid(e) {
    return this.check(uo(Vo, e));
  },
  base64(e) {
    return this.check(ho(Go, e));
  },
  base64url(e) {
    return this.check(vo(Xo, e));
  },
  xid(e) {
    return this.check(co(Mo, e));
  },
  ksuid(e) {
    return this.check(lo(Bo, e));
  },
  ipv4(e) {
    return this.check(fo(Jo, e));
  },
  ipv6(e) {
    return this.check(po(qo, e));
  },
  cidrv4(e) {
    return this.check(mo(Wo, e));
  },
  cidrv6(e) {
    return this.check(go(Ko, e));
  },
  e164(e) {
    return this.check(yo(Ho, e));
  },
  datetime(e) {
    return this.check(gn(ct, e));
  },
  date(e) {
    return this.check(hn(lt, e));
  },
  time(e) {
    return this.check(vn(dt, e));
  },
  duration(e) {
    return this.check(yn(ft, e));
  }
});
function Ut(e) {
  return Ul(Sr, e);
}
s(Ut, "string");
var q = /* @__PURE__ */ g("ZodStringFormat", (e, t) => {
  B.init(e, t), Uo.init(e, t);
}), ct = /* @__PURE__ */ g("ZodISODateTime", (e, t) => {
  Pu.init(e, t), q.init(e, t);
}), lt = /* @__PURE__ */ g("ZodISODate", (e, t) => {
  Du.init(e, t), q.init(e, t);
}), dt = /* @__PURE__ */ g("ZodISOTime", (e, t) => {
  Nu.init(e, t), q.init(e, t);
}), ft = /* @__PURE__ */ g("ZodISODuration", (e, t) => {
  Tu.init(e, t), q.init(e, t);
}), Eo = /* @__PURE__ */ g("ZodEmail", (e, t) => {
  $u.init(e, t), q.init(e, t);
});
function ig(e) {
  return Qi(Eo, e);
}
s(ig, "email");
var Co = /* @__PURE__ */ g("ZodGUID", (e, t) => {
  vu.init(e, t), q.init(e, t);
});
function og(e) {
  return Yi(Co, e);
}
s(og, "guid");
var Ve = /* @__PURE__ */ g("ZodUUID", (e, t) => {
  yu.init(e, t), q.init(e, t);
});
function ag(e) {
  return eo(Ve, e);
}
s(ag, "uuid");
function sg(e) {
  return to(Ve, e);
}
s(sg, "uuidv4");
function ug(e) {
  return ro(Ve, e);
}
s(ug, "uuidv6");
function cg(e) {
  return no(Ve, e);
}
s(cg, "uuidv7");
var wn = /* @__PURE__ */ g("ZodURL", (e, t) => {
  xu.init(e, t), q.init(e, t);
});
function lg(e) {
  return mn(wn, e);
}
s(lg, "url");
function dg(e) {
  return mn(wn, {
    protocol: ce.httpProtocol,
    hostname: ce.domain,
    ..._.normalizeParams(e)
  });
}
s(dg, "httpUrl");
var Zo = /* @__PURE__ */ g("ZodEmoji", (e, t) => {
  wu.init(e, t), q.init(e, t);
});
function fg(e) {
  return io(Zo, e);
}
s(fg, "emoji");
var Ro = /* @__PURE__ */ g("ZodNanoID", (e, t) => {
  ku.init(e, t), q.init(e, t);
});
function pg(e) {
  return oo(Ro, e);
}
s(pg, "nanoid");
var Fo = /* @__PURE__ */ g("ZodCUID", (e, t) => {
  Iu.init(e, t), q.init(e, t);
});
function mg(e) {
  return ao(Fo, e);
}
s(mg, "cuid");
var Lo = /* @__PURE__ */ g("ZodCUID2", (e, t) => {
  zu.init(e, t), q.init(e, t);
});
function gg(e) {
  return so(Lo, e);
}
s(gg, "cuid2");
var Vo = /* @__PURE__ */ g("ZodULID", (e, t) => {
  Su.init(e, t), q.init(e, t);
});
function hg(e) {
  return uo(Vo, e);
}
s(hg, "ulid");
var Mo = /* @__PURE__ */ g("ZodXID", (e, t) => {
  Ou.init(e, t), q.init(e, t);
});
function vg(e) {
  return co(Mo, e);
}
s(vg, "xid");
var Bo = /* @__PURE__ */ g("ZodKSUID", (e, t) => {
  ju.init(e, t), q.init(e, t);
});
function yg(e) {
  return lo(Bo, e);
}
s(yg, "ksuid");
var Jo = /* @__PURE__ */ g("ZodIPv4", (e, t) => {
  Au.init(e, t), q.init(e, t);
});
function $g(e) {
  return fo(Jo, e);
}
s($g, "ipv4");
var hf = /* @__PURE__ */ g("ZodMAC", (e, t) => {
  Eu.init(e, t), q.init(e, t);
});
function bg(e) {
  return Cl(hf, e);
}
s(bg, "mac");
var qo = /* @__PURE__ */ g("ZodIPv6", (e, t) => {
  Uu.init(e, t), q.init(e, t);
});
function _g(e) {
  return po(qo, e);
}
s(_g, "ipv6");
var Wo = /* @__PURE__ */ g("ZodCIDRv4", (e, t) => {
  Cu.init(e, t), q.init(e, t);
});
function xg(e) {
  return mo(Wo, e);
}
s(xg, "cidrv4");
var Ko = /* @__PURE__ */ g("ZodCIDRv6", (e, t) => {
  Zu.init(e, t), q.init(e, t);
});
function wg(e) {
  return go(Ko, e);
}
s(wg, "cidrv6");
var Go = /* @__PURE__ */ g("ZodBase64", (e, t) => {
  Ru.init(e, t), q.init(e, t);
});
function kg(e) {
  return ho(Go, e);
}
s(kg, "base64");
var Xo = /* @__PURE__ */ g("ZodBase64URL", (e, t) => {
  Fu.init(e, t), q.init(e, t);
});
function Ig(e) {
  return vo(Xo, e);
}
s(Ig, "base64url");
var Ho = /* @__PURE__ */ g("ZodE164", (e, t) => {
  Lu.init(e, t), q.init(e, t);
});
function zg(e) {
  return yo(Ho, e);
}
s(zg, "e164");
var vf = /* @__PURE__ */ g("ZodCreditCard", (e, t) => {
  Vu.init(e, t), q.init(e, t);
});
function Sg(e) {
  return Zl(vf, e);
}
s(Sg, "creditCard");
var Qo = /* @__PURE__ */ g("ZodJWT", (e, t) => {
  Mu.init(e, t), q.init(e, t);
});
function Og(e) {
  return $o(Qo, e);
}
s(Og, "jwt");
var Or = /* @__PURE__ */ g("ZodCustomStringFormat", (e, t) => {
  Bu.init(e, t), q.init(e, t);
});
function jg(e, t, n = {}) {
  return wr(Or, e, t, n);
}
s(jg, "stringFormat");
function Pg(e) {
  return wr(Or, "hostname", ce.hostname, e);
}
s(Pg, "hostname");
function Dg(e) {
  return wr(Or, "hex", ce.hex, e);
}
s(Dg, "hex");
function Ng(e, t) {
  let n = t?.enc ?? "hex", o = `${e}_${n}`, r = ce[o];
  if (!r)
    throw new Error(`Unrecognized hash format: ${o}`);
  return wr(Or, o, r, t);
}
s(Ng, "hash");
var jr = /* @__PURE__ */ g("ZodNumber", (e, t) => {
  Vi.init(e, t), A.init(e, t), e._zod.processJSONSchema = (o, r, i) => xd(e, o, r, i);
  let n = e._zod.bag;
  e.minValue = Math.max(n.minimum ?? Number.NEGATIVE_INFINITY, n.exclusiveMinimum ?? Number.NEGATIVE_INFINITY) ?? null, e.maxValue = Math.min(n.maximum ?? Number.POSITIVE_INFINITY, n.exclusiveMaximum ?? Number.POSITIVE_INFINITY) ?? null, e.isInt = (n.format ?? "").includes("int") || Number.isSafeInteger(n.multipleOf ?? 0.5), e.isFinite = !0, e.format = n.format ?? null;
}, {
  gt(e, t) {
    return this.check(Fe(e, t));
  },
  gte(e, t) {
    return this.check(ke(e, t));
  },
  min(e, t) {
    return this.check(ke(e, t));
  },
  lt(e, t) {
    return this.check(Re(e, t));
  },
  lte(e, t) {
    return this.check(we(e, t));
  },
  max(e, t) {
    return this.check(we(e, t));
  },
  int(e) {
    return this.check(To(e));
  },
  safe(e) {
    return this.check(To(e));
  },
  positive(e) {
    return this.check(Fe(0, e));
  },
  nonnegative(e) {
    return this.check(ke(0, e));
  },
  negative(e) {
    return this.check(Re(0, e));
  },
  nonpositive(e) {
    return this.check(we(0, e));
  },
  multipleOf(e, t) {
    return this.check(it(e, t));
  },
  step(e, t) {
    return this.check(it(e, t));
  },
  finite() {
    return this;
  }
});
function kn(e) {
  return Fl(jr, e);
}
s(kn, "number");
var Rt = /* @__PURE__ */ g("ZodNumberFormat", (e, t) => {
  Ju.init(e, t), jr.init(e, t);
});
function To(e) {
  return Vl(Rt, e);
}
s(To, "int");
function Tg(e) {
  return Ml(Rt, e);
}
s(Tg, "float32");
function Ag(e) {
  return Bl(Rt, e);
}
s(Ag, "float64");
function Ug(e) {
  return Jl(Rt, e);
}
s(Ug, "int32");
function Eg(e) {
  return ql(Rt, e);
}
s(Eg, "uint32");
var Pr = /* @__PURE__ */ g("ZodBoolean", (e, t) => {
  an.init(e, t), A.init(e, t), e._zod.processJSONSchema = (n, o, r) => wd(e, n, o, r);
});
function In(e) {
  return Wl(Pr, e);
}
s(In, "boolean");
var Dr = /* @__PURE__ */ g("ZodBigInt", (e, t) => {
  Mi.init(e, t), A.init(e, t), e._zod.processJSONSchema = (o, r, i) => kd(e, o, r, i);
  let n = e._zod.bag;
  e.minValue = n.minimum ?? null, e.maxValue = n.maximum ?? null, e.format = n.format ?? null;
}, {
  gte(e, t) {
    return this.check(ke(e, t));
  },
  min(e, t) {
    return this.check(ke(e, t));
  },
  gt(e, t) {
    return this.check(Fe(e, t));
  },
  lt(e, t) {
    return this.check(Re(e, t));
  },
  lte(e, t) {
    return this.check(we(e, t));
  },
  max(e, t) {
    return this.check(we(e, t));
  },
  positive(e) {
    return this.check(Fe(BigInt(0), e));
  },
  negative(e) {
    return this.check(Re(BigInt(0), e));
  },
  nonpositive(e) {
    return this.check(we(BigInt(0), e));
  },
  nonnegative(e) {
    return this.check(ke(BigInt(0), e));
  },
  multipleOf(e, t) {
    return this.check(it(e, t));
  }
});
function Cg(e) {
  return Gl(Dr, e);
}
s(Cg, "bigint");
var Yo = /* @__PURE__ */ g("ZodBigIntFormat", (e, t) => {
  qu.init(e, t), Dr.init(e, t);
});
function Zg(e) {
  return Hl(Yo, e);
}
s(Zg, "int64");
function Rg(e) {
  return Ql(Yo, e);
}
s(Rg, "uint64");
var yf = /* @__PURE__ */ g("ZodSymbol", (e, t) => {
  Wu.init(e, t), A.init(e, t), e._zod.processJSONSchema = (n, o, r) => Id(e, n, o, r);
});
function Fg(e) {
  return Yl(yf, e);
}
s(Fg, "symbol");
var $f = /* @__PURE__ */ g("ZodUndefined", (e, t) => {
  Ku.init(e, t), A.init(e, t), e._zod.processJSONSchema = (n, o, r) => Sd(e, n, o, r);
});
function Lg(e) {
  return ed($f, e);
}
s(Lg, "_undefined");
var bf = /* @__PURE__ */ g("ZodNull", (e, t) => {
  Gu.init(e, t), A.init(e, t), e._zod.processJSONSchema = (n, o, r) => zd(e, n, o, r);
});
function _f(e) {
  return td(bf, e);
}
s(_f, "_null");
var xf = /* @__PURE__ */ g("ZodAny", (e, t) => {
  Xu.init(e, t), A.init(e, t), e._zod.processJSONSchema = (n, o, r) => Pd(e, n, o, r);
});
function Vg() {
  return rd(xf);
}
s(Vg, "any");
var wf = /* @__PURE__ */ g("ZodUnknown", (e, t) => {
  Hu.init(e, t), A.init(e, t), e._zod.processJSONSchema = (n, o, r) => Dd(e, n, o, r);
});
function Et() {
  return nd(wf);
}
s(Et, "unknown");
var kf = /* @__PURE__ */ g("ZodNever", (e, t) => {
  Qu.init(e, t), A.init(e, t), e._zod.processJSONSchema = (n, o, r) => jd(e, n, o, r);
});
function ea(e) {
  return id(kf, e);
}
s(ea, "never");
var If = /* @__PURE__ */ g("ZodVoid", (e, t) => {
  Yu.init(e, t), A.init(e, t), e._zod.processJSONSchema = (n, o, r) => Od(e, n, o, r);
});
function Mg(e) {
  return od(If, e);
}
s(Mg, "_void");
var zn = /* @__PURE__ */ g("ZodDate", (e, t) => {
  sr.init(e, t), A.init(e, t), e._zod.processJSONSchema = (o, r, i) => Nd(e, o, r, i), e.min = (o, r) => e.check(ke(o, r)), e.max = (o, r) => e.check(we(o, r));
  let n = e._zod.bag;
  e.minDate = n.minimum ? new Date(n.minimum) : null, e.maxDate = n.maximum ? new Date(n.maximum) : null;
});
function ta(e) {
  return ad(zn, e);
}
s(ta, "date");
var zf = /* @__PURE__ */ g("ZodArray", (e, t) => {
  Zt(), et.init(e, t), A.init(e, t), e._zod.processJSONSchema = (n, o, r) => Bd(e, n, o, r), e.element = t.element;
}, {
  min(e, t) {
    return this.check(Je(e, t));
  },
  nonempty(e) {
    return this.check(Je(1, e));
  },
  max(e, t) {
    return this.check(Tt(e, t));
  },
  length(e, t) {
    return this.check(At(e, t));
  },
  unwrap() {
    return this.element;
  }
});
function Ft(e, t) {
  return cd(zf, e, t);
}
s(Ft, "array");
function Bg(e) {
  let t = e._zod.def.shape;
  return na(Object.keys(t));
}
s(Bg, "keyof");
var Sn = /* @__PURE__ */ g("ZodObject", (e, t) => {
  Zt(), ec.init(e, t), A.init(e, t), e._zod.processJSONSchema = (n, o, r) => Jd(e, n, o, r), _.installLazyProp(e, "shape", (n) => n._zod.def.shape, !1);
}, {
  keyof() {
    return na(Object.keys(this._zod.def.shape));
  },
  catchall(e) {
    return this.clone({ ...this._zod.def, catchall: e });
  },
  passthrough() {
    return this.clone({ ...this._zod.def, catchall: Et() });
  },
  loose() {
    return this.clone({ ...this._zod.def, catchall: Et() });
  },
  strict() {
    return this.clone({ ...this._zod.def, catchall: ea() });
  },
  strip() {
    return this.clone({ ...this._zod.def, catchall: void 0 });
  },
  extend(e) {
    return _.extend(this, e);
  },
  safeExtend(e) {
    return _.safeExtend(this, e);
  },
  merge(e) {
    return _.merge(this, e);
  },
  pick(e) {
    return _.pick(this, e);
  },
  omit(e) {
    return _.omit(this, e);
  },
  partial(...e) {
    return _.partial(jn, this, e[0]);
  },
  exactPartial(...e) {
    return _.partial(oa, this, e[0], "exactPartial");
  },
  required(...e) {
    return _.required(aa, this, e[0]);
  }
});
function ra(e, t) {
  let n = {
    type: "object",
    shape: e ?? {},
    ..._.normalizeParams(t)
  };
  return new Sn(n);
}
s(ra, "object");
function Jg(e, t) {
  return new Sn({
    type: "object",
    shape: e,
    catchall: ea(),
    ..._.normalizeParams(t)
  });
}
s(Jg, "strictObject");
function qg(e, t) {
  return new Sn({
    type: "object",
    shape: e,
    catchall: Et(),
    ..._.normalizeParams(t)
  });
}
s(qg, "looseObject");
var On = /* @__PURE__ */ g("ZodUnion", (e, t) => {
  le.init(e, t), A.init(e, t), e._zod.processJSONSchema = (n, o, r) => So(e, n, o, r), e.options = t.options;
});
function pt(e, t) {
  return new On({
    type: "union",
    options: e,
    ..._.normalizeParams(t)
  });
}
s(pt, "union");
var Sf = /* @__PURE__ */ g("ZodXor", (e, t) => {
  On.init(e, t), tc.init(e, t), e._zod.processJSONSchema = (n, o, r) => So(e, n, o, r), e.options = t.options;
});
function Wg(e, t) {
  return new Sf({
    type: "union",
    options: e,
    inclusive: !1,
    ..._.normalizeParams(t)
  });
}
s(Wg, "xor");
var Of = /* @__PURE__ */ g("ZodDiscriminatedUnion", (e, t) => {
  On.init(e, t), tt.init(e, t);
});
function Kg(e, t, n) {
  return new Of({
    type: "union",
    options: t,
    discriminator: e,
    ..._.normalizeParams(n)
  });
}
s(Kg, "discriminatedUnion");
var jf = /* @__PURE__ */ g("ZodIntersection", (e, t) => {
  nc.init(e, t), A.init(e, t), e._zod.processJSONSchema = (n, o, r) => qd(e, n, o, r);
});
function Pf(e, t) {
  return new jf({
    type: "intersection",
    left: e,
    right: t
  });
}
s(Pf, "intersection");
var Df = /* @__PURE__ */ g("ZodTuple", (e, t) => {
  Zt(), rt.init(e, t), A.init(e, t), e._zod.processJSONSchema = (n, o, r) => Wd(e, n, o, r);
}, {
  rest(e) {
    return this.clone({
      ...this._zod.def,
      rest: e
    });
  },
  partial() {
    let e = this._zod.def;
    if (e.checks?.length)
      throw new Error(".partial() cannot be used on tuple schemas containing refinements");
    return this.clone({
      ...e,
      items: e.items.map((t) => new jn({ type: "optional", innerType: t }))
    });
  }
});
function Nf(e, t, n) {
  let o = t instanceof O, r = o ? n : t, i = o ? t : null;
  return new Df({
    type: "tuple",
    items: e,
    rest: i,
    ..._.normalizeParams(r)
  });
}
s(Nf, "tuple");
var Ir = /* @__PURE__ */ g("ZodRecord", (e, t) => {
  Zt(), St.init(e, t), A.init(e, t), e._zod.processJSONSchema = (n, o, r) => Kd(e, n, o, r), e.keyType = t.keyType, e.valueType = t.valueType;
});
function Tf(e, t, n) {
  return !t || !t._zod ? new Ir({
    type: "record",
    keyType: Ut(),
    valueType: e,
    ..._.normalizeParams(t)
  }) : new Ir({
    type: "record",
    keyType: e,
    valueType: t,
    ..._.normalizeParams(n)
  });
}
s(Tf, "record");
function Gg(e, t, n) {
  return new Ir({
    type: "record",
    keyType: e,
    valueType: t,
    ..._.normalizeParams(n),
    partial: !0
  });
}
s(Gg, "partialRecord");
function Xg(e, t, n) {
  return new Ir({
    type: "record",
    keyType: e,
    valueType: t,
    mode: "loose",
    ..._.normalizeParams(n)
  });
}
s(Xg, "looseRecord");
var Af = /* @__PURE__ */ g("ZodMap", (e, t) => {
  Zt(), ic.init(e, t), A.init(e, t), e._zod.processJSONSchema = (n, o, r) => Vd(e, n, o, r), e.keyType = t.keyType, e.valueType = t.valueType, e.min = (...n) => e.check(Le(...n)), e.nonempty = (n) => e.check(Le(1, n)), e.max = (...n) => e.check(ot(...n)), e.size = (...n) => e.check(Nt(...n));
});
function Hg(e, t, n) {
  return new Af({
    type: "map",
    keyType: e,
    valueType: t,
    ..._.normalizeParams(n)
  });
}
s(Hg, "map");
var Uf = /* @__PURE__ */ g("ZodSet", (e, t) => {
  Zt(), oc.init(e, t), A.init(e, t), e._zod.processJSONSchema = (n, o, r) => Md(e, n, o, r), e.min = (...n) => e.check(Le(...n)), e.nonempty = (n) => e.check(Le(1, n)), e.max = (...n) => e.check(ot(...n)), e.size = (...n) => e.check(Nt(...n));
});
function Qg(e, t) {
  return new Uf({
    type: "set",
    valueType: e,
    ..._.normalizeParams(t)
  });
}
s(Qg, "set");
var zr = /* @__PURE__ */ g("ZodEnum", (e, t) => {
  ur.init(e, t), A.init(e, t), e._zod.processJSONSchema = (o, r, i) => Td(e, o, r, i), e.enum = t.entries, e.options = Object.values(t.entries);
  let n = new Set(Object.keys(t.entries));
  e.extract = (o, r) => {
    let i = {};
    for (let a of o)
      if (n.has(a))
        i[a] = t.entries[a];
      else
        throw new Error(`Key ${a} not found in enum`);
    return new zr({
      ...t,
      checks: [],
      ..._.normalizeParams(r),
      entries: i
    });
  }, e.exclude = (o, r) => {
    let i = { ...t.entries };
    for (let a of o)
      if (n.has(a))
        delete i[a];
      else
        throw new Error(`Key ${a} not found in enum`);
    return new zr({
      ...t,
      checks: [],
      ..._.normalizeParams(r),
      entries: i
    });
  };
});
function na(e, t) {
  let n = Array.isArray(e) ? Object.fromEntries(e.map((o) => [o, o])) : e;
  return new zr({
    type: "enum",
    entries: n,
    ..._.normalizeParams(t)
  });
}
s(na, "_enum");
function Yg(e, t) {
  return new zr({
    type: "enum",
    entries: e,
    ..._.normalizeParams(t)
  });
}
s(Yg, "nativeEnum");
var Ef = /* @__PURE__ */ g("ZodLiteral", (e, t) => {
  cr.init(e, t), A.init(e, t), e._zod.processJSONSchema = (n, o, r) => Ad(e, n, o, r), e.values = new Set(t.values), Object.defineProperty(e, "value", {
    get() {
      if (t.values.length > 1)
        throw new Error("This schema contains multiple valid literal values. Use `.values` instead.");
      return t.values[0];
    }
  });
});
function eh(e, t) {
  return new Ef({
    type: "literal",
    values: Array.isArray(e) ? e : [e],
    ..._.normalizeParams(t)
  });
}
s(eh, "literal");
var Cf = /* @__PURE__ */ g("ZodFile", (e, t) => {
  ac.init(e, t), A.init(e, t), e._zod.processJSONSchema = (n, o, r) => Cd(e, n, o, r), e.min = (n, o) => e.check(Le(n, o)), e.max = (n, o) => e.check(ot(n, o)), e.mime = (n, o) => e.check(vr(Array.isArray(n) ? n : [n], o));
});
function th(e) {
  return ld(Cf, e);
}
s(th, "file");
var Zf = /* @__PURE__ */ g("ZodTransform", (e, t) => {
  Zt(), sc.init(e, t), A.init(e, t), e._zod.processJSONSchema = (n, o, r) => Ld(e, n, o, r), e._zod.parse = (n, o) => {
    if (o.direction === "backward")
      throw new He(e.constructor.name);
    n.addIssue = (i) => {
      if (typeof i == "string")
        n.issues.push(_.issue(i, n.value, t));
      else {
        let a = i;
        a.fatal && (a.continue = !1), a.code ?? (a.code = "custom"), "input" in a || (a.input = n.value), a.inst ?? (a.inst = e), n.issues.push(_.issue(a));
      }
    };
    let r = t.transform(n.value, n);
    return r instanceof Promise ? r.then((i) => (n.value = i, n)) : (n.value = r, n);
  };
});
function ia(e) {
  return new Zf({
    type: "transform",
    transform: e
  });
}
s(ia, "transform");
var jn = /* @__PURE__ */ g("ZodOptional", (e, t) => {
  ee.init(e, t), A.init(e, t), e._zod.processJSONSchema = (n, o, r) => Oo(e, n, o, r), e.unwrap = () => e._zod.def.innerType;
});
function We(e) {
  return new jn({
    type: "optional",
    innerType: e
  });
}
s(We, "optional");
var oa = /* @__PURE__ */ g("ZodExactOptional", (e, t) => {
  uc.init(e, t), A.init(e, t), e._zod.processJSONSchema = (n, o, r) => Oo(e, n, o, r), e.unwrap = () => e._zod.def.innerType;
});
function Rf(e) {
  return new oa({
    type: "optional",
    innerType: e
  });
}
s(Rf, "exactOptional");
var Ff = /* @__PURE__ */ g("ZodNullable", (e, t) => {
  Te.init(e, t), A.init(e, t), e._zod.processJSONSchema = (n, o, r) => Gd(e, n, o, r), e.unwrap = () => e._zod.def.innerType;
});
function Ct(e) {
  return new Ff({
    type: "nullable",
    innerType: e
  });
}
s(Ct, "nullable");
function rh(e) {
  return We(Ct(e));
}
s(rh, "nullish");
var Lf = /* @__PURE__ */ g("ZodDefault", (e, t) => {
  _e.init(e, t), A.init(e, t), e._zod.processJSONSchema = (n, o, r) => Qd(e, n, o, r), e.unwrap = () => e._zod.def.innerType, e.removeDefault = e.unwrap;
});
function Vf(e, t) {
  return new Lf({
    type: "default",
    innerType: e,
    get defaultValue() {
      return typeof t == "function" ? t() : _.shallowClone(t);
    }
  });
}
s(Vf, "_default");
var Mf = /* @__PURE__ */ g("ZodPrefault", (e, t) => {
  cc.init(e, t), A.init(e, t), e._zod.processJSONSchema = (n, o, r) => Yd(e, n, o, r), e.unwrap = () => e._zod.def.innerType;
});
function Bf(e, t) {
  return new Mf({
    type: "prefault",
    innerType: e,
    get defaultValue() {
      return typeof t == "function" ? t() : _.shallowClone(t);
    }
  });
}
s(Bf, "prefault");
var aa = /* @__PURE__ */ g("ZodNonOptional", (e, t) => {
  lc.init(e, t), A.init(e, t), e._zod.processJSONSchema = (n, o, r) => Xd(e, n, o, r), e.unwrap = () => e._zod.def.innerType;
});
function Jf(e, t) {
  return new aa({
    type: "nonoptional",
    innerType: e,
    ..._.normalizeParams(t)
  });
}
s(Jf, "nonoptional");
var qf = /* @__PURE__ */ g("ZodSuccess", (e, t) => {
  dc.init(e, t), A.init(e, t), e._zod.processJSONSchema = (n, o, r) => Zd(e, n, o, r), e.unwrap = () => e._zod.def.innerType;
});
function nh(e) {
  return new qf({
    type: "success",
    innerType: e
  });
}
s(nh, "success");
var Wf = /* @__PURE__ */ g("ZodCatch", (e, t) => {
  fc.init(e, t), A.init(e, t), e._zod.processJSONSchema = (n, o, r) => ef(e, n, o, r), e.unwrap = () => e._zod.def.innerType, e.removeCatch = e.unwrap;
});
function Kf(e, t) {
  return new Wf({
    type: "catch",
    innerType: e,
    catchValue: typeof t == "function" ? t : _.constantCatch(t)
  });
}
s(Kf, "_catch");
var Gf = /* @__PURE__ */ g("ZodNaN", (e, t) => {
  pc.init(e, t), A.init(e, t), e._zod.processJSONSchema = (n, o, r) => Ud(e, n, o, r);
});
function ih(e) {
  return ud(Gf, e);
}
s(ih, "nan");
var Pn = /* @__PURE__ */ g("ZodPipe", (e, t) => {
  Bi.init(e, t), A.init(e, t), e._zod.processJSONSchema = (n, o, r) => tf(e, n, o, r), e.in = t.in, e.out = t.out;
});
function Ao(e, t) {
  return new Pn({
    type: "pipe",
    in: e,
    out: t
    // ...util.normalizeParams(params),
  });
}
s(Ao, "pipe");
var Dn = /* @__PURE__ */ g("ZodCodec", (e, t) => {
  Pn.init(e, t), Ae.init(e, t);
});
function sa(e, t, n) {
  return new Dn({
    type: "pipe",
    in: e,
    out: t,
    transform: n.decode,
    reverseTransform: n.encode
  });
}
s(sa, "codec");
function oh(e) {
  let t = e._zod.def;
  return new Dn({
    type: "pipe",
    in: t.out,
    out: t.in,
    transform: t.reverseTransform,
    reverseTransform: t.transform
  });
}
s(oh, "invertCodec");
var Xf = /* @__PURE__ */ g("ZodPreprocess", (e, t) => {
  Pn.init(e, t), mc.init(e, t);
}), Hf = /* @__PURE__ */ g("ZodReadonly", (e, t) => {
  gc.init(e, t), A.init(e, t), e._zod.processJSONSchema = (n, o, r) => rf(e, n, o, r), e.unwrap = () => e._zod.def.innerType;
});
function Qf(e) {
  return new Hf({
    type: "readonly",
    innerType: e
  });
}
s(Qf, "readonly");
var Yf = /* @__PURE__ */ g("ZodTemplateLiteral", (e, t) => {
  hc.init(e, t), A.init(e, t), e._zod.processJSONSchema = (n, o, r) => Ed(e, n, o, r);
});
function ah(e, t) {
  return new Yf({
    type: "template_literal",
    parts: e,
    ..._.normalizeParams(t)
  });
}
s(ah, "templateLiteral");
var ep = /* @__PURE__ */ g("ZodLazy", (e, t) => {
  nt.init(e, t), A.init(e, t), e._zod.processJSONSchema = (n, o, r) => of(e, n, o, r), e.unwrap = () => e._zod.def.getter();
});
function tp(e) {
  return new ep({
    type: "lazy",
    getter: e
  });
}
s(tp, "lazy");
var rp = /* @__PURE__ */ g("ZodPromise", (e, t) => {
  yc.init(e, t), A.init(e, t), e._zod.processJSONSchema = (n, o, r) => nf(e, n, o, r), e.unwrap = () => e._zod.def.innerType;
});
function sh(e) {
  return new rp({
    type: "promise",
    innerType: e
  });
}
s(sh, "promise");
var np = /* @__PURE__ */ g("ZodFunction", (e, t) => {
  vc.init(e, t), A.init(e, t), e._zod.processJSONSchema = (n, o, r) => Fd(e, n, o, r);
});
function uh(e) {
  return new np({
    type: "function",
    input: Array.isArray(e?.input) ? Nf(e?.input) : e?.input ?? Ft(Et()),
    output: e?.output ?? Et()
  });
}
s(uh, "_function");
var Nn = /* @__PURE__ */ g("ZodCustom", (e, t) => {
  sn.init(e, t), A.init(e, t), e._zod.processJSONSchema = (n, o, r) => Rd(e, n, o, r);
});
function ch(e) {
  let t = new K({
    check: "custom"
    // ...util.normalizeParams(params),
  });
  return t._zod.check = e, t;
}
s(ch, "check");
function lh(e, t) {
  return dd(Nn, e ?? (() => !0), t);
}
s(lh, "custom");
function ip(e, t = {}) {
  return fd(Nn, e, t);
}
s(ip, "refine");
function op(e, t) {
  return pd(e, t);
}
s(op, "superRefine");
var dh = md, fh = gd;
function ua(e, t = {}) {
  let n = new Nn({
    type: "custom",
    check: "custom",
    fn: /* @__PURE__ */ s((o) => o instanceof e, "fn"),
    abort: !0,
    ..._.normalizeParams(t)
  });
  return n._zod.bag.Class = e, n._zod.check = (o) => {
    o.value instanceof e || o.issues.push({
      code: "invalid_type",
      expected: e.name,
      input: o.value,
      inst: n,
      path: [...n._zod.def.path ?? []]
    });
  }, n;
}
s(ua, "_instanceof");
var ph = /* @__PURE__ */ s((...e) => hd({
  Codec: Dn,
  Boolean: Pr,
  String: Sr
}, ...e), "stringbool");
function mh(e) {
  let t = tp(() => pt([Ut(e), kn(), In(), _f(), Ft(t), Tf(Ut(), t)]));
  return t;
}
s(mh, "json");
function gh(e, t) {
  return new Xf({
    type: "pipe",
    in: ia(e),
    out: t
  });
}
s(gh, "preprocess");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/compat.js
var Ux = {
  invalid_type: "invalid_type",
  too_big: "too_big",
  too_small: "too_small",
  invalid_format: "invalid_format",
  not_multiple_of: "not_multiple_of",
  unrecognized_keys: "unrecognized_keys",
  invalid_union: "invalid_union",
  invalid_key: "invalid_key",
  invalid_element: "invalid_element",
  invalid_value: "invalid_value",
  custom: "custom"
};
function Ex(e) {
  te({
    customError: e
  });
}
s(Ex, "setErrorMap");
function Cx() {
  return te().customError;
}
s(Cx, "getErrorMap");
var ap;
ap || (ap = {});

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/iso.js
var Tn = {};
Be(Tn, {
  ZodISODate: () => lt,
  ZodISODateTime: () => ct,
  ZodISODuration: () => ft,
  ZodISOTime: () => dt,
  date: () => Rx,
  datetime: () => Zx,
  duration: () => Lx,
  time: () => Fx
});
function Zx(e) {
  return gn(ct, e);
}
s(Zx, "datetime");
function Rx(e) {
  return hn(lt, e);
}
s(Rx, "date");
function Fx(e) {
  return vn(dt, e);
}
s(Fx, "time");
function Lx(e) {
  return yn(ft, e);
}
s(Lx, "duration");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/from-json-schema.js
var z = {
  ...Nr,
  ...Do,
  iso: Tn
}, Vx = /* @__PURE__ */ new Set([
  // Schema identification
  "$schema",
  "$ref",
  "$defs",
  "definitions",
  // Core schema keywords
  "$id",
  "id",
  "$comment",
  "$anchor",
  "$vocabulary",
  "$dynamicRef",
  "$dynamicAnchor",
  // Type
  "type",
  "enum",
  "const",
  // Composition
  "anyOf",
  "oneOf",
  "allOf",
  "not",
  // Object
  "properties",
  "required",
  "additionalProperties",
  "patternProperties",
  "propertyNames",
  "minProperties",
  "maxProperties",
  // Array
  "items",
  "prefixItems",
  "additionalItems",
  "minItems",
  "maxItems",
  "uniqueItems",
  "contains",
  "minContains",
  "maxContains",
  // String
  "minLength",
  "maxLength",
  "pattern",
  "format",
  // Number
  "minimum",
  "maximum",
  "exclusiveMinimum",
  "exclusiveMaximum",
  "multipleOf",
  // Already handled metadata
  "description",
  "default",
  // Content
  "contentEncoding",
  "contentMediaType",
  "contentSchema",
  // Unsupported (error-throwing)
  "unevaluatedItems",
  "unevaluatedProperties",
  "if",
  "then",
  "else",
  "dependentSchemas",
  "dependentRequired",
  // OpenAPI
  "nullable",
  "readOnly"
]);
function Mx(e, t) {
  let n = e.$schema;
  return n === "https://json-schema.org/draft/2020-12/schema" ? "draft-2020-12" : n === "http://json-schema.org/draft-07/schema#" ? "draft-7" : n === "http://json-schema.org/draft-04/schema#" ? "draft-4" : t ?? "draft-2020-12";
}
s(Mx, "detectVersion");
function hh(e, t) {
  return e.map((n, o) => o < t ? n : n.optional());
}
s(hh, "applyMinItems");
function Bx(e) {
  return e.replace(/~1/g, "/").replace(/~0/g, "~");
}
s(Bx, "decodeJSONPointerSegment");
function Jx(e, t) {
  if (!e.startsWith("#"))
    throw new Error("External $ref is not supported, only local refs (#/...) are allowed");
  let n = e.slice(1).split("/").filter(Boolean);
  if (n.length === 0)
    return t.rootSchema;
  let o = t.version === "draft-2020-12" ? "$defs" : "definitions";
  if (n[0] === o) {
    let r = n[1] === void 0 ? void 0 : Bx(n[1]);
    if (!r || !t.defs[r])
      throw new Error(`Reference not found: ${e}`);
    return t.defs[r];
  }
  throw new Error(`Reference not found: ${e}`);
}
s(Jx, "resolveRef");
function qx(e, t) {
  return z.transform((o) => o).check((o) => {
    let r = o.value;
    if (!(typeof r != "object" || r === null || Array.isArray(r)))
      for (let i of Object.getOwnPropertyNames(r)) {
        let a = t.safeParse(i);
        a.success || o.issues.push({
          code: "invalid_key",
          origin: "record",
          issues: a.error.issues,
          input: i,
          path: [i],
          continue: !0
        });
      }
  }).pipe(e);
}
s(qx, "checkPropertyNames");
function vh(e, t) {
  if (e !== !1)
    return e === void 0 || e === !0 ? z.any() : $e(e, t);
}
s(vh, "getTupleRest");
var Wx = /^(?:[01]\d|2[0-3]):[0-5]\d:[0-5]\d(?:\.\d+)?(?:Z|[+-](?:[01]\d|2[0-3]):[0-5]\d)$/;
function yh(e, t) {
  if (e.not !== void 0) {
    if (typeof e.not == "object" && Object.keys(e.not).length === 0)
      return z.never();
    throw new Error("not is not supported in Zod (except { not: {} } for never)");
  }
  if (e.unevaluatedItems !== void 0)
    throw new Error("unevaluatedItems is not supported");
  if (e.unevaluatedProperties !== void 0)
    throw new Error("unevaluatedProperties is not supported");
  if (e.if !== void 0 || e.then !== void 0 || e.else !== void 0)
    throw new Error("Conditional schemas (if/then/else) are not supported");
  if (e.dependentSchemas !== void 0 || e.dependentRequired !== void 0)
    throw new Error("dependentSchemas and dependentRequired are not supported");
  if (e.$ref) {
    let r = e.$ref;
    if (t.refs.has(r))
      return t.refs.get(r);
    if (t.processing.has(r))
      return z.lazy(() => {
        if (!t.refs.has(r))
          throw new Error(`Circular reference not resolved: ${r}`);
        return t.refs.get(r);
      });
    t.processing.add(r);
    let i = Jx(r, t), a = $e(i, t);
    return t.refs.set(r, a), t.processing.delete(r), a;
  }
  if (e.enum !== void 0) {
    let r = e.enum;
    if (t.version === "openapi-3.0" && e.nullable === !0 && r.length === 1 && r[0] === null)
      return z.null();
    if (r.length === 0)
      return z.never();
    if (r.length === 1)
      return z.literal(r[0]);
    if (r.every((a) => typeof a == "string"))
      return z.enum(r);
    let i = r.map((a) => z.literal(a));
    return i.length < 2 ? i[0] : z.union([i[0], i[1], ...i.slice(2)]);
  }
  if (e.const !== void 0)
    return z.literal(e.const);
  let n = e.type;
  if (Array.isArray(n)) {
    let r = n.map((i) => {
      let a = { ...e, type: i };
      return yh(a, t);
    });
    return r.length === 0 ? z.never() : r.length === 1 ? r[0] : z.union(r);
  }
  if (!n)
    return z.any();
  let o;
  switch (n) {
    case "string": {
      let r = z.string();
      if (e.format) {
        let i = e.format;
        i === "email" ? r = r.check(z.email()) : i === "uri" || i === "uri-reference" ? r = r.check(z.url()) : i === "uuid" || i === "guid" ? r = r.check(z.uuid()) : i === "date-time" ? r = r.check(z.iso.datetime({ offset: !0 })) : i === "date" ? r = r.check(z.iso.date()) : i === "time" ? r = r.check(z.regex(Wx)) : i === "duration" ? r = r.check(z.iso.duration()) : i === "hostname" ? r = r.check(z.hostname()) : i === "ipv4" ? r = r.check(z.ipv4()) : i === "ipv6" ? r = r.check(z.ipv6()) : i === "mac" ? r = r.check(z.mac()) : i === "cidr" ? r = r.check(z.cidrv4()) : i === "cidr-v6" ? r = r.check(z.cidrv6()) : i === "base64" ? r = r.check(z.base64()) : i === "base64url" ? r = r.check(z.base64url()) : i === "e164" ? r = r.check(z.e164()) : i === "credit_card" ? r = r.check(z.creditCard()) : i === "jwt" ? r = r.check(z.jwt()) : i === "emoji" ? r = r.check(z.emoji()) : i === "nanoid" ? r = r.check(z.nanoid()) : i === "cuid" ? r = r.check(z.cuid()) : i === "cuid2" ? r = r.check(z.cuid2()) : i === "ulid" ? r = r.check(z.ulid()) : i === "xid" ? r = r.check(z.xid()) : i === "ksuid" && (r = r.check(z.ksuid()));
      }
      typeof e.minLength == "number" && (r = r.min(e.minLength)), typeof e.maxLength == "number" && (r = r.max(e.maxLength)), e.pattern && (r = r.regex(new RegExp(e.pattern))), o = r;
      break;
    }
    case "number":
    case "integer": {
      let r = n === "integer" ? z.number().int() : z.number();
      typeof e.minimum == "number" && e.exclusiveMinimum !== !0 && (r = r.min(e.minimum)), typeof e.maximum == "number" && e.exclusiveMaximum !== !0 && (r = r.max(e.maximum)), typeof e.exclusiveMinimum == "number" ? r = r.gt(e.exclusiveMinimum) : e.exclusiveMinimum === !0 && typeof e.minimum == "number" && (r = r.gt(e.minimum)), typeof e.exclusiveMaximum == "number" ? r = r.lt(e.exclusiveMaximum) : e.exclusiveMaximum === !0 && typeof e.maximum == "number" && (r = r.lt(e.maximum)), typeof e.multipleOf == "number" && (r = r.multipleOf(e.multipleOf)), o = r;
      break;
    }
    case "boolean": {
      o = z.boolean();
      break;
    }
    case "null": {
      o = z.null();
      break;
    }
    case "object": {
      let r = {}, i = e.properties || {}, a = new Set(e.required || []), u = typeof e.additionalProperties == "object" ? $e(e.additionalProperties, t) : void 0;
      for (let [c, l] of Object.entries(i)) {
        let d = $e(l, t);
        Y(r, c, a.has(c) ? d : d.optional());
      }
      if (e.patternProperties) {
        let c = e.patternProperties, l = Object.keys(c), d = [];
        for (let p of l) {
          let m = $e(c[p], t), v = z.string().regex(new RegExp(p));
          d.push(z.looseRecord(v, m));
        }
        let f = [];
        if (Object.keys(r).length > 0 && f.push(z.object(r).passthrough()), f.push(...d), f.length === 0)
          o = z.object({}).passthrough();
        else if (f.length === 1)
          o = f[0];
        else {
          let p = z.intersection(f[0], f[1]);
          for (let m = 2; m < f.length; m++)
            p = z.intersection(p, f[m]);
          o = p;
        }
        if (e.additionalProperties === !1) {
          let p = Object.keys(r), m = l.map((x) => new RegExp(x)), v = o;
          o = o.check((x) => {
            if (!Se(x.value))
              return;
            let k = [];
            for (let R of Object.keys(x.value))
              p.includes(R) || m.some((j) => j.test(R)) || k.push(R);
            k.length && x.issues.push({
              code: "unrecognized_keys",
              keys: k,
              input: x.value,
              inst: v
            });
          });
        }
      } else {
        let c = z.object(r);
        e.additionalProperties === !1 ? o = c.strict() : u ? o = c.catchall(u) : o = c.passthrough();
      }
      if (e.propertyNames !== void 0 && e.propertyNames !== !0) {
        let c = typeof e.propertyNames == "object" && e.propertyNames.type === void 0 ? { type: "string", ...e.propertyNames } : e.propertyNames;
        o = qx(o, $e(c, t));
      }
      break;
    }
    case "array": {
      let r = e.prefixItems, i = e.items;
      if (r && Array.isArray(r)) {
        let a = typeof e.minItems == "number" ? e.minItems : 0, u = r.map((f) => $e(f, t)), c = hh(u, a), l = Array.isArray(i) ? void 0 : vh(i, t), d = z.tuple(c);
        o = l ? d.rest(l) : d, typeof e.minItems == "number" && (o = o.check(z.minLength(e.minItems))), typeof e.maxItems == "number" && (o = o.check(z.maxLength(e.maxItems)));
      } else if (Array.isArray(i)) {
        let a = typeof e.minItems == "number" ? e.minItems : 0, u = i.map((f) => $e(f, t)), c = hh(u, a), l = vh(e.additionalItems, t), d = z.tuple(c);
        o = l ? d.rest(l) : d, typeof e.minItems == "number" && (o = o.check(z.minLength(e.minItems))), typeof e.maxItems == "number" && (o = o.check(z.maxLength(e.maxItems)));
      } else if (i !== void 0) {
        let a = $e(i, t), u = z.array(a);
        typeof e.minItems == "number" && (u = u.min(e.minItems)), typeof e.maxItems == "number" && (u = u.max(e.maxItems)), o = u;
      } else
        o = z.array(z.any());
      break;
    }
    default:
      throw new Error(`Unsupported type: ${n}`);
  }
  return o;
}
s(yh, "convertBaseSchema");
function $e(e, t) {
  if (typeof e == "boolean")
    return e ? z.any() : z.never();
  let n = yh(e, t), o = e.type || e.enum !== void 0 || e.const !== void 0;
  if (e.anyOf && Array.isArray(e.anyOf)) {
    let u = e.anyOf.map((l) => $e(l, t)), c = z.union(u);
    n = o ? z.intersection(n, c) : c;
  }
  if (e.oneOf && Array.isArray(e.oneOf)) {
    let u = e.oneOf.map((l) => $e(l, t)), c = z.xor(u);
    n = o ? z.intersection(n, c) : c;
  }
  if (e.allOf && Array.isArray(e.allOf))
    if (e.allOf.length === 0)
      n = o ? n : z.any();
    else {
      let u = o ? n : $e(e.allOf[0], t), c = o ? 0 : 1;
      for (let l = c; l < e.allOf.length; l++)
        u = z.intersection(u, $e(e.allOf[l], t));
      n = u;
    }
  e.nullable === !0 && t.version === "openapi-3.0" && (n = z.nullable(n)), e.readOnly === !0 && (n = z.readonly(n)), e.default !== void 0 && (n = n.default(e.default));
  let r = {}, i = ["$id", "id", "$comment", "$anchor", "$vocabulary", "$dynamicRef", "$dynamicAnchor"];
  for (let u of i)
    u in e && (r[u] = e[u]);
  let a = ["contentEncoding", "contentMediaType", "contentSchema"];
  for (let u of a)
    u in e && (r[u] = e[u]);
  e.propertyNames !== void 0 && e.type === "object" && e.$ref === void 0 && (r.propertyNames = e.propertyNames);
  for (let u of Object.keys(e))
    Vx.has(u) || Y(r, u, e[u]);
  return Object.keys(r).length > 0 && t.registry.add(n, r), e.description && (n = n.describe(e.description)), n;
}
s($e, "convertSchema");
function $h(e, t) {
  if (typeof e == "boolean")
    return e ? z.any() : z.never();
  let n;
  try {
    n = JSON.parse(JSON.stringify(e));
  } catch {
    throw new Error("fromJSONSchema input is not valid JSON (possibly cyclic); use $defs/$ref for recursive schemas");
  }
  let o = Mx(n, t?.defaultTarget), r = n.$defs || n.definitions || {}, i = {
    version: o,
    defs: r,
    refs: /* @__PURE__ */ new Map(),
    processing: /* @__PURE__ */ new Set(),
    rootSchema: n,
    registry: t?.registry ?? se
  };
  return $e(n, i);
}
s($h, "fromJSONSchema");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/visit.js
var bh = Symbol("z.visit/resolving");
function An(e, t) {
  let n = typeof t == "function" ? t : (a, u) => {
    let c = t[a._zod.def.type];
    return c ? c(a, u) : a;
  }, o = /* @__PURE__ */ new Map();
  function r(a) {
    let u = o.get(a);
    if (u === bh)
      return new nt({
        type: "lazy",
        getter: /* @__PURE__ */ s(() => o.get(a), "getter")
      });
    if (u !== void 0)
      return u;
    o.set(a, bh);
    let c = i(a), l = n(c, c !== a);
    return o.set(a, l), l;
  }
  s(r, "run");
  function i(a) {
    let u = a._zod.def, c = u.type;
    switch (c) {
      case "object": {
        let l = u.shape, d = Object.keys(l), f = !1, p = {};
        for (let v of d) {
          let x = r(l[v]);
          x !== l[v] && (f = !0), p[v] = x;
        }
        let m = u.catchall;
        return u.catchall && (m = r(u.catchall), m !== u.catchall && (f = !0)), f ? C(a, { ...u, shape: p, catchall: m }) : a;
      }
      case "array": {
        let l = r(u.element);
        return l === u.element ? a : C(a, { ...u, element: l });
      }
      case "tuple": {
        let l = u.items, d = !1, f = [];
        for (let m of l) {
          let v = r(m);
          v !== m && (d = !0), f.push(v);
        }
        let p = u.rest;
        return u.rest && (p = r(u.rest), p !== u.rest && (d = !0)), d ? C(a, { ...u, items: f, rest: p }) : a;
      }
      case "record":
      case "map": {
        let l = r(u.keyType), d = r(u.valueType);
        return l === u.keyType && d === u.valueType ? a : C(a, { ...u, keyType: l, valueType: d });
      }
      case "set": {
        let l = r(u.valueType);
        return l === u.valueType ? a : C(a, { ...u, valueType: l });
      }
      case "union": {
        let l = u.options, d = !1, f = [];
        for (let p of l) {
          let m = r(p);
          m !== p && (d = !0), f.push(m);
        }
        return d ? C(a, { ...u, options: f }) : a;
      }
      case "intersection": {
        let l = r(u.left), d = r(u.right);
        return l === u.left && d === u.right ? a : C(a, { ...u, left: l, right: d });
      }
      case "optional":
      case "nullable":
      case "default":
      case "prefault":
      case "catch":
      case "readonly":
      case "nonoptional":
      case "promise":
      case "success": {
        let l = r(u.innerType);
        return l === u.innerType ? a : C(a, { ...u, innerType: l });
      }
      case "pipe": {
        let l = r(u.in), d = r(u.out);
        return l === u.in && d === u.out ? a : C(a, { ...u, in: l, out: d });
      }
      case "function": {
        let l = r(u.input), d = r(u.output);
        return l === u.input && d === u.output ? a : C(a, { ...u, input: l, output: d });
      }
      case "lazy": {
        let l = u.getter, { _cachedInner: d, ...f } = u;
        return C(a, { ...f, getter: /* @__PURE__ */ s(() => r(l()), "getter") });
      }
      // A leaf by choice: `parts` are regex fragments, not data positions.
      case "template_literal":
      // Leaves.
      case "string":
      case "number":
      case "int":
      case "boolean":
      case "bigint":
      case "symbol":
      case "undefined":
      case "null":
      case "void":
      case "never":
      case "any":
      case "unknown":
      case "date":
      case "nan":
      case "enum":
      case "literal":
      case "file":
      case "transform":
      case "custom":
        return a;
      default:
        return a;
    }
  }
  return s(i, "mapInner"), r(e);
}
s(An, "visit");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/deep-partial.js
function _h(e) {
  return An(e, {
    object: /* @__PURE__ */ s((t) => t.partial(), "object"),
    // Every partialed option now admits `undefined`, which the constructor rejects as a duplicate.
    union: /* @__PURE__ */ s((t) => {
      let n = t._zod.def;
      return n.discriminator === void 0 ? t : pt(n.options);
    }, "union")
  });
}
s(_h, "deepPartial");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/in-out.js
function Kx(e, t) {
  if (!t?.length)
    return e;
  let n = e._zod.def;
  return C(e, Pe(n, { checks: [...n.checks ?? [], ...t] }), { parent: !0 });
}
s(Kx, "withChecks");
function xh(e) {
  return Kx(e.out, e.checks);
}
s(xh, "outSide");
function Gx(e) {
  return e.in._zod.traits.has("$ZodTransform") ? xh(e) : e.in;
}
s(Gx, "inSide");
function wh(e) {
  return An(e, {
    pipe: /* @__PURE__ */ s((t) => Gx(t._zod.def), "pipe"),
    // A default value belongs to the output side, so a rewritten inner type leaves it stranded. `.default()` widens the declared input type with `undefined`, and `optional` is what carries that across.
    default: /* @__PURE__ */ s((t, n) => n ? We(t._zod.def.innerType) : t, "default"),
    // A catch value is output-side too, but `.catch()` leaves the declared input type alone, so the inner schema stands on its own.
    catch: /* @__PURE__ */ s((t, n) => n ? t._zod.def.innerType : t, "catch")
  });
}
s(wh, "input");
function kh(e) {
  return An(e, {
    pipe: /* @__PURE__ */ s((t) => xh(t._zod.def), "pipe"),
    // A prefault value is fed through the schema, which makes it input-side, so a rewritten inner type leaves it stranded.
    prefault: /* @__PURE__ */ s((t, n) => n ? t._zod.def.innerType : t, "prefault")
  });
}
s(kh, "output");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/coerce.js
var sp = {};
Be(sp, {
  bigint: () => Yx,
  boolean: () => Qx,
  date: () => ew,
  number: () => Hx,
  string: () => Xx
});
function Xx(e) {
  return El(Sr, e);
}
s(Xx, "string");
function Hx(e) {
  return Ll(jr, e);
}
s(Hx, "number");
function Qx(e) {
  return Kl(Pr, e);
}
s(Qx, "boolean");
function Yx(e) {
  return Xl(Dr, e);
}
s(Yx, "bigint");
function ew(e) {
  return sd(zn, e);
}
s(ew, "date");

// ../../packages/zodvex/dist/index.js
var Ih = /* @__PURE__ */ new WeakMap(), rw = {
  getMetadata: /* @__PURE__ */ s((e) => Ih.get(e), "getMetadata"),
  setMetadata: /* @__PURE__ */ s((e, t) => Ih.set(e, t), "setMetadata")
};
var JD = S.discriminatedUnion("success", [
  S.object({ success: S.literal(!0) }),
  S.object({ success: S.literal(!1), error: S.string() })
]), qD = S.object({
  formErrors: S.array(S.string()),
  fieldErrors: S.record(S.string(), S.array(S.string()))
});
var nw = "__zodvexMeta";
function Oh(e, t) {
  Object.defineProperty(e, nw, {
    value: t,
    enumerable: !1,
    writable: !1,
    configurable: !1
  });
}
s(Oh, "attachMeta");
function up(e) {
  let t = S.string().check(
    S.refine((o) => typeof o == "string" && o.length > 0, {
      message: `Invalid ID for table "${e}"`
    }),
    S.describe(`convexId:${e}`)
  );
  rw.setMetadata(t, {
    isConvexId: !0,
    tableName: e
  });
  let n = t;
  return n._tableName = e, n;
}
s(up, "id");
function jh(e) {
  return e instanceof le || e instanceof tt;
}
s(jh, "isZodUnion");
function Ph(e) {
  return e instanceof le, e._zod.def.options;
}
s(Ph, "getUnionOptions");
function iw(e) {
  if (e.length < 2)
    throw new Error(
      `z.union() requires at least 2 options, but received ${e.length}. This indicates an invalid union schema was passed to zodTable().`
    );
}
s(iw, "assertUnionOptions");
function Dh(e) {
  return iw(e), S.union(e);
}
s(Dh, "createUnionFromOptions");
function Nh(e, t) {
  if (jh(t)) {
    let o = Ph(t).map((r) => {
      if (r instanceof re) {
        let i = {
          ...r._zod.def.shape,
          _id: up(e),
          _creationTime: S.number()
        };
        return C(r, { ...r._zod.def, shape: i });
      }
      return r;
    });
    return Dh(o);
  }
  if (t instanceof re) {
    let n = { ...t._zod.def.shape, _id: up(e), _creationTime: S.number() };
    return C(t, { ...t._zod.def, shape: n });
  }
  return t;
}
s(Nh, "addSystemFields");
function ow(e) {
  return e instanceof ee ? e : new ee({ type: "optional", innerType: e });
}
s(ow, "ensureOptional");
function zh(e) {
  return new ee({
    type: "optional",
    innerType: new Te({ type: "nullable", innerType: e })
  });
}
s(zh, "nullableOptional2");
function aw(e) {
  let t = {};
  for (let [n, o] of Object.entries(e))
    t[n] = ow(o);
  return t;
}
s(aw, "createPartialShape");
function cp(e, t) {
  return S.object({
    _id: up(e),
    _creationTime: S.optional(S.number()),
    ...aw(t)
  });
}
s(cp, "createUpdateObjectSchema");
function Th(e) {
  return S.object({
    page: S.array(e),
    isDone: S.boolean(),
    continueCursor: S.string(),
    splitCursor: zh(S.string()),
    pageStatus: zh(S.enum(["SplitRecommended", "SplitRequired"]))
  });
}
s(Th, "createPaginatedDocSchema");
function sw(e, t, n = S.object(t)) {
  let o = Nh(e, n);
  return {
    doc: o,
    base: n,
    insert: n,
    update: cp(e, t),
    docArray: S.array(o),
    paginatedDoc: Th(o)
  };
}
s(sw, "createObjectSchemaBundle");
function uw(e, t) {
  if (jh(t)) {
    let n = Ph(t).map((o) => o instanceof re ? cp(e, o._zod.def.shape) : o);
    return Dh(n);
  }
  return t instanceof re ? cp(e, t._zod.def.shape) : t;
}
s(uw, "createSchemaUpdateSchema");
function cw(e, t) {
  let n = Nh(e, t);
  return {
    doc: n,
    base: t,
    insert: t,
    update: uw(e, t),
    docArray: S.array(n),
    paginatedDoc: Th(n)
  };
}
s(cw, "createSchemaBundle");
function Ah(e, t) {
  let n;
  return {
    get: /* @__PURE__ */ s(() => n || (n = t ?? S.object(e), n), "get")
  };
}
s(Ah, "lazyValidator");
function Un(e, t, n, o, r = {}, i = {}, a = {}, u = null) {
  let c = Ah(t, u), l = {
    name: e,
    fields: t,
    schema: n,
    indexes: r,
    searchIndexes: i,
    vectorIndexes: a,
    get validator() {
      return c.get();
    },
    index(d, f) {
      return Un(
        e,
        t,
        n,
        o,
        { ...r, [d]: [...f, "_creationTime"] },
        i,
        a,
        u
      );
    },
    searchIndex(d, f) {
      return Un(
        e,
        t,
        n,
        o,
        r,
        { ...i, [d]: f },
        a,
        u
      );
    },
    vectorIndex(d, f) {
      return Un(
        e,
        t,
        n,
        o,
        r,
        i,
        { ...a, [d]: f },
        u
      );
    }
  };
  return Oh(l, { type: "model", tableName: e, definitionSource: o, schemas: n }), l;
}
s(Un, "createModel");
function En(e, t, n, o, r = {}, i = {}, a = {}) {
  let u = Ah(t, n), c = {
    name: e,
    fields: t,
    indexes: r,
    searchIndexes: i,
    vectorIndexes: a,
    get validator() {
      return u.get();
    },
    index(l, d) {
      return En(
        e,
        t,
        n,
        o,
        { ...r, [l]: [...d, "_creationTime"] },
        i,
        a
      );
    },
    searchIndex(l, d) {
      return En(
        e,
        t,
        n,
        o,
        r,
        { ...i, [l]: d },
        a
      );
    },
    vectorIndex(l, d) {
      return En(e, t, n, o, r, i, {
        ...a,
        [l]: d
      });
    }
  };
  return n !== null && (c.schema = n), Oh(c, { type: "model", tableName: e, definitionSource: o }), c;
}
s(En, "createSlimModel");
function Sh(e, t, n) {
  let o = n?.schemaHelpers === !1;
  if (t instanceof O)
    return o ? En(e, {}, t, "schema") : Un(
      e,
      {},
      cw(e, t),
      "schema",
      void 0,
      void 0,
      void 0,
      t
    );
  let r = t;
  return o ? En(e, r, null, "shape") : Un(e, r, sw(e, r), "shape");
}
s(Sh, "defineZodModel");
function Uh(e, t, n) {
  return t instanceof O, Sh(e, t, n);
}
s(Uh, "defineZodModel2");
function ca(e) {
  let t = /* @__PURE__ */ Symbol.for(`zodvex.zx.cache.${e}`), n = globalThis, o = n[t];
  if (o) return o;
  let r = /* @__PURE__ */ new WeakMap();
  return n[t] = r, r;
}
s(ca, "sharedWeakMap");
var WD = ca("base"), KD = ca("doc"), GD = ca("update"), XD = ca("docArray");

// ../../node_modules/.bun/convex-helpers@0.1.113+b9ed8f5244cf7f28/node_modules/convex-helpers/index.js
var YD = Symbol();

// ../../node_modules/.bun/convex-helpers@0.1.113+b9ed8f5244cf7f28/node_modules/convex-helpers/validators.js
var o6 = y.string(), a6 = y.float64(), s6 = y.float64(), u6 = y.boolean(), c6 = y.int64(), l6 = y.int64(), d6 = y.any(), f6 = y.null(), { id: p6, object: m6, array: g6, bytes: h6, literal: v6, optional: y6, union: $6 } = y, b6 = y.bytes();
var _6 = y.optional(y.any());

// ../../node_modules/.bun/convex-helpers@0.1.113+b9ed8f5244cf7f28/node_modules/convex-helpers/server/customFunctions.js
var la = {
  args: {},
  input() {
    return { args: {}, ctx: {} };
  }
};

// ../../packages/zodvex/dist/server/index.js
function Eh(e) {
  let t = e;
  for (let n = 0; n < 10; n++) {
    if (t instanceof ee || t instanceof Te || t instanceof _e) {
      t = t._zod.def.innerType;
      continue;
    }
    break;
  }
  return t;
}
s(Eh, "unwrapOuter");
function lw(e, t) {
  let n = [], o = t;
  for (let r of e) {
    if (o = Eh(o), o instanceof Ae)
      break;
    if (o instanceof re && typeof r == "string") {
      let i = o._zod.def.shape[r];
      if (!i) {
        n.push(r);
        break;
      }
      if (n.push(r), Eh(i) instanceof Ae)
        break;
      o = i;
      continue;
    }
    if (o instanceof et && typeof r == "number") {
      n.push(r), o = o._zod.def.element;
      continue;
    }
    n.push(r);
  }
  return n;
}
s(lw, "truncateAtCodecBoundary");
function dw(e, t) {
  let n = e.issues.map((o) => ({
    ...o,
    path: lw(o.path, t)
  }));
  return new De(n);
}
s(dw, "normalizeCodecPaths");
function fw(e, t) {
  try {
    return Ne(e, t);
  } catch (n) {
    throw n instanceof De ? dw(n, e) : n;
  }
}
s(fw, "safeEncode");
function mt(e) {
  if (e == null)
    return e;
  if (Array.isArray(e))
    return e.map(mt);
  if (typeof e == "object" && e.constructor === Object) {
    let t = {};
    for (let [n, o] of Object.entries(e))
      o !== void 0 && (t[n] = mt(o));
    return t;
  }
  return e;
}
s(mt, "stripUndefined");
var pw = /* @__PURE__ */ Symbol.for("functionName");
function Ch(e) {
  if (typeof e == "string") return e;
  let t = e[pw];
  return t || null;
}
s(Ch, "resolveFunctionPath");
var mw = class extends De {
  static {
    s(this, "ZodvexDecodeError");
  }
  functionPath;
  wireData;
  constructor(e, t, n) {
    super(t), this.functionPath = e, this.wireData = n, this.name = "ZodvexDecodeError";
  }
}, Zh = /* @__PURE__ */ new Set();
function gw(e, t) {
  let n = t?.onDecodeError ?? "warn", o = t?.warnWirePreview === !0;
  function r(a, u) {
    if (u == null) return u;
    let c = Ch(a);
    if (c == null) return u;
    let l = e[c];
    return l?.args ? mt(fw(l.args, u)) : (l === void 0 && !Zh.has(c) && (Zh.add(c), console.debug(
      `[zodvex] No registry entry for "${c}" \u2014 args/returns pass through unencoded. This is expected when the target is a raw (non-zodvex) function; if it should be codec-aware, run \`zodvex generate\` to update the registry.`
    )), u);
  }
  s(r, "encodeArgs");
  function i(a, u) {
    let c = Ch(a);
    if (c == null) return u;
    let l = e[c];
    if (!l?.returns) return u;
    let d = wt(l.returns, u);
    if (d.success) return d.data;
    if (n === "throw")
      throw new mw(c, d.error.issues, u);
    let f = d.error.issues.map((m) => `${m.path.join(".")}: ${m.message}`).join(", "), p = `[zodvex] Decode failed for ${c}: ${f}. Returning raw wire data.`;
    if (o) {
      let m = "[unavailable]";
      try {
        m = JSON.stringify(u) ?? "[unavailable]";
      } catch {
      }
      let v = m.length > 200 ? `${m.slice(0, 200)}...` : m;
      p += ` Preview: ${v}`;
    }
    return console.warn(p), u;
  }
  return s(i, "decodeResult"), { encodeArgs: r, decodeResult: i };
}
s(gw, "createBoundaryHelpers");
function Rh(e, t) {
  return async (n, ...o) => {
    let r = t.encodeArgs(n, o[0]), i = await e(n, r);
    return t.decodeResult(n, i);
  };
}
s(Rh, "wrapRun");
function hw(e, t) {
  let n = { ...e };
  return n.runAfter = (o, r, ...i) => {
    let a = t.encodeArgs(r, i[0]);
    return e.runAfter(o, r, ...i.length ? [a] : []);
  }, n.runAt = (o, r, ...i) => {
    let a = t.encodeArgs(r, i[0]);
    return e.runAt(o, r, ...i.length ? [a] : []);
  }, n;
}
s(hw, "wrapScheduler");
function av(e, t, n) {
  let o = gw(e, n), r = {};
  return typeof t.runQuery == "function" && (r.runQuery = Rh(t.runQuery, o)), typeof t.runMutation == "function" && (r.runMutation = Rh(t.runMutation, o)), t.scheduler && (r.scheduler = hw(t.scheduler, o)), r;
}
s(av, "createCodecCallOverrides");
var Fh = /* @__PURE__ */ new WeakMap(), ma = {
  getMetadata: /* @__PURE__ */ s((e) => Fh.get(e), "getMetadata"),
  setMetadata: /* @__PURE__ */ s((e, t) => Fh.set(e, t), "setMetadata")
};
function vw(e) {
  let t = e._zod.def.entries, n = Object.keys(t);
  if (n && Array.isArray(n) && n.length > 0) {
    let o = n.filter((r) => r != null).map((r) => y.literal(r));
    if (o.length === 1) {
      let [r] = o;
      return r;
    } else if (o.length >= 2) {
      let [r, i, ...a] = o;
      return y.union(
        r,
        i,
        ...a
      );
    } else
      return y.any();
  } else
    return y.any();
}
s(vw, "convertEnumType");
function yw(e, t, n) {
  let o = e._zod.def.innerType;
  if (o && o instanceof O)
    if (o instanceof ee) {
      let r = o._zod.def.innerType, i = n(r, t);
      return {
        validator: y.union(i, y.null()),
        isOptional: !0
        // Mark as optional so it gets wrapped later
      };
    } else {
      let r = n(o, t);
      return {
        validator: y.union(r, y.null()),
        isOptional: !1
      };
    }
  else
    return {
      validator: y.any(),
      isOptional: !1
    };
}
s(yw, "convertNullableType");
function $w(e, t, n) {
  let o = e._zod.def.valueType;
  if (o || (o = e._zod.def.keyType), o && o instanceof O)
    if (o instanceof ee || o instanceof _e || o instanceof _e && o._zod.def.innerType instanceof ee) {
      let i, a, u = !1;
      if (o instanceof _e) {
        u = !0, a = o._zod.def.defaultValue;
        let d = o._zod.def.innerType;
        d instanceof ee ? i = d._zod.def.innerType : i = d;
      } else o instanceof ee ? i = o._zod.def.innerType : i = o;
      let c = n(i, t), l = y.union(c, y.null());
      return u && (l._zodDefault = a), y.record(y.string(), l);
    } else
      return y.record(y.string(), n(o, t));
  else
    return y.record(y.string(), y.any());
}
s($w, "convertRecordType");
function bw(e, t, n) {
  let o = e instanceof tt ? e._zod.def.options : (
    // cast: fallback for non-standard discriminated union variants
    e._zod?.def?.options
  );
  if (o) {
    let r = Array.isArray(o) ? o : Array.from(o);
    if (r.length >= 2) {
      let i = r.map((l) => {
        let d = new Set(t);
        return n(l, d);
      }), [a, u, ...c] = i;
      return y.union(
        a,
        u,
        ...c
      );
    } else
      return y.any();
  } else
    return y.any();
}
s(bw, "convertDiscriminatedUnionType");
function _w(e, t, n) {
  let o = e._zod.def.options;
  if (o && Array.isArray(o) && o.length > 0) {
    if (o.length === 1)
      return n(o[0], t);
    {
      let r = o.map((i) => {
        let a = new Set(t);
        return n(i, a);
      });
      if (r.length >= 2) {
        let [i, a, ...u] = r;
        return y.union(
          i,
          a,
          ...u
        );
      } else
        return y.any();
    }
  } else
    return y.any();
}
s(_w, "convertUnionType");
function xw(e) {
  let t = ma.getMetadata(e);
  return t?.isConvexId === !0 && t?.tableName && typeof t.tableName == "string";
}
s(xw, "isZid");
var Lh = /* @__PURE__ */ new WeakMap();
function be(e, t = /* @__PURE__ */ new Set()) {
  if (!e)
    return y.any();
  let n = Lh.get(e);
  if (n)
    return n;
  if (t.has(e))
    return y.any();
  t.add(e);
  let o = e, r = !1, i, a = !1;
  e instanceof _e && (a = !0, i = e._zod.def.defaultValue, o = e._zod.def.innerType), o instanceof ee && (r = !0, o = o._zod.def.innerType, o instanceof _e && (a = !0, i = o._zod.def.defaultValue, o = o._zod.def.innerType));
  let u;
  if (xw(o)) {
    let d = ma.getMetadata(o)?.tableName || "unknown";
    u = y.id(d);
  } else
    switch (o._zod.def.type) {
      case "string":
        u = y.string();
        break;
      case "number":
        u = y.float64();
        break;
      case "bigint":
        u = y.int64();
        break;
      case "boolean":
        u = y.boolean();
        break;
      case "date":
        u = y.float64();
        break;
      case "null":
        u = y.null();
        break;
      case "nan":
        u = y.float64();
        break;
      case "array": {
        if (o instanceof et) {
          let d = o._zod.def.element;
          u = y.array(be(d, t));
        } else
          u = y.array(y.any());
        break;
      }
      case "object": {
        if (o instanceof re) {
          let d = o._zod.def.shape, f = {};
          for (let [p, m] of Object.entries(d))
            m && m instanceof O && (f[p] = be(m, t));
          u = y.object(f);
        } else
          u = y.object({});
        break;
      }
      case "union": {
        o instanceof le ? u = _w(o, t, be) : u = y.any();
        break;
      }
      case "discriminatedUnion": {
        u = bw(
          o,
          t,
          be
        );
        break;
      }
      case "literal": {
        if (o instanceof cr) {
          let f = o._zod.def.values.values().next().value;
          f != null ? u = y.literal(f) : u = y.any();
        } else
          u = y.any();
        break;
      }
      case "enum": {
        o instanceof ur ? u = vw(o) : u = y.any();
        break;
      }
      case "record": {
        o instanceof St ? u = $w(o, t, be) : u = y.record(y.string(), y.any());
        break;
      }
      case "transform":
      case "pipe": {
        if (o instanceof Ae) {
          let d = o._zod.def.in;
          d && d instanceof O ? u = be(d, t) : u = y.any();
        } else {
          let d = ma.getMetadata(o);
          if (d?.brand && d?.originalSchema)
            u = be(d.originalSchema, t);
          else {
            let f = o._zod?.def?.in;
            f && f instanceof O ? u = be(f, t) : u = y.any();
          }
        }
        break;
      }
      case "nullable": {
        if (o instanceof Te) {
          let d = yw(o, t, be);
          u = d.validator, d.isOptional && (r = !0);
        } else
          u = y.any();
        break;
      }
      case "tuple": {
        if (o instanceof rt) {
          let d = o._zod.def.items;
          if (d && d.length > 0) {
            let f = {};
            d.forEach((p, m) => {
              f[`_${m}`] = be(p, t);
            }), u = y.object(f);
          } else
            u = y.object({});
        } else
          u = y.object({});
        break;
      }
      case "lazy": {
        if (o instanceof nt)
          try {
            let d = o._zod.def.getter;
            if (d) {
              let f = d();
              f && f instanceof O ? u = be(f, t) : u = y.any();
            } else
              u = y.any();
          } catch {
            u = y.any();
          }
        else
          u = y.any();
        break;
      }
      case "any":
        u = y.any();
        break;
      case "unknown":
        u = y.any();
        break;
      case "undefined":
      case "void":
      case "never":
        u = y.any();
        break;
      case "intersection":
        u = y.any();
        break;
      case "optional": {
        let d = o._zod?.def?.innerType;
        d && d instanceof O ? (u = be(d, t), r = !0) : (u = y.any(), r = !0);
        break;
      }
      default:
        u = y.any();
        break;
    }
  let c = r || a ? y.optional(u) : u;
  return a && typeof c == "object" && c !== null && (c._zodDefault = i), Lh.set(e, c), c;
}
s(be, "zodToConvexInternal");
function sv(e) {
  return typeof e == "object" && e !== null && !(e instanceof O) ? ga(e) : be(e);
}
s(sv, "zodToConvex");
function ga(e) {
  let t = e instanceof re ? e._zod.def.shape : e, n = {};
  for (let [o, r] of Object.entries(t))
    n[o] = be(r);
  return n;
}
s(ga, "zodToConvexFields");
function Lt(e) {
  if (e instanceof sr) return !0;
  if (e instanceof Ae) return !1;
  if (e instanceof ee || e instanceof Te || e instanceof _e)
    return Lt(e._zod.def.innerType);
  if (e instanceof re)
    return Object.values(e._zod.def.shape).some((t) => Lt(t));
  if (e instanceof et)
    return Lt(e._zod.def.element);
  if (e instanceof le)
    return e._zod.def.options.some((t) => Lt(t));
  if (e instanceof St)
    return Lt(e._zod.def.valueType);
  if (e instanceof rt) {
    let t = e._zod.def.items;
    return t ? t.some((n) => Lt(n)) : !1;
  }
  return !1;
}
s(Lt, "containsNativeZodDate");
function Vh(e, t) {
  if (Lt(e))
    throw new Error(
      `[zodvex] Native z.date() found in ${t}. Convex stores dates as timestamps (numbers), which z.date() cannot parse.

Fix: Replace z.date() with zx.date()

Before: { createdAt: z.date() }
After:  { createdAt: zx.date() }

zx.date() is a codec that handles timestamp \u2194 Date conversion automatically.`
    );
}
s(Vh, "assertNoNativeZodDate");
function uv(e, t) {
  return Qe(e, t);
}
s(uv, "decodeDoc");
function Mh(e, t) {
  return mt(Ne(e, t));
}
s(Mh, "encodeDoc");
function Bh(e) {
  let t = {};
  for (let [n, o] of Object.entries(e))
    t[n] = o === void 0 ? void 0 : mt(o);
  return t;
}
s(Bh, "stripUndefinedPreservingTopLevel");
function ww(e, t) {
  if (!(e instanceof re)) {
    let a = Ne(e, t);
    return a !== null && typeof a == "object" && !Array.isArray(a) ? Bh(a) : mt(a);
  }
  let n = e._zod.def.shape, o = {};
  for (let [a, u] of Object.entries(n))
    o[a] = u instanceof ee ? u : new ee({ type: "optional", innerType: u });
  let r = S.object(o), i = Ne(r, t);
  return Bh(i);
}
s(ww, "encodePartialDoc");
function cv(e, t, n) {
  return S.codec(e, t, n);
}
s(cv, "zodvexCodec");
function lp(e, t, n) {
  if (t.includes(".")) return n;
  if (e instanceof re) {
    let o = e.shape[t];
    if (o) return Ne(o, n);
  }
  if (e instanceof le) {
    let r = e._zod.def.options.filter((i) => i instanceof re).map((i) => i.shape[t]).filter(Boolean);
    if (r.length === 1) return Ne(r[0], n);
    if (r.length > 1)
      return Ne(S.union(r), n);
  }
  return n;
}
s(lp, "encodeIndexValue");
function ha(e, t) {
  return new Proxy(e, {
    get(n, o, r) {
      return typeof o == "string" && ["eq", "gt", "gte", "lt", "lte"].includes(o) ? (i, a) => {
        let u = lp(t, i, a), c = n[o](i, u);
        return ha(c, t);
      } : o === "search" ? (...i) => {
        let a = n.search(...i);
        return ha(a, t);
      } : Reflect.get(n, o, r);
    }
  });
}
s(ha, "wrapIndexRangeBuilder");
function dp(e, t) {
  return e != null && Object.prototype.isPrototypeOf.call(t, e);
}
s(dp, "isFilterExpression");
function Jh(e, t) {
  if (dp(e, t)) {
    let n = e.serialize();
    if (n && typeof n == "object" && "$field" in n)
      return n.$field;
  }
  return null;
}
s(Jh, "extractFieldPath");
function kw(e, t) {
  let n = Object.getPrototypeOf(e.field("_id"));
  return new Proxy(e, {
    get(o, r, i) {
      return typeof r == "string" && ["eq", "neq", "lt", "lte", "gt", "gte"].includes(r) ? (a, u) => {
        let c = Jh(a, n), l = Jh(u, n);
        return c && !dp(u, n) ? u = lp(t, c, u) : l && !dp(a, n) && (a = lp(t, l, a)), o[r](a, u);
      } : Reflect.get(o, r, i);
    }
  });
}
s(kw, "wrapFilterBuilder");
var hp = class lv {
  static {
    s(this, "_ZodvexQueryChain");
  }
  constructor(t, n) {
    this.inner = t, this.schema = n;
  }
  /** Factory method for intermediate methods. Subclasses override to return their own type. */
  createChain(t) {
    return new lv(t, this.schema);
  }
  /** Decode a wire-format doc and cast to the decoded document type. */
  decode(t) {
    return uv(this.schema, t);
  }
  // --- Intermediate methods: wire-typed TableInfo for Convex machinery ---
  fullTableScan() {
    return this.createChain(this.inner.fullTableScan());
  }
  withIndex(t, n) {
    let o = n ? (r) => n(ha(r, this.schema)) : void 0;
    return this.createChain(this.inner.withIndex(t, o));
  }
  withSearchIndex(t, n) {
    let o = /* @__PURE__ */ s((r) => n(ha(r, this.schema)), "wrappedFilter");
    return this.createChain(this.inner.withSearchIndex(t, o));
  }
  order(t) {
    return this.createChain(this.inner.order(t));
  }
  // Implementation
  filter(t) {
    let n = /* @__PURE__ */ s((o) => t(kw(o, this.schema)), "wrappedPredicate");
    return this.createChain(this.inner.filter(n));
  }
  limit(t) {
    return this.createChain(this.inner.limit(t));
  }
  count() {
    return this.inner.count();
  }
  // --- Terminal methods: return decoded Doc type ---
  async first() {
    let t = await this.inner.first();
    return t ? this.decode(t) : null;
  }
  async unique() {
    let t = await this.inner.unique();
    return t ? this.decode(t) : null;
  }
  async collect() {
    return (await this.inner.collect()).map((n) => this.decode(n));
  }
  async take(t) {
    return (await this.inner.take(t)).map((o) => this.decode(o));
  }
  async paginate(t) {
    let n = await this.inner.paginate(t);
    return {
      ...n,
      page: n.page.map((o) => this.decode(o))
    };
  }
  // --- AsyncIterable: decode each yielded document ---
  async *[Symbol.asyncIterator]() {
    for await (let t of this.inner)
      yield this.decode(t);
  }
};
function fp(e, t, n) {
  for (let o of Object.keys(t))
    if (e.normalizeId(o, n))
      return o;
  return null;
}
s(fp, "resolveTableName");
var ya = class {
  static {
    s(this, "ZodvexDatabaseReader");
  }
  constructor(e, t) {
    this.db = e, this.tableMap = t, this.system = e.system;
  }
  system;
  /** @internal Expose for wrapper construction (rule/audit subclasses) */
  get _internals() {
    return { db: this.db, tableMap: this.tableMap };
  }
  /**
   * Escape hatch (#85/#92): returns the database this codec wrapper delegates
   * to — the composed underlying stack when `underlyingDb` is configured (e.g.
   * a trigger-wrapped writer), the bare Convex db otherwise.
   *
   * The returned db is native-shape: reads are undecoded wire documents and it
   * bypasses codec, `.withRules()`, and `.audit()` layers entirely.
   */
  unwrap() {
    return this.db;
  }
  normalizeId(e, t) {
    return this.db.normalizeId(e, t);
  }
  async get(e, t) {
    let n, o;
    if (t !== void 0 ? (n = e, o = await this.db.get(e, t)) : (o = await this.db.get(e), n = o ? fp(this.db, this.tableMap, e) : null), !o) return null;
    let r = n ? this.tableMap[n] : void 0;
    return r ? uv(r.doc, o) : o;
  }
  query(e) {
    let t = this.tableMap[e], n = this.db.query(e);
    return t ? new hp(n, t.doc) : n;
  }
  /**
   * Returns a new ZodvexDatabaseReader that applies per-table read rules.
   * The returned reader is also a ZodvexDatabaseReader, so `.withRules()` can be chained.
   */
  withRules(e, t, n) {
    return new fv(this, e, t, n ?? {});
  }
  /**
   * Returns a new ZodvexDatabaseReader that fires audit callbacks on reads.
   * The returned reader is also a ZodvexDatabaseReader, so `.audit()` can be chained
   * with `.withRules()`.
   */
  audit(e) {
    return new mv(this, e);
  }
}, vp = class extends ya {
  static {
    s(this, "ZodvexDatabaseWriter");
  }
  // Narrows the inherited `protected db` to the writer-typed view without
  // shadowing the underlying instance. Used by the write methods below.
  get writerDb() {
    return this.db;
  }
  constructor(e, t) {
    super(e, t), this.system = e.system;
  }
  /**
   * @internal Expose writer-typed internals for rules / audit subclasses.
   * Includes a `reader` field that aliases `this` (writer IS-A reader after
   * the #64 refactor) so callers expecting `_internals.reader` still work.
   */
  get _internals() {
    return { db: this.writerDb, tableMap: this.tableMap, reader: this };
  }
  /**
   * Escape hatch (#85/#92): returns the writer this codec wrapper delegates
   * to — the composed underlying stack when `underlyingDb` is configured (e.g.
   * a trigger-wrapped writer), the bare Convex db otherwise.
   *
   * The returned db is native-shape: writes must be wire-format and it
   * bypasses codec, `.withRules()`, and `.audit()` layers entirely.
   */
  unwrap() {
    return this.writerDb;
  }
  async insert(e, t) {
    let n = this.tableMap[e], o = n ? Mh(n.insert, t) : t;
    return this.writerDb.insert(e, o);
  }
  async patch(e, t, n) {
    let o, r, i;
    n !== void 0 ? (o = e, r = t, i = n) : (r = e, i = t, o = fp(this.db, this.tableMap, r));
    let a = o ? this.tableMap[o] : void 0, u = a ? ww(a.insert, i) : i;
    return n !== void 0 ? this.writerDb.patch(e, r, u) : this.writerDb.patch(r, u);
  }
  async replace(e, t, n) {
    let o, r, i;
    n !== void 0 ? (o = e, r = t, i = n) : (r = e, i = t, o = fp(this.db, this.tableMap, r));
    let a = o ? this.tableMap[o] : void 0, u = a ? Mh(a.insert, i) : i;
    return n !== void 0 ? this.writerDb.replace(e, r, u) : this.writerDb.replace(r, u);
  }
  async delete(e, t) {
    return t !== void 0 ? this.writerDb.delete(e, t) : this.writerDb.delete(e);
  }
  /**
   * Returns a new ZodvexDatabaseWriter that applies per-table read and write rules.
   * The returned writer is also a ZodvexDatabaseWriter, so `.withRules()` can be chained.
   *
   * Overrides Reader's signature so a writer chained call returns a writer.
   */
  withRules(e, t, n) {
    return new zw(this, e, t, n ?? {});
  }
  /**
   * Returns a new ZodvexDatabaseWriter that fires audit callbacks on reads and writes.
   * The returned writer is also a ZodvexDatabaseWriter, so `.audit()` can be chained
   * with `.withRules()`.
   *
   * Overrides Reader's signature so a writer chained call returns a writer.
   */
  audit(e) {
    return new Ow(this, e);
  }
};
function da(e, t) {
  return e === !0 ? t : e === !1 ? null : e;
}
s(da, "normalizeReadResult");
var Iw = class dv extends hp {
  static {
    s(this, "_RulesQueryChain");
  }
  readRule;
  rulesConfig;
  ctx;
  constructor(t, n, o, r, i = {}) {
    super(t, n), this.readRule = o, this.rulesConfig = r, this.ctx = i;
  }
  createChain(t) {
    return new dv(t, this.schema, this.readRule, this.rulesConfig, this.ctx);
  }
  async first() {
    for await (let t of this)
      return t;
    return null;
  }
  async unique() {
    let t = await super.unique();
    return t === null ? null : da(await this.readRule(this.ctx, t), t);
  }
  async collect() {
    let t = [];
    for await (let n of this)
      t.push(n);
    return t;
  }
  async take(t) {
    if (!Number.isInteger(t) || t < 0)
      throw new Error("take requires a non-negative integer");
    let n = [];
    if (t === 0) return n;
    for await (let o of this)
      if (n.push(o), n.length >= t) break;
    return n;
  }
  async paginate(t) {
    let n = await super.paginate(t), o = [];
    for (let r of n.page) {
      let i = da(await this.readRule(this.ctx, r), r);
      i !== null && o.push(i);
    }
    return { ...n, page: o };
  }
  async count() {
    if (!this.rulesConfig.allowCounting)
      throw new Error("count is not allowed with rules");
    return super.count();
  }
  async *[Symbol.asyncIterator]() {
    for await (let t of super[Symbol.asyncIterator]()) {
      let n = da(await this.readRule(this.ctx, t), t);
      n !== null && (yield n);
    }
  }
};
function fa(e, t, n, o) {
  for (let r of Object.keys(n))
    if (e.normalizeId(r, t))
      return r;
  if ((o.defaultPolicy ?? "allow") === "deny") {
    for (let r of Object.keys(e._internals.tableMap))
      if (e.normalizeId(r, t))
        return r;
  }
  return null;
}
s(fa, "resolveRulesTableName");
var fv = class extends ya {
  static {
    s(this, "RulesDatabaseReader");
  }
  constructor(e, t, n, o) {
    let { db: r, tableMap: i } = e._internals;
    super(r, i), this.inner = e, this.ctx = t, this.rules = n, this.rulesConfig = o, this.system = e.system;
  }
  async get(e, t) {
    let n = await this.inner.get(e, t);
    if (n === null) return null;
    let o = t !== void 0 ? e : fa(this.inner, e, this.rules, this.rulesConfig);
    return o ? this.applyReadRule(o, n) : n;
  }
  query(e) {
    let t = this.rules[e];
    if (!t?.read && (this.rulesConfig.defaultPolicy ?? "allow") === "allow")
      return this.inner.query(e);
    let n = this.inner.query(e), o = t?.read ?? (async () => null), r = S.any();
    return new Iw(n, r, o, this.rulesConfig, this.ctx);
  }
  async applyReadRule(e, t) {
    let n = this.rules[e];
    if (!n?.read)
      return (this.rulesConfig.defaultPolicy ?? "allow") === "deny" ? null : t;
    let o = await n.read(this.ctx, t);
    return da(o, t);
  }
}, zw = class extends vp {
  static {
    s(this, "RulesDatabaseWriter");
  }
  constructor(e, t, n, o) {
    let { db: r, tableMap: i, reader: a } = e._internals;
    super(r, i), this.inner = e, this.ctx = t, this.rules = n, this.rulesConfig = o, this.rulesReader = new fv(a, t, n, o), this.system = e.system;
  }
  rulesReader;
  normalizeId(e, t) {
    return this.rulesReader.normalizeId(e, t);
  }
  async get(e, t) {
    return this.rulesReader.get(e, t);
  }
  query(e) {
    return this.rulesReader.query(e);
  }
  async insert(e, t) {
    let n = e, o = this.rules[n];
    if (o?.insert) {
      let r = await o.insert(this.ctx, t);
      return this.inner.insert(
        e,
        r
      );
    }
    if ((this.rulesConfig.defaultPolicy ?? "allow") === "deny")
      throw new Error(`insert not allowed on ${n}`);
    return this.inner.insert(e, t);
  }
  async patch(e, t, n) {
    let o, r;
    n !== void 0 ? (o = t, r = n) : (o = e, r = t);
    let i = await this.rulesReader.get(o);
    if (i === null)
      throw new Error("no read access or doc does not exist");
    let a = fa(this.inner, o, this.rules, this.rulesConfig), u = a ? this.rules[a] : void 0;
    if (u?.patch) {
      let c = await u.patch(this.ctx, i, r);
      return this.inner.patch(
        o,
        c
      );
    }
    if ((this.rulesConfig.defaultPolicy ?? "allow") === "deny")
      throw new Error(`patch not allowed on ${a}`);
    return this.inner.patch(o, r);
  }
  async replace(e, t, n) {
    let o, r;
    n !== void 0 ? (o = t, r = n) : (o = e, r = t);
    let i = await this.rulesReader.get(o);
    if (i === null)
      throw new Error("no read access or doc does not exist");
    let a = fa(this.inner, o, this.rules, this.rulesConfig), u = a ? this.rules[a] : void 0;
    if (u?.replace) {
      let c = await u.replace(this.ctx, i, r);
      return this.inner.replace(o, c);
    }
    if ((this.rulesConfig.defaultPolicy ?? "allow") === "deny")
      throw new Error(`replace not allowed on ${a}`);
    return this.inner.replace(o, r);
  }
  async delete(e, t) {
    let n;
    t !== void 0 ? n = t : n = e;
    let o = await this.rulesReader.get(n);
    if (o === null)
      throw new Error("no read access or doc does not exist");
    let r = fa(this.inner, n, this.rules, this.rulesConfig), i = r ? this.rules[r] : void 0;
    if (i?.delete)
      return await i.delete(this.ctx, o), this.inner.delete(n);
    if ((this.rulesConfig.defaultPolicy ?? "allow") === "deny")
      throw new Error(`delete not allowed on ${r}`);
    return this.inner.delete(n);
  }
}, Sw = class pv extends hp {
  static {
    s(this, "_AuditQueryChain");
  }
  afterRead;
  tableName;
  constructor(t, n, o, r) {
    super(t, n), this.afterRead = o, this.tableName = r;
  }
  createChain(t) {
    return new pv(t, this.schema, this.afterRead, this.tableName);
  }
  async first() {
    let t = await super.first();
    return t !== null && await this.afterRead(this.tableName, t), t;
  }
  async unique() {
    let t = await super.unique();
    return t !== null && await this.afterRead(this.tableName, t), t;
  }
  async collect() {
    let t = await super.collect();
    for (let n of t)
      await this.afterRead(this.tableName, n);
    return t;
  }
  async take(t) {
    let n = await super.take(t);
    for (let o of n)
      await this.afterRead(this.tableName, o);
    return n;
  }
  async paginate(t) {
    let n = await super.paginate(t);
    for (let o of n.page)
      await this.afterRead(this.tableName, o);
    return n;
  }
  async *[Symbol.asyncIterator]() {
    for await (let t of super[Symbol.asyncIterator]())
      await this.afterRead(this.tableName, t), yield t;
  }
}, mv = class extends ya {
  static {
    s(this, "AuditDatabaseReader");
  }
  inner;
  afterRead;
  constructor(e, t) {
    let { db: n, tableMap: o } = e._internals;
    super(n, o), this.inner = e, this.afterRead = t.afterRead ?? (() => {
    }), this.system = e.system;
  }
  async get(e, t) {
    let n = await this.inner.get(e, t);
    if (n !== null) {
      let o = this.resolveTableFromId(
        t !== void 0 ? t : e,
        t !== void 0 ? e : void 0
      );
      o && await this.afterRead(o, n);
    }
    return n;
  }
  query(e) {
    let t = this.inner.query(e), n = S.any();
    return new Sw(t, n, this.afterRead, e);
  }
  resolveTableFromId(e, t) {
    if (t) return t;
    for (let n of Object.keys(this.tableMap))
      if (this.inner.normalizeId(n, e))
        return n;
    return null;
  }
}, Ow = class extends vp {
  static {
    s(this, "AuditDatabaseWriter");
  }
  inner;
  auditReader;
  afterWrite;
  constructor(e, t) {
    let { db: n, tableMap: o, reader: r } = e._internals;
    super(n, o), this.inner = e, this.afterWrite = t.afterWrite, this.auditReader = t.afterRead ? new mv(r, { afterRead: t.afterRead }) : r, this.system = e.system;
  }
  normalizeId(e, t) {
    return this.auditReader.normalizeId(e, t);
  }
  async get(e, t) {
    return this.auditReader.get(e, t);
  }
  query(e) {
    return this.auditReader.query(e);
  }
  async insert(e, t) {
    let n = await this.inner.insert(e, t);
    return this.afterWrite && await this.afterWrite(e, { type: "insert", id: n, value: t }), n;
  }
  async patch(e, t, n) {
    let o, r;
    n !== void 0 ? (o = t, r = n) : (o = e, r = t);
    let i = await this.inner.get(o);
    if (n !== void 0 ? await this.inner.patch(e, t, n) : await this.inner.patch(o, r), this.afterWrite) {
      let a = this.resolveTableFromId(o);
      a && await this.afterWrite(a, { type: "patch", id: o, doc: i, value: r });
    }
  }
  async replace(e, t, n) {
    let o, r;
    n !== void 0 ? (o = t, r = n) : (o = e, r = t);
    let i = await this.inner.get(o);
    if (n !== void 0 ? await this.inner.replace(e, t, n) : await this.inner.replace(o, r), this.afterWrite) {
      let a = this.resolveTableFromId(o);
      a && await this.afterWrite(a, { type: "replace", id: o, doc: i, value: r });
    }
  }
  async delete(e, t) {
    let n;
    t !== void 0 ? n = t : n = e;
    let o = await this.inner.get(n);
    if (t !== void 0 ? await this.inner.delete(e, t) : await this.inner.delete(n), this.afterWrite) {
      let r = this.resolveTableFromId(n);
      r && await this.afterWrite(r, { type: "delete", id: n, doc: o });
    }
  }
  resolveTableFromId(e) {
    for (let t of Object.keys(this.inner._internals.tableMap))
      if (this.inner.normalizeId(t, e))
        return t;
    return null;
  }
};
function jw(e, t) {
  let n = t?.underlyingDb?.query, o = t?.underlyingDb?.mutation;
  return {
    query: {
      args: {},
      input: /* @__PURE__ */ s(async (r, i, a) => ({
        ctx: {
          db: new ya(n ? n(r) : r.db, e)
        },
        args: {}
      }), "input")
    },
    mutation: {
      args: {},
      input: /* @__PURE__ */ s(async (r, i, a) => ({
        ctx: {
          db: new vp(o ? o(r) : r.db, e)
        },
        args: {}
      }), "input")
    }
  };
}
s(jw, "createZodvexCustomization");
function gv(e, t) {
  let n = {};
  for (let o of t)
    o in e && (n[o] = e[o]);
  return n;
}
s(gv, "pick");
var hv = "__zodvexMeta";
function Pw(e, t) {
  Object.defineProperty(e, hv, {
    value: t,
    enumerable: !1,
    writable: !1,
    configurable: !1
  });
}
s(Pw, "attachMeta");
function vv(e) {
  if (!(e == null || typeof e != "object" && typeof e != "function"))
    return e[hv];
}
s(vv, "readMeta");
var Dw = "__zodvexCodecBrand";
function Nw(e, t) {
  Object.defineProperty(e, Dw, {
    value: t,
    enumerable: !1,
    writable: !1,
    configurable: !1
  });
}
s(Nw, "attachCodecBrand");
function Tw(e, t) {
  return {
    error: "ZodValidationError",
    context: t,
    issues: e.issues.map((n) => ({
      path: Array.isArray(n.path) ? n.path.join(".") : String(n.path ?? ""),
      code: n.code,
      message: n.message
    })),
    // Keep a flattened snapshot for easier debugging without cyclic refs
    flatten: JSON.parse(JSON.stringify(e.flatten?.() ?? {}))
  };
}
s(Tw, "formatZodIssues");
function pp(e, t) {
  throw e instanceof De ? new Mt(Tw(e, t)) : e;
}
s(pp, "handleZodValidationError");
function Aw(e, t) {
  try {
    return Ne(e, t);
  } catch (n) {
    if (n?.message?.includes("unidirectional transform"))
      try {
        return Qe(e, t);
      } catch (o) {
        pp(o, "returns");
      }
    pp(n, "returns");
  }
  throw new Error("Unreachable");
}
s(Aw, "validateReturns");
function yv(e) {
  if (e)
    return e instanceof O ? e : S.object(e);
}
s(yv, "normalizeFunctionSchema");
function Uw(e) {
  if (e) {
    if (e instanceof re)
      return e;
    if (!(e instanceof O))
      return S.object(e);
  }
}
s(Uw, "normalizeFunctionMetaArgs");
function qh(e, t, n) {
  Pw(e, {
    type: "function",
    zodArgs: Uw(t),
    zodReturns: yv(n)
  });
}
s(qh, "attachFunctionMeta");
var Wh = /* @__PURE__ */ new WeakMap();
function Cn(e, t = 50, n = 0) {
  let o = Wh.get(e);
  if (o !== void 0)
    return o;
  if (n > t)
    return !1;
  let r = !1;
  return e instanceof sn ? r = !0 : e instanceof le ? r = e._zod.def.options.some((i) => Cn(i, t, n + 1)) : (e instanceof ee || e instanceof Te || e instanceof _e) && (r = Cn(e._zod.def.innerType, t, n + 1)), Wh.set(e, r), r;
}
s(Cn, "containsCustom");
function Ew(e) {
  if (e instanceof O) {
    if (e instanceof re)
      return {
        argsSchema: e,
        argsValidator: e._zod.def.shape
      };
    throw new Error(
      "Unsupported non-object Zod schema for args; please provide an args schema using z.object({...}), e.g. z.object({ foo: z.string() })"
    );
  }
  return {
    argsValidator: e,
    argsSchema: S.object(e)
  };
}
s(Ew, "normalizeCustomArgsValidator");
function Cw(e, t) {
  if (!(!e || t?.skipConvexValidation) && !(t?.skipCustomSchemas && Cn(e)))
    return sv(e);
}
s(Cw, "createConvexReturnsValidator");
function $v(e, t) {
  let n = wt(e, t);
  return n.success || pp(n.error, "args"), n.data;
}
s($v, "parseObjectArgsOrThrow");
async function Kh(e, t, n, o, r, i) {
  let a = gv(n, Object.keys(o)), u = i ? $v(i, a) : a;
  return await e(t, u, r);
}
s(Kh, "runCustomizationInput");
function Gh(e, t, n) {
  let o = { ...e, ...n?.ctx ?? {} }, r = n?.args ?? {};
  return {
    finalCtx: o,
    finalArgs: { ...t, ...r }
  };
}
s(Gh, "applyCustomizationResult");
async function Xh(e, t) {
  if (t?.added?.onSuccess && await t.added.onSuccess({
    ctx: t.ctx,
    args: t.args,
    result: e
  }), t?.returns) {
    let n = Aw(t.returns, e);
    return mt(n);
  }
  return mt(e);
}
s(Xh, "finalizeFunctionReturn");
function yp(e, t) {
  let n = t.input ?? la.input, o = t.args ?? la.args, r = Object.entries(o), i = r.length > 0 && r.every(([, c]) => c instanceof O), a = i ? ga(o) : o, u = i ? S.object(o) : void 0;
  return /* @__PURE__ */ s(function(l) {
    let { args: d, handler: f = l, returns: p, ...m } = l, v = l.skipConvexValidation ?? !1, x = yv(p), k = Cw(x, { skipConvexValidation: v }), R = k ? { returns: k } : void 0;
    if (x && Vh(x, "returns"), d) {
      let { argsValidator: P, argsSchema: U } = Ew(d), V = v ? a : { ...ga(P), ...a };
      Vh(U, "args");
      let I = e({
        args: V,
        ...R,
        handler: /* @__PURE__ */ s(async (W, Me) => {
          let gt = await Kh(
            n,
            W,
            Me,
            a,
            m,
            u
          ), Zn = Object.keys(P), ba = gv(Me, Zn), Rn = $v(U, ba), { finalCtx: Ov, finalArgs: jv } = Gh(W, Rn, gt), Pv = await f(Ov, jv);
          return Xh(Pv, { ctx: W, args: Rn, added: gt, returns: x });
        }, "handler")
      }), T = u ? S.object({
        ...U._zod.def.shape,
        ...u._zod.def.shape
      }) : U;
      return qh(I, T, x), I;
    }
    let j = e({
      args: a,
      ...R,
      handler: /* @__PURE__ */ s(async (P, U) => {
        let V = U, I = await Kh(
          n,
          P,
          U,
          a,
          m,
          u
        ), { finalCtx: T, finalArgs: W } = Gh(P, V, I), Me = await f(T, W);
        return Xh(Me, { ctx: P, args: V, added: I, returns: x });
      }, "handler")
    });
    return qh(j, u ?? void 0, x), j;
  }, "customBuilder");
}
s(yp, "customFnBuilder");
function Hh(e, t) {
  return yp(e, t);
}
s(Hh, "zCustomQuery");
function Qh(e, t) {
  return yp(
    e,
    t
  );
}
s(Qh, "zCustomMutation");
function Yh(e, t) {
  return yp(
    e,
    t
  );
}
s(Yh, "zCustomAction");
function bv(e, t, n) {
  let o = n?.wrapDb !== !1;
  if (!o && n?.underlyingDb)
    throw new Error(
      "[zodvex] initZodvex: `underlyingDb` requires the codec db wrapper \u2014 remove `wrapDb: false` or drop `underlyingDb`."
    );
  let r = jw(e.__zodTableMap, {
    underlyingDb: n?.underlyingDb
  }), i = Zw(), a = n?.registry, u = Rw(a, i), c = {
    query: o ? r.query : i,
    mutation: Fw(o ? r.mutation : i, a),
    action: u
  };
  return {
    zq: Tr(t.query, c.query, Hh),
    zm: Tr(t.mutation, c.mutation, Qh),
    za: Tr(t.action, c.action, Yh),
    ziq: Tr(t.internalQuery, c.query, Hh),
    zim: Tr(t.internalMutation, c.mutation, Qh),
    zia: Tr(t.internalAction, c.action, Yh)
  };
}
s(bv, "initZodvex");
function Zw() {
  return { args: {}, input: la.input };
}
s(Zw, "createNoOpCustomization");
function Rw(e, t) {
  return e ? {
    args: {},
    input: /* @__PURE__ */ s(async (n) => ({
      // Auto-encode codec args at outbound call sites: runQuery/runMutation
      // (encode args, decode result) and scheduler.runAfter/runAt (encode args).
      ctx: av(e(), n),
      args: {}
    }), "input")
  } : t;
}
s(Rw, "createActionCustomization");
function Fw(e, t) {
  return t ? {
    args: {},
    input: /* @__PURE__ */ s(async (n, o, r) => {
      let i = await e.input(n, {}, r), a = av(t(), n);
      return {
        ctx: { ...i.ctx, ...a },
        args: {}
      };
    }, "input")
  } : e;
}
s(Fw, "createMutationCustomization");
function Lw(e, t) {
  return {
    args: t.args ?? {},
    input: /* @__PURE__ */ s(async (n, o, r) => {
      let i = await e.input(n, {}, r), a = { ...n, ...i.ctx };
      if (!t.input)
        return { ctx: i.ctx, args: {} };
      let u = await t.input(a, o, r);
      return {
        ctx: { ...i.ctx, ...u.ctx ?? {} },
        args: u.args ?? {},
        ...u.onSuccess && { onSuccess: u.onSuccess }
      };
    }, "input")
  };
}
s(Lw, "composeCustomizations");
function Tr(e, t, n) {
  let o = n(e, t);
  return o.withContext = (r) => {
    let i = Lw(t, r);
    return n(e, i);
  }, o;
}
s(Tr, "createZodvexBuilder");
function va(e) {
  let t = S.string().check(
    S.refine((o) => typeof o == "string" && o.length > 0, {
      message: `Invalid ID for table "${e}"`
    }),
    S.describe(`convexId:${e}`)
  );
  ma.setMetadata(t, {
    isConvexId: !0,
    tableName: e
  });
  let n = t;
  return n._tableName = e, n;
}
s(va, "id");
function _v(e) {
  return e instanceof le || e instanceof tt;
}
s(_v, "isZodUnion");
function xv(e) {
  return e instanceof le, e._zod.def.options;
}
s(xv, "getUnionOptions");
function Vw(e) {
  if (e.length < 2)
    throw new Error(
      `z.union() requires at least 2 options, but received ${e.length}. This indicates an invalid union schema was passed to zodTable().`
    );
}
s(Vw, "assertUnionOptions");
function wv(e) {
  return Vw(e), S.union(e);
}
s(wv, "createUnionFromOptions");
function Mw(e, t) {
  if (_v(t)) {
    let o = xv(t).map((r) => {
      if (r instanceof re) {
        let i = {
          ...r._zod.def.shape,
          _id: va(e),
          _creationTime: S.number()
        };
        return C(r, { ...r._zod.def, shape: i });
      }
      return r;
    });
    return wv(o);
  }
  if (t instanceof re) {
    let n = { ...t._zod.def.shape, _id: va(e), _creationTime: S.number() };
    return C(t, { ...t._zod.def, shape: n });
  }
  return t;
}
s(Mw, "addSystemFields");
function Bw(e) {
  return e instanceof ee ? e : new ee({ type: "optional", innerType: e });
}
s(Bw, "ensureOptional");
function Jw(e) {
  let t = {};
  for (let [n, o] of Object.entries(e))
    t[n] = Bw(o);
  return t;
}
s(Jw, "createPartialShape");
function ev(e, t) {
  return S.object({
    _id: va(e),
    _creationTime: S.optional(S.number()),
    ...Jw(t)
  });
}
s(ev, "createUpdateObjectSchema");
function qw(e, t) {
  if (_v(t)) {
    let n = xv(t).map((o) => o instanceof re ? ev(e, o._zod.def.shape) : o);
    return wv(n);
  }
  return t instanceof re ? ev(e, t._zod.def.shape) : t;
}
s(qw, "createSchemaUpdateSchema");
var tv = /* @__PURE__ */ Symbol.for("zodvex.zxDate");
function Ww(e) {
  e[tv] = !0;
  let t = e._zod?.def;
  return t && (t[tv] = !0), e;
}
s(Ww, "brandZxDate");
function Kw() {
  return Ww(
    cv(
      S.number(),
      // Wire: timestamp
      S.custom((e) => e instanceof Date, {
        message: "Expected Date instance"
      }),
      {
        decode: /* @__PURE__ */ s((e) => new Date(e), "decode"),
        encode: /* @__PURE__ */ s((e) => e.getTime(), "encode")
      }
    )
  );
}
s(Kw, "date");
function Gw(e, t, n, o) {
  let r = cv(e, t, n);
  return o?.brand && Nw(r, o.brand), r;
}
s(Gw, "codec");
function $a(e) {
  let t = /* @__PURE__ */ Symbol.for(`zodvex.zx.cache.${e}`), n = globalThis, o = n[t];
  if (o) return o;
  let r = /* @__PURE__ */ new WeakMap();
  return n[t] = r, r;
}
s($a, "sharedWeakMap");
var rv = $a("base"), nv = $a("doc"), iv = $a("update"), ov = $a("docArray");
function $p(e) {
  let t = e.schema;
  return t instanceof O ? t : e.fields;
}
s($p, "slimCacheKey");
function bp(e) {
  let t = e.schema;
  if (t?.base instanceof O) return t.base;
  if (t instanceof O) return t;
  let n = rv.get(e.fields);
  if (n) return n;
  if (Object.keys(e.fields).length === 0)
    throw new Error(`[zodvex] Cannot derive base schema for model '${e.name}'`);
  let o = S.object(e.fields);
  return rv.set(e.fields, o), o;
}
s(bp, "base");
function kv(e) {
  let t = e.schema;
  if (t?.doc instanceof O) return t.doc;
  let n = $p(e), o = nv.get(n);
  if (o) return o;
  let r = Mw(e.name, bp(e));
  return nv.set(n, r), r;
}
s(kv, "doc");
function Xw(e) {
  let t = e.schema;
  if (t?.update instanceof O) return t.update;
  let n = $p(e), o = iv.get(n);
  if (o) return o;
  let r = qw(e.name, bp(e));
  return iv.set(n, r), r;
}
s(Xw, "update");
function Hw(e) {
  let t = e.schema;
  if (t?.docArray instanceof O) return t.docArray;
  let n = $p(e), o = ov.get(n);
  if (o) return o;
  let r = S.array(kv(e));
  return ov.set(n, r), r;
}
s(Hw, "docArray");
function Iv(e) {
  return new Te({ type: "nullable", innerType: e });
}
s(Iv, "nullable");
function pa(e) {
  return new ee({ type: "optional", innerType: e });
}
s(pa, "optional");
function mp(e) {
  return pa(Iv(e));
}
s(mp, "nullableOptional2");
function Qw() {
  return S.object({
    numItems: S.number(),
    cursor: Iv(S.string()),
    endCursor: mp(S.string()),
    id: pa(S.number()),
    maximumRowsRead: pa(S.number()),
    maximumBytesRead: pa(S.number())
  });
}
s(Qw, "paginationOpts");
function Yw(e) {
  return S.object({
    page: S.array(e),
    isDone: S.boolean(),
    continueCursor: S.string(),
    splitCursor: mp(S.string()),
    pageStatus: mp(S.enum(["SplitRecommended", "SplitRequired"]))
  });
}
s(Yw, "paginationResult");
var gp = {
  /**
   * Date ↔ timestamp codec
   * @see {@link date}
   */
  date: Kw,
  /**
   * Convex ID validator
   * @see {@link id}
   */
  id: va,
  /**
   * Custom codec builder
   * @see {@link codec}
   */
  codec: Gw,
  /**
   * Pagination options schema matching Convex's PaginationOptions type
   * @see {@link paginationOpts}
   */
  paginationOpts: Qw,
  /**
   * Paginated result schema wrapping any item schema in Convex's PaginationResult shape
   * @see {@link paginationResult}
   */
  paginationResult: Yw,
  /**
   * Base schema for a model (user fields only; no system fields).
   * For object models reconstructs from fields; for union models returns the
   * user-supplied union. Cached per-model.
   * @see {@link base}
   */
  base: bp,
  /**
   * Doc schema: model fields + _id + _creationTime
   * @see {@link doc}
   */
  doc: kv,
  /**
   * Update schema: _id required, all other fields optional
   * @see {@link update}
   */
  update: Xw,
  /**
   * Doc array schema: z.array(doc(model))
   * @see {@link docArray}
   */
  docArray: Hw
};
function ek(e) {
  return vv(e)?.type === "model";
}
s(ek, "isZodModelEntry");
function zv(e) {
  let t = vv(e);
  if (!t || t.type !== "model")
    throw new Error(`Model '${e.name}' is missing zodvex model metadata.`);
  return t;
}
s(zv, "getZodModelMeta");
function tk(e) {
  let t = zv(e), o = t.definitionSource === "schema" || t.definitionSource == null && Object.keys(e.fields).length === 0 ? $t(sv(gp.base(e))) : $t(ga(e.fields));
  for (let [r, i] of Object.entries(e.indexes)) {
    let a = i.filter((u) => u !== "_creationTime");
    o = o.index(r, a);
  }
  for (let [r, i] of Object.entries(e.searchIndexes))
    o = o.searchIndex(r, i);
  for (let [r, i] of Object.entries(e.vectorIndexes))
    o = o.vectorIndex(r, i);
  return o;
}
s(tk, "tableFromModel");
function Sv(e) {
  let t = {}, n = {};
  for (let [i, a] of Object.entries(e))
    if (ek(a)) {
      if (a.name !== i)
        throw new Error(
          `Model name '${a.name}' does not match key '${i}'. The model name must match the key in the schema definition.`
        );
      t[i] = tk(a);
      let u = zv(a);
      u.schemas ? n[i] = {
        doc: u.schemas.doc,
        insert: u.schemas.insert
      } : n[i] = {
        doc: gp.doc(a),
        insert: gp.base(a)
      };
    } else
      t[i] = a.table, n[i] = {
        doc: a.schema.doc,
        insert: a.schema.insert
      };
  let o = ui(t);
  return Object.assign(o, { __zodTableMap: n });
}
s(Sv, "defineZodSchema");

// graphProbe.ts
var nk = { query: Ba, mutation: Va, action: qa, internalQuery: Ja, internalMutation: Ma, internalAction: Wa }, ik = { kind: "full", server: nk, s: { number: kn, string: Ut, boolean: In, optional: We, nullable: Ct, object: ra, array: Ft, union: pt, date: ta, codec: sa, instanceof: ua, parse: _n, encode: xn }, defineZodModel: Uh, defineZodSchema: Sv, initZodvex: bv }, ok = nm(ik), ak = { kind: "full", count: 512, width: 32, profile: "codec-rich", entries: 0 }, gN = rk({ args: {}, returns: y.object({ checksum: y.number(), output: y.object({ seq: y.number(), at: y.number(), secret: y.string(), payload: y.string() }), manifest: y.any(), nonce: y.string() }), handler: /* @__PURE__ */ s(() => {
  let e = ok(ak), t = e.operation();
  return { checksum: e.checksum(), output: t, manifest: e.manifest, nonce: "1016f47f-edfc-4bfb-843d-491e060ab0bd" };
}, "handler") });
export {
  gN as default
};
