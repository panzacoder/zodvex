import {connect} from './mcp-client.mjs'
import {bundleProbe} from './bundle.mjs'
import {appendFileSync} from 'node:fs'
const client=await connect()
const output='/private/tmp/graph-capacity-prototype/results/hosted-runtime-boundary.jsonl'
let calls=0
async function trial(kind,count,mode='handler',width=32,profile='codec-rich'){
 if(++calls>70)throw new Error('Exceeded 70-call investigation budget')
 const id=crypto.randomUUID(),dimensions={count,width,profile,entries:0}
 const bundle=await bundleProbe(kind,dimensions,{mode,nonce:id})
 const start=performance.now(),raw=await client.run(bundle.source)
 const text=raw.content?.filter(c=>c.type==='text').map(c=>c.text).join('\n')||JSON.stringify(raw)
 let payload;try{payload=JSON.parse(text)}catch{}
 const outcome=raw.isError?/out of memory/i.test(text)?'memory':/timed out|timeout/i.test(text)?'time':'other':payload?.result?.nonce===id?'ok':'harness'
 const phase=outcome==='ok'?'query':/InvalidModules|Could not analyze/i.test(text)?'analysis':/Query failed/.test(text)?'query':'unknown'
 const row={id,kind,...dimensions,mode,bytes:bundle.bytes,elapsedMs:performance.now()-start,outcome,phase,raw}
 appendFileSync(output,JSON.stringify(row)+'\n')
 console.log(JSON.stringify({kind,count,width,profile,mode,outcome,phase,error:outcome==='ok'?undefined:text.slice(0,280)}))
 return row
}
try {
 // First separate top-level analysis from actual handler construction capacity.

 // Bracket static graph initialization, stopping at a coarse 32-model interval.
 for(const kind of ['full','mini','helpers','native']) {
  let low=256, high=512
  if((await trial(kind,low)).outcome!=='ok')throw new Error('Initial lower bound did not pass')
  let candidate=await trial(kind,high)
  while(candidate.outcome==='ok'&&high<8192){low=high;high*=2;candidate=await trial(kind,high)}
  if(candidate.outcome!=='memory'){console.log(JSON.stringify({kind,boundary:'unresolved',last:candidate.outcome,low,high}));continue}
  while(high-low>32){const mid=Math.floor((low+high)/64)*32;const result=await trial(kind,mid);if(result.outcome==='ok')low=mid;else if(result.outcome==='memory')high=mid;else throw new Error('Non-memory boundary: '+result.outcome)}
  for(let r=0;r<2;r++){await trial(kind,low);await trial(kind,high)}
  console.log(JSON.stringify({kind,bracket:{low,high},meaning:'initial bracket; raw repeat outcomes authoritative'}))
 }
}finally{client.close()}
