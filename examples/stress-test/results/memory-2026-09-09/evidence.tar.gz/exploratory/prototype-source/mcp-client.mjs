import { spawn } from 'node:child_process'
import { createInterface } from 'node:readline'
export async function connect() {
 const root='/private/tmp/zodvex-triage-20260909/examples/stress-test'
 for(const key of ['CONVEX_DEPLOY_KEY','CONVEX_SELF_HOSTED_URL','CONVEX_SELF_HOSTED_ADMIN_KEY']) if(process.env[key]) throw new Error('Unexpected target override')
 const child=spawn('/Users/jshebert/.local/share/mise/installs/node/22.22.3/bin/node',[root+'/node_modules/convex/dist/cli.bundle.cjs','mcp','start','--project-dir',root+'/_deploy','--deployment-name','lovable-donkey-430','--disable-tools','data,envGet,envList,envRemove,envSet,functionSpec,insights,logs,run,tables'],{cwd:root+'/_deploy',stdio:['pipe','pipe','pipe']})
 let nextId=1; const pending=new Map(); let stderr=''
 child.stderr.on('data',data=>{stderr+=data.toString()})
 createInterface({input:child.stdout}).on('line',line=>{try{const result=JSON.parse(line);if(pending.has(result.id)){const entry=pending.get(result.id);clearTimeout(entry.timer);pending.delete(result.id);result.error?entry.reject(new Error(JSON.stringify(result.error))):entry.resolve(result.result)}}catch{}})
 child.on('exit',()=>{for(const entry of pending.values()){clearTimeout(entry.timer);entry.reject(new Error('CLI MCP exited '+stderr.slice(-500)))}pending.clear()})
 function request(method,params){return new Promise((resolve,reject)=>{const id=nextId++;const timer=setTimeout(()=>{pending.delete(id);reject(new Error('CLI MCP request timeout'));child.kill()},30000);pending.set(id,{resolve,reject,timer});child.stdin.write(JSON.stringify({jsonrpc:'2.0',id,method,params})+'\n')})}
 await request('initialize',{protocolVersion:'2024-11-05',capabilities:{},clientInfo:{name:'zodvex-graph-benchmark',version:'0.1'}})
 child.stdin.write(JSON.stringify({jsonrpc:'2.0',method:'notifications/initialized'})+'\n')
 const status=await request('tools/call',{name:'status',arguments:{projectDir:root+'/_deploy'}})
 const inventory=JSON.parse(status.content.find(c=>c.type==='text').text)
 const target=inventory.availableDeployments.find(d=>d.url==='https://lovable-donkey-430.convex.cloud')
 if(!target){child.kill();throw new Error('Expected dedicated dev target not present')}
 return {target:target.url,run:async query=>request('tools/call',{name:'runOneoffQuery',arguments:{deploymentSelector:target.deploymentSelector,query}}),close:()=>child.kill()}
}
