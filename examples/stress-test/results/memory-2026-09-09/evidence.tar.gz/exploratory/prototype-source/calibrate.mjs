import {createRequire} from 'node:module'
import {readFileSync,appendFileSync} from 'node:fs'
const root='/private/tmp/zodvex-triage-20260909/examples/stress-test'
const require=createRequire(root+'/package.json')
const {ConvexHttpClient}=require('convex/browser'),{makeFunctionReference}=require('convex/server')
const client=new ConvexHttpClient('https://lovable-donkey-430.convex.cloud',{logger:false})
import {assertGraphResult} from './oracle.mjs'
const cases=JSON.parse(readFileSync('/private/tmp/graph-capacity-prototype/results/calibration-cases.json','utf8')).filter(c=>c[3]==='handler')
for(let repeat=0;repeat<3;repeat++)for(const [name,kind,count,mode] of cases){
 const nonce=crypto.randomUUID(),start=performance.now();let result=null,error=null
 try{result=await client.query(makeFunctionReference(`graphProbe/${name}:default`),{nonce});assertGraphResult(result,{kind,count,width:32,profile:'codec-rich',entries:0,nonce})}catch(e){error=e.message}
 const outcome=error?/out of memory/i.test(error)?'memory':/timed out|timeout/i.test(error)?'time':'other':'ok'
 const row={timestamp:new Date().toISOString(),name,kind,count,mode,repeat,nonce,outcome,elapsedMs:performance.now()-start,result,error}
 appendFileSync('/private/tmp/graph-capacity-prototype/results/deployed-construction-calibration.jsonl',JSON.stringify(row)+'\n')
 console.log(JSON.stringify({name,count,mode,repeat,outcome,error}))
}
