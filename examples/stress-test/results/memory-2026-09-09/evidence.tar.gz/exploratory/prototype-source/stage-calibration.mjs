import {bundleProbe} from './bundle.mjs'
import {writeFileSync,mkdirSync} from 'node:fs'
const dir='/private/tmp/zodvex-triage-20260909/examples/stress-test/_deploy/convex/graphProbe'
mkdirSync(dir,{recursive:true})
const cases=[['fullStatic','full',416,'static'],['fullConstruct','full',512,'handler'],['helpersStatic','helpers',512,'static'],['miniStatic','mini',512,'static'],['nativeStatic','native',512,'static'],['helpersConstruct','helpers',512,'handler'],['miniConstruct','mini',512,'handler'],['nativeConstruct','native',512,'handler']]
for(const [name,kind,count,mode] of cases){const bundle=await bundleProbe(kind,{count,width:32,profile:'codec-rich',entries:0},{mode,deployed:true});writeFileSync(`${dir}/${name}.js`,bundle.source)}
writeFileSync('/private/tmp/graph-capacity-prototype/results/calibration-cases.json',JSON.stringify(cases,null,2))
console.log('Staged5ordinaryquerymodules;onepush;noadditionaldeclaredtables')
