var gf = Object.defineProperty;
var s = (e, r) => gf(e, "name", { value: r, configurable: !0 });
var Pe = (e, r) => {
  for (var i in r)
    gf(e, i, { get: r[i], enumerable: !0 });
};

// consumerProbe.ts
import { query as $w } from "convex:/_system/repl/wrappers.js";

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/base64.js
var we = [], he = [], Kv = Uint8Array, Po = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
for (Xe = 0, vf = Po.length; Xe < vf; ++Xe)
  we[Xe] = Po[Xe], he[Po.charCodeAt(Xe)] = Xe;
var Xe, vf;
he[45] = 62;
he[95] = 63;
function Wv(e) {
  var r = e.length;
  if (r % 4 > 0)
    throw new Error("Invalid string. Length must be a multiple of 4");
  var i = e.indexOf("=");
  i === -1 && (i = r);
  var o = i === r ? 0 : 4 - i % 4;
  return [i, o];
}
s(Wv, "getLens");
function Gv(e, r, i) {
  return (r + i) * 3 / 4 - i;
}
s(Gv, "_byteLength");
function Do(e) {
  var r, i = Wv(e), o = i[0], t = i[1], n = new Kv(Gv(e, o, t)), a = 0, c = t > 0 ? o - 4 : o, u;
  for (u = 0; u < c; u += 4)
    r = he[e.charCodeAt(u)] << 18 | he[e.charCodeAt(u + 1)] << 12 | he[e.charCodeAt(u + 2)] << 6 | he[e.charCodeAt(u + 3)], n[a++] = r >> 16 & 255, n[a++] = r >> 8 & 255, n[a++] = r & 255;
  return t === 2 && (r = he[e.charCodeAt(u)] << 2 | he[e.charCodeAt(u + 1)] >> 4, n[a++] = r & 255), t === 1 && (r = he[e.charCodeAt(u)] << 10 | he[e.charCodeAt(u + 1)] << 4 | he[e.charCodeAt(u + 2)] >> 2, n[a++] = r >> 8 & 255, n[a++] = r & 255), n;
}
s(Do, "toByteArray");
function Xv(e) {
  return we[e >> 18 & 63] + we[e >> 12 & 63] + we[e >> 6 & 63] + we[e & 63];
}
s(Xv, "tripletToBase64");
function Hv(e, r, i) {
  for (var o, t = [], n = r; n < i; n += 3)
    o = (e[n] << 16 & 16711680) + (e[n + 1] << 8 & 65280) + (e[n + 2] & 255), t.push(Xv(o));
  return t.join("");
}
s(Hv, "encodeChunk");
function cr(e) {
  for (var r, i = e.length, o = i % 3, t = [], n = 16383, a = 0, c = i - o; a < c; a += n)
    t.push(
      Hv(
        e,
        a,
        a + n > c ? c : a + n
      )
    );
  return o === 1 ? (r = e[i - 1], t.push(we[r >> 2] + we[r << 4 & 63] + "==")) : o === 2 && (r = (e[i - 2] << 8) + e[i - 1], t.push(
    we[r >> 10] + we[r >> 4 & 63] + we[r << 2 & 63] + "="
  )), t.join("");
}
s(cr, "fromByteArray");

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/common/index.js
function No(e) {
  let r = typeof e == "object", i = Object.getPrototypeOf(e), o = i === null || i === Object.prototype || // Objects generated from other contexts (e.g. across Node.js `vm` modules) will not satisfy the previous
  // conditions but are still simple objects.
  i?.constructor?.name === "Object";
  return r && o;
}
s(No, "isSimpleObject");

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/value.js
var Qv = !0, yt = BigInt("-9223372036854775808"), Eo = BigInt("9223372036854775807"), Uo = BigInt("0"), Yv = BigInt("8"), ey = BigInt("256");
function ty(e) {
  return Number.isNaN(e) || !Number.isFinite(e) || Object.is(e, -0);
}
s(ty, "isSpecial");
function ry(e) {
  e < Uo && (e -= yt + yt);
  let r = e.toString(16);
  r.length % 2 === 1 && (r = "0" + r);
  let i = new Uint8Array(new ArrayBuffer(8)), o = 0;
  for (let t of r.match(/.{2}/g).reverse())
    i.set([parseInt(t, 16)], o++), e >>= Yv;
  return cr(i);
}
s(ry, "slowBigIntToBase64");
function ny(e) {
  let r = Do(e);
  if (r.byteLength !== 8)
    throw new Error(
      `Received ${r.byteLength} bytes, expected 8 for $integer`
    );
  let i = Uo, o = Uo;
  for (let t of r)
    i += BigInt(t) * ey ** o, o++;
  return i > Eo && (i += yt + yt), i;
}
s(ny, "slowBase64ToBigInt");
function iy(e) {
  if (e < yt || Eo < e)
    throw new Error(
      `BigInt ${e} does not fit into a 64-bit signed integer.`
    );
  let r = new ArrayBuffer(8);
  return new DataView(r).setBigInt64(0, e, !0), cr(new Uint8Array(r));
}
s(iy, "modernBigIntToBase64");
function oy(e) {
  let r = Do(e);
  if (r.byteLength !== 8)
    throw new Error(
      `Received ${r.byteLength} bytes, expected 8 for $integer`
    );
  return new DataView(r.buffer).getBigInt64(0, !0);
}
s(oy, "modernBase64ToBigInt");
var ay = DataView.prototype.setBigInt64 ? iy : ry, zw = DataView.prototype.getBigInt64 ? oy : ny, bf = 1024;
function $f(e) {
  if (e.length > bf)
    throw new Error(
      `Field name ${e} exceeds maximum field name length ${bf}.`
    );
  if (e.startsWith("$"))
    throw new Error(`Field name ${e} starts with a '$', which is reserved.`);
  for (let r = 0; r < e.length; r += 1) {
    let i = e.charCodeAt(r);
    if (i < 32 || i >= 127)
      throw new Error(
        `Field name ${e} has invalid character '${e[r]}': Field names can only contain non-control ASCII characters`
      );
  }
}
s($f, "validateObjectField");
var _f = 16384;
function He(e) {
  let r = JSON.stringify(e, (i, o) => o === void 0 ? "undefined" : typeof o == "bigint" ? `${o.toString()}n` : o);
  if (r.length > _f) {
    let i = "[...truncated]", o = _f - i.length, t = r.codePointAt(o - 1);
    return t !== void 0 && t > 65535 && (o -= 1), r.substring(0, o) + i;
  }
  return r;
}
s(He, "stringifyValueForError");
function dn(e, r, i, o) {
  if (e === void 0) {
    let a = i && ` (present at path ${i} in original object ${He(
      r
    )})`;
    throw new Error(
      `undefined is not a valid Convex value${a}. To learn about Convex's supported types, see https://docs.convex.dev/using/types.`
    );
  }
  if (e === null)
    return e;
  if (typeof e == "bigint") {
    if (e < yt || Eo < e)
      throw new Error(
        `BigInt ${e} does not fit into a 64-bit signed integer.`
      );
    return { $integer: ay(e) };
  }
  if (typeof e == "number")
    if (ty(e)) {
      let a = new ArrayBuffer(8);
      return new DataView(a).setFloat64(0, e, Qv), { $float: cr(new Uint8Array(a)) };
    } else
      return e;
  if (typeof e == "boolean" || typeof e == "string")
    return e;
  if (e instanceof ArrayBuffer)
    return { $bytes: cr(new Uint8Array(e)) };
  if (Array.isArray(e))
    return e.map(
      (a, c) => dn(a, r, i + `[${c}]`, !1)
    );
  if (e instanceof Set)
    throw new Error(
      To(i, "Set", [...e], r)
    );
  if (e instanceof Map)
    throw new Error(
      To(i, "Map", [...e], r)
    );
  if (!No(e)) {
    let a = e?.constructor?.name, c = a ? `${a} ` : "";
    throw new Error(
      To(i, c, e, r)
    );
  }
  let t = {}, n = Object.entries(e);
  n.sort(([a, c], [u, l]) => a === u ? 0 : a < u ? -1 : 1);
  for (let [a, c] of n)
    c !== void 0 ? ($f(a), t[a] = dn(c, r, i + `.${a}`, !1)) : o && ($f(a), t[a] = sy(
      c,
      r,
      i + `.${a}`
    ));
  return t;
}
s(dn, "convexToJsonInternal");
function To(e, r, i, o) {
  return e ? `${r}${He(
    i
  )} is not a supported Convex type (present at path ${e} in original object ${He(
    o
  )}). To learn about Convex's supported types, see https://docs.convex.dev/using/types.` : `${r}${He(
    i
  )} is not a supported Convex type.`;
}
s(To, "errorMessageForUnsupportedType");
function sy(e, r, i) {
  if (e === void 0)
    return { $undefined: null };
  if (r === void 0)
    throw new Error(
      `Programming error. Current value is ${He(
        e
      )} but original value is undefined`
    );
  return dn(e, r, i, !1);
}
s(sy, "convexOrUndefinedToJsonInternal");
function ke(e) {
  return dn(e, e, "", !1);
}
s(ke, "convexToJson");

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/validators.js
var cy = Object.defineProperty, uy = /* @__PURE__ */ s((e, r, i) => r in e ? cy(e, r, { enumerable: !0, configurable: !0, writable: !0, value: i }) : e[r] = i, "__defNormalProp"), K = /* @__PURE__ */ s((e, r, i) => uy(e, typeof r != "symbol" ? r + "" : r, i), "__publicField"), ly = "https://docs.convex.dev/error#undefined-validator";
function ur(e, r) {
  let i = r !== void 0 ? ` for field "${r}"` : "";
  throw new Error(
    `A validator is undefined${i} in ${e}. This is often caused by circular imports. See ${ly} for details.`
  );
}
s(ur, "throwUndefinedValidatorError");
var te = class {
  static {
    s(this, "BaseValidator");
  }
  constructor({ isOptional: r }) {
    K(this, "type"), K(this, "fieldPaths"), K(this, "isOptional"), K(this, "isConvexValidator"), this.isOptional = r, this.isConvexValidator = !0;
  }
}, fn = class e extends te {
  static {
    s(this, "VId");
  }
  /**
   * Usually you'd use `v.id(tableName)` instead.
   */
  constructor({
    isOptional: r,
    tableName: i
  }) {
    if (super({ isOptional: r }), K(this, "tableName"), K(this, "kind", "id"), typeof i != "string")
      throw new Error("v.id(tableName) requires a string");
    this.tableName = i;
  }
  /** @internal */
  get json() {
    return { type: "id", tableName: this.tableName };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      tableName: this.tableName
    });
  }
}, lr = class e extends te {
  static {
    s(this, "VFloat64");
  }
  constructor() {
    super(...arguments), K(this, "kind", "float64");
  }
  /** @internal */
  get json() {
    return { type: "number" };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, dr = class e extends te {
  static {
    s(this, "VInt64");
  }
  constructor() {
    super(...arguments), K(this, "kind", "int64");
  }
  /** @internal */
  get json() {
    return { type: "bigint" };
  }
  /** @internal */
  asOptional() {
    return new e({ isOptional: "optional" });
  }
}, pn = class e extends te {
  static {
    s(this, "VBoolean");
  }
  constructor() {
    super(...arguments), K(this, "kind", "boolean");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, mn = class e extends te {
  static {
    s(this, "VBytes");
  }
  constructor() {
    super(...arguments), K(this, "kind", "bytes");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({ isOptional: "optional" });
  }
}, hn = class e extends te {
  static {
    s(this, "VString");
  }
  constructor() {
    super(...arguments), K(this, "kind", "string");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, gn = class e extends te {
  static {
    s(this, "VNull");
  }
  constructor() {
    super(...arguments), K(this, "kind", "null");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({ isOptional: "optional" });
  }
}, vn = class e extends te {
  static {
    s(this, "VAny");
  }
  constructor() {
    super(...arguments), K(this, "kind", "any");
  }
  /** @internal */
  get json() {
    return {
      type: this.kind
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, yn = class e extends te {
  static {
    s(this, "VObject");
  }
  /**
   * Usually you'd use `v.object({ ... })` instead.
   */
  constructor({
    isOptional: r,
    fields: i
  }) {
    super({ isOptional: r }), K(this, "fields"), K(this, "kind", "object"), globalThis.Object.entries(i).forEach(([o, t]) => {
      if (t === void 0 && ur("v.object()", o), !t.isConvexValidator)
        throw new Error("v.object() entries must be validators");
    }), this.fields = i;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: globalThis.Object.fromEntries(
        globalThis.Object.entries(this.fields).map(([r, i]) => [
          r,
          {
            fieldType: i.json,
            optional: i.isOptional === "optional"
          }
        ])
      )
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      fields: this.fields
    });
  }
  /**
   * Create a new VObject with the specified fields omitted.
   * @param fields The field names to omit from this VObject.
   */
  omit(...r) {
    let i = { ...this.fields };
    for (let o of r)
      delete i[o];
    return new e({
      isOptional: this.isOptional,
      fields: i
    });
  }
  /**
   * Create a new VObject with only the specified fields.
   * @param fields The field names to pick from this VObject.
   */
  pick(...r) {
    let i = {};
    for (let o of r)
      i[o] = this.fields[o];
    return new e({
      isOptional: this.isOptional,
      fields: i
    });
  }
  /**
   * Create a new VObject with all fields marked as optional.
   */
  partial() {
    let r = {};
    for (let [i, o] of globalThis.Object.entries(this.fields))
      r[i] = o.asOptional();
    return new e({
      isOptional: this.isOptional,
      fields: r
    });
  }
  /**
   * Create a new VObject with additional fields merged in.
   * @param fields An object with additional validators to merge into this VObject.
   */
  extend(r) {
    return new e({
      isOptional: this.isOptional,
      fields: { ...this.fields, ...r }
    });
  }
}, bn = class e extends te {
  static {
    s(this, "VLiteral");
  }
  /**
   * Usually you'd use `v.literal(value)` instead.
   */
  constructor({ isOptional: r, value: i }) {
    if (super({ isOptional: r }), K(this, "value"), K(this, "kind", "literal"), typeof i != "string" && typeof i != "boolean" && typeof i != "number" && typeof i != "bigint")
      throw new Error("v.literal(value) must be a string, number, or boolean");
    this.value = i;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: ke(this.value)
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      value: this.value
    });
  }
}, $n = class e extends te {
  static {
    s(this, "VArray");
  }
  /**
   * Usually you'd use `v.array(element)` instead.
   */
  constructor({
    isOptional: r,
    element: i
  }) {
    super({ isOptional: r }), K(this, "element"), K(this, "kind", "array"), i === void 0 && ur("v.array()"), this.element = i;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: this.element.json
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      element: this.element
    });
  }
}, _n = class e extends te {
  static {
    s(this, "VRecord");
  }
  /**
   * Usually you'd use `v.record(key, value)` instead.
   */
  constructor({
    isOptional: r,
    key: i,
    value: o
  }) {
    if (super({ isOptional: r }), K(this, "key"), K(this, "value"), K(this, "kind", "record"), i === void 0 && ur("v.record()", "key"), o === void 0 && ur("v.record()", "value"), i.isOptional === "optional")
      throw new Error("Record validator cannot have optional keys");
    if (o.isOptional === "optional")
      throw new Error("Record validator cannot have optional values");
    if (!i.isConvexValidator || !o.isConvexValidator)
      throw new Error("Key and value of v.record() but be validators");
    this.key = i, this.value = o;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      // This cast is needed because TypeScript thinks the key type is too wide
      keys: this.key.json,
      values: {
        fieldType: this.value.json,
        optional: !1
      }
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      key: this.key,
      value: this.value
    });
  }
}, xn = class e extends te {
  static {
    s(this, "VUnion");
  }
  /**
   * Usually you'd use `v.union(...members)` instead.
   */
  constructor({ isOptional: r, members: i }) {
    super({ isOptional: r }), K(this, "members"), K(this, "kind", "union"), i.forEach((o, t) => {
      if (o === void 0 && ur("v.union()", `member at index ${t}`), !o.isConvexValidator)
        throw new Error("All members of v.union() must be validators");
    }), this.members = i;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: this.members.map((r) => r.json)
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      members: this.members
    });
  }
};

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/validator.js
function xf(e) {
  return !!e.isConvexValidator;
}
s(xf, "isValidator");
var j = {
  /**
   * Validates that the value is a document ID for the given table.
   *
   * IDs are strings at runtime but are typed as `Id<"tableName">` in
   * TypeScript for type safety.
   *
   * @example
   * ```typescript
   * args: { userId: v.id("users") }
   * ```
   *
   * @param tableName The name of the table.
   */
  id: /* @__PURE__ */ s((e) => new fn({
    isOptional: "required",
    tableName: e
  }), "id"),
  /**
   * Validates that the value is `null`.
   *
   * Use `returns: v.null()` for functions that don't return a meaningful value.
   * JavaScript `undefined` is not a valid Convex value, it is automatically
   * converted to `null`.
   */
  null: /* @__PURE__ */ s(() => new gn({ isOptional: "required" }), "null"),
  /**
   * Validates that the value is a JavaScript `number` (Convex Float64).
   *
   * Supports all IEEE-754 double-precision floating point numbers including
   * NaN and Infinity.
   *
   * Alias for `v.float64()`.
   */
  number: /* @__PURE__ */ s(() => new lr({ isOptional: "required" }), "number"),
  /**
   * Validates that the value is a JavaScript `number` (Convex Float64).
   *
   * Supports all IEEE-754 double-precision floating point numbers.
   */
  float64: /* @__PURE__ */ s(() => new lr({ isOptional: "required" }), "float64"),
  /**
   * @deprecated Use `v.int64()` instead.
   */
  bigint: /* @__PURE__ */ s(() => new dr({ isOptional: "required" }), "bigint"),
  /**
   * Validates that the value is a JavaScript `bigint` (Convex Int64).
   *
   * Supports BigInts between -2^63 and 2^63-1.
   *
   * @example
   * ```typescript
   * args: { timestamp: v.int64() }
   * // Usage: createDoc({ timestamp: 1234567890n })
   * ```
   */
  int64: /* @__PURE__ */ s(() => new dr({ isOptional: "required" }), "int64"),
  /**
   * Validates that the value is a `boolean`.
   */
  boolean: /* @__PURE__ */ s(() => new pn({ isOptional: "required" }), "boolean"),
  /**
   * Validates that the value is a `string`.
   *
   * Strings are stored as UTF-8 and their storage size is calculated as their
   * UTF-8 encoded size.
   */
  string: /* @__PURE__ */ s(() => new hn({ isOptional: "required" }), "string"),
  /**
   * Validates that the value is an `ArrayBuffer` (Convex Bytes).
   *
   * Use for binary data.
   */
  bytes: /* @__PURE__ */ s(() => new mn({ isOptional: "required" }), "bytes"),
  /**
   * Validates that the value is exactly equal to the given literal.
   *
   * Useful for discriminated unions and enum-like patterns.
   *
   * @example
   * ```typescript
   * // Discriminated union pattern:
   * v.union(
   *   v.object({ kind: v.literal("error"), message: v.string() }),
   *   v.object({ kind: v.literal("success"), value: v.number() }),
   * )
   * ```
   *
   * @param literal The literal value to compare against.
   */
  literal: /* @__PURE__ */ s((e) => new bn({ isOptional: "required", value: e }), "literal"),
  /**
   * Validates that the value is an `Array` where every element matches the
   * given validator.
   *
   * Arrays can have at most 8192 elements.
   *
   * @example
   * ```typescript
   * args: { tags: v.array(v.string()) }
   * args: { coordinates: v.array(v.number()) }
   * args: { items: v.array(v.object({ name: v.string(), qty: v.number() })) }
   * ```
   *
   * @param element The validator for the elements of the array.
   */
  array: /* @__PURE__ */ s((e) => new $n({ isOptional: "required", element: e }), "array"),
  /**
   * Validates that the value is an `Object` with the specified properties.
   *
   * Objects can have at most 1024 entries. Field names must be non-empty and
   * must not start with `"$"` or `"_"` (`_` is reserved for system fields
   * like `_id` and `_creationTime`; `$` is reserved for Convex internal use).
   *
   * @example
   * ```typescript
   * args: {
   *   user: v.object({
   *     name: v.string(),
   *     email: v.string(),
   *     age: v.optional(v.number()),
   *   })
   * }
   * ```
   *
   * @param fields An object mapping property names to their validators.
   */
  object: /* @__PURE__ */ s((e) => new yn({ isOptional: "required", fields: e }), "object"),
  /**
   * Validates that the value is a `Record` (object with dynamic keys).
   *
   * Records are objects at runtime but allow dynamic keys, unlike `v.object()`
   * which requires known property names. Keys must be ASCII characters only,
   * non-empty, and not start with `"$"` or `"_"`.
   *
   * @example
   * ```typescript
   * // Map of user IDs to scores:
   * args: { scores: v.record(v.id("users"), v.number()) }
   *
   * // Map of string keys to string values:
   * args: { metadata: v.record(v.string(), v.string()) }
   * ```
   *
   * @param keys The validator for the keys of the record.
   * @param values The validator for the values of the record.
   */
  record: /* @__PURE__ */ s((e, r) => new _n({
    isOptional: "required",
    key: e,
    value: r
  }), "record"),
  /**
   * Validates that the value matches at least one of the given validators.
   *
   * @example
   * ```typescript
   * // Allow string or number:
   * args: { value: v.union(v.string(), v.number()) }
   *
   * // Discriminated union (recommended pattern):
   * v.union(
   *   v.object({ kind: v.literal("text"), body: v.string() }),
   *   v.object({ kind: v.literal("image"), url: v.string() }),
   * )
   *
   * // Nullable value:
   * returns: v.union(v.object({ ... }), v.null())
   * ```
   *
   * @param members The validators to match against.
   */
  union: /* @__PURE__ */ s((...e) => new xn({
    isOptional: "required",
    members: e
  }), "union"),
  /**
   * A validator that accepts any Convex value without validation.
   *
   * Prefer using specific validators when possible for better type safety
   * and runtime validation.
   */
  any: /* @__PURE__ */ s(() => new vn({ isOptional: "required" }), "any"),
  /**
   * Makes a property optional in an object validator.
   *
   * An optional property can be omitted entirely when creating a document or
   * calling a function. This is different from `v.nullable()` which requires
   * the property to be present but allows `null`.
   *
   * @example
   * ```typescript
   * v.object({
   *   name: v.string(),              // required
   *   nickname: v.optional(v.string()), // can be omitted
   * })
   *
   * // Valid: { name: "Alice" }
   * // Valid: { name: "Alice", nickname: "Ali" }
   * // Invalid: { name: "Alice", nickname: null }  - use v.nullable() for this
   * ```
   *
   * @param value The property value validator to make optional.
   */
  optional: /* @__PURE__ */ s((e) => e.asOptional(), "optional"),
  /**
   * Allows a value to be either the given type or `null`.
   *
   * This is shorthand for `v.union(value, v.null())`. Unlike `v.optional()`,
   * the property must still be present, but may be `null`.
   *
   * @example
   * ```typescript
   * v.object({
   *   name: v.string(),
   *   deletedAt: v.nullable(v.number()), // must be present, can be null
   * })
   *
   * // Valid: { name: "Alice", deletedAt: null }
   * // Valid: { name: "Alice", deletedAt: 1234567890 }
   * // Invalid: { name: "Alice" }  - deletedAt is required
   * ```
   */
  nullable: /* @__PURE__ */ s((e) => j.union(e, j.null()), "nullable")
};

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/errors.js
var dy = Object.defineProperty, fy = /* @__PURE__ */ s((e, r, i) => r in e ? dy(e, r, { enumerable: !0, configurable: !0, writable: !0, value: i }) : e[r] = i, "__defNormalProp"), Co = /* @__PURE__ */ s((e, r, i) => fy(e, typeof r != "symbol" ? r + "" : r, i), "__publicField"), wf, kf, py = Symbol.for("ConvexError"), wn = class extends (kf = Error, wf = py, kf) {
  static {
    s(this, "ConvexError");
  }
  constructor(r) {
    super(typeof r == "string" ? r : He(r)), Co(this, "name", "ConvexError"), Co(this, "data"), Co(this, wf, !0), this.data = r;
  }
};

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/compare_utf8.js
var If = /* @__PURE__ */ s(() => Array.from({ length: 4 }, () => 0), "arr"), Zw = If(), Rw = If();

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/counters.mjs
var $ = { models: [], descriptors: [] };

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/external.js
var d = {};
Pe(d, {
  $brand: () => Yo,
  $input: () => vu,
  $output: () => gu,
  NEVER: () => Qo,
  TimePrecision: () => Su,
  ZodAny: () => pd,
  ZodArray: () => vd,
  ZodBase64: () => lo,
  ZodBase64URL: () => fo,
  ZodBigInt: () => tr,
  ZodBigIntFormat: () => ho,
  ZodBoolean: () => er,
  ZodCIDRv4: () => co,
  ZodCIDRv6: () => uo,
  ZodCUID: () => to,
  ZodCUID2: () => ro,
  ZodCatch: () => Zd,
  ZodCodec: () => nn,
  ZodCompileAsyncError: () => _e,
  ZodCompileUnsupportedError: () => C,
  ZodCreditCard: () => ad,
  ZodCustom: () => on,
  ZodCustomStringFormat: () => Qt,
  ZodDate: () => Hr,
  ZodDefault: () => Dd,
  ZodDiscriminatedUnion: () => bd,
  ZodE164: () => po,
  ZodEmail: () => Hi,
  ZodEmoji: () => Yi,
  ZodEnum: () => Xt,
  ZodError: () => $x,
  ZodExactOptional: () => bo,
  ZodFile: () => Od,
  ZodFirstPartyTypeKind: () => Hd,
  ZodFunction: () => Wd,
  ZodGUID: () => Qi,
  ZodIPv4: () => ao,
  ZodIPv6: () => so,
  ZodISODate: () => Je,
  ZodISODateTime: () => Be,
  ZodISODuration: () => Ke,
  ZodISOTime: () => qe,
  ZodIntersection: () => $d,
  ZodIssueCode: () => wx,
  ZodJWT: () => mo,
  ZodKSUID: () => oo,
  ZodLazy: () => Jd,
  ZodLiteral: () => Sd,
  ZodMAC: () => od,
  ZodMap: () => Id,
  ZodNaN: () => Fd,
  ZodNanoID: () => eo,
  ZodNever: () => hd,
  ZodNonOptional: () => $o,
  ZodNull: () => dd,
  ZodNullable: () => Pd,
  ZodNumber: () => Yt,
  ZodNumberFormat: () => vt,
  ZodObject: () => Yr,
  ZodOptional: () => tn,
  ZodPipe: () => rn,
  ZodPrefault: () => Td,
  ZodPreprocess: () => Ld,
  ZodPromise: () => Kd,
  ZodReadonly: () => Vd,
  ZodRealError: () => le,
  ZodRecord: () => Gt,
  ZodSet: () => zd,
  ZodString: () => Ht,
  ZodStringFormat: () => M,
  ZodSuccess: () => Cd,
  ZodSymbol: () => ud,
  ZodTemplateLiteral: () => Bd,
  ZodTransform: () => jd,
  ZodTuple: () => xd,
  ZodType: () => U,
  ZodULID: () => no,
  ZodURL: () => Xr,
  ZodUUID: () => je,
  ZodUndefined: () => ld,
  ZodUnion: () => en,
  ZodUnknown: () => md,
  ZodVoid: () => gd,
  ZodXID: () => io,
  ZodXor: () => yd,
  _ZodString: () => Xi,
  _default: () => Nd,
  _function: () => Tm,
  any: () => dm,
  array: () => Qr,
  base64: () => Kp,
  base64url: () => Wp,
  bigint: () => am,
  boolean: () => cd,
  catch: () => Rd,
  check: () => Um,
  cidrv4: () => Jp,
  cidrv6: () => qp,
  clone: () => Z,
  codec: () => Am,
  coerce: () => Qd,
  compile: () => _u,
  config: () => X,
  core: () => Te,
  creditCard: () => Xp,
  cuid: () => Cp,
  cuid2: () => Zp,
  custom: () => Em,
  date: () => pm,
  decode: () => Ql,
  decodeAsync: () => ed,
  deepPartial: () => Wm,
  describe: () => Cm,
  discriminatedUnion: () => bm,
  e164: () => Gp,
  email: () => Sp,
  emoji: () => Up,
  encode: () => Hl,
  encodeAsync: () => Yl,
  endsWith: () => Ft,
  enum: () => vo,
  exactOptional: () => Ad,
  file: () => zm,
  flattenError: () => $r,
  float32: () => rm,
  float64: () => nm,
  formatError: () => _r,
  fromJSONSchema: () => qm,
  function: () => Tm,
  getDiscriminatedOption: () => Bs,
  getErrorMap: () => Ix,
  globalRegistry: () => Y,
  gt: () => Se,
  gte: () => me,
  guid: () => Op,
  hash: () => tm,
  hex: () => em,
  hostname: () => Yp,
  httpUrl: () => Tp,
  includes: () => Zt,
  input: () => Xm,
  instanceof: () => Rm,
  int: () => Wi,
  int32: () => im,
  int64: () => sm,
  intersection: () => _d,
  invertCodec: () => Pm,
  ipv4: () => Vp,
  ipv6: () => Bp,
  iso: () => an,
  json: () => Lm,
  jwt: () => Hp,
  keyof: () => mm,
  ksuid: () => Lp,
  lazy: () => qd,
  length: () => pt,
  literal: () => Im,
  locales: () => Fr,
  looseObject: () => vm,
  looseRecord: () => _m,
  lowercase: () => Et,
  lt: () => ze,
  lte: () => pe,
  mac: () => Mp,
  map: () => xm,
  maxLength: () => ft,
  maxSize: () => Fe,
  memoizer: () => Ur,
  meta: () => Zm,
  mime: () => Lt,
  minLength: () => Ne,
  minSize: () => Oe,
  multipleOf: () => Re,
  nan: () => jm,
  nanoid: () => Ep,
  nativeEnum: () => km,
  negative: () => Ei,
  never: () => go,
  nonnegative: () => Zi,
  nonoptional: () => Ed,
  nonpositive: () => Ci,
  normalize: () => Vt,
  null: () => fd,
  nullable: () => Gr,
  nullish: () => Sm,
  number: () => sd,
  object: () => hm,
  optional: () => ht,
  output: () => Hm,
  overwrite: () => xe,
  parse: () => Kl,
  parseAsync: () => Wl,
  partialRecord: () => $m,
  pipe: () => Gi,
  positive: () => Ui,
  prefault: () => Ud,
  preprocess: () => Vm,
  prettifyError: () => ia,
  promise: () => Nm,
  properties: () => Fi,
  property: () => Ri,
  readonly: () => Md,
  record: () => kd,
  refine: () => Gd,
  regex: () => Ut,
  regexes: () => re,
  registry: () => fi,
  safeDecode: () => rd,
  safeDecodeAsync: () => id,
  safeEncode: () => td,
  safeEncodeAsync: () => nd,
  safeParse: () => Gl,
  safeParseAsync: () => Xl,
  set: () => wm,
  setErrorMap: () => kx,
  size: () => dt,
  slugify: () => qt,
  startsWith: () => Rt,
  strictObject: () => gm,
  string: () => Wr,
  stringFormat: () => Qp,
  stringbool: () => Fm,
  success: () => Om,
  superRefine: () => Xd,
  symbol: () => um,
  templateLiteral: () => Dm,
  toJSONSchema: () => Bi,
  toLowerCase: () => Bt,
  toUpperCase: () => Jt,
  toZod: () => fr,
  transform: () => yo,
  treeifyError: () => na,
  trim: () => Mt,
  tuple: () => wd,
  uint32: () => om,
  uint64: () => cm,
  ulid: () => Rp,
  undefined: () => lm,
  union: () => rr,
  unknown: () => mt,
  uppercase: () => Ct,
  url: () => Np,
  util: () => k,
  uuid: () => jp,
  uuidv4: () => Ap,
  uuidv6: () => Pp,
  uuidv7: () => Dp,
  validate: () => aa,
  validateAsync: () => sa,
  void: () => fm,
  xid: () => Fp,
  xor: () => ym
});

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/index.js
var Te = {};
Pe(Te, {
  $ZodAny: () => Zs,
  $ZodArray: () => Ar,
  $ZodAsyncError: () => ce,
  $ZodBase64: () => Ss,
  $ZodBase64URL: () => Os,
  $ZodBigInt: () => ii,
  $ZodBigIntFormat: () => Ts,
  $ZodBoolean: () => Or,
  $ZodCIDRv4: () => Is,
  $ZodCIDRv6: () => zs,
  $ZodCUID: () => ps,
  $ZodCUID2: () => ms,
  $ZodCatch: () => ec,
  $ZodCheck: () => B,
  $ZodCheckBigIntFormat: () => Va,
  $ZodCheckEndsWith: () => es,
  $ZodCheckGreaterThan: () => Vn,
  $ZodCheckIncludes: () => Qa,
  $ZodCheckLengthEquals: () => Wa,
  $ZodCheckLessThan: () => Ln,
  $ZodCheckLowerCase: () => Xa,
  $ZodCheckMaxLength: () => qa,
  $ZodCheckMaxSize: () => Ma,
  $ZodCheckMimeType: () => ts,
  $ZodCheckMinLength: () => Ka,
  $ZodCheckMinSize: () => Ba,
  $ZodCheckMultipleOf: () => Fa,
  $ZodCheckNumberFormat: () => La,
  $ZodCheckOverwrite: () => rs,
  $ZodCheckProperty: () => Mn,
  $ZodCheckRegex: () => Ga,
  $ZodCheckSizeEquals: () => Ja,
  $ZodCheckStartsWith: () => Ya,
  $ZodCheckStringFormat: () => jt,
  $ZodCheckUpperCase: () => Ha,
  $ZodCodec: () => ot,
  $ZodCreditCard: () => As,
  $ZodCustom: () => ai,
  $ZodCustomStringFormat: () => Ds,
  $ZodCyclicError: () => ui,
  $ZodDate: () => jr,
  $ZodDefault: () => Tr,
  $ZodDiscriminatedUnion: () => Pt,
  $ZodE164: () => js,
  $ZodEmail: () => ss,
  $ZodEmoji: () => ds,
  $ZodEncodeError: () => Ce,
  $ZodEnum: () => Dr,
  $ZodError: () => et,
  $ZodExactOptional: () => Xs,
  $ZodFile: () => Ws,
  $ZodFunction: () => oc,
  $ZodGUID: () => os,
  $ZodIPv4: () => xs,
  $ZodIPv6: () => ws,
  $ZodISODate: () => bs,
  $ZodISODateTime: () => ys,
  $ZodISODuration: () => _s,
  $ZodISOTime: () => $s,
  $ZodIntersection: () => Js,
  $ZodJWT: () => Ps,
  $ZodKSUID: () => vs,
  $ZodLazy: () => at,
  $ZodLiteral: () => Nr,
  $ZodMAC: () => ks,
  $ZodMap: () => qs,
  $ZodNaN: () => tc,
  $ZodNanoID: () => fs,
  $ZodNever: () => Fs,
  $ZodNonOptional: () => Qs,
  $ZodNull: () => Cs,
  $ZodNullable: () => Nt,
  $ZodNumber: () => ni,
  $ZodNumberFormat: () => Ns,
  $ZodObject: () => be,
  $ZodObjectJIT: () => Vs,
  $ZodOptional: () => $e,
  $ZodPipe: () => oi,
  $ZodPrefault: () => Hs,
  $ZodPreprocess: () => rc,
  $ZodPromise: () => ac,
  $ZodReadonly: () => nc,
  $ZodRealError: () => ue,
  $ZodRecord: () => Pr,
  $ZodRegistry: () => di,
  $ZodSet: () => Ks,
  $ZodString: () => it,
  $ZodStringFormat: () => V,
  $ZodSuccess: () => Ys,
  $ZodSymbol: () => Us,
  $ZodTemplateLiteral: () => ic,
  $ZodTransform: () => Gs,
  $ZodTuple: () => Dt,
  $ZodType: () => P,
  $ZodULID: () => hs,
  $ZodURL: () => ls,
  $ZodUUID: () => as,
  $ZodUndefined: () => Es,
  $ZodUnion: () => Ie,
  $ZodUnknown: () => Rs,
  $ZodVoid: () => Ls,
  $ZodXID: () => gs,
  $ZodXor: () => Ms,
  $brand: () => Yo,
  $constructor: () => h,
  $input: () => vu,
  $output: () => gu,
  Doc: () => nt,
  INVALID: () => fe,
  JSONSchema: () => kp,
  JSONSchemaGenerator: () => Ji,
  NEVER: () => Qo,
  TimePrecision: () => Su,
  URL_BAD_FORMAT: () => cs,
  URL_UNPARSEABLE: () => us,
  ZodCompileAsyncError: () => _e,
  ZodCompileUnsupportedError: () => C,
  _any: () => Bu,
  _array: () => Hu,
  _base64: () => Pi,
  _base64url: () => Di,
  _bigint: () => Cu,
  _boolean: () => Uu,
  _catch: () => lx,
  _check: () => vp,
  _cidrv4: () => ji,
  _cidrv6: () => Ai,
  _coercedBigint: () => Zu,
  _coercedBoolean: () => Eu,
  _coercedDate: () => Gu,
  _coercedNumber: () => ju,
  _coercedString: () => ku,
  _creditCard: () => zu,
  _cuid: () => xi,
  _cuid2: () => wi,
  _custom: () => Yu,
  _date: () => Wu,
  _decode: () => Pn,
  _decodeAsync: () => Nn,
  _default: () => sx,
  _discriminatedUnion: () => G_,
  _e164: () => Ni,
  _email: () => mi,
  _emoji: () => $i,
  _encode: () => An,
  _encodeAsync: () => Dn,
  _endsWith: () => Ft,
  _enum: () => tx,
  _file: () => Qu,
  _float32: () => Pu,
  _float64: () => Du,
  _gt: () => Se,
  _gte: () => me,
  _guid: () => hi,
  _includes: () => Zt,
  _int: () => Au,
  _int32: () => Nu,
  _int64: () => Ru,
  _intersection: () => X_,
  _ipv4: () => Si,
  _ipv6: () => Oi,
  _isoDate: () => Mr,
  _isoDateTime: () => Vr,
  _isoDuration: () => Jr,
  _isoTime: () => Br,
  _jwt: () => Ti,
  _ksuid: () => zi,
  _lazy: () => mx,
  _length: () => pt,
  _literal: () => nx,
  _lowercase: () => Et,
  _lt: () => ze,
  _lte: () => pe,
  _mac: () => Iu,
  _map: () => Y_,
  _max: () => pe,
  _maxLength: () => ft,
  _maxSize: () => Fe,
  _mime: () => Lt,
  _min: () => me,
  _minLength: () => Ne,
  _minSize: () => Oe,
  _multipleOf: () => Re,
  _nan: () => Xu,
  _nanoid: () => _i,
  _nativeEnum: () => rx,
  _negative: () => Ei,
  _never: () => qu,
  _nonnegative: () => Zi,
  _nonoptional: () => cx,
  _nonpositive: () => Ci,
  _normalize: () => Vt,
  _null: () => Mu,
  _nullable: () => ax,
  _number: () => Ou,
  _optional: () => ox,
  _overwrite: () => xe,
  _parse: () => It,
  _parseAsync: () => zt,
  _pipe: () => dx,
  _positive: () => Ui,
  _promise: () => hx,
  _properties: () => Fi,
  _property: () => Ri,
  _readonly: () => fx,
  _record: () => Q_,
  _refine: () => el,
  _regex: () => Ut,
  _safeDecode: () => Un,
  _safeDecodeAsync: () => Cn,
  _safeEncode: () => Tn,
  _safeEncodeAsync: () => En,
  _safeParse: () => St,
  _safeParseAsync: () => Ot,
  _set: () => ex,
  _size: () => dt,
  _slugify: () => qt,
  _startsWith: () => Rt,
  _string: () => wu,
  _stringFormat: () => Kt,
  _stringbool: () => il,
  _success: () => ux,
  _superRefine: () => tl,
  _symbol: () => Lu,
  _templateLiteral: () => px,
  _toLowerCase: () => Bt,
  _toUpperCase: () => Jt,
  _transform: () => ix,
  _trim: () => Mt,
  _tuple: () => H_,
  _uint32: () => Tu,
  _uint64: () => Fu,
  _ulid: () => ki,
  _undefined: () => Vu,
  _union: () => K_,
  _unknown: () => Ju,
  _uppercase: () => Ct,
  _url: () => Lr,
  _uuid: () => gi,
  _uuidv4: () => vi,
  _uuidv6: () => yi,
  _uuidv7: () => bi,
  _void: () => Ku,
  _xid: () => Ii,
  _xor: () => W_,
  clone: () => Z,
  compile: () => _u,
  compileFn: () => pi,
  config: () => X,
  createStandardJSONSchemaMethod: () => Wt,
  createToJSONSchemaMethod: () => al,
  decode: () => eb,
  decodeAsync: () => rb,
  describe: () => rl,
  encode: () => De,
  encodeAsync: () => tb,
  extractDefs: () => Ve,
  finalize: () => Me,
  flattenError: () => $r,
  formatError: () => _r,
  getDiscriminatedOption: () => Bs,
  globalConfig: () => Q,
  globalRegistry: () => Y,
  handleUnrepresentable: () => H,
  initializeContext: () => Le,
  isBackEdge: () => li,
  isRecursiveSchema: () => lc,
  isValidBase64: () => Sr,
  isValidBase64URL: () => ei,
  isValidCIDRv6: () => Yn,
  isValidCreditCard: () => ti,
  isValidIPv6: () => zr,
  isValidJWT: () => ri,
  locales: () => Fr,
  memoizer: () => Ur,
  mergeValues: () => At,
  meta: () => nl,
  parse: () => tt,
  parseAsync: () => jn,
  parseURLObject: () => Gn,
  prettifyError: () => ia,
  process: () => F,
  regexes: () => re,
  registry: () => fi,
  safeDecode: () => ib,
  safeDecodeAsync: () => ab,
  safeEncode: () => nb,
  safeEncodeAsync: () => ob,
  safeParse: () => xr,
  safeParseAsync: () => oa,
  standardProps: () => Wn,
  stripTabAndNewline: () => Xn,
  toDotPath: () => Tf,
  toJSONSchema: () => Bi,
  toZod: () => fr,
  treeifyError: () => na,
  urlHostnameOk: () => Hn,
  urlProtocolOk: () => Qn,
  util: () => k,
  validate: () => aa,
  validateAsync: () => sa,
  version: () => ns
});

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/util.js
var k = {};
Pe(k, {
  BIGINT_FORMAT_RANGES: () => qo,
  CONSTANT_CATCH: () => Sn,
  Class: () => Ro,
  NUMBER_FORMAT_RANGES: () => Jo,
  aborted: () => Ee,
  allowsEval: () => Vo,
  assert: () => by,
  assertEqual: () => hy,
  assertIs: () => vy,
  assertNever: () => yy,
  assertNotEqual: () => gy,
  assignProp: () => G,
  attachSchema: () => zn,
  base64ToUint8Array: () => Of,
  base64urlToUint8Array: () => Cy,
  cached: () => wt,
  captureStackTrace: () => In,
  cleanEnum: () => Ey,
  cleanRegex: () => mr,
  clone: () => Z,
  cloneDef: () => _y,
  codePointLength: () => Ye,
  constantCatch: () => Xo,
  createTransparentProxy: () => Sy,
  defineLazy: () => Fo,
  defineLazyInternal: () => E,
  esc: () => oe,
  escapeRegex: () => ve,
  explicitlyAborted: () => Ko,
  extend: () => Ay,
  finalizeIssue: () => se,
  floatSafeRemainder: () => hr,
  getElementAtPath: () => xy,
  getEnumValues: () => pr,
  getLengthableOrigin: () => br,
  getParsedType: () => zy,
  getSizableOrigin: () => yr,
  hexToUint8Array: () => Ry,
  hide: () => Go,
  installLazyProp: () => By,
  isObject: () => Qe,
  isPlainObject: () => ge,
  issue: () => kt,
  joinValues: () => g,
  jsonStringifyReplacer: () => xt,
  members: () => Wo,
  merge: () => Dy,
  mergeDefs: () => ye,
  normalizeParams: () => I,
  nullish: () => kn,
  numKeys: () => Iy,
  objectClone: () => $y,
  omit: () => jy,
  optionalKeys: () => Bo,
  own: () => _t,
  parsedType: () => w,
  partial: () => Ny,
  pick: () => Oy,
  prefixIssues: () => ae,
  primitiveTypes: () => Mo,
  promiseAllObject: () => wy,
  propertyKeyTypes: () => vr,
  randomString: () => ky,
  required: () => Ty,
  safeExtend: () => Py,
  shallowClone: () => gr,
  slugify: () => Lo,
  stringifyPrimitive: () => x,
  toZod: () => fr,
  uint8ArrayToBase64: () => jf,
  uint8ArrayToBase64url: () => Zy,
  uint8ArrayToHex: () => Fy,
  unwrapMessage: () => $t
});
function hy(e) {
  return e;
}
s(hy, "assertEqual");
function gy(e) {
  return e;
}
s(gy, "assertNotEqual");
function fr() {
  return (e) => e;
}
s(fr, "toZod");
function vy(e) {
}
s(vy, "assertIs");
function yy(e) {
  throw new Error("Unexpected value in exhaustive check");
}
s(yy, "assertNever");
function by(e) {
}
s(by, "assert");
function pr(e) {
  let r = Object.values(e).filter((o) => typeof o == "number");
  return Object.entries(e).filter(([o, t]) => r.indexOf(+o) === -1).map(([o, t]) => t);
}
s(pr, "getEnumValues");
function g(e, r = "|") {
  return e.map((i) => x(i)).join(r);
}
s(g, "joinValues");
function xt(e, r) {
  return typeof r == "bigint" ? r.toString() : r;
}
s(xt, "jsonStringifyReplacer");
function wt(e) {
  return {
    get value() {
      {
        let i = e();
        return Object.defineProperty(this, "value", { value: i }), i;
      }
      throw new Error("cached value already set");
    }
  };
}
s(wt, "cached");
function kn(e) {
  return e == null;
}
s(kn, "nullish");
function mr(e) {
  let r = e.startsWith("^") ? 1 : 0, i = e.endsWith("$") ? e.length - 1 : e.length;
  return e.slice(r, i);
}
s(mr, "cleanRegex");
function hr(e, r) {
  let i = e / r, o = Math.round(i), t = 4 * Number.EPSILON * Math.max(Math.abs(i), 1);
  return Math.abs(i - o) < t ? 0 : i - o;
}
s(hr, "floatSafeRemainder");
var Sf = /* @__PURE__ */ Symbol("evaluating");
function Fo(e, r, i) {
  let o;
  Object.defineProperty(e, r, {
    get() {
      if (o !== Sf)
        return o === void 0 && (o = Sf, o = i()), o;
    },
    set(t) {
      Object.defineProperty(e, r, {
        value: t
        // configurable: true,
      });
    },
    configurable: !0
  });
}
s(Fo, "defineLazy");
function $y(e) {
  return Object.create(Object.getPrototypeOf(e), Object.getOwnPropertyDescriptors(e));
}
s($y, "objectClone");
function G(e, r, i) {
  Object.defineProperty(e, r, {
    value: i,
    writable: !0,
    enumerable: !0,
    configurable: !0
  });
}
s(G, "assignProp");
function ye(...e) {
  let r = {};
  for (let i of e) {
    let o = Object.getOwnPropertyDescriptors(i);
    Object.assign(r, o);
  }
  return Object.defineProperties({}, r);
}
s(ye, "mergeDefs");
function _y(e) {
  return ye(e._zod.def);
}
s(_y, "cloneDef");
function xy(e, r) {
  return r ? r.reduce((i, o) => i?.[o], e) : e;
}
s(xy, "getElementAtPath");
function wy(e) {
  let r = Object.keys(e), i = r.map((o) => e[o]);
  return Promise.all(i).then((o) => {
    let t = {};
    for (let n = 0; n < r.length; n++)
      t[r[n]] = o[n];
    return t;
  });
}
s(wy, "promiseAllObject");
function ky(e = 10) {
  let r = "abcdefghijklmnopqrstuvwxyz", i = "";
  for (let o = 0; o < e; o++)
    i += r[Math.floor(Math.random() * r.length)];
  return i;
}
s(ky, "randomString");
function oe(e) {
  return JSON.stringify(e);
}
s(oe, "esc");
function Lo(e) {
  return e.toLowerCase().trim().replace(/[^\w\s-]/g, "").replace(/[\s_-]+/g, "-").replace(/^-+|-+$/g, "");
}
s(Lo, "slugify");
var In = "captureStackTrace" in Error ? Error.captureStackTrace : (...e) => {
};
function Qe(e) {
  return typeof e == "object" && e !== null && !Array.isArray(e);
}
s(Qe, "isObject");
var Vo = /* @__PURE__ */ wt(() => {
  if (Q.jitless || typeof navigator < "u" && navigator?.userAgent?.includes("Cloudflare"))
    return !1;
  try {
    let e = Function;
    return new e(""), !0;
  } catch {
    return !1;
  }
});
function ge(e) {
  if (Qe(e) === !1)
    return !1;
  let r = e.constructor;
  if (r === void 0 || typeof r != "function")
    return !0;
  let i = r.prototype;
  return !(Qe(i) === !1 || Object.prototype.hasOwnProperty.call(i, "isPrototypeOf") === !1);
}
s(ge, "isPlainObject");
function gr(e) {
  return ge(e) ? { ...e } : Array.isArray(e) ? [...e] : e instanceof Map ? new Map(e) : e instanceof Set ? new Set(e) : e;
}
s(gr, "shallowClone");
function Iy(e) {
  let r = 0;
  for (let i in e)
    Object.prototype.hasOwnProperty.call(e, i) && r++;
  return r;
}
s(Iy, "numKeys");
var zy = /* @__PURE__ */ s((e) => {
  let r = typeof e;
  switch (r) {
    case "undefined":
      return "undefined";
    case "string":
      return "string";
    case "number":
      return Number.isNaN(e) ? "nan" : "number";
    case "boolean":
      return "boolean";
    case "function":
      return "function";
    case "bigint":
      return "bigint";
    case "symbol":
      return "symbol";
    case "object":
      return Array.isArray(e) ? "array" : e === null ? "null" : e.then && typeof e.then == "function" && e.catch && typeof e.catch == "function" ? "promise" : typeof Map < "u" && e instanceof Map ? "map" : typeof Set < "u" && e instanceof Set ? "set" : typeof Date < "u" && e instanceof Date ? "date" : typeof File < "u" && e instanceof File ? "file" : "object";
    default:
      throw new Error(`Unknown data type: ${r}`);
  }
}, "getParsedType"), vr = /* @__PURE__ */ new Set(["string", "number", "symbol"]), Mo = /* @__PURE__ */ new Set([
  "string",
  "number",
  "bigint",
  "boolean",
  "symbol",
  "undefined"
]);
function ve(e) {
  return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
s(ve, "escapeRegex");
function Z(e, r, i) {
  let o = new e._zod.constr(r ?? e._zod.def);
  return (!r || i?.parent) && (o._zod.parent = e), o;
}
s(Z, "clone");
function I(e) {
  let r = e;
  if (!r)
    return {};
  if (typeof r == "string")
    return { error: /* @__PURE__ */ s(() => r, "error") };
  if (r?.message !== void 0) {
    if (r?.error !== void 0)
      throw new Error("Cannot specify both `message` and `error` params");
    r.error = r.message;
  }
  return delete r.message, typeof r.error == "string" ? { ...r, error: /* @__PURE__ */ s(() => r.error, "error") } : r;
}
s(I, "normalizeParams");
function Sy(e) {
  let r;
  return new Proxy({}, {
    get(i, o, t) {
      return r ?? (r = e()), Reflect.get(r, o, t);
    },
    set(i, o, t, n) {
      return r ?? (r = e()), Reflect.set(r, o, t, n);
    },
    has(i, o) {
      return r ?? (r = e()), Reflect.has(r, o);
    },
    deleteProperty(i, o) {
      return r ?? (r = e()), Reflect.deleteProperty(r, o);
    },
    ownKeys(i) {
      return r ?? (r = e()), Reflect.ownKeys(r);
    },
    getOwnPropertyDescriptor(i, o) {
      return r ?? (r = e()), Reflect.getOwnPropertyDescriptor(r, o);
    },
    defineProperty(i, o, t) {
      return r ?? (r = e()), Reflect.defineProperty(r, o, t);
    }
  });
}
s(Sy, "createTransparentProxy");
function x(e) {
  return typeof e == "bigint" ? e.toString() + "n" : typeof e == "string" ? `"${e}"` : `${e}`;
}
s(x, "stringifyPrimitive");
function Bo(e) {
  return Object.keys(e).filter((r) => e[r]._zod.optin !== void 0 && e[r]._zod.optout === "optional");
}
s(Bo, "optionalKeys");
var Jo = {
  safeint: [Number.MIN_SAFE_INTEGER, Number.MAX_SAFE_INTEGER],
  int32: [-2147483648, 2147483647],
  uint32: [0, 4294967295],
  float32: [-34028234663852886e22, 34028234663852886e22],
  float64: [-Number.MAX_VALUE, Number.MAX_VALUE]
}, qo = {
  int64: [/* @__PURE__ */ BigInt("-9223372036854775808"), /* @__PURE__ */ BigInt("9223372036854775807")],
  uint64: [/* @__PURE__ */ BigInt(0), /* @__PURE__ */ BigInt("18446744073709551615")]
};
function Oy(e, r) {
  let i = e._zod.def, o = i.checks;
  if (o && o.length > 0)
    throw new Error(".pick() cannot be used on object schemas containing refinements");
  let n = ye(e._zod.def, {
    get shape() {
      let a = {};
      for (let c of Reflect.ownKeys(r)) {
        if (!Object.prototype.hasOwnProperty.call(i.shape, c))
          throw new Error(`Unrecognized key: "${String(c)}"`);
        r[c] && G(a, c, i.shape[c]);
      }
      return G(this, "shape", a), a;
    },
    checks: []
  });
  return Z(e, n);
}
s(Oy, "pick");
function jy(e, r) {
  let i = e._zod.def, o = i.checks;
  if (o && o.length > 0)
    throw new Error(".omit() cannot be used on object schemas containing refinements");
  let n = ye(e._zod.def, {
    get shape() {
      let a = { ...e._zod.def.shape };
      for (let c of Reflect.ownKeys(r)) {
        if (!Object.prototype.hasOwnProperty.call(i.shape, c))
          throw new Error(`Unrecognized key: "${String(c)}"`);
        r[c] && delete a[c];
      }
      return G(this, "shape", a), a;
    },
    checks: []
  });
  return Z(e, n);
}
s(jy, "omit");
function Ay(e, r) {
  if (!ge(r))
    throw new Error("Invalid input to extend: expected a plain object");
  let i = e._zod.def.checks;
  if (i && i.length > 0) {
    let n = e._zod.def.shape;
    for (let a of Reflect.ownKeys(r))
      if (Object.getOwnPropertyDescriptor(n, a) !== void 0)
        throw new Error("Cannot overwrite keys on object schemas containing refinements. Use `.safeExtend()` instead.");
  }
  let t = ye(e._zod.def, {
    get shape() {
      let n = { ...e._zod.def.shape, ...r };
      return G(this, "shape", n), n;
    }
  });
  return Z(e, t);
}
s(Ay, "extend");
function Py(e, r) {
  if (!ge(r))
    throw new Error("Invalid input to safeExtend: expected a plain object");
  let i = ye(e._zod.def, {
    get shape() {
      let o = { ...e._zod.def.shape, ...r };
      return G(this, "shape", o), o;
    }
  });
  return Z(e, i);
}
s(Py, "safeExtend");
function Dy(e, r) {
  if (!r?._zod?.def)
    throw new Error("Invalid input to merge: expected an object schema. To merge a plain shape, use `.extend()`.");
  if (e._zod.def.checks?.length)
    throw new Error(".merge() cannot be used on object schemas containing refinements. Use .safeExtend() instead.");
  let i = ye(e._zod.def, {
    get shape() {
      let o = { ...e._zod.def.shape, ...r._zod.def.shape };
      return G(this, "shape", o), o;
    },
    get catchall() {
      return r._zod.def.catchall;
    },
    checks: r._zod.def.checks ?? []
  });
  return Z(e, i);
}
s(Dy, "merge");
function Ny(e, r, i, o = "partial") {
  let n = r._zod.def.checks;
  if (n && n.length > 0)
    throw new Error(`.${o}() cannot be used on object schemas containing refinements`);
  let c = ye(r._zod.def, {
    get shape() {
      let u = r._zod.def.shape, l = { ...u };
      if (i)
        for (let f of Reflect.ownKeys(i)) {
          if (!Object.prototype.hasOwnProperty.call(u, f))
            throw new Error(`Unrecognized key: "${String(f)}"`);
          i[f] && (l[f] = e ? new e({
            type: "optional",
            innerType: u[f]
          }) : u[f]);
        }
      else
        for (let f of Reflect.ownKeys(u))
          l[f] = e ? new e({
            type: "optional",
            innerType: u[f]
          }) : u[f];
      return G(this, "shape", l), l;
    },
    checks: []
  });
  return Z(r, c);
}
s(Ny, "partial");
function Ty(e, r, i) {
  let o = ye(r._zod.def, {
    get shape() {
      let t = r._zod.def.shape, n = { ...t };
      if (i)
        for (let a of Reflect.ownKeys(i)) {
          if (!Object.prototype.hasOwnProperty.call(n, a))
            throw new Error(`Unrecognized key: "${String(a)}"`);
          i[a] && (n[a] = new e({
            type: "nonoptional",
            innerType: t[a]
          }));
        }
      else
        for (let a of Reflect.ownKeys(t))
          n[a] = new e({
            type: "nonoptional",
            innerType: t[a]
          });
      return G(this, "shape", n), n;
    }
  });
  return Z(r, o);
}
s(Ty, "required");
function Ee(e, r = 0) {
  if (e.aborted === !0)
    return !0;
  for (let i = r; i < e.issues.length; i++)
    if (e.issues[i]?.continue !== !0)
      return !0;
  return !1;
}
s(Ee, "aborted");
function Ko(e, r = 0) {
  if (e.aborted === !0)
    return !0;
  for (let i = r; i < e.issues.length; i++)
    if (e.issues[i]?.continue === !1)
      return !0;
  return !1;
}
s(Ko, "explicitlyAborted");
function ae(e, r) {
  return r.map((i) => {
    var o;
    return (o = i).path ?? (o.path = []), i.path.unshift(e), i;
  });
}
s(ae, "prefixIssues");
function $t(e) {
  return typeof e == "string" ? e : e?.message;
}
s($t, "unwrapMessage");
function zn(e, r, i) {
  var o;
  for (let t = r; t < e.length; t++)
    (o = e[t]).schema ?? (o.schema = i);
}
s(zn, "attachSchema");
function se(e, r, i) {
  var o;
  let t = e.inst?._zod?.traits;
  t?.has("$ZodType") && (t.has("$ZodCheck") ? (o = e).schema ?? (o.schema = e.inst) : e.schema = e.inst);
  let n = e.schema !== e.inst ? e.schema?._zod.def?.error : void 0, a = e.message ? e.message : $t(e.inst?._zod.def?.error?.(e)) ?? $t(n?.(e)) ?? $t(r?.error?.(e)) ?? $t(i.customError?.(e)) ?? $t(i.localeError?.(e)) ?? "Invalid input", { inst: c, schema: u, continue: l, input: f, ...m } = e;
  return m.path ?? (m.path = []), m.message = a, r?.reportInput && (m.input = f), m;
}
s(se, "finalizeIssue");
function yr(e) {
  return e instanceof Set ? "set" : e instanceof Map ? "map" : e instanceof File ? "file" : "unknown";
}
s(yr, "getSizableOrigin");
var Uy = /[\uD800-\uDBFF]/;
function Ye(e) {
  let r = e.length;
  if (!Uy.test(e))
    return r;
  let i = r;
  for (let o = 0; o < r - 1; o++)
    (e.charCodeAt(o) & 64512) === 55296 && (e.charCodeAt(o + 1) & 64512) === 56320 && (i--, o++);
  return i;
}
s(Ye, "codePointLength");
function br(e) {
  return Array.isArray(e) ? "array" : typeof e == "string" ? "string" : "unknown";
}
s(br, "getLengthableOrigin");
function w(e) {
  let r = typeof e;
  switch (r) {
    case "number":
      return Number.isNaN(e) ? "nan" : "number";
    case "object": {
      if (e === null)
        return "null";
      if (Array.isArray(e))
        return "array";
      let i = e;
      if (i && Object.getPrototypeOf(i) !== Object.prototype && "constructor" in i && i.constructor)
        return i.constructor.name;
    }
  }
  return r;
}
s(w, "parsedType");
function kt(...e) {
  let [r, i, o] = e;
  return typeof r == "string" ? {
    message: r,
    code: "custom",
    input: i,
    inst: o
  } : { ...r };
}
s(kt, "issue");
function Ey(e) {
  return Object.entries(e).filter(([r, i]) => Number.isNaN(Number.parseInt(r, 10))).map((r) => r[1]);
}
s(Ey, "cleanEnum");
function Of(e) {
  let r = atob(e), i = new Uint8Array(r.length);
  for (let o = 0; o < r.length; o++)
    i[o] = r.charCodeAt(o);
  return i;
}
s(Of, "base64ToUint8Array");
function jf(e) {
  let r = "";
  for (let i = 0; i < e.length; i++)
    r += String.fromCharCode(e[i]);
  return btoa(r);
}
s(jf, "uint8ArrayToBase64");
function Cy(e) {
  let r = e.replace(/-/g, "+").replace(/_/g, "/"), i = "=".repeat((4 - r.length % 4) % 4);
  return Of(r + i);
}
s(Cy, "base64urlToUint8Array");
function Zy(e) {
  return jf(e).replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, "");
}
s(Zy, "uint8ArrayToBase64url");
function Ry(e) {
  let r = e.replace(/^0x/, "");
  if (r.length % 2 !== 0)
    throw new Error("Invalid hex string length");
  let i = new Uint8Array(r.length / 2);
  for (let o = 0; o < r.length; o += 2)
    i[o / 2] = Number.parseInt(r.slice(o, o + 2), 16);
  return i;
}
s(Ry, "hexToUint8Array");
function Fy(e) {
  return Array.from(e).map((r) => r.toString(16).padStart(2, "0")).join("");
}
s(Fy, "uint8ArrayToHex");
var Ro = class {
  static {
    s(this, "Class");
  }
  constructor(...r) {
  }
};
function Wo(e, r) {
  for (let i in r) {
    let o = Object.getOwnPropertyDescriptor(r, i);
    o.get ? Object.defineProperty(e, i, { ...o, enumerable: !1 }) : Ly(e, i, o.value);
  }
}
s(Wo, "members");
function _t(e, r, i, o = !0) {
  return Object.defineProperty(e, r, { configurable: !0, writable: !0, enumerable: o, value: i }), i;
}
s(_t, "own");
function Go(e, r, i) {
  return _t(e, r, i, !1);
}
s(Go, "hide");
function Ly(e, r, i) {
  Object.defineProperty(e, r, {
    configurable: !0,
    get() {
      return this == null ? i : _t(this, r, i.bind(this));
    },
    set(o) {
      _t(this, r, o);
    }
  });
}
s(Ly, "defineBound");
function Vy(e, r) {
  let i = Object.getPrototypeOf(e);
  return r in i ? void 0 : i;
}
s(Vy, "claim");
var Zo, Ue = !1, My = {
  configurable: !0,
  get() {
    Ue = !0;
  }
};
function E(e, r, i) {
  let o = Object.getPrototypeOf(e._zod);
  if (r in o && Zo !== e._zod) {
    Zo = void 0;
    return;
  }
  Zo = e._zod, Object.defineProperty(o, r, {
    configurable: !0,
    get() {
      Object.defineProperty(this, r, My);
      let t = Ue;
      Ue = !1;
      try {
        let n = i(this);
        return Ue ? delete this[r] : Object.defineProperty(this, r, { configurable: !0, writable: !0, value: n }), Ue = Ue || t, n;
      } catch (n) {
        throw delete this[r], Ue = Ue || t, n;
      }
    },
    set(t) {
      Object.defineProperty(this, r, { configurable: !0, writable: !0, value: t });
    }
  });
}
s(E, "defineLazyInternal");
function By(e, r, i, o) {
  let t = Vy(e, r);
  t && Object.defineProperty(t, r, {
    configurable: !0,
    get() {
      let n = { configurable: !0, writable: !0, enumerable: o, value: void 0 };
      return Object.defineProperty(this, r, n), n.value = i(this), Object.defineProperty(this, r, n), n.value;
    },
    set(n) {
      Object.defineProperty(this, r, { configurable: !0, writable: !0, enumerable: o, value: n });
    }
  });
}
s(By, "installLazyProp");
var Sn = "~constantCatch";
function Xo(e) {
  let r = /* @__PURE__ */ s(() => e, "fn");
  return r[Sn] = !0, r;
}
s(Xo, "constantCatch");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/core.js
var Af, Qo = /* @__PURE__ */ Object.freeze({
  status: "aborted"
}), Ho = { value: void 0, enumerable: !1 }, Pf = "captureStackTrace" in Error ? Error : null;
function Jy(e) {
  let r = Pf;
  if (r) {
    let i = r.stackTraceLimit;
    if (typeof i == "number") {
      try {
        r.stackTraceLimit = 0;
      } catch {
        return Pf = null, new e();
      }
      try {
        return new e();
      } finally {
        r.stackTraceLimit = i;
      }
    }
  }
  return new e();
}
s(Jy, "newError");
// @__NO_SIDE_EFFECTS__
function h(e, r, i, o) {
  let t = {};
  function n(v) {
    this.def = v, this.constr = m, this.traits = /* @__PURE__ */ new Set();
  }
  s(n, "Internals"), n.prototype = t;
  let a = i, c = a && /* @__PURE__ */ new WeakSet();
  function u(v, y) {
    if (!v._zod) {
      Ho.value = new n(y);
      try {
        Object.defineProperty(v, "_zod", Ho);
      } finally {
        Ho.value = void 0;
      }
    }
    if (v._zod.traits.has(e))
      return;
    if (v._zod.traits.add(e), r(v, y), c) {
      let z = Object.getPrototypeOf(v), O = v._zod.constr.prototype, L = z;
      for (; L && L !== O; )
        L = Object.getPrototypeOf(L);
      let A = L ?? z;
      c.has(A) || (c.add(A), Wo(A, a));
    }
    let b = m.prototype;
    for (let z in b)
      Object.prototype.hasOwnProperty.call(b, z) && (z in v || (v[z] = b[z].bind(v)));
  }
  s(u, "init");
  let l = o?.Parent ?? Object;
  class f extends l {
    static {
      s(this, "Definition");
    }
  }
  Object.defineProperty(f, "name", { value: e });
  function m(v) {
    let y = o?.Parent ? Jy(f) : this;
    u(y, v);
    let b = y._zod.deferred;
    if (b) {
      for (let O of b)
        O();
      y._zod.deferred = void 0;
    }
    let z = globalThis.__zod_globalConfig?.postProcessor;
    return z && z(y), y;
  }
  return s(m, "_"), Object.defineProperty(m, "init", { value: u }), Object.defineProperty(m, Symbol.hasInstance, {
    value: /* @__PURE__ */ s((v) => o?.Parent && v instanceof o.Parent ? !0 : v?._zod?.traits?.has(e), "value")
  }), Object.defineProperty(m, "name", { value: e }), m;
}
s(h, "$constructor");
var Yo = /* @__PURE__ */ Symbol("zod_brand"), ce = class extends Error {
  static {
    s(this, "$ZodAsyncError");
  }
  constructor() {
    super("Encountered Promise during synchronous parse. Use .parseAsync() instead.");
  }
}, Ce = class extends Error {
  static {
    s(this, "$ZodEncodeError");
  }
  constructor(r) {
    super(`Encountered unidirectional transform during encode: ${r}`), this.name = "ZodEncodeError";
  }
};
(Af = globalThis).__zod_globalConfig ?? (Af.__zod_globalConfig = {});
var Q = globalThis.__zod_globalConfig;
function X(e) {
  return e && Object.assign(Q, e), Q;
}
s(X, "config");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/errors.js
function qy() {
  let e = this._zod;
  return e.message ?? (e.message = JSON.stringify(e.def, xt, 2)), e.message;
}
s(qy, "_getMessage");
function Ky(e) {
  this._zod.message = e;
}
s(Ky, "_setMessage");
var Wy = {
  get: qy,
  set: Ky,
  enumerable: !0,
  configurable: !0
}, ta = { value: void 0, enumerable: !1 }, ra = { value: void 0, enumerable: !1 }, Df = /* @__PURE__ */ new WeakSet([Object.prototype, Error.prototype]), Nf = /* @__PURE__ */ s((e, r) => {
  e.name = "$ZodError", ta.value = e._zod, Object.defineProperty(e, "_zod", ta), ra.value = r, Object.defineProperty(e, "issues", ra), ta.value = void 0, ra.value = void 0, Object.defineProperty(e, "message", Wy);
  let i = Object.getPrototypeOf(e);
  Df.has(i) || (Df.add(i), Object.defineProperty(i, "toString", {
    configurable: !0,
    enumerable: !1,
    get() {
      let o = /* @__PURE__ */ s(() => this.message, "value");
      return Object.defineProperty(this, "toString", { value: o, configurable: !0, writable: !0 }), o;
    },
    set(o) {
      Object.defineProperty(this, "toString", { value: o, configurable: !0, writable: !0 });
    }
  }));
}, "initializer"), et = h("$ZodError", Nf), ue = h("$ZodError", Nf, void 0, {
  Parent: Error
});
function Gy(e, r, i) {
  return Object.prototype.hasOwnProperty.call(e, r) || (r === "__proto__" ? Object.defineProperty(e, r, { value: i(), writable: !0, enumerable: !0, configurable: !0 }) : e[r] = i()), e[r];
}
s(Gy, "node");
function $r(e, r = (i) => i.message) {
  let i = {}, o = [];
  for (let t of e.issues)
    t.path.length > 0 ? Gy(i, t.path[0], () => []).push(r(t)) : o.push(r(t));
  return { formErrors: o, fieldErrors: i };
}
s($r, "flattenError");
function _r(e, r = (i) => i.message) {
  let i = { _errors: [] }, o = /* @__PURE__ */ s((t, n = []) => {
    for (let a of t.issues)
      if (a.code === "invalid_union" && a.errors.length)
        a.errors.map((c) => o({ issues: c }, [...n, ...a.path]));
      else if (a.code === "invalid_key")
        o({ issues: a.issues }, [...n, ...a.path]);
      else if (a.code === "invalid_element")
        o({ issues: a.issues }, [...n, ...a.path]);
      else {
        let c = [...n, ...a.path];
        if (c.length === 0)
          i._errors.push(r(a));
        else {
          let u = i, l = 0;
          for (; l < c.length; ) {
            let f = c[l], m = l === c.length - 1;
            if (f === "_errors") {
              m && u._errors.push(r(a)), l++;
              continue;
            }
            Object.prototype.hasOwnProperty.call(u, f) || Object.defineProperty(u, f, {
              value: { _errors: [] },
              enumerable: !0,
              writable: !0,
              configurable: !0
            });
            let v = u[f];
            m && v._errors.push(r(a)), u = v, l++;
          }
        }
      }
  }, "processError");
  return o(e), i;
}
s(_r, "formatError");
function na(e, r = (i) => i.message) {
  let i = { errors: [] }, o = /* @__PURE__ */ s((t, n = []) => {
    var a;
    for (let c of t.issues)
      if (c.code === "invalid_union" && c.errors.length)
        c.errors.map((u) => o({ issues: u }, [...n, ...c.path]));
      else if (c.code === "invalid_key")
        o({ issues: c.issues }, [...n, ...c.path]);
      else if (c.code === "invalid_element")
        o({ issues: c.issues }, [...n, ...c.path]);
      else {
        let u = [...n, ...c.path];
        if (u.length === 0) {
          i.errors.push(r(c));
          continue;
        }
        let l = i, f = 0;
        for (; f < u.length; ) {
          let m = u[f], v = f === u.length - 1;
          typeof m == "string" ? (l.properties ?? (l.properties = {}), Object.prototype.hasOwnProperty.call(l.properties, m) || Object.defineProperty(l.properties, m, {
            value: { errors: [] },
            enumerable: !0,
            writable: !0,
            configurable: !0
          }), l = l.properties[m]) : (l.items ?? (l.items = []), (a = l.items)[m] ?? (a[m] = { errors: [] }), l = l.items[m]), v && l.errors.push(r(c)), f++;
        }
      }
  }, "processError");
  return o(e), i;
}
s(na, "treeifyError");
function Tf(e) {
  let r = [], i = e.map((o) => typeof o == "object" ? o.key : o);
  for (let o of i)
    typeof o == "number" ? r.push(`[${o}]`) : typeof o == "symbol" ? r.push(`[${JSON.stringify(String(o))}]`) : /[^\w$]/.test(o) ? r.push(`[${JSON.stringify(o)}]`) : (r.length && r.push("."), r.push(o));
  return r.join("");
}
s(Tf, "toDotPath");
function ia(e) {
  let r = [], i = [...e.issues].sort((o, t) => (o.path ?? []).length - (t.path ?? []).length);
  for (let o of i)
    r.push(`\u2716 ${o.message}`), o.path?.length && r.push(`  \u2192 at ${Tf(o.path)}`);
  return r.join(`
`);
}
s(ia, "prettifyError");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/parse.js
function On(e, r) {
  return { callee: r?.callee ?? e, Err: r?.Err };
}
s(On, "finalizeParams");
var It = /* @__PURE__ */ s((e) => {
  let r = /* @__PURE__ */ s((i, o, t, n) => {
    let a = t ? { ...t, async: !1 } : { async: !1 }, c = i._zod.run({ value: o, issues: [] }, a);
    if (c instanceof Promise)
      throw new ce();
    if (c.issues.length) {
      let u = new (n?.Err ?? e)(c.issues.map((l) => se(l, a, X())));
      throw In(u, n?.callee ?? r), u;
    }
    return c.value;
  }, "fn");
  return r;
}, "_parse"), tt = /* @__PURE__ */ It(ue), zt = /* @__PURE__ */ s((e) => {
  let r = /* @__PURE__ */ s(async (i, o, t, n) => {
    let a = t ? { ...t, async: !0 } : { async: !0 }, c = i._zod.run({ value: o, issues: [] }, a);
    if (c instanceof Promise && (c = await c), c.issues.length) {
      let u = new (n?.Err ?? e)(c.issues.map((l) => se(l, a, X())));
      throw In(u, n?.callee ?? r), u;
    }
    return c.value;
  }, "fn");
  return r;
}, "_parseAsync"), jn = /* @__PURE__ */ zt(ue), St = /* @__PURE__ */ s((e) => (r, i, o) => {
  let t = o ? { ...o, async: !1 } : { async: !1 }, n = r._zod.run({ value: i, issues: [] }, t);
  if (n instanceof Promise)
    throw new ce();
  return n.issues.length ? {
    success: !1,
    error: new (e ?? et)(n.issues.map((a) => se(a, t, X())))
  } : { success: !0, data: n.value };
}, "_safeParse"), xr = /* @__PURE__ */ St(ue), Ot = /* @__PURE__ */ s((e) => async (r, i, o) => {
  let t = o ? { ...o, async: !0 } : { async: !0 }, n = r._zod.run({ value: i, issues: [] }, t);
  return n instanceof Promise && (n = await n), n.issues.length ? {
    success: !1,
    error: new e(n.issues.map((a) => se(a, t, X())))
  } : { success: !0, data: n.value };
}, "_safeParseAsync"), oa = /* @__PURE__ */ Ot(ue), Hy = /* @__PURE__ */ Symbol.for("zod.compile.invalid"), Qy = /* @__PURE__ */ Symbol.for("zod.compile.fallback"), aa = /* @__PURE__ */ s(((e, r, i) => {
  let o = e._zod.bag.validator;
  return o !== void 0 && o(r) !== Hy ? !0 : Yy(e, r, i);
}), "validate");
function Yy(e, r, i) {
  let o = i ? { ...i, async: !1 } : { async: !1 }, t = e._zod.bag.fallbackRun, n;
  if (t ? (o[Qy] = !0, n = t({ value: r, issues: [] }, o)) : n = e._zod.run({ value: r, issues: [] }, o), n instanceof Promise)
    throw new ce();
  return n.issues.length === 0;
}
s(Yy, "validateFallback");
var sa = /* @__PURE__ */ s(async (e, r, i) => {
  let o = i ? { ...i, async: !0 } : { async: !0 }, t = e._zod.run({ value: r, issues: [] }, o);
  return t instanceof Promise && (t = await t), t.issues.length === 0;
}, "validateAsync"), An = /* @__PURE__ */ s((e) => {
  let r = It(e), i = /* @__PURE__ */ s((o, t, n, a) => {
    let c = n ? { ...n, direction: "backward" } : { direction: "backward" };
    return r(o, t, c, On(i, a));
  }, "fn");
  return i;
}, "_encode"), De = /* @__PURE__ */ An(ue), Pn = /* @__PURE__ */ s((e) => {
  let r = It(e), i = /* @__PURE__ */ s((o, t, n, a) => r(o, t, n, On(i, a)), "fn");
  return i;
}, "_decode"), eb = /* @__PURE__ */ Pn(ue), Dn = /* @__PURE__ */ s((e) => {
  let r = zt(e), i = /* @__PURE__ */ s(async (o, t, n, a) => {
    let c = n ? { ...n, direction: "backward" } : { direction: "backward" };
    return await r(o, t, c, On(i, a));
  }, "fn");
  return i;
}, "_encodeAsync"), tb = /* @__PURE__ */ Dn(ue), Nn = /* @__PURE__ */ s((e) => {
  let r = zt(e), i = /* @__PURE__ */ s(async (o, t, n, a) => await r(o, t, n, On(i, a)), "fn");
  return i;
}, "_decodeAsync"), rb = /* @__PURE__ */ Nn(ue), Tn = /* @__PURE__ */ s((e) => (r, i, o) => {
  let t = o ? { ...o, direction: "backward" } : { direction: "backward" };
  return St(e)(r, i, t);
}, "_safeEncode"), nb = /* @__PURE__ */ Tn(ue), Un = /* @__PURE__ */ s((e) => (r, i, o) => St(e)(r, i, o), "_safeDecode"), ib = /* @__PURE__ */ Un(ue), En = /* @__PURE__ */ s((e) => async (r, i, o) => {
  let t = o ? { ...o, direction: "backward" } : { direction: "backward" };
  return Ot(e)(r, i, t);
}, "_safeEncodeAsync"), ob = /* @__PURE__ */ En(ue), Cn = /* @__PURE__ */ s((e) => async (r, i, o) => Ot(e)(r, i, o), "_safeDecodeAsync"), ab = /* @__PURE__ */ Cn(ue);

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/regexes.js
var re = {};
Pe(re, {
  base64: () => Ia,
  base64url: () => Zn,
  bigint: () => Da,
  boolean: () => Na,
  browserEmail: () => mb,
  cidrv4: () => wa,
  cidrv6: () => ka,
  creditCard: () => Rn,
  cuid: () => ua,
  cuid2: () => la,
  date: () => Oa,
  datetime: () => Aa,
  domain: () => vb,
  duration: () => ga,
  e164: () => Sa,
  email: () => ya,
  emoji: () => ba,
  extendedDuration: () => sb,
  guid: () => va,
  hex: () => bb,
  hostname: () => gb,
  html5Email: () => db,
  httpProtocol: () => za,
  idnEmail: () => pb,
  integer: () => wr,
  ipv4: () => $a,
  ipv6: () => _a,
  ksuid: () => pa,
  lowercase: () => Ea,
  mac: () => xa,
  md5_base64: () => _b,
  md5_base64url: () => xb,
  md5_hex: () => $b,
  nanoid: () => ma,
  nanoidOfLength: () => ha,
  null: () => Ta,
  number: () => Ze,
  rfc5322Email: () => fb,
  sha1_base64: () => kb,
  sha1_base64url: () => Ib,
  sha1_hex: () => wb,
  sha256_base64: () => Sb,
  sha256_base64url: () => Ob,
  sha256_hex: () => zb,
  sha384_base64: () => Ab,
  sha384_base64url: () => Pb,
  sha384_hex: () => jb,
  sha512_base64: () => Nb,
  sha512_base64url: () => Tb,
  sha512_hex: () => Db,
  string: () => Pa,
  time: () => ja,
  ulid: () => da,
  undefined: () => Ua,
  unicodeEmail: () => Uf,
  uppercase: () => Ca,
  uuid: () => rt,
  uuid4: () => cb,
  uuid6: () => ub,
  uuid7: () => lb,
  xid: () => fa
});
var ua = /^[cC][0-9a-z]{6,}$/, la = /^[0-9a-z]+$/, da = /^[0-7][0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{25}$/, fa = /^[0-9a-vA-V]{20}$/, pa = /^[A-Za-z0-9]{27}$/, ma = /^[a-zA-Z0-9_-]{21}$/;
function ha(e) {
  return new RegExp(`^[a-zA-Z0-9_-]{${e}}$`);
}
s(ha, "nanoidOfLength");
var ga = /^P(?:(\d+W)|(?!.*W)(?=\d|T\d)(\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+([.,]\d+)?S)?)?)$/, sb = /^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/, va = /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/, rt = /* @__PURE__ */ s((e) => e ? new RegExp(`^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${e}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`) : /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/, "uuid"), cb = /* @__PURE__ */ rt(4), ub = /* @__PURE__ */ rt(6), lb = /* @__PURE__ */ rt(7), ya = /^(?!\.)(?!.*\.\.)([A-Za-z0-9_'+\-\.]*)[A-Za-z0-9_+-]@([A-Za-z0-9][A-Za-z0-9\-]*\.)+[A-Za-z]{2,}$/, db = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/, fb = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/, Uf = /^[^\s@"]{1,64}@[^\s@]{1,255}$/u, pb = Uf, mb = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/, hb = "^[\\p{Extended_Pictographic}\\p{Emoji_Component}]+$";
function ba() {
  return new RegExp(hb, "u");
}
s(ba, "emoji");
var $a = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/, _a = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))$/, xa = /* @__PURE__ */ s((e) => {
  let r = ve(e ?? ":");
  return new RegExp(`^(?:[0-9A-F]{2}${r}){5}[0-9A-F]{2}$|^(?:[0-9a-f]{2}${r}){5}[0-9a-f]{2}$`);
}, "mac"), wa = /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/([0-9]|[1-2][0-9]|3[0-2])$/, ka = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/, Ia = /^$|^(?:[0-9a-zA-Z+/]{4})*(?:(?:[0-9a-zA-Z+/]{2}==)|(?:[0-9a-zA-Z+/]{3}=))?$/, Zn = /^[A-Za-z0-9_-]*$/, gb = /^(?=.{1,253}\.?$)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[-0-9a-zA-Z]{0,61}[0-9a-zA-Z])?)*\.?$/, vb = /^(?=.{1,253}$)([a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,63}$/, za = /^https?$/, Sa = /^\+[1-9]\d{6,14}$/, Rn = /^\d(?:[ -]?\d){11,18}$/, Ef = "(?:(?:\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-(?:(?:0[13578]|1[02])-(?:0[1-9]|[12]\\d|3[01])|(?:0[469]|11)-(?:0[1-9]|[12]\\d|30)|(?:02)-(?:0[1-9]|1\\d|2[0-8])))";
function yb(e) {
  return new RegExp(`^${e}$`);
}
s(yb, "anchor");
var Oa = /* @__PURE__ */ yb(Ef);
function ca(e) {
  let r = "(?:[01]\\d|2[0-3]):[0-5]\\d";
  return typeof e.precision == "number" ? e.precision === -1 ? `${r}` : e.precision === 0 ? `${r}:[0-5]\\d` : `${r}:[0-5]\\d\\.\\d{${e.precision}}` : e.seconds ? `${r}:[0-5]\\d(?:\\.\\d+)?` : `${r}(?::[0-5]\\d(?:\\.\\d+)?)?`;
}
s(ca, "timeSource");
function ja(e) {
  return new RegExp(`^${ca(e)}$`);
}
s(ja, "time");
function Aa(e) {
  let r = ["Z"];
  e.offset && r.push("([+-](?:[01]\\d|2[0-3]):[0-5]\\d)");
  let i = `${ca({ precision: e.precision, seconds: !0 })}(?:${r.join("|")})`, o = e.local ? `${i}|${ca({ precision: e.precision })}` : i;
  return new RegExp(`^${Ef}T(?:${o})$`);
}
s(Aa, "datetime");
var Pa = /* @__PURE__ */ s((e) => {
  let r = e ? `[\\s\\S]{${e?.minimum ?? 0},${e?.maximum ?? ""}}` : "[\\s\\S]*";
  return new RegExp(`^${r}$`);
}, "string"), Da = /^-?\d+n?$/, wr = /^-?\d+$/, Ze = /^-?\d+(?:\.\d+)?$/, Na = /^(?:true|false)$/i, Ta = /^null$/i;
var Ua = /^undefined$/i;
var Ea = /^[^A-Z]*$/, Ca = /^[^a-z]*$/, bb = /^[0-9a-fA-F]*$/;
function kr(e, r) {
  return new RegExp(`^[A-Za-z0-9+/]{${e}}${r}$`);
}
s(kr, "fixedBase64");
function Ir(e) {
  return new RegExp(`^[A-Za-z0-9_-]{${e}}$`);
}
s(Ir, "fixedBase64url");
var $b = /^[0-9a-fA-F]{32}$/, _b = /* @__PURE__ */ kr(22, "=="), xb = /* @__PURE__ */ Ir(22), wb = /^[0-9a-fA-F]{40}$/, kb = /* @__PURE__ */ kr(27, "="), Ib = /* @__PURE__ */ Ir(27), zb = /^[0-9a-fA-F]{64}$/, Sb = /* @__PURE__ */ kr(43, "="), Ob = /* @__PURE__ */ Ir(43), jb = /^[0-9a-fA-F]{96}$/, Ab = /* @__PURE__ */ kr(64, ""), Pb = /* @__PURE__ */ Ir(64), Db = /^[0-9a-fA-F]{128}$/, Nb = /* @__PURE__ */ kr(86, "=="), Tb = /* @__PURE__ */ Ir(86);

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/checks.js
var B = /* @__PURE__ */ h("$ZodCheck", (e, r) => {
  var i;
  e._zod ?? (e._zod = {}), e._zod.def = r, (i = e._zod).onattach ?? (i.onattach = []);
}), Za = /* @__PURE__ */ s((e) => {
  let r = e.value;
  return !kn(r) && r.size !== void 0;
}, "_whenHasSize"), Ra = /* @__PURE__ */ s((e) => {
  let r = e.value;
  return !kn(r) && r.length !== void 0;
}, "_whenHasLength"), Fn = {
  number: "number",
  bigint: "bigint",
  object: "date"
}, Ln = /* @__PURE__ */ h("$ZodCheckLessThan", (e, r) => {
  B.init(e, r);
  let i = Fn[typeof r.value];
  e._zod.onattach.push((o) => {
    let t = o._zod.bag, n = (r.inclusive ? t.maximum : t.exclusiveMaximum) ?? Number.POSITIVE_INFINITY;
    r.value < n && (r.inclusive ? t.maximum = r.value : t.exclusiveMaximum = r.value);
  }), e._zod.check = (o) => {
    (r.inclusive ? o.value <= r.value : o.value < r.value) || o.issues.push({
      origin: Fn[typeof o.value] ?? i,
      code: "too_big",
      maximum: typeof r.value == "object" ? r.value.getTime() : r.value,
      input: o.value,
      inclusive: r.inclusive,
      inst: e,
      continue: !r.abort
    });
  };
}), Vn = /* @__PURE__ */ h("$ZodCheckGreaterThan", (e, r) => {
  B.init(e, r);
  let i = Fn[typeof r.value];
  e._zod.onattach.push((o) => {
    let t = o._zod.bag, n = (r.inclusive ? t.minimum : t.exclusiveMinimum) ?? Number.NEGATIVE_INFINITY;
    r.value > n && (r.inclusive ? t.minimum = r.value : t.exclusiveMinimum = r.value);
  }), e._zod.check = (o) => {
    (r.inclusive ? o.value >= r.value : o.value > r.value) || o.issues.push({
      origin: Fn[typeof o.value] ?? i,
      code: "too_small",
      minimum: typeof r.value == "object" ? r.value.getTime() : r.value,
      input: o.value,
      inclusive: r.inclusive,
      inst: e,
      continue: !r.abort
    });
  };
}), Fa = /* @__PURE__ */ h("$ZodCheckMultipleOf", (e, r) => {
  B.init(e, r), e._zod.onattach.push((i) => {
    var o;
    (o = i._zod.bag).multipleOf ?? (o.multipleOf = r.value);
  }), e._zod.check = (i) => {
    if (typeof i.value != typeof r.value)
      throw new Error("Cannot mix number and bigint in multiple_of check.");
    (typeof i.value == "bigint" ? (
      // `value % 0n` throws, and nothing is a multiple of zero — the number branch already fails this way via NaN
      r.value !== BigInt(0) && i.value % r.value === BigInt(0)
    ) : hr(i.value, r.value) === 0) || i.issues.push({
      origin: typeof i.value,
      code: "not_multiple_of",
      divisor: r.value,
      input: i.value,
      inst: e,
      continue: !r.abort
    });
  };
}), La = /* @__PURE__ */ h("$ZodCheckNumberFormat", (e, r) => {
  B.init(e, r), r.format = r.format || "float64";
  let i = r.format?.includes("int"), o = i ? "int" : "number", [t, n] = Jo[r.format];
  e._zod.onattach.push((a) => {
    let c = a._zod.bag;
    c.format = r.format, c.minimum = t, c.maximum = n, i && (c.pattern = wr);
  }), e._zod.check = (a) => {
    let c = a.value;
    if (i) {
      if (!Number.isInteger(c)) {
        a.issues.push({
          expected: o,
          format: r.format,
          code: "invalid_type",
          continue: !1,
          input: c,
          inst: e
        });
        return;
      }
      if (!Number.isSafeInteger(c)) {
        c > 0 ? a.issues.push({
          input: c,
          code: "too_big",
          maximum: Number.MAX_SAFE_INTEGER,
          note: "Integers must be within the safe integer range.",
          inst: e,
          origin: o,
          inclusive: !0,
          continue: !r.abort
        }) : a.issues.push({
          input: c,
          code: "too_small",
          minimum: Number.MIN_SAFE_INTEGER,
          note: "Integers must be within the safe integer range.",
          inst: e,
          origin: o,
          inclusive: !0,
          continue: !r.abort
        });
        return;
      }
    }
    c < t && a.issues.push({
      origin: "number",
      input: c,
      code: "too_small",
      minimum: t,
      inclusive: !0,
      inst: e,
      continue: !r.abort
    }), c > n && a.issues.push({
      origin: "number",
      input: c,
      code: "too_big",
      maximum: n,
      inclusive: !0,
      inst: e,
      continue: !r.abort
    });
  };
}), Va = /* @__PURE__ */ h("$ZodCheckBigIntFormat", (e, r) => {
  B.init(e, r);
  let [i, o] = qo[r.format];
  e._zod.onattach.push((t) => {
    let n = t._zod.bag;
    n.format = r.format, n.minimum = i, n.maximum = o;
  }), e._zod.check = (t) => {
    let n = t.value;
    n < i && t.issues.push({
      origin: "bigint",
      input: n,
      code: "too_small",
      minimum: i,
      inclusive: !0,
      inst: e,
      continue: !r.abort
    }), n > o && t.issues.push({
      origin: "bigint",
      input: n,
      code: "too_big",
      maximum: o,
      inclusive: !0,
      inst: e,
      continue: !r.abort
    });
  };
}), Ma = /* @__PURE__ */ h("$ZodCheckMaxSize", (e, r) => {
  var i;
  B.init(e, r), (i = e._zod.def).when ?? (i.when = Za), e._zod.onattach.push((o) => {
    let t = o._zod.bag.maximum ?? Number.POSITIVE_INFINITY;
    r.maximum < t && (o._zod.bag.maximum = r.maximum);
  }), e._zod.check = (o) => {
    let t = o.value;
    t.size <= r.maximum || o.issues.push({
      origin: yr(t),
      code: "too_big",
      maximum: r.maximum,
      inclusive: !0,
      input: t,
      inst: e,
      continue: !r.abort
    });
  };
}), Ba = /* @__PURE__ */ h("$ZodCheckMinSize", (e, r) => {
  var i;
  B.init(e, r), (i = e._zod.def).when ?? (i.when = Za), e._zod.onattach.push((o) => {
    let t = o._zod.bag.minimum ?? Number.NEGATIVE_INFINITY;
    r.minimum > t && (o._zod.bag.minimum = r.minimum);
  }), e._zod.check = (o) => {
    let t = o.value;
    t.size >= r.minimum || o.issues.push({
      origin: yr(t),
      code: "too_small",
      minimum: r.minimum,
      inclusive: !0,
      input: t,
      inst: e,
      continue: !r.abort
    });
  };
}), Ja = /* @__PURE__ */ h("$ZodCheckSizeEquals", (e, r) => {
  var i;
  B.init(e, r), (i = e._zod.def).when ?? (i.when = Za), e._zod.onattach.push((o) => {
    let t = o._zod.bag;
    t.minimum = r.size, t.maximum = r.size, t.size = r.size;
  }), e._zod.check = (o) => {
    let t = o.value, n = t.size;
    if (n === r.size)
      return;
    let a = n > r.size;
    o.issues.push({
      origin: yr(t),
      ...a ? { code: "too_big", maximum: r.size } : { code: "too_small", minimum: r.size },
      inclusive: !0,
      exact: !0,
      input: o.value,
      inst: e,
      continue: !r.abort
    });
  };
}), qa = /* @__PURE__ */ h("$ZodCheckMaxLength", (e, r) => {
  var i;
  B.init(e, r), (i = e._zod.def).when ?? (i.when = Ra), e._zod.onattach.push((o) => {
    let t = o._zod.bag.maximum ?? Number.POSITIVE_INFINITY;
    r.maximum < t && (o._zod.bag.maximum = r.maximum);
  }), e._zod.check = (o) => {
    let t = o.value, n = t.length;
    if ((typeof t == "string" && n > r.maximum ? Ye(t) : n) <= r.maximum)
      return;
    let c = br(t);
    o.issues.push({
      origin: c,
      code: "too_big",
      maximum: r.maximum,
      inclusive: !0,
      input: t,
      inst: e,
      continue: !r.abort
    });
  };
}), Ka = /* @__PURE__ */ h("$ZodCheckMinLength", (e, r) => {
  var i;
  B.init(e, r), (i = e._zod.def).when ?? (i.when = Ra), e._zod.onattach.push((o) => {
    let t = o._zod.bag.minimum ?? Number.NEGATIVE_INFINITY;
    r.minimum > t && (o._zod.bag.minimum = r.minimum);
  }), e._zod.check = (o) => {
    let t = o.value, n = t.length;
    if ((typeof t == "string" && n >= r.minimum && n < r.minimum * 2 ? Ye(t) : n) >= r.minimum)
      return;
    let c = br(t);
    o.issues.push({
      origin: c,
      code: "too_small",
      minimum: r.minimum,
      inclusive: !0,
      input: t,
      inst: e,
      continue: !r.abort
    });
  };
}), Wa = /* @__PURE__ */ h("$ZodCheckLengthEquals", (e, r) => {
  var i;
  B.init(e, r), (i = e._zod.def).when ?? (i.when = Ra), e._zod.onattach.push((o) => {
    let t = o._zod.bag;
    t.minimum = r.length, t.maximum = r.length, t.length = r.length;
  }), e._zod.check = (o) => {
    let t = o.value, n = t.length, a = typeof t == "string" && n >= r.length && n <= r.length * 2 ? Ye(t) : n;
    if (a === r.length)
      return;
    let c = br(t), u = a > r.length;
    o.issues.push({
      origin: c,
      ...u ? { code: "too_big", maximum: r.length } : { code: "too_small", minimum: r.length },
      inclusive: !0,
      exact: !0,
      input: o.value,
      inst: e,
      continue: !r.abort
    });
  };
}), jt = /* @__PURE__ */ h("$ZodCheckStringFormat", (e, r) => {
  var i, o;
  B.init(e, r), e._zod.onattach.push((t) => {
    let n = t._zod.bag;
    n.format = r.format, r.pattern && (n.patterns ?? (n.patterns = /* @__PURE__ */ new Set()), n.patterns.add(r.pattern));
  }), r.pattern ? (i = e._zod).check ?? (i.check = (t) => {
    r.pattern.lastIndex = 0, !r.pattern.test(t.value) && t.issues.push({
      origin: "string",
      code: "invalid_format",
      format: r.format,
      input: t.value,
      ...r.pattern ? { pattern: r.pattern.toString() } : {},
      inst: e,
      continue: !r.abort
    });
  }) : (o = e._zod).check ?? (o.check = () => {
  });
}), Ga = /* @__PURE__ */ h("$ZodCheckRegex", (e, r) => {
  jt.init(e, r), e._zod.check = (i) => {
    r.pattern.lastIndex = 0, !r.pattern.test(i.value) && i.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "regex",
      input: i.value,
      pattern: r.pattern.toString(),
      inst: e,
      continue: !r.abort
    });
  };
}), Xa = /* @__PURE__ */ h("$ZodCheckLowerCase", (e, r) => {
  r.pattern ?? (r.pattern = Ea), jt.init(e, r);
}), Ha = /* @__PURE__ */ h("$ZodCheckUpperCase", (e, r) => {
  r.pattern ?? (r.pattern = Ca), jt.init(e, r);
}), Qa = /* @__PURE__ */ h("$ZodCheckIncludes", (e, r) => {
  B.init(e, r);
  let i = ve(r.includes), o = new RegExp(typeof r.position == "number" ? `^.{${r.position},}${i}` : i);
  r.pattern = o, e._zod.onattach.push((t) => {
    let n = t._zod.bag;
    n.patterns ?? (n.patterns = /* @__PURE__ */ new Set()), n.patterns.add(o);
  }), e._zod.check = (t) => {
    t.value.includes(r.includes, r.position) || t.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "includes",
      includes: r.includes,
      input: t.value,
      inst: e,
      continue: !r.abort
    });
  };
}), Ya = /* @__PURE__ */ h("$ZodCheckStartsWith", (e, r) => {
  B.init(e, r);
  let i = new RegExp(`^${ve(r.prefix)}.*`);
  r.pattern ?? (r.pattern = i), e._zod.onattach.push((o) => {
    let t = o._zod.bag;
    t.patterns ?? (t.patterns = /* @__PURE__ */ new Set()), t.patterns.add(i);
  }), e._zod.check = (o) => {
    o.value.startsWith(r.prefix) || o.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "starts_with",
      prefix: r.prefix,
      input: o.value,
      inst: e,
      continue: !r.abort
    });
  };
}), es = /* @__PURE__ */ h("$ZodCheckEndsWith", (e, r) => {
  B.init(e, r);
  let i = new RegExp(`.*${ve(r.suffix)}$`);
  r.pattern ?? (r.pattern = i), e._zod.onattach.push((o) => {
    let t = o._zod.bag;
    t.patterns ?? (t.patterns = /* @__PURE__ */ new Set()), t.patterns.add(i);
  }), e._zod.check = (o) => {
    o.value.endsWith(r.suffix) || o.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "ends_with",
      suffix: r.suffix,
      input: o.value,
      inst: e,
      continue: !r.abort
    });
  };
});
function Cf(e, r, i) {
  e.issues.length && r.issues.push(...ae(i, e.issues));
}
s(Cf, "handleCheckPropertyResult");
var Mn = /* @__PURE__ */ h("$ZodCheckProperty", (e, r) => {
  B.init(e, r), e._zod.check = (i) => {
    let o = r.schema._zod.run({
      value: i.value[r.property],
      issues: []
    }, {});
    if (o instanceof Promise)
      return o.then((t) => Cf(t, i, r.property));
    Cf(o, i, r.property);
  };
}), ts = /* @__PURE__ */ h("$ZodCheckMimeType", (e, r) => {
  B.init(e, r);
  let i = new Set(r.mime);
  e._zod.onattach.push((o) => {
    o._zod.bag.mime = r.mime;
  }), e._zod.check = (o) => {
    i.has(o.value.type) || o.issues.push({
      code: "invalid_value",
      values: r.mime,
      input: o.value.type,
      inst: e,
      continue: !r.abort
    });
  };
}), rs = /* @__PURE__ */ h("$ZodCheckOverwrite", (e, r) => {
  B.init(e, r), e._zod.check = (i) => {
    i.value = r.tx(i.value);
  };
});

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/doc.js
var nt = class {
  static {
    s(this, "Doc");
  }
  constructor(r = [], i = {}) {
    this.content = [], this.indent = 0, this.args = r, this.closed = i;
  }
  indented(r) {
    this.indent += 1, r(this), this.indent -= 1;
  }
  write(r) {
    if (typeof r == "function") {
      r(this, { execution: "sync" }), r(this, { execution: "async" });
      return;
    }
    let o = r.split(`
`).filter((a) => a), t = Math.min(...o.map((a) => a.length - a.trimStart().length)), n = o.map((a) => a.slice(t)).map((a) => " ".repeat(this.indent * 2) + a);
    for (let a of n)
      this.content.push(a);
  }
  compile() {
    let r = Function, i = this?.content ?? [""];
    return new r(...Object.keys(this.closed), `return function (${this.args.join(", ")}) {
${i.join(`
`)}
};`)(...Object.values(this.closed));
  }
};

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/versions.js
var ns = {
  major: 4,
  minor: 5,
  patch: 4
};

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/schemas.js
var P = /* @__PURE__ */ h("$ZodType", (e, r) => {
  var i;
  e ?? (e = {}), e._zod.def = r, e._zod.bag = e._zod.bag || {}, e._zod.version = ns;
  let o = e._zod.def.checks, t = e._zod.traits.has("$ZodCheck") ? [e, ...o ?? []] : o?.length ? [...o] : [];
  for (let n of t)
    for (let a of n._zod.onattach)
      a(e);
  if (t.length === 0)
    (i = e._zod).deferred ?? (i.deferred = []), e._zod.deferred?.push(() => {
      e._zod.run = e._zod.parse;
    });
  else {
    let n = /* @__PURE__ */ s((c, u, l) => {
      if (c.memo)
        return c;
      let f = Ee(c), m;
      for (let v of u) {
        if (v._zod.def.when) {
          if (Ko(c) || !v._zod.def.when(c))
            continue;
        } else if (f)
          continue;
        let y = c.issues.length, b = v._zod.check(c);
        if (b instanceof Promise && l?.async === !1)
          throw new ce();
        if (m || b instanceof Promise)
          m = (m ?? Promise.resolve()).then(async () => {
            await b, c.issues.length !== y && (zn(c.issues, y, e), f || (f = Ee(c, y)));
          });
        else {
          if (c.issues.length === y)
            continue;
          zn(c.issues, y, e), f || (f = Ee(c, y));
        }
      }
      return m ? m.then(() => c) : c;
    }, "runChecks"), a = /* @__PURE__ */ s((c, u, l) => {
      if (Ee(c))
        return c.aborted = !0, c;
      let f = n(u, t, l);
      if (f instanceof Promise) {
        if (l.async === !1)
          throw new ce();
        return f.then((m) => e._zod.parse(m, l));
      }
      return e._zod.parse(f, l);
    }, "handleCanaryResult");
    e._zod.run = (c, u) => {
      if (u.skipChecks)
        return e._zod.parse(c, u);
      if (u.direction === "backward") {
        let f = e._zod.parse({ value: c.value, issues: [] }, { ...u, skipChecks: !0 });
        return f instanceof Promise ? f.then((m) => a(m, c, u)) : a(f, c, u);
      }
      let l = e._zod.parse(c, u);
      if (l instanceof Promise) {
        if (u.async === !1)
          throw new ce();
        return l.then((f) => n(f, t, u));
      }
      return n(l, t, u);
    };
  }
}, {
  // Wrappers extend this by installing a richer factory over it; reading it eagerly would defeat the laziness.
  get "~standard"() {
    return Go(this, "~standard", Wn(this));
  },
  set "~standard"(e) {
    _t(this, "~standard", e);
  }
}), Rf = /* @__PURE__ */ s((e) => e.success ? { value: e.data } : { issues: e.error?.issues }, "toStandardResult");
function Wn(e) {
  return {
    validate: /* @__PURE__ */ s((r) => {
      try {
        return Rf(xr(e, r));
      } catch {
        return oa(e, r).then(Rf);
      }
    }, "validate"),
    vendor: "zod",
    version: 1
  };
}
s(Wn, "standardProps");
var it = /* @__PURE__ */ h("$ZodString", (e, r) => {
  P.init(e, r), e._zod.pattern = [...e?._zod.bag?.patterns ?? []].pop() ?? Pa(e._zod.bag), e._zod.parse = (i, o) => {
    if (r.coerce)
      try {
        i.value = String(i.value);
      } catch {
      }
    return typeof i.value == "string" || i.issues.push({
      expected: "string",
      code: "invalid_type",
      input: i.value,
      inst: e
    }), i;
  };
}), V = /* @__PURE__ */ h("$ZodStringFormat", (e, r) => {
  jt.init(e, r), it.init(e, r);
}), os = /* @__PURE__ */ h("$ZodGUID", (e, r) => {
  r.pattern ?? (r.pattern = va), V.init(e, r);
}), as = /* @__PURE__ */ h("$ZodUUID", (e, r) => {
  if (r.version) {
    let o = {
      v1: 1,
      v2: 2,
      v3: 3,
      v4: 4,
      v5: 5,
      v6: 6,
      v7: 7,
      v8: 8
    }[r.version];
    if (o === void 0)
      throw new Error(`Invalid UUID version: "${r.version}"`);
    r.pattern ?? (r.pattern = rt(o));
  } else
    r.pattern ?? (r.pattern = rt());
  V.init(e, r);
}), ss = /* @__PURE__ */ h("$ZodEmail", (e, r) => {
  r.pattern ?? (r.pattern = ya), V.init(e, r);
}), cs = 1, us = 2;
function Gn(e, r) {
  if (!r.normalize && r.protocol?.source === za.source && !/^https?:\/\//i.test(e))
    return cs;
  try {
    return new URL(e);
  } catch {
    return us;
  }
}
s(Gn, "parseURLObject");
var Ub = /[\t\n\r]/g;
function Xn(e) {
  return e.replace(Ub, "");
}
s(Xn, "stripTabAndNewline");
function Hn(e, r) {
  return r.lastIndex = 0, r.test(e.hostname);
}
s(Hn, "urlHostnameOk");
function Qn(e, r) {
  return r.lastIndex = 0, r.test(e.protocol.endsWith(":") ? e.protocol.slice(0, -1) : e.protocol);
}
s(Qn, "urlProtocolOk");
var ls = /* @__PURE__ */ h("$ZodURL", (e, r) => {
  V.init(e, r), e._zod.check = (i) => {
    try {
      let o = i.value.trim(), t = Gn(o, r);
      if (t === cs) {
        i.issues.push({
          code: "invalid_format",
          format: "url",
          note: "Invalid URL format",
          input: i.value,
          inst: e,
          continue: !r.abort
        });
        return;
      }
      if (t === us) {
        i.issues.push({
          code: "invalid_format",
          format: "url",
          input: i.value,
          inst: e,
          continue: !r.abort
        });
        return;
      }
      r.hostname && !Hn(t, r.hostname) && i.issues.push({
        code: "invalid_format",
        format: "url",
        note: "Invalid hostname",
        pattern: r.hostname.source,
        input: i.value,
        inst: e,
        continue: !r.abort
      }), r.protocol && !Qn(t, r.protocol) && i.issues.push({
        code: "invalid_format",
        format: "url",
        note: "Invalid protocol",
        pattern: r.protocol.source,
        input: i.value,
        inst: e,
        continue: !r.abort
      }), i.value = r.normalize ? t.href : Xn(o);
      return;
    } catch {
      i.issues.push({
        code: "invalid_format",
        format: "url",
        input: i.value,
        inst: e,
        continue: !r.abort
      });
    }
  };
}), ds = /* @__PURE__ */ h("$ZodEmoji", (e, r) => {
  r.pattern ?? (r.pattern = ba()), V.init(e, r);
}), fs = /* @__PURE__ */ h("$ZodNanoID", (e, r) => {
  if (r.length !== void 0 && (!Number.isInteger(r.length) || r.length < 1))
    throw new Error(`Invalid nanoid length: ${r.length}`);
  r.pattern ?? (r.pattern = r.length === void 0 ? ma : ha(r.length)), V.init(e, r);
}), ps = /* @__PURE__ */ h("$ZodCUID", (e, r) => {
  r.pattern ?? (r.pattern = ua), V.init(e, r);
}), ms = /* @__PURE__ */ h("$ZodCUID2", (e, r) => {
  r.pattern ?? (r.pattern = la), V.init(e, r);
}), hs = /* @__PURE__ */ h("$ZodULID", (e, r) => {
  r.pattern ?? (r.pattern = da), V.init(e, r);
}), gs = /* @__PURE__ */ h("$ZodXID", (e, r) => {
  r.pattern ?? (r.pattern = fa), V.init(e, r);
}), vs = /* @__PURE__ */ h("$ZodKSUID", (e, r) => {
  r.pattern ?? (r.pattern = pa), V.init(e, r);
}), ys = /* @__PURE__ */ h("$ZodISODateTime", (e, r) => {
  r.pattern ?? (r.pattern = Aa(r)), V.init(e, r), (r.local || r.precision === -1) && (e._zod.bag.laxFormat = !0, e._zod.onattach.push((i) => {
    i._zod.bag.laxFormat = !0;
  }));
}), bs = /* @__PURE__ */ h("$ZodISODate", (e, r) => {
  r.pattern ?? (r.pattern = Oa), V.init(e, r);
}), $s = /* @__PURE__ */ h("$ZodISOTime", (e, r) => {
  r.pattern ?? (r.pattern = ja(r)), V.init(e, r);
}), _s = /* @__PURE__ */ h("$ZodISODuration", (e, r) => {
  r.pattern ?? (r.pattern = ga), V.init(e, r);
}), xs = /* @__PURE__ */ h("$ZodIPv4", (e, r) => {
  r.pattern ?? (r.pattern = $a), V.init(e, r), e._zod.bag.format = "ipv4";
}), Eb = /^[0-9a-fA-F:.]+$/;
function zr(e) {
  if (!Eb.test(e))
    return !1;
  try {
    return new URL(`http://[${e}]`), !0;
  } catch {
    return !1;
  }
}
s(zr, "isValidIPv6");
var ws = /* @__PURE__ */ h("$ZodIPv6", (e, r) => {
  r.pattern ?? (r.pattern = _a), V.init(e, r), e._zod.bag.format = "ipv6", e._zod.check = (i) => {
    zr(i.value) || i.issues.push({
      code: "invalid_format",
      format: "ipv6",
      input: i.value,
      inst: e,
      continue: !r.abort
    });
  };
}), ks = /* @__PURE__ */ h("$ZodMAC", (e, r) => {
  r.pattern ?? (r.pattern = xa(r.delimiter)), V.init(e, r), e._zod.bag.format = "mac";
}), Is = /* @__PURE__ */ h("$ZodCIDRv4", (e, r) => {
  r.pattern ?? (r.pattern = wa), V.init(e, r);
});
function Yn(e) {
  let r = e.split("/");
  if (r.length !== 2)
    return !1;
  let [i, o] = r;
  if (!o)
    return !1;
  let t = Number(o);
  return `${t}` !== o || t < 0 || t > 128 ? !1 : zr(i);
}
s(Yn, "isValidCIDRv6");
var zs = /* @__PURE__ */ h("$ZodCIDRv6", (e, r) => {
  r.pattern ?? (r.pattern = ka), V.init(e, r), e._zod.check = (i) => {
    Yn(i.value) || i.issues.push({
      code: "invalid_format",
      format: "cidrv6",
      input: i.value,
      inst: e,
      continue: !r.abort
    });
  };
});
function Sr(e) {
  if (e === "")
    return !0;
  if (/\s/.test(e) || e.length % 4 !== 0)
    return !1;
  try {
    return atob(e), !0;
  } catch {
    return !1;
  }
}
s(Sr, "isValidBase64");
var Ss = /* @__PURE__ */ h("$ZodBase64", (e, r) => {
  r.pattern ?? (r.pattern = Ia), V.init(e, r), e._zod.bag.contentEncoding = "base64", e._zod.check = (i) => {
    Sr(i.value) || i.issues.push({
      code: "invalid_format",
      format: "base64",
      input: i.value,
      inst: e,
      continue: !r.abort
    });
  };
});
function ei(e) {
  if (!Zn.test(e))
    return !1;
  let r = e.replace(/[-_]/g, (o) => o === "-" ? "+" : "/"), i = r.padEnd(Math.ceil(r.length / 4) * 4, "=");
  return Sr(i);
}
s(ei, "isValidBase64URL");
var Os = /* @__PURE__ */ h("$ZodBase64URL", (e, r) => {
  r.pattern ?? (r.pattern = Zn), V.init(e, r), e._zod.bag.contentEncoding = "base64url", e._zod.check = (i) => {
    ei(i.value) || i.issues.push({
      code: "invalid_format",
      format: "base64url",
      input: i.value,
      inst: e,
      continue: !r.abort
    });
  };
}), js = /* @__PURE__ */ h("$ZodE164", (e, r) => {
  r.pattern ?? (r.pattern = Sa), V.init(e, r);
}), Cb = /[- ]/g;
function Zb(e) {
  let r = e.length, i = 1, o = 0;
  for (; r; ) {
    let t = +e[--r];
    i ^= 1, o += i ? [0, 2, 4, 6, 8, 1, 3, 5, 7, 9][t] : t;
  }
  return o % 10 === 0;
}
s(Zb, "isLuhnAlgo");
function ti(e) {
  return Rn.test(e) ? Zb(e.replace(Cb, "")) : !1;
}
s(ti, "isValidCreditCard");
var As = /* @__PURE__ */ h("$ZodCreditCard", (e, r) => {
  r.pattern ?? (r.pattern = Rn), V.init(e, r), e._zod.check = (i) => {
    ti(i.value) || i.issues.push({
      code: "invalid_format",
      format: "credit_card",
      input: i.value,
      inst: e,
      continue: !r.abort
    });
  };
});
function ri(e, r = null) {
  try {
    let i = e.split(".");
    if (i.length !== 3)
      return !1;
    let [o] = i;
    if (!o)
      return !1;
    let t = JSON.parse(atob(o));
    return !("typ" in t && t?.typ !== "JWT" || !t.alg || r && (!("alg" in t) || t.alg !== r));
  } catch {
    return !1;
  }
}
s(ri, "isValidJWT");
var Ps = /* @__PURE__ */ h("$ZodJWT", (e, r) => {
  V.init(e, r), e._zod.check = (i) => {
    ri(i.value, r.alg) || i.issues.push({
      code: "invalid_format",
      format: "jwt",
      input: i.value,
      inst: e,
      continue: !r.abort
    });
  };
}), Ds = /* @__PURE__ */ h("$ZodCustomStringFormat", (e, r) => {
  V.init(e, r), e._zod.check = (i) => {
    r.fn(i.value) || i.issues.push({
      code: "invalid_format",
      format: r.format,
      input: i.value,
      inst: e,
      continue: !r.abort
    });
  };
}), ni = /* @__PURE__ */ h("$ZodNumber", (e, r) => {
  P.init(e, r), e._zod.pattern = e._zod.bag.pattern ?? Ze, e._zod.parse = (i, o) => {
    if (r.coerce)
      try {
        i.value = Number(i.value);
      } catch {
      }
    let t = i.value;
    if (typeof t == "number" && !Number.isNaN(t) && Number.isFinite(t))
      return i;
    let n = typeof t == "number" ? Number.isNaN(t) ? "NaN" : Number.isFinite(t) ? void 0 : String(t) : void 0;
    return i.issues.push({
      expected: "number",
      code: "invalid_type",
      input: t,
      inst: e,
      ...n ? { received: n } : {}
    }), i;
  };
}), Ns = /* @__PURE__ */ h("$ZodNumberFormat", (e, r) => {
  La.init(e, r), ni.init(e, r);
}), Or = /* @__PURE__ */ h("$ZodBoolean", (e, r) => {
  P.init(e, r), e._zod.pattern = Na, e._zod.parse = (i, o) => {
    if (r.coerce)
      try {
        i.value = !!i.value;
      } catch {
      }
    let t = i.value;
    return typeof t == "boolean" || i.issues.push({
      expected: "boolean",
      code: "invalid_type",
      input: t,
      inst: e
    }), i;
  };
}), ii = /* @__PURE__ */ h("$ZodBigInt", (e, r) => {
  P.init(e, r), e._zod.pattern = Da, e._zod.parse = (i, o) => {
    if (r.coerce)
      try {
        i.value = BigInt(i.value);
      } catch {
      }
    return typeof i.value == "bigint" || i.issues.push({
      expected: "bigint",
      code: "invalid_type",
      input: i.value,
      inst: e
    }), i;
  };
}), Ts = /* @__PURE__ */ h("$ZodBigIntFormat", (e, r) => {
  Va.init(e, r), ii.init(e, r);
}), Us = /* @__PURE__ */ h("$ZodSymbol", (e, r) => {
  P.init(e, r), e._zod.parse = (i, o) => {
    let t = i.value;
    return typeof t == "symbol" || i.issues.push({
      expected: "symbol",
      code: "invalid_type",
      input: t,
      inst: e
    }), i;
  };
}), Es = /* @__PURE__ */ h("$ZodUndefined", (e, r) => {
  P.init(e, r), e._zod.pattern = Ua, e._zod.values = /* @__PURE__ */ new Set([void 0]), e._zod.parse = (i, o) => {
    let t = i.value;
    return typeof t > "u" || i.issues.push({
      expected: "undefined",
      code: "invalid_type",
      input: t,
      inst: e
    }), i;
  };
}), Cs = /* @__PURE__ */ h("$ZodNull", (e, r) => {
  P.init(e, r), e._zod.pattern = Ta, e._zod.values = /* @__PURE__ */ new Set([null]), e._zod.parse = (i, o) => {
    let t = i.value;
    return t === null || i.issues.push({
      expected: "null",
      code: "invalid_type",
      input: t,
      inst: e
    }), i;
  };
}), Zs = /* @__PURE__ */ h("$ZodAny", (e, r) => {
  P.init(e, r), e._zod.parse = (i) => i;
}), Rs = /* @__PURE__ */ h("$ZodUnknown", (e, r) => {
  P.init(e, r), e._zod.parse = (i) => i;
}), Fs = /* @__PURE__ */ h("$ZodNever", (e, r) => {
  P.init(e, r), e._zod.parse = (i, o) => (i.issues.push({
    expected: "never",
    code: "invalid_type",
    input: i.value,
    inst: e
  }), i);
}), Ls = /* @__PURE__ */ h("$ZodVoid", (e, r) => {
  P.init(e, r), e._zod.parse = (i, o) => {
    let t = i.value;
    return typeof t > "u" || i.issues.push({
      expected: "void",
      code: "invalid_type",
      input: t,
      inst: e
    }), i;
  };
}), jr = /* @__PURE__ */ h("$ZodDate", (e, r) => {
  P.init(e, r), e._zod.parse = (i, o) => {
    if (r.coerce)
      try {
        i.value = new Date(i.value);
      } catch {
      }
    let t = i.value, n = t instanceof Date;
    return n && !Number.isNaN(t.getTime()) || i.issues.push({
      expected: "date",
      code: "invalid_type",
      input: t,
      ...n ? { received: "Invalid Date" } : {},
      inst: e
    }), i;
  };
});
function Ff(e, r, i) {
  e.issues.length && r.issues.push(...ae(i, e.issues)), r.value[i] = e.value;
}
s(Ff, "handleArrayResult");
var Ar = /* @__PURE__ */ h("$ZodArray", (e, r) => {
  P.init(e, r);
  let i = Q.memoizer;
  i?.attach(e), e._zod.parse = (o, t) => {
    let n = o.value;
    if (!Array.isArray(n))
      return o.issues.push({
        expected: "array",
        code: "invalid_type",
        input: n,
        inst: e
      }), o;
    o.value = i ? i.alloc(e, o, Array(n.length), t) : Array(n.length);
    let a = [];
    for (let c = 0; c < n.length; c++) {
      let u = n[c], l = r.element._zod.run({
        value: u,
        issues: []
      }, t);
      l instanceof Promise ? a.push(l.then((f) => Ff(f, o, c))) : Ff(l, o, c);
    }
    return a.length ? Promise.all(a).then(() => o) : o;
  };
});
function Kn(e, r, i, o, t, n) {
  let a = i in o, c = n === "optional";
  if (!(!a && c && t === "optional")) {
    if (e.issues.length) {
      if (t !== void 0 && c && !a)
        return;
      r.issues.push(...ae(i, e.issues));
    }
    if (!a && t === void 0) {
      e.issues.length || r.issues.push({
        code: "invalid_type",
        expected: "nonoptional",
        input: void 0,
        path: [i]
      });
      return;
    }
    e.value === void 0 ? a && (r.value[i] = void 0) : r.value[i] = e.value;
  }
}
s(Kn, "handlePropertyResult");
var Rb = [];
function tp(e) {
  let r = Object.keys(e.shape), i = Object.getOwnPropertySymbols(e.shape), o = i.length ? i : Rb, t = o.length ? [...r, ...o] : r;
  for (let a of t)
    if (!e.shape?.[a]?._zod?.traits?.has("$ZodType"))
      throw new Error(`Invalid element at key "${String(a)}": expected a Zod schema`);
  let n = Bo(e.shape);
  return {
    ...e,
    allKeys: t,
    symbolKeys: o,
    // string-only: handleCatchall matches it against `for...in`, which never yields a symbol
    keySet: new Set(r),
    numKeys: r.length,
    optionalKeys: new Set(n)
  };
}
s(tp, "normalizeDef");
function rp(e, r, i, o, t, n) {
  let a = [], c = t.keySet, u = t.catchall._zod, l = u.def.type, f = u.optin, m = u.optout;
  for (let v in r) {
    if (c.has(v))
      continue;
    if (v === "__proto__") {
      l === "never" && a.push(v);
      continue;
    }
    if (l === "never") {
      a.push(v);
      continue;
    }
    let y = u.run({ value: r[v], issues: [] }, o);
    y instanceof Promise ? e.push(y.then((b) => Kn(b, i, v, r, f, m))) : Kn(y, i, v, r, f, m);
  }
  return a.length && i.issues.push({
    code: "unrecognized_keys",
    keys: a,
    input: r,
    inst: n,
    // Describes the shape of the input, not the validity of the parsed value, so it never aborts. The parse still fails; the schema's own checks just get to run first, and an enclosing intersection can reconcile the key against a sibling operand.
    continue: !0
  }), e.length ? Promise.all(e).then(() => i) : i;
}
s(rp, "handleCatchall");
var is = /* @__PURE__ */ new WeakMap(), be = /* @__PURE__ */ h("$ZodObject", (e, r) => {
  if (P.init(e, r), !Object.getOwnPropertyDescriptor(r, "shape")?.get) {
    let u = r.shape;
    is.set(r, u), Object.defineProperty(r, "shape", {
      get: /* @__PURE__ */ s(() => {
        let l = { ...u };
        return Object.defineProperty(r, "shape", {
          value: l
        }), is.set(r, l), l;
      }, "get")
    });
  }
  let o = wt(() => tp(r));
  E(e, "propValues", (u) => {
    let l = u.def.shape, f = {};
    for (let m in l) {
      let v = l[m]._zod;
      if (v.values) {
        Object.prototype.hasOwnProperty.call(f, m) || G(f, m, /* @__PURE__ */ new Set());
        for (let y of v.values)
          f[m].add(y);
        v.optin !== void 0 && f[m].add(void 0);
      }
    }
    return f;
  });
  let t = Qe, n = r.catchall, a, c = Q.memoizer;
  c?.attach(e), e._zod.parse = (u, l) => {
    a ?? (a = o.value);
    let f = u.value;
    if (!t(f))
      return u.issues.push({
        expected: "object",
        code: "invalid_type",
        input: f,
        inst: e
      }), u;
    u.value = c ? c.alloc(e, u, {}, l) : {};
    let m = [], v = a.shape;
    for (let y of a.allKeys) {
      if (y === "__proto__")
        continue;
      let b = v[y], z = b._zod.optin, O = b._zod.optout, L = b._zod.run({ value: f[y], issues: [] }, l);
      L instanceof Promise ? m.push(L.then((A) => Kn(A, u, y, f, z, O))) : Kn(L, u, y, f, z, O);
    }
    return n ? rp(m, f, u, l, o.value, e) : m.length ? Promise.all(m).then(() => u) : u;
  };
}), Vs = /* @__PURE__ */ h("$ZodObjectJIT", (e, r) => {
  be.init(e, r);
  let i = e._zod.parse, o = wt(() => tp(r)), t = Q.memoizer, n = /* @__PURE__ */ s((y) => {
    let b = o.value, z = b.symbolKeys, O = new nt(["payload", "ctx"], { shape: y, inst: e, memo: t, syms: z }), L = /* @__PURE__ */ s((q) => `shape[${q}]._zod.run({ value: input[${q}], issues: [] }, ctx)`, "parseStr"), A = /* @__PURE__ */ s((q, R) => `
          for (let i = 0; i < ${q}.issues.length; i++) {
            const iss = ${q}.issues[i];
            iss.path = iss.path ? [${R}, ...iss.path] : [${R}];
            payload.issues.push(iss);
          }`, "prefixStr");
    O.write("const input = payload.value;");
    let T = /* @__PURE__ */ Object.create(null), J = 0;
    for (let q of b.allKeys)
      T[q] = `key_${J++}`;
    O.write(t ? "const newResult = memo.alloc(inst, payload, {}, ctx);" : "const newResult = {};");
    for (let q of b.allKeys) {
      if (q === "__proto__")
        continue;
      let R = T[q], ee = typeof q == "symbol" ? `syms[${z.indexOf(q)}]` : oe(q), sr = `${ee} in input`, pf = y[q], mf = pf?._zod?.optin, hf = mf !== void 0, Jv = pf?._zod?.optout === "optional";
      if (O.write(`const ${R} = ${L(ee)};`), hf && Jv) {
        let qv = mf === "optional" ? `${R}_present` : `${R}.value !== undefined || ${R}_present`;
        O.write(`
        const ${R}_present = ${sr};
        if (!${R}.issues.length || ${R}_present) {
          if (${R}.issues.length) {${A(R, ee)}
          }

          if (${qv}) {
            newResult[${ee}] = ${R}.value;
          }
        }

      `);
      } else hf ? O.write(`
        if (${R}.issues.length) {${A(R, ee)}
        }
        
        if (${R}.value === undefined) {
          if (${sr}) {
            newResult[${ee}] = undefined;
          }
        } else {
          newResult[${ee}] = ${R}.value;
        }

      `) : O.write(`
        const ${R}_present = ${sr};
        if (${R}.issues.length) {${A(R, ee)}
        }
        if (!${R}_present && !${R}.issues.length) {
          payload.issues.push({
            code: "invalid_type",
            expected: "nonoptional",
            input: undefined,
            path: [${ee}]
          });
        }

        if (${R}_present) {
          newResult[${ee}] = ${R}.value;
        }

      `);
    }
    return O.write("payload.value = newResult;"), O.write("return payload;"), O.compile();
  }, "generateFastpass"), a, c = Qe, u = !Q.jitless, f = u && Vo.value, m = r.catchall, v;
  e._zod.parse = (y, b) => {
    v ?? (v = o.value);
    let z = y.value;
    return c(z) ? u && f && b?.async === !1 && b.jitless !== !0 ? (a || (a = n(r.shape)), y = a(y, b), m ? rp([], z, y, b, v, e) : y) : i(y, b) : (y.issues.push({
      expected: "object",
      code: "invalid_type",
      input: z,
      inst: e
    }), y);
  };
});
function Lf(e, r, i, o) {
  for (let n of e)
    if (n.issues.length === 0)
      return r.value = n.value, r;
  let t = e.filter((n) => !Ee(n));
  return t.length === 1 ? (r.value = t[0].value, t[0]) : (r.issues.push({
    code: "invalid_union",
    input: r.value,
    inst: i,
    errors: e.map((n) => n.issues.map((a) => se(a, o, X())))
  }), r);
}
s(Lf, "handleUnionResults");
var Ie = /* @__PURE__ */ h("$ZodUnion", (e, r) => {
  P.init(e, r), E(e, "optin", (o) => o.def.options.some((t) => t._zod.optin === "defaulted") ? "defaulted" : o.def.options.some((t) => t._zod.optin !== void 0) ? "optional" : void 0), E(e, "optout", (o) => o.def.options.some((t) => t._zod.optout === "optional") ? "optional" : void 0), E(e, "values", (o) => {
    if (o.def.options.every((t) => t._zod.values))
      return new Set(o.def.options.flatMap((t) => Array.from(t._zod.values)));
  }), E(e, "pattern", (o) => {
    if (o.def.options.every((t) => t._zod.pattern)) {
      let t = o.def.options.map((n) => n._zod.pattern);
      return new RegExp(`^(${t.map((n) => mr(n.source)).join("|")})$`);
    }
  });
  let i = r.options.length === 1 ? r.options[0]._zod.run : null;
  e._zod.parse = (o, t) => {
    if (i)
      return i(o, t);
    let n = !1, a = [];
    for (let c of r.options) {
      let u = c._zod.run({
        value: o.value,
        issues: []
      }, t);
      if (u instanceof Promise)
        a.push(u), n = !0;
      else {
        if (u.issues.length === 0)
          return u;
        a.push(u);
      }
    }
    return n ? Promise.all(a).then((c) => Lf(c, o, e, t)) : Lf(a, o, e, t);
  };
});
function Vf(e, r, i, o) {
  let t = [];
  for (let n = 0; n < e.length; n++)
    e[n].issues.length === 0 && t.push(n);
  return t.length === 1 ? (r.value = e[t[0]].value, r) : (t.length === 0 ? r.issues.push({
    code: "invalid_union",
    input: r.value,
    inst: i,
    errors: e.map((n) => n.issues.map((a) => se(a, o, X())))
  }) : r.issues.push({
    code: "invalid_union",
    input: r.value,
    inst: i,
    errors: [],
    inclusive: !1,
    matches: t
  }), r);
}
s(Vf, "handleExclusiveUnionResults");
var Ms = /* @__PURE__ */ h("$ZodXor", (e, r) => {
  Ie.init(e, r), r.inclusive = !1;
  let i = r.options.length === 1 ? r.options[0]._zod.run : null;
  e._zod.parse = (o, t) => {
    if (i)
      return i(o, t);
    let n = !1, a = [];
    for (let c of r.options) {
      let u = c._zod.run({
        value: o.value,
        issues: []
      }, t);
      u instanceof Promise ? (a.push(u), n = !0) : a.push(u);
    }
    return n ? Promise.all(a).then((c) => Vf(c, o, e, t)) : Vf(a, o, e, t);
  };
});
function Bs(e, r) {
  let i = e._zod, o = i.bag.optionsMap;
  if (!o) {
    o = /* @__PURE__ */ new Map();
    let { options: t, discriminator: n } = i.def;
    for (let a of t)
      for (let c of a._zod.propValues?.[n] ?? [])
        o.has(c) || o.set(c, a);
    i.bag.optionsMap = o;
  }
  return o.get(r);
}
s(Bs, "getDiscriminatedOption");
var Pt = /* @__PURE__ */ h("$ZodDiscriminatedUnion", (e, r) => {
  r.inclusive = !1, Ie.init(e, r);
  let i = e._zod.parse;
  E(e, "propValues", (t) => {
    let n = {};
    for (let a of t.def.options) {
      let c = a._zod.propValues;
      if (!c || Object.keys(c).length === 0)
        throw new Error(`Invalid discriminated union option at index "${t.def.options.indexOf(a)}"`);
      for (let [u, l] of Object.entries(c)) {
        Object.prototype.hasOwnProperty.call(n, u) || G(n, u, /* @__PURE__ */ new Set());
        for (let f of l)
          n[u].add(f);
      }
    }
    return n;
  }), r.options.forEach((t, n) => {
    let a = is.get(t._zod.def);
    if (a && !Object.prototype.hasOwnProperty.call(a, r.discriminator))
      throw new Error(`Invalid discriminated union option at index "${n}"`);
  });
  let o = wt(() => {
    let t = r.options, n = /* @__PURE__ */ new Map();
    for (let a of t) {
      let c = a._zod.propValues?.[r.discriminator];
      if (!c || c.size === 0)
        throw new Error(`Invalid discriminated union option at index "${r.options.indexOf(a)}"`);
      for (let u of c) {
        if (n.has(u))
          throw new Error(`Duplicate discriminator value "${String(u)}"`);
        n.set(u, a);
      }
    }
    return n;
  });
  e._zod.parse = (t, n) => {
    let a = t.value;
    if (!Qe(a))
      return t.issues.push({
        code: "invalid_type",
        expected: "object",
        input: a,
        inst: e
      }), t;
    let c = o.value.get(a?.[r.discriminator]);
    return c ? c._zod.run(t, n) : r.unionFallback || n.direction === "backward" ? i(t, n) : (t.issues.push({
      code: "invalid_union",
      errors: [],
      note: "No matching discriminator",
      discriminator: r.discriminator,
      options: Array.from(o.value.keys()),
      input: a,
      path: [r.discriminator],
      inst: e
    }), t);
  };
}), Js = /* @__PURE__ */ h("$ZodIntersection", (e, r) => {
  P.init(e, r), e._zod.parse = (i, o) => {
    let t = i.value, n = r.left._zod.run({ value: t, issues: [] }, o), a = r.right._zod.run({ value: t, issues: [] }, o);
    return n instanceof Promise || a instanceof Promise ? Promise.all([n, a]).then(([u, l]) => Mf(i, u, l)) : Mf(i, n, a);
  };
});
function At(e, r) {
  if (e === r)
    return { valid: !0, data: e };
  if (e instanceof Date && r instanceof Date && +e == +r)
    return { valid: !0, data: e };
  if (ge(e) && ge(r)) {
    let i = Object.keys(r), o = Object.keys(e).filter((n) => i.indexOf(n) !== -1), t = { ...e, ...r };
    Object.prototype.hasOwnProperty.call(t, "__proto__") && delete t.__proto__;
    for (let n of o) {
      if (n === "__proto__")
        continue;
      let a = At(e[n], r[n]);
      if (!a.valid)
        return {
          valid: !1,
          mergeErrorPath: [n, ...a.mergeErrorPath]
        };
      t[n] = a.data;
    }
    return { valid: !0, data: t };
  }
  if (Array.isArray(e) && Array.isArray(r)) {
    if (e.length !== r.length)
      return { valid: !1, mergeErrorPath: [] };
    let i = [];
    for (let o = 0; o < e.length; o++) {
      let t = e[o], n = r[o], a = At(t, n);
      if (!a.valid)
        return {
          valid: !1,
          mergeErrorPath: [o, ...a.mergeErrorPath]
        };
      i.push(a.data);
    }
    return { valid: !0, data: i };
  }
  return { valid: !1, mergeErrorPath: [] };
}
s(At, "mergeValues");
function Mf(e, r, i) {
  let o = /* @__PURE__ */ new Map(), t, n = /* @__PURE__ */ new Map(), a = /* @__PURE__ */ s((l, f) => {
    let m;
    if (l.code === "unrecognized_keys" && !l.path?.length)
      t ?? (t = l), m = l.keys;
    else if (l.code === "invalid_key" && l.origin === "record" && l.path?.length === 1) {
      let v = String(l.path[0]);
      n.has(v) || n.set(v, l), m = [v];
    } else
      return !1;
    for (let v of m)
      o.has(v) || o.set(v, {}), o.get(v)[f] = !0;
    return !0;
  }, "collect");
  for (let l of r.issues)
    a(l, "l") || e.issues.push(l);
  for (let l of i.issues)
    a(l, "r") || e.issues.push(l);
  let c = [...o].filter(([, l]) => l.l && l.r).map(([l]) => l);
  if (c.length) {
    let l = t ? c.filter((f) => t.keys.includes(f)) : [];
    l.length && e.issues.push({ ...t, keys: l });
    for (let f of c)
      !l.includes(f) && n.has(f) && e.issues.push(n.get(f));
  }
  let u = At(r.value, i.value);
  if (!u.valid) {
    if (Ee(e))
      return e;
    throw new Error(`Unmergable intersection. Error path: ${JSON.stringify(u.mergeErrorPath)}`);
  }
  return e.value = u.data, e;
}
s(Mf, "handleIntersectionResults");
var Dt = /* @__PURE__ */ h("$ZodTuple", (e, r) => {
  P.init(e, r);
  let i = r.items, o = Q.memoizer;
  o?.attach(e), e._zod.parse = (t, n) => {
    let a = t.value;
    if (!Array.isArray(a))
      return t.issues.push({
        input: a,
        inst: e,
        expected: "tuple",
        code: "invalid_type"
      }), t;
    t.value = o ? o.alloc(e, t, [], n) : [];
    let c = [], u = Bf(i, "optin"), l = Bf(i, "optout");
    if (!r.rest) {
      if (a.length < u)
        return t.issues.push({
          code: "too_small",
          minimum: u,
          inclusive: !0,
          input: a,
          inst: e,
          origin: "array"
        }), t;
      a.length > i.length && t.issues.push({
        code: "too_big",
        maximum: i.length,
        inclusive: !0,
        input: a,
        inst: e,
        origin: "array"
      });
    }
    let f = new Array(i.length);
    for (let m = 0; m < i.length; m++) {
      let v = i[m]._zod.run({ value: a[m], issues: [] }, n);
      v instanceof Promise ? c.push(v.then((y) => {
        f[m] = y;
      })) : f[m] = v;
    }
    if (r.rest) {
      let m = i.length - 1, v = a.slice(i.length);
      for (let y of v) {
        m++;
        let b = r.rest._zod.run({ value: y, issues: [] }, n);
        b instanceof Promise ? c.push(b.then((z) => Jf(z, t, m))) : Jf(b, t, m);
      }
    }
    return c.length ? Promise.all(c).then(() => qf(f, t, i, a, l)) : qf(f, t, i, a, l);
  };
});
function Bf(e, r) {
  for (let i = e.length - 1; i >= 0; i--)
    if (!(r === "optin" ? e[i]._zod.optin !== void 0 : e[i]._zod.optout === "optional"))
      return i + 1;
  return 0;
}
s(Bf, "getTupleOptStart");
function Jf(e, r, i) {
  e.issues.length && r.issues.push(...ae(i, e.issues)), r.value[i] = e.value;
}
s(Jf, "handleTupleResult");
function qf(e, r, i, o, t) {
  for (let n = 0; n < i.length; n++) {
    let a = e[n], c = n < o.length;
    if (!c && n >= t && i[n]._zod.optin === "optional") {
      r.value.length = n;
      break;
    }
    if (a.issues.length) {
      if (!c && n >= t) {
        r.value.length = n;
        break;
      }
      r.issues.push(...ae(n, a.issues));
    }
    r.value[n] = a.value;
  }
  for (let n = r.value.length - 1; n >= o.length && (i[n]._zod.optout === "optional" && r.value[n] === void 0); n--)
    r.value.length = n;
  return r;
}
s(qf, "handleTupleResults");
var Pr = /* @__PURE__ */ h("$ZodRecord", (e, r) => {
  P.init(e, r);
  let i = Q.memoizer;
  i?.attach(e), e._zod.parse = (o, t) => {
    let n = o.value;
    if (!ge(n))
      return o.issues.push({
        expected: "record",
        code: "invalid_type",
        input: n,
        inst: e
      }), o;
    let a = [], c = r.keyType._zod.values;
    if (c && !r.partial) {
      o.value = i ? i.alloc(e, o, {}, t) : {};
      let u = /* @__PURE__ */ new Set();
      for (let f of c)
        if (typeof f == "string" || typeof f == "number" || typeof f == "symbol") {
          if (u.add(typeof f == "number" ? f.toString() : f), f === "__proto__")
            continue;
          let m = r.keyType._zod.run({ value: f, issues: [] }, t);
          if (m instanceof Promise)
            throw new Error("Async schemas not supported in object keys currently");
          if (m.issues.length) {
            o.issues.push({
              code: "invalid_key",
              origin: "record",
              issues: m.issues.map((b) => se(b, t, X())),
              input: f,
              path: [f],
              inst: e
            });
            continue;
          }
          let v = m.value;
          if (v === "__proto__")
            continue;
          let y = r.valueType._zod.run({ value: n[f], issues: [] }, t);
          y instanceof Promise ? a.push(y.then((b) => {
            b.issues.length && o.issues.push(...ae(f, b.issues)), o.value[v] = b.value;
          })) : (y.issues.length && o.issues.push(...ae(f, y.issues)), o.value[v] = y.value);
        }
      let l;
      for (let f in n)
        if (!u.has(f))
          if (r.mode === "loose") {
            if (f === "__proto__")
              continue;
            o.value[f] = n[f];
          } else
            l = l ?? [], l.push(f);
      l && l.length > 0 && o.issues.push({
        code: "unrecognized_keys",
        input: n,
        inst: e,
        keys: l,
        continue: !0
      });
    } else {
      o.value = i ? i.alloc(e, o, {}, t) : {};
      let u;
      for (let l of Reflect.ownKeys(n)) {
        if (l === "__proto__" || !Object.prototype.propertyIsEnumerable.call(n, l))
          continue;
        let f = r.keyType._zod.run({ value: l, issues: [] }, t);
        if (f instanceof Promise)
          throw new Error("Async schemas not supported in object keys currently");
        if (typeof l == "string" && Ze.test(l) && f.issues.length) {
          let b = r.keyType._zod.run({ value: Number(l), issues: [] }, t);
          if (b instanceof Promise)
            throw new Error("Async schemas not supported in object keys currently");
          b.issues.length === 0 && (f = b);
        }
        if (f.issues.length) {
          r.mode === "loose" ? o.value[l] = n[l] : c ? (u = u ?? [], u.push(l)) : o.issues.push({
            code: "invalid_key",
            origin: "record",
            issues: f.issues.map((b) => se(b, t, X())),
            input: l,
            path: [l],
            inst: e
          });
          continue;
        }
        let v = f.value;
        if (v === "__proto__")
          continue;
        let y = r.valueType._zod.run({ value: n[l], issues: [] }, t);
        y instanceof Promise ? a.push(y.then((b) => {
          b.issues.length && o.issues.push(...ae(l, b.issues)), o.value[v] = b.value;
        })) : (y.issues.length && o.issues.push(...ae(l, y.issues)), o.value[v] = y.value);
      }
      u && u.length > 0 && o.issues.push({
        code: "unrecognized_keys",
        input: n,
        inst: e,
        keys: u,
        continue: !0
      });
    }
    return a.length ? Promise.all(a).then(() => o) : o;
  };
}), qs = /* @__PURE__ */ h("$ZodMap", (e, r) => {
  P.init(e, r);
  let i = Q.memoizer;
  i?.attach(e), e._zod.parse = (o, t) => {
    let n = o.value;
    if (!(n instanceof Map))
      return o.issues.push({
        expected: "map",
        code: "invalid_type",
        input: n,
        inst: e
      }), o;
    let a = [];
    o.value = i ? i.alloc(e, o, /* @__PURE__ */ new Map(), t) : /* @__PURE__ */ new Map();
    for (let [c, u] of n) {
      let l = r.keyType._zod.run({ value: c, issues: [] }, t), f = r.valueType._zod.run({ value: u, issues: [] }, t);
      l instanceof Promise || f instanceof Promise ? a.push(Promise.all([l, f]).then(([m, v]) => {
        Kf(m, v, o, c, n, e, t);
      })) : Kf(l, f, o, c, n, e, t);
    }
    return a.length ? Promise.all(a).then(() => o) : o;
  };
});
function Kf(e, r, i, o, t, n, a) {
  e.issues.length && (vr.has(typeof o) ? i.issues.push(...ae(o, e.issues)) : i.issues.push({
    code: "invalid_key",
    origin: "map",
    input: t,
    inst: n,
    issues: e.issues.map((c) => se(c, a, X()))
  })), r.issues.length && (vr.has(typeof o) ? i.issues.push(...ae(o, r.issues)) : i.issues.push({
    origin: "map",
    code: "invalid_element",
    input: t,
    inst: n,
    key: o,
    issues: r.issues.map((c) => se(c, a, X()))
  })), i.value.set(e.value, r.value);
}
s(Kf, "handleMapResult");
var Ks = /* @__PURE__ */ h("$ZodSet", (e, r) => {
  P.init(e, r);
  let i = Q.memoizer;
  i?.attach(e), e._zod.parse = (o, t) => {
    let n = o.value;
    if (!(n instanceof Set))
      return o.issues.push({
        input: n,
        inst: e,
        expected: "set",
        code: "invalid_type"
      }), o;
    let a = [];
    o.value = i ? i.alloc(e, o, /* @__PURE__ */ new Set(), t) : /* @__PURE__ */ new Set();
    for (let c of n) {
      let u = r.valueType._zod.run({ value: c, issues: [] }, t);
      u instanceof Promise ? a.push(u.then((l) => Wf(l, o))) : Wf(u, o);
    }
    return a.length ? Promise.all(a).then(() => o) : o;
  };
});
function Wf(e, r) {
  e.issues.length && r.issues.push(...e.issues), r.value.add(e.value);
}
s(Wf, "handleSetResult");
var Dr = /* @__PURE__ */ h("$ZodEnum", (e, r) => {
  P.init(e, r);
  let i = pr(r.entries), o = new Set(i);
  e._zod.values = o;
  let t = i.filter((n) => vr.has(typeof n));
  e._zod.pattern = new RegExp(t.length ? `^(${t.map((n) => ve(n.toString())).join("|")})$` : "^[^\\s\\S]$"), e._zod.parse = (n, a) => {
    let c = n.value;
    return o.has(c) || n.issues.push({
      code: "invalid_value",
      values: i,
      input: c,
      inst: e
    }), n;
  };
}), Nr = /* @__PURE__ */ h("$ZodLiteral", (e, r) => {
  P.init(e, r);
  let i = new Set(r.values);
  e._zod.values = i, e._zod.pattern = new RegExp(r.values.length ? `^(${r.values.map((o) => typeof o == "string" ? ve(o) : o ? ve(o.toString()) : String(o)).join("|")})$` : "^[^\\s\\S]$"), e._zod.parse = (o, t) => {
    let n = o.value;
    return i.has(n) || o.issues.push({
      code: "invalid_value",
      values: r.values,
      input: n,
      inst: e
    }), o;
  };
}), Ws = /* @__PURE__ */ h("$ZodFile", (e, r) => {
  P.init(e, r), e._zod.parse = (i, o) => {
    let t = i.value;
    return t instanceof File || i.issues.push({
      expected: "file",
      code: "invalid_type",
      input: t,
      inst: e
    }), i;
  };
}), Gs = /* @__PURE__ */ h("$ZodTransform", (e, r) => {
  P.init(e, r), e._zod.optin = "optional", Q.memoizer?.guard(e), e._zod.parse = (i, o) => {
    if (o.direction === "backward")
      throw new Ce(e.constructor.name);
    let t = r.transform(i.value, i);
    if (o.async)
      return (t instanceof Promise ? t : Promise.resolve(t)).then((a) => (i.value = a, i));
    if (t instanceof Promise)
      throw new ce();
    return i.value = t, i;
  };
});
function Gf(e, r) {
  return e.value = r.issues.length ? void 0 : r.value, e;
}
s(Gf, "handleOptionalResult");
var $e = /* @__PURE__ */ h("$ZodOptional", (e, r) => {
  P.init(e, r), E(e, "optin", (i) => i.def.innerType._zod.optin === "defaulted" ? "defaulted" : "optional"), e._zod.optout = "optional", E(e, "values", (i) => {
    let o = i.def.innerType._zod.values;
    return o ? /* @__PURE__ */ new Set([...o, void 0]) : void 0;
  }), E(e, "pattern", (i) => {
    let o = i.def.innerType._zod.pattern;
    return o ? new RegExp(`^(${mr(o.source)})?$`) : void 0;
  }), e._zod.parse = (i, o) => {
    if (i.value === void 0) {
      if (r.innerType._zod.optin !== "defaulted")
        return i;
      let t = r.innerType._zod.run({ value: i.value, issues: [] }, o);
      return t instanceof Promise ? t.then((n) => Gf(i, n)) : Gf(i, t);
    }
    return r.innerType._zod.run(i, o);
  };
}), Xs = /* @__PURE__ */ h("$ZodExactOptional", (e, r) => {
  $e.init(e, r), E(e, "values", (i) => i.def.innerType._zod.values), E(e, "pattern", (i) => i.def.innerType._zod.pattern), e._zod.parse = (i, o) => r.innerType._zod.run(i, o);
}), Nt = /* @__PURE__ */ h("$ZodNullable", (e, r) => {
  P.init(e, r), E(e, "optin", (i) => i.def.innerType._zod.optin), E(e, "optout", (i) => i.def.innerType._zod.optout), E(e, "pattern", (i) => {
    let o = i.def.innerType._zod.pattern;
    return o ? new RegExp(`^(${mr(o.source)}|null)$`) : void 0;
  }), E(e, "values", (i) => i.def.innerType._zod.values ? /* @__PURE__ */ new Set([...i.def.innerType._zod.values, null]) : void 0), e._zod.parse = (i, o) => i.value === null ? i : r.innerType._zod.run(i, o);
}), Tr = /* @__PURE__ */ h("$ZodDefault", (e, r) => {
  P.init(e, r), e._zod.optin = "defaulted", E(e, "values", (i) => i.def.innerType._zod.values), e._zod.parse = (i, o) => {
    if (o.direction === "backward")
      return r.innerType._zod.run(i, o);
    if (i.value === void 0)
      return i.value = r.defaultValue, i;
    let t = r.innerType._zod.run(i, o);
    return t instanceof Promise ? t.then((n) => Xf(n, r)) : Xf(t, r);
  };
});
function Xf(e, r) {
  return e.value === void 0 && (e.value = r.defaultValue), e;
}
s(Xf, "handleDefaultResult");
var Hs = /* @__PURE__ */ h("$ZodPrefault", (e, r) => {
  P.init(e, r), e._zod.optin = "defaulted", E(e, "values", (i) => i.def.innerType._zod.values), e._zod.parse = (i, o) => (o.direction === "backward" || i.value === void 0 && (i.value = r.defaultValue), r.innerType._zod.run(i, o));
}), Qs = /* @__PURE__ */ h("$ZodNonOptional", (e, r) => {
  P.init(e, r), E(e, "values", (i) => {
    let o = i.def.innerType._zod.values;
    return o ? new Set([...o].filter((t) => t !== void 0)) : void 0;
  }), e._zod.parse = (i, o) => {
    let t = r.innerType._zod.run(i, o);
    return t instanceof Promise ? t.then((n) => Hf(n, e)) : Hf(t, e);
  };
});
function Hf(e, r) {
  return !e.issues.length && e.value === void 0 && e.issues.push({
    code: "invalid_type",
    expected: "nonoptional",
    input: e.value,
    inst: r
  }), e;
}
s(Hf, "handleNonOptionalResult");
var Ys = /* @__PURE__ */ h("$ZodSuccess", (e, r) => {
  P.init(e, r), e._zod.parse = (i, o) => {
    if (o.direction === "backward")
      throw new Ce("ZodSuccess");
    let t = r.innerType._zod.run(i, o);
    return t instanceof Promise ? t.then((n) => (i.value = n.issues.length === 0, i)) : (i.value = t.issues.length === 0, i);
  };
});
function Qf(e, r, i, o) {
  return r.issues.length ? (e.value = i.catchValue({
    ...r,
    value: e.value,
    error: {
      issues: r.issues.map((t) => se(t, o, X()))
    },
    input: e.value
  }), e) : (e.value = r.value, r.memo && (e.memo = !0), e);
}
s(Qf, "handleCatchResult");
var ec = /* @__PURE__ */ h("$ZodCatch", (e, r) => {
  P.init(e, r), E(e, "optin", (i) => i.def.innerType._zod.optin === "defaulted" ? "defaulted" : "optional"), E(e, "optout", (i) => i.def.innerType._zod.optout), E(e, "values", (i) => i.def.innerType._zod.values), e._zod.parse = (i, o) => {
    if (o.direction === "backward")
      return r.innerType._zod.run(i, o);
    let t = r.innerType._zod.run({ value: i.value, issues: [] }, o);
    return t instanceof Promise ? t.then((n) => Qf(i, n, r, o)) : Qf(i, t, r, o);
  };
}), tc = /* @__PURE__ */ h("$ZodNaN", (e, r) => {
  P.init(e, r), e._zod.parse = (i, o) => ((typeof i.value != "number" || !Number.isNaN(i.value)) && i.issues.push({
    input: i.value,
    inst: e,
    expected: "nan",
    code: "invalid_type"
  }), i);
}), oi = /* @__PURE__ */ h("$ZodPipe", (e, r) => {
  P.init(e, r), E(e, "values", (i) => i.def.in._zod.values), E(e, "optin", (i) => i.def.in._zod.optin), E(e, "optout", (i) => i.def.out._zod.optout), E(e, "propValues", (i) => i.def.in._zod.propValues), e._zod.parse = (i, o) => {
    if (o.direction === "backward") {
      let n = r.out._zod.run(i, o);
      return n instanceof Promise ? n.then((a) => Bn(a, r.in, o)) : Bn(n, r.in, o);
    }
    let t = r.in._zod.run(i, o);
    return t instanceof Promise ? t.then((n) => Bn(n, r.out, o)) : Bn(t, r.out, o);
  };
});
function Bn(e, r, i) {
  return e.issues.some((o) => o.code !== "unrecognized_keys") ? (e.aborted = !0, e) : r._zod.run({ value: e.value, issues: e.issues }, i);
}
s(Bn, "handlePipeResult");
var ot = /* @__PURE__ */ h("$ZodCodec", (e, r) => {
  P.init(e, r), E(e, "values", (i) => i.def.in._zod.values), E(e, "optin", (i) => i.def.in._zod.optin), E(e, "optout", (i) => i.def.out._zod.optout), E(e, "propValues", (i) => i.def.in._zod.propValues), e._zod.parse = (i, o) => {
    if ((o.direction || "forward") === "forward") {
      let n = r.in._zod.run(i, o);
      return n instanceof Promise ? n.then((a) => Jn(a, r, o)) : Jn(n, r, o);
    } else {
      let n = r.out._zod.run(i, o);
      return n instanceof Promise ? n.then((a) => Jn(a, r, o)) : Jn(n, r, o);
    }
  };
});
function Jn(e, r, i) {
  if (e.issues.length)
    return e.aborted = !0, e;
  if ((i.direction || "forward") === "forward") {
    let t = r.transform(e.value, e);
    return t instanceof Promise ? t.then((n) => qn(e, n, r.out, i)) : qn(e, t, r.out, i);
  } else {
    let t = r.reverseTransform(e.value, e);
    return t instanceof Promise ? t.then((n) => qn(e, n, r.in, i)) : qn(e, t, r.in, i);
  }
}
s(Jn, "handleCodecAResult");
function qn(e, r, i, o) {
  return e.issues.length ? (e.aborted = !0, e) : i._zod.run({ value: r, issues: e.issues }, o);
}
s(qn, "handleCodecTxResult");
var rc = /* @__PURE__ */ h("$ZodPreprocess", (e, r) => {
  oi.init(e, r);
}), nc = /* @__PURE__ */ h("$ZodReadonly", (e, r) => {
  P.init(e, r), E(e, "propValues", (i) => i.def.innerType._zod.propValues), E(e, "values", (i) => i.def.innerType._zod.values), E(e, "optin", (i) => i.def.innerType?._zod?.optin), E(e, "optout", (i) => i.def.innerType?._zod?.optout), e._zod.parse = (i, o) => {
    if (o.direction === "backward")
      return r.innerType._zod.run(i, o);
    let t = r.innerType._zod.run(i, o);
    return t instanceof Promise ? t.then(Yf) : Yf(t);
  };
});
function Yf(e) {
  return e.memo || (e.value = Object.freeze(e.value)), e;
}
s(Yf, "handleReadonlyResult");
var ic = /* @__PURE__ */ h("$ZodTemplateLiteral", (e, r) => {
  P.init(e, r);
  let i = [];
  for (let o of r.parts)
    if (typeof o == "object" && o !== null) {
      if (!o._zod.pattern)
        throw new Error(`Invalid template literal part, no pattern found: ${[...o._zod.traits].shift()}`);
      let t = o._zod.pattern instanceof RegExp ? o._zod.pattern.source : o._zod.pattern;
      if (!t)
        throw new Error(`Invalid template literal part: ${o._zod.traits}`);
      let n = t.startsWith("^") ? 1 : 0, a = t.endsWith("$") ? t.length - 1 : t.length;
      i.push(t.slice(n, a));
    } else if (o === null || Mo.has(typeof o))
      i.push(ve(`${o}`));
    else
      throw new Error(`Invalid template literal part: ${o}`);
  e._zod.pattern = new RegExp(`^${i.join("")}$`), e._zod.parse = (o, t) => typeof o.value != "string" ? (o.issues.push({
    input: o.value,
    inst: e,
    expected: "string",
    code: "invalid_type"
  }), o) : (e._zod.pattern.lastIndex = 0, e._zod.pattern.test(o.value) || o.issues.push({
    input: o.value,
    inst: e,
    code: "invalid_format",
    format: r.format ?? "template_literal",
    pattern: e._zod.pattern.source
  }), o);
}), oc = /* @__PURE__ */ h("$ZodFunction", (e, r) => (P.init(e, r), Object.defineProperty(e, "_def", { value: r }), e._zod.def = r, e.implement = (i) => {
  if (typeof i != "function")
    throw new Error("implement() must be called with a function");
  return Object.defineProperty(function(...o) {
    let t = e._def.input ? tt(e._def.input, o) : o, n = Reflect.apply(i, this, t);
    return e._def.output ? tt(e._def.output, n) : n;
  }, "_zod", { value: e._zod, enumerable: !1 });
}, e.implementAsync = (i) => {
  if (typeof i != "function")
    throw new Error("implementAsync() must be called with a function");
  return Object.defineProperty(async function(...o) {
    let t = e._def.input ? await jn(e._def.input, o) : o, n = await Reflect.apply(i, this, t);
    return e._def.output ? await jn(e._def.output, n) : n;
  }, "_zod", { value: e._zod, enumerable: !1 });
}, e._zod.parse = (i, o) => typeof i.value != "function" ? (i.issues.push({
  code: "invalid_type",
  expected: "function",
  input: i.value,
  inst: e
}), i) : (e._def.output && e._def.output._zod.def.type === "promise" ? i.value = e.implementAsync(i.value) : i.value = e.implement(i.value), i), e.input = (...i) => {
  let o = e.constructor;
  return Array.isArray(i[0]) ? new o({
    type: "function",
    input: new Dt({
      type: "tuple",
      items: i[0],
      rest: i[1]
    }),
    output: e._def.output
  }) : new o({
    type: "function",
    input: i[0],
    output: e._def.output
  });
}, e.output = (i) => {
  let o = e.constructor;
  return new o({
    type: "function",
    input: e._def.input,
    output: i
  });
}, e)), ac = /* @__PURE__ */ h("$ZodPromise", (e, r) => {
  P.init(e, r), e._zod.parse = (i, o) => Promise.resolve(i.value).then((t) => r.innerType._zod.run({ value: t, issues: [] }, o));
}), at = /* @__PURE__ */ h("$ZodLazy", (e, r) => {
  P.init(e, r), Fo(e._zod, "innerType", () => {
    let i = r;
    return i._cachedInner || (i._cachedInner = r.getter()), i._cachedInner;
  }), E(e, "pattern", (i) => i.innerType?._zod?.pattern), E(e, "propValues", (i) => i.innerType?._zod?.propValues), E(e, "optin", (i) => i.innerType?._zod?.optin ?? void 0), E(e, "optout", (i) => i.innerType?._zod?.optout ?? void 0), e._zod.parse = (i, o) => e._zod.innerType._zod.run(i, o);
}), ai = /* @__PURE__ */ h("$ZodCustom", (e, r) => {
  B.init(e, r), P.init(e, r), e._zod.parse = (i, o) => i, e._zod.check = (i) => {
    let o = i.value, t = r.fn(o);
    if (t instanceof Promise)
      return t.then((n) => ep(n, i, o, e));
    ep(t, i, o, e);
  };
});
function ep(e, r, i, o) {
  if (!e) {
    let t = {
      code: "custom",
      input: i,
      inst: o,
      // incorporates params.error into issue reporting
      path: [...o._zod.def.path ?? []],
      // incorporates params.error into issue reporting
      continue: !o._zod.def.abort
      // params: inst._zod.def.params,
    };
    o._zod.def.params && (t.params = o._zod.def.params), r.issues.push(kt(t));
  }
}
s(ep, "handleRefineResult");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/memoizer.js
var ui = class extends Error {
  static {
    s(this, "$ZodCyclicError");
  }
  constructor() {
    super("Cannot parse a reference cycle that closes through a transform"), this.name = "ZodCyclicError";
  }
}, cc = "~memo", ip = [];
function sc(e) {
  return e.map((r) => r.path ? { ...r, path: r.path.slice() } : { ...r });
}
s(sc, "cloneIssues");
var op = /* @__PURE__ */ new WeakMap();
function uc(e, r) {
  let i = op.get(e);
  if (i !== void 0)
    return i;
  if (r.has(e))
    return !0;
  r.add(e);
  let o = !1, t = /* @__PURE__ */ s((c) => {
    !o && c?._zod && uc(c, r) && (o = !0);
  }, "check"), n = e._zod.def, a = n.type;
  switch (a) {
    case "object": {
      for (let c of Reflect.ownKeys(n.shape))
        t(n.shape[c]);
      t(n.catchall);
      break;
    }
    case "array":
      t(n.element);
      break;
    case "tuple":
      for (let c of n.items)
        t(c);
      t(n.rest);
      break;
    case "record":
    case "map":
      t(n.keyType), t(n.valueType);
      break;
    case "set":
      t(n.valueType);
      break;
    case "union":
      for (let c of n.options)
        t(c);
      break;
    case "intersection":
      t(n.left), t(n.right);
      break;
    case "optional":
    case "nullable":
    case "default":
    case "prefault":
    case "catch":
    case "readonly":
    case "nonoptional":
    case "promise":
    case "success":
      t(n.innerType);
      break;
    case "pipe":
      t(n.in), t(n.out);
      break;
    case "function":
      t(n.input), t(n.output);
      break;
    // reading `_zod.innerType` resolves the getter once and caches it
    case "lazy":
      t(e._zod.innerType);
      break;
    // a leaf by choice: `parts` are regex fragments, not data positions
    case "template_literal":
    // leaves
    case "string":
    case "number":
    case "int":
    case "boolean":
    case "bigint":
    case "symbol":
    case "undefined":
    case "null":
    case "void":
    case "never":
    case "any":
    case "unknown":
    case "date":
    case "nan":
    case "enum":
    case "literal":
    case "file":
    case "transform":
    case "custom":
      break;
    default:
      for (let c in n) {
        let u = Object.getOwnPropertyDescriptor(n, c);
        if (!u || u.get)
          continue;
        let l = u.value;
        if (!(!l || typeof l != "object")) {
          if (l._zod)
            t(l);
          else if (Array.isArray(l))
            for (let f of l)
              t(f);
        }
      }
  }
  return r.delete(e), op.set(e, o), o;
}
s(uc, "isRecursive");
function lc(e) {
  return uc(e, /* @__PURE__ */ new Set());
}
s(lc, "isRecursiveSchema");
function Fb(e, r) {
  let i = e.buckets.get(r);
  return i || (i = /* @__PURE__ */ new Map(), e.buckets.set(r, i)), i;
}
s(Fb, "bucketFor");
var si, ci = [], Lb = {
  alloc(e, r, i) {
    let o = si;
    if (!o)
      return i;
    si = void 0;
    let t = { value: i, issues: null };
    return o.set(r.value, t), ci.push(t), i;
  },
  guard(e) {
    var r;
    (r = e._zod).deferred ?? (r.deferred = []), e._zod.deferred.push(() => {
      let i = e._zod.parse, o = /* @__PURE__ */ s((t, n) => {
        if (n.direction !== "backward" && li(n, t.value))
          throw new ui();
        return i(t, n);
      }, "wrapped");
      e._zod.parse = o, e._zod.run === i && (e._zod.run = o);
    });
  },
  attach(e) {
    var r;
    let i, o, t;
    (r = e._zod).deferred ?? (r.deferred = []), e._zod.deferred.push(() => {
      let n = e._zod.parse, a = /* @__PURE__ */ s((c, u) => {
        if (i === void 0 && (i = uc(e, /* @__PURE__ */ new Set()), !i))
          return e._zod.parse = n, e._zod.run === a && (e._zod.run = n), n(c, u);
        let l = c.value;
        if (l === null || typeof l != "object")
          return n(c, u);
        let f = u[cc];
        f || (f = { buckets: /* @__PURE__ */ new Map(), backEdges: void 0 }, u[cc] = f);
        let m;
        o === u ? m = t : (m = Fb(f, e), o = u, t = m);
        let v = m.get(l);
        if (v)
          return c.value = v.value, v.issues ? v.issues.length && c.issues.push(...sc(v.issues)) : (c.memo = !0, f.backEdges ?? (f.backEdges = /* @__PURE__ */ new Set()), f.backEdges.add(v.value)), c;
        si = m;
        let y = ci.length, b = n(c, u);
        si = void 0;
        let z = ci.length > y ? ci.pop() : void 0;
        return b instanceof Promise ? b.then((O) => (z && (z.issues = O.issues.length ? sc(O.issues) : ip), O)) : (z && (z.issues = b.issues.length ? sc(b.issues) : ip), b);
      }, "wrapped");
      e._zod.parse = a, e._zod.run === n && (e._zod.run = a);
    });
  }
};
function Ur() {
  return Lb;
}
s(Ur, "memoizer");
function li(e, r) {
  let i = e[cc]?.backEdges;
  return i !== void 0 && r !== null && typeof r == "object" && i.has(r);
}
s(li, "isBackEdge");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/index.js
var Fr = {};
Pe(Fr, {
  ar: () => dc,
  az: () => fc,
  be: () => pc,
  bg: () => mc,
  bn: () => hc,
  ca: () => gc,
  ckb: () => vc,
  cs: () => yc,
  da: () => bc,
  de: () => $c,
  el: () => _c,
  en: () => Er,
  eo: () => xc,
  es: () => wc,
  fa: () => kc,
  fi: () => Ic,
  fr: () => zc,
  frCA: () => Sc,
  gu: () => Oc,
  he: () => jc,
  hi: () => Ac,
  hr: () => Pc,
  hu: () => Dc,
  hy: () => Nc,
  id: () => Tc,
  is: () => Uc,
  it: () => Ec,
  ja: () => Cc,
  ka: () => Zc,
  kh: () => Rc,
  km: () => Cr,
  kn: () => Fc,
  ko: () => Lc,
  lt: () => Vc,
  mk: () => Mc,
  ms: () => Bc,
  ne: () => Jc,
  nl: () => qc,
  nn: () => Kc,
  no: () => Wc,
  ota: () => Gc,
  pl: () => Hc,
  ps: () => Xc,
  pt: () => Qc,
  ptBR: () => Yc,
  ro: () => eu,
  ru: () => tu,
  sk: () => ru,
  sl: () => nu,
  sv: () => iu,
  ta: () => ou,
  th: () => au,
  tk: () => su,
  tr: () => cu,
  ua: () => uu,
  uk: () => Rr,
  ur: () => lu,
  uz: () => du,
  vi: () => fu,
  yo: () => hu,
  zhCN: () => pu,
  zhTW: () => mu
});

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ar.js
var Vb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u062D\u0631\u0641", verb: "\u0623\u0646 \u064A\u062D\u0648\u064A" },
    file: { unit: "\u0628\u0627\u064A\u062A", verb: "\u0623\u0646 \u064A\u062D\u0648\u064A" },
    array: { unit: "\u0639\u0646\u0635\u0631", verb: "\u0623\u0646 \u064A\u062D\u0648\u064A" },
    set: { unit: "\u0639\u0646\u0635\u0631", verb: "\u0623\u0646 \u064A\u062D\u0648\u064A" },
    map: { unit: "\u0639\u0646\u0635\u0631", verb: "\u0623\u0646 \u064A\u062D\u0648\u064A" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u0645\u062F\u062E\u0644",
    email: "\u0628\u0631\u064A\u062F \u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A",
    url: "\u0631\u0627\u0628\u0637",
    emoji: "\u0625\u064A\u0645\u0648\u062C\u064A",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u062A\u0627\u0631\u064A\u062E \u0648\u0648\u0642\u062A \u0628\u0645\u0639\u064A\u0627\u0631 ISO",
    date: "\u062A\u0627\u0631\u064A\u062E \u0628\u0645\u0639\u064A\u0627\u0631 ISO",
    time: "\u0648\u0642\u062A \u0628\u0645\u0639\u064A\u0627\u0631 ISO",
    duration: "\u0645\u062F\u0629 \u0628\u0645\u0639\u064A\u0627\u0631 ISO",
    ipv4: "\u0639\u0646\u0648\u0627\u0646 IPv4",
    ipv6: "\u0639\u0646\u0648\u0627\u0646 IPv6",
    mac: "\u0639\u0646\u0648\u0627\u0646 MAC",
    cidrv4: "\u0645\u062F\u0649 \u0639\u0646\u0627\u0648\u064A\u0646 \u0628\u0635\u064A\u063A\u0629 IPv4",
    cidrv6: "\u0645\u062F\u0649 \u0639\u0646\u0627\u0648\u064A\u0646 \u0628\u0635\u064A\u063A\u0629 IPv6",
    base64: "\u0646\u064E\u0635 \u0628\u062A\u0631\u0645\u064A\u0632 base64-encoded",
    base64url: "\u0646\u064E\u0635 \u0628\u062A\u0631\u0645\u064A\u0632 base64url-encoded",
    json_string: "\u0646\u064E\u0635 \u0639\u0644\u0649 \u0647\u064A\u0626\u0629 JSON",
    e164: "\u0631\u0642\u0645 \u0647\u0627\u062A\u0641 \u0628\u0645\u0639\u064A\u0627\u0631 E.164",
    credit_card: "\u0631\u0642\u0645 \u0628\u0637\u0627\u0642\u0629 \u0627\u0644\u0627\u0626\u062A\u0645\u0627\u0646",
    jwt: "JWT",
    template_literal: "\u0645\u062F\u062E\u0644"
  }, o = {
    nan: "NaN"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u0645\u062F\u062E\u0644\u0627\u062A \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644\u0629: \u064A\u0641\u062A\u0631\u0636 \u0625\u062F\u062E\u0627\u0644 instanceof ${t.expected}\u060C \u0648\u0644\u0643\u0646 \u062A\u0645 \u0625\u062F\u062E\u0627\u0644 ${c}` : `\u0645\u062F\u062E\u0644\u0627\u062A \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644\u0629: \u064A\u0641\u062A\u0631\u0636 \u0625\u062F\u062E\u0627\u0644 ${n}\u060C \u0648\u0644\u0643\u0646 \u062A\u0645 \u0625\u062F\u062E\u0627\u0644 ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u0645\u062F\u062E\u0644\u0627\u062A \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644\u0629: \u064A\u0641\u062A\u0631\u0636 \u0625\u062F\u062E\u0627\u0644 ${x(t.values[0])}` : `\u0627\u062E\u062A\u064A\u0627\u0631 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062A\u0648\u0642\u0639 \u0627\u0646\u062A\u0642\u0627\u0621 \u0623\u062D\u062F \u0647\u0630\u0647 \u0627\u0644\u062E\u064A\u0627\u0631\u0627\u062A: ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? ` \u0623\u0643\u0628\u0631 \u0645\u0646 \u0627\u0644\u0644\u0627\u0632\u0645: \u064A\u0641\u062A\u0631\u0636 \u0623\u0646 \u062A\u0643\u0648\u0646 ${t.origin ?? "\u0627\u0644\u0642\u064A\u0645\u0629"} ${n} ${t.maximum.toString()} ${a.unit ?? "\u0639\u0646\u0635\u0631"}` : `\u0623\u0643\u0628\u0631 \u0645\u0646 \u0627\u0644\u0644\u0627\u0632\u0645: \u064A\u0641\u062A\u0631\u0636 \u0623\u0646 \u062A\u0643\u0648\u0646 ${t.origin ?? "\u0627\u0644\u0642\u064A\u0645\u0629"} ${n} ${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u0623\u0635\u063A\u0631 \u0645\u0646 \u0627\u0644\u0644\u0627\u0632\u0645: \u064A\u0641\u062A\u0631\u0636 \u0644\u0640 ${t.origin} \u0623\u0646 \u064A\u0643\u0648\u0646 ${n} ${t.minimum.toString()} ${a.unit}` : `\u0623\u0635\u063A\u0631 \u0645\u0646 \u0627\u0644\u0644\u0627\u0632\u0645: \u064A\u0641\u062A\u0631\u0636 \u0644\u0640 ${t.origin} \u0623\u0646 \u064A\u0643\u0648\u0646 ${n} ${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u0646\u064E\u0635 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u0628\u062F\u0623 \u0628\u0640 "${t.prefix}"` : n.format === "ends_with" ? `\u0646\u064E\u0635 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u0646\u062A\u0647\u064A \u0628\u0640 "${n.suffix}"` : n.format === "includes" ? `\u0646\u064E\u0635 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u062A\u0636\u0645\u0651\u064E\u0646 "${n.includes}"` : n.format === "regex" ? `\u0646\u064E\u0635 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u0637\u0627\u0628\u0642 \u0627\u0644\u0646\u0645\u0637 ${n.pattern}` : `${i[n.format] ?? t.format} \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644`;
      }
      case "not_multiple_of":
        return `\u0631\u0642\u0645 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u0643\u0648\u0646 \u0645\u0646 \u0645\u0636\u0627\u0639\u0641\u0627\u062A ${t.divisor}`;
      case "unrecognized_keys":
        return `\u0645\u0639\u0631\u0641${t.keys.length > 1 ? "\u0627\u062A" : ""} \u063A\u0631\u064A\u0628${t.keys.length > 1 ? "\u0629" : ""}: ${g(t.keys, "\u060C ")}`;
      case "invalid_key":
        return `\u0645\u0639\u0631\u0641 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644 \u0641\u064A ${t.origin}`;
      case "invalid_union":
        return "\u0645\u062F\u062E\u0644 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644";
      case "invalid_element":
        return `\u0645\u062F\u062E\u0644 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644 \u0641\u064A ${t.origin}`;
      default:
        return "\u0645\u062F\u062E\u0644 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644";
    }
  };
}, "error");
function dc() {
  return {
    localeError: Vb()
  };
}
s(dc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/az.js
var Mb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "simvol", verb: "olmal\u0131d\u0131r" },
    file: { unit: "bayt", verb: "olmal\u0131d\u0131r" },
    array: { unit: "element", verb: "olmal\u0131d\u0131r" },
    set: { unit: "element", verb: "olmal\u0131d\u0131r" },
    map: { unit: "element", verb: "olmal\u0131d\u0131r" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "input",
    email: "email address",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datetime",
    date: "ISO date",
    time: "ISO time",
    duration: "ISO duration",
    ipv4: "IPv4 address",
    ipv6: "IPv6 address",
    mac: "MAC address",
    cidrv4: "IPv4 range",
    cidrv6: "IPv6 range",
    base64: "base64-encoded string",
    base64url: "base64url-encoded string",
    json_string: "JSON string",
    e164: "E.164 number",
    credit_card: "kredit kart\u0131 n\xF6mr\u0259si",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Yanl\u0131\u015F d\u0259y\u0259r: g\xF6zl\u0259nil\u0259n instanceof ${t.expected}, daxil olan ${c}` : `Yanl\u0131\u015F d\u0259y\u0259r: g\xF6zl\u0259nil\u0259n ${n}, daxil olan ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Yanl\u0131\u015F d\u0259y\u0259r: g\xF6zl\u0259nil\u0259n ${x(t.values[0])}` : `Yanl\u0131\u015F se\xE7im: a\u015Fa\u011F\u0131dak\u0131lardan biri olmal\u0131d\u0131r: ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\xC7ox b\xF6y\xFCk: g\xF6zl\u0259nil\u0259n ${t.origin ?? "d\u0259y\u0259r"} ${n}${t.maximum.toString()} ${a.unit ?? "element"}` : `\xC7ox b\xF6y\xFCk: g\xF6zl\u0259nil\u0259n ${t.origin ?? "d\u0259y\u0259r"} ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\xC7ox ki\xE7ik: g\xF6zl\u0259nil\u0259n ${t.origin} ${n}${t.minimum.toString()} ${a.unit}` : `\xC7ox ki\xE7ik: g\xF6zl\u0259nil\u0259n ${t.origin} ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Yanl\u0131\u015F m\u0259tn: "${n.prefix}" il\u0259 ba\u015Flamal\u0131d\u0131r` : n.format === "ends_with" ? `Yanl\u0131\u015F m\u0259tn: "${n.suffix}" il\u0259 bitm\u0259lidir` : n.format === "includes" ? `Yanl\u0131\u015F m\u0259tn: "${n.includes}" daxil olmal\u0131d\u0131r` : n.format === "regex" ? `Yanl\u0131\u015F m\u0259tn: ${n.pattern} \u015Fablonuna uy\u011Fun olmal\u0131d\u0131r` : `Yanl\u0131\u015F ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Yanl\u0131\u015F \u0259d\u0259d: ${t.divisor} il\u0259 b\xF6l\xFCn\u0259 bil\u0259n olmal\u0131d\u0131r`;
      case "unrecognized_keys":
        return `Tan\u0131nmayan a\xE7ar${t.keys.length > 1 ? "lar" : ""}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `${t.origin} daxilind\u0259 yanl\u0131\u015F a\xE7ar`;
      case "invalid_union":
        return "Yanl\u0131\u015F d\u0259y\u0259r";
      case "invalid_element":
        return `${t.origin} daxilind\u0259 yanl\u0131\u015F d\u0259y\u0259r`;
      default:
        return "Yanl\u0131\u015F d\u0259y\u0259r";
    }
  };
}, "error");
function fc() {
  return {
    localeError: Mb()
  };
}
s(fc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/be.js
function ap(e, r, i, o) {
  let t = Math.abs(e), n = t % 10, a = t % 100;
  return a >= 11 && a <= 19 ? o : n === 1 ? r : n >= 2 && n <= 4 ? i : o;
}
s(ap, "getBelarusianPlural");
var Bb = /* @__PURE__ */ s(() => {
  let e = {
    string: {
      unit: {
        one: "\u0441\u0456\u043C\u0432\u0430\u043B",
        few: "\u0441\u0456\u043C\u0432\u0430\u043B\u044B",
        many: "\u0441\u0456\u043C\u0432\u0430\u043B\u0430\u045E"
      },
      verb: "\u043C\u0435\u0446\u044C"
    },
    array: {
      unit: {
        one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
        few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u044B",
        many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430\u045E"
      },
      verb: "\u043C\u0435\u0446\u044C"
    },
    set: {
      unit: {
        one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
        few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u044B",
        many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430\u045E"
      },
      verb: "\u043C\u0435\u0446\u044C"
    },
    map: {
      unit: {
        one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
        few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u044B",
        many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430\u045E"
      },
      verb: "\u043C\u0435\u0446\u044C"
    },
    file: {
      unit: {
        one: "\u0431\u0430\u0439\u0442",
        few: "\u0431\u0430\u0439\u0442\u044B",
        many: "\u0431\u0430\u0439\u0442\u0430\u045E"
      },
      verb: "\u043C\u0435\u0446\u044C"
    }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u0443\u0432\u043E\u0434",
    email: "email \u0430\u0434\u0440\u0430\u0441",
    url: "URL",
    emoji: "\u044D\u043C\u043E\u0434\u0437\u0456",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0434\u0430\u0442\u0430 \u0456 \u0447\u0430\u0441",
    date: "ISO \u0434\u0430\u0442\u0430",
    time: "ISO \u0447\u0430\u0441",
    duration: "ISO \u043F\u0440\u0430\u0446\u044F\u0433\u043B\u0430\u0441\u0446\u044C",
    ipv4: "IPv4 \u0430\u0434\u0440\u0430\u0441",
    ipv6: "IPv6 \u0430\u0434\u0440\u0430\u0441",
    mac: "MAC \u0430\u0434\u0440\u0430\u0441",
    cidrv4: "IPv4 \u0434\u044B\u044F\u043F\u0430\u0437\u043E\u043D",
    cidrv6: "IPv6 \u0434\u044B\u044F\u043F\u0430\u0437\u043E\u043D",
    base64: "\u0440\u0430\u0434\u043E\u043A \u0443 \u0444\u0430\u0440\u043C\u0430\u0446\u0435 base64",
    base64url: "\u0440\u0430\u0434\u043E\u043A \u0443 \u0444\u0430\u0440\u043C\u0430\u0446\u0435 base64url",
    json_string: "JSON \u0440\u0430\u0434\u043E\u043A",
    e164: "\u043D\u0443\u043C\u0430\u0440 E.164",
    credit_card: "\u043D\u0443\u043C\u0430\u0440 \u043A\u0440\u044D\u0434\u044B\u0442\u043D\u0430\u0439 \u043A\u0430\u0440\u0442\u044B",
    jwt: "JWT",
    template_literal: "\u0443\u0432\u043E\u0434"
  }, o = {
    nan: "NaN",
    number: "\u043B\u0456\u043A",
    array: "\u043C\u0430\u0441\u0456\u045E"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434: \u0447\u0430\u043A\u0430\u045E\u0441\u044F instanceof ${t.expected}, \u0430\u0442\u0440\u044B\u043C\u0430\u043D\u0430 ${c}` : `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434: \u0447\u0430\u043A\u0430\u045E\u0441\u044F ${n}, \u0430\u0442\u0440\u044B\u043C\u0430\u043D\u0430 ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F ${x(t.values[0])}` : `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0432\u0430\u0440\u044B\u044F\u043D\u0442: \u0447\u0430\u043A\u0430\u045E\u0441\u044F \u0430\u0434\u0437\u0456\u043D \u0437 ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        if (a) {
          let c = Number(t.maximum), u = ap(c, a.unit.one, a.unit.few, a.unit.many);
          return `\u0417\u0430\u043D\u0430\u0434\u0442\u0430 \u0432\u044F\u043B\u0456\u043A\u0456: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F, \u0448\u0442\u043E ${t.origin ?? "\u0437\u043D\u0430\u0447\u044D\u043D\u043D\u0435"} \u043F\u0430\u0432\u0456\u043D\u043D\u0430 ${a.verb} ${n}${t.maximum.toString()} ${u}`;
        }
        return `\u0417\u0430\u043D\u0430\u0434\u0442\u0430 \u0432\u044F\u043B\u0456\u043A\u0456: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F, \u0448\u0442\u043E ${t.origin ?? "\u0437\u043D\u0430\u0447\u044D\u043D\u043D\u0435"} \u043F\u0430\u0432\u0456\u043D\u043D\u0430 \u0431\u044B\u0446\u044C ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        if (a) {
          let c = Number(t.minimum), u = ap(c, a.unit.one, a.unit.few, a.unit.many);
          return `\u0417\u0430\u043D\u0430\u0434\u0442\u0430 \u043C\u0430\u043B\u044B: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F, \u0448\u0442\u043E ${t.origin} \u043F\u0430\u0432\u0456\u043D\u043D\u0430 ${a.verb} ${n}${t.minimum.toString()} ${u}`;
        }
        return `\u0417\u0430\u043D\u0430\u0434\u0442\u0430 \u043C\u0430\u043B\u044B: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F, \u0448\u0442\u043E ${t.origin} \u043F\u0430\u0432\u0456\u043D\u043D\u0430 \u0431\u044B\u0446\u044C ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0440\u0430\u0434\u043E\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u043F\u0430\u0447\u044B\u043D\u0430\u0446\u0446\u0430 \u0437 "${n.prefix}"` : n.format === "ends_with" ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0440\u0430\u0434\u043E\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u0437\u0430\u043A\u0430\u043D\u0447\u0432\u0430\u0446\u0446\u0430 \u043D\u0430 "${n.suffix}"` : n.format === "includes" ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0440\u0430\u0434\u043E\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u0437\u043C\u044F\u0448\u0447\u0430\u0446\u044C "${n.includes}"` : n.format === "regex" ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0440\u0430\u0434\u043E\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u0430\u0434\u043F\u0430\u0432\u044F\u0434\u0430\u0446\u044C \u0448\u0430\u0431\u043B\u043E\u043D\u0443 ${n.pattern}` : `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u043B\u0456\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u0431\u044B\u0446\u044C \u043A\u0440\u0430\u0442\u043D\u044B\u043C ${t.divisor}`;
      case "unrecognized_keys":
        return `\u041D\u0435\u0440\u0430\u0441\u043F\u0430\u0437\u043D\u0430\u043D\u044B ${t.keys.length > 1 ? "\u043A\u043B\u044E\u0447\u044B" : "\u043A\u043B\u044E\u0447"}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u043A\u043B\u044E\u0447 \u0443 ${t.origin}`;
      case "invalid_union":
        return "\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434";
      case "invalid_element":
        return `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u0430\u0435 \u0437\u043D\u0430\u0447\u044D\u043D\u043D\u0435 \u045E ${t.origin}`;
      default:
        return "\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434";
    }
  };
}, "error");
function pc() {
  return {
    localeError: Bb()
  };
}
s(pc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/bg.js
var Jb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0441\u0438\u043C\u0432\u043E\u043B\u0430", verb: "\u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430" },
    file: { unit: "\u0431\u0430\u0439\u0442\u0430", verb: "\u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430" },
    array: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0430", verb: "\u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430" },
    set: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0430", verb: "\u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430" },
    map: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0430", verb: "\u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u0432\u0445\u043E\u0434",
    email: "\u0438\u043C\u0435\u0439\u043B \u0430\u0434\u0440\u0435\u0441",
    url: "URL",
    emoji: "\u0435\u043C\u043E\u0434\u0436\u0438",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0432\u0440\u0435\u043C\u0435",
    date: "ISO \u0434\u0430\u0442\u0430",
    time: "ISO \u0432\u0440\u0435\u043C\u0435",
    duration: "ISO \u043F\u0440\u043E\u0434\u044A\u043B\u0436\u0438\u0442\u0435\u043B\u043D\u043E\u0441\u0442",
    ipv4: "IPv4 \u0430\u0434\u0440\u0435\u0441",
    ipv6: "IPv6 \u0430\u0434\u0440\u0435\u0441",
    mac: "MAC \u0430\u0434\u0440\u0435\u0441",
    cidrv4: "IPv4 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D",
    cidrv6: "IPv6 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D",
    base64: "base64-\u043A\u043E\u0434\u0438\u0440\u0430\u043D \u043D\u0438\u0437",
    base64url: "base64url-\u043A\u043E\u0434\u0438\u0440\u0430\u043D \u043D\u0438\u0437",
    json_string: "JSON \u043D\u0438\u0437",
    e164: "E.164 \u043D\u043E\u043C\u0435\u0440",
    credit_card: "\u043D\u043E\u043C\u0435\u0440 \u043D\u0430 \u043A\u0440\u0435\u0434\u0438\u0442\u043D\u0430 \u043A\u0430\u0440\u0442\u0430",
    jwt: "JWT",
    template_literal: "\u0432\u0445\u043E\u0434"
  }, o = {
    nan: "NaN",
    number: "\u0447\u0438\u0441\u043B\u043E",
    array: "\u043C\u0430\u0441\u0438\u0432"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434: \u043E\u0447\u0430\u043A\u0432\u0430\u043D instanceof ${t.expected}, \u043F\u043E\u043B\u0443\u0447\u0435\u043D ${c}` : `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434: \u043E\u0447\u0430\u043A\u0432\u0430\u043D ${n}, \u043F\u043E\u043B\u0443\u0447\u0435\u043D ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434: \u043E\u0447\u0430\u043A\u0432\u0430\u043D ${x(t.values[0])}` : `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u0430 \u043E\u043F\u0446\u0438\u044F: \u043E\u0447\u0430\u043A\u0432\u0430\u043D\u043E \u0435\u0434\u043D\u043E \u043E\u0442 ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u0422\u0432\u044A\u0440\u0434\u0435 \u0433\u043E\u043B\u044F\u043C\u043E: \u043E\u0447\u0430\u043A\u0432\u0430 \u0441\u0435 ${t.origin ?? "\u0441\u0442\u043E\u0439\u043D\u043E\u0441\u0442"} \u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430 ${n}${t.maximum.toString()} ${a.unit ?? "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0430"}` : `\u0422\u0432\u044A\u0440\u0434\u0435 \u0433\u043E\u043B\u044F\u043C\u043E: \u043E\u0447\u0430\u043A\u0432\u0430 \u0441\u0435 ${t.origin ?? "\u0441\u0442\u043E\u0439\u043D\u043E\u0441\u0442"} \u0434\u0430 \u0431\u044A\u0434\u0435 ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u0422\u0432\u044A\u0440\u0434\u0435 \u043C\u0430\u043B\u043A\u043E: \u043E\u0447\u0430\u043A\u0432\u0430 \u0441\u0435 ${t.origin} \u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430 ${n}${t.minimum.toString()} ${a.unit}` : `\u0422\u0432\u044A\u0440\u0434\u0435 \u043C\u0430\u043B\u043A\u043E: \u043E\u0447\u0430\u043A\u0432\u0430 \u0441\u0435 ${t.origin} \u0434\u0430 \u0431\u044A\u0434\u0435 ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        if (n.format === "starts_with")
          return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043D\u0438\u0437: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0437\u0430\u043F\u043E\u0447\u0432\u0430 \u0441 "${n.prefix}"`;
        if (n.format === "ends_with")
          return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043D\u0438\u0437: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0437\u0430\u0432\u044A\u0440\u0448\u0432\u0430 \u0441 "${n.suffix}"`;
        if (n.format === "includes")
          return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043D\u0438\u0437: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0432\u043A\u043B\u044E\u0447\u0432\u0430 "${n.includes}"`;
        if (n.format === "regex")
          return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043D\u0438\u0437: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0441\u044A\u0432\u043F\u0430\u0434\u0430 \u0441 ${n.pattern}`;
        let a = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D";
        return n.format === "emoji" && (a = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u043E"), n.format === "datetime" && (a = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u043E"), n.format === "date" && (a = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u0430"), n.format === "time" && (a = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u043E"), n.format === "duration" && (a = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u0430"), `${a} ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u043E \u0447\u0438\u0441\u043B\u043E: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0431\u044A\u0434\u0435 \u043A\u0440\u0430\u0442\u043D\u043E \u043D\u0430 ${t.divisor}`;
      case "unrecognized_keys":
        return `\u041D\u0435\u0440\u0430\u0437\u043F\u043E\u0437\u043D\u0430\u0442${t.keys.length > 1 ? "\u0438" : ""} \u043A\u043B\u044E\u0447${t.keys.length > 1 ? "\u043E\u0432\u0435" : ""}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043A\u043B\u044E\u0447 \u0432 ${t.origin}`;
      case "invalid_union":
        return "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434";
      case "invalid_element":
        return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u0430 \u0441\u0442\u043E\u0439\u043D\u043E\u0441\u0442 \u0432 ${t.origin}`;
      default:
        return "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434";
    }
  };
}, "error");
function mc() {
  return {
    localeError: Jb()
  };
}
s(mc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/bn.js
var qb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0985\u0995\u09CD\u09B7\u09B0", verb: "\u09A5\u09BE\u0995\u09A4\u09C7 \u09B9\u09AC\u09C7" },
    file: { unit: "\u09AC\u09BE\u0987\u099F", verb: "\u09A5\u09BE\u0995\u09A4\u09C7 \u09B9\u09AC\u09C7" },
    array: { unit: "\u0986\u0987\u099F\u09C7\u09AE", verb: "\u09A5\u09BE\u0995\u09A4\u09C7 \u09B9\u09AC\u09C7" },
    set: { unit: "\u0986\u0987\u099F\u09C7\u09AE", verb: "\u09A5\u09BE\u0995\u09A4\u09C7 \u09B9\u09AC\u09C7" },
    map: { unit: "\u098F\u09A8\u09CD\u099F\u09CD\u09B0\u09BF", verb: "\u09A5\u09BE\u0995\u09A4\u09C7 \u09B9\u09AC\u09C7" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u0987\u09A8\u09AA\u09C1\u099F",
    email: "\u0987\u09AE\u09C7\u0987\u09B2 \u09A0\u09BF\u0995\u09BE\u09A8\u09BE",
    url: "URL",
    emoji: "\u0987\u09AE\u09CB\u099C\u09BF",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u09A4\u09BE\u09B0\u09BF\u0996 \u0993 \u09B8\u09AE\u09AF\u09BC",
    date: "ISO \u09A4\u09BE\u09B0\u09BF\u0996",
    time: "ISO \u09B8\u09AE\u09AF\u09BC",
    duration: "ISO \u09B8\u09AE\u09AF\u09BC\u0995\u09BE\u09B2",
    ipv4: "IPv4 \u09A0\u09BF\u0995\u09BE\u09A8\u09BE",
    ipv6: "IPv6 \u09A0\u09BF\u0995\u09BE\u09A8\u09BE",
    mac: "MAC \u09A0\u09BF\u0995\u09BE\u09A8\u09BE",
    cidrv4: "IPv4 \u09B0\u09C7\u099E\u09CD\u099C",
    cidrv6: "IPv6 \u09B0\u09C7\u099E\u09CD\u099C",
    base64: "base64-\u098F\u09A8\u0995\u09CB\u09A1\u09C7\u09A1 \u09B8\u09CD\u099F\u09CD\u09B0\u09BF\u0982",
    base64url: "base64url-\u098F\u09A8\u0995\u09CB\u09A1\u09C7\u09A1 \u09B8\u09CD\u099F\u09CD\u09B0\u09BF\u0982",
    json_string: "JSON \u09B8\u09CD\u099F\u09CD\u09B0\u09BF\u0982",
    e164: "E.164 \u09A8\u09AE\u09CD\u09AC\u09B0",
    credit_card: "\u0995\u09CD\u09B0\u09C7\u09A1\u09BF\u099F \u0995\u09BE\u09B0\u09CD\u09A1 \u09A8\u09AE\u09CD\u09AC\u09B0",
    jwt: "JWT",
    template_literal: "\u0987\u09A8\u09AA\u09C1\u099F"
  }, o = {
    nan: "NaN"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return `\u0985\u09AC\u09C8\u09A7 \u0987\u09A8\u09AA\u09C1\u099F: \u09AA\u09CD\u09B0\u09A4\u09CD\u09AF\u09BE\u09B6\u09BF\u09A4 ${n}, \u09AA\u09CD\u09B0\u09BE\u09AA\u09CD\u09A4 ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u0985\u09AC\u09C8\u09A7 \u0987\u09A8\u09AA\u09C1\u099F: \u09AA\u09CD\u09B0\u09A4\u09CD\u09AF\u09BE\u09B6\u09BF\u09A4 ${x(t.values[0])}` : `\u0985\u09AC\u09C8\u09A7 \u0985\u09AA\u09B6\u09A8: ${g(t.values, " | ")} \u098F\u09B0 \u09AE\u09A7\u09CD\u09AF\u09C7 \u098F\u0995\u099F\u09BF \u09AA\u09CD\u09B0\u09A4\u09CD\u09AF\u09BE\u09B6\u09BF\u09A4`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u0985\u09A8\u09C7\u0995 \u09AC\u09A1\u09BC: ${t.origin ?? "\u09AE\u09BE\u09A8"} ${n}${t.maximum.toString()} ${a.unit ?? "\u098F\u09B2\u09BF\u09AE\u09C7\u09A8\u09CD\u099F"} \u09B9\u09A4\u09C7 \u09B9\u09AC\u09C7` : `\u0985\u09A8\u09C7\u0995 \u09AC\u09A1\u09BC: ${t.origin ?? "\u09AE\u09BE\u09A8"} ${n}${t.maximum.toString()} \u09B9\u09A4\u09C7 \u09B9\u09AC\u09C7`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u0985\u09A8\u09C7\u0995 \u099B\u09CB\u099F: ${t.origin} ${n}${t.minimum.toString()} ${a.unit} \u09B9\u09A4\u09C7 \u09B9\u09AC\u09C7` : `\u0985\u09A8\u09C7\u0995 \u099B\u09CB\u099F: ${t.origin} ${n}${t.minimum.toString()} \u09B9\u09A4\u09C7 \u09B9\u09AC\u09C7`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u0985\u09AC\u09C8\u09A7 \u09B8\u09CD\u099F\u09CD\u09B0\u09BF\u0982: "${n.prefix}" \u09A6\u09BF\u09AF\u09BC\u09C7 \u09B6\u09C1\u09B0\u09C1 \u09B9\u09A4\u09C7 \u09B9\u09AC\u09C7` : n.format === "ends_with" ? `\u0985\u09AC\u09C8\u09A7 \u09B8\u09CD\u099F\u09CD\u09B0\u09BF\u0982: "${n.suffix}" \u09A6\u09BF\u09AF\u09BC\u09C7 \u09B6\u09C7\u09B7 \u09B9\u09A4\u09C7 \u09B9\u09AC\u09C7` : n.format === "includes" ? `\u0985\u09AC\u09C8\u09A7 \u09B8\u09CD\u099F\u09CD\u09B0\u09BF\u0982: "${n.includes}" \u0985\u09A8\u09CD\u09A4\u09B0\u09CD\u09AD\u09C1\u0995\u09CD\u09A4 \u09A5\u09BE\u0995\u09A4\u09C7 \u09B9\u09AC\u09C7` : n.format === "regex" ? `\u0985\u09AC\u09C8\u09A7 \u09B8\u09CD\u099F\u09CD\u09B0\u09BF\u0982: ${n.pattern} \u09AA\u09CD\u09AF\u09BE\u099F\u09BE\u09B0\u09CD\u09A8 \u09AE\u09BF\u09B2\u09A4\u09C7 \u09B9\u09AC\u09C7` : `\u0985\u09AC\u09C8\u09A7 ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u0985\u09AC\u09C8\u09A7 \u09A8\u09AE\u09CD\u09AC\u09B0: ${t.divisor} \u098F\u09B0 \u0997\u09C1\u09A3\u09BF\u09A4\u0995 \u09B9\u09A4\u09C7 \u09B9\u09AC\u09C7`;
      case "unrecognized_keys":
        return `\u0985\u099A\u09C7\u09A8\u09BE \u0995\u09C0${t.keys.length > 1 ? "\u0997\u09C1\u09B2\u09CB" : ""}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `${t.origin} \u098F \u0985\u09AC\u09C8\u09A7 \u0995\u09C0`;
      case "invalid_union":
        return t.options && Array.isArray(t.options) && t.options.length > 0 ? `\u0985\u09AC\u09C8\u09A7 \u09A1\u09BF\u09B8\u0995\u09CD\u09B0\u09BF\u09AE\u09BF\u09A8\u09C7\u099F\u09B0 \u09AE\u09BE\u09A8\u0964 \u09AA\u09CD\u09B0\u09A4\u09CD\u09AF\u09BE\u09B6\u09BF\u09A4 ${t.options.map((a) => `'${a}'`).join(" | ")}` : "\u0985\u09AC\u09C8\u09A7 \u0987\u09A8\u09AA\u09C1\u099F";
      case "invalid_element":
        return `${t.origin} \u098F \u0985\u09AC\u09C8\u09A7 \u09AE\u09BE\u09A8`;
      default:
        return "\u0985\u09AC\u09C8\u09A7 \u0987\u09A8\u09AA\u09C1\u099F";
    }
  };
}, "error");
function hc() {
  return {
    localeError: qb()
  };
}
s(hc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ca.js
var Kb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "car\xE0cters", verb: "contenir" },
    file: { unit: "bytes", verb: "contenir" },
    array: { unit: "elements", verb: "contenir" },
    set: { unit: "elements", verb: "contenir" },
    map: { unit: "elements", verb: "contenir" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "entrada",
    email: "adre\xE7a electr\xF2nica",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "data i hora ISO",
    date: "data ISO",
    time: "hora ISO",
    duration: "durada ISO",
    ipv4: "adre\xE7a IPv4",
    ipv6: "adre\xE7a IPv6",
    mac: "adre\xE7a MAC",
    cidrv4: "rang IPv4",
    cidrv6: "rang IPv6",
    base64: "cadena codificada en base64",
    base64url: "cadena codificada en base64url",
    json_string: "cadena JSON",
    e164: "n\xFAmero E.164",
    credit_card: "n\xFAmero de targeta de cr\xE8dit",
    jwt: "JWT",
    template_literal: "entrada"
  }, o = {
    nan: "NaN"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Tipus inv\xE0lid: s'esperava instanceof ${t.expected}, s'ha rebut ${c}` : `Tipus inv\xE0lid: s'esperava ${n}, s'ha rebut ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Valor inv\xE0lid: s'esperava ${x(t.values[0])}` : `Opci\xF3 inv\xE0lida: s'esperava una de ${g(t.values, " o ")}`;
      case "too_big": {
        let n = t.inclusive ? "com a m\xE0xim" : "menys de", a = r(t.origin);
        return a ? `Massa gran: s'esperava que ${t.origin ?? "el valor"} contingu\xE9s ${n} ${t.maximum.toString()} ${a.unit ?? "elements"}` : `Massa gran: s'esperava que ${t.origin ?? "el valor"} fos ${n} ${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? "com a m\xEDnim" : "m\xE9s de", a = r(t.origin);
        return a ? `Massa petit: s'esperava que ${t.origin} contingu\xE9s ${n} ${t.minimum.toString()} ${a.unit}` : `Massa petit: s'esperava que ${t.origin} fos ${n} ${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Format inv\xE0lid: ha de comen\xE7ar amb "${n.prefix}"` : n.format === "ends_with" ? `Format inv\xE0lid: ha d'acabar amb "${n.suffix}"` : n.format === "includes" ? `Format inv\xE0lid: ha d'incloure "${n.includes}"` : n.format === "regex" ? `Format inv\xE0lid: ha de coincidir amb el patr\xF3 ${n.pattern}` : `Format inv\xE0lid per a ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `N\xFAmero inv\xE0lid: ha de ser m\xFAltiple de ${t.divisor}`;
      case "unrecognized_keys":
        return `Clau${t.keys.length > 1 ? "s" : ""} no reconeguda${t.keys.length > 1 ? "s" : ""}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `Clau inv\xE0lida a ${t.origin}`;
      case "invalid_union":
        return "Entrada inv\xE0lida";
      // Could also be "Tipus d'unió invàlid" but "Entrada invàlida" is more general
      case "invalid_element":
        return `Element inv\xE0lid a ${t.origin}`;
      default:
        return "Entrada inv\xE0lida";
    }
  };
}, "error");
function gc() {
  return {
    localeError: Kb()
  };
}
s(gc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ckb.js
var Wb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u067E\u06CC\u062A", verb: "\u0628\u06CE\u062A" },
    file: { unit: "\u0628\u0627\u06CC\u062A", verb: "\u0628\u06CE\u062A" },
    array: { unit: "\u062F\u0627\u0646\u06D5", verb: "\u0628\u06CE\u062A" },
    set: { unit: "\u062F\u0627\u0646\u06D5", verb: "\u0628\u06CE\u062A" },
    map: { unit: "\u062F\u0627\u0646\u06D5", verb: "\u0628\u06CE\u062A" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "regex",
    email: "\u0626\u06CC\u0645\u06D5\u06CC\u06B5",
    url: "\u0628\u06D5\u0633\u062A\u06D5\u0631 (URL)",
    emoji: "\u0626\u06CC\u0645\u06C6\u062C\u06CC",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u0695\u06CE\u06A9\u06D5\u0648\u062A \u0648 \u06A9\u0627\u062A",
    date: "\u0695\u06CE\u06A9\u06D5\u0648\u062A",
    time: "\u06A9\u0627\u062A",
    duration: "\u0645\u0627\u0648\u06D5",
    ipv4: "\u0646\u0627\u0648\u0646\u06CC\u0634\u0627\u0646\u06CC IPv4",
    ipv6: "\u0646\u0627\u0648\u0646\u06CC\u0634\u0627\u0646\u06CC IPv6",
    mac: "\u0646\u0627\u0648\u0646\u06CC\u0634\u0627\u0646\u06CC MAC",
    cidrv4: "\u0645\u06D5\u0648\u062F\u0627\u06CC IPv4",
    cidrv6: "\u0645\u06D5\u0648\u062F\u0627\u06CC IPv6",
    base64: "\u062F\u06D5\u0642\u06CC base64",
    base64url: "\u062F\u06D5\u0642\u06CC base64url",
    json_string: "\u062F\u06D5\u0642\u06CC JSON",
    e164: "\u0698\u0645\u0627\u0631\u06D5\u06CC E.164",
    credit_card: "\u0698\u0645\u0627\u0631\u06D5\u06CC \u06A9\u0627\u0631\u062A\u06CC \u06A9\u0631\u06CE\u062F\u06CC\u062A",
    jwt: "JWT",
    template_literal: "\u062A\u06CE\u06A9\u0631\u062F\u06D5"
  }, o = {
    nan: "NaN",
    string: "\u0646\u0648\u0648\u0633\u06CC\u0646",
    number: "\u0698\u0645\u0627\u0631\u06D5",
    boolean: "boolean",
    array: "array",
    object: "object",
    date: "\u0695\u06CE\u06A9\u06D5\u0648\u062A",
    integer: "\u0698\u0645\u0627\u0631\u06D5",
    float: "\u0698\u0645\u0627\u0631\u06D5",
    null: "null",
    undefined: "undefined",
    function: "function",
    symbol: "symbol",
    unknown: "unknown",
    promise: "promise",
    void: "void",
    never: "never",
    map: "map",
    set: "set"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a, u = ["\u0627", "\u0648", "\u06C6", "\u0648\u0648", "\u06D5", "\u06CC", "\u06CE"].some((f) => c.endsWith(f)) ? "\u06CC\u06D5" : "\u06D5", l = /^[a-zA-Z]+$/.test(c);
        return a === "null" || a === "undefined" ? "\u062F\u0627\u0648\u0627\u06A9\u0631\u0627\u0648\u06D5" : `\u0686\u0627\u0648\u06D5\u0695\u0648\u0627\u0646\u06A9\u0631\u0627\u0648\u06D5 ${n} \u0628\u06CE\u062A\u060C \u0628\u06D5\u06B5\u0627\u0645 ${c}${l ? "" : u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u0628\u06D5\u0647\u0627\u06A9\u06D5 \u0646\u0627\u062F\u0631\u0648\u0648\u0633\u062A\u06D5: \u0686\u0627\u0648\u06D5\u0695\u0648\u0627\u0646\u06A9\u0631\u0627\u0648\u06D5 ${x(t.values[0])} \u0628\u06CE\u062A` : `\u0647\u06D5\u06B5\u0628\u0698\u0627\u0631\u062F\u06D5\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A: \u0686\u0627\u0648\u06D5\u0695\u0648\u0627\u0646\u06A9\u0631\u0627\u0648\u06D5 \u06CC\u06D5\u06A9\u06CE\u06A9 \u0628\u06CE\u062A \u0644\u06D5 ${g(t.values, "|")}`;
      case "too_big": {
        let n = r(t.origin);
        return n ? `\u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 \u0628\u06D5 \u0644\u0627\u06CC\u06D5\u0646\u06CC \u0632\u06C6\u0631\u06D5\u0648\u06D5 ${t.maximum.toString()} ${n.unit} ${n.verb}` : `\u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 \u0628\u06D5 \u0644\u0627\u06CC\u06D5\u0646\u06CC \u0632\u06C6\u0631\u06D5\u0648\u06D5 ${t.maximum.toString()} \u0628\u06CE\u062A`;
      }
      case "too_small": {
        let n = r(t.origin);
        return n ? `\u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 \u0628\u06D5 \u0644\u0627\u06CC\u06D5\u0646\u06CC \u06A9\u06D5\u0645\u06D5\u0648\u06D5 ${t.minimum.toString()} ${n.unit} ${n.verb}` : `\u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 \u0628\u06D5 \u0644\u0627\u06CC\u06D5\u0646\u06CC \u06A9\u06D5\u0645\u06D5\u0648\u06D5 ${t.minimum.toString()} \u0628\u06CE\u062A`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u062F\u06D5\u0642\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A: \u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 \u062F\u06D5\u0633\u062A\u067E\u06CE\u0628\u06A9\u0627\u062A \u0628\u06D5 "${n.prefix}"` : n.format === "ends_with" ? `\u062F\u06D5\u0642\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A: \u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 \u06A9\u06C6\u062A\u0627\u06CC\u06CC\u0628\u06CE\u062A \u0628\u06D5 "${n.suffix}"` : n.format === "includes" ? `\u062F\u06D5\u0642\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A: \u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 "${n.includes}" \u0644\u06D5\u062E\u06C6\u0628\u06AF\u0631\u06CE\u062A` : n.format === "regex" ? `\u062F\u06D5\u0642\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A: \u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 \u0644\u06D5\u06AF\u06D5\u06B5 \u067E\u0627\u062A\u06CE\u0631\u0646\u06CC ${n.pattern} \u0628\u06AF\u0648\u0646\u062C\u06CE\u062A` : `\u0628\u06D5\u0647\u0627\u06CC ${i[n.format] ?? t.format} \u0646\u0627\u062F\u0631\u0648\u0633\u062A\u06D5`;
      }
      case "not_multiple_of":
        return `\u0698\u0645\u0627\u0631\u06D5\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A: \u062F\u06D5\u0628\u06CE\u062A \u0686\u06D5\u0646\u062F \u0647\u06CE\u0646\u062F\u06D5 \u0628\u06CE\u062A \u0628\u06C6 ${t.divisor}`;
      case "unrecognized_keys":
        return `\u06A9\u0644\u06CC\u0644\u06CC \u0646\u06D5\u0646\u0627\u0633\u0631\u0627\u0648: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `\u06A9\u0644\u06CC\u0644\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A \u0644\u06D5 ${t.origin}`;
      case "invalid_union":
        return t.options && Array.isArray(t.options) && t.options.length > 0 ? `\u0628\u06D5\u0647\u0627\u06CC \u0646\u06D5\u0646\u0627\u0633\u0631\u0627\u0648 \u0647\u06D5\u06CC\u06D5. \u0628\u06D5\u0647\u0627\u06CC \u0686\u0627\u0648\u06D5\u0695\u0648\u0627\u0646\u06A9\u0631\u0627\u0648: ${t.options.map((a) => `'${a}'`).join(" | ")}` : "\u06CC\u06D5\u06A9\u06AF\u0631\u062A\u0646\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A";
      case "invalid_element":
        return `${t.origin} \u0628\u06D5\u0647\u0627\u06A9\u06D5 \u0646\u0627\u062F\u0631\u0648\u0633\u062A\u06D5`;
      default:
        return "\u062A\u06CE\u06A9\u0631\u062F\u06D5\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A";
    }
  };
}, "error");
function vc() {
  return {
    localeError: Wb()
  };
}
s(vc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/cs.js
var Gb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "znak\u016F", verb: "m\xEDt" },
    file: { unit: "bajt\u016F", verb: "m\xEDt" },
    array: { unit: "prvk\u016F", verb: "m\xEDt" },
    set: { unit: "prvk\u016F", verb: "m\xEDt" },
    map: { unit: "prvk\u016F", verb: "m\xEDt" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "regul\xE1rn\xED v\xFDraz",
    email: "e-mailov\xE1 adresa",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "datum a \u010Das ve form\xE1tu ISO",
    date: "datum ve form\xE1tu ISO",
    time: "\u010Das ve form\xE1tu ISO",
    duration: "doba trv\xE1n\xED ISO",
    ipv4: "IPv4 adresa",
    ipv6: "IPv6 adresa",
    mac: "MAC adresa",
    cidrv4: "rozsah IPv4",
    cidrv6: "rozsah IPv6",
    base64: "\u0159et\u011Bzec zak\xF3dovan\xFD ve form\xE1tu base64",
    base64url: "\u0159et\u011Bzec zak\xF3dovan\xFD ve form\xE1tu base64url",
    json_string: "\u0159et\u011Bzec ve form\xE1tu JSON",
    e164: "\u010D\xEDslo E.164",
    credit_card: "\u010D\xEDslo kreditn\xED karty",
    jwt: "JWT",
    template_literal: "vstup"
  }, o = {
    nan: "NaN",
    number: "\u010D\xEDslo",
    string: "\u0159et\u011Bzec",
    function: "funkce",
    array: "pole"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Neplatn\xFD vstup: o\u010Dek\xE1v\xE1no instanceof ${t.expected}, obdr\u017Eeno ${c}` : `Neplatn\xFD vstup: o\u010Dek\xE1v\xE1no ${n}, obdr\u017Eeno ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Neplatn\xFD vstup: o\u010Dek\xE1v\xE1no ${x(t.values[0])}` : `Neplatn\xE1 mo\u017Enost: o\u010Dek\xE1v\xE1na jedna z hodnot ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Hodnota je p\u0159\xEDli\u0161 velk\xE1: ${t.origin ?? "hodnota"} mus\xED m\xEDt ${n}${t.maximum.toString()} ${a.unit ?? "prvk\u016F"}` : `Hodnota je p\u0159\xEDli\u0161 velk\xE1: ${t.origin ?? "hodnota"} mus\xED b\xFDt ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Hodnota je p\u0159\xEDli\u0161 mal\xE1: ${t.origin ?? "hodnota"} mus\xED m\xEDt ${n}${t.minimum.toString()} ${a.unit ?? "prvk\u016F"}` : `Hodnota je p\u0159\xEDli\u0161 mal\xE1: ${t.origin ?? "hodnota"} mus\xED b\xFDt ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Neplatn\xFD \u0159et\u011Bzec: mus\xED za\u010D\xEDnat na "${n.prefix}"` : n.format === "ends_with" ? `Neplatn\xFD \u0159et\u011Bzec: mus\xED kon\u010Dit na "${n.suffix}"` : n.format === "includes" ? `Neplatn\xFD \u0159et\u011Bzec: mus\xED obsahovat "${n.includes}"` : n.format === "regex" ? `Neplatn\xFD \u0159et\u011Bzec: mus\xED odpov\xEDdat vzoru ${n.pattern}` : `Neplatn\xFD form\xE1t ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Neplatn\xE9 \u010D\xEDslo: mus\xED b\xFDt n\xE1sobkem ${t.divisor}`;
      case "unrecognized_keys":
        return `Nezn\xE1m\xE9 kl\xED\u010De: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `Neplatn\xFD kl\xED\u010D v ${t.origin}`;
      case "invalid_union":
        return "Neplatn\xFD vstup";
      case "invalid_element":
        return `Neplatn\xE1 hodnota v ${t.origin}`;
      default:
        return "Neplatn\xFD vstup";
    }
  };
}, "error");
function yc() {
  return {
    localeError: Gb()
  };
}
s(yc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/da.js
var Xb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "tegn", verb: "havde" },
    file: { unit: "bytes", verb: "havde" },
    array: { unit: "elementer", verb: "indeholdt" },
    set: { unit: "elementer", verb: "indeholdt" },
    map: { unit: "elementer", verb: "indeholdt" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "input",
    email: "e-mailadresse",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO dato- og klokkesl\xE6t",
    date: "ISO-dato",
    time: "ISO-klokkesl\xE6t",
    duration: "ISO-varighed",
    ipv4: "IPv4-adresse",
    ipv6: "IPv6-adresse",
    mac: "MAC-adresse",
    cidrv4: "IPv4-spektrum",
    cidrv6: "IPv6-spektrum",
    base64: "base64-kodet streng",
    base64url: "base64url-kodet streng",
    json_string: "JSON-streng",
    e164: "E.164-nummer",
    credit_card: "kreditkortnummer",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN",
    string: "streng",
    number: "tal",
    boolean: "boolean",
    array: "liste",
    object: "objekt",
    set: "s\xE6t",
    file: "fil"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Ugyldigt input: forventede instanceof ${t.expected}, fik ${c}` : `Ugyldigt input: forventede ${n}, fik ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Ugyldig v\xE6rdi: forventede ${x(t.values[0])}` : `Ugyldigt valg: forventede en af f\xF8lgende ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin), c = o[t.origin] ?? t.origin;
        return a ? `For stor: forventede ${c ?? "value"} ${a.verb} ${n} ${t.maximum.toString()} ${a.unit ?? "elementer"}` : `For stor: forventede ${c ?? "value"} havde ${n} ${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin), c = o[t.origin] ?? t.origin;
        return a ? `For lille: forventede ${c} ${a.verb} ${n} ${t.minimum.toString()} ${a.unit}` : `For lille: forventede ${c} havde ${n} ${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Ugyldig streng: skal starte med "${n.prefix}"` : n.format === "ends_with" ? `Ugyldig streng: skal ende med "${n.suffix}"` : n.format === "includes" ? `Ugyldig streng: skal indeholde "${n.includes}"` : n.format === "regex" ? `Ugyldig streng: skal matche m\xF8nsteret ${n.pattern}` : `Ugyldig ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Ugyldigt tal: skal v\xE6re deleligt med ${t.divisor}`;
      case "unrecognized_keys":
        return `${t.keys.length > 1 ? "Ukendte n\xF8gler" : "Ukendt n\xF8gle"}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `Ugyldig n\xF8gle i ${t.origin}`;
      case "invalid_union":
        return "Ugyldigt input: matcher ingen af de tilladte typer";
      case "invalid_element":
        return `Ugyldig v\xE6rdi i ${t.origin}`;
      default:
        return "Ugyldigt input";
    }
  };
}, "error");
function bc() {
  return {
    localeError: Xb()
  };
}
s(bc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/de.js
var Hb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "Zeichen", verb: "zu haben" },
    file: { unit: "Bytes", verb: "zu haben" },
    array: { unit: "Elemente", verb: "zu haben" },
    set: { unit: "Elemente", verb: "zu haben" },
    map: { unit: "Elemente", verb: "zu haben" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "Eingabe",
    email: "E-Mail-Adresse",
    url: "URL",
    emoji: "Emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO-Datum und -Uhrzeit",
    date: "ISO-Datum",
    time: "ISO-Uhrzeit",
    duration: "ISO-Dauer",
    ipv4: "IPv4-Adresse",
    ipv6: "IPv6-Adresse",
    mac: "MAC-Adresse",
    cidrv4: "IPv4-Bereich",
    cidrv6: "IPv6-Bereich",
    base64: "Base64-codierter String",
    base64url: "Base64-URL-codierter String",
    json_string: "JSON-String",
    e164: "E.164-Nummer",
    credit_card: "Kreditkartennummer",
    jwt: "JWT",
    template_literal: "Eingabe"
  }, o = {
    nan: "NaN",
    number: "Zahl",
    array: "Array"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Ung\xFCltige Eingabe: erwartet instanceof ${t.expected}, erhalten ${c}` : `Ung\xFCltige Eingabe: erwartet ${n}, erhalten ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Ung\xFCltige Eingabe: erwartet ${x(t.values[0])}` : `Ung\xFCltige Option: erwartet eine von ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Zu gro\xDF: erwartet, dass ${t.origin ?? "Wert"} ${n}${t.maximum.toString()} ${a.unit ?? "Elemente"} hat` : `Zu gro\xDF: erwartet, dass ${t.origin ?? "Wert"} ${n}${t.maximum.toString()} ist`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Zu klein: erwartet, dass ${t.origin} ${n}${t.minimum.toString()} ${a.unit} hat` : `Zu klein: erwartet, dass ${t.origin} ${n}${t.minimum.toString()} ist`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Ung\xFCltiger String: muss mit "${n.prefix}" beginnen` : n.format === "ends_with" ? `Ung\xFCltiger String: muss mit "${n.suffix}" enden` : n.format === "includes" ? `Ung\xFCltiger String: muss "${n.includes}" enthalten` : n.format === "regex" ? `Ung\xFCltiger String: muss dem Muster ${n.pattern} entsprechen` : `Ung\xFCltig: ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Ung\xFCltige Zahl: muss ein Vielfaches von ${t.divisor} sein`;
      case "unrecognized_keys":
        return `${t.keys.length > 1 ? "Unbekannte Schl\xFCssel" : "Unbekannter Schl\xFCssel"}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `Ung\xFCltiger Schl\xFCssel in ${t.origin}`;
      case "invalid_union":
        return "Ung\xFCltige Eingabe";
      case "invalid_element":
        return `Ung\xFCltiger Wert in ${t.origin}`;
      default:
        return "Ung\xFCltige Eingabe";
    }
  };
}, "error");
function $c() {
  return {
    localeError: Hb()
  };
}
s($c, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/el.js
var Qb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u03C7\u03B1\u03C1\u03B1\u03BA\u03C4\u03AE\u03C1\u03B5\u03C2", verb: "\u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9" },
    file: { unit: "bytes", verb: "\u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9" },
    array: { unit: "\u03C3\u03C4\u03BF\u03B9\u03C7\u03B5\u03AF\u03B1", verb: "\u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9" },
    set: { unit: "\u03C3\u03C4\u03BF\u03B9\u03C7\u03B5\u03AF\u03B1", verb: "\u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9" },
    map: { unit: "\u03BA\u03B1\u03C4\u03B1\u03C7\u03C9\u03C1\u03AE\u03C3\u03B5\u03B9\u03C2", verb: "\u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2",
    email: "\u03B4\u03B9\u03B5\u03CD\u03B8\u03C5\u03BD\u03C3\u03B7 email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u03B7\u03BC\u03B5\u03C1\u03BF\u03BC\u03B7\u03BD\u03AF\u03B1 \u03BA\u03B1\u03B9 \u03CE\u03C1\u03B1",
    date: "ISO \u03B7\u03BC\u03B5\u03C1\u03BF\u03BC\u03B7\u03BD\u03AF\u03B1",
    time: "ISO \u03CE\u03C1\u03B1",
    duration: "ISO \u03B4\u03B9\u03AC\u03C1\u03BA\u03B5\u03B9\u03B1",
    ipv4: "\u03B4\u03B9\u03B5\u03CD\u03B8\u03C5\u03BD\u03C3\u03B7 IPv4",
    ipv6: "\u03B4\u03B9\u03B5\u03CD\u03B8\u03C5\u03BD\u03C3\u03B7 IPv6",
    mac: "\u03B4\u03B9\u03B5\u03CD\u03B8\u03C5\u03BD\u03C3\u03B7 MAC",
    cidrv4: "\u03B5\u03CD\u03C1\u03BF\u03C2 IPv4",
    cidrv6: "\u03B5\u03CD\u03C1\u03BF\u03C2 IPv6",
    base64: "\u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC \u03BA\u03C9\u03B4\u03B9\u03BA\u03BF\u03C0\u03BF\u03B9\u03B7\u03BC\u03AD\u03BD\u03B7 \u03C3\u03B5 base64",
    base64url: "\u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC \u03BA\u03C9\u03B4\u03B9\u03BA\u03BF\u03C0\u03BF\u03B9\u03B7\u03BC\u03AD\u03BD\u03B7 \u03C3\u03B5 base64url",
    json_string: "\u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC JSON",
    e164: "\u03B1\u03C1\u03B9\u03B8\u03BC\u03CC\u03C2 E.164",
    credit_card: "\u03B1\u03C1\u03B9\u03B8\u03BC\u03CC\u03C2 \u03C0\u03B9\u03C3\u03C4\u03C9\u03C4\u03B9\u03BA\u03AE\u03C2 \u03BA\u03AC\u03C1\u03C4\u03B1\u03C2",
    jwt: "JWT",
    template_literal: "\u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2"
  }, o = {
    nan: "NaN"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return typeof t.expected == "string" && /^[A-Z]/.test(t.expected) ? `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD instanceof ${t.expected}, \u03BB\u03AE\u03C6\u03B8\u03B7\u03BA\u03B5 ${c}` : `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${n}, \u03BB\u03AE\u03C6\u03B8\u03B7\u03BA\u03B5 ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${x(t.values[0])}` : `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03C0\u03B9\u03BB\u03BF\u03B3\u03AE: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD \u03AD\u03BD\u03B1 \u03B1\u03C0\u03CC ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u03A0\u03BF\u03BB\u03CD \u03BC\u03B5\u03B3\u03AC\u03BB\u03BF: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${t.origin ?? "\u03C4\u03B9\u03BC\u03AE"} \u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9 ${n}${t.maximum.toString()} ${a.unit ?? "\u03C3\u03C4\u03BF\u03B9\u03C7\u03B5\u03AF\u03B1"}` : `\u03A0\u03BF\u03BB\u03CD \u03BC\u03B5\u03B3\u03AC\u03BB\u03BF: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${t.origin ?? "\u03C4\u03B9\u03BC\u03AE"} \u03BD\u03B1 \u03B5\u03AF\u03BD\u03B1\u03B9 ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u03A0\u03BF\u03BB\u03CD \u03BC\u03B9\u03BA\u03C1\u03CC: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${t.origin} \u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9 ${n}${t.minimum.toString()} ${a.unit}` : `\u03A0\u03BF\u03BB\u03CD \u03BC\u03B9\u03BA\u03C1\u03CC: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${t.origin} \u03BD\u03B1 \u03B5\u03AF\u03BD\u03B1\u03B9 ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC: \u03C0\u03C1\u03AD\u03C0\u03B5\u03B9 \u03BD\u03B1 \u03BE\u03B5\u03BA\u03B9\u03BD\u03AC \u03BC\u03B5 "${n.prefix}"` : n.format === "ends_with" ? `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC: \u03C0\u03C1\u03AD\u03C0\u03B5\u03B9 \u03BD\u03B1 \u03C4\u03B5\u03BB\u03B5\u03B9\u03CE\u03BD\u03B5\u03B9 \u03BC\u03B5 "${n.suffix}"` : n.format === "includes" ? `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC: \u03C0\u03C1\u03AD\u03C0\u03B5\u03B9 \u03BD\u03B1 \u03C0\u03B5\u03C1\u03B9\u03AD\u03C7\u03B5\u03B9 "${n.includes}"` : n.format === "regex" ? `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC: \u03C0\u03C1\u03AD\u03C0\u03B5\u03B9 \u03BD\u03B1 \u03C4\u03B1\u03B9\u03C1\u03B9\u03AC\u03B6\u03B5\u03B9 \u03BC\u03B5 \u03C4\u03BF \u03BC\u03BF\u03C4\u03AF\u03B2\u03BF ${n.pattern}` : `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03BF: ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03BF\u03C2 \u03B1\u03C1\u03B9\u03B8\u03BC\u03CC\u03C2: \u03C0\u03C1\u03AD\u03C0\u03B5\u03B9 \u03BD\u03B1 \u03B5\u03AF\u03BD\u03B1\u03B9 \u03C0\u03BF\u03BB\u03BB\u03B1\u03C0\u03BB\u03AC\u03C3\u03B9\u03BF \u03C4\u03BF\u03C5 ${t.divisor}`;
      case "unrecognized_keys":
        return `\u0386\u03B3\u03BD\u03C9\u03C3\u03C4${t.keys.length > 1 ? "\u03B1" : "\u03BF"} \u03BA\u03BB\u03B5\u03B9\u03B4${t.keys.length > 1 ? "\u03B9\u03AC" : "\u03AF"}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03BF \u03BA\u03BB\u03B5\u03B9\u03B4\u03AF \u03C3\u03C4\u03BF ${t.origin}`;
      case "invalid_union":
        return "\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2";
      case "invalid_element":
        return `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03C4\u03B9\u03BC\u03AE \u03C3\u03C4\u03BF ${t.origin}`;
      default:
        return "\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2";
    }
  };
}, "error");
function _c() {
  return {
    localeError: Qb()
  };
}
s(_c, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/en.js
var Yb = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "characters", verb: "to have" },
    file: { unit: "bytes", verb: "to have" },
    array: { unit: "items", verb: "to have" },
    set: { unit: "items", verb: "to have" },
    map: { unit: "entries", verb: "to have" }
  };
  function r(n) {
    return e[n] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "input",
    email: "email address",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datetime",
    date: "ISO date",
    time: "ISO time",
    duration: "ISO duration",
    ipv4: "IPv4 address",
    ipv6: "IPv6 address",
    mac: "MAC address",
    cidrv4: "IPv4 range",
    cidrv6: "IPv6 range",
    base64: "base64-encoded string",
    base64url: "base64url-encoded string",
    json_string: "JSON string",
    e164: "E.164 number",
    credit_card: "credit card number",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    // Compatibility: "nan" -> "NaN" for display
    nan: "NaN"
    // All other type names omitted - they fall back to raw values via ?? operator
  };
  function t(n, a) {
    return n === "number" && typeof a == "number" && !Number.isFinite(a) ? String(a) : o[n] ?? n;
  }
  return s(t, "getTypeName"), (n) => {
    switch (n.code) {
      case "invalid_type": {
        let a = t(n.expected), c = w(n.input), u = t(c, n.input);
        return `Invalid input: expected ${a}, received ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `Invalid input: expected ${x(n.values[0])}` : `Invalid option: expected one of ${g(n.values, "|")}`;
      case "too_big": {
        let a = n.exact ? "exactly " : n.inclusive ? "<=" : "<", c = r(n.origin);
        return c ? `Too big: expected ${n.origin ?? "value"} to have ${a}${n.maximum.toString()} ${c.unit ?? "elements"}` : `Too big: expected ${n.origin ?? "value"} to be ${a}${n.maximum.toString()}`;
      }
      case "too_small": {
        let a = n.exact ? "exactly " : n.inclusive ? ">=" : ">", c = r(n.origin);
        return c ? `Too small: expected ${n.origin} to have ${a}${n.minimum.toString()} ${c.unit}` : `Too small: expected ${n.origin} to be ${a}${n.minimum.toString()}`;
      }
      case "invalid_format": {
        let a = n;
        return a.format === "starts_with" ? `Invalid string: must start with "${a.prefix}"` : a.format === "ends_with" ? `Invalid string: must end with "${a.suffix}"` : a.format === "includes" ? `Invalid string: must include "${a.includes}"` : a.format === "regex" ? `Invalid string: must match pattern ${a.pattern}` : `Invalid ${i[a.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `Invalid number: must be a multiple of ${n.divisor}`;
      case "unrecognized_keys":
        return `Unrecognized key${n.keys.length > 1 ? "s" : ""}: ${g(n.keys, ", ")}`;
      case "invalid_key":
        return `Invalid key in ${n.origin}`;
      case "invalid_union":
        return n.options && Array.isArray(n.options) && n.options.length > 0 ? `Invalid discriminator value. Expected ${n.options.map((c) => `'${c}'`).join(" | ")}` : n.inclusive === !1 ? "Invalid input: more than one option matched" : "Invalid input";
      case "invalid_element":
        return `Invalid value in ${n.origin}`;
      default:
        return "Invalid input";
    }
  };
}, "error");
function Er() {
  return {
    localeError: Yb()
  };
}
s(Er, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/eo.js
var e$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "karaktrojn", verb: "havi" },
    file: { unit: "bajtojn", verb: "havi" },
    array: { unit: "elementojn", verb: "havi" },
    set: { unit: "elementojn", verb: "havi" },
    map: { unit: "elementojn", verb: "havi" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "enigo",
    email: "retadreso",
    url: "URL",
    emoji: "emo\u011Dio",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO-datotempo",
    date: "ISO-dato",
    time: "ISO-tempo",
    duration: "ISO-da\u016Dro",
    ipv4: "IPv4-adreso",
    ipv6: "IPv6-adreso",
    mac: "MAC-adreso",
    cidrv4: "IPv4-rango",
    cidrv6: "IPv6-rango",
    base64: "64-ume kodita karaktraro",
    base64url: "URL-64-ume kodita karaktraro",
    json_string: "JSON-karaktraro",
    e164: "E.164-nombro",
    credit_card: "kreditkarta numero",
    jwt: "JWT",
    template_literal: "enigo"
  }, o = {
    nan: "NaN",
    number: "nombro",
    array: "tabelo",
    null: "senvalora"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Nevalida enigo: atendi\u011Dis instanceof ${t.expected}, ricevi\u011Dis ${c}` : `Nevalida enigo: atendi\u011Dis ${n}, ricevi\u011Dis ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Nevalida enigo: atendi\u011Dis ${x(t.values[0])}` : `Nevalida opcio: atendi\u011Dis unu el ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Tro granda: atendi\u011Dis ke ${t.origin ?? "valoro"} havu ${n}${t.maximum.toString()} ${a.unit ?? "elementojn"}` : `Tro granda: atendi\u011Dis ke ${t.origin ?? "valoro"} havu ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Tro malgranda: atendi\u011Dis ke ${t.origin} havu ${n}${t.minimum.toString()} ${a.unit}` : `Tro malgranda: atendi\u011Dis ke ${t.origin} estu ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Nevalida karaktraro: devas komenci\u011Di per "${n.prefix}"` : n.format === "ends_with" ? `Nevalida karaktraro: devas fini\u011Di per "${n.suffix}"` : n.format === "includes" ? `Nevalida karaktraro: devas inkluzivi "${n.includes}"` : n.format === "regex" ? `Nevalida karaktraro: devas kongrui kun la modelo ${n.pattern}` : `Nevalida ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Nevalida nombro: devas esti oblo de ${t.divisor}`;
      case "unrecognized_keys":
        return `Nekonata${t.keys.length > 1 ? "j" : ""} \u015Dlosilo${t.keys.length > 1 ? "j" : ""}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `Nevalida \u015Dlosilo en ${t.origin}`;
      case "invalid_union":
        return "Nevalida enigo";
      case "invalid_element":
        return `Nevalida valoro en ${t.origin}`;
      default:
        return "Nevalida enigo";
    }
  };
}, "error");
function xc() {
  return {
    localeError: e$()
  };
}
s(xc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/es.js
var t$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "caracteres", verb: "tener" },
    file: { unit: "bytes", verb: "tener" },
    array: { unit: "elementos", verb: "tener" },
    set: { unit: "elementos", verb: "tener" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "entrada",
    email: "direcci\xF3n de correo electr\xF3nico",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "fecha y hora ISO",
    date: "fecha ISO",
    time: "hora ISO",
    duration: "duraci\xF3n ISO",
    ipv4: "direcci\xF3n IPv4",
    ipv6: "direcci\xF3n IPv6",
    mac: "direcci\xF3n MAC",
    cidrv4: "rango IPv4",
    cidrv6: "rango IPv6",
    base64: "cadena codificada en base64",
    base64url: "URL codificada en base64",
    json_string: "cadena JSON",
    e164: "n\xFAmero E.164",
    credit_card: "n\xFAmero de tarjeta de cr\xE9dito",
    jwt: "JWT",
    template_literal: "entrada"
  }, o = {
    nan: "NaN",
    string: "texto",
    number: "n\xFAmero",
    boolean: "booleano",
    array: "arreglo",
    object: "objeto",
    set: "conjunto",
    file: "archivo",
    date: "fecha",
    bigint: "n\xFAmero grande",
    symbol: "s\xEDmbolo",
    undefined: "indefinido",
    null: "nulo",
    function: "funci\xF3n",
    map: "mapa",
    record: "registro",
    tuple: "tupla",
    enum: "enumeraci\xF3n",
    union: "uni\xF3n",
    literal: "literal",
    promise: "promesa",
    void: "vac\xEDo",
    never: "nunca",
    unknown: "desconocido",
    any: "cualquiera"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Entrada inv\xE1lida: se esperaba instanceof ${t.expected}, recibido ${c}` : `Entrada inv\xE1lida: se esperaba ${n}, recibido ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Entrada inv\xE1lida: se esperaba ${x(t.values[0])}` : `Opci\xF3n inv\xE1lida: se esperaba una de ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin), c = o[t.origin] ?? t.origin;
        return a ? `Demasiado grande: se esperaba que ${c ?? "valor"} tuviera ${n}${t.maximum.toString()} ${a.unit ?? "elementos"}` : `Demasiado grande: se esperaba que ${c ?? "valor"} fuera ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin), c = o[t.origin] ?? t.origin;
        return a ? `Demasiado peque\xF1o: se esperaba que ${c} tuviera ${n}${t.minimum.toString()} ${a.unit}` : `Demasiado peque\xF1o: se esperaba que ${c} fuera ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Cadena inv\xE1lida: debe comenzar con "${n.prefix}"` : n.format === "ends_with" ? `Cadena inv\xE1lida: debe terminar en "${n.suffix}"` : n.format === "includes" ? `Cadena inv\xE1lida: debe incluir "${n.includes}"` : n.format === "regex" ? `Cadena inv\xE1lida: debe coincidir con el patr\xF3n ${n.pattern}` : `Inv\xE1lido ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `N\xFAmero inv\xE1lido: debe ser m\xFAltiplo de ${t.divisor}`;
      case "unrecognized_keys":
        return `Llave${t.keys.length > 1 ? "s" : ""} desconocida${t.keys.length > 1 ? "s" : ""}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `Llave inv\xE1lida en ${o[t.origin] ?? t.origin}`;
      case "invalid_union":
        return "Entrada inv\xE1lida";
      case "invalid_element":
        return `Valor inv\xE1lido en ${o[t.origin] ?? t.origin}`;
      default:
        return "Entrada inv\xE1lida";
    }
  };
}, "error");
function wc() {
  return {
    localeError: t$()
  };
}
s(wc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/fa.js
var r$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u06A9\u0627\u0631\u0627\u06A9\u062A\u0631", verb: "\u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F" },
    file: { unit: "\u0628\u0627\u06CC\u062A", verb: "\u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F" },
    array: { unit: "\u0622\u06CC\u062A\u0645", verb: "\u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F" },
    set: { unit: "\u0622\u06CC\u062A\u0645", verb: "\u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F" },
    map: { unit: "\u0622\u06CC\u062A\u0645", verb: "\u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u0648\u0631\u0648\u062F\u06CC",
    email: "\u0622\u062F\u0631\u0633 \u0627\u06CC\u0645\u06CC\u0644",
    url: "URL",
    emoji: "\u0627\u06CC\u0645\u0648\u062C\u06CC",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u062A\u0627\u0631\u06CC\u062E \u0648 \u0632\u0645\u0627\u0646 \u0627\u06CC\u0632\u0648",
    date: "\u062A\u0627\u0631\u06CC\u062E \u0627\u06CC\u0632\u0648",
    time: "\u0632\u0645\u0627\u0646 \u0627\u06CC\u0632\u0648",
    duration: "\u0645\u062F\u062A \u0632\u0645\u0627\u0646 \u0627\u06CC\u0632\u0648",
    ipv4: "IPv4 \u0622\u062F\u0631\u0633",
    ipv6: "IPv6 \u0622\u062F\u0631\u0633",
    mac: "MAC \u0622\u062F\u0631\u0633",
    cidrv4: "IPv4 \u062F\u0627\u0645\u0646\u0647",
    cidrv6: "IPv6 \u062F\u0627\u0645\u0646\u0647",
    base64: "base64-encoded \u0631\u0634\u062A\u0647",
    base64url: "base64url-encoded \u0631\u0634\u062A\u0647",
    json_string: "JSON \u0631\u0634\u062A\u0647",
    e164: "E.164 \u0639\u062F\u062F",
    credit_card: "\u0634\u0645\u0627\u0631\u0647 \u06A9\u0627\u0631\u062A \u0627\u0639\u062A\u0628\u0627\u0631\u06CC",
    jwt: "JWT",
    template_literal: "\u0648\u0631\u0648\u062F\u06CC"
  }, o = {
    nan: "NaN",
    number: "\u0639\u062F\u062F",
    array: "\u0622\u0631\u0627\u06CC\u0647"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0645\u06CC\u200C\u0628\u0627\u06CC\u0633\u062A instanceof ${t.expected} \u0645\u06CC\u200C\u0628\u0648\u062F\u060C ${c} \u062F\u0631\u06CC\u0627\u0641\u062A \u0634\u062F` : `\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0645\u06CC\u200C\u0628\u0627\u06CC\u0633\u062A ${n} \u0645\u06CC\u200C\u0628\u0648\u062F\u060C ${c} \u062F\u0631\u06CC\u0627\u0641\u062A \u0634\u062F`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0645\u06CC\u200C\u0628\u0627\u06CC\u0633\u062A ${x(t.values[0])} \u0645\u06CC\u200C\u0628\u0648\u062F` : `\u06AF\u0632\u06CC\u0646\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0645\u06CC\u200C\u0628\u0627\u06CC\u0633\u062A \u06CC\u06A9\u06CC \u0627\u0632 ${g(t.values, "|")} \u0645\u06CC\u200C\u0628\u0648\u062F`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u062E\u06CC\u0644\u06CC \u0628\u0632\u0631\u06AF: ${t.origin ?? "\u0645\u0642\u062F\u0627\u0631"} \u0628\u0627\u06CC\u062F ${n}${t.maximum.toString()} ${a.unit ?? "\u0639\u0646\u0635\u0631"} \u0628\u0627\u0634\u062F` : `\u062E\u06CC\u0644\u06CC \u0628\u0632\u0631\u06AF: ${t.origin ?? "\u0645\u0642\u062F\u0627\u0631"} \u0628\u0627\u06CC\u062F ${n}${t.maximum.toString()} \u0628\u0627\u0634\u062F`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u062E\u06CC\u0644\u06CC \u06A9\u0648\u0686\u06A9: ${t.origin} \u0628\u0627\u06CC\u062F ${n}${t.minimum.toString()} ${a.unit} \u0628\u0627\u0634\u062F` : `\u062E\u06CC\u0644\u06CC \u06A9\u0648\u0686\u06A9: ${t.origin} \u0628\u0627\u06CC\u062F ${n}${t.minimum.toString()} \u0628\u0627\u0634\u062F`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u0631\u0634\u062A\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0628\u0627 "${n.prefix}" \u0634\u0631\u0648\u0639 \u0634\u0648\u062F` : n.format === "ends_with" ? `\u0631\u0634\u062A\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0628\u0627 "${n.suffix}" \u062A\u0645\u0627\u0645 \u0634\u0648\u062F` : n.format === "includes" ? `\u0631\u0634\u062A\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0634\u0627\u0645\u0644 "${n.includes}" \u0628\u0627\u0634\u062F` : n.format === "regex" ? `\u0631\u0634\u062A\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0628\u0627 \u0627\u0644\u06AF\u0648\u06CC ${n.pattern} \u0645\u0637\u0627\u0628\u0642\u062A \u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F` : `${i[n.format] ?? t.format} \u0646\u0627\u0645\u0639\u062A\u0628\u0631`;
      }
      case "not_multiple_of":
        return `\u0639\u062F\u062F \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0645\u0636\u0631\u0628 ${t.divisor} \u0628\u0627\u0634\u062F`;
      case "unrecognized_keys":
        return `\u06A9\u0644\u06CC\u062F${t.keys.length > 1 ? "\u0647\u0627\u06CC" : ""} \u0646\u0627\u0634\u0646\u0627\u0633: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `\u06A9\u0644\u06CC\u062F \u0646\u0627\u0634\u0646\u0627\u0633 \u062F\u0631 ${t.origin}`;
      case "invalid_union":
        return "\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631";
      case "invalid_element":
        return `\u0645\u0642\u062F\u0627\u0631 \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u062F\u0631 ${t.origin}`;
      default:
        return "\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631";
    }
  };
}, "error");
function kc() {
  return {
    localeError: r$()
  };
}
s(kc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/fi.js
var n$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "merkki\xE4", subject: "merkkijonon" },
    file: { unit: "tavua", subject: "tiedoston" },
    array: { unit: "alkiota", subject: "listan" },
    set: { unit: "alkiota", subject: "joukon" },
    map: { unit: "alkiota", subject: "kuvauksen" },
    number: { unit: "", subject: "luvun" },
    bigint: { unit: "", subject: "suuren kokonaisluvun" },
    int: { unit: "", subject: "kokonaisluvun" },
    date: { unit: "", subject: "p\xE4iv\xE4m\xE4\xE4r\xE4n" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "s\xE4\xE4nn\xF6llinen lauseke",
    email: "s\xE4hk\xF6postiosoite",
    url: "URL-osoite",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO-aikaleima",
    date: "ISO-p\xE4iv\xE4m\xE4\xE4r\xE4",
    time: "ISO-aika",
    duration: "ISO-kesto",
    ipv4: "IPv4-osoite",
    ipv6: "IPv6-osoite",
    mac: "MAC-osoite",
    cidrv4: "IPv4-alue",
    cidrv6: "IPv6-alue",
    base64: "base64-koodattu merkkijono",
    base64url: "base64url-koodattu merkkijono",
    json_string: "JSON-merkkijono",
    e164: "E.164-luku",
    credit_card: "luottokortin numero",
    jwt: "JWT",
    template_literal: "templaattimerkkijono"
  }, o = {
    nan: "NaN"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Virheellinen tyyppi: odotettiin instanceof ${t.expected}, oli ${c}` : `Virheellinen tyyppi: odotettiin ${n}, oli ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Virheellinen sy\xF6te: t\xE4ytyy olla ${x(t.values[0])}` : `Virheellinen valinta: t\xE4ytyy olla yksi seuraavista: ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Liian suuri: ${a.subject} t\xE4ytyy olla ${n}${t.maximum.toString()} ${a.unit}`.trim() : `Liian suuri: arvon t\xE4ytyy olla ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Liian pieni: ${a.subject} t\xE4ytyy olla ${n}${t.minimum.toString()} ${a.unit}`.trim() : `Liian pieni: arvon t\xE4ytyy olla ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Virheellinen sy\xF6te: t\xE4ytyy alkaa "${n.prefix}"` : n.format === "ends_with" ? `Virheellinen sy\xF6te: t\xE4ytyy loppua "${n.suffix}"` : n.format === "includes" ? `Virheellinen sy\xF6te: t\xE4ytyy sis\xE4lt\xE4\xE4 "${n.includes}"` : n.format === "regex" ? `Virheellinen sy\xF6te: t\xE4ytyy vastata s\xE4\xE4nn\xF6llist\xE4 lauseketta ${n.pattern}` : `Virheellinen ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Virheellinen luku: t\xE4ytyy olla luvun ${t.divisor} monikerta`;
      case "unrecognized_keys":
        return `${t.keys.length > 1 ? "Tuntemattomat avaimet" : "Tuntematon avain"}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return "Virheellinen avain tietueessa";
      case "invalid_union":
        return "Virheellinen unioni";
      case "invalid_element":
        return "Virheellinen arvo joukossa";
      default:
        return "Virheellinen sy\xF6te";
    }
  };
}, "error");
function Ic() {
  return {
    localeError: n$()
  };
}
s(Ic, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/fr.js
var i$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "caract\xE8res", verb: "avoir" },
    file: { unit: "octets", verb: "avoir" },
    array: { unit: "\xE9l\xE9ments", verb: "avoir" },
    set: { unit: "\xE9l\xE9ments", verb: "avoir" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "expression r\xE9guli\xE8re",
    email: "adresse e-mail",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "date et heure ISO",
    date: "date ISO",
    time: "heure ISO",
    duration: "dur\xE9e ISO",
    ipv4: "adresse IPv4",
    ipv6: "adresse IPv6",
    mac: "adresse MAC",
    cidrv4: "plage IPv4",
    cidrv6: "plage IPv6",
    base64: "cha\xEEne de caract\xE8res encod\xE9e en base64",
    base64url: "cha\xEEne de caract\xE8res encod\xE9e en base64url",
    json_string: "cha\xEEne de caract\xE8res JSON",
    e164: "num\xE9ro au format E.164",
    credit_card: "num\xE9ro de carte de cr\xE9dit",
    jwt: "JWT",
    template_literal: "entr\xE9e"
  }, o = {
    string: "cha\xEEne de caract\xE8res",
    number: "nombre",
    int: "entier",
    boolean: "bool\xE9en",
    bigint: "grand entier",
    symbol: "symbole",
    undefined: "ind\xE9fini",
    null: "null",
    never: "jamais",
    void: "vide",
    date: "date",
    array: "tableau",
    object: "objet",
    tuple: "tuple",
    record: "record",
    map: "map",
    set: "ensemble",
    file: "fichier",
    nonoptional: "non optionnel",
    nan: "NaN",
    function: "fonction"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Entr\xE9e invalide : instance de ${t.expected} attendu, ${c} re\xE7u` : `Entr\xE9e invalide : ${n} attendu, ${c} re\xE7u`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Entr\xE9e invalide : ${x(t.values[0])} attendu` : `Option invalide : une valeur parmi ${g(t.values, "|")} attendue`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Trop grand : ${o[t.origin] ?? "valeur"} doit ${a.verb} ${n}${t.maximum.toString()} ${a.unit ?? "\xE9l\xE9ment(s)"}` : `Trop grand : ${o[t.origin] ?? "valeur"} doit \xEAtre ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Trop petit : ${o[t.origin] ?? "valeur"} doit ${a.verb} ${n}${t.minimum.toString()} ${a.unit}` : `Trop petit : ${o[t.origin] ?? "valeur"} doit \xEAtre ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Cha\xEEne de caract\xE8res invalide : doit commencer par "${n.prefix}"` : n.format === "ends_with" ? `Cha\xEEne de caract\xE8res invalide : doit se terminer par "${n.suffix}"` : n.format === "includes" ? `Cha\xEEne de caract\xE8res invalide : doit inclure "${n.includes}"` : n.format === "regex" ? `Cha\xEEne de caract\xE8res invalide : doit correspondre au motif ${n.pattern}` : `${i[n.format] ?? t.format} invalide`;
      }
      case "not_multiple_of":
        return `Nombre invalide : doit \xEAtre un multiple de ${t.divisor}`;
      case "unrecognized_keys":
        return `Cl\xE9${t.keys.length > 1 ? "s" : ""} non reconnue${t.keys.length > 1 ? "s" : ""} : ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `Cl\xE9 invalide dans ${t.origin}`;
      case "invalid_union":
        return "Entr\xE9e invalide";
      case "invalid_element":
        return `Valeur invalide dans ${t.origin}`;
      default:
        return "Entr\xE9e invalide";
    }
  };
}, "error");
function zc() {
  return {
    localeError: i$()
  };
}
s(zc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/fr-CA.js
var o$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "caract\xE8res", verb: "avoir" },
    file: { unit: "octets", verb: "avoir" },
    array: { unit: "\xE9l\xE9ments", verb: "avoir" },
    set: { unit: "\xE9l\xE9ments", verb: "avoir" },
    map: { unit: "\xE9l\xE9ments", verb: "avoir" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "entr\xE9e",
    email: "adresse courriel",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "date-heure ISO",
    date: "date ISO",
    time: "heure ISO",
    duration: "dur\xE9e ISO",
    ipv4: "adresse IPv4",
    ipv6: "adresse IPv6",
    mac: "adresse MAC",
    cidrv4: "plage IPv4",
    cidrv6: "plage IPv6",
    base64: "cha\xEEne encod\xE9e en base64",
    base64url: "cha\xEEne encod\xE9e en base64url",
    json_string: "cha\xEEne JSON",
    e164: "num\xE9ro E.164",
    credit_card: "num\xE9ro de carte de cr\xE9dit",
    jwt: "JWT",
    template_literal: "entr\xE9e"
  }, o = {
    nan: "NaN"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Entr\xE9e invalide : attendu instanceof ${t.expected}, re\xE7u ${c}` : `Entr\xE9e invalide : attendu ${n}, re\xE7u ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Entr\xE9e invalide : attendu ${x(t.values[0])}` : `Option invalide : attendu l'une des valeurs suivantes ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "\u2264" : "<", a = r(t.origin);
        return a ? `Trop grand : attendu que ${t.origin ?? "la valeur"} ait ${n}${t.maximum.toString()} ${a.unit}` : `Trop grand : attendu que ${t.origin ?? "la valeur"} soit ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? "\u2265" : ">", a = r(t.origin);
        return a ? `Trop petit : attendu que ${t.origin} ait ${n}${t.minimum.toString()} ${a.unit}` : `Trop petit : attendu que ${t.origin} soit ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Cha\xEEne invalide : doit commencer par "${n.prefix}"` : n.format === "ends_with" ? `Cha\xEEne invalide : doit se terminer par "${n.suffix}"` : n.format === "includes" ? `Cha\xEEne invalide : doit inclure "${n.includes}"` : n.format === "regex" ? `Cha\xEEne invalide : doit correspondre au motif ${n.pattern}` : `${i[n.format] ?? t.format} invalide`;
      }
      case "not_multiple_of":
        return `Nombre invalide : doit \xEAtre un multiple de ${t.divisor}`;
      case "unrecognized_keys":
        return `Cl\xE9${t.keys.length > 1 ? "s" : ""} non reconnue${t.keys.length > 1 ? "s" : ""} : ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `Cl\xE9 invalide dans ${t.origin}`;
      case "invalid_union":
        return "Entr\xE9e invalide";
      case "invalid_element":
        return `Valeur invalide dans ${t.origin}`;
      default:
        return "Entr\xE9e invalide";
    }
  };
}, "error");
function Sc() {
  return {
    localeError: o$()
  };
}
s(Sc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/gu.js
var a$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0A85\u0A95\u0ACD\u0AB7\u0AB0", verb: "\u0AB9\u0ACB\u0AB5\u0ABE \u0A9C\u0ACB\u0A88\u0A8F" },
    file: { unit: "\u0AAC\u0ABE\u0AAF\u0A9F", verb: "\u0AB9\u0ACB\u0AB5\u0ABE \u0A9C\u0ACB\u0A88\u0A8F" },
    array: { unit: "\u0A86\u0A87\u0A9F\u0AAE", verb: "\u0AB9\u0ACB\u0AB5\u0ABE \u0A9C\u0ACB\u0A88\u0A8F" },
    set: { unit: "\u0A86\u0A87\u0A9F\u0AAE", verb: "\u0AB9\u0ACB\u0AB5\u0ABE \u0A9C\u0ACB\u0A88\u0A8F" },
    map: { unit: "\u0A8F\u0AA8\u0ACD\u0A9F\u0ACD\u0AB0\u0AC0", verb: "\u0AB9\u0ACB\u0AB5\u0ABE \u0A9C\u0ACB\u0A88\u0A8F" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u0A87\u0AA8\u0AAA\u0AC1\u0A9F",
    email: "\u0A88\u0AAE\u0AC7\u0A87\u0AB2 \u0A8F\u0AA1\u0ACD\u0AB0\u0AC7\u0AB8",
    url: "URL",
    emoji: "\u0A87\u0AAE\u0ACB\u0A9C\u0AC0",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0AA4\u0ABE\u0AB0\u0AC0\u0A96 \u0A85\u0AA8\u0AC7 \u0AB8\u0AAE\u0AAF",
    date: "ISO \u0AA4\u0ABE\u0AB0\u0AC0\u0A96",
    time: "ISO \u0AB8\u0AAE\u0AAF",
    duration: "ISO \u0A85\u0AB5\u0AA7\u0ABF",
    ipv4: "IPv4 \u0A8F\u0AA1\u0ACD\u0AB0\u0AC7\u0AB8",
    ipv6: "IPv6 \u0A8F\u0AA1\u0ACD\u0AB0\u0AC7\u0AB8",
    mac: "MAC \u0A8F\u0AA1\u0ACD\u0AB0\u0AC7\u0AB8",
    cidrv4: "IPv4 \u0AB6\u0ACD\u0AB0\u0AC7\u0AA3\u0AC0",
    cidrv6: "IPv6 \u0AB6\u0ACD\u0AB0\u0AC7\u0AA3\u0AC0",
    base64: "base64-\u0A8F\u0AA8\u0ACD\u0A95\u0ACB\u0AA1\u0AC7\u0AA1 \u0AB8\u0ACD\u0A9F\u0ACD\u0AB0\u0ABF\u0A82\u0A97",
    base64url: "base64url-\u0A8F\u0AA8\u0ACD\u0A95\u0ACB\u0AA1\u0AC7\u0AA1 \u0AB8\u0ACD\u0A9F\u0ACD\u0AB0\u0ABF\u0A82\u0A97",
    json_string: "JSON \u0AB8\u0ACD\u0A9F\u0ACD\u0AB0\u0ABF\u0A82\u0A97",
    e164: "E.164 \u0AA8\u0A82\u0AAC\u0AB0",
    credit_card: "\u0A95\u0ACD\u0AB0\u0AC7\u0AA1\u0ABF\u0A9F \u0A95\u0ABE\u0AB0\u0ACD\u0AA1 \u0AA8\u0A82\u0AAC\u0AB0",
    jwt: "JWT",
    template_literal: "\u0A87\u0AA8\u0AAA\u0AC1\u0A9F"
  }, o = {
    nan: "NaN"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0A87\u0AA8\u0AAA\u0AC1\u0A9F: \u0A85\u0AAA\u0AC7\u0A95\u0ACD\u0AB7\u0ABF\u0AA4 ${n}, \u0AAA\u0ACD\u0AB0\u0ABE\u0AAA\u0ACD\u0AA4 ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0A87\u0AA8\u0AAA\u0AC1\u0A9F: \u0A85\u0AAA\u0AC7\u0A95\u0ACD\u0AB7\u0ABF\u0AA4 ${x(t.values[0])}` : `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AB5\u0ABF\u0A95\u0AB2\u0ACD\u0AAA: ${g(t.values, " | ")} \u0AAE\u0ABE\u0AA7\u0ACD\u0AAF\u0AAE\u0AA5\u0AC0 \u0A8F\u0A95 \u0A85\u0AAA\u0AC7\u0A95\u0ACD\u0AB7\u0ABF\u0AA4`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u0A96\u0AC2\u0AAC \u0AAE\u0ACB\u0A9F\u0AC1\u0A82: ${t.origin ?? "\u0AAE\u0AC2\u0AB2\u0ACD\u0AAF"} ${n}${t.maximum.toString()} ${a.unit ?? "\u0A8F\u0AB2\u0ABF\u0AAE\u0AC7\u0AA8\u0ACD\u0A9F"} \u0AB9\u0ACB\u0AB5\u0ABE \u0A9C\u0ACB\u0A88\u0A8F` : `\u0A96\u0AC2\u0AAC \u0AAE\u0ACB\u0A9F\u0AC1\u0A82: ${t.origin ?? "\u0AAE\u0AC2\u0AB2\u0ACD\u0AAF"} ${n}${t.maximum.toString()} \u0AB9\u0ACB\u0AB5\u0AC1\u0A82 \u0A9C\u0ACB\u0A88\u0A8F`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u0A96\u0AC2\u0AAC \u0AA8\u0ABE\u0AA8\u0AC1\u0A82: ${t.origin} ${n}${t.minimum.toString()} ${a.unit} \u0AB9\u0ACB\u0AB5\u0ABE \u0A9C\u0ACB\u0A88\u0A8F` : `\u0A96\u0AC2\u0AAC \u0AA8\u0ABE\u0AA8\u0AC1\u0A82: ${t.origin} ${n}${t.minimum.toString()} \u0AB9\u0ACB\u0AB5\u0AC1\u0A82 \u0A9C\u0ACB\u0A88\u0A8F`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AB8\u0ACD\u0A9F\u0ACD\u0AB0\u0ABF\u0A82\u0A97: "${n.prefix}" \u0AA5\u0AC0 \u0AB6\u0AB0\u0AC2 \u0AA5\u0AB5\u0AC1\u0A82 \u0A9C\u0ACB\u0A88\u0A8F` : n.format === "ends_with" ? `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AB8\u0ACD\u0A9F\u0ACD\u0AB0\u0ABF\u0A82\u0A97: "${n.suffix}" \u0AAA\u0AB0 \u0AB8\u0AAE\u0ABE\u0AAA\u0ACD\u0AA4 \u0AA5\u0AB5\u0AC1\u0A82 \u0A9C\u0ACB\u0A88\u0A8F` : n.format === "includes" ? `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AB8\u0ACD\u0A9F\u0ACD\u0AB0\u0ABF\u0A82\u0A97: "${n.includes}" \u0AB6\u0ABE\u0AAE\u0AC7\u0AB2 \u0AB9\u0ACB\u0AB5\u0AC1\u0A82 \u0A9C\u0ACB\u0A88\u0A8F` : n.format === "regex" ? `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AB8\u0ACD\u0A9F\u0ACD\u0AB0\u0ABF\u0A82\u0A97: \u0AAA\u0AC7\u0A9F\u0AB0\u0ACD\u0AA8 ${n.pattern} \u0AB8\u0ABE\u0AA5\u0AC7 \u0AAE\u0AC7\u0AB3 \u0A96\u0ABE\u0AB5\u0AC1\u0A82 \u0A9C\u0ACB\u0A88\u0A8F` : `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AA8\u0A82\u0AAC\u0AB0: ${t.divisor} \u0AA8\u0ACB \u0A97\u0AC1\u0AA3\u0ABE\u0A82\u0A95 \u0AB9\u0ACB\u0AB5\u0ACB \u0A9C\u0ACB\u0A88\u0A8F`;
      case "unrecognized_keys":
        return `\u0A93\u0AB3\u0A96\u0AC0 \u0AB6\u0A95\u0ABE\u0AA4\u0ABE \u0AA8\u0AB9\u0AC0\u0A82 \u0AA4\u0AC7 \u0A95\u0AC0${t.keys.length > 1 ? "\u0A93" : ""}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `${t.origin} \u0AAE\u0ABE\u0A82 \u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0A95\u0AC0`;
      case "invalid_union":
        return t.options && Array.isArray(t.options) && t.options.length > 0 ? `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AA1\u0ABF\u0AB8\u0ACD\u0A95\u0ACD\u0AB0\u0ABF\u0AAE\u0ABF\u0AA8\u0AC7\u0A9F\u0AB0 \u0AAE\u0AC2\u0AB2\u0ACD\u0AAF. \u0A85\u0AAA\u0AC7\u0A95\u0ACD\u0AB7\u0ABF\u0AA4 ${t.options.map((a) => `'${a}'`).join(" | ")}` : "\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0A87\u0AA8\u0AAA\u0AC1\u0A9F";
      case "invalid_element":
        return `${t.origin} \u0AAE\u0ABE\u0A82 \u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AAE\u0AC2\u0AB2\u0ACD\u0AAF`;
      default:
        return "\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0A87\u0AA8\u0AAA\u0AC1\u0A9F";
    }
  };
}, "error");
function Oc() {
  return {
    localeError: a$()
  };
}
s(Oc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/he.js
var s$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { label: "\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA", gender: "f" },
    number: { label: "\u05DE\u05E1\u05E4\u05E8", gender: "m" },
    boolean: { label: "\u05E2\u05E8\u05DA \u05D1\u05D5\u05DC\u05D9\u05D0\u05E0\u05D9", gender: "m" },
    bigint: { label: "BigInt", gender: "m" },
    date: { label: "\u05EA\u05D0\u05E8\u05D9\u05DA", gender: "m" },
    array: { label: "\u05DE\u05E2\u05E8\u05DA", gender: "m" },
    object: { label: "\u05D0\u05D5\u05D1\u05D9\u05D9\u05E7\u05D8", gender: "m" },
    null: { label: "\u05E2\u05E8\u05DA \u05E8\u05D9\u05E7 (null)", gender: "m" },
    undefined: { label: "\u05E2\u05E8\u05DA \u05DC\u05D0 \u05DE\u05D5\u05D2\u05D3\u05E8 (undefined)", gender: "m" },
    symbol: { label: "\u05E1\u05D9\u05DE\u05D1\u05D5\u05DC (Symbol)", gender: "m" },
    function: { label: "\u05E4\u05D5\u05E0\u05E7\u05E6\u05D9\u05D4", gender: "f" },
    map: { label: "\u05DE\u05E4\u05D4 (Map)", gender: "f" },
    set: { label: "\u05E7\u05D1\u05D5\u05E6\u05D4 (Set)", gender: "f" },
    file: { label: "\u05E7\u05D5\u05D1\u05E5", gender: "m" },
    promise: { label: "Promise", gender: "m" },
    NaN: { label: "NaN", gender: "m" },
    unknown: { label: "\u05E2\u05E8\u05DA \u05DC\u05D0 \u05D9\u05D3\u05D5\u05E2", gender: "m" },
    value: { label: "\u05E2\u05E8\u05DA", gender: "m" }
  }, r = {
    string: { unit: "\u05EA\u05D5\u05D5\u05D9\u05DD", shortLabel: "\u05E7\u05E6\u05E8", longLabel: "\u05D0\u05E8\u05D5\u05DA" },
    file: { unit: "\u05D1\u05D9\u05D9\u05D8\u05D9\u05DD", shortLabel: "\u05E7\u05D8\u05DF", longLabel: "\u05D2\u05D3\u05D5\u05DC" },
    array: { unit: "\u05E4\u05E8\u05D9\u05D8\u05D9\u05DD", shortLabel: "\u05E7\u05D8\u05DF", longLabel: "\u05D2\u05D3\u05D5\u05DC" },
    set: { unit: "\u05E4\u05E8\u05D9\u05D8\u05D9\u05DD", shortLabel: "\u05E7\u05D8\u05DF", longLabel: "\u05D2\u05D3\u05D5\u05DC" },
    number: { unit: "", shortLabel: "\u05E7\u05D8\u05DF", longLabel: "\u05D2\u05D3\u05D5\u05DC" }
    // no unit
  }, i = /* @__PURE__ */ s((l) => l ? e[l] : void 0, "typeEntry"), o = /* @__PURE__ */ s((l) => {
    let f = i(l);
    return f ? f.label : l ?? e.unknown.label;
  }, "typeLabel"), t = /* @__PURE__ */ s((l) => `\u05D4${o(l)}`, "withDefinite"), n = /* @__PURE__ */ s((l) => (i(l)?.gender ?? "m") === "f" ? "\u05E6\u05E8\u05D9\u05DB\u05D4 \u05DC\u05D4\u05D9\u05D5\u05EA" : "\u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA", "verbFor"), a = /* @__PURE__ */ s((l) => l ? r[l] ?? null : null, "getSizing"), c = {
    regex: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    email: { label: "\u05DB\u05EA\u05D5\u05D1\u05EA \u05D0\u05D9\u05DE\u05D9\u05D9\u05DC", gender: "f" },
    url: { label: "\u05DB\u05EA\u05D5\u05D1\u05EA \u05E8\u05E9\u05EA", gender: "f" },
    emoji: { label: "\u05D0\u05D9\u05DE\u05D5\u05D2'\u05D9", gender: "m" },
    uuid: { label: "UUID", gender: "m" },
    uuidv4: { label: "UUIDv4", gender: "m" },
    uuidv6: { label: "UUIDv6", gender: "m" },
    nanoid: { label: "nanoid", gender: "m" },
    guid: { label: "GUID", gender: "m" },
    cuid: { label: "cuid", gender: "m" },
    cuid2: { label: "cuid2", gender: "m" },
    ulid: { label: "ULID", gender: "m" },
    xid: { label: "XID", gender: "m" },
    ksuid: { label: "KSUID", gender: "m" },
    datetime: { label: "\u05EA\u05D0\u05E8\u05D9\u05DA \u05D5\u05D6\u05DE\u05DF ISO", gender: "m" },
    date: { label: "\u05EA\u05D0\u05E8\u05D9\u05DA ISO", gender: "m" },
    time: { label: "\u05D6\u05DE\u05DF ISO", gender: "m" },
    duration: { label: "\u05DE\u05E9\u05DA \u05D6\u05DE\u05DF ISO", gender: "m" },
    ipv4: { label: "\u05DB\u05EA\u05D5\u05D1\u05EA IPv4", gender: "f" },
    ipv6: { label: "\u05DB\u05EA\u05D5\u05D1\u05EA IPv6", gender: "f" },
    mac: { label: "\u05DB\u05EA\u05D5\u05D1\u05EA MAC", gender: "f" },
    cidrv4: { label: "\u05D8\u05D5\u05D5\u05D7 IPv4", gender: "m" },
    cidrv6: { label: "\u05D8\u05D5\u05D5\u05D7 IPv6", gender: "m" },
    base64: { label: "\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D1\u05D1\u05E1\u05D9\u05E1 64", gender: "f" },
    base64url: { label: "\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D1\u05D1\u05E1\u05D9\u05E1 64 \u05DC\u05DB\u05EA\u05D5\u05D1\u05D5\u05EA \u05E8\u05E9\u05EA", gender: "f" },
    json_string: { label: "\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA JSON", gender: "f" },
    e164: { label: "\u05DE\u05E1\u05E4\u05E8 E.164", gender: "m" },
    credit_card: { label: "\u05DE\u05E1\u05E4\u05E8 \u05DB\u05E8\u05D8\u05D9\u05E1 \u05D0\u05E9\u05E8\u05D0\u05D9", gender: "m" },
    jwt: { label: "JWT", gender: "m" },
    template_literal: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    ends_with: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    includes: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    lowercase: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    starts_with: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    uppercase: { label: "\u05E7\u05DC\u05D8", gender: "m" }
  }, u = {
    nan: "NaN"
  };
  return (l) => {
    switch (l.code) {
      case "invalid_type": {
        let f = l.expected, m = u[f ?? ""] ?? o(f), v = w(l.input), y = u[v] ?? e[v]?.label ?? v;
        return /^[A-Z]/.test(l.expected) ? `\u05E7\u05DC\u05D8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA instanceof ${l.expected}, \u05D4\u05EA\u05E7\u05D1\u05DC ${y}` : `\u05E7\u05DC\u05D8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA ${m}, \u05D4\u05EA\u05E7\u05D1\u05DC ${y}`;
      }
      case "invalid_value": {
        if (l.values.length === 1)
          return `\u05E2\u05E8\u05DA \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05D4\u05E2\u05E8\u05DA \u05D7\u05D9\u05D9\u05D1 \u05DC\u05D4\u05D9\u05D5\u05EA ${x(l.values[0])}`;
        let f = l.values.map((y) => x(y));
        if (l.values.length === 2)
          return `\u05E2\u05E8\u05DA \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05D4\u05D0\u05E4\u05E9\u05E8\u05D5\u05D9\u05D5\u05EA \u05D4\u05DE\u05EA\u05D0\u05D9\u05DE\u05D5\u05EA \u05D4\u05DF ${f[0]} \u05D0\u05D5 ${f[1]}`;
        let m = f[f.length - 1];
        return `\u05E2\u05E8\u05DA \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05D4\u05D0\u05E4\u05E9\u05E8\u05D5\u05D9\u05D5\u05EA \u05D4\u05DE\u05EA\u05D0\u05D9\u05DE\u05D5\u05EA \u05D4\u05DF ${f.slice(0, -1).join(", ")} \u05D0\u05D5 ${m}`;
      }
      case "too_big": {
        let f = a(l.origin), m = t(l.origin ?? "value");
        if (l.origin === "string")
          return `${f?.longLabel ?? "\u05D0\u05E8\u05D5\u05DA"} \u05DE\u05D3\u05D9: ${m} \u05E6\u05E8\u05D9\u05DB\u05D4 \u05DC\u05D4\u05DB\u05D9\u05DC ${l.maximum.toString()} ${f?.unit ?? ""} ${l.inclusive ? "\u05D0\u05D5 \u05E4\u05D7\u05D5\u05EA" : "\u05DC\u05DB\u05DC \u05D4\u05D9\u05D5\u05EA\u05E8"}`.trim();
        if (l.origin === "number") {
          let b = l.inclusive ? `\u05E7\u05D8\u05DF \u05D0\u05D5 \u05E9\u05D5\u05D5\u05D4 \u05DC-${l.maximum}` : `\u05E7\u05D8\u05DF \u05DE-${l.maximum}`;
          return `\u05D2\u05D3\u05D5\u05DC \u05DE\u05D3\u05D9: ${m} \u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA ${b}`;
        }
        if (l.origin === "array" || l.origin === "set") {
          let b = l.origin === "set" ? "\u05E6\u05E8\u05D9\u05DB\u05D4" : "\u05E6\u05E8\u05D9\u05DA", z = l.inclusive ? `${l.maximum} ${f?.unit ?? ""} \u05D0\u05D5 \u05E4\u05D7\u05D5\u05EA` : `\u05E4\u05D7\u05D5\u05EA \u05DE-${l.maximum} ${f?.unit ?? ""}`;
          return `\u05D2\u05D3\u05D5\u05DC \u05DE\u05D3\u05D9: ${m} ${b} \u05DC\u05D4\u05DB\u05D9\u05DC ${z}`.trim();
        }
        let v = l.inclusive ? "<=" : "<", y = n(l.origin ?? "value");
        return f?.unit ? `${f.longLabel} \u05DE\u05D3\u05D9: ${m} ${y} ${v}${l.maximum.toString()} ${f.unit}` : `${f?.longLabel ?? "\u05D2\u05D3\u05D5\u05DC"} \u05DE\u05D3\u05D9: ${m} ${y} ${v}${l.maximum.toString()}`;
      }
      case "too_small": {
        let f = a(l.origin), m = t(l.origin ?? "value");
        if (l.origin === "string")
          return `${f?.shortLabel ?? "\u05E7\u05E6\u05E8"} \u05DE\u05D3\u05D9: ${m} \u05E6\u05E8\u05D9\u05DB\u05D4 \u05DC\u05D4\u05DB\u05D9\u05DC ${l.minimum.toString()} ${f?.unit ?? ""} ${l.inclusive ? "\u05D0\u05D5 \u05D9\u05D5\u05EA\u05E8" : "\u05DC\u05E4\u05D7\u05D5\u05EA"}`.trim();
        if (l.origin === "number") {
          let b = l.inclusive ? `\u05D2\u05D3\u05D5\u05DC \u05D0\u05D5 \u05E9\u05D5\u05D5\u05D4 \u05DC-${l.minimum}` : `\u05D2\u05D3\u05D5\u05DC \u05DE-${l.minimum}`;
          return `\u05E7\u05D8\u05DF \u05DE\u05D3\u05D9: ${m} \u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA ${b}`;
        }
        if (l.origin === "array" || l.origin === "set") {
          let b = l.origin === "set" ? "\u05E6\u05E8\u05D9\u05DB\u05D4" : "\u05E6\u05E8\u05D9\u05DA";
          if (l.minimum === 1 && l.inclusive) {
            let O = (l.origin === "set", "\u05DC\u05E4\u05D7\u05D5\u05EA \u05E4\u05E8\u05D9\u05D8 \u05D0\u05D7\u05D3");
            return `\u05E7\u05D8\u05DF \u05DE\u05D3\u05D9: ${m} ${b} \u05DC\u05D4\u05DB\u05D9\u05DC ${O}`;
          }
          let z = l.inclusive ? `${l.minimum} ${f?.unit ?? ""} \u05D0\u05D5 \u05D9\u05D5\u05EA\u05E8` : `\u05D9\u05D5\u05EA\u05E8 \u05DE-${l.minimum} ${f?.unit ?? ""}`;
          return `\u05E7\u05D8\u05DF \u05DE\u05D3\u05D9: ${m} ${b} \u05DC\u05D4\u05DB\u05D9\u05DC ${z}`.trim();
        }
        let v = l.inclusive ? ">=" : ">", y = n(l.origin ?? "value");
        return f?.unit ? `${f.shortLabel} \u05DE\u05D3\u05D9: ${m} ${y} ${v}${l.minimum.toString()} ${f.unit}` : `${f?.shortLabel ?? "\u05E7\u05D8\u05DF"} \u05DE\u05D3\u05D9: ${m} ${y} ${v}${l.minimum.toString()}`;
      }
      case "invalid_format": {
        let f = l;
        if (f.format === "starts_with")
          return `\u05D4\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D7\u05D9\u05D9\u05D1\u05EA \u05DC\u05D4\u05EA\u05D7\u05D9\u05DC \u05D1 "${f.prefix}"`;
        if (f.format === "ends_with")
          return `\u05D4\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D7\u05D9\u05D9\u05D1\u05EA \u05DC\u05D4\u05E1\u05EA\u05D9\u05D9\u05DD \u05D1 "${f.suffix}"`;
        if (f.format === "includes")
          return `\u05D4\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D7\u05D9\u05D9\u05D1\u05EA \u05DC\u05DB\u05DC\u05D5\u05DC "${f.includes}"`;
        if (f.format === "regex")
          return `\u05D4\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D7\u05D9\u05D9\u05D1\u05EA \u05DC\u05D4\u05EA\u05D0\u05D9\u05DD \u05DC\u05EA\u05D1\u05E0\u05D9\u05EA ${f.pattern}`;
        let m = c[f.format], v = m?.label ?? f.format, b = (m?.gender ?? "m") === "f" ? "\u05EA\u05E7\u05D9\u05E0\u05D4" : "\u05EA\u05E7\u05D9\u05DF";
        return `${v} \u05DC\u05D0 ${b}`;
      }
      case "not_multiple_of":
        return `\u05DE\u05E1\u05E4\u05E8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05D7\u05D9\u05D9\u05D1 \u05DC\u05D4\u05D9\u05D5\u05EA \u05DE\u05DB\u05E4\u05DC\u05D4 \u05E9\u05DC ${l.divisor}`;
      case "unrecognized_keys":
        return `\u05DE\u05E4\u05EA\u05D7${l.keys.length > 1 ? "\u05D5\u05EA" : ""} \u05DC\u05D0 \u05DE\u05D6\u05D5\u05D4${l.keys.length > 1 ? "\u05D9\u05DD" : "\u05D4"}: ${g(l.keys, ", ")}`;
      case "invalid_key":
        return "\u05E9\u05D3\u05D4 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF \u05D1\u05D0\u05D5\u05D1\u05D9\u05D9\u05E7\u05D8";
      case "invalid_union":
        return "\u05E7\u05DC\u05D8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF";
      case "invalid_element":
        return `\u05E2\u05E8\u05DA \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF \u05D1${t(l.origin ?? "array")}`;
      default:
        return "\u05E7\u05DC\u05D8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF";
    }
  };
}, "error");
function jc() {
  return {
    localeError: s$()
  };
}
s(jc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/hi.js
var c$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0905\u0915\u094D\u0937\u0930", verb: "\u0930\u0916\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F" },
    file: { unit: "\u092C\u093E\u0907\u091F\u094D\u0938", verb: "\u0930\u0916\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F" },
    array: { unit: "\u0924\u0924\u094D\u0935", verb: "\u0930\u0916\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F" },
    set: { unit: "\u0924\u0924\u094D\u0935", verb: "\u0930\u0916\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F" },
    map: { unit: "\u092A\u094D\u0930\u0935\u093F\u0937\u094D\u091F\u093F\u092F\u093E\u0901", verb: "\u0930\u0916\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u0907\u0928\u092A\u0941\u091F",
    email: "\u0908\u092E\u0947\u0932 \u092A\u0924\u093E",
    url: "URL",
    emoji: "\u0907\u092E\u094B\u091C\u0940",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0924\u093F\u0925\u093F \u0914\u0930 \u0938\u092E\u092F",
    date: "ISO \u0924\u093F\u0925\u093F",
    time: "ISO \u0938\u092E\u092F",
    duration: "ISO \u0905\u0935\u0927\u093F",
    ipv4: "IPv4 \u092A\u0924\u093E",
    ipv6: "IPv6 \u092A\u0924\u093E",
    mac: "MAC \u092A\u0924\u093E",
    cidrv4: "IPv4 \u0936\u094D\u0930\u0947\u0923\u0940",
    cidrv6: "IPv6 \u0936\u094D\u0930\u0947\u0923\u0940",
    base64: "Base64-\u090F\u0928\u094D\u0915\u094B\u0921\u0947\u0921 \u0938\u094D\u091F\u094D\u0930\u093F\u0902\u0917",
    base64url: "Base64URL-\u090F\u0928\u094D\u0915\u094B\u0921\u0947\u0921 \u0938\u094D\u091F\u094D\u0930\u093F\u0902\u0917",
    json_string: "JSON \u0938\u094D\u091F\u094D\u0930\u093F\u0902\u0917",
    e164: "E.164 \u0938\u0902\u0916\u094D\u092F\u093E",
    credit_card: "\u0915\u094D\u0930\u0947\u0921\u093F\u091F \u0915\u093E\u0930\u094D\u0921 \u0938\u0902\u0916\u094D\u092F\u093E",
    jwt: "JWT",
    template_literal: "\u0907\u0928\u092A\u0941\u091F"
  }, o = {
    nan: "NaN"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return `\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 ${n}, \u092A\u094D\u0930\u093E\u092A\u094D\u0924 ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 ${x(t.values[0])}` : `\u0905\u092E\u093E\u0928\u094D\u092F \u0935\u093F\u0915\u0932\u094D\u092A: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 \u092E\u093E\u0928\u094B\u0902 \u092E\u0947\u0902 \u0938\u0947 \u090F\u0915 ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u092C\u0939\u0941\u0924 \u092C\u0921\u093C\u093E: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 \u0925\u093E \u0915\u093F ${t.origin ?? "\u092E\u093E\u0928"} \u092E\u0947\u0902 ${n}${t.maximum} ${a.unit} \u0939\u094B\u0902` : `\u092C\u0939\u0941\u0924 \u092C\u0921\u093C\u093E: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 \u0925\u093E \u0915\u093F ${t.origin ?? "\u092E\u093E\u0928"} ${n}${t.maximum} \u0939\u094B`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u092C\u0939\u0941\u0924 \u091B\u094B\u091F\u093E: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 \u0925\u093E \u0915\u093F ${t.origin} \u092E\u0947\u0902 ${n}${t.minimum} ${a.unit} \u0939\u094B\u0902` : `\u092C\u0939\u0941\u0924 \u091B\u094B\u091F\u093E: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 \u0925\u093E \u0915\u093F ${t.origin} ${n}${t.minimum} \u0939\u094B`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0902\u0917: "${n.prefix}" \u0938\u0947 \u0936\u0941\u0930\u0942 \u0939\u094B\u0928\u093E \u091A\u093E\u0939\u093F\u090F` : n.format === "ends_with" ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0902\u0917: "${n.suffix}" \u092A\u0930 \u0938\u092E\u093E\u092A\u094D\u0924 \u0939\u094B\u0928\u093E \u091A\u093E\u0939\u093F\u090F` : n.format === "includes" ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0902\u0917: \u0907\u0938\u092E\u0947\u0902 "${n.includes}" \u0936\u093E\u092E\u093F\u0932 \u0939\u094B\u0928\u093E \u091A\u093E\u0939\u093F\u090F` : n.format === "regex" ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0902\u0917: \u092A\u0948\u091F\u0930\u094D\u0928 ${n.pattern} \u0938\u0947 \u092E\u0947\u0932 \u0916\u093E\u0928\u093E \u091A\u093E\u0939\u093F\u090F` : `\u0905\u092E\u093E\u0928\u094D\u092F ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u0902\u0916\u094D\u092F\u093E: \u092F\u0939 ${t.divisor} \u0915\u093E \u0917\u0941\u0923\u091C \u0939\u094B\u0928\u093E \u091A\u093E\u0939\u093F\u090F`;
      case "unrecognized_keys":
        return `\u0905\u092A\u0930\u093F\u091A\u093F\u0924 \u0915\u0941\u0902\u091C\u0940${t.keys.length > 1 ? "\u092F\u093E\u0901" : ""}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `\u0905\u092E\u093E\u0928\u094D\u092F \u0915\u0941\u0902\u091C\u0940: ${t.origin} \u092E\u0947\u0902`;
      case "invalid_union":
        return t.options && Array.isArray(t.options) && t.options.length > 0 ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0921\u093F\u0938\u094D\u0915\u094D\u0930\u093F\u092E\u093F\u0928\u0947\u091F\u0930 \u092E\u093E\u0928: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 ${t.options.map((a) => `'${a}'`).join(" | ")}` : "\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F";
      case "invalid_element":
        return `\u0905\u092E\u093E\u0928\u094D\u092F \u092E\u093E\u0928: ${t.origin} \u092E\u0947\u0902`;
      default:
        return "\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F";
    }
  };
}, "error");
function Ac() {
  return {
    localeError: c$()
  };
}
s(Ac, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/hr.js
var u$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "znakova", verb: "imati" },
    file: { unit: "bajtova", verb: "imati" },
    array: { unit: "stavki", verb: "imati" },
    set: { unit: "stavki", verb: "imati" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "unos",
    email: "email adresa",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datum i vrijeme",
    date: "ISO datum",
    time: "ISO vrijeme",
    duration: "ISO trajanje",
    ipv4: "IPv4 adresa",
    ipv6: "IPv6 adresa",
    mac: "MAC adresa",
    cidrv4: "IPv4 raspon",
    cidrv6: "IPv6 raspon",
    base64: "base64 kodirani tekst",
    base64url: "base64url kodirani tekst",
    json_string: "JSON tekst",
    e164: "E.164 broj",
    credit_card: "broj kreditne kartice",
    jwt: "JWT",
    template_literal: "unos"
  }, o = {
    nan: "NaN",
    string: "tekst",
    number: "broj",
    boolean: "boolean",
    array: "niz",
    object: "objekt",
    set: "skup",
    file: "datoteka",
    date: "datum",
    bigint: "bigint",
    symbol: "simbol",
    undefined: "undefined",
    null: "null",
    function: "funkcija",
    map: "mapa"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Neispravan unos: o\u010Dekuje se instanceof ${t.expected}, a primljeno je ${c}` : `Neispravan unos: o\u010Dekuje se ${n}, a primljeno je ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Neispravna vrijednost: o\u010Dekivano ${x(t.values[0])}` : `Neispravna opcija: o\u010Dekivano jedno od ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin), c = o[t.origin] ?? t.origin;
        return a ? `Preveliko: o\u010Dekivano da ${c ?? "vrijednost"} ima ${n}${t.maximum.toString()} ${a.unit ?? "elemenata"}` : `Preveliko: o\u010Dekivano da ${c ?? "vrijednost"} bude ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin), c = o[t.origin] ?? t.origin;
        return a ? `Premalo: o\u010Dekivano da ${c} ima ${n}${t.minimum.toString()} ${a.unit}` : `Premalo: o\u010Dekivano da ${c} bude ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Neispravan tekst: mora zapo\u010Dinjati s "${n.prefix}"` : n.format === "ends_with" ? `Neispravan tekst: mora zavr\u0161avati s "${n.suffix}"` : n.format === "includes" ? `Neispravan tekst: mora sadr\u017Eavati "${n.includes}"` : n.format === "regex" ? `Neispravan tekst: mora odgovarati uzorku ${n.pattern}` : `Neispravna ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Neispravan broj: mora biti vi\u0161ekratnik od ${t.divisor}`;
      case "unrecognized_keys":
        return `Neprepoznat${t.keys.length > 1 ? "i klju\u010Devi" : " klju\u010D"}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `Neispravan klju\u010D u ${o[t.origin] ?? t.origin}`;
      case "invalid_union":
        return "Neispravan unos";
      case "invalid_element":
        return `Neispravna vrijednost u ${o[t.origin] ?? t.origin}`;
      default:
        return "Neispravan unos";
    }
  };
}, "error");
function Pc() {
  return {
    localeError: u$()
  };
}
s(Pc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/hu.js
var l$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "karakter", verb: "legyen" },
    file: { unit: "byte", verb: "legyen" },
    array: { unit: "elem", verb: "legyen" },
    set: { unit: "elem", verb: "legyen" },
    map: { unit: "elem", verb: "legyen" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "bemenet",
    email: "email c\xEDm",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO id\u0151b\xE9lyeg",
    date: "ISO d\xE1tum",
    time: "ISO id\u0151",
    duration: "ISO id\u0151intervallum",
    ipv4: "IPv4 c\xEDm",
    ipv6: "IPv6 c\xEDm",
    mac: "MAC c\xEDm",
    cidrv4: "IPv4 tartom\xE1ny",
    cidrv6: "IPv6 tartom\xE1ny",
    base64: "base64-k\xF3dolt string",
    base64url: "base64url-k\xF3dolt string",
    json_string: "JSON string",
    e164: "E.164 sz\xE1m",
    credit_card: "hitelk\xE1rtyasz\xE1m",
    jwt: "JWT",
    template_literal: "bemenet"
  }, o = {
    nan: "NaN",
    number: "sz\xE1m",
    array: "t\xF6mb"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\xC9rv\xE9nytelen bemenet: a v\xE1rt \xE9rt\xE9k instanceof ${t.expected}, a kapott \xE9rt\xE9k ${c}` : `\xC9rv\xE9nytelen bemenet: a v\xE1rt \xE9rt\xE9k ${n}, a kapott \xE9rt\xE9k ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\xC9rv\xE9nytelen bemenet: a v\xE1rt \xE9rt\xE9k ${x(t.values[0])}` : `\xC9rv\xE9nytelen opci\xF3: valamelyik \xE9rt\xE9k v\xE1rt ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `T\xFAl nagy: ${t.origin ?? "\xE9rt\xE9k"} m\xE9rete t\xFAl nagy ${n}${t.maximum.toString()} ${a.unit ?? "elem"}` : `T\xFAl nagy: a bemeneti \xE9rt\xE9k ${t.origin ?? "\xE9rt\xE9k"} t\xFAl nagy: ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `T\xFAl kicsi: a bemeneti \xE9rt\xE9k ${t.origin} m\xE9rete t\xFAl kicsi ${n}${t.minimum.toString()} ${a.unit}` : `T\xFAl kicsi: a bemeneti \xE9rt\xE9k ${t.origin} t\xFAl kicsi ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\xC9rv\xE9nytelen string: "${n.prefix}" \xE9rt\xE9kkel kell kezd\u0151dnie` : n.format === "ends_with" ? `\xC9rv\xE9nytelen string: "${n.suffix}" \xE9rt\xE9kkel kell v\xE9gz\u0151dnie` : n.format === "includes" ? `\xC9rv\xE9nytelen string: "${n.includes}" \xE9rt\xE9ket kell tartalmaznia` : n.format === "regex" ? `\xC9rv\xE9nytelen string: ${n.pattern} mint\xE1nak kell megfelelnie` : `\xC9rv\xE9nytelen ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\xC9rv\xE9nytelen sz\xE1m: ${t.divisor} t\xF6bbsz\xF6r\xF6s\xE9nek kell lennie`;
      case "unrecognized_keys":
        return `Ismeretlen kulcs${t.keys.length > 1 ? "s" : ""}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `\xC9rv\xE9nytelen kulcs ${t.origin}`;
      case "invalid_union":
        return "\xC9rv\xE9nytelen bemenet";
      case "invalid_element":
        return `\xC9rv\xE9nytelen \xE9rt\xE9k: ${t.origin}`;
      default:
        return "\xC9rv\xE9nytelen bemenet";
    }
  };
}, "error");
function Dc() {
  return {
    localeError: l$()
  };
}
s(Dc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/hy.js
function sp(e, r, i) {
  return Math.abs(e) === 1 ? r : i;
}
s(sp, "getArmenianPlural");
function Tt(e) {
  if (!e)
    return "";
  let r = ["\u0561", "\u0565", "\u0568", "\u056B", "\u0578", "\u0578\u0582", "\u0585"], i = e[e.length - 1];
  return e + (r.includes(i) ? "\u0576" : "\u0568");
}
s(Tt, "withDefiniteArticle");
var d$ = /* @__PURE__ */ s(() => {
  let e = {
    string: {
      unit: {
        one: "\u0576\u0577\u0561\u0576",
        many: "\u0576\u0577\u0561\u0576\u0576\u0565\u0580"
      },
      verb: "\u0578\u0582\u0576\u0565\u0576\u0561\u056C"
    },
    file: {
      unit: {
        one: "\u0562\u0561\u0575\u0569",
        many: "\u0562\u0561\u0575\u0569\u0565\u0580"
      },
      verb: "\u0578\u0582\u0576\u0565\u0576\u0561\u056C"
    },
    array: {
      unit: {
        one: "\u057F\u0561\u0580\u0580",
        many: "\u057F\u0561\u0580\u0580\u0565\u0580"
      },
      verb: "\u0578\u0582\u0576\u0565\u0576\u0561\u056C"
    },
    set: {
      unit: {
        one: "\u057F\u0561\u0580\u0580",
        many: "\u057F\u0561\u0580\u0580\u0565\u0580"
      },
      verb: "\u0578\u0582\u0576\u0565\u0576\u0561\u056C"
    },
    map: {
      unit: {
        one: "\u057F\u0561\u0580\u0580",
        many: "\u057F\u0561\u0580\u0580\u0565\u0580"
      },
      verb: "\u0578\u0582\u0576\u0565\u0576\u0561\u056C"
    }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u0574\u0578\u0582\u057F\u0584",
    email: "\u0567\u056C. \u0570\u0561\u057D\u0581\u0565",
    url: "URL",
    emoji: "\u0567\u0574\u0578\u057B\u056B",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0561\u0574\u057D\u0561\u0569\u056B\u057E \u0587 \u056A\u0561\u0574",
    date: "ISO \u0561\u0574\u057D\u0561\u0569\u056B\u057E",
    time: "ISO \u056A\u0561\u0574",
    duration: "ISO \u057F\u0587\u0578\u0572\u0578\u0582\u0569\u0575\u0578\u0582\u0576",
    ipv4: "IPv4 \u0570\u0561\u057D\u0581\u0565",
    ipv6: "IPv6 \u0570\u0561\u057D\u0581\u0565",
    mac: "MAC \u0570\u0561\u057D\u0581\u0565",
    cidrv4: "IPv4 \u0574\u056B\u057B\u0561\u056F\u0561\u0575\u0584",
    cidrv6: "IPv6 \u0574\u056B\u057B\u0561\u056F\u0561\u0575\u0584",
    base64: "base64 \u0571\u0587\u0561\u0579\u0561\u0583\u0578\u057E \u057F\u0578\u0572",
    base64url: "base64url \u0571\u0587\u0561\u0579\u0561\u0583\u0578\u057E \u057F\u0578\u0572",
    json_string: "JSON \u057F\u0578\u0572",
    e164: "E.164 \u0570\u0561\u0574\u0561\u0580",
    credit_card: "\u056F\u0580\u0565\u0564\u056B\u057F \u0584\u0561\u0580\u057F\u056B \u0570\u0561\u0574\u0561\u0580",
    jwt: "JWT",
    template_literal: "\u0574\u0578\u0582\u057F\u0584"
  }, o = {
    nan: "NaN",
    number: "\u0569\u056B\u057E",
    array: "\u0566\u0561\u0576\u0563\u057E\u0561\u056E"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567\u0580 instanceof ${t.expected}, \u057D\u057F\u0561\u0581\u057E\u0565\u056C \u0567 ${c}` : `\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567\u0580 ${n}, \u057D\u057F\u0561\u0581\u057E\u0565\u056C \u0567 ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567\u0580 ${x(t.values[1])}` : `\u054D\u056D\u0561\u056C \u057F\u0561\u0580\u0562\u0565\u0580\u0561\u056F\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567\u0580 \u0570\u0565\u057F\u0587\u0575\u0561\u056C\u0576\u0565\u0580\u056B\u0581 \u0574\u0565\u056F\u0568\u055D ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        if (a) {
          let c = Number(t.maximum), u = sp(c, a.unit.one, a.unit.many);
          return `\u0549\u0561\u0583\u0561\u0566\u0561\u0576\u0581 \u0574\u0565\u056E \u0561\u0580\u056A\u0565\u0584\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567, \u0578\u0580 ${Tt(t.origin ?? "\u0561\u0580\u056A\u0565\u0584")} \u056F\u0578\u0582\u0576\u0565\u0576\u0561 ${n}${t.maximum.toString()} ${u}`;
        }
        return `\u0549\u0561\u0583\u0561\u0566\u0561\u0576\u0581 \u0574\u0565\u056E \u0561\u0580\u056A\u0565\u0584\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567, \u0578\u0580 ${Tt(t.origin ?? "\u0561\u0580\u056A\u0565\u0584")} \u056C\u056B\u0576\u056B ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        if (a) {
          let c = Number(t.minimum), u = sp(c, a.unit.one, a.unit.many);
          return `\u0549\u0561\u0583\u0561\u0566\u0561\u0576\u0581 \u0583\u0578\u0584\u0580 \u0561\u0580\u056A\u0565\u0584\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567, \u0578\u0580 ${Tt(t.origin)} \u056F\u0578\u0582\u0576\u0565\u0576\u0561 ${n}${t.minimum.toString()} ${u}`;
        }
        return `\u0549\u0561\u0583\u0561\u0566\u0561\u0576\u0581 \u0583\u0578\u0584\u0580 \u0561\u0580\u056A\u0565\u0584\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567, \u0578\u0580 ${Tt(t.origin)} \u056C\u056B\u0576\u056B ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u054D\u056D\u0561\u056C \u057F\u0578\u0572\u2024 \u057A\u0565\u057F\u0584 \u0567 \u057D\u056F\u057D\u057E\u056B "${n.prefix}"-\u0578\u057E` : n.format === "ends_with" ? `\u054D\u056D\u0561\u056C \u057F\u0578\u0572\u2024 \u057A\u0565\u057F\u0584 \u0567 \u0561\u057E\u0561\u0580\u057F\u057E\u056B "${n.suffix}"-\u0578\u057E` : n.format === "includes" ? `\u054D\u056D\u0561\u056C \u057F\u0578\u0572\u2024 \u057A\u0565\u057F\u0584 \u0567 \u057A\u0561\u0580\u0578\u0582\u0576\u0561\u056F\u056B "${n.includes}"` : n.format === "regex" ? `\u054D\u056D\u0561\u056C \u057F\u0578\u0572\u2024 \u057A\u0565\u057F\u0584 \u0567 \u0570\u0561\u0574\u0561\u057A\u0561\u057F\u0561\u057D\u056D\u0561\u0576\u056B ${n.pattern} \u0571\u0587\u0561\u0579\u0561\u0583\u056B\u0576` : `\u054D\u056D\u0561\u056C ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u054D\u056D\u0561\u056C \u0569\u056B\u057E\u2024 \u057A\u0565\u057F\u0584 \u0567 \u0562\u0561\u0566\u0574\u0561\u057A\u0561\u057F\u056B\u056F \u056C\u056B\u0576\u056B ${t.divisor}-\u056B`;
      case "unrecognized_keys":
        return `\u0549\u0573\u0561\u0576\u0561\u0579\u057E\u0561\u056E \u0562\u0561\u0576\u0561\u056C\u056B${t.keys.length > 1 ? "\u0576\u0565\u0580" : ""}. ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `\u054D\u056D\u0561\u056C \u0562\u0561\u0576\u0561\u056C\u056B ${Tt(t.origin)}-\u0578\u0582\u0574`;
      case "invalid_union":
        return "\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574";
      case "invalid_element":
        return `\u054D\u056D\u0561\u056C \u0561\u0580\u056A\u0565\u0584 ${Tt(t.origin)}-\u0578\u0582\u0574`;
      default:
        return "\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574";
    }
  };
}, "error");
function Nc() {
  return {
    localeError: d$()
  };
}
s(Nc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/id.js
var f$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "karakter", verb: "memiliki" },
    file: { unit: "byte", verb: "memiliki" },
    array: { unit: "item", verb: "memiliki" },
    set: { unit: "item", verb: "memiliki" },
    map: { unit: "item", verb: "memiliki" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "input",
    email: "alamat email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "tanggal dan waktu format ISO",
    date: "tanggal format ISO",
    time: "jam format ISO",
    duration: "durasi format ISO",
    ipv4: "alamat IPv4",
    ipv6: "alamat IPv6",
    mac: "alamat MAC",
    cidrv4: "rentang alamat IPv4",
    cidrv6: "rentang alamat IPv6",
    base64: "string dengan enkode base64",
    base64url: "string dengan enkode base64url",
    json_string: "string JSON",
    e164: "angka E.164",
    credit_card: "nomor kartu kredit",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Input tidak valid: diharapkan instanceof ${t.expected}, diterima ${c}` : `Input tidak valid: diharapkan ${n}, diterima ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Input tidak valid: diharapkan ${x(t.values[0])}` : `Pilihan tidak valid: diharapkan salah satu dari ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Terlalu besar: diharapkan ${t.origin ?? "value"} memiliki ${n}${t.maximum.toString()} ${a.unit ?? "elemen"}` : `Terlalu besar: diharapkan ${t.origin ?? "value"} menjadi ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Terlalu kecil: diharapkan ${t.origin} memiliki ${n}${t.minimum.toString()} ${a.unit}` : `Terlalu kecil: diharapkan ${t.origin} menjadi ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `String tidak valid: harus dimulai dengan "${n.prefix}"` : n.format === "ends_with" ? `String tidak valid: harus berakhir dengan "${n.suffix}"` : n.format === "includes" ? `String tidak valid: harus menyertakan "${n.includes}"` : n.format === "regex" ? `String tidak valid: harus sesuai pola ${n.pattern}` : `${i[n.format] ?? t.format} tidak valid`;
      }
      case "not_multiple_of":
        return `Angka tidak valid: harus kelipatan dari ${t.divisor}`;
      case "unrecognized_keys":
        return `Kunci tidak dikenali ${t.keys.length > 1 ? "s" : ""}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `Kunci tidak valid di ${t.origin}`;
      case "invalid_union":
        return "Input tidak valid";
      case "invalid_element":
        return `Nilai tidak valid di ${t.origin}`;
      default:
        return "Input tidak valid";
    }
  };
}, "error");
function Tc() {
  return {
    localeError: f$()
  };
}
s(Tc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/is.js
var p$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "stafi", verb: "a\xF0 hafa" },
    file: { unit: "b\xE6ti", verb: "a\xF0 hafa" },
    array: { unit: "hluti", verb: "a\xF0 hafa" },
    set: { unit: "hluti", verb: "a\xF0 hafa" },
    map: { unit: "hluti", verb: "a\xF0 hafa" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "gildi",
    email: "netfang",
    url: "vefsl\xF3\xF0",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO dagsetning og t\xEDmi",
    date: "ISO dagsetning",
    time: "ISO t\xEDmi",
    duration: "ISO t\xEDmalengd",
    ipv4: "IPv4 address",
    ipv6: "IPv6 address",
    mac: "MAC address",
    cidrv4: "IPv4 range",
    cidrv6: "IPv6 range",
    base64: "base64-encoded strengur",
    base64url: "base64url-encoded strengur",
    json_string: "JSON strengur",
    e164: "E.164 t\xF6lugildi",
    credit_card: "kreditkortan\xFAmer",
    jwt: "JWT",
    template_literal: "gildi"
  }, o = {
    nan: "NaN",
    number: "n\xFAmer",
    array: "fylki"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Rangt gildi: \xDE\xFA sl\xF3st inn ${c} \xFEar sem \xE1 a\xF0 vera instanceof ${t.expected}` : `Rangt gildi: \xDE\xFA sl\xF3st inn ${c} \xFEar sem \xE1 a\xF0 vera ${n}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Rangt gildi: gert r\xE1\xF0 fyrir ${x(t.values[0])}` : `\xD3gilt val: m\xE1 vera eitt af eftirfarandi ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Of st\xF3rt: gert er r\xE1\xF0 fyrir a\xF0 ${t.origin ?? "gildi"} hafi ${n}${t.maximum.toString()} ${a.unit ?? "hluti"}` : `Of st\xF3rt: gert er r\xE1\xF0 fyrir a\xF0 ${t.origin ?? "gildi"} s\xE9 ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Of l\xEDti\xF0: gert er r\xE1\xF0 fyrir a\xF0 ${t.origin} hafi ${n}${t.minimum.toString()} ${a.unit}` : `Of l\xEDti\xF0: gert er r\xE1\xF0 fyrir a\xF0 ${t.origin} s\xE9 ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\xD3gildur strengur: ver\xF0ur a\xF0 byrja \xE1 "${n.prefix}"` : n.format === "ends_with" ? `\xD3gildur strengur: ver\xF0ur a\xF0 enda \xE1 "${n.suffix}"` : n.format === "includes" ? `\xD3gildur strengur: ver\xF0ur a\xF0 innihalda "${n.includes}"` : n.format === "regex" ? `\xD3gildur strengur: ver\xF0ur a\xF0 fylgja mynstri ${n.pattern}` : `Rangt ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `R\xF6ng tala: ver\xF0ur a\xF0 vera margfeldi af ${t.divisor}`;
      case "unrecognized_keys":
        return `\xD3\xFEekkt ${t.keys.length > 1 ? "ir lyklar" : "ur lykill"}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `Rangur lykill \xED ${t.origin}`;
      case "invalid_union":
        return "Rangt gildi";
      case "invalid_element":
        return `Rangt gildi \xED ${t.origin}`;
      default:
        return "Rangt gildi";
    }
  };
}, "error");
function Uc() {
  return {
    localeError: p$()
  };
}
s(Uc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/it.js
var m$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "caratteri", verb: "avere" },
    file: { unit: "byte", verb: "avere" },
    array: { unit: "elementi", verb: "avere" },
    set: { unit: "elementi", verb: "avere" },
    map: { unit: "elementi", verb: "avere" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "input",
    email: "indirizzo email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "data e ora ISO",
    date: "data ISO",
    time: "ora ISO",
    duration: "durata ISO",
    ipv4: "indirizzo IPv4",
    ipv6: "indirizzo IPv6",
    mac: "indirizzo MAC",
    cidrv4: "intervallo IPv4",
    cidrv6: "intervallo IPv6",
    base64: "stringa codificata in base64",
    base64url: "URL codificata in base64",
    json_string: "stringa JSON",
    e164: "numero E.164",
    credit_card: "numero di carta di credito",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN",
    number: "numero",
    array: "vettore"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Input non valido: atteso instanceof ${t.expected}, ricevuto ${c}` : `Input non valido: atteso ${n}, ricevuto ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Input non valido: atteso ${x(t.values[0])}` : `Opzione non valida: atteso uno tra ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Troppo grande: ${t.origin ?? "valore"} deve avere ${n}${t.maximum.toString()} ${a.unit ?? "elementi"}` : `Troppo grande: ${t.origin ?? "valore"} deve essere ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Troppo piccolo: ${t.origin} deve avere ${n}${t.minimum.toString()} ${a.unit}` : `Troppo piccolo: ${t.origin} deve essere ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Stringa non valida: deve iniziare con "${n.prefix}"` : n.format === "ends_with" ? `Stringa non valida: deve terminare con "${n.suffix}"` : n.format === "includes" ? `Stringa non valida: deve includere "${n.includes}"` : n.format === "regex" ? `Stringa non valida: deve corrispondere al pattern ${n.pattern}` : `Input non valido: ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Numero non valido: deve essere un multiplo di ${t.divisor}`;
      case "unrecognized_keys":
        return `Chiav${t.keys.length > 1 ? "i" : "e"} non riconosciut${t.keys.length > 1 ? "e" : "a"}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `Chiave non valida in ${t.origin}`;
      case "invalid_union":
        return "Input non valido";
      case "invalid_element":
        return `Valore non valido in ${t.origin}`;
      default:
        return "Input non valido";
    }
  };
}, "error");
function Ec() {
  return {
    localeError: m$()
  };
}
s(Ec, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ja.js
var h$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u6587\u5B57", verb: "\u3067\u3042\u308B" },
    file: { unit: "\u30D0\u30A4\u30C8", verb: "\u3067\u3042\u308B" },
    array: { unit: "\u8981\u7D20", verb: "\u3067\u3042\u308B" },
    set: { unit: "\u8981\u7D20", verb: "\u3067\u3042\u308B" },
    map: { unit: "\u8981\u7D20", verb: "\u3067\u3042\u308B" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u5165\u529B\u5024",
    email: "\u30E1\u30FC\u30EB\u30A2\u30C9\u30EC\u30B9",
    url: "URL",
    emoji: "\u7D75\u6587\u5B57",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO\u65E5\u6642",
    date: "ISO\u65E5\u4ED8",
    time: "ISO\u6642\u523B",
    duration: "ISO\u671F\u9593",
    ipv4: "IPv4\u30A2\u30C9\u30EC\u30B9",
    ipv6: "IPv6\u30A2\u30C9\u30EC\u30B9",
    mac: "MAC\u30A2\u30C9\u30EC\u30B9",
    cidrv4: "IPv4\u7BC4\u56F2",
    cidrv6: "IPv6\u7BC4\u56F2",
    base64: "base64\u30A8\u30F3\u30B3\u30FC\u30C9\u6587\u5B57\u5217",
    base64url: "base64url\u30A8\u30F3\u30B3\u30FC\u30C9\u6587\u5B57\u5217",
    json_string: "JSON\u6587\u5B57\u5217",
    e164: "E.164\u756A\u53F7",
    credit_card: "\u30AF\u30EC\u30B8\u30C3\u30C8\u30AB\u30FC\u30C9\u756A\u53F7",
    jwt: "JWT",
    template_literal: "\u5165\u529B\u5024"
  }, o = {
    nan: "NaN",
    number: "\u6570\u5024",
    array: "\u914D\u5217"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u7121\u52B9\u306A\u5165\u529B: instanceof ${t.expected}\u304C\u671F\u5F85\u3055\u308C\u307E\u3057\u305F\u304C\u3001${c}\u304C\u5165\u529B\u3055\u308C\u307E\u3057\u305F` : `\u7121\u52B9\u306A\u5165\u529B: ${n}\u304C\u671F\u5F85\u3055\u308C\u307E\u3057\u305F\u304C\u3001${c}\u304C\u5165\u529B\u3055\u308C\u307E\u3057\u305F`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u7121\u52B9\u306A\u5165\u529B: ${x(t.values[0])}\u304C\u671F\u5F85\u3055\u308C\u307E\u3057\u305F` : `\u7121\u52B9\u306A\u9078\u629E: ${g(t.values, "\u3001")}\u306E\u3044\u305A\u308C\u304B\u3067\u3042\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`;
      case "too_big": {
        let n = t.inclusive ? "\u4EE5\u4E0B\u3067\u3042\u308B" : "\u3088\u308A\u5C0F\u3055\u3044", a = r(t.origin);
        return a ? `\u5927\u304D\u3059\u304E\u308B\u5024: ${t.origin ?? "\u5024"}\u306F${t.maximum.toString()}${a.unit ?? "\u8981\u7D20"}${n}\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : `\u5927\u304D\u3059\u304E\u308B\u5024: ${t.origin ?? "\u5024"}\u306F${t.maximum.toString()}${n}\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`;
      }
      case "too_small": {
        let n = t.inclusive ? "\u4EE5\u4E0A\u3067\u3042\u308B" : "\u3088\u308A\u5927\u304D\u3044", a = r(t.origin);
        return a ? `\u5C0F\u3055\u3059\u304E\u308B\u5024: ${t.origin}\u306F${t.minimum.toString()}${a.unit}${n}\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : `\u5C0F\u3055\u3059\u304E\u308B\u5024: ${t.origin}\u306F${t.minimum.toString()}${n}\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u7121\u52B9\u306A\u6587\u5B57\u5217: "${n.prefix}"\u3067\u59CB\u307E\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : n.format === "ends_with" ? `\u7121\u52B9\u306A\u6587\u5B57\u5217: "${n.suffix}"\u3067\u7D42\u308F\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : n.format === "includes" ? `\u7121\u52B9\u306A\u6587\u5B57\u5217: "${n.includes}"\u3092\u542B\u3080\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : n.format === "regex" ? `\u7121\u52B9\u306A\u6587\u5B57\u5217: \u30D1\u30BF\u30FC\u30F3${n.pattern}\u306B\u4E00\u81F4\u3059\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : `\u7121\u52B9\u306A${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u7121\u52B9\u306A\u6570\u5024: ${t.divisor}\u306E\u500D\u6570\u3067\u3042\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`;
      case "unrecognized_keys":
        return `\u8A8D\u8B58\u3055\u308C\u3066\u3044\u306A\u3044\u30AD\u30FC${t.keys.length > 1 ? "\u7FA4" : ""}: ${g(t.keys, "\u3001")}`;
      case "invalid_key":
        return `${t.origin}\u5185\u306E\u7121\u52B9\u306A\u30AD\u30FC`;
      case "invalid_union":
        return "\u7121\u52B9\u306A\u5165\u529B";
      case "invalid_element":
        return `${t.origin}\u5185\u306E\u7121\u52B9\u306A\u5024`;
      default:
        return "\u7121\u52B9\u306A\u5165\u529B";
    }
  };
}, "error");
function Cc() {
  return {
    localeError: h$()
  };
}
s(Cc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ka.js
var g$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u10E1\u10D8\u10DB\u10D1\u10DD\u10DA\u10DD", verb: "\u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1" },
    file: { unit: "\u10D1\u10D0\u10D8\u10E2\u10D8", verb: "\u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1" },
    array: { unit: "\u10D4\u10DA\u10D4\u10DB\u10D4\u10DC\u10E2\u10D8", verb: "\u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1" },
    set: { unit: "\u10D4\u10DA\u10D4\u10DB\u10D4\u10DC\u10E2\u10D8", verb: "\u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1" },
    map: { unit: "\u10D4\u10DA\u10D4\u10DB\u10D4\u10DC\u10E2\u10D8", verb: "\u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0",
    email: "\u10D4\u10DA-\u10E4\u10DD\u10E1\u10E2\u10D8\u10E1 \u10DB\u10D8\u10E1\u10D0\u10DB\u10D0\u10E0\u10D7\u10D8",
    url: "URL",
    emoji: "\u10D4\u10DB\u10DD\u10EF\u10D8",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u10D7\u10D0\u10E0\u10D8\u10E6\u10D8-\u10D3\u10E0\u10DD",
    date: "\u10D7\u10D0\u10E0\u10D8\u10E6\u10D8",
    time: "\u10D3\u10E0\u10DD",
    duration: "\u10EE\u10D0\u10DC\u10D2\u10E0\u10EB\u10DA\u10D8\u10D5\u10DD\u10D1\u10D0",
    ipv4: "IPv4 \u10DB\u10D8\u10E1\u10D0\u10DB\u10D0\u10E0\u10D7\u10D8",
    ipv6: "IPv6 \u10DB\u10D8\u10E1\u10D0\u10DB\u10D0\u10E0\u10D7\u10D8",
    mac: "MAC \u10DB\u10D8\u10E1\u10D0\u10DB\u10D0\u10E0\u10D7\u10D8",
    cidrv4: "IPv4 \u10D3\u10D8\u10D0\u10DE\u10D0\u10D6\u10DD\u10DC\u10D8",
    cidrv6: "IPv6 \u10D3\u10D8\u10D0\u10DE\u10D0\u10D6\u10DD\u10DC\u10D8",
    base64: "base64-\u10D9\u10DD\u10D3\u10D8\u10E0\u10D4\u10D1\u10E3\u10DA\u10D8 \u10D5\u10D4\u10DA\u10D8",
    base64url: "base64url-\u10D9\u10DD\u10D3\u10D8\u10E0\u10D4\u10D1\u10E3\u10DA\u10D8 \u10D5\u10D4\u10DA\u10D8",
    json_string: "JSON \u10D5\u10D4\u10DA\u10D8",
    e164: "E.164 \u10DC\u10DD\u10DB\u10D4\u10E0\u10D8",
    credit_card: "\u10E1\u10D0\u10D9\u10E0\u10D4\u10D3\u10D8\u10E2\u10DD \u10D1\u10D0\u10E0\u10D0\u10D7\u10D8\u10E1 \u10DC\u10DD\u10DB\u10D4\u10E0\u10D8",
    jwt: "JWT",
    template_literal: "\u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0"
  }, o = {
    nan: "NaN",
    number: "\u10E0\u10D8\u10EA\u10EE\u10D5\u10D8",
    string: "\u10D5\u10D4\u10DA\u10D8",
    boolean: "\u10D1\u10E3\u10DA\u10D4\u10D0\u10DC\u10D8",
    function: "\u10E4\u10E3\u10DC\u10E5\u10EA\u10D8\u10D0",
    array: "\u10DB\u10D0\u10E1\u10D8\u10D5\u10D8"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 instanceof ${t.expected}, \u10DB\u10D8\u10E6\u10D4\u10D1\u10E3\u10DA\u10D8 ${c}` : `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${n}, \u10DB\u10D8\u10E6\u10D4\u10D1\u10E3\u10DA\u10D8 ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${x(t.values[0])}` : `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D5\u10D0\u10E0\u10D8\u10D0\u10DC\u10E2\u10D8: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8\u10D0 \u10D4\u10E0\u10D7-\u10D4\u10E0\u10D7\u10D8 ${g(t.values, "|")}-\u10D3\u10D0\u10DC`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u10D6\u10D4\u10D3\u10DB\u10D4\u10E2\u10D0\u10D3 \u10D3\u10D8\u10D3\u10D8: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${t.origin ?? "\u10DB\u10DC\u10D8\u10E8\u10D5\u10DC\u10D4\u10DA\u10DD\u10D1\u10D0"} ${a.verb} ${n}${t.maximum.toString()} ${a.unit}` : `\u10D6\u10D4\u10D3\u10DB\u10D4\u10E2\u10D0\u10D3 \u10D3\u10D8\u10D3\u10D8: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${t.origin ?? "\u10DB\u10DC\u10D8\u10E8\u10D5\u10DC\u10D4\u10DA\u10DD\u10D1\u10D0"} \u10D8\u10E7\u10DD\u10E1 ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u10D6\u10D4\u10D3\u10DB\u10D4\u10E2\u10D0\u10D3 \u10DE\u10D0\u10E2\u10D0\u10E0\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${t.origin} ${a.verb} ${n}${t.minimum.toString()} ${a.unit}` : `\u10D6\u10D4\u10D3\u10DB\u10D4\u10E2\u10D0\u10D3 \u10DE\u10D0\u10E2\u10D0\u10E0\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${t.origin} \u10D8\u10E7\u10DD\u10E1 ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D5\u10D4\u10DA\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10D8\u10EC\u10E7\u10D4\u10D1\u10DD\u10D3\u10D4\u10E1 "${n.prefix}"-\u10D8\u10D7` : n.format === "ends_with" ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D5\u10D4\u10DA\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10DB\u10D7\u10D0\u10D5\u10E0\u10D3\u10D4\u10D1\u10DD\u10D3\u10D4\u10E1 "${n.suffix}"-\u10D8\u10D7` : n.format === "includes" ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D5\u10D4\u10DA\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1 "${n.includes}"-\u10E1` : n.format === "regex" ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D5\u10D4\u10DA\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D4\u10E1\u10D0\u10D1\u10D0\u10DB\u10D4\u10D1\u10DD\u10D3\u10D4\u10E1 \u10E8\u10D0\u10D1\u10DA\u10DD\u10DC\u10E1 ${n.pattern}` : `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E0\u10D8\u10EA\u10EE\u10D5\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10D8\u10E7\u10DD\u10E1 ${t.divisor}-\u10D8\u10E1 \u10EF\u10D4\u10E0\u10D0\u10D3\u10D8`;
      case "unrecognized_keys":
        return `\u10E3\u10EA\u10DC\u10DD\u10D1\u10D8 \u10D2\u10D0\u10E1\u10D0\u10E6\u10D4\u10D1${t.keys.length > 1 ? "\u10D4\u10D1\u10D8" : "\u10D8"}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D2\u10D0\u10E1\u10D0\u10E6\u10D4\u10D1\u10D8 ${t.origin}-\u10E8\u10D8`;
      case "invalid_union":
        return "\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0";
      case "invalid_element":
        return `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10DB\u10DC\u10D8\u10E8\u10D5\u10DC\u10D4\u10DA\u10DD\u10D1\u10D0 ${t.origin}-\u10E8\u10D8`;
      default:
        return "\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0";
    }
  };
}, "error");
function Zc() {
  return {
    localeError: g$()
  };
}
s(Zc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/km.js
var v$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u178F\u17BD\u17A2\u1780\u17D2\u179F\u179A", verb: "\u1782\u17BD\u179A\u1798\u17B6\u1793" },
    file: { unit: "\u1794\u17C3", verb: "\u1782\u17BD\u179A\u1798\u17B6\u1793" },
    array: { unit: "\u1792\u17B6\u178F\u17BB", verb: "\u1782\u17BD\u179A\u1798\u17B6\u1793" },
    set: { unit: "\u1792\u17B6\u178F\u17BB", verb: "\u1782\u17BD\u179A\u1798\u17B6\u1793" },
    map: { unit: "\u1792\u17B6\u178F\u17BB", verb: "\u1782\u17BD\u179A\u1798\u17B6\u1793" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B",
    email: "\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793\u17A2\u17CA\u17B8\u1798\u17C2\u179B",
    url: "URL",
    emoji: "\u179F\u1789\u17D2\u1789\u17B6\u17A2\u17B6\u179A\u1798\u17D2\u1798\u178E\u17CD",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u1780\u17B6\u179B\u1794\u179A\u17B7\u1785\u17D2\u1786\u17C1\u1791 \u1793\u17B7\u1784\u1798\u17C9\u17C4\u1784 ISO",
    date: "\u1780\u17B6\u179B\u1794\u179A\u17B7\u1785\u17D2\u1786\u17C1\u1791 ISO",
    time: "\u1798\u17C9\u17C4\u1784 ISO",
    duration: "\u179A\u1799\u17C8\u1796\u17C1\u179B ISO",
    ipv4: "\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793 IPv4",
    ipv6: "\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793 IPv6",
    mac: "\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793 MAC",
    cidrv4: "\u178A\u17C2\u1793\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793 IPv4",
    cidrv6: "\u178A\u17C2\u1793\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793 IPv6",
    base64: "\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u17A2\u17CA\u17B7\u1780\u17BC\u178A base64",
    base64url: "\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u17A2\u17CA\u17B7\u1780\u17BC\u178A base64url",
    json_string: "\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A JSON",
    e164: "\u179B\u17C1\u1781 E.164",
    credit_card: "\u179B\u17C1\u1781\u1794\u17D0\u178E\u17D2\u178E\u17A5\u178E\u1791\u17B6\u1793",
    jwt: "JWT",
    template_literal: "\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B"
  }, o = {
    nan: "NaN",
    number: "\u179B\u17C1\u1781",
    array: "\u17A2\u17B6\u179A\u17C1 (Array)",
    null: "\u1782\u17D2\u1798\u17B6\u1793\u178F\u1798\u17D2\u179B\u17C3 (null)"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A instanceof ${t.expected} \u1794\u17C9\u17BB\u1793\u17D2\u178F\u17C2\u1791\u1791\u17BD\u179B\u1794\u17B6\u1793 ${c}` : `\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${n} \u1794\u17C9\u17BB\u1793\u17D2\u178F\u17C2\u1791\u1791\u17BD\u179B\u1794\u17B6\u1793 ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${x(t.values[0])}` : `\u1787\u1798\u17D2\u179A\u17BE\u179F\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1787\u17B6\u1798\u17BD\u1799\u1780\u17D2\u1793\u17BB\u1784\u1785\u17C6\u178E\u17C4\u1798 ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u1792\u17C6\u1796\u17C1\u1780\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${t.origin ?? "\u178F\u1798\u17D2\u179B\u17C3"} ${n} ${t.maximum.toString()} ${a.unit ?? "\u1792\u17B6\u178F\u17BB"}` : `\u1792\u17C6\u1796\u17C1\u1780\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${t.origin ?? "\u178F\u1798\u17D2\u179B\u17C3"} ${n} ${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u178F\u17BC\u1785\u1796\u17C1\u1780\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${t.origin} ${n} ${t.minimum.toString()} ${a.unit}` : `\u178F\u17BC\u1785\u1796\u17C1\u1780\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${t.origin} ${n} ${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1785\u17B6\u1794\u17CB\u1795\u17D2\u178F\u17BE\u1798\u178A\u17C4\u1799 "${n.prefix}"` : n.format === "ends_with" ? `\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1794\u1789\u17D2\u1785\u1794\u17CB\u178A\u17C4\u1799 "${n.suffix}"` : n.format === "includes" ? `\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1798\u17B6\u1793 "${n.includes}"` : n.format === "regex" ? `\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u178F\u17C2\u1795\u17D2\u1782\u17BC\u1795\u17D2\u1782\u1784\u1793\u17B9\u1784\u1791\u1798\u17D2\u179A\u1784\u17CB\u178A\u17C2\u179B\u1794\u17B6\u1793\u1780\u17C6\u178E\u178F\u17CB ${n.pattern}` : `\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u179B\u17C1\u1781\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u178F\u17C2\u1787\u17B6\u1796\u17A0\u17BB\u1782\u17BB\u178E\u1793\u17C3 ${t.divisor}`;
      case "unrecognized_keys":
        return `\u179A\u1780\u1783\u17BE\u1789\u179F\u17C4\u1798\u17B7\u1793\u179F\u17D2\u1782\u17B6\u179B\u17CB\u17D6 ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `\u179F\u17C4\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u1793\u17C5\u1780\u17D2\u1793\u17BB\u1784 ${t.origin}`;
      case "invalid_union":
        return "\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C";
      case "invalid_element":
        return `\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u1793\u17C5\u1780\u17D2\u1793\u17BB\u1784 ${t.origin}`;
      default:
        return "\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C";
    }
  };
}, "error");
function Cr() {
  return {
    localeError: v$()
  };
}
s(Cr, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/kh.js
function Rc() {
  return Cr();
}
s(Rc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/kn.js
var y$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0C85\u0C95\u0CCD\u0CB7\u0CB0\u0C97\u0CB3\u0CC1", verb: "\u0CB9\u0CCA\u0C82\u0CA6\u0CB2\u0CC1" },
    file: { unit: "\u0CAC\u0CC8\u0C9F\u0CCD\u200C\u0C97\u0CB3\u0CC1", verb: "\u0CB9\u0CCA\u0C82\u0CA6\u0CB2\u0CC1" },
    array: { unit: "\u0CB5\u0CB8\u0CCD\u0CA4\u0CC1\u0C97\u0CB3\u0CC1", verb: "\u0CB9\u0CCA\u0C82\u0CA6\u0CB2\u0CC1" },
    set: { unit: "\u0CB5\u0CB8\u0CCD\u0CA4\u0CC1\u0C97\u0CB3\u0CC1", verb: "\u0CB9\u0CCA\u0C82\u0CA6\u0CB2\u0CC1" },
    map: { unit: "entries", verb: "\u0CB9\u0CCA\u0C82\u0CA6\u0CB2\u0CC1" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u0C87\u0CA8\u0CCD\u0CAA\u0CC1\u0C9F\u0CCD",
    email: "email \u0CB5\u0CBF\u0CB3\u0CBE\u0CB8",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0CA6\u0CBF\u0CA8\u0CBE\u0C82\u0C95\u0CA6 \u0CB8\u0CAE\u0CAF",
    date: "ISO \u0CA6\u0CBF\u0CA8\u0CBE\u0C82\u0C95",
    time: "ISO \u0CB8\u0CAE\u0CAF",
    duration: "ISO \u0C85\u0CB5\u0CA7\u0CBF",
    ipv4: "IPv4 \u0CB5\u0CBF\u0CB3\u0CBE\u0CB8",
    ipv6: "IPv6 \u0CB5\u0CBF\u0CB3\u0CBE\u0CB8",
    mac: "MAC \u0CB5\u0CBF\u0CB3\u0CBE\u0CB8",
    cidrv4: "IPv4 \u0CB5\u0CCD\u0CAF\u0CBE\u0CAA\u0CCD\u0CA4\u0CBF\u0CAF",
    cidrv6: "IPv6 \u0CB5\u0CCD\u0CAF\u0CBE\u0CAA\u0CCD\u0CA4\u0CBF\u0CAF",
    base64: "base64-encoded\u0CB8\u0CCD\u0C9F\u0CCD\u0CB0\u0CBF\u0C82\u0C97\u0CCD",
    base64url: "base64url-encoded\u0CB8\u0CCD\u0C9F\u0CCD\u0CB0\u0CBF\u0C82\u0C97\u0CCD",
    json_string: "JSON\u0CB8\u0CCD\u0C9F\u0CCD\u0CB0\u0CBF\u0C82\u0C97\u0CCD",
    e164: "E.164 \u0CB8\u0C82\u0C96\u0CCD\u0CAF\u0CC6",
    credit_card: "\u0C95\u0CCD\u0CB0\u0CC6\u0CA1\u0CBF\u0C9F\u0CCD \u0C95\u0CBE\u0CB0\u0CCD\u0CA1\u0CCD \u0CB8\u0C82\u0C96\u0CCD\u0CAF\u0CC6",
    jwt: "JWT",
    template_literal: "\u0C87\u0CA8\u0CCD\u0CAA\u0CC1\u0C9F\u0CCD"
  }, o = {
    // Compatibility: "nan" -> "NaN" for display
    nan: "NaN"
    // All other type names omitted - they fall back to raw values via ?? operator
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0C87\u0CA8\u0CCD\u200C\u0CAA\u0CC1\u0C9F\u0CCD: \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${n}, \u0CB8\u0CCD\u0CB5\u0CC0\u0C95\u0CB0\u0CBF\u0CB8\u0CBF\u0CA6\u0CA8\u0CC1 ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0C87\u0CA8\u0CCD\u200C\u0CAA\u0CC1\u0C9F\u0CCD: \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${x(t.values[0])}` : `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0C86\u0CAF\u0CCD\u0C95\u0CC6: \u0C87\u0CB5\u0CC1\u0C97\u0CB3\u0CB2\u0CCD\u0CB2\u0CBF \u0C92\u0C82\u0CA6\u0CA8\u0CCD\u0CA8\u0CC1 \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u0CA4\u0CC1\u0C82\u0CAC\u0CBE \u0CA6\u0CCA\u0CA1\u0CCD\u0CA1\u0CA6\u0CC1: \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${t.origin ?? "value"} \u0CB9\u0CCA\u0C82\u0CA6\u0CB2\u0CC1 ${n}${t.maximum.toString()} ${a.unit ?? "\u0C85\u0C82\u0CB6\u0C97\u0CB3\u0CC1"}` : `\u0CA4\u0CC1\u0C82\u0CAC\u0CBE \u0CA6\u0CCA\u0CA1\u0CCD\u0CA1\u0CA6\u0CC1: \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${t.origin ?? "value"} \u0C8E\u0C82\u0CA6\u0CC1 ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u0CA4\u0CC1\u0C82\u0CAC\u0CBE \u0C9A\u0CBF\u0C95\u0CCD\u0C95\u0CA6\u0CC1: \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${t.origin} \u0CB9\u0CCA\u0C82\u0CA6\u0CB2\u0CC1 ${n}${t.minimum.toString()} ${a.unit}` : `\u0CA4\u0CC1\u0C82\u0CAC\u0CBE \u0C9A\u0CBF\u0C95\u0CCD\u0C95\u0CA6\u0CC1: \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${t.origin} \u0C8E\u0C82\u0CA6\u0CC1 ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF\u0CB5\u0CBE\u0CA6 \u0CB8\u0CCD\u0C9F\u0CCD\u0CB0\u0CBF\u0C82\u0C97\u0CCD: \u0C87\u0CA6\u0CB0\u0CCA\u0C82\u0CA6\u0CBF\u0C97\u0CC6 \u0CAA\u0CCD\u0CB0\u0CBE\u0CB0\u0C82\u0CAD\u0CBF\u0CB8\u0CAC\u0CC7\u0C95\u0CC1 "${n.prefix}"` : n.format === "ends_with" ? `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF\u0CB5\u0CBE\u0CA6 \u0CB8\u0CCD\u0C9F\u0CCD\u0CB0\u0CBF\u0C82\u0C97\u0CCD: \u0C87\u0CA6\u0CB0\u0CCA\u0C82\u0CA6\u0CBF\u0C97\u0CC6 \u0C95\u0CCA\u0CA8\u0CC6\u0C97\u0CCA\u0CB3\u0CCD\u0CB3\u0CAC\u0CC7\u0C95\u0CC1 "${n.suffix}"` : n.format === "includes" ? `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0CB8\u0CCD\u0C9F\u0CCD\u0CB0\u0CBF\u0C82\u0C97\u0CCD: \u0C92\u0CB3\u0C97\u0CCA\u0C82\u0CA1\u0CBF\u0CB0\u0CAC\u0CC7\u0C95\u0CC1 "${n.includes}"` : n.format === "regex" ? `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF\u0CB5\u0CBE\u0CA6 \u0CB8\u0CCD\u0C9F\u0CCD\u0CB0\u0CBF\u0C82\u0C97\u0CCD: \u0CAE\u0CBE\u0CA6\u0CB0\u0CBF\u0C97\u0CC6 \u0CB9\u0CCA\u0C82\u0CA6\u0CBF\u0C95\u0CC6\u0CAF\u0CBE\u0C97\u0CAC\u0CC7\u0C95\u0CC1 ${n.pattern}` : `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0CB8\u0C82\u0C96\u0CCD\u0CAF\u0CC6: \u0CAC\u0CB9\u0CC1\u0CB8\u0C82\u0C96\u0CCD\u0CAF\u0CC6\u0CAF\u0CBE\u0C97\u0CBF\u0CB0\u0CAC\u0CC7\u0C95\u0CC1 ${t.divisor}`;
      case "unrecognized_keys":
        return `\u0C97\u0CC1\u0CB0\u0CC1\u0CA4\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CA6 \u0C95\u0CC0 ${t.keys.length > 1 ? "s" : ""}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF\u0CB5\u0CBE\u0CA6 \u0C95\u0CC0 \u0C87\u0CA8\u0CCD ${t.origin}`;
      case "invalid_union":
        return t.options && Array.isArray(t.options) && t.options.length > 0 ? `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0CA4\u0CBE\u0CB0\u0CA4\u0CAE\u0CCD\u0CAF \u0CAE\u0CCC\u0CB2\u0CCD\u0CAF. \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${t.options.map((a) => `'${a}'`).join(" | ")}` : "\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0C87\u0CA8\u0CCD\u200C\u0CAA\u0CC1\u0C9F\u0CCD";
      case "invalid_element":
        return `\u0CB0\u0CB2\u0CCD\u0CB2\u0CBF \u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0CAE\u0CCC\u0CB2\u0CCD\u0CAF ${t.origin}`;
      default:
        return "\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0C87\u0CA8\u0CCD\u200C\u0CAA\u0CC1\u0C9F\u0CCD";
    }
  };
}, "error");
function Fc() {
  return {
    localeError: y$()
  };
}
s(Fc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ko.js
var b$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\uBB38\uC790", verb: "to have" },
    file: { unit: "\uBC14\uC774\uD2B8", verb: "to have" },
    array: { unit: "\uAC1C", verb: "to have" },
    set: { unit: "\uAC1C", verb: "to have" },
    map: { unit: "\uAC1C", verb: "to have" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\uC785\uB825",
    email: "\uC774\uBA54\uC77C \uC8FC\uC18C",
    url: "URL",
    emoji: "\uC774\uBAA8\uC9C0",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \uB0A0\uC9DC\uC2DC\uAC04",
    date: "ISO \uB0A0\uC9DC",
    time: "ISO \uC2DC\uAC04",
    duration: "ISO \uAE30\uAC04",
    ipv4: "IPv4 \uC8FC\uC18C",
    ipv6: "IPv6 \uC8FC\uC18C",
    mac: "MAC \uC8FC\uC18C",
    cidrv4: "IPv4 \uBC94\uC704",
    cidrv6: "IPv6 \uBC94\uC704",
    base64: "base64 \uC778\uCF54\uB529 \uBB38\uC790\uC5F4",
    base64url: "base64url \uC778\uCF54\uB529 \uBB38\uC790\uC5F4",
    json_string: "JSON \uBB38\uC790\uC5F4",
    e164: "E.164 \uBC88\uD638",
    credit_card: "\uC2E0\uC6A9\uCE74\uB4DC \uBC88\uD638",
    jwt: "JWT",
    template_literal: "\uC785\uB825"
  }, o = {
    nan: "NaN"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\uC798\uBABB\uB41C \uC785\uB825: \uC608\uC0C1 \uD0C0\uC785\uC740 instanceof ${t.expected}, \uBC1B\uC740 \uD0C0\uC785\uC740 ${c}\uC785\uB2C8\uB2E4` : `\uC798\uBABB\uB41C \uC785\uB825: \uC608\uC0C1 \uD0C0\uC785\uC740 ${n}, \uBC1B\uC740 \uD0C0\uC785\uC740 ${c}\uC785\uB2C8\uB2E4`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\uC798\uBABB\uB41C \uC785\uB825: \uAC12\uC740 ${x(t.values[0])} \uC774\uC5B4\uC57C \uD569\uB2C8\uB2E4` : `\uC798\uBABB\uB41C \uC635\uC158: ${g(t.values, "\uB610\uB294 ")} \uC911 \uD558\uB098\uC5EC\uC57C \uD569\uB2C8\uB2E4`;
      case "too_big": {
        let n = t.inclusive ? "\uC774\uD558" : "\uBBF8\uB9CC", a = n === "\uBBF8\uB9CC" ? "\uC774\uC5B4\uC57C \uD569\uB2C8\uB2E4" : "\uC5EC\uC57C \uD569\uB2C8\uB2E4", c = r(t.origin), u = c?.unit ?? "\uC694\uC18C";
        return c ? `${t.origin ?? "\uAC12"}\uC774 \uB108\uBB34 \uD07D\uB2C8\uB2E4: ${t.maximum.toString()}${u} ${n}${a}` : `${t.origin ?? "\uAC12"}\uC774 \uB108\uBB34 \uD07D\uB2C8\uB2E4: ${t.maximum.toString()} ${n}${a}`;
      }
      case "too_small": {
        let n = t.inclusive ? "\uC774\uC0C1" : "\uCD08\uACFC", a = n === "\uC774\uC0C1" ? "\uC774\uC5B4\uC57C \uD569\uB2C8\uB2E4" : "\uC5EC\uC57C \uD569\uB2C8\uB2E4", c = r(t.origin), u = c?.unit ?? "\uC694\uC18C";
        return c ? `${t.origin ?? "\uAC12"}\uC774 \uB108\uBB34 \uC791\uC2B5\uB2C8\uB2E4: ${t.minimum.toString()}${u} ${n}${a}` : `${t.origin ?? "\uAC12"}\uC774 \uB108\uBB34 \uC791\uC2B5\uB2C8\uB2E4: ${t.minimum.toString()} ${n}${a}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\uC798\uBABB\uB41C \uBB38\uC790\uC5F4: "${n.prefix}"(\uC73C)\uB85C \uC2DC\uC791\uD574\uC57C \uD569\uB2C8\uB2E4` : n.format === "ends_with" ? `\uC798\uBABB\uB41C \uBB38\uC790\uC5F4: "${n.suffix}"(\uC73C)\uB85C \uB05D\uB098\uC57C \uD569\uB2C8\uB2E4` : n.format === "includes" ? `\uC798\uBABB\uB41C \uBB38\uC790\uC5F4: "${n.includes}"\uC744(\uB97C) \uD3EC\uD568\uD574\uC57C \uD569\uB2C8\uB2E4` : n.format === "regex" ? `\uC798\uBABB\uB41C \uBB38\uC790\uC5F4: \uC815\uADDC\uC2DD ${n.pattern} \uD328\uD134\uACFC \uC77C\uCE58\uD574\uC57C \uD569\uB2C8\uB2E4` : `\uC798\uBABB\uB41C ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\uC798\uBABB\uB41C \uC22B\uC790: ${t.divisor}\uC758 \uBC30\uC218\uC5EC\uC57C \uD569\uB2C8\uB2E4`;
      case "unrecognized_keys":
        return `\uC778\uC2DD\uD560 \uC218 \uC5C6\uB294 \uD0A4: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `\uC798\uBABB\uB41C \uD0A4: ${t.origin}`;
      case "invalid_union":
        return "\uC798\uBABB\uB41C \uC785\uB825";
      case "invalid_element":
        return `\uC798\uBABB\uB41C \uAC12: ${t.origin}`;
      default:
        return "\uC798\uBABB\uB41C \uC785\uB825";
    }
  };
}, "error");
function Lc() {
  return {
    localeError: b$()
  };
}
s(Lc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/lt.js
var Zr = /* @__PURE__ */ s((e) => e.charAt(0).toUpperCase() + e.slice(1), "capitalizeFirstCharacter");
function cp(e) {
  let r = Math.abs(e), i = r % 10, o = r % 100;
  return o >= 11 && o <= 19 || i === 0 ? "many" : i === 1 ? "one" : "few";
}
s(cp, "getUnitTypeFromNumber");
var $$ = /* @__PURE__ */ s(() => {
  let e = {
    string: {
      unit: {
        one: "simbolis",
        few: "simboliai",
        many: "simboli\u0173"
      },
      verb: {
        smaller: {
          inclusive: "turi b\u016Bti ne ilgesn\u0117 kaip",
          notInclusive: "turi b\u016Bti trumpesn\u0117 kaip"
        },
        bigger: {
          inclusive: "turi b\u016Bti ne trumpesn\u0117 kaip",
          notInclusive: "turi b\u016Bti ilgesn\u0117 kaip"
        }
      }
    },
    file: {
      unit: {
        one: "baitas",
        few: "baitai",
        many: "bait\u0173"
      },
      verb: {
        smaller: {
          inclusive: "turi b\u016Bti ne didesnis kaip",
          notInclusive: "turi b\u016Bti ma\u017Eesnis kaip"
        },
        bigger: {
          inclusive: "turi b\u016Bti ne ma\u017Eesnis kaip",
          notInclusive: "turi b\u016Bti didesnis kaip"
        }
      }
    },
    array: {
      unit: {
        one: "element\u0105",
        few: "elementus",
        many: "element\u0173"
      },
      verb: {
        smaller: {
          inclusive: "turi tur\u0117ti ne daugiau kaip",
          notInclusive: "turi tur\u0117ti ma\u017Eiau kaip"
        },
        bigger: {
          inclusive: "turi tur\u0117ti ne ma\u017Eiau kaip",
          notInclusive: "turi tur\u0117ti daugiau kaip"
        }
      }
    },
    set: {
      unit: {
        one: "element\u0105",
        few: "elementus",
        many: "element\u0173"
      },
      verb: {
        smaller: {
          inclusive: "turi tur\u0117ti ne daugiau kaip",
          notInclusive: "turi tur\u0117ti ma\u017Eiau kaip"
        },
        bigger: {
          inclusive: "turi tur\u0117ti ne ma\u017Eiau kaip",
          notInclusive: "turi tur\u0117ti daugiau kaip"
        }
      }
    }
  };
  function r(t, n, a, c) {
    let u = e[t] ?? null;
    return u === null ? u : {
      unit: u.unit[n],
      verb: u.verb[c][a ? "inclusive" : "notInclusive"]
    };
  }
  s(r, "getSizing");
  let i = {
    regex: "\u012Fvestis",
    email: "el. pa\u0161to adresas",
    url: "URL",
    emoji: "jaustukas",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO data ir laikas",
    date: "ISO data",
    time: "ISO laikas",
    duration: "ISO trukm\u0117",
    ipv4: "IPv4 adresas",
    ipv6: "IPv6 adresas",
    mac: "MAC adresas",
    cidrv4: "IPv4 tinklo prefiksas (CIDR)",
    cidrv6: "IPv6 tinklo prefiksas (CIDR)",
    base64: "base64 u\u017Ekoduota eilut\u0117",
    base64url: "base64url u\u017Ekoduota eilut\u0117",
    json_string: "JSON eilut\u0117",
    e164: "E.164 numeris",
    credit_card: "kredito kortel\u0117s numeris",
    jwt: "JWT",
    template_literal: "\u012Fvestis"
  }, o = {
    nan: "NaN",
    number: "skai\u010Dius",
    bigint: "sveikasis skai\u010Dius",
    string: "eilut\u0117",
    boolean: "login\u0117 reik\u0161m\u0117",
    undefined: "neapibr\u0117\u017Eta reik\u0161m\u0117",
    function: "funkcija",
    symbol: "simbolis",
    array: "masyvas",
    object: "objektas",
    null: "nulin\u0117 reik\u0161m\u0117"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Gautas tipas ${c}, o tik\u0117tasi - instanceof ${t.expected}` : `Gautas tipas ${c}, o tik\u0117tasi - ${n}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Privalo b\u016Bti ${x(t.values[0])}` : `Privalo b\u016Bti vienas i\u0161 ${g(t.values, "|")} pasirinkim\u0173`;
      case "too_big": {
        let n = o[t.origin] ?? t.origin, a = r(t.origin, cp(Number(t.maximum)), t.inclusive ?? !1, "smaller");
        if (a?.verb)
          return `${Zr(n ?? t.origin ?? "reik\u0161m\u0117")} ${a.verb} ${t.maximum.toString()} ${a.unit ?? "element\u0173"}`;
        let c = t.inclusive ? "ne didesnis kaip" : "ma\u017Eesnis kaip";
        return `${Zr(n ?? t.origin ?? "reik\u0161m\u0117")} turi b\u016Bti ${c} ${t.maximum.toString()} ${a?.unit}`;
      }
      case "too_small": {
        let n = o[t.origin] ?? t.origin, a = r(t.origin, cp(Number(t.minimum)), t.inclusive ?? !1, "bigger");
        if (a?.verb)
          return `${Zr(n ?? t.origin ?? "reik\u0161m\u0117")} ${a.verb} ${t.minimum.toString()} ${a.unit ?? "element\u0173"}`;
        let c = t.inclusive ? "ne ma\u017Eesnis kaip" : "didesnis kaip";
        return `${Zr(n ?? t.origin ?? "reik\u0161m\u0117")} turi b\u016Bti ${c} ${t.minimum.toString()} ${a?.unit}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Eilut\u0117 privalo prasid\u0117ti "${n.prefix}"` : n.format === "ends_with" ? `Eilut\u0117 privalo pasibaigti "${n.suffix}"` : n.format === "includes" ? `Eilut\u0117 privalo \u012Ftraukti "${n.includes}"` : n.format === "regex" ? `Eilut\u0117 privalo atitikti ${n.pattern}` : `Neteisingas ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Skai\u010Dius privalo b\u016Bti ${t.divisor} kartotinis.`;
      case "unrecognized_keys":
        return `Neatpa\u017Eint${t.keys.length > 1 ? "i" : "as"} rakt${t.keys.length > 1 ? "ai" : "as"}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return "Rastas klaidingas raktas";
      case "invalid_union":
        return "Klaidinga \u012Fvestis";
      case "invalid_element": {
        let n = o[t.origin] ?? t.origin;
        return `${Zr(n ?? t.origin ?? "reik\u0161m\u0117")} turi klaiding\u0105 \u012Fvest\u012F`;
      }
      default:
        return "Klaidinga \u012Fvestis";
    }
  };
}, "error");
function Vc() {
  return {
    localeError: $$()
  };
}
s(Vc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/mk.js
var _$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0437\u043D\u0430\u0446\u0438", verb: "\u0434\u0430 \u0438\u043C\u0430\u0430\u0442" },
    file: { unit: "\u0431\u0430\u0458\u0442\u0438", verb: "\u0434\u0430 \u0438\u043C\u0430\u0430\u0442" },
    array: { unit: "\u0441\u0442\u0430\u0432\u043A\u0438", verb: "\u0434\u0430 \u0438\u043C\u0430\u0430\u0442" },
    set: { unit: "\u0441\u0442\u0430\u0432\u043A\u0438", verb: "\u0434\u0430 \u0438\u043C\u0430\u0430\u0442" },
    map: { unit: "\u0441\u0442\u0430\u0432\u043A\u0438", verb: "\u0434\u0430 \u0438\u043C\u0430\u0430\u0442" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u0432\u043D\u0435\u0441",
    email: "\u0430\u0434\u0440\u0435\u0441\u0430 \u043D\u0430 \u0435-\u043F\u043E\u0448\u0442\u0430",
    url: "URL",
    emoji: "\u0435\u043C\u043E\u045F\u0438",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0434\u0430\u0442\u0443\u043C \u0438 \u0432\u0440\u0435\u043C\u0435",
    date: "ISO \u0434\u0430\u0442\u0443\u043C",
    time: "ISO \u0432\u0440\u0435\u043C\u0435",
    duration: "ISO \u0432\u0440\u0435\u043C\u0435\u0442\u0440\u0430\u0435\u045A\u0435",
    ipv4: "IPv4 \u0430\u0434\u0440\u0435\u0441\u0430",
    ipv6: "IPv6 \u0430\u0434\u0440\u0435\u0441\u0430",
    mac: "MAC \u0430\u0434\u0440\u0435\u0441\u0430",
    cidrv4: "IPv4 \u043E\u043F\u0441\u0435\u0433",
    cidrv6: "IPv6 \u043E\u043F\u0441\u0435\u0433",
    base64: "base64-\u0435\u043D\u043A\u043E\u0434\u0438\u0440\u0430\u043D\u0430 \u043D\u0438\u0437\u0430",
    base64url: "base64url-\u0435\u043D\u043A\u043E\u0434\u0438\u0440\u0430\u043D\u0430 \u043D\u0438\u0437\u0430",
    json_string: "JSON \u043D\u0438\u0437\u0430",
    e164: "E.164 \u0431\u0440\u043E\u0458",
    credit_card: "\u0431\u0440\u043E\u0458 \u043D\u0430 \u043A\u0440\u0435\u0434\u0438\u0442\u043D\u0430 \u043A\u0430\u0440\u0442\u0438\u0447\u043A\u0430",
    jwt: "JWT",
    template_literal: "\u0432\u043D\u0435\u0441"
  }, o = {
    nan: "NaN",
    number: "\u0431\u0440\u043E\u0458",
    array: "\u043D\u0438\u0437\u0430"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u0413\u0440\u0435\u0448\u0435\u043D \u0432\u043D\u0435\u0441: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 instanceof ${t.expected}, \u043F\u0440\u0438\u043C\u0435\u043D\u043E ${c}` : `\u0413\u0440\u0435\u0448\u0435\u043D \u0432\u043D\u0435\u0441: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${n}, \u043F\u0440\u0438\u043C\u0435\u043D\u043E ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Invalid input: expected ${x(t.values[0])}` : `\u0413\u0440\u0435\u0448\u0430\u043D\u0430 \u043E\u043F\u0446\u0438\u0458\u0430: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 \u0435\u0434\u043D\u0430 ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u041F\u0440\u0435\u043C\u043D\u043E\u0433\u0443 \u0433\u043E\u043B\u0435\u043C: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${t.origin ?? "\u0432\u0440\u0435\u0434\u043D\u043E\u0441\u0442\u0430"} \u0434\u0430 \u0438\u043C\u0430 ${n}${t.maximum.toString()} ${a.unit ?? "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0438"}` : `\u041F\u0440\u0435\u043C\u043D\u043E\u0433\u0443 \u0433\u043E\u043B\u0435\u043C: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${t.origin ?? "\u0432\u0440\u0435\u0434\u043D\u043E\u0441\u0442\u0430"} \u0434\u0430 \u0431\u0438\u0434\u0435 ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u041F\u0440\u0435\u043C\u043D\u043E\u0433\u0443 \u043C\u0430\u043B: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${t.origin} \u0434\u0430 \u0438\u043C\u0430 ${n}${t.minimum.toString()} ${a.unit}` : `\u041F\u0440\u0435\u043C\u043D\u043E\u0433\u0443 \u043C\u0430\u043B: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${t.origin} \u0434\u0430 \u0431\u0438\u0434\u0435 ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u041D\u0435\u0432\u0430\u0436\u0435\u0447\u043A\u0430 \u043D\u0438\u0437\u0430: \u043C\u043E\u0440\u0430 \u0434\u0430 \u0437\u0430\u043F\u043E\u0447\u043D\u0443\u0432\u0430 \u0441\u043E "${n.prefix}"` : n.format === "ends_with" ? `\u041D\u0435\u0432\u0430\u0436\u0435\u0447\u043A\u0430 \u043D\u0438\u0437\u0430: \u043C\u043E\u0440\u0430 \u0434\u0430 \u0437\u0430\u0432\u0440\u0448\u0443\u0432\u0430 \u0441\u043E "${n.suffix}"` : n.format === "includes" ? `\u041D\u0435\u0432\u0430\u0436\u0435\u0447\u043A\u0430 \u043D\u0438\u0437\u0430: \u043C\u043E\u0440\u0430 \u0434\u0430 \u0432\u043A\u043B\u0443\u0447\u0443\u0432\u0430 "${n.includes}"` : n.format === "regex" ? `\u041D\u0435\u0432\u0430\u0436\u0435\u0447\u043A\u0430 \u043D\u0438\u0437\u0430: \u043C\u043E\u0440\u0430 \u0434\u0430 \u043E\u0434\u0433\u043E\u0430\u0440\u0430 \u043D\u0430 \u043F\u0430\u0442\u0435\u0440\u043D\u043E\u0442 ${n.pattern}` : `Invalid ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u0413\u0440\u0435\u0448\u0435\u043D \u0431\u0440\u043E\u0458: \u043C\u043E\u0440\u0430 \u0434\u0430 \u0431\u0438\u0434\u0435 \u0434\u0435\u043B\u0438\u0432 \u0441\u043E ${t.divisor}`;
      case "unrecognized_keys":
        return `${t.keys.length > 1 ? "\u041D\u0435\u043F\u0440\u0435\u043F\u043E\u0437\u043D\u0430\u0435\u043D\u0438 \u043A\u043B\u0443\u0447\u0435\u0432\u0438" : "\u041D\u0435\u043F\u0440\u0435\u043F\u043E\u0437\u043D\u0430\u0435\u043D \u043A\u043B\u0443\u0447"}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `\u0413\u0440\u0435\u0448\u0435\u043D \u043A\u043B\u0443\u0447 \u0432\u043E ${t.origin}`;
      case "invalid_union":
        return "\u0413\u0440\u0435\u0448\u0435\u043D \u0432\u043D\u0435\u0441";
      case "invalid_element":
        return `\u0413\u0440\u0435\u0448\u043D\u0430 \u0432\u0440\u0435\u0434\u043D\u043E\u0441\u0442 \u0432\u043E ${t.origin}`;
      default:
        return "\u0413\u0440\u0435\u0448\u0435\u043D \u0432\u043D\u0435\u0441";
    }
  };
}, "error");
function Mc() {
  return {
    localeError: _$()
  };
}
s(Mc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ms.js
var x$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "aksara", verb: "mempunyai" },
    file: { unit: "bait", verb: "mempunyai" },
    array: { unit: "elemen", verb: "mempunyai" },
    set: { unit: "elemen", verb: "mempunyai" },
    map: { unit: "elemen", verb: "mempunyai" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "input",
    email: "alamat e-mel",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "tarikh masa ISO",
    date: "tarikh ISO",
    time: "masa ISO",
    duration: "tempoh ISO",
    ipv4: "alamat IPv4",
    ipv6: "alamat IPv6",
    mac: "alamat MAC",
    cidrv4: "julat IPv4",
    cidrv6: "julat IPv6",
    base64: "string dikodkan base64",
    base64url: "string dikodkan base64url",
    json_string: "string JSON",
    e164: "nombor E.164",
    credit_card: "nombor kad kredit",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN",
    number: "nombor"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Input tidak sah: dijangka instanceof ${t.expected}, diterima ${c}` : `Input tidak sah: dijangka ${n}, diterima ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Input tidak sah: dijangka ${x(t.values[0])}` : `Pilihan tidak sah: dijangka salah satu daripada ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Terlalu besar: dijangka ${t.origin ?? "nilai"} ${a.verb} ${n}${t.maximum.toString()} ${a.unit ?? "elemen"}` : `Terlalu besar: dijangka ${t.origin ?? "nilai"} adalah ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Terlalu kecil: dijangka ${t.origin} ${a.verb} ${n}${t.minimum.toString()} ${a.unit}` : `Terlalu kecil: dijangka ${t.origin} adalah ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `String tidak sah: mesti bermula dengan "${n.prefix}"` : n.format === "ends_with" ? `String tidak sah: mesti berakhir dengan "${n.suffix}"` : n.format === "includes" ? `String tidak sah: mesti mengandungi "${n.includes}"` : n.format === "regex" ? `String tidak sah: mesti sepadan dengan corak ${n.pattern}` : `${i[n.format] ?? t.format} tidak sah`;
      }
      case "not_multiple_of":
        return `Nombor tidak sah: perlu gandaan ${t.divisor}`;
      case "unrecognized_keys":
        return `Kunci tidak dikenali: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `Kunci tidak sah dalam ${t.origin}`;
      case "invalid_union":
        return "Input tidak sah";
      case "invalid_element":
        return `Nilai tidak sah dalam ${t.origin}`;
      default:
        return "Input tidak sah";
    }
  };
}, "error");
function Bc() {
  return {
    localeError: x$()
  };
}
s(Bc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ne.js
var w$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0905\u0915\u094D\u0937\u0930", verb: "\u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B" },
    file: { unit: "\u092C\u093E\u0907\u091F", verb: "\u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B" },
    array: { unit: "\u0924\u0924\u094D\u0935", verb: "\u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B" },
    set: { unit: "\u0924\u0924\u094D\u0935", verb: "\u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B" },
    map: { unit: "\u092A\u094D\u0930\u0935\u093F\u0937\u094D\u091F\u093F", verb: "\u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u0907\u0928\u092A\u0941\u091F",
    email: "\u0907\u092E\u0947\u0932 \u0920\u0947\u0917\u093E\u0928\u093E",
    url: "URL",
    emoji: "\u0907\u092E\u094B\u091C\u0940",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u092E\u093F\u0924\u093F \u0930 \u0938\u092E\u092F",
    date: "ISO \u092E\u093F\u0924\u093F",
    time: "ISO \u0938\u092E\u092F",
    duration: "ISO \u0905\u0935\u0927\u093F",
    ipv4: "IPv4 \u0920\u0947\u0917\u093E\u0928\u093E",
    ipv6: "IPv6 \u0920\u0947\u0917\u093E\u0928\u093E",
    mac: "MAC \u0920\u0947\u0917\u093E\u0928\u093E",
    cidrv4: "IPv4 \u0926\u093E\u092F\u0930\u093E",
    cidrv6: "IPv6 \u0926\u093E\u092F\u0930\u093E",
    base64: "base64-\u0907\u0928\u094D\u0915\u094B\u0921 \u0917\u0930\u093F\u090F\u0915\u094B \u0938\u094D\u091F\u094D\u0930\u093F\u0919",
    base64url: "base64url-\u0907\u0928\u094D\u0915\u094B\u0921 \u0917\u0930\u093F\u090F\u0915\u094B \u0938\u094D\u091F\u094D\u0930\u093F\u0919",
    json_string: "JSON \u0938\u094D\u091F\u094D\u0930\u093F\u0919",
    e164: "E.164 \u0928\u092E\u094D\u092C\u0930",
    credit_card: "\u0915\u094D\u0930\u0947\u0921\u093F\u091F \u0915\u093E\u0930\u094D\u0921 \u0928\u092E\u094D\u092C\u0930",
    jwt: "JWT",
    template_literal: "\u0907\u0928\u092A\u0941\u091F"
  }, o = {
    nan: "NaN"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return `\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 ${n}, \u092A\u094D\u0930\u093E\u092A\u094D\u0924 ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 ${x(t.values[0])}` : `\u0905\u092E\u093E\u0928\u094D\u092F \u0935\u093F\u0915\u0932\u094D\u092A: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 \u092E\u093E\u0928\u0939\u0930\u0942 \u092E\u0927\u094D\u092F\u0947 \u090F\u0915 ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u0927\u0947\u0930\u0948 \u0920\u0942\u0932\u094B: ${t.origin ?? "\u092E\u093E\u0928"} \u092E\u093E ${n}${t.maximum.toString()} ${a.unit} ${a.verb}` : `\u0927\u0947\u0930\u0948 \u0920\u0942\u0932\u094B: ${t.origin ?? "\u092E\u093E\u0928"} ${n}${t.maximum.toString()} \u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u0927\u0947\u0930\u0948 \u0938\u093E\u0928\u094B: ${t.origin} \u092E\u093E ${n}${t.minimum.toString()} ${a.unit} ${a.verb}` : `\u0927\u0947\u0930\u0948 \u0938\u093E\u0928\u094B: ${t.origin} ${n}${t.minimum.toString()} \u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0919: "${n.prefix}" \u092C\u093E\u091F \u0938\u0941\u0930\u0941 \u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B` : n.format === "ends_with" ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0919: "${n.suffix}" \u092E\u093E \u0938\u092E\u093E\u092A\u094D\u0924 \u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B` : n.format === "includes" ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0919: "${n.includes}" \u0938\u092E\u093E\u0935\u0947\u0936 \u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B` : n.format === "regex" ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0919: \u0922\u093E\u0901\u091A\u093E ${n.pattern} \u0938\u0901\u0917 \u092E\u0947\u0932 \u0916\u093E\u0928\u0941\u092A\u0930\u094D\u091B` : `\u0905\u092E\u093E\u0928\u094D\u092F ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u0902\u0916\u094D\u092F\u093E: ${t.divisor} \u0915\u094B \u0917\u0941\u0923\u091C \u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B`;
      case "unrecognized_keys":
        return `\u0905\u092A\u0930\u093F\u091A\u093F\u0924 \u0915\u0941\u091E\u094D\u091C\u0940${t.keys.length > 1 ? "\u0939\u0930\u0942" : ""}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `\u0905\u092E\u093E\u0928\u094D\u092F \u0915\u0941\u091E\u094D\u091C\u0940: ${t.origin} \u092E\u093E`;
      case "invalid_union":
        return t.options && Array.isArray(t.options) && t.options.length > 0 ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0921\u093F\u0938\u094D\u0915\u094D\u0930\u093F\u092E\u093F\u0928\u0947\u091F\u0930 \u092E\u093E\u0928: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 ${t.options.map((a) => `'${a}'`).join(" | ")}` : "\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F";
      case "invalid_element":
        return `\u0905\u092E\u093E\u0928\u094D\u092F \u092E\u093E\u0928: ${t.origin} \u092E\u093E`;
      default:
        return "\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F";
    }
  };
}, "error");
function Jc() {
  return {
    localeError: w$()
  };
}
s(Jc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/nl.js
var k$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "tekens", verb: "heeft" },
    file: { unit: "bytes", verb: "heeft" },
    array: { unit: "elementen", verb: "heeft" },
    set: { unit: "elementen", verb: "heeft" },
    map: { unit: "elementen", verb: "heeft" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "invoer",
    email: "emailadres",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datum en tijd",
    date: "ISO datum",
    time: "ISO tijd",
    duration: "ISO duur",
    ipv4: "IPv4-adres",
    ipv6: "IPv6-adres",
    mac: "MAC-adres",
    cidrv4: "IPv4-bereik",
    cidrv6: "IPv6-bereik",
    base64: "base64-gecodeerde tekst",
    base64url: "base64 URL-gecodeerde tekst",
    json_string: "JSON string",
    e164: "E.164-nummer",
    credit_card: "creditcardnummer",
    jwt: "JWT",
    template_literal: "invoer"
  }, o = {
    nan: "NaN",
    number: "getal"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Ongeldige invoer: verwacht instanceof ${t.expected}, ontving ${c}` : `Ongeldige invoer: verwacht ${n}, ontving ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Ongeldige invoer: verwacht ${x(t.values[0])}` : `Ongeldige optie: verwacht \xE9\xE9n van ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin), c = t.origin === "date" ? "laat" : t.origin === "string" ? "lang" : "groot";
        return a ? `Te ${c}: verwacht dat ${t.origin ?? "waarde"} ${n}${t.maximum.toString()} ${a.unit ?? "elementen"} ${a.verb}` : `Te ${c}: verwacht dat ${t.origin ?? "waarde"} ${n}${t.maximum.toString()} is`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin), c = t.origin === "date" ? "vroeg" : t.origin === "string" ? "kort" : "klein";
        return a ? `Te ${c}: verwacht dat ${t.origin} ${n}${t.minimum.toString()} ${a.unit} ${a.verb}` : `Te ${c}: verwacht dat ${t.origin} ${n}${t.minimum.toString()} is`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Ongeldige tekst: moet met "${n.prefix}" beginnen` : n.format === "ends_with" ? `Ongeldige tekst: moet op "${n.suffix}" eindigen` : n.format === "includes" ? `Ongeldige tekst: moet "${n.includes}" bevatten` : n.format === "regex" ? `Ongeldige tekst: moet overeenkomen met patroon ${n.pattern}` : `Ongeldig: ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Ongeldig getal: moet een veelvoud van ${t.divisor} zijn`;
      case "unrecognized_keys":
        return `Onbekende key${t.keys.length > 1 ? "s" : ""}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `Ongeldige key in ${t.origin}`;
      case "invalid_union":
        return "Ongeldige invoer";
      case "invalid_element":
        return `Ongeldige waarde in ${t.origin}`;
      default:
        return "Ongeldige invoer";
    }
  };
}, "error");
function qc() {
  return {
    localeError: k$()
  };
}
s(qc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/nn.js
var I$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "teikn", verb: "\xE5 ha" },
    file: { unit: "bytes", verb: "\xE5 ha" },
    array: { unit: "element", verb: "\xE5 innehalde" },
    set: { unit: "element", verb: "\xE5 innehalde" },
    map: { unit: "element", verb: "\xE5 innehalde" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "input",
    email: "e-postadresse",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO dato- og klokkeslett",
    date: "ISO-dato",
    time: "ISO-klokkeslett",
    duration: "ISO-varigheit",
    ipv4: "IPv4-adresse",
    ipv6: "IPv6-adresse",
    mac: "MAC-adresse",
    cidrv4: "IPv4-spekter",
    cidrv6: "IPv6-spekter",
    base64: "base64-enkoda streng",
    base64url: "base64url-enkoda streng",
    json_string: "JSON-streng",
    e164: "E.164-nummer",
    credit_card: "kredittkortnummer",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN",
    number: "tal",
    array: "liste"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Ugyldig input: forventa instanceof ${t.expected}, fekk ${c}` : `Ugyldig input: forventa ${n}, fekk ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Ugyldig verdi: forventa ${x(t.values[0])}` : `Ugyldig val: forventa eitt av ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `For stor(t): forventa ${t.origin ?? "value"} til \xE5 ha ${n}${t.maximum.toString()} ${a.unit ?? "element"}` : `For stor(t): forventa ${t.origin ?? "value"} til \xE5 ha ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `For lite(n): forventa ${t.origin} til \xE5 ha ${n}${t.minimum.toString()} ${a.unit}` : `For lite(n): forventa ${t.origin} til \xE5 ha ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Ugyldig streng: m\xE5 starte med "${n.prefix}"` : n.format === "ends_with" ? `Ugyldig streng: m\xE5 slutte med "${n.suffix}"` : n.format === "includes" ? `Ugyldig streng: m\xE5 innehalde "${n.includes}"` : n.format === "regex" ? `Ugyldig streng: m\xE5 matche m\xF8nsteret ${n.pattern}` : `Ugyldig ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Ugyldig tal: m\xE5 vere eit multiplum av ${t.divisor}`;
      case "unrecognized_keys":
        return `${t.keys.length > 1 ? "Ukjende n\xF8klar" : "Ukjend n\xF8kkel"}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `Ugyldig n\xF8kkel i ${t.origin}`;
      case "invalid_union":
        return "Ugyldig input";
      case "invalid_element":
        return `Ugyldig verdi i ${t.origin}`;
      default:
        return "Ugyldig input";
    }
  };
}, "error");
function Kc() {
  return {
    localeError: I$()
  };
}
s(Kc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/no.js
var z$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "tegn", verb: "\xE5 ha" },
    file: { unit: "bytes", verb: "\xE5 ha" },
    array: { unit: "elementer", verb: "\xE5 inneholde" },
    set: { unit: "elementer", verb: "\xE5 inneholde" },
    map: { unit: "elementer", verb: "\xE5 inneholde" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "input",
    email: "e-postadresse",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO dato- og klokkeslett",
    date: "ISO-dato",
    time: "ISO-klokkeslett",
    duration: "ISO-varighet",
    ipv4: "IPv4-adresse",
    ipv6: "IPv6-adresse",
    mac: "MAC-adresse",
    cidrv4: "IPv4-spekter",
    cidrv6: "IPv6-spekter",
    base64: "base64-enkodet streng",
    base64url: "base64url-enkodet streng",
    json_string: "JSON-streng",
    e164: "E.164-nummer",
    credit_card: "kredittkortnummer",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN",
    number: "tall",
    array: "liste"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Ugyldig input: forventet instanceof ${t.expected}, fikk ${c}` : `Ugyldig input: forventet ${n}, fikk ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Ugyldig verdi: forventet ${x(t.values[0])}` : `Ugyldig valg: forventet en av ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `For stor(t): forventet ${t.origin ?? "value"} til \xE5 ha ${n}${t.maximum.toString()} ${a.unit ?? "elementer"}` : `For stor(t): forventet ${t.origin ?? "value"} til \xE5 ha ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `For lite(n): forventet ${t.origin} til \xE5 ha ${n}${t.minimum.toString()} ${a.unit}` : `For lite(n): forventet ${t.origin} til \xE5 ha ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Ugyldig streng: m\xE5 starte med "${n.prefix}"` : n.format === "ends_with" ? `Ugyldig streng: m\xE5 ende med "${n.suffix}"` : n.format === "includes" ? `Ugyldig streng: m\xE5 inneholde "${n.includes}"` : n.format === "regex" ? `Ugyldig streng: m\xE5 matche m\xF8nsteret ${n.pattern}` : `Ugyldig ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Ugyldig tall: m\xE5 v\xE6re et multiplum av ${t.divisor}`;
      case "unrecognized_keys":
        return `${t.keys.length > 1 ? "Ukjente n\xF8kler" : "Ukjent n\xF8kkel"}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `Ugyldig n\xF8kkel i ${t.origin}`;
      case "invalid_union":
        return "Ugyldig input";
      case "invalid_element":
        return `Ugyldig verdi i ${t.origin}`;
      default:
        return "Ugyldig input";
    }
  };
}, "error");
function Wc() {
  return {
    localeError: z$()
  };
}
s(Wc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ota.js
var S$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "harf", verb: "olmal\u0131d\u0131r" },
    file: { unit: "bayt", verb: "olmal\u0131d\u0131r" },
    array: { unit: "unsur", verb: "olmal\u0131d\u0131r" },
    set: { unit: "unsur", verb: "olmal\u0131d\u0131r" },
    map: { unit: "unsur", verb: "olmal\u0131d\u0131r" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "giren",
    email: "epostag\xE2h",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO heng\xE2m\u0131",
    date: "ISO tarihi",
    time: "ISO zaman\u0131",
    duration: "ISO m\xFCddeti",
    ipv4: "IPv4 ni\u015F\xE2n\u0131",
    ipv6: "IPv6 ni\u015F\xE2n\u0131",
    mac: "MAC ni\u015F\xE2n\u0131",
    cidrv4: "IPv4 menzili",
    cidrv6: "IPv6 menzili",
    base64: "base64-\u015Fifreli metin",
    base64url: "base64url-\u015Fifreli metin",
    json_string: "JSON metin",
    e164: "E.164 say\u0131s\u0131",
    credit_card: "i'tib\xE2r kart\u0131 numaras\u0131",
    jwt: "JWT",
    template_literal: "giren"
  }, o = {
    nan: "NaN",
    number: "numara",
    array: "saf",
    null: "gayb"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `F\xE2sit giren: umulan instanceof ${t.expected}, al\u0131nan ${c}` : `F\xE2sit giren: umulan ${n}, al\u0131nan ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `F\xE2sit giren: umulan ${x(t.values[0])}` : `F\xE2sit tercih: m\xFBteberler ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Fazla b\xFCy\xFCk: ${t.origin ?? "value"}, ${n}${t.maximum.toString()} ${a.unit ?? "elements"} sahip olmal\u0131yd\u0131.` : `Fazla b\xFCy\xFCk: ${t.origin ?? "value"}, ${n}${t.maximum.toString()} olmal\u0131yd\u0131.`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Fazla k\xFC\xE7\xFCk: ${t.origin}, ${n}${t.minimum.toString()} ${a.unit} sahip olmal\u0131yd\u0131.` : `Fazla k\xFC\xE7\xFCk: ${t.origin}, ${n}${t.minimum.toString()} olmal\u0131yd\u0131.`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `F\xE2sit metin: "${n.prefix}" ile ba\u015Flamal\u0131.` : n.format === "ends_with" ? `F\xE2sit metin: "${n.suffix}" ile bitmeli.` : n.format === "includes" ? `F\xE2sit metin: "${n.includes}" ihtiv\xE2 etmeli.` : n.format === "regex" ? `F\xE2sit metin: ${n.pattern} nak\u015F\u0131na uymal\u0131.` : `F\xE2sit ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `F\xE2sit say\u0131: ${t.divisor} kat\u0131 olmal\u0131yd\u0131.`;
      case "unrecognized_keys":
        return `Tan\u0131nmayan anahtar ${t.keys.length > 1 ? "s" : ""}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `${t.origin} i\xE7in tan\u0131nmayan anahtar var.`;
      case "invalid_union":
        return "Giren tan\u0131namad\u0131.";
      case "invalid_element":
        return `${t.origin} i\xE7in tan\u0131nmayan k\u0131ymet var.`;
      default:
        return "K\u0131ymet tan\u0131namad\u0131.";
    }
  };
}, "error");
function Gc() {
  return {
    localeError: S$()
  };
}
s(Gc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ps.js
var O$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u062A\u0648\u06A9\u064A", verb: "\u0648\u0644\u0631\u064A" },
    file: { unit: "\u0628\u0627\u06CC\u067C\u0633", verb: "\u0648\u0644\u0631\u064A" },
    array: { unit: "\u062A\u0648\u06A9\u064A", verb: "\u0648\u0644\u0631\u064A" },
    set: { unit: "\u062A\u0648\u06A9\u064A", verb: "\u0648\u0644\u0631\u064A" },
    map: { unit: "\u062A\u0648\u06A9\u064A", verb: "\u0648\u0644\u0631\u064A" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u0648\u0631\u0648\u062F\u064A",
    email: "\u0628\u0631\u06CC\u069A\u0646\u0627\u0644\u06CC\u06A9",
    url: "\u06CC\u0648 \u0622\u0631 \u0627\u0644",
    emoji: "\u0627\u06CC\u0645\u0648\u062C\u064A",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u0646\u06CC\u067C\u0647 \u0627\u0648 \u0648\u062E\u062A",
    date: "\u0646\u06D0\u067C\u0647",
    time: "\u0648\u062E\u062A",
    duration: "\u0645\u0648\u062F\u0647",
    ipv4: "\u062F IPv4 \u067E\u062A\u0647",
    ipv6: "\u062F IPv6 \u067E\u062A\u0647",
    mac: "\u062F MAC \u067E\u062A\u0647",
    cidrv4: "\u062F IPv4 \u0633\u0627\u062D\u0647",
    cidrv6: "\u062F IPv6 \u0633\u0627\u062D\u0647",
    base64: "base64-encoded \u0645\u062A\u0646",
    base64url: "base64url-encoded \u0645\u062A\u0646",
    json_string: "JSON \u0645\u062A\u0646",
    e164: "\u062F E.164 \u0634\u0645\u06D0\u0631\u0647",
    credit_card: "\u062F \u06A9\u0631\u06CC\u0689\u06CC\u067C \u06A9\u0627\u0631\u062A \u0634\u0645\u06CC\u0631\u0647",
    jwt: "JWT",
    template_literal: "\u0648\u0631\u0648\u062F\u064A"
  }, o = {
    nan: "NaN",
    number: "\u0639\u062F\u062F",
    array: "\u0627\u0631\u06D0"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u0646\u0627\u0633\u0645 \u0648\u0631\u0648\u062F\u064A: \u0628\u0627\u06CC\u062F instanceof ${t.expected} \u0648\u0627\u06CC, \u0645\u06AB\u0631 ${c} \u062A\u0631\u0644\u0627\u0633\u0647 \u0634\u0648` : `\u0646\u0627\u0633\u0645 \u0648\u0631\u0648\u062F\u064A: \u0628\u0627\u06CC\u062F ${n} \u0648\u0627\u06CC, \u0645\u06AB\u0631 ${c} \u062A\u0631\u0644\u0627\u0633\u0647 \u0634\u0648`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u0646\u0627\u0633\u0645 \u0648\u0631\u0648\u062F\u064A: \u0628\u0627\u06CC\u062F ${x(t.values[0])} \u0648\u0627\u06CC` : `\u0646\u0627\u0633\u0645 \u0627\u0646\u062A\u062E\u0627\u0628: \u0628\u0627\u06CC\u062F \u06CC\u0648 \u0644\u0647 ${g(t.values, "|")} \u0685\u062E\u0647 \u0648\u0627\u06CC`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u0689\u06CC\u0631 \u0644\u0648\u06CC: ${t.origin ?? "\u0627\u0631\u0632\u069A\u062A"} \u0628\u0627\u06CC\u062F ${n}${t.maximum.toString()} ${a.unit ?? "\u0639\u0646\u0635\u0631\u0648\u0646\u0647"} \u0648\u0644\u0631\u064A` : `\u0689\u06CC\u0631 \u0644\u0648\u06CC: ${t.origin ?? "\u0627\u0631\u0632\u069A\u062A"} \u0628\u0627\u06CC\u062F ${n}${t.maximum.toString()} \u0648\u064A`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u0689\u06CC\u0631 \u06A9\u0648\u0686\u0646\u06CC: ${t.origin} \u0628\u0627\u06CC\u062F ${n}${t.minimum.toString()} ${a.unit} \u0648\u0644\u0631\u064A` : `\u0689\u06CC\u0631 \u06A9\u0648\u0686\u0646\u06CC: ${t.origin} \u0628\u0627\u06CC\u062F ${n}${t.minimum.toString()} \u0648\u064A`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u0646\u0627\u0633\u0645 \u0645\u062A\u0646: \u0628\u0627\u06CC\u062F \u062F "${n.prefix}" \u0633\u0631\u0647 \u067E\u06CC\u0644 \u0634\u064A` : n.format === "ends_with" ? `\u0646\u0627\u0633\u0645 \u0645\u062A\u0646: \u0628\u0627\u06CC\u062F \u062F "${n.suffix}" \u0633\u0631\u0647 \u067E\u0627\u06CC \u062A\u0647 \u0648\u0631\u0633\u064A\u0696\u064A` : n.format === "includes" ? `\u0646\u0627\u0633\u0645 \u0645\u062A\u0646: \u0628\u0627\u06CC\u062F "${n.includes}" \u0648\u0644\u0631\u064A` : n.format === "regex" ? `\u0646\u0627\u0633\u0645 \u0645\u062A\u0646: \u0628\u0627\u06CC\u062F \u062F ${n.pattern} \u0633\u0631\u0647 \u0645\u0637\u0627\u0628\u0642\u062A \u0648\u0644\u0631\u064A` : `${i[n.format] ?? t.format} \u0646\u0627\u0633\u0645 \u062F\u06CC`;
      }
      case "not_multiple_of":
        return `\u0646\u0627\u0633\u0645 \u0639\u062F\u062F: \u0628\u0627\u06CC\u062F \u062F ${t.divisor} \u0645\u0636\u0631\u0628 \u0648\u064A`;
      case "unrecognized_keys":
        return `\u0646\u0627\u0633\u0645 ${t.keys.length > 1 ? "\u06A9\u0644\u06CC\u0689\u0648\u0646\u0647" : "\u06A9\u0644\u06CC\u0689"}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `\u0646\u0627\u0633\u0645 \u06A9\u0644\u06CC\u0689 \u067E\u0647 ${t.origin} \u06A9\u06D0`;
      case "invalid_union":
        return "\u0646\u0627\u0633\u0645\u0647 \u0648\u0631\u0648\u062F\u064A";
      case "invalid_element":
        return `\u0646\u0627\u0633\u0645 \u0639\u0646\u0635\u0631 \u067E\u0647 ${t.origin} \u06A9\u06D0`;
      default:
        return "\u0646\u0627\u0633\u0645\u0647 \u0648\u0631\u0648\u062F\u064A";
    }
  };
}, "error");
function Xc() {
  return {
    localeError: O$()
  };
}
s(Xc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/pl.js
var j$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "znak\xF3w", verb: "mie\u0107" },
    file: { unit: "bajt\xF3w", verb: "mie\u0107" },
    array: { unit: "element\xF3w", verb: "mie\u0107" },
    set: { unit: "element\xF3w", verb: "mie\u0107" },
    map: { unit: "element\xF3w", verb: "mie\u0107" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "wyra\u017Cenie",
    email: "adres email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "data i godzina w formacie ISO",
    date: "data w formacie ISO",
    time: "godzina w formacie ISO",
    duration: "czas trwania ISO",
    ipv4: "adres IPv4",
    ipv6: "adres IPv6",
    mac: "adres MAC",
    cidrv4: "zakres IPv4",
    cidrv6: "zakres IPv6",
    base64: "ci\u0105g znak\xF3w zakodowany w formacie base64",
    base64url: "ci\u0105g znak\xF3w zakodowany w formacie base64url",
    json_string: "ci\u0105g znak\xF3w w formacie JSON",
    e164: "liczba E.164",
    credit_card: "numer karty kredytowej",
    jwt: "JWT",
    template_literal: "wej\u015Bcie"
  }, o = {
    nan: "NaN",
    number: "liczba",
    array: "tablica"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Nieprawid\u0142owe dane wej\u015Bciowe: oczekiwano instanceof ${t.expected}, otrzymano ${c}` : `Nieprawid\u0142owe dane wej\u015Bciowe: oczekiwano ${n}, otrzymano ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Nieprawid\u0142owe dane wej\u015Bciowe: oczekiwano ${x(t.values[0])}` : `Nieprawid\u0142owa opcja: oczekiwano jednej z warto\u015Bci ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Za du\u017Ca warto\u015B\u0107: oczekiwano, \u017Ce ${t.origin ?? "warto\u015B\u0107"} b\u0119dzie mie\u0107 ${n}${t.maximum.toString()} ${a.unit ?? "element\xF3w"}` : `Zbyt du\u017C(y/a/e): oczekiwano, \u017Ce ${t.origin ?? "warto\u015B\u0107"} b\u0119dzie wynosi\u0107 ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Za ma\u0142a warto\u015B\u0107: oczekiwano, \u017Ce ${t.origin ?? "warto\u015B\u0107"} b\u0119dzie mie\u0107 ${n}${t.minimum.toString()} ${a.unit ?? "element\xF3w"}` : `Zbyt ma\u0142(y/a/e): oczekiwano, \u017Ce ${t.origin ?? "warto\u015B\u0107"} b\u0119dzie wynosi\u0107 ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Nieprawid\u0142owy ci\u0105g znak\xF3w: musi zaczyna\u0107 si\u0119 od "${n.prefix}"` : n.format === "ends_with" ? `Nieprawid\u0142owy ci\u0105g znak\xF3w: musi ko\u0144czy\u0107 si\u0119 na "${n.suffix}"` : n.format === "includes" ? `Nieprawid\u0142owy ci\u0105g znak\xF3w: musi zawiera\u0107 "${n.includes}"` : n.format === "regex" ? `Nieprawid\u0142owy ci\u0105g znak\xF3w: musi odpowiada\u0107 wzorcowi ${n.pattern}` : `Nieprawid\u0142ow(y/a/e) ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Nieprawid\u0142owa liczba: musi by\u0107 wielokrotno\u015Bci\u0105 ${t.divisor}`;
      case "unrecognized_keys":
        return `Nierozpoznane klucze${t.keys.length > 1 ? "s" : ""}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `Nieprawid\u0142owy klucz w ${t.origin}`;
      case "invalid_union":
        return "Nieprawid\u0142owe dane wej\u015Bciowe";
      case "invalid_element":
        return `Nieprawid\u0142owa warto\u015B\u0107 w ${t.origin}`;
      default:
        return "Nieprawid\u0142owe dane wej\u015Bciowe";
    }
  };
}, "error");
function Hc() {
  return {
    localeError: j$()
  };
}
s(Hc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/pt.js
var A$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "caracteres" },
    file: { unit: "bytes" },
    array: { unit: "elementos" },
    set: { unit: "elementos" },
    map: { unit: "entradas" }
  };
  function r(a) {
    return e[a] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "a entrada",
    email: "o endere\xE7o de e-mail",
    url: "o URL",
    emoji: "o emoji",
    uuid: "o UUID",
    uuidv4: "o UUIDv4",
    uuidv6: "o UUIDv6",
    nanoid: "o nanoid",
    guid: "o GUID",
    cuid: "o cuid",
    cuid2: "o cuid2",
    ulid: "o ULID",
    xid: "o XID",
    ksuid: "o KSUID",
    datetime: "a data e hora ISO",
    date: "a data ISO",
    time: "a hora ISO",
    duration: "a dura\xE7\xE3o ISO",
    ipv4: "o endere\xE7o IPv4",
    ipv6: "o endere\xE7o IPv6",
    mac: "o endere\xE7o MAC",
    cidrv4: "o intervalo de endere\xE7os IPv4",
    cidrv6: "o intervalo de endere\xE7os IPv6",
    base64: "o texto codificado em base64",
    base64url: "o texto codificado em base64url",
    json_string: "o texto JSON",
    e164: "o n\xFAmero E.164",
    credit_card: "o n\xFAmero de cart\xE3o de cr\xE9dito",
    jwt: "o JWT",
    template_literal: "a entrada"
  }, o = {
    masculine: { definite: "o", indefinite: "um" },
    feminine: { definite: "a", indefinite: "uma" }
  }, t = {
    string: { name: "texto", articles: o.masculine },
    number: { name: "n\xFAmero", articles: o.masculine },
    int: { name: "n\xFAmero inteiro", articles: o.masculine },
    boolean: { name: "valor booleano", articles: o.masculine },
    bigint: { name: "n\xFAmero bigint", articles: o.masculine },
    symbol: { name: "s\xEDmbolo", articles: o.masculine },
    undefined: { name: 'valor "undefined"', articles: o.masculine },
    null: { name: 'valor "nulo"', articles: o.masculine },
    never: { name: 'valor "never"', articles: o.masculine },
    void: { name: 'valor "void"', articles: o.masculine },
    date: { name: "data", articles: o.feminine },
    array: { name: "vetor", articles: o.masculine },
    object: { name: "objeto", articles: o.masculine },
    tuple: { name: "tuplo", articles: o.masculine },
    record: { name: "registo", articles: o.masculine },
    map: { name: "mapa", articles: o.masculine },
    set: { name: "conjunto", articles: o.masculine },
    file: { name: "ficheiro", articles: o.masculine },
    nonoptional: { name: "valor n\xE3o opcional", articles: o.masculine },
    nan: { name: 'valor "NaN"', articles: o.masculine },
    // Compatibility: "nan" -> "NaN" for display
    function: { name: "fun\xE7\xE3o", articles: o.feminine }
  };
  function n(a, c) {
    let u = t[a] ?? { name: `valor "${a}"`, articles: o.masculine };
    return `${u.articles[c]} ${u.name}`;
  }
  return s(n, "translateOriginWithArticle"), (a) => {
    switch (a.code) {
      case "invalid_type": {
        let c = n(a.expected, "indefinite"), u = w(a.input), l = n(u, "indefinite");
        return `Entrada inv\xE1lida: esperava ${c}, recebeu ${l}`;
      }
      case "invalid_value":
        return a.values.length === 1 ? `Entrada inv\xE1lida: esperava ${x(a.values[0])}` : `Op\xE7\xE3o inv\xE1lida: esperava uma das seguintes op\xE7\xF5es: ${g(a.values, "|")}`;
      case "too_big": {
        let c = a.inclusive ? "<=" : "<", u = r(a.origin);
        return u ? `Demasiado grande: esperava que ${n(a.origin, "definite")} tivesse ${c} ${a.maximum.toString()} ${u.unit ?? "elementos"}` : `Demasiado grande: esperava que ${n(a.origin, "definite")} fosse ${c} ${a.maximum.toString()}`;
      }
      case "too_small": {
        let c = a.inclusive ? ">=" : ">", u = r(a.origin);
        return u ? `Demasiado pequeno: esperava que ${n(a.origin, "definite")} tivesse ${c} ${a.minimum.toString()} ${u.unit ?? "elementos"}` : `Demasiado pequeno: esperava que ${n(a.origin, "definite")} fosse ${c} ${a.minimum.toString()}`;
      }
      case "invalid_format": {
        let c = a;
        return c.format === "starts_with" ? `Texto inv\xE1lido: deve come\xE7ar por "${c.prefix}"` : c.format === "ends_with" ? `Texto inv\xE1lido: deve terminar em "${c.suffix}"` : c.format === "includes" ? `Texto inv\xE1lido: deve incluir "${c.includes}"` : c.format === "regex" ? `Texto inv\xE1lido: deve corresponder ao padr\xE3o ${c.pattern}` : `Formato d${i[c.format] ?? a.format} inv\xE1lido`;
      }
      case "not_multiple_of":
        return `N\xFAmero inv\xE1lido: deve ser m\xFAltiplo de ${a.divisor}`;
      case "unrecognized_keys": {
        let c = a.keys.length > 1 ? "s" : "";
        return `Chave${c} inv\xE1lida${c}: ${g(a.keys, ", ")}`;
      }
      case "invalid_key":
        return `Entrada inv\xE1lida n${n(a.origin, "definite")}`;
      case "invalid_union":
        return a.options && Array.isArray(a.options) && a.options.length > 0 ? `Valor de discrimina\xE7\xE3o inv\xE1lido. Esperava ${a.options.map((u) => `'${u}'`).join(" | ")}` : "Entrada inv\xE1lida";
      case "invalid_element":
        return `Entrada inv\xE1lida n${n(a.origin, "definite")}`;
      default:
        return "Entrada inv\xE1lida";
    }
  };
}, "error");
function Qc() {
  return {
    localeError: A$()
  };
}
s(Qc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/pt-BR.js
var P$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "caracteres" },
    file: { unit: "bytes" },
    array: { unit: "elementos" },
    set: { unit: "elementos" },
    map: { unit: "entradas" }
  };
  function r(a) {
    return e[a] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "a entrada",
    email: "o endere\xE7o de e-mail",
    url: "o URL",
    emoji: "o emoji",
    uuid: "o UUID",
    uuidv4: "o UUIDv4",
    uuidv6: "o UUIDv6",
    nanoid: "o nanoid",
    guid: "o GUID",
    cuid: "o cuid",
    cuid2: "o cuid2",
    ulid: "o ULID",
    xid: "o XID",
    ksuid: "o KSUID",
    datetime: "a data e hora ISO",
    date: "a data ISO",
    time: "a hora ISO",
    duration: "a dura\xE7\xE3o ISO",
    ipv4: "o endere\xE7o IPv4",
    ipv6: "o endere\xE7o IPv6",
    mac: "o endere\xE7o MAC",
    cidrv4: "a faixa de endere\xE7os IPv4",
    cidrv6: "a faixa de endere\xE7os IPv6",
    base64: "o texto codificado em base64",
    base64url: "o texto codificado em base64url",
    json_string: "o texto JSON",
    e164: "o n\xFAmero E.164",
    credit_card: "o n\xFAmero de cart\xE3o de cr\xE9dito",
    jwt: "o JWT",
    template_literal: "a entrada"
  }, o = {
    masculine: { definite: "o", indefinite: "um" },
    feminine: { definite: "a", indefinite: "uma" }
  }, t = {
    string: { name: "texto", articles: o.masculine },
    number: { name: "n\xFAmero", articles: o.masculine },
    int: { name: "n\xFAmero inteiro", articles: o.masculine },
    boolean: { name: "valor booleano", articles: o.masculine },
    bigint: { name: "n\xFAmero bigint", articles: o.masculine },
    symbol: { name: "s\xEDmbolo", articles: o.masculine },
    undefined: { name: 'valor "undefined"', articles: o.masculine },
    null: { name: 'valor "nulo"', articles: o.masculine },
    never: { name: 'valor "never"', articles: o.masculine },
    void: { name: 'valor "void"', articles: o.masculine },
    date: { name: "data", articles: o.feminine },
    array: { name: "vetor", articles: o.masculine },
    object: { name: "objeto", articles: o.masculine },
    tuple: { name: "tupla", articles: o.feminine },
    record: { name: "registro", articles: o.masculine },
    map: { name: "mapa", articles: o.masculine },
    set: { name: "conjunto", articles: o.masculine },
    file: { name: "arquivo", articles: o.masculine },
    nonoptional: { name: "valor n\xE3o opcional", articles: o.masculine },
    nan: { name: 'valor "NaN"', articles: o.masculine },
    // Compatibility: "nan" -> "NaN" for display
    function: { name: "fun\xE7\xE3o", articles: o.feminine }
  };
  function n(a, c) {
    let u = t[a] ?? { name: `valor "${a}"`, articles: o.masculine };
    return `${u.articles[c]} ${u.name}`;
  }
  return s(n, "translateOriginWithArticle"), (a) => {
    switch (a.code) {
      case "invalid_type": {
        let c = n(a.expected, "indefinite"), u = w(a.input), l = n(u, "indefinite");
        return `Entrada inv\xE1lida: esperava ${c}, recebeu ${l}`;
      }
      case "invalid_value":
        return a.values.length === 1 ? `Entrada inv\xE1lida: esperava ${x(a.values[0])}` : `Op\xE7\xE3o inv\xE1lida: esperava uma das seguintes op\xE7\xF5es: ${g(a.values, "|")}`;
      case "too_big": {
        let c = a.inclusive ? "<=" : "<", u = r(a.origin);
        return u ? `Grande demais: esperava que ${n(a.origin, "definite")} tivesse ${c} ${a.maximum.toString()} ${u.unit ?? "elementos"}` : `Grande demais: esperava que ${n(a.origin, "definite")} fosse ${c} ${a.maximum.toString()}`;
      }
      case "too_small": {
        let c = a.inclusive ? ">=" : ">", u = r(a.origin);
        return u ? `Pequeno demais: esperava que ${n(a.origin, "definite")} tivesse ${c} ${a.minimum.toString()} ${u.unit ?? "elementos"}` : `Pequeno demais: esperava que ${n(a.origin, "definite")} fosse ${c} ${a.minimum.toString()}`;
      }
      case "invalid_format": {
        let c = a;
        return c.format === "starts_with" ? `Texto inv\xE1lido: deve come\xE7ar com "${c.prefix}"` : c.format === "ends_with" ? `Texto inv\xE1lido: deve terminar com "${c.suffix}"` : c.format === "includes" ? `Texto inv\xE1lido: deve incluir "${c.includes}"` : c.format === "regex" ? `Texto inv\xE1lido: deve corresponder ao padr\xE3o ${c.pattern}` : `Formato d${i[c.format] ?? a.format} inv\xE1lido`;
      }
      case "not_multiple_of":
        return `N\xFAmero inv\xE1lido: deve ser m\xFAltiplo de ${a.divisor}`;
      case "unrecognized_keys": {
        let c = a.keys.length > 1 ? "s" : "";
        return `Chave${c} inv\xE1lida${c}: ${g(a.keys, ", ")}`;
      }
      case "invalid_key":
        return `Entrada inv\xE1lida n${n(a.origin, "definite")}`;
      case "invalid_union":
        return a.options && Array.isArray(a.options) && a.options.length > 0 ? `Valor de discrimina\xE7\xE3o inv\xE1lido. Esperava ${a.options.map((u) => `'${u}'`).join(" | ")}` : "Entrada inv\xE1lida";
      case "invalid_element":
        return `Entrada inv\xE1lida n${n(a.origin, "definite")}`;
      default:
        return "Entrada inv\xE1lida";
    }
  };
}, "error");
function Yc() {
  return {
    localeError: P$()
  };
}
s(Yc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ro.js
var D$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "caractere", verb: "s\u0103 aib\u0103" },
    file: { unit: "octe\u021Bi", verb: "s\u0103 aib\u0103" },
    array: { unit: "elemente", verb: "s\u0103 aib\u0103" },
    set: { unit: "elemente", verb: "s\u0103 aib\u0103" },
    map: { unit: "intr\u0103ri", verb: "s\u0103 aib\u0103" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "intrare",
    email: "adres\u0103 de email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "dat\u0103 \u0219i or\u0103 ISO",
    date: "dat\u0103 ISO",
    time: "or\u0103 ISO",
    duration: "durat\u0103 ISO",
    ipv4: "adres\u0103 IPv4",
    ipv6: "adres\u0103 IPv6",
    mac: "adres\u0103 MAC",
    cidrv4: "interval IPv4",
    cidrv6: "interval IPv6",
    base64: "\u0219ir codat base64",
    base64url: "\u0219ir codat base64url",
    json_string: "\u0219ir JSON",
    e164: "num\u0103r E.164",
    credit_card: "num\u0103r de card de credit",
    jwt: "JWT",
    template_literal: "intrare"
  }, o = {
    nan: "NaN",
    string: "\u0219ir",
    number: "num\u0103r",
    boolean: "boolean",
    function: "func\u021Bie",
    array: "matrice",
    object: "obiect",
    undefined: "nedefinit",
    symbol: "simbol",
    bigint: "num\u0103r mare",
    void: "void",
    never: "never",
    map: "hart\u0103",
    set: "set"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return `Intrare invalid\u0103: a\u0219teptat ${n}, primit ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Intrare invalid\u0103: a\u0219teptat ${x(t.values[0])}` : `Op\u021Biune invalid\u0103: a\u0219teptat una dintre ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Prea mare: a\u0219teptat ca ${t.origin ?? "valoarea"} ${a.verb} ${n}${t.maximum.toString()} ${a.unit ?? "elemente"}` : `Prea mare: a\u0219teptat ca ${t.origin ?? "valoarea"} s\u0103 fie ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Prea mic: a\u0219teptat ca ${t.origin} ${a.verb} ${n}${t.minimum.toString()} ${a.unit}` : `Prea mic: a\u0219teptat ca ${t.origin} s\u0103 fie ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u0218ir invalid: trebuie s\u0103 \xEEnceap\u0103 cu "${n.prefix}"` : n.format === "ends_with" ? `\u0218ir invalid: trebuie s\u0103 se termine cu "${n.suffix}"` : n.format === "includes" ? `\u0218ir invalid: trebuie s\u0103 includ\u0103 "${n.includes}"` : n.format === "regex" ? `\u0218ir invalid: trebuie s\u0103 se potriveasc\u0103 cu modelul ${n.pattern}` : `Format invalid: ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Num\u0103r invalid: trebuie s\u0103 fie multiplu de ${t.divisor}`;
      case "unrecognized_keys":
        return `Chei nerecunoscute: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `Cheie invalid\u0103 \xEEn ${t.origin}`;
      case "invalid_union":
        return "Intrare invalid\u0103";
      case "invalid_element":
        return `Valoare invalid\u0103 \xEEn ${t.origin}`;
      default:
        return "Intrare invalid\u0103";
    }
  };
}, "error");
function eu() {
  return {
    localeError: D$()
  };
}
s(eu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ru.js
function up(e, r, i, o) {
  let t = Math.abs(e), n = t % 10, a = t % 100;
  return a >= 11 && a <= 19 ? o : n === 1 ? r : n >= 2 && n <= 4 ? i : o;
}
s(up, "getRussianPlural");
var N$ = /* @__PURE__ */ s(() => {
  let e = {
    string: {
      unit: {
        one: "\u0441\u0438\u043C\u0432\u043E\u043B",
        few: "\u0441\u0438\u043C\u0432\u043E\u043B\u0430",
        many: "\u0441\u0438\u043C\u0432\u043E\u043B\u043E\u0432"
      },
      verb: "\u0438\u043C\u0435\u0442\u044C"
    },
    file: {
      unit: {
        one: "\u0431\u0430\u0439\u0442",
        few: "\u0431\u0430\u0439\u0442\u0430",
        many: "\u0431\u0430\u0439\u0442"
      },
      verb: "\u0438\u043C\u0435\u0442\u044C"
    },
    array: {
      unit: {
        one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
        few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430",
        many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u043E\u0432"
      },
      verb: "\u0438\u043C\u0435\u0442\u044C"
    },
    set: {
      unit: {
        one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
        few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430",
        many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u043E\u0432"
      },
      verb: "\u0438\u043C\u0435\u0442\u044C"
    },
    map: {
      unit: {
        one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
        few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430",
        many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u043E\u0432"
      },
      verb: "\u0438\u043C\u0435\u0442\u044C"
    }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u0432\u0432\u043E\u0434",
    email: "email \u0430\u0434\u0440\u0435\u0441",
    url: "URL",
    emoji: "\u044D\u043C\u043E\u0434\u0437\u0438",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0434\u0430\u0442\u0430 \u0438 \u0432\u0440\u0435\u043C\u044F",
    date: "ISO \u0434\u0430\u0442\u0430",
    time: "ISO \u0432\u0440\u0435\u043C\u044F",
    duration: "ISO \u0434\u043B\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C",
    ipv4: "IPv4 \u0430\u0434\u0440\u0435\u0441",
    ipv6: "IPv6 \u0430\u0434\u0440\u0435\u0441",
    mac: "MAC \u0430\u0434\u0440\u0435\u0441",
    cidrv4: "IPv4 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D",
    cidrv6: "IPv6 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D",
    base64: "\u0441\u0442\u0440\u043E\u043A\u0430 \u0432 \u0444\u043E\u0440\u043C\u0430\u0442\u0435 base64",
    base64url: "\u0441\u0442\u0440\u043E\u043A\u0430 \u0432 \u0444\u043E\u0440\u043C\u0430\u0442\u0435 base64url",
    json_string: "JSON \u0441\u0442\u0440\u043E\u043A\u0430",
    e164: "\u043D\u043E\u043C\u0435\u0440 E.164",
    credit_card: "\u043D\u043E\u043C\u0435\u0440 \u043A\u0440\u0435\u0434\u0438\u0442\u043D\u043E\u0439 \u043A\u0430\u0440\u0442\u044B",
    jwt: "JWT",
    template_literal: "\u0432\u0432\u043E\u0434"
  }, o = {
    nan: "NaN",
    number: "\u0447\u0438\u0441\u043B\u043E",
    array: "\u043C\u0430\u0441\u0441\u0438\u0432"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0432\u0432\u043E\u0434: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C instanceof ${t.expected}, \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u043E ${c}` : `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0432\u0432\u043E\u0434: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C ${n}, \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u043E ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0432\u0432\u043E\u0434: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C ${x(t.values[0])}` : `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0432\u0430\u0440\u0438\u0430\u043D\u0442: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C \u043E\u0434\u043D\u043E \u0438\u0437 ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        if (a) {
          let c = Number(t.maximum), u = up(c, a.unit.one, a.unit.few, a.unit.many);
          return `\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C, \u0447\u0442\u043E ${t.origin ?? "\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435"} \u0431\u0443\u0434\u0435\u0442 \u0438\u043C\u0435\u0442\u044C ${n}${t.maximum.toString()} ${u}`;
        }
        return `\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C, \u0447\u0442\u043E ${t.origin ?? "\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435"} \u0431\u0443\u0434\u0435\u0442 ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        if (a) {
          let c = Number(t.minimum), u = up(c, a.unit.one, a.unit.few, a.unit.many);
          return `\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u043C\u0430\u043B\u0435\u043D\u044C\u043A\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C, \u0447\u0442\u043E ${t.origin} \u0431\u0443\u0434\u0435\u0442 \u0438\u043C\u0435\u0442\u044C ${n}${t.minimum.toString()} ${u}`;
        }
        return `\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u043C\u0430\u043B\u0435\u043D\u044C\u043A\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C, \u0447\u0442\u043E ${t.origin} \u0431\u0443\u0434\u0435\u0442 ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u0441\u0442\u0440\u043E\u043A\u0430: \u0434\u043E\u043B\u0436\u043D\u0430 \u043D\u0430\u0447\u0438\u043D\u0430\u0442\u044C\u0441\u044F \u0441 "${n.prefix}"` : n.format === "ends_with" ? `\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u0441\u0442\u0440\u043E\u043A\u0430: \u0434\u043E\u043B\u0436\u043D\u0430 \u0437\u0430\u043A\u0430\u043D\u0447\u0438\u0432\u0430\u0442\u044C\u0441\u044F \u043D\u0430 "${n.suffix}"` : n.format === "includes" ? `\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u0441\u0442\u0440\u043E\u043A\u0430: \u0434\u043E\u043B\u0436\u043D\u0430 \u0441\u043E\u0434\u0435\u0440\u0436\u0430\u0442\u044C "${n.includes}"` : n.format === "regex" ? `\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u0441\u0442\u0440\u043E\u043A\u0430: \u0434\u043E\u043B\u0436\u043D\u0430 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u043E\u0432\u0430\u0442\u044C \u0448\u0430\u0431\u043B\u043E\u043D\u0443 ${n.pattern}` : `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u041D\u0435\u0432\u0435\u0440\u043D\u043E\u0435 \u0447\u0438\u0441\u043B\u043E: \u0434\u043E\u043B\u0436\u043D\u043E \u0431\u044B\u0442\u044C \u043A\u0440\u0430\u0442\u043D\u044B\u043C ${t.divisor}`;
      case "unrecognized_keys":
        return `\u041D\u0435\u0440\u0430\u0441\u043F\u043E\u0437\u043D\u0430\u043D\u043D${t.keys.length > 1 ? "\u044B\u0435" : "\u044B\u0439"} \u043A\u043B\u044E\u0447${t.keys.length > 1 ? "\u0438" : ""}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u043A\u043B\u044E\u0447 \u0432 ${t.origin}`;
      case "invalid_union":
        return "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0435 \u0432\u0445\u043E\u0434\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435";
      case "invalid_element":
        return `\u041D\u0435\u0432\u0435\u0440\u043D\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u0432 ${t.origin}`;
      default:
        return "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0435 \u0432\u0445\u043E\u0434\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435";
    }
  };
}, "error");
function tu() {
  return {
    localeError: N$()
  };
}
s(tu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/sk.js
var T$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "znakov", verb: "ma\u0165" },
    file: { unit: "bajtov", verb: "ma\u0165" },
    array: { unit: "prvkov", verb: "ma\u0165" },
    set: { unit: "prvkov", verb: "ma\u0165" },
    map: { unit: "polo\u017Eiek", verb: "ma\u0165" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "regul\xE1rny v\xFDraz",
    email: "e-mailov\xE1 adresa",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "d\xE1tum a \u010Das vo form\xE1te ISO",
    date: "d\xE1tum vo form\xE1te ISO",
    time: "\u010Das vo form\xE1te ISO",
    duration: "doba trvania ISO",
    ipv4: "IPv4 adresa",
    ipv6: "IPv6 adresa",
    mac: "MAC adresa",
    cidrv4: "rozsah IPv4",
    cidrv6: "rozsah IPv6",
    base64: "re\u0165azec zak\xF3dovan\xFD vo form\xE1te base64",
    base64url: "re\u0165azec zak\xF3dovan\xFD vo form\xE1te base64url",
    json_string: "re\u0165azec vo form\xE1te JSON",
    e164: "\u010D\xEDslo E.164",
    credit_card: "\u010D\xEDslo kreditnej karty",
    jwt: "JWT",
    template_literal: "vstup"
  }, o = {
    nan: "NaN",
    number: "\u010D\xEDslo",
    string: "re\u0165azec",
    function: "funkcia",
    array: "pole"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Neplatn\xFD vstup: o\u010Dak\xE1van\xE9 instanceof ${t.expected}, obdr\u017Ean\xE9 ${c}` : `Neplatn\xFD vstup: o\u010Dak\xE1van\xE9 ${n}, obdr\u017Ean\xE9 ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Neplatn\xFD vstup: o\u010Dak\xE1van\xE9 ${x(t.values[0])}` : `Neplatn\xFD vstup: o\u010Dak\xE1van\xE1 jedna z hodn\xF4t ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Hodnota je pr\xEDli\u0161 ve\u013Ek\xE1: ${t.origin ?? "hodnota"} mus\xED ma\u0165 ${n}${t.maximum.toString()} ${a.unit ?? "prvkov"}` : `Hodnota je pr\xEDli\u0161 ve\u013Ek\xE1: ${t.origin ?? "hodnota"} mus\xED by\u0165 ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Hodnota je pr\xEDli\u0161 mal\xE1: ${t.origin ?? "hodnota"} mus\xED ma\u0165 ${n}${t.minimum.toString()} ${a.unit ?? "prvkov"}` : `Hodnota je pr\xEDli\u0161 mal\xE1: ${t.origin ?? "hodnota"} mus\xED by\u0165 ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Neplatn\xFD re\u0165azec: mus\xED za\u010D\xEDna\u0165 na "${n.prefix}"` : n.format === "ends_with" ? `Neplatn\xFD re\u0165azec: mus\xED kon\u010Di\u0165 na "${n.suffix}"` : n.format === "includes" ? `Neplatn\xFD re\u0165azec: mus\xED obsahova\u0165 "${n.includes}"` : n.format === "regex" ? `Neplatn\xFD re\u0165azec: mus\xED zodpoveda\u0165 vzoru ${n.pattern}` : `Neplatn\xFD form\xE1t ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Neplatn\xE9 \u010D\xEDslo: mus\xED by\u0165 n\xE1sobkom ${t.divisor}`;
      case "unrecognized_keys":
        return `Nezn\xE1me kl\xFA\u010De: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `Neplatn\xFD kl\xFA\u010D v ${t.origin}`;
      case "invalid_union":
        return "Neplatn\xFD vstup";
      case "invalid_element":
        return `Neplatn\xE1 hodnota v ${t.origin}`;
      default:
        return "Neplatn\xFD vstup";
    }
  };
}, "error");
function ru() {
  return {
    localeError: T$()
  };
}
s(ru, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/sl.js
var U$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "znakov", verb: "imeti" },
    file: { unit: "bajtov", verb: "imeti" },
    array: { unit: "elementov", verb: "imeti" },
    set: { unit: "elementov", verb: "imeti" },
    map: { unit: "elementov", verb: "imeti" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "vnos",
    email: "e-po\u0161tni naslov",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datum in \u010Das",
    date: "ISO datum",
    time: "ISO \u010Das",
    duration: "ISO trajanje",
    ipv4: "IPv4 naslov",
    ipv6: "IPv6 naslov",
    mac: "MAC naslov",
    cidrv4: "obseg IPv4",
    cidrv6: "obseg IPv6",
    base64: "base64 kodiran niz",
    base64url: "base64url kodiran niz",
    json_string: "JSON niz",
    e164: "E.164 \u0161tevilka",
    credit_card: "\u0161tevilka kreditne kartice",
    jwt: "JWT",
    template_literal: "vnos"
  }, o = {
    nan: "NaN",
    number: "\u0161tevilo",
    array: "tabela"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Neveljaven vnos: pri\u010Dakovano instanceof ${t.expected}, prejeto ${c}` : `Neveljaven vnos: pri\u010Dakovano ${n}, prejeto ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Neveljaven vnos: pri\u010Dakovano ${x(t.values[0])}` : `Neveljavna mo\u017Enost: pri\u010Dakovano eno izmed ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Preveliko: pri\u010Dakovano, da bo ${t.origin ?? "vrednost"} imelo ${n}${t.maximum.toString()} ${a.unit ?? "elementov"}` : `Preveliko: pri\u010Dakovano, da bo ${t.origin ?? "vrednost"} ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Premajhno: pri\u010Dakovano, da bo ${t.origin} imelo ${n}${t.minimum.toString()} ${a.unit}` : `Premajhno: pri\u010Dakovano, da bo ${t.origin} ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Neveljaven niz: mora se za\u010Deti z "${n.prefix}"` : n.format === "ends_with" ? `Neveljaven niz: mora se kon\u010Dati z "${n.suffix}"` : n.format === "includes" ? `Neveljaven niz: mora vsebovati "${n.includes}"` : n.format === "regex" ? `Neveljaven niz: mora ustrezati vzorcu ${n.pattern}` : `Neveljaven ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Neveljavno \u0161tevilo: mora biti ve\u010Dkratnik ${t.divisor}`;
      case "unrecognized_keys":
        return `Neprepoznan${t.keys.length > 1 ? "i klju\u010Di" : " klju\u010D"}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `Neveljaven klju\u010D v ${t.origin}`;
      case "invalid_union":
        return "Neveljaven vnos";
      case "invalid_element":
        return `Neveljavna vrednost v ${t.origin}`;
      default:
        return "Neveljaven vnos";
    }
  };
}, "error");
function nu() {
  return {
    localeError: U$()
  };
}
s(nu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/sv.js
var E$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "tecken", verb: "att ha" },
    file: { unit: "bytes", verb: "att ha" },
    array: { unit: "objekt", verb: "att inneh\xE5lla" },
    set: { unit: "objekt", verb: "att inneh\xE5lla" },
    map: { unit: "objekt", verb: "att inneh\xE5lla" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "regulj\xE4rt uttryck",
    email: "e-postadress",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO-datum och tid",
    date: "ISO-datum",
    time: "ISO-tid",
    duration: "ISO-varaktighet",
    ipv4: "IPv4-adress",
    ipv6: "IPv6-adress",
    mac: "MAC-adress",
    cidrv4: "IPv4-spektrum",
    cidrv6: "IPv6-spektrum",
    base64: "base64-kodad str\xE4ng",
    base64url: "base64url-kodad str\xE4ng",
    json_string: "JSON-str\xE4ng",
    e164: "E.164-nummer",
    credit_card: "kreditkortsnummer",
    jwt: "JWT",
    template_literal: "mall-literal"
  }, o = {
    nan: "NaN",
    number: "antal",
    array: "lista"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Ogiltig inmatning: f\xF6rv\xE4ntat instanceof ${t.expected}, fick ${c}` : `Ogiltig inmatning: f\xF6rv\xE4ntat ${n}, fick ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Ogiltig inmatning: f\xF6rv\xE4ntat ${x(t.values[0])}` : `Ogiltigt val: f\xF6rv\xE4ntade en av ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `F\xF6r stor(t): f\xF6rv\xE4ntade ${t.origin ?? "v\xE4rdet"} att ha ${n}${t.maximum.toString()} ${a.unit ?? "element"}` : `F\xF6r stor(t): f\xF6rv\xE4ntat ${t.origin ?? "v\xE4rdet"} att ha ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `F\xF6r lite(t): f\xF6rv\xE4ntade ${t.origin ?? "v\xE4rdet"} att ha ${n}${t.minimum.toString()} ${a.unit}` : `F\xF6r lite(t): f\xF6rv\xE4ntade ${t.origin ?? "v\xE4rdet"} att ha ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Ogiltig str\xE4ng: m\xE5ste b\xF6rja med "${n.prefix}"` : n.format === "ends_with" ? `Ogiltig str\xE4ng: m\xE5ste sluta med "${n.suffix}"` : n.format === "includes" ? `Ogiltig str\xE4ng: m\xE5ste inneh\xE5lla "${n.includes}"` : n.format === "regex" ? `Ogiltig str\xE4ng: m\xE5ste matcha m\xF6nstret "${n.pattern}"` : `Ogiltig(t) ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Ogiltigt tal: m\xE5ste vara en multipel av ${t.divisor}`;
      case "unrecognized_keys":
        return `${t.keys.length > 1 ? "Ok\xE4nda nycklar" : "Ok\xE4nd nyckel"}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `Ogiltig nyckel i ${t.origin ?? "v\xE4rdet"}`;
      case "invalid_union":
        return "Ogiltig input";
      case "invalid_element":
        return `Ogiltigt v\xE4rde i ${t.origin ?? "v\xE4rdet"}`;
      default:
        return "Ogiltig input";
    }
  };
}, "error");
function iu() {
  return {
    localeError: E$()
  };
}
s(iu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ta.js
var C$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0B8E\u0BB4\u0BC1\u0BA4\u0BCD\u0BA4\u0BC1\u0B95\u0BCD\u0B95\u0BB3\u0BCD", verb: "\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD" },
    file: { unit: "\u0BAA\u0BC8\u0B9F\u0BCD\u0B9F\u0BC1\u0B95\u0BB3\u0BCD", verb: "\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD" },
    array: { unit: "\u0B89\u0BB1\u0BC1\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD", verb: "\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD" },
    set: { unit: "\u0B89\u0BB1\u0BC1\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD", verb: "\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD" },
    map: { unit: "\u0B89\u0BB1\u0BC1\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD", verb: "\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1",
    email: "\u0BAE\u0BBF\u0BA9\u0BCD\u0BA9\u0B9E\u0BCD\u0B9A\u0BB2\u0BCD \u0BAE\u0BC1\u0B95\u0BB5\u0BB0\u0BBF",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0BA4\u0BC7\u0BA4\u0BBF \u0BA8\u0BC7\u0BB0\u0BAE\u0BCD",
    date: "ISO \u0BA4\u0BC7\u0BA4\u0BBF",
    time: "ISO \u0BA8\u0BC7\u0BB0\u0BAE\u0BCD",
    duration: "ISO \u0B95\u0BBE\u0BB2 \u0B85\u0BB3\u0BB5\u0BC1",
    ipv4: "IPv4 \u0BAE\u0BC1\u0B95\u0BB5\u0BB0\u0BBF",
    ipv6: "IPv6 \u0BAE\u0BC1\u0B95\u0BB5\u0BB0\u0BBF",
    mac: "MAC \u0BAE\u0BC1\u0B95\u0BB5\u0BB0\u0BBF",
    cidrv4: "IPv4 \u0BB5\u0BB0\u0BAE\u0BCD\u0BAA\u0BC1",
    cidrv6: "IPv6 \u0BB5\u0BB0\u0BAE\u0BCD\u0BAA\u0BC1",
    base64: "base64-encoded \u0B9A\u0BB0\u0BAE\u0BCD",
    base64url: "base64url-encoded \u0B9A\u0BB0\u0BAE\u0BCD",
    json_string: "JSON \u0B9A\u0BB0\u0BAE\u0BCD",
    e164: "E.164 \u0B8E\u0BA3\u0BCD",
    credit_card: "\u0B95\u0B9F\u0BA9\u0BCD \u0B85\u0B9F\u0BCD\u0B9F\u0BC8 \u0B8E\u0BA3\u0BCD",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN",
    number: "\u0B8E\u0BA3\u0BCD",
    array: "\u0B85\u0BA3\u0BBF",
    null: "\u0BB5\u0BC6\u0BB1\u0BC1\u0BAE\u0BC8"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 instanceof ${t.expected}, \u0BAA\u0BC6\u0BB1\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${c}` : `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${n}, \u0BAA\u0BC6\u0BB1\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${x(t.values[0])}` : `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0BB5\u0BBF\u0BB0\u0BC1\u0BAA\u0BCD\u0BAA\u0BAE\u0BCD: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${g(t.values, "|")} \u0B87\u0BB2\u0BCD \u0B92\u0BA9\u0BCD\u0BB1\u0BC1`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u0BAE\u0BBF\u0B95 \u0BAA\u0BC6\u0BB0\u0BBF\u0BAF\u0BA4\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${t.origin ?? "\u0BAE\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1"} ${n}${t.maximum.toString()} ${a.unit ?? "\u0B89\u0BB1\u0BC1\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD"} \u0B86\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : `\u0BAE\u0BBF\u0B95 \u0BAA\u0BC6\u0BB0\u0BBF\u0BAF\u0BA4\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${t.origin ?? "\u0BAE\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1"} ${n}${t.maximum.toString()} \u0B86\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u0BAE\u0BBF\u0B95\u0B9A\u0BCD \u0B9A\u0BBF\u0BB1\u0BBF\u0BAF\u0BA4\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${t.origin} ${n}${t.minimum.toString()} ${a.unit} \u0B86\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : `\u0BAE\u0BBF\u0B95\u0B9A\u0BCD \u0B9A\u0BBF\u0BB1\u0BBF\u0BAF\u0BA4\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${t.origin} ${n}${t.minimum.toString()} \u0B86\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B9A\u0BB0\u0BAE\u0BCD: "${n.prefix}" \u0B87\u0BB2\u0BCD \u0BA4\u0BCA\u0B9F\u0B99\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : n.format === "ends_with" ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B9A\u0BB0\u0BAE\u0BCD: "${n.suffix}" \u0B87\u0BB2\u0BCD \u0BAE\u0BC1\u0B9F\u0BBF\u0BB5\u0B9F\u0BC8\u0BAF \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : n.format === "includes" ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B9A\u0BB0\u0BAE\u0BCD: "${n.includes}" \u0B90 \u0B89\u0BB3\u0BCD\u0BB3\u0B9F\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : n.format === "regex" ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B9A\u0BB0\u0BAE\u0BCD: ${n.pattern} \u0BAE\u0BC1\u0BB1\u0BC8\u0BAA\u0BBE\u0B9F\u0BCD\u0B9F\u0BC1\u0B9F\u0BA9\u0BCD \u0BAA\u0BCA\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B8E\u0BA3\u0BCD: ${t.divisor} \u0B87\u0BA9\u0BCD \u0BAA\u0BB2\u0BAE\u0BBE\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD`;
      case "unrecognized_keys":
        return `\u0B85\u0B9F\u0BC8\u0BAF\u0BBE\u0BB3\u0BAE\u0BCD \u0BA4\u0BC6\u0BB0\u0BBF\u0BAF\u0BBE\u0BA4 \u0BB5\u0BBF\u0B9A\u0BC8${t.keys.length > 1 ? "\u0B95\u0BB3\u0BCD" : ""}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `${t.origin} \u0B87\u0BB2\u0BCD \u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0BB5\u0BBF\u0B9A\u0BC8`;
      case "invalid_union":
        return "\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1";
      case "invalid_element":
        return `${t.origin} \u0B87\u0BB2\u0BCD \u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0BAE\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1`;
      default:
        return "\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1";
    }
  };
}, "error");
function ou() {
  return {
    localeError: C$()
  };
}
s(ou, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/th.js
var Z$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0E15\u0E31\u0E27\u0E2D\u0E31\u0E01\u0E29\u0E23", verb: "\u0E04\u0E27\u0E23\u0E21\u0E35" },
    file: { unit: "\u0E44\u0E1A\u0E15\u0E4C", verb: "\u0E04\u0E27\u0E23\u0E21\u0E35" },
    array: { unit: "\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23", verb: "\u0E04\u0E27\u0E23\u0E21\u0E35" },
    set: { unit: "\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23", verb: "\u0E04\u0E27\u0E23\u0E21\u0E35" },
    map: { unit: "\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23", verb: "\u0E04\u0E27\u0E23\u0E21\u0E35" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E17\u0E35\u0E48\u0E1B\u0E49\u0E2D\u0E19",
    email: "\u0E17\u0E35\u0E48\u0E2D\u0E22\u0E39\u0E48\u0E2D\u0E35\u0E40\u0E21\u0E25",
    url: "URL",
    emoji: "\u0E2D\u0E34\u0E42\u0E21\u0E08\u0E34",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48\u0E40\u0E27\u0E25\u0E32\u0E41\u0E1A\u0E1A ISO",
    date: "\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48\u0E41\u0E1A\u0E1A ISO",
    time: "\u0E40\u0E27\u0E25\u0E32\u0E41\u0E1A\u0E1A ISO",
    duration: "\u0E0A\u0E48\u0E27\u0E07\u0E40\u0E27\u0E25\u0E32\u0E41\u0E1A\u0E1A ISO",
    ipv4: "\u0E17\u0E35\u0E48\u0E2D\u0E22\u0E39\u0E48 IPv4",
    ipv6: "\u0E17\u0E35\u0E48\u0E2D\u0E22\u0E39\u0E48 IPv6",
    mac: "\u0E17\u0E35\u0E48\u0E2D\u0E22\u0E39\u0E48 MAC",
    cidrv4: "\u0E0A\u0E48\u0E27\u0E07 IP \u0E41\u0E1A\u0E1A IPv4",
    cidrv6: "\u0E0A\u0E48\u0E27\u0E07 IP \u0E41\u0E1A\u0E1A IPv6",
    base64: "\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E41\u0E1A\u0E1A Base64",
    base64url: "\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E41\u0E1A\u0E1A Base64 \u0E2A\u0E33\u0E2B\u0E23\u0E31\u0E1A URL",
    json_string: "\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E41\u0E1A\u0E1A JSON",
    e164: "\u0E40\u0E1A\u0E2D\u0E23\u0E4C\u0E42\u0E17\u0E23\u0E28\u0E31\u0E1E\u0E17\u0E4C\u0E23\u0E30\u0E2B\u0E27\u0E48\u0E32\u0E07\u0E1B\u0E23\u0E30\u0E40\u0E17\u0E28 (E.164)",
    credit_card: "\u0E2B\u0E21\u0E32\u0E22\u0E40\u0E25\u0E02\u0E1A\u0E31\u0E15\u0E23\u0E40\u0E04\u0E23\u0E14\u0E34\u0E15",
    jwt: "\u0E42\u0E17\u0E40\u0E04\u0E19 JWT",
    template_literal: "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E17\u0E35\u0E48\u0E1B\u0E49\u0E2D\u0E19"
  }, o = {
    nan: "NaN",
    number: "\u0E15\u0E31\u0E27\u0E40\u0E25\u0E02",
    array: "\u0E2D\u0E32\u0E23\u0E4C\u0E40\u0E23\u0E22\u0E4C (Array)",
    null: "\u0E44\u0E21\u0E48\u0E21\u0E35\u0E04\u0E48\u0E32 (null)"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u0E1B\u0E23\u0E30\u0E40\u0E20\u0E17\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E04\u0E27\u0E23\u0E40\u0E1B\u0E47\u0E19 instanceof ${t.expected} \u0E41\u0E15\u0E48\u0E44\u0E14\u0E49\u0E23\u0E31\u0E1A ${c}` : `\u0E1B\u0E23\u0E30\u0E40\u0E20\u0E17\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E04\u0E27\u0E23\u0E40\u0E1B\u0E47\u0E19 ${n} \u0E41\u0E15\u0E48\u0E44\u0E14\u0E49\u0E23\u0E31\u0E1A ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u0E04\u0E48\u0E32\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E04\u0E27\u0E23\u0E40\u0E1B\u0E47\u0E19 ${x(t.values[0])}` : `\u0E15\u0E31\u0E27\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E04\u0E27\u0E23\u0E40\u0E1B\u0E47\u0E19\u0E2B\u0E19\u0E36\u0E48\u0E07\u0E43\u0E19 ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "\u0E44\u0E21\u0E48\u0E40\u0E01\u0E34\u0E19" : "\u0E19\u0E49\u0E2D\u0E22\u0E01\u0E27\u0E48\u0E32", a = r(t.origin);
        return a ? `\u0E40\u0E01\u0E34\u0E19\u0E01\u0E33\u0E2B\u0E19\u0E14: ${t.origin ?? "\u0E04\u0E48\u0E32"} \u0E04\u0E27\u0E23\u0E21\u0E35${n} ${t.maximum.toString()} ${a.unit ?? "\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23"}` : `\u0E40\u0E01\u0E34\u0E19\u0E01\u0E33\u0E2B\u0E19\u0E14: ${t.origin ?? "\u0E04\u0E48\u0E32"} \u0E04\u0E27\u0E23\u0E21\u0E35${n} ${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? "\u0E2D\u0E22\u0E48\u0E32\u0E07\u0E19\u0E49\u0E2D\u0E22" : "\u0E21\u0E32\u0E01\u0E01\u0E27\u0E48\u0E32", a = r(t.origin);
        return a ? `\u0E19\u0E49\u0E2D\u0E22\u0E01\u0E27\u0E48\u0E32\u0E01\u0E33\u0E2B\u0E19\u0E14: ${t.origin} \u0E04\u0E27\u0E23\u0E21\u0E35${n} ${t.minimum.toString()} ${a.unit}` : `\u0E19\u0E49\u0E2D\u0E22\u0E01\u0E27\u0E48\u0E32\u0E01\u0E33\u0E2B\u0E19\u0E14: ${t.origin} \u0E04\u0E27\u0E23\u0E21\u0E35${n} ${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E15\u0E49\u0E2D\u0E07\u0E02\u0E36\u0E49\u0E19\u0E15\u0E49\u0E19\u0E14\u0E49\u0E27\u0E22 "${n.prefix}"` : n.format === "ends_with" ? `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E15\u0E49\u0E2D\u0E07\u0E25\u0E07\u0E17\u0E49\u0E32\u0E22\u0E14\u0E49\u0E27\u0E22 "${n.suffix}"` : n.format === "includes" ? `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E15\u0E49\u0E2D\u0E07\u0E21\u0E35 "${n.includes}" \u0E2D\u0E22\u0E39\u0E48\u0E43\u0E19\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21` : n.format === "regex" ? `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E15\u0E49\u0E2D\u0E07\u0E15\u0E23\u0E07\u0E01\u0E31\u0E1A\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E17\u0E35\u0E48\u0E01\u0E33\u0E2B\u0E19\u0E14 ${n.pattern}` : `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u0E15\u0E31\u0E27\u0E40\u0E25\u0E02\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E15\u0E49\u0E2D\u0E07\u0E40\u0E1B\u0E47\u0E19\u0E08\u0E33\u0E19\u0E27\u0E19\u0E17\u0E35\u0E48\u0E2B\u0E32\u0E23\u0E14\u0E49\u0E27\u0E22 ${t.divisor} \u0E44\u0E14\u0E49\u0E25\u0E07\u0E15\u0E31\u0E27`;
      case "unrecognized_keys":
        return `\u0E1E\u0E1A\u0E04\u0E35\u0E22\u0E4C\u0E17\u0E35\u0E48\u0E44\u0E21\u0E48\u0E23\u0E39\u0E49\u0E08\u0E31\u0E01: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `\u0E04\u0E35\u0E22\u0E4C\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07\u0E43\u0E19 ${t.origin}`;
      case "invalid_union":
        return "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E44\u0E21\u0E48\u0E15\u0E23\u0E07\u0E01\u0E31\u0E1A\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E22\u0E39\u0E40\u0E19\u0E35\u0E22\u0E19\u0E17\u0E35\u0E48\u0E01\u0E33\u0E2B\u0E19\u0E14\u0E44\u0E27\u0E49";
      case "invalid_element":
        return `\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07\u0E43\u0E19 ${t.origin}`;
      default:
        return "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07";
    }
  };
}, "error");
function au() {
  return {
    localeError: Z$()
  };
}
s(au, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/tk.js
var R$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "simwol", verb: "bolmaly" },
    file: { unit: "ba\xFDt", verb: "bolmaly" },
    array: { unit: "elementler", verb: "bolmaly" },
    set: { unit: "elementler", verb: "bolmaly" },
    map: { unit: "elementler", verb: "bolmaly" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "giri\u015F",
    email: "e-po\xE7ta salgysy",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO sene we wagt",
    date: "ISO sene",
    time: "ISO wagt",
    duration: "ISO wagt aralygy",
    ipv4: "IPv4 salgysy",
    ipv6: "IPv6 salgysy",
    mac: "MAC salgysy",
    cidrv4: "IPv4 aralygy",
    cidrv6: "IPv6 aralygy",
    base64: "base64 bilen \u015Fifrlenen setir",
    base64url: "base64url bilen \u015Fifrlenen setir",
    json_string: "JSON setiri",
    e164: "E.164 nomeri",
    credit_card: "kredit kartyny\u0148 nomeri",
    jwt: "JWT",
    template_literal: "\u015Fablon"
  }, o = {
    nan: "NaN"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return `N\xE4dogry baha: gara\u015Fylan ${n} \xFDerine ${c} alyndy`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `N\xE4dogry baha: ${x(t.values[0])} bolmaly` : `N\xE4dogry sa\xFDlaw: a\u015Fakdakylardan biri bolmaly: ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Has uly: gara\u015Fyl\xFDan ${t.origin ?? "baha"} ${n} ${t.maximum.toString()} ${a.unit ?? "element"}` : `Has uly: gara\u015Fyl\xFDan ${t.origin ?? "baha"} ${n} ${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Has ki\xE7i: gara\u015Fyl\xFDan ${t.origin} ${n} ${t.minimum.toString()} ${a.unit}` : `Has ki\xE7i: gara\u015Fyl\xFDan ${t.origin} ${n} ${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `N\xE4dogry setir: "${n.prefix}" bilen ba\u015Flamaly` : n.format === "ends_with" ? `N\xE4dogry setir: "${n.suffix}" bilen gutarmaly` : n.format === "includes" ? `N\xE4dogry setir: "${n.includes}" saklamaly` : n.format === "regex" ? `N\xE4dogry setir: ${n.pattern} nusga la\xFDyk bolmaly` : `N\xE4dogry ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `N\xE4dogry san: ${t.divisor} bilen galyndysyz b\xF6l\xFCnmeli`;
      case "unrecognized_keys":
        return `Tanalma\xFDan a\xE7ar${t.keys.length > 1 ? "lar" : ""}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `${t.origin} i\xE7inde n\xE4dogry a\xE7ar`;
      case "invalid_union":
        return "N\xE4dogry baha";
      case "invalid_element":
        return `${t.origin} i\xE7inde n\xE4dogry baha`;
      default:
        return "N\xE4dogry baha";
    }
  };
}, "error");
function su() {
  return {
    localeError: R$()
  };
}
s(su, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/tr.js
var F$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "karakter", verb: "olmal\u0131" },
    file: { unit: "bayt", verb: "olmal\u0131" },
    array: { unit: "\xF6\u011Fe", verb: "olmal\u0131" },
    set: { unit: "\xF6\u011Fe", verb: "olmal\u0131" },
    map: { unit: "\xF6\u011Fe", verb: "olmal\u0131" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "girdi",
    email: "e-posta adresi",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO tarih ve saat",
    date: "ISO tarih",
    time: "ISO saat",
    duration: "ISO s\xFCre",
    ipv4: "IPv4 adresi",
    ipv6: "IPv6 adresi",
    mac: "MAC adresi",
    cidrv4: "IPv4 aral\u0131\u011F\u0131",
    cidrv6: "IPv6 aral\u0131\u011F\u0131",
    base64: "base64 ile \u015Fifrelenmi\u015F metin",
    base64url: "base64url ile \u015Fifrelenmi\u015F metin",
    json_string: "JSON dizesi",
    e164: "E.164 say\u0131s\u0131",
    credit_card: "kredi kart\u0131 numaras\u0131",
    jwt: "JWT",
    template_literal: "\u015Eablon dizesi"
  }, o = {
    nan: "NaN"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Ge\xE7ersiz de\u011Fer: beklenen instanceof ${t.expected}, al\u0131nan ${c}` : `Ge\xE7ersiz de\u011Fer: beklenen ${n}, al\u0131nan ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Ge\xE7ersiz de\u011Fer: beklenen ${x(t.values[0])}` : `Ge\xE7ersiz se\xE7enek: a\u015Fa\u011F\u0131dakilerden biri olmal\u0131: ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\xC7ok b\xFCy\xFCk: beklenen ${t.origin ?? "de\u011Fer"} ${n}${t.maximum.toString()} ${a.unit ?? "\xF6\u011Fe"}` : `\xC7ok b\xFCy\xFCk: beklenen ${t.origin ?? "de\u011Fer"} ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\xC7ok k\xFC\xE7\xFCk: beklenen ${t.origin} ${n}${t.minimum.toString()} ${a.unit}` : `\xC7ok k\xFC\xE7\xFCk: beklenen ${t.origin} ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Ge\xE7ersiz metin: "${n.prefix}" ile ba\u015Flamal\u0131` : n.format === "ends_with" ? `Ge\xE7ersiz metin: "${n.suffix}" ile bitmeli` : n.format === "includes" ? `Ge\xE7ersiz metin: "${n.includes}" i\xE7ermeli` : n.format === "regex" ? `Ge\xE7ersiz metin: ${n.pattern} desenine uymal\u0131` : `Ge\xE7ersiz ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Ge\xE7ersiz say\u0131: ${t.divisor} ile tam b\xF6l\xFCnebilmeli`;
      case "unrecognized_keys":
        return `Tan\u0131nmayan anahtar${t.keys.length > 1 ? "lar" : ""}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `${t.origin} i\xE7inde ge\xE7ersiz anahtar`;
      case "invalid_union":
        return "Ge\xE7ersiz de\u011Fer";
      case "invalid_element":
        return `${t.origin} i\xE7inde ge\xE7ersiz de\u011Fer`;
      default:
        return "Ge\xE7ersiz de\u011Fer";
    }
  };
}, "error");
function cu() {
  return {
    localeError: F$()
  };
}
s(cu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/uk.js
var L$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0441\u0438\u043C\u0432\u043E\u043B\u0456\u0432", verb: "\u043C\u0430\u0442\u0438\u043C\u0435" },
    file: { unit: "\u0431\u0430\u0439\u0442\u0456\u0432", verb: "\u043C\u0430\u0442\u0438\u043C\u0435" },
    array: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0456\u0432", verb: "\u043C\u0430\u0442\u0438\u043C\u0435" },
    set: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0456\u0432", verb: "\u043C\u0430\u0442\u0438\u043C\u0435" },
    map: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0456\u0432", verb: "\u043C\u0430\u0442\u0438\u043C\u0435" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456",
    email: "\u0430\u0434\u0440\u0435\u0441\u0430 \u0435\u043B\u0435\u043A\u0442\u0440\u043E\u043D\u043D\u043E\u0457 \u043F\u043E\u0448\u0442\u0438",
    url: "URL",
    emoji: "\u0435\u043C\u043E\u0434\u0437\u0456",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u0434\u0430\u0442\u0430 \u0442\u0430 \u0447\u0430\u0441 ISO",
    date: "\u0434\u0430\u0442\u0430 ISO",
    time: "\u0447\u0430\u0441 ISO",
    duration: "\u0442\u0440\u0438\u0432\u0430\u043B\u0456\u0441\u0442\u044C ISO",
    ipv4: "\u0430\u0434\u0440\u0435\u0441\u0430 IPv4",
    ipv6: "\u0430\u0434\u0440\u0435\u0441\u0430 IPv6",
    mac: "\u0430\u0434\u0440\u0435\u0441\u0430 MAC",
    cidrv4: "\u0434\u0456\u0430\u043F\u0430\u0437\u043E\u043D IPv4",
    cidrv6: "\u0434\u0456\u0430\u043F\u0430\u0437\u043E\u043D IPv6",
    base64: "\u0440\u044F\u0434\u043E\u043A \u0443 \u043A\u043E\u0434\u0443\u0432\u0430\u043D\u043D\u0456 base64",
    base64url: "\u0440\u044F\u0434\u043E\u043A \u0443 \u043A\u043E\u0434\u0443\u0432\u0430\u043D\u043D\u0456 base64url",
    json_string: "\u0440\u044F\u0434\u043E\u043A JSON",
    e164: "\u043D\u043E\u043C\u0435\u0440 E.164",
    credit_card: "\u043D\u043E\u043C\u0435\u0440 \u043A\u0440\u0435\u0434\u0438\u0442\u043D\u043E\u0457 \u043A\u0430\u0440\u0442\u043A\u0438",
    jwt: "JWT",
    template_literal: "\u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456"
  }, o = {
    nan: "NaN",
    number: "\u0447\u0438\u0441\u043B\u043E",
    array: "\u043C\u0430\u0441\u0438\u0432"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F instanceof ${t.expected}, \u043E\u0442\u0440\u0438\u043C\u0430\u043D\u043E ${c}` : `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F ${n}, \u043E\u0442\u0440\u0438\u043C\u0430\u043D\u043E ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F ${x(t.values[0])}` : `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0430 \u043E\u043F\u0446\u0456\u044F: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F \u043E\u0434\u043D\u0435 \u0437 ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u0417\u0430\u043D\u0430\u0434\u0442\u043E \u0432\u0435\u043B\u0438\u043A\u0435: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F, \u0449\u043E ${t.origin ?? "\u0437\u043D\u0430\u0447\u0435\u043D\u043D\u044F"} ${a.verb} ${n}${t.maximum.toString()} ${a.unit ?? "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0456\u0432"}` : `\u0417\u0430\u043D\u0430\u0434\u0442\u043E \u0432\u0435\u043B\u0438\u043A\u0435: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F, \u0449\u043E ${t.origin ?? "\u0437\u043D\u0430\u0447\u0435\u043D\u043D\u044F"} \u0431\u0443\u0434\u0435 ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u0417\u0430\u043D\u0430\u0434\u0442\u043E \u043C\u0430\u043B\u0435: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F, \u0449\u043E ${t.origin} ${a.verb} ${n}${t.minimum.toString()} ${a.unit}` : `\u0417\u0430\u043D\u0430\u0434\u0442\u043E \u043C\u0430\u043B\u0435: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F, \u0449\u043E ${t.origin} \u0431\u0443\u0434\u0435 ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u0440\u044F\u0434\u043E\u043A: \u043F\u043E\u0432\u0438\u043D\u0435\u043D \u043F\u043E\u0447\u0438\u043D\u0430\u0442\u0438\u0441\u044F \u0437 "${n.prefix}"` : n.format === "ends_with" ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u0440\u044F\u0434\u043E\u043A: \u043F\u043E\u0432\u0438\u043D\u0435\u043D \u0437\u0430\u043A\u0456\u043D\u0447\u0443\u0432\u0430\u0442\u0438\u0441\u044F \u043D\u0430 "${n.suffix}"` : n.format === "includes" ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u0440\u044F\u0434\u043E\u043A: \u043F\u043E\u0432\u0438\u043D\u0435\u043D \u043C\u0456\u0441\u0442\u0438\u0442\u0438 "${n.includes}"` : n.format === "regex" ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u0440\u044F\u0434\u043E\u043A: \u043F\u043E\u0432\u0438\u043D\u0435\u043D \u0432\u0456\u0434\u043F\u043E\u0432\u0456\u0434\u0430\u0442\u0438 \u0448\u0430\u0431\u043B\u043E\u043D\u0443 ${n.pattern}` : `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0435 \u0447\u0438\u0441\u043B\u043E: \u043F\u043E\u0432\u0438\u043D\u043D\u043E \u0431\u0443\u0442\u0438 \u043A\u0440\u0430\u0442\u043D\u0438\u043C ${t.divisor}`;
      case "unrecognized_keys":
        return `\u041D\u0435\u0440\u043E\u0437\u043F\u0456\u0437\u043D\u0430\u043D\u0438\u0439 \u043A\u043B\u044E\u0447${t.keys.length > 1 ? "\u0456" : ""}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u043A\u043B\u044E\u0447 \u0443 ${t.origin}`;
      case "invalid_union":
        return "\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456";
      case "invalid_element":
        return `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u043D\u044F \u0443 ${t.origin}`;
      default:
        return "\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456";
    }
  };
}, "error");
function Rr() {
  return {
    localeError: L$()
  };
}
s(Rr, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ua.js
function uu() {
  return Rr();
}
s(uu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ur.js
var V$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u062D\u0631\u0648\u0641", verb: "\u06C1\u0648\u0646\u0627" },
    file: { unit: "\u0628\u0627\u0626\u0679\u0633", verb: "\u06C1\u0648\u0646\u0627" },
    array: { unit: "\u0622\u0626\u0679\u0645\u0632", verb: "\u06C1\u0648\u0646\u0627" },
    set: { unit: "\u0622\u0626\u0679\u0645\u0632", verb: "\u06C1\u0648\u0646\u0627" },
    map: { unit: "\u0622\u0626\u0679\u0645\u0632", verb: "\u06C1\u0648\u0646\u0627" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u0627\u0646 \u067E\u0679",
    email: "\u0627\u06CC \u0645\u06CC\u0644 \u0627\u06CC\u0688\u0631\u06CC\u0633",
    url: "\u06CC\u0648 \u0622\u0631 \u0627\u06CC\u0644",
    emoji: "\u0627\u06CC\u0645\u0648\u062C\u06CC",
    uuid: "\u06CC\u0648 \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC",
    uuidv4: "\u06CC\u0648 \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC \u0648\u06CC 4",
    uuidv6: "\u06CC\u0648 \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC \u0648\u06CC 6",
    nanoid: "\u0646\u06CC\u0646\u0648 \u0622\u0626\u06CC \u0688\u06CC",
    guid: "\u062C\u06CC \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC",
    cuid: "\u0633\u06CC \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC",
    cuid2: "\u0633\u06CC \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC 2",
    ulid: "\u06CC\u0648 \u0627\u06CC\u0644 \u0622\u0626\u06CC \u0688\u06CC",
    xid: "\u0627\u06CC\u06A9\u0633 \u0622\u0626\u06CC \u0688\u06CC",
    ksuid: "\u06A9\u06D2 \u0627\u06CC\u0633 \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC",
    datetime: "\u0622\u0626\u06CC \u0627\u06CC\u0633 \u0627\u0648 \u0688\u06CC\u0679 \u0679\u0627\u0626\u0645",
    date: "\u0622\u0626\u06CC \u0627\u06CC\u0633 \u0627\u0648 \u062A\u0627\u0631\u06CC\u062E",
    time: "\u0622\u0626\u06CC \u0627\u06CC\u0633 \u0627\u0648 \u0648\u0642\u062A",
    duration: "\u0622\u0626\u06CC \u0627\u06CC\u0633 \u0627\u0648 \u0645\u062F\u062A",
    ipv4: "\u0622\u0626\u06CC \u067E\u06CC \u0648\u06CC 4 \u0627\u06CC\u0688\u0631\u06CC\u0633",
    ipv6: "\u0622\u0626\u06CC \u067E\u06CC \u0648\u06CC 6 \u0627\u06CC\u0688\u0631\u06CC\u0633",
    mac: "\u0627\u06CC\u0645 \u0627\u06D2 \u0633\u06CC \u0627\u06CC\u0688\u0631\u06CC\u0633",
    cidrv4: "\u0622\u0626\u06CC \u067E\u06CC \u0648\u06CC 4 \u0631\u06CC\u0646\u062C",
    cidrv6: "\u0622\u0626\u06CC \u067E\u06CC \u0648\u06CC 6 \u0631\u06CC\u0646\u062C",
    base64: "\u0628\u06CC\u0633 64 \u0627\u0646 \u06A9\u0648\u0688\u0688 \u0633\u0679\u0631\u0646\u06AF",
    base64url: "\u0628\u06CC\u0633 64 \u06CC\u0648 \u0622\u0631 \u0627\u06CC\u0644 \u0627\u0646 \u06A9\u0648\u0688\u0688 \u0633\u0679\u0631\u0646\u06AF",
    json_string: "\u062C\u06D2 \u0627\u06CC\u0633 \u0627\u0648 \u0627\u06CC\u0646 \u0633\u0679\u0631\u0646\u06AF",
    e164: "\u0627\u06CC 164 \u0646\u0645\u0628\u0631",
    credit_card: "\u06A9\u0631\u06CC\u0688\u0679 \u06A9\u0627\u0631\u0688 \u0646\u0645\u0628\u0631",
    jwt: "\u062C\u06D2 \u0688\u0628\u0644\u06CC\u0648 \u0679\u06CC",
    template_literal: "\u0627\u0646 \u067E\u0679"
  }, o = {
    nan: "NaN",
    number: "\u0646\u0645\u0628\u0631",
    array: "\u0622\u0631\u06D2",
    null: "\u0646\u0644"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679: instanceof ${t.expected} \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627\u060C ${c} \u0645\u0648\u0635\u0648\u0644 \u06C1\u0648\u0627` : `\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679: ${n} \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627\u060C ${c} \u0645\u0648\u0635\u0648\u0644 \u06C1\u0648\u0627`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679: ${x(t.values[0])} \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627` : `\u063A\u0644\u0637 \u0622\u067E\u0634\u0646: ${g(t.values, "|")} \u0645\u06CC\u06BA \u0633\u06D2 \u0627\u06CC\u06A9 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u0628\u06C1\u062A \u0628\u0691\u0627: ${t.origin ?? "\u0648\u06CC\u0644\u06CC\u0648"} \u06A9\u06D2 ${n}${t.maximum.toString()} ${a.unit ?? "\u0639\u0646\u0627\u0635\u0631"} \u06C1\u0648\u0646\u06D2 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u06D2` : `\u0628\u06C1\u062A \u0628\u0691\u0627: ${t.origin ?? "\u0648\u06CC\u0644\u06CC\u0648"} \u06A9\u0627 ${n}${t.maximum.toString()} \u06C1\u0648\u0646\u0627 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u0628\u06C1\u062A \u0686\u06BE\u0648\u0679\u0627: ${t.origin} \u06A9\u06D2 ${n}${t.minimum.toString()} ${a.unit} \u06C1\u0648\u0646\u06D2 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u06D2` : `\u0628\u06C1\u062A \u0686\u06BE\u0648\u0679\u0627: ${t.origin} \u06A9\u0627 ${n}${t.minimum.toString()} \u06C1\u0648\u0646\u0627 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u063A\u0644\u0637 \u0633\u0679\u0631\u0646\u06AF: "${n.prefix}" \u0633\u06D2 \u0634\u0631\u0648\u0639 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2` : n.format === "ends_with" ? `\u063A\u0644\u0637 \u0633\u0679\u0631\u0646\u06AF: "${n.suffix}" \u067E\u0631 \u062E\u062A\u0645 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2` : n.format === "includes" ? `\u063A\u0644\u0637 \u0633\u0679\u0631\u0646\u06AF: "${n.includes}" \u0634\u0627\u0645\u0644 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2` : n.format === "regex" ? `\u063A\u0644\u0637 \u0633\u0679\u0631\u0646\u06AF: \u067E\u06CC\u0679\u0631\u0646 ${n.pattern} \u0633\u06D2 \u0645\u06CC\u0686 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2` : `\u063A\u0644\u0637 ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u063A\u0644\u0637 \u0646\u0645\u0628\u0631: ${t.divisor} \u06A9\u0627 \u0645\u0636\u0627\u0639\u0641 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2`;
      case "unrecognized_keys":
        return `\u063A\u06CC\u0631 \u062A\u0633\u0644\u06CC\u0645 \u0634\u062F\u06C1 \u06A9\u06CC${t.keys.length > 1 ? "\u0632" : ""}: ${g(t.keys, "\u060C ")}`;
      case "invalid_key":
        return `${t.origin} \u0645\u06CC\u06BA \u063A\u0644\u0637 \u06A9\u06CC`;
      case "invalid_union":
        return "\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679";
      case "invalid_element":
        return `${t.origin} \u0645\u06CC\u06BA \u063A\u0644\u0637 \u0648\u06CC\u0644\u06CC\u0648`;
      default:
        return "\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679";
    }
  };
}, "error");
function lu() {
  return {
    localeError: V$()
  };
}
s(lu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/uz.js
var M$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "belgi", verb: "bo\u2018lishi kerak" },
    file: { unit: "bayt", verb: "bo\u2018lishi kerak" },
    array: { unit: "element", verb: "bo\u2018lishi kerak" },
    set: { unit: "element", verb: "bo\u2018lishi kerak" },
    map: { unit: "yozuv", verb: "bo\u2018lishi kerak" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "kirish",
    email: "elektron pochta manzili",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO sana va vaqti",
    date: "ISO sana",
    time: "ISO vaqt",
    duration: "ISO davomiylik",
    ipv4: "IPv4 manzil",
    ipv6: "IPv6 manzil",
    mac: "MAC manzil",
    cidrv4: "IPv4 diapazon",
    cidrv6: "IPv6 diapazon",
    base64: "base64 kodlangan satr",
    base64url: "base64url kodlangan satr",
    json_string: "JSON satr",
    e164: "E.164 raqam",
    credit_card: "kredit karta raqami",
    jwt: "JWT",
    template_literal: "kirish"
  }, o = {
    nan: "NaN",
    number: "raqam",
    array: "massiv"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Noto\u2018g\u2018ri kirish: kutilgan instanceof ${t.expected}, qabul qilingan ${c}` : `Noto\u2018g\u2018ri kirish: kutilgan ${n}, qabul qilingan ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Noto\u2018g\u2018ri kirish: kutilgan ${x(t.values[0])}` : `Noto\u2018g\u2018ri variant: quyidagilardan biri kutilgan ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Juda katta: kutilgan ${t.origin ?? "qiymat"} ${n}${t.maximum.toString()} ${a.unit} ${a.verb}` : `Juda katta: kutilgan ${t.origin ?? "qiymat"} ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Juda kichik: kutilgan ${t.origin} ${n}${t.minimum.toString()} ${a.unit} ${a.verb}` : `Juda kichik: kutilgan ${t.origin} ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Noto\u2018g\u2018ri satr: "${n.prefix}" bilan boshlanishi kerak` : n.format === "ends_with" ? `Noto\u2018g\u2018ri satr: "${n.suffix}" bilan tugashi kerak` : n.format === "includes" ? `Noto\u2018g\u2018ri satr: "${n.includes}" ni o\u2018z ichiga olishi kerak` : n.format === "regex" ? `Noto\u2018g\u2018ri satr: ${n.pattern} shabloniga mos kelishi kerak` : `Noto\u2018g\u2018ri ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Noto\u2018g\u2018ri raqam: ${t.divisor} ning karralisi bo\u2018lishi kerak`;
      case "unrecognized_keys":
        return `Noma\u2019lum kalit${t.keys.length > 1 ? "lar" : ""}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `${t.origin} dagi kalit noto\u2018g\u2018ri`;
      case "invalid_union":
        return "Noto\u2018g\u2018ri kirish";
      case "invalid_element":
        return `${t.origin} da noto\u2018g\u2018ri qiymat`;
      default:
        return "Noto\u2018g\u2018ri kirish";
    }
  };
}, "error");
function du() {
  return {
    localeError: M$()
  };
}
s(du, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/vi.js
var B$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "k\xFD t\u1EF1", verb: "c\xF3" },
    file: { unit: "byte", verb: "c\xF3" },
    array: { unit: "ph\u1EA7n t\u1EED", verb: "c\xF3" },
    set: { unit: "ph\u1EA7n t\u1EED", verb: "c\xF3" },
    map: { unit: "ph\u1EA7n t\u1EED", verb: "c\xF3" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u0111\u1EA7u v\xE0o",
    email: "\u0111\u1ECBa ch\u1EC9 email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ng\xE0y gi\u1EDD ISO",
    date: "ng\xE0y ISO",
    time: "gi\u1EDD ISO",
    duration: "kho\u1EA3ng th\u1EDDi gian ISO",
    ipv4: "\u0111\u1ECBa ch\u1EC9 IPv4",
    ipv6: "\u0111\u1ECBa ch\u1EC9 IPv6",
    mac: "\u0111\u1ECBa ch\u1EC9 MAC",
    cidrv4: "d\u1EA3i IPv4",
    cidrv6: "d\u1EA3i IPv6",
    base64: "chu\u1ED7i m\xE3 h\xF3a base64",
    base64url: "chu\u1ED7i m\xE3 h\xF3a base64url",
    json_string: "chu\u1ED7i JSON",
    e164: "s\u1ED1 E.164",
    credit_card: "s\u1ED1 th\u1EBB t\xEDn d\u1EE5ng",
    jwt: "JWT",
    template_literal: "\u0111\u1EA7u v\xE0o"
  }, o = {
    nan: "NaN",
    number: "s\u1ED1",
    array: "m\u1EA3ng"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7: mong \u0111\u1EE3i instanceof ${t.expected}, nh\u1EADn \u0111\u01B0\u1EE3c ${c}` : `\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7: mong \u0111\u1EE3i ${n}, nh\u1EADn \u0111\u01B0\u1EE3c ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7: mong \u0111\u1EE3i ${x(t.values[0])}` : `T\xF9y ch\u1ECDn kh\xF4ng h\u1EE3p l\u1EC7: mong \u0111\u1EE3i m\u1ED9t trong c\xE1c gi\xE1 tr\u1ECB ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Qu\xE1 l\u1EDBn: mong \u0111\u1EE3i ${t.origin ?? "gi\xE1 tr\u1ECB"} ${a.verb} ${n}${t.maximum.toString()} ${a.unit ?? "ph\u1EA7n t\u1EED"}` : `Qu\xE1 l\u1EDBn: mong \u0111\u1EE3i ${t.origin ?? "gi\xE1 tr\u1ECB"} ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Qu\xE1 nh\u1ECF: mong \u0111\u1EE3i ${t.origin} ${a.verb} ${n}${t.minimum.toString()} ${a.unit}` : `Qu\xE1 nh\u1ECF: mong \u0111\u1EE3i ${t.origin} ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Chu\u1ED7i kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i b\u1EAFt \u0111\u1EA7u b\u1EB1ng "${n.prefix}"` : n.format === "ends_with" ? `Chu\u1ED7i kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i k\u1EBFt th\xFAc b\u1EB1ng "${n.suffix}"` : n.format === "includes" ? `Chu\u1ED7i kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i bao g\u1ED3m "${n.includes}"` : n.format === "regex" ? `Chu\u1ED7i kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i kh\u1EDBp v\u1EDBi m\u1EABu ${n.pattern}` : `${i[n.format] ?? t.format} kh\xF4ng h\u1EE3p l\u1EC7`;
      }
      case "not_multiple_of":
        return `S\u1ED1 kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i l\xE0 b\u1ED9i s\u1ED1 c\u1EE7a ${t.divisor}`;
      case "unrecognized_keys":
        return `Kh\xF3a kh\xF4ng \u0111\u01B0\u1EE3c nh\u1EADn d\u1EA1ng: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `Kh\xF3a kh\xF4ng h\u1EE3p l\u1EC7 trong ${t.origin}`;
      case "invalid_union":
        return "\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7";
      case "invalid_element":
        return `Gi\xE1 tr\u1ECB kh\xF4ng h\u1EE3p l\u1EC7 trong ${t.origin}`;
      default:
        return "\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7";
    }
  };
}, "error");
function fu() {
  return {
    localeError: B$()
  };
}
s(fu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/zh-CN.js
var J$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u5B57\u7B26", verb: "\u5305\u542B" },
    file: { unit: "\u5B57\u8282", verb: "\u5305\u542B" },
    array: { unit: "\u9879", verb: "\u5305\u542B" },
    set: { unit: "\u9879", verb: "\u5305\u542B" },
    map: { unit: "\u9879", verb: "\u5305\u542B" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u8F93\u5165",
    email: "\u7535\u5B50\u90AE\u4EF6",
    url: "URL",
    emoji: "\u8868\u60C5\u7B26\u53F7",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO\u65E5\u671F\u65F6\u95F4",
    date: "ISO\u65E5\u671F",
    time: "ISO\u65F6\u95F4",
    duration: "ISO\u65F6\u957F",
    ipv4: "IPv4\u5730\u5740",
    ipv6: "IPv6\u5730\u5740",
    mac: "MAC\u5730\u5740",
    cidrv4: "IPv4\u7F51\u6BB5",
    cidrv6: "IPv6\u7F51\u6BB5",
    base64: "base64\u7F16\u7801\u5B57\u7B26\u4E32",
    base64url: "base64url\u7F16\u7801\u5B57\u7B26\u4E32",
    json_string: "JSON\u5B57\u7B26\u4E32",
    e164: "E.164\u53F7\u7801",
    credit_card: "\u4FE1\u7528\u5361\u53F7",
    jwt: "JWT",
    template_literal: "\u8F93\u5165"
  }, o = {
    nan: "NaN",
    number: "\u6570\u5B57",
    array: "\u6570\u7EC4",
    null: "\u7A7A\u503C(null)"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u65E0\u6548\u8F93\u5165\uFF1A\u671F\u671B instanceof ${t.expected}\uFF0C\u5B9E\u9645\u63A5\u6536 ${c}` : `\u65E0\u6548\u8F93\u5165\uFF1A\u671F\u671B ${n}\uFF0C\u5B9E\u9645\u63A5\u6536 ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u65E0\u6548\u8F93\u5165\uFF1A\u671F\u671B ${x(t.values[0])}` : `\u65E0\u6548\u9009\u9879\uFF1A\u671F\u671B\u4EE5\u4E0B\u4E4B\u4E00 ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u6570\u503C\u8FC7\u5927\uFF1A\u671F\u671B ${t.origin ?? "\u503C"} ${n}${t.maximum.toString()} ${a.unit ?? "\u4E2A\u5143\u7D20"}` : `\u6570\u503C\u8FC7\u5927\uFF1A\u671F\u671B ${t.origin ?? "\u503C"} ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u6570\u503C\u8FC7\u5C0F\uFF1A\u671F\u671B ${t.origin} ${n}${t.minimum.toString()} ${a.unit}` : `\u6570\u503C\u8FC7\u5C0F\uFF1A\u671F\u671B ${t.origin} ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u65E0\u6548\u5B57\u7B26\u4E32\uFF1A\u5FC5\u987B\u4EE5 "${n.prefix}" \u5F00\u5934` : n.format === "ends_with" ? `\u65E0\u6548\u5B57\u7B26\u4E32\uFF1A\u5FC5\u987B\u4EE5 "${n.suffix}" \u7ED3\u5C3E` : n.format === "includes" ? `\u65E0\u6548\u5B57\u7B26\u4E32\uFF1A\u5FC5\u987B\u5305\u542B "${n.includes}"` : n.format === "regex" ? `\u65E0\u6548\u5B57\u7B26\u4E32\uFF1A\u5FC5\u987B\u6EE1\u8DB3\u6B63\u5219\u8868\u8FBE\u5F0F ${n.pattern}` : `\u65E0\u6548${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u65E0\u6548\u6570\u5B57\uFF1A\u5FC5\u987B\u662F ${t.divisor} \u7684\u500D\u6570`;
      case "unrecognized_keys":
        return `\u51FA\u73B0\u672A\u77E5\u7684\u952E(key): ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `${t.origin} \u4E2D\u7684\u952E(key)\u65E0\u6548`;
      case "invalid_union":
        return "\u65E0\u6548\u8F93\u5165";
      case "invalid_element":
        return `${t.origin} \u4E2D\u5305\u542B\u65E0\u6548\u503C(value)`;
      default:
        return "\u65E0\u6548\u8F93\u5165";
    }
  };
}, "error");
function pu() {
  return {
    localeError: J$()
  };
}
s(pu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/zh-TW.js
var q$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u5B57\u5143", verb: "\u64C1\u6709" },
    file: { unit: "\u4F4D\u5143\u7D44", verb: "\u64C1\u6709" },
    array: { unit: "\u9805\u76EE", verb: "\u64C1\u6709" },
    set: { unit: "\u9805\u76EE", verb: "\u64C1\u6709" },
    map: { unit: "\u9805\u76EE", verb: "\u64C1\u6709" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u8F38\u5165",
    email: "\u90F5\u4EF6\u5730\u5740",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u65E5\u671F\u6642\u9593",
    date: "ISO \u65E5\u671F",
    time: "ISO \u6642\u9593",
    duration: "ISO \u671F\u9593",
    ipv4: "IPv4 \u4F4D\u5740",
    ipv6: "IPv6 \u4F4D\u5740",
    mac: "MAC \u4F4D\u5740",
    cidrv4: "IPv4 \u7BC4\u570D",
    cidrv6: "IPv6 \u7BC4\u570D",
    base64: "base64 \u7DE8\u78BC\u5B57\u4E32",
    base64url: "base64url \u7DE8\u78BC\u5B57\u4E32",
    json_string: "JSON \u5B57\u4E32",
    e164: "E.164 \u6578\u503C",
    credit_card: "\u4FE1\u7528\u5361\u865F",
    jwt: "JWT",
    template_literal: "\u8F38\u5165"
  }, o = {
    nan: "NaN"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u7121\u6548\u7684\u8F38\u5165\u503C\uFF1A\u9810\u671F\u70BA instanceof ${t.expected}\uFF0C\u4F46\u6536\u5230 ${c}` : `\u7121\u6548\u7684\u8F38\u5165\u503C\uFF1A\u9810\u671F\u70BA ${n}\uFF0C\u4F46\u6536\u5230 ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u7121\u6548\u7684\u8F38\u5165\u503C\uFF1A\u9810\u671F\u70BA ${x(t.values[0])}` : `\u7121\u6548\u7684\u9078\u9805\uFF1A\u9810\u671F\u70BA\u4EE5\u4E0B\u5176\u4E2D\u4E4B\u4E00 ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u6578\u503C\u904E\u5927\uFF1A\u9810\u671F ${t.origin ?? "\u503C"} \u61C9\u70BA ${n}${t.maximum.toString()} ${a.unit ?? "\u500B\u5143\u7D20"}` : `\u6578\u503C\u904E\u5927\uFF1A\u9810\u671F ${t.origin ?? "\u503C"} \u61C9\u70BA ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u6578\u503C\u904E\u5C0F\uFF1A\u9810\u671F ${t.origin} \u61C9\u70BA ${n}${t.minimum.toString()} ${a.unit}` : `\u6578\u503C\u904E\u5C0F\uFF1A\u9810\u671F ${t.origin} \u61C9\u70BA ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u7121\u6548\u7684\u5B57\u4E32\uFF1A\u5FC5\u9808\u4EE5 "${n.prefix}" \u958B\u982D` : n.format === "ends_with" ? `\u7121\u6548\u7684\u5B57\u4E32\uFF1A\u5FC5\u9808\u4EE5 "${n.suffix}" \u7D50\u5C3E` : n.format === "includes" ? `\u7121\u6548\u7684\u5B57\u4E32\uFF1A\u5FC5\u9808\u5305\u542B "${n.includes}"` : n.format === "regex" ? `\u7121\u6548\u7684\u5B57\u4E32\uFF1A\u5FC5\u9808\u7B26\u5408\u683C\u5F0F ${n.pattern}` : `\u7121\u6548\u7684 ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u7121\u6548\u7684\u6578\u5B57\uFF1A\u5FC5\u9808\u70BA ${t.divisor} \u7684\u500D\u6578`;
      case "unrecognized_keys":
        return `\u7121\u6CD5\u8B58\u5225\u7684\u9375\u503C${t.keys.length > 1 ? "\u5011" : ""}\uFF1A${g(t.keys, "\u3001")}`;
      case "invalid_key":
        return `${t.origin} \u4E2D\u6709\u7121\u6548\u7684\u9375\u503C`;
      case "invalid_union":
        return "\u7121\u6548\u7684\u8F38\u5165\u503C";
      case "invalid_element":
        return `${t.origin} \u4E2D\u6709\u7121\u6548\u7684\u503C`;
      default:
        return "\u7121\u6548\u7684\u8F38\u5165\u503C";
    }
  };
}, "error");
function mu() {
  return {
    localeError: q$()
  };
}
s(mu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/yo.js
var K$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\xE0mi", verb: "n\xED" },
    file: { unit: "bytes", verb: "n\xED" },
    array: { unit: "nkan", verb: "n\xED" },
    set: { unit: "nkan", verb: "n\xED" },
    map: { unit: "nkan", verb: "n\xED" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u1EB9\u0300r\u1ECD \xECb\xE1w\u1ECDl\xE9",
    email: "\xE0d\xEDr\u1EB9\u0301s\xEC \xECm\u1EB9\u0301l\xEC",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\xE0k\xF3k\xF2 ISO",
    date: "\u1ECDj\u1ECD\u0301 ISO",
    time: "\xE0k\xF3k\xF2 ISO",
    duration: "\xE0k\xF3k\xF2 t\xF3 p\xE9 ISO",
    ipv4: "\xE0d\xEDr\u1EB9\u0301s\xEC IPv4",
    ipv6: "\xE0d\xEDr\u1EB9\u0301s\xEC IPv6",
    mac: "\xE0d\xEDr\u1EB9\u0301s\xEC MAC",
    cidrv4: "\xE0gb\xE8gb\xE8 IPv4",
    cidrv6: "\xE0gb\xE8gb\xE8 IPv6",
    base64: "\u1ECD\u0300r\u1ECD\u0300 t\xED a k\u1ECD\u0301 n\xED base64",
    base64url: "\u1ECD\u0300r\u1ECD\u0300 base64url",
    json_string: "\u1ECD\u0300r\u1ECD\u0300 JSON",
    e164: "n\u1ECD\u0301mb\xE0 E.164",
    credit_card: "n\u1ECDmba kaadi gbese",
    jwt: "JWT",
    template_literal: "\u1EB9\u0300r\u1ECD \xECb\xE1w\u1ECDl\xE9"
  }, o = {
    nan: "NaN",
    number: "n\u1ECD\u0301mb\xE0",
    array: "akop\u1ECD"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = w(t.input), c = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e: a n\xED l\xE1ti fi instanceof ${t.expected}, \xE0m\u1ECD\u0300 a r\xED ${c}` : `\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e: a n\xED l\xE1ti fi ${n}, \xE0m\u1ECD\u0300 a r\xED ${c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e: a n\xED l\xE1ti fi ${x(t.values[0])}` : `\xC0\u1E63\xE0y\xE0n a\u1E63\xEC\u1E63e: yan \u1ECD\u0300kan l\xE1ra ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `T\xF3 p\u1ECD\u0300 j\xF9: a n\xED l\xE1ti j\u1EB9\u0301 p\xE9 ${t.origin ?? "iye"} ${a.verb} ${n}${t.maximum} ${a.unit}` : `T\xF3 p\u1ECD\u0300 j\xF9: a n\xED l\xE1ti j\u1EB9\u0301 ${n}${t.maximum}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `K\xE9r\xE9 ju: a n\xED l\xE1ti j\u1EB9\u0301 p\xE9 ${t.origin} ${a.verb} ${n}${t.minimum} ${a.unit}` : `K\xE9r\xE9 ju: a n\xED l\xE1ti j\u1EB9\u0301 ${n}${t.minimum}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u1ECC\u0300r\u1ECD\u0300 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 b\u1EB9\u0300r\u1EB9\u0300 p\u1EB9\u0300l\xFA "${n.prefix}"` : n.format === "ends_with" ? `\u1ECC\u0300r\u1ECD\u0300 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 par\xED p\u1EB9\u0300l\xFA "${n.suffix}"` : n.format === "includes" ? `\u1ECC\u0300r\u1ECD\u0300 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 n\xED "${n.includes}"` : n.format === "regex" ? `\u1ECC\u0300r\u1ECD\u0300 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 b\xE1 \xE0p\u1EB9\u1EB9r\u1EB9 mu ${n.pattern}` : `A\u1E63\xEC\u1E63e: ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `N\u1ECD\u0301mb\xE0 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 j\u1EB9\u0301 \xE8y\xE0 p\xEDp\xEDn ti ${t.divisor}`;
      case "unrecognized_keys":
        return `B\u1ECDt\xECn\xEC \xE0\xECm\u1ECD\u0300: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `B\u1ECDt\xECn\xEC a\u1E63\xEC\u1E63e n\xEDn\xFA ${t.origin}`;
      case "invalid_union":
        return "\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e";
      case "invalid_element":
        return `Iye a\u1E63\xEC\u1E63e n\xEDn\xFA ${t.origin}`;
      default:
        return "\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e";
    }
  };
}, "error");
function hu() {
  return {
    localeError: K$()
  };
}
s(hu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/registries.js
var lp, gu = /* @__PURE__ */ Symbol("ZodOutput"), vu = /* @__PURE__ */ Symbol("ZodInput"), di = class {
  static {
    s(this, "$ZodRegistry");
  }
  constructor() {
    this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map();
  }
  add(r, ...i) {
    let o = i[0];
    return this._map.set(r, o), o && typeof o == "object" && "id" in o && this._idmap.set(o.id, r), this;
  }
  clear() {
    return this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map(), this;
  }
  remove(r) {
    let i = this._map.get(r);
    return i && typeof i == "object" && "id" in i && this._idmap.delete(i.id), this._map.delete(r), this;
  }
  get(r) {
    let i = r._zod.parent;
    if (i) {
      let o = { ...this.get(i) ?? {} };
      delete o.id;
      let t = { ...o, ...this._map.get(r) };
      return Object.keys(t).length ? t : void 0;
    }
    return this._map.get(r);
  }
  has(r) {
    return this._map.has(r);
  }
};
function fi() {
  return new di();
}
s(fi, "registry");
(lp = globalThis).__zod_globalRegistry ?? (lp.__zod_globalRegistry = fi());
var Y = globalThis.__zod_globalRegistry;

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/compile.js
var fe = Symbol.for("zod.compile.invalid"), dp = Symbol.for("zod.compile.fallback"), _e = class extends Error {
  static {
    s(this, "ZodCompileAsyncError");
  }
  constructor(r = "z.compile does not support async refinements, transforms, or checks") {
    super(r), this.name = "ZodCompileAsyncError";
  }
}, C = class extends Error {
  static {
    s(this, "ZodCompileUnsupportedError");
  }
  constructor(r, i = !0) {
    super(`z.compile does not support ${r}; this schema must use the runtime parser`), this.name = "ZodCompileUnsupportedError", this.islandable = i;
  }
};
function G$(e, r) {
  try {
    return pi(e, { assertOnly: !0 });
  } catch {
    return r;
  }
}
s(G$, "compileValidator");
function _u(e, r) {
  try {
    let i = pi(e), o = Z(e), t = e._zod.run, n = t.__originalRun ?? t, a = /* @__PURE__ */ s((c, u) => {
      if (u?.async || u?.direction === "backward" || u?.skipChecks || u?.[dp] || u && li(u, c.value))
        return n(c, u);
      let l = i(c.value);
      return l !== fe ? (c.value = l, c) : (u && (u[dp] = !0), n(c, u));
    }, "wrapped");
    return a.__originalRun = n, o._zod.bag.fallbackRun = n, o._zod.bag.validator = G$(e, i), o._zod.run = a, t.__originalRun || X$(o, e, i), o;
  } catch (i) {
    if (r?.strict)
      throw i;
    return e;
  }
}
s(_u, "compile");
function X$(e, r, i) {
  let o = e, t = r;
  if (typeof t.safeParse == "function") {
    let n = t.safeParse;
    o.safeParse = (a, c) => {
      let u = i(a);
      return u !== fe ? { success: !0, data: u } : n(a, c);
    };
  }
  if (typeof t.parse == "function") {
    let n = t.parse;
    o.parse = (a, c) => {
      let u = i(a);
      return u !== fe ? u : n(a, c);
    };
  }
}
s(X$, "installCompiledUserMethods");
function pi(e, r) {
  let i = !0;
  try {
    i = lc(e);
  } catch {
  }
  if (i)
    throw new C("a schema whose subtree contains a reference cycle");
  let o = {
    constants: /* @__PURE__ */ new Map(),
    constantCounter: 0,
    varCounter: 0
  }, t = new nt(["input"]), n = W(t, o, e, "input", !r?.assertOnly);
  t.write(n === null ? "return true;" : `return ${n};`);
  let a = ["INVALID", ...o.constants.keys()], c = [fe, ...o.constants.values()], u = t.content.join(`
`), l = r?.debug ? a.length > 0 ? `// Constants: ${a.join(", ")}
${u}` : u : "", f = Function, m = `return (input) => {
${u}
}`, v;
  try {
    v = new f(...a, m)(...c);
  } catch (y) {
    throw new C(`this schema (generated code failed to evaluate: ${y.message})`);
  }
  return r?.debug && (v.code = l), v;
}
s(pi, "compileFn");
function D(e, r) {
  for (let [o, t] of e.constants)
    if (t === r)
      return o;
  let i = `c${e.constantCounter++}`;
  return e.constants.set(i, r), i;
}
s(D, "addConstant");
function N(e) {
  return `v${e.varCounter++}`;
}
s(N, "newVar");
function H$(e, r) {
  let i = e._zod.run({ value: r, issues: [] }, {});
  if (i && typeof i.then == "function")
    return fe;
  let o = i;
  return o.issues.length === 0 ? o.value : fe;
}
s(H$, "runtimeRun");
function ne(e, r, i, o, t = !0) {
  let n = e.content.length, a = r.constants.size, c = r.constantCounter, u = r.varCounter;
  try {
    return W(e, r, i, o, t);
  } catch (l) {
    if (!(l instanceof C) || !l.islandable)
      throw l;
    if (e.content.length = n, r.constants.size > a) {
      let f = Array.from(r.constants.keys()).slice(a);
      for (let m of f)
        r.constants.delete(m);
    }
    return r.constantCounter = c, r.varCounter = u, Q$(e, r, i, o);
  }
}
s(ne, "compileChild");
function Q$(e, r, i, o) {
  let t = D(r, i), n = D(r, H$), a = N(r);
  return e.write(`const ${a} = ${n}(${t}, ${o});`), e.write(`if (${a} === INVALID) return INVALID;`), a;
}
s(Q$, "emitRuntimeIsland");
var Y$ = /* @__PURE__ */ new Set([
  "max_size",
  "min_size",
  "size_equals",
  "max_length",
  "min_length",
  "length_equals"
]);
function e_(e, r, i, o) {
  let t = i._zod.def.checks;
  if (!t || t.length === 0)
    return o;
  let n = o;
  for (let a of t) {
    let c = a._zod.def;
    if (c.when && !Y$.has(c.check))
      throw new C('check with a custom "when" condition');
    switch (c.check) {
      case "greater_than":
        t_(e, r, c, n);
        break;
      case "less_than":
        r_(e, r, c, n);
        break;
      case "multiple_of":
        n_(e, r, c, n);
        break;
      case "number_format":
        hp(e, c, n);
        break;
      case "min_length": {
        let u = st(c.minimum, "min_length"), l = yu(e, r, n, `${n}.length >= ${u} && ${n}.length < ${c.minimum * 2}`);
        e.write(`if (${l} < ${u}) return INVALID;`);
        break;
      }
      case "max_length": {
        let u = st(c.maximum, "max_length"), l = yu(e, r, n, `${n}.length > ${u}`);
        e.write(`if (${l} > ${u}) return INVALID;`);
        break;
      }
      case "length_equals": {
        let u = st(c.length, "length_equals"), l = yu(e, r, n, `${n}.length >= ${u} && ${n}.length <= ${c.length * 2}`);
        e.write(`if (${l} !== ${u}) return INVALID;`);
        break;
      }
      case "min_size":
        e.write(`if (${n}.size < ${st(c.minimum, "min_size")}) return INVALID;`);
        break;
      case "max_size":
        e.write(`if (${n}.size > ${st(c.maximum, "max_size")}) return INVALID;`);
        break;
      case "size_equals":
        e.write(`if (${n}.size !== ${st(c.size, "size_equals")}) return INVALID;`);
        break;
      case "string_format":
        n = gp(e, r, c, n);
        break;
      case "custom":
        n = c_(e, r, a, n);
        break;
      case "bigint_format":
        i_(e, c, n);
        break;
      case "mime_type":
        o_(e, r, c, n);
        break;
      case "property":
        a_(e, r, c, n);
        break;
      case "overwrite": {
        let u = N(r);
        s_(e, r, a, n, u), n = u;
        break;
      }
      default:
        throw new C(`check type ${c.check}`);
    }
  }
  return n;
}
s(e_, "generateChecks");
function yu(e, r, i, o) {
  let t = D(r, Ye), n = N(r);
  return e.write(`const ${n} = typeof ${i} === "string" && ${o} ? ${t}(${i}) : ${i}.length;`), n;
}
s(yu, "codePointLengthVar");
function st(e, r) {
  if (typeof e != "number" || !Number.isFinite(e))
    throw new C(`${r} bound of type ${typeof e}`);
  return `${e}`;
}
s(st, "numericOperand");
function mp(e, r) {
  if (typeof r == "bigint")
    return `${r}n`;
  if (typeof r == "number") {
    if (Number.isNaN(r))
      throw new C("comparison check with NaN bound");
    return `${r}`;
  }
  if (r instanceof Date) {
    if (Number.isNaN(r.getTime()))
      throw new C("comparison check with Invalid Date bound");
    return D(e, r);
  }
  throw new C(`comparison check bound of type ${typeof r}`);
}
s(mp, "comparisonOperand");
function t_(e, r, i, o) {
  let t = i.inclusive ? "<" : "<=";
  e.write(`if (${o} ${t} ${mp(r, i.value)}) return INVALID;`);
}
s(t_, "generateGreaterThanCheck");
function r_(e, r, i, o) {
  let t = i.inclusive ? ">" : ">=";
  e.write(`if (${o} ${t} ${mp(r, i.value)}) return INVALID;`);
}
s(r_, "generateLessThanCheck");
function n_(e, r, i, o) {
  if (typeof i.value == "bigint") {
    if (i.value === BigInt(0))
      throw new C("multiple_of check with a zero divisor");
    e.write(`if (${o} % ${i.value}n !== 0n) return INVALID;`);
  } else {
    let t = D(r, hr);
    e.write(`if (${t}(${o}, ${st(i.value, "multiple_of")}) !== 0) return INVALID;`);
  }
}
s(n_, "generateMultipleOfCheck");
function hp(e, r, i) {
  let o = r.format;
  switch (o) {
    case "safeint":
      e.write(`if (!Number.isSafeInteger(${i})) return INVALID;`);
      break;
    case "int32":
      e.write(`if (!Number.isInteger(${i}) || ${i} < -2147483648 || ${i} > 2147483647) return INVALID;`);
      break;
    case "uint32":
      e.write(`if (!Number.isInteger(${i}) || ${i} < 0 || ${i} > 4294967295) return INVALID;`);
      break;
    case "float32":
      e.write(`if (!Number.isFinite(${i}) || ${i} < -3.4028234663852886e38 || ${i} > 3.4028234663852886e38) return INVALID;`);
      break;
    case "float64":
      e.write(`if (!Number.isFinite(${i})) return INVALID;`);
      break;
    default:
      throw new C(`number format ${o}`);
  }
}
s(hp, "generateNumberFormatCheck");
function i_(e, r, i) {
  let o = r.format;
  if (o)
    switch (o) {
      case "int64":
        e.write(`if (${i} < -9223372036854775808n || ${i} > 9223372036854775807n) return INVALID;`);
        break;
      case "uint64":
        e.write(`if (${i} < 0n || ${i} > 18446744073709551615n) return INVALID;`);
        break;
      default:
        throw new C(`bigint format ${o}`);
    }
}
s(i_, "generateBigIntFormatCheck");
function o_(e, r, i, o) {
  let t = i.mime;
  if (t && t.length > 0) {
    let n = D(r, new Set(t));
    e.write(`if (!${n}.has(${o}.type)) return INVALID;`);
  }
}
s(o_, "generateMimeTypeCheck");
function a_(e, r, i, o) {
  let t = `${o}[${JSON.stringify(i.property)}]`;
  W(e, r, i.schema, t);
}
s(a_, "generatePropertyCheck");
function s_(e, r, i, o, t) {
  let n = i._zod.def.tx;
  if (!n)
    throw new C("overwrite check without a transform function");
  if (lt(n))
    throw new _e("z.compile: async overwrite transforms are not supported");
  let a = D(r, n);
  e.write(`const ${t} = ${a}(${o});`);
}
s(s_, "generateOverwriteCheck");
function bu() {
  throw new ce();
}
s(bu, "throwAsync");
function xu(e) {
  this.issues.push(e);
}
s(xu, "pushIssue");
function c_(e, r, i, o) {
  let t = i._zod.def;
  if (t.fn) {
    if (lt(t.fn))
      throw new _e("z.compile: async .refine() predicates are not supported");
    let n = D(r, t.fn), a = D(r, bu), c = N(r);
    return e.write(`const ${c} = ${n}(${o});`), e.write(`if (${c} instanceof Promise) ${a}();`), e.write(`if (!${c}) return INVALID;`), o;
  }
  if (i._zod.check) {
    if (lt(i._zod.check))
      throw new _e("z.compile: async .superRefine() / check functions are not supported");
    let n = i._zod.check, c = D(r, /* @__PURE__ */ s((l) => {
      let f = { value: l, issues: [], addIssue: xu };
      return n(f) instanceof Promise && bu(), f.issues.length === 0 ? f.value : fe;
    }, "helperFn")), u = N(r);
    return e.write(`const ${u} = ${c}(${o});`), e.write(`if (${u} === INVALID) return INVALID;`), u;
  }
  throw new C("custom check without a predicate or check function");
}
s(c_, "generateCustomRefineCheck");
var u_ = /* @__PURE__ */ new Set([
  "cidrv4",
  "cuid",
  "cuid2",
  "date",
  "datetime",
  "duration",
  "e164",
  "email",
  "emoji",
  "ends_with",
  "guid",
  "includes",
  "ipv4",
  "ksuid",
  "lowercase",
  "mac",
  "nanoid",
  "regex",
  "starts_with",
  "time",
  "ulid",
  "uppercase",
  "uuid",
  "xid"
]);
function gp(e, r, i, o) {
  let t = i.format;
  if (t === "base64") {
    let u = D(r, Sr);
    return e.write(`if (!${u}(${o})) return INVALID;`), o;
  }
  if (t === "base64url") {
    let u = D(r, ei);
    return e.write(`if (!${u}(${o})) return INVALID;`), o;
  }
  if (t === "jwt") {
    let u = D(r, ri), l = D(r, i.alg ?? null);
    return e.write(`if (!${u}(${o}, ${l})) return INVALID;`), o;
  }
  if (t === "ipv6") {
    let u = D(r, zr);
    return e.write(`if (!${u}(${o})) return INVALID;`), o;
  }
  if (t === "cidrv6") {
    let u = D(r, Yn);
    return e.write(`if (!${u}(${o})) return INVALID;`), o;
  }
  if (t === "credit_card") {
    let u = D(r, ti);
    return e.write(`if (!${u}(${o})) return INVALID;`), o;
  }
  let n = i;
  if (t === "url" || t === "httpurl" || n.normalize || n.hostname !== void 0 || n.protocol !== void 0) {
    let u = D(r, Gn), l = D(r, i), f = N(r), m = N(r);
    if (e.write(`const ${f} = ${o}.trim();`), e.write(`const ${m} = ${u}(${f}, ${l});`), e.write(`if (typeof ${m} === "number") return INVALID;`), n.hostname !== void 0) {
      let b = D(r, Hn);
      e.write(`if (!${b}(${m}, ${l}.hostname)) return INVALID;`);
    }
    if (n.protocol !== void 0) {
      let b = D(r, Qn);
      e.write(`if (!${b}(${m}, ${l}.protocol)) return INVALID;`);
    }
    let v = N(r), y = n.normalize ? `${m}.href` : `${D(r, Xn)}(${f})`;
    return e.write(`const ${v} = ${y};`), v;
  }
  let a = i.fn;
  if (a) {
    if (lt(a))
      throw new C(`async string format ${t}`);
    let u = D(r, a);
    return e.write(`if (!${u}(${o})) return INVALID;`), o;
  }
  if (u_.has(t) && i.pattern) {
    let u = D(r, i.pattern);
    return e.write(`${u}.lastIndex = 0;`), e.write(`if (!${u}.test(${o})) return INVALID;`), o;
  }
  let c = i.format;
  switch (c) {
    case "regex":
      throw new C("regex format without a pattern");
    case "lowercase":
      e.write(`if (${o} !== ${o}.toLowerCase()) return INVALID;`);
      break;
    case "uppercase":
      e.write(`if (${o} !== ${o}.toUpperCase()) return INVALID;`);
      break;
    case "includes":
      e.write(`if (!${o}.includes(${oe(i.includes)})) return INVALID;`);
      break;
    case "starts_with": {
      let u = i.prefix;
      e.write(`if (${o}.slice(0, ${u.length}) !== ${oe(u)}) return INVALID;`);
      break;
    }
    case "ends_with": {
      let u = i.suffix;
      e.write(`if (${o}.slice(-${u.length}) !== ${oe(u)}) return INVALID;`);
      break;
    }
    default:
      throw new C(`string format ${c}`);
  }
  return o;
}
s(gp, "generateStringFormatCheck");
function W(e, r, i, o, t = !0) {
  let n = i._zod.def, a = n.type;
  if (n.coerce)
    throw new C(`coercion (z.coerce.${a}())`);
  let c = t || !!n.checks?.length, u;
  switch (a) {
    case "string":
      u = l_(e, r, i, o);
      break;
    case "number":
      u = d_(e, i, o);
      break;
    case "boolean":
      u = f_(e, o);
      break;
    case "bigint":
      u = p_(e, i, o);
      break;
    case "symbol":
      u = m_(e, o);
      break;
    case "undefined":
      u = h_(e, o);
      break;
    case "null":
      u = g_(e, o);
      break;
    case "any":
    case "unknown":
      u = o;
      break;
    case "never":
      e.write("return INVALID;"), u = o;
      break;
    case "void":
      u = v_(e, o);
      break;
    case "nan":
      u = y_(e, o);
      break;
    case "date":
      u = b_(e, o);
      break;
    case "object":
      u = $_(e, r, i, o, c);
      break;
    case "optional":
      u = __(e, r, i, o, c);
      break;
    case "nullable":
      u = k_(e, r, i, o, c);
      break;
    case "array":
      u = I_(e, r, i, o, c);
      break;
    case "literal":
      u = z_(e, r, i, o);
      break;
    case "enum":
      u = S_(e, r, i, o);
      break;
    case "readonly": {
      let l = fp(e, r, i, o), f = N(r);
      e.write(`const ${f} = Object.freeze(${l});`), u = f;
      break;
    }
    case "success":
      fp(e, r, i, o), u = "true";
      break;
    case "default":
    case "prefault":
      u = O_(e, r, i, o);
      break;
    case "nonoptional":
      u = j_(e, r, i, o);
      break;
    case "tuple":
      u = A_(e, r, i, o);
      break;
    case "union":
      u = P_(e, r, i, o);
      break;
    case "intersection":
      u = T_(e, r, i, o);
      break;
    case "record":
      u = U_(e, r, i, o);
      break;
    case "map":
      u = C_(e, r, i, o);
      break;
    case "set":
      u = Z_(e, r, i, o);
      break;
    case "file":
      u = R_(e, o);
      break;
    case "template_literal":
      u = F_(e, r, i, o);
      break;
    case "lazy":
      u = L_(e, r, i, o);
      break;
    case "pipe":
      u = V_(e, r, i, o);
      break;
    case "custom":
      u = M_(e, r, i, o);
      break;
    case "transform":
      u = q_(e, r, i, o);
      break;
    case "catch":
      u = J_(e, r, i, o);
      break;
    default:
      throw new C(`schema type ${a}`);
  }
  return u === null ? null : e_(e, r, i, u);
}
s(W, "generateCheck");
function l_(e, r, i, o) {
  e.write(`if (typeof ${o} !== "string") return INVALID;`);
  let t = i._zod.def;
  return t.format === void 0 ? o : gp(e, r, t, o);
}
s(l_, "generateStringCheck");
function d_(e, r, i) {
  e.write(`if (typeof ${i} !== "number" || !Number.isFinite(${i})) return INVALID;`);
  let o = r._zod.def;
  return o.check === "number_format" && o.format && hp(e, { format: o.format }, i), i;
}
s(d_, "generateNumberCheck");
function f_(e, r) {
  return e.write(`if (typeof ${r} !== "boolean") return INVALID;`), r;
}
s(f_, "generateBooleanCheck");
function p_(e, r, i) {
  e.write(`if (typeof ${i} !== "bigint") return INVALID;`);
  let o = r._zod.def;
  if (o.format)
    switch (o.format) {
      case "int64":
        e.write(`if (${i} < -9223372036854775808n || ${i} > 9223372036854775807n) return INVALID;`);
        break;
      case "uint64":
        e.write(`if (${i} < 0n || ${i} > 18446744073709551615n) return INVALID;`);
        break;
    }
  return i;
}
s(p_, "generateBigIntCheck");
function m_(e, r) {
  return e.write(`if (typeof ${r} !== "symbol") return INVALID;`), r;
}
s(m_, "generateSymbolCheck");
function h_(e, r) {
  return e.write(`if (${r} !== undefined) return INVALID;`), r;
}
s(h_, "generateUndefinedCheck");
function g_(e, r) {
  return e.write(`if (${r} !== null) return INVALID;`), r;
}
s(g_, "generateNullCheck");
function v_(e, r) {
  return e.write(`if (${r} !== undefined) return INVALID;`), r;
}
s(v_, "generateVoidCheck");
function y_(e, r) {
  return e.write(`if (typeof ${r} !== "number" || !Number.isNaN(${r})) return INVALID;`), r;
}
s(y_, "generateNaNCheck");
function b_(e, r) {
  return e.write(`if (!(${r} instanceof Date) || Number.isNaN(${r}.getTime())) return INVALID;`), r;
}
s(b_, "generateDateCheck");
function $_(e, r, i, o, t = !0) {
  let n = i._zod.def;
  e.write(`if (typeof ${o} !== "object" || ${o} === null || Array.isArray(${o})) return INVALID;`);
  let a = n.shape, c = Object.keys(a), u = Object.getOwnPropertySymbols(a), l = u.length ? [...c, ...u] : c, f = /* @__PURE__ */ s((A) => typeof A == "symbol" ? D(r, A) : oe(A), "keyExpr"), m = /* @__PURE__ */ s((A) => typeof A == "symbol" ? `[${f(A)}]` : oe(A), "propKey"), v = a;
  if (c.includes("__proto__"))
    throw new C('object shape key "__proto__"');
  let y = /* @__PURE__ */ new Map();
  for (let A of l) {
    let T = v[A], J = f(A), q = N(r);
    if (e.write(`const ${q} = ${o}[${J}];`), T._zod.optin !== void 0) {
      let R = N(r);
      e.write(`let ${R} = (() => {`), e.indented((ee) => {
        let sr = ne(ee, r, T, q);
        ee.write(`return ${sr};`);
      }), e.write("})();"), T._zod.optout === "optional" ? (e.write(`if (${R} === INVALID) {`), e.indented((ee) => {
        ee.write(`if (${J} in ${o}) return INVALID;`), ee.write(`${R} = undefined;`);
      }), e.write("}")) : e.write(`if (${R} === INVALID) return INVALID;`), y.set(A, R);
    } else {
      w_(T) && e.write(`if (!(${J} in ${o})) return INVALID;`);
      let R = ne(e, r, T, q, t);
      R !== null && y.set(A, R);
    }
  }
  let b = n.catchall, z = "none";
  if (b) {
    let A = b._zod.def.type;
    if (A === "never") {
      let T = c.map((J) => `k !== ${oe(J)}`).join(" && ") || "true";
      e.write(`for (const k in ${o}) {`), e.indented((J) => {
        J.write(`if (${T}) return INVALID;`);
      }), e.write("}");
    } else (A === "unknown" || A === "any") && !b._zod.def.checks?.length ? z = "passthrough" : z = "schema";
  }
  let O = N(r), L = l.some((A) => ut(v[A]) || $u(v[A]));
  if (!t) {
    if (z === "schema") {
      let A = c.length > 0 ? D(r, new Set(c)) : null;
      e.write(`for (const k in ${o}) {`), e.indented((T) => {
        T.write('if (k === "__proto__") continue;'), A && T.write(`if (${A}.has(k)) continue;`);
        let J = N(r);
        T.write(`const ${J} = ${o}[k];`), ne(T, r, b, J, !1);
      }), e.write("}");
    }
    return null;
  }
  if (L) {
    e.write(`const ${O} = {};`);
    for (let A of l) {
      let T = f(A), J = y.get(A);
      $u(v[A]) ? e.write(`if (${T} in ${o}) ${O}[${T}] = ${J};`) : ut(v[A]) ? e.write(`if (${J} !== undefined || ${T} in ${o}) ${O}[${T}] = ${J};`) : e.write(`${O}[${T}] = ${J};`);
    }
  } else {
    let A = l.map((T) => `${m(T)}: ${y.get(T)}`).join(", ");
    e.write(`const ${O} = { ${A} };`);
  }
  if (z !== "none") {
    let A = c.length > 0 ? D(r, new Set(c)) : null;
    e.write(`for (const k in ${o}) {`), e.indented((T) => {
      if (T.write('if (k === "__proto__") continue;'), A && T.write(`if (${A}.has(k)) continue;`), z === "passthrough")
        T.write(`${O}[k] = ${o}[k];`);
      else {
        let J = N(r);
        T.write(`const ${J} = ${o}[k];`);
        let q = ne(T, r, b, J);
        T.write(`${O}[k] = ${q};`);
      }
    }), e.write("}");
  }
  return O;
}
s($_, "generateObjectCheck");
function __(e, r, i, o, t = !0) {
  let n = i._zod.def;
  if (x_(i))
    return W(e, r, n.innerType, o, t);
  if (n.innerType._zod.optin === "defaulted") {
    let c = N(r), u = N(r);
    return e.write(`let ${c};`), e.write(`if (${o} === undefined) {`), e.indented((l) => {
      l.write(`const ${u} = (() => {`), l.indented((f) => {
        let m = W(f, r, n.innerType, o);
        f.write(`return ${m};`);
      }), l.write("})();"), l.write(`if (${u} !== INVALID) ${c} = ${u};`);
    }), e.write("} else {"), e.indented((l) => {
      let f = W(l, r, n.innerType, o);
      l.write(`${c} = ${f};`);
    }), e.write("}"), c;
  }
  let a = t ? N(r) : null;
  return a && e.write(`let ${a};`), e.write(`if (${o} !== undefined) {`), e.indented((c) => {
    let u = W(c, r, n.innerType, o, t);
    a && u !== null && c.write(`${a} = ${u};`);
  }), e.write("}"), a;
}
s(__, "generateOptionalCheck");
function x_(e) {
  return e._zod.traits?.has("$ZodExactOptional") === !0;
}
s(x_, "isExactOptional");
function w_(e) {
  return e._zod.optin === void 0 && ct(e);
}
s(w_, "requiresPresenceCheck");
function ct(e) {
  if (e._zod.def.coerce)
    return !0;
  let r = e._zod.def;
  switch (r.type) {
    case "any":
    case "unknown":
    case "undefined":
    case "void":
    case "default":
    case "prefault":
    case "transform":
    case "custom":
    case "lazy":
      return !0;
    case "string":
    case "number":
    case "boolean":
    case "bigint":
    case "symbol":
    case "null":
    case "never":
    case "nan":
    case "date":
    case "object":
    case "array":
    case "tuple":
    case "record":
    case "map":
    case "set":
    case "file":
    case "template_literal":
      return !1;
    case "nonoptional":
      return r.innerType ? ct(r.innerType) : !1;
    case "literal":
      return !!r.values?.includes(void 0);
    case "enum":
      return !!e._zod.values?.has(void 0);
    case "optional":
    case "nullable":
    case "readonly":
    case "success":
      return r.innerType ? ct(r.innerType) : !0;
    case "catch":
      return !0;
    case "union":
      return r.options ? r.options.some(ct) : !0;
    case "intersection":
      return !r.left || !r.right ? !0 : ct(r.left) && ct(r.right);
    case "pipe":
      return r.in ? ct(r.in) : !0;
    default:
      return !0;
  }
}
s(ct, "fastPathAcceptsAbsence");
function $u(e) {
  return e._zod.optin === "optional" && e._zod.optout === "optional";
}
s($u, "dropsWhenAbsent");
function ut(e) {
  let r = e._zod.def;
  switch (r.type) {
    case "string":
    case "number":
    case "boolean":
    case "bigint":
    case "symbol":
    case "null":
    case "nan":
    case "date":
    case "object":
    case "array":
    case "tuple":
    case "record":
    case "map":
    case "set":
    case "file":
    case "template_literal":
    case "never":
    case "success":
      return !1;
    case "literal":
      return !!r.values?.includes(void 0);
    case "enum":
      return !!e._zod.values?.has(void 0);
    case "optional":
      return !0;
    case "nullable":
    case "readonly":
    case "nonoptional":
      return r.innerType ? ut(r.innerType) : !0;
    case "union":
      return r.options ? r.options.some(ut) : !0;
    case "intersection":
      return !r.left || !r.right || ut(r.left) || ut(r.right);
    case "pipe":
      return r.out ? ut(r.out) : !0;
    default:
      return !0;
  }
}
s(ut, "mayOutputUndefined");
function k_(e, r, i, o, t = !0) {
  let n = i._zod.def, a = t ? N(r) : null;
  return a && e.write(`let ${a} = null;`), e.write(`if (${o} !== null) {`), e.indented((c) => {
    let u = W(c, r, n.innerType, o, t);
    a && u !== null && c.write(`${a} = ${u};`);
  }), e.write("}"), a;
}
s(k_, "generateNullableCheck");
function I_(e, r, i, o, t = !0) {
  let n = i._zod.def;
  e.write(`if (!Array.isArray(${o})) return INVALID;`);
  let a = t ? N(r) : null, c = N(r), u = N(r);
  return a && e.write(`const ${a} = new Array(${o}.length);`), e.write(`for (let ${c} = 0; ${c} < ${o}.length; ${c}++) {`), e.indented((l) => {
    l.write(`const ${u} = ${o}[${c}];`);
    let f = ne(l, r, n.element, u, t);
    a && f !== null && l.write(`${a}[${c}] = ${f};`);
  }), e.write("}"), a;
}
s(I_, "generateArrayCheck");
function z_(e, r, i, o) {
  let n = i._zod.def.values;
  if (n.length !== 1) {
    let c = D(r, new Set(n));
    return e.write(`if (!${c}.has(${o})) return INVALID;`), o;
  }
  let a = n[0];
  if (typeof a == "number" && Number.isNaN(a)) {
    let c = D(r, new Set(n));
    return e.write(`if (!${c}.has(${o})) return INVALID;`), o;
  }
  if (typeof a == "string")
    e.write(`if (${o} !== ${oe(a)}) return INVALID;`);
  else if (typeof a == "number" || typeof a == "boolean")
    e.write(`if (${o} !== ${a}) return INVALID;`);
  else if (a === null)
    e.write(`if (${o} !== null) return INVALID;`);
  else if (a === void 0)
    e.write(`if (${o} !== undefined) return INVALID;`);
  else if (typeof a == "bigint")
    e.write(`if (${o} !== ${a}n) return INVALID;`);
  else
    throw new C(`literal type ${typeof a}`);
  return o;
}
s(z_, "generateLiteralCheck");
function S_(e, r, i, o) {
  let t = i._zod.values;
  if (!t)
    throw new C("enum schema without enumerated values");
  let n = D(r, t);
  return e.write(`if (!${n}.has(${o})) return INVALID;`), o;
}
s(S_, "generateEnumCheck");
function fp(e, r, i, o) {
  let t = i._zod.def;
  return W(e, r, t.innerType, o);
}
s(fp, "generateWrapperCheck");
function O_(e, r, i, o) {
  let t = i._zod.def, a = Object.getOwnPropertyDescriptor(i._zod.def, "defaultValue") ? () => i._zod.def.defaultValue : void 0;
  if (i._zod.def.type === "prefault") {
    if (!a)
      return W(e, r, t.innerType, o);
    let u = D(r, a), l = N(r);
    return e.write(`let ${l} = ${o};`), e.write(`if (${o} === undefined) ${l} = ${u}();`), W(e, r, t.innerType, l);
  }
  let c = N(r);
  if (a) {
    let u = D(r, a), l = D(r, gr);
    e.write(`let ${c};`), e.write(`if (${o} === undefined) {`), e.indented((f) => {
      f.write(`${c} = ${l}(${u}());`);
    }), e.write("} else {"), e.indented((f) => {
      let m = W(f, r, t.innerType, o);
      f.write(`${c} = ${m} === undefined ? ${l}(${u}()) : ${m};`);
    }), e.write("}");
  } else
    e.write(`let ${c};`), e.write(`if (${o} !== undefined) {`), e.indented((u) => {
      let l = W(u, r, t.innerType, o);
      u.write(`${c} = ${l};`);
    }), e.write("}");
  return c;
}
s(O_, "generateDefaultCheck");
function j_(e, r, i, o) {
  let t = i._zod.def, n = W(e, r, t.innerType, o), a = N(r);
  return e.write(`const ${a} = ${n};`), e.write(`if (${a} === undefined) return INVALID;`), a;
}
s(j_, "generateNonOptionalCheck");
function A_(e, r, i, o) {
  let t = i._zod.def, n = t.items, a = t.rest;
  e.write(`if (!Array.isArray(${o})) return INVALID;`);
  let c = pp(n, "optin"), u = pp(n, "optout");
  a ? e.write(`if (${o}.length < ${c}) return INVALID;`) : e.write(`if (${o}.length < ${c} || ${o}.length > ${n.length}) return INVALID;`);
  let l = N(r);
  e.write(`const ${l} = [];`);
  for (let f = 0; f < n.length; f++) {
    let m = n[f];
    if (f >= u)
      e.write(`if (${l}.length === ${f}) {`), e.indented((v) => {
        v.write(`if (${f} < ${o}.length) {`), v.indented((y) => {
          let b = N(r);
          y.write(`const ${b} = ${o}[${f}];`);
          let z = ne(y, r, m, b);
          y.write(`${l}[${f}] = ${z};`);
        }), v.write("} else {"), v.indented((y) => {
          if ($u(m)) {
            y.write(`${l}.length = ${f};`);
            return;
          }
          let b = N(r), z = N(r);
          y.write(`const ${b} = undefined;`), y.write(`const ${z} = (() => {`), y.indented((O) => {
            let L = ne(O, r, m, b);
            O.write(`return ${L};`);
          }), y.write("})();"), y.write(`if (${z} === INVALID || ${z} === undefined) ${l}.length = ${f};`), y.write(`else ${l}[${f}] = ${z};`);
        }), v.write("}");
      }), e.write("}");
    else {
      let v = N(r);
      e.write(`const ${v} = ${o}[${f}];`);
      let y = ne(e, r, m, v);
      e.write(`${l}[${f}] = ${y};`);
    }
  }
  if (a) {
    let f = N(r), m = N(r);
    e.write(`for (let ${f} = ${n.length}; ${f} < ${o}.length; ${f}++) {`), e.indented((v) => {
      v.write(`const ${m} = ${o}[${f}];`);
      let y = ne(v, r, a, m);
      v.write(`${l}[${f}] = ${y};`);
    }), e.write("}");
  }
  return l;
}
s(A_, "generateTupleCheck");
function pp(e, r) {
  for (let i = e.length - 1; i >= 0; i--)
    if (!(r === "optin" ? e[i]._zod.optin !== void 0 : e[i]._zod.optout === "optional"))
      return i + 1;
  return 0;
}
s(pp, "getTupleOptStart");
function P_(e, r, i, o) {
  let t = i._zod.def, n = t.options;
  if (t.discriminator)
    return D_(e, r, t, o);
  if (t.inclusive === !1)
    throw new C("exclusive unions (z.xor)");
  if (n.length === 0)
    return e.write("return INVALID;"), o;
  if (n.length === 1)
    return W(e, r, n[0], o);
  if (n.every((u) => u._zod.def.type === "literal" && !u._zod.def.checks?.length)) {
    let u = new Set(n.flatMap((f) => f._zod.def.values)), l = D(r, u);
    return e.write(`if (!${l}.has(${o})) return INVALID;`), o;
  }
  let c = N(r);
  e.write(`let ${c};`);
  for (let u = 0; u < n.length; u++) {
    let l = n[u];
    u === 0 ? e.write(`${c} = (() => {`) : e.write(`if (${c} === INVALID) ${c} = (() => {`), e.indented((f) => {
      let m = W(f, r, l, o);
      f.write(`return ${m};`);
    }), e.write("})();");
  }
  return e.write(`if (${c} === INVALID) return INVALID;`), c;
}
s(P_, "generateUnionCheck");
function D_(e, r, i, o) {
  if (i.unionFallback)
    throw new C("discriminated union with unionFallback");
  if (i.options.length === 0)
    return e.write("return INVALID;"), o;
  let t = N(r), n = N(r);
  e.write(`const ${t} = ${o}?.[${oe(i.discriminator)}];`), e.write(`let ${n};`);
  let a = !0, c = /* @__PURE__ */ new Set();
  for (let u of i.options) {
    let l = u._zod.propValues?.[i.discriminator];
    if (!l || l.size === 0)
      throw new C("discriminated union option without static discriminator values");
    for (let v of l) {
      if (c.has(v))
        throw new C(`duplicate discriminator value ${String(v)}`);
      c.add(v);
    }
    let f = Array.from(l, (v) => N_(r, t, v)), m = a ? "if" : "else if";
    e.write(`${m} (${f.join(" || ")}) {`), e.indented((v) => {
      let y = W(v, r, u, o);
      v.write(`${n} = ${y};`);
    }), e.write("}"), a = !1;
  }
  return e.write("else { return INVALID; }"), n;
}
s(D_, "generateDiscriminatedUnionCheck");
function N_(e, r, i) {
  if (typeof i == "string")
    return `${r} === ${oe(i)}`;
  if (typeof i == "number")
    return Number.isNaN(i) ? `Number.isNaN(${r})` : `${r} === ${i}`;
  if (typeof i == "boolean")
    return `${r} === ${i}`;
  if (i === null)
    return `${r} === null`;
  if (i === void 0)
    return `${r} === undefined`;
  if (typeof i == "bigint")
    return `${r} === ${i}n`;
  if (typeof i == "symbol") {
    let o = D(e, i);
    return `${r} === ${o}`;
  }
  throw new C(`literal discriminator value ${String(i)}`);
}
s(N_, "literalEquality");
function T_(e, r, i, o) {
  let t = i._zod.def, n = ne(e, r, t.left, o), a = ne(e, r, t.right, o), c = D(r, At), u = N(r);
  return e.write(`const ${u} = ${c}(${n}, ${a});`), e.write(`if (!${u}.valid) return INVALID;`), `${u}.data`;
}
s(T_, "generateIntersectionCheck");
function U_(e, r, i, o) {
  let t = i._zod.def, n = D(r, ge);
  e.write(`if (!${n}(${o})) return INVALID;`);
  let a = N(r), c = N(r), u = N(r);
  e.write(`const ${a} = {};`);
  let l = t, f = l.partial ? void 0 : t.keyType._zod.values;
  if (f) {
    let b = [];
    for (let O of f) {
      if (!(typeof O == "string" || typeof O == "number" || typeof O == "symbol"))
        throw new C(`record key value ${String(O)}`);
      let L = typeof O == "number" ? O.toString() : O;
      if (L === "__proto__")
        throw new C('record key "__proto__"');
      b.push(L);
      let A = D(r, O), T = W(e, r, t.keyType, A), J = N(r);
      e.write(`const ${J} = ${o}[${E_(r, L)}];`);
      let q = ne(e, r, t.valueType, J);
      e.write(`${a}[${T}] = ${q};`);
    }
    let z = D(r, new Set(b));
    return e.write(`for (const ${c} in ${o}) {`), e.indented((O) => {
      O.write(`if (${z}.has(${c})) continue;`), l.mode === "loose" ? O.write(`if (${c} !== "__proto__") ${a}[${c}] = ${o}[${c}];`) : O.write("return INVALID;");
    }), e.write("}"), a;
  }
  let m = t.keyType._zod.def;
  if (!(m.type === "string" && m.format === void 0 && !m.coerce && (m.checks?.length ?? 0) === 0)) {
    let b = t.mode === "loose", z = D(r, pi(t.keyType)), O = D(r, Ze), L = D(r, Object.prototype.propertyIsEnumerable), A = N(r);
    return e.write(`for (const ${c} of Reflect.ownKeys(${o})) {`), e.indented((T) => {
      T.write(`if (${c} === "__proto__") continue;`), T.write(`if (!${L}.call(${o}, ${c})) continue;`), T.write(`let ${A} = ${z}(${c});`), T.write(`if (${A} === INVALID && typeof ${c} === "string" && ${O}.test(${c})) ${A} = ${z}(Number(${c}));`), b ? T.write(`if (${A} === INVALID) { ${a}[${c}] = ${o}[${c}]; continue; }`) : T.write(`if (${A} === INVALID) return INVALID;`), T.write(`if (${A} === "__proto__") continue;`);
      let J = N(r);
      T.write(`const ${J} = ${o}[${c}];`);
      let q = ne(T, r, t.valueType, J);
      T.write(`${a}[${A}] = ${q};`);
    }), e.write("}"), a;
  }
  let y = D(r, Object.prototype.propertyIsEnumerable);
  return e.write(`for (const ${c} of Reflect.ownKeys(${o})) {`), e.indented((b) => {
    b.write(`if (${c} === "__proto__") continue;`), b.write(`if (!${y}.call(${o}, ${c})) continue;`), b.write(`if (typeof ${c} !== "string") return INVALID;`), b.write(`const ${u} = ${o}[${c}];`);
    let z = ne(b, r, t.valueType, u);
    b.write(`${a}[${c}] = ${z};`);
  }), e.write("}"), a;
}
s(U_, "generateRecordCheck");
function E_(e, r) {
  return typeof r == "string" ? oe(r) : D(e, r);
}
s(E_, "literalPropertyKey");
function C_(e, r, i, o) {
  let t = i._zod.def;
  e.write(`if (!(${o} instanceof Map)) return INVALID;`);
  let n = N(r), a = N(r), c = N(r);
  return e.write(`const ${n} = new Map();`), e.write(`for (const [${a}, ${c}] of ${o}) {`), e.indented((u) => {
    let l = W(u, r, t.keyType, a), f = W(u, r, t.valueType, c);
    u.write(`${n}.set(${l}, ${f});`);
  }), e.write("}"), n;
}
s(C_, "generateMapCheck");
function Z_(e, r, i, o) {
  let t = i._zod.def;
  e.write(`if (!(${o} instanceof Set)) return INVALID;`);
  let n = N(r), a = N(r);
  return e.write(`const ${n} = new Set();`), e.write(`for (const ${a} of ${o}) {`), e.indented((c) => {
    let u = W(c, r, t.valueType, a);
    c.write(`${n}.add(${u});`);
  }), e.write("}"), n;
}
s(Z_, "generateSetCheck");
function R_(e, r) {
  return e.write(`if (!(${r} instanceof File)) return INVALID;`), r;
}
s(R_, "generateFileCheck");
function F_(e, r, i, o) {
  e.write(`if (typeof ${o} !== "string") return INVALID;`);
  let t = i._zod.pattern;
  if (t) {
    let n = D(r, t);
    e.write(`${n}.lastIndex = 0;`), e.write(`if (!${n}.test(${o})) return INVALID;`);
  }
  return o;
}
s(F_, "generateTemplateLiteralCheck");
function L_(e, r, i, o) {
  let t = i._zod.def, n = D(r, t.getter), a = D(r, { parser: null });
  e.write(`if (!${a}.parser) {`), e.indented((u) => {
    u.write(`const inner = ${n}();`), u.write(`${a}.parser = function(input) {`), u.indented((l) => {
      l.write("const result = inner._zod.run({ value: input, issues: [] }, {});"), l.write("return result.issues.length === 0 ? result.value : INVALID;");
    }), u.write("};");
  }), e.write("}");
  let c = N(r);
  return e.write(`const ${c} = ${a}.parser(${o});`), e.write(`if (${c} === INVALID) return INVALID;`), c;
}
s(L_, "generateLazyCheck");
function V_(e, r, i, o) {
  let t = i._zod.def, n = W(e, r, t.in, o);
  if (t.transform) {
    if (lt(t.transform))
      throw new _e("z.compile: async transforms in pipes are not supported");
    let a = t.transform, u = D(r, /* @__PURE__ */ s((f) => {
      let m = { value: f, issues: [], addIssue: xu }, v = a(f, m);
      return v instanceof Promise ? fe : m.issues.length === 0 ? v : fe;
    }, "helperFn")), l = N(r);
    return e.write(`const ${l} = ${u}(${n});`), e.write(`if (${l} === INVALID) return INVALID;`), W(e, r, t.out, l);
  } else
    return W(e, r, t.out, n);
}
s(V_, "generatePipeCheck");
function lt(e) {
  return typeof e == "function" && (e.constructor.name === "AsyncFunction" || e[Symbol.toStringTag] === "AsyncFunction");
}
s(lt, "isAsyncFunction");
function M_(e, r, i, o) {
  let t = i._zod.def;
  if (t.fn) {
    if (lt(t.fn))
      throw new _e("z.compile: async custom predicates are not supported");
    let n = D(r, t.fn), a = D(r, bu), c = N(r);
    e.write(`const ${c} = ${n}(${o});`), e.write(`if (${c} instanceof Promise) ${a}();`), e.write(`if (!${c}) return INVALID;`);
  } else
    throw new C("custom schema without a predicate function");
  return o;
}
s(M_, "generateCustomCheck");
function B_(e, r, i) {
  let o = e._zod.run({ value: i, issues: [] }, {});
  if (o && typeof o.then == "function")
    return fe;
  let t = o;
  return t.issues.length === 0 ? t.value : r();
}
s(B_, "runtimeCatch");
function J_(e, r, i, o) {
  let t = i._zod.def;
  if (!t.catchValue[Sn])
    throw new C("catch with a callback (only a constant catch value compiles)", !1);
  let n = N(r);
  e.write(`let ${n} = (() => {`), e.indented((l) => {
    let f = ne(l, r, t.innerType, o);
    l.write(`return ${f};`);
  }), e.write("})();");
  let a = D(r, t.innerType), c = D(r, t.catchValue), u = D(r, B_);
  return e.write(`if (${n} === INVALID) {`), e.indented((l) => {
    l.write(`${n} = ${u}(${a}, ${c}, ${o});`), l.write(`if (${n} === INVALID) return INVALID;`);
  }), e.write("}"), n;
}
s(J_, "generateCatchCheck");
function q_(e, r, i, o) {
  let t = i._zod.def;
  if (t.transform) {
    if (lt(t.transform))
      throw new _e("z.compile: async transforms are not supported");
    let n = t.transform, c = D(r, /* @__PURE__ */ s((l) => {
      let f = { value: l, issues: [], addIssue: xu }, m = n(l, f);
      return m instanceof Promise ? fe : f.issues.length === 0 ? m : fe;
    }, "helperFn")), u = N(r);
    return e.write(`const ${u} = ${c}(${o});`), e.write(`if (${u} === INVALID) return INVALID;`), u;
  }
  return o;
}
s(q_, "generateTransformCheck");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/api.js
// @__NO_SIDE_EFFECTS__
function wu(e, r) {
  return new e({
    type: "string",
    ...I(r)
  });
}
s(wu, "_string");
// @__NO_SIDE_EFFECTS__
function ku(e, r) {
  return new e({
    type: "string",
    coerce: !0,
    ...I(r)
  });
}
s(ku, "_coercedString");
// @__NO_SIDE_EFFECTS__
function mi(e, r) {
  return new e({
    type: "string",
    format: "email",
    check: "string_format",
    abort: !1,
    ...I(r)
  });
}
s(mi, "_email");
// @__NO_SIDE_EFFECTS__
function hi(e, r) {
  return new e({
    type: "string",
    format: "guid",
    check: "string_format",
    abort: !1,
    ...I(r)
  });
}
s(hi, "_guid");
// @__NO_SIDE_EFFECTS__
function gi(e, r) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    ...I(r)
  });
}
s(gi, "_uuid");
// @__NO_SIDE_EFFECTS__
function vi(e, r) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v4",
    ...I(r)
  });
}
s(vi, "_uuidv4");
// @__NO_SIDE_EFFECTS__
function yi(e, r) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v6",
    ...I(r)
  });
}
s(yi, "_uuidv6");
// @__NO_SIDE_EFFECTS__
function bi(e, r) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v7",
    ...I(r)
  });
}
s(bi, "_uuidv7");
// @__NO_SIDE_EFFECTS__
function Lr(e, r) {
  return new e({
    type: "string",
    format: "url",
    check: "string_format",
    abort: !1,
    ...I(r)
  });
}
s(Lr, "_url");
// @__NO_SIDE_EFFECTS__
function $i(e, r) {
  return new e({
    type: "string",
    format: "emoji",
    check: "string_format",
    abort: !1,
    ...I(r)
  });
}
s($i, "_emoji");
// @__NO_SIDE_EFFECTS__
function _i(e, r) {
  return new e({
    type: "string",
    format: "nanoid",
    check: "string_format",
    abort: !1,
    ...I(r)
  });
}
s(_i, "_nanoid");
// @__NO_SIDE_EFFECTS__
function xi(e, r) {
  return new e({
    type: "string",
    format: "cuid",
    check: "string_format",
    abort: !1,
    ...I(r)
  });
}
s(xi, "_cuid");
// @__NO_SIDE_EFFECTS__
function wi(e, r) {
  return new e({
    type: "string",
    format: "cuid2",
    check: "string_format",
    abort: !1,
    ...I(r)
  });
}
s(wi, "_cuid2");
// @__NO_SIDE_EFFECTS__
function ki(e, r) {
  return new e({
    type: "string",
    format: "ulid",
    check: "string_format",
    abort: !1,
    ...I(r)
  });
}
s(ki, "_ulid");
// @__NO_SIDE_EFFECTS__
function Ii(e, r) {
  return new e({
    type: "string",
    format: "xid",
    check: "string_format",
    abort: !1,
    ...I(r)
  });
}
s(Ii, "_xid");
// @__NO_SIDE_EFFECTS__
function zi(e, r) {
  return new e({
    type: "string",
    format: "ksuid",
    check: "string_format",
    abort: !1,
    ...I(r)
  });
}
s(zi, "_ksuid");
// @__NO_SIDE_EFFECTS__
function Si(e, r) {
  return new e({
    type: "string",
    format: "ipv4",
    check: "string_format",
    abort: !1,
    ...I(r)
  });
}
s(Si, "_ipv4");
// @__NO_SIDE_EFFECTS__
function Oi(e, r) {
  return new e({
    type: "string",
    format: "ipv6",
    check: "string_format",
    abort: !1,
    ...I(r)
  });
}
s(Oi, "_ipv6");
// @__NO_SIDE_EFFECTS__
function Iu(e, r) {
  return new e({
    type: "string",
    format: "mac",
    check: "string_format",
    abort: !1,
    ...I(r)
  });
}
s(Iu, "_mac");
// @__NO_SIDE_EFFECTS__
function ji(e, r) {
  return new e({
    type: "string",
    format: "cidrv4",
    check: "string_format",
    abort: !1,
    ...I(r)
  });
}
s(ji, "_cidrv4");
// @__NO_SIDE_EFFECTS__
function Ai(e, r) {
  return new e({
    type: "string",
    format: "cidrv6",
    check: "string_format",
    abort: !1,
    ...I(r)
  });
}
s(Ai, "_cidrv6");
// @__NO_SIDE_EFFECTS__
function Pi(e, r) {
  return new e({
    type: "string",
    format: "base64",
    check: "string_format",
    abort: !1,
    ...I(r)
  });
}
s(Pi, "_base64");
// @__NO_SIDE_EFFECTS__
function Di(e, r) {
  return new e({
    type: "string",
    format: "base64url",
    check: "string_format",
    abort: !1,
    ...I(r)
  });
}
s(Di, "_base64url");
// @__NO_SIDE_EFFECTS__
function Ni(e, r) {
  return new e({
    type: "string",
    format: "e164",
    check: "string_format",
    abort: !1,
    ...I(r)
  });
}
s(Ni, "_e164");
// @__NO_SIDE_EFFECTS__
function zu(e, r) {
  return new e({
    type: "string",
    format: "credit_card",
    check: "string_format",
    abort: !1,
    ...I(r)
  });
}
s(zu, "_creditCard");
// @__NO_SIDE_EFFECTS__
function Ti(e, r) {
  return new e({
    type: "string",
    format: "jwt",
    check: "string_format",
    abort: !1,
    ...I(r)
  });
}
s(Ti, "_jwt");
var Su = {
  Any: null,
  Minute: -1,
  Second: 0,
  Millisecond: 3,
  Microsecond: 6
};
// @__NO_SIDE_EFFECTS__
function Vr(e, r) {
  return new e({
    type: "string",
    format: "datetime",
    check: "string_format",
    offset: !1,
    local: !1,
    precision: null,
    ...I(r)
  });
}
s(Vr, "_isoDateTime");
// @__NO_SIDE_EFFECTS__
function Mr(e, r) {
  return new e({
    type: "string",
    format: "date",
    check: "string_format",
    ...I(r)
  });
}
s(Mr, "_isoDate");
// @__NO_SIDE_EFFECTS__
function Br(e, r) {
  return new e({
    type: "string",
    format: "time",
    check: "string_format",
    precision: null,
    ...I(r)
  });
}
s(Br, "_isoTime");
// @__NO_SIDE_EFFECTS__
function Jr(e, r) {
  return new e({
    type: "string",
    format: "duration",
    check: "string_format",
    ...I(r)
  });
}
s(Jr, "_isoDuration");
// @__NO_SIDE_EFFECTS__
function Ou(e, r) {
  return new e({
    type: "number",
    checks: [],
    ...I(r)
  });
}
s(Ou, "_number");
// @__NO_SIDE_EFFECTS__
function ju(e, r) {
  return new e({
    type: "number",
    coerce: !0,
    checks: [],
    ...I(r)
  });
}
s(ju, "_coercedNumber");
// @__NO_SIDE_EFFECTS__
function Au(e, r) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "safeint",
    ...I(r)
  });
}
s(Au, "_int");
// @__NO_SIDE_EFFECTS__
function Pu(e, r) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "float32",
    ...I(r)
  });
}
s(Pu, "_float32");
// @__NO_SIDE_EFFECTS__
function Du(e, r) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "float64",
    ...I(r)
  });
}
s(Du, "_float64");
// @__NO_SIDE_EFFECTS__
function Nu(e, r) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "int32",
    ...I(r)
  });
}
s(Nu, "_int32");
// @__NO_SIDE_EFFECTS__
function Tu(e, r) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "uint32",
    ...I(r)
  });
}
s(Tu, "_uint32");
// @__NO_SIDE_EFFECTS__
function Uu(e, r) {
  return new e({
    type: "boolean",
    ...I(r)
  });
}
s(Uu, "_boolean");
// @__NO_SIDE_EFFECTS__
function Eu(e, r) {
  return new e({
    type: "boolean",
    coerce: !0,
    ...I(r)
  });
}
s(Eu, "_coercedBoolean");
// @__NO_SIDE_EFFECTS__
function Cu(e, r) {
  return new e({
    type: "bigint",
    ...I(r)
  });
}
s(Cu, "_bigint");
// @__NO_SIDE_EFFECTS__
function Zu(e, r) {
  return new e({
    type: "bigint",
    coerce: !0,
    ...I(r)
  });
}
s(Zu, "_coercedBigint");
// @__NO_SIDE_EFFECTS__
function Ru(e, r) {
  return new e({
    type: "bigint",
    check: "bigint_format",
    abort: !1,
    format: "int64",
    ...I(r)
  });
}
s(Ru, "_int64");
// @__NO_SIDE_EFFECTS__
function Fu(e, r) {
  return new e({
    type: "bigint",
    check: "bigint_format",
    abort: !1,
    format: "uint64",
    ...I(r)
  });
}
s(Fu, "_uint64");
// @__NO_SIDE_EFFECTS__
function Lu(e, r) {
  return new e({
    type: "symbol",
    ...I(r)
  });
}
s(Lu, "_symbol");
// @__NO_SIDE_EFFECTS__
function Vu(e, r) {
  return new e({
    type: "undefined",
    ...I(r)
  });
}
s(Vu, "_undefined");
// @__NO_SIDE_EFFECTS__
function Mu(e, r) {
  return new e({
    type: "null",
    ...I(r)
  });
}
s(Mu, "_null");
// @__NO_SIDE_EFFECTS__
function Bu(e) {
  return new e({
    type: "any"
  });
}
s(Bu, "_any");
// @__NO_SIDE_EFFECTS__
function Ju(e) {
  return new e({
    type: "unknown"
  });
}
s(Ju, "_unknown");
// @__NO_SIDE_EFFECTS__
function qu(e, r) {
  return new e({
    type: "never",
    ...I(r)
  });
}
s(qu, "_never");
// @__NO_SIDE_EFFECTS__
function Ku(e, r) {
  return new e({
    type: "void",
    ...I(r)
  });
}
s(Ku, "_void");
// @__NO_SIDE_EFFECTS__
function Wu(e, r) {
  return new e({
    type: "date",
    ...I(r)
  });
}
s(Wu, "_date");
// @__NO_SIDE_EFFECTS__
function Gu(e, r) {
  return new e({
    type: "date",
    coerce: !0,
    ...I(r)
  });
}
s(Gu, "_coercedDate");
// @__NO_SIDE_EFFECTS__
function Xu(e, r) {
  return new e({
    type: "nan",
    ...I(r)
  });
}
s(Xu, "_nan");
// @__NO_SIDE_EFFECTS__
function ze(e, r) {
  return new Ln({
    check: "less_than",
    ...I(r),
    value: e,
    inclusive: !1
  });
}
s(ze, "_lt");
// @__NO_SIDE_EFFECTS__
function pe(e, r) {
  return new Ln({
    check: "less_than",
    ...I(r),
    value: e,
    inclusive: !0
  });
}
s(pe, "_lte");
// @__NO_SIDE_EFFECTS__
function Se(e, r) {
  return new Vn({
    check: "greater_than",
    ...I(r),
    value: e,
    inclusive: !1
  });
}
s(Se, "_gt");
// @__NO_SIDE_EFFECTS__
function me(e, r) {
  return new Vn({
    check: "greater_than",
    ...I(r),
    value: e,
    inclusive: !0
  });
}
s(me, "_gte");
// @__NO_SIDE_EFFECTS__
function Ui(e) {
  return /* @__PURE__ */ Se(0, e);
}
s(Ui, "_positive");
// @__NO_SIDE_EFFECTS__
function Ei(e) {
  return /* @__PURE__ */ ze(0, e);
}
s(Ei, "_negative");
// @__NO_SIDE_EFFECTS__
function Ci(e) {
  return /* @__PURE__ */ pe(0, e);
}
s(Ci, "_nonpositive");
// @__NO_SIDE_EFFECTS__
function Zi(e) {
  return /* @__PURE__ */ me(0, e);
}
s(Zi, "_nonnegative");
// @__NO_SIDE_EFFECTS__
function Re(e, r) {
  return new Fa({
    check: "multiple_of",
    ...I(r),
    value: e
  });
}
s(Re, "_multipleOf");
// @__NO_SIDE_EFFECTS__
function Fe(e, r) {
  return new Ma({
    check: "max_size",
    ...I(r),
    maximum: e
  });
}
s(Fe, "_maxSize");
// @__NO_SIDE_EFFECTS__
function Oe(e, r) {
  return new Ba({
    check: "min_size",
    ...I(r),
    minimum: e
  });
}
s(Oe, "_minSize");
// @__NO_SIDE_EFFECTS__
function dt(e, r) {
  return new Ja({
    check: "size_equals",
    ...I(r),
    size: e
  });
}
s(dt, "_size");
// @__NO_SIDE_EFFECTS__
function ft(e, r) {
  return new qa({
    check: "max_length",
    ...I(r),
    maximum: e
  });
}
s(ft, "_maxLength");
// @__NO_SIDE_EFFECTS__
function Ne(e, r) {
  return new Ka({
    check: "min_length",
    ...I(r),
    minimum: e
  });
}
s(Ne, "_minLength");
// @__NO_SIDE_EFFECTS__
function pt(e, r) {
  return new Wa({
    check: "length_equals",
    ...I(r),
    length: e
  });
}
s(pt, "_length");
// @__NO_SIDE_EFFECTS__
function Ut(e, r) {
  return new Ga({
    check: "string_format",
    format: "regex",
    ...I(r),
    pattern: e
  });
}
s(Ut, "_regex");
// @__NO_SIDE_EFFECTS__
function Et(e) {
  return new Xa({
    check: "string_format",
    format: "lowercase",
    ...I(e)
  });
}
s(Et, "_lowercase");
// @__NO_SIDE_EFFECTS__
function Ct(e) {
  return new Ha({
    check: "string_format",
    format: "uppercase",
    ...I(e)
  });
}
s(Ct, "_uppercase");
// @__NO_SIDE_EFFECTS__
function Zt(e, r) {
  return new Qa({
    check: "string_format",
    format: "includes",
    ...I(r),
    includes: e
  });
}
s(Zt, "_includes");
// @__NO_SIDE_EFFECTS__
function Rt(e, r) {
  return new Ya({
    check: "string_format",
    format: "starts_with",
    ...I(r),
    prefix: e
  });
}
s(Rt, "_startsWith");
// @__NO_SIDE_EFFECTS__
function Ft(e, r) {
  return new es({
    check: "string_format",
    format: "ends_with",
    ...I(r),
    suffix: e
  });
}
s(Ft, "_endsWith");
// @__NO_SIDE_EFFECTS__
function Ri(e, r, i) {
  return new Mn({
    check: "property",
    property: e,
    schema: r,
    ...I(i)
  });
}
s(Ri, "_property");
// @__NO_SIDE_EFFECTS__
function Fi(e) {
  return Object.entries(e).map(([r, i]) => new Mn({ check: "property", property: r, schema: i }));
}
s(Fi, "_properties");
// @__NO_SIDE_EFFECTS__
function Lt(e, r) {
  return new ts({
    check: "mime_type",
    mime: e,
    ...I(r)
  });
}
s(Lt, "_mime");
// @__NO_SIDE_EFFECTS__
function xe(e) {
  return new rs({
    check: "overwrite",
    tx: e
  });
}
s(xe, "_overwrite");
// @__NO_SIDE_EFFECTS__
function Vt(e) {
  return /* @__PURE__ */ xe((r) => r.normalize(e));
}
s(Vt, "_normalize");
// @__NO_SIDE_EFFECTS__
function Mt() {
  return /* @__PURE__ */ xe((e) => e.trim());
}
s(Mt, "_trim");
// @__NO_SIDE_EFFECTS__
function Bt() {
  return /* @__PURE__ */ xe((e) => e.toLowerCase());
}
s(Bt, "_toLowerCase");
// @__NO_SIDE_EFFECTS__
function Jt() {
  return /* @__PURE__ */ xe((e) => e.toUpperCase());
}
s(Jt, "_toUpperCase");
// @__NO_SIDE_EFFECTS__
function qt() {
  return /* @__PURE__ */ xe((e) => Lo(e));
}
s(qt, "_slugify");
// @__NO_SIDE_EFFECTS__
function Hu(e, r, i) {
  return new e({
    type: "array",
    element: r,
    // get element() {
    //   return element;
    // },
    ...I(i)
  });
}
s(Hu, "_array");
// @__NO_SIDE_EFFECTS__
function K_(e, r, i) {
  return new e({
    type: "union",
    options: r,
    ...I(i)
  });
}
s(K_, "_union");
function W_(e, r, i) {
  return new e({
    type: "union",
    options: r,
    inclusive: !1,
    ...I(i)
  });
}
s(W_, "_xor");
// @__NO_SIDE_EFFECTS__
function G_(e, r, i, o) {
  return new e({
    type: "union",
    options: i,
    discriminator: r,
    ...I(o)
  });
}
s(G_, "_discriminatedUnion");
// @__NO_SIDE_EFFECTS__
function X_(e, r, i) {
  return new e({
    type: "intersection",
    left: r,
    right: i
  });
}
s(X_, "_intersection");
// @__NO_SIDE_EFFECTS__
function H_(e, r, i, o) {
  let t = i instanceof P, n = t ? o : i, a = t ? i : null;
  return new e({
    type: "tuple",
    items: r,
    rest: a,
    ...I(n)
  });
}
s(H_, "_tuple");
// @__NO_SIDE_EFFECTS__
function Q_(e, r, i, o) {
  return new e({
    type: "record",
    keyType: r,
    valueType: i,
    ...I(o)
  });
}
s(Q_, "_record");
// @__NO_SIDE_EFFECTS__
function Y_(e, r, i, o) {
  return new e({
    type: "map",
    keyType: r,
    valueType: i,
    ...I(o)
  });
}
s(Y_, "_map");
// @__NO_SIDE_EFFECTS__
function ex(e, r, i) {
  return new e({
    type: "set",
    valueType: r,
    ...I(i)
  });
}
s(ex, "_set");
// @__NO_SIDE_EFFECTS__
function tx(e, r, i) {
  let o = Array.isArray(r) ? Object.fromEntries(r.map((t) => [t, t])) : r;
  return new e({
    type: "enum",
    entries: o,
    ...I(i)
  });
}
s(tx, "_enum");
// @__NO_SIDE_EFFECTS__
function rx(e, r, i) {
  return new e({
    type: "enum",
    entries: r,
    ...I(i)
  });
}
s(rx, "_nativeEnum");
// @__NO_SIDE_EFFECTS__
function nx(e, r, i) {
  return new e({
    type: "literal",
    values: Array.isArray(r) ? r : [r],
    ...I(i)
  });
}
s(nx, "_literal");
// @__NO_SIDE_EFFECTS__
function Qu(e, r) {
  return new e({
    type: "file",
    ...I(r)
  });
}
s(Qu, "_file");
// @__NO_SIDE_EFFECTS__
function ix(e, r) {
  return new e({
    type: "transform",
    transform: r
  });
}
s(ix, "_transform");
// @__NO_SIDE_EFFECTS__
function ox(e, r) {
  return new e({
    type: "optional",
    innerType: r
  });
}
s(ox, "_optional");
// @__NO_SIDE_EFFECTS__
function ax(e, r) {
  return new e({
    type: "nullable",
    innerType: r
  });
}
s(ax, "_nullable");
// @__NO_SIDE_EFFECTS__
function sx(e, r, i) {
  return new e({
    type: "default",
    innerType: r,
    get defaultValue() {
      return typeof i == "function" ? i() : gr(i);
    }
  });
}
s(sx, "_default");
// @__NO_SIDE_EFFECTS__
function cx(e, r, i) {
  return new e({
    type: "nonoptional",
    innerType: r,
    ...I(i)
  });
}
s(cx, "_nonoptional");
// @__NO_SIDE_EFFECTS__
function ux(e, r) {
  return new e({
    type: "success",
    innerType: r
  });
}
s(ux, "_success");
// @__NO_SIDE_EFFECTS__
function lx(e, r, i) {
  return new e({
    type: "catch",
    innerType: r,
    catchValue: typeof i == "function" ? i : Xo(i)
  });
}
s(lx, "_catch");
// @__NO_SIDE_EFFECTS__
function dx(e, r, i) {
  return new e({
    type: "pipe",
    in: r,
    out: i
  });
}
s(dx, "_pipe");
// @__NO_SIDE_EFFECTS__
function fx(e, r) {
  return new e({
    type: "readonly",
    innerType: r
  });
}
s(fx, "_readonly");
// @__NO_SIDE_EFFECTS__
function px(e, r, i) {
  return new e({
    type: "template_literal",
    parts: r,
    ...I(i)
  });
}
s(px, "_templateLiteral");
// @__NO_SIDE_EFFECTS__
function mx(e, r) {
  return new e({
    type: "lazy",
    getter: r
  });
}
s(mx, "_lazy");
// @__NO_SIDE_EFFECTS__
function hx(e, r) {
  return new e({
    type: "promise",
    innerType: r
  });
}
s(hx, "_promise");
// @__NO_SIDE_EFFECTS__
function Yu(e, r, i) {
  let o = I(i);
  return o.abort ?? (o.abort = !0), new e({
    type: "custom",
    check: "custom",
    fn: r,
    ...o
  });
}
s(Yu, "_custom");
// @__NO_SIDE_EFFECTS__
function el(e, r, i) {
  return new e({
    type: "custom",
    check: "custom",
    fn: r,
    ...I(i)
  });
}
s(el, "_refine");
// @__NO_SIDE_EFFECTS__
function tl(e, r) {
  let i = /* @__PURE__ */ vp((o) => (o.addIssue = (t) => {
    if (typeof t == "string")
      o.issues.push(kt(t, o.value, i._zod.def));
    else {
      let n = t;
      n.fatal && (n.continue = !1), n.code ?? (n.code = "custom"), "input" in n || (n.input = o.value), n.inst ?? (n.inst = i), n.continue ?? (n.continue = !i._zod.def.abort), o.issues.push(kt(n));
    }
  }, e(o.value, o)), r);
  return i;
}
s(tl, "_superRefine");
// @__NO_SIDE_EFFECTS__
function vp(e, r) {
  let i = new B({
    check: "custom",
    ...I(r)
  });
  return i._zod.check = e, i;
}
s(vp, "_check");
// @__NO_SIDE_EFFECTS__
function rl(e) {
  let r = new B({ check: "describe" });
  return r._zod.onattach = [
    (i) => {
      let o = Y.get(i) ?? {};
      Y.add(i, { ...o, description: e });
    }
  ], r._zod.check = () => {
  }, r;
}
s(rl, "describe");
// @__NO_SIDE_EFFECTS__
function nl(e) {
  let r = new B({ check: "meta" });
  return r._zod.onattach = [
    (i) => {
      let o = Y.get(i) ?? {};
      Y.add(i, { ...o, ...e });
    }
  ], r._zod.check = () => {
  }, r;
}
s(nl, "meta");
// @__NO_SIDE_EFFECTS__
function il(e, r) {
  let i = I(r), o = i.truthy ?? ["true", "1", "yes", "on", "y", "enabled"], t = i.falsy ?? ["false", "0", "no", "off", "n", "disabled"];
  i.case !== "sensitive" && (o = o.map((y) => typeof y == "string" ? y.toLowerCase() : y), t = t.map((y) => typeof y == "string" ? y.toLowerCase() : y));
  let n = new Set(o), a = new Set(t), c = e.Codec ?? ot, u = e.Boolean ?? Or, l = e.String ?? it, f = new l({ type: "string", error: i.error }), m = new u({ type: "boolean", error: i.error }), v = new c({
    type: "pipe",
    in: f,
    out: m,
    transform: /* @__PURE__ */ s(((y, b) => {
      let z = y;
      return i.case !== "sensitive" && (z = z.toLowerCase()), n.has(z) ? !0 : a.has(z) ? !1 : (b.issues.push({
        code: "invalid_value",
        expected: "stringbool",
        values: [...n, ...a],
        input: b.value,
        inst: v,
        continue: !1
      }), {});
    }), "transform"),
    reverseTransform: /* @__PURE__ */ s(((y, b) => y === !0 ? o[0] || "true" : t[0] || "false"), "reverseTransform"),
    error: i.error
  });
  return v._zod.bag.truthy = o, v._zod.bag.falsy = t, v._zod.bag.case = i.case ?? "insensitive", v;
}
s(il, "_stringbool");
// @__NO_SIDE_EFFECTS__
function Kt(e, r, i, o = {}) {
  let t = I(o), n = {
    check: "string_format",
    type: "string",
    format: r,
    fn: typeof i == "function" ? i : (c) => i.test(c),
    ...t
  };
  return i instanceof RegExp && (n.pattern = i), new e(n);
}
s(Kt, "_stringFormat");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/to-json-schema.js
function qr(e, ...r) {
  for (let i of r)
    for (let o of Reflect.ownKeys(i))
      Object.prototype.propertyIsEnumerable.call(i, o) && G(e, o, i[o]);
  return e;
}
s(qr, "assignProps");
function Le(e) {
  let r = e?.target ?? "draft-2020-12";
  return r === "draft-4" && (r = "draft-04"), r === "draft-7" && (r = "draft-07"), {
    processors: e.processors ?? {},
    metadataRegistry: e?.metadata ?? Y,
    target: r,
    unrepresentable: e?.unrepresentable ?? "throw",
    override: e?.override ?? (() => {
    }),
    io: e?.io ?? "output",
    counter: 0,
    seen: /* @__PURE__ */ new Map(),
    sharedDefsExtractedFor: void 0,
    sharedEmitDoneFor: void 0,
    cycles: e?.cycles ?? "ref",
    reused: e?.reused ?? "inline",
    intersections: [],
    deferred: [],
    external: e?.external ?? void 0
  };
}
s(Le, "initializeContext");
function H(e, r, i, o, t) {
  let n = typeof r.unrepresentable == "function" ? r.unrepresentable({ zodSchema: e, path: o.path, message: t }) : r.unrepresentable;
  if (n === "any")
    return !1;
  if (n === void 0 || n === "throw")
    throw new Error(t);
  return Object.assign(i, n), !0;
}
s(H, "handleUnrepresentable");
function F(e, r, i = { path: [], schemaPath: [] }) {
  var o;
  let t = e._zod.def, n = r.seen.get(e);
  if (n)
    return n.count++, i.schemaPath.includes(e) && (n.cycle = i.path), n.schema;
  let a = { schema: {}, count: 1, cycle: void 0, path: i.path };
  r.seen.set(e, a), r.sharedDefsExtractedFor = void 0, r.sharedEmitDoneFor = void 0;
  let c = e._zod.toJSONSchema?.();
  if (c)
    a.schema = c;
  else {
    let f = {
      ...i,
      schemaPath: [...i.schemaPath, e],
      path: i.path
    };
    if (e._zod.processJSONSchema)
      e._zod.processJSONSchema(r, a.schema, f);
    else {
      let v = a.schema, y = r.processors[t.type];
      if (!y)
        throw new Error(`[toJSONSchema]: Non-representable type encountered: ${t.type}`);
      y(e, r, v, f);
    }
    let m = e._zod.parent;
    m && (a.ref || (a.ref = m), F(m, r, f), r.seen.get(m).isParent = !0);
  }
  let u = r.metadataRegistry.get(e);
  return u && qr(a.schema, u), r.io === "input" && ie(e) && (delete a.schema.examples, delete a.schema.default), r.io === "input" && "_prefault" in a.schema && ((o = a.schema).default ?? (o.default = a.schema._prefault)), delete a.schema._prefault, r.seen.get(e).schema;
}
s(F, "process");
function yp(e) {
  return e.replace(/~/g, "~0").replace(/\//g, "~1");
}
s(yp, "encodeJSONPointerSegment");
function Ve(e, r) {
  let i = e.seen.get(r);
  if (!i)
    throw new Error("Unprocessed schema. This is a bug in Zod.");
  if (e.external && e.sharedDefsExtractedFor === e.external)
    return;
  let o = /* @__PURE__ */ new Map();
  for (let a of e.seen.entries()) {
    let c = e.metadataRegistry.get(a[0])?.id;
    if (c) {
      let u = o.get(c);
      if (u && u !== a[0])
        throw new Error(`Duplicate schema id "${c}" detected during JSON Schema conversion. Two different schemas cannot share the same id when converted together.`);
      o.set(c, a[0]);
    }
  }
  let t = /* @__PURE__ */ s((a) => {
    let c = e.target === "draft-2020-12" ? "$defs" : "definitions";
    if (e.external) {
      let m = e.external.registry.get(a[0])?.id, v = e.external.uri ?? ((b) => b);
      if (m)
        return { ref: v(m) };
      let y = a[1].defId ?? a[1].schema.id ?? `schema${e.counter++}`;
      return a[1].defId = y, { defId: y, ref: `${v("__shared")}#/${c}/${yp(y)}` };
    }
    let u = "#", l = `${u}/${c}/`;
    if (a[1] === i && !a[1].schema.id)
      return { ref: u };
    let f = a[1].schema.id ?? `__schema${e.counter++}`;
    return { defId: f, ref: l + yp(f) };
  }, "makeURI"), n = /* @__PURE__ */ s((a) => {
    if (a[1].schema.$ref)
      return;
    let c = a[1], { ref: u, defId: l } = t(a);
    c.def = { ...c.schema }, l && (c.defId = l);
    let f = c.schema;
    for (let m in f)
      delete f[m];
    f.$ref = u;
  }, "extractToDef");
  if (e.cycles === "throw")
    for (let a of e.seen.entries()) {
      let c = a[1];
      if (c.cycle)
        throw new Error(`Cycle detected: #/${c.cycle?.join("/")}/<root>

Set the \`cycles\` parameter to \`"ref"\` to resolve cyclical schemas with defs.`);
    }
  for (let a of e.seen.entries()) {
    let c = a[1];
    if (r === a[0]) {
      n(a);
      continue;
    }
    if (e.external) {
      let l = e.external.registry.get(a[0])?.id;
      if (r !== a[0] && l) {
        n(a);
        continue;
      }
    }
    if (e.metadataRegistry.get(a[0])?.id) {
      n(a);
      continue;
    }
    if (c.cycle) {
      n(a);
      continue;
    }
    if (c.count > 1 && e.reused === "ref") {
      n(a);
      continue;
    }
  }
  e.external && (e.sharedDefsExtractedFor = e.external);
}
s(Ve, "extractDefs");
function _p(e) {
  let r = e.anyOf;
  if (!Array.isArray(r) || r.length === 0 || e.type !== void 0)
    return;
  let i = [];
  for (let o of r) {
    if (!o || typeof o != "object")
      return;
    _p(o);
    let t = Object.keys(o);
    if (t.length !== 1 || t[0] !== "type")
      return;
    let n = o.type;
    for (let a of Array.isArray(n) ? n : [n]) {
      if (typeof a != "string")
        return;
      i.includes(a) || i.push(a);
    }
  }
  delete e.anyOf, e.type = i.length === 1 ? i[0] : i;
}
s(_p, "compactTypeUnion");
var xp = /* @__PURE__ */ new Set(["type", "properties", "required", "additionalProperties"]), bp = ["oneOf", "anyOf"];
function $p(e) {
  let r = e.additionalProperties;
  return r === void 0 || r === !1 || typeof r != "object" || r === null ? null : Object.keys(r).length ? r : null;
}
s($p, "undeclaredConstraint");
function ol(e) {
  let r = [];
  for (let n of e) {
    if (typeof n != "object" || n.type !== "object")
      return null;
    for (let a in n)
      if (!xp.has(a))
        return null;
    r.push(n);
  }
  let i = {}, o = /* @__PURE__ */ new Set();
  for (let n of r) {
    for (let a in n.properties) {
      if (Object.prototype.hasOwnProperty.call(i, a))
        continue;
      let c = [];
      for (let l of r) {
        let f = l.properties?.[a] ?? $p(l);
        f != null && (c.some((m) => JSON.stringify(m) === JSON.stringify(f)) || c.push(f));
      }
      let u = c.length === 1 ? c[0] : ol(c) ?? { allOf: c };
      G(i, a, u);
    }
    for (let a of n.required ?? [])
      o.add(a);
  }
  let t = { type: "object", properties: i };
  if (o.size && (t.required = [...o]), r.every((n) => n.additionalProperties === !1))
    t.additionalProperties = !1;
  else {
    let n = [];
    for (let a of r) {
      let c = $p(a);
      c && !n.some((u) => JSON.stringify(u) === JSON.stringify(c)) && n.push(c);
    }
    n.length === 1 ? t.additionalProperties = n[0] : n.length > 1 && (t.additionalProperties = { allOf: n });
  }
  return t;
}
s(ol, "foldObjects");
function gx(e) {
  let r = e.allOf;
  if (!Array.isArray(r) || r.length < 2)
    return;
  for (let t of xp)
    if (t in e)
      return;
  let i = r.filter((t) => bp.some((n) => Array.isArray(t[n]))), o = null;
  if (!i.length)
    o = ol(r);
  else {
    let t = i[0], n = bp.find((u) => Array.isArray(t[u]));
    if (Object.keys(t).length !== 1)
      return;
    let a = r.filter((u) => u !== t), c = t[n].map((u) => ol([...a, u]));
    if (c.some((u) => !u))
      return;
    o = { [n]: c };
  }
  o && (delete e.allOf, qr(e, o));
}
s(gx, "foldIntersection");
function Me(e, r) {
  let i = e.seen.get(r);
  if (!i)
    throw new Error("Unprocessed schema. This is a bug in Zod.");
  let o = /* @__PURE__ */ s((c) => {
    let u = e.seen.get(c);
    if (u.ref === null)
      return;
    let l = u.def ?? u.schema, f = { ...l }, m = u.ref;
    if (u.ref = null, m) {
      o(m);
      let y = e.seen.get(m), b = y.schema;
      if (b.$ref && (e.target === "draft-07" || e.target === "draft-04" || e.target === "openapi-3.0") ? (l.allOf = l.allOf ?? [], l.allOf.push(b)) : qr(l, b), qr(l, f), c._zod.parent === m)
        for (let O in l)
          O === "$ref" || O === "allOf" || O in f || delete l[O];
      if (b.$ref && y.def)
        for (let O in l)
          O === "$ref" || O === "allOf" || O in y.def && JSON.stringify(l[O]) === JSON.stringify(y.def[O]) && delete l[O];
    }
    let v = c._zod.parent;
    if (v && v !== m) {
      o(v);
      let y = e.seen.get(v);
      if (y?.schema.$ref && (l.$ref = y.schema.$ref, y.def))
        for (let b in l)
          b === "$ref" || b === "allOf" || b in y.def && JSON.stringify(l[b]) === JSON.stringify(y.def[b]) && delete l[b];
    }
    e.override({
      zodSchema: c,
      jsonSchema: l,
      path: u.path ?? []
    });
  }, "flattenRef");
  if (!e.external || e.sharedEmitDoneFor !== e.external) {
    for (let c of [...e.seen.entries()].reverse())
      o(c[0]);
    if (e.target !== "openapi-3.0")
      for (let c of e.seen.entries())
        _p(c[1].def ?? c[1].schema);
    for (let c of e.deferred)
      c();
    if (e.intersections.length) {
      let c = /* @__PURE__ */ new Map();
      for (let u of e.seen.values())
        for (let l of [u.schema, u.def]) {
          let f = l?.allOf;
          if (!Array.isArray(f))
            continue;
          let m = c.get(f);
          m ? m.push(l) : c.set(f, [l]);
        }
      for (let u of e.intersections)
        for (let l of c.get(u) ?? [])
          gx(l);
    }
  }
  let t = {};
  if (e.target === "draft-2020-12" ? t.$schema = "https://json-schema.org/draft/2020-12/schema" : e.target === "draft-07" ? t.$schema = "http://json-schema.org/draft-07/schema#" : e.target === "draft-04" ? t.$schema = "http://json-schema.org/draft-04/schema#" : e.target, e.external?.uri) {
    let c = e.external.registry.get(r)?.id;
    if (!c)
      throw new Error("Schema is missing an `id` property");
    t.$id = e.external.uri(c);
  }
  qr(t, i.defId ? i.schema : i.def ?? i.schema);
  let n = e.metadataRegistry.get(r)?.id;
  n !== void 0 && t.id === n && delete t.id;
  let a = e.external?.defs ?? {};
  if (!e.external || e.sharedEmitDoneFor !== e.external)
    for (let c of e.seen.entries()) {
      let u = c[1];
      u.def && u.defId && (u.def.id === u.defId && delete u.def.id, G(a, u.defId, u.def));
    }
  e.external && (e.sharedEmitDoneFor = e.external), e.external || Object.keys(a).length > 0 && (e.target === "draft-2020-12" ? t.$defs = a : t.definitions = a);
  try {
    let c = JSON.parse(JSON.stringify(t));
    return Object.defineProperty(c, "~standard", {
      value: {
        ...r["~standard"],
        jsonSchema: {
          input: Wt(r, "input", e.processors),
          output: Wt(r, "output", e.processors)
        }
      },
      enumerable: !1,
      writable: !1
    }), c;
  } catch {
    throw new Error("Error converting schema to JSON.");
  }
}
s(Me, "finalize");
function ie(e, r) {
  let i = r ?? { seen: /* @__PURE__ */ new Set() };
  if (i.seen.has(e))
    return !1;
  i.seen.add(e);
  let o = e._zod.def;
  if (o.type === "transform")
    return !0;
  if (o.type === "array")
    return ie(o.element, i);
  if (o.type === "set")
    return ie(o.valueType, i);
  if (o.type === "lazy")
    return ie(o.getter(), i);
  if (o.type === "promise" || o.type === "optional" || o.type === "nonoptional" || o.type === "nullable" || o.type === "readonly" || o.type === "default" || o.type === "prefault" || o.type === "catch")
    return ie(o.innerType, i);
  if (o.type === "intersection")
    return ie(o.left, i) || ie(o.right, i);
  if (o.type === "record" || o.type === "map")
    return ie(o.keyType, i) || ie(o.valueType, i);
  if (o.type === "pipe")
    return e._zod.traits.has("$ZodCodec") ? !0 : ie(o.in, i) || ie(o.out, i);
  if (o.type === "object") {
    for (let t in o.shape)
      if (ie(o.shape[t], i))
        return !0;
    return !1;
  }
  if (o.type === "union") {
    for (let t of o.options)
      if (ie(t, i))
        return !0;
    return !1;
  }
  if (o.type === "tuple") {
    for (let t of o.items)
      if (ie(t, i))
        return !0;
    return !!(o.rest && ie(o.rest, i));
  }
  return !1;
}
s(ie, "isTransforming");
var al = /* @__PURE__ */ s((e, r = {}) => (i) => {
  let o = Le({ ...i, processors: r });
  return F(e, o), Ve(o, e), Me(o, e);
}, "createToJSONSchemaMethod"), Wt = /* @__PURE__ */ s((e, r, i = {}) => (o) => {
  let { libraryOptions: t, target: n } = o ?? {}, a = Le({ ...t ?? {}, target: n, io: r, processors: i });
  return F(e, a), Ve(a, e), Me(a, e);
}, "createStandardJSONSchemaMethod");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/json-schema-processors.js
var vx = {
  guid: "uuid",
  url: "uri",
  datetime: "date-time",
  json_string: "json-string",
  regex: ""
  // do not set
}, ul = /* @__PURE__ */ s((e, r, i, o) => {
  let t = i;
  t.type = "string";
  let { minimum: n, maximum: a, format: c, patterns: u, contentEncoding: l, laxFormat: f } = e._zod.bag;
  if (typeof n == "number" && (t.minLength = n), typeof a == "number" && (t.maxLength = a), c && (t.format = vx[c] ?? c, t.format === "" && delete t.format, (c === "time" || f) && delete t.format), l && (t.contentEncoding = l), u && u.size > 0) {
    let m = [...u];
    m.length === 1 ? t.pattern = m[0].source : m.length > 1 && (t.allOf = [
      ...m.map((v) => ({
        ...r.target === "draft-07" || r.target === "draft-04" || r.target === "openapi-3.0" ? { type: "string" } : {},
        pattern: v.source
      }))
    ]);
  }
}, "stringProcessor"), ll = /* @__PURE__ */ s((e, r, i, o) => {
  let t = i, { minimum: n, maximum: a, format: c, multipleOf: u, exclusiveMaximum: l, exclusiveMinimum: f } = e._zod.bag;
  typeof c == "string" && c.includes("int") ? t.type = "integer" : t.type = "number";
  let m = typeof f == "number" && f >= (n ?? Number.NEGATIVE_INFINITY), v = typeof l == "number" && l <= (a ?? Number.POSITIVE_INFINITY), y = r.target === "draft-04" || r.target === "openapi-3.0";
  m ? y ? (t.minimum = f, t.exclusiveMinimum = !0) : t.exclusiveMinimum = f : typeof n == "number" && (t.minimum = n), v ? y ? (t.maximum = l, t.exclusiveMaximum = !0) : t.exclusiveMaximum = l : typeof a == "number" && (t.maximum = a), typeof u == "number" && (Number.isFinite(u) && u !== 0 ? t.multipleOf = Math.abs(u) : H(e, r, t, o, `A multipleOf divisor of ${u} cannot be represented in JSON Schema`));
}, "numberProcessor"), dl = /* @__PURE__ */ s((e, r, i, o) => {
  i.type = "boolean";
}, "booleanProcessor"), fl = /* @__PURE__ */ s((e, r, i, o) => {
  H(e, r, i, o, "BigInt cannot be represented in JSON Schema");
}, "bigintProcessor"), pl = /* @__PURE__ */ s((e, r, i, o) => {
  H(e, r, i, o, "Symbols cannot be represented in JSON Schema");
}, "symbolProcessor"), ml = /* @__PURE__ */ s((e, r, i, o) => {
  r.target === "openapi-3.0" ? (i.type = "string", i.nullable = !0, i.enum = [null]) : i.type = "null";
}, "nullProcessor"), hl = /* @__PURE__ */ s((e, r, i, o) => {
  H(e, r, i, o, "Undefined cannot be represented in JSON Schema");
}, "undefinedProcessor"), gl = /* @__PURE__ */ s((e, r, i, o) => {
  H(e, r, i, o, "Void cannot be represented in JSON Schema");
}, "voidProcessor"), vl = /* @__PURE__ */ s((e, r, i, o) => {
  i.not = {};
}, "neverProcessor"), yl = /* @__PURE__ */ s((e, r, i, o) => {
}, "anyProcessor"), bl = /* @__PURE__ */ s((e, r, i, o) => {
}, "unknownProcessor"), $l = /* @__PURE__ */ s((e, r, i, o) => {
  H(e, r, i, o, "Date cannot be represented in JSON Schema");
}, "dateProcessor"), _l = /* @__PURE__ */ s((e, r, i, o) => {
  let t = e._zod.def, n = pr(t.entries);
  if (n.length === 0) {
    i.not = {};
    return;
  }
  n.every((a) => typeof a == "number") && (i.type = "number"), n.every((a) => typeof a == "string") && (i.type = "string"), i.enum = n;
}, "enumProcessor"), xl = /* @__PURE__ */ s((e, r, i, o) => {
  let t = e._zod.def;
  if (t.values.length === 0) {
    i.not = {};
    return;
  }
  let n = [];
  for (let a of t.values)
    if (a === void 0) {
      if (H(e, r, i, o, "Literal `undefined` cannot be represented in JSON Schema"))
        return;
    } else if (typeof a == "bigint") {
      if (H(e, r, i, o, "BigInt literals cannot be represented in JSON Schema"))
        return;
      n.push(Number(a));
    } else
      n.push(a);
  if (n.length !== 0)
    if (n.length === 1) {
      let a = n[0];
      i.type = a === null ? "null" : typeof a, r.target === "draft-04" || r.target === "openapi-3.0" ? i.enum = [a] : i.const = a;
    } else
      n.every((a) => typeof a == "number") && (i.type = "number"), n.every((a) => typeof a == "string") && (i.type = "string"), n.every((a) => typeof a == "boolean") && (i.type = "boolean"), n.every((a) => a === null) && (i.type = "null"), i.enum = n;
}, "literalProcessor"), wl = /* @__PURE__ */ s((e, r, i, o) => {
  H(e, r, i, o, "NaN cannot be represented in JSON Schema");
}, "nanProcessor"), kl = /* @__PURE__ */ s((e, r, i, o) => {
  let t = i, n = e._zod.pattern;
  if (!n)
    throw new Error("Pattern not found in template literal");
  t.type = "string", t.pattern = n.source;
}, "templateLiteralProcessor"), Il = /* @__PURE__ */ s((e, r, i, o) => {
  let t = i, n = {
    type: "string",
    format: "binary",
    contentEncoding: "binary"
  }, { minimum: a, maximum: c, mime: u } = e._zod.bag;
  a !== void 0 && (n.minLength = a), c !== void 0 && (n.maxLength = c), u ? u.length === 1 ? (n.contentMediaType = u[0], Object.assign(t, n)) : (Object.assign(t, n), t.anyOf = u.map((l) => ({ contentMediaType: l }))) : Object.assign(t, n);
}, "fileProcessor"), zl = /* @__PURE__ */ s((e, r, i, o) => {
  i.type = "boolean";
}, "successProcessor"), Sl = /* @__PURE__ */ s((e, r, i, o) => {
  H(e, r, i, o, "Custom types cannot be represented in JSON Schema");
}, "customProcessor"), Ol = /* @__PURE__ */ s((e, r, i, o) => {
  H(e, r, i, o, "Function types cannot be represented in JSON Schema");
}, "functionProcessor"), jl = /* @__PURE__ */ s((e, r, i, o) => {
  H(e, r, i, o, "Transforms cannot be represented in JSON Schema");
}, "transformProcessor"), Al = /* @__PURE__ */ s((e, r, i, o) => {
  H(e, r, i, o, "Map cannot be represented in JSON Schema");
}, "mapProcessor"), Pl = /* @__PURE__ */ s((e, r, i, o) => {
  H(e, r, i, o, "Set cannot be represented in JSON Schema");
}, "setProcessor"), Dl = /* @__PURE__ */ s((e, r, i, o) => {
  let t = i, n = e._zod.def, { minimum: a, maximum: c } = e._zod.bag;
  typeof a == "number" && (t.minItems = a), typeof c == "number" && (t.maxItems = c), t.type = "array", t.items = F(n.element, r, {
    ...o,
    path: [...o.path, "items"]
  });
}, "arrayProcessor");
function Kr(e) {
  let r = e._zod.def;
  return r.type === "pipe" && r.in._zod.traits.has("$ZodTransform") ? Kr(r.out) : r.type === "catch" ? Kr(r.innerType) : e._zod.optin;
}
s(Kr, "inputOptin");
var Nl = /* @__PURE__ */ s((e, r, i, o) => {
  let t = i, n = e._zod.def, a = n.shape;
  if (Object.getOwnPropertySymbols(a).length && H(e, r, t, o, "Symbol keys cannot be represented in JSON Schema"))
    return;
  t.type = "object", t.properties = {};
  for (let f in a)
    G(t.properties, f, F(a[f], r, {
      ...o,
      path: [...o.path, "properties", f]
    }));
  let u = new Set(Object.keys(a)), l = new Set([...u].filter((f) => {
    let m = n.shape[f];
    return r.io === "input" ? Kr(m) === void 0 : m._zod.optout === void 0;
  }));
  l.size > 0 && (t.required = Array.from(l)), n.catchall?._zod.def.type === "never" ? t.additionalProperties = !1 : n.catchall ? n.catchall && (t.additionalProperties = F(n.catchall, r, {
    ...o,
    path: [...o.path, "additionalProperties"]
  })) : r.io === "output" && (t.additionalProperties = !1);
}, "objectProcessor"), Vi = /* @__PURE__ */ s((e, r, i, o) => {
  let t = e._zod.def, n = t.inclusive === !1, a = t.options.map((c, u) => F(c, r, {
    ...o,
    path: [...o.path, n ? "oneOf" : "anyOf", u]
  }));
  n ? i.oneOf = a : i.anyOf = a;
}, "unionProcessor"), Tl = /* @__PURE__ */ s((e, r, i, o) => {
  let t = e._zod.def, n = F(t.left, r, {
    ...o,
    path: [...o.path, "allOf", 0]
  }), a = F(t.right, r, {
    ...o,
    path: [...o.path, "allOf", 1]
  }), c = /* @__PURE__ */ s((l) => "allOf" in l && Object.keys(l).length === 1, "isSimpleIntersection"), u = [
    ...c(n) ? n.allOf : [n],
    ...c(a) ? a.allOf : [a]
  ];
  i.allOf = u, r.intersections.push(u);
}, "intersectionProcessor"), Ul = /* @__PURE__ */ s((e, r, i, o) => {
  let t = i, n = e._zod.def;
  t.type = "array";
  let a = r.target === "draft-2020-12" ? "prefixItems" : "items", c = r.target === "draft-2020-12" || r.target === "openapi-3.0" ? "items" : "additionalItems", u = n.items.map((z, O) => F(z, r, {
    ...o,
    path: [...o.path, a, O]
  })), l = n.rest ? F(n.rest, r, {
    ...o,
    path: [...o.path, c, ...r.target === "openapi-3.0" ? [n.items.length] : []]
  }) : null, f = n.items.length;
  for (; f > 0; ) {
    let z = n.items[f - 1];
    if (!(r.io === "input" ? Kr(z) !== void 0 : z._zod.optout === "optional"))
      break;
    f--;
  }
  let m = n.items.length, v = !n.rest;
  r.target === "draft-2020-12" ? (t.prefixItems = u, v ? t.items = !1 : l && (t.items = l), f > 0 && (t.minItems = f), v && (t.maxItems = m)) : r.target === "openapi-3.0" ? (t.items = {
    anyOf: u
  }, l && t.items.anyOf.push(l), f > 0 && (t.minItems = f), v && (t.maxItems = m)) : (t.items = u, v ? t.additionalItems = !1 : l && (t.additionalItems = l), f > 0 && (t.minItems = f), v && (t.maxItems = m));
  let { minimum: y, maximum: b } = e._zod.bag;
  typeof y == "number" && (t.minItems = y), typeof b == "number" && (t.maxItems = b);
}, "tupleProcessor");
function sl(e, r, i) {
  if (r.$ref) {
    if (i.has(r))
      return r;
    i.add(r);
    let b = e.get(r)?.def;
    if (!b)
      return r;
    let z = sl(e, b, i);
    return z === b ? r : z;
  }
  for (let b of ["anyOf", "oneOf"]) {
    let z = r[b];
    if (!Array.isArray(z))
      continue;
    let O = z.map((L) => sl(e, L, i));
    O.some((L, A) => L !== z[A]) && (r = { ...r, [b]: O });
  }
  let o = Array.isArray(r.type) ? r.type : [r.type], t = !o.includes("string") && o.some((b) => b === "number" || b === "integer"), n = r.enum ?? (r.const !== void 0 ? [r.const] : void 0);
  if (!t && !n?.some((b) => typeof b == "number"))
    return r;
  let { minimum: a, maximum: c, exclusiveMinimum: u, exclusiveMaximum: l, multipleOf: f, format: m, id: v, ...y } = r;
  return y.enum ? y.enum = y.enum.map((b) => typeof b == "number" ? String(b) : b) : typeof y.const == "number" && (y.const = String(y.const)), t && (y.type = "string", n || (y.pattern = (o.includes("number") ? Ze : wr).source)), y;
}
s(sl, "stringifyKeyNames");
var cl = /* @__PURE__ */ new WeakMap();
function yx(e) {
  let r = /* @__PURE__ */ new Map();
  for (let o of e.seen.values())
    o.def && !r.has(o.schema) && r.set(o.schema, o);
  let i = /* @__PURE__ */ new Map();
  for (let o of cl.get(e) ?? []) {
    let t = e.seen.get(o), n = (t?.def ?? t?.schema)?.propertyNames;
    if (!n || n === !0 || i.has(n))
      continue;
    let a = sl(r, n, /* @__PURE__ */ new Set());
    a !== n && i.set(n, a);
  }
  if (i.size)
    for (let o of e.seen.values())
      for (let t of [o.schema, o.def]) {
        let n = t && i.get(t.propertyNames);
        n && (t.propertyNames = n);
      }
}
s(yx, "rewriteKeyNames");
var El = /* @__PURE__ */ s((e, r, i, o) => {
  let t = i, n = e._zod.def;
  t.type = "object";
  let a = n.keyType, u = a._zod.bag?.patterns;
  if (n.mode === "loose" && u && u.size > 0) {
    let m = F(n.valueType, r, {
      ...o,
      path: [...o.path, "patternProperties", "*"]
    });
    t.patternProperties = {};
    for (let v of u)
      G(t.patternProperties, v.source, m);
  } else {
    if (r.target === "draft-07" || r.target === "draft-2020-12") {
      t.propertyNames = F(n.keyType, r, {
        ...o,
        path: [...o.path, "propertyNames"]
      });
      let m = cl.get(r);
      m || (m = [], cl.set(r, m), r.deferred.push(() => yx(r))), m.push(e);
    }
    t.additionalProperties = F(n.valueType, r, {
      ...o,
      path: [...o.path, "additionalProperties"]
    });
  }
  let l = a._zod.values, f = r.io === "input" && Kr(n.valueType) !== void 0;
  if (l && !n.partial && !f) {
    let m = [...l].filter((v) => typeof v == "string" || typeof v == "number");
    m.length > 0 && (t.required = m.map(String));
  }
}, "recordProcessor"), Cl = /* @__PURE__ */ s((e, r, i, o) => {
  let t = e._zod.def, n = F(t.innerType, r, o), a = r.seen.get(e);
  r.target === "openapi-3.0" ? (a.ref = t.innerType, i.nullable = !0) : i.anyOf = [n, { type: "null" }];
}, "nullableProcessor"), Zl = /* @__PURE__ */ s((e, r, i, o) => {
  let t = e._zod.def;
  F(t.innerType, r, o);
  let n = r.seen.get(e);
  n.ref = t.innerType;
}, "nonoptionalProcessor"), Rl = Symbol();
function wp(e, r, i, o, t) {
  let n = !1, a = JSON.stringify(e, (c, u) => typeof u != "bigint" ? u : (n = !0, null));
  return n ? (H(r, i, o, t, "BigInt defaults cannot be represented in JSON Schema"), Rl) : JSON.parse(a);
}
s(wp, "serializeDefaultValue");
var Fl = /* @__PURE__ */ s((e, r, i, o) => {
  let t = e._zod.def;
  F(t.innerType, r, o);
  let n = r.seen.get(e);
  n.ref = t.innerType;
  let a = wp(t.defaultValue, e, r, i, o);
  a !== Rl && (i.default = a);
}, "defaultProcessor"), Ll = /* @__PURE__ */ s((e, r, i, o) => {
  let t = e._zod.def;
  F(t.innerType, r, o);
  let n = r.seen.get(e);
  if (n.ref = t.innerType, r.io !== "input")
    return;
  let a = wp(t.defaultValue, e, r, i, o);
  a !== Rl && (i._prefault = a);
}, "prefaultProcessor"), Vl = /* @__PURE__ */ s((e, r, i, o) => {
  let t = e._zod.def;
  F(t.innerType, r, o);
  let n = r.seen.get(e);
  n.ref = t.innerType;
  let a;
  try {
    a = t.catchValue(void 0);
  } catch {
    H(e, r, i, o, "Dynamic catch values are not supported in JSON Schema");
    return;
  }
  i.default = a;
}, "catchProcessor"), Ml = /* @__PURE__ */ s((e, r, i, o) => {
  let t = e._zod.def, n = t.in._zod.traits.has("$ZodTransform"), a = r.io === "input" ? n ? t.out : t.in : t.out;
  F(a, r, o);
  let c = r.seen.get(e);
  c.ref = a;
}, "pipeProcessor"), Bl = /* @__PURE__ */ s((e, r, i, o) => {
  let t = e._zod.def;
  F(t.innerType, r, o);
  let n = r.seen.get(e);
  n.ref = t.innerType, i.readOnly = !0;
}, "readonlyProcessor"), Jl = /* @__PURE__ */ s((e, r, i, o) => {
  let t = e._zod.def;
  F(t.innerType, r, o);
  let n = r.seen.get(e);
  n.ref = t.innerType;
}, "promiseProcessor"), Mi = /* @__PURE__ */ s((e, r, i, o) => {
  let t = e._zod.def;
  F(t.innerType, r, o);
  let n = r.seen.get(e);
  n.ref = t.innerType;
}, "optionalProcessor"), ql = /* @__PURE__ */ s((e, r, i, o) => {
  let t = e._zod.innerType;
  F(t, r, o);
  let n = r.seen.get(e);
  n.ref = t;
}, "lazyProcessor"), Li = {
  string: ul,
  number: ll,
  boolean: dl,
  bigint: fl,
  symbol: pl,
  null: ml,
  undefined: hl,
  void: gl,
  never: vl,
  any: yl,
  unknown: bl,
  date: $l,
  enum: _l,
  literal: xl,
  nan: wl,
  template_literal: kl,
  file: Il,
  success: zl,
  custom: Sl,
  function: Ol,
  transform: jl,
  map: Al,
  set: Pl,
  array: Dl,
  object: Nl,
  union: Vi,
  intersection: Tl,
  tuple: Ul,
  record: El,
  nullable: Cl,
  nonoptional: Zl,
  default: Fl,
  prefault: Ll,
  catch: Vl,
  pipe: Ml,
  readonly: Bl,
  promise: Jl,
  optional: Mi,
  lazy: ql
};
function Bi(e, r) {
  if ("_idmap" in e) {
    let o = e, t = Le({ ...r, processors: Li }), n = {};
    for (let u of o._idmap.entries()) {
      let [l, f] = u;
      F(f, t);
    }
    let a = {}, c = {
      registry: o,
      uri: r?.uri,
      defs: n
    };
    t.external = c;
    for (let u of o._idmap.entries()) {
      let [l, f] = u;
      Ve(t, f), G(a, l, Me(t, f));
    }
    if (Object.keys(n).length > 0) {
      let u = t.target === "draft-2020-12" ? "$defs" : "definitions";
      a.__shared = {
        [u]: n
      };
    }
    return { schemas: a };
  }
  let i = Le({ ...r, processors: Li });
  return F(e, i), Ve(i, e), Me(i, e);
}
s(Bi, "toJSONSchema");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/json-schema-generator.js
var Ji = class {
  static {
    s(this, "JSONSchemaGenerator");
  }
  /** @deprecated Access via ctx instead */
  get metadataRegistry() {
    return this.ctx.metadataRegistry;
  }
  /** @deprecated Access via ctx instead */
  get target() {
    return this.ctx.target;
  }
  // annotated so the .d.cts emits an indexed access rather than an inline `import()` of an ESM path
  /** @deprecated Access via ctx instead */
  get unrepresentable() {
    return this.ctx.unrepresentable;
  }
  /** @deprecated Access via ctx instead */
  get override() {
    return this.ctx.override;
  }
  /** @deprecated Access via ctx instead */
  get io() {
    return this.ctx.io;
  }
  /** @deprecated Access via ctx instead */
  get counter() {
    return this.ctx.counter;
  }
  set counter(r) {
    this.ctx.counter = r;
  }
  /** @deprecated Access via ctx instead */
  get seen() {
    return this.ctx.seen;
  }
  constructor(r) {
    let i = r?.target ?? "draft-2020-12";
    i === "draft-4" && (i = "draft-04"), i === "draft-7" && (i = "draft-07"), this.ctx = Le({
      processors: Li,
      target: i,
      ...r?.metadata && { metadata: r.metadata },
      ...r?.unrepresentable && { unrepresentable: r.unrepresentable },
      ...r?.override && { override: r.override },
      ...r?.io && { io: r.io }
    });
  }
  /**
   * Process a schema to prepare it for JSON Schema generation.
   * This must be called before emit().
   */
  process(r, i = { path: [], schemaPath: [] }) {
    return F(r, this.ctx, i);
  }
  /**
   * Emit the final JSON Schema after processing.
   * Must call process() first.
   */
  emit(r, i) {
    i && (i.cycles && (this.ctx.cycles = i.cycles), i.reused && (this.ctx.reused = i.reused), i.external && (this.ctx.external = i.external)), this.ctx.sharedDefsExtractedFor = void 0, this.ctx.sharedEmitDoneFor = void 0, Ve(this.ctx, r);
    let o = Me(this.ctx, r), { "~standard": t, ...n } = o;
    return n;
  }
};

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/json-schema.js
var kp = {};

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/schemas.js
var nr = {};
Pe(nr, {
  ZodAny: () => pd,
  ZodArray: () => vd,
  ZodBase64: () => lo,
  ZodBase64URL: () => fo,
  ZodBigInt: () => tr,
  ZodBigIntFormat: () => ho,
  ZodBoolean: () => er,
  ZodCIDRv4: () => co,
  ZodCIDRv6: () => uo,
  ZodCUID: () => to,
  ZodCUID2: () => ro,
  ZodCatch: () => Zd,
  ZodCodec: () => nn,
  ZodCreditCard: () => ad,
  ZodCustom: () => on,
  ZodCustomStringFormat: () => Qt,
  ZodDate: () => Hr,
  ZodDefault: () => Dd,
  ZodDiscriminatedUnion: () => bd,
  ZodE164: () => po,
  ZodEmail: () => Hi,
  ZodEmoji: () => Yi,
  ZodEnum: () => Xt,
  ZodExactOptional: () => bo,
  ZodFile: () => Od,
  ZodFunction: () => Wd,
  ZodGUID: () => Qi,
  ZodIPv4: () => ao,
  ZodIPv6: () => so,
  ZodISODate: () => Je,
  ZodISODateTime: () => Be,
  ZodISODuration: () => Ke,
  ZodISOTime: () => qe,
  ZodIntersection: () => $d,
  ZodJWT: () => mo,
  ZodKSUID: () => oo,
  ZodLazy: () => Jd,
  ZodLiteral: () => Sd,
  ZodMAC: () => od,
  ZodMap: () => Id,
  ZodNaN: () => Fd,
  ZodNanoID: () => eo,
  ZodNever: () => hd,
  ZodNonOptional: () => $o,
  ZodNull: () => dd,
  ZodNullable: () => Pd,
  ZodNumber: () => Yt,
  ZodNumberFormat: () => vt,
  ZodObject: () => Yr,
  ZodOptional: () => tn,
  ZodPipe: () => rn,
  ZodPrefault: () => Td,
  ZodPreprocess: () => Ld,
  ZodPromise: () => Kd,
  ZodReadonly: () => Vd,
  ZodRecord: () => Gt,
  ZodSet: () => zd,
  ZodString: () => Ht,
  ZodStringFormat: () => M,
  ZodSuccess: () => Cd,
  ZodSymbol: () => ud,
  ZodTemplateLiteral: () => Bd,
  ZodTransform: () => jd,
  ZodTuple: () => xd,
  ZodType: () => U,
  ZodULID: () => no,
  ZodURL: () => Xr,
  ZodUUID: () => je,
  ZodUndefined: () => ld,
  ZodUnion: () => en,
  ZodUnknown: () => md,
  ZodVoid: () => gd,
  ZodXID: () => io,
  ZodXor: () => yd,
  _ZodString: () => Xi,
  _default: () => Nd,
  _function: () => Tm,
  any: () => dm,
  array: () => Qr,
  base64: () => Kp,
  base64url: () => Wp,
  bigint: () => am,
  boolean: () => cd,
  catch: () => Rd,
  check: () => Um,
  cidrv4: () => Jp,
  cidrv6: () => qp,
  codec: () => Am,
  creditCard: () => Xp,
  cuid: () => Cp,
  cuid2: () => Zp,
  custom: () => Em,
  date: () => pm,
  describe: () => Cm,
  discriminatedUnion: () => bm,
  e164: () => Gp,
  email: () => Sp,
  emoji: () => Up,
  enum: () => vo,
  exactOptional: () => Ad,
  file: () => zm,
  float32: () => rm,
  float64: () => nm,
  function: () => Tm,
  guid: () => Op,
  hash: () => tm,
  hex: () => em,
  hostname: () => Yp,
  httpUrl: () => Tp,
  instanceof: () => Rm,
  int: () => Wi,
  int32: () => im,
  int64: () => sm,
  intersection: () => _d,
  invertCodec: () => Pm,
  ipv4: () => Vp,
  ipv6: () => Bp,
  json: () => Lm,
  jwt: () => Hp,
  keyof: () => mm,
  ksuid: () => Lp,
  lazy: () => qd,
  literal: () => Im,
  looseObject: () => vm,
  looseRecord: () => _m,
  mac: () => Mp,
  map: () => xm,
  meta: () => Zm,
  nan: () => jm,
  nanoid: () => Ep,
  nativeEnum: () => km,
  never: () => go,
  nonoptional: () => Ed,
  null: () => fd,
  nullable: () => Gr,
  nullish: () => Sm,
  number: () => sd,
  object: () => hm,
  optional: () => ht,
  partialRecord: () => $m,
  pipe: () => Gi,
  prefault: () => Ud,
  preprocess: () => Vm,
  promise: () => Nm,
  readonly: () => Md,
  record: () => kd,
  refine: () => Gd,
  set: () => wm,
  strictObject: () => gm,
  string: () => Wr,
  stringFormat: () => Qp,
  stringbool: () => Fm,
  success: () => Om,
  superRefine: () => Xd,
  symbol: () => um,
  templateLiteral: () => Dm,
  transform: () => yo,
  tuple: () => wd,
  uint32: () => om,
  uint64: () => cm,
  ulid: () => Rp,
  undefined: () => lm,
  union: () => rr,
  unknown: () => mt,
  url: () => Np,
  uuid: () => jp,
  uuidv4: () => Ap,
  uuidv6: () => Pp,
  uuidv7: () => Dp,
  void: () => fm,
  xid: () => Fp,
  xor: () => ym
});

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/checks.js
var qi = {};
Pe(qi, {
  endsWith: () => Ft,
  gt: () => Se,
  gte: () => me,
  includes: () => Zt,
  length: () => pt,
  lowercase: () => Et,
  lt: () => ze,
  lte: () => pe,
  maxLength: () => ft,
  maxSize: () => Fe,
  mime: () => Lt,
  minLength: () => Ne,
  minSize: () => Oe,
  multipleOf: () => Re,
  negative: () => Ei,
  nonnegative: () => Zi,
  nonpositive: () => Ci,
  normalize: () => Vt,
  overwrite: () => xe,
  positive: () => Ui,
  properties: () => Fi,
  property: () => Ri,
  regex: () => Ut,
  size: () => dt,
  slugify: () => qt,
  startsWith: () => Rt,
  toLowerCase: () => Bt,
  toUpperCase: () => Jt,
  trim: () => Mt,
  uppercase: () => Ct
});

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/errors.js
var Ip = /* @__PURE__ */ new WeakSet([Object.prototype, Error.prototype]);
function Ki(e, r, i) {
  Object.defineProperty(e, r, {
    configurable: !0,
    enumerable: !1,
    get() {
      let o = i(this);
      return Object.defineProperty(this, r, { value: o, configurable: !0, writable: !0 }), o;
    },
    set(o) {
      Object.defineProperty(this, r, { value: o, configurable: !0, writable: !0 });
    }
  });
}
s(Ki, "_lazyMethod");
var zp = /* @__PURE__ */ s((e, r) => {
  et.init(e, r), e.name = "ZodError";
  let i = Object.getPrototypeOf(e);
  Ip.has(i) || (Ip.add(i), Ki(i, "format", (o) => (t) => _r(o, t)), Ki(i, "flatten", (o) => (t) => $r(o, t)), Ki(i, "addIssue", (o) => (t) => {
    o.issues.push(t), o.message = JSON.stringify(o.issues, xt, 2);
  }), Ki(i, "addIssues", (o) => (t) => {
    o.issues.push(...t), o.message = JSON.stringify(o.issues, xt, 2);
  }), Object.defineProperty(i, "isEmpty", {
    configurable: !0,
    enumerable: !1,
    get() {
      return this.issues.length === 0;
    }
  }));
}, "initializer"), $x = /* @__PURE__ */ h("ZodError", zp), le = /* @__PURE__ */ h("ZodError", zp, void 0, {
  Parent: Error
});

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/parse.js
var Kl = /* @__PURE__ */ It(le), Wl = /* @__PURE__ */ zt(le), Gl = /* @__PURE__ */ St(le), Xl = /* @__PURE__ */ Ot(le), Hl = /* @__PURE__ */ An(le), Ql = /* @__PURE__ */ Pn(le), Yl = /* @__PURE__ */ Dn(le), ed = /* @__PURE__ */ Nn(le), td = /* @__PURE__ */ Tn(le), rd = /* @__PURE__ */ Un(le), nd = /* @__PURE__ */ En(le), id = /* @__PURE__ */ Cn(le);

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/schemas.js
function xx() {
  Q.localeError || X(Er());
}
s(xx, "_ensureDefaultLocale");
function gt() {
  Q.memoizer || X({ memoizer: Ur() });
}
s(gt, "_ensureDefaultMemoizer");
var U = /* @__PURE__ */ h("ZodType", (e, r) => (xx(), P.init(e, r), e.def = r, e.type = r.type, e), {
  check(...e) {
    let r = this.def;
    return this.clone(k.mergeDefs(r, {
      checks: [
        ...r.checks ?? [],
        ...e.map((i) => typeof i == "function" ? { _zod: { check: i, def: { check: "custom" }, onattach: [] } } : i)
      ]
    }), { parent: !0 });
  },
  with(...e) {
    return this.check(...e);
  },
  clone(e, r) {
    return Z(this, e, r);
  },
  brand() {
    return this;
  },
  register(e, r) {
    return e.add(this, r), this;
  },
  refine(e, r) {
    return this.check(Gd(e, r));
  },
  superRefine(e, r) {
    return this.check(Xd(e, r));
  },
  overwrite(e) {
    return this.check(xe(e));
  },
  optional() {
    return ht(this);
  },
  exactOptional() {
    return Ad(this);
  },
  nullable() {
    return Gr(this);
  },
  nullish() {
    return ht(Gr(this));
  },
  nonoptional(e) {
    return Ed(this, e);
  },
  array() {
    return Qr(this);
  },
  or(e) {
    return rr([this, e]);
  },
  and(e) {
    return _d(this, e);
  },
  transform(e) {
    return Gi(this, yo(e));
  },
  default(e) {
    return Nd(this, e);
  },
  prefault(e) {
    return Ud(this, e);
  },
  catch(e) {
    return Rd(this, e);
  },
  pipe(e) {
    return Gi(this, e);
  },
  readonly() {
    return Md(this);
  },
  describe(e) {
    let r = this.clone();
    return Y.add(r, { description: e }), r;
  },
  meta(...e) {
    if (e.length === 0)
      return Y.get(this);
    let r = this.clone();
    return Y.add(r, e[0]), r;
  },
  isOptional() {
    return this.safeParse(void 0).success;
  },
  isNullable() {
    return this.safeParse(null).success;
  },
  apply(e, ...r) {
    return r.length === 0 ? e(this) : e(this, ...r);
  },
  // Overrides core's `~standard` to add `jsonSchema`. Must stay a prototype entry: redefining it per instance demotes instances to dictionary mode.
  get "~standard"() {
    return k.hide(this, "~standard", {
      ...Wn(this),
      jsonSchema: {
        input: Wt(this, "input"),
        output: Wt(this, "output")
      }
    });
  },
  set "~standard"(e) {
    k.own(this, "~standard", e);
  },
  parse: /* @__PURE__ */ s(function e(r, i) {
    return Kl(this, r, i, { callee: e });
  }, "_parse"),
  parseAsync: /* @__PURE__ */ s(async function e(r, i) {
    return await Wl(this, r, i, { callee: e });
  }, "_parseAsync"),
  safeParse(e, r) {
    return Gl(this, e, r);
  },
  async safeParseAsync(e, r) {
    return Xl(this, e, r);
  },
  // `spa` is an alias: same function object as `safeParseAsync`, as before.
  get spa() {
    return this?.safeParseAsync;
  },
  set spa(e) {
    k.own(this, "spa", e);
  },
  encode: /* @__PURE__ */ s(function e(r, i) {
    return Hl(this, r, i, { callee: e });
  }, "_encode"),
  decode: /* @__PURE__ */ s(function e(r, i) {
    return Ql(this, r, i, { callee: e });
  }, "_decode"),
  encodeAsync: /* @__PURE__ */ s(async function e(r, i) {
    return await Yl(this, r, i, { callee: e });
  }, "_encodeAsync"),
  decodeAsync: /* @__PURE__ */ s(async function e(r, i) {
    return await ed(this, r, i, { callee: e });
  }, "_decodeAsync"),
  safeEncode(e, r) {
    return td(this, e, r);
  },
  safeDecode(e, r) {
    return rd(this, e, r);
  },
  async safeEncodeAsync(e, r) {
    return nd(this, e, r);
  },
  async safeDecodeAsync(e, r) {
    return id(this, e, r);
  },
  toJSONSchema(e) {
    return al(this, {})(e);
  },
  // Reads through to the registry on every access, so it must not cache.
  get description() {
    return Y.get(this)?.description;
  },
  // No setter: `schema._def = x` throws, as it did when `_def` was a non-writable own property.
  get _def() {
    return this._zod.def;
  }
}), Xi = /* @__PURE__ */ h("_ZodString", (e, r) => {
  it.init(e, r), U.init(e, r), e._zod.processJSONSchema = (o, t, n) => ul(e, o, t, n);
  let i = e._zod.bag;
  e.format = i.format ?? null, e.minLength = i.minimum ?? null, e.maxLength = i.maximum ?? null;
}, {
  regex(...e) {
    return this.check(Ut(...e));
  },
  includes(...e) {
    return this.check(Zt(...e));
  },
  startsWith(...e) {
    return this.check(Rt(...e));
  },
  endsWith(...e) {
    return this.check(Ft(...e));
  },
  min(...e) {
    return this.check(Ne(...e));
  },
  max(...e) {
    return this.check(ft(...e));
  },
  length(...e) {
    return this.check(pt(...e));
  },
  nonempty(...e) {
    return this.check(Ne(1, ...e));
  },
  lowercase(e) {
    return this.check(Et(e));
  },
  uppercase(e) {
    return this.check(Ct(e));
  },
  trim() {
    return this.check(Mt());
  },
  normalize(...e) {
    return this.check(Vt(...e));
  },
  toLowerCase() {
    return this.check(Bt());
  },
  toUpperCase() {
    return this.check(Jt());
  },
  slugify() {
    return this.check(qt());
  }
}), Ht = /* @__PURE__ */ h("ZodString", (e, r) => {
  it.init(e, r), Xi.init(e, r);
}, {
  email(e) {
    return this.check(mi(Hi, e));
  },
  url(e) {
    return this.check(Lr(Xr, e));
  },
  jwt(e) {
    return this.check(Ti(mo, e));
  },
  emoji(e) {
    return this.check($i(Yi, e));
  },
  guid(e) {
    return this.check(hi(Qi, e));
  },
  uuid(e) {
    return this.check(gi(je, e));
  },
  uuidv4(e) {
    return this.check(vi(je, e));
  },
  uuidv6(e) {
    return this.check(yi(je, e));
  },
  uuidv7(e) {
    return this.check(bi(je, e));
  },
  nanoid(e) {
    return this.check(_i(eo, e));
  },
  cuid(e) {
    return this.check(xi(to, e));
  },
  cuid2(e) {
    return this.check(wi(ro, e));
  },
  ulid(e) {
    return this.check(ki(no, e));
  },
  base64(e) {
    return this.check(Pi(lo, e));
  },
  base64url(e) {
    return this.check(Di(fo, e));
  },
  xid(e) {
    return this.check(Ii(io, e));
  },
  ksuid(e) {
    return this.check(zi(oo, e));
  },
  ipv4(e) {
    return this.check(Si(ao, e));
  },
  ipv6(e) {
    return this.check(Oi(so, e));
  },
  cidrv4(e) {
    return this.check(ji(co, e));
  },
  cidrv6(e) {
    return this.check(Ai(uo, e));
  },
  e164(e) {
    return this.check(Ni(po, e));
  },
  datetime(e) {
    return this.check(Vr(Be, e));
  },
  date(e) {
    return this.check(Mr(Je, e));
  },
  time(e) {
    return this.check(Br(qe, e));
  },
  duration(e) {
    return this.check(Jr(Ke, e));
  }
});
function Wr(e) {
  return wu(Ht, e);
}
s(Wr, "string");
var M = /* @__PURE__ */ h("ZodStringFormat", (e, r) => {
  V.init(e, r), Xi.init(e, r);
}), Be = /* @__PURE__ */ h("ZodISODateTime", (e, r) => {
  ys.init(e, r), M.init(e, r);
}), Je = /* @__PURE__ */ h("ZodISODate", (e, r) => {
  bs.init(e, r), M.init(e, r);
}), qe = /* @__PURE__ */ h("ZodISOTime", (e, r) => {
  $s.init(e, r), M.init(e, r);
}), Ke = /* @__PURE__ */ h("ZodISODuration", (e, r) => {
  _s.init(e, r), M.init(e, r);
}), Hi = /* @__PURE__ */ h("ZodEmail", (e, r) => {
  ss.init(e, r), M.init(e, r);
});
function Sp(e) {
  return mi(Hi, e);
}
s(Sp, "email");
var Qi = /* @__PURE__ */ h("ZodGUID", (e, r) => {
  os.init(e, r), M.init(e, r);
});
function Op(e) {
  return hi(Qi, e);
}
s(Op, "guid");
var je = /* @__PURE__ */ h("ZodUUID", (e, r) => {
  as.init(e, r), M.init(e, r);
});
function jp(e) {
  return gi(je, e);
}
s(jp, "uuid");
function Ap(e) {
  return vi(je, e);
}
s(Ap, "uuidv4");
function Pp(e) {
  return yi(je, e);
}
s(Pp, "uuidv6");
function Dp(e) {
  return bi(je, e);
}
s(Dp, "uuidv7");
var Xr = /* @__PURE__ */ h("ZodURL", (e, r) => {
  ls.init(e, r), M.init(e, r);
});
function Np(e) {
  return Lr(Xr, e);
}
s(Np, "url");
function Tp(e) {
  return Lr(Xr, {
    protocol: re.httpProtocol,
    hostname: re.domain,
    ...k.normalizeParams(e)
  });
}
s(Tp, "httpUrl");
var Yi = /* @__PURE__ */ h("ZodEmoji", (e, r) => {
  ds.init(e, r), M.init(e, r);
});
function Up(e) {
  return $i(Yi, e);
}
s(Up, "emoji");
var eo = /* @__PURE__ */ h("ZodNanoID", (e, r) => {
  fs.init(e, r), M.init(e, r);
});
function Ep(e) {
  return _i(eo, e);
}
s(Ep, "nanoid");
var to = /* @__PURE__ */ h("ZodCUID", (e, r) => {
  ps.init(e, r), M.init(e, r);
});
function Cp(e) {
  return xi(to, e);
}
s(Cp, "cuid");
var ro = /* @__PURE__ */ h("ZodCUID2", (e, r) => {
  ms.init(e, r), M.init(e, r);
});
function Zp(e) {
  return wi(ro, e);
}
s(Zp, "cuid2");
var no = /* @__PURE__ */ h("ZodULID", (e, r) => {
  hs.init(e, r), M.init(e, r);
});
function Rp(e) {
  return ki(no, e);
}
s(Rp, "ulid");
var io = /* @__PURE__ */ h("ZodXID", (e, r) => {
  gs.init(e, r), M.init(e, r);
});
function Fp(e) {
  return Ii(io, e);
}
s(Fp, "xid");
var oo = /* @__PURE__ */ h("ZodKSUID", (e, r) => {
  vs.init(e, r), M.init(e, r);
});
function Lp(e) {
  return zi(oo, e);
}
s(Lp, "ksuid");
var ao = /* @__PURE__ */ h("ZodIPv4", (e, r) => {
  xs.init(e, r), M.init(e, r);
});
function Vp(e) {
  return Si(ao, e);
}
s(Vp, "ipv4");
var od = /* @__PURE__ */ h("ZodMAC", (e, r) => {
  ks.init(e, r), M.init(e, r);
});
function Mp(e) {
  return Iu(od, e);
}
s(Mp, "mac");
var so = /* @__PURE__ */ h("ZodIPv6", (e, r) => {
  ws.init(e, r), M.init(e, r);
});
function Bp(e) {
  return Oi(so, e);
}
s(Bp, "ipv6");
var co = /* @__PURE__ */ h("ZodCIDRv4", (e, r) => {
  Is.init(e, r), M.init(e, r);
});
function Jp(e) {
  return ji(co, e);
}
s(Jp, "cidrv4");
var uo = /* @__PURE__ */ h("ZodCIDRv6", (e, r) => {
  zs.init(e, r), M.init(e, r);
});
function qp(e) {
  return Ai(uo, e);
}
s(qp, "cidrv6");
var lo = /* @__PURE__ */ h("ZodBase64", (e, r) => {
  Ss.init(e, r), M.init(e, r);
});
function Kp(e) {
  return Pi(lo, e);
}
s(Kp, "base64");
var fo = /* @__PURE__ */ h("ZodBase64URL", (e, r) => {
  Os.init(e, r), M.init(e, r);
});
function Wp(e) {
  return Di(fo, e);
}
s(Wp, "base64url");
var po = /* @__PURE__ */ h("ZodE164", (e, r) => {
  js.init(e, r), M.init(e, r);
});
function Gp(e) {
  return Ni(po, e);
}
s(Gp, "e164");
var ad = /* @__PURE__ */ h("ZodCreditCard", (e, r) => {
  As.init(e, r), M.init(e, r);
});
function Xp(e) {
  return zu(ad, e);
}
s(Xp, "creditCard");
var mo = /* @__PURE__ */ h("ZodJWT", (e, r) => {
  Ps.init(e, r), M.init(e, r);
});
function Hp(e) {
  return Ti(mo, e);
}
s(Hp, "jwt");
var Qt = /* @__PURE__ */ h("ZodCustomStringFormat", (e, r) => {
  Ds.init(e, r), M.init(e, r);
});
function Qp(e, r, i = {}) {
  return Kt(Qt, e, r, i);
}
s(Qp, "stringFormat");
function Yp(e) {
  return Kt(Qt, "hostname", re.hostname, e);
}
s(Yp, "hostname");
function em(e) {
  return Kt(Qt, "hex", re.hex, e);
}
s(em, "hex");
function tm(e, r) {
  let i = r?.enc ?? "hex", o = `${e}_${i}`, t = re[o];
  if (!t)
    throw new Error(`Unrecognized hash format: ${o}`);
  return Kt(Qt, o, t, r);
}
s(tm, "hash");
var Yt = /* @__PURE__ */ h("ZodNumber", (e, r) => {
  ni.init(e, r), U.init(e, r), e._zod.processJSONSchema = (o, t, n) => ll(e, o, t, n);
  let i = e._zod.bag;
  e.minValue = Math.max(i.minimum ?? Number.NEGATIVE_INFINITY, i.exclusiveMinimum ?? Number.NEGATIVE_INFINITY) ?? null, e.maxValue = Math.min(i.maximum ?? Number.POSITIVE_INFINITY, i.exclusiveMaximum ?? Number.POSITIVE_INFINITY) ?? null, e.isInt = (i.format ?? "").includes("int") || Number.isSafeInteger(i.multipleOf ?? 0.5), e.isFinite = !0, e.format = i.format ?? null;
}, {
  gt(e, r) {
    return this.check(Se(e, r));
  },
  gte(e, r) {
    return this.check(me(e, r));
  },
  min(e, r) {
    return this.check(me(e, r));
  },
  lt(e, r) {
    return this.check(ze(e, r));
  },
  lte(e, r) {
    return this.check(pe(e, r));
  },
  max(e, r) {
    return this.check(pe(e, r));
  },
  int(e) {
    return this.check(Wi(e));
  },
  safe(e) {
    return this.check(Wi(e));
  },
  positive(e) {
    return this.check(Se(0, e));
  },
  nonnegative(e) {
    return this.check(me(0, e));
  },
  negative(e) {
    return this.check(ze(0, e));
  },
  nonpositive(e) {
    return this.check(pe(0, e));
  },
  multipleOf(e, r) {
    return this.check(Re(e, r));
  },
  step(e, r) {
    return this.check(Re(e, r));
  },
  finite() {
    return this;
  }
});
function sd(e) {
  return Ou(Yt, e);
}
s(sd, "number");
var vt = /* @__PURE__ */ h("ZodNumberFormat", (e, r) => {
  Ns.init(e, r), Yt.init(e, r);
});
function Wi(e) {
  return Au(vt, e);
}
s(Wi, "int");
function rm(e) {
  return Pu(vt, e);
}
s(rm, "float32");
function nm(e) {
  return Du(vt, e);
}
s(nm, "float64");
function im(e) {
  return Nu(vt, e);
}
s(im, "int32");
function om(e) {
  return Tu(vt, e);
}
s(om, "uint32");
var er = /* @__PURE__ */ h("ZodBoolean", (e, r) => {
  Or.init(e, r), U.init(e, r), e._zod.processJSONSchema = (i, o, t) => dl(e, i, o, t);
});
function cd(e) {
  return Uu(er, e);
}
s(cd, "boolean");
var tr = /* @__PURE__ */ h("ZodBigInt", (e, r) => {
  ii.init(e, r), U.init(e, r), e._zod.processJSONSchema = (o, t, n) => fl(e, o, t, n);
  let i = e._zod.bag;
  e.minValue = i.minimum ?? null, e.maxValue = i.maximum ?? null, e.format = i.format ?? null;
}, {
  gte(e, r) {
    return this.check(me(e, r));
  },
  min(e, r) {
    return this.check(me(e, r));
  },
  gt(e, r) {
    return this.check(Se(e, r));
  },
  lt(e, r) {
    return this.check(ze(e, r));
  },
  lte(e, r) {
    return this.check(pe(e, r));
  },
  max(e, r) {
    return this.check(pe(e, r));
  },
  positive(e) {
    return this.check(Se(BigInt(0), e));
  },
  negative(e) {
    return this.check(ze(BigInt(0), e));
  },
  nonpositive(e) {
    return this.check(pe(BigInt(0), e));
  },
  nonnegative(e) {
    return this.check(me(BigInt(0), e));
  },
  multipleOf(e, r) {
    return this.check(Re(e, r));
  }
});
function am(e) {
  return Cu(tr, e);
}
s(am, "bigint");
var ho = /* @__PURE__ */ h("ZodBigIntFormat", (e, r) => {
  Ts.init(e, r), tr.init(e, r);
});
function sm(e) {
  return Ru(ho, e);
}
s(sm, "int64");
function cm(e) {
  return Fu(ho, e);
}
s(cm, "uint64");
var ud = /* @__PURE__ */ h("ZodSymbol", (e, r) => {
  Us.init(e, r), U.init(e, r), e._zod.processJSONSchema = (i, o, t) => pl(e, i, o, t);
});
function um(e) {
  return Lu(ud, e);
}
s(um, "symbol");
var ld = /* @__PURE__ */ h("ZodUndefined", (e, r) => {
  Es.init(e, r), U.init(e, r), e._zod.processJSONSchema = (i, o, t) => hl(e, i, o, t);
});
function lm(e) {
  return Vu(ld, e);
}
s(lm, "_undefined");
var dd = /* @__PURE__ */ h("ZodNull", (e, r) => {
  Cs.init(e, r), U.init(e, r), e._zod.processJSONSchema = (i, o, t) => ml(e, i, o, t);
});
function fd(e) {
  return Mu(dd, e);
}
s(fd, "_null");
var pd = /* @__PURE__ */ h("ZodAny", (e, r) => {
  Zs.init(e, r), U.init(e, r), e._zod.processJSONSchema = (i, o, t) => yl(e, i, o, t);
});
function dm() {
  return Bu(pd);
}
s(dm, "any");
var md = /* @__PURE__ */ h("ZodUnknown", (e, r) => {
  Rs.init(e, r), U.init(e, r), e._zod.processJSONSchema = (i, o, t) => bl(e, i, o, t);
});
function mt() {
  return Ju(md);
}
s(mt, "unknown");
var hd = /* @__PURE__ */ h("ZodNever", (e, r) => {
  Fs.init(e, r), U.init(e, r), e._zod.processJSONSchema = (i, o, t) => vl(e, i, o, t);
});
function go(e) {
  return qu(hd, e);
}
s(go, "never");
var gd = /* @__PURE__ */ h("ZodVoid", (e, r) => {
  Ls.init(e, r), U.init(e, r), e._zod.processJSONSchema = (i, o, t) => gl(e, i, o, t);
});
function fm(e) {
  return Ku(gd, e);
}
s(fm, "_void");
var Hr = /* @__PURE__ */ h("ZodDate", (e, r) => {
  jr.init(e, r), U.init(e, r), e._zod.processJSONSchema = (o, t, n) => $l(e, o, t, n), e.min = (o, t) => e.check(me(o, t)), e.max = (o, t) => e.check(pe(o, t));
  let i = e._zod.bag;
  e.minDate = i.minimum ? new Date(i.minimum) : null, e.maxDate = i.maximum ? new Date(i.maximum) : null;
});
function pm(e) {
  return Wu(Hr, e);
}
s(pm, "date");
var vd = /* @__PURE__ */ h("ZodArray", (e, r) => {
  gt(), Ar.init(e, r), U.init(e, r), e._zod.processJSONSchema = (i, o, t) => Dl(e, i, o, t), e.element = r.element;
}, {
  min(e, r) {
    return this.check(Ne(e, r));
  },
  nonempty(e) {
    return this.check(Ne(1, e));
  },
  max(e, r) {
    return this.check(ft(e, r));
  },
  length(e, r) {
    return this.check(pt(e, r));
  },
  unwrap() {
    return this.element;
  }
});
function Qr(e, r) {
  return Hu(vd, e, r);
}
s(Qr, "array");
function mm(e) {
  let r = e._zod.def.shape;
  return vo(Object.keys(r));
}
s(mm, "keyof");
var Yr = /* @__PURE__ */ h("ZodObject", (e, r) => {
  gt(), Vs.init(e, r), U.init(e, r), e._zod.processJSONSchema = (i, o, t) => Nl(e, i, o, t), k.installLazyProp(e, "shape", (i) => i._zod.def.shape, !1);
}, {
  keyof() {
    return vo(Object.keys(this._zod.def.shape));
  },
  catchall(e) {
    return this.clone({ ...this._zod.def, catchall: e });
  },
  passthrough() {
    return this.clone({ ...this._zod.def, catchall: mt() });
  },
  loose() {
    return this.clone({ ...this._zod.def, catchall: mt() });
  },
  strict() {
    return this.clone({ ...this._zod.def, catchall: go() });
  },
  strip() {
    return this.clone({ ...this._zod.def, catchall: void 0 });
  },
  extend(e) {
    return k.extend(this, e);
  },
  safeExtend(e) {
    return k.safeExtend(this, e);
  },
  merge(e) {
    return k.merge(this, e);
  },
  pick(e) {
    return k.pick(this, e);
  },
  omit(e) {
    return k.omit(this, e);
  },
  partial(...e) {
    return k.partial(tn, this, e[0]);
  },
  exactPartial(...e) {
    return k.partial(bo, this, e[0], "exactPartial");
  },
  required(...e) {
    return k.required($o, this, e[0]);
  }
});
function hm(e, r) {
  let i = {
    type: "object",
    shape: e ?? {},
    ...k.normalizeParams(r)
  };
  return new Yr(i);
}
s(hm, "object");
function gm(e, r) {
  return new Yr({
    type: "object",
    shape: e,
    catchall: go(),
    ...k.normalizeParams(r)
  });
}
s(gm, "strictObject");
function vm(e, r) {
  return new Yr({
    type: "object",
    shape: e,
    catchall: mt(),
    ...k.normalizeParams(r)
  });
}
s(vm, "looseObject");
var en = /* @__PURE__ */ h("ZodUnion", (e, r) => {
  Ie.init(e, r), U.init(e, r), e._zod.processJSONSchema = (i, o, t) => Vi(e, i, o, t), e.options = r.options;
});
function rr(e, r) {
  return new en({
    type: "union",
    options: e,
    ...k.normalizeParams(r)
  });
}
s(rr, "union");
var yd = /* @__PURE__ */ h("ZodXor", (e, r) => {
  en.init(e, r), Ms.init(e, r), e._zod.processJSONSchema = (i, o, t) => Vi(e, i, o, t), e.options = r.options;
});
function ym(e, r) {
  return new yd({
    type: "union",
    options: e,
    inclusive: !1,
    ...k.normalizeParams(r)
  });
}
s(ym, "xor");
var bd = /* @__PURE__ */ h("ZodDiscriminatedUnion", (e, r) => {
  en.init(e, r), Pt.init(e, r);
});
function bm(e, r, i) {
  return new bd({
    type: "union",
    options: r,
    discriminator: e,
    ...k.normalizeParams(i)
  });
}
s(bm, "discriminatedUnion");
var $d = /* @__PURE__ */ h("ZodIntersection", (e, r) => {
  Js.init(e, r), U.init(e, r), e._zod.processJSONSchema = (i, o, t) => Tl(e, i, o, t);
});
function _d(e, r) {
  return new $d({
    type: "intersection",
    left: e,
    right: r
  });
}
s(_d, "intersection");
var xd = /* @__PURE__ */ h("ZodTuple", (e, r) => {
  gt(), Dt.init(e, r), U.init(e, r), e._zod.processJSONSchema = (i, o, t) => Ul(e, i, o, t);
}, {
  rest(e) {
    return this.clone({
      ...this._zod.def,
      rest: e
    });
  },
  partial() {
    let e = this._zod.def;
    if (e.checks?.length)
      throw new Error(".partial() cannot be used on tuple schemas containing refinements");
    return this.clone({
      ...e,
      items: e.items.map((r) => new tn({ type: "optional", innerType: r }))
    });
  }
});
function wd(e, r, i) {
  let o = r instanceof P, t = o ? i : r, n = o ? r : null;
  return new xd({
    type: "tuple",
    items: e,
    rest: n,
    ...k.normalizeParams(t)
  });
}
s(wd, "tuple");
var Gt = /* @__PURE__ */ h("ZodRecord", (e, r) => {
  gt(), Pr.init(e, r), U.init(e, r), e._zod.processJSONSchema = (i, o, t) => El(e, i, o, t), e.keyType = r.keyType, e.valueType = r.valueType;
});
function kd(e, r, i) {
  return !r || !r._zod ? new Gt({
    type: "record",
    keyType: Wr(),
    valueType: e,
    ...k.normalizeParams(r)
  }) : new Gt({
    type: "record",
    keyType: e,
    valueType: r,
    ...k.normalizeParams(i)
  });
}
s(kd, "record");
function $m(e, r, i) {
  return new Gt({
    type: "record",
    keyType: e,
    valueType: r,
    ...k.normalizeParams(i),
    partial: !0
  });
}
s($m, "partialRecord");
function _m(e, r, i) {
  return new Gt({
    type: "record",
    keyType: e,
    valueType: r,
    mode: "loose",
    ...k.normalizeParams(i)
  });
}
s(_m, "looseRecord");
var Id = /* @__PURE__ */ h("ZodMap", (e, r) => {
  gt(), qs.init(e, r), U.init(e, r), e._zod.processJSONSchema = (i, o, t) => Al(e, i, o, t), e.keyType = r.keyType, e.valueType = r.valueType, e.min = (...i) => e.check(Oe(...i)), e.nonempty = (i) => e.check(Oe(1, i)), e.max = (...i) => e.check(Fe(...i)), e.size = (...i) => e.check(dt(...i));
});
function xm(e, r, i) {
  return new Id({
    type: "map",
    keyType: e,
    valueType: r,
    ...k.normalizeParams(i)
  });
}
s(xm, "map");
var zd = /* @__PURE__ */ h("ZodSet", (e, r) => {
  gt(), Ks.init(e, r), U.init(e, r), e._zod.processJSONSchema = (i, o, t) => Pl(e, i, o, t), e.min = (...i) => e.check(Oe(...i)), e.nonempty = (i) => e.check(Oe(1, i)), e.max = (...i) => e.check(Fe(...i)), e.size = (...i) => e.check(dt(...i));
});
function wm(e, r) {
  return new zd({
    type: "set",
    valueType: e,
    ...k.normalizeParams(r)
  });
}
s(wm, "set");
var Xt = /* @__PURE__ */ h("ZodEnum", (e, r) => {
  Dr.init(e, r), U.init(e, r), e._zod.processJSONSchema = (o, t, n) => _l(e, o, t, n), e.enum = r.entries, e.options = Object.values(r.entries);
  let i = new Set(Object.keys(r.entries));
  e.extract = (o, t) => {
    let n = {};
    for (let a of o)
      if (i.has(a))
        n[a] = r.entries[a];
      else
        throw new Error(`Key ${a} not found in enum`);
    return new Xt({
      ...r,
      checks: [],
      ...k.normalizeParams(t),
      entries: n
    });
  }, e.exclude = (o, t) => {
    let n = { ...r.entries };
    for (let a of o)
      if (i.has(a))
        delete n[a];
      else
        throw new Error(`Key ${a} not found in enum`);
    return new Xt({
      ...r,
      checks: [],
      ...k.normalizeParams(t),
      entries: n
    });
  };
});
function vo(e, r) {
  let i = Array.isArray(e) ? Object.fromEntries(e.map((o) => [o, o])) : e;
  return new Xt({
    type: "enum",
    entries: i,
    ...k.normalizeParams(r)
  });
}
s(vo, "_enum");
function km(e, r) {
  return new Xt({
    type: "enum",
    entries: e,
    ...k.normalizeParams(r)
  });
}
s(km, "nativeEnum");
var Sd = /* @__PURE__ */ h("ZodLiteral", (e, r) => {
  Nr.init(e, r), U.init(e, r), e._zod.processJSONSchema = (i, o, t) => xl(e, i, o, t), e.values = new Set(r.values), Object.defineProperty(e, "value", {
    get() {
      if (r.values.length > 1)
        throw new Error("This schema contains multiple valid literal values. Use `.values` instead.");
      return r.values[0];
    }
  });
});
function Im(e, r) {
  return new Sd({
    type: "literal",
    values: Array.isArray(e) ? e : [e],
    ...k.normalizeParams(r)
  });
}
s(Im, "literal");
var Od = /* @__PURE__ */ h("ZodFile", (e, r) => {
  Ws.init(e, r), U.init(e, r), e._zod.processJSONSchema = (i, o, t) => Il(e, i, o, t), e.min = (i, o) => e.check(Oe(i, o)), e.max = (i, o) => e.check(Fe(i, o)), e.mime = (i, o) => e.check(Lt(Array.isArray(i) ? i : [i], o));
});
function zm(e) {
  return Qu(Od, e);
}
s(zm, "file");
var jd = /* @__PURE__ */ h("ZodTransform", (e, r) => {
  gt(), Gs.init(e, r), U.init(e, r), e._zod.processJSONSchema = (i, o, t) => jl(e, i, o, t), e._zod.parse = (i, o) => {
    if (o.direction === "backward")
      throw new Ce(e.constructor.name);
    i.addIssue = (n) => {
      if (typeof n == "string")
        i.issues.push(k.issue(n, i.value, r));
      else {
        let a = n;
        a.fatal && (a.continue = !1), a.code ?? (a.code = "custom"), "input" in a || (a.input = i.value), a.inst ?? (a.inst = e), i.issues.push(k.issue(a));
      }
    };
    let t = r.transform(i.value, i);
    return t instanceof Promise ? t.then((n) => (i.value = n, i)) : (i.value = t, i);
  };
});
function yo(e) {
  return new jd({
    type: "transform",
    transform: e
  });
}
s(yo, "transform");
var tn = /* @__PURE__ */ h("ZodOptional", (e, r) => {
  $e.init(e, r), U.init(e, r), e._zod.processJSONSchema = (i, o, t) => Mi(e, i, o, t), e.unwrap = () => e._zod.def.innerType;
});
function ht(e) {
  return new tn({
    type: "optional",
    innerType: e
  });
}
s(ht, "optional");
var bo = /* @__PURE__ */ h("ZodExactOptional", (e, r) => {
  Xs.init(e, r), U.init(e, r), e._zod.processJSONSchema = (i, o, t) => Mi(e, i, o, t), e.unwrap = () => e._zod.def.innerType;
});
function Ad(e) {
  return new bo({
    type: "optional",
    innerType: e
  });
}
s(Ad, "exactOptional");
var Pd = /* @__PURE__ */ h("ZodNullable", (e, r) => {
  Nt.init(e, r), U.init(e, r), e._zod.processJSONSchema = (i, o, t) => Cl(e, i, o, t), e.unwrap = () => e._zod.def.innerType;
});
function Gr(e) {
  return new Pd({
    type: "nullable",
    innerType: e
  });
}
s(Gr, "nullable");
function Sm(e) {
  return ht(Gr(e));
}
s(Sm, "nullish");
var Dd = /* @__PURE__ */ h("ZodDefault", (e, r) => {
  Tr.init(e, r), U.init(e, r), e._zod.processJSONSchema = (i, o, t) => Fl(e, i, o, t), e.unwrap = () => e._zod.def.innerType, e.removeDefault = e.unwrap;
});
function Nd(e, r) {
  return new Dd({
    type: "default",
    innerType: e,
    get defaultValue() {
      return typeof r == "function" ? r() : k.shallowClone(r);
    }
  });
}
s(Nd, "_default");
var Td = /* @__PURE__ */ h("ZodPrefault", (e, r) => {
  Hs.init(e, r), U.init(e, r), e._zod.processJSONSchema = (i, o, t) => Ll(e, i, o, t), e.unwrap = () => e._zod.def.innerType;
});
function Ud(e, r) {
  return new Td({
    type: "prefault",
    innerType: e,
    get defaultValue() {
      return typeof r == "function" ? r() : k.shallowClone(r);
    }
  });
}
s(Ud, "prefault");
var $o = /* @__PURE__ */ h("ZodNonOptional", (e, r) => {
  Qs.init(e, r), U.init(e, r), e._zod.processJSONSchema = (i, o, t) => Zl(e, i, o, t), e.unwrap = () => e._zod.def.innerType;
});
function Ed(e, r) {
  return new $o({
    type: "nonoptional",
    innerType: e,
    ...k.normalizeParams(r)
  });
}
s(Ed, "nonoptional");
var Cd = /* @__PURE__ */ h("ZodSuccess", (e, r) => {
  Ys.init(e, r), U.init(e, r), e._zod.processJSONSchema = (i, o, t) => zl(e, i, o, t), e.unwrap = () => e._zod.def.innerType;
});
function Om(e) {
  return new Cd({
    type: "success",
    innerType: e
  });
}
s(Om, "success");
var Zd = /* @__PURE__ */ h("ZodCatch", (e, r) => {
  ec.init(e, r), U.init(e, r), e._zod.processJSONSchema = (i, o, t) => Vl(e, i, o, t), e.unwrap = () => e._zod.def.innerType, e.removeCatch = e.unwrap;
});
function Rd(e, r) {
  return new Zd({
    type: "catch",
    innerType: e,
    catchValue: typeof r == "function" ? r : k.constantCatch(r)
  });
}
s(Rd, "_catch");
var Fd = /* @__PURE__ */ h("ZodNaN", (e, r) => {
  tc.init(e, r), U.init(e, r), e._zod.processJSONSchema = (i, o, t) => wl(e, i, o, t);
});
function jm(e) {
  return Xu(Fd, e);
}
s(jm, "nan");
var rn = /* @__PURE__ */ h("ZodPipe", (e, r) => {
  oi.init(e, r), U.init(e, r), e._zod.processJSONSchema = (i, o, t) => Ml(e, i, o, t), e.in = r.in, e.out = r.out;
});
function Gi(e, r) {
  return new rn({
    type: "pipe",
    in: e,
    out: r
    // ...util.normalizeParams(params),
  });
}
s(Gi, "pipe");
var nn = /* @__PURE__ */ h("ZodCodec", (e, r) => {
  rn.init(e, r), ot.init(e, r);
});
function Am(e, r, i) {
  return new nn({
    type: "pipe",
    in: e,
    out: r,
    transform: i.decode,
    reverseTransform: i.encode
  });
}
s(Am, "codec");
function Pm(e) {
  let r = e._zod.def;
  return new nn({
    type: "pipe",
    in: r.out,
    out: r.in,
    transform: r.reverseTransform,
    reverseTransform: r.transform
  });
}
s(Pm, "invertCodec");
var Ld = /* @__PURE__ */ h("ZodPreprocess", (e, r) => {
  rn.init(e, r), rc.init(e, r);
}), Vd = /* @__PURE__ */ h("ZodReadonly", (e, r) => {
  nc.init(e, r), U.init(e, r), e._zod.processJSONSchema = (i, o, t) => Bl(e, i, o, t), e.unwrap = () => e._zod.def.innerType;
});
function Md(e) {
  return new Vd({
    type: "readonly",
    innerType: e
  });
}
s(Md, "readonly");
var Bd = /* @__PURE__ */ h("ZodTemplateLiteral", (e, r) => {
  ic.init(e, r), U.init(e, r), e._zod.processJSONSchema = (i, o, t) => kl(e, i, o, t);
});
function Dm(e, r) {
  return new Bd({
    type: "template_literal",
    parts: e,
    ...k.normalizeParams(r)
  });
}
s(Dm, "templateLiteral");
var Jd = /* @__PURE__ */ h("ZodLazy", (e, r) => {
  at.init(e, r), U.init(e, r), e._zod.processJSONSchema = (i, o, t) => ql(e, i, o, t), e.unwrap = () => e._zod.def.getter();
});
function qd(e) {
  return new Jd({
    type: "lazy",
    getter: e
  });
}
s(qd, "lazy");
var Kd = /* @__PURE__ */ h("ZodPromise", (e, r) => {
  ac.init(e, r), U.init(e, r), e._zod.processJSONSchema = (i, o, t) => Jl(e, i, o, t), e.unwrap = () => e._zod.def.innerType;
});
function Nm(e) {
  return new Kd({
    type: "promise",
    innerType: e
  });
}
s(Nm, "promise");
var Wd = /* @__PURE__ */ h("ZodFunction", (e, r) => {
  oc.init(e, r), U.init(e, r), e._zod.processJSONSchema = (i, o, t) => Ol(e, i, o, t);
});
function Tm(e) {
  return new Wd({
    type: "function",
    input: Array.isArray(e?.input) ? wd(e?.input) : e?.input ?? Qr(mt()),
    output: e?.output ?? mt()
  });
}
s(Tm, "_function");
var on = /* @__PURE__ */ h("ZodCustom", (e, r) => {
  ai.init(e, r), U.init(e, r), e._zod.processJSONSchema = (i, o, t) => Sl(e, i, o, t);
});
function Um(e) {
  let r = new B({
    check: "custom"
    // ...util.normalizeParams(params),
  });
  return r._zod.check = e, r;
}
s(Um, "check");
function Em(e, r) {
  return Yu(on, e ?? (() => !0), r);
}
s(Em, "custom");
function Gd(e, r = {}) {
  return el(on, e, r);
}
s(Gd, "refine");
function Xd(e, r) {
  return tl(e, r);
}
s(Xd, "superRefine");
var Cm = rl, Zm = nl;
function Rm(e, r = {}) {
  let i = new on({
    type: "custom",
    check: "custom",
    fn: /* @__PURE__ */ s((o) => o instanceof e, "fn"),
    abort: !0,
    ...k.normalizeParams(r)
  });
  return i._zod.bag.Class = e, i._zod.check = (o) => {
    o.value instanceof e || o.issues.push({
      code: "invalid_type",
      expected: e.name,
      input: o.value,
      inst: i,
      path: [...i._zod.def.path ?? []]
    });
  }, i;
}
s(Rm, "_instanceof");
var Fm = /* @__PURE__ */ s((...e) => il({
  Codec: nn,
  Boolean: er,
  String: Ht
}, ...e), "stringbool");
function Lm(e) {
  let r = qd(() => rr([Wr(e), sd(), cd(), fd(), Qr(r), kd(Wr(), r)]));
  return r;
}
s(Lm, "json");
function Vm(e, r) {
  return new Ld({
    type: "pipe",
    in: yo(e),
    out: r
  });
}
s(Vm, "preprocess");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/compat.js
var wx = {
  invalid_type: "invalid_type",
  too_big: "too_big",
  too_small: "too_small",
  invalid_format: "invalid_format",
  not_multiple_of: "not_multiple_of",
  unrecognized_keys: "unrecognized_keys",
  invalid_union: "invalid_union",
  invalid_key: "invalid_key",
  invalid_element: "invalid_element",
  invalid_value: "invalid_value",
  custom: "custom"
};
function kx(e) {
  X({
    customError: e
  });
}
s(kx, "setErrorMap");
function Ix() {
  return X().customError;
}
s(Ix, "getErrorMap");
var Hd;
Hd || (Hd = {});

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/iso.js
var an = {};
Pe(an, {
  ZodISODate: () => Je,
  ZodISODateTime: () => Be,
  ZodISODuration: () => Ke,
  ZodISOTime: () => qe,
  date: () => Sx,
  datetime: () => zx,
  duration: () => jx,
  time: () => Ox
});
function zx(e) {
  return Vr(Be, e);
}
s(zx, "datetime");
function Sx(e) {
  return Mr(Je, e);
}
s(Sx, "date");
function Ox(e) {
  return Br(qe, e);
}
s(Ox, "time");
function jx(e) {
  return Jr(Ke, e);
}
s(jx, "duration");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/from-json-schema.js
var S = {
  ...nr,
  ...qi,
  iso: an
}, Ax = /* @__PURE__ */ new Set([
  // Schema identification
  "$schema",
  "$ref",
  "$defs",
  "definitions",
  // Core schema keywords
  "$id",
  "id",
  "$comment",
  "$anchor",
  "$vocabulary",
  "$dynamicRef",
  "$dynamicAnchor",
  // Type
  "type",
  "enum",
  "const",
  // Composition
  "anyOf",
  "oneOf",
  "allOf",
  "not",
  // Object
  "properties",
  "required",
  "additionalProperties",
  "patternProperties",
  "propertyNames",
  "minProperties",
  "maxProperties",
  // Array
  "items",
  "prefixItems",
  "additionalItems",
  "minItems",
  "maxItems",
  "uniqueItems",
  "contains",
  "minContains",
  "maxContains",
  // String
  "minLength",
  "maxLength",
  "pattern",
  "format",
  // Number
  "minimum",
  "maximum",
  "exclusiveMinimum",
  "exclusiveMaximum",
  "multipleOf",
  // Already handled metadata
  "description",
  "default",
  // Content
  "contentEncoding",
  "contentMediaType",
  "contentSchema",
  // Unsupported (error-throwing)
  "unevaluatedItems",
  "unevaluatedProperties",
  "if",
  "then",
  "else",
  "dependentSchemas",
  "dependentRequired",
  // OpenAPI
  "nullable",
  "readOnly"
]);
function Px(e, r) {
  let i = e.$schema;
  return i === "https://json-schema.org/draft/2020-12/schema" ? "draft-2020-12" : i === "http://json-schema.org/draft-07/schema#" ? "draft-7" : i === "http://json-schema.org/draft-04/schema#" ? "draft-4" : r ?? "draft-2020-12";
}
s(Px, "detectVersion");
function Mm(e, r) {
  return e.map((i, o) => o < r ? i : i.optional());
}
s(Mm, "applyMinItems");
function Dx(e) {
  return e.replace(/~1/g, "/").replace(/~0/g, "~");
}
s(Dx, "decodeJSONPointerSegment");
function Nx(e, r) {
  if (!e.startsWith("#"))
    throw new Error("External $ref is not supported, only local refs (#/...) are allowed");
  let i = e.slice(1).split("/").filter(Boolean);
  if (i.length === 0)
    return r.rootSchema;
  let o = r.version === "draft-2020-12" ? "$defs" : "definitions";
  if (i[0] === o) {
    let t = i[1] === void 0 ? void 0 : Dx(i[1]);
    if (!t || !r.defs[t])
      throw new Error(`Reference not found: ${e}`);
    return r.defs[t];
  }
  throw new Error(`Reference not found: ${e}`);
}
s(Nx, "resolveRef");
function Tx(e, r) {
  return S.transform((o) => o).check((o) => {
    let t = o.value;
    if (!(typeof t != "object" || t === null || Array.isArray(t)))
      for (let n of Object.getOwnPropertyNames(t)) {
        let a = r.safeParse(n);
        a.success || o.issues.push({
          code: "invalid_key",
          origin: "record",
          issues: a.error.issues,
          input: n,
          path: [n],
          continue: !0
        });
      }
  }).pipe(e);
}
s(Tx, "checkPropertyNames");
function Bm(e, r) {
  if (e !== !1)
    return e === void 0 || e === !0 ? S.any() : de(e, r);
}
s(Bm, "getTupleRest");
var Ux = /^(?:[01]\d|2[0-3]):[0-5]\d:[0-5]\d(?:\.\d+)?(?:Z|[+-](?:[01]\d|2[0-3]):[0-5]\d)$/;
function Jm(e, r) {
  if (e.not !== void 0) {
    if (typeof e.not == "object" && Object.keys(e.not).length === 0)
      return S.never();
    throw new Error("not is not supported in Zod (except { not: {} } for never)");
  }
  if (e.unevaluatedItems !== void 0)
    throw new Error("unevaluatedItems is not supported");
  if (e.unevaluatedProperties !== void 0)
    throw new Error("unevaluatedProperties is not supported");
  if (e.if !== void 0 || e.then !== void 0 || e.else !== void 0)
    throw new Error("Conditional schemas (if/then/else) are not supported");
  if (e.dependentSchemas !== void 0 || e.dependentRequired !== void 0)
    throw new Error("dependentSchemas and dependentRequired are not supported");
  if (e.$ref) {
    let t = e.$ref;
    if (r.refs.has(t))
      return r.refs.get(t);
    if (r.processing.has(t))
      return S.lazy(() => {
        if (!r.refs.has(t))
          throw new Error(`Circular reference not resolved: ${t}`);
        return r.refs.get(t);
      });
    r.processing.add(t);
    let n = Nx(t, r), a = de(n, r);
    return r.refs.set(t, a), r.processing.delete(t), a;
  }
  if (e.enum !== void 0) {
    let t = e.enum;
    if (r.version === "openapi-3.0" && e.nullable === !0 && t.length === 1 && t[0] === null)
      return S.null();
    if (t.length === 0)
      return S.never();
    if (t.length === 1)
      return S.literal(t[0]);
    if (t.every((a) => typeof a == "string"))
      return S.enum(t);
    let n = t.map((a) => S.literal(a));
    return n.length < 2 ? n[0] : S.union([n[0], n[1], ...n.slice(2)]);
  }
  if (e.const !== void 0)
    return S.literal(e.const);
  let i = e.type;
  if (Array.isArray(i)) {
    let t = i.map((n) => {
      let a = { ...e, type: n };
      return Jm(a, r);
    });
    return t.length === 0 ? S.never() : t.length === 1 ? t[0] : S.union(t);
  }
  if (!i)
    return S.any();
  let o;
  switch (i) {
    case "string": {
      let t = S.string();
      if (e.format) {
        let n = e.format;
        n === "email" ? t = t.check(S.email()) : n === "uri" || n === "uri-reference" ? t = t.check(S.url()) : n === "uuid" || n === "guid" ? t = t.check(S.uuid()) : n === "date-time" ? t = t.check(S.iso.datetime({ offset: !0 })) : n === "date" ? t = t.check(S.iso.date()) : n === "time" ? t = t.check(S.regex(Ux)) : n === "duration" ? t = t.check(S.iso.duration()) : n === "hostname" ? t = t.check(S.hostname()) : n === "ipv4" ? t = t.check(S.ipv4()) : n === "ipv6" ? t = t.check(S.ipv6()) : n === "mac" ? t = t.check(S.mac()) : n === "cidr" ? t = t.check(S.cidrv4()) : n === "cidr-v6" ? t = t.check(S.cidrv6()) : n === "base64" ? t = t.check(S.base64()) : n === "base64url" ? t = t.check(S.base64url()) : n === "e164" ? t = t.check(S.e164()) : n === "credit_card" ? t = t.check(S.creditCard()) : n === "jwt" ? t = t.check(S.jwt()) : n === "emoji" ? t = t.check(S.emoji()) : n === "nanoid" ? t = t.check(S.nanoid()) : n === "cuid" ? t = t.check(S.cuid()) : n === "cuid2" ? t = t.check(S.cuid2()) : n === "ulid" ? t = t.check(S.ulid()) : n === "xid" ? t = t.check(S.xid()) : n === "ksuid" && (t = t.check(S.ksuid()));
      }
      typeof e.minLength == "number" && (t = t.min(e.minLength)), typeof e.maxLength == "number" && (t = t.max(e.maxLength)), e.pattern && (t = t.regex(new RegExp(e.pattern))), o = t;
      break;
    }
    case "number":
    case "integer": {
      let t = i === "integer" ? S.number().int() : S.number();
      typeof e.minimum == "number" && e.exclusiveMinimum !== !0 && (t = t.min(e.minimum)), typeof e.maximum == "number" && e.exclusiveMaximum !== !0 && (t = t.max(e.maximum)), typeof e.exclusiveMinimum == "number" ? t = t.gt(e.exclusiveMinimum) : e.exclusiveMinimum === !0 && typeof e.minimum == "number" && (t = t.gt(e.minimum)), typeof e.exclusiveMaximum == "number" ? t = t.lt(e.exclusiveMaximum) : e.exclusiveMaximum === !0 && typeof e.maximum == "number" && (t = t.lt(e.maximum)), typeof e.multipleOf == "number" && (t = t.multipleOf(e.multipleOf)), o = t;
      break;
    }
    case "boolean": {
      o = S.boolean();
      break;
    }
    case "null": {
      o = S.null();
      break;
    }
    case "object": {
      let t = {}, n = e.properties || {}, a = new Set(e.required || []), c = typeof e.additionalProperties == "object" ? de(e.additionalProperties, r) : void 0;
      for (let [u, l] of Object.entries(n)) {
        let f = de(l, r);
        G(t, u, a.has(u) ? f : f.optional());
      }
      if (e.patternProperties) {
        let u = e.patternProperties, l = Object.keys(u), f = [];
        for (let v of l) {
          let y = de(u[v], r), b = S.string().regex(new RegExp(v));
          f.push(S.looseRecord(b, y));
        }
        let m = [];
        if (Object.keys(t).length > 0 && m.push(S.object(t).passthrough()), m.push(...f), m.length === 0)
          o = S.object({}).passthrough();
        else if (m.length === 1)
          o = m[0];
        else {
          let v = S.intersection(m[0], m[1]);
          for (let y = 2; y < m.length; y++)
            v = S.intersection(v, m[y]);
          o = v;
        }
        if (e.additionalProperties === !1) {
          let v = Object.keys(t), y = l.map((z) => new RegExp(z)), b = o;
          o = o.check((z) => {
            if (!ge(z.value))
              return;
            let O = [];
            for (let L of Object.keys(z.value))
              v.includes(L) || y.some((A) => A.test(L)) || O.push(L);
            O.length && z.issues.push({
              code: "unrecognized_keys",
              keys: O,
              input: z.value,
              inst: b
            });
          });
        }
      } else {
        let u = S.object(t);
        e.additionalProperties === !1 ? o = u.strict() : c ? o = u.catchall(c) : o = u.passthrough();
      }
      if (e.propertyNames !== void 0 && e.propertyNames !== !0) {
        let u = typeof e.propertyNames == "object" && e.propertyNames.type === void 0 ? { type: "string", ...e.propertyNames } : e.propertyNames;
        o = Tx(o, de(u, r));
      }
      break;
    }
    case "array": {
      let t = e.prefixItems, n = e.items;
      if (t && Array.isArray(t)) {
        let a = typeof e.minItems == "number" ? e.minItems : 0, c = t.map((m) => de(m, r)), u = Mm(c, a), l = Array.isArray(n) ? void 0 : Bm(n, r), f = S.tuple(u);
        o = l ? f.rest(l) : f, typeof e.minItems == "number" && (o = o.check(S.minLength(e.minItems))), typeof e.maxItems == "number" && (o = o.check(S.maxLength(e.maxItems)));
      } else if (Array.isArray(n)) {
        let a = typeof e.minItems == "number" ? e.minItems : 0, c = n.map((m) => de(m, r)), u = Mm(c, a), l = Bm(e.additionalItems, r), f = S.tuple(u);
        o = l ? f.rest(l) : f, typeof e.minItems == "number" && (o = o.check(S.minLength(e.minItems))), typeof e.maxItems == "number" && (o = o.check(S.maxLength(e.maxItems)));
      } else if (n !== void 0) {
        let a = de(n, r), c = S.array(a);
        typeof e.minItems == "number" && (c = c.min(e.minItems)), typeof e.maxItems == "number" && (c = c.max(e.maxItems)), o = c;
      } else
        o = S.array(S.any());
      break;
    }
    default:
      throw new Error(`Unsupported type: ${i}`);
  }
  return o;
}
s(Jm, "convertBaseSchema");
function de(e, r) {
  if (typeof e == "boolean")
    return e ? S.any() : S.never();
  let i = Jm(e, r), o = e.type || e.enum !== void 0 || e.const !== void 0;
  if (e.anyOf && Array.isArray(e.anyOf)) {
    let c = e.anyOf.map((l) => de(l, r)), u = S.union(c);
    i = o ? S.intersection(i, u) : u;
  }
  if (e.oneOf && Array.isArray(e.oneOf)) {
    let c = e.oneOf.map((l) => de(l, r)), u = S.xor(c);
    i = o ? S.intersection(i, u) : u;
  }
  if (e.allOf && Array.isArray(e.allOf))
    if (e.allOf.length === 0)
      i = o ? i : S.any();
    else {
      let c = o ? i : de(e.allOf[0], r), u = o ? 0 : 1;
      for (let l = u; l < e.allOf.length; l++)
        c = S.intersection(c, de(e.allOf[l], r));
      i = c;
    }
  e.nullable === !0 && r.version === "openapi-3.0" && (i = S.nullable(i)), e.readOnly === !0 && (i = S.readonly(i)), e.default !== void 0 && (i = i.default(e.default));
  let t = {}, n = ["$id", "id", "$comment", "$anchor", "$vocabulary", "$dynamicRef", "$dynamicAnchor"];
  for (let c of n)
    c in e && (t[c] = e[c]);
  let a = ["contentEncoding", "contentMediaType", "contentSchema"];
  for (let c of a)
    c in e && (t[c] = e[c]);
  e.propertyNames !== void 0 && e.type === "object" && e.$ref === void 0 && (t.propertyNames = e.propertyNames);
  for (let c of Object.keys(e))
    Ax.has(c) || G(t, c, e[c]);
  return Object.keys(t).length > 0 && r.registry.add(i, t), e.description && (i = i.describe(e.description)), i;
}
s(de, "convertSchema");
function qm(e, r) {
  if (typeof e == "boolean")
    return e ? S.any() : S.never();
  let i;
  try {
    i = JSON.parse(JSON.stringify(e));
  } catch {
    throw new Error("fromJSONSchema input is not valid JSON (possibly cyclic); use $defs/$ref for recursive schemas");
  }
  let o = Px(i, r?.defaultTarget), t = i.$defs || i.definitions || {}, n = {
    version: o,
    defs: t,
    refs: /* @__PURE__ */ new Map(),
    processing: /* @__PURE__ */ new Set(),
    rootSchema: i,
    registry: r?.registry ?? Y
  };
  return de(i, n);
}
s(qm, "fromJSONSchema");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/visit.js
var Km = Symbol("z.visit/resolving");
function sn(e, r) {
  let i = typeof r == "function" ? r : (a, c) => {
    let u = r[a._zod.def.type];
    return u ? u(a, c) : a;
  }, o = /* @__PURE__ */ new Map();
  function t(a) {
    let c = o.get(a);
    if (c === Km)
      return new at({
        type: "lazy",
        getter: /* @__PURE__ */ s(() => o.get(a), "getter")
      });
    if (c !== void 0)
      return c;
    o.set(a, Km);
    let u = n(a), l = i(u, u !== a);
    return o.set(a, l), l;
  }
  s(t, "run");
  function n(a) {
    let c = a._zod.def, u = c.type;
    switch (u) {
      case "object": {
        let l = c.shape, f = Object.keys(l), m = !1, v = {};
        for (let b of f) {
          let z = t(l[b]);
          z !== l[b] && (m = !0), v[b] = z;
        }
        let y = c.catchall;
        return c.catchall && (y = t(c.catchall), y !== c.catchall && (m = !0)), m ? Z(a, { ...c, shape: v, catchall: y }) : a;
      }
      case "array": {
        let l = t(c.element);
        return l === c.element ? a : Z(a, { ...c, element: l });
      }
      case "tuple": {
        let l = c.items, f = !1, m = [];
        for (let y of l) {
          let b = t(y);
          b !== y && (f = !0), m.push(b);
        }
        let v = c.rest;
        return c.rest && (v = t(c.rest), v !== c.rest && (f = !0)), f ? Z(a, { ...c, items: m, rest: v }) : a;
      }
      case "record":
      case "map": {
        let l = t(c.keyType), f = t(c.valueType);
        return l === c.keyType && f === c.valueType ? a : Z(a, { ...c, keyType: l, valueType: f });
      }
      case "set": {
        let l = t(c.valueType);
        return l === c.valueType ? a : Z(a, { ...c, valueType: l });
      }
      case "union": {
        let l = c.options, f = !1, m = [];
        for (let v of l) {
          let y = t(v);
          y !== v && (f = !0), m.push(y);
        }
        return f ? Z(a, { ...c, options: m }) : a;
      }
      case "intersection": {
        let l = t(c.left), f = t(c.right);
        return l === c.left && f === c.right ? a : Z(a, { ...c, left: l, right: f });
      }
      case "optional":
      case "nullable":
      case "default":
      case "prefault":
      case "catch":
      case "readonly":
      case "nonoptional":
      case "promise":
      case "success": {
        let l = t(c.innerType);
        return l === c.innerType ? a : Z(a, { ...c, innerType: l });
      }
      case "pipe": {
        let l = t(c.in), f = t(c.out);
        return l === c.in && f === c.out ? a : Z(a, { ...c, in: l, out: f });
      }
      case "function": {
        let l = t(c.input), f = t(c.output);
        return l === c.input && f === c.output ? a : Z(a, { ...c, input: l, output: f });
      }
      case "lazy": {
        let l = c.getter, { _cachedInner: f, ...m } = c;
        return Z(a, { ...m, getter: /* @__PURE__ */ s(() => t(l()), "getter") });
      }
      // A leaf by choice: `parts` are regex fragments, not data positions.
      case "template_literal":
      // Leaves.
      case "string":
      case "number":
      case "int":
      case "boolean":
      case "bigint":
      case "symbol":
      case "undefined":
      case "null":
      case "void":
      case "never":
      case "any":
      case "unknown":
      case "date":
      case "nan":
      case "enum":
      case "literal":
      case "file":
      case "transform":
      case "custom":
        return a;
      default:
        return a;
    }
  }
  return s(n, "mapInner"), t(e);
}
s(sn, "visit");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/deep-partial.js
function Wm(e) {
  return sn(e, {
    object: /* @__PURE__ */ s((r) => r.partial(), "object"),
    // Every partialed option now admits `undefined`, which the constructor rejects as a duplicate.
    union: /* @__PURE__ */ s((r) => {
      let i = r._zod.def;
      return i.discriminator === void 0 ? r : rr(i.options);
    }, "union")
  });
}
s(Wm, "deepPartial");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/in-out.js
function Ex(e, r) {
  if (!r?.length)
    return e;
  let i = e._zod.def;
  return Z(e, ye(i, { checks: [...i.checks ?? [], ...r] }), { parent: !0 });
}
s(Ex, "withChecks");
function Gm(e) {
  return Ex(e.out, e.checks);
}
s(Gm, "outSide");
function Cx(e) {
  return e.in._zod.traits.has("$ZodTransform") ? Gm(e) : e.in;
}
s(Cx, "inSide");
function Xm(e) {
  return sn(e, {
    pipe: /* @__PURE__ */ s((r) => Cx(r._zod.def), "pipe"),
    // A default value belongs to the output side, so a rewritten inner type leaves it stranded. `.default()` widens the declared input type with `undefined`, and `optional` is what carries that across.
    default: /* @__PURE__ */ s((r, i) => i ? ht(r._zod.def.innerType) : r, "default"),
    // A catch value is output-side too, but `.catch()` leaves the declared input type alone, so the inner schema stands on its own.
    catch: /* @__PURE__ */ s((r, i) => i ? r._zod.def.innerType : r, "catch")
  });
}
s(Xm, "input");
function Hm(e) {
  return sn(e, {
    pipe: /* @__PURE__ */ s((r) => Gm(r._zod.def), "pipe"),
    // A prefault value is fed through the schema, which makes it input-side, so a rewritten inner type leaves it stranded.
    prefault: /* @__PURE__ */ s((r, i) => i ? r._zod.def.innerType : r, "prefault")
  });
}
s(Hm, "output");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/coerce.js
var Qd = {};
Pe(Qd, {
  bigint: () => Lx,
  boolean: () => Fx,
  date: () => Vx,
  number: () => Rx,
  string: () => Zx
});
function Zx(e) {
  return ku(Ht, e);
}
s(Zx, "string");
function Rx(e) {
  return ju(Yt, e);
}
s(Rx, "number");
function Fx(e) {
  return Eu(er, e);
}
s(Fx, "boolean");
function Lx(e) {
  return Zu(tr, e);
}
s(Lx, "bigint");
function Vx(e) {
  return Gu(Hr, e);
}
s(Vx, "date");

// ../../packages/zodvex/dist/index.js
var Qm = /* @__PURE__ */ new WeakMap(), Mx = {
  getMetadata: /* @__PURE__ */ s((e) => Qm.get(e), "getMetadata"),
  setMetadata: /* @__PURE__ */ s((e, r) => Qm.set(e, r), "setMetadata")
};
var Ym = /* @__PURE__ */ Symbol.for("zodvex.zxDate");
function Bx(e) {
  e[Ym] = !0;
  let r = e._zod?.def;
  return r && (r[Ym] = !0), e;
}
s(Bx, "brandZxDate");
var wj = d.discriminatedUnion("success", [
  d.object({ success: d.literal(!0) }),
  d.object({ success: d.literal(!1), error: d.string() })
]), kj = d.object({
  formErrors: d.array(d.string()),
  fieldErrors: d.record(d.string(), d.array(d.string()))
});
function oh(e, r, i) {
  return d.codec(e, r, i);
}
s(oh, "zodvexCodec");
var Jx = "__zodvexCodecBrand";
function qx(e, r) {
  Object.defineProperty(e, Jx, {
    value: r,
    enumerable: !1,
    writable: !1,
    configurable: !1
  });
}
s(qx, "attachCodecBrand");
function xo(e) {
  let r = d.string().check(
    d.refine((o) => typeof o == "string" && o.length > 0, {
      message: `Invalid ID for table "${e}"`
    }),
    d.describe(`convexId:${e}`)
  );
  Mx.setMetadata(r, {
    isConvexId: !0,
    tableName: e
  });
  let i = r;
  return i._tableName = e, i;
}
s(xo, "id");
function ah(e) {
  return e instanceof Ie || e instanceof Pt;
}
s(ah, "isZodUnion");
function sh(e) {
  return e instanceof Ie, e._zod.def.options;
}
s(sh, "getUnionOptions");
function Kx(e) {
  if (e.length < 2)
    throw new Error(
      `z.union() requires at least 2 options, but received ${e.length}. This indicates an invalid union schema was passed to zodTable().`
    );
}
s(Kx, "assertUnionOptions");
function ch(e) {
  return Kx(e), d.union(e);
}
s(ch, "createUnionFromOptions");
function Wx(e, r) {
  if (ah(r)) {
    let o = sh(r).map((t) => {
      if (t instanceof be) {
        let n = {
          ...t._zod.def.shape,
          _id: xo(e),
          _creationTime: d.number()
        };
        return Z(t, { ...t._zod.def, shape: n });
      }
      return t;
    });
    return ch(o);
  }
  if (r instanceof be) {
    let i = { ...r._zod.def.shape, _id: xo(e), _creationTime: d.number() };
    return Z(r, { ...r._zod.def, shape: i });
  }
  return r;
}
s(Wx, "addSystemFields");
function Gx(e) {
  return e instanceof $e ? e : new $e({ type: "optional", innerType: e });
}
s(Gx, "ensureOptional");
function Xx(e) {
  let r = {};
  for (let [i, o] of Object.entries(e))
    r[i] = Gx(o);
  return r;
}
s(Xx, "createPartialShape");
function eh(e, r) {
  return d.object({
    _id: xo(e),
    _creationTime: d.optional(d.number()),
    ...Xx(r)
  });
}
s(eh, "createUpdateObjectSchema");
function Hx(e, r) {
  if (ah(r)) {
    let i = sh(r).map((o) => o instanceof be ? eh(e, o._zod.def.shape) : o);
    return ch(i);
  }
  return r instanceof be ? eh(e, r._zod.def.shape) : r;
}
s(Hx, "createSchemaUpdateSchema");
function Qx() {
  return Bx(
    oh(
      d.number(),
      // Wire: timestamp
      d.custom((e) => e instanceof Date, {
        message: "Expected Date instance"
      }),
      {
        decode: /* @__PURE__ */ s((e) => new Date(e), "decode"),
        encode: /* @__PURE__ */ s((e) => e.getTime(), "encode")
      }
    )
  );
}
s(Qx, "date");
function Yx(e, r, i, o) {
  let t = oh(e, r, i);
  return o?.brand && qx(t, o.brand), t;
}
s(Yx, "codec");
function wo(e) {
  let r = /* @__PURE__ */ Symbol.for(`zodvex.zx.cache.${e}`), i = globalThis, o = i[r];
  if (o) return o;
  let t = /* @__PURE__ */ new WeakMap();
  return i[r] = t, t;
}
s(wo, "sharedWeakMap");
var th = wo("base"), rh = wo("doc"), nh = wo("update"), ih = wo("docArray");
function ef(e) {
  let r = e.schema;
  return r instanceof P ? r : e.fields;
}
s(ef, "slimCacheKey");
function tf(e) {
  let r = e.schema;
  if (r?.base instanceof P) return r.base;
  if (r instanceof P) return r;
  let i = th.get(e.fields);
  if (i) return i;
  if (Object.keys(e.fields).length === 0)
    throw new Error(`[zodvex] Cannot derive base schema for model '${e.name}'`);
  let o = d.object(e.fields);
  return th.set(e.fields, o), o;
}
s(tf, "base");
function uh(e) {
  let r = e.schema;
  if (r?.doc instanceof P) return r.doc;
  let i = ef(e), o = rh.get(i);
  if (o) return o;
  let t = Wx(e.name, tf(e));
  return rh.set(i, t), t;
}
s(uh, "doc");
function ew(e) {
  let r = e.schema;
  if (r?.update instanceof P) return r.update;
  let i = ef(e), o = nh.get(i);
  if (o) return o;
  let t = Hx(e.name, tf(e));
  return nh.set(i, t), t;
}
s(ew, "update");
function tw(e) {
  let r = e.schema;
  if (r?.docArray instanceof P) return r.docArray;
  let i = ef(e), o = ih.get(i);
  if (o) return o;
  let t = d.array(uh(e));
  return ih.set(i, t), t;
}
s(tw, "docArray");
function lh(e) {
  return new Nt({ type: "nullable", innerType: e });
}
s(lh, "nullable");
function _o(e) {
  return new $e({ type: "optional", innerType: e });
}
s(_o, "optional");
function Yd(e) {
  return _o(lh(e));
}
s(Yd, "nullableOptional3");
function rw() {
  return d.object({
    numItems: d.number(),
    cursor: lh(d.string()),
    endCursor: Yd(d.string()),
    id: _o(d.number()),
    maximumRowsRead: _o(d.number()),
    maximumBytesRead: _o(d.number())
  });
}
s(rw, "paginationOpts");
function nw(e) {
  return d.object({
    page: d.array(e),
    isDone: d.boolean(),
    continueCursor: d.string(),
    splitCursor: Yd(d.string()),
    pageStatus: Yd(d.enum(["SplitRecommended", "SplitRequired"]))
  });
}
s(nw, "paginationResult");
var p = {
  /**
   * Date ↔ timestamp codec
   * @see {@link date}
   */
  date: Qx,
  /**
   * Convex ID validator
   * @see {@link id}
   */
  id: xo,
  /**
   * Custom codec builder
   * @see {@link codec}
   */
  codec: Yx,
  /**
   * Pagination options schema matching Convex's PaginationOptions type
   * @see {@link paginationOpts}
   */
  paginationOpts: rw,
  /**
   * Paginated result schema wrapping any item schema in Convex's PaginationResult shape
   * @see {@link paginationResult}
   */
  paginationResult: nw,
  /**
   * Base schema for a model (user fields only; no system fields).
   * For object models reconstructs from fields; for union models returns the
   * user-supplied union. Cached per-model.
   * @see {@link base}
   */
  base: tf,
  /**
   * Doc schema: model fields + _id + _creationTime
   * @see {@link doc}
   */
  doc: uh,
  /**
   * Update schema: _id required, all other fields optional
   * @see {@link update}
   */
  update: ew,
  /**
   * Doc array schema: z.array(doc(model))
   * @see {@link docArray}
   */
  docArray: tw
};

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/codecs.mjs
var ir = class {
  static {
    s(this, "SecretText");
  }
  constructor(r) {
    this.value = r;
  }
  reveal() {
    return this.value;
  }
}, _ = d.codec(d.string(), d.instanceof(ir), {
  decode: /* @__PURE__ */ s((e) => new ir(e), "decode"),
  encode: /* @__PURE__ */ s((e) => e.reveal(), "encode")
}), Oj = d.codec(d.string(), d.string().min(3), {
  decode: /* @__PURE__ */ s((e) => e, "decode"),
  encode: /* @__PURE__ */ s((e) => e, "encode")
});

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/probe.js
$.descriptors.push("probe");
var dh = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), fh = { doc: dh, insert: dh };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused0.js
$.descriptors.push("unused0");
var ph = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), mh = { doc: ph, insert: ph };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused1.js
$.descriptors.push("unused1");
var hh = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), gh = { doc: hh, insert: hh };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused10.js
$.descriptors.push("unused10");
var vh = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), yh = { doc: vh, insert: vh };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused11.js
$.descriptors.push("unused11");
var bh = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), $h = { doc: bh, insert: bh };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused12.js
$.descriptors.push("unused12");
var _h = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), xh = { doc: _h, insert: _h };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused13.js
$.descriptors.push("unused13");
var wh = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), kh = { doc: wh, insert: wh };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused14.js
$.descriptors.push("unused14");
var Ih = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), zh = { doc: Ih, insert: Ih };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused15.js
$.descriptors.push("unused15");
var Sh = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), Oh = { doc: Sh, insert: Sh };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused16.js
$.descriptors.push("unused16");
var jh = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), Ah = { doc: jh, insert: jh };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused17.js
$.descriptors.push("unused17");
var Ph = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), Dh = { doc: Ph, insert: Ph };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused18.js
$.descriptors.push("unused18");
var Nh = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), Th = { doc: Nh, insert: Nh };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused19.js
$.descriptors.push("unused19");
var Uh = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), Eh = { doc: Uh, insert: Uh };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused2.js
$.descriptors.push("unused2");
var Ch = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), Zh = { doc: Ch, insert: Ch };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused20.js
$.descriptors.push("unused20");
var Rh = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), Fh = { doc: Rh, insert: Rh };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused21.js
$.descriptors.push("unused21");
var Lh = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), Vh = { doc: Lh, insert: Lh };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused22.js
$.descriptors.push("unused22");
var Mh = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), Bh = { doc: Mh, insert: Mh };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused23.js
$.descriptors.push("unused23");
var Jh = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), qh = { doc: Jh, insert: Jh };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused24.js
$.descriptors.push("unused24");
var Kh = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), Wh = { doc: Kh, insert: Kh };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused25.js
$.descriptors.push("unused25");
var Gh = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), Xh = { doc: Gh, insert: Gh };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused26.js
$.descriptors.push("unused26");
var Hh = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), Qh = { doc: Hh, insert: Hh };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused27.js
$.descriptors.push("unused27");
var Yh = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), eg = { doc: Yh, insert: Yh };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused28.js
$.descriptors.push("unused28");
var tg = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), rg = { doc: tg, insert: tg };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused29.js
$.descriptors.push("unused29");
var ng = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), ig = { doc: ng, insert: ng };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused3.js
$.descriptors.push("unused3");
var og = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), ag = { doc: og, insert: og };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused30.js
$.descriptors.push("unused30");
var sg = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), cg = { doc: sg, insert: sg };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused31.js
$.descriptors.push("unused31");
var ug = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), lg = { doc: ug, insert: ug };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused32.js
$.descriptors.push("unused32");
var dg = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), fg = { doc: dg, insert: dg };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused33.js
$.descriptors.push("unused33");
var pg = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), mg = { doc: pg, insert: pg };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused34.js
$.descriptors.push("unused34");
var hg = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), gg = { doc: hg, insert: hg };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused35.js
$.descriptors.push("unused35");
var vg = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), yg = { doc: vg, insert: vg };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused36.js
$.descriptors.push("unused36");
var bg = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), $g = { doc: bg, insert: bg };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused37.js
$.descriptors.push("unused37");
var _g = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), xg = { doc: _g, insert: _g };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused38.js
$.descriptors.push("unused38");
var wg = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), kg = { doc: wg, insert: wg };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused39.js
$.descriptors.push("unused39");
var Ig = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), zg = { doc: Ig, insert: Ig };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused4.js
$.descriptors.push("unused4");
var Sg = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), Og = { doc: Sg, insert: Sg };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused40.js
$.descriptors.push("unused40");
var jg = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), Ag = { doc: jg, insert: jg };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused41.js
$.descriptors.push("unused41");
var Pg = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), Dg = { doc: Pg, insert: Pg };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused42.js
$.descriptors.push("unused42");
var Ng = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), Tg = { doc: Ng, insert: Ng };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused43.js
$.descriptors.push("unused43");
var Ug = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), Eg = { doc: Ug, insert: Ug };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused44.js
$.descriptors.push("unused44");
var Cg = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), Zg = { doc: Cg, insert: Cg };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused45.js
$.descriptors.push("unused45");
var Rg = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), Fg = { doc: Rg, insert: Rg };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused46.js
$.descriptors.push("unused46");
var Lg = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), Vg = { doc: Lg, insert: Lg };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused47.js
$.descriptors.push("unused47");
var Mg = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), Bg = { doc: Mg, insert: Mg };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused48.js
$.descriptors.push("unused48");
var Jg = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), qg = { doc: Jg, insert: Jg };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused49.js
$.descriptors.push("unused49");
var Kg = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), Wg = { doc: Kg, insert: Kg };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused5.js
$.descriptors.push("unused5");
var Gg = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), Xg = { doc: Gg, insert: Gg };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused50.js
$.descriptors.push("unused50");
var Hg = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), Qg = { doc: Hg, insert: Hg };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused51.js
$.descriptors.push("unused51");
var Yg = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), ev = { doc: Yg, insert: Yg };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused52.js
$.descriptors.push("unused52");
var tv = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), rv = { doc: tv, insert: tv };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused53.js
$.descriptors.push("unused53");
var nv = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), iv = { doc: nv, insert: nv };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused54.js
$.descriptors.push("unused54");
var ov = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), av = { doc: ov, insert: ov };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused55.js
$.descriptors.push("unused55");
var sv = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), cv = { doc: sv, insert: sv };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused56.js
$.descriptors.push("unused56");
var uv = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), lv = { doc: uv, insert: uv };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused57.js
$.descriptors.push("unused57");
var dv = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), fv = { doc: dv, insert: dv };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused58.js
$.descriptors.push("unused58");
var pv = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), mv = { doc: pv, insert: pv };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused59.js
$.descriptors.push("unused59");
var hv = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), gv = { doc: hv, insert: hv };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused6.js
$.descriptors.push("unused6");
var vv = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), yv = { doc: vv, insert: vv };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused60.js
$.descriptors.push("unused60");
var bv = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), $v = { doc: bv, insert: bv };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused61.js
$.descriptors.push("unused61");
var _v = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), xv = { doc: _v, insert: _v };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused62.js
$.descriptors.push("unused62");
var wv = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), kv = { doc: wv, insert: wv };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused63.js
$.descriptors.push("unused63");
var Iv = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), zv = { doc: Iv, insert: Iv };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused7.js
$.descriptors.push("unused7");
var Sv = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), Ov = { doc: Sv, insert: Sv };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused8.js
$.descriptors.push("unused8");
var jv = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), Av = { doc: jv, insert: jv };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/unused9.js
$.descriptors.push("unused9");
var Pv = d.looseObject({ createdAt: p.date(), nested: d.looseObject({ history: d.array(p.date()) }), secret: _, updatedAt: d.optional(p.date()) }), Dv = { doc: Pv, insert: Pv };

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/_zodvex/models/index.js
var ko = {
  probe: fh,
  unused0: mh,
  unused1: gh,
  unused10: yh,
  unused11: $h,
  unused12: xh,
  unused13: kh,
  unused14: zh,
  unused15: Oh,
  unused16: Ah,
  unused17: Dh,
  unused18: Th,
  unused19: Eh,
  unused2: Zh,
  unused20: Fh,
  unused21: Vh,
  unused22: Bh,
  unused23: qh,
  unused24: Wh,
  unused25: Xh,
  unused26: Qh,
  unused27: eg,
  unused28: rg,
  unused29: ig,
  unused3: ag,
  unused30: cg,
  unused31: lg,
  unused32: fg,
  unused33: mg,
  unused34: gg,
  unused35: yg,
  unused36: $g,
  unused37: xg,
  unused38: kg,
  unused39: zg,
  unused4: Og,
  unused40: Ag,
  unused41: Dg,
  unused42: Tg,
  unused43: Eg,
  unused44: Zg,
  unused45: Fg,
  unused46: Vg,
  unused47: Bg,
  unused48: qg,
  unused49: Wg,
  unused5: Xg,
  unused50: Qg,
  unused51: ev,
  unused52: rv,
  unused53: iv,
  unused54: av,
  unused55: cv,
  unused56: lv,
  unused57: fv,
  unused58: mv,
  unused59: gv,
  unused6: yv,
  unused60: $v,
  unused61: xv,
  unused62: kv,
  unused63: zv,
  unused7: Ov,
  unused8: Av,
  unused9: Dv
};

// ../../node_modules/.bun/convex-helpers@0.1.113+b9ed8f5244cf7f28/node_modules/convex-helpers/index.js
var qN = Symbol();

// ../../node_modules/.bun/convex-helpers@0.1.113+b9ed8f5244cf7f28/node_modules/convex-helpers/validators.js
var QN = j.string(), YN = j.float64(), eT = j.float64(), tT = j.boolean(), rT = j.int64(), nT = j.int64(), iT = j.any(), oT = j.null(), { id: aT, object: sT, array: cT, bytes: uT, literal: lT, optional: dT, union: fT } = j, pT = j.bytes();
var mT = j.optional(j.any());

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/functionName.js
var rf = Symbol.for("functionName");

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/components/paths.js
var iw = Symbol.for("toReferencePath");

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/pagination.js
var cw = j.object({
  numItems: j.number(),
  cursor: j.union(j.string(), j.null()),
  endCursor: j.optional(j.union(j.string(), j.null())),
  id: j.optional(j.number()),
  maximumRowsRead: j.optional(j.number()),
  maximumBytesRead: j.optional(j.number())
});

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/api.js
function Nv(e = []) {
  let r = {
    get(i, o) {
      if (typeof o == "string") {
        let t = [...e, o];
        return Nv(t);
      } else if (o === rf) {
        if (e.length < 2) {
          let a = ["api", ...e].join(".");
          throw new Error(
            `API path is expected to be of the form \`api.moduleName.functionName\`. Found: \`${a}\``
          );
        }
        let t = e.slice(0, -1).join("/"), n = e[e.length - 1];
        return n === "default" ? t : t + ":" + n;
      } else return o === Symbol.toStringTag ? "FunctionReference" : void 0;
    }
  };
  return new Proxy({}, r);
}
s(Nv, "createApi");
var uw = Nv();

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/schema.js
var dw = Object.defineProperty, fw = /* @__PURE__ */ s((e, r, i) => r in e ? dw(e, r, { enumerable: !0, configurable: !0, writable: !0, value: i }) : e[r] = i, "__defNormalProp"), Ae = /* @__PURE__ */ s((e, r, i) => fw(e, typeof r != "symbol" ? r + "" : r, i), "__publicField"), Io = class {
  static {
    s(this, "TableDefinition");
  }
  /**
   * @internal
   */
  constructor(r) {
    Ae(this, "indexes"), Ae(this, "stagedDbIndexes"), Ae(this, "searchIndexes"), Ae(this, "stagedSearchIndexes"), Ae(this, "vectorIndexes"), Ae(this, "stagedVectorIndexes"), Ae(this, "validator"), this.indexes = [], this.stagedDbIndexes = [], this.searchIndexes = [], this.stagedSearchIndexes = [], this.vectorIndexes = [], this.stagedVectorIndexes = [], this.validator = r;
  }
  /**
   * This API is experimental: it may change or disappear.
   *
   * Returns indexes defined on this table.
   * Intended for the advanced use cases of dynamically deciding which index to use for a query.
   * If you think you need this, please chime in on ths issue in the Convex JS GitHub repo.
   * https://github.com/get-convex/convex-js/issues/49
   */
  " indexes"() {
    return this.indexes;
  }
  index(r, i) {
    return Array.isArray(i) ? this.indexes.push({
      indexDescriptor: r,
      fields: i
    }) : i.staged ? this.stagedDbIndexes.push({
      indexDescriptor: r,
      fields: i.fields
    }) : this.indexes.push({
      indexDescriptor: r,
      fields: i.fields
    }), this;
  }
  searchIndex(r, i) {
    return i.staged ? this.stagedSearchIndexes.push({
      indexDescriptor: r,
      searchField: i.searchField,
      filterFields: i.filterFields || []
    }) : this.searchIndexes.push({
      indexDescriptor: r,
      searchField: i.searchField,
      filterFields: i.filterFields || []
    }), this;
  }
  vectorIndex(r, i) {
    return i.staged ? this.stagedVectorIndexes.push({
      indexDescriptor: r,
      vectorField: i.vectorField,
      dimensions: i.dimensions,
      filterFields: i.filterFields || []
    }) : this.vectorIndexes.push({
      indexDescriptor: r,
      vectorField: i.vectorField,
      dimensions: i.dimensions,
      filterFields: i.filterFields || []
    }), this;
  }
  /**
   * Work around for https://github.com/microsoft/TypeScript/issues/57035
   */
  self() {
    return this;
  }
  /**
   * Export the contents of this definition.
   *
   * This is called internally by the Convex framework.
   * @internal
   */
  export() {
    let r = this.validator.json;
    if (typeof r != "object")
      throw new Error(
        "Invalid validator: please make sure that the parameter of `defineTable` is valid (see https://docs.convex.dev/database/schemas)"
      );
    return {
      indexes: this.indexes,
      stagedDbIndexes: this.stagedDbIndexes,
      searchIndexes: this.searchIndexes,
      stagedSearchIndexes: this.stagedSearchIndexes,
      vectorIndexes: this.vectorIndexes,
      stagedVectorIndexes: this.stagedVectorIndexes,
      documentType: r
    };
  }
};
function un(e) {
  return xf(e) ? new Io(e) : new Io(j.object(e));
}
s(un, "defineTable");
var af = class {
  static {
    s(this, "SchemaDefinition");
  }
  /**
   * @internal
   */
  constructor(r, i) {
    Ae(this, "tables"), Ae(this, "strictTableNameTypes"), Ae(this, "schemaValidation"), this.tables = r, this.schemaValidation = i?.schemaValidation === void 0 ? !0 : i.schemaValidation;
  }
  /**
   * Export the contents of this definition.
   *
   * This is called internally by the Convex framework.
   * @internal
   */
  export() {
    return JSON.stringify({
      tables: Object.entries(this.tables).map(([r, i]) => {
        let {
          indexes: o,
          stagedDbIndexes: t,
          searchIndexes: n,
          stagedSearchIndexes: a,
          vectorIndexes: c,
          stagedVectorIndexes: u,
          documentType: l
        } = i.export();
        return {
          tableName: r,
          indexes: o,
          stagedDbIndexes: t,
          searchIndexes: n,
          stagedSearchIndexes: a,
          vectorIndexes: c,
          stagedVectorIndexes: u,
          documentType: l
        };
      }),
      schemaValidation: this.schemaValidation
    });
  }
};
function sf(e, r) {
  return new af(e, r);
}
s(sf, "defineSchema");
var eC = sf({
  _scheduled_functions: un({
    name: j.string(),
    args: j.array(j.any()),
    scheduledTime: j.float64(),
    completedTime: j.optional(j.float64()),
    state: j.union(
      j.object({ kind: j.literal("pending") }),
      j.object({ kind: j.literal("inProgress") }),
      j.object({ kind: j.literal("success") }),
      j.object({ kind: j.literal("failed"), error: j.string() }),
      j.object({ kind: j.literal("canceled") })
    )
  }),
  _storage: un({
    sha256: j.string(),
    size: j.float64(),
    contentType: j.optional(j.string())
  })
});

// ../../packages/zodvex/dist/server/index.js
function ln(e) {
  if (e == null)
    return e;
  if (Array.isArray(e))
    return e.map(ln);
  if (typeof e == "object" && e.constructor === Object) {
    let r = {};
    for (let [i, o] of Object.entries(e))
      o !== void 0 && (r[i] = ln(o));
    return r;
  }
  return e;
}
s(ln, "stripUndefined");
function Cv(e, r) {
  return tt(e, r);
}
s(Cv, "decodeDoc");
function Tv(e, r) {
  return ln(De(e, r));
}
s(Tv, "encodeDoc");
function Uv(e) {
  let r = {};
  for (let [i, o] of Object.entries(e))
    r[i] = o === void 0 ? void 0 : ln(o);
  return r;
}
s(Uv, "stripUndefinedPreservingTopLevel");
function pw(e, r) {
  if (!(e instanceof be)) {
    let a = De(e, r);
    return a !== null && typeof a == "object" && !Array.isArray(a) ? Uv(a) : ln(a);
  }
  let i = e._zod.def.shape, o = {};
  for (let [a, c] of Object.entries(i))
    o[a] = c instanceof $e ? c : new $e({ type: "optional", innerType: c });
  let t = d.object(o), n = De(t, r);
  return Uv(n);
}
s(pw, "encodePartialDoc");
function cf(e, r, i) {
  if (r.includes(".")) return i;
  if (e instanceof be) {
    let o = e.shape[r];
    if (o) return De(o, i);
  }
  if (e instanceof Ie) {
    let t = e._zod.def.options.filter((n) => n instanceof be).map((n) => n.shape[r]).filter(Boolean);
    if (t.length === 1) return De(t[0], i);
    if (t.length > 1)
      return De(d.union(t), i);
  }
  return i;
}
s(cf, "encodeIndexValue");
function Oo(e, r) {
  return new Proxy(e, {
    get(i, o, t) {
      return typeof o == "string" && ["eq", "gt", "gte", "lt", "lte"].includes(o) ? (n, a) => {
        let c = cf(r, n, a), u = i[o](n, c);
        return Oo(u, r);
      } : o === "search" ? (...n) => {
        let a = i.search(...n);
        return Oo(a, r);
      } : Reflect.get(i, o, t);
    }
  });
}
s(Oo, "wrapIndexRangeBuilder");
function uf(e, r) {
  return e != null && Object.prototype.isPrototypeOf.call(r, e);
}
s(uf, "isFilterExpression");
function Ev(e, r) {
  if (uf(e, r)) {
    let i = e.serialize();
    if (i && typeof i == "object" && "$field" in i)
      return i.$field;
  }
  return null;
}
s(Ev, "extractFieldPath");
function mw(e, r) {
  let i = Object.getPrototypeOf(e.field("_id"));
  return new Proxy(e, {
    get(o, t, n) {
      return typeof t == "string" && ["eq", "neq", "lt", "lte", "gt", "gte"].includes(t) ? (a, c) => {
        let u = Ev(a, i), l = Ev(c, i);
        return u && !uf(c, i) ? c = cf(r, u, c) : l && !uf(a, i) && (a = cf(r, l, a)), o[t](a, c);
      } : Reflect.get(o, t, n);
    }
  });
}
s(mw, "wrapFilterBuilder");
var df = class Zv {
  static {
    s(this, "_ZodvexQueryChain");
  }
  constructor(r, i) {
    this.inner = r, this.schema = i;
  }
  /** Factory method for intermediate methods. Subclasses override to return their own type. */
  createChain(r) {
    return new Zv(r, this.schema);
  }
  /** Decode a wire-format doc and cast to the decoded document type. */
  decode(r) {
    return Cv(this.schema, r);
  }
  // --- Intermediate methods: wire-typed TableInfo for Convex machinery ---
  fullTableScan() {
    return this.createChain(this.inner.fullTableScan());
  }
  withIndex(r, i) {
    let o = i ? (t) => i(Oo(t, this.schema)) : void 0;
    return this.createChain(this.inner.withIndex(r, o));
  }
  withSearchIndex(r, i) {
    let o = /* @__PURE__ */ s((t) => i(Oo(t, this.schema)), "wrappedFilter");
    return this.createChain(this.inner.withSearchIndex(r, o));
  }
  order(r) {
    return this.createChain(this.inner.order(r));
  }
  // Implementation
  filter(r) {
    let i = /* @__PURE__ */ s((o) => r(mw(o, this.schema)), "wrappedPredicate");
    return this.createChain(this.inner.filter(i));
  }
  limit(r) {
    return this.createChain(this.inner.limit(r));
  }
  count() {
    return this.inner.count();
  }
  // --- Terminal methods: return decoded Doc type ---
  async first() {
    let r = await this.inner.first();
    return r ? this.decode(r) : null;
  }
  async unique() {
    let r = await this.inner.unique();
    return r ? this.decode(r) : null;
  }
  async collect() {
    return (await this.inner.collect()).map((i) => this.decode(i));
  }
  async take(r) {
    return (await this.inner.take(r)).map((o) => this.decode(o));
  }
  async paginate(r) {
    let i = await this.inner.paginate(r);
    return {
      ...i,
      page: i.page.map((o) => this.decode(o))
    };
  }
  // --- AsyncIterable: decode each yielded document ---
  async *[Symbol.asyncIterator]() {
    for await (let r of this.inner)
      yield this.decode(r);
  }
};
function lf(e, r, i) {
  for (let o of Object.keys(r))
    if (e.normalizeId(o, i))
      return o;
  return null;
}
s(lf, "resolveTableName");
var ff = class {
  static {
    s(this, "ZodvexDatabaseReader");
  }
  constructor(e, r) {
    this.db = e, this.tableMap = r, this.system = e.system;
  }
  system;
  /** @internal Expose for wrapper construction (rule/audit subclasses) */
  get _internals() {
    return { db: this.db, tableMap: this.tableMap };
  }
  /**
   * Escape hatch (#85/#92): returns the database this codec wrapper delegates
   * to — the composed underlying stack when `underlyingDb` is configured (e.g.
   * a trigger-wrapped writer), the bare Convex db otherwise.
   *
   * The returned db is native-shape: reads are undecoded wire documents and it
   * bypasses codec, `.withRules()`, and `.audit()` layers entirely.
   */
  unwrap() {
    return this.db;
  }
  normalizeId(e, r) {
    return this.db.normalizeId(e, r);
  }
  async get(e, r) {
    let i, o;
    if (r !== void 0 ? (i = e, o = await this.db.get(e, r)) : (o = await this.db.get(e), i = o ? lf(this.db, this.tableMap, e) : null), !o) return null;
    let t = i ? this.tableMap[i] : void 0;
    return t ? Cv(t.doc, o) : o;
  }
  query(e) {
    let r = this.tableMap[e], i = this.db.query(e);
    return r ? new df(i, r.doc) : i;
  }
  /**
   * Returns a new ZodvexDatabaseReader that applies per-table read rules.
   * The returned reader is also a ZodvexDatabaseReader, so `.withRules()` can be chained.
   */
  withRules(e, r, i) {
    return new Fv(this, e, r, i ?? {});
  }
  /**
   * Returns a new ZodvexDatabaseReader that fires audit callbacks on reads.
   * The returned reader is also a ZodvexDatabaseReader, so `.audit()` can be chained
   * with `.withRules()`.
   */
  audit(e) {
    return new Vv(this, e);
  }
}, jo = class extends ff {
  static {
    s(this, "ZodvexDatabaseWriter");
  }
  // Narrows the inherited `protected db` to the writer-typed view without
  // shadowing the underlying instance. Used by the write methods below.
  get writerDb() {
    return this.db;
  }
  constructor(e, r) {
    super(e, r), this.system = e.system;
  }
  /**
   * @internal Expose writer-typed internals for rules / audit subclasses.
   * Includes a `reader` field that aliases `this` (writer IS-A reader after
   * the #64 refactor) so callers expecting `_internals.reader` still work.
   */
  get _internals() {
    return { db: this.writerDb, tableMap: this.tableMap, reader: this };
  }
  /**
   * Escape hatch (#85/#92): returns the writer this codec wrapper delegates
   * to — the composed underlying stack when `underlyingDb` is configured (e.g.
   * a trigger-wrapped writer), the bare Convex db otherwise.
   *
   * The returned db is native-shape: writes must be wire-format and it
   * bypasses codec, `.withRules()`, and `.audit()` layers entirely.
   */
  unwrap() {
    return this.writerDb;
  }
  async insert(e, r) {
    let i = this.tableMap[e], o = i ? Tv(i.insert, r) : r;
    return this.writerDb.insert(e, o);
  }
  async patch(e, r, i) {
    let o, t, n;
    i !== void 0 ? (o = e, t = r, n = i) : (t = e, n = r, o = lf(this.db, this.tableMap, t));
    let a = o ? this.tableMap[o] : void 0, c = a ? pw(a.insert, n) : n;
    return i !== void 0 ? this.writerDb.patch(e, t, c) : this.writerDb.patch(t, c);
  }
  async replace(e, r, i) {
    let o, t, n;
    i !== void 0 ? (o = e, t = r, n = i) : (t = e, n = r, o = lf(this.db, this.tableMap, t));
    let a = o ? this.tableMap[o] : void 0, c = a ? Tv(a.insert, n) : n;
    return i !== void 0 ? this.writerDb.replace(e, t, c) : this.writerDb.replace(t, c);
  }
  async delete(e, r) {
    return r !== void 0 ? this.writerDb.delete(e, r) : this.writerDb.delete(e);
  }
  /**
   * Returns a new ZodvexDatabaseWriter that applies per-table read and write rules.
   * The returned writer is also a ZodvexDatabaseWriter, so `.withRules()` can be chained.
   *
   * Overrides Reader's signature so a writer chained call returns a writer.
   */
  withRules(e, r, i) {
    return new gw(this, e, r, i ?? {});
  }
  /**
   * Returns a new ZodvexDatabaseWriter that fires audit callbacks on reads and writes.
   * The returned writer is also a ZodvexDatabaseWriter, so `.audit()` can be chained
   * with `.withRules()`.
   *
   * Overrides Reader's signature so a writer chained call returns a writer.
   */
  audit(e) {
    return new yw(this, e);
  }
};
function zo(e, r) {
  return e === !0 ? r : e === !1 ? null : e;
}
s(zo, "normalizeReadResult");
var hw = class Rv extends df {
  static {
    s(this, "_RulesQueryChain");
  }
  readRule;
  rulesConfig;
  ctx;
  constructor(r, i, o, t, n = {}) {
    super(r, i), this.readRule = o, this.rulesConfig = t, this.ctx = n;
  }
  createChain(r) {
    return new Rv(r, this.schema, this.readRule, this.rulesConfig, this.ctx);
  }
  async first() {
    for await (let r of this)
      return r;
    return null;
  }
  async unique() {
    let r = await super.unique();
    return r === null ? null : zo(await this.readRule(this.ctx, r), r);
  }
  async collect() {
    let r = [];
    for await (let i of this)
      r.push(i);
    return r;
  }
  async take(r) {
    if (!Number.isInteger(r) || r < 0)
      throw new Error("take requires a non-negative integer");
    let i = [];
    if (r === 0) return i;
    for await (let o of this)
      if (i.push(o), i.length >= r) break;
    return i;
  }
  async paginate(r) {
    let i = await super.paginate(r), o = [];
    for (let t of i.page) {
      let n = zo(await this.readRule(this.ctx, t), t);
      n !== null && o.push(n);
    }
    return { ...i, page: o };
  }
  async count() {
    if (!this.rulesConfig.allowCounting)
      throw new Error("count is not allowed with rules");
    return super.count();
  }
  async *[Symbol.asyncIterator]() {
    for await (let r of super[Symbol.asyncIterator]()) {
      let i = zo(await this.readRule(this.ctx, r), r);
      i !== null && (yield i);
    }
  }
};
function So(e, r, i, o) {
  for (let t of Object.keys(i))
    if (e.normalizeId(t, r))
      return t;
  if ((o.defaultPolicy ?? "allow") === "deny") {
    for (let t of Object.keys(e._internals.tableMap))
      if (e.normalizeId(t, r))
        return t;
  }
  return null;
}
s(So, "resolveRulesTableName");
var Fv = class extends ff {
  static {
    s(this, "RulesDatabaseReader");
  }
  constructor(e, r, i, o) {
    let { db: t, tableMap: n } = e._internals;
    super(t, n), this.inner = e, this.ctx = r, this.rules = i, this.rulesConfig = o, this.system = e.system;
  }
  async get(e, r) {
    let i = await this.inner.get(e, r);
    if (i === null) return null;
    let o = r !== void 0 ? e : So(this.inner, e, this.rules, this.rulesConfig);
    return o ? this.applyReadRule(o, i) : i;
  }
  query(e) {
    let r = this.rules[e];
    if (!r?.read && (this.rulesConfig.defaultPolicy ?? "allow") === "allow")
      return this.inner.query(e);
    let i = this.inner.query(e), o = r?.read ?? (async () => null), t = d.any();
    return new hw(i, t, o, this.rulesConfig, this.ctx);
  }
  async applyReadRule(e, r) {
    let i = this.rules[e];
    if (!i?.read)
      return (this.rulesConfig.defaultPolicy ?? "allow") === "deny" ? null : r;
    let o = await i.read(this.ctx, r);
    return zo(o, r);
  }
}, gw = class extends jo {
  static {
    s(this, "RulesDatabaseWriter");
  }
  constructor(e, r, i, o) {
    let { db: t, tableMap: n, reader: a } = e._internals;
    super(t, n), this.inner = e, this.ctx = r, this.rules = i, this.rulesConfig = o, this.rulesReader = new Fv(a, r, i, o), this.system = e.system;
  }
  rulesReader;
  normalizeId(e, r) {
    return this.rulesReader.normalizeId(e, r);
  }
  async get(e, r) {
    return this.rulesReader.get(e, r);
  }
  query(e) {
    return this.rulesReader.query(e);
  }
  async insert(e, r) {
    let i = e, o = this.rules[i];
    if (o?.insert) {
      let t = await o.insert(this.ctx, r);
      return this.inner.insert(
        e,
        t
      );
    }
    if ((this.rulesConfig.defaultPolicy ?? "allow") === "deny")
      throw new Error(`insert not allowed on ${i}`);
    return this.inner.insert(e, r);
  }
  async patch(e, r, i) {
    let o, t;
    i !== void 0 ? (o = r, t = i) : (o = e, t = r);
    let n = await this.rulesReader.get(o);
    if (n === null)
      throw new Error("no read access or doc does not exist");
    let a = So(this.inner, o, this.rules, this.rulesConfig), c = a ? this.rules[a] : void 0;
    if (c?.patch) {
      let u = await c.patch(this.ctx, n, t);
      return this.inner.patch(
        o,
        u
      );
    }
    if ((this.rulesConfig.defaultPolicy ?? "allow") === "deny")
      throw new Error(`patch not allowed on ${a}`);
    return this.inner.patch(o, t);
  }
  async replace(e, r, i) {
    let o, t;
    i !== void 0 ? (o = r, t = i) : (o = e, t = r);
    let n = await this.rulesReader.get(o);
    if (n === null)
      throw new Error("no read access or doc does not exist");
    let a = So(this.inner, o, this.rules, this.rulesConfig), c = a ? this.rules[a] : void 0;
    if (c?.replace) {
      let u = await c.replace(this.ctx, n, t);
      return this.inner.replace(o, u);
    }
    if ((this.rulesConfig.defaultPolicy ?? "allow") === "deny")
      throw new Error(`replace not allowed on ${a}`);
    return this.inner.replace(o, t);
  }
  async delete(e, r) {
    let i;
    r !== void 0 ? i = r : i = e;
    let o = await this.rulesReader.get(i);
    if (o === null)
      throw new Error("no read access or doc does not exist");
    let t = So(this.inner, i, this.rules, this.rulesConfig), n = t ? this.rules[t] : void 0;
    if (n?.delete)
      return await n.delete(this.ctx, o), this.inner.delete(i);
    if ((this.rulesConfig.defaultPolicy ?? "allow") === "deny")
      throw new Error(`delete not allowed on ${t}`);
    return this.inner.delete(i);
  }
}, vw = class Lv extends df {
  static {
    s(this, "_AuditQueryChain");
  }
  afterRead;
  tableName;
  constructor(r, i, o, t) {
    super(r, i), this.afterRead = o, this.tableName = t;
  }
  createChain(r) {
    return new Lv(r, this.schema, this.afterRead, this.tableName);
  }
  async first() {
    let r = await super.first();
    return r !== null && await this.afterRead(this.tableName, r), r;
  }
  async unique() {
    let r = await super.unique();
    return r !== null && await this.afterRead(this.tableName, r), r;
  }
  async collect() {
    let r = await super.collect();
    for (let i of r)
      await this.afterRead(this.tableName, i);
    return r;
  }
  async take(r) {
    let i = await super.take(r);
    for (let o of i)
      await this.afterRead(this.tableName, o);
    return i;
  }
  async paginate(r) {
    let i = await super.paginate(r);
    for (let o of i.page)
      await this.afterRead(this.tableName, o);
    return i;
  }
  async *[Symbol.asyncIterator]() {
    for await (let r of super[Symbol.asyncIterator]())
      await this.afterRead(this.tableName, r), yield r;
  }
}, Vv = class extends ff {
  static {
    s(this, "AuditDatabaseReader");
  }
  inner;
  afterRead;
  constructor(e, r) {
    let { db: i, tableMap: o } = e._internals;
    super(i, o), this.inner = e, this.afterRead = r.afterRead ?? (() => {
    }), this.system = e.system;
  }
  async get(e, r) {
    let i = await this.inner.get(e, r);
    if (i !== null) {
      let o = this.resolveTableFromId(
        r !== void 0 ? r : e,
        r !== void 0 ? e : void 0
      );
      o && await this.afterRead(o, i);
    }
    return i;
  }
  query(e) {
    let r = this.inner.query(e), i = d.any();
    return new vw(r, i, this.afterRead, e);
  }
  resolveTableFromId(e, r) {
    if (r) return r;
    for (let i of Object.keys(this.tableMap))
      if (this.inner.normalizeId(i, e))
        return i;
    return null;
  }
}, yw = class extends jo {
  static {
    s(this, "AuditDatabaseWriter");
  }
  inner;
  auditReader;
  afterWrite;
  constructor(e, r) {
    let { db: i, tableMap: o, reader: t } = e._internals;
    super(i, o), this.inner = e, this.afterWrite = r.afterWrite, this.auditReader = r.afterRead ? new Vv(t, { afterRead: r.afterRead }) : t, this.system = e.system;
  }
  normalizeId(e, r) {
    return this.auditReader.normalizeId(e, r);
  }
  async get(e, r) {
    return this.auditReader.get(e, r);
  }
  query(e) {
    return this.auditReader.query(e);
  }
  async insert(e, r) {
    let i = await this.inner.insert(e, r);
    return this.afterWrite && await this.afterWrite(e, { type: "insert", id: i, value: r }), i;
  }
  async patch(e, r, i) {
    let o, t;
    i !== void 0 ? (o = r, t = i) : (o = e, t = r);
    let n = await this.inner.get(o);
    if (i !== void 0 ? await this.inner.patch(e, r, i) : await this.inner.patch(o, t), this.afterWrite) {
      let a = this.resolveTableFromId(o);
      a && await this.afterWrite(a, { type: "patch", id: o, doc: n, value: t });
    }
  }
  async replace(e, r, i) {
    let o, t;
    i !== void 0 ? (o = r, t = i) : (o = e, t = r);
    let n = await this.inner.get(o);
    if (i !== void 0 ? await this.inner.replace(e, r, i) : await this.inner.replace(o, t), this.afterWrite) {
      let a = this.resolveTableFromId(o);
      a && await this.afterWrite(a, { type: "replace", id: o, doc: n, value: t });
    }
  }
  async delete(e, r) {
    let i;
    r !== void 0 ? i = r : i = e;
    let o = await this.inner.get(i);
    if (r !== void 0 ? await this.inner.delete(e, r) : await this.inner.delete(i), this.afterWrite) {
      let t = this.resolveTableFromId(i);
      t && await this.afterWrite(t, { type: "delete", id: i, doc: o });
    }
  }
  resolveTableFromId(e) {
    for (let r of Object.keys(this.inner._internals.tableMap))
      if (this.inner.normalizeId(r, e))
        return r;
    return null;
  }
};
function Ao(e) {
  let r = /* @__PURE__ */ Symbol.for(`zodvex.zx.cache.${e}`), i = globalThis, o = i[r];
  if (o) return o;
  let t = /* @__PURE__ */ new WeakMap();
  return i[r] = t, t;
}
s(Ao, "sharedWeakMap");
var t1 = Ao("base"), r1 = Ao("doc"), n1 = Ao("update"), i1 = Ao("docArray");

// results/descriptor-experiment-2026-09-09/memory/fixtures/64/db-fixture.mjs
function bw(e = []) {
  let r = new Map(e.map((n) => [n._id, n])), i = [], o = /* @__PURE__ */ s((n) => n.length === 2 ? n[1] : n[0], "idFrom");
  return { database: {
    normalizeId(n, a) {
      return String(a).startsWith(`${n}:`) ? a : null;
    },
    async get(...n) {
      return i.push("get"), r.get(o(n)) ?? null;
    },
    query(n) {
      return { async take(a) {
        return i.push("take"), [...r.values()].filter((c) => c._id.startsWith(`${n}:`)).slice(0, a);
      } };
    },
    async insert(n, a) {
      i.push("insert");
      let c = `${n}:${r.size + 1}`;
      return r.set(c, { ...a, _id: c, _creationTime: 100 }), c;
    },
    async patch(...n) {
      i.push("patch");
      let a = n.at(-2), c = n.at(-1), u = { ...r.get(a), ...c };
      for (let [l, f] of Object.entries(c)) f === void 0 && delete u[l];
      r.set(a, u);
    },
    async replace(...n) {
      i.push("replace");
      let a = n.at(-2), c = r.get(a);
      r.set(a, { ...n.at(-1), _id: a, _creationTime: c._creationTime });
    }
  }, calls: i, documents: r };
}
s(bw, "memoryDatabase");
var Ge = 17e11;
function Mv() {
  return {
    name: "before",
    createdAt: new Date(Ge),
    secret: new ir("value"),
    nested: { history: [new Date(Ge + 1)], note: "preserved" }
  };
}
s(Mv, "runtimeValue");
async function Bv(e) {
  let r = bw(), i = new jo(r.database, e), o = await i.insert("probe", Mv()), t = await i.get("probe", o), n = r.documents.get(o);
  await i.patch("probe", o, { updatedAt: new Date(Ge + 2), name: "patched" });
  let a = await i.get("probe", o);
  await i.patch("probe", o, { updatedAt: void 0 });
  let c = await i.get("probe", o);
  await i.replace("probe", o, { ...Mv(), name: "replaced" });
  let [u] = await i.query("probe").take(1);
  return {
    wireEncoded: n.createdAt === Ge && n.secret === "value" && n.nested.history[0] === Ge + 1,
    decoded: t.createdAt.getTime() === Ge && t.secret.reveal() === "value" && t.nested.history[0].getTime() === Ge + 1,
    codecPatch: a.updatedAt.getTime() === Ge + 2,
    ordinaryPatch: a.name === "patched",
    unset: !("updatedAt" in c),
    replaceAndQuery: u.name === "replaced" && u.secret.reveal() === "value",
    calls: r.calls
  };
}
s(Bv, "exercise");

// consumerProbe.ts
var w1 = $w({ args: {}, returns: j.any(), handler: /* @__PURE__ */ s(async () => {
  let e = await Bv(ko);
  if (typeof globalThis.gc != "function") throw new Error("GC diagnostic unavailable");
  globalThis.gc(), globalThis.gc();
  let r = Object.keys(ko).sort();
  return {
    nonce: "1b179349-e9f2-4b90-8304-bb305484dfed",
    kind: "descriptor",
    count: 64,
    operation: e,
    models: $.models,
    descriptors: $.descriptors,
    tables: r,
    checksum: r.reduce((i, o) => i + o.length, 0)
  };
}, "handler") });
export {
  w1 as default
};
