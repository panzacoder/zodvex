var Sf = Object.defineProperty;
var s = (e, r) => Sf(e, "name", { value: r, configurable: !0 });
var Pe = (e, r) => {
  for (var i in r)
    Sf(e, i, { get: r[i], enumerable: !0 });
};

// consumerProbe.ts
import { query as ux } from "convex:/_system/repl/wrappers.js";

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/base64.js
var xe = [], he = [], ch = Uint8Array, Eo = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
for (Ye = 0, Of = Eo.length; Ye < Of; ++Ye)
  xe[Ye] = Eo[Ye], he[Eo.charCodeAt(Ye)] = Ye;
var Ye, Of;
he[45] = 62;
he[95] = 63;
function lh(e) {
  var r = e.length;
  if (r % 4 > 0)
    throw new Error("Invalid string. Length must be a multiple of 4");
  var i = e.indexOf("=");
  i === -1 && (i = r);
  var o = i === r ? 0 : 4 - i % 4;
  return [i, o];
}
s(lh, "getLens");
function dh(e, r, i) {
  return (r + i) * 3 / 4 - i;
}
s(dh, "_byteLength");
function Co(e) {
  var r, i = lh(e), o = i[0], t = i[1], n = new ch(dh(e, o, t)), a = 0, u = t > 0 ? o - 4 : o, c;
  for (c = 0; c < u; c += 4)
    r = he[e.charCodeAt(c)] << 18 | he[e.charCodeAt(c + 1)] << 12 | he[e.charCodeAt(c + 2)] << 6 | he[e.charCodeAt(c + 3)], n[a++] = r >> 16 & 255, n[a++] = r >> 8 & 255, n[a++] = r & 255;
  return t === 2 && (r = he[e.charCodeAt(c)] << 2 | he[e.charCodeAt(c + 1)] >> 4, n[a++] = r & 255), t === 1 && (r = he[e.charCodeAt(c)] << 10 | he[e.charCodeAt(c + 1)] << 4 | he[e.charCodeAt(c + 2)] >> 2, n[a++] = r >> 8 & 255, n[a++] = r & 255), n;
}
s(Co, "toByteArray");
function fh(e) {
  return xe[e >> 18 & 63] + xe[e >> 12 & 63] + xe[e >> 6 & 63] + xe[e & 63];
}
s(fh, "tripletToBase64");
function ph(e, r, i) {
  for (var o, t = [], n = r; n < i; n += 3)
    o = (e[n] << 16 & 16711680) + (e[n + 1] << 8 & 65280) + (e[n + 2] & 255), t.push(fh(o));
  return t.join("");
}
s(ph, "encodeChunk");
function fr(e) {
  for (var r, i = e.length, o = i % 3, t = [], n = 16383, a = 0, u = i - o; a < u; a += n)
    t.push(
      ph(
        e,
        a,
        a + n > u ? u : a + n
      )
    );
  return o === 1 ? (r = e[i - 1], t.push(xe[r >> 2] + xe[r << 4 & 63] + "==")) : o === 2 && (r = (e[i - 2] << 8) + e[i - 1], t.push(
    xe[r >> 10] + xe[r >> 4 & 63] + xe[r << 2 & 63] + "="
  )), t.join("");
}
s(fr, "fromByteArray");

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/common/index.js
function Zo(e) {
  let r = typeof e == "object", i = Object.getPrototypeOf(e), o = i === null || i === Object.prototype || // Objects generated from other contexts (e.g. across Node.js `vm` modules) will not satisfy the previous
  // conditions but are still simple objects.
  i?.constructor?.name === "Object";
  return r && o;
}
s(Zo, "isSimpleObject");

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/value.js
var mh = !0, _t = BigInt("-9223372036854775808"), Lo = BigInt("9223372036854775807"), Fo = BigInt("0"), gh = BigInt("8"), hh = BigInt("256");
function vh(e) {
  return Number.isNaN(e) || !Number.isFinite(e) || Object.is(e, -0);
}
s(vh, "isSpecial");
function yh(e) {
  e < Fo && (e -= _t + _t);
  let r = e.toString(16);
  r.length % 2 === 1 && (r = "0" + r);
  let i = new Uint8Array(new ArrayBuffer(8)), o = 0;
  for (let t of r.match(/.{2}/g).reverse())
    i.set([parseInt(t, 16)], o++), e >>= gh;
  return fr(i);
}
s(yh, "slowBigIntToBase64");
function $h(e) {
  let r = Co(e);
  if (r.byteLength !== 8)
    throw new Error(
      `Received ${r.byteLength} bytes, expected 8 for $integer`
    );
  let i = Fo, o = Fo;
  for (let t of r)
    i += BigInt(t) * hh ** o, o++;
  return i > Lo && (i += _t + _t), i;
}
s($h, "slowBase64ToBigInt");
function bh(e) {
  if (e < _t || Lo < e)
    throw new Error(
      `BigInt ${e} does not fit into a 64-bit signed integer.`
    );
  let r = new ArrayBuffer(8);
  return new DataView(r).setBigInt64(0, e, !0), fr(new Uint8Array(r));
}
s(bh, "modernBigIntToBase64");
function _h(e) {
  let r = Co(e);
  if (r.byteLength !== 8)
    throw new Error(
      `Received ${r.byteLength} bytes, expected 8 for $integer`
    );
  return new DataView(r.buffer).getBigInt64(0, !0);
}
s(_h, "modernBase64ToBigInt");
var xh = DataView.prototype.setBigInt64 ? bh : yh, mx = DataView.prototype.getBigInt64 ? _h : $h, Pf = 1024;
function Df(e) {
  if (e.length > Pf)
    throw new Error(
      `Field name ${e} exceeds maximum field name length ${Pf}.`
    );
  if (e.startsWith("$"))
    throw new Error(`Field name ${e} starts with a '$', which is reserved.`);
  for (let r = 0; r < e.length; r += 1) {
    let i = e.charCodeAt(r);
    if (i < 32 || i >= 127)
      throw new Error(
        `Field name ${e} has invalid character '${e[r]}': Field names can only contain non-control ASCII characters`
      );
  }
}
s(Df, "validateObjectField");
var Nf = 16384;
function et(e) {
  let r = JSON.stringify(e, (i, o) => o === void 0 ? "undefined" : typeof o == "bigint" ? `${o.toString()}n` : o);
  if (r.length > Nf) {
    let i = "[...truncated]", o = Nf - i.length, t = r.codePointAt(o - 1);
    return t !== void 0 && t > 65535 && (o -= 1), r.substring(0, o) + i;
  }
  return r;
}
s(et, "stringifyValueForError");
function fn(e, r, i, o) {
  if (e === void 0) {
    let a = i && ` (present at path ${i} in original object ${et(
      r
    )})`;
    throw new Error(
      `undefined is not a valid Convex value${a}. To learn about Convex's supported types, see https://docs.convex.dev/using/types.`
    );
  }
  if (e === null)
    return e;
  if (typeof e == "bigint") {
    if (e < _t || Lo < e)
      throw new Error(
        `BigInt ${e} does not fit into a 64-bit signed integer.`
      );
    return { $integer: xh(e) };
  }
  if (typeof e == "number")
    if (vh(e)) {
      let a = new ArrayBuffer(8);
      return new DataView(a).setFloat64(0, e, mh), { $float: fr(new Uint8Array(a)) };
    } else
      return e;
  if (typeof e == "boolean" || typeof e == "string")
    return e;
  if (e instanceof ArrayBuffer)
    return { $bytes: fr(new Uint8Array(e)) };
  if (Array.isArray(e))
    return e.map(
      (a, u) => fn(a, r, i + `[${u}]`, !1)
    );
  if (e instanceof Set)
    throw new Error(
      Ro(i, "Set", [...e], r)
    );
  if (e instanceof Map)
    throw new Error(
      Ro(i, "Map", [...e], r)
    );
  if (!Zo(e)) {
    let a = e?.constructor?.name, u = a ? `${a} ` : "";
    throw new Error(
      Ro(i, u, e, r)
    );
  }
  let t = {}, n = Object.entries(e);
  n.sort(([a, u], [c, l]) => a === c ? 0 : a < c ? -1 : 1);
  for (let [a, u] of n)
    u !== void 0 ? (Df(a), t[a] = fn(u, r, i + `.${a}`, !1)) : o && (Df(a), t[a] = wh(
      u,
      r,
      i + `.${a}`
    ));
  return t;
}
s(fn, "convexToJsonInternal");
function Ro(e, r, i, o) {
  return e ? `${r}${et(
    i
  )} is not a supported Convex type (present at path ${e} in original object ${et(
    o
  )}). To learn about Convex's supported types, see https://docs.convex.dev/using/types.` : `${r}${et(
    i
  )} is not a supported Convex type.`;
}
s(Ro, "errorMessageForUnsupportedType");
function wh(e, r, i) {
  if (e === void 0)
    return { $undefined: null };
  if (r === void 0)
    throw new Error(
      `Programming error. Current value is ${et(
        e
      )} but original value is undefined`
    );
  return fn(e, r, i, !1);
}
s(wh, "convexOrUndefinedToJsonInternal");
function we(e) {
  return fn(e, e, "", !1);
}
s(we, "convexToJson");

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/validators.js
var kh = Object.defineProperty, Ih = /* @__PURE__ */ s((e, r, i) => r in e ? kh(e, r, { enumerable: !0, configurable: !0, writable: !0, value: i }) : e[r] = i, "__defNormalProp"), B = /* @__PURE__ */ s((e, r, i) => Ih(e, typeof r != "symbol" ? r + "" : r, i), "__publicField"), zh = "https://docs.convex.dev/error#undefined-validator";
function pr(e, r) {
  let i = r !== void 0 ? ` for field "${r}"` : "";
  throw new Error(
    `A validator is undefined${i} in ${e}. This is often caused by circular imports. See ${zh} for details.`
  );
}
s(pr, "throwUndefinedValidatorError");
var ee = class {
  static {
    s(this, "BaseValidator");
  }
  constructor({ isOptional: r }) {
    B(this, "type"), B(this, "fieldPaths"), B(this, "isOptional"), B(this, "isConvexValidator"), this.isOptional = r, this.isConvexValidator = !0;
  }
}, pn = class e extends ee {
  static {
    s(this, "VId");
  }
  /**
   * Usually you'd use `v.id(tableName)` instead.
   */
  constructor({
    isOptional: r,
    tableName: i
  }) {
    if (super({ isOptional: r }), B(this, "tableName"), B(this, "kind", "id"), typeof i != "string")
      throw new Error("v.id(tableName) requires a string");
    this.tableName = i;
  }
  /** @internal */
  get json() {
    return { type: "id", tableName: this.tableName };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      tableName: this.tableName
    });
  }
}, mr = class e extends ee {
  static {
    s(this, "VFloat64");
  }
  constructor() {
    super(...arguments), B(this, "kind", "float64");
  }
  /** @internal */
  get json() {
    return { type: "number" };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, gr = class e extends ee {
  static {
    s(this, "VInt64");
  }
  constructor() {
    super(...arguments), B(this, "kind", "int64");
  }
  /** @internal */
  get json() {
    return { type: "bigint" };
  }
  /** @internal */
  asOptional() {
    return new e({ isOptional: "optional" });
  }
}, mn = class e extends ee {
  static {
    s(this, "VBoolean");
  }
  constructor() {
    super(...arguments), B(this, "kind", "boolean");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, gn = class e extends ee {
  static {
    s(this, "VBytes");
  }
  constructor() {
    super(...arguments), B(this, "kind", "bytes");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({ isOptional: "optional" });
  }
}, hn = class e extends ee {
  static {
    s(this, "VString");
  }
  constructor() {
    super(...arguments), B(this, "kind", "string");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, vn = class e extends ee {
  static {
    s(this, "VNull");
  }
  constructor() {
    super(...arguments), B(this, "kind", "null");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({ isOptional: "optional" });
  }
}, yn = class e extends ee {
  static {
    s(this, "VAny");
  }
  constructor() {
    super(...arguments), B(this, "kind", "any");
  }
  /** @internal */
  get json() {
    return {
      type: this.kind
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, $n = class e extends ee {
  static {
    s(this, "VObject");
  }
  /**
   * Usually you'd use `v.object({ ... })` instead.
   */
  constructor({
    isOptional: r,
    fields: i
  }) {
    super({ isOptional: r }), B(this, "fields"), B(this, "kind", "object"), globalThis.Object.entries(i).forEach(([o, t]) => {
      if (t === void 0 && pr("v.object()", o), !t.isConvexValidator)
        throw new Error("v.object() entries must be validators");
    }), this.fields = i;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: globalThis.Object.fromEntries(
        globalThis.Object.entries(this.fields).map(([r, i]) => [
          r,
          {
            fieldType: i.json,
            optional: i.isOptional === "optional"
          }
        ])
      )
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      fields: this.fields
    });
  }
  /**
   * Create a new VObject with the specified fields omitted.
   * @param fields The field names to omit from this VObject.
   */
  omit(...r) {
    let i = { ...this.fields };
    for (let o of r)
      delete i[o];
    return new e({
      isOptional: this.isOptional,
      fields: i
    });
  }
  /**
   * Create a new VObject with only the specified fields.
   * @param fields The field names to pick from this VObject.
   */
  pick(...r) {
    let i = {};
    for (let o of r)
      i[o] = this.fields[o];
    return new e({
      isOptional: this.isOptional,
      fields: i
    });
  }
  /**
   * Create a new VObject with all fields marked as optional.
   */
  partial() {
    let r = {};
    for (let [i, o] of globalThis.Object.entries(this.fields))
      r[i] = o.asOptional();
    return new e({
      isOptional: this.isOptional,
      fields: r
    });
  }
  /**
   * Create a new VObject with additional fields merged in.
   * @param fields An object with additional validators to merge into this VObject.
   */
  extend(r) {
    return new e({
      isOptional: this.isOptional,
      fields: { ...this.fields, ...r }
    });
  }
}, bn = class e extends ee {
  static {
    s(this, "VLiteral");
  }
  /**
   * Usually you'd use `v.literal(value)` instead.
   */
  constructor({ isOptional: r, value: i }) {
    if (super({ isOptional: r }), B(this, "value"), B(this, "kind", "literal"), typeof i != "string" && typeof i != "boolean" && typeof i != "number" && typeof i != "bigint")
      throw new Error("v.literal(value) must be a string, number, or boolean");
    this.value = i;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: we(this.value)
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      value: this.value
    });
  }
}, _n = class e extends ee {
  static {
    s(this, "VArray");
  }
  /**
   * Usually you'd use `v.array(element)` instead.
   */
  constructor({
    isOptional: r,
    element: i
  }) {
    super({ isOptional: r }), B(this, "element"), B(this, "kind", "array"), i === void 0 && pr("v.array()"), this.element = i;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: this.element.json
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      element: this.element
    });
  }
}, xn = class e extends ee {
  static {
    s(this, "VRecord");
  }
  /**
   * Usually you'd use `v.record(key, value)` instead.
   */
  constructor({
    isOptional: r,
    key: i,
    value: o
  }) {
    if (super({ isOptional: r }), B(this, "key"), B(this, "value"), B(this, "kind", "record"), i === void 0 && pr("v.record()", "key"), o === void 0 && pr("v.record()", "value"), i.isOptional === "optional")
      throw new Error("Record validator cannot have optional keys");
    if (o.isOptional === "optional")
      throw new Error("Record validator cannot have optional values");
    if (!i.isConvexValidator || !o.isConvexValidator)
      throw new Error("Key and value of v.record() but be validators");
    this.key = i, this.value = o;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      // This cast is needed because TypeScript thinks the key type is too wide
      keys: this.key.json,
      values: {
        fieldType: this.value.json,
        optional: !1
      }
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      key: this.key,
      value: this.value
    });
  }
}, wn = class e extends ee {
  static {
    s(this, "VUnion");
  }
  /**
   * Usually you'd use `v.union(...members)` instead.
   */
  constructor({ isOptional: r, members: i }) {
    super({ isOptional: r }), B(this, "members"), B(this, "kind", "union"), i.forEach((o, t) => {
      if (o === void 0 && pr("v.union()", `member at index ${t}`), !o.isConvexValidator)
        throw new Error("All members of v.union() must be validators");
    }), this.members = i;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: this.members.map((r) => r.json)
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      members: this.members
    });
  }
};

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/validator.js
function Tf(e) {
  return !!e.isConvexValidator;
}
s(Tf, "isValidator");
var y = {
  /**
   * Validates that the value is a document ID for the given table.
   *
   * IDs are strings at runtime but are typed as `Id<"tableName">` in
   * TypeScript for type safety.
   *
   * @example
   * ```typescript
   * args: { userId: v.id("users") }
   * ```
   *
   * @param tableName The name of the table.
   */
  id: /* @__PURE__ */ s((e) => new pn({
    isOptional: "required",
    tableName: e
  }), "id"),
  /**
   * Validates that the value is `null`.
   *
   * Use `returns: v.null()` for functions that don't return a meaningful value.
   * JavaScript `undefined` is not a valid Convex value, it is automatically
   * converted to `null`.
   */
  null: /* @__PURE__ */ s(() => new vn({ isOptional: "required" }), "null"),
  /**
   * Validates that the value is a JavaScript `number` (Convex Float64).
   *
   * Supports all IEEE-754 double-precision floating point numbers including
   * NaN and Infinity.
   *
   * Alias for `v.float64()`.
   */
  number: /* @__PURE__ */ s(() => new mr({ isOptional: "required" }), "number"),
  /**
   * Validates that the value is a JavaScript `number` (Convex Float64).
   *
   * Supports all IEEE-754 double-precision floating point numbers.
   */
  float64: /* @__PURE__ */ s(() => new mr({ isOptional: "required" }), "float64"),
  /**
   * @deprecated Use `v.int64()` instead.
   */
  bigint: /* @__PURE__ */ s(() => new gr({ isOptional: "required" }), "bigint"),
  /**
   * Validates that the value is a JavaScript `bigint` (Convex Int64).
   *
   * Supports BigInts between -2^63 and 2^63-1.
   *
   * @example
   * ```typescript
   * args: { timestamp: v.int64() }
   * // Usage: createDoc({ timestamp: 1234567890n })
   * ```
   */
  int64: /* @__PURE__ */ s(() => new gr({ isOptional: "required" }), "int64"),
  /**
   * Validates that the value is a `boolean`.
   */
  boolean: /* @__PURE__ */ s(() => new mn({ isOptional: "required" }), "boolean"),
  /**
   * Validates that the value is a `string`.
   *
   * Strings are stored as UTF-8 and their storage size is calculated as their
   * UTF-8 encoded size.
   */
  string: /* @__PURE__ */ s(() => new hn({ isOptional: "required" }), "string"),
  /**
   * Validates that the value is an `ArrayBuffer` (Convex Bytes).
   *
   * Use for binary data.
   */
  bytes: /* @__PURE__ */ s(() => new gn({ isOptional: "required" }), "bytes"),
  /**
   * Validates that the value is exactly equal to the given literal.
   *
   * Useful for discriminated unions and enum-like patterns.
   *
   * @example
   * ```typescript
   * // Discriminated union pattern:
   * v.union(
   *   v.object({ kind: v.literal("error"), message: v.string() }),
   *   v.object({ kind: v.literal("success"), value: v.number() }),
   * )
   * ```
   *
   * @param literal The literal value to compare against.
   */
  literal: /* @__PURE__ */ s((e) => new bn({ isOptional: "required", value: e }), "literal"),
  /**
   * Validates that the value is an `Array` where every element matches the
   * given validator.
   *
   * Arrays can have at most 8192 elements.
   *
   * @example
   * ```typescript
   * args: { tags: v.array(v.string()) }
   * args: { coordinates: v.array(v.number()) }
   * args: { items: v.array(v.object({ name: v.string(), qty: v.number() })) }
   * ```
   *
   * @param element The validator for the elements of the array.
   */
  array: /* @__PURE__ */ s((e) => new _n({ isOptional: "required", element: e }), "array"),
  /**
   * Validates that the value is an `Object` with the specified properties.
   *
   * Objects can have at most 1024 entries. Field names must be non-empty and
   * must not start with `"$"` or `"_"` (`_` is reserved for system fields
   * like `_id` and `_creationTime`; `$` is reserved for Convex internal use).
   *
   * @example
   * ```typescript
   * args: {
   *   user: v.object({
   *     name: v.string(),
   *     email: v.string(),
   *     age: v.optional(v.number()),
   *   })
   * }
   * ```
   *
   * @param fields An object mapping property names to their validators.
   */
  object: /* @__PURE__ */ s((e) => new $n({ isOptional: "required", fields: e }), "object"),
  /**
   * Validates that the value is a `Record` (object with dynamic keys).
   *
   * Records are objects at runtime but allow dynamic keys, unlike `v.object()`
   * which requires known property names. Keys must be ASCII characters only,
   * non-empty, and not start with `"$"` or `"_"`.
   *
   * @example
   * ```typescript
   * // Map of user IDs to scores:
   * args: { scores: v.record(v.id("users"), v.number()) }
   *
   * // Map of string keys to string values:
   * args: { metadata: v.record(v.string(), v.string()) }
   * ```
   *
   * @param keys The validator for the keys of the record.
   * @param values The validator for the values of the record.
   */
  record: /* @__PURE__ */ s((e, r) => new xn({
    isOptional: "required",
    key: e,
    value: r
  }), "record"),
  /**
   * Validates that the value matches at least one of the given validators.
   *
   * @example
   * ```typescript
   * // Allow string or number:
   * args: { value: v.union(v.string(), v.number()) }
   *
   * // Discriminated union (recommended pattern):
   * v.union(
   *   v.object({ kind: v.literal("text"), body: v.string() }),
   *   v.object({ kind: v.literal("image"), url: v.string() }),
   * )
   *
   * // Nullable value:
   * returns: v.union(v.object({ ... }), v.null())
   * ```
   *
   * @param members The validators to match against.
   */
  union: /* @__PURE__ */ s((...e) => new wn({
    isOptional: "required",
    members: e
  }), "union"),
  /**
   * A validator that accepts any Convex value without validation.
   *
   * Prefer using specific validators when possible for better type safety
   * and runtime validation.
   */
  any: /* @__PURE__ */ s(() => new yn({ isOptional: "required" }), "any"),
  /**
   * Makes a property optional in an object validator.
   *
   * An optional property can be omitted entirely when creating a document or
   * calling a function. This is different from `v.nullable()` which requires
   * the property to be present but allows `null`.
   *
   * @example
   * ```typescript
   * v.object({
   *   name: v.string(),              // required
   *   nickname: v.optional(v.string()), // can be omitted
   * })
   *
   * // Valid: { name: "Alice" }
   * // Valid: { name: "Alice", nickname: "Ali" }
   * // Invalid: { name: "Alice", nickname: null }  - use v.nullable() for this
   * ```
   *
   * @param value The property value validator to make optional.
   */
  optional: /* @__PURE__ */ s((e) => e.asOptional(), "optional"),
  /**
   * Allows a value to be either the given type or `null`.
   *
   * This is shorthand for `v.union(value, v.null())`. Unlike `v.optional()`,
   * the property must still be present, but may be `null`.
   *
   * @example
   * ```typescript
   * v.object({
   *   name: v.string(),
   *   deletedAt: v.nullable(v.number()), // must be present, can be null
   * })
   *
   * // Valid: { name: "Alice", deletedAt: null }
   * // Valid: { name: "Alice", deletedAt: 1234567890 }
   * // Invalid: { name: "Alice" }  - deletedAt is required
   * ```
   */
  nullable: /* @__PURE__ */ s((e) => y.union(e, y.null()), "nullable")
};

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/errors.js
var Sh = Object.defineProperty, Oh = /* @__PURE__ */ s((e, r, i) => r in e ? Sh(e, r, { enumerable: !0, configurable: !0, writable: !0, value: i }) : e[r] = i, "__defNormalProp"), Vo = /* @__PURE__ */ s((e, r, i) => Oh(e, typeof r != "symbol" ? r + "" : r, i), "__publicField"), Af, Uf, jh = Symbol.for("ConvexError"), kn = class extends (Uf = Error, Af = jh, Uf) {
  static {
    s(this, "ConvexError");
  }
  constructor(r) {
    super(typeof r == "string" ? r : et(r)), Vo(this, "name", "ConvexError"), Vo(this, "data"), Vo(this, Af, !0), this.data = r;
  }
};

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/compare_utf8.js
var Ef = /* @__PURE__ */ s(() => Array.from({ length: 4 }, () => 0), "arr"), zx = Ef(), Sx = Ef();

// ../../node_modules/.bun/convex-helpers@0.1.113+b9ed8f5244cf7f28/node_modules/convex-helpers/index.js
var Jx = Symbol();

// ../../node_modules/.bun/convex-helpers@0.1.113+b9ed8f5244cf7f28/node_modules/convex-helpers/validators.js
var Hx = y.string(), Qx = y.float64(), Yx = y.float64(), ew = y.boolean(), tw = y.int64(), rw = y.int64(), nw = y.any(), iw = y.null(), { id: ow, object: aw, array: sw, bytes: uw, literal: cw, optional: lw, union: dw } = y, fw = y.bytes();
var pw = y.optional(y.any());

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/index.js
var Ae = {};
Pe(Ae, {
  $ZodAny: () => Ms,
  $ZodArray: () => At,
  $ZodAsyncError: () => se,
  $ZodBase64: () => Ns,
  $ZodBase64URL: () => Ts,
  $ZodBigInt: () => oi,
  $ZodBigIntFormat: () => Rs,
  $ZodBoolean: () => Nr,
  $ZodCIDRv4: () => Ps,
  $ZodCIDRv6: () => Ds,
  $ZodCUID: () => ys,
  $ZodCUID2: () => $s,
  $ZodCatch: () => ou,
  $ZodCheck: () => L,
  $ZodCheckBigIntFormat: () => Ka,
  $ZodCheckEndsWith: () => os,
  $ZodCheckGreaterThan: () => Mn,
  $ZodCheckIncludes: () => ns,
  $ZodCheckLengthEquals: () => Ya,
  $ZodCheckLessThan: () => Vn,
  $ZodCheckLowerCase: () => ts,
  $ZodCheckMaxLength: () => Ha,
  $ZodCheckMaxSize: () => Wa,
  $ZodCheckMimeType: () => as,
  $ZodCheckMinLength: () => Qa,
  $ZodCheckMinSize: () => Ga,
  $ZodCheckMultipleOf: () => Ja,
  $ZodCheckNumberFormat: () => qa,
  $ZodCheckOverwrite: () => ss,
  $ZodCheckProperty: () => Bn,
  $ZodCheckRegex: () => es,
  $ZodCheckSizeEquals: () => Xa,
  $ZodCheckStartsWith: () => is,
  $ZodCheckStringFormat: () => Nt,
  $ZodCheckUpperCase: () => rs,
  $ZodCodec: () => Fe,
  $ZodCreditCard: () => Us,
  $ZodCustom: () => si,
  $ZodCustomStringFormat: () => Cs,
  $ZodCyclicError: () => li,
  $ZodDate: () => Tr,
  $ZodDefault: () => ke,
  $ZodDiscriminatedUnion: () => Re,
  $ZodE164: () => As,
  $ZodEmail: () => fs,
  $ZodEmoji: () => hs,
  $ZodEncodeError: () => Ce,
  $ZodEnum: () => Et,
  $ZodError: () => nt,
  $ZodExactOptional: () => tu,
  $ZodFile: () => Ys,
  $ZodFunction: () => lu,
  $ZodGUID: () => ls,
  $ZodIPv4: () => Ss,
  $ZodIPv6: () => Os,
  $ZodISODate: () => ks,
  $ZodISODateTime: () => ws,
  $ZodISODuration: () => zs,
  $ZodISOTime: () => Is,
  $ZodIntersection: () => Xs,
  $ZodJWT: () => Es,
  $ZodKSUID: () => xs,
  $ZodLazy: () => Le,
  $ZodLiteral: () => Ct,
  $ZodMAC: () => js,
  $ZodMap: () => Hs,
  $ZodNaN: () => au,
  $ZodNanoID: () => vs,
  $ZodNever: () => Js,
  $ZodNonOptional: () => nu,
  $ZodNull: () => Vs,
  $ZodNullable: () => Ne,
  $ZodNumber: () => ii,
  $ZodNumberFormat: () => Zs,
  $ZodObject: () => Q,
  $ZodObjectJIT: () => Ks,
  $ZodOptional: () => W,
  $ZodPipe: () => ai,
  $ZodPrefault: () => ru,
  $ZodPreprocess: () => su,
  $ZodPromise: () => du,
  $ZodReadonly: () => uu,
  $ZodRealError: () => ue,
  $ZodRecord: () => Ut,
  $ZodRegistry: () => fi,
  $ZodSet: () => Qs,
  $ZodString: () => st,
  $ZodStringFormat: () => R,
  $ZodSuccess: () => iu,
  $ZodSymbol: () => Fs,
  $ZodTemplateLiteral: () => cu,
  $ZodTransform: () => eu,
  $ZodTuple: () => ut,
  $ZodType: () => S,
  $ZodULID: () => bs,
  $ZodURL: () => gs,
  $ZodUUID: () => ds,
  $ZodUndefined: () => Ls,
  $ZodUnion: () => fe,
  $ZodUnknown: () => Bs,
  $ZodVoid: () => qs,
  $ZodXID: () => _s,
  $ZodXor: () => Ws,
  $brand: () => ia,
  $constructor: () => m,
  $input: () => xc,
  $output: () => _c,
  Doc: () => at,
  INVALID: () => pe,
  JSONSchema: () => Up,
  JSONSchemaGenerator: () => qi,
  NEVER: () => na,
  TimePrecision: () => Nc,
  URL_BAD_FORMAT: () => ps,
  URL_UNPARSEABLE: () => ms,
  ZodCompileAsyncError: () => be,
  ZodCompileUnsupportedError: () => U,
  _any: () => Gc,
  _array: () => rl,
  _base64: () => Ni,
  _base64url: () => Ti,
  _bigint: () => Vc,
  _boolean: () => Fc,
  _catch: () => zb,
  _check: () => Op,
  _cidrv4: () => Pi,
  _cidrv6: () => Di,
  _coercedBigint: () => Mc,
  _coercedBoolean: () => Lc,
  _coercedDate: () => el,
  _coercedNumber: () => Ac,
  _coercedString: () => jc,
  _creditCard: () => Dc,
  _cuid: () => wi,
  _cuid2: () => ki,
  _custom: () => il,
  _date: () => Yc,
  _decode: () => Nn,
  _decodeAsync: () => An,
  _default: () => wb,
  _discriminatedUnion: () => db,
  _e164: () => Ai,
  _email: () => gi,
  _emoji: () => _i,
  _encode: () => Dn,
  _encodeAsync: () => Tn,
  _endsWith: () => Bt,
  _enum: () => vb,
  _file: () => nl,
  _float32: () => Ec,
  _float64: () => Cc,
  _gt: () => ze,
  _gte: () => ge,
  _guid: () => hi,
  _includes: () => Vt,
  _int: () => Uc,
  _int32: () => Zc,
  _int64: () => Bc,
  _intersection: () => fb,
  _ipv4: () => Oi,
  _ipv6: () => ji,
  _isoDate: () => Vr,
  _isoDateTime: () => Lr,
  _isoDuration: () => Br,
  _isoTime: () => Mr,
  _jwt: () => Ui,
  _ksuid: () => Si,
  _lazy: () => Pb,
  _length: () => gt,
  _literal: () => $b,
  _lowercase: () => Ft,
  _lt: () => Ie,
  _lte: () => me,
  _mac: () => Pc,
  _map: () => gb,
  _max: () => me,
  _maxLength: () => mt,
  _maxSize: () => Me,
  _mime: () => Jt,
  _min: () => ge,
  _minLength: () => Te,
  _minSize: () => Se,
  _multipleOf: () => Ve,
  _nan: () => tl,
  _nanoid: () => xi,
  _nativeEnum: () => yb,
  _negative: () => Ci,
  _never: () => Hc,
  _nonnegative: () => Ri,
  _nonoptional: () => kb,
  _nonpositive: () => Zi,
  _normalize: () => qt,
  _null: () => Wc,
  _nullable: () => xb,
  _number: () => Tc,
  _optional: () => _b,
  _overwrite: () => _e,
  _parse: () => Ot,
  _parseAsync: () => jt,
  _pipe: () => Sb,
  _positive: () => Ei,
  _promise: () => Db,
  _properties: () => Li,
  _property: () => Fi,
  _readonly: () => Ob,
  _record: () => mb,
  _refine: () => ol,
  _regex: () => Rt,
  _safeDecode: () => En,
  _safeDecodeAsync: () => Zn,
  _safeEncode: () => Un,
  _safeEncodeAsync: () => Cn,
  _safeParse: () => Pt,
  _safeParseAsync: () => Dt,
  _set: () => hb,
  _size: () => pt,
  _slugify: () => Xt,
  _startsWith: () => Mt,
  _string: () => Oc,
  _stringFormat: () => Ht,
  _stringbool: () => cl,
  _success: () => Ib,
  _superRefine: () => al,
  _symbol: () => qc,
  _templateLiteral: () => jb,
  _toLowerCase: () => Wt,
  _toUpperCase: () => Gt,
  _transform: () => bb,
  _trim: () => Kt,
  _tuple: () => pb,
  _uint32: () => Rc,
  _uint64: () => Jc,
  _ulid: () => Ii,
  _undefined: () => Kc,
  _union: () => cb,
  _unknown: () => Xc,
  _uppercase: () => Lt,
  _url: () => Fr,
  _uuid: () => vi,
  _uuidv4: () => yi,
  _uuidv6: () => $i,
  _uuidv7: () => bi,
  _void: () => Qc,
  _xid: () => zi,
  _xor: () => lb,
  clone: () => A,
  compile: () => zc,
  compileFn: () => mi,
  config: () => K,
  createStandardJSONSchemaMethod: () => Qt,
  createToJSONSchemaMethod: () => dl,
  decode: () => hv,
  decodeAsync: () => yv,
  describe: () => sl,
  encode: () => De,
  encodeAsync: () => vv,
  extractDefs: () => Je,
  finalize: () => qe,
  flattenError: () => kr,
  formatError: () => Ir,
  getDiscriminatedOption: () => Gs,
  globalConfig: () => X,
  globalRegistry: () => H,
  handleUnrepresentable: () => G,
  initializeContext: () => Be,
  isBackEdge: () => di,
  isRecursiveSchema: () => gu,
  isValidBase64: () => Dr,
  isValidBase64URL: () => ti,
  isValidCIDRv6: () => ei,
  isValidCreditCard: () => ri,
  isValidIPv6: () => Pr,
  isValidJWT: () => ni,
  locales: () => Rr,
  memoizer: () => Ar,
  mergeValues: () => Tt,
  meta: () => ul,
  parse: () => it,
  parseAsync: () => Pn,
  parseURLObject: () => Xn,
  prettifyError: () => ca,
  process: () => C,
  regexes: () => te,
  registry: () => pi,
  safeDecode: () => bv,
  safeDecodeAsync: () => xv,
  safeEncode: () => $v,
  safeEncodeAsync: () => _v,
  safeParse: () => zr,
  safeParseAsync: () => la,
  standardProps: () => Gn,
  stripTabAndNewline: () => Hn,
  toDotPath: () => Jf,
  toJSONSchema: () => Ji,
  toZod: () => hr,
  treeifyError: () => ua,
  urlHostnameOk: () => Qn,
  urlProtocolOk: () => Yn,
  util: () => _,
  validate: () => da,
  validateAsync: () => fa,
  version: () => us
});

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/util.js
var _ = {};
Pe(_, {
  BIGINT_FORMAT_RANGES: () => Ho,
  CONSTANT_CATCH: () => On,
  Class: () => Bo,
  NUMBER_FORMAT_RANGES: () => Xo,
  aborted: () => Ee,
  allowsEval: () => Ko,
  assert: () => Uh,
  assertEqual: () => Dh,
  assertIs: () => Th,
  assertNever: () => Ah,
  assertNotEqual: () => Nh,
  assignProp: () => q,
  attachSchema: () => Sn,
  base64ToUint8Array: () => Rf,
  base64urlToUint8Array: () => Yh,
  cached: () => zt,
  captureStackTrace: () => zn,
  cleanEnum: () => Qh,
  cleanRegex: () => yr,
  clone: () => A,
  cloneDef: () => Ch,
  codePointLength: () => rt,
  constantCatch: () => ta,
  createTransparentProxy: () => Mh,
  defineLazy: () => Jo,
  defineLazyInternal: () => T,
  esc: () => ie,
  escapeRegex: () => ye,
  explicitlyAborted: () => Qo,
  extend: () => qh,
  finalizeIssue: () => ae,
  floatSafeRemainder: () => $r,
  getElementAtPath: () => Zh,
  getEnumValues: () => vr,
  getLengthableOrigin: () => wr,
  getParsedType: () => Vh,
  getSizableOrigin: () => xr,
  hexToUint8Array: () => tv,
  hide: () => ea,
  installLazyProp: () => av,
  isObject: () => tt,
  isPlainObject: () => ve,
  issue: () => St,
  joinValues: () => g,
  jsonStringifyReplacer: () => It,
  members: () => Yo,
  merge: () => Wh,
  mergeDefs: () => $e,
  normalizeParams: () => w,
  nullish: () => In,
  numKeys: () => Lh,
  objectClone: () => Eh,
  omit: () => Jh,
  optionalKeys: () => Go,
  own: () => kt,
  parsedType: () => b,
  partial: () => Gh,
  pick: () => Bh,
  prefixIssues: () => oe,
  primitiveTypes: () => Wo,
  promiseAllObject: () => Rh,
  propertyKeyTypes: () => _r,
  randomString: () => Fh,
  required: () => Xh,
  safeExtend: () => Kh,
  shallowClone: () => br,
  slugify: () => qo,
  stringifyPrimitive: () => $,
  toZod: () => hr,
  uint8ArrayToBase64: () => Ff,
  uint8ArrayToBase64url: () => ev,
  uint8ArrayToHex: () => rv,
  unwrapMessage: () => wt
});
function Dh(e) {
  return e;
}
s(Dh, "assertEqual");
function Nh(e) {
  return e;
}
s(Nh, "assertNotEqual");
function hr() {
  return (e) => e;
}
s(hr, "toZod");
function Th(e) {
}
s(Th, "assertIs");
function Ah(e) {
  throw new Error("Unexpected value in exhaustive check");
}
s(Ah, "assertNever");
function Uh(e) {
}
s(Uh, "assert");
function vr(e) {
  let r = Object.values(e).filter((o) => typeof o == "number");
  return Object.entries(e).filter(([o, t]) => r.indexOf(+o) === -1).map(([o, t]) => t);
}
s(vr, "getEnumValues");
function g(e, r = "|") {
  return e.map((i) => $(i)).join(r);
}
s(g, "joinValues");
function It(e, r) {
  return typeof r == "bigint" ? r.toString() : r;
}
s(It, "jsonStringifyReplacer");
function zt(e) {
  return {
    get value() {
      {
        let i = e();
        return Object.defineProperty(this, "value", { value: i }), i;
      }
      throw new Error("cached value already set");
    }
  };
}
s(zt, "cached");
function In(e) {
  return e == null;
}
s(In, "nullish");
function yr(e) {
  let r = e.startsWith("^") ? 1 : 0, i = e.endsWith("$") ? e.length - 1 : e.length;
  return e.slice(r, i);
}
s(yr, "cleanRegex");
function $r(e, r) {
  let i = e / r, o = Math.round(i), t = 4 * Number.EPSILON * Math.max(Math.abs(i), 1);
  return Math.abs(i - o) < t ? 0 : i - o;
}
s($r, "floatSafeRemainder");
var Zf = /* @__PURE__ */ Symbol("evaluating");
function Jo(e, r, i) {
  let o;
  Object.defineProperty(e, r, {
    get() {
      if (o !== Zf)
        return o === void 0 && (o = Zf, o = i()), o;
    },
    set(t) {
      Object.defineProperty(e, r, {
        value: t
        // configurable: true,
      });
    },
    configurable: !0
  });
}
s(Jo, "defineLazy");
function Eh(e) {
  return Object.create(Object.getPrototypeOf(e), Object.getOwnPropertyDescriptors(e));
}
s(Eh, "objectClone");
function q(e, r, i) {
  Object.defineProperty(e, r, {
    value: i,
    writable: !0,
    enumerable: !0,
    configurable: !0
  });
}
s(q, "assignProp");
function $e(...e) {
  let r = {};
  for (let i of e) {
    let o = Object.getOwnPropertyDescriptors(i);
    Object.assign(r, o);
  }
  return Object.defineProperties({}, r);
}
s($e, "mergeDefs");
function Ch(e) {
  return $e(e._zod.def);
}
s(Ch, "cloneDef");
function Zh(e, r) {
  return r ? r.reduce((i, o) => i?.[o], e) : e;
}
s(Zh, "getElementAtPath");
function Rh(e) {
  let r = Object.keys(e), i = r.map((o) => e[o]);
  return Promise.all(i).then((o) => {
    let t = {};
    for (let n = 0; n < r.length; n++)
      t[r[n]] = o[n];
    return t;
  });
}
s(Rh, "promiseAllObject");
function Fh(e = 10) {
  let r = "abcdefghijklmnopqrstuvwxyz", i = "";
  for (let o = 0; o < e; o++)
    i += r[Math.floor(Math.random() * r.length)];
  return i;
}
s(Fh, "randomString");
function ie(e) {
  return JSON.stringify(e);
}
s(ie, "esc");
function qo(e) {
  return e.toLowerCase().trim().replace(/[^\w\s-]/g, "").replace(/[\s_-]+/g, "-").replace(/^-+|-+$/g, "");
}
s(qo, "slugify");
var zn = "captureStackTrace" in Error ? Error.captureStackTrace : (...e) => {
};
function tt(e) {
  return typeof e == "object" && e !== null && !Array.isArray(e);
}
s(tt, "isObject");
var Ko = /* @__PURE__ */ zt(() => {
  if (X.jitless || typeof navigator < "u" && navigator?.userAgent?.includes("Cloudflare"))
    return !1;
  try {
    let e = Function;
    return new e(""), !0;
  } catch {
    return !1;
  }
});
function ve(e) {
  if (tt(e) === !1)
    return !1;
  let r = e.constructor;
  if (r === void 0 || typeof r != "function")
    return !0;
  let i = r.prototype;
  return !(tt(i) === !1 || Object.prototype.hasOwnProperty.call(i, "isPrototypeOf") === !1);
}
s(ve, "isPlainObject");
function br(e) {
  return ve(e) ? { ...e } : Array.isArray(e) ? [...e] : e instanceof Map ? new Map(e) : e instanceof Set ? new Set(e) : e;
}
s(br, "shallowClone");
function Lh(e) {
  let r = 0;
  for (let i in e)
    Object.prototype.hasOwnProperty.call(e, i) && r++;
  return r;
}
s(Lh, "numKeys");
var Vh = /* @__PURE__ */ s((e) => {
  let r = typeof e;
  switch (r) {
    case "undefined":
      return "undefined";
    case "string":
      return "string";
    case "number":
      return Number.isNaN(e) ? "nan" : "number";
    case "boolean":
      return "boolean";
    case "function":
      return "function";
    case "bigint":
      return "bigint";
    case "symbol":
      return "symbol";
    case "object":
      return Array.isArray(e) ? "array" : e === null ? "null" : e.then && typeof e.then == "function" && e.catch && typeof e.catch == "function" ? "promise" : typeof Map < "u" && e instanceof Map ? "map" : typeof Set < "u" && e instanceof Set ? "set" : typeof Date < "u" && e instanceof Date ? "date" : typeof File < "u" && e instanceof File ? "file" : "object";
    default:
      throw new Error(`Unknown data type: ${r}`);
  }
}, "getParsedType"), _r = /* @__PURE__ */ new Set(["string", "number", "symbol"]), Wo = /* @__PURE__ */ new Set([
  "string",
  "number",
  "bigint",
  "boolean",
  "symbol",
  "undefined"
]);
function ye(e) {
  return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
s(ye, "escapeRegex");
function A(e, r, i) {
  let o = new e._zod.constr(r ?? e._zod.def);
  return (!r || i?.parent) && (o._zod.parent = e), o;
}
s(A, "clone");
function w(e) {
  let r = e;
  if (!r)
    return {};
  if (typeof r == "string")
    return { error: /* @__PURE__ */ s(() => r, "error") };
  if (r?.message !== void 0) {
    if (r?.error !== void 0)
      throw new Error("Cannot specify both `message` and `error` params");
    r.error = r.message;
  }
  return delete r.message, typeof r.error == "string" ? { ...r, error: /* @__PURE__ */ s(() => r.error, "error") } : r;
}
s(w, "normalizeParams");
function Mh(e) {
  let r;
  return new Proxy({}, {
    get(i, o, t) {
      return r ?? (r = e()), Reflect.get(r, o, t);
    },
    set(i, o, t, n) {
      return r ?? (r = e()), Reflect.set(r, o, t, n);
    },
    has(i, o) {
      return r ?? (r = e()), Reflect.has(r, o);
    },
    deleteProperty(i, o) {
      return r ?? (r = e()), Reflect.deleteProperty(r, o);
    },
    ownKeys(i) {
      return r ?? (r = e()), Reflect.ownKeys(r);
    },
    getOwnPropertyDescriptor(i, o) {
      return r ?? (r = e()), Reflect.getOwnPropertyDescriptor(r, o);
    },
    defineProperty(i, o, t) {
      return r ?? (r = e()), Reflect.defineProperty(r, o, t);
    }
  });
}
s(Mh, "createTransparentProxy");
function $(e) {
  return typeof e == "bigint" ? e.toString() + "n" : typeof e == "string" ? `"${e}"` : `${e}`;
}
s($, "stringifyPrimitive");
function Go(e) {
  return Object.keys(e).filter((r) => e[r]._zod.optin !== void 0 && e[r]._zod.optout === "optional");
}
s(Go, "optionalKeys");
var Xo = {
  safeint: [Number.MIN_SAFE_INTEGER, Number.MAX_SAFE_INTEGER],
  int32: [-2147483648, 2147483647],
  uint32: [0, 4294967295],
  float32: [-34028234663852886e22, 34028234663852886e22],
  float64: [-Number.MAX_VALUE, Number.MAX_VALUE]
}, Ho = {
  int64: [/* @__PURE__ */ BigInt("-9223372036854775808"), /* @__PURE__ */ BigInt("9223372036854775807")],
  uint64: [/* @__PURE__ */ BigInt(0), /* @__PURE__ */ BigInt("18446744073709551615")]
};
function Bh(e, r) {
  let i = e._zod.def, o = i.checks;
  if (o && o.length > 0)
    throw new Error(".pick() cannot be used on object schemas containing refinements");
  let n = $e(e._zod.def, {
    get shape() {
      let a = {};
      for (let u of Reflect.ownKeys(r)) {
        if (!Object.prototype.hasOwnProperty.call(i.shape, u))
          throw new Error(`Unrecognized key: "${String(u)}"`);
        r[u] && q(a, u, i.shape[u]);
      }
      return q(this, "shape", a), a;
    },
    checks: []
  });
  return A(e, n);
}
s(Bh, "pick");
function Jh(e, r) {
  let i = e._zod.def, o = i.checks;
  if (o && o.length > 0)
    throw new Error(".omit() cannot be used on object schemas containing refinements");
  let n = $e(e._zod.def, {
    get shape() {
      let a = { ...e._zod.def.shape };
      for (let u of Reflect.ownKeys(r)) {
        if (!Object.prototype.hasOwnProperty.call(i.shape, u))
          throw new Error(`Unrecognized key: "${String(u)}"`);
        r[u] && delete a[u];
      }
      return q(this, "shape", a), a;
    },
    checks: []
  });
  return A(e, n);
}
s(Jh, "omit");
function qh(e, r) {
  if (!ve(r))
    throw new Error("Invalid input to extend: expected a plain object");
  let i = e._zod.def.checks;
  if (i && i.length > 0) {
    let n = e._zod.def.shape;
    for (let a of Reflect.ownKeys(r))
      if (Object.getOwnPropertyDescriptor(n, a) !== void 0)
        throw new Error("Cannot overwrite keys on object schemas containing refinements. Use `.safeExtend()` instead.");
  }
  let t = $e(e._zod.def, {
    get shape() {
      let n = { ...e._zod.def.shape, ...r };
      return q(this, "shape", n), n;
    }
  });
  return A(e, t);
}
s(qh, "extend");
function Kh(e, r) {
  if (!ve(r))
    throw new Error("Invalid input to safeExtend: expected a plain object");
  let i = $e(e._zod.def, {
    get shape() {
      let o = { ...e._zod.def.shape, ...r };
      return q(this, "shape", o), o;
    }
  });
  return A(e, i);
}
s(Kh, "safeExtend");
function Wh(e, r) {
  if (!r?._zod?.def)
    throw new Error("Invalid input to merge: expected an object schema. To merge a plain shape, use `.extend()`.");
  if (e._zod.def.checks?.length)
    throw new Error(".merge() cannot be used on object schemas containing refinements. Use .safeExtend() instead.");
  let i = $e(e._zod.def, {
    get shape() {
      let o = { ...e._zod.def.shape, ...r._zod.def.shape };
      return q(this, "shape", o), o;
    },
    get catchall() {
      return r._zod.def.catchall;
    },
    checks: r._zod.def.checks ?? []
  });
  return A(e, i);
}
s(Wh, "merge");
function Gh(e, r, i, o = "partial") {
  let n = r._zod.def.checks;
  if (n && n.length > 0)
    throw new Error(`.${o}() cannot be used on object schemas containing refinements`);
  let u = $e(r._zod.def, {
    get shape() {
      let c = r._zod.def.shape, l = { ...c };
      if (i)
        for (let d of Reflect.ownKeys(i)) {
          if (!Object.prototype.hasOwnProperty.call(c, d))
            throw new Error(`Unrecognized key: "${String(d)}"`);
          i[d] && (l[d] = e ? new e({
            type: "optional",
            innerType: c[d]
          }) : c[d]);
        }
      else
        for (let d of Reflect.ownKeys(c))
          l[d] = e ? new e({
            type: "optional",
            innerType: c[d]
          }) : c[d];
      return q(this, "shape", l), l;
    },
    checks: []
  });
  return A(r, u);
}
s(Gh, "partial");
function Xh(e, r, i) {
  let o = $e(r._zod.def, {
    get shape() {
      let t = r._zod.def.shape, n = { ...t };
      if (i)
        for (let a of Reflect.ownKeys(i)) {
          if (!Object.prototype.hasOwnProperty.call(n, a))
            throw new Error(`Unrecognized key: "${String(a)}"`);
          i[a] && (n[a] = new e({
            type: "nonoptional",
            innerType: t[a]
          }));
        }
      else
        for (let a of Reflect.ownKeys(t))
          n[a] = new e({
            type: "nonoptional",
            innerType: t[a]
          });
      return q(this, "shape", n), n;
    }
  });
  return A(r, o);
}
s(Xh, "required");
function Ee(e, r = 0) {
  if (e.aborted === !0)
    return !0;
  for (let i = r; i < e.issues.length; i++)
    if (e.issues[i]?.continue !== !0)
      return !0;
  return !1;
}
s(Ee, "aborted");
function Qo(e, r = 0) {
  if (e.aborted === !0)
    return !0;
  for (let i = r; i < e.issues.length; i++)
    if (e.issues[i]?.continue === !1)
      return !0;
  return !1;
}
s(Qo, "explicitlyAborted");
function oe(e, r) {
  return r.map((i) => {
    var o;
    return (o = i).path ?? (o.path = []), i.path.unshift(e), i;
  });
}
s(oe, "prefixIssues");
function wt(e) {
  return typeof e == "string" ? e : e?.message;
}
s(wt, "unwrapMessage");
function Sn(e, r, i) {
  var o;
  for (let t = r; t < e.length; t++)
    (o = e[t]).schema ?? (o.schema = i);
}
s(Sn, "attachSchema");
function ae(e, r, i) {
  var o;
  let t = e.inst?._zod?.traits;
  t?.has("$ZodType") && (t.has("$ZodCheck") ? (o = e).schema ?? (o.schema = e.inst) : e.schema = e.inst);
  let n = e.schema !== e.inst ? e.schema?._zod.def?.error : void 0, a = e.message ? e.message : wt(e.inst?._zod.def?.error?.(e)) ?? wt(n?.(e)) ?? wt(r?.error?.(e)) ?? wt(i.customError?.(e)) ?? wt(i.localeError?.(e)) ?? "Invalid input", { inst: u, schema: c, continue: l, input: d, ...f } = e;
  return f.path ?? (f.path = []), f.message = a, r?.reportInput && (f.input = d), f;
}
s(ae, "finalizeIssue");
function xr(e) {
  return e instanceof Set ? "set" : e instanceof Map ? "map" : e instanceof File ? "file" : "unknown";
}
s(xr, "getSizableOrigin");
var Hh = /[\uD800-\uDBFF]/;
function rt(e) {
  let r = e.length;
  if (!Hh.test(e))
    return r;
  let i = r;
  for (let o = 0; o < r - 1; o++)
    (e.charCodeAt(o) & 64512) === 55296 && (e.charCodeAt(o + 1) & 64512) === 56320 && (i--, o++);
  return i;
}
s(rt, "codePointLength");
function wr(e) {
  return Array.isArray(e) ? "array" : typeof e == "string" ? "string" : "unknown";
}
s(wr, "getLengthableOrigin");
function b(e) {
  let r = typeof e;
  switch (r) {
    case "number":
      return Number.isNaN(e) ? "nan" : "number";
    case "object": {
      if (e === null)
        return "null";
      if (Array.isArray(e))
        return "array";
      let i = e;
      if (i && Object.getPrototypeOf(i) !== Object.prototype && "constructor" in i && i.constructor)
        return i.constructor.name;
    }
  }
  return r;
}
s(b, "parsedType");
function St(...e) {
  let [r, i, o] = e;
  return typeof r == "string" ? {
    message: r,
    code: "custom",
    input: i,
    inst: o
  } : { ...r };
}
s(St, "issue");
function Qh(e) {
  return Object.entries(e).filter(([r, i]) => Number.isNaN(Number.parseInt(r, 10))).map((r) => r[1]);
}
s(Qh, "cleanEnum");
function Rf(e) {
  let r = atob(e), i = new Uint8Array(r.length);
  for (let o = 0; o < r.length; o++)
    i[o] = r.charCodeAt(o);
  return i;
}
s(Rf, "base64ToUint8Array");
function Ff(e) {
  let r = "";
  for (let i = 0; i < e.length; i++)
    r += String.fromCharCode(e[i]);
  return btoa(r);
}
s(Ff, "uint8ArrayToBase64");
function Yh(e) {
  let r = e.replace(/-/g, "+").replace(/_/g, "/"), i = "=".repeat((4 - r.length % 4) % 4);
  return Rf(r + i);
}
s(Yh, "base64urlToUint8Array");
function ev(e) {
  return Ff(e).replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, "");
}
s(ev, "uint8ArrayToBase64url");
function tv(e) {
  let r = e.replace(/^0x/, "");
  if (r.length % 2 !== 0)
    throw new Error("Invalid hex string length");
  let i = new Uint8Array(r.length / 2);
  for (let o = 0; o < r.length; o += 2)
    i[o / 2] = Number.parseInt(r.slice(o, o + 2), 16);
  return i;
}
s(tv, "hexToUint8Array");
function rv(e) {
  return Array.from(e).map((r) => r.toString(16).padStart(2, "0")).join("");
}
s(rv, "uint8ArrayToHex");
var Bo = class {
  static {
    s(this, "Class");
  }
  constructor(...r) {
  }
};
function Yo(e, r) {
  for (let i in r) {
    let o = Object.getOwnPropertyDescriptor(r, i);
    o.get ? Object.defineProperty(e, i, { ...o, enumerable: !1 }) : nv(e, i, o.value);
  }
}
s(Yo, "members");
function kt(e, r, i, o = !0) {
  return Object.defineProperty(e, r, { configurable: !0, writable: !0, enumerable: o, value: i }), i;
}
s(kt, "own");
function ea(e, r, i) {
  return kt(e, r, i, !1);
}
s(ea, "hide");
function nv(e, r, i) {
  Object.defineProperty(e, r, {
    configurable: !0,
    get() {
      return this == null ? i : kt(this, r, i.bind(this));
    },
    set(o) {
      kt(this, r, o);
    }
  });
}
s(nv, "defineBound");
function iv(e, r) {
  let i = Object.getPrototypeOf(e);
  return r in i ? void 0 : i;
}
s(iv, "claim");
var Mo, Ue = !1, ov = {
  configurable: !0,
  get() {
    Ue = !0;
  }
};
function T(e, r, i) {
  let o = Object.getPrototypeOf(e._zod);
  if (r in o && Mo !== e._zod) {
    Mo = void 0;
    return;
  }
  Mo = e._zod, Object.defineProperty(o, r, {
    configurable: !0,
    get() {
      Object.defineProperty(this, r, ov);
      let t = Ue;
      Ue = !1;
      try {
        let n = i(this);
        return Ue ? delete this[r] : Object.defineProperty(this, r, { configurable: !0, writable: !0, value: n }), Ue = Ue || t, n;
      } catch (n) {
        throw delete this[r], Ue = Ue || t, n;
      }
    },
    set(t) {
      Object.defineProperty(this, r, { configurable: !0, writable: !0, value: t });
    }
  });
}
s(T, "defineLazyInternal");
function av(e, r, i, o) {
  let t = iv(e, r);
  t && Object.defineProperty(t, r, {
    configurable: !0,
    get() {
      let n = { configurable: !0, writable: !0, enumerable: o, value: void 0 };
      return Object.defineProperty(this, r, n), n.value = i(this), Object.defineProperty(this, r, n), n.value;
    },
    set(n) {
      Object.defineProperty(this, r, { configurable: !0, writable: !0, enumerable: o, value: n });
    }
  });
}
s(av, "installLazyProp");
var On = "~constantCatch";
function ta(e) {
  let r = /* @__PURE__ */ s(() => e, "fn");
  return r[On] = !0, r;
}
s(ta, "constantCatch");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/core.js
var Lf, na = /* @__PURE__ */ Object.freeze({
  status: "aborted"
}), ra = { value: void 0, enumerable: !1 }, Vf = "captureStackTrace" in Error ? Error : null;
function sv(e) {
  let r = Vf;
  if (r) {
    let i = r.stackTraceLimit;
    if (typeof i == "number") {
      try {
        r.stackTraceLimit = 0;
      } catch {
        return Vf = null, new e();
      }
      try {
        return new e();
      } finally {
        r.stackTraceLimit = i;
      }
    }
  }
  return new e();
}
s(sv, "newError");
// @__NO_SIDE_EFFECTS__
function m(e, r, i, o) {
  let t = {};
  function n(p) {
    this.def = p, this.constr = f, this.traits = /* @__PURE__ */ new Set();
  }
  s(n, "Internals"), n.prototype = t;
  let a = i, u = a && /* @__PURE__ */ new WeakSet();
  function c(p, h) {
    if (!p._zod) {
      ra.value = new n(h);
      try {
        Object.defineProperty(p, "_zod", ra);
      } finally {
        ra.value = void 0;
      }
    }
    if (p._zod.traits.has(e))
      return;
    if (p._zod.traits.add(e), r(p, h), u) {
      let k = Object.getPrototypeOf(p), z = p._zod.constr.prototype, Z = k;
      for (; Z && Z !== z; )
        Z = Object.getPrototypeOf(Z);
      let O = Z ?? k;
      u.has(O) || (u.add(O), Yo(O, a));
    }
    let v = f.prototype;
    for (let k in v)
      Object.prototype.hasOwnProperty.call(v, k) && (k in p || (p[k] = v[k].bind(p)));
  }
  s(c, "init");
  let l = o?.Parent ?? Object;
  class d extends l {
    static {
      s(this, "Definition");
    }
  }
  Object.defineProperty(d, "name", { value: e });
  function f(p) {
    let h = o?.Parent ? sv(d) : this;
    c(h, p);
    let v = h._zod.deferred;
    if (v) {
      for (let z of v)
        z();
      h._zod.deferred = void 0;
    }
    let k = globalThis.__zod_globalConfig?.postProcessor;
    return k && k(h), h;
  }
  return s(f, "_"), Object.defineProperty(f, "init", { value: c }), Object.defineProperty(f, Symbol.hasInstance, {
    value: /* @__PURE__ */ s((p) => o?.Parent && p instanceof o.Parent ? !0 : p?._zod?.traits?.has(e), "value")
  }), Object.defineProperty(f, "name", { value: e }), f;
}
s(m, "$constructor");
var ia = /* @__PURE__ */ Symbol("zod_brand"), se = class extends Error {
  static {
    s(this, "$ZodAsyncError");
  }
  constructor() {
    super("Encountered Promise during synchronous parse. Use .parseAsync() instead.");
  }
}, Ce = class extends Error {
  static {
    s(this, "$ZodEncodeError");
  }
  constructor(r) {
    super(`Encountered unidirectional transform during encode: ${r}`), this.name = "ZodEncodeError";
  }
};
(Lf = globalThis).__zod_globalConfig ?? (Lf.__zod_globalConfig = {});
var X = globalThis.__zod_globalConfig;
function K(e) {
  return e && Object.assign(X, e), X;
}
s(K, "config");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/errors.js
function uv() {
  let e = this._zod;
  return e.message ?? (e.message = JSON.stringify(e.def, It, 2)), e.message;
}
s(uv, "_getMessage");
function cv(e) {
  this._zod.message = e;
}
s(cv, "_setMessage");
var lv = {
  get: uv,
  set: cv,
  enumerable: !0,
  configurable: !0
}, aa = { value: void 0, enumerable: !1 }, sa = { value: void 0, enumerable: !1 }, Mf = /* @__PURE__ */ new WeakSet([Object.prototype, Error.prototype]), Bf = /* @__PURE__ */ s((e, r) => {
  e.name = "$ZodError", aa.value = e._zod, Object.defineProperty(e, "_zod", aa), sa.value = r, Object.defineProperty(e, "issues", sa), aa.value = void 0, sa.value = void 0, Object.defineProperty(e, "message", lv);
  let i = Object.getPrototypeOf(e);
  Mf.has(i) || (Mf.add(i), Object.defineProperty(i, "toString", {
    configurable: !0,
    enumerable: !1,
    get() {
      let o = /* @__PURE__ */ s(() => this.message, "value");
      return Object.defineProperty(this, "toString", { value: o, configurable: !0, writable: !0 }), o;
    },
    set(o) {
      Object.defineProperty(this, "toString", { value: o, configurable: !0, writable: !0 });
    }
  }));
}, "initializer"), nt = m("$ZodError", Bf), ue = m("$ZodError", Bf, void 0, {
  Parent: Error
});
function dv(e, r, i) {
  return Object.prototype.hasOwnProperty.call(e, r) || (r === "__proto__" ? Object.defineProperty(e, r, { value: i(), writable: !0, enumerable: !0, configurable: !0 }) : e[r] = i()), e[r];
}
s(dv, "node");
function kr(e, r = (i) => i.message) {
  let i = {}, o = [];
  for (let t of e.issues)
    t.path.length > 0 ? dv(i, t.path[0], () => []).push(r(t)) : o.push(r(t));
  return { formErrors: o, fieldErrors: i };
}
s(kr, "flattenError");
function Ir(e, r = (i) => i.message) {
  let i = { _errors: [] }, o = /* @__PURE__ */ s((t, n = []) => {
    for (let a of t.issues)
      if (a.code === "invalid_union" && a.errors.length)
        a.errors.map((u) => o({ issues: u }, [...n, ...a.path]));
      else if (a.code === "invalid_key")
        o({ issues: a.issues }, [...n, ...a.path]);
      else if (a.code === "invalid_element")
        o({ issues: a.issues }, [...n, ...a.path]);
      else {
        let u = [...n, ...a.path];
        if (u.length === 0)
          i._errors.push(r(a));
        else {
          let c = i, l = 0;
          for (; l < u.length; ) {
            let d = u[l], f = l === u.length - 1;
            if (d === "_errors") {
              f && c._errors.push(r(a)), l++;
              continue;
            }
            Object.prototype.hasOwnProperty.call(c, d) || Object.defineProperty(c, d, {
              value: { _errors: [] },
              enumerable: !0,
              writable: !0,
              configurable: !0
            });
            let p = c[d];
            f && p._errors.push(r(a)), c = p, l++;
          }
        }
      }
  }, "processError");
  return o(e), i;
}
s(Ir, "formatError");
function ua(e, r = (i) => i.message) {
  let i = { errors: [] }, o = /* @__PURE__ */ s((t, n = []) => {
    var a;
    for (let u of t.issues)
      if (u.code === "invalid_union" && u.errors.length)
        u.errors.map((c) => o({ issues: c }, [...n, ...u.path]));
      else if (u.code === "invalid_key")
        o({ issues: u.issues }, [...n, ...u.path]);
      else if (u.code === "invalid_element")
        o({ issues: u.issues }, [...n, ...u.path]);
      else {
        let c = [...n, ...u.path];
        if (c.length === 0) {
          i.errors.push(r(u));
          continue;
        }
        let l = i, d = 0;
        for (; d < c.length; ) {
          let f = c[d], p = d === c.length - 1;
          typeof f == "string" ? (l.properties ?? (l.properties = {}), Object.prototype.hasOwnProperty.call(l.properties, f) || Object.defineProperty(l.properties, f, {
            value: { errors: [] },
            enumerable: !0,
            writable: !0,
            configurable: !0
          }), l = l.properties[f]) : (l.items ?? (l.items = []), (a = l.items)[f] ?? (a[f] = { errors: [] }), l = l.items[f]), p && l.errors.push(r(u)), d++;
        }
      }
  }, "processError");
  return o(e), i;
}
s(ua, "treeifyError");
function Jf(e) {
  let r = [], i = e.map((o) => typeof o == "object" ? o.key : o);
  for (let o of i)
    typeof o == "number" ? r.push(`[${o}]`) : typeof o == "symbol" ? r.push(`[${JSON.stringify(String(o))}]`) : /[^\w$]/.test(o) ? r.push(`[${JSON.stringify(o)}]`) : (r.length && r.push("."), r.push(o));
  return r.join("");
}
s(Jf, "toDotPath");
function ca(e) {
  let r = [], i = [...e.issues].sort((o, t) => (o.path ?? []).length - (t.path ?? []).length);
  for (let o of i)
    r.push(`\u2716 ${o.message}`), o.path?.length && r.push(`  \u2192 at ${Jf(o.path)}`);
  return r.join(`
`);
}
s(ca, "prettifyError");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/parse.js
function jn(e, r) {
  return { callee: r?.callee ?? e, Err: r?.Err };
}
s(jn, "finalizeParams");
var Ot = /* @__PURE__ */ s((e) => {
  let r = /* @__PURE__ */ s((i, o, t, n) => {
    let a = t ? { ...t, async: !1 } : { async: !1 }, u = i._zod.run({ value: o, issues: [] }, a);
    if (u instanceof Promise)
      throw new se();
    if (u.issues.length) {
      let c = new (n?.Err ?? e)(u.issues.map((l) => ae(l, a, K())));
      throw zn(c, n?.callee ?? r), c;
    }
    return u.value;
  }, "fn");
  return r;
}, "_parse"), it = /* @__PURE__ */ Ot(ue), jt = /* @__PURE__ */ s((e) => {
  let r = /* @__PURE__ */ s(async (i, o, t, n) => {
    let a = t ? { ...t, async: !0 } : { async: !0 }, u = i._zod.run({ value: o, issues: [] }, a);
    if (u instanceof Promise && (u = await u), u.issues.length) {
      let c = new (n?.Err ?? e)(u.issues.map((l) => ae(l, a, K())));
      throw zn(c, n?.callee ?? r), c;
    }
    return u.value;
  }, "fn");
  return r;
}, "_parseAsync"), Pn = /* @__PURE__ */ jt(ue), Pt = /* @__PURE__ */ s((e) => (r, i, o) => {
  let t = o ? { ...o, async: !1 } : { async: !1 }, n = r._zod.run({ value: i, issues: [] }, t);
  if (n instanceof Promise)
    throw new se();
  return n.issues.length ? {
    success: !1,
    error: new (e ?? nt)(n.issues.map((a) => ae(a, t, K())))
  } : { success: !0, data: n.value };
}, "_safeParse"), zr = /* @__PURE__ */ Pt(ue), Dt = /* @__PURE__ */ s((e) => async (r, i, o) => {
  let t = o ? { ...o, async: !0 } : { async: !0 }, n = r._zod.run({ value: i, issues: [] }, t);
  return n instanceof Promise && (n = await n), n.issues.length ? {
    success: !1,
    error: new e(n.issues.map((a) => ae(a, t, K())))
  } : { success: !0, data: n.value };
}, "_safeParseAsync"), la = /* @__PURE__ */ Dt(ue), pv = /* @__PURE__ */ Symbol.for("zod.compile.invalid"), mv = /* @__PURE__ */ Symbol.for("zod.compile.fallback"), da = /* @__PURE__ */ s(((e, r, i) => {
  let o = e._zod.bag.validator;
  return o !== void 0 && o(r) !== pv ? !0 : gv(e, r, i);
}), "validate");
function gv(e, r, i) {
  let o = i ? { ...i, async: !1 } : { async: !1 }, t = e._zod.bag.fallbackRun, n;
  if (t ? (o[mv] = !0, n = t({ value: r, issues: [] }, o)) : n = e._zod.run({ value: r, issues: [] }, o), n instanceof Promise)
    throw new se();
  return n.issues.length === 0;
}
s(gv, "validateFallback");
var fa = /* @__PURE__ */ s(async (e, r, i) => {
  let o = i ? { ...i, async: !0 } : { async: !0 }, t = e._zod.run({ value: r, issues: [] }, o);
  return t instanceof Promise && (t = await t), t.issues.length === 0;
}, "validateAsync"), Dn = /* @__PURE__ */ s((e) => {
  let r = Ot(e), i = /* @__PURE__ */ s((o, t, n, a) => {
    let u = n ? { ...n, direction: "backward" } : { direction: "backward" };
    return r(o, t, u, jn(i, a));
  }, "fn");
  return i;
}, "_encode"), De = /* @__PURE__ */ Dn(ue), Nn = /* @__PURE__ */ s((e) => {
  let r = Ot(e), i = /* @__PURE__ */ s((o, t, n, a) => r(o, t, n, jn(i, a)), "fn");
  return i;
}, "_decode"), hv = /* @__PURE__ */ Nn(ue), Tn = /* @__PURE__ */ s((e) => {
  let r = jt(e), i = /* @__PURE__ */ s(async (o, t, n, a) => {
    let u = n ? { ...n, direction: "backward" } : { direction: "backward" };
    return await r(o, t, u, jn(i, a));
  }, "fn");
  return i;
}, "_encodeAsync"), vv = /* @__PURE__ */ Tn(ue), An = /* @__PURE__ */ s((e) => {
  let r = jt(e), i = /* @__PURE__ */ s(async (o, t, n, a) => await r(o, t, n, jn(i, a)), "fn");
  return i;
}, "_decodeAsync"), yv = /* @__PURE__ */ An(ue), Un = /* @__PURE__ */ s((e) => (r, i, o) => {
  let t = o ? { ...o, direction: "backward" } : { direction: "backward" };
  return Pt(e)(r, i, t);
}, "_safeEncode"), $v = /* @__PURE__ */ Un(ue), En = /* @__PURE__ */ s((e) => (r, i, o) => Pt(e)(r, i, o), "_safeDecode"), bv = /* @__PURE__ */ En(ue), Cn = /* @__PURE__ */ s((e) => async (r, i, o) => {
  let t = o ? { ...o, direction: "backward" } : { direction: "backward" };
  return Dt(e)(r, i, t);
}, "_safeEncodeAsync"), _v = /* @__PURE__ */ Cn(ue), Zn = /* @__PURE__ */ s((e) => async (r, i, o) => Dt(e)(r, i, o), "_safeDecodeAsync"), xv = /* @__PURE__ */ Zn(ue);

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/regexes.js
var te = {};
Pe(te, {
  base64: () => Pa,
  base64url: () => Rn,
  bigint: () => Ca,
  boolean: () => Za,
  browserEmail: () => Pv,
  cidrv4: () => Oa,
  cidrv6: () => ja,
  creditCard: () => Fn,
  cuid: () => ma,
  cuid2: () => ga,
  date: () => Ta,
  datetime: () => Ua,
  domain: () => Tv,
  duration: () => _a,
  e164: () => Na,
  email: () => wa,
  emoji: () => ka,
  extendedDuration: () => wv,
  guid: () => xa,
  hex: () => Uv,
  hostname: () => Nv,
  html5Email: () => Sv,
  httpProtocol: () => Da,
  idnEmail: () => jv,
  integer: () => Sr,
  ipv4: () => Ia,
  ipv6: () => za,
  ksuid: () => ya,
  lowercase: () => La,
  mac: () => Sa,
  md5_base64: () => Cv,
  md5_base64url: () => Zv,
  md5_hex: () => Ev,
  nanoid: () => $a,
  nanoidOfLength: () => ba,
  null: () => Ra,
  number: () => Ze,
  rfc5322Email: () => Ov,
  sha1_base64: () => Fv,
  sha1_base64url: () => Lv,
  sha1_hex: () => Rv,
  sha256_base64: () => Mv,
  sha256_base64url: () => Bv,
  sha256_hex: () => Vv,
  sha384_base64: () => qv,
  sha384_base64url: () => Kv,
  sha384_hex: () => Jv,
  sha512_base64: () => Gv,
  sha512_base64url: () => Xv,
  sha512_hex: () => Wv,
  string: () => Ea,
  time: () => Aa,
  ulid: () => ha,
  undefined: () => Fa,
  unicodeEmail: () => qf,
  uppercase: () => Va,
  uuid: () => ot,
  uuid4: () => kv,
  uuid6: () => Iv,
  uuid7: () => zv,
  xid: () => va
});
var ma = /^[cC][0-9a-z]{6,}$/, ga = /^[0-9a-z]+$/, ha = /^[0-7][0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{25}$/, va = /^[0-9a-vA-V]{20}$/, ya = /^[A-Za-z0-9]{27}$/, $a = /^[a-zA-Z0-9_-]{21}$/;
function ba(e) {
  return new RegExp(`^[a-zA-Z0-9_-]{${e}}$`);
}
s(ba, "nanoidOfLength");
var _a = /^P(?:(\d+W)|(?!.*W)(?=\d|T\d)(\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+([.,]\d+)?S)?)?)$/, wv = /^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/, xa = /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/, ot = /* @__PURE__ */ s((e) => e ? new RegExp(`^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${e}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`) : /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/, "uuid"), kv = /* @__PURE__ */ ot(4), Iv = /* @__PURE__ */ ot(6), zv = /* @__PURE__ */ ot(7), wa = /^(?!\.)(?!.*\.\.)([A-Za-z0-9_'+\-\.]*)[A-Za-z0-9_+-]@([A-Za-z0-9][A-Za-z0-9\-]*\.)+[A-Za-z]{2,}$/, Sv = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/, Ov = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/, qf = /^[^\s@"]{1,64}@[^\s@]{1,255}$/u, jv = qf, Pv = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/, Dv = "^[\\p{Extended_Pictographic}\\p{Emoji_Component}]+$";
function ka() {
  return new RegExp(Dv, "u");
}
s(ka, "emoji");
var Ia = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/, za = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))$/, Sa = /* @__PURE__ */ s((e) => {
  let r = ye(e ?? ":");
  return new RegExp(`^(?:[0-9A-F]{2}${r}){5}[0-9A-F]{2}$|^(?:[0-9a-f]{2}${r}){5}[0-9a-f]{2}$`);
}, "mac"), Oa = /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/([0-9]|[1-2][0-9]|3[0-2])$/, ja = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/, Pa = /^$|^(?:[0-9a-zA-Z+/]{4})*(?:(?:[0-9a-zA-Z+/]{2}==)|(?:[0-9a-zA-Z+/]{3}=))?$/, Rn = /^[A-Za-z0-9_-]*$/, Nv = /^(?=.{1,253}\.?$)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[-0-9a-zA-Z]{0,61}[0-9a-zA-Z])?)*\.?$/, Tv = /^(?=.{1,253}$)([a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,63}$/, Da = /^https?$/, Na = /^\+[1-9]\d{6,14}$/, Fn = /^\d(?:[ -]?\d){11,18}$/, Kf = "(?:(?:\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-(?:(?:0[13578]|1[02])-(?:0[1-9]|[12]\\d|3[01])|(?:0[469]|11)-(?:0[1-9]|[12]\\d|30)|(?:02)-(?:0[1-9]|1\\d|2[0-8])))";
function Av(e) {
  return new RegExp(`^${e}$`);
}
s(Av, "anchor");
var Ta = /* @__PURE__ */ Av(Kf);
function pa(e) {
  let r = "(?:[01]\\d|2[0-3]):[0-5]\\d";
  return typeof e.precision == "number" ? e.precision === -1 ? `${r}` : e.precision === 0 ? `${r}:[0-5]\\d` : `${r}:[0-5]\\d\\.\\d{${e.precision}}` : e.seconds ? `${r}:[0-5]\\d(?:\\.\\d+)?` : `${r}(?::[0-5]\\d(?:\\.\\d+)?)?`;
}
s(pa, "timeSource");
function Aa(e) {
  return new RegExp(`^${pa(e)}$`);
}
s(Aa, "time");
function Ua(e) {
  let r = ["Z"];
  e.offset && r.push("([+-](?:[01]\\d|2[0-3]):[0-5]\\d)");
  let i = `${pa({ precision: e.precision, seconds: !0 })}(?:${r.join("|")})`, o = e.local ? `${i}|${pa({ precision: e.precision })}` : i;
  return new RegExp(`^${Kf}T(?:${o})$`);
}
s(Ua, "datetime");
var Ea = /* @__PURE__ */ s((e) => {
  let r = e ? `[\\s\\S]{${e?.minimum ?? 0},${e?.maximum ?? ""}}` : "[\\s\\S]*";
  return new RegExp(`^${r}$`);
}, "string"), Ca = /^-?\d+n?$/, Sr = /^-?\d+$/, Ze = /^-?\d+(?:\.\d+)?$/, Za = /^(?:true|false)$/i, Ra = /^null$/i;
var Fa = /^undefined$/i;
var La = /^[^A-Z]*$/, Va = /^[^a-z]*$/, Uv = /^[0-9a-fA-F]*$/;
function Or(e, r) {
  return new RegExp(`^[A-Za-z0-9+/]{${e}}${r}$`);
}
s(Or, "fixedBase64");
function jr(e) {
  return new RegExp(`^[A-Za-z0-9_-]{${e}}$`);
}
s(jr, "fixedBase64url");
var Ev = /^[0-9a-fA-F]{32}$/, Cv = /* @__PURE__ */ Or(22, "=="), Zv = /* @__PURE__ */ jr(22), Rv = /^[0-9a-fA-F]{40}$/, Fv = /* @__PURE__ */ Or(27, "="), Lv = /* @__PURE__ */ jr(27), Vv = /^[0-9a-fA-F]{64}$/, Mv = /* @__PURE__ */ Or(43, "="), Bv = /* @__PURE__ */ jr(43), Jv = /^[0-9a-fA-F]{96}$/, qv = /* @__PURE__ */ Or(64, ""), Kv = /* @__PURE__ */ jr(64), Wv = /^[0-9a-fA-F]{128}$/, Gv = /* @__PURE__ */ Or(86, "=="), Xv = /* @__PURE__ */ jr(86);

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/checks.js
var L = /* @__PURE__ */ m("$ZodCheck", (e, r) => {
  var i;
  e._zod ?? (e._zod = {}), e._zod.def = r, (i = e._zod).onattach ?? (i.onattach = []);
}), Ma = /* @__PURE__ */ s((e) => {
  let r = e.value;
  return !In(r) && r.size !== void 0;
}, "_whenHasSize"), Ba = /* @__PURE__ */ s((e) => {
  let r = e.value;
  return !In(r) && r.length !== void 0;
}, "_whenHasLength"), Ln = {
  number: "number",
  bigint: "bigint",
  object: "date"
}, Vn = /* @__PURE__ */ m("$ZodCheckLessThan", (e, r) => {
  L.init(e, r);
  let i = Ln[typeof r.value];
  e._zod.onattach.push((o) => {
    let t = o._zod.bag, n = (r.inclusive ? t.maximum : t.exclusiveMaximum) ?? Number.POSITIVE_INFINITY;
    r.value < n && (r.inclusive ? t.maximum = r.value : t.exclusiveMaximum = r.value);
  }), e._zod.check = (o) => {
    (r.inclusive ? o.value <= r.value : o.value < r.value) || o.issues.push({
      origin: Ln[typeof o.value] ?? i,
      code: "too_big",
      maximum: typeof r.value == "object" ? r.value.getTime() : r.value,
      input: o.value,
      inclusive: r.inclusive,
      inst: e,
      continue: !r.abort
    });
  };
}), Mn = /* @__PURE__ */ m("$ZodCheckGreaterThan", (e, r) => {
  L.init(e, r);
  let i = Ln[typeof r.value];
  e._zod.onattach.push((o) => {
    let t = o._zod.bag, n = (r.inclusive ? t.minimum : t.exclusiveMinimum) ?? Number.NEGATIVE_INFINITY;
    r.value > n && (r.inclusive ? t.minimum = r.value : t.exclusiveMinimum = r.value);
  }), e._zod.check = (o) => {
    (r.inclusive ? o.value >= r.value : o.value > r.value) || o.issues.push({
      origin: Ln[typeof o.value] ?? i,
      code: "too_small",
      minimum: typeof r.value == "object" ? r.value.getTime() : r.value,
      input: o.value,
      inclusive: r.inclusive,
      inst: e,
      continue: !r.abort
    });
  };
}), Ja = /* @__PURE__ */ m("$ZodCheckMultipleOf", (e, r) => {
  L.init(e, r), e._zod.onattach.push((i) => {
    var o;
    (o = i._zod.bag).multipleOf ?? (o.multipleOf = r.value);
  }), e._zod.check = (i) => {
    if (typeof i.value != typeof r.value)
      throw new Error("Cannot mix number and bigint in multiple_of check.");
    (typeof i.value == "bigint" ? (
      // `value % 0n` throws, and nothing is a multiple of zero — the number branch already fails this way via NaN
      r.value !== BigInt(0) && i.value % r.value === BigInt(0)
    ) : $r(i.value, r.value) === 0) || i.issues.push({
      origin: typeof i.value,
      code: "not_multiple_of",
      divisor: r.value,
      input: i.value,
      inst: e,
      continue: !r.abort
    });
  };
}), qa = /* @__PURE__ */ m("$ZodCheckNumberFormat", (e, r) => {
  L.init(e, r), r.format = r.format || "float64";
  let i = r.format?.includes("int"), o = i ? "int" : "number", [t, n] = Xo[r.format];
  e._zod.onattach.push((a) => {
    let u = a._zod.bag;
    u.format = r.format, u.minimum = t, u.maximum = n, i && (u.pattern = Sr);
  }), e._zod.check = (a) => {
    let u = a.value;
    if (i) {
      if (!Number.isInteger(u)) {
        a.issues.push({
          expected: o,
          format: r.format,
          code: "invalid_type",
          continue: !1,
          input: u,
          inst: e
        });
        return;
      }
      if (!Number.isSafeInteger(u)) {
        u > 0 ? a.issues.push({
          input: u,
          code: "too_big",
          maximum: Number.MAX_SAFE_INTEGER,
          note: "Integers must be within the safe integer range.",
          inst: e,
          origin: o,
          inclusive: !0,
          continue: !r.abort
        }) : a.issues.push({
          input: u,
          code: "too_small",
          minimum: Number.MIN_SAFE_INTEGER,
          note: "Integers must be within the safe integer range.",
          inst: e,
          origin: o,
          inclusive: !0,
          continue: !r.abort
        });
        return;
      }
    }
    u < t && a.issues.push({
      origin: "number",
      input: u,
      code: "too_small",
      minimum: t,
      inclusive: !0,
      inst: e,
      continue: !r.abort
    }), u > n && a.issues.push({
      origin: "number",
      input: u,
      code: "too_big",
      maximum: n,
      inclusive: !0,
      inst: e,
      continue: !r.abort
    });
  };
}), Ka = /* @__PURE__ */ m("$ZodCheckBigIntFormat", (e, r) => {
  L.init(e, r);
  let [i, o] = Ho[r.format];
  e._zod.onattach.push((t) => {
    let n = t._zod.bag;
    n.format = r.format, n.minimum = i, n.maximum = o;
  }), e._zod.check = (t) => {
    let n = t.value;
    n < i && t.issues.push({
      origin: "bigint",
      input: n,
      code: "too_small",
      minimum: i,
      inclusive: !0,
      inst: e,
      continue: !r.abort
    }), n > o && t.issues.push({
      origin: "bigint",
      input: n,
      code: "too_big",
      maximum: o,
      inclusive: !0,
      inst: e,
      continue: !r.abort
    });
  };
}), Wa = /* @__PURE__ */ m("$ZodCheckMaxSize", (e, r) => {
  var i;
  L.init(e, r), (i = e._zod.def).when ?? (i.when = Ma), e._zod.onattach.push((o) => {
    let t = o._zod.bag.maximum ?? Number.POSITIVE_INFINITY;
    r.maximum < t && (o._zod.bag.maximum = r.maximum);
  }), e._zod.check = (o) => {
    let t = o.value;
    t.size <= r.maximum || o.issues.push({
      origin: xr(t),
      code: "too_big",
      maximum: r.maximum,
      inclusive: !0,
      input: t,
      inst: e,
      continue: !r.abort
    });
  };
}), Ga = /* @__PURE__ */ m("$ZodCheckMinSize", (e, r) => {
  var i;
  L.init(e, r), (i = e._zod.def).when ?? (i.when = Ma), e._zod.onattach.push((o) => {
    let t = o._zod.bag.minimum ?? Number.NEGATIVE_INFINITY;
    r.minimum > t && (o._zod.bag.minimum = r.minimum);
  }), e._zod.check = (o) => {
    let t = o.value;
    t.size >= r.minimum || o.issues.push({
      origin: xr(t),
      code: "too_small",
      minimum: r.minimum,
      inclusive: !0,
      input: t,
      inst: e,
      continue: !r.abort
    });
  };
}), Xa = /* @__PURE__ */ m("$ZodCheckSizeEquals", (e, r) => {
  var i;
  L.init(e, r), (i = e._zod.def).when ?? (i.when = Ma), e._zod.onattach.push((o) => {
    let t = o._zod.bag;
    t.minimum = r.size, t.maximum = r.size, t.size = r.size;
  }), e._zod.check = (o) => {
    let t = o.value, n = t.size;
    if (n === r.size)
      return;
    let a = n > r.size;
    o.issues.push({
      origin: xr(t),
      ...a ? { code: "too_big", maximum: r.size } : { code: "too_small", minimum: r.size },
      inclusive: !0,
      exact: !0,
      input: o.value,
      inst: e,
      continue: !r.abort
    });
  };
}), Ha = /* @__PURE__ */ m("$ZodCheckMaxLength", (e, r) => {
  var i;
  L.init(e, r), (i = e._zod.def).when ?? (i.when = Ba), e._zod.onattach.push((o) => {
    let t = o._zod.bag.maximum ?? Number.POSITIVE_INFINITY;
    r.maximum < t && (o._zod.bag.maximum = r.maximum);
  }), e._zod.check = (o) => {
    let t = o.value, n = t.length;
    if ((typeof t == "string" && n > r.maximum ? rt(t) : n) <= r.maximum)
      return;
    let u = wr(t);
    o.issues.push({
      origin: u,
      code: "too_big",
      maximum: r.maximum,
      inclusive: !0,
      input: t,
      inst: e,
      continue: !r.abort
    });
  };
}), Qa = /* @__PURE__ */ m("$ZodCheckMinLength", (e, r) => {
  var i;
  L.init(e, r), (i = e._zod.def).when ?? (i.when = Ba), e._zod.onattach.push((o) => {
    let t = o._zod.bag.minimum ?? Number.NEGATIVE_INFINITY;
    r.minimum > t && (o._zod.bag.minimum = r.minimum);
  }), e._zod.check = (o) => {
    let t = o.value, n = t.length;
    if ((typeof t == "string" && n >= r.minimum && n < r.minimum * 2 ? rt(t) : n) >= r.minimum)
      return;
    let u = wr(t);
    o.issues.push({
      origin: u,
      code: "too_small",
      minimum: r.minimum,
      inclusive: !0,
      input: t,
      inst: e,
      continue: !r.abort
    });
  };
}), Ya = /* @__PURE__ */ m("$ZodCheckLengthEquals", (e, r) => {
  var i;
  L.init(e, r), (i = e._zod.def).when ?? (i.when = Ba), e._zod.onattach.push((o) => {
    let t = o._zod.bag;
    t.minimum = r.length, t.maximum = r.length, t.length = r.length;
  }), e._zod.check = (o) => {
    let t = o.value, n = t.length, a = typeof t == "string" && n >= r.length && n <= r.length * 2 ? rt(t) : n;
    if (a === r.length)
      return;
    let u = wr(t), c = a > r.length;
    o.issues.push({
      origin: u,
      ...c ? { code: "too_big", maximum: r.length } : { code: "too_small", minimum: r.length },
      inclusive: !0,
      exact: !0,
      input: o.value,
      inst: e,
      continue: !r.abort
    });
  };
}), Nt = /* @__PURE__ */ m("$ZodCheckStringFormat", (e, r) => {
  var i, o;
  L.init(e, r), e._zod.onattach.push((t) => {
    let n = t._zod.bag;
    n.format = r.format, r.pattern && (n.patterns ?? (n.patterns = /* @__PURE__ */ new Set()), n.patterns.add(r.pattern));
  }), r.pattern ? (i = e._zod).check ?? (i.check = (t) => {
    r.pattern.lastIndex = 0, !r.pattern.test(t.value) && t.issues.push({
      origin: "string",
      code: "invalid_format",
      format: r.format,
      input: t.value,
      ...r.pattern ? { pattern: r.pattern.toString() } : {},
      inst: e,
      continue: !r.abort
    });
  }) : (o = e._zod).check ?? (o.check = () => {
  });
}), es = /* @__PURE__ */ m("$ZodCheckRegex", (e, r) => {
  Nt.init(e, r), e._zod.check = (i) => {
    r.pattern.lastIndex = 0, !r.pattern.test(i.value) && i.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "regex",
      input: i.value,
      pattern: r.pattern.toString(),
      inst: e,
      continue: !r.abort
    });
  };
}), ts = /* @__PURE__ */ m("$ZodCheckLowerCase", (e, r) => {
  r.pattern ?? (r.pattern = La), Nt.init(e, r);
}), rs = /* @__PURE__ */ m("$ZodCheckUpperCase", (e, r) => {
  r.pattern ?? (r.pattern = Va), Nt.init(e, r);
}), ns = /* @__PURE__ */ m("$ZodCheckIncludes", (e, r) => {
  L.init(e, r);
  let i = ye(r.includes), o = new RegExp(typeof r.position == "number" ? `^.{${r.position},}${i}` : i);
  r.pattern = o, e._zod.onattach.push((t) => {
    let n = t._zod.bag;
    n.patterns ?? (n.patterns = /* @__PURE__ */ new Set()), n.patterns.add(o);
  }), e._zod.check = (t) => {
    t.value.includes(r.includes, r.position) || t.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "includes",
      includes: r.includes,
      input: t.value,
      inst: e,
      continue: !r.abort
    });
  };
}), is = /* @__PURE__ */ m("$ZodCheckStartsWith", (e, r) => {
  L.init(e, r);
  let i = new RegExp(`^${ye(r.prefix)}.*`);
  r.pattern ?? (r.pattern = i), e._zod.onattach.push((o) => {
    let t = o._zod.bag;
    t.patterns ?? (t.patterns = /* @__PURE__ */ new Set()), t.patterns.add(i);
  }), e._zod.check = (o) => {
    o.value.startsWith(r.prefix) || o.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "starts_with",
      prefix: r.prefix,
      input: o.value,
      inst: e,
      continue: !r.abort
    });
  };
}), os = /* @__PURE__ */ m("$ZodCheckEndsWith", (e, r) => {
  L.init(e, r);
  let i = new RegExp(`.*${ye(r.suffix)}$`);
  r.pattern ?? (r.pattern = i), e._zod.onattach.push((o) => {
    let t = o._zod.bag;
    t.patterns ?? (t.patterns = /* @__PURE__ */ new Set()), t.patterns.add(i);
  }), e._zod.check = (o) => {
    o.value.endsWith(r.suffix) || o.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "ends_with",
      suffix: r.suffix,
      input: o.value,
      inst: e,
      continue: !r.abort
    });
  };
});
function Wf(e, r, i) {
  e.issues.length && r.issues.push(...oe(i, e.issues));
}
s(Wf, "handleCheckPropertyResult");
var Bn = /* @__PURE__ */ m("$ZodCheckProperty", (e, r) => {
  L.init(e, r), e._zod.check = (i) => {
    let o = r.schema._zod.run({
      value: i.value[r.property],
      issues: []
    }, {});
    if (o instanceof Promise)
      return o.then((t) => Wf(t, i, r.property));
    Wf(o, i, r.property);
  };
}), as = /* @__PURE__ */ m("$ZodCheckMimeType", (e, r) => {
  L.init(e, r);
  let i = new Set(r.mime);
  e._zod.onattach.push((o) => {
    o._zod.bag.mime = r.mime;
  }), e._zod.check = (o) => {
    i.has(o.value.type) || o.issues.push({
      code: "invalid_value",
      values: r.mime,
      input: o.value.type,
      inst: e,
      continue: !r.abort
    });
  };
}), ss = /* @__PURE__ */ m("$ZodCheckOverwrite", (e, r) => {
  L.init(e, r), e._zod.check = (i) => {
    i.value = r.tx(i.value);
  };
});

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/doc.js
var at = class {
  static {
    s(this, "Doc");
  }
  constructor(r = [], i = {}) {
    this.content = [], this.indent = 0, this.args = r, this.closed = i;
  }
  indented(r) {
    this.indent += 1, r(this), this.indent -= 1;
  }
  write(r) {
    if (typeof r == "function") {
      r(this, { execution: "sync" }), r(this, { execution: "async" });
      return;
    }
    let o = r.split(`
`).filter((a) => a), t = Math.min(...o.map((a) => a.length - a.trimStart().length)), n = o.map((a) => a.slice(t)).map((a) => " ".repeat(this.indent * 2) + a);
    for (let a of n)
      this.content.push(a);
  }
  compile() {
    let r = Function, i = this?.content ?? [""];
    return new r(...Object.keys(this.closed), `return function (${this.args.join(", ")}) {
${i.join(`
`)}
};`)(...Object.values(this.closed));
  }
};

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/versions.js
var us = {
  major: 4,
  minor: 5,
  patch: 4
};

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/schemas.js
var S = /* @__PURE__ */ m("$ZodType", (e, r) => {
  var i;
  e ?? (e = {}), e._zod.def = r, e._zod.bag = e._zod.bag || {}, e._zod.version = us;
  let o = e._zod.def.checks, t = e._zod.traits.has("$ZodCheck") ? [e, ...o ?? []] : o?.length ? [...o] : [];
  for (let n of t)
    for (let a of n._zod.onattach)
      a(e);
  if (t.length === 0)
    (i = e._zod).deferred ?? (i.deferred = []), e._zod.deferred?.push(() => {
      e._zod.run = e._zod.parse;
    });
  else {
    let n = /* @__PURE__ */ s((u, c, l) => {
      if (u.memo)
        return u;
      let d = Ee(u), f;
      for (let p of c) {
        if (p._zod.def.when) {
          if (Qo(u) || !p._zod.def.when(u))
            continue;
        } else if (d)
          continue;
        let h = u.issues.length, v = p._zod.check(u);
        if (v instanceof Promise && l?.async === !1)
          throw new se();
        if (f || v instanceof Promise)
          f = (f ?? Promise.resolve()).then(async () => {
            await v, u.issues.length !== h && (Sn(u.issues, h, e), d || (d = Ee(u, h)));
          });
        else {
          if (u.issues.length === h)
            continue;
          Sn(u.issues, h, e), d || (d = Ee(u, h));
        }
      }
      return f ? f.then(() => u) : u;
    }, "runChecks"), a = /* @__PURE__ */ s((u, c, l) => {
      if (Ee(u))
        return u.aborted = !0, u;
      let d = n(c, t, l);
      if (d instanceof Promise) {
        if (l.async === !1)
          throw new se();
        return d.then((f) => e._zod.parse(f, l));
      }
      return e._zod.parse(d, l);
    }, "handleCanaryResult");
    e._zod.run = (u, c) => {
      if (c.skipChecks)
        return e._zod.parse(u, c);
      if (c.direction === "backward") {
        let d = e._zod.parse({ value: u.value, issues: [] }, { ...c, skipChecks: !0 });
        return d instanceof Promise ? d.then((f) => a(f, u, c)) : a(d, u, c);
      }
      let l = e._zod.parse(u, c);
      if (l instanceof Promise) {
        if (c.async === !1)
          throw new se();
        return l.then((d) => n(d, t, c));
      }
      return n(l, t, c);
    };
  }
}, {
  // Wrappers extend this by installing a richer factory over it; reading it eagerly would defeat the laziness.
  get "~standard"() {
    return ea(this, "~standard", Gn(this));
  },
  set "~standard"(e) {
    kt(this, "~standard", e);
  }
}), Xf = /* @__PURE__ */ s((e) => e.success ? { value: e.data } : { issues: e.error?.issues }, "toStandardResult");
function Gn(e) {
  return {
    validate: /* @__PURE__ */ s((r) => {
      try {
        return Xf(zr(e, r));
      } catch {
        return la(e, r).then(Xf);
      }
    }, "validate"),
    vendor: "zod",
    version: 1
  };
}
s(Gn, "standardProps");
var st = /* @__PURE__ */ m("$ZodString", (e, r) => {
  S.init(e, r), e._zod.pattern = [...e?._zod.bag?.patterns ?? []].pop() ?? Ea(e._zod.bag), e._zod.parse = (i, o) => {
    if (r.coerce)
      try {
        i.value = String(i.value);
      } catch {
      }
    return typeof i.value == "string" || i.issues.push({
      expected: "string",
      code: "invalid_type",
      input: i.value,
      inst: e
    }), i;
  };
}), R = /* @__PURE__ */ m("$ZodStringFormat", (e, r) => {
  Nt.init(e, r), st.init(e, r);
}), ls = /* @__PURE__ */ m("$ZodGUID", (e, r) => {
  r.pattern ?? (r.pattern = xa), R.init(e, r);
}), ds = /* @__PURE__ */ m("$ZodUUID", (e, r) => {
  if (r.version) {
    let o = {
      v1: 1,
      v2: 2,
      v3: 3,
      v4: 4,
      v5: 5,
      v6: 6,
      v7: 7,
      v8: 8
    }[r.version];
    if (o === void 0)
      throw new Error(`Invalid UUID version: "${r.version}"`);
    r.pattern ?? (r.pattern = ot(o));
  } else
    r.pattern ?? (r.pattern = ot());
  R.init(e, r);
}), fs = /* @__PURE__ */ m("$ZodEmail", (e, r) => {
  r.pattern ?? (r.pattern = wa), R.init(e, r);
}), ps = 1, ms = 2;
function Xn(e, r) {
  if (!r.normalize && r.protocol?.source === Da.source && !/^https?:\/\//i.test(e))
    return ps;
  try {
    return new URL(e);
  } catch {
    return ms;
  }
}
s(Xn, "parseURLObject");
var Hv = /[\t\n\r]/g;
function Hn(e) {
  return e.replace(Hv, "");
}
s(Hn, "stripTabAndNewline");
function Qn(e, r) {
  return r.lastIndex = 0, r.test(e.hostname);
}
s(Qn, "urlHostnameOk");
function Yn(e, r) {
  return r.lastIndex = 0, r.test(e.protocol.endsWith(":") ? e.protocol.slice(0, -1) : e.protocol);
}
s(Yn, "urlProtocolOk");
var gs = /* @__PURE__ */ m("$ZodURL", (e, r) => {
  R.init(e, r), e._zod.check = (i) => {
    try {
      let o = i.value.trim(), t = Xn(o, r);
      if (t === ps) {
        i.issues.push({
          code: "invalid_format",
          format: "url",
          note: "Invalid URL format",
          input: i.value,
          inst: e,
          continue: !r.abort
        });
        return;
      }
      if (t === ms) {
        i.issues.push({
          code: "invalid_format",
          format: "url",
          input: i.value,
          inst: e,
          continue: !r.abort
        });
        return;
      }
      r.hostname && !Qn(t, r.hostname) && i.issues.push({
        code: "invalid_format",
        format: "url",
        note: "Invalid hostname",
        pattern: r.hostname.source,
        input: i.value,
        inst: e,
        continue: !r.abort
      }), r.protocol && !Yn(t, r.protocol) && i.issues.push({
        code: "invalid_format",
        format: "url",
        note: "Invalid protocol",
        pattern: r.protocol.source,
        input: i.value,
        inst: e,
        continue: !r.abort
      }), i.value = r.normalize ? t.href : Hn(o);
      return;
    } catch {
      i.issues.push({
        code: "invalid_format",
        format: "url",
        input: i.value,
        inst: e,
        continue: !r.abort
      });
    }
  };
}), hs = /* @__PURE__ */ m("$ZodEmoji", (e, r) => {
  r.pattern ?? (r.pattern = ka()), R.init(e, r);
}), vs = /* @__PURE__ */ m("$ZodNanoID", (e, r) => {
  if (r.length !== void 0 && (!Number.isInteger(r.length) || r.length < 1))
    throw new Error(`Invalid nanoid length: ${r.length}`);
  r.pattern ?? (r.pattern = r.length === void 0 ? $a : ba(r.length)), R.init(e, r);
}), ys = /* @__PURE__ */ m("$ZodCUID", (e, r) => {
  r.pattern ?? (r.pattern = ma), R.init(e, r);
}), $s = /* @__PURE__ */ m("$ZodCUID2", (e, r) => {
  r.pattern ?? (r.pattern = ga), R.init(e, r);
}), bs = /* @__PURE__ */ m("$ZodULID", (e, r) => {
  r.pattern ?? (r.pattern = ha), R.init(e, r);
}), _s = /* @__PURE__ */ m("$ZodXID", (e, r) => {
  r.pattern ?? (r.pattern = va), R.init(e, r);
}), xs = /* @__PURE__ */ m("$ZodKSUID", (e, r) => {
  r.pattern ?? (r.pattern = ya), R.init(e, r);
}), ws = /* @__PURE__ */ m("$ZodISODateTime", (e, r) => {
  r.pattern ?? (r.pattern = Ua(r)), R.init(e, r), (r.local || r.precision === -1) && (e._zod.bag.laxFormat = !0, e._zod.onattach.push((i) => {
    i._zod.bag.laxFormat = !0;
  }));
}), ks = /* @__PURE__ */ m("$ZodISODate", (e, r) => {
  r.pattern ?? (r.pattern = Ta), R.init(e, r);
}), Is = /* @__PURE__ */ m("$ZodISOTime", (e, r) => {
  r.pattern ?? (r.pattern = Aa(r)), R.init(e, r);
}), zs = /* @__PURE__ */ m("$ZodISODuration", (e, r) => {
  r.pattern ?? (r.pattern = _a), R.init(e, r);
}), Ss = /* @__PURE__ */ m("$ZodIPv4", (e, r) => {
  r.pattern ?? (r.pattern = Ia), R.init(e, r), e._zod.bag.format = "ipv4";
}), Qv = /^[0-9a-fA-F:.]+$/;
function Pr(e) {
  if (!Qv.test(e))
    return !1;
  try {
    return new URL(`http://[${e}]`), !0;
  } catch {
    return !1;
  }
}
s(Pr, "isValidIPv6");
var Os = /* @__PURE__ */ m("$ZodIPv6", (e, r) => {
  r.pattern ?? (r.pattern = za), R.init(e, r), e._zod.bag.format = "ipv6", e._zod.check = (i) => {
    Pr(i.value) || i.issues.push({
      code: "invalid_format",
      format: "ipv6",
      input: i.value,
      inst: e,
      continue: !r.abort
    });
  };
}), js = /* @__PURE__ */ m("$ZodMAC", (e, r) => {
  r.pattern ?? (r.pattern = Sa(r.delimiter)), R.init(e, r), e._zod.bag.format = "mac";
}), Ps = /* @__PURE__ */ m("$ZodCIDRv4", (e, r) => {
  r.pattern ?? (r.pattern = Oa), R.init(e, r);
});
function ei(e) {
  let r = e.split("/");
  if (r.length !== 2)
    return !1;
  let [i, o] = r;
  if (!o)
    return !1;
  let t = Number(o);
  return `${t}` !== o || t < 0 || t > 128 ? !1 : Pr(i);
}
s(ei, "isValidCIDRv6");
var Ds = /* @__PURE__ */ m("$ZodCIDRv6", (e, r) => {
  r.pattern ?? (r.pattern = ja), R.init(e, r), e._zod.check = (i) => {
    ei(i.value) || i.issues.push({
      code: "invalid_format",
      format: "cidrv6",
      input: i.value,
      inst: e,
      continue: !r.abort
    });
  };
});
function Dr(e) {
  if (e === "")
    return !0;
  if (/\s/.test(e) || e.length % 4 !== 0)
    return !1;
  try {
    return atob(e), !0;
  } catch {
    return !1;
  }
}
s(Dr, "isValidBase64");
var Ns = /* @__PURE__ */ m("$ZodBase64", (e, r) => {
  r.pattern ?? (r.pattern = Pa), R.init(e, r), e._zod.bag.contentEncoding = "base64", e._zod.check = (i) => {
    Dr(i.value) || i.issues.push({
      code: "invalid_format",
      format: "base64",
      input: i.value,
      inst: e,
      continue: !r.abort
    });
  };
});
function ti(e) {
  if (!Rn.test(e))
    return !1;
  let r = e.replace(/[-_]/g, (o) => o === "-" ? "+" : "/"), i = r.padEnd(Math.ceil(r.length / 4) * 4, "=");
  return Dr(i);
}
s(ti, "isValidBase64URL");
var Ts = /* @__PURE__ */ m("$ZodBase64URL", (e, r) => {
  r.pattern ?? (r.pattern = Rn), R.init(e, r), e._zod.bag.contentEncoding = "base64url", e._zod.check = (i) => {
    ti(i.value) || i.issues.push({
      code: "invalid_format",
      format: "base64url",
      input: i.value,
      inst: e,
      continue: !r.abort
    });
  };
}), As = /* @__PURE__ */ m("$ZodE164", (e, r) => {
  r.pattern ?? (r.pattern = Na), R.init(e, r);
}), Yv = /[- ]/g;
function ey(e) {
  let r = e.length, i = 1, o = 0;
  for (; r; ) {
    let t = +e[--r];
    i ^= 1, o += i ? [0, 2, 4, 6, 8, 1, 3, 5, 7, 9][t] : t;
  }
  return o % 10 === 0;
}
s(ey, "isLuhnAlgo");
function ri(e) {
  return Fn.test(e) ? ey(e.replace(Yv, "")) : !1;
}
s(ri, "isValidCreditCard");
var Us = /* @__PURE__ */ m("$ZodCreditCard", (e, r) => {
  r.pattern ?? (r.pattern = Fn), R.init(e, r), e._zod.check = (i) => {
    ri(i.value) || i.issues.push({
      code: "invalid_format",
      format: "credit_card",
      input: i.value,
      inst: e,
      continue: !r.abort
    });
  };
});
function ni(e, r = null) {
  try {
    let i = e.split(".");
    if (i.length !== 3)
      return !1;
    let [o] = i;
    if (!o)
      return !1;
    let t = JSON.parse(atob(o));
    return !("typ" in t && t?.typ !== "JWT" || !t.alg || r && (!("alg" in t) || t.alg !== r));
  } catch {
    return !1;
  }
}
s(ni, "isValidJWT");
var Es = /* @__PURE__ */ m("$ZodJWT", (e, r) => {
  R.init(e, r), e._zod.check = (i) => {
    ni(i.value, r.alg) || i.issues.push({
      code: "invalid_format",
      format: "jwt",
      input: i.value,
      inst: e,
      continue: !r.abort
    });
  };
}), Cs = /* @__PURE__ */ m("$ZodCustomStringFormat", (e, r) => {
  R.init(e, r), e._zod.check = (i) => {
    r.fn(i.value) || i.issues.push({
      code: "invalid_format",
      format: r.format,
      input: i.value,
      inst: e,
      continue: !r.abort
    });
  };
}), ii = /* @__PURE__ */ m("$ZodNumber", (e, r) => {
  S.init(e, r), e._zod.pattern = e._zod.bag.pattern ?? Ze, e._zod.parse = (i, o) => {
    if (r.coerce)
      try {
        i.value = Number(i.value);
      } catch {
      }
    let t = i.value;
    if (typeof t == "number" && !Number.isNaN(t) && Number.isFinite(t))
      return i;
    let n = typeof t == "number" ? Number.isNaN(t) ? "NaN" : Number.isFinite(t) ? void 0 : String(t) : void 0;
    return i.issues.push({
      expected: "number",
      code: "invalid_type",
      input: t,
      inst: e,
      ...n ? { received: n } : {}
    }), i;
  };
}), Zs = /* @__PURE__ */ m("$ZodNumberFormat", (e, r) => {
  qa.init(e, r), ii.init(e, r);
}), Nr = /* @__PURE__ */ m("$ZodBoolean", (e, r) => {
  S.init(e, r), e._zod.pattern = Za, e._zod.parse = (i, o) => {
    if (r.coerce)
      try {
        i.value = !!i.value;
      } catch {
      }
    let t = i.value;
    return typeof t == "boolean" || i.issues.push({
      expected: "boolean",
      code: "invalid_type",
      input: t,
      inst: e
    }), i;
  };
}), oi = /* @__PURE__ */ m("$ZodBigInt", (e, r) => {
  S.init(e, r), e._zod.pattern = Ca, e._zod.parse = (i, o) => {
    if (r.coerce)
      try {
        i.value = BigInt(i.value);
      } catch {
      }
    return typeof i.value == "bigint" || i.issues.push({
      expected: "bigint",
      code: "invalid_type",
      input: i.value,
      inst: e
    }), i;
  };
}), Rs = /* @__PURE__ */ m("$ZodBigIntFormat", (e, r) => {
  Ka.init(e, r), oi.init(e, r);
}), Fs = /* @__PURE__ */ m("$ZodSymbol", (e, r) => {
  S.init(e, r), e._zod.parse = (i, o) => {
    let t = i.value;
    return typeof t == "symbol" || i.issues.push({
      expected: "symbol",
      code: "invalid_type",
      input: t,
      inst: e
    }), i;
  };
}), Ls = /* @__PURE__ */ m("$ZodUndefined", (e, r) => {
  S.init(e, r), e._zod.pattern = Fa, e._zod.values = /* @__PURE__ */ new Set([void 0]), e._zod.parse = (i, o) => {
    let t = i.value;
    return typeof t > "u" || i.issues.push({
      expected: "undefined",
      code: "invalid_type",
      input: t,
      inst: e
    }), i;
  };
}), Vs = /* @__PURE__ */ m("$ZodNull", (e, r) => {
  S.init(e, r), e._zod.pattern = Ra, e._zod.values = /* @__PURE__ */ new Set([null]), e._zod.parse = (i, o) => {
    let t = i.value;
    return t === null || i.issues.push({
      expected: "null",
      code: "invalid_type",
      input: t,
      inst: e
    }), i;
  };
}), Ms = /* @__PURE__ */ m("$ZodAny", (e, r) => {
  S.init(e, r), e._zod.parse = (i) => i;
}), Bs = /* @__PURE__ */ m("$ZodUnknown", (e, r) => {
  S.init(e, r), e._zod.parse = (i) => i;
}), Js = /* @__PURE__ */ m("$ZodNever", (e, r) => {
  S.init(e, r), e._zod.parse = (i, o) => (i.issues.push({
    expected: "never",
    code: "invalid_type",
    input: i.value,
    inst: e
  }), i);
}), qs = /* @__PURE__ */ m("$ZodVoid", (e, r) => {
  S.init(e, r), e._zod.parse = (i, o) => {
    let t = i.value;
    return typeof t > "u" || i.issues.push({
      expected: "void",
      code: "invalid_type",
      input: t,
      inst: e
    }), i;
  };
}), Tr = /* @__PURE__ */ m("$ZodDate", (e, r) => {
  S.init(e, r), e._zod.parse = (i, o) => {
    if (r.coerce)
      try {
        i.value = new Date(i.value);
      } catch {
      }
    let t = i.value, n = t instanceof Date;
    return n && !Number.isNaN(t.getTime()) || i.issues.push({
      expected: "date",
      code: "invalid_type",
      input: t,
      ...n ? { received: "Invalid Date" } : {},
      inst: e
    }), i;
  };
});
function Hf(e, r, i) {
  e.issues.length && r.issues.push(...oe(i, e.issues)), r.value[i] = e.value;
}
s(Hf, "handleArrayResult");
var At = /* @__PURE__ */ m("$ZodArray", (e, r) => {
  S.init(e, r);
  let i = X.memoizer;
  i?.attach(e), e._zod.parse = (o, t) => {
    let n = o.value;
    if (!Array.isArray(n))
      return o.issues.push({
        expected: "array",
        code: "invalid_type",
        input: n,
        inst: e
      }), o;
    o.value = i ? i.alloc(e, o, Array(n.length), t) : Array(n.length);
    let a = [];
    for (let u = 0; u < n.length; u++) {
      let c = n[u], l = r.element._zod.run({
        value: c,
        issues: []
      }, t);
      l instanceof Promise ? a.push(l.then((d) => Hf(d, o, u))) : Hf(l, o, u);
    }
    return a.length ? Promise.all(a).then(() => o) : o;
  };
});
function Wn(e, r, i, o, t, n) {
  let a = i in o, u = n === "optional";
  if (!(!a && u && t === "optional")) {
    if (e.issues.length) {
      if (t !== void 0 && u && !a)
        return;
      r.issues.push(...oe(i, e.issues));
    }
    if (!a && t === void 0) {
      e.issues.length || r.issues.push({
        code: "invalid_type",
        expected: "nonoptional",
        input: void 0,
        path: [i]
      });
      return;
    }
    e.value === void 0 ? a && (r.value[i] = void 0) : r.value[i] = e.value;
  }
}
s(Wn, "handlePropertyResult");
var ty = [];
function fp(e) {
  let r = Object.keys(e.shape), i = Object.getOwnPropertySymbols(e.shape), o = i.length ? i : ty, t = o.length ? [...r, ...o] : r;
  for (let a of t)
    if (!e.shape?.[a]?._zod?.traits?.has("$ZodType"))
      throw new Error(`Invalid element at key "${String(a)}": expected a Zod schema`);
  let n = Go(e.shape);
  return {
    ...e,
    allKeys: t,
    symbolKeys: o,
    // string-only: handleCatchall matches it against `for...in`, which never yields a symbol
    keySet: new Set(r),
    numKeys: r.length,
    optionalKeys: new Set(n)
  };
}
s(fp, "normalizeDef");
function pp(e, r, i, o, t, n) {
  let a = [], u = t.keySet, c = t.catchall._zod, l = c.def.type, d = c.optin, f = c.optout;
  for (let p in r) {
    if (u.has(p))
      continue;
    if (p === "__proto__") {
      l === "never" && a.push(p);
      continue;
    }
    if (l === "never") {
      a.push(p);
      continue;
    }
    let h = c.run({ value: r[p], issues: [] }, o);
    h instanceof Promise ? e.push(h.then((v) => Wn(v, i, p, r, d, f))) : Wn(h, i, p, r, d, f);
  }
  return a.length && i.issues.push({
    code: "unrecognized_keys",
    keys: a,
    input: r,
    inst: n,
    // Describes the shape of the input, not the validity of the parsed value, so it never aborts. The parse still fails; the schema's own checks just get to run first, and an enclosing intersection can reconcile the key against a sibling operand.
    continue: !0
  }), e.length ? Promise.all(e).then(() => i) : i;
}
s(pp, "handleCatchall");
var cs = /* @__PURE__ */ new WeakMap(), Q = /* @__PURE__ */ m("$ZodObject", (e, r) => {
  if (S.init(e, r), !Object.getOwnPropertyDescriptor(r, "shape")?.get) {
    let c = r.shape;
    cs.set(r, c), Object.defineProperty(r, "shape", {
      get: /* @__PURE__ */ s(() => {
        let l = { ...c };
        return Object.defineProperty(r, "shape", {
          value: l
        }), cs.set(r, l), l;
      }, "get")
    });
  }
  let o = zt(() => fp(r));
  T(e, "propValues", (c) => {
    let l = c.def.shape, d = {};
    for (let f in l) {
      let p = l[f]._zod;
      if (p.values) {
        Object.prototype.hasOwnProperty.call(d, f) || q(d, f, /* @__PURE__ */ new Set());
        for (let h of p.values)
          d[f].add(h);
        p.optin !== void 0 && d[f].add(void 0);
      }
    }
    return d;
  });
  let t = tt, n = r.catchall, a, u = X.memoizer;
  u?.attach(e), e._zod.parse = (c, l) => {
    a ?? (a = o.value);
    let d = c.value;
    if (!t(d))
      return c.issues.push({
        expected: "object",
        code: "invalid_type",
        input: d,
        inst: e
      }), c;
    c.value = u ? u.alloc(e, c, {}, l) : {};
    let f = [], p = a.shape;
    for (let h of a.allKeys) {
      if (h === "__proto__")
        continue;
      let v = p[h], k = v._zod.optin, z = v._zod.optout, Z = v._zod.run({ value: d[h], issues: [] }, l);
      Z instanceof Promise ? f.push(Z.then((O) => Wn(O, c, h, d, k, z))) : Wn(Z, c, h, d, k, z);
    }
    return n ? pp(f, d, c, l, o.value, e) : f.length ? Promise.all(f).then(() => c) : c;
  };
}), Ks = /* @__PURE__ */ m("$ZodObjectJIT", (e, r) => {
  Q.init(e, r);
  let i = e._zod.parse, o = zt(() => fp(r)), t = X.memoizer, n = /* @__PURE__ */ s((h) => {
    let v = o.value, k = v.symbolKeys, z = new at(["payload", "ctx"], { shape: h, inst: e, memo: t, syms: k }), Z = /* @__PURE__ */ s((M) => `shape[${M}]._zod.run({ value: input[${M}], issues: [] }, ctx)`, "parseStr"), O = /* @__PURE__ */ s((M, E) => `
          for (let i = 0; i < ${M}.issues.length; i++) {
            const iss = ${M}.issues[i];
            iss.path = iss.path ? [${E}, ...iss.path] : [${E}];
            payload.issues.push(iss);
          }`, "prefixStr");
    z.write("const input = payload.value;");
    let D = /* @__PURE__ */ Object.create(null), V = 0;
    for (let M of v.allKeys)
      D[M] = `key_${V++}`;
    z.write(t ? "const newResult = memo.alloc(inst, payload, {}, ctx);" : "const newResult = {};");
    for (let M of v.allKeys) {
      if (M === "__proto__")
        continue;
      let E = D[M], Y = typeof M == "symbol" ? `syms[${k.indexOf(M)}]` : ie(M), dr = `${Y} in input`, kf = h[M], If = kf?._zod?.optin, zf = If !== void 0, sh = kf?._zod?.optout === "optional";
      if (z.write(`const ${E} = ${Z(Y)};`), zf && sh) {
        let uh = If === "optional" ? `${E}_present` : `${E}.value !== undefined || ${E}_present`;
        z.write(`
        const ${E}_present = ${dr};
        if (!${E}.issues.length || ${E}_present) {
          if (${E}.issues.length) {${O(E, Y)}
          }

          if (${uh}) {
            newResult[${Y}] = ${E}.value;
          }
        }

      `);
      } else zf ? z.write(`
        if (${E}.issues.length) {${O(E, Y)}
        }
        
        if (${E}.value === undefined) {
          if (${dr}) {
            newResult[${Y}] = undefined;
          }
        } else {
          newResult[${Y}] = ${E}.value;
        }

      `) : z.write(`
        const ${E}_present = ${dr};
        if (${E}.issues.length) {${O(E, Y)}
        }
        if (!${E}_present && !${E}.issues.length) {
          payload.issues.push({
            code: "invalid_type",
            expected: "nonoptional",
            input: undefined,
            path: [${Y}]
          });
        }

        if (${E}_present) {
          newResult[${Y}] = ${E}.value;
        }

      `);
    }
    return z.write("payload.value = newResult;"), z.write("return payload;"), z.compile();
  }, "generateFastpass"), a, u = tt, c = !X.jitless, d = c && Ko.value, f = r.catchall, p;
  e._zod.parse = (h, v) => {
    p ?? (p = o.value);
    let k = h.value;
    return u(k) ? c && d && v?.async === !1 && v.jitless !== !0 ? (a || (a = n(r.shape)), h = a(h, v), f ? pp([], k, h, v, p, e) : h) : i(h, v) : (h.issues.push({
      expected: "object",
      code: "invalid_type",
      input: k,
      inst: e
    }), h);
  };
});
function Qf(e, r, i, o) {
  for (let n of e)
    if (n.issues.length === 0)
      return r.value = n.value, r;
  let t = e.filter((n) => !Ee(n));
  return t.length === 1 ? (r.value = t[0].value, t[0]) : (r.issues.push({
    code: "invalid_union",
    input: r.value,
    inst: i,
    errors: e.map((n) => n.issues.map((a) => ae(a, o, K())))
  }), r);
}
s(Qf, "handleUnionResults");
var fe = /* @__PURE__ */ m("$ZodUnion", (e, r) => {
  S.init(e, r), T(e, "optin", (o) => o.def.options.some((t) => t._zod.optin === "defaulted") ? "defaulted" : o.def.options.some((t) => t._zod.optin !== void 0) ? "optional" : void 0), T(e, "optout", (o) => o.def.options.some((t) => t._zod.optout === "optional") ? "optional" : void 0), T(e, "values", (o) => {
    if (o.def.options.every((t) => t._zod.values))
      return new Set(o.def.options.flatMap((t) => Array.from(t._zod.values)));
  }), T(e, "pattern", (o) => {
    if (o.def.options.every((t) => t._zod.pattern)) {
      let t = o.def.options.map((n) => n._zod.pattern);
      return new RegExp(`^(${t.map((n) => yr(n.source)).join("|")})$`);
    }
  });
  let i = r.options.length === 1 ? r.options[0]._zod.run : null;
  e._zod.parse = (o, t) => {
    if (i)
      return i(o, t);
    let n = !1, a = [];
    for (let u of r.options) {
      let c = u._zod.run({
        value: o.value,
        issues: []
      }, t);
      if (c instanceof Promise)
        a.push(c), n = !0;
      else {
        if (c.issues.length === 0)
          return c;
        a.push(c);
      }
    }
    return n ? Promise.all(a).then((u) => Qf(u, o, e, t)) : Qf(a, o, e, t);
  };
});
function Yf(e, r, i, o) {
  let t = [];
  for (let n = 0; n < e.length; n++)
    e[n].issues.length === 0 && t.push(n);
  return t.length === 1 ? (r.value = e[t[0]].value, r) : (t.length === 0 ? r.issues.push({
    code: "invalid_union",
    input: r.value,
    inst: i,
    errors: e.map((n) => n.issues.map((a) => ae(a, o, K())))
  }) : r.issues.push({
    code: "invalid_union",
    input: r.value,
    inst: i,
    errors: [],
    inclusive: !1,
    matches: t
  }), r);
}
s(Yf, "handleExclusiveUnionResults");
var Ws = /* @__PURE__ */ m("$ZodXor", (e, r) => {
  fe.init(e, r), r.inclusive = !1;
  let i = r.options.length === 1 ? r.options[0]._zod.run : null;
  e._zod.parse = (o, t) => {
    if (i)
      return i(o, t);
    let n = !1, a = [];
    for (let u of r.options) {
      let c = u._zod.run({
        value: o.value,
        issues: []
      }, t);
      c instanceof Promise ? (a.push(c), n = !0) : a.push(c);
    }
    return n ? Promise.all(a).then((u) => Yf(u, o, e, t)) : Yf(a, o, e, t);
  };
});
function Gs(e, r) {
  let i = e._zod, o = i.bag.optionsMap;
  if (!o) {
    o = /* @__PURE__ */ new Map();
    let { options: t, discriminator: n } = i.def;
    for (let a of t)
      for (let u of a._zod.propValues?.[n] ?? [])
        o.has(u) || o.set(u, a);
    i.bag.optionsMap = o;
  }
  return o.get(r);
}
s(Gs, "getDiscriminatedOption");
var Re = /* @__PURE__ */ m("$ZodDiscriminatedUnion", (e, r) => {
  r.inclusive = !1, fe.init(e, r);
  let i = e._zod.parse;
  T(e, "propValues", (t) => {
    let n = {};
    for (let a of t.def.options) {
      let u = a._zod.propValues;
      if (!u || Object.keys(u).length === 0)
        throw new Error(`Invalid discriminated union option at index "${t.def.options.indexOf(a)}"`);
      for (let [c, l] of Object.entries(u)) {
        Object.prototype.hasOwnProperty.call(n, c) || q(n, c, /* @__PURE__ */ new Set());
        for (let d of l)
          n[c].add(d);
      }
    }
    return n;
  }), r.options.forEach((t, n) => {
    let a = cs.get(t._zod.def);
    if (a && !Object.prototype.hasOwnProperty.call(a, r.discriminator))
      throw new Error(`Invalid discriminated union option at index "${n}"`);
  });
  let o = zt(() => {
    let t = r.options, n = /* @__PURE__ */ new Map();
    for (let a of t) {
      let u = a._zod.propValues?.[r.discriminator];
      if (!u || u.size === 0)
        throw new Error(`Invalid discriminated union option at index "${r.options.indexOf(a)}"`);
      for (let c of u) {
        if (n.has(c))
          throw new Error(`Duplicate discriminator value "${String(c)}"`);
        n.set(c, a);
      }
    }
    return n;
  });
  e._zod.parse = (t, n) => {
    let a = t.value;
    if (!tt(a))
      return t.issues.push({
        code: "invalid_type",
        expected: "object",
        input: a,
        inst: e
      }), t;
    let u = o.value.get(a?.[r.discriminator]);
    return u ? u._zod.run(t, n) : r.unionFallback || n.direction === "backward" ? i(t, n) : (t.issues.push({
      code: "invalid_union",
      errors: [],
      note: "No matching discriminator",
      discriminator: r.discriminator,
      options: Array.from(o.value.keys()),
      input: a,
      path: [r.discriminator],
      inst: e
    }), t);
  };
}), Xs = /* @__PURE__ */ m("$ZodIntersection", (e, r) => {
  S.init(e, r), e._zod.parse = (i, o) => {
    let t = i.value, n = r.left._zod.run({ value: t, issues: [] }, o), a = r.right._zod.run({ value: t, issues: [] }, o);
    return n instanceof Promise || a instanceof Promise ? Promise.all([n, a]).then(([c, l]) => ep(i, c, l)) : ep(i, n, a);
  };
});
function Tt(e, r) {
  if (e === r)
    return { valid: !0, data: e };
  if (e instanceof Date && r instanceof Date && +e == +r)
    return { valid: !0, data: e };
  if (ve(e) && ve(r)) {
    let i = Object.keys(r), o = Object.keys(e).filter((n) => i.indexOf(n) !== -1), t = { ...e, ...r };
    Object.prototype.hasOwnProperty.call(t, "__proto__") && delete t.__proto__;
    for (let n of o) {
      if (n === "__proto__")
        continue;
      let a = Tt(e[n], r[n]);
      if (!a.valid)
        return {
          valid: !1,
          mergeErrorPath: [n, ...a.mergeErrorPath]
        };
      t[n] = a.data;
    }
    return { valid: !0, data: t };
  }
  if (Array.isArray(e) && Array.isArray(r)) {
    if (e.length !== r.length)
      return { valid: !1, mergeErrorPath: [] };
    let i = [];
    for (let o = 0; o < e.length; o++) {
      let t = e[o], n = r[o], a = Tt(t, n);
      if (!a.valid)
        return {
          valid: !1,
          mergeErrorPath: [o, ...a.mergeErrorPath]
        };
      i.push(a.data);
    }
    return { valid: !0, data: i };
  }
  return { valid: !1, mergeErrorPath: [] };
}
s(Tt, "mergeValues");
function ep(e, r, i) {
  let o = /* @__PURE__ */ new Map(), t, n = /* @__PURE__ */ new Map(), a = /* @__PURE__ */ s((l, d) => {
    let f;
    if (l.code === "unrecognized_keys" && !l.path?.length)
      t ?? (t = l), f = l.keys;
    else if (l.code === "invalid_key" && l.origin === "record" && l.path?.length === 1) {
      let p = String(l.path[0]);
      n.has(p) || n.set(p, l), f = [p];
    } else
      return !1;
    for (let p of f)
      o.has(p) || o.set(p, {}), o.get(p)[d] = !0;
    return !0;
  }, "collect");
  for (let l of r.issues)
    a(l, "l") || e.issues.push(l);
  for (let l of i.issues)
    a(l, "r") || e.issues.push(l);
  let u = [...o].filter(([, l]) => l.l && l.r).map(([l]) => l);
  if (u.length) {
    let l = t ? u.filter((d) => t.keys.includes(d)) : [];
    l.length && e.issues.push({ ...t, keys: l });
    for (let d of u)
      !l.includes(d) && n.has(d) && e.issues.push(n.get(d));
  }
  let c = Tt(r.value, i.value);
  if (!c.valid) {
    if (Ee(e))
      return e;
    throw new Error(`Unmergable intersection. Error path: ${JSON.stringify(c.mergeErrorPath)}`);
  }
  return e.value = c.data, e;
}
s(ep, "handleIntersectionResults");
var ut = /* @__PURE__ */ m("$ZodTuple", (e, r) => {
  S.init(e, r);
  let i = r.items, o = X.memoizer;
  o?.attach(e), e._zod.parse = (t, n) => {
    let a = t.value;
    if (!Array.isArray(a))
      return t.issues.push({
        input: a,
        inst: e,
        expected: "tuple",
        code: "invalid_type"
      }), t;
    t.value = o ? o.alloc(e, t, [], n) : [];
    let u = [], c = tp(i, "optin"), l = tp(i, "optout");
    if (!r.rest) {
      if (a.length < c)
        return t.issues.push({
          code: "too_small",
          minimum: c,
          inclusive: !0,
          input: a,
          inst: e,
          origin: "array"
        }), t;
      a.length > i.length && t.issues.push({
        code: "too_big",
        maximum: i.length,
        inclusive: !0,
        input: a,
        inst: e,
        origin: "array"
      });
    }
    let d = new Array(i.length);
    for (let f = 0; f < i.length; f++) {
      let p = i[f]._zod.run({ value: a[f], issues: [] }, n);
      p instanceof Promise ? u.push(p.then((h) => {
        d[f] = h;
      })) : d[f] = p;
    }
    if (r.rest) {
      let f = i.length - 1, p = a.slice(i.length);
      for (let h of p) {
        f++;
        let v = r.rest._zod.run({ value: h, issues: [] }, n);
        v instanceof Promise ? u.push(v.then((k) => rp(k, t, f))) : rp(v, t, f);
      }
    }
    return u.length ? Promise.all(u).then(() => np(d, t, i, a, l)) : np(d, t, i, a, l);
  };
});
function tp(e, r) {
  for (let i = e.length - 1; i >= 0; i--)
    if (!(r === "optin" ? e[i]._zod.optin !== void 0 : e[i]._zod.optout === "optional"))
      return i + 1;
  return 0;
}
s(tp, "getTupleOptStart");
function rp(e, r, i) {
  e.issues.length && r.issues.push(...oe(i, e.issues)), r.value[i] = e.value;
}
s(rp, "handleTupleResult");
function np(e, r, i, o, t) {
  for (let n = 0; n < i.length; n++) {
    let a = e[n], u = n < o.length;
    if (!u && n >= t && i[n]._zod.optin === "optional") {
      r.value.length = n;
      break;
    }
    if (a.issues.length) {
      if (!u && n >= t) {
        r.value.length = n;
        break;
      }
      r.issues.push(...oe(n, a.issues));
    }
    r.value[n] = a.value;
  }
  for (let n = r.value.length - 1; n >= o.length && (i[n]._zod.optout === "optional" && r.value[n] === void 0); n--)
    r.value.length = n;
  return r;
}
s(np, "handleTupleResults");
var Ut = /* @__PURE__ */ m("$ZodRecord", (e, r) => {
  S.init(e, r);
  let i = X.memoizer;
  i?.attach(e), e._zod.parse = (o, t) => {
    let n = o.value;
    if (!ve(n))
      return o.issues.push({
        expected: "record",
        code: "invalid_type",
        input: n,
        inst: e
      }), o;
    let a = [], u = r.keyType._zod.values;
    if (u && !r.partial) {
      o.value = i ? i.alloc(e, o, {}, t) : {};
      let c = /* @__PURE__ */ new Set();
      for (let d of u)
        if (typeof d == "string" || typeof d == "number" || typeof d == "symbol") {
          if (c.add(typeof d == "number" ? d.toString() : d), d === "__proto__")
            continue;
          let f = r.keyType._zod.run({ value: d, issues: [] }, t);
          if (f instanceof Promise)
            throw new Error("Async schemas not supported in object keys currently");
          if (f.issues.length) {
            o.issues.push({
              code: "invalid_key",
              origin: "record",
              issues: f.issues.map((v) => ae(v, t, K())),
              input: d,
              path: [d],
              inst: e
            });
            continue;
          }
          let p = f.value;
          if (p === "__proto__")
            continue;
          let h = r.valueType._zod.run({ value: n[d], issues: [] }, t);
          h instanceof Promise ? a.push(h.then((v) => {
            v.issues.length && o.issues.push(...oe(d, v.issues)), o.value[p] = v.value;
          })) : (h.issues.length && o.issues.push(...oe(d, h.issues)), o.value[p] = h.value);
        }
      let l;
      for (let d in n)
        if (!c.has(d))
          if (r.mode === "loose") {
            if (d === "__proto__")
              continue;
            o.value[d] = n[d];
          } else
            l = l ?? [], l.push(d);
      l && l.length > 0 && o.issues.push({
        code: "unrecognized_keys",
        input: n,
        inst: e,
        keys: l,
        continue: !0
      });
    } else {
      o.value = i ? i.alloc(e, o, {}, t) : {};
      let c;
      for (let l of Reflect.ownKeys(n)) {
        if (l === "__proto__" || !Object.prototype.propertyIsEnumerable.call(n, l))
          continue;
        let d = r.keyType._zod.run({ value: l, issues: [] }, t);
        if (d instanceof Promise)
          throw new Error("Async schemas not supported in object keys currently");
        if (typeof l == "string" && Ze.test(l) && d.issues.length) {
          let v = r.keyType._zod.run({ value: Number(l), issues: [] }, t);
          if (v instanceof Promise)
            throw new Error("Async schemas not supported in object keys currently");
          v.issues.length === 0 && (d = v);
        }
        if (d.issues.length) {
          r.mode === "loose" ? o.value[l] = n[l] : u ? (c = c ?? [], c.push(l)) : o.issues.push({
            code: "invalid_key",
            origin: "record",
            issues: d.issues.map((v) => ae(v, t, K())),
            input: l,
            path: [l],
            inst: e
          });
          continue;
        }
        let p = d.value;
        if (p === "__proto__")
          continue;
        let h = r.valueType._zod.run({ value: n[l], issues: [] }, t);
        h instanceof Promise ? a.push(h.then((v) => {
          v.issues.length && o.issues.push(...oe(l, v.issues)), o.value[p] = v.value;
        })) : (h.issues.length && o.issues.push(...oe(l, h.issues)), o.value[p] = h.value);
      }
      c && c.length > 0 && o.issues.push({
        code: "unrecognized_keys",
        input: n,
        inst: e,
        keys: c,
        continue: !0
      });
    }
    return a.length ? Promise.all(a).then(() => o) : o;
  };
}), Hs = /* @__PURE__ */ m("$ZodMap", (e, r) => {
  S.init(e, r);
  let i = X.memoizer;
  i?.attach(e), e._zod.parse = (o, t) => {
    let n = o.value;
    if (!(n instanceof Map))
      return o.issues.push({
        expected: "map",
        code: "invalid_type",
        input: n,
        inst: e
      }), o;
    let a = [];
    o.value = i ? i.alloc(e, o, /* @__PURE__ */ new Map(), t) : /* @__PURE__ */ new Map();
    for (let [u, c] of n) {
      let l = r.keyType._zod.run({ value: u, issues: [] }, t), d = r.valueType._zod.run({ value: c, issues: [] }, t);
      l instanceof Promise || d instanceof Promise ? a.push(Promise.all([l, d]).then(([f, p]) => {
        ip(f, p, o, u, n, e, t);
      })) : ip(l, d, o, u, n, e, t);
    }
    return a.length ? Promise.all(a).then(() => o) : o;
  };
});
function ip(e, r, i, o, t, n, a) {
  e.issues.length && (_r.has(typeof o) ? i.issues.push(...oe(o, e.issues)) : i.issues.push({
    code: "invalid_key",
    origin: "map",
    input: t,
    inst: n,
    issues: e.issues.map((u) => ae(u, a, K()))
  })), r.issues.length && (_r.has(typeof o) ? i.issues.push(...oe(o, r.issues)) : i.issues.push({
    origin: "map",
    code: "invalid_element",
    input: t,
    inst: n,
    key: o,
    issues: r.issues.map((u) => ae(u, a, K()))
  })), i.value.set(e.value, r.value);
}
s(ip, "handleMapResult");
var Qs = /* @__PURE__ */ m("$ZodSet", (e, r) => {
  S.init(e, r);
  let i = X.memoizer;
  i?.attach(e), e._zod.parse = (o, t) => {
    let n = o.value;
    if (!(n instanceof Set))
      return o.issues.push({
        input: n,
        inst: e,
        expected: "set",
        code: "invalid_type"
      }), o;
    let a = [];
    o.value = i ? i.alloc(e, o, /* @__PURE__ */ new Set(), t) : /* @__PURE__ */ new Set();
    for (let u of n) {
      let c = r.valueType._zod.run({ value: u, issues: [] }, t);
      c instanceof Promise ? a.push(c.then((l) => op(l, o))) : op(c, o);
    }
    return a.length ? Promise.all(a).then(() => o) : o;
  };
});
function op(e, r) {
  e.issues.length && r.issues.push(...e.issues), r.value.add(e.value);
}
s(op, "handleSetResult");
var Et = /* @__PURE__ */ m("$ZodEnum", (e, r) => {
  S.init(e, r);
  let i = vr(r.entries), o = new Set(i);
  e._zod.values = o;
  let t = i.filter((n) => _r.has(typeof n));
  e._zod.pattern = new RegExp(t.length ? `^(${t.map((n) => ye(n.toString())).join("|")})$` : "^[^\\s\\S]$"), e._zod.parse = (n, a) => {
    let u = n.value;
    return o.has(u) || n.issues.push({
      code: "invalid_value",
      values: i,
      input: u,
      inst: e
    }), n;
  };
}), Ct = /* @__PURE__ */ m("$ZodLiteral", (e, r) => {
  S.init(e, r);
  let i = new Set(r.values);
  e._zod.values = i, e._zod.pattern = new RegExp(r.values.length ? `^(${r.values.map((o) => typeof o == "string" ? ye(o) : o ? ye(o.toString()) : String(o)).join("|")})$` : "^[^\\s\\S]$"), e._zod.parse = (o, t) => {
    let n = o.value;
    return i.has(n) || o.issues.push({
      code: "invalid_value",
      values: r.values,
      input: n,
      inst: e
    }), o;
  };
}), Ys = /* @__PURE__ */ m("$ZodFile", (e, r) => {
  S.init(e, r), e._zod.parse = (i, o) => {
    let t = i.value;
    return t instanceof File || i.issues.push({
      expected: "file",
      code: "invalid_type",
      input: t,
      inst: e
    }), i;
  };
}), eu = /* @__PURE__ */ m("$ZodTransform", (e, r) => {
  S.init(e, r), e._zod.optin = "optional", X.memoizer?.guard(e), e._zod.parse = (i, o) => {
    if (o.direction === "backward")
      throw new Ce(e.constructor.name);
    let t = r.transform(i.value, i);
    if (o.async)
      return (t instanceof Promise ? t : Promise.resolve(t)).then((a) => (i.value = a, i));
    if (t instanceof Promise)
      throw new se();
    return i.value = t, i;
  };
});
function ap(e, r) {
  return e.value = r.issues.length ? void 0 : r.value, e;
}
s(ap, "handleOptionalResult");
var W = /* @__PURE__ */ m("$ZodOptional", (e, r) => {
  S.init(e, r), T(e, "optin", (i) => i.def.innerType._zod.optin === "defaulted" ? "defaulted" : "optional"), e._zod.optout = "optional", T(e, "values", (i) => {
    let o = i.def.innerType._zod.values;
    return o ? /* @__PURE__ */ new Set([...o, void 0]) : void 0;
  }), T(e, "pattern", (i) => {
    let o = i.def.innerType._zod.pattern;
    return o ? new RegExp(`^(${yr(o.source)})?$`) : void 0;
  }), e._zod.parse = (i, o) => {
    if (i.value === void 0) {
      if (r.innerType._zod.optin !== "defaulted")
        return i;
      let t = r.innerType._zod.run({ value: i.value, issues: [] }, o);
      return t instanceof Promise ? t.then((n) => ap(i, n)) : ap(i, t);
    }
    return r.innerType._zod.run(i, o);
  };
}), tu = /* @__PURE__ */ m("$ZodExactOptional", (e, r) => {
  W.init(e, r), T(e, "values", (i) => i.def.innerType._zod.values), T(e, "pattern", (i) => i.def.innerType._zod.pattern), e._zod.parse = (i, o) => r.innerType._zod.run(i, o);
}), Ne = /* @__PURE__ */ m("$ZodNullable", (e, r) => {
  S.init(e, r), T(e, "optin", (i) => i.def.innerType._zod.optin), T(e, "optout", (i) => i.def.innerType._zod.optout), T(e, "pattern", (i) => {
    let o = i.def.innerType._zod.pattern;
    return o ? new RegExp(`^(${yr(o.source)}|null)$`) : void 0;
  }), T(e, "values", (i) => i.def.innerType._zod.values ? /* @__PURE__ */ new Set([...i.def.innerType._zod.values, null]) : void 0), e._zod.parse = (i, o) => i.value === null ? i : r.innerType._zod.run(i, o);
}), ke = /* @__PURE__ */ m("$ZodDefault", (e, r) => {
  S.init(e, r), e._zod.optin = "defaulted", T(e, "values", (i) => i.def.innerType._zod.values), e._zod.parse = (i, o) => {
    if (o.direction === "backward")
      return r.innerType._zod.run(i, o);
    if (i.value === void 0)
      return i.value = r.defaultValue, i;
    let t = r.innerType._zod.run(i, o);
    return t instanceof Promise ? t.then((n) => sp(n, r)) : sp(t, r);
  };
});
function sp(e, r) {
  return e.value === void 0 && (e.value = r.defaultValue), e;
}
s(sp, "handleDefaultResult");
var ru = /* @__PURE__ */ m("$ZodPrefault", (e, r) => {
  S.init(e, r), e._zod.optin = "defaulted", T(e, "values", (i) => i.def.innerType._zod.values), e._zod.parse = (i, o) => (o.direction === "backward" || i.value === void 0 && (i.value = r.defaultValue), r.innerType._zod.run(i, o));
}), nu = /* @__PURE__ */ m("$ZodNonOptional", (e, r) => {
  S.init(e, r), T(e, "values", (i) => {
    let o = i.def.innerType._zod.values;
    return o ? new Set([...o].filter((t) => t !== void 0)) : void 0;
  }), e._zod.parse = (i, o) => {
    let t = r.innerType._zod.run(i, o);
    return t instanceof Promise ? t.then((n) => up(n, e)) : up(t, e);
  };
});
function up(e, r) {
  return !e.issues.length && e.value === void 0 && e.issues.push({
    code: "invalid_type",
    expected: "nonoptional",
    input: e.value,
    inst: r
  }), e;
}
s(up, "handleNonOptionalResult");
var iu = /* @__PURE__ */ m("$ZodSuccess", (e, r) => {
  S.init(e, r), e._zod.parse = (i, o) => {
    if (o.direction === "backward")
      throw new Ce("ZodSuccess");
    let t = r.innerType._zod.run(i, o);
    return t instanceof Promise ? t.then((n) => (i.value = n.issues.length === 0, i)) : (i.value = t.issues.length === 0, i);
  };
});
function cp(e, r, i, o) {
  return r.issues.length ? (e.value = i.catchValue({
    ...r,
    value: e.value,
    error: {
      issues: r.issues.map((t) => ae(t, o, K()))
    },
    input: e.value
  }), e) : (e.value = r.value, r.memo && (e.memo = !0), e);
}
s(cp, "handleCatchResult");
var ou = /* @__PURE__ */ m("$ZodCatch", (e, r) => {
  S.init(e, r), T(e, "optin", (i) => i.def.innerType._zod.optin === "defaulted" ? "defaulted" : "optional"), T(e, "optout", (i) => i.def.innerType._zod.optout), T(e, "values", (i) => i.def.innerType._zod.values), e._zod.parse = (i, o) => {
    if (o.direction === "backward")
      return r.innerType._zod.run(i, o);
    let t = r.innerType._zod.run({ value: i.value, issues: [] }, o);
    return t instanceof Promise ? t.then((n) => cp(i, n, r, o)) : cp(i, t, r, o);
  };
}), au = /* @__PURE__ */ m("$ZodNaN", (e, r) => {
  S.init(e, r), e._zod.parse = (i, o) => ((typeof i.value != "number" || !Number.isNaN(i.value)) && i.issues.push({
    input: i.value,
    inst: e,
    expected: "nan",
    code: "invalid_type"
  }), i);
}), ai = /* @__PURE__ */ m("$ZodPipe", (e, r) => {
  S.init(e, r), T(e, "values", (i) => i.def.in._zod.values), T(e, "optin", (i) => i.def.in._zod.optin), T(e, "optout", (i) => i.def.out._zod.optout), T(e, "propValues", (i) => i.def.in._zod.propValues), e._zod.parse = (i, o) => {
    if (o.direction === "backward") {
      let n = r.out._zod.run(i, o);
      return n instanceof Promise ? n.then((a) => Jn(a, r.in, o)) : Jn(n, r.in, o);
    }
    let t = r.in._zod.run(i, o);
    return t instanceof Promise ? t.then((n) => Jn(n, r.out, o)) : Jn(t, r.out, o);
  };
});
function Jn(e, r, i) {
  return e.issues.some((o) => o.code !== "unrecognized_keys") ? (e.aborted = !0, e) : r._zod.run({ value: e.value, issues: e.issues }, i);
}
s(Jn, "handlePipeResult");
var Fe = /* @__PURE__ */ m("$ZodCodec", (e, r) => {
  S.init(e, r), T(e, "values", (i) => i.def.in._zod.values), T(e, "optin", (i) => i.def.in._zod.optin), T(e, "optout", (i) => i.def.out._zod.optout), T(e, "propValues", (i) => i.def.in._zod.propValues), e._zod.parse = (i, o) => {
    if ((o.direction || "forward") === "forward") {
      let n = r.in._zod.run(i, o);
      return n instanceof Promise ? n.then((a) => qn(a, r, o)) : qn(n, r, o);
    } else {
      let n = r.out._zod.run(i, o);
      return n instanceof Promise ? n.then((a) => qn(a, r, o)) : qn(n, r, o);
    }
  };
});
function qn(e, r, i) {
  if (e.issues.length)
    return e.aborted = !0, e;
  if ((i.direction || "forward") === "forward") {
    let t = r.transform(e.value, e);
    return t instanceof Promise ? t.then((n) => Kn(e, n, r.out, i)) : Kn(e, t, r.out, i);
  } else {
    let t = r.reverseTransform(e.value, e);
    return t instanceof Promise ? t.then((n) => Kn(e, n, r.in, i)) : Kn(e, t, r.in, i);
  }
}
s(qn, "handleCodecAResult");
function Kn(e, r, i, o) {
  return e.issues.length ? (e.aborted = !0, e) : i._zod.run({ value: r, issues: e.issues }, o);
}
s(Kn, "handleCodecTxResult");
var su = /* @__PURE__ */ m("$ZodPreprocess", (e, r) => {
  ai.init(e, r);
}), uu = /* @__PURE__ */ m("$ZodReadonly", (e, r) => {
  S.init(e, r), T(e, "propValues", (i) => i.def.innerType._zod.propValues), T(e, "values", (i) => i.def.innerType._zod.values), T(e, "optin", (i) => i.def.innerType?._zod?.optin), T(e, "optout", (i) => i.def.innerType?._zod?.optout), e._zod.parse = (i, o) => {
    if (o.direction === "backward")
      return r.innerType._zod.run(i, o);
    let t = r.innerType._zod.run(i, o);
    return t instanceof Promise ? t.then(lp) : lp(t);
  };
});
function lp(e) {
  return e.memo || (e.value = Object.freeze(e.value)), e;
}
s(lp, "handleReadonlyResult");
var cu = /* @__PURE__ */ m("$ZodTemplateLiteral", (e, r) => {
  S.init(e, r);
  let i = [];
  for (let o of r.parts)
    if (typeof o == "object" && o !== null) {
      if (!o._zod.pattern)
        throw new Error(`Invalid template literal part, no pattern found: ${[...o._zod.traits].shift()}`);
      let t = o._zod.pattern instanceof RegExp ? o._zod.pattern.source : o._zod.pattern;
      if (!t)
        throw new Error(`Invalid template literal part: ${o._zod.traits}`);
      let n = t.startsWith("^") ? 1 : 0, a = t.endsWith("$") ? t.length - 1 : t.length;
      i.push(t.slice(n, a));
    } else if (o === null || Wo.has(typeof o))
      i.push(ye(`${o}`));
    else
      throw new Error(`Invalid template literal part: ${o}`);
  e._zod.pattern = new RegExp(`^${i.join("")}$`), e._zod.parse = (o, t) => typeof o.value != "string" ? (o.issues.push({
    input: o.value,
    inst: e,
    expected: "string",
    code: "invalid_type"
  }), o) : (e._zod.pattern.lastIndex = 0, e._zod.pattern.test(o.value) || o.issues.push({
    input: o.value,
    inst: e,
    code: "invalid_format",
    format: r.format ?? "template_literal",
    pattern: e._zod.pattern.source
  }), o);
}), lu = /* @__PURE__ */ m("$ZodFunction", (e, r) => (S.init(e, r), Object.defineProperty(e, "_def", { value: r }), e._zod.def = r, e.implement = (i) => {
  if (typeof i != "function")
    throw new Error("implement() must be called with a function");
  return Object.defineProperty(function(...o) {
    let t = e._def.input ? it(e._def.input, o) : o, n = Reflect.apply(i, this, t);
    return e._def.output ? it(e._def.output, n) : n;
  }, "_zod", { value: e._zod, enumerable: !1 });
}, e.implementAsync = (i) => {
  if (typeof i != "function")
    throw new Error("implementAsync() must be called with a function");
  return Object.defineProperty(async function(...o) {
    let t = e._def.input ? await Pn(e._def.input, o) : o, n = await Reflect.apply(i, this, t);
    return e._def.output ? await Pn(e._def.output, n) : n;
  }, "_zod", { value: e._zod, enumerable: !1 });
}, e._zod.parse = (i, o) => typeof i.value != "function" ? (i.issues.push({
  code: "invalid_type",
  expected: "function",
  input: i.value,
  inst: e
}), i) : (e._def.output && e._def.output._zod.def.type === "promise" ? i.value = e.implementAsync(i.value) : i.value = e.implement(i.value), i), e.input = (...i) => {
  let o = e.constructor;
  return Array.isArray(i[0]) ? new o({
    type: "function",
    input: new ut({
      type: "tuple",
      items: i[0],
      rest: i[1]
    }),
    output: e._def.output
  }) : new o({
    type: "function",
    input: i[0],
    output: e._def.output
  });
}, e.output = (i) => {
  let o = e.constructor;
  return new o({
    type: "function",
    input: e._def.input,
    output: i
  });
}, e)), du = /* @__PURE__ */ m("$ZodPromise", (e, r) => {
  S.init(e, r), e._zod.parse = (i, o) => Promise.resolve(i.value).then((t) => r.innerType._zod.run({ value: t, issues: [] }, o));
}), Le = /* @__PURE__ */ m("$ZodLazy", (e, r) => {
  S.init(e, r), Jo(e._zod, "innerType", () => {
    let i = r;
    return i._cachedInner || (i._cachedInner = r.getter()), i._cachedInner;
  }), T(e, "pattern", (i) => i.innerType?._zod?.pattern), T(e, "propValues", (i) => i.innerType?._zod?.propValues), T(e, "optin", (i) => i.innerType?._zod?.optin ?? void 0), T(e, "optout", (i) => i.innerType?._zod?.optout ?? void 0), e._zod.parse = (i, o) => e._zod.innerType._zod.run(i, o);
}), si = /* @__PURE__ */ m("$ZodCustom", (e, r) => {
  L.init(e, r), S.init(e, r), e._zod.parse = (i, o) => i, e._zod.check = (i) => {
    let o = i.value, t = r.fn(o);
    if (t instanceof Promise)
      return t.then((n) => dp(n, i, o, e));
    dp(t, i, o, e);
  };
});
function dp(e, r, i, o) {
  if (!e) {
    let t = {
      code: "custom",
      input: i,
      inst: o,
      // incorporates params.error into issue reporting
      path: [...o._zod.def.path ?? []],
      // incorporates params.error into issue reporting
      continue: !o._zod.def.abort
      // params: inst._zod.def.params,
    };
    o._zod.def.params && (t.params = o._zod.def.params), r.issues.push(St(t));
  }
}
s(dp, "handleRefineResult");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/memoizer.js
var li = class extends Error {
  static {
    s(this, "$ZodCyclicError");
  }
  constructor() {
    super("Cannot parse a reference cycle that closes through a transform"), this.name = "ZodCyclicError";
  }
}, pu = "~memo", gp = [];
function fu(e) {
  return e.map((r) => r.path ? { ...r, path: r.path.slice() } : { ...r });
}
s(fu, "cloneIssues");
var hp = /* @__PURE__ */ new WeakMap();
function mu(e, r) {
  let i = hp.get(e);
  if (i !== void 0)
    return i;
  if (r.has(e))
    return !0;
  r.add(e);
  let o = !1, t = /* @__PURE__ */ s((u) => {
    !o && u?._zod && mu(u, r) && (o = !0);
  }, "check"), n = e._zod.def, a = n.type;
  switch (a) {
    case "object": {
      for (let u of Reflect.ownKeys(n.shape))
        t(n.shape[u]);
      t(n.catchall);
      break;
    }
    case "array":
      t(n.element);
      break;
    case "tuple":
      for (let u of n.items)
        t(u);
      t(n.rest);
      break;
    case "record":
    case "map":
      t(n.keyType), t(n.valueType);
      break;
    case "set":
      t(n.valueType);
      break;
    case "union":
      for (let u of n.options)
        t(u);
      break;
    case "intersection":
      t(n.left), t(n.right);
      break;
    case "optional":
    case "nullable":
    case "default":
    case "prefault":
    case "catch":
    case "readonly":
    case "nonoptional":
    case "promise":
    case "success":
      t(n.innerType);
      break;
    case "pipe":
      t(n.in), t(n.out);
      break;
    case "function":
      t(n.input), t(n.output);
      break;
    // reading `_zod.innerType` resolves the getter once and caches it
    case "lazy":
      t(e._zod.innerType);
      break;
    // a leaf by choice: `parts` are regex fragments, not data positions
    case "template_literal":
    // leaves
    case "string":
    case "number":
    case "int":
    case "boolean":
    case "bigint":
    case "symbol":
    case "undefined":
    case "null":
    case "void":
    case "never":
    case "any":
    case "unknown":
    case "date":
    case "nan":
    case "enum":
    case "literal":
    case "file":
    case "transform":
    case "custom":
      break;
    default:
      for (let u in n) {
        let c = Object.getOwnPropertyDescriptor(n, u);
        if (!c || c.get)
          continue;
        let l = c.value;
        if (!(!l || typeof l != "object")) {
          if (l._zod)
            t(l);
          else if (Array.isArray(l))
            for (let d of l)
              t(d);
        }
      }
  }
  return r.delete(e), hp.set(e, o), o;
}
s(mu, "isRecursive");
function gu(e) {
  return mu(e, /* @__PURE__ */ new Set());
}
s(gu, "isRecursiveSchema");
function ry(e, r) {
  let i = e.buckets.get(r);
  return i || (i = /* @__PURE__ */ new Map(), e.buckets.set(r, i)), i;
}
s(ry, "bucketFor");
var ui, ci = [], ny = {
  alloc(e, r, i) {
    let o = ui;
    if (!o)
      return i;
    ui = void 0;
    let t = { value: i, issues: null };
    return o.set(r.value, t), ci.push(t), i;
  },
  guard(e) {
    var r;
    (r = e._zod).deferred ?? (r.deferred = []), e._zod.deferred.push(() => {
      let i = e._zod.parse, o = /* @__PURE__ */ s((t, n) => {
        if (n.direction !== "backward" && di(n, t.value))
          throw new li();
        return i(t, n);
      }, "wrapped");
      e._zod.parse = o, e._zod.run === i && (e._zod.run = o);
    });
  },
  attach(e) {
    var r;
    let i, o, t;
    (r = e._zod).deferred ?? (r.deferred = []), e._zod.deferred.push(() => {
      let n = e._zod.parse, a = /* @__PURE__ */ s((u, c) => {
        if (i === void 0 && (i = mu(e, /* @__PURE__ */ new Set()), !i))
          return e._zod.parse = n, e._zod.run === a && (e._zod.run = n), n(u, c);
        let l = u.value;
        if (l === null || typeof l != "object")
          return n(u, c);
        let d = c[pu];
        d || (d = { buckets: /* @__PURE__ */ new Map(), backEdges: void 0 }, c[pu] = d);
        let f;
        o === c ? f = t : (f = ry(d, e), o = c, t = f);
        let p = f.get(l);
        if (p)
          return u.value = p.value, p.issues ? p.issues.length && u.issues.push(...fu(p.issues)) : (u.memo = !0, d.backEdges ?? (d.backEdges = /* @__PURE__ */ new Set()), d.backEdges.add(p.value)), u;
        ui = f;
        let h = ci.length, v = n(u, c);
        ui = void 0;
        let k = ci.length > h ? ci.pop() : void 0;
        return v instanceof Promise ? v.then((z) => (k && (k.issues = z.issues.length ? fu(z.issues) : gp), z)) : (k && (k.issues = v.issues.length ? fu(v.issues) : gp), v);
      }, "wrapped");
      e._zod.parse = a, e._zod.run === n && (e._zod.run = a);
    });
  }
};
function Ar() {
  return ny;
}
s(Ar, "memoizer");
function di(e, r) {
  let i = e[pu]?.backEdges;
  return i !== void 0 && r !== null && typeof r == "object" && i.has(r);
}
s(di, "isBackEdge");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/index.js
var Rr = {};
Pe(Rr, {
  ar: () => hu,
  az: () => vu,
  be: () => yu,
  bg: () => $u,
  bn: () => bu,
  ca: () => _u,
  ckb: () => xu,
  cs: () => wu,
  da: () => ku,
  de: () => Iu,
  el: () => zu,
  en: () => Ur,
  eo: () => Su,
  es: () => Ou,
  fa: () => ju,
  fi: () => Pu,
  fr: () => Du,
  frCA: () => Nu,
  gu: () => Tu,
  he: () => Au,
  hi: () => Uu,
  hr: () => Eu,
  hu: () => Cu,
  hy: () => Zu,
  id: () => Ru,
  is: () => Fu,
  it: () => Lu,
  ja: () => Vu,
  ka: () => Mu,
  kh: () => Bu,
  km: () => Er,
  kn: () => Ju,
  ko: () => qu,
  lt: () => Ku,
  mk: () => Wu,
  ms: () => Gu,
  ne: () => Xu,
  nl: () => Hu,
  nn: () => Qu,
  no: () => Yu,
  ota: () => ec,
  pl: () => rc,
  ps: () => tc,
  pt: () => nc,
  ptBR: () => ic,
  ro: () => oc,
  ru: () => ac,
  sk: () => sc,
  sl: () => uc,
  sv: () => cc,
  ta: () => lc,
  th: () => dc,
  tk: () => fc,
  tr: () => pc,
  ua: () => mc,
  uk: () => Zr,
  ur: () => gc,
  uz: () => hc,
  vi: () => vc,
  yo: () => bc,
  zhCN: () => yc,
  zhTW: () => $c
});

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ar.js
var iy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u062D\u0631\u0641", verb: "\u0623\u0646 \u064A\u062D\u0648\u064A" },
    file: { unit: "\u0628\u0627\u064A\u062A", verb: "\u0623\u0646 \u064A\u062D\u0648\u064A" },
    array: { unit: "\u0639\u0646\u0635\u0631", verb: "\u0623\u0646 \u064A\u062D\u0648\u064A" },
    set: { unit: "\u0639\u0646\u0635\u0631", verb: "\u0623\u0646 \u064A\u062D\u0648\u064A" },
    map: { unit: "\u0639\u0646\u0635\u0631", verb: "\u0623\u0646 \u064A\u062D\u0648\u064A" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u0645\u062F\u062E\u0644",
    email: "\u0628\u0631\u064A\u062F \u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A",
    url: "\u0631\u0627\u0628\u0637",
    emoji: "\u0625\u064A\u0645\u0648\u062C\u064A",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u062A\u0627\u0631\u064A\u062E \u0648\u0648\u0642\u062A \u0628\u0645\u0639\u064A\u0627\u0631 ISO",
    date: "\u062A\u0627\u0631\u064A\u062E \u0628\u0645\u0639\u064A\u0627\u0631 ISO",
    time: "\u0648\u0642\u062A \u0628\u0645\u0639\u064A\u0627\u0631 ISO",
    duration: "\u0645\u062F\u0629 \u0628\u0645\u0639\u064A\u0627\u0631 ISO",
    ipv4: "\u0639\u0646\u0648\u0627\u0646 IPv4",
    ipv6: "\u0639\u0646\u0648\u0627\u0646 IPv6",
    mac: "\u0639\u0646\u0648\u0627\u0646 MAC",
    cidrv4: "\u0645\u062F\u0649 \u0639\u0646\u0627\u0648\u064A\u0646 \u0628\u0635\u064A\u063A\u0629 IPv4",
    cidrv6: "\u0645\u062F\u0649 \u0639\u0646\u0627\u0648\u064A\u0646 \u0628\u0635\u064A\u063A\u0629 IPv6",
    base64: "\u0646\u064E\u0635 \u0628\u062A\u0631\u0645\u064A\u0632 base64-encoded",
    base64url: "\u0646\u064E\u0635 \u0628\u062A\u0631\u0645\u064A\u0632 base64url-encoded",
    json_string: "\u0646\u064E\u0635 \u0639\u0644\u0649 \u0647\u064A\u0626\u0629 JSON",
    e164: "\u0631\u0642\u0645 \u0647\u0627\u062A\u0641 \u0628\u0645\u0639\u064A\u0627\u0631 E.164",
    credit_card: "\u0631\u0642\u0645 \u0628\u0637\u0627\u0642\u0629 \u0627\u0644\u0627\u0626\u062A\u0645\u0627\u0646",
    jwt: "JWT",
    template_literal: "\u0645\u062F\u062E\u0644"
  }, o = {
    nan: "NaN"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u0645\u062F\u062E\u0644\u0627\u062A \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644\u0629: \u064A\u0641\u062A\u0631\u0636 \u0625\u062F\u062E\u0627\u0644 instanceof ${t.expected}\u060C \u0648\u0644\u0643\u0646 \u062A\u0645 \u0625\u062F\u062E\u0627\u0644 ${u}` : `\u0645\u062F\u062E\u0644\u0627\u062A \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644\u0629: \u064A\u0641\u062A\u0631\u0636 \u0625\u062F\u062E\u0627\u0644 ${n}\u060C \u0648\u0644\u0643\u0646 \u062A\u0645 \u0625\u062F\u062E\u0627\u0644 ${u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u0645\u062F\u062E\u0644\u0627\u062A \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644\u0629: \u064A\u0641\u062A\u0631\u0636 \u0625\u062F\u062E\u0627\u0644 ${$(t.values[0])}` : `\u0627\u062E\u062A\u064A\u0627\u0631 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062A\u0648\u0642\u0639 \u0627\u0646\u062A\u0642\u0627\u0621 \u0623\u062D\u062F \u0647\u0630\u0647 \u0627\u0644\u062E\u064A\u0627\u0631\u0627\u062A: ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? ` \u0623\u0643\u0628\u0631 \u0645\u0646 \u0627\u0644\u0644\u0627\u0632\u0645: \u064A\u0641\u062A\u0631\u0636 \u0623\u0646 \u062A\u0643\u0648\u0646 ${t.origin ?? "\u0627\u0644\u0642\u064A\u0645\u0629"} ${n} ${t.maximum.toString()} ${a.unit ?? "\u0639\u0646\u0635\u0631"}` : `\u0623\u0643\u0628\u0631 \u0645\u0646 \u0627\u0644\u0644\u0627\u0632\u0645: \u064A\u0641\u062A\u0631\u0636 \u0623\u0646 \u062A\u0643\u0648\u0646 ${t.origin ?? "\u0627\u0644\u0642\u064A\u0645\u0629"} ${n} ${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u0623\u0635\u063A\u0631 \u0645\u0646 \u0627\u0644\u0644\u0627\u0632\u0645: \u064A\u0641\u062A\u0631\u0636 \u0644\u0640 ${t.origin} \u0623\u0646 \u064A\u0643\u0648\u0646 ${n} ${t.minimum.toString()} ${a.unit}` : `\u0623\u0635\u063A\u0631 \u0645\u0646 \u0627\u0644\u0644\u0627\u0632\u0645: \u064A\u0641\u062A\u0631\u0636 \u0644\u0640 ${t.origin} \u0623\u0646 \u064A\u0643\u0648\u0646 ${n} ${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u0646\u064E\u0635 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u0628\u062F\u0623 \u0628\u0640 "${t.prefix}"` : n.format === "ends_with" ? `\u0646\u064E\u0635 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u0646\u062A\u0647\u064A \u0628\u0640 "${n.suffix}"` : n.format === "includes" ? `\u0646\u064E\u0635 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u062A\u0636\u0645\u0651\u064E\u0646 "${n.includes}"` : n.format === "regex" ? `\u0646\u064E\u0635 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u0637\u0627\u0628\u0642 \u0627\u0644\u0646\u0645\u0637 ${n.pattern}` : `${i[n.format] ?? t.format} \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644`;
      }
      case "not_multiple_of":
        return `\u0631\u0642\u0645 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u0643\u0648\u0646 \u0645\u0646 \u0645\u0636\u0627\u0639\u0641\u0627\u062A ${t.divisor}`;
      case "unrecognized_keys":
        return `\u0645\u0639\u0631\u0641${t.keys.length > 1 ? "\u0627\u062A" : ""} \u063A\u0631\u064A\u0628${t.keys.length > 1 ? "\u0629" : ""}: ${g(t.keys, "\u060C ")}`;
      case "invalid_key":
        return `\u0645\u0639\u0631\u0641 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644 \u0641\u064A ${t.origin}`;
      case "invalid_union":
        return "\u0645\u062F\u062E\u0644 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644";
      case "invalid_element":
        return `\u0645\u062F\u062E\u0644 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644 \u0641\u064A ${t.origin}`;
      default:
        return "\u0645\u062F\u062E\u0644 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644";
    }
  };
}, "error");
function hu() {
  return {
    localeError: iy()
  };
}
s(hu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/az.js
var oy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "simvol", verb: "olmal\u0131d\u0131r" },
    file: { unit: "bayt", verb: "olmal\u0131d\u0131r" },
    array: { unit: "element", verb: "olmal\u0131d\u0131r" },
    set: { unit: "element", verb: "olmal\u0131d\u0131r" },
    map: { unit: "element", verb: "olmal\u0131d\u0131r" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "input",
    email: "email address",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datetime",
    date: "ISO date",
    time: "ISO time",
    duration: "ISO duration",
    ipv4: "IPv4 address",
    ipv6: "IPv6 address",
    mac: "MAC address",
    cidrv4: "IPv4 range",
    cidrv6: "IPv6 range",
    base64: "base64-encoded string",
    base64url: "base64url-encoded string",
    json_string: "JSON string",
    e164: "E.164 number",
    credit_card: "kredit kart\u0131 n\xF6mr\u0259si",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Yanl\u0131\u015F d\u0259y\u0259r: g\xF6zl\u0259nil\u0259n instanceof ${t.expected}, daxil olan ${u}` : `Yanl\u0131\u015F d\u0259y\u0259r: g\xF6zl\u0259nil\u0259n ${n}, daxil olan ${u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Yanl\u0131\u015F d\u0259y\u0259r: g\xF6zl\u0259nil\u0259n ${$(t.values[0])}` : `Yanl\u0131\u015F se\xE7im: a\u015Fa\u011F\u0131dak\u0131lardan biri olmal\u0131d\u0131r: ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\xC7ox b\xF6y\xFCk: g\xF6zl\u0259nil\u0259n ${t.origin ?? "d\u0259y\u0259r"} ${n}${t.maximum.toString()} ${a.unit ?? "element"}` : `\xC7ox b\xF6y\xFCk: g\xF6zl\u0259nil\u0259n ${t.origin ?? "d\u0259y\u0259r"} ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\xC7ox ki\xE7ik: g\xF6zl\u0259nil\u0259n ${t.origin} ${n}${t.minimum.toString()} ${a.unit}` : `\xC7ox ki\xE7ik: g\xF6zl\u0259nil\u0259n ${t.origin} ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Yanl\u0131\u015F m\u0259tn: "${n.prefix}" il\u0259 ba\u015Flamal\u0131d\u0131r` : n.format === "ends_with" ? `Yanl\u0131\u015F m\u0259tn: "${n.suffix}" il\u0259 bitm\u0259lidir` : n.format === "includes" ? `Yanl\u0131\u015F m\u0259tn: "${n.includes}" daxil olmal\u0131d\u0131r` : n.format === "regex" ? `Yanl\u0131\u015F m\u0259tn: ${n.pattern} \u015Fablonuna uy\u011Fun olmal\u0131d\u0131r` : `Yanl\u0131\u015F ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Yanl\u0131\u015F \u0259d\u0259d: ${t.divisor} il\u0259 b\xF6l\xFCn\u0259 bil\u0259n olmal\u0131d\u0131r`;
      case "unrecognized_keys":
        return `Tan\u0131nmayan a\xE7ar${t.keys.length > 1 ? "lar" : ""}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `${t.origin} daxilind\u0259 yanl\u0131\u015F a\xE7ar`;
      case "invalid_union":
        return "Yanl\u0131\u015F d\u0259y\u0259r";
      case "invalid_element":
        return `${t.origin} daxilind\u0259 yanl\u0131\u015F d\u0259y\u0259r`;
      default:
        return "Yanl\u0131\u015F d\u0259y\u0259r";
    }
  };
}, "error");
function vu() {
  return {
    localeError: oy()
  };
}
s(vu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/be.js
function vp(e, r, i, o) {
  let t = Math.abs(e), n = t % 10, a = t % 100;
  return a >= 11 && a <= 19 ? o : n === 1 ? r : n >= 2 && n <= 4 ? i : o;
}
s(vp, "getBelarusianPlural");
var ay = /* @__PURE__ */ s(() => {
  let e = {
    string: {
      unit: {
        one: "\u0441\u0456\u043C\u0432\u0430\u043B",
        few: "\u0441\u0456\u043C\u0432\u0430\u043B\u044B",
        many: "\u0441\u0456\u043C\u0432\u0430\u043B\u0430\u045E"
      },
      verb: "\u043C\u0435\u0446\u044C"
    },
    array: {
      unit: {
        one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
        few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u044B",
        many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430\u045E"
      },
      verb: "\u043C\u0435\u0446\u044C"
    },
    set: {
      unit: {
        one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
        few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u044B",
        many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430\u045E"
      },
      verb: "\u043C\u0435\u0446\u044C"
    },
    map: {
      unit: {
        one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
        few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u044B",
        many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430\u045E"
      },
      verb: "\u043C\u0435\u0446\u044C"
    },
    file: {
      unit: {
        one: "\u0431\u0430\u0439\u0442",
        few: "\u0431\u0430\u0439\u0442\u044B",
        many: "\u0431\u0430\u0439\u0442\u0430\u045E"
      },
      verb: "\u043C\u0435\u0446\u044C"
    }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u0443\u0432\u043E\u0434",
    email: "email \u0430\u0434\u0440\u0430\u0441",
    url: "URL",
    emoji: "\u044D\u043C\u043E\u0434\u0437\u0456",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0434\u0430\u0442\u0430 \u0456 \u0447\u0430\u0441",
    date: "ISO \u0434\u0430\u0442\u0430",
    time: "ISO \u0447\u0430\u0441",
    duration: "ISO \u043F\u0440\u0430\u0446\u044F\u0433\u043B\u0430\u0441\u0446\u044C",
    ipv4: "IPv4 \u0430\u0434\u0440\u0430\u0441",
    ipv6: "IPv6 \u0430\u0434\u0440\u0430\u0441",
    mac: "MAC \u0430\u0434\u0440\u0430\u0441",
    cidrv4: "IPv4 \u0434\u044B\u044F\u043F\u0430\u0437\u043E\u043D",
    cidrv6: "IPv6 \u0434\u044B\u044F\u043F\u0430\u0437\u043E\u043D",
    base64: "\u0440\u0430\u0434\u043E\u043A \u0443 \u0444\u0430\u0440\u043C\u0430\u0446\u0435 base64",
    base64url: "\u0440\u0430\u0434\u043E\u043A \u0443 \u0444\u0430\u0440\u043C\u0430\u0446\u0435 base64url",
    json_string: "JSON \u0440\u0430\u0434\u043E\u043A",
    e164: "\u043D\u0443\u043C\u0430\u0440 E.164",
    credit_card: "\u043D\u0443\u043C\u0430\u0440 \u043A\u0440\u044D\u0434\u044B\u0442\u043D\u0430\u0439 \u043A\u0430\u0440\u0442\u044B",
    jwt: "JWT",
    template_literal: "\u0443\u0432\u043E\u0434"
  }, o = {
    nan: "NaN",
    number: "\u043B\u0456\u043A",
    array: "\u043C\u0430\u0441\u0456\u045E"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434: \u0447\u0430\u043A\u0430\u045E\u0441\u044F instanceof ${t.expected}, \u0430\u0442\u0440\u044B\u043C\u0430\u043D\u0430 ${u}` : `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434: \u0447\u0430\u043A\u0430\u045E\u0441\u044F ${n}, \u0430\u0442\u0440\u044B\u043C\u0430\u043D\u0430 ${u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F ${$(t.values[0])}` : `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0432\u0430\u0440\u044B\u044F\u043D\u0442: \u0447\u0430\u043A\u0430\u045E\u0441\u044F \u0430\u0434\u0437\u0456\u043D \u0437 ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        if (a) {
          let u = Number(t.maximum), c = vp(u, a.unit.one, a.unit.few, a.unit.many);
          return `\u0417\u0430\u043D\u0430\u0434\u0442\u0430 \u0432\u044F\u043B\u0456\u043A\u0456: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F, \u0448\u0442\u043E ${t.origin ?? "\u0437\u043D\u0430\u0447\u044D\u043D\u043D\u0435"} \u043F\u0430\u0432\u0456\u043D\u043D\u0430 ${a.verb} ${n}${t.maximum.toString()} ${c}`;
        }
        return `\u0417\u0430\u043D\u0430\u0434\u0442\u0430 \u0432\u044F\u043B\u0456\u043A\u0456: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F, \u0448\u0442\u043E ${t.origin ?? "\u0437\u043D\u0430\u0447\u044D\u043D\u043D\u0435"} \u043F\u0430\u0432\u0456\u043D\u043D\u0430 \u0431\u044B\u0446\u044C ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        if (a) {
          let u = Number(t.minimum), c = vp(u, a.unit.one, a.unit.few, a.unit.many);
          return `\u0417\u0430\u043D\u0430\u0434\u0442\u0430 \u043C\u0430\u043B\u044B: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F, \u0448\u0442\u043E ${t.origin} \u043F\u0430\u0432\u0456\u043D\u043D\u0430 ${a.verb} ${n}${t.minimum.toString()} ${c}`;
        }
        return `\u0417\u0430\u043D\u0430\u0434\u0442\u0430 \u043C\u0430\u043B\u044B: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F, \u0448\u0442\u043E ${t.origin} \u043F\u0430\u0432\u0456\u043D\u043D\u0430 \u0431\u044B\u0446\u044C ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0440\u0430\u0434\u043E\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u043F\u0430\u0447\u044B\u043D\u0430\u0446\u0446\u0430 \u0437 "${n.prefix}"` : n.format === "ends_with" ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0440\u0430\u0434\u043E\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u0437\u0430\u043A\u0430\u043D\u0447\u0432\u0430\u0446\u0446\u0430 \u043D\u0430 "${n.suffix}"` : n.format === "includes" ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0440\u0430\u0434\u043E\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u0437\u043C\u044F\u0448\u0447\u0430\u0446\u044C "${n.includes}"` : n.format === "regex" ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0440\u0430\u0434\u043E\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u0430\u0434\u043F\u0430\u0432\u044F\u0434\u0430\u0446\u044C \u0448\u0430\u0431\u043B\u043E\u043D\u0443 ${n.pattern}` : `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u043B\u0456\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u0431\u044B\u0446\u044C \u043A\u0440\u0430\u0442\u043D\u044B\u043C ${t.divisor}`;
      case "unrecognized_keys":
        return `\u041D\u0435\u0440\u0430\u0441\u043F\u0430\u0437\u043D\u0430\u043D\u044B ${t.keys.length > 1 ? "\u043A\u043B\u044E\u0447\u044B" : "\u043A\u043B\u044E\u0447"}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u043A\u043B\u044E\u0447 \u0443 ${t.origin}`;
      case "invalid_union":
        return "\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434";
      case "invalid_element":
        return `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u0430\u0435 \u0437\u043D\u0430\u0447\u044D\u043D\u043D\u0435 \u045E ${t.origin}`;
      default:
        return "\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434";
    }
  };
}, "error");
function yu() {
  return {
    localeError: ay()
  };
}
s(yu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/bg.js
var sy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0441\u0438\u043C\u0432\u043E\u043B\u0430", verb: "\u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430" },
    file: { unit: "\u0431\u0430\u0439\u0442\u0430", verb: "\u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430" },
    array: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0430", verb: "\u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430" },
    set: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0430", verb: "\u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430" },
    map: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0430", verb: "\u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u0432\u0445\u043E\u0434",
    email: "\u0438\u043C\u0435\u0439\u043B \u0430\u0434\u0440\u0435\u0441",
    url: "URL",
    emoji: "\u0435\u043C\u043E\u0434\u0436\u0438",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0432\u0440\u0435\u043C\u0435",
    date: "ISO \u0434\u0430\u0442\u0430",
    time: "ISO \u0432\u0440\u0435\u043C\u0435",
    duration: "ISO \u043F\u0440\u043E\u0434\u044A\u043B\u0436\u0438\u0442\u0435\u043B\u043D\u043E\u0441\u0442",
    ipv4: "IPv4 \u0430\u0434\u0440\u0435\u0441",
    ipv6: "IPv6 \u0430\u0434\u0440\u0435\u0441",
    mac: "MAC \u0430\u0434\u0440\u0435\u0441",
    cidrv4: "IPv4 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D",
    cidrv6: "IPv6 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D",
    base64: "base64-\u043A\u043E\u0434\u0438\u0440\u0430\u043D \u043D\u0438\u0437",
    base64url: "base64url-\u043A\u043E\u0434\u0438\u0440\u0430\u043D \u043D\u0438\u0437",
    json_string: "JSON \u043D\u0438\u0437",
    e164: "E.164 \u043D\u043E\u043C\u0435\u0440",
    credit_card: "\u043D\u043E\u043C\u0435\u0440 \u043D\u0430 \u043A\u0440\u0435\u0434\u0438\u0442\u043D\u0430 \u043A\u0430\u0440\u0442\u0430",
    jwt: "JWT",
    template_literal: "\u0432\u0445\u043E\u0434"
  }, o = {
    nan: "NaN",
    number: "\u0447\u0438\u0441\u043B\u043E",
    array: "\u043C\u0430\u0441\u0438\u0432"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434: \u043E\u0447\u0430\u043A\u0432\u0430\u043D instanceof ${t.expected}, \u043F\u043E\u043B\u0443\u0447\u0435\u043D ${u}` : `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434: \u043E\u0447\u0430\u043A\u0432\u0430\u043D ${n}, \u043F\u043E\u043B\u0443\u0447\u0435\u043D ${u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434: \u043E\u0447\u0430\u043A\u0432\u0430\u043D ${$(t.values[0])}` : `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u0430 \u043E\u043F\u0446\u0438\u044F: \u043E\u0447\u0430\u043A\u0432\u0430\u043D\u043E \u0435\u0434\u043D\u043E \u043E\u0442 ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u0422\u0432\u044A\u0440\u0434\u0435 \u0433\u043E\u043B\u044F\u043C\u043E: \u043E\u0447\u0430\u043A\u0432\u0430 \u0441\u0435 ${t.origin ?? "\u0441\u0442\u043E\u0439\u043D\u043E\u0441\u0442"} \u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430 ${n}${t.maximum.toString()} ${a.unit ?? "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0430"}` : `\u0422\u0432\u044A\u0440\u0434\u0435 \u0433\u043E\u043B\u044F\u043C\u043E: \u043E\u0447\u0430\u043A\u0432\u0430 \u0441\u0435 ${t.origin ?? "\u0441\u0442\u043E\u0439\u043D\u043E\u0441\u0442"} \u0434\u0430 \u0431\u044A\u0434\u0435 ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u0422\u0432\u044A\u0440\u0434\u0435 \u043C\u0430\u043B\u043A\u043E: \u043E\u0447\u0430\u043A\u0432\u0430 \u0441\u0435 ${t.origin} \u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430 ${n}${t.minimum.toString()} ${a.unit}` : `\u0422\u0432\u044A\u0440\u0434\u0435 \u043C\u0430\u043B\u043A\u043E: \u043E\u0447\u0430\u043A\u0432\u0430 \u0441\u0435 ${t.origin} \u0434\u0430 \u0431\u044A\u0434\u0435 ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        if (n.format === "starts_with")
          return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043D\u0438\u0437: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0437\u0430\u043F\u043E\u0447\u0432\u0430 \u0441 "${n.prefix}"`;
        if (n.format === "ends_with")
          return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043D\u0438\u0437: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0437\u0430\u0432\u044A\u0440\u0448\u0432\u0430 \u0441 "${n.suffix}"`;
        if (n.format === "includes")
          return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043D\u0438\u0437: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0432\u043A\u043B\u044E\u0447\u0432\u0430 "${n.includes}"`;
        if (n.format === "regex")
          return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043D\u0438\u0437: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0441\u044A\u0432\u043F\u0430\u0434\u0430 \u0441 ${n.pattern}`;
        let a = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D";
        return n.format === "emoji" && (a = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u043E"), n.format === "datetime" && (a = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u043E"), n.format === "date" && (a = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u0430"), n.format === "time" && (a = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u043E"), n.format === "duration" && (a = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u0430"), `${a} ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u043E \u0447\u0438\u0441\u043B\u043E: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0431\u044A\u0434\u0435 \u043A\u0440\u0430\u0442\u043D\u043E \u043D\u0430 ${t.divisor}`;
      case "unrecognized_keys":
        return `\u041D\u0435\u0440\u0430\u0437\u043F\u043E\u0437\u043D\u0430\u0442${t.keys.length > 1 ? "\u0438" : ""} \u043A\u043B\u044E\u0447${t.keys.length > 1 ? "\u043E\u0432\u0435" : ""}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043A\u043B\u044E\u0447 \u0432 ${t.origin}`;
      case "invalid_union":
        return "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434";
      case "invalid_element":
        return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u0430 \u0441\u0442\u043E\u0439\u043D\u043E\u0441\u0442 \u0432 ${t.origin}`;
      default:
        return "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434";
    }
  };
}, "error");
function $u() {
  return {
    localeError: sy()
  };
}
s($u, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/bn.js
var uy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0985\u0995\u09CD\u09B7\u09B0", verb: "\u09A5\u09BE\u0995\u09A4\u09C7 \u09B9\u09AC\u09C7" },
    file: { unit: "\u09AC\u09BE\u0987\u099F", verb: "\u09A5\u09BE\u0995\u09A4\u09C7 \u09B9\u09AC\u09C7" },
    array: { unit: "\u0986\u0987\u099F\u09C7\u09AE", verb: "\u09A5\u09BE\u0995\u09A4\u09C7 \u09B9\u09AC\u09C7" },
    set: { unit: "\u0986\u0987\u099F\u09C7\u09AE", verb: "\u09A5\u09BE\u0995\u09A4\u09C7 \u09B9\u09AC\u09C7" },
    map: { unit: "\u098F\u09A8\u09CD\u099F\u09CD\u09B0\u09BF", verb: "\u09A5\u09BE\u0995\u09A4\u09C7 \u09B9\u09AC\u09C7" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u0987\u09A8\u09AA\u09C1\u099F",
    email: "\u0987\u09AE\u09C7\u0987\u09B2 \u09A0\u09BF\u0995\u09BE\u09A8\u09BE",
    url: "URL",
    emoji: "\u0987\u09AE\u09CB\u099C\u09BF",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u09A4\u09BE\u09B0\u09BF\u0996 \u0993 \u09B8\u09AE\u09AF\u09BC",
    date: "ISO \u09A4\u09BE\u09B0\u09BF\u0996",
    time: "ISO \u09B8\u09AE\u09AF\u09BC",
    duration: "ISO \u09B8\u09AE\u09AF\u09BC\u0995\u09BE\u09B2",
    ipv4: "IPv4 \u09A0\u09BF\u0995\u09BE\u09A8\u09BE",
    ipv6: "IPv6 \u09A0\u09BF\u0995\u09BE\u09A8\u09BE",
    mac: "MAC \u09A0\u09BF\u0995\u09BE\u09A8\u09BE",
    cidrv4: "IPv4 \u09B0\u09C7\u099E\u09CD\u099C",
    cidrv6: "IPv6 \u09B0\u09C7\u099E\u09CD\u099C",
    base64: "base64-\u098F\u09A8\u0995\u09CB\u09A1\u09C7\u09A1 \u09B8\u09CD\u099F\u09CD\u09B0\u09BF\u0982",
    base64url: "base64url-\u098F\u09A8\u0995\u09CB\u09A1\u09C7\u09A1 \u09B8\u09CD\u099F\u09CD\u09B0\u09BF\u0982",
    json_string: "JSON \u09B8\u09CD\u099F\u09CD\u09B0\u09BF\u0982",
    e164: "E.164 \u09A8\u09AE\u09CD\u09AC\u09B0",
    credit_card: "\u0995\u09CD\u09B0\u09C7\u09A1\u09BF\u099F \u0995\u09BE\u09B0\u09CD\u09A1 \u09A8\u09AE\u09CD\u09AC\u09B0",
    jwt: "JWT",
    template_literal: "\u0987\u09A8\u09AA\u09C1\u099F"
  }, o = {
    nan: "NaN"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return `\u0985\u09AC\u09C8\u09A7 \u0987\u09A8\u09AA\u09C1\u099F: \u09AA\u09CD\u09B0\u09A4\u09CD\u09AF\u09BE\u09B6\u09BF\u09A4 ${n}, \u09AA\u09CD\u09B0\u09BE\u09AA\u09CD\u09A4 ${u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u0985\u09AC\u09C8\u09A7 \u0987\u09A8\u09AA\u09C1\u099F: \u09AA\u09CD\u09B0\u09A4\u09CD\u09AF\u09BE\u09B6\u09BF\u09A4 ${$(t.values[0])}` : `\u0985\u09AC\u09C8\u09A7 \u0985\u09AA\u09B6\u09A8: ${g(t.values, " | ")} \u098F\u09B0 \u09AE\u09A7\u09CD\u09AF\u09C7 \u098F\u0995\u099F\u09BF \u09AA\u09CD\u09B0\u09A4\u09CD\u09AF\u09BE\u09B6\u09BF\u09A4`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u0985\u09A8\u09C7\u0995 \u09AC\u09A1\u09BC: ${t.origin ?? "\u09AE\u09BE\u09A8"} ${n}${t.maximum.toString()} ${a.unit ?? "\u098F\u09B2\u09BF\u09AE\u09C7\u09A8\u09CD\u099F"} \u09B9\u09A4\u09C7 \u09B9\u09AC\u09C7` : `\u0985\u09A8\u09C7\u0995 \u09AC\u09A1\u09BC: ${t.origin ?? "\u09AE\u09BE\u09A8"} ${n}${t.maximum.toString()} \u09B9\u09A4\u09C7 \u09B9\u09AC\u09C7`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u0985\u09A8\u09C7\u0995 \u099B\u09CB\u099F: ${t.origin} ${n}${t.minimum.toString()} ${a.unit} \u09B9\u09A4\u09C7 \u09B9\u09AC\u09C7` : `\u0985\u09A8\u09C7\u0995 \u099B\u09CB\u099F: ${t.origin} ${n}${t.minimum.toString()} \u09B9\u09A4\u09C7 \u09B9\u09AC\u09C7`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u0985\u09AC\u09C8\u09A7 \u09B8\u09CD\u099F\u09CD\u09B0\u09BF\u0982: "${n.prefix}" \u09A6\u09BF\u09AF\u09BC\u09C7 \u09B6\u09C1\u09B0\u09C1 \u09B9\u09A4\u09C7 \u09B9\u09AC\u09C7` : n.format === "ends_with" ? `\u0985\u09AC\u09C8\u09A7 \u09B8\u09CD\u099F\u09CD\u09B0\u09BF\u0982: "${n.suffix}" \u09A6\u09BF\u09AF\u09BC\u09C7 \u09B6\u09C7\u09B7 \u09B9\u09A4\u09C7 \u09B9\u09AC\u09C7` : n.format === "includes" ? `\u0985\u09AC\u09C8\u09A7 \u09B8\u09CD\u099F\u09CD\u09B0\u09BF\u0982: "${n.includes}" \u0985\u09A8\u09CD\u09A4\u09B0\u09CD\u09AD\u09C1\u0995\u09CD\u09A4 \u09A5\u09BE\u0995\u09A4\u09C7 \u09B9\u09AC\u09C7` : n.format === "regex" ? `\u0985\u09AC\u09C8\u09A7 \u09B8\u09CD\u099F\u09CD\u09B0\u09BF\u0982: ${n.pattern} \u09AA\u09CD\u09AF\u09BE\u099F\u09BE\u09B0\u09CD\u09A8 \u09AE\u09BF\u09B2\u09A4\u09C7 \u09B9\u09AC\u09C7` : `\u0985\u09AC\u09C8\u09A7 ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u0985\u09AC\u09C8\u09A7 \u09A8\u09AE\u09CD\u09AC\u09B0: ${t.divisor} \u098F\u09B0 \u0997\u09C1\u09A3\u09BF\u09A4\u0995 \u09B9\u09A4\u09C7 \u09B9\u09AC\u09C7`;
      case "unrecognized_keys":
        return `\u0985\u099A\u09C7\u09A8\u09BE \u0995\u09C0${t.keys.length > 1 ? "\u0997\u09C1\u09B2\u09CB" : ""}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `${t.origin} \u098F \u0985\u09AC\u09C8\u09A7 \u0995\u09C0`;
      case "invalid_union":
        return t.options && Array.isArray(t.options) && t.options.length > 0 ? `\u0985\u09AC\u09C8\u09A7 \u09A1\u09BF\u09B8\u0995\u09CD\u09B0\u09BF\u09AE\u09BF\u09A8\u09C7\u099F\u09B0 \u09AE\u09BE\u09A8\u0964 \u09AA\u09CD\u09B0\u09A4\u09CD\u09AF\u09BE\u09B6\u09BF\u09A4 ${t.options.map((a) => `'${a}'`).join(" | ")}` : "\u0985\u09AC\u09C8\u09A7 \u0987\u09A8\u09AA\u09C1\u099F";
      case "invalid_element":
        return `${t.origin} \u098F \u0985\u09AC\u09C8\u09A7 \u09AE\u09BE\u09A8`;
      default:
        return "\u0985\u09AC\u09C8\u09A7 \u0987\u09A8\u09AA\u09C1\u099F";
    }
  };
}, "error");
function bu() {
  return {
    localeError: uy()
  };
}
s(bu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ca.js
var cy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "car\xE0cters", verb: "contenir" },
    file: { unit: "bytes", verb: "contenir" },
    array: { unit: "elements", verb: "contenir" },
    set: { unit: "elements", verb: "contenir" },
    map: { unit: "elements", verb: "contenir" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "entrada",
    email: "adre\xE7a electr\xF2nica",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "data i hora ISO",
    date: "data ISO",
    time: "hora ISO",
    duration: "durada ISO",
    ipv4: "adre\xE7a IPv4",
    ipv6: "adre\xE7a IPv6",
    mac: "adre\xE7a MAC",
    cidrv4: "rang IPv4",
    cidrv6: "rang IPv6",
    base64: "cadena codificada en base64",
    base64url: "cadena codificada en base64url",
    json_string: "cadena JSON",
    e164: "n\xFAmero E.164",
    credit_card: "n\xFAmero de targeta de cr\xE8dit",
    jwt: "JWT",
    template_literal: "entrada"
  }, o = {
    nan: "NaN"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Tipus inv\xE0lid: s'esperava instanceof ${t.expected}, s'ha rebut ${u}` : `Tipus inv\xE0lid: s'esperava ${n}, s'ha rebut ${u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Valor inv\xE0lid: s'esperava ${$(t.values[0])}` : `Opci\xF3 inv\xE0lida: s'esperava una de ${g(t.values, " o ")}`;
      case "too_big": {
        let n = t.inclusive ? "com a m\xE0xim" : "menys de", a = r(t.origin);
        return a ? `Massa gran: s'esperava que ${t.origin ?? "el valor"} contingu\xE9s ${n} ${t.maximum.toString()} ${a.unit ?? "elements"}` : `Massa gran: s'esperava que ${t.origin ?? "el valor"} fos ${n} ${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? "com a m\xEDnim" : "m\xE9s de", a = r(t.origin);
        return a ? `Massa petit: s'esperava que ${t.origin} contingu\xE9s ${n} ${t.minimum.toString()} ${a.unit}` : `Massa petit: s'esperava que ${t.origin} fos ${n} ${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Format inv\xE0lid: ha de comen\xE7ar amb "${n.prefix}"` : n.format === "ends_with" ? `Format inv\xE0lid: ha d'acabar amb "${n.suffix}"` : n.format === "includes" ? `Format inv\xE0lid: ha d'incloure "${n.includes}"` : n.format === "regex" ? `Format inv\xE0lid: ha de coincidir amb el patr\xF3 ${n.pattern}` : `Format inv\xE0lid per a ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `N\xFAmero inv\xE0lid: ha de ser m\xFAltiple de ${t.divisor}`;
      case "unrecognized_keys":
        return `Clau${t.keys.length > 1 ? "s" : ""} no reconeguda${t.keys.length > 1 ? "s" : ""}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `Clau inv\xE0lida a ${t.origin}`;
      case "invalid_union":
        return "Entrada inv\xE0lida";
      // Could also be "Tipus d'unió invàlid" but "Entrada invàlida" is more general
      case "invalid_element":
        return `Element inv\xE0lid a ${t.origin}`;
      default:
        return "Entrada inv\xE0lida";
    }
  };
}, "error");
function _u() {
  return {
    localeError: cy()
  };
}
s(_u, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ckb.js
var ly = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u067E\u06CC\u062A", verb: "\u0628\u06CE\u062A" },
    file: { unit: "\u0628\u0627\u06CC\u062A", verb: "\u0628\u06CE\u062A" },
    array: { unit: "\u062F\u0627\u0646\u06D5", verb: "\u0628\u06CE\u062A" },
    set: { unit: "\u062F\u0627\u0646\u06D5", verb: "\u0628\u06CE\u062A" },
    map: { unit: "\u062F\u0627\u0646\u06D5", verb: "\u0628\u06CE\u062A" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "regex",
    email: "\u0626\u06CC\u0645\u06D5\u06CC\u06B5",
    url: "\u0628\u06D5\u0633\u062A\u06D5\u0631 (URL)",
    emoji: "\u0626\u06CC\u0645\u06C6\u062C\u06CC",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u0695\u06CE\u06A9\u06D5\u0648\u062A \u0648 \u06A9\u0627\u062A",
    date: "\u0695\u06CE\u06A9\u06D5\u0648\u062A",
    time: "\u06A9\u0627\u062A",
    duration: "\u0645\u0627\u0648\u06D5",
    ipv4: "\u0646\u0627\u0648\u0646\u06CC\u0634\u0627\u0646\u06CC IPv4",
    ipv6: "\u0646\u0627\u0648\u0646\u06CC\u0634\u0627\u0646\u06CC IPv6",
    mac: "\u0646\u0627\u0648\u0646\u06CC\u0634\u0627\u0646\u06CC MAC",
    cidrv4: "\u0645\u06D5\u0648\u062F\u0627\u06CC IPv4",
    cidrv6: "\u0645\u06D5\u0648\u062F\u0627\u06CC IPv6",
    base64: "\u062F\u06D5\u0642\u06CC base64",
    base64url: "\u062F\u06D5\u0642\u06CC base64url",
    json_string: "\u062F\u06D5\u0642\u06CC JSON",
    e164: "\u0698\u0645\u0627\u0631\u06D5\u06CC E.164",
    credit_card: "\u0698\u0645\u0627\u0631\u06D5\u06CC \u06A9\u0627\u0631\u062A\u06CC \u06A9\u0631\u06CE\u062F\u06CC\u062A",
    jwt: "JWT",
    template_literal: "\u062A\u06CE\u06A9\u0631\u062F\u06D5"
  }, o = {
    nan: "NaN",
    string: "\u0646\u0648\u0648\u0633\u06CC\u0646",
    number: "\u0698\u0645\u0627\u0631\u06D5",
    boolean: "boolean",
    array: "array",
    object: "object",
    date: "\u0695\u06CE\u06A9\u06D5\u0648\u062A",
    integer: "\u0698\u0645\u0627\u0631\u06D5",
    float: "\u0698\u0645\u0627\u0631\u06D5",
    null: "null",
    undefined: "undefined",
    function: "function",
    symbol: "symbol",
    unknown: "unknown",
    promise: "promise",
    void: "void",
    never: "never",
    map: "map",
    set: "set"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a, c = ["\u0627", "\u0648", "\u06C6", "\u0648\u0648", "\u06D5", "\u06CC", "\u06CE"].some((d) => u.endsWith(d)) ? "\u06CC\u06D5" : "\u06D5", l = /^[a-zA-Z]+$/.test(u);
        return a === "null" || a === "undefined" ? "\u062F\u0627\u0648\u0627\u06A9\u0631\u0627\u0648\u06D5" : `\u0686\u0627\u0648\u06D5\u0695\u0648\u0627\u0646\u06A9\u0631\u0627\u0648\u06D5 ${n} \u0628\u06CE\u062A\u060C \u0628\u06D5\u06B5\u0627\u0645 ${u}${l ? "" : c}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u0628\u06D5\u0647\u0627\u06A9\u06D5 \u0646\u0627\u062F\u0631\u0648\u0648\u0633\u062A\u06D5: \u0686\u0627\u0648\u06D5\u0695\u0648\u0627\u0646\u06A9\u0631\u0627\u0648\u06D5 ${$(t.values[0])} \u0628\u06CE\u062A` : `\u0647\u06D5\u06B5\u0628\u0698\u0627\u0631\u062F\u06D5\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A: \u0686\u0627\u0648\u06D5\u0695\u0648\u0627\u0646\u06A9\u0631\u0627\u0648\u06D5 \u06CC\u06D5\u06A9\u06CE\u06A9 \u0628\u06CE\u062A \u0644\u06D5 ${g(t.values, "|")}`;
      case "too_big": {
        let n = r(t.origin);
        return n ? `\u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 \u0628\u06D5 \u0644\u0627\u06CC\u06D5\u0646\u06CC \u0632\u06C6\u0631\u06D5\u0648\u06D5 ${t.maximum.toString()} ${n.unit} ${n.verb}` : `\u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 \u0628\u06D5 \u0644\u0627\u06CC\u06D5\u0646\u06CC \u0632\u06C6\u0631\u06D5\u0648\u06D5 ${t.maximum.toString()} \u0628\u06CE\u062A`;
      }
      case "too_small": {
        let n = r(t.origin);
        return n ? `\u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 \u0628\u06D5 \u0644\u0627\u06CC\u06D5\u0646\u06CC \u06A9\u06D5\u0645\u06D5\u0648\u06D5 ${t.minimum.toString()} ${n.unit} ${n.verb}` : `\u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 \u0628\u06D5 \u0644\u0627\u06CC\u06D5\u0646\u06CC \u06A9\u06D5\u0645\u06D5\u0648\u06D5 ${t.minimum.toString()} \u0628\u06CE\u062A`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u062F\u06D5\u0642\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A: \u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 \u062F\u06D5\u0633\u062A\u067E\u06CE\u0628\u06A9\u0627\u062A \u0628\u06D5 "${n.prefix}"` : n.format === "ends_with" ? `\u062F\u06D5\u0642\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A: \u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 \u06A9\u06C6\u062A\u0627\u06CC\u06CC\u0628\u06CE\u062A \u0628\u06D5 "${n.suffix}"` : n.format === "includes" ? `\u062F\u06D5\u0642\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A: \u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 "${n.includes}" \u0644\u06D5\u062E\u06C6\u0628\u06AF\u0631\u06CE\u062A` : n.format === "regex" ? `\u062F\u06D5\u0642\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A: \u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 \u0644\u06D5\u06AF\u06D5\u06B5 \u067E\u0627\u062A\u06CE\u0631\u0646\u06CC ${n.pattern} \u0628\u06AF\u0648\u0646\u062C\u06CE\u062A` : `\u0628\u06D5\u0647\u0627\u06CC ${i[n.format] ?? t.format} \u0646\u0627\u062F\u0631\u0648\u0633\u062A\u06D5`;
      }
      case "not_multiple_of":
        return `\u0698\u0645\u0627\u0631\u06D5\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A: \u062F\u06D5\u0628\u06CE\u062A \u0686\u06D5\u0646\u062F \u0647\u06CE\u0646\u062F\u06D5 \u0628\u06CE\u062A \u0628\u06C6 ${t.divisor}`;
      case "unrecognized_keys":
        return `\u06A9\u0644\u06CC\u0644\u06CC \u0646\u06D5\u0646\u0627\u0633\u0631\u0627\u0648: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `\u06A9\u0644\u06CC\u0644\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A \u0644\u06D5 ${t.origin}`;
      case "invalid_union":
        return t.options && Array.isArray(t.options) && t.options.length > 0 ? `\u0628\u06D5\u0647\u0627\u06CC \u0646\u06D5\u0646\u0627\u0633\u0631\u0627\u0648 \u0647\u06D5\u06CC\u06D5. \u0628\u06D5\u0647\u0627\u06CC \u0686\u0627\u0648\u06D5\u0695\u0648\u0627\u0646\u06A9\u0631\u0627\u0648: ${t.options.map((a) => `'${a}'`).join(" | ")}` : "\u06CC\u06D5\u06A9\u06AF\u0631\u062A\u0646\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A";
      case "invalid_element":
        return `${t.origin} \u0628\u06D5\u0647\u0627\u06A9\u06D5 \u0646\u0627\u062F\u0631\u0648\u0633\u062A\u06D5`;
      default:
        return "\u062A\u06CE\u06A9\u0631\u062F\u06D5\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A";
    }
  };
}, "error");
function xu() {
  return {
    localeError: ly()
  };
}
s(xu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/cs.js
var dy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "znak\u016F", verb: "m\xEDt" },
    file: { unit: "bajt\u016F", verb: "m\xEDt" },
    array: { unit: "prvk\u016F", verb: "m\xEDt" },
    set: { unit: "prvk\u016F", verb: "m\xEDt" },
    map: { unit: "prvk\u016F", verb: "m\xEDt" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "regul\xE1rn\xED v\xFDraz",
    email: "e-mailov\xE1 adresa",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "datum a \u010Das ve form\xE1tu ISO",
    date: "datum ve form\xE1tu ISO",
    time: "\u010Das ve form\xE1tu ISO",
    duration: "doba trv\xE1n\xED ISO",
    ipv4: "IPv4 adresa",
    ipv6: "IPv6 adresa",
    mac: "MAC adresa",
    cidrv4: "rozsah IPv4",
    cidrv6: "rozsah IPv6",
    base64: "\u0159et\u011Bzec zak\xF3dovan\xFD ve form\xE1tu base64",
    base64url: "\u0159et\u011Bzec zak\xF3dovan\xFD ve form\xE1tu base64url",
    json_string: "\u0159et\u011Bzec ve form\xE1tu JSON",
    e164: "\u010D\xEDslo E.164",
    credit_card: "\u010D\xEDslo kreditn\xED karty",
    jwt: "JWT",
    template_literal: "vstup"
  }, o = {
    nan: "NaN",
    number: "\u010D\xEDslo",
    string: "\u0159et\u011Bzec",
    function: "funkce",
    array: "pole"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Neplatn\xFD vstup: o\u010Dek\xE1v\xE1no instanceof ${t.expected}, obdr\u017Eeno ${u}` : `Neplatn\xFD vstup: o\u010Dek\xE1v\xE1no ${n}, obdr\u017Eeno ${u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Neplatn\xFD vstup: o\u010Dek\xE1v\xE1no ${$(t.values[0])}` : `Neplatn\xE1 mo\u017Enost: o\u010Dek\xE1v\xE1na jedna z hodnot ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Hodnota je p\u0159\xEDli\u0161 velk\xE1: ${t.origin ?? "hodnota"} mus\xED m\xEDt ${n}${t.maximum.toString()} ${a.unit ?? "prvk\u016F"}` : `Hodnota je p\u0159\xEDli\u0161 velk\xE1: ${t.origin ?? "hodnota"} mus\xED b\xFDt ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Hodnota je p\u0159\xEDli\u0161 mal\xE1: ${t.origin ?? "hodnota"} mus\xED m\xEDt ${n}${t.minimum.toString()} ${a.unit ?? "prvk\u016F"}` : `Hodnota je p\u0159\xEDli\u0161 mal\xE1: ${t.origin ?? "hodnota"} mus\xED b\xFDt ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Neplatn\xFD \u0159et\u011Bzec: mus\xED za\u010D\xEDnat na "${n.prefix}"` : n.format === "ends_with" ? `Neplatn\xFD \u0159et\u011Bzec: mus\xED kon\u010Dit na "${n.suffix}"` : n.format === "includes" ? `Neplatn\xFD \u0159et\u011Bzec: mus\xED obsahovat "${n.includes}"` : n.format === "regex" ? `Neplatn\xFD \u0159et\u011Bzec: mus\xED odpov\xEDdat vzoru ${n.pattern}` : `Neplatn\xFD form\xE1t ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Neplatn\xE9 \u010D\xEDslo: mus\xED b\xFDt n\xE1sobkem ${t.divisor}`;
      case "unrecognized_keys":
        return `Nezn\xE1m\xE9 kl\xED\u010De: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `Neplatn\xFD kl\xED\u010D v ${t.origin}`;
      case "invalid_union":
        return "Neplatn\xFD vstup";
      case "invalid_element":
        return `Neplatn\xE1 hodnota v ${t.origin}`;
      default:
        return "Neplatn\xFD vstup";
    }
  };
}, "error");
function wu() {
  return {
    localeError: dy()
  };
}
s(wu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/da.js
var fy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "tegn", verb: "havde" },
    file: { unit: "bytes", verb: "havde" },
    array: { unit: "elementer", verb: "indeholdt" },
    set: { unit: "elementer", verb: "indeholdt" },
    map: { unit: "elementer", verb: "indeholdt" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "input",
    email: "e-mailadresse",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO dato- og klokkesl\xE6t",
    date: "ISO-dato",
    time: "ISO-klokkesl\xE6t",
    duration: "ISO-varighed",
    ipv4: "IPv4-adresse",
    ipv6: "IPv6-adresse",
    mac: "MAC-adresse",
    cidrv4: "IPv4-spektrum",
    cidrv6: "IPv6-spektrum",
    base64: "base64-kodet streng",
    base64url: "base64url-kodet streng",
    json_string: "JSON-streng",
    e164: "E.164-nummer",
    credit_card: "kreditkortnummer",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN",
    string: "streng",
    number: "tal",
    boolean: "boolean",
    array: "liste",
    object: "objekt",
    set: "s\xE6t",
    file: "fil"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Ugyldigt input: forventede instanceof ${t.expected}, fik ${u}` : `Ugyldigt input: forventede ${n}, fik ${u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Ugyldig v\xE6rdi: forventede ${$(t.values[0])}` : `Ugyldigt valg: forventede en af f\xF8lgende ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin), u = o[t.origin] ?? t.origin;
        return a ? `For stor: forventede ${u ?? "value"} ${a.verb} ${n} ${t.maximum.toString()} ${a.unit ?? "elementer"}` : `For stor: forventede ${u ?? "value"} havde ${n} ${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin), u = o[t.origin] ?? t.origin;
        return a ? `For lille: forventede ${u} ${a.verb} ${n} ${t.minimum.toString()} ${a.unit}` : `For lille: forventede ${u} havde ${n} ${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Ugyldig streng: skal starte med "${n.prefix}"` : n.format === "ends_with" ? `Ugyldig streng: skal ende med "${n.suffix}"` : n.format === "includes" ? `Ugyldig streng: skal indeholde "${n.includes}"` : n.format === "regex" ? `Ugyldig streng: skal matche m\xF8nsteret ${n.pattern}` : `Ugyldig ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Ugyldigt tal: skal v\xE6re deleligt med ${t.divisor}`;
      case "unrecognized_keys":
        return `${t.keys.length > 1 ? "Ukendte n\xF8gler" : "Ukendt n\xF8gle"}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `Ugyldig n\xF8gle i ${t.origin}`;
      case "invalid_union":
        return "Ugyldigt input: matcher ingen af de tilladte typer";
      case "invalid_element":
        return `Ugyldig v\xE6rdi i ${t.origin}`;
      default:
        return "Ugyldigt input";
    }
  };
}, "error");
function ku() {
  return {
    localeError: fy()
  };
}
s(ku, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/de.js
var py = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "Zeichen", verb: "zu haben" },
    file: { unit: "Bytes", verb: "zu haben" },
    array: { unit: "Elemente", verb: "zu haben" },
    set: { unit: "Elemente", verb: "zu haben" },
    map: { unit: "Elemente", verb: "zu haben" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "Eingabe",
    email: "E-Mail-Adresse",
    url: "URL",
    emoji: "Emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO-Datum und -Uhrzeit",
    date: "ISO-Datum",
    time: "ISO-Uhrzeit",
    duration: "ISO-Dauer",
    ipv4: "IPv4-Adresse",
    ipv6: "IPv6-Adresse",
    mac: "MAC-Adresse",
    cidrv4: "IPv4-Bereich",
    cidrv6: "IPv6-Bereich",
    base64: "Base64-codierter String",
    base64url: "Base64-URL-codierter String",
    json_string: "JSON-String",
    e164: "E.164-Nummer",
    credit_card: "Kreditkartennummer",
    jwt: "JWT",
    template_literal: "Eingabe"
  }, o = {
    nan: "NaN",
    number: "Zahl",
    array: "Array"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Ung\xFCltige Eingabe: erwartet instanceof ${t.expected}, erhalten ${u}` : `Ung\xFCltige Eingabe: erwartet ${n}, erhalten ${u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Ung\xFCltige Eingabe: erwartet ${$(t.values[0])}` : `Ung\xFCltige Option: erwartet eine von ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Zu gro\xDF: erwartet, dass ${t.origin ?? "Wert"} ${n}${t.maximum.toString()} ${a.unit ?? "Elemente"} hat` : `Zu gro\xDF: erwartet, dass ${t.origin ?? "Wert"} ${n}${t.maximum.toString()} ist`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Zu klein: erwartet, dass ${t.origin} ${n}${t.minimum.toString()} ${a.unit} hat` : `Zu klein: erwartet, dass ${t.origin} ${n}${t.minimum.toString()} ist`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Ung\xFCltiger String: muss mit "${n.prefix}" beginnen` : n.format === "ends_with" ? `Ung\xFCltiger String: muss mit "${n.suffix}" enden` : n.format === "includes" ? `Ung\xFCltiger String: muss "${n.includes}" enthalten` : n.format === "regex" ? `Ung\xFCltiger String: muss dem Muster ${n.pattern} entsprechen` : `Ung\xFCltig: ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Ung\xFCltige Zahl: muss ein Vielfaches von ${t.divisor} sein`;
      case "unrecognized_keys":
        return `${t.keys.length > 1 ? "Unbekannte Schl\xFCssel" : "Unbekannter Schl\xFCssel"}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `Ung\xFCltiger Schl\xFCssel in ${t.origin}`;
      case "invalid_union":
        return "Ung\xFCltige Eingabe";
      case "invalid_element":
        return `Ung\xFCltiger Wert in ${t.origin}`;
      default:
        return "Ung\xFCltige Eingabe";
    }
  };
}, "error");
function Iu() {
  return {
    localeError: py()
  };
}
s(Iu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/el.js
var my = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u03C7\u03B1\u03C1\u03B1\u03BA\u03C4\u03AE\u03C1\u03B5\u03C2", verb: "\u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9" },
    file: { unit: "bytes", verb: "\u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9" },
    array: { unit: "\u03C3\u03C4\u03BF\u03B9\u03C7\u03B5\u03AF\u03B1", verb: "\u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9" },
    set: { unit: "\u03C3\u03C4\u03BF\u03B9\u03C7\u03B5\u03AF\u03B1", verb: "\u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9" },
    map: { unit: "\u03BA\u03B1\u03C4\u03B1\u03C7\u03C9\u03C1\u03AE\u03C3\u03B5\u03B9\u03C2", verb: "\u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2",
    email: "\u03B4\u03B9\u03B5\u03CD\u03B8\u03C5\u03BD\u03C3\u03B7 email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u03B7\u03BC\u03B5\u03C1\u03BF\u03BC\u03B7\u03BD\u03AF\u03B1 \u03BA\u03B1\u03B9 \u03CE\u03C1\u03B1",
    date: "ISO \u03B7\u03BC\u03B5\u03C1\u03BF\u03BC\u03B7\u03BD\u03AF\u03B1",
    time: "ISO \u03CE\u03C1\u03B1",
    duration: "ISO \u03B4\u03B9\u03AC\u03C1\u03BA\u03B5\u03B9\u03B1",
    ipv4: "\u03B4\u03B9\u03B5\u03CD\u03B8\u03C5\u03BD\u03C3\u03B7 IPv4",
    ipv6: "\u03B4\u03B9\u03B5\u03CD\u03B8\u03C5\u03BD\u03C3\u03B7 IPv6",
    mac: "\u03B4\u03B9\u03B5\u03CD\u03B8\u03C5\u03BD\u03C3\u03B7 MAC",
    cidrv4: "\u03B5\u03CD\u03C1\u03BF\u03C2 IPv4",
    cidrv6: "\u03B5\u03CD\u03C1\u03BF\u03C2 IPv6",
    base64: "\u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC \u03BA\u03C9\u03B4\u03B9\u03BA\u03BF\u03C0\u03BF\u03B9\u03B7\u03BC\u03AD\u03BD\u03B7 \u03C3\u03B5 base64",
    base64url: "\u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC \u03BA\u03C9\u03B4\u03B9\u03BA\u03BF\u03C0\u03BF\u03B9\u03B7\u03BC\u03AD\u03BD\u03B7 \u03C3\u03B5 base64url",
    json_string: "\u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC JSON",
    e164: "\u03B1\u03C1\u03B9\u03B8\u03BC\u03CC\u03C2 E.164",
    credit_card: "\u03B1\u03C1\u03B9\u03B8\u03BC\u03CC\u03C2 \u03C0\u03B9\u03C3\u03C4\u03C9\u03C4\u03B9\u03BA\u03AE\u03C2 \u03BA\u03AC\u03C1\u03C4\u03B1\u03C2",
    jwt: "JWT",
    template_literal: "\u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2"
  }, o = {
    nan: "NaN"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return typeof t.expected == "string" && /^[A-Z]/.test(t.expected) ? `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD instanceof ${t.expected}, \u03BB\u03AE\u03C6\u03B8\u03B7\u03BA\u03B5 ${u}` : `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${n}, \u03BB\u03AE\u03C6\u03B8\u03B7\u03BA\u03B5 ${u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${$(t.values[0])}` : `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03C0\u03B9\u03BB\u03BF\u03B3\u03AE: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD \u03AD\u03BD\u03B1 \u03B1\u03C0\u03CC ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u03A0\u03BF\u03BB\u03CD \u03BC\u03B5\u03B3\u03AC\u03BB\u03BF: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${t.origin ?? "\u03C4\u03B9\u03BC\u03AE"} \u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9 ${n}${t.maximum.toString()} ${a.unit ?? "\u03C3\u03C4\u03BF\u03B9\u03C7\u03B5\u03AF\u03B1"}` : `\u03A0\u03BF\u03BB\u03CD \u03BC\u03B5\u03B3\u03AC\u03BB\u03BF: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${t.origin ?? "\u03C4\u03B9\u03BC\u03AE"} \u03BD\u03B1 \u03B5\u03AF\u03BD\u03B1\u03B9 ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u03A0\u03BF\u03BB\u03CD \u03BC\u03B9\u03BA\u03C1\u03CC: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${t.origin} \u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9 ${n}${t.minimum.toString()} ${a.unit}` : `\u03A0\u03BF\u03BB\u03CD \u03BC\u03B9\u03BA\u03C1\u03CC: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${t.origin} \u03BD\u03B1 \u03B5\u03AF\u03BD\u03B1\u03B9 ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC: \u03C0\u03C1\u03AD\u03C0\u03B5\u03B9 \u03BD\u03B1 \u03BE\u03B5\u03BA\u03B9\u03BD\u03AC \u03BC\u03B5 "${n.prefix}"` : n.format === "ends_with" ? `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC: \u03C0\u03C1\u03AD\u03C0\u03B5\u03B9 \u03BD\u03B1 \u03C4\u03B5\u03BB\u03B5\u03B9\u03CE\u03BD\u03B5\u03B9 \u03BC\u03B5 "${n.suffix}"` : n.format === "includes" ? `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC: \u03C0\u03C1\u03AD\u03C0\u03B5\u03B9 \u03BD\u03B1 \u03C0\u03B5\u03C1\u03B9\u03AD\u03C7\u03B5\u03B9 "${n.includes}"` : n.format === "regex" ? `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC: \u03C0\u03C1\u03AD\u03C0\u03B5\u03B9 \u03BD\u03B1 \u03C4\u03B1\u03B9\u03C1\u03B9\u03AC\u03B6\u03B5\u03B9 \u03BC\u03B5 \u03C4\u03BF \u03BC\u03BF\u03C4\u03AF\u03B2\u03BF ${n.pattern}` : `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03BF: ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03BF\u03C2 \u03B1\u03C1\u03B9\u03B8\u03BC\u03CC\u03C2: \u03C0\u03C1\u03AD\u03C0\u03B5\u03B9 \u03BD\u03B1 \u03B5\u03AF\u03BD\u03B1\u03B9 \u03C0\u03BF\u03BB\u03BB\u03B1\u03C0\u03BB\u03AC\u03C3\u03B9\u03BF \u03C4\u03BF\u03C5 ${t.divisor}`;
      case "unrecognized_keys":
        return `\u0386\u03B3\u03BD\u03C9\u03C3\u03C4${t.keys.length > 1 ? "\u03B1" : "\u03BF"} \u03BA\u03BB\u03B5\u03B9\u03B4${t.keys.length > 1 ? "\u03B9\u03AC" : "\u03AF"}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03BF \u03BA\u03BB\u03B5\u03B9\u03B4\u03AF \u03C3\u03C4\u03BF ${t.origin}`;
      case "invalid_union":
        return "\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2";
      case "invalid_element":
        return `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03C4\u03B9\u03BC\u03AE \u03C3\u03C4\u03BF ${t.origin}`;
      default:
        return "\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2";
    }
  };
}, "error");
function zu() {
  return {
    localeError: my()
  };
}
s(zu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/en.js
var gy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "characters", verb: "to have" },
    file: { unit: "bytes", verb: "to have" },
    array: { unit: "items", verb: "to have" },
    set: { unit: "items", verb: "to have" },
    map: { unit: "entries", verb: "to have" }
  };
  function r(n) {
    return e[n] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "input",
    email: "email address",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datetime",
    date: "ISO date",
    time: "ISO time",
    duration: "ISO duration",
    ipv4: "IPv4 address",
    ipv6: "IPv6 address",
    mac: "MAC address",
    cidrv4: "IPv4 range",
    cidrv6: "IPv6 range",
    base64: "base64-encoded string",
    base64url: "base64url-encoded string",
    json_string: "JSON string",
    e164: "E.164 number",
    credit_card: "credit card number",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    // Compatibility: "nan" -> "NaN" for display
    nan: "NaN"
    // All other type names omitted - they fall back to raw values via ?? operator
  };
  function t(n, a) {
    return n === "number" && typeof a == "number" && !Number.isFinite(a) ? String(a) : o[n] ?? n;
  }
  return s(t, "getTypeName"), (n) => {
    switch (n.code) {
      case "invalid_type": {
        let a = t(n.expected), u = b(n.input), c = t(u, n.input);
        return `Invalid input: expected ${a}, received ${c}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `Invalid input: expected ${$(n.values[0])}` : `Invalid option: expected one of ${g(n.values, "|")}`;
      case "too_big": {
        let a = n.exact ? "exactly " : n.inclusive ? "<=" : "<", u = r(n.origin);
        return u ? `Too big: expected ${n.origin ?? "value"} to have ${a}${n.maximum.toString()} ${u.unit ?? "elements"}` : `Too big: expected ${n.origin ?? "value"} to be ${a}${n.maximum.toString()}`;
      }
      case "too_small": {
        let a = n.exact ? "exactly " : n.inclusive ? ">=" : ">", u = r(n.origin);
        return u ? `Too small: expected ${n.origin} to have ${a}${n.minimum.toString()} ${u.unit}` : `Too small: expected ${n.origin} to be ${a}${n.minimum.toString()}`;
      }
      case "invalid_format": {
        let a = n;
        return a.format === "starts_with" ? `Invalid string: must start with "${a.prefix}"` : a.format === "ends_with" ? `Invalid string: must end with "${a.suffix}"` : a.format === "includes" ? `Invalid string: must include "${a.includes}"` : a.format === "regex" ? `Invalid string: must match pattern ${a.pattern}` : `Invalid ${i[a.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `Invalid number: must be a multiple of ${n.divisor}`;
      case "unrecognized_keys":
        return `Unrecognized key${n.keys.length > 1 ? "s" : ""}: ${g(n.keys, ", ")}`;
      case "invalid_key":
        return `Invalid key in ${n.origin}`;
      case "invalid_union":
        return n.options && Array.isArray(n.options) && n.options.length > 0 ? `Invalid discriminator value. Expected ${n.options.map((u) => `'${u}'`).join(" | ")}` : n.inclusive === !1 ? "Invalid input: more than one option matched" : "Invalid input";
      case "invalid_element":
        return `Invalid value in ${n.origin}`;
      default:
        return "Invalid input";
    }
  };
}, "error");
function Ur() {
  return {
    localeError: gy()
  };
}
s(Ur, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/eo.js
var hy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "karaktrojn", verb: "havi" },
    file: { unit: "bajtojn", verb: "havi" },
    array: { unit: "elementojn", verb: "havi" },
    set: { unit: "elementojn", verb: "havi" },
    map: { unit: "elementojn", verb: "havi" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "enigo",
    email: "retadreso",
    url: "URL",
    emoji: "emo\u011Dio",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO-datotempo",
    date: "ISO-dato",
    time: "ISO-tempo",
    duration: "ISO-da\u016Dro",
    ipv4: "IPv4-adreso",
    ipv6: "IPv6-adreso",
    mac: "MAC-adreso",
    cidrv4: "IPv4-rango",
    cidrv6: "IPv6-rango",
    base64: "64-ume kodita karaktraro",
    base64url: "URL-64-ume kodita karaktraro",
    json_string: "JSON-karaktraro",
    e164: "E.164-nombro",
    credit_card: "kreditkarta numero",
    jwt: "JWT",
    template_literal: "enigo"
  }, o = {
    nan: "NaN",
    number: "nombro",
    array: "tabelo",
    null: "senvalora"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Nevalida enigo: atendi\u011Dis instanceof ${t.expected}, ricevi\u011Dis ${u}` : `Nevalida enigo: atendi\u011Dis ${n}, ricevi\u011Dis ${u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Nevalida enigo: atendi\u011Dis ${$(t.values[0])}` : `Nevalida opcio: atendi\u011Dis unu el ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Tro granda: atendi\u011Dis ke ${t.origin ?? "valoro"} havu ${n}${t.maximum.toString()} ${a.unit ?? "elementojn"}` : `Tro granda: atendi\u011Dis ke ${t.origin ?? "valoro"} havu ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Tro malgranda: atendi\u011Dis ke ${t.origin} havu ${n}${t.minimum.toString()} ${a.unit}` : `Tro malgranda: atendi\u011Dis ke ${t.origin} estu ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Nevalida karaktraro: devas komenci\u011Di per "${n.prefix}"` : n.format === "ends_with" ? `Nevalida karaktraro: devas fini\u011Di per "${n.suffix}"` : n.format === "includes" ? `Nevalida karaktraro: devas inkluzivi "${n.includes}"` : n.format === "regex" ? `Nevalida karaktraro: devas kongrui kun la modelo ${n.pattern}` : `Nevalida ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Nevalida nombro: devas esti oblo de ${t.divisor}`;
      case "unrecognized_keys":
        return `Nekonata${t.keys.length > 1 ? "j" : ""} \u015Dlosilo${t.keys.length > 1 ? "j" : ""}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `Nevalida \u015Dlosilo en ${t.origin}`;
      case "invalid_union":
        return "Nevalida enigo";
      case "invalid_element":
        return `Nevalida valoro en ${t.origin}`;
      default:
        return "Nevalida enigo";
    }
  };
}, "error");
function Su() {
  return {
    localeError: hy()
  };
}
s(Su, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/es.js
var vy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "caracteres", verb: "tener" },
    file: { unit: "bytes", verb: "tener" },
    array: { unit: "elementos", verb: "tener" },
    set: { unit: "elementos", verb: "tener" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "entrada",
    email: "direcci\xF3n de correo electr\xF3nico",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "fecha y hora ISO",
    date: "fecha ISO",
    time: "hora ISO",
    duration: "duraci\xF3n ISO",
    ipv4: "direcci\xF3n IPv4",
    ipv6: "direcci\xF3n IPv6",
    mac: "direcci\xF3n MAC",
    cidrv4: "rango IPv4",
    cidrv6: "rango IPv6",
    base64: "cadena codificada en base64",
    base64url: "URL codificada en base64",
    json_string: "cadena JSON",
    e164: "n\xFAmero E.164",
    credit_card: "n\xFAmero de tarjeta de cr\xE9dito",
    jwt: "JWT",
    template_literal: "entrada"
  }, o = {
    nan: "NaN",
    string: "texto",
    number: "n\xFAmero",
    boolean: "booleano",
    array: "arreglo",
    object: "objeto",
    set: "conjunto",
    file: "archivo",
    date: "fecha",
    bigint: "n\xFAmero grande",
    symbol: "s\xEDmbolo",
    undefined: "indefinido",
    null: "nulo",
    function: "funci\xF3n",
    map: "mapa",
    record: "registro",
    tuple: "tupla",
    enum: "enumeraci\xF3n",
    union: "uni\xF3n",
    literal: "literal",
    promise: "promesa",
    void: "vac\xEDo",
    never: "nunca",
    unknown: "desconocido",
    any: "cualquiera"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Entrada inv\xE1lida: se esperaba instanceof ${t.expected}, recibido ${u}` : `Entrada inv\xE1lida: se esperaba ${n}, recibido ${u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Entrada inv\xE1lida: se esperaba ${$(t.values[0])}` : `Opci\xF3n inv\xE1lida: se esperaba una de ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin), u = o[t.origin] ?? t.origin;
        return a ? `Demasiado grande: se esperaba que ${u ?? "valor"} tuviera ${n}${t.maximum.toString()} ${a.unit ?? "elementos"}` : `Demasiado grande: se esperaba que ${u ?? "valor"} fuera ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin), u = o[t.origin] ?? t.origin;
        return a ? `Demasiado peque\xF1o: se esperaba que ${u} tuviera ${n}${t.minimum.toString()} ${a.unit}` : `Demasiado peque\xF1o: se esperaba que ${u} fuera ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Cadena inv\xE1lida: debe comenzar con "${n.prefix}"` : n.format === "ends_with" ? `Cadena inv\xE1lida: debe terminar en "${n.suffix}"` : n.format === "includes" ? `Cadena inv\xE1lida: debe incluir "${n.includes}"` : n.format === "regex" ? `Cadena inv\xE1lida: debe coincidir con el patr\xF3n ${n.pattern}` : `Inv\xE1lido ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `N\xFAmero inv\xE1lido: debe ser m\xFAltiplo de ${t.divisor}`;
      case "unrecognized_keys":
        return `Llave${t.keys.length > 1 ? "s" : ""} desconocida${t.keys.length > 1 ? "s" : ""}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `Llave inv\xE1lida en ${o[t.origin] ?? t.origin}`;
      case "invalid_union":
        return "Entrada inv\xE1lida";
      case "invalid_element":
        return `Valor inv\xE1lido en ${o[t.origin] ?? t.origin}`;
      default:
        return "Entrada inv\xE1lida";
    }
  };
}, "error");
function Ou() {
  return {
    localeError: vy()
  };
}
s(Ou, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/fa.js
var yy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u06A9\u0627\u0631\u0627\u06A9\u062A\u0631", verb: "\u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F" },
    file: { unit: "\u0628\u0627\u06CC\u062A", verb: "\u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F" },
    array: { unit: "\u0622\u06CC\u062A\u0645", verb: "\u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F" },
    set: { unit: "\u0622\u06CC\u062A\u0645", verb: "\u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F" },
    map: { unit: "\u0622\u06CC\u062A\u0645", verb: "\u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u0648\u0631\u0648\u062F\u06CC",
    email: "\u0622\u062F\u0631\u0633 \u0627\u06CC\u0645\u06CC\u0644",
    url: "URL",
    emoji: "\u0627\u06CC\u0645\u0648\u062C\u06CC",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u062A\u0627\u0631\u06CC\u062E \u0648 \u0632\u0645\u0627\u0646 \u0627\u06CC\u0632\u0648",
    date: "\u062A\u0627\u0631\u06CC\u062E \u0627\u06CC\u0632\u0648",
    time: "\u0632\u0645\u0627\u0646 \u0627\u06CC\u0632\u0648",
    duration: "\u0645\u062F\u062A \u0632\u0645\u0627\u0646 \u0627\u06CC\u0632\u0648",
    ipv4: "IPv4 \u0622\u062F\u0631\u0633",
    ipv6: "IPv6 \u0622\u062F\u0631\u0633",
    mac: "MAC \u0622\u062F\u0631\u0633",
    cidrv4: "IPv4 \u062F\u0627\u0645\u0646\u0647",
    cidrv6: "IPv6 \u062F\u0627\u0645\u0646\u0647",
    base64: "base64-encoded \u0631\u0634\u062A\u0647",
    base64url: "base64url-encoded \u0631\u0634\u062A\u0647",
    json_string: "JSON \u0631\u0634\u062A\u0647",
    e164: "E.164 \u0639\u062F\u062F",
    credit_card: "\u0634\u0645\u0627\u0631\u0647 \u06A9\u0627\u0631\u062A \u0627\u0639\u062A\u0628\u0627\u0631\u06CC",
    jwt: "JWT",
    template_literal: "\u0648\u0631\u0648\u062F\u06CC"
  }, o = {
    nan: "NaN",
    number: "\u0639\u062F\u062F",
    array: "\u0622\u0631\u0627\u06CC\u0647"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0645\u06CC\u200C\u0628\u0627\u06CC\u0633\u062A instanceof ${t.expected} \u0645\u06CC\u200C\u0628\u0648\u062F\u060C ${u} \u062F\u0631\u06CC\u0627\u0641\u062A \u0634\u062F` : `\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0645\u06CC\u200C\u0628\u0627\u06CC\u0633\u062A ${n} \u0645\u06CC\u200C\u0628\u0648\u062F\u060C ${u} \u062F\u0631\u06CC\u0627\u0641\u062A \u0634\u062F`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0645\u06CC\u200C\u0628\u0627\u06CC\u0633\u062A ${$(t.values[0])} \u0645\u06CC\u200C\u0628\u0648\u062F` : `\u06AF\u0632\u06CC\u0646\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0645\u06CC\u200C\u0628\u0627\u06CC\u0633\u062A \u06CC\u06A9\u06CC \u0627\u0632 ${g(t.values, "|")} \u0645\u06CC\u200C\u0628\u0648\u062F`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u062E\u06CC\u0644\u06CC \u0628\u0632\u0631\u06AF: ${t.origin ?? "\u0645\u0642\u062F\u0627\u0631"} \u0628\u0627\u06CC\u062F ${n}${t.maximum.toString()} ${a.unit ?? "\u0639\u0646\u0635\u0631"} \u0628\u0627\u0634\u062F` : `\u062E\u06CC\u0644\u06CC \u0628\u0632\u0631\u06AF: ${t.origin ?? "\u0645\u0642\u062F\u0627\u0631"} \u0628\u0627\u06CC\u062F ${n}${t.maximum.toString()} \u0628\u0627\u0634\u062F`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u062E\u06CC\u0644\u06CC \u06A9\u0648\u0686\u06A9: ${t.origin} \u0628\u0627\u06CC\u062F ${n}${t.minimum.toString()} ${a.unit} \u0628\u0627\u0634\u062F` : `\u062E\u06CC\u0644\u06CC \u06A9\u0648\u0686\u06A9: ${t.origin} \u0628\u0627\u06CC\u062F ${n}${t.minimum.toString()} \u0628\u0627\u0634\u062F`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u0631\u0634\u062A\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0628\u0627 "${n.prefix}" \u0634\u0631\u0648\u0639 \u0634\u0648\u062F` : n.format === "ends_with" ? `\u0631\u0634\u062A\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0628\u0627 "${n.suffix}" \u062A\u0645\u0627\u0645 \u0634\u0648\u062F` : n.format === "includes" ? `\u0631\u0634\u062A\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0634\u0627\u0645\u0644 "${n.includes}" \u0628\u0627\u0634\u062F` : n.format === "regex" ? `\u0631\u0634\u062A\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0628\u0627 \u0627\u0644\u06AF\u0648\u06CC ${n.pattern} \u0645\u0637\u0627\u0628\u0642\u062A \u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F` : `${i[n.format] ?? t.format} \u0646\u0627\u0645\u0639\u062A\u0628\u0631`;
      }
      case "not_multiple_of":
        return `\u0639\u062F\u062F \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0645\u0636\u0631\u0628 ${t.divisor} \u0628\u0627\u0634\u062F`;
      case "unrecognized_keys":
        return `\u06A9\u0644\u06CC\u062F${t.keys.length > 1 ? "\u0647\u0627\u06CC" : ""} \u0646\u0627\u0634\u0646\u0627\u0633: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `\u06A9\u0644\u06CC\u062F \u0646\u0627\u0634\u0646\u0627\u0633 \u062F\u0631 ${t.origin}`;
      case "invalid_union":
        return "\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631";
      case "invalid_element":
        return `\u0645\u0642\u062F\u0627\u0631 \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u062F\u0631 ${t.origin}`;
      default:
        return "\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631";
    }
  };
}, "error");
function ju() {
  return {
    localeError: yy()
  };
}
s(ju, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/fi.js
var $y = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "merkki\xE4", subject: "merkkijonon" },
    file: { unit: "tavua", subject: "tiedoston" },
    array: { unit: "alkiota", subject: "listan" },
    set: { unit: "alkiota", subject: "joukon" },
    map: { unit: "alkiota", subject: "kuvauksen" },
    number: { unit: "", subject: "luvun" },
    bigint: { unit: "", subject: "suuren kokonaisluvun" },
    int: { unit: "", subject: "kokonaisluvun" },
    date: { unit: "", subject: "p\xE4iv\xE4m\xE4\xE4r\xE4n" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "s\xE4\xE4nn\xF6llinen lauseke",
    email: "s\xE4hk\xF6postiosoite",
    url: "URL-osoite",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO-aikaleima",
    date: "ISO-p\xE4iv\xE4m\xE4\xE4r\xE4",
    time: "ISO-aika",
    duration: "ISO-kesto",
    ipv4: "IPv4-osoite",
    ipv6: "IPv6-osoite",
    mac: "MAC-osoite",
    cidrv4: "IPv4-alue",
    cidrv6: "IPv6-alue",
    base64: "base64-koodattu merkkijono",
    base64url: "base64url-koodattu merkkijono",
    json_string: "JSON-merkkijono",
    e164: "E.164-luku",
    credit_card: "luottokortin numero",
    jwt: "JWT",
    template_literal: "templaattimerkkijono"
  }, o = {
    nan: "NaN"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Virheellinen tyyppi: odotettiin instanceof ${t.expected}, oli ${u}` : `Virheellinen tyyppi: odotettiin ${n}, oli ${u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Virheellinen sy\xF6te: t\xE4ytyy olla ${$(t.values[0])}` : `Virheellinen valinta: t\xE4ytyy olla yksi seuraavista: ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Liian suuri: ${a.subject} t\xE4ytyy olla ${n}${t.maximum.toString()} ${a.unit}`.trim() : `Liian suuri: arvon t\xE4ytyy olla ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Liian pieni: ${a.subject} t\xE4ytyy olla ${n}${t.minimum.toString()} ${a.unit}`.trim() : `Liian pieni: arvon t\xE4ytyy olla ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Virheellinen sy\xF6te: t\xE4ytyy alkaa "${n.prefix}"` : n.format === "ends_with" ? `Virheellinen sy\xF6te: t\xE4ytyy loppua "${n.suffix}"` : n.format === "includes" ? `Virheellinen sy\xF6te: t\xE4ytyy sis\xE4lt\xE4\xE4 "${n.includes}"` : n.format === "regex" ? `Virheellinen sy\xF6te: t\xE4ytyy vastata s\xE4\xE4nn\xF6llist\xE4 lauseketta ${n.pattern}` : `Virheellinen ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Virheellinen luku: t\xE4ytyy olla luvun ${t.divisor} monikerta`;
      case "unrecognized_keys":
        return `${t.keys.length > 1 ? "Tuntemattomat avaimet" : "Tuntematon avain"}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return "Virheellinen avain tietueessa";
      case "invalid_union":
        return "Virheellinen unioni";
      case "invalid_element":
        return "Virheellinen arvo joukossa";
      default:
        return "Virheellinen sy\xF6te";
    }
  };
}, "error");
function Pu() {
  return {
    localeError: $y()
  };
}
s(Pu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/fr.js
var by = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "caract\xE8res", verb: "avoir" },
    file: { unit: "octets", verb: "avoir" },
    array: { unit: "\xE9l\xE9ments", verb: "avoir" },
    set: { unit: "\xE9l\xE9ments", verb: "avoir" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "expression r\xE9guli\xE8re",
    email: "adresse e-mail",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "date et heure ISO",
    date: "date ISO",
    time: "heure ISO",
    duration: "dur\xE9e ISO",
    ipv4: "adresse IPv4",
    ipv6: "adresse IPv6",
    mac: "adresse MAC",
    cidrv4: "plage IPv4",
    cidrv6: "plage IPv6",
    base64: "cha\xEEne de caract\xE8res encod\xE9e en base64",
    base64url: "cha\xEEne de caract\xE8res encod\xE9e en base64url",
    json_string: "cha\xEEne de caract\xE8res JSON",
    e164: "num\xE9ro au format E.164",
    credit_card: "num\xE9ro de carte de cr\xE9dit",
    jwt: "JWT",
    template_literal: "entr\xE9e"
  }, o = {
    string: "cha\xEEne de caract\xE8res",
    number: "nombre",
    int: "entier",
    boolean: "bool\xE9en",
    bigint: "grand entier",
    symbol: "symbole",
    undefined: "ind\xE9fini",
    null: "null",
    never: "jamais",
    void: "vide",
    date: "date",
    array: "tableau",
    object: "objet",
    tuple: "tuple",
    record: "record",
    map: "map",
    set: "ensemble",
    file: "fichier",
    nonoptional: "non optionnel",
    nan: "NaN",
    function: "fonction"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Entr\xE9e invalide : instance de ${t.expected} attendu, ${u} re\xE7u` : `Entr\xE9e invalide : ${n} attendu, ${u} re\xE7u`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Entr\xE9e invalide : ${$(t.values[0])} attendu` : `Option invalide : une valeur parmi ${g(t.values, "|")} attendue`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Trop grand : ${o[t.origin] ?? "valeur"} doit ${a.verb} ${n}${t.maximum.toString()} ${a.unit ?? "\xE9l\xE9ment(s)"}` : `Trop grand : ${o[t.origin] ?? "valeur"} doit \xEAtre ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Trop petit : ${o[t.origin] ?? "valeur"} doit ${a.verb} ${n}${t.minimum.toString()} ${a.unit}` : `Trop petit : ${o[t.origin] ?? "valeur"} doit \xEAtre ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Cha\xEEne de caract\xE8res invalide : doit commencer par "${n.prefix}"` : n.format === "ends_with" ? `Cha\xEEne de caract\xE8res invalide : doit se terminer par "${n.suffix}"` : n.format === "includes" ? `Cha\xEEne de caract\xE8res invalide : doit inclure "${n.includes}"` : n.format === "regex" ? `Cha\xEEne de caract\xE8res invalide : doit correspondre au motif ${n.pattern}` : `${i[n.format] ?? t.format} invalide`;
      }
      case "not_multiple_of":
        return `Nombre invalide : doit \xEAtre un multiple de ${t.divisor}`;
      case "unrecognized_keys":
        return `Cl\xE9${t.keys.length > 1 ? "s" : ""} non reconnue${t.keys.length > 1 ? "s" : ""} : ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `Cl\xE9 invalide dans ${t.origin}`;
      case "invalid_union":
        return "Entr\xE9e invalide";
      case "invalid_element":
        return `Valeur invalide dans ${t.origin}`;
      default:
        return "Entr\xE9e invalide";
    }
  };
}, "error");
function Du() {
  return {
    localeError: by()
  };
}
s(Du, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/fr-CA.js
var _y = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "caract\xE8res", verb: "avoir" },
    file: { unit: "octets", verb: "avoir" },
    array: { unit: "\xE9l\xE9ments", verb: "avoir" },
    set: { unit: "\xE9l\xE9ments", verb: "avoir" },
    map: { unit: "\xE9l\xE9ments", verb: "avoir" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "entr\xE9e",
    email: "adresse courriel",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "date-heure ISO",
    date: "date ISO",
    time: "heure ISO",
    duration: "dur\xE9e ISO",
    ipv4: "adresse IPv4",
    ipv6: "adresse IPv6",
    mac: "adresse MAC",
    cidrv4: "plage IPv4",
    cidrv6: "plage IPv6",
    base64: "cha\xEEne encod\xE9e en base64",
    base64url: "cha\xEEne encod\xE9e en base64url",
    json_string: "cha\xEEne JSON",
    e164: "num\xE9ro E.164",
    credit_card: "num\xE9ro de carte de cr\xE9dit",
    jwt: "JWT",
    template_literal: "entr\xE9e"
  }, o = {
    nan: "NaN"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Entr\xE9e invalide : attendu instanceof ${t.expected}, re\xE7u ${u}` : `Entr\xE9e invalide : attendu ${n}, re\xE7u ${u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Entr\xE9e invalide : attendu ${$(t.values[0])}` : `Option invalide : attendu l'une des valeurs suivantes ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "\u2264" : "<", a = r(t.origin);
        return a ? `Trop grand : attendu que ${t.origin ?? "la valeur"} ait ${n}${t.maximum.toString()} ${a.unit}` : `Trop grand : attendu que ${t.origin ?? "la valeur"} soit ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? "\u2265" : ">", a = r(t.origin);
        return a ? `Trop petit : attendu que ${t.origin} ait ${n}${t.minimum.toString()} ${a.unit}` : `Trop petit : attendu que ${t.origin} soit ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Cha\xEEne invalide : doit commencer par "${n.prefix}"` : n.format === "ends_with" ? `Cha\xEEne invalide : doit se terminer par "${n.suffix}"` : n.format === "includes" ? `Cha\xEEne invalide : doit inclure "${n.includes}"` : n.format === "regex" ? `Cha\xEEne invalide : doit correspondre au motif ${n.pattern}` : `${i[n.format] ?? t.format} invalide`;
      }
      case "not_multiple_of":
        return `Nombre invalide : doit \xEAtre un multiple de ${t.divisor}`;
      case "unrecognized_keys":
        return `Cl\xE9${t.keys.length > 1 ? "s" : ""} non reconnue${t.keys.length > 1 ? "s" : ""} : ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `Cl\xE9 invalide dans ${t.origin}`;
      case "invalid_union":
        return "Entr\xE9e invalide";
      case "invalid_element":
        return `Valeur invalide dans ${t.origin}`;
      default:
        return "Entr\xE9e invalide";
    }
  };
}, "error");
function Nu() {
  return {
    localeError: _y()
  };
}
s(Nu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/gu.js
var xy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0A85\u0A95\u0ACD\u0AB7\u0AB0", verb: "\u0AB9\u0ACB\u0AB5\u0ABE \u0A9C\u0ACB\u0A88\u0A8F" },
    file: { unit: "\u0AAC\u0ABE\u0AAF\u0A9F", verb: "\u0AB9\u0ACB\u0AB5\u0ABE \u0A9C\u0ACB\u0A88\u0A8F" },
    array: { unit: "\u0A86\u0A87\u0A9F\u0AAE", verb: "\u0AB9\u0ACB\u0AB5\u0ABE \u0A9C\u0ACB\u0A88\u0A8F" },
    set: { unit: "\u0A86\u0A87\u0A9F\u0AAE", verb: "\u0AB9\u0ACB\u0AB5\u0ABE \u0A9C\u0ACB\u0A88\u0A8F" },
    map: { unit: "\u0A8F\u0AA8\u0ACD\u0A9F\u0ACD\u0AB0\u0AC0", verb: "\u0AB9\u0ACB\u0AB5\u0ABE \u0A9C\u0ACB\u0A88\u0A8F" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u0A87\u0AA8\u0AAA\u0AC1\u0A9F",
    email: "\u0A88\u0AAE\u0AC7\u0A87\u0AB2 \u0A8F\u0AA1\u0ACD\u0AB0\u0AC7\u0AB8",
    url: "URL",
    emoji: "\u0A87\u0AAE\u0ACB\u0A9C\u0AC0",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0AA4\u0ABE\u0AB0\u0AC0\u0A96 \u0A85\u0AA8\u0AC7 \u0AB8\u0AAE\u0AAF",
    date: "ISO \u0AA4\u0ABE\u0AB0\u0AC0\u0A96",
    time: "ISO \u0AB8\u0AAE\u0AAF",
    duration: "ISO \u0A85\u0AB5\u0AA7\u0ABF",
    ipv4: "IPv4 \u0A8F\u0AA1\u0ACD\u0AB0\u0AC7\u0AB8",
    ipv6: "IPv6 \u0A8F\u0AA1\u0ACD\u0AB0\u0AC7\u0AB8",
    mac: "MAC \u0A8F\u0AA1\u0ACD\u0AB0\u0AC7\u0AB8",
    cidrv4: "IPv4 \u0AB6\u0ACD\u0AB0\u0AC7\u0AA3\u0AC0",
    cidrv6: "IPv6 \u0AB6\u0ACD\u0AB0\u0AC7\u0AA3\u0AC0",
    base64: "base64-\u0A8F\u0AA8\u0ACD\u0A95\u0ACB\u0AA1\u0AC7\u0AA1 \u0AB8\u0ACD\u0A9F\u0ACD\u0AB0\u0ABF\u0A82\u0A97",
    base64url: "base64url-\u0A8F\u0AA8\u0ACD\u0A95\u0ACB\u0AA1\u0AC7\u0AA1 \u0AB8\u0ACD\u0A9F\u0ACD\u0AB0\u0ABF\u0A82\u0A97",
    json_string: "JSON \u0AB8\u0ACD\u0A9F\u0ACD\u0AB0\u0ABF\u0A82\u0A97",
    e164: "E.164 \u0AA8\u0A82\u0AAC\u0AB0",
    credit_card: "\u0A95\u0ACD\u0AB0\u0AC7\u0AA1\u0ABF\u0A9F \u0A95\u0ABE\u0AB0\u0ACD\u0AA1 \u0AA8\u0A82\u0AAC\u0AB0",
    jwt: "JWT",
    template_literal: "\u0A87\u0AA8\u0AAA\u0AC1\u0A9F"
  }, o = {
    nan: "NaN"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0A87\u0AA8\u0AAA\u0AC1\u0A9F: \u0A85\u0AAA\u0AC7\u0A95\u0ACD\u0AB7\u0ABF\u0AA4 ${n}, \u0AAA\u0ACD\u0AB0\u0ABE\u0AAA\u0ACD\u0AA4 ${u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0A87\u0AA8\u0AAA\u0AC1\u0A9F: \u0A85\u0AAA\u0AC7\u0A95\u0ACD\u0AB7\u0ABF\u0AA4 ${$(t.values[0])}` : `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AB5\u0ABF\u0A95\u0AB2\u0ACD\u0AAA: ${g(t.values, " | ")} \u0AAE\u0ABE\u0AA7\u0ACD\u0AAF\u0AAE\u0AA5\u0AC0 \u0A8F\u0A95 \u0A85\u0AAA\u0AC7\u0A95\u0ACD\u0AB7\u0ABF\u0AA4`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u0A96\u0AC2\u0AAC \u0AAE\u0ACB\u0A9F\u0AC1\u0A82: ${t.origin ?? "\u0AAE\u0AC2\u0AB2\u0ACD\u0AAF"} ${n}${t.maximum.toString()} ${a.unit ?? "\u0A8F\u0AB2\u0ABF\u0AAE\u0AC7\u0AA8\u0ACD\u0A9F"} \u0AB9\u0ACB\u0AB5\u0ABE \u0A9C\u0ACB\u0A88\u0A8F` : `\u0A96\u0AC2\u0AAC \u0AAE\u0ACB\u0A9F\u0AC1\u0A82: ${t.origin ?? "\u0AAE\u0AC2\u0AB2\u0ACD\u0AAF"} ${n}${t.maximum.toString()} \u0AB9\u0ACB\u0AB5\u0AC1\u0A82 \u0A9C\u0ACB\u0A88\u0A8F`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u0A96\u0AC2\u0AAC \u0AA8\u0ABE\u0AA8\u0AC1\u0A82: ${t.origin} ${n}${t.minimum.toString()} ${a.unit} \u0AB9\u0ACB\u0AB5\u0ABE \u0A9C\u0ACB\u0A88\u0A8F` : `\u0A96\u0AC2\u0AAC \u0AA8\u0ABE\u0AA8\u0AC1\u0A82: ${t.origin} ${n}${t.minimum.toString()} \u0AB9\u0ACB\u0AB5\u0AC1\u0A82 \u0A9C\u0ACB\u0A88\u0A8F`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AB8\u0ACD\u0A9F\u0ACD\u0AB0\u0ABF\u0A82\u0A97: "${n.prefix}" \u0AA5\u0AC0 \u0AB6\u0AB0\u0AC2 \u0AA5\u0AB5\u0AC1\u0A82 \u0A9C\u0ACB\u0A88\u0A8F` : n.format === "ends_with" ? `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AB8\u0ACD\u0A9F\u0ACD\u0AB0\u0ABF\u0A82\u0A97: "${n.suffix}" \u0AAA\u0AB0 \u0AB8\u0AAE\u0ABE\u0AAA\u0ACD\u0AA4 \u0AA5\u0AB5\u0AC1\u0A82 \u0A9C\u0ACB\u0A88\u0A8F` : n.format === "includes" ? `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AB8\u0ACD\u0A9F\u0ACD\u0AB0\u0ABF\u0A82\u0A97: "${n.includes}" \u0AB6\u0ABE\u0AAE\u0AC7\u0AB2 \u0AB9\u0ACB\u0AB5\u0AC1\u0A82 \u0A9C\u0ACB\u0A88\u0A8F` : n.format === "regex" ? `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AB8\u0ACD\u0A9F\u0ACD\u0AB0\u0ABF\u0A82\u0A97: \u0AAA\u0AC7\u0A9F\u0AB0\u0ACD\u0AA8 ${n.pattern} \u0AB8\u0ABE\u0AA5\u0AC7 \u0AAE\u0AC7\u0AB3 \u0A96\u0ABE\u0AB5\u0AC1\u0A82 \u0A9C\u0ACB\u0A88\u0A8F` : `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AA8\u0A82\u0AAC\u0AB0: ${t.divisor} \u0AA8\u0ACB \u0A97\u0AC1\u0AA3\u0ABE\u0A82\u0A95 \u0AB9\u0ACB\u0AB5\u0ACB \u0A9C\u0ACB\u0A88\u0A8F`;
      case "unrecognized_keys":
        return `\u0A93\u0AB3\u0A96\u0AC0 \u0AB6\u0A95\u0ABE\u0AA4\u0ABE \u0AA8\u0AB9\u0AC0\u0A82 \u0AA4\u0AC7 \u0A95\u0AC0${t.keys.length > 1 ? "\u0A93" : ""}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `${t.origin} \u0AAE\u0ABE\u0A82 \u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0A95\u0AC0`;
      case "invalid_union":
        return t.options && Array.isArray(t.options) && t.options.length > 0 ? `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AA1\u0ABF\u0AB8\u0ACD\u0A95\u0ACD\u0AB0\u0ABF\u0AAE\u0ABF\u0AA8\u0AC7\u0A9F\u0AB0 \u0AAE\u0AC2\u0AB2\u0ACD\u0AAF. \u0A85\u0AAA\u0AC7\u0A95\u0ACD\u0AB7\u0ABF\u0AA4 ${t.options.map((a) => `'${a}'`).join(" | ")}` : "\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0A87\u0AA8\u0AAA\u0AC1\u0A9F";
      case "invalid_element":
        return `${t.origin} \u0AAE\u0ABE\u0A82 \u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AAE\u0AC2\u0AB2\u0ACD\u0AAF`;
      default:
        return "\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0A87\u0AA8\u0AAA\u0AC1\u0A9F";
    }
  };
}, "error");
function Tu() {
  return {
    localeError: xy()
  };
}
s(Tu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/he.js
var wy = /* @__PURE__ */ s(() => {
  let e = {
    string: { label: "\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA", gender: "f" },
    number: { label: "\u05DE\u05E1\u05E4\u05E8", gender: "m" },
    boolean: { label: "\u05E2\u05E8\u05DA \u05D1\u05D5\u05DC\u05D9\u05D0\u05E0\u05D9", gender: "m" },
    bigint: { label: "BigInt", gender: "m" },
    date: { label: "\u05EA\u05D0\u05E8\u05D9\u05DA", gender: "m" },
    array: { label: "\u05DE\u05E2\u05E8\u05DA", gender: "m" },
    object: { label: "\u05D0\u05D5\u05D1\u05D9\u05D9\u05E7\u05D8", gender: "m" },
    null: { label: "\u05E2\u05E8\u05DA \u05E8\u05D9\u05E7 (null)", gender: "m" },
    undefined: { label: "\u05E2\u05E8\u05DA \u05DC\u05D0 \u05DE\u05D5\u05D2\u05D3\u05E8 (undefined)", gender: "m" },
    symbol: { label: "\u05E1\u05D9\u05DE\u05D1\u05D5\u05DC (Symbol)", gender: "m" },
    function: { label: "\u05E4\u05D5\u05E0\u05E7\u05E6\u05D9\u05D4", gender: "f" },
    map: { label: "\u05DE\u05E4\u05D4 (Map)", gender: "f" },
    set: { label: "\u05E7\u05D1\u05D5\u05E6\u05D4 (Set)", gender: "f" },
    file: { label: "\u05E7\u05D5\u05D1\u05E5", gender: "m" },
    promise: { label: "Promise", gender: "m" },
    NaN: { label: "NaN", gender: "m" },
    unknown: { label: "\u05E2\u05E8\u05DA \u05DC\u05D0 \u05D9\u05D3\u05D5\u05E2", gender: "m" },
    value: { label: "\u05E2\u05E8\u05DA", gender: "m" }
  }, r = {
    string: { unit: "\u05EA\u05D5\u05D5\u05D9\u05DD", shortLabel: "\u05E7\u05E6\u05E8", longLabel: "\u05D0\u05E8\u05D5\u05DA" },
    file: { unit: "\u05D1\u05D9\u05D9\u05D8\u05D9\u05DD", shortLabel: "\u05E7\u05D8\u05DF", longLabel: "\u05D2\u05D3\u05D5\u05DC" },
    array: { unit: "\u05E4\u05E8\u05D9\u05D8\u05D9\u05DD", shortLabel: "\u05E7\u05D8\u05DF", longLabel: "\u05D2\u05D3\u05D5\u05DC" },
    set: { unit: "\u05E4\u05E8\u05D9\u05D8\u05D9\u05DD", shortLabel: "\u05E7\u05D8\u05DF", longLabel: "\u05D2\u05D3\u05D5\u05DC" },
    number: { unit: "", shortLabel: "\u05E7\u05D8\u05DF", longLabel: "\u05D2\u05D3\u05D5\u05DC" }
    // no unit
  }, i = /* @__PURE__ */ s((l) => l ? e[l] : void 0, "typeEntry"), o = /* @__PURE__ */ s((l) => {
    let d = i(l);
    return d ? d.label : l ?? e.unknown.label;
  }, "typeLabel"), t = /* @__PURE__ */ s((l) => `\u05D4${o(l)}`, "withDefinite"), n = /* @__PURE__ */ s((l) => (i(l)?.gender ?? "m") === "f" ? "\u05E6\u05E8\u05D9\u05DB\u05D4 \u05DC\u05D4\u05D9\u05D5\u05EA" : "\u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA", "verbFor"), a = /* @__PURE__ */ s((l) => l ? r[l] ?? null : null, "getSizing"), u = {
    regex: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    email: { label: "\u05DB\u05EA\u05D5\u05D1\u05EA \u05D0\u05D9\u05DE\u05D9\u05D9\u05DC", gender: "f" },
    url: { label: "\u05DB\u05EA\u05D5\u05D1\u05EA \u05E8\u05E9\u05EA", gender: "f" },
    emoji: { label: "\u05D0\u05D9\u05DE\u05D5\u05D2'\u05D9", gender: "m" },
    uuid: { label: "UUID", gender: "m" },
    uuidv4: { label: "UUIDv4", gender: "m" },
    uuidv6: { label: "UUIDv6", gender: "m" },
    nanoid: { label: "nanoid", gender: "m" },
    guid: { label: "GUID", gender: "m" },
    cuid: { label: "cuid", gender: "m" },
    cuid2: { label: "cuid2", gender: "m" },
    ulid: { label: "ULID", gender: "m" },
    xid: { label: "XID", gender: "m" },
    ksuid: { label: "KSUID", gender: "m" },
    datetime: { label: "\u05EA\u05D0\u05E8\u05D9\u05DA \u05D5\u05D6\u05DE\u05DF ISO", gender: "m" },
    date: { label: "\u05EA\u05D0\u05E8\u05D9\u05DA ISO", gender: "m" },
    time: { label: "\u05D6\u05DE\u05DF ISO", gender: "m" },
    duration: { label: "\u05DE\u05E9\u05DA \u05D6\u05DE\u05DF ISO", gender: "m" },
    ipv4: { label: "\u05DB\u05EA\u05D5\u05D1\u05EA IPv4", gender: "f" },
    ipv6: { label: "\u05DB\u05EA\u05D5\u05D1\u05EA IPv6", gender: "f" },
    mac: { label: "\u05DB\u05EA\u05D5\u05D1\u05EA MAC", gender: "f" },
    cidrv4: { label: "\u05D8\u05D5\u05D5\u05D7 IPv4", gender: "m" },
    cidrv6: { label: "\u05D8\u05D5\u05D5\u05D7 IPv6", gender: "m" },
    base64: { label: "\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D1\u05D1\u05E1\u05D9\u05E1 64", gender: "f" },
    base64url: { label: "\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D1\u05D1\u05E1\u05D9\u05E1 64 \u05DC\u05DB\u05EA\u05D5\u05D1\u05D5\u05EA \u05E8\u05E9\u05EA", gender: "f" },
    json_string: { label: "\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA JSON", gender: "f" },
    e164: { label: "\u05DE\u05E1\u05E4\u05E8 E.164", gender: "m" },
    credit_card: { label: "\u05DE\u05E1\u05E4\u05E8 \u05DB\u05E8\u05D8\u05D9\u05E1 \u05D0\u05E9\u05E8\u05D0\u05D9", gender: "m" },
    jwt: { label: "JWT", gender: "m" },
    template_literal: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    ends_with: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    includes: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    lowercase: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    starts_with: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    uppercase: { label: "\u05E7\u05DC\u05D8", gender: "m" }
  }, c = {
    nan: "NaN"
  };
  return (l) => {
    switch (l.code) {
      case "invalid_type": {
        let d = l.expected, f = c[d ?? ""] ?? o(d), p = b(l.input), h = c[p] ?? e[p]?.label ?? p;
        return /^[A-Z]/.test(l.expected) ? `\u05E7\u05DC\u05D8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA instanceof ${l.expected}, \u05D4\u05EA\u05E7\u05D1\u05DC ${h}` : `\u05E7\u05DC\u05D8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA ${f}, \u05D4\u05EA\u05E7\u05D1\u05DC ${h}`;
      }
      case "invalid_value": {
        if (l.values.length === 1)
          return `\u05E2\u05E8\u05DA \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05D4\u05E2\u05E8\u05DA \u05D7\u05D9\u05D9\u05D1 \u05DC\u05D4\u05D9\u05D5\u05EA ${$(l.values[0])}`;
        let d = l.values.map((h) => $(h));
        if (l.values.length === 2)
          return `\u05E2\u05E8\u05DA \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05D4\u05D0\u05E4\u05E9\u05E8\u05D5\u05D9\u05D5\u05EA \u05D4\u05DE\u05EA\u05D0\u05D9\u05DE\u05D5\u05EA \u05D4\u05DF ${d[0]} \u05D0\u05D5 ${d[1]}`;
        let f = d[d.length - 1];
        return `\u05E2\u05E8\u05DA \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05D4\u05D0\u05E4\u05E9\u05E8\u05D5\u05D9\u05D5\u05EA \u05D4\u05DE\u05EA\u05D0\u05D9\u05DE\u05D5\u05EA \u05D4\u05DF ${d.slice(0, -1).join(", ")} \u05D0\u05D5 ${f}`;
      }
      case "too_big": {
        let d = a(l.origin), f = t(l.origin ?? "value");
        if (l.origin === "string")
          return `${d?.longLabel ?? "\u05D0\u05E8\u05D5\u05DA"} \u05DE\u05D3\u05D9: ${f} \u05E6\u05E8\u05D9\u05DB\u05D4 \u05DC\u05D4\u05DB\u05D9\u05DC ${l.maximum.toString()} ${d?.unit ?? ""} ${l.inclusive ? "\u05D0\u05D5 \u05E4\u05D7\u05D5\u05EA" : "\u05DC\u05DB\u05DC \u05D4\u05D9\u05D5\u05EA\u05E8"}`.trim();
        if (l.origin === "number") {
          let v = l.inclusive ? `\u05E7\u05D8\u05DF \u05D0\u05D5 \u05E9\u05D5\u05D5\u05D4 \u05DC-${l.maximum}` : `\u05E7\u05D8\u05DF \u05DE-${l.maximum}`;
          return `\u05D2\u05D3\u05D5\u05DC \u05DE\u05D3\u05D9: ${f} \u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA ${v}`;
        }
        if (l.origin === "array" || l.origin === "set") {
          let v = l.origin === "set" ? "\u05E6\u05E8\u05D9\u05DB\u05D4" : "\u05E6\u05E8\u05D9\u05DA", k = l.inclusive ? `${l.maximum} ${d?.unit ?? ""} \u05D0\u05D5 \u05E4\u05D7\u05D5\u05EA` : `\u05E4\u05D7\u05D5\u05EA \u05DE-${l.maximum} ${d?.unit ?? ""}`;
          return `\u05D2\u05D3\u05D5\u05DC \u05DE\u05D3\u05D9: ${f} ${v} \u05DC\u05D4\u05DB\u05D9\u05DC ${k}`.trim();
        }
        let p = l.inclusive ? "<=" : "<", h = n(l.origin ?? "value");
        return d?.unit ? `${d.longLabel} \u05DE\u05D3\u05D9: ${f} ${h} ${p}${l.maximum.toString()} ${d.unit}` : `${d?.longLabel ?? "\u05D2\u05D3\u05D5\u05DC"} \u05DE\u05D3\u05D9: ${f} ${h} ${p}${l.maximum.toString()}`;
      }
      case "too_small": {
        let d = a(l.origin), f = t(l.origin ?? "value");
        if (l.origin === "string")
          return `${d?.shortLabel ?? "\u05E7\u05E6\u05E8"} \u05DE\u05D3\u05D9: ${f} \u05E6\u05E8\u05D9\u05DB\u05D4 \u05DC\u05D4\u05DB\u05D9\u05DC ${l.minimum.toString()} ${d?.unit ?? ""} ${l.inclusive ? "\u05D0\u05D5 \u05D9\u05D5\u05EA\u05E8" : "\u05DC\u05E4\u05D7\u05D5\u05EA"}`.trim();
        if (l.origin === "number") {
          let v = l.inclusive ? `\u05D2\u05D3\u05D5\u05DC \u05D0\u05D5 \u05E9\u05D5\u05D5\u05D4 \u05DC-${l.minimum}` : `\u05D2\u05D3\u05D5\u05DC \u05DE-${l.minimum}`;
          return `\u05E7\u05D8\u05DF \u05DE\u05D3\u05D9: ${f} \u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA ${v}`;
        }
        if (l.origin === "array" || l.origin === "set") {
          let v = l.origin === "set" ? "\u05E6\u05E8\u05D9\u05DB\u05D4" : "\u05E6\u05E8\u05D9\u05DA";
          if (l.minimum === 1 && l.inclusive) {
            let z = (l.origin === "set", "\u05DC\u05E4\u05D7\u05D5\u05EA \u05E4\u05E8\u05D9\u05D8 \u05D0\u05D7\u05D3");
            return `\u05E7\u05D8\u05DF \u05DE\u05D3\u05D9: ${f} ${v} \u05DC\u05D4\u05DB\u05D9\u05DC ${z}`;
          }
          let k = l.inclusive ? `${l.minimum} ${d?.unit ?? ""} \u05D0\u05D5 \u05D9\u05D5\u05EA\u05E8` : `\u05D9\u05D5\u05EA\u05E8 \u05DE-${l.minimum} ${d?.unit ?? ""}`;
          return `\u05E7\u05D8\u05DF \u05DE\u05D3\u05D9: ${f} ${v} \u05DC\u05D4\u05DB\u05D9\u05DC ${k}`.trim();
        }
        let p = l.inclusive ? ">=" : ">", h = n(l.origin ?? "value");
        return d?.unit ? `${d.shortLabel} \u05DE\u05D3\u05D9: ${f} ${h} ${p}${l.minimum.toString()} ${d.unit}` : `${d?.shortLabel ?? "\u05E7\u05D8\u05DF"} \u05DE\u05D3\u05D9: ${f} ${h} ${p}${l.minimum.toString()}`;
      }
      case "invalid_format": {
        let d = l;
        if (d.format === "starts_with")
          return `\u05D4\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D7\u05D9\u05D9\u05D1\u05EA \u05DC\u05D4\u05EA\u05D7\u05D9\u05DC \u05D1 "${d.prefix}"`;
        if (d.format === "ends_with")
          return `\u05D4\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D7\u05D9\u05D9\u05D1\u05EA \u05DC\u05D4\u05E1\u05EA\u05D9\u05D9\u05DD \u05D1 "${d.suffix}"`;
        if (d.format === "includes")
          return `\u05D4\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D7\u05D9\u05D9\u05D1\u05EA \u05DC\u05DB\u05DC\u05D5\u05DC "${d.includes}"`;
        if (d.format === "regex")
          return `\u05D4\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D7\u05D9\u05D9\u05D1\u05EA \u05DC\u05D4\u05EA\u05D0\u05D9\u05DD \u05DC\u05EA\u05D1\u05E0\u05D9\u05EA ${d.pattern}`;
        let f = u[d.format], p = f?.label ?? d.format, v = (f?.gender ?? "m") === "f" ? "\u05EA\u05E7\u05D9\u05E0\u05D4" : "\u05EA\u05E7\u05D9\u05DF";
        return `${p} \u05DC\u05D0 ${v}`;
      }
      case "not_multiple_of":
        return `\u05DE\u05E1\u05E4\u05E8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05D7\u05D9\u05D9\u05D1 \u05DC\u05D4\u05D9\u05D5\u05EA \u05DE\u05DB\u05E4\u05DC\u05D4 \u05E9\u05DC ${l.divisor}`;
      case "unrecognized_keys":
        return `\u05DE\u05E4\u05EA\u05D7${l.keys.length > 1 ? "\u05D5\u05EA" : ""} \u05DC\u05D0 \u05DE\u05D6\u05D5\u05D4${l.keys.length > 1 ? "\u05D9\u05DD" : "\u05D4"}: ${g(l.keys, ", ")}`;
      case "invalid_key":
        return "\u05E9\u05D3\u05D4 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF \u05D1\u05D0\u05D5\u05D1\u05D9\u05D9\u05E7\u05D8";
      case "invalid_union":
        return "\u05E7\u05DC\u05D8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF";
      case "invalid_element":
        return `\u05E2\u05E8\u05DA \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF \u05D1${t(l.origin ?? "array")}`;
      default:
        return "\u05E7\u05DC\u05D8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF";
    }
  };
}, "error");
function Au() {
  return {
    localeError: wy()
  };
}
s(Au, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/hi.js
var ky = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0905\u0915\u094D\u0937\u0930", verb: "\u0930\u0916\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F" },
    file: { unit: "\u092C\u093E\u0907\u091F\u094D\u0938", verb: "\u0930\u0916\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F" },
    array: { unit: "\u0924\u0924\u094D\u0935", verb: "\u0930\u0916\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F" },
    set: { unit: "\u0924\u0924\u094D\u0935", verb: "\u0930\u0916\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F" },
    map: { unit: "\u092A\u094D\u0930\u0935\u093F\u0937\u094D\u091F\u093F\u092F\u093E\u0901", verb: "\u0930\u0916\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u0907\u0928\u092A\u0941\u091F",
    email: "\u0908\u092E\u0947\u0932 \u092A\u0924\u093E",
    url: "URL",
    emoji: "\u0907\u092E\u094B\u091C\u0940",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0924\u093F\u0925\u093F \u0914\u0930 \u0938\u092E\u092F",
    date: "ISO \u0924\u093F\u0925\u093F",
    time: "ISO \u0938\u092E\u092F",
    duration: "ISO \u0905\u0935\u0927\u093F",
    ipv4: "IPv4 \u092A\u0924\u093E",
    ipv6: "IPv6 \u092A\u0924\u093E",
    mac: "MAC \u092A\u0924\u093E",
    cidrv4: "IPv4 \u0936\u094D\u0930\u0947\u0923\u0940",
    cidrv6: "IPv6 \u0936\u094D\u0930\u0947\u0923\u0940",
    base64: "Base64-\u090F\u0928\u094D\u0915\u094B\u0921\u0947\u0921 \u0938\u094D\u091F\u094D\u0930\u093F\u0902\u0917",
    base64url: "Base64URL-\u090F\u0928\u094D\u0915\u094B\u0921\u0947\u0921 \u0938\u094D\u091F\u094D\u0930\u093F\u0902\u0917",
    json_string: "JSON \u0938\u094D\u091F\u094D\u0930\u093F\u0902\u0917",
    e164: "E.164 \u0938\u0902\u0916\u094D\u092F\u093E",
    credit_card: "\u0915\u094D\u0930\u0947\u0921\u093F\u091F \u0915\u093E\u0930\u094D\u0921 \u0938\u0902\u0916\u094D\u092F\u093E",
    jwt: "JWT",
    template_literal: "\u0907\u0928\u092A\u0941\u091F"
  }, o = {
    nan: "NaN"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return `\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 ${n}, \u092A\u094D\u0930\u093E\u092A\u094D\u0924 ${u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 ${$(t.values[0])}` : `\u0905\u092E\u093E\u0928\u094D\u092F \u0935\u093F\u0915\u0932\u094D\u092A: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 \u092E\u093E\u0928\u094B\u0902 \u092E\u0947\u0902 \u0938\u0947 \u090F\u0915 ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u092C\u0939\u0941\u0924 \u092C\u0921\u093C\u093E: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 \u0925\u093E \u0915\u093F ${t.origin ?? "\u092E\u093E\u0928"} \u092E\u0947\u0902 ${n}${t.maximum} ${a.unit} \u0939\u094B\u0902` : `\u092C\u0939\u0941\u0924 \u092C\u0921\u093C\u093E: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 \u0925\u093E \u0915\u093F ${t.origin ?? "\u092E\u093E\u0928"} ${n}${t.maximum} \u0939\u094B`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u092C\u0939\u0941\u0924 \u091B\u094B\u091F\u093E: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 \u0925\u093E \u0915\u093F ${t.origin} \u092E\u0947\u0902 ${n}${t.minimum} ${a.unit} \u0939\u094B\u0902` : `\u092C\u0939\u0941\u0924 \u091B\u094B\u091F\u093E: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 \u0925\u093E \u0915\u093F ${t.origin} ${n}${t.minimum} \u0939\u094B`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0902\u0917: "${n.prefix}" \u0938\u0947 \u0936\u0941\u0930\u0942 \u0939\u094B\u0928\u093E \u091A\u093E\u0939\u093F\u090F` : n.format === "ends_with" ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0902\u0917: "${n.suffix}" \u092A\u0930 \u0938\u092E\u093E\u092A\u094D\u0924 \u0939\u094B\u0928\u093E \u091A\u093E\u0939\u093F\u090F` : n.format === "includes" ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0902\u0917: \u0907\u0938\u092E\u0947\u0902 "${n.includes}" \u0936\u093E\u092E\u093F\u0932 \u0939\u094B\u0928\u093E \u091A\u093E\u0939\u093F\u090F` : n.format === "regex" ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0902\u0917: \u092A\u0948\u091F\u0930\u094D\u0928 ${n.pattern} \u0938\u0947 \u092E\u0947\u0932 \u0916\u093E\u0928\u093E \u091A\u093E\u0939\u093F\u090F` : `\u0905\u092E\u093E\u0928\u094D\u092F ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u0902\u0916\u094D\u092F\u093E: \u092F\u0939 ${t.divisor} \u0915\u093E \u0917\u0941\u0923\u091C \u0939\u094B\u0928\u093E \u091A\u093E\u0939\u093F\u090F`;
      case "unrecognized_keys":
        return `\u0905\u092A\u0930\u093F\u091A\u093F\u0924 \u0915\u0941\u0902\u091C\u0940${t.keys.length > 1 ? "\u092F\u093E\u0901" : ""}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `\u0905\u092E\u093E\u0928\u094D\u092F \u0915\u0941\u0902\u091C\u0940: ${t.origin} \u092E\u0947\u0902`;
      case "invalid_union":
        return t.options && Array.isArray(t.options) && t.options.length > 0 ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0921\u093F\u0938\u094D\u0915\u094D\u0930\u093F\u092E\u093F\u0928\u0947\u091F\u0930 \u092E\u093E\u0928: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 ${t.options.map((a) => `'${a}'`).join(" | ")}` : "\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F";
      case "invalid_element":
        return `\u0905\u092E\u093E\u0928\u094D\u092F \u092E\u093E\u0928: ${t.origin} \u092E\u0947\u0902`;
      default:
        return "\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F";
    }
  };
}, "error");
function Uu() {
  return {
    localeError: ky()
  };
}
s(Uu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/hr.js
var Iy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "znakova", verb: "imati" },
    file: { unit: "bajtova", verb: "imati" },
    array: { unit: "stavki", verb: "imati" },
    set: { unit: "stavki", verb: "imati" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "unos",
    email: "email adresa",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datum i vrijeme",
    date: "ISO datum",
    time: "ISO vrijeme",
    duration: "ISO trajanje",
    ipv4: "IPv4 adresa",
    ipv6: "IPv6 adresa",
    mac: "MAC adresa",
    cidrv4: "IPv4 raspon",
    cidrv6: "IPv6 raspon",
    base64: "base64 kodirani tekst",
    base64url: "base64url kodirani tekst",
    json_string: "JSON tekst",
    e164: "E.164 broj",
    credit_card: "broj kreditne kartice",
    jwt: "JWT",
    template_literal: "unos"
  }, o = {
    nan: "NaN",
    string: "tekst",
    number: "broj",
    boolean: "boolean",
    array: "niz",
    object: "objekt",
    set: "skup",
    file: "datoteka",
    date: "datum",
    bigint: "bigint",
    symbol: "simbol",
    undefined: "undefined",
    null: "null",
    function: "funkcija",
    map: "mapa"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Neispravan unos: o\u010Dekuje se instanceof ${t.expected}, a primljeno je ${u}` : `Neispravan unos: o\u010Dekuje se ${n}, a primljeno je ${u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Neispravna vrijednost: o\u010Dekivano ${$(t.values[0])}` : `Neispravna opcija: o\u010Dekivano jedno od ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin), u = o[t.origin] ?? t.origin;
        return a ? `Preveliko: o\u010Dekivano da ${u ?? "vrijednost"} ima ${n}${t.maximum.toString()} ${a.unit ?? "elemenata"}` : `Preveliko: o\u010Dekivano da ${u ?? "vrijednost"} bude ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin), u = o[t.origin] ?? t.origin;
        return a ? `Premalo: o\u010Dekivano da ${u} ima ${n}${t.minimum.toString()} ${a.unit}` : `Premalo: o\u010Dekivano da ${u} bude ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Neispravan tekst: mora zapo\u010Dinjati s "${n.prefix}"` : n.format === "ends_with" ? `Neispravan tekst: mora zavr\u0161avati s "${n.suffix}"` : n.format === "includes" ? `Neispravan tekst: mora sadr\u017Eavati "${n.includes}"` : n.format === "regex" ? `Neispravan tekst: mora odgovarati uzorku ${n.pattern}` : `Neispravna ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Neispravan broj: mora biti vi\u0161ekratnik od ${t.divisor}`;
      case "unrecognized_keys":
        return `Neprepoznat${t.keys.length > 1 ? "i klju\u010Devi" : " klju\u010D"}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `Neispravan klju\u010D u ${o[t.origin] ?? t.origin}`;
      case "invalid_union":
        return "Neispravan unos";
      case "invalid_element":
        return `Neispravna vrijednost u ${o[t.origin] ?? t.origin}`;
      default:
        return "Neispravan unos";
    }
  };
}, "error");
function Eu() {
  return {
    localeError: Iy()
  };
}
s(Eu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/hu.js
var zy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "karakter", verb: "legyen" },
    file: { unit: "byte", verb: "legyen" },
    array: { unit: "elem", verb: "legyen" },
    set: { unit: "elem", verb: "legyen" },
    map: { unit: "elem", verb: "legyen" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "bemenet",
    email: "email c\xEDm",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO id\u0151b\xE9lyeg",
    date: "ISO d\xE1tum",
    time: "ISO id\u0151",
    duration: "ISO id\u0151intervallum",
    ipv4: "IPv4 c\xEDm",
    ipv6: "IPv6 c\xEDm",
    mac: "MAC c\xEDm",
    cidrv4: "IPv4 tartom\xE1ny",
    cidrv6: "IPv6 tartom\xE1ny",
    base64: "base64-k\xF3dolt string",
    base64url: "base64url-k\xF3dolt string",
    json_string: "JSON string",
    e164: "E.164 sz\xE1m",
    credit_card: "hitelk\xE1rtyasz\xE1m",
    jwt: "JWT",
    template_literal: "bemenet"
  }, o = {
    nan: "NaN",
    number: "sz\xE1m",
    array: "t\xF6mb"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\xC9rv\xE9nytelen bemenet: a v\xE1rt \xE9rt\xE9k instanceof ${t.expected}, a kapott \xE9rt\xE9k ${u}` : `\xC9rv\xE9nytelen bemenet: a v\xE1rt \xE9rt\xE9k ${n}, a kapott \xE9rt\xE9k ${u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\xC9rv\xE9nytelen bemenet: a v\xE1rt \xE9rt\xE9k ${$(t.values[0])}` : `\xC9rv\xE9nytelen opci\xF3: valamelyik \xE9rt\xE9k v\xE1rt ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `T\xFAl nagy: ${t.origin ?? "\xE9rt\xE9k"} m\xE9rete t\xFAl nagy ${n}${t.maximum.toString()} ${a.unit ?? "elem"}` : `T\xFAl nagy: a bemeneti \xE9rt\xE9k ${t.origin ?? "\xE9rt\xE9k"} t\xFAl nagy: ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `T\xFAl kicsi: a bemeneti \xE9rt\xE9k ${t.origin} m\xE9rete t\xFAl kicsi ${n}${t.minimum.toString()} ${a.unit}` : `T\xFAl kicsi: a bemeneti \xE9rt\xE9k ${t.origin} t\xFAl kicsi ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\xC9rv\xE9nytelen string: "${n.prefix}" \xE9rt\xE9kkel kell kezd\u0151dnie` : n.format === "ends_with" ? `\xC9rv\xE9nytelen string: "${n.suffix}" \xE9rt\xE9kkel kell v\xE9gz\u0151dnie` : n.format === "includes" ? `\xC9rv\xE9nytelen string: "${n.includes}" \xE9rt\xE9ket kell tartalmaznia` : n.format === "regex" ? `\xC9rv\xE9nytelen string: ${n.pattern} mint\xE1nak kell megfelelnie` : `\xC9rv\xE9nytelen ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\xC9rv\xE9nytelen sz\xE1m: ${t.divisor} t\xF6bbsz\xF6r\xF6s\xE9nek kell lennie`;
      case "unrecognized_keys":
        return `Ismeretlen kulcs${t.keys.length > 1 ? "s" : ""}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `\xC9rv\xE9nytelen kulcs ${t.origin}`;
      case "invalid_union":
        return "\xC9rv\xE9nytelen bemenet";
      case "invalid_element":
        return `\xC9rv\xE9nytelen \xE9rt\xE9k: ${t.origin}`;
      default:
        return "\xC9rv\xE9nytelen bemenet";
    }
  };
}, "error");
function Cu() {
  return {
    localeError: zy()
  };
}
s(Cu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/hy.js
function yp(e, r, i) {
  return Math.abs(e) === 1 ? r : i;
}
s(yp, "getArmenianPlural");
function Zt(e) {
  if (!e)
    return "";
  let r = ["\u0561", "\u0565", "\u0568", "\u056B", "\u0578", "\u0578\u0582", "\u0585"], i = e[e.length - 1];
  return e + (r.includes(i) ? "\u0576" : "\u0568");
}
s(Zt, "withDefiniteArticle");
var Sy = /* @__PURE__ */ s(() => {
  let e = {
    string: {
      unit: {
        one: "\u0576\u0577\u0561\u0576",
        many: "\u0576\u0577\u0561\u0576\u0576\u0565\u0580"
      },
      verb: "\u0578\u0582\u0576\u0565\u0576\u0561\u056C"
    },
    file: {
      unit: {
        one: "\u0562\u0561\u0575\u0569",
        many: "\u0562\u0561\u0575\u0569\u0565\u0580"
      },
      verb: "\u0578\u0582\u0576\u0565\u0576\u0561\u056C"
    },
    array: {
      unit: {
        one: "\u057F\u0561\u0580\u0580",
        many: "\u057F\u0561\u0580\u0580\u0565\u0580"
      },
      verb: "\u0578\u0582\u0576\u0565\u0576\u0561\u056C"
    },
    set: {
      unit: {
        one: "\u057F\u0561\u0580\u0580",
        many: "\u057F\u0561\u0580\u0580\u0565\u0580"
      },
      verb: "\u0578\u0582\u0576\u0565\u0576\u0561\u056C"
    },
    map: {
      unit: {
        one: "\u057F\u0561\u0580\u0580",
        many: "\u057F\u0561\u0580\u0580\u0565\u0580"
      },
      verb: "\u0578\u0582\u0576\u0565\u0576\u0561\u056C"
    }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u0574\u0578\u0582\u057F\u0584",
    email: "\u0567\u056C. \u0570\u0561\u057D\u0581\u0565",
    url: "URL",
    emoji: "\u0567\u0574\u0578\u057B\u056B",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0561\u0574\u057D\u0561\u0569\u056B\u057E \u0587 \u056A\u0561\u0574",
    date: "ISO \u0561\u0574\u057D\u0561\u0569\u056B\u057E",
    time: "ISO \u056A\u0561\u0574",
    duration: "ISO \u057F\u0587\u0578\u0572\u0578\u0582\u0569\u0575\u0578\u0582\u0576",
    ipv4: "IPv4 \u0570\u0561\u057D\u0581\u0565",
    ipv6: "IPv6 \u0570\u0561\u057D\u0581\u0565",
    mac: "MAC \u0570\u0561\u057D\u0581\u0565",
    cidrv4: "IPv4 \u0574\u056B\u057B\u0561\u056F\u0561\u0575\u0584",
    cidrv6: "IPv6 \u0574\u056B\u057B\u0561\u056F\u0561\u0575\u0584",
    base64: "base64 \u0571\u0587\u0561\u0579\u0561\u0583\u0578\u057E \u057F\u0578\u0572",
    base64url: "base64url \u0571\u0587\u0561\u0579\u0561\u0583\u0578\u057E \u057F\u0578\u0572",
    json_string: "JSON \u057F\u0578\u0572",
    e164: "E.164 \u0570\u0561\u0574\u0561\u0580",
    credit_card: "\u056F\u0580\u0565\u0564\u056B\u057F \u0584\u0561\u0580\u057F\u056B \u0570\u0561\u0574\u0561\u0580",
    jwt: "JWT",
    template_literal: "\u0574\u0578\u0582\u057F\u0584"
  }, o = {
    nan: "NaN",
    number: "\u0569\u056B\u057E",
    array: "\u0566\u0561\u0576\u0563\u057E\u0561\u056E"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567\u0580 instanceof ${t.expected}, \u057D\u057F\u0561\u0581\u057E\u0565\u056C \u0567 ${u}` : `\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567\u0580 ${n}, \u057D\u057F\u0561\u0581\u057E\u0565\u056C \u0567 ${u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567\u0580 ${$(t.values[1])}` : `\u054D\u056D\u0561\u056C \u057F\u0561\u0580\u0562\u0565\u0580\u0561\u056F\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567\u0580 \u0570\u0565\u057F\u0587\u0575\u0561\u056C\u0576\u0565\u0580\u056B\u0581 \u0574\u0565\u056F\u0568\u055D ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        if (a) {
          let u = Number(t.maximum), c = yp(u, a.unit.one, a.unit.many);
          return `\u0549\u0561\u0583\u0561\u0566\u0561\u0576\u0581 \u0574\u0565\u056E \u0561\u0580\u056A\u0565\u0584\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567, \u0578\u0580 ${Zt(t.origin ?? "\u0561\u0580\u056A\u0565\u0584")} \u056F\u0578\u0582\u0576\u0565\u0576\u0561 ${n}${t.maximum.toString()} ${c}`;
        }
        return `\u0549\u0561\u0583\u0561\u0566\u0561\u0576\u0581 \u0574\u0565\u056E \u0561\u0580\u056A\u0565\u0584\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567, \u0578\u0580 ${Zt(t.origin ?? "\u0561\u0580\u056A\u0565\u0584")} \u056C\u056B\u0576\u056B ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        if (a) {
          let u = Number(t.minimum), c = yp(u, a.unit.one, a.unit.many);
          return `\u0549\u0561\u0583\u0561\u0566\u0561\u0576\u0581 \u0583\u0578\u0584\u0580 \u0561\u0580\u056A\u0565\u0584\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567, \u0578\u0580 ${Zt(t.origin)} \u056F\u0578\u0582\u0576\u0565\u0576\u0561 ${n}${t.minimum.toString()} ${c}`;
        }
        return `\u0549\u0561\u0583\u0561\u0566\u0561\u0576\u0581 \u0583\u0578\u0584\u0580 \u0561\u0580\u056A\u0565\u0584\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567, \u0578\u0580 ${Zt(t.origin)} \u056C\u056B\u0576\u056B ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u054D\u056D\u0561\u056C \u057F\u0578\u0572\u2024 \u057A\u0565\u057F\u0584 \u0567 \u057D\u056F\u057D\u057E\u056B "${n.prefix}"-\u0578\u057E` : n.format === "ends_with" ? `\u054D\u056D\u0561\u056C \u057F\u0578\u0572\u2024 \u057A\u0565\u057F\u0584 \u0567 \u0561\u057E\u0561\u0580\u057F\u057E\u056B "${n.suffix}"-\u0578\u057E` : n.format === "includes" ? `\u054D\u056D\u0561\u056C \u057F\u0578\u0572\u2024 \u057A\u0565\u057F\u0584 \u0567 \u057A\u0561\u0580\u0578\u0582\u0576\u0561\u056F\u056B "${n.includes}"` : n.format === "regex" ? `\u054D\u056D\u0561\u056C \u057F\u0578\u0572\u2024 \u057A\u0565\u057F\u0584 \u0567 \u0570\u0561\u0574\u0561\u057A\u0561\u057F\u0561\u057D\u056D\u0561\u0576\u056B ${n.pattern} \u0571\u0587\u0561\u0579\u0561\u0583\u056B\u0576` : `\u054D\u056D\u0561\u056C ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u054D\u056D\u0561\u056C \u0569\u056B\u057E\u2024 \u057A\u0565\u057F\u0584 \u0567 \u0562\u0561\u0566\u0574\u0561\u057A\u0561\u057F\u056B\u056F \u056C\u056B\u0576\u056B ${t.divisor}-\u056B`;
      case "unrecognized_keys":
        return `\u0549\u0573\u0561\u0576\u0561\u0579\u057E\u0561\u056E \u0562\u0561\u0576\u0561\u056C\u056B${t.keys.length > 1 ? "\u0576\u0565\u0580" : ""}. ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `\u054D\u056D\u0561\u056C \u0562\u0561\u0576\u0561\u056C\u056B ${Zt(t.origin)}-\u0578\u0582\u0574`;
      case "invalid_union":
        return "\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574";
      case "invalid_element":
        return `\u054D\u056D\u0561\u056C \u0561\u0580\u056A\u0565\u0584 ${Zt(t.origin)}-\u0578\u0582\u0574`;
      default:
        return "\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574";
    }
  };
}, "error");
function Zu() {
  return {
    localeError: Sy()
  };
}
s(Zu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/id.js
var Oy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "karakter", verb: "memiliki" },
    file: { unit: "byte", verb: "memiliki" },
    array: { unit: "item", verb: "memiliki" },
    set: { unit: "item", verb: "memiliki" },
    map: { unit: "item", verb: "memiliki" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "input",
    email: "alamat email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "tanggal dan waktu format ISO",
    date: "tanggal format ISO",
    time: "jam format ISO",
    duration: "durasi format ISO",
    ipv4: "alamat IPv4",
    ipv6: "alamat IPv6",
    mac: "alamat MAC",
    cidrv4: "rentang alamat IPv4",
    cidrv6: "rentang alamat IPv6",
    base64: "string dengan enkode base64",
    base64url: "string dengan enkode base64url",
    json_string: "string JSON",
    e164: "angka E.164",
    credit_card: "nomor kartu kredit",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Input tidak valid: diharapkan instanceof ${t.expected}, diterima ${u}` : `Input tidak valid: diharapkan ${n}, diterima ${u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Input tidak valid: diharapkan ${$(t.values[0])}` : `Pilihan tidak valid: diharapkan salah satu dari ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Terlalu besar: diharapkan ${t.origin ?? "value"} memiliki ${n}${t.maximum.toString()} ${a.unit ?? "elemen"}` : `Terlalu besar: diharapkan ${t.origin ?? "value"} menjadi ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Terlalu kecil: diharapkan ${t.origin} memiliki ${n}${t.minimum.toString()} ${a.unit}` : `Terlalu kecil: diharapkan ${t.origin} menjadi ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `String tidak valid: harus dimulai dengan "${n.prefix}"` : n.format === "ends_with" ? `String tidak valid: harus berakhir dengan "${n.suffix}"` : n.format === "includes" ? `String tidak valid: harus menyertakan "${n.includes}"` : n.format === "regex" ? `String tidak valid: harus sesuai pola ${n.pattern}` : `${i[n.format] ?? t.format} tidak valid`;
      }
      case "not_multiple_of":
        return `Angka tidak valid: harus kelipatan dari ${t.divisor}`;
      case "unrecognized_keys":
        return `Kunci tidak dikenali ${t.keys.length > 1 ? "s" : ""}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `Kunci tidak valid di ${t.origin}`;
      case "invalid_union":
        return "Input tidak valid";
      case "invalid_element":
        return `Nilai tidak valid di ${t.origin}`;
      default:
        return "Input tidak valid";
    }
  };
}, "error");
function Ru() {
  return {
    localeError: Oy()
  };
}
s(Ru, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/is.js
var jy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "stafi", verb: "a\xF0 hafa" },
    file: { unit: "b\xE6ti", verb: "a\xF0 hafa" },
    array: { unit: "hluti", verb: "a\xF0 hafa" },
    set: { unit: "hluti", verb: "a\xF0 hafa" },
    map: { unit: "hluti", verb: "a\xF0 hafa" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "gildi",
    email: "netfang",
    url: "vefsl\xF3\xF0",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO dagsetning og t\xEDmi",
    date: "ISO dagsetning",
    time: "ISO t\xEDmi",
    duration: "ISO t\xEDmalengd",
    ipv4: "IPv4 address",
    ipv6: "IPv6 address",
    mac: "MAC address",
    cidrv4: "IPv4 range",
    cidrv6: "IPv6 range",
    base64: "base64-encoded strengur",
    base64url: "base64url-encoded strengur",
    json_string: "JSON strengur",
    e164: "E.164 t\xF6lugildi",
    credit_card: "kreditkortan\xFAmer",
    jwt: "JWT",
    template_literal: "gildi"
  }, o = {
    nan: "NaN",
    number: "n\xFAmer",
    array: "fylki"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Rangt gildi: \xDE\xFA sl\xF3st inn ${u} \xFEar sem \xE1 a\xF0 vera instanceof ${t.expected}` : `Rangt gildi: \xDE\xFA sl\xF3st inn ${u} \xFEar sem \xE1 a\xF0 vera ${n}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Rangt gildi: gert r\xE1\xF0 fyrir ${$(t.values[0])}` : `\xD3gilt val: m\xE1 vera eitt af eftirfarandi ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Of st\xF3rt: gert er r\xE1\xF0 fyrir a\xF0 ${t.origin ?? "gildi"} hafi ${n}${t.maximum.toString()} ${a.unit ?? "hluti"}` : `Of st\xF3rt: gert er r\xE1\xF0 fyrir a\xF0 ${t.origin ?? "gildi"} s\xE9 ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Of l\xEDti\xF0: gert er r\xE1\xF0 fyrir a\xF0 ${t.origin} hafi ${n}${t.minimum.toString()} ${a.unit}` : `Of l\xEDti\xF0: gert er r\xE1\xF0 fyrir a\xF0 ${t.origin} s\xE9 ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\xD3gildur strengur: ver\xF0ur a\xF0 byrja \xE1 "${n.prefix}"` : n.format === "ends_with" ? `\xD3gildur strengur: ver\xF0ur a\xF0 enda \xE1 "${n.suffix}"` : n.format === "includes" ? `\xD3gildur strengur: ver\xF0ur a\xF0 innihalda "${n.includes}"` : n.format === "regex" ? `\xD3gildur strengur: ver\xF0ur a\xF0 fylgja mynstri ${n.pattern}` : `Rangt ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `R\xF6ng tala: ver\xF0ur a\xF0 vera margfeldi af ${t.divisor}`;
      case "unrecognized_keys":
        return `\xD3\xFEekkt ${t.keys.length > 1 ? "ir lyklar" : "ur lykill"}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `Rangur lykill \xED ${t.origin}`;
      case "invalid_union":
        return "Rangt gildi";
      case "invalid_element":
        return `Rangt gildi \xED ${t.origin}`;
      default:
        return "Rangt gildi";
    }
  };
}, "error");
function Fu() {
  return {
    localeError: jy()
  };
}
s(Fu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/it.js
var Py = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "caratteri", verb: "avere" },
    file: { unit: "byte", verb: "avere" },
    array: { unit: "elementi", verb: "avere" },
    set: { unit: "elementi", verb: "avere" },
    map: { unit: "elementi", verb: "avere" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "input",
    email: "indirizzo email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "data e ora ISO",
    date: "data ISO",
    time: "ora ISO",
    duration: "durata ISO",
    ipv4: "indirizzo IPv4",
    ipv6: "indirizzo IPv6",
    mac: "indirizzo MAC",
    cidrv4: "intervallo IPv4",
    cidrv6: "intervallo IPv6",
    base64: "stringa codificata in base64",
    base64url: "URL codificata in base64",
    json_string: "stringa JSON",
    e164: "numero E.164",
    credit_card: "numero di carta di credito",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN",
    number: "numero",
    array: "vettore"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Input non valido: atteso instanceof ${t.expected}, ricevuto ${u}` : `Input non valido: atteso ${n}, ricevuto ${u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Input non valido: atteso ${$(t.values[0])}` : `Opzione non valida: atteso uno tra ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Troppo grande: ${t.origin ?? "valore"} deve avere ${n}${t.maximum.toString()} ${a.unit ?? "elementi"}` : `Troppo grande: ${t.origin ?? "valore"} deve essere ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Troppo piccolo: ${t.origin} deve avere ${n}${t.minimum.toString()} ${a.unit}` : `Troppo piccolo: ${t.origin} deve essere ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Stringa non valida: deve iniziare con "${n.prefix}"` : n.format === "ends_with" ? `Stringa non valida: deve terminare con "${n.suffix}"` : n.format === "includes" ? `Stringa non valida: deve includere "${n.includes}"` : n.format === "regex" ? `Stringa non valida: deve corrispondere al pattern ${n.pattern}` : `Input non valido: ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Numero non valido: deve essere un multiplo di ${t.divisor}`;
      case "unrecognized_keys":
        return `Chiav${t.keys.length > 1 ? "i" : "e"} non riconosciut${t.keys.length > 1 ? "e" : "a"}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `Chiave non valida in ${t.origin}`;
      case "invalid_union":
        return "Input non valido";
      case "invalid_element":
        return `Valore non valido in ${t.origin}`;
      default:
        return "Input non valido";
    }
  };
}, "error");
function Lu() {
  return {
    localeError: Py()
  };
}
s(Lu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ja.js
var Dy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u6587\u5B57", verb: "\u3067\u3042\u308B" },
    file: { unit: "\u30D0\u30A4\u30C8", verb: "\u3067\u3042\u308B" },
    array: { unit: "\u8981\u7D20", verb: "\u3067\u3042\u308B" },
    set: { unit: "\u8981\u7D20", verb: "\u3067\u3042\u308B" },
    map: { unit: "\u8981\u7D20", verb: "\u3067\u3042\u308B" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u5165\u529B\u5024",
    email: "\u30E1\u30FC\u30EB\u30A2\u30C9\u30EC\u30B9",
    url: "URL",
    emoji: "\u7D75\u6587\u5B57",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO\u65E5\u6642",
    date: "ISO\u65E5\u4ED8",
    time: "ISO\u6642\u523B",
    duration: "ISO\u671F\u9593",
    ipv4: "IPv4\u30A2\u30C9\u30EC\u30B9",
    ipv6: "IPv6\u30A2\u30C9\u30EC\u30B9",
    mac: "MAC\u30A2\u30C9\u30EC\u30B9",
    cidrv4: "IPv4\u7BC4\u56F2",
    cidrv6: "IPv6\u7BC4\u56F2",
    base64: "base64\u30A8\u30F3\u30B3\u30FC\u30C9\u6587\u5B57\u5217",
    base64url: "base64url\u30A8\u30F3\u30B3\u30FC\u30C9\u6587\u5B57\u5217",
    json_string: "JSON\u6587\u5B57\u5217",
    e164: "E.164\u756A\u53F7",
    credit_card: "\u30AF\u30EC\u30B8\u30C3\u30C8\u30AB\u30FC\u30C9\u756A\u53F7",
    jwt: "JWT",
    template_literal: "\u5165\u529B\u5024"
  }, o = {
    nan: "NaN",
    number: "\u6570\u5024",
    array: "\u914D\u5217"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u7121\u52B9\u306A\u5165\u529B: instanceof ${t.expected}\u304C\u671F\u5F85\u3055\u308C\u307E\u3057\u305F\u304C\u3001${u}\u304C\u5165\u529B\u3055\u308C\u307E\u3057\u305F` : `\u7121\u52B9\u306A\u5165\u529B: ${n}\u304C\u671F\u5F85\u3055\u308C\u307E\u3057\u305F\u304C\u3001${u}\u304C\u5165\u529B\u3055\u308C\u307E\u3057\u305F`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u7121\u52B9\u306A\u5165\u529B: ${$(t.values[0])}\u304C\u671F\u5F85\u3055\u308C\u307E\u3057\u305F` : `\u7121\u52B9\u306A\u9078\u629E: ${g(t.values, "\u3001")}\u306E\u3044\u305A\u308C\u304B\u3067\u3042\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`;
      case "too_big": {
        let n = t.inclusive ? "\u4EE5\u4E0B\u3067\u3042\u308B" : "\u3088\u308A\u5C0F\u3055\u3044", a = r(t.origin);
        return a ? `\u5927\u304D\u3059\u304E\u308B\u5024: ${t.origin ?? "\u5024"}\u306F${t.maximum.toString()}${a.unit ?? "\u8981\u7D20"}${n}\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : `\u5927\u304D\u3059\u304E\u308B\u5024: ${t.origin ?? "\u5024"}\u306F${t.maximum.toString()}${n}\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`;
      }
      case "too_small": {
        let n = t.inclusive ? "\u4EE5\u4E0A\u3067\u3042\u308B" : "\u3088\u308A\u5927\u304D\u3044", a = r(t.origin);
        return a ? `\u5C0F\u3055\u3059\u304E\u308B\u5024: ${t.origin}\u306F${t.minimum.toString()}${a.unit}${n}\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : `\u5C0F\u3055\u3059\u304E\u308B\u5024: ${t.origin}\u306F${t.minimum.toString()}${n}\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u7121\u52B9\u306A\u6587\u5B57\u5217: "${n.prefix}"\u3067\u59CB\u307E\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : n.format === "ends_with" ? `\u7121\u52B9\u306A\u6587\u5B57\u5217: "${n.suffix}"\u3067\u7D42\u308F\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : n.format === "includes" ? `\u7121\u52B9\u306A\u6587\u5B57\u5217: "${n.includes}"\u3092\u542B\u3080\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : n.format === "regex" ? `\u7121\u52B9\u306A\u6587\u5B57\u5217: \u30D1\u30BF\u30FC\u30F3${n.pattern}\u306B\u4E00\u81F4\u3059\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : `\u7121\u52B9\u306A${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u7121\u52B9\u306A\u6570\u5024: ${t.divisor}\u306E\u500D\u6570\u3067\u3042\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`;
      case "unrecognized_keys":
        return `\u8A8D\u8B58\u3055\u308C\u3066\u3044\u306A\u3044\u30AD\u30FC${t.keys.length > 1 ? "\u7FA4" : ""}: ${g(t.keys, "\u3001")}`;
      case "invalid_key":
        return `${t.origin}\u5185\u306E\u7121\u52B9\u306A\u30AD\u30FC`;
      case "invalid_union":
        return "\u7121\u52B9\u306A\u5165\u529B";
      case "invalid_element":
        return `${t.origin}\u5185\u306E\u7121\u52B9\u306A\u5024`;
      default:
        return "\u7121\u52B9\u306A\u5165\u529B";
    }
  };
}, "error");
function Vu() {
  return {
    localeError: Dy()
  };
}
s(Vu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ka.js
var Ny = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u10E1\u10D8\u10DB\u10D1\u10DD\u10DA\u10DD", verb: "\u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1" },
    file: { unit: "\u10D1\u10D0\u10D8\u10E2\u10D8", verb: "\u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1" },
    array: { unit: "\u10D4\u10DA\u10D4\u10DB\u10D4\u10DC\u10E2\u10D8", verb: "\u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1" },
    set: { unit: "\u10D4\u10DA\u10D4\u10DB\u10D4\u10DC\u10E2\u10D8", verb: "\u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1" },
    map: { unit: "\u10D4\u10DA\u10D4\u10DB\u10D4\u10DC\u10E2\u10D8", verb: "\u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0",
    email: "\u10D4\u10DA-\u10E4\u10DD\u10E1\u10E2\u10D8\u10E1 \u10DB\u10D8\u10E1\u10D0\u10DB\u10D0\u10E0\u10D7\u10D8",
    url: "URL",
    emoji: "\u10D4\u10DB\u10DD\u10EF\u10D8",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u10D7\u10D0\u10E0\u10D8\u10E6\u10D8-\u10D3\u10E0\u10DD",
    date: "\u10D7\u10D0\u10E0\u10D8\u10E6\u10D8",
    time: "\u10D3\u10E0\u10DD",
    duration: "\u10EE\u10D0\u10DC\u10D2\u10E0\u10EB\u10DA\u10D8\u10D5\u10DD\u10D1\u10D0",
    ipv4: "IPv4 \u10DB\u10D8\u10E1\u10D0\u10DB\u10D0\u10E0\u10D7\u10D8",
    ipv6: "IPv6 \u10DB\u10D8\u10E1\u10D0\u10DB\u10D0\u10E0\u10D7\u10D8",
    mac: "MAC \u10DB\u10D8\u10E1\u10D0\u10DB\u10D0\u10E0\u10D7\u10D8",
    cidrv4: "IPv4 \u10D3\u10D8\u10D0\u10DE\u10D0\u10D6\u10DD\u10DC\u10D8",
    cidrv6: "IPv6 \u10D3\u10D8\u10D0\u10DE\u10D0\u10D6\u10DD\u10DC\u10D8",
    base64: "base64-\u10D9\u10DD\u10D3\u10D8\u10E0\u10D4\u10D1\u10E3\u10DA\u10D8 \u10D5\u10D4\u10DA\u10D8",
    base64url: "base64url-\u10D9\u10DD\u10D3\u10D8\u10E0\u10D4\u10D1\u10E3\u10DA\u10D8 \u10D5\u10D4\u10DA\u10D8",
    json_string: "JSON \u10D5\u10D4\u10DA\u10D8",
    e164: "E.164 \u10DC\u10DD\u10DB\u10D4\u10E0\u10D8",
    credit_card: "\u10E1\u10D0\u10D9\u10E0\u10D4\u10D3\u10D8\u10E2\u10DD \u10D1\u10D0\u10E0\u10D0\u10D7\u10D8\u10E1 \u10DC\u10DD\u10DB\u10D4\u10E0\u10D8",
    jwt: "JWT",
    template_literal: "\u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0"
  }, o = {
    nan: "NaN",
    number: "\u10E0\u10D8\u10EA\u10EE\u10D5\u10D8",
    string: "\u10D5\u10D4\u10DA\u10D8",
    boolean: "\u10D1\u10E3\u10DA\u10D4\u10D0\u10DC\u10D8",
    function: "\u10E4\u10E3\u10DC\u10E5\u10EA\u10D8\u10D0",
    array: "\u10DB\u10D0\u10E1\u10D8\u10D5\u10D8"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 instanceof ${t.expected}, \u10DB\u10D8\u10E6\u10D4\u10D1\u10E3\u10DA\u10D8 ${u}` : `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${n}, \u10DB\u10D8\u10E6\u10D4\u10D1\u10E3\u10DA\u10D8 ${u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${$(t.values[0])}` : `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D5\u10D0\u10E0\u10D8\u10D0\u10DC\u10E2\u10D8: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8\u10D0 \u10D4\u10E0\u10D7-\u10D4\u10E0\u10D7\u10D8 ${g(t.values, "|")}-\u10D3\u10D0\u10DC`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u10D6\u10D4\u10D3\u10DB\u10D4\u10E2\u10D0\u10D3 \u10D3\u10D8\u10D3\u10D8: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${t.origin ?? "\u10DB\u10DC\u10D8\u10E8\u10D5\u10DC\u10D4\u10DA\u10DD\u10D1\u10D0"} ${a.verb} ${n}${t.maximum.toString()} ${a.unit}` : `\u10D6\u10D4\u10D3\u10DB\u10D4\u10E2\u10D0\u10D3 \u10D3\u10D8\u10D3\u10D8: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${t.origin ?? "\u10DB\u10DC\u10D8\u10E8\u10D5\u10DC\u10D4\u10DA\u10DD\u10D1\u10D0"} \u10D8\u10E7\u10DD\u10E1 ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u10D6\u10D4\u10D3\u10DB\u10D4\u10E2\u10D0\u10D3 \u10DE\u10D0\u10E2\u10D0\u10E0\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${t.origin} ${a.verb} ${n}${t.minimum.toString()} ${a.unit}` : `\u10D6\u10D4\u10D3\u10DB\u10D4\u10E2\u10D0\u10D3 \u10DE\u10D0\u10E2\u10D0\u10E0\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${t.origin} \u10D8\u10E7\u10DD\u10E1 ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D5\u10D4\u10DA\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10D8\u10EC\u10E7\u10D4\u10D1\u10DD\u10D3\u10D4\u10E1 "${n.prefix}"-\u10D8\u10D7` : n.format === "ends_with" ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D5\u10D4\u10DA\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10DB\u10D7\u10D0\u10D5\u10E0\u10D3\u10D4\u10D1\u10DD\u10D3\u10D4\u10E1 "${n.suffix}"-\u10D8\u10D7` : n.format === "includes" ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D5\u10D4\u10DA\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1 "${n.includes}"-\u10E1` : n.format === "regex" ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D5\u10D4\u10DA\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D4\u10E1\u10D0\u10D1\u10D0\u10DB\u10D4\u10D1\u10DD\u10D3\u10D4\u10E1 \u10E8\u10D0\u10D1\u10DA\u10DD\u10DC\u10E1 ${n.pattern}` : `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E0\u10D8\u10EA\u10EE\u10D5\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10D8\u10E7\u10DD\u10E1 ${t.divisor}-\u10D8\u10E1 \u10EF\u10D4\u10E0\u10D0\u10D3\u10D8`;
      case "unrecognized_keys":
        return `\u10E3\u10EA\u10DC\u10DD\u10D1\u10D8 \u10D2\u10D0\u10E1\u10D0\u10E6\u10D4\u10D1${t.keys.length > 1 ? "\u10D4\u10D1\u10D8" : "\u10D8"}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D2\u10D0\u10E1\u10D0\u10E6\u10D4\u10D1\u10D8 ${t.origin}-\u10E8\u10D8`;
      case "invalid_union":
        return "\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0";
      case "invalid_element":
        return `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10DB\u10DC\u10D8\u10E8\u10D5\u10DC\u10D4\u10DA\u10DD\u10D1\u10D0 ${t.origin}-\u10E8\u10D8`;
      default:
        return "\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0";
    }
  };
}, "error");
function Mu() {
  return {
    localeError: Ny()
  };
}
s(Mu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/km.js
var Ty = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u178F\u17BD\u17A2\u1780\u17D2\u179F\u179A", verb: "\u1782\u17BD\u179A\u1798\u17B6\u1793" },
    file: { unit: "\u1794\u17C3", verb: "\u1782\u17BD\u179A\u1798\u17B6\u1793" },
    array: { unit: "\u1792\u17B6\u178F\u17BB", verb: "\u1782\u17BD\u179A\u1798\u17B6\u1793" },
    set: { unit: "\u1792\u17B6\u178F\u17BB", verb: "\u1782\u17BD\u179A\u1798\u17B6\u1793" },
    map: { unit: "\u1792\u17B6\u178F\u17BB", verb: "\u1782\u17BD\u179A\u1798\u17B6\u1793" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B",
    email: "\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793\u17A2\u17CA\u17B8\u1798\u17C2\u179B",
    url: "URL",
    emoji: "\u179F\u1789\u17D2\u1789\u17B6\u17A2\u17B6\u179A\u1798\u17D2\u1798\u178E\u17CD",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u1780\u17B6\u179B\u1794\u179A\u17B7\u1785\u17D2\u1786\u17C1\u1791 \u1793\u17B7\u1784\u1798\u17C9\u17C4\u1784 ISO",
    date: "\u1780\u17B6\u179B\u1794\u179A\u17B7\u1785\u17D2\u1786\u17C1\u1791 ISO",
    time: "\u1798\u17C9\u17C4\u1784 ISO",
    duration: "\u179A\u1799\u17C8\u1796\u17C1\u179B ISO",
    ipv4: "\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793 IPv4",
    ipv6: "\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793 IPv6",
    mac: "\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793 MAC",
    cidrv4: "\u178A\u17C2\u1793\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793 IPv4",
    cidrv6: "\u178A\u17C2\u1793\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793 IPv6",
    base64: "\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u17A2\u17CA\u17B7\u1780\u17BC\u178A base64",
    base64url: "\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u17A2\u17CA\u17B7\u1780\u17BC\u178A base64url",
    json_string: "\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A JSON",
    e164: "\u179B\u17C1\u1781 E.164",
    credit_card: "\u179B\u17C1\u1781\u1794\u17D0\u178E\u17D2\u178E\u17A5\u178E\u1791\u17B6\u1793",
    jwt: "JWT",
    template_literal: "\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B"
  }, o = {
    nan: "NaN",
    number: "\u179B\u17C1\u1781",
    array: "\u17A2\u17B6\u179A\u17C1 (Array)",
    null: "\u1782\u17D2\u1798\u17B6\u1793\u178F\u1798\u17D2\u179B\u17C3 (null)"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A instanceof ${t.expected} \u1794\u17C9\u17BB\u1793\u17D2\u178F\u17C2\u1791\u1791\u17BD\u179B\u1794\u17B6\u1793 ${u}` : `\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${n} \u1794\u17C9\u17BB\u1793\u17D2\u178F\u17C2\u1791\u1791\u17BD\u179B\u1794\u17B6\u1793 ${u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${$(t.values[0])}` : `\u1787\u1798\u17D2\u179A\u17BE\u179F\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1787\u17B6\u1798\u17BD\u1799\u1780\u17D2\u1793\u17BB\u1784\u1785\u17C6\u178E\u17C4\u1798 ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u1792\u17C6\u1796\u17C1\u1780\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${t.origin ?? "\u178F\u1798\u17D2\u179B\u17C3"} ${n} ${t.maximum.toString()} ${a.unit ?? "\u1792\u17B6\u178F\u17BB"}` : `\u1792\u17C6\u1796\u17C1\u1780\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${t.origin ?? "\u178F\u1798\u17D2\u179B\u17C3"} ${n} ${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u178F\u17BC\u1785\u1796\u17C1\u1780\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${t.origin} ${n} ${t.minimum.toString()} ${a.unit}` : `\u178F\u17BC\u1785\u1796\u17C1\u1780\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${t.origin} ${n} ${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1785\u17B6\u1794\u17CB\u1795\u17D2\u178F\u17BE\u1798\u178A\u17C4\u1799 "${n.prefix}"` : n.format === "ends_with" ? `\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1794\u1789\u17D2\u1785\u1794\u17CB\u178A\u17C4\u1799 "${n.suffix}"` : n.format === "includes" ? `\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1798\u17B6\u1793 "${n.includes}"` : n.format === "regex" ? `\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u178F\u17C2\u1795\u17D2\u1782\u17BC\u1795\u17D2\u1782\u1784\u1793\u17B9\u1784\u1791\u1798\u17D2\u179A\u1784\u17CB\u178A\u17C2\u179B\u1794\u17B6\u1793\u1780\u17C6\u178E\u178F\u17CB ${n.pattern}` : `\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u179B\u17C1\u1781\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u178F\u17C2\u1787\u17B6\u1796\u17A0\u17BB\u1782\u17BB\u178E\u1793\u17C3 ${t.divisor}`;
      case "unrecognized_keys":
        return `\u179A\u1780\u1783\u17BE\u1789\u179F\u17C4\u1798\u17B7\u1793\u179F\u17D2\u1782\u17B6\u179B\u17CB\u17D6 ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `\u179F\u17C4\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u1793\u17C5\u1780\u17D2\u1793\u17BB\u1784 ${t.origin}`;
      case "invalid_union":
        return "\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C";
      case "invalid_element":
        return `\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u1793\u17C5\u1780\u17D2\u1793\u17BB\u1784 ${t.origin}`;
      default:
        return "\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C";
    }
  };
}, "error");
function Er() {
  return {
    localeError: Ty()
  };
}
s(Er, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/kh.js
function Bu() {
  return Er();
}
s(Bu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/kn.js
var Ay = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0C85\u0C95\u0CCD\u0CB7\u0CB0\u0C97\u0CB3\u0CC1", verb: "\u0CB9\u0CCA\u0C82\u0CA6\u0CB2\u0CC1" },
    file: { unit: "\u0CAC\u0CC8\u0C9F\u0CCD\u200C\u0C97\u0CB3\u0CC1", verb: "\u0CB9\u0CCA\u0C82\u0CA6\u0CB2\u0CC1" },
    array: { unit: "\u0CB5\u0CB8\u0CCD\u0CA4\u0CC1\u0C97\u0CB3\u0CC1", verb: "\u0CB9\u0CCA\u0C82\u0CA6\u0CB2\u0CC1" },
    set: { unit: "\u0CB5\u0CB8\u0CCD\u0CA4\u0CC1\u0C97\u0CB3\u0CC1", verb: "\u0CB9\u0CCA\u0C82\u0CA6\u0CB2\u0CC1" },
    map: { unit: "entries", verb: "\u0CB9\u0CCA\u0C82\u0CA6\u0CB2\u0CC1" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u0C87\u0CA8\u0CCD\u0CAA\u0CC1\u0C9F\u0CCD",
    email: "email \u0CB5\u0CBF\u0CB3\u0CBE\u0CB8",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0CA6\u0CBF\u0CA8\u0CBE\u0C82\u0C95\u0CA6 \u0CB8\u0CAE\u0CAF",
    date: "ISO \u0CA6\u0CBF\u0CA8\u0CBE\u0C82\u0C95",
    time: "ISO \u0CB8\u0CAE\u0CAF",
    duration: "ISO \u0C85\u0CB5\u0CA7\u0CBF",
    ipv4: "IPv4 \u0CB5\u0CBF\u0CB3\u0CBE\u0CB8",
    ipv6: "IPv6 \u0CB5\u0CBF\u0CB3\u0CBE\u0CB8",
    mac: "MAC \u0CB5\u0CBF\u0CB3\u0CBE\u0CB8",
    cidrv4: "IPv4 \u0CB5\u0CCD\u0CAF\u0CBE\u0CAA\u0CCD\u0CA4\u0CBF\u0CAF",
    cidrv6: "IPv6 \u0CB5\u0CCD\u0CAF\u0CBE\u0CAA\u0CCD\u0CA4\u0CBF\u0CAF",
    base64: "base64-encoded\u0CB8\u0CCD\u0C9F\u0CCD\u0CB0\u0CBF\u0C82\u0C97\u0CCD",
    base64url: "base64url-encoded\u0CB8\u0CCD\u0C9F\u0CCD\u0CB0\u0CBF\u0C82\u0C97\u0CCD",
    json_string: "JSON\u0CB8\u0CCD\u0C9F\u0CCD\u0CB0\u0CBF\u0C82\u0C97\u0CCD",
    e164: "E.164 \u0CB8\u0C82\u0C96\u0CCD\u0CAF\u0CC6",
    credit_card: "\u0C95\u0CCD\u0CB0\u0CC6\u0CA1\u0CBF\u0C9F\u0CCD \u0C95\u0CBE\u0CB0\u0CCD\u0CA1\u0CCD \u0CB8\u0C82\u0C96\u0CCD\u0CAF\u0CC6",
    jwt: "JWT",
    template_literal: "\u0C87\u0CA8\u0CCD\u0CAA\u0CC1\u0C9F\u0CCD"
  }, o = {
    // Compatibility: "nan" -> "NaN" for display
    nan: "NaN"
    // All other type names omitted - they fall back to raw values via ?? operator
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0C87\u0CA8\u0CCD\u200C\u0CAA\u0CC1\u0C9F\u0CCD: \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${n}, \u0CB8\u0CCD\u0CB5\u0CC0\u0C95\u0CB0\u0CBF\u0CB8\u0CBF\u0CA6\u0CA8\u0CC1 ${u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0C87\u0CA8\u0CCD\u200C\u0CAA\u0CC1\u0C9F\u0CCD: \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${$(t.values[0])}` : `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0C86\u0CAF\u0CCD\u0C95\u0CC6: \u0C87\u0CB5\u0CC1\u0C97\u0CB3\u0CB2\u0CCD\u0CB2\u0CBF \u0C92\u0C82\u0CA6\u0CA8\u0CCD\u0CA8\u0CC1 \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u0CA4\u0CC1\u0C82\u0CAC\u0CBE \u0CA6\u0CCA\u0CA1\u0CCD\u0CA1\u0CA6\u0CC1: \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${t.origin ?? "value"} \u0CB9\u0CCA\u0C82\u0CA6\u0CB2\u0CC1 ${n}${t.maximum.toString()} ${a.unit ?? "\u0C85\u0C82\u0CB6\u0C97\u0CB3\u0CC1"}` : `\u0CA4\u0CC1\u0C82\u0CAC\u0CBE \u0CA6\u0CCA\u0CA1\u0CCD\u0CA1\u0CA6\u0CC1: \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${t.origin ?? "value"} \u0C8E\u0C82\u0CA6\u0CC1 ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u0CA4\u0CC1\u0C82\u0CAC\u0CBE \u0C9A\u0CBF\u0C95\u0CCD\u0C95\u0CA6\u0CC1: \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${t.origin} \u0CB9\u0CCA\u0C82\u0CA6\u0CB2\u0CC1 ${n}${t.minimum.toString()} ${a.unit}` : `\u0CA4\u0CC1\u0C82\u0CAC\u0CBE \u0C9A\u0CBF\u0C95\u0CCD\u0C95\u0CA6\u0CC1: \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${t.origin} \u0C8E\u0C82\u0CA6\u0CC1 ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF\u0CB5\u0CBE\u0CA6 \u0CB8\u0CCD\u0C9F\u0CCD\u0CB0\u0CBF\u0C82\u0C97\u0CCD: \u0C87\u0CA6\u0CB0\u0CCA\u0C82\u0CA6\u0CBF\u0C97\u0CC6 \u0CAA\u0CCD\u0CB0\u0CBE\u0CB0\u0C82\u0CAD\u0CBF\u0CB8\u0CAC\u0CC7\u0C95\u0CC1 "${n.prefix}"` : n.format === "ends_with" ? `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF\u0CB5\u0CBE\u0CA6 \u0CB8\u0CCD\u0C9F\u0CCD\u0CB0\u0CBF\u0C82\u0C97\u0CCD: \u0C87\u0CA6\u0CB0\u0CCA\u0C82\u0CA6\u0CBF\u0C97\u0CC6 \u0C95\u0CCA\u0CA8\u0CC6\u0C97\u0CCA\u0CB3\u0CCD\u0CB3\u0CAC\u0CC7\u0C95\u0CC1 "${n.suffix}"` : n.format === "includes" ? `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0CB8\u0CCD\u0C9F\u0CCD\u0CB0\u0CBF\u0C82\u0C97\u0CCD: \u0C92\u0CB3\u0C97\u0CCA\u0C82\u0CA1\u0CBF\u0CB0\u0CAC\u0CC7\u0C95\u0CC1 "${n.includes}"` : n.format === "regex" ? `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF\u0CB5\u0CBE\u0CA6 \u0CB8\u0CCD\u0C9F\u0CCD\u0CB0\u0CBF\u0C82\u0C97\u0CCD: \u0CAE\u0CBE\u0CA6\u0CB0\u0CBF\u0C97\u0CC6 \u0CB9\u0CCA\u0C82\u0CA6\u0CBF\u0C95\u0CC6\u0CAF\u0CBE\u0C97\u0CAC\u0CC7\u0C95\u0CC1 ${n.pattern}` : `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0CB8\u0C82\u0C96\u0CCD\u0CAF\u0CC6: \u0CAC\u0CB9\u0CC1\u0CB8\u0C82\u0C96\u0CCD\u0CAF\u0CC6\u0CAF\u0CBE\u0C97\u0CBF\u0CB0\u0CAC\u0CC7\u0C95\u0CC1 ${t.divisor}`;
      case "unrecognized_keys":
        return `\u0C97\u0CC1\u0CB0\u0CC1\u0CA4\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CA6 \u0C95\u0CC0 ${t.keys.length > 1 ? "s" : ""}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF\u0CB5\u0CBE\u0CA6 \u0C95\u0CC0 \u0C87\u0CA8\u0CCD ${t.origin}`;
      case "invalid_union":
        return t.options && Array.isArray(t.options) && t.options.length > 0 ? `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0CA4\u0CBE\u0CB0\u0CA4\u0CAE\u0CCD\u0CAF \u0CAE\u0CCC\u0CB2\u0CCD\u0CAF. \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${t.options.map((a) => `'${a}'`).join(" | ")}` : "\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0C87\u0CA8\u0CCD\u200C\u0CAA\u0CC1\u0C9F\u0CCD";
      case "invalid_element":
        return `\u0CB0\u0CB2\u0CCD\u0CB2\u0CBF \u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0CAE\u0CCC\u0CB2\u0CCD\u0CAF ${t.origin}`;
      default:
        return "\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0C87\u0CA8\u0CCD\u200C\u0CAA\u0CC1\u0C9F\u0CCD";
    }
  };
}, "error");
function Ju() {
  return {
    localeError: Ay()
  };
}
s(Ju, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ko.js
var Uy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\uBB38\uC790", verb: "to have" },
    file: { unit: "\uBC14\uC774\uD2B8", verb: "to have" },
    array: { unit: "\uAC1C", verb: "to have" },
    set: { unit: "\uAC1C", verb: "to have" },
    map: { unit: "\uAC1C", verb: "to have" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\uC785\uB825",
    email: "\uC774\uBA54\uC77C \uC8FC\uC18C",
    url: "URL",
    emoji: "\uC774\uBAA8\uC9C0",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \uB0A0\uC9DC\uC2DC\uAC04",
    date: "ISO \uB0A0\uC9DC",
    time: "ISO \uC2DC\uAC04",
    duration: "ISO \uAE30\uAC04",
    ipv4: "IPv4 \uC8FC\uC18C",
    ipv6: "IPv6 \uC8FC\uC18C",
    mac: "MAC \uC8FC\uC18C",
    cidrv4: "IPv4 \uBC94\uC704",
    cidrv6: "IPv6 \uBC94\uC704",
    base64: "base64 \uC778\uCF54\uB529 \uBB38\uC790\uC5F4",
    base64url: "base64url \uC778\uCF54\uB529 \uBB38\uC790\uC5F4",
    json_string: "JSON \uBB38\uC790\uC5F4",
    e164: "E.164 \uBC88\uD638",
    credit_card: "\uC2E0\uC6A9\uCE74\uB4DC \uBC88\uD638",
    jwt: "JWT",
    template_literal: "\uC785\uB825"
  }, o = {
    nan: "NaN"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\uC798\uBABB\uB41C \uC785\uB825: \uC608\uC0C1 \uD0C0\uC785\uC740 instanceof ${t.expected}, \uBC1B\uC740 \uD0C0\uC785\uC740 ${u}\uC785\uB2C8\uB2E4` : `\uC798\uBABB\uB41C \uC785\uB825: \uC608\uC0C1 \uD0C0\uC785\uC740 ${n}, \uBC1B\uC740 \uD0C0\uC785\uC740 ${u}\uC785\uB2C8\uB2E4`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\uC798\uBABB\uB41C \uC785\uB825: \uAC12\uC740 ${$(t.values[0])} \uC774\uC5B4\uC57C \uD569\uB2C8\uB2E4` : `\uC798\uBABB\uB41C \uC635\uC158: ${g(t.values, "\uB610\uB294 ")} \uC911 \uD558\uB098\uC5EC\uC57C \uD569\uB2C8\uB2E4`;
      case "too_big": {
        let n = t.inclusive ? "\uC774\uD558" : "\uBBF8\uB9CC", a = n === "\uBBF8\uB9CC" ? "\uC774\uC5B4\uC57C \uD569\uB2C8\uB2E4" : "\uC5EC\uC57C \uD569\uB2C8\uB2E4", u = r(t.origin), c = u?.unit ?? "\uC694\uC18C";
        return u ? `${t.origin ?? "\uAC12"}\uC774 \uB108\uBB34 \uD07D\uB2C8\uB2E4: ${t.maximum.toString()}${c} ${n}${a}` : `${t.origin ?? "\uAC12"}\uC774 \uB108\uBB34 \uD07D\uB2C8\uB2E4: ${t.maximum.toString()} ${n}${a}`;
      }
      case "too_small": {
        let n = t.inclusive ? "\uC774\uC0C1" : "\uCD08\uACFC", a = n === "\uC774\uC0C1" ? "\uC774\uC5B4\uC57C \uD569\uB2C8\uB2E4" : "\uC5EC\uC57C \uD569\uB2C8\uB2E4", u = r(t.origin), c = u?.unit ?? "\uC694\uC18C";
        return u ? `${t.origin ?? "\uAC12"}\uC774 \uB108\uBB34 \uC791\uC2B5\uB2C8\uB2E4: ${t.minimum.toString()}${c} ${n}${a}` : `${t.origin ?? "\uAC12"}\uC774 \uB108\uBB34 \uC791\uC2B5\uB2C8\uB2E4: ${t.minimum.toString()} ${n}${a}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\uC798\uBABB\uB41C \uBB38\uC790\uC5F4: "${n.prefix}"(\uC73C)\uB85C \uC2DC\uC791\uD574\uC57C \uD569\uB2C8\uB2E4` : n.format === "ends_with" ? `\uC798\uBABB\uB41C \uBB38\uC790\uC5F4: "${n.suffix}"(\uC73C)\uB85C \uB05D\uB098\uC57C \uD569\uB2C8\uB2E4` : n.format === "includes" ? `\uC798\uBABB\uB41C \uBB38\uC790\uC5F4: "${n.includes}"\uC744(\uB97C) \uD3EC\uD568\uD574\uC57C \uD569\uB2C8\uB2E4` : n.format === "regex" ? `\uC798\uBABB\uB41C \uBB38\uC790\uC5F4: \uC815\uADDC\uC2DD ${n.pattern} \uD328\uD134\uACFC \uC77C\uCE58\uD574\uC57C \uD569\uB2C8\uB2E4` : `\uC798\uBABB\uB41C ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\uC798\uBABB\uB41C \uC22B\uC790: ${t.divisor}\uC758 \uBC30\uC218\uC5EC\uC57C \uD569\uB2C8\uB2E4`;
      case "unrecognized_keys":
        return `\uC778\uC2DD\uD560 \uC218 \uC5C6\uB294 \uD0A4: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `\uC798\uBABB\uB41C \uD0A4: ${t.origin}`;
      case "invalid_union":
        return "\uC798\uBABB\uB41C \uC785\uB825";
      case "invalid_element":
        return `\uC798\uBABB\uB41C \uAC12: ${t.origin}`;
      default:
        return "\uC798\uBABB\uB41C \uC785\uB825";
    }
  };
}, "error");
function qu() {
  return {
    localeError: Uy()
  };
}
s(qu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/lt.js
var Cr = /* @__PURE__ */ s((e) => e.charAt(0).toUpperCase() + e.slice(1), "capitalizeFirstCharacter");
function $p(e) {
  let r = Math.abs(e), i = r % 10, o = r % 100;
  return o >= 11 && o <= 19 || i === 0 ? "many" : i === 1 ? "one" : "few";
}
s($p, "getUnitTypeFromNumber");
var Ey = /* @__PURE__ */ s(() => {
  let e = {
    string: {
      unit: {
        one: "simbolis",
        few: "simboliai",
        many: "simboli\u0173"
      },
      verb: {
        smaller: {
          inclusive: "turi b\u016Bti ne ilgesn\u0117 kaip",
          notInclusive: "turi b\u016Bti trumpesn\u0117 kaip"
        },
        bigger: {
          inclusive: "turi b\u016Bti ne trumpesn\u0117 kaip",
          notInclusive: "turi b\u016Bti ilgesn\u0117 kaip"
        }
      }
    },
    file: {
      unit: {
        one: "baitas",
        few: "baitai",
        many: "bait\u0173"
      },
      verb: {
        smaller: {
          inclusive: "turi b\u016Bti ne didesnis kaip",
          notInclusive: "turi b\u016Bti ma\u017Eesnis kaip"
        },
        bigger: {
          inclusive: "turi b\u016Bti ne ma\u017Eesnis kaip",
          notInclusive: "turi b\u016Bti didesnis kaip"
        }
      }
    },
    array: {
      unit: {
        one: "element\u0105",
        few: "elementus",
        many: "element\u0173"
      },
      verb: {
        smaller: {
          inclusive: "turi tur\u0117ti ne daugiau kaip",
          notInclusive: "turi tur\u0117ti ma\u017Eiau kaip"
        },
        bigger: {
          inclusive: "turi tur\u0117ti ne ma\u017Eiau kaip",
          notInclusive: "turi tur\u0117ti daugiau kaip"
        }
      }
    },
    set: {
      unit: {
        one: "element\u0105",
        few: "elementus",
        many: "element\u0173"
      },
      verb: {
        smaller: {
          inclusive: "turi tur\u0117ti ne daugiau kaip",
          notInclusive: "turi tur\u0117ti ma\u017Eiau kaip"
        },
        bigger: {
          inclusive: "turi tur\u0117ti ne ma\u017Eiau kaip",
          notInclusive: "turi tur\u0117ti daugiau kaip"
        }
      }
    }
  };
  function r(t, n, a, u) {
    let c = e[t] ?? null;
    return c === null ? c : {
      unit: c.unit[n],
      verb: c.verb[u][a ? "inclusive" : "notInclusive"]
    };
  }
  s(r, "getSizing");
  let i = {
    regex: "\u012Fvestis",
    email: "el. pa\u0161to adresas",
    url: "URL",
    emoji: "jaustukas",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO data ir laikas",
    date: "ISO data",
    time: "ISO laikas",
    duration: "ISO trukm\u0117",
    ipv4: "IPv4 adresas",
    ipv6: "IPv6 adresas",
    mac: "MAC adresas",
    cidrv4: "IPv4 tinklo prefiksas (CIDR)",
    cidrv6: "IPv6 tinklo prefiksas (CIDR)",
    base64: "base64 u\u017Ekoduota eilut\u0117",
    base64url: "base64url u\u017Ekoduota eilut\u0117",
    json_string: "JSON eilut\u0117",
    e164: "E.164 numeris",
    credit_card: "kredito kortel\u0117s numeris",
    jwt: "JWT",
    template_literal: "\u012Fvestis"
  }, o = {
    nan: "NaN",
    number: "skai\u010Dius",
    bigint: "sveikasis skai\u010Dius",
    string: "eilut\u0117",
    boolean: "login\u0117 reik\u0161m\u0117",
    undefined: "neapibr\u0117\u017Eta reik\u0161m\u0117",
    function: "funkcija",
    symbol: "simbolis",
    array: "masyvas",
    object: "objektas",
    null: "nulin\u0117 reik\u0161m\u0117"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Gautas tipas ${u}, o tik\u0117tasi - instanceof ${t.expected}` : `Gautas tipas ${u}, o tik\u0117tasi - ${n}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Privalo b\u016Bti ${$(t.values[0])}` : `Privalo b\u016Bti vienas i\u0161 ${g(t.values, "|")} pasirinkim\u0173`;
      case "too_big": {
        let n = o[t.origin] ?? t.origin, a = r(t.origin, $p(Number(t.maximum)), t.inclusive ?? !1, "smaller");
        if (a?.verb)
          return `${Cr(n ?? t.origin ?? "reik\u0161m\u0117")} ${a.verb} ${t.maximum.toString()} ${a.unit ?? "element\u0173"}`;
        let u = t.inclusive ? "ne didesnis kaip" : "ma\u017Eesnis kaip";
        return `${Cr(n ?? t.origin ?? "reik\u0161m\u0117")} turi b\u016Bti ${u} ${t.maximum.toString()} ${a?.unit}`;
      }
      case "too_small": {
        let n = o[t.origin] ?? t.origin, a = r(t.origin, $p(Number(t.minimum)), t.inclusive ?? !1, "bigger");
        if (a?.verb)
          return `${Cr(n ?? t.origin ?? "reik\u0161m\u0117")} ${a.verb} ${t.minimum.toString()} ${a.unit ?? "element\u0173"}`;
        let u = t.inclusive ? "ne ma\u017Eesnis kaip" : "didesnis kaip";
        return `${Cr(n ?? t.origin ?? "reik\u0161m\u0117")} turi b\u016Bti ${u} ${t.minimum.toString()} ${a?.unit}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Eilut\u0117 privalo prasid\u0117ti "${n.prefix}"` : n.format === "ends_with" ? `Eilut\u0117 privalo pasibaigti "${n.suffix}"` : n.format === "includes" ? `Eilut\u0117 privalo \u012Ftraukti "${n.includes}"` : n.format === "regex" ? `Eilut\u0117 privalo atitikti ${n.pattern}` : `Neteisingas ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Skai\u010Dius privalo b\u016Bti ${t.divisor} kartotinis.`;
      case "unrecognized_keys":
        return `Neatpa\u017Eint${t.keys.length > 1 ? "i" : "as"} rakt${t.keys.length > 1 ? "ai" : "as"}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return "Rastas klaidingas raktas";
      case "invalid_union":
        return "Klaidinga \u012Fvestis";
      case "invalid_element": {
        let n = o[t.origin] ?? t.origin;
        return `${Cr(n ?? t.origin ?? "reik\u0161m\u0117")} turi klaiding\u0105 \u012Fvest\u012F`;
      }
      default:
        return "Klaidinga \u012Fvestis";
    }
  };
}, "error");
function Ku() {
  return {
    localeError: Ey()
  };
}
s(Ku, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/mk.js
var Cy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0437\u043D\u0430\u0446\u0438", verb: "\u0434\u0430 \u0438\u043C\u0430\u0430\u0442" },
    file: { unit: "\u0431\u0430\u0458\u0442\u0438", verb: "\u0434\u0430 \u0438\u043C\u0430\u0430\u0442" },
    array: { unit: "\u0441\u0442\u0430\u0432\u043A\u0438", verb: "\u0434\u0430 \u0438\u043C\u0430\u0430\u0442" },
    set: { unit: "\u0441\u0442\u0430\u0432\u043A\u0438", verb: "\u0434\u0430 \u0438\u043C\u0430\u0430\u0442" },
    map: { unit: "\u0441\u0442\u0430\u0432\u043A\u0438", verb: "\u0434\u0430 \u0438\u043C\u0430\u0430\u0442" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u0432\u043D\u0435\u0441",
    email: "\u0430\u0434\u0440\u0435\u0441\u0430 \u043D\u0430 \u0435-\u043F\u043E\u0448\u0442\u0430",
    url: "URL",
    emoji: "\u0435\u043C\u043E\u045F\u0438",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0434\u0430\u0442\u0443\u043C \u0438 \u0432\u0440\u0435\u043C\u0435",
    date: "ISO \u0434\u0430\u0442\u0443\u043C",
    time: "ISO \u0432\u0440\u0435\u043C\u0435",
    duration: "ISO \u0432\u0440\u0435\u043C\u0435\u0442\u0440\u0430\u0435\u045A\u0435",
    ipv4: "IPv4 \u0430\u0434\u0440\u0435\u0441\u0430",
    ipv6: "IPv6 \u0430\u0434\u0440\u0435\u0441\u0430",
    mac: "MAC \u0430\u0434\u0440\u0435\u0441\u0430",
    cidrv4: "IPv4 \u043E\u043F\u0441\u0435\u0433",
    cidrv6: "IPv6 \u043E\u043F\u0441\u0435\u0433",
    base64: "base64-\u0435\u043D\u043A\u043E\u0434\u0438\u0440\u0430\u043D\u0430 \u043D\u0438\u0437\u0430",
    base64url: "base64url-\u0435\u043D\u043A\u043E\u0434\u0438\u0440\u0430\u043D\u0430 \u043D\u0438\u0437\u0430",
    json_string: "JSON \u043D\u0438\u0437\u0430",
    e164: "E.164 \u0431\u0440\u043E\u0458",
    credit_card: "\u0431\u0440\u043E\u0458 \u043D\u0430 \u043A\u0440\u0435\u0434\u0438\u0442\u043D\u0430 \u043A\u0430\u0440\u0442\u0438\u0447\u043A\u0430",
    jwt: "JWT",
    template_literal: "\u0432\u043D\u0435\u0441"
  }, o = {
    nan: "NaN",
    number: "\u0431\u0440\u043E\u0458",
    array: "\u043D\u0438\u0437\u0430"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u0413\u0440\u0435\u0448\u0435\u043D \u0432\u043D\u0435\u0441: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 instanceof ${t.expected}, \u043F\u0440\u0438\u043C\u0435\u043D\u043E ${u}` : `\u0413\u0440\u0435\u0448\u0435\u043D \u0432\u043D\u0435\u0441: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${n}, \u043F\u0440\u0438\u043C\u0435\u043D\u043E ${u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Invalid input: expected ${$(t.values[0])}` : `\u0413\u0440\u0435\u0448\u0430\u043D\u0430 \u043E\u043F\u0446\u0438\u0458\u0430: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 \u0435\u0434\u043D\u0430 ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u041F\u0440\u0435\u043C\u043D\u043E\u0433\u0443 \u0433\u043E\u043B\u0435\u043C: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${t.origin ?? "\u0432\u0440\u0435\u0434\u043D\u043E\u0441\u0442\u0430"} \u0434\u0430 \u0438\u043C\u0430 ${n}${t.maximum.toString()} ${a.unit ?? "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0438"}` : `\u041F\u0440\u0435\u043C\u043D\u043E\u0433\u0443 \u0433\u043E\u043B\u0435\u043C: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${t.origin ?? "\u0432\u0440\u0435\u0434\u043D\u043E\u0441\u0442\u0430"} \u0434\u0430 \u0431\u0438\u0434\u0435 ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u041F\u0440\u0435\u043C\u043D\u043E\u0433\u0443 \u043C\u0430\u043B: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${t.origin} \u0434\u0430 \u0438\u043C\u0430 ${n}${t.minimum.toString()} ${a.unit}` : `\u041F\u0440\u0435\u043C\u043D\u043E\u0433\u0443 \u043C\u0430\u043B: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${t.origin} \u0434\u0430 \u0431\u0438\u0434\u0435 ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u041D\u0435\u0432\u0430\u0436\u0435\u0447\u043A\u0430 \u043D\u0438\u0437\u0430: \u043C\u043E\u0440\u0430 \u0434\u0430 \u0437\u0430\u043F\u043E\u0447\u043D\u0443\u0432\u0430 \u0441\u043E "${n.prefix}"` : n.format === "ends_with" ? `\u041D\u0435\u0432\u0430\u0436\u0435\u0447\u043A\u0430 \u043D\u0438\u0437\u0430: \u043C\u043E\u0440\u0430 \u0434\u0430 \u0437\u0430\u0432\u0440\u0448\u0443\u0432\u0430 \u0441\u043E "${n.suffix}"` : n.format === "includes" ? `\u041D\u0435\u0432\u0430\u0436\u0435\u0447\u043A\u0430 \u043D\u0438\u0437\u0430: \u043C\u043E\u0440\u0430 \u0434\u0430 \u0432\u043A\u043B\u0443\u0447\u0443\u0432\u0430 "${n.includes}"` : n.format === "regex" ? `\u041D\u0435\u0432\u0430\u0436\u0435\u0447\u043A\u0430 \u043D\u0438\u0437\u0430: \u043C\u043E\u0440\u0430 \u0434\u0430 \u043E\u0434\u0433\u043E\u0430\u0440\u0430 \u043D\u0430 \u043F\u0430\u0442\u0435\u0440\u043D\u043E\u0442 ${n.pattern}` : `Invalid ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u0413\u0440\u0435\u0448\u0435\u043D \u0431\u0440\u043E\u0458: \u043C\u043E\u0440\u0430 \u0434\u0430 \u0431\u0438\u0434\u0435 \u0434\u0435\u043B\u0438\u0432 \u0441\u043E ${t.divisor}`;
      case "unrecognized_keys":
        return `${t.keys.length > 1 ? "\u041D\u0435\u043F\u0440\u0435\u043F\u043E\u0437\u043D\u0430\u0435\u043D\u0438 \u043A\u043B\u0443\u0447\u0435\u0432\u0438" : "\u041D\u0435\u043F\u0440\u0435\u043F\u043E\u0437\u043D\u0430\u0435\u043D \u043A\u043B\u0443\u0447"}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `\u0413\u0440\u0435\u0448\u0435\u043D \u043A\u043B\u0443\u0447 \u0432\u043E ${t.origin}`;
      case "invalid_union":
        return "\u0413\u0440\u0435\u0448\u0435\u043D \u0432\u043D\u0435\u0441";
      case "invalid_element":
        return `\u0413\u0440\u0435\u0448\u043D\u0430 \u0432\u0440\u0435\u0434\u043D\u043E\u0441\u0442 \u0432\u043E ${t.origin}`;
      default:
        return "\u0413\u0440\u0435\u0448\u0435\u043D \u0432\u043D\u0435\u0441";
    }
  };
}, "error");
function Wu() {
  return {
    localeError: Cy()
  };
}
s(Wu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ms.js
var Zy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "aksara", verb: "mempunyai" },
    file: { unit: "bait", verb: "mempunyai" },
    array: { unit: "elemen", verb: "mempunyai" },
    set: { unit: "elemen", verb: "mempunyai" },
    map: { unit: "elemen", verb: "mempunyai" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "input",
    email: "alamat e-mel",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "tarikh masa ISO",
    date: "tarikh ISO",
    time: "masa ISO",
    duration: "tempoh ISO",
    ipv4: "alamat IPv4",
    ipv6: "alamat IPv6",
    mac: "alamat MAC",
    cidrv4: "julat IPv4",
    cidrv6: "julat IPv6",
    base64: "string dikodkan base64",
    base64url: "string dikodkan base64url",
    json_string: "string JSON",
    e164: "nombor E.164",
    credit_card: "nombor kad kredit",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN",
    number: "nombor"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Input tidak sah: dijangka instanceof ${t.expected}, diterima ${u}` : `Input tidak sah: dijangka ${n}, diterima ${u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Input tidak sah: dijangka ${$(t.values[0])}` : `Pilihan tidak sah: dijangka salah satu daripada ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Terlalu besar: dijangka ${t.origin ?? "nilai"} ${a.verb} ${n}${t.maximum.toString()} ${a.unit ?? "elemen"}` : `Terlalu besar: dijangka ${t.origin ?? "nilai"} adalah ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Terlalu kecil: dijangka ${t.origin} ${a.verb} ${n}${t.minimum.toString()} ${a.unit}` : `Terlalu kecil: dijangka ${t.origin} adalah ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `String tidak sah: mesti bermula dengan "${n.prefix}"` : n.format === "ends_with" ? `String tidak sah: mesti berakhir dengan "${n.suffix}"` : n.format === "includes" ? `String tidak sah: mesti mengandungi "${n.includes}"` : n.format === "regex" ? `String tidak sah: mesti sepadan dengan corak ${n.pattern}` : `${i[n.format] ?? t.format} tidak sah`;
      }
      case "not_multiple_of":
        return `Nombor tidak sah: perlu gandaan ${t.divisor}`;
      case "unrecognized_keys":
        return `Kunci tidak dikenali: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `Kunci tidak sah dalam ${t.origin}`;
      case "invalid_union":
        return "Input tidak sah";
      case "invalid_element":
        return `Nilai tidak sah dalam ${t.origin}`;
      default:
        return "Input tidak sah";
    }
  };
}, "error");
function Gu() {
  return {
    localeError: Zy()
  };
}
s(Gu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ne.js
var Ry = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0905\u0915\u094D\u0937\u0930", verb: "\u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B" },
    file: { unit: "\u092C\u093E\u0907\u091F", verb: "\u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B" },
    array: { unit: "\u0924\u0924\u094D\u0935", verb: "\u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B" },
    set: { unit: "\u0924\u0924\u094D\u0935", verb: "\u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B" },
    map: { unit: "\u092A\u094D\u0930\u0935\u093F\u0937\u094D\u091F\u093F", verb: "\u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u0907\u0928\u092A\u0941\u091F",
    email: "\u0907\u092E\u0947\u0932 \u0920\u0947\u0917\u093E\u0928\u093E",
    url: "URL",
    emoji: "\u0907\u092E\u094B\u091C\u0940",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u092E\u093F\u0924\u093F \u0930 \u0938\u092E\u092F",
    date: "ISO \u092E\u093F\u0924\u093F",
    time: "ISO \u0938\u092E\u092F",
    duration: "ISO \u0905\u0935\u0927\u093F",
    ipv4: "IPv4 \u0920\u0947\u0917\u093E\u0928\u093E",
    ipv6: "IPv6 \u0920\u0947\u0917\u093E\u0928\u093E",
    mac: "MAC \u0920\u0947\u0917\u093E\u0928\u093E",
    cidrv4: "IPv4 \u0926\u093E\u092F\u0930\u093E",
    cidrv6: "IPv6 \u0926\u093E\u092F\u0930\u093E",
    base64: "base64-\u0907\u0928\u094D\u0915\u094B\u0921 \u0917\u0930\u093F\u090F\u0915\u094B \u0938\u094D\u091F\u094D\u0930\u093F\u0919",
    base64url: "base64url-\u0907\u0928\u094D\u0915\u094B\u0921 \u0917\u0930\u093F\u090F\u0915\u094B \u0938\u094D\u091F\u094D\u0930\u093F\u0919",
    json_string: "JSON \u0938\u094D\u091F\u094D\u0930\u093F\u0919",
    e164: "E.164 \u0928\u092E\u094D\u092C\u0930",
    credit_card: "\u0915\u094D\u0930\u0947\u0921\u093F\u091F \u0915\u093E\u0930\u094D\u0921 \u0928\u092E\u094D\u092C\u0930",
    jwt: "JWT",
    template_literal: "\u0907\u0928\u092A\u0941\u091F"
  }, o = {
    nan: "NaN"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return `\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 ${n}, \u092A\u094D\u0930\u093E\u092A\u094D\u0924 ${u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 ${$(t.values[0])}` : `\u0905\u092E\u093E\u0928\u094D\u092F \u0935\u093F\u0915\u0932\u094D\u092A: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 \u092E\u093E\u0928\u0939\u0930\u0942 \u092E\u0927\u094D\u092F\u0947 \u090F\u0915 ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u0927\u0947\u0930\u0948 \u0920\u0942\u0932\u094B: ${t.origin ?? "\u092E\u093E\u0928"} \u092E\u093E ${n}${t.maximum.toString()} ${a.unit} ${a.verb}` : `\u0927\u0947\u0930\u0948 \u0920\u0942\u0932\u094B: ${t.origin ?? "\u092E\u093E\u0928"} ${n}${t.maximum.toString()} \u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u0927\u0947\u0930\u0948 \u0938\u093E\u0928\u094B: ${t.origin} \u092E\u093E ${n}${t.minimum.toString()} ${a.unit} ${a.verb}` : `\u0927\u0947\u0930\u0948 \u0938\u093E\u0928\u094B: ${t.origin} ${n}${t.minimum.toString()} \u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0919: "${n.prefix}" \u092C\u093E\u091F \u0938\u0941\u0930\u0941 \u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B` : n.format === "ends_with" ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0919: "${n.suffix}" \u092E\u093E \u0938\u092E\u093E\u092A\u094D\u0924 \u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B` : n.format === "includes" ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0919: "${n.includes}" \u0938\u092E\u093E\u0935\u0947\u0936 \u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B` : n.format === "regex" ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0919: \u0922\u093E\u0901\u091A\u093E ${n.pattern} \u0938\u0901\u0917 \u092E\u0947\u0932 \u0916\u093E\u0928\u0941\u092A\u0930\u094D\u091B` : `\u0905\u092E\u093E\u0928\u094D\u092F ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u0902\u0916\u094D\u092F\u093E: ${t.divisor} \u0915\u094B \u0917\u0941\u0923\u091C \u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B`;
      case "unrecognized_keys":
        return `\u0905\u092A\u0930\u093F\u091A\u093F\u0924 \u0915\u0941\u091E\u094D\u091C\u0940${t.keys.length > 1 ? "\u0939\u0930\u0942" : ""}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `\u0905\u092E\u093E\u0928\u094D\u092F \u0915\u0941\u091E\u094D\u091C\u0940: ${t.origin} \u092E\u093E`;
      case "invalid_union":
        return t.options && Array.isArray(t.options) && t.options.length > 0 ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0921\u093F\u0938\u094D\u0915\u094D\u0930\u093F\u092E\u093F\u0928\u0947\u091F\u0930 \u092E\u093E\u0928: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 ${t.options.map((a) => `'${a}'`).join(" | ")}` : "\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F";
      case "invalid_element":
        return `\u0905\u092E\u093E\u0928\u094D\u092F \u092E\u093E\u0928: ${t.origin} \u092E\u093E`;
      default:
        return "\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F";
    }
  };
}, "error");
function Xu() {
  return {
    localeError: Ry()
  };
}
s(Xu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/nl.js
var Fy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "tekens", verb: "heeft" },
    file: { unit: "bytes", verb: "heeft" },
    array: { unit: "elementen", verb: "heeft" },
    set: { unit: "elementen", verb: "heeft" },
    map: { unit: "elementen", verb: "heeft" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "invoer",
    email: "emailadres",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datum en tijd",
    date: "ISO datum",
    time: "ISO tijd",
    duration: "ISO duur",
    ipv4: "IPv4-adres",
    ipv6: "IPv6-adres",
    mac: "MAC-adres",
    cidrv4: "IPv4-bereik",
    cidrv6: "IPv6-bereik",
    base64: "base64-gecodeerde tekst",
    base64url: "base64 URL-gecodeerde tekst",
    json_string: "JSON string",
    e164: "E.164-nummer",
    credit_card: "creditcardnummer",
    jwt: "JWT",
    template_literal: "invoer"
  }, o = {
    nan: "NaN",
    number: "getal"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Ongeldige invoer: verwacht instanceof ${t.expected}, ontving ${u}` : `Ongeldige invoer: verwacht ${n}, ontving ${u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Ongeldige invoer: verwacht ${$(t.values[0])}` : `Ongeldige optie: verwacht \xE9\xE9n van ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin), u = t.origin === "date" ? "laat" : t.origin === "string" ? "lang" : "groot";
        return a ? `Te ${u}: verwacht dat ${t.origin ?? "waarde"} ${n}${t.maximum.toString()} ${a.unit ?? "elementen"} ${a.verb}` : `Te ${u}: verwacht dat ${t.origin ?? "waarde"} ${n}${t.maximum.toString()} is`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin), u = t.origin === "date" ? "vroeg" : t.origin === "string" ? "kort" : "klein";
        return a ? `Te ${u}: verwacht dat ${t.origin} ${n}${t.minimum.toString()} ${a.unit} ${a.verb}` : `Te ${u}: verwacht dat ${t.origin} ${n}${t.minimum.toString()} is`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Ongeldige tekst: moet met "${n.prefix}" beginnen` : n.format === "ends_with" ? `Ongeldige tekst: moet op "${n.suffix}" eindigen` : n.format === "includes" ? `Ongeldige tekst: moet "${n.includes}" bevatten` : n.format === "regex" ? `Ongeldige tekst: moet overeenkomen met patroon ${n.pattern}` : `Ongeldig: ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Ongeldig getal: moet een veelvoud van ${t.divisor} zijn`;
      case "unrecognized_keys":
        return `Onbekende key${t.keys.length > 1 ? "s" : ""}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `Ongeldige key in ${t.origin}`;
      case "invalid_union":
        return "Ongeldige invoer";
      case "invalid_element":
        return `Ongeldige waarde in ${t.origin}`;
      default:
        return "Ongeldige invoer";
    }
  };
}, "error");
function Hu() {
  return {
    localeError: Fy()
  };
}
s(Hu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/nn.js
var Ly = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "teikn", verb: "\xE5 ha" },
    file: { unit: "bytes", verb: "\xE5 ha" },
    array: { unit: "element", verb: "\xE5 innehalde" },
    set: { unit: "element", verb: "\xE5 innehalde" },
    map: { unit: "element", verb: "\xE5 innehalde" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "input",
    email: "e-postadresse",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO dato- og klokkeslett",
    date: "ISO-dato",
    time: "ISO-klokkeslett",
    duration: "ISO-varigheit",
    ipv4: "IPv4-adresse",
    ipv6: "IPv6-adresse",
    mac: "MAC-adresse",
    cidrv4: "IPv4-spekter",
    cidrv6: "IPv6-spekter",
    base64: "base64-enkoda streng",
    base64url: "base64url-enkoda streng",
    json_string: "JSON-streng",
    e164: "E.164-nummer",
    credit_card: "kredittkortnummer",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN",
    number: "tal",
    array: "liste"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Ugyldig input: forventa instanceof ${t.expected}, fekk ${u}` : `Ugyldig input: forventa ${n}, fekk ${u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Ugyldig verdi: forventa ${$(t.values[0])}` : `Ugyldig val: forventa eitt av ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `For stor(t): forventa ${t.origin ?? "value"} til \xE5 ha ${n}${t.maximum.toString()} ${a.unit ?? "element"}` : `For stor(t): forventa ${t.origin ?? "value"} til \xE5 ha ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `For lite(n): forventa ${t.origin} til \xE5 ha ${n}${t.minimum.toString()} ${a.unit}` : `For lite(n): forventa ${t.origin} til \xE5 ha ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Ugyldig streng: m\xE5 starte med "${n.prefix}"` : n.format === "ends_with" ? `Ugyldig streng: m\xE5 slutte med "${n.suffix}"` : n.format === "includes" ? `Ugyldig streng: m\xE5 innehalde "${n.includes}"` : n.format === "regex" ? `Ugyldig streng: m\xE5 matche m\xF8nsteret ${n.pattern}` : `Ugyldig ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Ugyldig tal: m\xE5 vere eit multiplum av ${t.divisor}`;
      case "unrecognized_keys":
        return `${t.keys.length > 1 ? "Ukjende n\xF8klar" : "Ukjend n\xF8kkel"}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `Ugyldig n\xF8kkel i ${t.origin}`;
      case "invalid_union":
        return "Ugyldig input";
      case "invalid_element":
        return `Ugyldig verdi i ${t.origin}`;
      default:
        return "Ugyldig input";
    }
  };
}, "error");
function Qu() {
  return {
    localeError: Ly()
  };
}
s(Qu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/no.js
var Vy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "tegn", verb: "\xE5 ha" },
    file: { unit: "bytes", verb: "\xE5 ha" },
    array: { unit: "elementer", verb: "\xE5 inneholde" },
    set: { unit: "elementer", verb: "\xE5 inneholde" },
    map: { unit: "elementer", verb: "\xE5 inneholde" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "input",
    email: "e-postadresse",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO dato- og klokkeslett",
    date: "ISO-dato",
    time: "ISO-klokkeslett",
    duration: "ISO-varighet",
    ipv4: "IPv4-adresse",
    ipv6: "IPv6-adresse",
    mac: "MAC-adresse",
    cidrv4: "IPv4-spekter",
    cidrv6: "IPv6-spekter",
    base64: "base64-enkodet streng",
    base64url: "base64url-enkodet streng",
    json_string: "JSON-streng",
    e164: "E.164-nummer",
    credit_card: "kredittkortnummer",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN",
    number: "tall",
    array: "liste"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Ugyldig input: forventet instanceof ${t.expected}, fikk ${u}` : `Ugyldig input: forventet ${n}, fikk ${u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Ugyldig verdi: forventet ${$(t.values[0])}` : `Ugyldig valg: forventet en av ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `For stor(t): forventet ${t.origin ?? "value"} til \xE5 ha ${n}${t.maximum.toString()} ${a.unit ?? "elementer"}` : `For stor(t): forventet ${t.origin ?? "value"} til \xE5 ha ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `For lite(n): forventet ${t.origin} til \xE5 ha ${n}${t.minimum.toString()} ${a.unit}` : `For lite(n): forventet ${t.origin} til \xE5 ha ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Ugyldig streng: m\xE5 starte med "${n.prefix}"` : n.format === "ends_with" ? `Ugyldig streng: m\xE5 ende med "${n.suffix}"` : n.format === "includes" ? `Ugyldig streng: m\xE5 inneholde "${n.includes}"` : n.format === "regex" ? `Ugyldig streng: m\xE5 matche m\xF8nsteret ${n.pattern}` : `Ugyldig ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Ugyldig tall: m\xE5 v\xE6re et multiplum av ${t.divisor}`;
      case "unrecognized_keys":
        return `${t.keys.length > 1 ? "Ukjente n\xF8kler" : "Ukjent n\xF8kkel"}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `Ugyldig n\xF8kkel i ${t.origin}`;
      case "invalid_union":
        return "Ugyldig input";
      case "invalid_element":
        return `Ugyldig verdi i ${t.origin}`;
      default:
        return "Ugyldig input";
    }
  };
}, "error");
function Yu() {
  return {
    localeError: Vy()
  };
}
s(Yu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ota.js
var My = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "harf", verb: "olmal\u0131d\u0131r" },
    file: { unit: "bayt", verb: "olmal\u0131d\u0131r" },
    array: { unit: "unsur", verb: "olmal\u0131d\u0131r" },
    set: { unit: "unsur", verb: "olmal\u0131d\u0131r" },
    map: { unit: "unsur", verb: "olmal\u0131d\u0131r" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "giren",
    email: "epostag\xE2h",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO heng\xE2m\u0131",
    date: "ISO tarihi",
    time: "ISO zaman\u0131",
    duration: "ISO m\xFCddeti",
    ipv4: "IPv4 ni\u015F\xE2n\u0131",
    ipv6: "IPv6 ni\u015F\xE2n\u0131",
    mac: "MAC ni\u015F\xE2n\u0131",
    cidrv4: "IPv4 menzili",
    cidrv6: "IPv6 menzili",
    base64: "base64-\u015Fifreli metin",
    base64url: "base64url-\u015Fifreli metin",
    json_string: "JSON metin",
    e164: "E.164 say\u0131s\u0131",
    credit_card: "i'tib\xE2r kart\u0131 numaras\u0131",
    jwt: "JWT",
    template_literal: "giren"
  }, o = {
    nan: "NaN",
    number: "numara",
    array: "saf",
    null: "gayb"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `F\xE2sit giren: umulan instanceof ${t.expected}, al\u0131nan ${u}` : `F\xE2sit giren: umulan ${n}, al\u0131nan ${u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `F\xE2sit giren: umulan ${$(t.values[0])}` : `F\xE2sit tercih: m\xFBteberler ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Fazla b\xFCy\xFCk: ${t.origin ?? "value"}, ${n}${t.maximum.toString()} ${a.unit ?? "elements"} sahip olmal\u0131yd\u0131.` : `Fazla b\xFCy\xFCk: ${t.origin ?? "value"}, ${n}${t.maximum.toString()} olmal\u0131yd\u0131.`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Fazla k\xFC\xE7\xFCk: ${t.origin}, ${n}${t.minimum.toString()} ${a.unit} sahip olmal\u0131yd\u0131.` : `Fazla k\xFC\xE7\xFCk: ${t.origin}, ${n}${t.minimum.toString()} olmal\u0131yd\u0131.`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `F\xE2sit metin: "${n.prefix}" ile ba\u015Flamal\u0131.` : n.format === "ends_with" ? `F\xE2sit metin: "${n.suffix}" ile bitmeli.` : n.format === "includes" ? `F\xE2sit metin: "${n.includes}" ihtiv\xE2 etmeli.` : n.format === "regex" ? `F\xE2sit metin: ${n.pattern} nak\u015F\u0131na uymal\u0131.` : `F\xE2sit ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `F\xE2sit say\u0131: ${t.divisor} kat\u0131 olmal\u0131yd\u0131.`;
      case "unrecognized_keys":
        return `Tan\u0131nmayan anahtar ${t.keys.length > 1 ? "s" : ""}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `${t.origin} i\xE7in tan\u0131nmayan anahtar var.`;
      case "invalid_union":
        return "Giren tan\u0131namad\u0131.";
      case "invalid_element":
        return `${t.origin} i\xE7in tan\u0131nmayan k\u0131ymet var.`;
      default:
        return "K\u0131ymet tan\u0131namad\u0131.";
    }
  };
}, "error");
function ec() {
  return {
    localeError: My()
  };
}
s(ec, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ps.js
var By = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u062A\u0648\u06A9\u064A", verb: "\u0648\u0644\u0631\u064A" },
    file: { unit: "\u0628\u0627\u06CC\u067C\u0633", verb: "\u0648\u0644\u0631\u064A" },
    array: { unit: "\u062A\u0648\u06A9\u064A", verb: "\u0648\u0644\u0631\u064A" },
    set: { unit: "\u062A\u0648\u06A9\u064A", verb: "\u0648\u0644\u0631\u064A" },
    map: { unit: "\u062A\u0648\u06A9\u064A", verb: "\u0648\u0644\u0631\u064A" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u0648\u0631\u0648\u062F\u064A",
    email: "\u0628\u0631\u06CC\u069A\u0646\u0627\u0644\u06CC\u06A9",
    url: "\u06CC\u0648 \u0622\u0631 \u0627\u0644",
    emoji: "\u0627\u06CC\u0645\u0648\u062C\u064A",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u0646\u06CC\u067C\u0647 \u0627\u0648 \u0648\u062E\u062A",
    date: "\u0646\u06D0\u067C\u0647",
    time: "\u0648\u062E\u062A",
    duration: "\u0645\u0648\u062F\u0647",
    ipv4: "\u062F IPv4 \u067E\u062A\u0647",
    ipv6: "\u062F IPv6 \u067E\u062A\u0647",
    mac: "\u062F MAC \u067E\u062A\u0647",
    cidrv4: "\u062F IPv4 \u0633\u0627\u062D\u0647",
    cidrv6: "\u062F IPv6 \u0633\u0627\u062D\u0647",
    base64: "base64-encoded \u0645\u062A\u0646",
    base64url: "base64url-encoded \u0645\u062A\u0646",
    json_string: "JSON \u0645\u062A\u0646",
    e164: "\u062F E.164 \u0634\u0645\u06D0\u0631\u0647",
    credit_card: "\u062F \u06A9\u0631\u06CC\u0689\u06CC\u067C \u06A9\u0627\u0631\u062A \u0634\u0645\u06CC\u0631\u0647",
    jwt: "JWT",
    template_literal: "\u0648\u0631\u0648\u062F\u064A"
  }, o = {
    nan: "NaN",
    number: "\u0639\u062F\u062F",
    array: "\u0627\u0631\u06D0"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u0646\u0627\u0633\u0645 \u0648\u0631\u0648\u062F\u064A: \u0628\u0627\u06CC\u062F instanceof ${t.expected} \u0648\u0627\u06CC, \u0645\u06AB\u0631 ${u} \u062A\u0631\u0644\u0627\u0633\u0647 \u0634\u0648` : `\u0646\u0627\u0633\u0645 \u0648\u0631\u0648\u062F\u064A: \u0628\u0627\u06CC\u062F ${n} \u0648\u0627\u06CC, \u0645\u06AB\u0631 ${u} \u062A\u0631\u0644\u0627\u0633\u0647 \u0634\u0648`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u0646\u0627\u0633\u0645 \u0648\u0631\u0648\u062F\u064A: \u0628\u0627\u06CC\u062F ${$(t.values[0])} \u0648\u0627\u06CC` : `\u0646\u0627\u0633\u0645 \u0627\u0646\u062A\u062E\u0627\u0628: \u0628\u0627\u06CC\u062F \u06CC\u0648 \u0644\u0647 ${g(t.values, "|")} \u0685\u062E\u0647 \u0648\u0627\u06CC`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u0689\u06CC\u0631 \u0644\u0648\u06CC: ${t.origin ?? "\u0627\u0631\u0632\u069A\u062A"} \u0628\u0627\u06CC\u062F ${n}${t.maximum.toString()} ${a.unit ?? "\u0639\u0646\u0635\u0631\u0648\u0646\u0647"} \u0648\u0644\u0631\u064A` : `\u0689\u06CC\u0631 \u0644\u0648\u06CC: ${t.origin ?? "\u0627\u0631\u0632\u069A\u062A"} \u0628\u0627\u06CC\u062F ${n}${t.maximum.toString()} \u0648\u064A`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u0689\u06CC\u0631 \u06A9\u0648\u0686\u0646\u06CC: ${t.origin} \u0628\u0627\u06CC\u062F ${n}${t.minimum.toString()} ${a.unit} \u0648\u0644\u0631\u064A` : `\u0689\u06CC\u0631 \u06A9\u0648\u0686\u0646\u06CC: ${t.origin} \u0628\u0627\u06CC\u062F ${n}${t.minimum.toString()} \u0648\u064A`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u0646\u0627\u0633\u0645 \u0645\u062A\u0646: \u0628\u0627\u06CC\u062F \u062F "${n.prefix}" \u0633\u0631\u0647 \u067E\u06CC\u0644 \u0634\u064A` : n.format === "ends_with" ? `\u0646\u0627\u0633\u0645 \u0645\u062A\u0646: \u0628\u0627\u06CC\u062F \u062F "${n.suffix}" \u0633\u0631\u0647 \u067E\u0627\u06CC \u062A\u0647 \u0648\u0631\u0633\u064A\u0696\u064A` : n.format === "includes" ? `\u0646\u0627\u0633\u0645 \u0645\u062A\u0646: \u0628\u0627\u06CC\u062F "${n.includes}" \u0648\u0644\u0631\u064A` : n.format === "regex" ? `\u0646\u0627\u0633\u0645 \u0645\u062A\u0646: \u0628\u0627\u06CC\u062F \u062F ${n.pattern} \u0633\u0631\u0647 \u0645\u0637\u0627\u0628\u0642\u062A \u0648\u0644\u0631\u064A` : `${i[n.format] ?? t.format} \u0646\u0627\u0633\u0645 \u062F\u06CC`;
      }
      case "not_multiple_of":
        return `\u0646\u0627\u0633\u0645 \u0639\u062F\u062F: \u0628\u0627\u06CC\u062F \u062F ${t.divisor} \u0645\u0636\u0631\u0628 \u0648\u064A`;
      case "unrecognized_keys":
        return `\u0646\u0627\u0633\u0645 ${t.keys.length > 1 ? "\u06A9\u0644\u06CC\u0689\u0648\u0646\u0647" : "\u06A9\u0644\u06CC\u0689"}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `\u0646\u0627\u0633\u0645 \u06A9\u0644\u06CC\u0689 \u067E\u0647 ${t.origin} \u06A9\u06D0`;
      case "invalid_union":
        return "\u0646\u0627\u0633\u0645\u0647 \u0648\u0631\u0648\u062F\u064A";
      case "invalid_element":
        return `\u0646\u0627\u0633\u0645 \u0639\u0646\u0635\u0631 \u067E\u0647 ${t.origin} \u06A9\u06D0`;
      default:
        return "\u0646\u0627\u0633\u0645\u0647 \u0648\u0631\u0648\u062F\u064A";
    }
  };
}, "error");
function tc() {
  return {
    localeError: By()
  };
}
s(tc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/pl.js
var Jy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "znak\xF3w", verb: "mie\u0107" },
    file: { unit: "bajt\xF3w", verb: "mie\u0107" },
    array: { unit: "element\xF3w", verb: "mie\u0107" },
    set: { unit: "element\xF3w", verb: "mie\u0107" },
    map: { unit: "element\xF3w", verb: "mie\u0107" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "wyra\u017Cenie",
    email: "adres email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "data i godzina w formacie ISO",
    date: "data w formacie ISO",
    time: "godzina w formacie ISO",
    duration: "czas trwania ISO",
    ipv4: "adres IPv4",
    ipv6: "adres IPv6",
    mac: "adres MAC",
    cidrv4: "zakres IPv4",
    cidrv6: "zakres IPv6",
    base64: "ci\u0105g znak\xF3w zakodowany w formacie base64",
    base64url: "ci\u0105g znak\xF3w zakodowany w formacie base64url",
    json_string: "ci\u0105g znak\xF3w w formacie JSON",
    e164: "liczba E.164",
    credit_card: "numer karty kredytowej",
    jwt: "JWT",
    template_literal: "wej\u015Bcie"
  }, o = {
    nan: "NaN",
    number: "liczba",
    array: "tablica"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Nieprawid\u0142owe dane wej\u015Bciowe: oczekiwano instanceof ${t.expected}, otrzymano ${u}` : `Nieprawid\u0142owe dane wej\u015Bciowe: oczekiwano ${n}, otrzymano ${u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Nieprawid\u0142owe dane wej\u015Bciowe: oczekiwano ${$(t.values[0])}` : `Nieprawid\u0142owa opcja: oczekiwano jednej z warto\u015Bci ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Za du\u017Ca warto\u015B\u0107: oczekiwano, \u017Ce ${t.origin ?? "warto\u015B\u0107"} b\u0119dzie mie\u0107 ${n}${t.maximum.toString()} ${a.unit ?? "element\xF3w"}` : `Zbyt du\u017C(y/a/e): oczekiwano, \u017Ce ${t.origin ?? "warto\u015B\u0107"} b\u0119dzie wynosi\u0107 ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Za ma\u0142a warto\u015B\u0107: oczekiwano, \u017Ce ${t.origin ?? "warto\u015B\u0107"} b\u0119dzie mie\u0107 ${n}${t.minimum.toString()} ${a.unit ?? "element\xF3w"}` : `Zbyt ma\u0142(y/a/e): oczekiwano, \u017Ce ${t.origin ?? "warto\u015B\u0107"} b\u0119dzie wynosi\u0107 ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Nieprawid\u0142owy ci\u0105g znak\xF3w: musi zaczyna\u0107 si\u0119 od "${n.prefix}"` : n.format === "ends_with" ? `Nieprawid\u0142owy ci\u0105g znak\xF3w: musi ko\u0144czy\u0107 si\u0119 na "${n.suffix}"` : n.format === "includes" ? `Nieprawid\u0142owy ci\u0105g znak\xF3w: musi zawiera\u0107 "${n.includes}"` : n.format === "regex" ? `Nieprawid\u0142owy ci\u0105g znak\xF3w: musi odpowiada\u0107 wzorcowi ${n.pattern}` : `Nieprawid\u0142ow(y/a/e) ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Nieprawid\u0142owa liczba: musi by\u0107 wielokrotno\u015Bci\u0105 ${t.divisor}`;
      case "unrecognized_keys":
        return `Nierozpoznane klucze${t.keys.length > 1 ? "s" : ""}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `Nieprawid\u0142owy klucz w ${t.origin}`;
      case "invalid_union":
        return "Nieprawid\u0142owe dane wej\u015Bciowe";
      case "invalid_element":
        return `Nieprawid\u0142owa warto\u015B\u0107 w ${t.origin}`;
      default:
        return "Nieprawid\u0142owe dane wej\u015Bciowe";
    }
  };
}, "error");
function rc() {
  return {
    localeError: Jy()
  };
}
s(rc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/pt.js
var qy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "caracteres" },
    file: { unit: "bytes" },
    array: { unit: "elementos" },
    set: { unit: "elementos" },
    map: { unit: "entradas" }
  };
  function r(a) {
    return e[a] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "a entrada",
    email: "o endere\xE7o de e-mail",
    url: "o URL",
    emoji: "o emoji",
    uuid: "o UUID",
    uuidv4: "o UUIDv4",
    uuidv6: "o UUIDv6",
    nanoid: "o nanoid",
    guid: "o GUID",
    cuid: "o cuid",
    cuid2: "o cuid2",
    ulid: "o ULID",
    xid: "o XID",
    ksuid: "o KSUID",
    datetime: "a data e hora ISO",
    date: "a data ISO",
    time: "a hora ISO",
    duration: "a dura\xE7\xE3o ISO",
    ipv4: "o endere\xE7o IPv4",
    ipv6: "o endere\xE7o IPv6",
    mac: "o endere\xE7o MAC",
    cidrv4: "o intervalo de endere\xE7os IPv4",
    cidrv6: "o intervalo de endere\xE7os IPv6",
    base64: "o texto codificado em base64",
    base64url: "o texto codificado em base64url",
    json_string: "o texto JSON",
    e164: "o n\xFAmero E.164",
    credit_card: "o n\xFAmero de cart\xE3o de cr\xE9dito",
    jwt: "o JWT",
    template_literal: "a entrada"
  }, o = {
    masculine: { definite: "o", indefinite: "um" },
    feminine: { definite: "a", indefinite: "uma" }
  }, t = {
    string: { name: "texto", articles: o.masculine },
    number: { name: "n\xFAmero", articles: o.masculine },
    int: { name: "n\xFAmero inteiro", articles: o.masculine },
    boolean: { name: "valor booleano", articles: o.masculine },
    bigint: { name: "n\xFAmero bigint", articles: o.masculine },
    symbol: { name: "s\xEDmbolo", articles: o.masculine },
    undefined: { name: 'valor "undefined"', articles: o.masculine },
    null: { name: 'valor "nulo"', articles: o.masculine },
    never: { name: 'valor "never"', articles: o.masculine },
    void: { name: 'valor "void"', articles: o.masculine },
    date: { name: "data", articles: o.feminine },
    array: { name: "vetor", articles: o.masculine },
    object: { name: "objeto", articles: o.masculine },
    tuple: { name: "tuplo", articles: o.masculine },
    record: { name: "registo", articles: o.masculine },
    map: { name: "mapa", articles: o.masculine },
    set: { name: "conjunto", articles: o.masculine },
    file: { name: "ficheiro", articles: o.masculine },
    nonoptional: { name: "valor n\xE3o opcional", articles: o.masculine },
    nan: { name: 'valor "NaN"', articles: o.masculine },
    // Compatibility: "nan" -> "NaN" for display
    function: { name: "fun\xE7\xE3o", articles: o.feminine }
  };
  function n(a, u) {
    let c = t[a] ?? { name: `valor "${a}"`, articles: o.masculine };
    return `${c.articles[u]} ${c.name}`;
  }
  return s(n, "translateOriginWithArticle"), (a) => {
    switch (a.code) {
      case "invalid_type": {
        let u = n(a.expected, "indefinite"), c = b(a.input), l = n(c, "indefinite");
        return `Entrada inv\xE1lida: esperava ${u}, recebeu ${l}`;
      }
      case "invalid_value":
        return a.values.length === 1 ? `Entrada inv\xE1lida: esperava ${$(a.values[0])}` : `Op\xE7\xE3o inv\xE1lida: esperava uma das seguintes op\xE7\xF5es: ${g(a.values, "|")}`;
      case "too_big": {
        let u = a.inclusive ? "<=" : "<", c = r(a.origin);
        return c ? `Demasiado grande: esperava que ${n(a.origin, "definite")} tivesse ${u} ${a.maximum.toString()} ${c.unit ?? "elementos"}` : `Demasiado grande: esperava que ${n(a.origin, "definite")} fosse ${u} ${a.maximum.toString()}`;
      }
      case "too_small": {
        let u = a.inclusive ? ">=" : ">", c = r(a.origin);
        return c ? `Demasiado pequeno: esperava que ${n(a.origin, "definite")} tivesse ${u} ${a.minimum.toString()} ${c.unit ?? "elementos"}` : `Demasiado pequeno: esperava que ${n(a.origin, "definite")} fosse ${u} ${a.minimum.toString()}`;
      }
      case "invalid_format": {
        let u = a;
        return u.format === "starts_with" ? `Texto inv\xE1lido: deve come\xE7ar por "${u.prefix}"` : u.format === "ends_with" ? `Texto inv\xE1lido: deve terminar em "${u.suffix}"` : u.format === "includes" ? `Texto inv\xE1lido: deve incluir "${u.includes}"` : u.format === "regex" ? `Texto inv\xE1lido: deve corresponder ao padr\xE3o ${u.pattern}` : `Formato d${i[u.format] ?? a.format} inv\xE1lido`;
      }
      case "not_multiple_of":
        return `N\xFAmero inv\xE1lido: deve ser m\xFAltiplo de ${a.divisor}`;
      case "unrecognized_keys": {
        let u = a.keys.length > 1 ? "s" : "";
        return `Chave${u} inv\xE1lida${u}: ${g(a.keys, ", ")}`;
      }
      case "invalid_key":
        return `Entrada inv\xE1lida n${n(a.origin, "definite")}`;
      case "invalid_union":
        return a.options && Array.isArray(a.options) && a.options.length > 0 ? `Valor de discrimina\xE7\xE3o inv\xE1lido. Esperava ${a.options.map((c) => `'${c}'`).join(" | ")}` : "Entrada inv\xE1lida";
      case "invalid_element":
        return `Entrada inv\xE1lida n${n(a.origin, "definite")}`;
      default:
        return "Entrada inv\xE1lida";
    }
  };
}, "error");
function nc() {
  return {
    localeError: qy()
  };
}
s(nc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/pt-BR.js
var Ky = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "caracteres" },
    file: { unit: "bytes" },
    array: { unit: "elementos" },
    set: { unit: "elementos" },
    map: { unit: "entradas" }
  };
  function r(a) {
    return e[a] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "a entrada",
    email: "o endere\xE7o de e-mail",
    url: "o URL",
    emoji: "o emoji",
    uuid: "o UUID",
    uuidv4: "o UUIDv4",
    uuidv6: "o UUIDv6",
    nanoid: "o nanoid",
    guid: "o GUID",
    cuid: "o cuid",
    cuid2: "o cuid2",
    ulid: "o ULID",
    xid: "o XID",
    ksuid: "o KSUID",
    datetime: "a data e hora ISO",
    date: "a data ISO",
    time: "a hora ISO",
    duration: "a dura\xE7\xE3o ISO",
    ipv4: "o endere\xE7o IPv4",
    ipv6: "o endere\xE7o IPv6",
    mac: "o endere\xE7o MAC",
    cidrv4: "a faixa de endere\xE7os IPv4",
    cidrv6: "a faixa de endere\xE7os IPv6",
    base64: "o texto codificado em base64",
    base64url: "o texto codificado em base64url",
    json_string: "o texto JSON",
    e164: "o n\xFAmero E.164",
    credit_card: "o n\xFAmero de cart\xE3o de cr\xE9dito",
    jwt: "o JWT",
    template_literal: "a entrada"
  }, o = {
    masculine: { definite: "o", indefinite: "um" },
    feminine: { definite: "a", indefinite: "uma" }
  }, t = {
    string: { name: "texto", articles: o.masculine },
    number: { name: "n\xFAmero", articles: o.masculine },
    int: { name: "n\xFAmero inteiro", articles: o.masculine },
    boolean: { name: "valor booleano", articles: o.masculine },
    bigint: { name: "n\xFAmero bigint", articles: o.masculine },
    symbol: { name: "s\xEDmbolo", articles: o.masculine },
    undefined: { name: 'valor "undefined"', articles: o.masculine },
    null: { name: 'valor "nulo"', articles: o.masculine },
    never: { name: 'valor "never"', articles: o.masculine },
    void: { name: 'valor "void"', articles: o.masculine },
    date: { name: "data", articles: o.feminine },
    array: { name: "vetor", articles: o.masculine },
    object: { name: "objeto", articles: o.masculine },
    tuple: { name: "tupla", articles: o.feminine },
    record: { name: "registro", articles: o.masculine },
    map: { name: "mapa", articles: o.masculine },
    set: { name: "conjunto", articles: o.masculine },
    file: { name: "arquivo", articles: o.masculine },
    nonoptional: { name: "valor n\xE3o opcional", articles: o.masculine },
    nan: { name: 'valor "NaN"', articles: o.masculine },
    // Compatibility: "nan" -> "NaN" for display
    function: { name: "fun\xE7\xE3o", articles: o.feminine }
  };
  function n(a, u) {
    let c = t[a] ?? { name: `valor "${a}"`, articles: o.masculine };
    return `${c.articles[u]} ${c.name}`;
  }
  return s(n, "translateOriginWithArticle"), (a) => {
    switch (a.code) {
      case "invalid_type": {
        let u = n(a.expected, "indefinite"), c = b(a.input), l = n(c, "indefinite");
        return `Entrada inv\xE1lida: esperava ${u}, recebeu ${l}`;
      }
      case "invalid_value":
        return a.values.length === 1 ? `Entrada inv\xE1lida: esperava ${$(a.values[0])}` : `Op\xE7\xE3o inv\xE1lida: esperava uma das seguintes op\xE7\xF5es: ${g(a.values, "|")}`;
      case "too_big": {
        let u = a.inclusive ? "<=" : "<", c = r(a.origin);
        return c ? `Grande demais: esperava que ${n(a.origin, "definite")} tivesse ${u} ${a.maximum.toString()} ${c.unit ?? "elementos"}` : `Grande demais: esperava que ${n(a.origin, "definite")} fosse ${u} ${a.maximum.toString()}`;
      }
      case "too_small": {
        let u = a.inclusive ? ">=" : ">", c = r(a.origin);
        return c ? `Pequeno demais: esperava que ${n(a.origin, "definite")} tivesse ${u} ${a.minimum.toString()} ${c.unit ?? "elementos"}` : `Pequeno demais: esperava que ${n(a.origin, "definite")} fosse ${u} ${a.minimum.toString()}`;
      }
      case "invalid_format": {
        let u = a;
        return u.format === "starts_with" ? `Texto inv\xE1lido: deve come\xE7ar com "${u.prefix}"` : u.format === "ends_with" ? `Texto inv\xE1lido: deve terminar com "${u.suffix}"` : u.format === "includes" ? `Texto inv\xE1lido: deve incluir "${u.includes}"` : u.format === "regex" ? `Texto inv\xE1lido: deve corresponder ao padr\xE3o ${u.pattern}` : `Formato d${i[u.format] ?? a.format} inv\xE1lido`;
      }
      case "not_multiple_of":
        return `N\xFAmero inv\xE1lido: deve ser m\xFAltiplo de ${a.divisor}`;
      case "unrecognized_keys": {
        let u = a.keys.length > 1 ? "s" : "";
        return `Chave${u} inv\xE1lida${u}: ${g(a.keys, ", ")}`;
      }
      case "invalid_key":
        return `Entrada inv\xE1lida n${n(a.origin, "definite")}`;
      case "invalid_union":
        return a.options && Array.isArray(a.options) && a.options.length > 0 ? `Valor de discrimina\xE7\xE3o inv\xE1lido. Esperava ${a.options.map((c) => `'${c}'`).join(" | ")}` : "Entrada inv\xE1lida";
      case "invalid_element":
        return `Entrada inv\xE1lida n${n(a.origin, "definite")}`;
      default:
        return "Entrada inv\xE1lida";
    }
  };
}, "error");
function ic() {
  return {
    localeError: Ky()
  };
}
s(ic, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ro.js
var Wy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "caractere", verb: "s\u0103 aib\u0103" },
    file: { unit: "octe\u021Bi", verb: "s\u0103 aib\u0103" },
    array: { unit: "elemente", verb: "s\u0103 aib\u0103" },
    set: { unit: "elemente", verb: "s\u0103 aib\u0103" },
    map: { unit: "intr\u0103ri", verb: "s\u0103 aib\u0103" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "intrare",
    email: "adres\u0103 de email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "dat\u0103 \u0219i or\u0103 ISO",
    date: "dat\u0103 ISO",
    time: "or\u0103 ISO",
    duration: "durat\u0103 ISO",
    ipv4: "adres\u0103 IPv4",
    ipv6: "adres\u0103 IPv6",
    mac: "adres\u0103 MAC",
    cidrv4: "interval IPv4",
    cidrv6: "interval IPv6",
    base64: "\u0219ir codat base64",
    base64url: "\u0219ir codat base64url",
    json_string: "\u0219ir JSON",
    e164: "num\u0103r E.164",
    credit_card: "num\u0103r de card de credit",
    jwt: "JWT",
    template_literal: "intrare"
  }, o = {
    nan: "NaN",
    string: "\u0219ir",
    number: "num\u0103r",
    boolean: "boolean",
    function: "func\u021Bie",
    array: "matrice",
    object: "obiect",
    undefined: "nedefinit",
    symbol: "simbol",
    bigint: "num\u0103r mare",
    void: "void",
    never: "never",
    map: "hart\u0103",
    set: "set"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return `Intrare invalid\u0103: a\u0219teptat ${n}, primit ${u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Intrare invalid\u0103: a\u0219teptat ${$(t.values[0])}` : `Op\u021Biune invalid\u0103: a\u0219teptat una dintre ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Prea mare: a\u0219teptat ca ${t.origin ?? "valoarea"} ${a.verb} ${n}${t.maximum.toString()} ${a.unit ?? "elemente"}` : `Prea mare: a\u0219teptat ca ${t.origin ?? "valoarea"} s\u0103 fie ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Prea mic: a\u0219teptat ca ${t.origin} ${a.verb} ${n}${t.minimum.toString()} ${a.unit}` : `Prea mic: a\u0219teptat ca ${t.origin} s\u0103 fie ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u0218ir invalid: trebuie s\u0103 \xEEnceap\u0103 cu "${n.prefix}"` : n.format === "ends_with" ? `\u0218ir invalid: trebuie s\u0103 se termine cu "${n.suffix}"` : n.format === "includes" ? `\u0218ir invalid: trebuie s\u0103 includ\u0103 "${n.includes}"` : n.format === "regex" ? `\u0218ir invalid: trebuie s\u0103 se potriveasc\u0103 cu modelul ${n.pattern}` : `Format invalid: ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Num\u0103r invalid: trebuie s\u0103 fie multiplu de ${t.divisor}`;
      case "unrecognized_keys":
        return `Chei nerecunoscute: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `Cheie invalid\u0103 \xEEn ${t.origin}`;
      case "invalid_union":
        return "Intrare invalid\u0103";
      case "invalid_element":
        return `Valoare invalid\u0103 \xEEn ${t.origin}`;
      default:
        return "Intrare invalid\u0103";
    }
  };
}, "error");
function oc() {
  return {
    localeError: Wy()
  };
}
s(oc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ru.js
function bp(e, r, i, o) {
  let t = Math.abs(e), n = t % 10, a = t % 100;
  return a >= 11 && a <= 19 ? o : n === 1 ? r : n >= 2 && n <= 4 ? i : o;
}
s(bp, "getRussianPlural");
var Gy = /* @__PURE__ */ s(() => {
  let e = {
    string: {
      unit: {
        one: "\u0441\u0438\u043C\u0432\u043E\u043B",
        few: "\u0441\u0438\u043C\u0432\u043E\u043B\u0430",
        many: "\u0441\u0438\u043C\u0432\u043E\u043B\u043E\u0432"
      },
      verb: "\u0438\u043C\u0435\u0442\u044C"
    },
    file: {
      unit: {
        one: "\u0431\u0430\u0439\u0442",
        few: "\u0431\u0430\u0439\u0442\u0430",
        many: "\u0431\u0430\u0439\u0442"
      },
      verb: "\u0438\u043C\u0435\u0442\u044C"
    },
    array: {
      unit: {
        one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
        few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430",
        many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u043E\u0432"
      },
      verb: "\u0438\u043C\u0435\u0442\u044C"
    },
    set: {
      unit: {
        one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
        few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430",
        many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u043E\u0432"
      },
      verb: "\u0438\u043C\u0435\u0442\u044C"
    },
    map: {
      unit: {
        one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
        few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430",
        many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u043E\u0432"
      },
      verb: "\u0438\u043C\u0435\u0442\u044C"
    }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u0432\u0432\u043E\u0434",
    email: "email \u0430\u0434\u0440\u0435\u0441",
    url: "URL",
    emoji: "\u044D\u043C\u043E\u0434\u0437\u0438",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0434\u0430\u0442\u0430 \u0438 \u0432\u0440\u0435\u043C\u044F",
    date: "ISO \u0434\u0430\u0442\u0430",
    time: "ISO \u0432\u0440\u0435\u043C\u044F",
    duration: "ISO \u0434\u043B\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C",
    ipv4: "IPv4 \u0430\u0434\u0440\u0435\u0441",
    ipv6: "IPv6 \u0430\u0434\u0440\u0435\u0441",
    mac: "MAC \u0430\u0434\u0440\u0435\u0441",
    cidrv4: "IPv4 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D",
    cidrv6: "IPv6 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D",
    base64: "\u0441\u0442\u0440\u043E\u043A\u0430 \u0432 \u0444\u043E\u0440\u043C\u0430\u0442\u0435 base64",
    base64url: "\u0441\u0442\u0440\u043E\u043A\u0430 \u0432 \u0444\u043E\u0440\u043C\u0430\u0442\u0435 base64url",
    json_string: "JSON \u0441\u0442\u0440\u043E\u043A\u0430",
    e164: "\u043D\u043E\u043C\u0435\u0440 E.164",
    credit_card: "\u043D\u043E\u043C\u0435\u0440 \u043A\u0440\u0435\u0434\u0438\u0442\u043D\u043E\u0439 \u043A\u0430\u0440\u0442\u044B",
    jwt: "JWT",
    template_literal: "\u0432\u0432\u043E\u0434"
  }, o = {
    nan: "NaN",
    number: "\u0447\u0438\u0441\u043B\u043E",
    array: "\u043C\u0430\u0441\u0441\u0438\u0432"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0432\u0432\u043E\u0434: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C instanceof ${t.expected}, \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u043E ${u}` : `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0432\u0432\u043E\u0434: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C ${n}, \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u043E ${u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0432\u0432\u043E\u0434: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C ${$(t.values[0])}` : `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0432\u0430\u0440\u0438\u0430\u043D\u0442: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C \u043E\u0434\u043D\u043E \u0438\u0437 ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        if (a) {
          let u = Number(t.maximum), c = bp(u, a.unit.one, a.unit.few, a.unit.many);
          return `\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C, \u0447\u0442\u043E ${t.origin ?? "\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435"} \u0431\u0443\u0434\u0435\u0442 \u0438\u043C\u0435\u0442\u044C ${n}${t.maximum.toString()} ${c}`;
        }
        return `\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C, \u0447\u0442\u043E ${t.origin ?? "\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435"} \u0431\u0443\u0434\u0435\u0442 ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        if (a) {
          let u = Number(t.minimum), c = bp(u, a.unit.one, a.unit.few, a.unit.many);
          return `\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u043C\u0430\u043B\u0435\u043D\u044C\u043A\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C, \u0447\u0442\u043E ${t.origin} \u0431\u0443\u0434\u0435\u0442 \u0438\u043C\u0435\u0442\u044C ${n}${t.minimum.toString()} ${c}`;
        }
        return `\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u043C\u0430\u043B\u0435\u043D\u044C\u043A\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C, \u0447\u0442\u043E ${t.origin} \u0431\u0443\u0434\u0435\u0442 ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u0441\u0442\u0440\u043E\u043A\u0430: \u0434\u043E\u043B\u0436\u043D\u0430 \u043D\u0430\u0447\u0438\u043D\u0430\u0442\u044C\u0441\u044F \u0441 "${n.prefix}"` : n.format === "ends_with" ? `\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u0441\u0442\u0440\u043E\u043A\u0430: \u0434\u043E\u043B\u0436\u043D\u0430 \u0437\u0430\u043A\u0430\u043D\u0447\u0438\u0432\u0430\u0442\u044C\u0441\u044F \u043D\u0430 "${n.suffix}"` : n.format === "includes" ? `\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u0441\u0442\u0440\u043E\u043A\u0430: \u0434\u043E\u043B\u0436\u043D\u0430 \u0441\u043E\u0434\u0435\u0440\u0436\u0430\u0442\u044C "${n.includes}"` : n.format === "regex" ? `\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u0441\u0442\u0440\u043E\u043A\u0430: \u0434\u043E\u043B\u0436\u043D\u0430 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u043E\u0432\u0430\u0442\u044C \u0448\u0430\u0431\u043B\u043E\u043D\u0443 ${n.pattern}` : `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u041D\u0435\u0432\u0435\u0440\u043D\u043E\u0435 \u0447\u0438\u0441\u043B\u043E: \u0434\u043E\u043B\u0436\u043D\u043E \u0431\u044B\u0442\u044C \u043A\u0440\u0430\u0442\u043D\u044B\u043C ${t.divisor}`;
      case "unrecognized_keys":
        return `\u041D\u0435\u0440\u0430\u0441\u043F\u043E\u0437\u043D\u0430\u043D\u043D${t.keys.length > 1 ? "\u044B\u0435" : "\u044B\u0439"} \u043A\u043B\u044E\u0447${t.keys.length > 1 ? "\u0438" : ""}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u043A\u043B\u044E\u0447 \u0432 ${t.origin}`;
      case "invalid_union":
        return "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0435 \u0432\u0445\u043E\u0434\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435";
      case "invalid_element":
        return `\u041D\u0435\u0432\u0435\u0440\u043D\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u0432 ${t.origin}`;
      default:
        return "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0435 \u0432\u0445\u043E\u0434\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435";
    }
  };
}, "error");
function ac() {
  return {
    localeError: Gy()
  };
}
s(ac, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/sk.js
var Xy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "znakov", verb: "ma\u0165" },
    file: { unit: "bajtov", verb: "ma\u0165" },
    array: { unit: "prvkov", verb: "ma\u0165" },
    set: { unit: "prvkov", verb: "ma\u0165" },
    map: { unit: "polo\u017Eiek", verb: "ma\u0165" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "regul\xE1rny v\xFDraz",
    email: "e-mailov\xE1 adresa",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "d\xE1tum a \u010Das vo form\xE1te ISO",
    date: "d\xE1tum vo form\xE1te ISO",
    time: "\u010Das vo form\xE1te ISO",
    duration: "doba trvania ISO",
    ipv4: "IPv4 adresa",
    ipv6: "IPv6 adresa",
    mac: "MAC adresa",
    cidrv4: "rozsah IPv4",
    cidrv6: "rozsah IPv6",
    base64: "re\u0165azec zak\xF3dovan\xFD vo form\xE1te base64",
    base64url: "re\u0165azec zak\xF3dovan\xFD vo form\xE1te base64url",
    json_string: "re\u0165azec vo form\xE1te JSON",
    e164: "\u010D\xEDslo E.164",
    credit_card: "\u010D\xEDslo kreditnej karty",
    jwt: "JWT",
    template_literal: "vstup"
  }, o = {
    nan: "NaN",
    number: "\u010D\xEDslo",
    string: "re\u0165azec",
    function: "funkcia",
    array: "pole"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Neplatn\xFD vstup: o\u010Dak\xE1van\xE9 instanceof ${t.expected}, obdr\u017Ean\xE9 ${u}` : `Neplatn\xFD vstup: o\u010Dak\xE1van\xE9 ${n}, obdr\u017Ean\xE9 ${u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Neplatn\xFD vstup: o\u010Dak\xE1van\xE9 ${$(t.values[0])}` : `Neplatn\xFD vstup: o\u010Dak\xE1van\xE1 jedna z hodn\xF4t ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Hodnota je pr\xEDli\u0161 ve\u013Ek\xE1: ${t.origin ?? "hodnota"} mus\xED ma\u0165 ${n}${t.maximum.toString()} ${a.unit ?? "prvkov"}` : `Hodnota je pr\xEDli\u0161 ve\u013Ek\xE1: ${t.origin ?? "hodnota"} mus\xED by\u0165 ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Hodnota je pr\xEDli\u0161 mal\xE1: ${t.origin ?? "hodnota"} mus\xED ma\u0165 ${n}${t.minimum.toString()} ${a.unit ?? "prvkov"}` : `Hodnota je pr\xEDli\u0161 mal\xE1: ${t.origin ?? "hodnota"} mus\xED by\u0165 ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Neplatn\xFD re\u0165azec: mus\xED za\u010D\xEDna\u0165 na "${n.prefix}"` : n.format === "ends_with" ? `Neplatn\xFD re\u0165azec: mus\xED kon\u010Di\u0165 na "${n.suffix}"` : n.format === "includes" ? `Neplatn\xFD re\u0165azec: mus\xED obsahova\u0165 "${n.includes}"` : n.format === "regex" ? `Neplatn\xFD re\u0165azec: mus\xED zodpoveda\u0165 vzoru ${n.pattern}` : `Neplatn\xFD form\xE1t ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Neplatn\xE9 \u010D\xEDslo: mus\xED by\u0165 n\xE1sobkom ${t.divisor}`;
      case "unrecognized_keys":
        return `Nezn\xE1me kl\xFA\u010De: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `Neplatn\xFD kl\xFA\u010D v ${t.origin}`;
      case "invalid_union":
        return "Neplatn\xFD vstup";
      case "invalid_element":
        return `Neplatn\xE1 hodnota v ${t.origin}`;
      default:
        return "Neplatn\xFD vstup";
    }
  };
}, "error");
function sc() {
  return {
    localeError: Xy()
  };
}
s(sc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/sl.js
var Hy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "znakov", verb: "imeti" },
    file: { unit: "bajtov", verb: "imeti" },
    array: { unit: "elementov", verb: "imeti" },
    set: { unit: "elementov", verb: "imeti" },
    map: { unit: "elementov", verb: "imeti" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "vnos",
    email: "e-po\u0161tni naslov",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datum in \u010Das",
    date: "ISO datum",
    time: "ISO \u010Das",
    duration: "ISO trajanje",
    ipv4: "IPv4 naslov",
    ipv6: "IPv6 naslov",
    mac: "MAC naslov",
    cidrv4: "obseg IPv4",
    cidrv6: "obseg IPv6",
    base64: "base64 kodiran niz",
    base64url: "base64url kodiran niz",
    json_string: "JSON niz",
    e164: "E.164 \u0161tevilka",
    credit_card: "\u0161tevilka kreditne kartice",
    jwt: "JWT",
    template_literal: "vnos"
  }, o = {
    nan: "NaN",
    number: "\u0161tevilo",
    array: "tabela"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Neveljaven vnos: pri\u010Dakovano instanceof ${t.expected}, prejeto ${u}` : `Neveljaven vnos: pri\u010Dakovano ${n}, prejeto ${u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Neveljaven vnos: pri\u010Dakovano ${$(t.values[0])}` : `Neveljavna mo\u017Enost: pri\u010Dakovano eno izmed ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Preveliko: pri\u010Dakovano, da bo ${t.origin ?? "vrednost"} imelo ${n}${t.maximum.toString()} ${a.unit ?? "elementov"}` : `Preveliko: pri\u010Dakovano, da bo ${t.origin ?? "vrednost"} ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Premajhno: pri\u010Dakovano, da bo ${t.origin} imelo ${n}${t.minimum.toString()} ${a.unit}` : `Premajhno: pri\u010Dakovano, da bo ${t.origin} ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Neveljaven niz: mora se za\u010Deti z "${n.prefix}"` : n.format === "ends_with" ? `Neveljaven niz: mora se kon\u010Dati z "${n.suffix}"` : n.format === "includes" ? `Neveljaven niz: mora vsebovati "${n.includes}"` : n.format === "regex" ? `Neveljaven niz: mora ustrezati vzorcu ${n.pattern}` : `Neveljaven ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Neveljavno \u0161tevilo: mora biti ve\u010Dkratnik ${t.divisor}`;
      case "unrecognized_keys":
        return `Neprepoznan${t.keys.length > 1 ? "i klju\u010Di" : " klju\u010D"}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `Neveljaven klju\u010D v ${t.origin}`;
      case "invalid_union":
        return "Neveljaven vnos";
      case "invalid_element":
        return `Neveljavna vrednost v ${t.origin}`;
      default:
        return "Neveljaven vnos";
    }
  };
}, "error");
function uc() {
  return {
    localeError: Hy()
  };
}
s(uc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/sv.js
var Qy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "tecken", verb: "att ha" },
    file: { unit: "bytes", verb: "att ha" },
    array: { unit: "objekt", verb: "att inneh\xE5lla" },
    set: { unit: "objekt", verb: "att inneh\xE5lla" },
    map: { unit: "objekt", verb: "att inneh\xE5lla" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "regulj\xE4rt uttryck",
    email: "e-postadress",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO-datum och tid",
    date: "ISO-datum",
    time: "ISO-tid",
    duration: "ISO-varaktighet",
    ipv4: "IPv4-adress",
    ipv6: "IPv6-adress",
    mac: "MAC-adress",
    cidrv4: "IPv4-spektrum",
    cidrv6: "IPv6-spektrum",
    base64: "base64-kodad str\xE4ng",
    base64url: "base64url-kodad str\xE4ng",
    json_string: "JSON-str\xE4ng",
    e164: "E.164-nummer",
    credit_card: "kreditkortsnummer",
    jwt: "JWT",
    template_literal: "mall-literal"
  }, o = {
    nan: "NaN",
    number: "antal",
    array: "lista"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Ogiltig inmatning: f\xF6rv\xE4ntat instanceof ${t.expected}, fick ${u}` : `Ogiltig inmatning: f\xF6rv\xE4ntat ${n}, fick ${u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Ogiltig inmatning: f\xF6rv\xE4ntat ${$(t.values[0])}` : `Ogiltigt val: f\xF6rv\xE4ntade en av ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `F\xF6r stor(t): f\xF6rv\xE4ntade ${t.origin ?? "v\xE4rdet"} att ha ${n}${t.maximum.toString()} ${a.unit ?? "element"}` : `F\xF6r stor(t): f\xF6rv\xE4ntat ${t.origin ?? "v\xE4rdet"} att ha ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `F\xF6r lite(t): f\xF6rv\xE4ntade ${t.origin ?? "v\xE4rdet"} att ha ${n}${t.minimum.toString()} ${a.unit}` : `F\xF6r lite(t): f\xF6rv\xE4ntade ${t.origin ?? "v\xE4rdet"} att ha ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Ogiltig str\xE4ng: m\xE5ste b\xF6rja med "${n.prefix}"` : n.format === "ends_with" ? `Ogiltig str\xE4ng: m\xE5ste sluta med "${n.suffix}"` : n.format === "includes" ? `Ogiltig str\xE4ng: m\xE5ste inneh\xE5lla "${n.includes}"` : n.format === "regex" ? `Ogiltig str\xE4ng: m\xE5ste matcha m\xF6nstret "${n.pattern}"` : `Ogiltig(t) ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Ogiltigt tal: m\xE5ste vara en multipel av ${t.divisor}`;
      case "unrecognized_keys":
        return `${t.keys.length > 1 ? "Ok\xE4nda nycklar" : "Ok\xE4nd nyckel"}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `Ogiltig nyckel i ${t.origin ?? "v\xE4rdet"}`;
      case "invalid_union":
        return "Ogiltig input";
      case "invalid_element":
        return `Ogiltigt v\xE4rde i ${t.origin ?? "v\xE4rdet"}`;
      default:
        return "Ogiltig input";
    }
  };
}, "error");
function cc() {
  return {
    localeError: Qy()
  };
}
s(cc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ta.js
var Yy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0B8E\u0BB4\u0BC1\u0BA4\u0BCD\u0BA4\u0BC1\u0B95\u0BCD\u0B95\u0BB3\u0BCD", verb: "\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD" },
    file: { unit: "\u0BAA\u0BC8\u0B9F\u0BCD\u0B9F\u0BC1\u0B95\u0BB3\u0BCD", verb: "\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD" },
    array: { unit: "\u0B89\u0BB1\u0BC1\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD", verb: "\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD" },
    set: { unit: "\u0B89\u0BB1\u0BC1\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD", verb: "\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD" },
    map: { unit: "\u0B89\u0BB1\u0BC1\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD", verb: "\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1",
    email: "\u0BAE\u0BBF\u0BA9\u0BCD\u0BA9\u0B9E\u0BCD\u0B9A\u0BB2\u0BCD \u0BAE\u0BC1\u0B95\u0BB5\u0BB0\u0BBF",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0BA4\u0BC7\u0BA4\u0BBF \u0BA8\u0BC7\u0BB0\u0BAE\u0BCD",
    date: "ISO \u0BA4\u0BC7\u0BA4\u0BBF",
    time: "ISO \u0BA8\u0BC7\u0BB0\u0BAE\u0BCD",
    duration: "ISO \u0B95\u0BBE\u0BB2 \u0B85\u0BB3\u0BB5\u0BC1",
    ipv4: "IPv4 \u0BAE\u0BC1\u0B95\u0BB5\u0BB0\u0BBF",
    ipv6: "IPv6 \u0BAE\u0BC1\u0B95\u0BB5\u0BB0\u0BBF",
    mac: "MAC \u0BAE\u0BC1\u0B95\u0BB5\u0BB0\u0BBF",
    cidrv4: "IPv4 \u0BB5\u0BB0\u0BAE\u0BCD\u0BAA\u0BC1",
    cidrv6: "IPv6 \u0BB5\u0BB0\u0BAE\u0BCD\u0BAA\u0BC1",
    base64: "base64-encoded \u0B9A\u0BB0\u0BAE\u0BCD",
    base64url: "base64url-encoded \u0B9A\u0BB0\u0BAE\u0BCD",
    json_string: "JSON \u0B9A\u0BB0\u0BAE\u0BCD",
    e164: "E.164 \u0B8E\u0BA3\u0BCD",
    credit_card: "\u0B95\u0B9F\u0BA9\u0BCD \u0B85\u0B9F\u0BCD\u0B9F\u0BC8 \u0B8E\u0BA3\u0BCD",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN",
    number: "\u0B8E\u0BA3\u0BCD",
    array: "\u0B85\u0BA3\u0BBF",
    null: "\u0BB5\u0BC6\u0BB1\u0BC1\u0BAE\u0BC8"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 instanceof ${t.expected}, \u0BAA\u0BC6\u0BB1\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${u}` : `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${n}, \u0BAA\u0BC6\u0BB1\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${$(t.values[0])}` : `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0BB5\u0BBF\u0BB0\u0BC1\u0BAA\u0BCD\u0BAA\u0BAE\u0BCD: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${g(t.values, "|")} \u0B87\u0BB2\u0BCD \u0B92\u0BA9\u0BCD\u0BB1\u0BC1`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u0BAE\u0BBF\u0B95 \u0BAA\u0BC6\u0BB0\u0BBF\u0BAF\u0BA4\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${t.origin ?? "\u0BAE\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1"} ${n}${t.maximum.toString()} ${a.unit ?? "\u0B89\u0BB1\u0BC1\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD"} \u0B86\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : `\u0BAE\u0BBF\u0B95 \u0BAA\u0BC6\u0BB0\u0BBF\u0BAF\u0BA4\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${t.origin ?? "\u0BAE\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1"} ${n}${t.maximum.toString()} \u0B86\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u0BAE\u0BBF\u0B95\u0B9A\u0BCD \u0B9A\u0BBF\u0BB1\u0BBF\u0BAF\u0BA4\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${t.origin} ${n}${t.minimum.toString()} ${a.unit} \u0B86\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : `\u0BAE\u0BBF\u0B95\u0B9A\u0BCD \u0B9A\u0BBF\u0BB1\u0BBF\u0BAF\u0BA4\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${t.origin} ${n}${t.minimum.toString()} \u0B86\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B9A\u0BB0\u0BAE\u0BCD: "${n.prefix}" \u0B87\u0BB2\u0BCD \u0BA4\u0BCA\u0B9F\u0B99\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : n.format === "ends_with" ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B9A\u0BB0\u0BAE\u0BCD: "${n.suffix}" \u0B87\u0BB2\u0BCD \u0BAE\u0BC1\u0B9F\u0BBF\u0BB5\u0B9F\u0BC8\u0BAF \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : n.format === "includes" ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B9A\u0BB0\u0BAE\u0BCD: "${n.includes}" \u0B90 \u0B89\u0BB3\u0BCD\u0BB3\u0B9F\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : n.format === "regex" ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B9A\u0BB0\u0BAE\u0BCD: ${n.pattern} \u0BAE\u0BC1\u0BB1\u0BC8\u0BAA\u0BBE\u0B9F\u0BCD\u0B9F\u0BC1\u0B9F\u0BA9\u0BCD \u0BAA\u0BCA\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B8E\u0BA3\u0BCD: ${t.divisor} \u0B87\u0BA9\u0BCD \u0BAA\u0BB2\u0BAE\u0BBE\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD`;
      case "unrecognized_keys":
        return `\u0B85\u0B9F\u0BC8\u0BAF\u0BBE\u0BB3\u0BAE\u0BCD \u0BA4\u0BC6\u0BB0\u0BBF\u0BAF\u0BBE\u0BA4 \u0BB5\u0BBF\u0B9A\u0BC8${t.keys.length > 1 ? "\u0B95\u0BB3\u0BCD" : ""}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `${t.origin} \u0B87\u0BB2\u0BCD \u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0BB5\u0BBF\u0B9A\u0BC8`;
      case "invalid_union":
        return "\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1";
      case "invalid_element":
        return `${t.origin} \u0B87\u0BB2\u0BCD \u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0BAE\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1`;
      default:
        return "\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1";
    }
  };
}, "error");
function lc() {
  return {
    localeError: Yy()
  };
}
s(lc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/th.js
var e$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0E15\u0E31\u0E27\u0E2D\u0E31\u0E01\u0E29\u0E23", verb: "\u0E04\u0E27\u0E23\u0E21\u0E35" },
    file: { unit: "\u0E44\u0E1A\u0E15\u0E4C", verb: "\u0E04\u0E27\u0E23\u0E21\u0E35" },
    array: { unit: "\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23", verb: "\u0E04\u0E27\u0E23\u0E21\u0E35" },
    set: { unit: "\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23", verb: "\u0E04\u0E27\u0E23\u0E21\u0E35" },
    map: { unit: "\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23", verb: "\u0E04\u0E27\u0E23\u0E21\u0E35" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E17\u0E35\u0E48\u0E1B\u0E49\u0E2D\u0E19",
    email: "\u0E17\u0E35\u0E48\u0E2D\u0E22\u0E39\u0E48\u0E2D\u0E35\u0E40\u0E21\u0E25",
    url: "URL",
    emoji: "\u0E2D\u0E34\u0E42\u0E21\u0E08\u0E34",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48\u0E40\u0E27\u0E25\u0E32\u0E41\u0E1A\u0E1A ISO",
    date: "\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48\u0E41\u0E1A\u0E1A ISO",
    time: "\u0E40\u0E27\u0E25\u0E32\u0E41\u0E1A\u0E1A ISO",
    duration: "\u0E0A\u0E48\u0E27\u0E07\u0E40\u0E27\u0E25\u0E32\u0E41\u0E1A\u0E1A ISO",
    ipv4: "\u0E17\u0E35\u0E48\u0E2D\u0E22\u0E39\u0E48 IPv4",
    ipv6: "\u0E17\u0E35\u0E48\u0E2D\u0E22\u0E39\u0E48 IPv6",
    mac: "\u0E17\u0E35\u0E48\u0E2D\u0E22\u0E39\u0E48 MAC",
    cidrv4: "\u0E0A\u0E48\u0E27\u0E07 IP \u0E41\u0E1A\u0E1A IPv4",
    cidrv6: "\u0E0A\u0E48\u0E27\u0E07 IP \u0E41\u0E1A\u0E1A IPv6",
    base64: "\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E41\u0E1A\u0E1A Base64",
    base64url: "\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E41\u0E1A\u0E1A Base64 \u0E2A\u0E33\u0E2B\u0E23\u0E31\u0E1A URL",
    json_string: "\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E41\u0E1A\u0E1A JSON",
    e164: "\u0E40\u0E1A\u0E2D\u0E23\u0E4C\u0E42\u0E17\u0E23\u0E28\u0E31\u0E1E\u0E17\u0E4C\u0E23\u0E30\u0E2B\u0E27\u0E48\u0E32\u0E07\u0E1B\u0E23\u0E30\u0E40\u0E17\u0E28 (E.164)",
    credit_card: "\u0E2B\u0E21\u0E32\u0E22\u0E40\u0E25\u0E02\u0E1A\u0E31\u0E15\u0E23\u0E40\u0E04\u0E23\u0E14\u0E34\u0E15",
    jwt: "\u0E42\u0E17\u0E40\u0E04\u0E19 JWT",
    template_literal: "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E17\u0E35\u0E48\u0E1B\u0E49\u0E2D\u0E19"
  }, o = {
    nan: "NaN",
    number: "\u0E15\u0E31\u0E27\u0E40\u0E25\u0E02",
    array: "\u0E2D\u0E32\u0E23\u0E4C\u0E40\u0E23\u0E22\u0E4C (Array)",
    null: "\u0E44\u0E21\u0E48\u0E21\u0E35\u0E04\u0E48\u0E32 (null)"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u0E1B\u0E23\u0E30\u0E40\u0E20\u0E17\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E04\u0E27\u0E23\u0E40\u0E1B\u0E47\u0E19 instanceof ${t.expected} \u0E41\u0E15\u0E48\u0E44\u0E14\u0E49\u0E23\u0E31\u0E1A ${u}` : `\u0E1B\u0E23\u0E30\u0E40\u0E20\u0E17\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E04\u0E27\u0E23\u0E40\u0E1B\u0E47\u0E19 ${n} \u0E41\u0E15\u0E48\u0E44\u0E14\u0E49\u0E23\u0E31\u0E1A ${u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u0E04\u0E48\u0E32\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E04\u0E27\u0E23\u0E40\u0E1B\u0E47\u0E19 ${$(t.values[0])}` : `\u0E15\u0E31\u0E27\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E04\u0E27\u0E23\u0E40\u0E1B\u0E47\u0E19\u0E2B\u0E19\u0E36\u0E48\u0E07\u0E43\u0E19 ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "\u0E44\u0E21\u0E48\u0E40\u0E01\u0E34\u0E19" : "\u0E19\u0E49\u0E2D\u0E22\u0E01\u0E27\u0E48\u0E32", a = r(t.origin);
        return a ? `\u0E40\u0E01\u0E34\u0E19\u0E01\u0E33\u0E2B\u0E19\u0E14: ${t.origin ?? "\u0E04\u0E48\u0E32"} \u0E04\u0E27\u0E23\u0E21\u0E35${n} ${t.maximum.toString()} ${a.unit ?? "\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23"}` : `\u0E40\u0E01\u0E34\u0E19\u0E01\u0E33\u0E2B\u0E19\u0E14: ${t.origin ?? "\u0E04\u0E48\u0E32"} \u0E04\u0E27\u0E23\u0E21\u0E35${n} ${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? "\u0E2D\u0E22\u0E48\u0E32\u0E07\u0E19\u0E49\u0E2D\u0E22" : "\u0E21\u0E32\u0E01\u0E01\u0E27\u0E48\u0E32", a = r(t.origin);
        return a ? `\u0E19\u0E49\u0E2D\u0E22\u0E01\u0E27\u0E48\u0E32\u0E01\u0E33\u0E2B\u0E19\u0E14: ${t.origin} \u0E04\u0E27\u0E23\u0E21\u0E35${n} ${t.minimum.toString()} ${a.unit}` : `\u0E19\u0E49\u0E2D\u0E22\u0E01\u0E27\u0E48\u0E32\u0E01\u0E33\u0E2B\u0E19\u0E14: ${t.origin} \u0E04\u0E27\u0E23\u0E21\u0E35${n} ${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E15\u0E49\u0E2D\u0E07\u0E02\u0E36\u0E49\u0E19\u0E15\u0E49\u0E19\u0E14\u0E49\u0E27\u0E22 "${n.prefix}"` : n.format === "ends_with" ? `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E15\u0E49\u0E2D\u0E07\u0E25\u0E07\u0E17\u0E49\u0E32\u0E22\u0E14\u0E49\u0E27\u0E22 "${n.suffix}"` : n.format === "includes" ? `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E15\u0E49\u0E2D\u0E07\u0E21\u0E35 "${n.includes}" \u0E2D\u0E22\u0E39\u0E48\u0E43\u0E19\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21` : n.format === "regex" ? `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E15\u0E49\u0E2D\u0E07\u0E15\u0E23\u0E07\u0E01\u0E31\u0E1A\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E17\u0E35\u0E48\u0E01\u0E33\u0E2B\u0E19\u0E14 ${n.pattern}` : `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u0E15\u0E31\u0E27\u0E40\u0E25\u0E02\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E15\u0E49\u0E2D\u0E07\u0E40\u0E1B\u0E47\u0E19\u0E08\u0E33\u0E19\u0E27\u0E19\u0E17\u0E35\u0E48\u0E2B\u0E32\u0E23\u0E14\u0E49\u0E27\u0E22 ${t.divisor} \u0E44\u0E14\u0E49\u0E25\u0E07\u0E15\u0E31\u0E27`;
      case "unrecognized_keys":
        return `\u0E1E\u0E1A\u0E04\u0E35\u0E22\u0E4C\u0E17\u0E35\u0E48\u0E44\u0E21\u0E48\u0E23\u0E39\u0E49\u0E08\u0E31\u0E01: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `\u0E04\u0E35\u0E22\u0E4C\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07\u0E43\u0E19 ${t.origin}`;
      case "invalid_union":
        return "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E44\u0E21\u0E48\u0E15\u0E23\u0E07\u0E01\u0E31\u0E1A\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E22\u0E39\u0E40\u0E19\u0E35\u0E22\u0E19\u0E17\u0E35\u0E48\u0E01\u0E33\u0E2B\u0E19\u0E14\u0E44\u0E27\u0E49";
      case "invalid_element":
        return `\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07\u0E43\u0E19 ${t.origin}`;
      default:
        return "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07";
    }
  };
}, "error");
function dc() {
  return {
    localeError: e$()
  };
}
s(dc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/tk.js
var t$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "simwol", verb: "bolmaly" },
    file: { unit: "ba\xFDt", verb: "bolmaly" },
    array: { unit: "elementler", verb: "bolmaly" },
    set: { unit: "elementler", verb: "bolmaly" },
    map: { unit: "elementler", verb: "bolmaly" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "giri\u015F",
    email: "e-po\xE7ta salgysy",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO sene we wagt",
    date: "ISO sene",
    time: "ISO wagt",
    duration: "ISO wagt aralygy",
    ipv4: "IPv4 salgysy",
    ipv6: "IPv6 salgysy",
    mac: "MAC salgysy",
    cidrv4: "IPv4 aralygy",
    cidrv6: "IPv6 aralygy",
    base64: "base64 bilen \u015Fifrlenen setir",
    base64url: "base64url bilen \u015Fifrlenen setir",
    json_string: "JSON setiri",
    e164: "E.164 nomeri",
    credit_card: "kredit kartyny\u0148 nomeri",
    jwt: "JWT",
    template_literal: "\u015Fablon"
  }, o = {
    nan: "NaN"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return `N\xE4dogry baha: gara\u015Fylan ${n} \xFDerine ${u} alyndy`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `N\xE4dogry baha: ${$(t.values[0])} bolmaly` : `N\xE4dogry sa\xFDlaw: a\u015Fakdakylardan biri bolmaly: ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Has uly: gara\u015Fyl\xFDan ${t.origin ?? "baha"} ${n} ${t.maximum.toString()} ${a.unit ?? "element"}` : `Has uly: gara\u015Fyl\xFDan ${t.origin ?? "baha"} ${n} ${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Has ki\xE7i: gara\u015Fyl\xFDan ${t.origin} ${n} ${t.minimum.toString()} ${a.unit}` : `Has ki\xE7i: gara\u015Fyl\xFDan ${t.origin} ${n} ${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `N\xE4dogry setir: "${n.prefix}" bilen ba\u015Flamaly` : n.format === "ends_with" ? `N\xE4dogry setir: "${n.suffix}" bilen gutarmaly` : n.format === "includes" ? `N\xE4dogry setir: "${n.includes}" saklamaly` : n.format === "regex" ? `N\xE4dogry setir: ${n.pattern} nusga la\xFDyk bolmaly` : `N\xE4dogry ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `N\xE4dogry san: ${t.divisor} bilen galyndysyz b\xF6l\xFCnmeli`;
      case "unrecognized_keys":
        return `Tanalma\xFDan a\xE7ar${t.keys.length > 1 ? "lar" : ""}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `${t.origin} i\xE7inde n\xE4dogry a\xE7ar`;
      case "invalid_union":
        return "N\xE4dogry baha";
      case "invalid_element":
        return `${t.origin} i\xE7inde n\xE4dogry baha`;
      default:
        return "N\xE4dogry baha";
    }
  };
}, "error");
function fc() {
  return {
    localeError: t$()
  };
}
s(fc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/tr.js
var r$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "karakter", verb: "olmal\u0131" },
    file: { unit: "bayt", verb: "olmal\u0131" },
    array: { unit: "\xF6\u011Fe", verb: "olmal\u0131" },
    set: { unit: "\xF6\u011Fe", verb: "olmal\u0131" },
    map: { unit: "\xF6\u011Fe", verb: "olmal\u0131" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "girdi",
    email: "e-posta adresi",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO tarih ve saat",
    date: "ISO tarih",
    time: "ISO saat",
    duration: "ISO s\xFCre",
    ipv4: "IPv4 adresi",
    ipv6: "IPv6 adresi",
    mac: "MAC adresi",
    cidrv4: "IPv4 aral\u0131\u011F\u0131",
    cidrv6: "IPv6 aral\u0131\u011F\u0131",
    base64: "base64 ile \u015Fifrelenmi\u015F metin",
    base64url: "base64url ile \u015Fifrelenmi\u015F metin",
    json_string: "JSON dizesi",
    e164: "E.164 say\u0131s\u0131",
    credit_card: "kredi kart\u0131 numaras\u0131",
    jwt: "JWT",
    template_literal: "\u015Eablon dizesi"
  }, o = {
    nan: "NaN"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Ge\xE7ersiz de\u011Fer: beklenen instanceof ${t.expected}, al\u0131nan ${u}` : `Ge\xE7ersiz de\u011Fer: beklenen ${n}, al\u0131nan ${u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Ge\xE7ersiz de\u011Fer: beklenen ${$(t.values[0])}` : `Ge\xE7ersiz se\xE7enek: a\u015Fa\u011F\u0131dakilerden biri olmal\u0131: ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\xC7ok b\xFCy\xFCk: beklenen ${t.origin ?? "de\u011Fer"} ${n}${t.maximum.toString()} ${a.unit ?? "\xF6\u011Fe"}` : `\xC7ok b\xFCy\xFCk: beklenen ${t.origin ?? "de\u011Fer"} ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\xC7ok k\xFC\xE7\xFCk: beklenen ${t.origin} ${n}${t.minimum.toString()} ${a.unit}` : `\xC7ok k\xFC\xE7\xFCk: beklenen ${t.origin} ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Ge\xE7ersiz metin: "${n.prefix}" ile ba\u015Flamal\u0131` : n.format === "ends_with" ? `Ge\xE7ersiz metin: "${n.suffix}" ile bitmeli` : n.format === "includes" ? `Ge\xE7ersiz metin: "${n.includes}" i\xE7ermeli` : n.format === "regex" ? `Ge\xE7ersiz metin: ${n.pattern} desenine uymal\u0131` : `Ge\xE7ersiz ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Ge\xE7ersiz say\u0131: ${t.divisor} ile tam b\xF6l\xFCnebilmeli`;
      case "unrecognized_keys":
        return `Tan\u0131nmayan anahtar${t.keys.length > 1 ? "lar" : ""}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `${t.origin} i\xE7inde ge\xE7ersiz anahtar`;
      case "invalid_union":
        return "Ge\xE7ersiz de\u011Fer";
      case "invalid_element":
        return `${t.origin} i\xE7inde ge\xE7ersiz de\u011Fer`;
      default:
        return "Ge\xE7ersiz de\u011Fer";
    }
  };
}, "error");
function pc() {
  return {
    localeError: r$()
  };
}
s(pc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/uk.js
var n$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0441\u0438\u043C\u0432\u043E\u043B\u0456\u0432", verb: "\u043C\u0430\u0442\u0438\u043C\u0435" },
    file: { unit: "\u0431\u0430\u0439\u0442\u0456\u0432", verb: "\u043C\u0430\u0442\u0438\u043C\u0435" },
    array: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0456\u0432", verb: "\u043C\u0430\u0442\u0438\u043C\u0435" },
    set: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0456\u0432", verb: "\u043C\u0430\u0442\u0438\u043C\u0435" },
    map: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0456\u0432", verb: "\u043C\u0430\u0442\u0438\u043C\u0435" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456",
    email: "\u0430\u0434\u0440\u0435\u0441\u0430 \u0435\u043B\u0435\u043A\u0442\u0440\u043E\u043D\u043D\u043E\u0457 \u043F\u043E\u0448\u0442\u0438",
    url: "URL",
    emoji: "\u0435\u043C\u043E\u0434\u0437\u0456",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u0434\u0430\u0442\u0430 \u0442\u0430 \u0447\u0430\u0441 ISO",
    date: "\u0434\u0430\u0442\u0430 ISO",
    time: "\u0447\u0430\u0441 ISO",
    duration: "\u0442\u0440\u0438\u0432\u0430\u043B\u0456\u0441\u0442\u044C ISO",
    ipv4: "\u0430\u0434\u0440\u0435\u0441\u0430 IPv4",
    ipv6: "\u0430\u0434\u0440\u0435\u0441\u0430 IPv6",
    mac: "\u0430\u0434\u0440\u0435\u0441\u0430 MAC",
    cidrv4: "\u0434\u0456\u0430\u043F\u0430\u0437\u043E\u043D IPv4",
    cidrv6: "\u0434\u0456\u0430\u043F\u0430\u0437\u043E\u043D IPv6",
    base64: "\u0440\u044F\u0434\u043E\u043A \u0443 \u043A\u043E\u0434\u0443\u0432\u0430\u043D\u043D\u0456 base64",
    base64url: "\u0440\u044F\u0434\u043E\u043A \u0443 \u043A\u043E\u0434\u0443\u0432\u0430\u043D\u043D\u0456 base64url",
    json_string: "\u0440\u044F\u0434\u043E\u043A JSON",
    e164: "\u043D\u043E\u043C\u0435\u0440 E.164",
    credit_card: "\u043D\u043E\u043C\u0435\u0440 \u043A\u0440\u0435\u0434\u0438\u0442\u043D\u043E\u0457 \u043A\u0430\u0440\u0442\u043A\u0438",
    jwt: "JWT",
    template_literal: "\u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456"
  }, o = {
    nan: "NaN",
    number: "\u0447\u0438\u0441\u043B\u043E",
    array: "\u043C\u0430\u0441\u0438\u0432"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F instanceof ${t.expected}, \u043E\u0442\u0440\u0438\u043C\u0430\u043D\u043E ${u}` : `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F ${n}, \u043E\u0442\u0440\u0438\u043C\u0430\u043D\u043E ${u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F ${$(t.values[0])}` : `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0430 \u043E\u043F\u0446\u0456\u044F: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F \u043E\u0434\u043D\u0435 \u0437 ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u0417\u0430\u043D\u0430\u0434\u0442\u043E \u0432\u0435\u043B\u0438\u043A\u0435: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F, \u0449\u043E ${t.origin ?? "\u0437\u043D\u0430\u0447\u0435\u043D\u043D\u044F"} ${a.verb} ${n}${t.maximum.toString()} ${a.unit ?? "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0456\u0432"}` : `\u0417\u0430\u043D\u0430\u0434\u0442\u043E \u0432\u0435\u043B\u0438\u043A\u0435: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F, \u0449\u043E ${t.origin ?? "\u0437\u043D\u0430\u0447\u0435\u043D\u043D\u044F"} \u0431\u0443\u0434\u0435 ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u0417\u0430\u043D\u0430\u0434\u0442\u043E \u043C\u0430\u043B\u0435: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F, \u0449\u043E ${t.origin} ${a.verb} ${n}${t.minimum.toString()} ${a.unit}` : `\u0417\u0430\u043D\u0430\u0434\u0442\u043E \u043C\u0430\u043B\u0435: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F, \u0449\u043E ${t.origin} \u0431\u0443\u0434\u0435 ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u0440\u044F\u0434\u043E\u043A: \u043F\u043E\u0432\u0438\u043D\u0435\u043D \u043F\u043E\u0447\u0438\u043D\u0430\u0442\u0438\u0441\u044F \u0437 "${n.prefix}"` : n.format === "ends_with" ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u0440\u044F\u0434\u043E\u043A: \u043F\u043E\u0432\u0438\u043D\u0435\u043D \u0437\u0430\u043A\u0456\u043D\u0447\u0443\u0432\u0430\u0442\u0438\u0441\u044F \u043D\u0430 "${n.suffix}"` : n.format === "includes" ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u0440\u044F\u0434\u043E\u043A: \u043F\u043E\u0432\u0438\u043D\u0435\u043D \u043C\u0456\u0441\u0442\u0438\u0442\u0438 "${n.includes}"` : n.format === "regex" ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u0440\u044F\u0434\u043E\u043A: \u043F\u043E\u0432\u0438\u043D\u0435\u043D \u0432\u0456\u0434\u043F\u043E\u0432\u0456\u0434\u0430\u0442\u0438 \u0448\u0430\u0431\u043B\u043E\u043D\u0443 ${n.pattern}` : `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0435 \u0447\u0438\u0441\u043B\u043E: \u043F\u043E\u0432\u0438\u043D\u043D\u043E \u0431\u0443\u0442\u0438 \u043A\u0440\u0430\u0442\u043D\u0438\u043C ${t.divisor}`;
      case "unrecognized_keys":
        return `\u041D\u0435\u0440\u043E\u0437\u043F\u0456\u0437\u043D\u0430\u043D\u0438\u0439 \u043A\u043B\u044E\u0447${t.keys.length > 1 ? "\u0456" : ""}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u043A\u043B\u044E\u0447 \u0443 ${t.origin}`;
      case "invalid_union":
        return "\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456";
      case "invalid_element":
        return `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u043D\u044F \u0443 ${t.origin}`;
      default:
        return "\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456";
    }
  };
}, "error");
function Zr() {
  return {
    localeError: n$()
  };
}
s(Zr, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ua.js
function mc() {
  return Zr();
}
s(mc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ur.js
var i$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u062D\u0631\u0648\u0641", verb: "\u06C1\u0648\u0646\u0627" },
    file: { unit: "\u0628\u0627\u0626\u0679\u0633", verb: "\u06C1\u0648\u0646\u0627" },
    array: { unit: "\u0622\u0626\u0679\u0645\u0632", verb: "\u06C1\u0648\u0646\u0627" },
    set: { unit: "\u0622\u0626\u0679\u0645\u0632", verb: "\u06C1\u0648\u0646\u0627" },
    map: { unit: "\u0622\u0626\u0679\u0645\u0632", verb: "\u06C1\u0648\u0646\u0627" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u0627\u0646 \u067E\u0679",
    email: "\u0627\u06CC \u0645\u06CC\u0644 \u0627\u06CC\u0688\u0631\u06CC\u0633",
    url: "\u06CC\u0648 \u0622\u0631 \u0627\u06CC\u0644",
    emoji: "\u0627\u06CC\u0645\u0648\u062C\u06CC",
    uuid: "\u06CC\u0648 \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC",
    uuidv4: "\u06CC\u0648 \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC \u0648\u06CC 4",
    uuidv6: "\u06CC\u0648 \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC \u0648\u06CC 6",
    nanoid: "\u0646\u06CC\u0646\u0648 \u0622\u0626\u06CC \u0688\u06CC",
    guid: "\u062C\u06CC \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC",
    cuid: "\u0633\u06CC \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC",
    cuid2: "\u0633\u06CC \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC 2",
    ulid: "\u06CC\u0648 \u0627\u06CC\u0644 \u0622\u0626\u06CC \u0688\u06CC",
    xid: "\u0627\u06CC\u06A9\u0633 \u0622\u0626\u06CC \u0688\u06CC",
    ksuid: "\u06A9\u06D2 \u0627\u06CC\u0633 \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC",
    datetime: "\u0622\u0626\u06CC \u0627\u06CC\u0633 \u0627\u0648 \u0688\u06CC\u0679 \u0679\u0627\u0626\u0645",
    date: "\u0622\u0626\u06CC \u0627\u06CC\u0633 \u0627\u0648 \u062A\u0627\u0631\u06CC\u062E",
    time: "\u0622\u0626\u06CC \u0627\u06CC\u0633 \u0627\u0648 \u0648\u0642\u062A",
    duration: "\u0622\u0626\u06CC \u0627\u06CC\u0633 \u0627\u0648 \u0645\u062F\u062A",
    ipv4: "\u0622\u0626\u06CC \u067E\u06CC \u0648\u06CC 4 \u0627\u06CC\u0688\u0631\u06CC\u0633",
    ipv6: "\u0622\u0626\u06CC \u067E\u06CC \u0648\u06CC 6 \u0627\u06CC\u0688\u0631\u06CC\u0633",
    mac: "\u0627\u06CC\u0645 \u0627\u06D2 \u0633\u06CC \u0627\u06CC\u0688\u0631\u06CC\u0633",
    cidrv4: "\u0622\u0626\u06CC \u067E\u06CC \u0648\u06CC 4 \u0631\u06CC\u0646\u062C",
    cidrv6: "\u0622\u0626\u06CC \u067E\u06CC \u0648\u06CC 6 \u0631\u06CC\u0646\u062C",
    base64: "\u0628\u06CC\u0633 64 \u0627\u0646 \u06A9\u0648\u0688\u0688 \u0633\u0679\u0631\u0646\u06AF",
    base64url: "\u0628\u06CC\u0633 64 \u06CC\u0648 \u0622\u0631 \u0627\u06CC\u0644 \u0627\u0646 \u06A9\u0648\u0688\u0688 \u0633\u0679\u0631\u0646\u06AF",
    json_string: "\u062C\u06D2 \u0627\u06CC\u0633 \u0627\u0648 \u0627\u06CC\u0646 \u0633\u0679\u0631\u0646\u06AF",
    e164: "\u0627\u06CC 164 \u0646\u0645\u0628\u0631",
    credit_card: "\u06A9\u0631\u06CC\u0688\u0679 \u06A9\u0627\u0631\u0688 \u0646\u0645\u0628\u0631",
    jwt: "\u062C\u06D2 \u0688\u0628\u0644\u06CC\u0648 \u0679\u06CC",
    template_literal: "\u0627\u0646 \u067E\u0679"
  }, o = {
    nan: "NaN",
    number: "\u0646\u0645\u0628\u0631",
    array: "\u0622\u0631\u06D2",
    null: "\u0646\u0644"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679: instanceof ${t.expected} \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627\u060C ${u} \u0645\u0648\u0635\u0648\u0644 \u06C1\u0648\u0627` : `\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679: ${n} \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627\u060C ${u} \u0645\u0648\u0635\u0648\u0644 \u06C1\u0648\u0627`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679: ${$(t.values[0])} \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627` : `\u063A\u0644\u0637 \u0622\u067E\u0634\u0646: ${g(t.values, "|")} \u0645\u06CC\u06BA \u0633\u06D2 \u0627\u06CC\u06A9 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u0628\u06C1\u062A \u0628\u0691\u0627: ${t.origin ?? "\u0648\u06CC\u0644\u06CC\u0648"} \u06A9\u06D2 ${n}${t.maximum.toString()} ${a.unit ?? "\u0639\u0646\u0627\u0635\u0631"} \u06C1\u0648\u0646\u06D2 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u06D2` : `\u0628\u06C1\u062A \u0628\u0691\u0627: ${t.origin ?? "\u0648\u06CC\u0644\u06CC\u0648"} \u06A9\u0627 ${n}${t.maximum.toString()} \u06C1\u0648\u0646\u0627 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u0628\u06C1\u062A \u0686\u06BE\u0648\u0679\u0627: ${t.origin} \u06A9\u06D2 ${n}${t.minimum.toString()} ${a.unit} \u06C1\u0648\u0646\u06D2 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u06D2` : `\u0628\u06C1\u062A \u0686\u06BE\u0648\u0679\u0627: ${t.origin} \u06A9\u0627 ${n}${t.minimum.toString()} \u06C1\u0648\u0646\u0627 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u063A\u0644\u0637 \u0633\u0679\u0631\u0646\u06AF: "${n.prefix}" \u0633\u06D2 \u0634\u0631\u0648\u0639 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2` : n.format === "ends_with" ? `\u063A\u0644\u0637 \u0633\u0679\u0631\u0646\u06AF: "${n.suffix}" \u067E\u0631 \u062E\u062A\u0645 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2` : n.format === "includes" ? `\u063A\u0644\u0637 \u0633\u0679\u0631\u0646\u06AF: "${n.includes}" \u0634\u0627\u0645\u0644 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2` : n.format === "regex" ? `\u063A\u0644\u0637 \u0633\u0679\u0631\u0646\u06AF: \u067E\u06CC\u0679\u0631\u0646 ${n.pattern} \u0633\u06D2 \u0645\u06CC\u0686 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2` : `\u063A\u0644\u0637 ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u063A\u0644\u0637 \u0646\u0645\u0628\u0631: ${t.divisor} \u06A9\u0627 \u0645\u0636\u0627\u0639\u0641 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2`;
      case "unrecognized_keys":
        return `\u063A\u06CC\u0631 \u062A\u0633\u0644\u06CC\u0645 \u0634\u062F\u06C1 \u06A9\u06CC${t.keys.length > 1 ? "\u0632" : ""}: ${g(t.keys, "\u060C ")}`;
      case "invalid_key":
        return `${t.origin} \u0645\u06CC\u06BA \u063A\u0644\u0637 \u06A9\u06CC`;
      case "invalid_union":
        return "\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679";
      case "invalid_element":
        return `${t.origin} \u0645\u06CC\u06BA \u063A\u0644\u0637 \u0648\u06CC\u0644\u06CC\u0648`;
      default:
        return "\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679";
    }
  };
}, "error");
function gc() {
  return {
    localeError: i$()
  };
}
s(gc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/uz.js
var o$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "belgi", verb: "bo\u2018lishi kerak" },
    file: { unit: "bayt", verb: "bo\u2018lishi kerak" },
    array: { unit: "element", verb: "bo\u2018lishi kerak" },
    set: { unit: "element", verb: "bo\u2018lishi kerak" },
    map: { unit: "yozuv", verb: "bo\u2018lishi kerak" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "kirish",
    email: "elektron pochta manzili",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO sana va vaqti",
    date: "ISO sana",
    time: "ISO vaqt",
    duration: "ISO davomiylik",
    ipv4: "IPv4 manzil",
    ipv6: "IPv6 manzil",
    mac: "MAC manzil",
    cidrv4: "IPv4 diapazon",
    cidrv6: "IPv6 diapazon",
    base64: "base64 kodlangan satr",
    base64url: "base64url kodlangan satr",
    json_string: "JSON satr",
    e164: "E.164 raqam",
    credit_card: "kredit karta raqami",
    jwt: "JWT",
    template_literal: "kirish"
  }, o = {
    nan: "NaN",
    number: "raqam",
    array: "massiv"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `Noto\u2018g\u2018ri kirish: kutilgan instanceof ${t.expected}, qabul qilingan ${u}` : `Noto\u2018g\u2018ri kirish: kutilgan ${n}, qabul qilingan ${u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `Noto\u2018g\u2018ri kirish: kutilgan ${$(t.values[0])}` : `Noto\u2018g\u2018ri variant: quyidagilardan biri kutilgan ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Juda katta: kutilgan ${t.origin ?? "qiymat"} ${n}${t.maximum.toString()} ${a.unit} ${a.verb}` : `Juda katta: kutilgan ${t.origin ?? "qiymat"} ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Juda kichik: kutilgan ${t.origin} ${n}${t.minimum.toString()} ${a.unit} ${a.verb}` : `Juda kichik: kutilgan ${t.origin} ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Noto\u2018g\u2018ri satr: "${n.prefix}" bilan boshlanishi kerak` : n.format === "ends_with" ? `Noto\u2018g\u2018ri satr: "${n.suffix}" bilan tugashi kerak` : n.format === "includes" ? `Noto\u2018g\u2018ri satr: "${n.includes}" ni o\u2018z ichiga olishi kerak` : n.format === "regex" ? `Noto\u2018g\u2018ri satr: ${n.pattern} shabloniga mos kelishi kerak` : `Noto\u2018g\u2018ri ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `Noto\u2018g\u2018ri raqam: ${t.divisor} ning karralisi bo\u2018lishi kerak`;
      case "unrecognized_keys":
        return `Noma\u2019lum kalit${t.keys.length > 1 ? "lar" : ""}: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `${t.origin} dagi kalit noto\u2018g\u2018ri`;
      case "invalid_union":
        return "Noto\u2018g\u2018ri kirish";
      case "invalid_element":
        return `${t.origin} da noto\u2018g\u2018ri qiymat`;
      default:
        return "Noto\u2018g\u2018ri kirish";
    }
  };
}, "error");
function hc() {
  return {
    localeError: o$()
  };
}
s(hc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/vi.js
var a$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "k\xFD t\u1EF1", verb: "c\xF3" },
    file: { unit: "byte", verb: "c\xF3" },
    array: { unit: "ph\u1EA7n t\u1EED", verb: "c\xF3" },
    set: { unit: "ph\u1EA7n t\u1EED", verb: "c\xF3" },
    map: { unit: "ph\u1EA7n t\u1EED", verb: "c\xF3" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u0111\u1EA7u v\xE0o",
    email: "\u0111\u1ECBa ch\u1EC9 email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ng\xE0y gi\u1EDD ISO",
    date: "ng\xE0y ISO",
    time: "gi\u1EDD ISO",
    duration: "kho\u1EA3ng th\u1EDDi gian ISO",
    ipv4: "\u0111\u1ECBa ch\u1EC9 IPv4",
    ipv6: "\u0111\u1ECBa ch\u1EC9 IPv6",
    mac: "\u0111\u1ECBa ch\u1EC9 MAC",
    cidrv4: "d\u1EA3i IPv4",
    cidrv6: "d\u1EA3i IPv6",
    base64: "chu\u1ED7i m\xE3 h\xF3a base64",
    base64url: "chu\u1ED7i m\xE3 h\xF3a base64url",
    json_string: "chu\u1ED7i JSON",
    e164: "s\u1ED1 E.164",
    credit_card: "s\u1ED1 th\u1EBB t\xEDn d\u1EE5ng",
    jwt: "JWT",
    template_literal: "\u0111\u1EA7u v\xE0o"
  }, o = {
    nan: "NaN",
    number: "s\u1ED1",
    array: "m\u1EA3ng"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7: mong \u0111\u1EE3i instanceof ${t.expected}, nh\u1EADn \u0111\u01B0\u1EE3c ${u}` : `\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7: mong \u0111\u1EE3i ${n}, nh\u1EADn \u0111\u01B0\u1EE3c ${u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7: mong \u0111\u1EE3i ${$(t.values[0])}` : `T\xF9y ch\u1ECDn kh\xF4ng h\u1EE3p l\u1EC7: mong \u0111\u1EE3i m\u1ED9t trong c\xE1c gi\xE1 tr\u1ECB ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `Qu\xE1 l\u1EDBn: mong \u0111\u1EE3i ${t.origin ?? "gi\xE1 tr\u1ECB"} ${a.verb} ${n}${t.maximum.toString()} ${a.unit ?? "ph\u1EA7n t\u1EED"}` : `Qu\xE1 l\u1EDBn: mong \u0111\u1EE3i ${t.origin ?? "gi\xE1 tr\u1ECB"} ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `Qu\xE1 nh\u1ECF: mong \u0111\u1EE3i ${t.origin} ${a.verb} ${n}${t.minimum.toString()} ${a.unit}` : `Qu\xE1 nh\u1ECF: mong \u0111\u1EE3i ${t.origin} ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `Chu\u1ED7i kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i b\u1EAFt \u0111\u1EA7u b\u1EB1ng "${n.prefix}"` : n.format === "ends_with" ? `Chu\u1ED7i kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i k\u1EBFt th\xFAc b\u1EB1ng "${n.suffix}"` : n.format === "includes" ? `Chu\u1ED7i kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i bao g\u1ED3m "${n.includes}"` : n.format === "regex" ? `Chu\u1ED7i kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i kh\u1EDBp v\u1EDBi m\u1EABu ${n.pattern}` : `${i[n.format] ?? t.format} kh\xF4ng h\u1EE3p l\u1EC7`;
      }
      case "not_multiple_of":
        return `S\u1ED1 kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i l\xE0 b\u1ED9i s\u1ED1 c\u1EE7a ${t.divisor}`;
      case "unrecognized_keys":
        return `Kh\xF3a kh\xF4ng \u0111\u01B0\u1EE3c nh\u1EADn d\u1EA1ng: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `Kh\xF3a kh\xF4ng h\u1EE3p l\u1EC7 trong ${t.origin}`;
      case "invalid_union":
        return "\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7";
      case "invalid_element":
        return `Gi\xE1 tr\u1ECB kh\xF4ng h\u1EE3p l\u1EC7 trong ${t.origin}`;
      default:
        return "\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7";
    }
  };
}, "error");
function vc() {
  return {
    localeError: a$()
  };
}
s(vc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/zh-CN.js
var s$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u5B57\u7B26", verb: "\u5305\u542B" },
    file: { unit: "\u5B57\u8282", verb: "\u5305\u542B" },
    array: { unit: "\u9879", verb: "\u5305\u542B" },
    set: { unit: "\u9879", verb: "\u5305\u542B" },
    map: { unit: "\u9879", verb: "\u5305\u542B" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u8F93\u5165",
    email: "\u7535\u5B50\u90AE\u4EF6",
    url: "URL",
    emoji: "\u8868\u60C5\u7B26\u53F7",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO\u65E5\u671F\u65F6\u95F4",
    date: "ISO\u65E5\u671F",
    time: "ISO\u65F6\u95F4",
    duration: "ISO\u65F6\u957F",
    ipv4: "IPv4\u5730\u5740",
    ipv6: "IPv6\u5730\u5740",
    mac: "MAC\u5730\u5740",
    cidrv4: "IPv4\u7F51\u6BB5",
    cidrv6: "IPv6\u7F51\u6BB5",
    base64: "base64\u7F16\u7801\u5B57\u7B26\u4E32",
    base64url: "base64url\u7F16\u7801\u5B57\u7B26\u4E32",
    json_string: "JSON\u5B57\u7B26\u4E32",
    e164: "E.164\u53F7\u7801",
    credit_card: "\u4FE1\u7528\u5361\u53F7",
    jwt: "JWT",
    template_literal: "\u8F93\u5165"
  }, o = {
    nan: "NaN",
    number: "\u6570\u5B57",
    array: "\u6570\u7EC4",
    null: "\u7A7A\u503C(null)"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u65E0\u6548\u8F93\u5165\uFF1A\u671F\u671B instanceof ${t.expected}\uFF0C\u5B9E\u9645\u63A5\u6536 ${u}` : `\u65E0\u6548\u8F93\u5165\uFF1A\u671F\u671B ${n}\uFF0C\u5B9E\u9645\u63A5\u6536 ${u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u65E0\u6548\u8F93\u5165\uFF1A\u671F\u671B ${$(t.values[0])}` : `\u65E0\u6548\u9009\u9879\uFF1A\u671F\u671B\u4EE5\u4E0B\u4E4B\u4E00 ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u6570\u503C\u8FC7\u5927\uFF1A\u671F\u671B ${t.origin ?? "\u503C"} ${n}${t.maximum.toString()} ${a.unit ?? "\u4E2A\u5143\u7D20"}` : `\u6570\u503C\u8FC7\u5927\uFF1A\u671F\u671B ${t.origin ?? "\u503C"} ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u6570\u503C\u8FC7\u5C0F\uFF1A\u671F\u671B ${t.origin} ${n}${t.minimum.toString()} ${a.unit}` : `\u6570\u503C\u8FC7\u5C0F\uFF1A\u671F\u671B ${t.origin} ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u65E0\u6548\u5B57\u7B26\u4E32\uFF1A\u5FC5\u987B\u4EE5 "${n.prefix}" \u5F00\u5934` : n.format === "ends_with" ? `\u65E0\u6548\u5B57\u7B26\u4E32\uFF1A\u5FC5\u987B\u4EE5 "${n.suffix}" \u7ED3\u5C3E` : n.format === "includes" ? `\u65E0\u6548\u5B57\u7B26\u4E32\uFF1A\u5FC5\u987B\u5305\u542B "${n.includes}"` : n.format === "regex" ? `\u65E0\u6548\u5B57\u7B26\u4E32\uFF1A\u5FC5\u987B\u6EE1\u8DB3\u6B63\u5219\u8868\u8FBE\u5F0F ${n.pattern}` : `\u65E0\u6548${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u65E0\u6548\u6570\u5B57\uFF1A\u5FC5\u987B\u662F ${t.divisor} \u7684\u500D\u6570`;
      case "unrecognized_keys":
        return `\u51FA\u73B0\u672A\u77E5\u7684\u952E(key): ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `${t.origin} \u4E2D\u7684\u952E(key)\u65E0\u6548`;
      case "invalid_union":
        return "\u65E0\u6548\u8F93\u5165";
      case "invalid_element":
        return `${t.origin} \u4E2D\u5305\u542B\u65E0\u6548\u503C(value)`;
      default:
        return "\u65E0\u6548\u8F93\u5165";
    }
  };
}, "error");
function yc() {
  return {
    localeError: s$()
  };
}
s(yc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/zh-TW.js
var u$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u5B57\u5143", verb: "\u64C1\u6709" },
    file: { unit: "\u4F4D\u5143\u7D44", verb: "\u64C1\u6709" },
    array: { unit: "\u9805\u76EE", verb: "\u64C1\u6709" },
    set: { unit: "\u9805\u76EE", verb: "\u64C1\u6709" },
    map: { unit: "\u9805\u76EE", verb: "\u64C1\u6709" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u8F38\u5165",
    email: "\u90F5\u4EF6\u5730\u5740",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u65E5\u671F\u6642\u9593",
    date: "ISO \u65E5\u671F",
    time: "ISO \u6642\u9593",
    duration: "ISO \u671F\u9593",
    ipv4: "IPv4 \u4F4D\u5740",
    ipv6: "IPv6 \u4F4D\u5740",
    mac: "MAC \u4F4D\u5740",
    cidrv4: "IPv4 \u7BC4\u570D",
    cidrv6: "IPv6 \u7BC4\u570D",
    base64: "base64 \u7DE8\u78BC\u5B57\u4E32",
    base64url: "base64url \u7DE8\u78BC\u5B57\u4E32",
    json_string: "JSON \u5B57\u4E32",
    e164: "E.164 \u6578\u503C",
    credit_card: "\u4FE1\u7528\u5361\u865F",
    jwt: "JWT",
    template_literal: "\u8F38\u5165"
  }, o = {
    nan: "NaN"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\u7121\u6548\u7684\u8F38\u5165\u503C\uFF1A\u9810\u671F\u70BA instanceof ${t.expected}\uFF0C\u4F46\u6536\u5230 ${u}` : `\u7121\u6548\u7684\u8F38\u5165\u503C\uFF1A\u9810\u671F\u70BA ${n}\uFF0C\u4F46\u6536\u5230 ${u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\u7121\u6548\u7684\u8F38\u5165\u503C\uFF1A\u9810\u671F\u70BA ${$(t.values[0])}` : `\u7121\u6548\u7684\u9078\u9805\uFF1A\u9810\u671F\u70BA\u4EE5\u4E0B\u5176\u4E2D\u4E4B\u4E00 ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `\u6578\u503C\u904E\u5927\uFF1A\u9810\u671F ${t.origin ?? "\u503C"} \u61C9\u70BA ${n}${t.maximum.toString()} ${a.unit ?? "\u500B\u5143\u7D20"}` : `\u6578\u503C\u904E\u5927\uFF1A\u9810\u671F ${t.origin ?? "\u503C"} \u61C9\u70BA ${n}${t.maximum.toString()}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `\u6578\u503C\u904E\u5C0F\uFF1A\u9810\u671F ${t.origin} \u61C9\u70BA ${n}${t.minimum.toString()} ${a.unit}` : `\u6578\u503C\u904E\u5C0F\uFF1A\u9810\u671F ${t.origin} \u61C9\u70BA ${n}${t.minimum.toString()}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u7121\u6548\u7684\u5B57\u4E32\uFF1A\u5FC5\u9808\u4EE5 "${n.prefix}" \u958B\u982D` : n.format === "ends_with" ? `\u7121\u6548\u7684\u5B57\u4E32\uFF1A\u5FC5\u9808\u4EE5 "${n.suffix}" \u7D50\u5C3E` : n.format === "includes" ? `\u7121\u6548\u7684\u5B57\u4E32\uFF1A\u5FC5\u9808\u5305\u542B "${n.includes}"` : n.format === "regex" ? `\u7121\u6548\u7684\u5B57\u4E32\uFF1A\u5FC5\u9808\u7B26\u5408\u683C\u5F0F ${n.pattern}` : `\u7121\u6548\u7684 ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `\u7121\u6548\u7684\u6578\u5B57\uFF1A\u5FC5\u9808\u70BA ${t.divisor} \u7684\u500D\u6578`;
      case "unrecognized_keys":
        return `\u7121\u6CD5\u8B58\u5225\u7684\u9375\u503C${t.keys.length > 1 ? "\u5011" : ""}\uFF1A${g(t.keys, "\u3001")}`;
      case "invalid_key":
        return `${t.origin} \u4E2D\u6709\u7121\u6548\u7684\u9375\u503C`;
      case "invalid_union":
        return "\u7121\u6548\u7684\u8F38\u5165\u503C";
      case "invalid_element":
        return `${t.origin} \u4E2D\u6709\u7121\u6548\u7684\u503C`;
      default:
        return "\u7121\u6548\u7684\u8F38\u5165\u503C";
    }
  };
}, "error");
function $c() {
  return {
    localeError: u$()
  };
}
s($c, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/yo.js
var c$ = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\xE0mi", verb: "n\xED" },
    file: { unit: "bytes", verb: "n\xED" },
    array: { unit: "nkan", verb: "n\xED" },
    set: { unit: "nkan", verb: "n\xED" },
    map: { unit: "nkan", verb: "n\xED" }
  };
  function r(t) {
    return e[t] ?? null;
  }
  s(r, "getSizing");
  let i = {
    regex: "\u1EB9\u0300r\u1ECD \xECb\xE1w\u1ECDl\xE9",
    email: "\xE0d\xEDr\u1EB9\u0301s\xEC \xECm\u1EB9\u0301l\xEC",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\xE0k\xF3k\xF2 ISO",
    date: "\u1ECDj\u1ECD\u0301 ISO",
    time: "\xE0k\xF3k\xF2 ISO",
    duration: "\xE0k\xF3k\xF2 t\xF3 p\xE9 ISO",
    ipv4: "\xE0d\xEDr\u1EB9\u0301s\xEC IPv4",
    ipv6: "\xE0d\xEDr\u1EB9\u0301s\xEC IPv6",
    mac: "\xE0d\xEDr\u1EB9\u0301s\xEC MAC",
    cidrv4: "\xE0gb\xE8gb\xE8 IPv4",
    cidrv6: "\xE0gb\xE8gb\xE8 IPv6",
    base64: "\u1ECD\u0300r\u1ECD\u0300 t\xED a k\u1ECD\u0301 n\xED base64",
    base64url: "\u1ECD\u0300r\u1ECD\u0300 base64url",
    json_string: "\u1ECD\u0300r\u1ECD\u0300 JSON",
    e164: "n\u1ECD\u0301mb\xE0 E.164",
    credit_card: "n\u1ECDmba kaadi gbese",
    jwt: "JWT",
    template_literal: "\u1EB9\u0300r\u1ECD \xECb\xE1w\u1ECDl\xE9"
  }, o = {
    nan: "NaN",
    number: "n\u1ECD\u0301mb\xE0",
    array: "akop\u1ECD"
  };
  return (t) => {
    switch (t.code) {
      case "invalid_type": {
        let n = o[t.expected] ?? t.expected, a = b(t.input), u = o[a] ?? a;
        return /^[A-Z]/.test(t.expected) ? `\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e: a n\xED l\xE1ti fi instanceof ${t.expected}, \xE0m\u1ECD\u0300 a r\xED ${u}` : `\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e: a n\xED l\xE1ti fi ${n}, \xE0m\u1ECD\u0300 a r\xED ${u}`;
      }
      case "invalid_value":
        return t.values.length === 1 ? `\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e: a n\xED l\xE1ti fi ${$(t.values[0])}` : `\xC0\u1E63\xE0y\xE0n a\u1E63\xEC\u1E63e: yan \u1ECD\u0300kan l\xE1ra ${g(t.values, "|")}`;
      case "too_big": {
        let n = t.inclusive ? "<=" : "<", a = r(t.origin);
        return a ? `T\xF3 p\u1ECD\u0300 j\xF9: a n\xED l\xE1ti j\u1EB9\u0301 p\xE9 ${t.origin ?? "iye"} ${a.verb} ${n}${t.maximum} ${a.unit}` : `T\xF3 p\u1ECD\u0300 j\xF9: a n\xED l\xE1ti j\u1EB9\u0301 ${n}${t.maximum}`;
      }
      case "too_small": {
        let n = t.inclusive ? ">=" : ">", a = r(t.origin);
        return a ? `K\xE9r\xE9 ju: a n\xED l\xE1ti j\u1EB9\u0301 p\xE9 ${t.origin} ${a.verb} ${n}${t.minimum} ${a.unit}` : `K\xE9r\xE9 ju: a n\xED l\xE1ti j\u1EB9\u0301 ${n}${t.minimum}`;
      }
      case "invalid_format": {
        let n = t;
        return n.format === "starts_with" ? `\u1ECC\u0300r\u1ECD\u0300 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 b\u1EB9\u0300r\u1EB9\u0300 p\u1EB9\u0300l\xFA "${n.prefix}"` : n.format === "ends_with" ? `\u1ECC\u0300r\u1ECD\u0300 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 par\xED p\u1EB9\u0300l\xFA "${n.suffix}"` : n.format === "includes" ? `\u1ECC\u0300r\u1ECD\u0300 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 n\xED "${n.includes}"` : n.format === "regex" ? `\u1ECC\u0300r\u1ECD\u0300 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 b\xE1 \xE0p\u1EB9\u1EB9r\u1EB9 mu ${n.pattern}` : `A\u1E63\xEC\u1E63e: ${i[n.format] ?? t.format}`;
      }
      case "not_multiple_of":
        return `N\u1ECD\u0301mb\xE0 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 j\u1EB9\u0301 \xE8y\xE0 p\xEDp\xEDn ti ${t.divisor}`;
      case "unrecognized_keys":
        return `B\u1ECDt\xECn\xEC \xE0\xECm\u1ECD\u0300: ${g(t.keys, ", ")}`;
      case "invalid_key":
        return `B\u1ECDt\xECn\xEC a\u1E63\xEC\u1E63e n\xEDn\xFA ${t.origin}`;
      case "invalid_union":
        return "\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e";
      case "invalid_element":
        return `Iye a\u1E63\xEC\u1E63e n\xEDn\xFA ${t.origin}`;
      default:
        return "\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e";
    }
  };
}, "error");
function bc() {
  return {
    localeError: c$()
  };
}
s(bc, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/registries.js
var _p, _c = /* @__PURE__ */ Symbol("ZodOutput"), xc = /* @__PURE__ */ Symbol("ZodInput"), fi = class {
  static {
    s(this, "$ZodRegistry");
  }
  constructor() {
    this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map();
  }
  add(r, ...i) {
    let o = i[0];
    return this._map.set(r, o), o && typeof o == "object" && "id" in o && this._idmap.set(o.id, r), this;
  }
  clear() {
    return this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map(), this;
  }
  remove(r) {
    let i = this._map.get(r);
    return i && typeof i == "object" && "id" in i && this._idmap.delete(i.id), this._map.delete(r), this;
  }
  get(r) {
    let i = r._zod.parent;
    if (i) {
      let o = { ...this.get(i) ?? {} };
      delete o.id;
      let t = { ...o, ...this._map.get(r) };
      return Object.keys(t).length ? t : void 0;
    }
    return this._map.get(r);
  }
  has(r) {
    return this._map.has(r);
  }
};
function pi() {
  return new fi();
}
s(pi, "registry");
(_p = globalThis).__zod_globalRegistry ?? (_p.__zod_globalRegistry = pi());
var H = globalThis.__zod_globalRegistry;

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/compile.js
var pe = Symbol.for("zod.compile.invalid"), xp = Symbol.for("zod.compile.fallback"), be = class extends Error {
  static {
    s(this, "ZodCompileAsyncError");
  }
  constructor(r = "z.compile does not support async refinements, transforms, or checks") {
    super(r), this.name = "ZodCompileAsyncError";
  }
}, U = class extends Error {
  static {
    s(this, "ZodCompileUnsupportedError");
  }
  constructor(r, i = !0) {
    super(`z.compile does not support ${r}; this schema must use the runtime parser`), this.name = "ZodCompileUnsupportedError", this.islandable = i;
  }
};
function d$(e, r) {
  try {
    return mi(e, { assertOnly: !0 });
  } catch {
    return r;
  }
}
s(d$, "compileValidator");
function zc(e, r) {
  try {
    let i = mi(e), o = A(e), t = e._zod.run, n = t.__originalRun ?? t, a = /* @__PURE__ */ s((u, c) => {
      if (c?.async || c?.direction === "backward" || c?.skipChecks || c?.[xp] || c && di(c, u.value))
        return n(u, c);
      let l = i(u.value);
      return l !== pe ? (u.value = l, u) : (c && (c[xp] = !0), n(u, c));
    }, "wrapped");
    return a.__originalRun = n, o._zod.bag.fallbackRun = n, o._zod.bag.validator = d$(e, i), o._zod.run = a, t.__originalRun || f$(o, e, i), o;
  } catch (i) {
    if (r?.strict)
      throw i;
    return e;
  }
}
s(zc, "compile");
function f$(e, r, i) {
  let o = e, t = r;
  if (typeof t.safeParse == "function") {
    let n = t.safeParse;
    o.safeParse = (a, u) => {
      let c = i(a);
      return c !== pe ? { success: !0, data: c } : n(a, u);
    };
  }
  if (typeof t.parse == "function") {
    let n = t.parse;
    o.parse = (a, u) => {
      let c = i(a);
      return c !== pe ? c : n(a, u);
    };
  }
}
s(f$, "installCompiledUserMethods");
function mi(e, r) {
  let i = !0;
  try {
    i = gu(e);
  } catch {
  }
  if (i)
    throw new U("a schema whose subtree contains a reference cycle");
  let o = {
    constants: /* @__PURE__ */ new Map(),
    constantCounter: 0,
    varCounter: 0
  }, t = new at(["input"]), n = J(t, o, e, "input", !r?.assertOnly);
  t.write(n === null ? "return true;" : `return ${n};`);
  let a = ["INVALID", ...o.constants.keys()], u = [pe, ...o.constants.values()], c = t.content.join(`
`), l = r?.debug ? a.length > 0 ? `// Constants: ${a.join(", ")}
${c}` : c : "", d = Function, f = `return (input) => {
${c}
}`, p;
  try {
    p = new d(...a, f)(...u);
  } catch (h) {
    throw new U(`this schema (generated code failed to evaluate: ${h.message})`);
  }
  return r?.debug && (p.code = l), p;
}
s(mi, "compileFn");
function j(e, r) {
  for (let [o, t] of e.constants)
    if (t === r)
      return o;
  let i = `c${e.constantCounter++}`;
  return e.constants.set(i, r), i;
}
s(j, "addConstant");
function P(e) {
  return `v${e.varCounter++}`;
}
s(P, "newVar");
function p$(e, r) {
  let i = e._zod.run({ value: r, issues: [] }, {});
  if (i && typeof i.then == "function")
    return pe;
  let o = i;
  return o.issues.length === 0 ? o.value : pe;
}
s(p$, "runtimeRun");
function re(e, r, i, o, t = !0) {
  let n = e.content.length, a = r.constants.size, u = r.constantCounter, c = r.varCounter;
  try {
    return J(e, r, i, o, t);
  } catch (l) {
    if (!(l instanceof U) || !l.islandable)
      throw l;
    if (e.content.length = n, r.constants.size > a) {
      let d = Array.from(r.constants.keys()).slice(a);
      for (let f of d)
        r.constants.delete(f);
    }
    return r.constantCounter = u, r.varCounter = c, m$(e, r, i, o);
  }
}
s(re, "compileChild");
function m$(e, r, i, o) {
  let t = j(r, i), n = j(r, p$), a = P(r);
  return e.write(`const ${a} = ${n}(${t}, ${o});`), e.write(`if (${a} === INVALID) return INVALID;`), a;
}
s(m$, "emitRuntimeIsland");
var g$ = /* @__PURE__ */ new Set([
  "max_size",
  "min_size",
  "size_equals",
  "max_length",
  "min_length",
  "length_equals"
]);
function h$(e, r, i, o) {
  let t = i._zod.def.checks;
  if (!t || t.length === 0)
    return o;
  let n = o;
  for (let a of t) {
    let u = a._zod.def;
    if (u.when && !g$.has(u.check))
      throw new U('check with a custom "when" condition');
    switch (u.check) {
      case "greater_than":
        v$(e, r, u, n);
        break;
      case "less_than":
        y$(e, r, u, n);
        break;
      case "multiple_of":
        $$(e, r, u, n);
        break;
      case "number_format":
        zp(e, u, n);
        break;
      case "min_length": {
        let c = ct(u.minimum, "min_length"), l = wc(e, r, n, `${n}.length >= ${c} && ${n}.length < ${u.minimum * 2}`);
        e.write(`if (${l} < ${c}) return INVALID;`);
        break;
      }
      case "max_length": {
        let c = ct(u.maximum, "max_length"), l = wc(e, r, n, `${n}.length > ${c}`);
        e.write(`if (${l} > ${c}) return INVALID;`);
        break;
      }
      case "length_equals": {
        let c = ct(u.length, "length_equals"), l = wc(e, r, n, `${n}.length >= ${c} && ${n}.length <= ${u.length * 2}`);
        e.write(`if (${l} !== ${c}) return INVALID;`);
        break;
      }
      case "min_size":
        e.write(`if (${n}.size < ${ct(u.minimum, "min_size")}) return INVALID;`);
        break;
      case "max_size":
        e.write(`if (${n}.size > ${ct(u.maximum, "max_size")}) return INVALID;`);
        break;
      case "size_equals":
        e.write(`if (${n}.size !== ${ct(u.size, "size_equals")}) return INVALID;`);
        break;
      case "string_format":
        n = Sp(e, r, u, n);
        break;
      case "custom":
        n = k$(e, r, a, n);
        break;
      case "bigint_format":
        b$(e, u, n);
        break;
      case "mime_type":
        _$(e, r, u, n);
        break;
      case "property":
        x$(e, r, u, n);
        break;
      case "overwrite": {
        let c = P(r);
        w$(e, r, a, n, c), n = c;
        break;
      }
      default:
        throw new U(`check type ${u.check}`);
    }
  }
  return n;
}
s(h$, "generateChecks");
function wc(e, r, i, o) {
  let t = j(r, rt), n = P(r);
  return e.write(`const ${n} = typeof ${i} === "string" && ${o} ? ${t}(${i}) : ${i}.length;`), n;
}
s(wc, "codePointLengthVar");
function ct(e, r) {
  if (typeof e != "number" || !Number.isFinite(e))
    throw new U(`${r} bound of type ${typeof e}`);
  return `${e}`;
}
s(ct, "numericOperand");
function Ip(e, r) {
  if (typeof r == "bigint")
    return `${r}n`;
  if (typeof r == "number") {
    if (Number.isNaN(r))
      throw new U("comparison check with NaN bound");
    return `${r}`;
  }
  if (r instanceof Date) {
    if (Number.isNaN(r.getTime()))
      throw new U("comparison check with Invalid Date bound");
    return j(e, r);
  }
  throw new U(`comparison check bound of type ${typeof r}`);
}
s(Ip, "comparisonOperand");
function v$(e, r, i, o) {
  let t = i.inclusive ? "<" : "<=";
  e.write(`if (${o} ${t} ${Ip(r, i.value)}) return INVALID;`);
}
s(v$, "generateGreaterThanCheck");
function y$(e, r, i, o) {
  let t = i.inclusive ? ">" : ">=";
  e.write(`if (${o} ${t} ${Ip(r, i.value)}) return INVALID;`);
}
s(y$, "generateLessThanCheck");
function $$(e, r, i, o) {
  if (typeof i.value == "bigint") {
    if (i.value === BigInt(0))
      throw new U("multiple_of check with a zero divisor");
    e.write(`if (${o} % ${i.value}n !== 0n) return INVALID;`);
  } else {
    let t = j(r, $r);
    e.write(`if (${t}(${o}, ${ct(i.value, "multiple_of")}) !== 0) return INVALID;`);
  }
}
s($$, "generateMultipleOfCheck");
function zp(e, r, i) {
  let o = r.format;
  switch (o) {
    case "safeint":
      e.write(`if (!Number.isSafeInteger(${i})) return INVALID;`);
      break;
    case "int32":
      e.write(`if (!Number.isInteger(${i}) || ${i} < -2147483648 || ${i} > 2147483647) return INVALID;`);
      break;
    case "uint32":
      e.write(`if (!Number.isInteger(${i}) || ${i} < 0 || ${i} > 4294967295) return INVALID;`);
      break;
    case "float32":
      e.write(`if (!Number.isFinite(${i}) || ${i} < -3.4028234663852886e38 || ${i} > 3.4028234663852886e38) return INVALID;`);
      break;
    case "float64":
      e.write(`if (!Number.isFinite(${i})) return INVALID;`);
      break;
    default:
      throw new U(`number format ${o}`);
  }
}
s(zp, "generateNumberFormatCheck");
function b$(e, r, i) {
  let o = r.format;
  if (o)
    switch (o) {
      case "int64":
        e.write(`if (${i} < -9223372036854775808n || ${i} > 9223372036854775807n) return INVALID;`);
        break;
      case "uint64":
        e.write(`if (${i} < 0n || ${i} > 18446744073709551615n) return INVALID;`);
        break;
      default:
        throw new U(`bigint format ${o}`);
    }
}
s(b$, "generateBigIntFormatCheck");
function _$(e, r, i, o) {
  let t = i.mime;
  if (t && t.length > 0) {
    let n = j(r, new Set(t));
    e.write(`if (!${n}.has(${o}.type)) return INVALID;`);
  }
}
s(_$, "generateMimeTypeCheck");
function x$(e, r, i, o) {
  let t = `${o}[${JSON.stringify(i.property)}]`;
  J(e, r, i.schema, t);
}
s(x$, "generatePropertyCheck");
function w$(e, r, i, o, t) {
  let n = i._zod.def.tx;
  if (!n)
    throw new U("overwrite check without a transform function");
  if (ft(n))
    throw new be("z.compile: async overwrite transforms are not supported");
  let a = j(r, n);
  e.write(`const ${t} = ${a}(${o});`);
}
s(w$, "generateOverwriteCheck");
function kc() {
  throw new se();
}
s(kc, "throwAsync");
function Sc(e) {
  this.issues.push(e);
}
s(Sc, "pushIssue");
function k$(e, r, i, o) {
  let t = i._zod.def;
  if (t.fn) {
    if (ft(t.fn))
      throw new be("z.compile: async .refine() predicates are not supported");
    let n = j(r, t.fn), a = j(r, kc), u = P(r);
    return e.write(`const ${u} = ${n}(${o});`), e.write(`if (${u} instanceof Promise) ${a}();`), e.write(`if (!${u}) return INVALID;`), o;
  }
  if (i._zod.check) {
    if (ft(i._zod.check))
      throw new be("z.compile: async .superRefine() / check functions are not supported");
    let n = i._zod.check, u = j(r, /* @__PURE__ */ s((l) => {
      let d = { value: l, issues: [], addIssue: Sc };
      return n(d) instanceof Promise && kc(), d.issues.length === 0 ? d.value : pe;
    }, "helperFn")), c = P(r);
    return e.write(`const ${c} = ${u}(${o});`), e.write(`if (${c} === INVALID) return INVALID;`), c;
  }
  throw new U("custom check without a predicate or check function");
}
s(k$, "generateCustomRefineCheck");
var I$ = /* @__PURE__ */ new Set([
  "cidrv4",
  "cuid",
  "cuid2",
  "date",
  "datetime",
  "duration",
  "e164",
  "email",
  "emoji",
  "ends_with",
  "guid",
  "includes",
  "ipv4",
  "ksuid",
  "lowercase",
  "mac",
  "nanoid",
  "regex",
  "starts_with",
  "time",
  "ulid",
  "uppercase",
  "uuid",
  "xid"
]);
function Sp(e, r, i, o) {
  let t = i.format;
  if (t === "base64") {
    let c = j(r, Dr);
    return e.write(`if (!${c}(${o})) return INVALID;`), o;
  }
  if (t === "base64url") {
    let c = j(r, ti);
    return e.write(`if (!${c}(${o})) return INVALID;`), o;
  }
  if (t === "jwt") {
    let c = j(r, ni), l = j(r, i.alg ?? null);
    return e.write(`if (!${c}(${o}, ${l})) return INVALID;`), o;
  }
  if (t === "ipv6") {
    let c = j(r, Pr);
    return e.write(`if (!${c}(${o})) return INVALID;`), o;
  }
  if (t === "cidrv6") {
    let c = j(r, ei);
    return e.write(`if (!${c}(${o})) return INVALID;`), o;
  }
  if (t === "credit_card") {
    let c = j(r, ri);
    return e.write(`if (!${c}(${o})) return INVALID;`), o;
  }
  let n = i;
  if (t === "url" || t === "httpurl" || n.normalize || n.hostname !== void 0 || n.protocol !== void 0) {
    let c = j(r, Xn), l = j(r, i), d = P(r), f = P(r);
    if (e.write(`const ${d} = ${o}.trim();`), e.write(`const ${f} = ${c}(${d}, ${l});`), e.write(`if (typeof ${f} === "number") return INVALID;`), n.hostname !== void 0) {
      let v = j(r, Qn);
      e.write(`if (!${v}(${f}, ${l}.hostname)) return INVALID;`);
    }
    if (n.protocol !== void 0) {
      let v = j(r, Yn);
      e.write(`if (!${v}(${f}, ${l}.protocol)) return INVALID;`);
    }
    let p = P(r), h = n.normalize ? `${f}.href` : `${j(r, Hn)}(${d})`;
    return e.write(`const ${p} = ${h};`), p;
  }
  let a = i.fn;
  if (a) {
    if (ft(a))
      throw new U(`async string format ${t}`);
    let c = j(r, a);
    return e.write(`if (!${c}(${o})) return INVALID;`), o;
  }
  if (I$.has(t) && i.pattern) {
    let c = j(r, i.pattern);
    return e.write(`${c}.lastIndex = 0;`), e.write(`if (!${c}.test(${o})) return INVALID;`), o;
  }
  let u = i.format;
  switch (u) {
    case "regex":
      throw new U("regex format without a pattern");
    case "lowercase":
      e.write(`if (${o} !== ${o}.toLowerCase()) return INVALID;`);
      break;
    case "uppercase":
      e.write(`if (${o} !== ${o}.toUpperCase()) return INVALID;`);
      break;
    case "includes":
      e.write(`if (!${o}.includes(${ie(i.includes)})) return INVALID;`);
      break;
    case "starts_with": {
      let c = i.prefix;
      e.write(`if (${o}.slice(0, ${c.length}) !== ${ie(c)}) return INVALID;`);
      break;
    }
    case "ends_with": {
      let c = i.suffix;
      e.write(`if (${o}.slice(-${c.length}) !== ${ie(c)}) return INVALID;`);
      break;
    }
    default:
      throw new U(`string format ${u}`);
  }
  return o;
}
s(Sp, "generateStringFormatCheck");
function J(e, r, i, o, t = !0) {
  let n = i._zod.def, a = n.type;
  if (n.coerce)
    throw new U(`coercion (z.coerce.${a}())`);
  let u = t || !!n.checks?.length, c;
  switch (a) {
    case "string":
      c = z$(e, r, i, o);
      break;
    case "number":
      c = S$(e, i, o);
      break;
    case "boolean":
      c = O$(e, o);
      break;
    case "bigint":
      c = j$(e, i, o);
      break;
    case "symbol":
      c = P$(e, o);
      break;
    case "undefined":
      c = D$(e, o);
      break;
    case "null":
      c = N$(e, o);
      break;
    case "any":
    case "unknown":
      c = o;
      break;
    case "never":
      e.write("return INVALID;"), c = o;
      break;
    case "void":
      c = T$(e, o);
      break;
    case "nan":
      c = A$(e, o);
      break;
    case "date":
      c = U$(e, o);
      break;
    case "object":
      c = E$(e, r, i, o, u);
      break;
    case "optional":
      c = C$(e, r, i, o, u);
      break;
    case "nullable":
      c = F$(e, r, i, o, u);
      break;
    case "array":
      c = L$(e, r, i, o, u);
      break;
    case "literal":
      c = V$(e, r, i, o);
      break;
    case "enum":
      c = M$(e, r, i, o);
      break;
    case "readonly": {
      let l = wp(e, r, i, o), d = P(r);
      e.write(`const ${d} = Object.freeze(${l});`), c = d;
      break;
    }
    case "success":
      wp(e, r, i, o), c = "true";
      break;
    case "default":
    case "prefault":
      c = B$(e, r, i, o);
      break;
    case "nonoptional":
      c = J$(e, r, i, o);
      break;
    case "tuple":
      c = q$(e, r, i, o);
      break;
    case "union":
      c = K$(e, r, i, o);
      break;
    case "intersection":
      c = X$(e, r, i, o);
      break;
    case "record":
      c = H$(e, r, i, o);
      break;
    case "map":
      c = Y$(e, r, i, o);
      break;
    case "set":
      c = eb(e, r, i, o);
      break;
    case "file":
      c = tb(e, o);
      break;
    case "template_literal":
      c = rb(e, r, i, o);
      break;
    case "lazy":
      c = nb(e, r, i, o);
      break;
    case "pipe":
      c = ib(e, r, i, o);
      break;
    case "custom":
      c = ob(e, r, i, o);
      break;
    case "transform":
      c = ub(e, r, i, o);
      break;
    case "catch":
      c = sb(e, r, i, o);
      break;
    default:
      throw new U(`schema type ${a}`);
  }
  return c === null ? null : h$(e, r, i, c);
}
s(J, "generateCheck");
function z$(e, r, i, o) {
  e.write(`if (typeof ${o} !== "string") return INVALID;`);
  let t = i._zod.def;
  return t.format === void 0 ? o : Sp(e, r, t, o);
}
s(z$, "generateStringCheck");
function S$(e, r, i) {
  e.write(`if (typeof ${i} !== "number" || !Number.isFinite(${i})) return INVALID;`);
  let o = r._zod.def;
  return o.check === "number_format" && o.format && zp(e, { format: o.format }, i), i;
}
s(S$, "generateNumberCheck");
function O$(e, r) {
  return e.write(`if (typeof ${r} !== "boolean") return INVALID;`), r;
}
s(O$, "generateBooleanCheck");
function j$(e, r, i) {
  e.write(`if (typeof ${i} !== "bigint") return INVALID;`);
  let o = r._zod.def;
  if (o.format)
    switch (o.format) {
      case "int64":
        e.write(`if (${i} < -9223372036854775808n || ${i} > 9223372036854775807n) return INVALID;`);
        break;
      case "uint64":
        e.write(`if (${i} < 0n || ${i} > 18446744073709551615n) return INVALID;`);
        break;
    }
  return i;
}
s(j$, "generateBigIntCheck");
function P$(e, r) {
  return e.write(`if (typeof ${r} !== "symbol") return INVALID;`), r;
}
s(P$, "generateSymbolCheck");
function D$(e, r) {
  return e.write(`if (${r} !== undefined) return INVALID;`), r;
}
s(D$, "generateUndefinedCheck");
function N$(e, r) {
  return e.write(`if (${r} !== null) return INVALID;`), r;
}
s(N$, "generateNullCheck");
function T$(e, r) {
  return e.write(`if (${r} !== undefined) return INVALID;`), r;
}
s(T$, "generateVoidCheck");
function A$(e, r) {
  return e.write(`if (typeof ${r} !== "number" || !Number.isNaN(${r})) return INVALID;`), r;
}
s(A$, "generateNaNCheck");
function U$(e, r) {
  return e.write(`if (!(${r} instanceof Date) || Number.isNaN(${r}.getTime())) return INVALID;`), r;
}
s(U$, "generateDateCheck");
function E$(e, r, i, o, t = !0) {
  let n = i._zod.def;
  e.write(`if (typeof ${o} !== "object" || ${o} === null || Array.isArray(${o})) return INVALID;`);
  let a = n.shape, u = Object.keys(a), c = Object.getOwnPropertySymbols(a), l = c.length ? [...u, ...c] : u, d = /* @__PURE__ */ s((O) => typeof O == "symbol" ? j(r, O) : ie(O), "keyExpr"), f = /* @__PURE__ */ s((O) => typeof O == "symbol" ? `[${d(O)}]` : ie(O), "propKey"), p = a;
  if (u.includes("__proto__"))
    throw new U('object shape key "__proto__"');
  let h = /* @__PURE__ */ new Map();
  for (let O of l) {
    let D = p[O], V = d(O), M = P(r);
    if (e.write(`const ${M} = ${o}[${V}];`), D._zod.optin !== void 0) {
      let E = P(r);
      e.write(`let ${E} = (() => {`), e.indented((Y) => {
        let dr = re(Y, r, D, M);
        Y.write(`return ${dr};`);
      }), e.write("})();"), D._zod.optout === "optional" ? (e.write(`if (${E} === INVALID) {`), e.indented((Y) => {
        Y.write(`if (${V} in ${o}) return INVALID;`), Y.write(`${E} = undefined;`);
      }), e.write("}")) : e.write(`if (${E} === INVALID) return INVALID;`), h.set(O, E);
    } else {
      R$(D) && e.write(`if (!(${V} in ${o})) return INVALID;`);
      let E = re(e, r, D, M, t);
      E !== null && h.set(O, E);
    }
  }
  let v = n.catchall, k = "none";
  if (v) {
    let O = v._zod.def.type;
    if (O === "never") {
      let D = u.map((V) => `k !== ${ie(V)}`).join(" && ") || "true";
      e.write(`for (const k in ${o}) {`), e.indented((V) => {
        V.write(`if (${D}) return INVALID;`);
      }), e.write("}");
    } else (O === "unknown" || O === "any") && !v._zod.def.checks?.length ? k = "passthrough" : k = "schema";
  }
  let z = P(r), Z = l.some((O) => dt(p[O]) || Ic(p[O]));
  if (!t) {
    if (k === "schema") {
      let O = u.length > 0 ? j(r, new Set(u)) : null;
      e.write(`for (const k in ${o}) {`), e.indented((D) => {
        D.write('if (k === "__proto__") continue;'), O && D.write(`if (${O}.has(k)) continue;`);
        let V = P(r);
        D.write(`const ${V} = ${o}[k];`), re(D, r, v, V, !1);
      }), e.write("}");
    }
    return null;
  }
  if (Z) {
    e.write(`const ${z} = {};`);
    for (let O of l) {
      let D = d(O), V = h.get(O);
      Ic(p[O]) ? e.write(`if (${D} in ${o}) ${z}[${D}] = ${V};`) : dt(p[O]) ? e.write(`if (${V} !== undefined || ${D} in ${o}) ${z}[${D}] = ${V};`) : e.write(`${z}[${D}] = ${V};`);
    }
  } else {
    let O = l.map((D) => `${f(D)}: ${h.get(D)}`).join(", ");
    e.write(`const ${z} = { ${O} };`);
  }
  if (k !== "none") {
    let O = u.length > 0 ? j(r, new Set(u)) : null;
    e.write(`for (const k in ${o}) {`), e.indented((D) => {
      if (D.write('if (k === "__proto__") continue;'), O && D.write(`if (${O}.has(k)) continue;`), k === "passthrough")
        D.write(`${z}[k] = ${o}[k];`);
      else {
        let V = P(r);
        D.write(`const ${V} = ${o}[k];`);
        let M = re(D, r, v, V);
        D.write(`${z}[k] = ${M};`);
      }
    }), e.write("}");
  }
  return z;
}
s(E$, "generateObjectCheck");
function C$(e, r, i, o, t = !0) {
  let n = i._zod.def;
  if (Z$(i))
    return J(e, r, n.innerType, o, t);
  if (n.innerType._zod.optin === "defaulted") {
    let u = P(r), c = P(r);
    return e.write(`let ${u};`), e.write(`if (${o} === undefined) {`), e.indented((l) => {
      l.write(`const ${c} = (() => {`), l.indented((d) => {
        let f = J(d, r, n.innerType, o);
        d.write(`return ${f};`);
      }), l.write("})();"), l.write(`if (${c} !== INVALID) ${u} = ${c};`);
    }), e.write("} else {"), e.indented((l) => {
      let d = J(l, r, n.innerType, o);
      l.write(`${u} = ${d};`);
    }), e.write("}"), u;
  }
  let a = t ? P(r) : null;
  return a && e.write(`let ${a};`), e.write(`if (${o} !== undefined) {`), e.indented((u) => {
    let c = J(u, r, n.innerType, o, t);
    a && c !== null && u.write(`${a} = ${c};`);
  }), e.write("}"), a;
}
s(C$, "generateOptionalCheck");
function Z$(e) {
  return e._zod.traits?.has("$ZodExactOptional") === !0;
}
s(Z$, "isExactOptional");
function R$(e) {
  return e._zod.optin === void 0 && lt(e);
}
s(R$, "requiresPresenceCheck");
function lt(e) {
  if (e._zod.def.coerce)
    return !0;
  let r = e._zod.def;
  switch (r.type) {
    case "any":
    case "unknown":
    case "undefined":
    case "void":
    case "default":
    case "prefault":
    case "transform":
    case "custom":
    case "lazy":
      return !0;
    case "string":
    case "number":
    case "boolean":
    case "bigint":
    case "symbol":
    case "null":
    case "never":
    case "nan":
    case "date":
    case "object":
    case "array":
    case "tuple":
    case "record":
    case "map":
    case "set":
    case "file":
    case "template_literal":
      return !1;
    case "nonoptional":
      return r.innerType ? lt(r.innerType) : !1;
    case "literal":
      return !!r.values?.includes(void 0);
    case "enum":
      return !!e._zod.values?.has(void 0);
    case "optional":
    case "nullable":
    case "readonly":
    case "success":
      return r.innerType ? lt(r.innerType) : !0;
    case "catch":
      return !0;
    case "union":
      return r.options ? r.options.some(lt) : !0;
    case "intersection":
      return !r.left || !r.right ? !0 : lt(r.left) && lt(r.right);
    case "pipe":
      return r.in ? lt(r.in) : !0;
    default:
      return !0;
  }
}
s(lt, "fastPathAcceptsAbsence");
function Ic(e) {
  return e._zod.optin === "optional" && e._zod.optout === "optional";
}
s(Ic, "dropsWhenAbsent");
function dt(e) {
  let r = e._zod.def;
  switch (r.type) {
    case "string":
    case "number":
    case "boolean":
    case "bigint":
    case "symbol":
    case "null":
    case "nan":
    case "date":
    case "object":
    case "array":
    case "tuple":
    case "record":
    case "map":
    case "set":
    case "file":
    case "template_literal":
    case "never":
    case "success":
      return !1;
    case "literal":
      return !!r.values?.includes(void 0);
    case "enum":
      return !!e._zod.values?.has(void 0);
    case "optional":
      return !0;
    case "nullable":
    case "readonly":
    case "nonoptional":
      return r.innerType ? dt(r.innerType) : !0;
    case "union":
      return r.options ? r.options.some(dt) : !0;
    case "intersection":
      return !r.left || !r.right || dt(r.left) || dt(r.right);
    case "pipe":
      return r.out ? dt(r.out) : !0;
    default:
      return !0;
  }
}
s(dt, "mayOutputUndefined");
function F$(e, r, i, o, t = !0) {
  let n = i._zod.def, a = t ? P(r) : null;
  return a && e.write(`let ${a} = null;`), e.write(`if (${o} !== null) {`), e.indented((u) => {
    let c = J(u, r, n.innerType, o, t);
    a && c !== null && u.write(`${a} = ${c};`);
  }), e.write("}"), a;
}
s(F$, "generateNullableCheck");
function L$(e, r, i, o, t = !0) {
  let n = i._zod.def;
  e.write(`if (!Array.isArray(${o})) return INVALID;`);
  let a = t ? P(r) : null, u = P(r), c = P(r);
  return a && e.write(`const ${a} = new Array(${o}.length);`), e.write(`for (let ${u} = 0; ${u} < ${o}.length; ${u}++) {`), e.indented((l) => {
    l.write(`const ${c} = ${o}[${u}];`);
    let d = re(l, r, n.element, c, t);
    a && d !== null && l.write(`${a}[${u}] = ${d};`);
  }), e.write("}"), a;
}
s(L$, "generateArrayCheck");
function V$(e, r, i, o) {
  let n = i._zod.def.values;
  if (n.length !== 1) {
    let u = j(r, new Set(n));
    return e.write(`if (!${u}.has(${o})) return INVALID;`), o;
  }
  let a = n[0];
  if (typeof a == "number" && Number.isNaN(a)) {
    let u = j(r, new Set(n));
    return e.write(`if (!${u}.has(${o})) return INVALID;`), o;
  }
  if (typeof a == "string")
    e.write(`if (${o} !== ${ie(a)}) return INVALID;`);
  else if (typeof a == "number" || typeof a == "boolean")
    e.write(`if (${o} !== ${a}) return INVALID;`);
  else if (a === null)
    e.write(`if (${o} !== null) return INVALID;`);
  else if (a === void 0)
    e.write(`if (${o} !== undefined) return INVALID;`);
  else if (typeof a == "bigint")
    e.write(`if (${o} !== ${a}n) return INVALID;`);
  else
    throw new U(`literal type ${typeof a}`);
  return o;
}
s(V$, "generateLiteralCheck");
function M$(e, r, i, o) {
  let t = i._zod.values;
  if (!t)
    throw new U("enum schema without enumerated values");
  let n = j(r, t);
  return e.write(`if (!${n}.has(${o})) return INVALID;`), o;
}
s(M$, "generateEnumCheck");
function wp(e, r, i, o) {
  let t = i._zod.def;
  return J(e, r, t.innerType, o);
}
s(wp, "generateWrapperCheck");
function B$(e, r, i, o) {
  let t = i._zod.def, a = Object.getOwnPropertyDescriptor(i._zod.def, "defaultValue") ? () => i._zod.def.defaultValue : void 0;
  if (i._zod.def.type === "prefault") {
    if (!a)
      return J(e, r, t.innerType, o);
    let c = j(r, a), l = P(r);
    return e.write(`let ${l} = ${o};`), e.write(`if (${o} === undefined) ${l} = ${c}();`), J(e, r, t.innerType, l);
  }
  let u = P(r);
  if (a) {
    let c = j(r, a), l = j(r, br);
    e.write(`let ${u};`), e.write(`if (${o} === undefined) {`), e.indented((d) => {
      d.write(`${u} = ${l}(${c}());`);
    }), e.write("} else {"), e.indented((d) => {
      let f = J(d, r, t.innerType, o);
      d.write(`${u} = ${f} === undefined ? ${l}(${c}()) : ${f};`);
    }), e.write("}");
  } else
    e.write(`let ${u};`), e.write(`if (${o} !== undefined) {`), e.indented((c) => {
      let l = J(c, r, t.innerType, o);
      c.write(`${u} = ${l};`);
    }), e.write("}");
  return u;
}
s(B$, "generateDefaultCheck");
function J$(e, r, i, o) {
  let t = i._zod.def, n = J(e, r, t.innerType, o), a = P(r);
  return e.write(`const ${a} = ${n};`), e.write(`if (${a} === undefined) return INVALID;`), a;
}
s(J$, "generateNonOptionalCheck");
function q$(e, r, i, o) {
  let t = i._zod.def, n = t.items, a = t.rest;
  e.write(`if (!Array.isArray(${o})) return INVALID;`);
  let u = kp(n, "optin"), c = kp(n, "optout");
  a ? e.write(`if (${o}.length < ${u}) return INVALID;`) : e.write(`if (${o}.length < ${u} || ${o}.length > ${n.length}) return INVALID;`);
  let l = P(r);
  e.write(`const ${l} = [];`);
  for (let d = 0; d < n.length; d++) {
    let f = n[d];
    if (d >= c)
      e.write(`if (${l}.length === ${d}) {`), e.indented((p) => {
        p.write(`if (${d} < ${o}.length) {`), p.indented((h) => {
          let v = P(r);
          h.write(`const ${v} = ${o}[${d}];`);
          let k = re(h, r, f, v);
          h.write(`${l}[${d}] = ${k};`);
        }), p.write("} else {"), p.indented((h) => {
          if (Ic(f)) {
            h.write(`${l}.length = ${d};`);
            return;
          }
          let v = P(r), k = P(r);
          h.write(`const ${v} = undefined;`), h.write(`const ${k} = (() => {`), h.indented((z) => {
            let Z = re(z, r, f, v);
            z.write(`return ${Z};`);
          }), h.write("})();"), h.write(`if (${k} === INVALID || ${k} === undefined) ${l}.length = ${d};`), h.write(`else ${l}[${d}] = ${k};`);
        }), p.write("}");
      }), e.write("}");
    else {
      let p = P(r);
      e.write(`const ${p} = ${o}[${d}];`);
      let h = re(e, r, f, p);
      e.write(`${l}[${d}] = ${h};`);
    }
  }
  if (a) {
    let d = P(r), f = P(r);
    e.write(`for (let ${d} = ${n.length}; ${d} < ${o}.length; ${d}++) {`), e.indented((p) => {
      p.write(`const ${f} = ${o}[${d}];`);
      let h = re(p, r, a, f);
      p.write(`${l}[${d}] = ${h};`);
    }), e.write("}");
  }
  return l;
}
s(q$, "generateTupleCheck");
function kp(e, r) {
  for (let i = e.length - 1; i >= 0; i--)
    if (!(r === "optin" ? e[i]._zod.optin !== void 0 : e[i]._zod.optout === "optional"))
      return i + 1;
  return 0;
}
s(kp, "getTupleOptStart");
function K$(e, r, i, o) {
  let t = i._zod.def, n = t.options;
  if (t.discriminator)
    return W$(e, r, t, o);
  if (t.inclusive === !1)
    throw new U("exclusive unions (z.xor)");
  if (n.length === 0)
    return e.write("return INVALID;"), o;
  if (n.length === 1)
    return J(e, r, n[0], o);
  if (n.every((c) => c._zod.def.type === "literal" && !c._zod.def.checks?.length)) {
    let c = new Set(n.flatMap((d) => d._zod.def.values)), l = j(r, c);
    return e.write(`if (!${l}.has(${o})) return INVALID;`), o;
  }
  let u = P(r);
  e.write(`let ${u};`);
  for (let c = 0; c < n.length; c++) {
    let l = n[c];
    c === 0 ? e.write(`${u} = (() => {`) : e.write(`if (${u} === INVALID) ${u} = (() => {`), e.indented((d) => {
      let f = J(d, r, l, o);
      d.write(`return ${f};`);
    }), e.write("})();");
  }
  return e.write(`if (${u} === INVALID) return INVALID;`), u;
}
s(K$, "generateUnionCheck");
function W$(e, r, i, o) {
  if (i.unionFallback)
    throw new U("discriminated union with unionFallback");
  if (i.options.length === 0)
    return e.write("return INVALID;"), o;
  let t = P(r), n = P(r);
  e.write(`const ${t} = ${o}?.[${ie(i.discriminator)}];`), e.write(`let ${n};`);
  let a = !0, u = /* @__PURE__ */ new Set();
  for (let c of i.options) {
    let l = c._zod.propValues?.[i.discriminator];
    if (!l || l.size === 0)
      throw new U("discriminated union option without static discriminator values");
    for (let p of l) {
      if (u.has(p))
        throw new U(`duplicate discriminator value ${String(p)}`);
      u.add(p);
    }
    let d = Array.from(l, (p) => G$(r, t, p)), f = a ? "if" : "else if";
    e.write(`${f} (${d.join(" || ")}) {`), e.indented((p) => {
      let h = J(p, r, c, o);
      p.write(`${n} = ${h};`);
    }), e.write("}"), a = !1;
  }
  return e.write("else { return INVALID; }"), n;
}
s(W$, "generateDiscriminatedUnionCheck");
function G$(e, r, i) {
  if (typeof i == "string")
    return `${r} === ${ie(i)}`;
  if (typeof i == "number")
    return Number.isNaN(i) ? `Number.isNaN(${r})` : `${r} === ${i}`;
  if (typeof i == "boolean")
    return `${r} === ${i}`;
  if (i === null)
    return `${r} === null`;
  if (i === void 0)
    return `${r} === undefined`;
  if (typeof i == "bigint")
    return `${r} === ${i}n`;
  if (typeof i == "symbol") {
    let o = j(e, i);
    return `${r} === ${o}`;
  }
  throw new U(`literal discriminator value ${String(i)}`);
}
s(G$, "literalEquality");
function X$(e, r, i, o) {
  let t = i._zod.def, n = re(e, r, t.left, o), a = re(e, r, t.right, o), u = j(r, Tt), c = P(r);
  return e.write(`const ${c} = ${u}(${n}, ${a});`), e.write(`if (!${c}.valid) return INVALID;`), `${c}.data`;
}
s(X$, "generateIntersectionCheck");
function H$(e, r, i, o) {
  let t = i._zod.def, n = j(r, ve);
  e.write(`if (!${n}(${o})) return INVALID;`);
  let a = P(r), u = P(r), c = P(r);
  e.write(`const ${a} = {};`);
  let l = t, d = l.partial ? void 0 : t.keyType._zod.values;
  if (d) {
    let v = [];
    for (let z of d) {
      if (!(typeof z == "string" || typeof z == "number" || typeof z == "symbol"))
        throw new U(`record key value ${String(z)}`);
      let Z = typeof z == "number" ? z.toString() : z;
      if (Z === "__proto__")
        throw new U('record key "__proto__"');
      v.push(Z);
      let O = j(r, z), D = J(e, r, t.keyType, O), V = P(r);
      e.write(`const ${V} = ${o}[${Q$(r, Z)}];`);
      let M = re(e, r, t.valueType, V);
      e.write(`${a}[${D}] = ${M};`);
    }
    let k = j(r, new Set(v));
    return e.write(`for (const ${u} in ${o}) {`), e.indented((z) => {
      z.write(`if (${k}.has(${u})) continue;`), l.mode === "loose" ? z.write(`if (${u} !== "__proto__") ${a}[${u}] = ${o}[${u}];`) : z.write("return INVALID;");
    }), e.write("}"), a;
  }
  let f = t.keyType._zod.def;
  if (!(f.type === "string" && f.format === void 0 && !f.coerce && (f.checks?.length ?? 0) === 0)) {
    let v = t.mode === "loose", k = j(r, mi(t.keyType)), z = j(r, Ze), Z = j(r, Object.prototype.propertyIsEnumerable), O = P(r);
    return e.write(`for (const ${u} of Reflect.ownKeys(${o})) {`), e.indented((D) => {
      D.write(`if (${u} === "__proto__") continue;`), D.write(`if (!${Z}.call(${o}, ${u})) continue;`), D.write(`let ${O} = ${k}(${u});`), D.write(`if (${O} === INVALID && typeof ${u} === "string" && ${z}.test(${u})) ${O} = ${k}(Number(${u}));`), v ? D.write(`if (${O} === INVALID) { ${a}[${u}] = ${o}[${u}]; continue; }`) : D.write(`if (${O} === INVALID) return INVALID;`), D.write(`if (${O} === "__proto__") continue;`);
      let V = P(r);
      D.write(`const ${V} = ${o}[${u}];`);
      let M = re(D, r, t.valueType, V);
      D.write(`${a}[${O}] = ${M};`);
    }), e.write("}"), a;
  }
  let h = j(r, Object.prototype.propertyIsEnumerable);
  return e.write(`for (const ${u} of Reflect.ownKeys(${o})) {`), e.indented((v) => {
    v.write(`if (${u} === "__proto__") continue;`), v.write(`if (!${h}.call(${o}, ${u})) continue;`), v.write(`if (typeof ${u} !== "string") return INVALID;`), v.write(`const ${c} = ${o}[${u}];`);
    let k = re(v, r, t.valueType, c);
    v.write(`${a}[${u}] = ${k};`);
  }), e.write("}"), a;
}
s(H$, "generateRecordCheck");
function Q$(e, r) {
  return typeof r == "string" ? ie(r) : j(e, r);
}
s(Q$, "literalPropertyKey");
function Y$(e, r, i, o) {
  let t = i._zod.def;
  e.write(`if (!(${o} instanceof Map)) return INVALID;`);
  let n = P(r), a = P(r), u = P(r);
  return e.write(`const ${n} = new Map();`), e.write(`for (const [${a}, ${u}] of ${o}) {`), e.indented((c) => {
    let l = J(c, r, t.keyType, a), d = J(c, r, t.valueType, u);
    c.write(`${n}.set(${l}, ${d});`);
  }), e.write("}"), n;
}
s(Y$, "generateMapCheck");
function eb(e, r, i, o) {
  let t = i._zod.def;
  e.write(`if (!(${o} instanceof Set)) return INVALID;`);
  let n = P(r), a = P(r);
  return e.write(`const ${n} = new Set();`), e.write(`for (const ${a} of ${o}) {`), e.indented((u) => {
    let c = J(u, r, t.valueType, a);
    u.write(`${n}.add(${c});`);
  }), e.write("}"), n;
}
s(eb, "generateSetCheck");
function tb(e, r) {
  return e.write(`if (!(${r} instanceof File)) return INVALID;`), r;
}
s(tb, "generateFileCheck");
function rb(e, r, i, o) {
  e.write(`if (typeof ${o} !== "string") return INVALID;`);
  let t = i._zod.pattern;
  if (t) {
    let n = j(r, t);
    e.write(`${n}.lastIndex = 0;`), e.write(`if (!${n}.test(${o})) return INVALID;`);
  }
  return o;
}
s(rb, "generateTemplateLiteralCheck");
function nb(e, r, i, o) {
  let t = i._zod.def, n = j(r, t.getter), a = j(r, { parser: null });
  e.write(`if (!${a}.parser) {`), e.indented((c) => {
    c.write(`const inner = ${n}();`), c.write(`${a}.parser = function(input) {`), c.indented((l) => {
      l.write("const result = inner._zod.run({ value: input, issues: [] }, {});"), l.write("return result.issues.length === 0 ? result.value : INVALID;");
    }), c.write("};");
  }), e.write("}");
  let u = P(r);
  return e.write(`const ${u} = ${a}.parser(${o});`), e.write(`if (${u} === INVALID) return INVALID;`), u;
}
s(nb, "generateLazyCheck");
function ib(e, r, i, o) {
  let t = i._zod.def, n = J(e, r, t.in, o);
  if (t.transform) {
    if (ft(t.transform))
      throw new be("z.compile: async transforms in pipes are not supported");
    let a = t.transform, c = j(r, /* @__PURE__ */ s((d) => {
      let f = { value: d, issues: [], addIssue: Sc }, p = a(d, f);
      return p instanceof Promise ? pe : f.issues.length === 0 ? p : pe;
    }, "helperFn")), l = P(r);
    return e.write(`const ${l} = ${c}(${n});`), e.write(`if (${l} === INVALID) return INVALID;`), J(e, r, t.out, l);
  } else
    return J(e, r, t.out, n);
}
s(ib, "generatePipeCheck");
function ft(e) {
  return typeof e == "function" && (e.constructor.name === "AsyncFunction" || e[Symbol.toStringTag] === "AsyncFunction");
}
s(ft, "isAsyncFunction");
function ob(e, r, i, o) {
  let t = i._zod.def;
  if (t.fn) {
    if (ft(t.fn))
      throw new be("z.compile: async custom predicates are not supported");
    let n = j(r, t.fn), a = j(r, kc), u = P(r);
    e.write(`const ${u} = ${n}(${o});`), e.write(`if (${u} instanceof Promise) ${a}();`), e.write(`if (!${u}) return INVALID;`);
  } else
    throw new U("custom schema without a predicate function");
  return o;
}
s(ob, "generateCustomCheck");
function ab(e, r, i) {
  let o = e._zod.run({ value: i, issues: [] }, {});
  if (o && typeof o.then == "function")
    return pe;
  let t = o;
  return t.issues.length === 0 ? t.value : r();
}
s(ab, "runtimeCatch");
function sb(e, r, i, o) {
  let t = i._zod.def;
  if (!t.catchValue[On])
    throw new U("catch with a callback (only a constant catch value compiles)", !1);
  let n = P(r);
  e.write(`let ${n} = (() => {`), e.indented((l) => {
    let d = re(l, r, t.innerType, o);
    l.write(`return ${d};`);
  }), e.write("})();");
  let a = j(r, t.innerType), u = j(r, t.catchValue), c = j(r, ab);
  return e.write(`if (${n} === INVALID) {`), e.indented((l) => {
    l.write(`${n} = ${c}(${a}, ${u}, ${o});`), l.write(`if (${n} === INVALID) return INVALID;`);
  }), e.write("}"), n;
}
s(sb, "generateCatchCheck");
function ub(e, r, i, o) {
  let t = i._zod.def;
  if (t.transform) {
    if (ft(t.transform))
      throw new be("z.compile: async transforms are not supported");
    let n = t.transform, u = j(r, /* @__PURE__ */ s((l) => {
      let d = { value: l, issues: [], addIssue: Sc }, f = n(l, d);
      return f instanceof Promise ? pe : d.issues.length === 0 ? f : pe;
    }, "helperFn")), c = P(r);
    return e.write(`const ${c} = ${u}(${o});`), e.write(`if (${c} === INVALID) return INVALID;`), c;
  }
  return o;
}
s(ub, "generateTransformCheck");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/api.js
// @__NO_SIDE_EFFECTS__
function Oc(e, r) {
  return new e({
    type: "string",
    ...w(r)
  });
}
s(Oc, "_string");
// @__NO_SIDE_EFFECTS__
function jc(e, r) {
  return new e({
    type: "string",
    coerce: !0,
    ...w(r)
  });
}
s(jc, "_coercedString");
// @__NO_SIDE_EFFECTS__
function gi(e, r) {
  return new e({
    type: "string",
    format: "email",
    check: "string_format",
    abort: !1,
    ...w(r)
  });
}
s(gi, "_email");
// @__NO_SIDE_EFFECTS__
function hi(e, r) {
  return new e({
    type: "string",
    format: "guid",
    check: "string_format",
    abort: !1,
    ...w(r)
  });
}
s(hi, "_guid");
// @__NO_SIDE_EFFECTS__
function vi(e, r) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    ...w(r)
  });
}
s(vi, "_uuid");
// @__NO_SIDE_EFFECTS__
function yi(e, r) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v4",
    ...w(r)
  });
}
s(yi, "_uuidv4");
// @__NO_SIDE_EFFECTS__
function $i(e, r) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v6",
    ...w(r)
  });
}
s($i, "_uuidv6");
// @__NO_SIDE_EFFECTS__
function bi(e, r) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v7",
    ...w(r)
  });
}
s(bi, "_uuidv7");
// @__NO_SIDE_EFFECTS__
function Fr(e, r) {
  return new e({
    type: "string",
    format: "url",
    check: "string_format",
    abort: !1,
    ...w(r)
  });
}
s(Fr, "_url");
// @__NO_SIDE_EFFECTS__
function _i(e, r) {
  return new e({
    type: "string",
    format: "emoji",
    check: "string_format",
    abort: !1,
    ...w(r)
  });
}
s(_i, "_emoji");
// @__NO_SIDE_EFFECTS__
function xi(e, r) {
  return new e({
    type: "string",
    format: "nanoid",
    check: "string_format",
    abort: !1,
    ...w(r)
  });
}
s(xi, "_nanoid");
// @__NO_SIDE_EFFECTS__
function wi(e, r) {
  return new e({
    type: "string",
    format: "cuid",
    check: "string_format",
    abort: !1,
    ...w(r)
  });
}
s(wi, "_cuid");
// @__NO_SIDE_EFFECTS__
function ki(e, r) {
  return new e({
    type: "string",
    format: "cuid2",
    check: "string_format",
    abort: !1,
    ...w(r)
  });
}
s(ki, "_cuid2");
// @__NO_SIDE_EFFECTS__
function Ii(e, r) {
  return new e({
    type: "string",
    format: "ulid",
    check: "string_format",
    abort: !1,
    ...w(r)
  });
}
s(Ii, "_ulid");
// @__NO_SIDE_EFFECTS__
function zi(e, r) {
  return new e({
    type: "string",
    format: "xid",
    check: "string_format",
    abort: !1,
    ...w(r)
  });
}
s(zi, "_xid");
// @__NO_SIDE_EFFECTS__
function Si(e, r) {
  return new e({
    type: "string",
    format: "ksuid",
    check: "string_format",
    abort: !1,
    ...w(r)
  });
}
s(Si, "_ksuid");
// @__NO_SIDE_EFFECTS__
function Oi(e, r) {
  return new e({
    type: "string",
    format: "ipv4",
    check: "string_format",
    abort: !1,
    ...w(r)
  });
}
s(Oi, "_ipv4");
// @__NO_SIDE_EFFECTS__
function ji(e, r) {
  return new e({
    type: "string",
    format: "ipv6",
    check: "string_format",
    abort: !1,
    ...w(r)
  });
}
s(ji, "_ipv6");
// @__NO_SIDE_EFFECTS__
function Pc(e, r) {
  return new e({
    type: "string",
    format: "mac",
    check: "string_format",
    abort: !1,
    ...w(r)
  });
}
s(Pc, "_mac");
// @__NO_SIDE_EFFECTS__
function Pi(e, r) {
  return new e({
    type: "string",
    format: "cidrv4",
    check: "string_format",
    abort: !1,
    ...w(r)
  });
}
s(Pi, "_cidrv4");
// @__NO_SIDE_EFFECTS__
function Di(e, r) {
  return new e({
    type: "string",
    format: "cidrv6",
    check: "string_format",
    abort: !1,
    ...w(r)
  });
}
s(Di, "_cidrv6");
// @__NO_SIDE_EFFECTS__
function Ni(e, r) {
  return new e({
    type: "string",
    format: "base64",
    check: "string_format",
    abort: !1,
    ...w(r)
  });
}
s(Ni, "_base64");
// @__NO_SIDE_EFFECTS__
function Ti(e, r) {
  return new e({
    type: "string",
    format: "base64url",
    check: "string_format",
    abort: !1,
    ...w(r)
  });
}
s(Ti, "_base64url");
// @__NO_SIDE_EFFECTS__
function Ai(e, r) {
  return new e({
    type: "string",
    format: "e164",
    check: "string_format",
    abort: !1,
    ...w(r)
  });
}
s(Ai, "_e164");
// @__NO_SIDE_EFFECTS__
function Dc(e, r) {
  return new e({
    type: "string",
    format: "credit_card",
    check: "string_format",
    abort: !1,
    ...w(r)
  });
}
s(Dc, "_creditCard");
// @__NO_SIDE_EFFECTS__
function Ui(e, r) {
  return new e({
    type: "string",
    format: "jwt",
    check: "string_format",
    abort: !1,
    ...w(r)
  });
}
s(Ui, "_jwt");
var Nc = {
  Any: null,
  Minute: -1,
  Second: 0,
  Millisecond: 3,
  Microsecond: 6
};
// @__NO_SIDE_EFFECTS__
function Lr(e, r) {
  return new e({
    type: "string",
    format: "datetime",
    check: "string_format",
    offset: !1,
    local: !1,
    precision: null,
    ...w(r)
  });
}
s(Lr, "_isoDateTime");
// @__NO_SIDE_EFFECTS__
function Vr(e, r) {
  return new e({
    type: "string",
    format: "date",
    check: "string_format",
    ...w(r)
  });
}
s(Vr, "_isoDate");
// @__NO_SIDE_EFFECTS__
function Mr(e, r) {
  return new e({
    type: "string",
    format: "time",
    check: "string_format",
    precision: null,
    ...w(r)
  });
}
s(Mr, "_isoTime");
// @__NO_SIDE_EFFECTS__
function Br(e, r) {
  return new e({
    type: "string",
    format: "duration",
    check: "string_format",
    ...w(r)
  });
}
s(Br, "_isoDuration");
// @__NO_SIDE_EFFECTS__
function Tc(e, r) {
  return new e({
    type: "number",
    checks: [],
    ...w(r)
  });
}
s(Tc, "_number");
// @__NO_SIDE_EFFECTS__
function Ac(e, r) {
  return new e({
    type: "number",
    coerce: !0,
    checks: [],
    ...w(r)
  });
}
s(Ac, "_coercedNumber");
// @__NO_SIDE_EFFECTS__
function Uc(e, r) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "safeint",
    ...w(r)
  });
}
s(Uc, "_int");
// @__NO_SIDE_EFFECTS__
function Ec(e, r) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "float32",
    ...w(r)
  });
}
s(Ec, "_float32");
// @__NO_SIDE_EFFECTS__
function Cc(e, r) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "float64",
    ...w(r)
  });
}
s(Cc, "_float64");
// @__NO_SIDE_EFFECTS__
function Zc(e, r) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "int32",
    ...w(r)
  });
}
s(Zc, "_int32");
// @__NO_SIDE_EFFECTS__
function Rc(e, r) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "uint32",
    ...w(r)
  });
}
s(Rc, "_uint32");
// @__NO_SIDE_EFFECTS__
function Fc(e, r) {
  return new e({
    type: "boolean",
    ...w(r)
  });
}
s(Fc, "_boolean");
// @__NO_SIDE_EFFECTS__
function Lc(e, r) {
  return new e({
    type: "boolean",
    coerce: !0,
    ...w(r)
  });
}
s(Lc, "_coercedBoolean");
// @__NO_SIDE_EFFECTS__
function Vc(e, r) {
  return new e({
    type: "bigint",
    ...w(r)
  });
}
s(Vc, "_bigint");
// @__NO_SIDE_EFFECTS__
function Mc(e, r) {
  return new e({
    type: "bigint",
    coerce: !0,
    ...w(r)
  });
}
s(Mc, "_coercedBigint");
// @__NO_SIDE_EFFECTS__
function Bc(e, r) {
  return new e({
    type: "bigint",
    check: "bigint_format",
    abort: !1,
    format: "int64",
    ...w(r)
  });
}
s(Bc, "_int64");
// @__NO_SIDE_EFFECTS__
function Jc(e, r) {
  return new e({
    type: "bigint",
    check: "bigint_format",
    abort: !1,
    format: "uint64",
    ...w(r)
  });
}
s(Jc, "_uint64");
// @__NO_SIDE_EFFECTS__
function qc(e, r) {
  return new e({
    type: "symbol",
    ...w(r)
  });
}
s(qc, "_symbol");
// @__NO_SIDE_EFFECTS__
function Kc(e, r) {
  return new e({
    type: "undefined",
    ...w(r)
  });
}
s(Kc, "_undefined");
// @__NO_SIDE_EFFECTS__
function Wc(e, r) {
  return new e({
    type: "null",
    ...w(r)
  });
}
s(Wc, "_null");
// @__NO_SIDE_EFFECTS__
function Gc(e) {
  return new e({
    type: "any"
  });
}
s(Gc, "_any");
// @__NO_SIDE_EFFECTS__
function Xc(e) {
  return new e({
    type: "unknown"
  });
}
s(Xc, "_unknown");
// @__NO_SIDE_EFFECTS__
function Hc(e, r) {
  return new e({
    type: "never",
    ...w(r)
  });
}
s(Hc, "_never");
// @__NO_SIDE_EFFECTS__
function Qc(e, r) {
  return new e({
    type: "void",
    ...w(r)
  });
}
s(Qc, "_void");
// @__NO_SIDE_EFFECTS__
function Yc(e, r) {
  return new e({
    type: "date",
    ...w(r)
  });
}
s(Yc, "_date");
// @__NO_SIDE_EFFECTS__
function el(e, r) {
  return new e({
    type: "date",
    coerce: !0,
    ...w(r)
  });
}
s(el, "_coercedDate");
// @__NO_SIDE_EFFECTS__
function tl(e, r) {
  return new e({
    type: "nan",
    ...w(r)
  });
}
s(tl, "_nan");
// @__NO_SIDE_EFFECTS__
function Ie(e, r) {
  return new Vn({
    check: "less_than",
    ...w(r),
    value: e,
    inclusive: !1
  });
}
s(Ie, "_lt");
// @__NO_SIDE_EFFECTS__
function me(e, r) {
  return new Vn({
    check: "less_than",
    ...w(r),
    value: e,
    inclusive: !0
  });
}
s(me, "_lte");
// @__NO_SIDE_EFFECTS__
function ze(e, r) {
  return new Mn({
    check: "greater_than",
    ...w(r),
    value: e,
    inclusive: !1
  });
}
s(ze, "_gt");
// @__NO_SIDE_EFFECTS__
function ge(e, r) {
  return new Mn({
    check: "greater_than",
    ...w(r),
    value: e,
    inclusive: !0
  });
}
s(ge, "_gte");
// @__NO_SIDE_EFFECTS__
function Ei(e) {
  return /* @__PURE__ */ ze(0, e);
}
s(Ei, "_positive");
// @__NO_SIDE_EFFECTS__
function Ci(e) {
  return /* @__PURE__ */ Ie(0, e);
}
s(Ci, "_negative");
// @__NO_SIDE_EFFECTS__
function Zi(e) {
  return /* @__PURE__ */ me(0, e);
}
s(Zi, "_nonpositive");
// @__NO_SIDE_EFFECTS__
function Ri(e) {
  return /* @__PURE__ */ ge(0, e);
}
s(Ri, "_nonnegative");
// @__NO_SIDE_EFFECTS__
function Ve(e, r) {
  return new Ja({
    check: "multiple_of",
    ...w(r),
    value: e
  });
}
s(Ve, "_multipleOf");
// @__NO_SIDE_EFFECTS__
function Me(e, r) {
  return new Wa({
    check: "max_size",
    ...w(r),
    maximum: e
  });
}
s(Me, "_maxSize");
// @__NO_SIDE_EFFECTS__
function Se(e, r) {
  return new Ga({
    check: "min_size",
    ...w(r),
    minimum: e
  });
}
s(Se, "_minSize");
// @__NO_SIDE_EFFECTS__
function pt(e, r) {
  return new Xa({
    check: "size_equals",
    ...w(r),
    size: e
  });
}
s(pt, "_size");
// @__NO_SIDE_EFFECTS__
function mt(e, r) {
  return new Ha({
    check: "max_length",
    ...w(r),
    maximum: e
  });
}
s(mt, "_maxLength");
// @__NO_SIDE_EFFECTS__
function Te(e, r) {
  return new Qa({
    check: "min_length",
    ...w(r),
    minimum: e
  });
}
s(Te, "_minLength");
// @__NO_SIDE_EFFECTS__
function gt(e, r) {
  return new Ya({
    check: "length_equals",
    ...w(r),
    length: e
  });
}
s(gt, "_length");
// @__NO_SIDE_EFFECTS__
function Rt(e, r) {
  return new es({
    check: "string_format",
    format: "regex",
    ...w(r),
    pattern: e
  });
}
s(Rt, "_regex");
// @__NO_SIDE_EFFECTS__
function Ft(e) {
  return new ts({
    check: "string_format",
    format: "lowercase",
    ...w(e)
  });
}
s(Ft, "_lowercase");
// @__NO_SIDE_EFFECTS__
function Lt(e) {
  return new rs({
    check: "string_format",
    format: "uppercase",
    ...w(e)
  });
}
s(Lt, "_uppercase");
// @__NO_SIDE_EFFECTS__
function Vt(e, r) {
  return new ns({
    check: "string_format",
    format: "includes",
    ...w(r),
    includes: e
  });
}
s(Vt, "_includes");
// @__NO_SIDE_EFFECTS__
function Mt(e, r) {
  return new is({
    check: "string_format",
    format: "starts_with",
    ...w(r),
    prefix: e
  });
}
s(Mt, "_startsWith");
// @__NO_SIDE_EFFECTS__
function Bt(e, r) {
  return new os({
    check: "string_format",
    format: "ends_with",
    ...w(r),
    suffix: e
  });
}
s(Bt, "_endsWith");
// @__NO_SIDE_EFFECTS__
function Fi(e, r, i) {
  return new Bn({
    check: "property",
    property: e,
    schema: r,
    ...w(i)
  });
}
s(Fi, "_property");
// @__NO_SIDE_EFFECTS__
function Li(e) {
  return Object.entries(e).map(([r, i]) => new Bn({ check: "property", property: r, schema: i }));
}
s(Li, "_properties");
// @__NO_SIDE_EFFECTS__
function Jt(e, r) {
  return new as({
    check: "mime_type",
    mime: e,
    ...w(r)
  });
}
s(Jt, "_mime");
// @__NO_SIDE_EFFECTS__
function _e(e) {
  return new ss({
    check: "overwrite",
    tx: e
  });
}
s(_e, "_overwrite");
// @__NO_SIDE_EFFECTS__
function qt(e) {
  return /* @__PURE__ */ _e((r) => r.normalize(e));
}
s(qt, "_normalize");
// @__NO_SIDE_EFFECTS__
function Kt() {
  return /* @__PURE__ */ _e((e) => e.trim());
}
s(Kt, "_trim");
// @__NO_SIDE_EFFECTS__
function Wt() {
  return /* @__PURE__ */ _e((e) => e.toLowerCase());
}
s(Wt, "_toLowerCase");
// @__NO_SIDE_EFFECTS__
function Gt() {
  return /* @__PURE__ */ _e((e) => e.toUpperCase());
}
s(Gt, "_toUpperCase");
// @__NO_SIDE_EFFECTS__
function Xt() {
  return /* @__PURE__ */ _e((e) => qo(e));
}
s(Xt, "_slugify");
// @__NO_SIDE_EFFECTS__
function rl(e, r, i) {
  return new e({
    type: "array",
    element: r,
    // get element() {
    //   return element;
    // },
    ...w(i)
  });
}
s(rl, "_array");
// @__NO_SIDE_EFFECTS__
function cb(e, r, i) {
  return new e({
    type: "union",
    options: r,
    ...w(i)
  });
}
s(cb, "_union");
function lb(e, r, i) {
  return new e({
    type: "union",
    options: r,
    inclusive: !1,
    ...w(i)
  });
}
s(lb, "_xor");
// @__NO_SIDE_EFFECTS__
function db(e, r, i, o) {
  return new e({
    type: "union",
    options: i,
    discriminator: r,
    ...w(o)
  });
}
s(db, "_discriminatedUnion");
// @__NO_SIDE_EFFECTS__
function fb(e, r, i) {
  return new e({
    type: "intersection",
    left: r,
    right: i
  });
}
s(fb, "_intersection");
// @__NO_SIDE_EFFECTS__
function pb(e, r, i, o) {
  let t = i instanceof S, n = t ? o : i, a = t ? i : null;
  return new e({
    type: "tuple",
    items: r,
    rest: a,
    ...w(n)
  });
}
s(pb, "_tuple");
// @__NO_SIDE_EFFECTS__
function mb(e, r, i, o) {
  return new e({
    type: "record",
    keyType: r,
    valueType: i,
    ...w(o)
  });
}
s(mb, "_record");
// @__NO_SIDE_EFFECTS__
function gb(e, r, i, o) {
  return new e({
    type: "map",
    keyType: r,
    valueType: i,
    ...w(o)
  });
}
s(gb, "_map");
// @__NO_SIDE_EFFECTS__
function hb(e, r, i) {
  return new e({
    type: "set",
    valueType: r,
    ...w(i)
  });
}
s(hb, "_set");
// @__NO_SIDE_EFFECTS__
function vb(e, r, i) {
  let o = Array.isArray(r) ? Object.fromEntries(r.map((t) => [t, t])) : r;
  return new e({
    type: "enum",
    entries: o,
    ...w(i)
  });
}
s(vb, "_enum");
// @__NO_SIDE_EFFECTS__
function yb(e, r, i) {
  return new e({
    type: "enum",
    entries: r,
    ...w(i)
  });
}
s(yb, "_nativeEnum");
// @__NO_SIDE_EFFECTS__
function $b(e, r, i) {
  return new e({
    type: "literal",
    values: Array.isArray(r) ? r : [r],
    ...w(i)
  });
}
s($b, "_literal");
// @__NO_SIDE_EFFECTS__
function nl(e, r) {
  return new e({
    type: "file",
    ...w(r)
  });
}
s(nl, "_file");
// @__NO_SIDE_EFFECTS__
function bb(e, r) {
  return new e({
    type: "transform",
    transform: r
  });
}
s(bb, "_transform");
// @__NO_SIDE_EFFECTS__
function _b(e, r) {
  return new e({
    type: "optional",
    innerType: r
  });
}
s(_b, "_optional");
// @__NO_SIDE_EFFECTS__
function xb(e, r) {
  return new e({
    type: "nullable",
    innerType: r
  });
}
s(xb, "_nullable");
// @__NO_SIDE_EFFECTS__
function wb(e, r, i) {
  return new e({
    type: "default",
    innerType: r,
    get defaultValue() {
      return typeof i == "function" ? i() : br(i);
    }
  });
}
s(wb, "_default");
// @__NO_SIDE_EFFECTS__
function kb(e, r, i) {
  return new e({
    type: "nonoptional",
    innerType: r,
    ...w(i)
  });
}
s(kb, "_nonoptional");
// @__NO_SIDE_EFFECTS__
function Ib(e, r) {
  return new e({
    type: "success",
    innerType: r
  });
}
s(Ib, "_success");
// @__NO_SIDE_EFFECTS__
function zb(e, r, i) {
  return new e({
    type: "catch",
    innerType: r,
    catchValue: typeof i == "function" ? i : ta(i)
  });
}
s(zb, "_catch");
// @__NO_SIDE_EFFECTS__
function Sb(e, r, i) {
  return new e({
    type: "pipe",
    in: r,
    out: i
  });
}
s(Sb, "_pipe");
// @__NO_SIDE_EFFECTS__
function Ob(e, r) {
  return new e({
    type: "readonly",
    innerType: r
  });
}
s(Ob, "_readonly");
// @__NO_SIDE_EFFECTS__
function jb(e, r, i) {
  return new e({
    type: "template_literal",
    parts: r,
    ...w(i)
  });
}
s(jb, "_templateLiteral");
// @__NO_SIDE_EFFECTS__
function Pb(e, r) {
  return new e({
    type: "lazy",
    getter: r
  });
}
s(Pb, "_lazy");
// @__NO_SIDE_EFFECTS__
function Db(e, r) {
  return new e({
    type: "promise",
    innerType: r
  });
}
s(Db, "_promise");
// @__NO_SIDE_EFFECTS__
function il(e, r, i) {
  let o = w(i);
  return o.abort ?? (o.abort = !0), new e({
    type: "custom",
    check: "custom",
    fn: r,
    ...o
  });
}
s(il, "_custom");
// @__NO_SIDE_EFFECTS__
function ol(e, r, i) {
  return new e({
    type: "custom",
    check: "custom",
    fn: r,
    ...w(i)
  });
}
s(ol, "_refine");
// @__NO_SIDE_EFFECTS__
function al(e, r) {
  let i = /* @__PURE__ */ Op((o) => (o.addIssue = (t) => {
    if (typeof t == "string")
      o.issues.push(St(t, o.value, i._zod.def));
    else {
      let n = t;
      n.fatal && (n.continue = !1), n.code ?? (n.code = "custom"), "input" in n || (n.input = o.value), n.inst ?? (n.inst = i), n.continue ?? (n.continue = !i._zod.def.abort), o.issues.push(St(n));
    }
  }, e(o.value, o)), r);
  return i;
}
s(al, "_superRefine");
// @__NO_SIDE_EFFECTS__
function Op(e, r) {
  let i = new L({
    check: "custom",
    ...w(r)
  });
  return i._zod.check = e, i;
}
s(Op, "_check");
// @__NO_SIDE_EFFECTS__
function sl(e) {
  let r = new L({ check: "describe" });
  return r._zod.onattach = [
    (i) => {
      let o = H.get(i) ?? {};
      H.add(i, { ...o, description: e });
    }
  ], r._zod.check = () => {
  }, r;
}
s(sl, "describe");
// @__NO_SIDE_EFFECTS__
function ul(e) {
  let r = new L({ check: "meta" });
  return r._zod.onattach = [
    (i) => {
      let o = H.get(i) ?? {};
      H.add(i, { ...o, ...e });
    }
  ], r._zod.check = () => {
  }, r;
}
s(ul, "meta");
// @__NO_SIDE_EFFECTS__
function cl(e, r) {
  let i = w(r), o = i.truthy ?? ["true", "1", "yes", "on", "y", "enabled"], t = i.falsy ?? ["false", "0", "no", "off", "n", "disabled"];
  i.case !== "sensitive" && (o = o.map((h) => typeof h == "string" ? h.toLowerCase() : h), t = t.map((h) => typeof h == "string" ? h.toLowerCase() : h));
  let n = new Set(o), a = new Set(t), u = e.Codec ?? Fe, c = e.Boolean ?? Nr, l = e.String ?? st, d = new l({ type: "string", error: i.error }), f = new c({ type: "boolean", error: i.error }), p = new u({
    type: "pipe",
    in: d,
    out: f,
    transform: /* @__PURE__ */ s(((h, v) => {
      let k = h;
      return i.case !== "sensitive" && (k = k.toLowerCase()), n.has(k) ? !0 : a.has(k) ? !1 : (v.issues.push({
        code: "invalid_value",
        expected: "stringbool",
        values: [...n, ...a],
        input: v.value,
        inst: p,
        continue: !1
      }), {});
    }), "transform"),
    reverseTransform: /* @__PURE__ */ s(((h, v) => h === !0 ? o[0] || "true" : t[0] || "false"), "reverseTransform"),
    error: i.error
  });
  return p._zod.bag.truthy = o, p._zod.bag.falsy = t, p._zod.bag.case = i.case ?? "insensitive", p;
}
s(cl, "_stringbool");
// @__NO_SIDE_EFFECTS__
function Ht(e, r, i, o = {}) {
  let t = w(o), n = {
    check: "string_format",
    type: "string",
    format: r,
    fn: typeof i == "function" ? i : (u) => i.test(u),
    ...t
  };
  return i instanceof RegExp && (n.pattern = i), new e(n);
}
s(Ht, "_stringFormat");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/to-json-schema.js
function Jr(e, ...r) {
  for (let i of r)
    for (let o of Reflect.ownKeys(i))
      Object.prototype.propertyIsEnumerable.call(i, o) && q(e, o, i[o]);
  return e;
}
s(Jr, "assignProps");
function Be(e) {
  let r = e?.target ?? "draft-2020-12";
  return r === "draft-4" && (r = "draft-04"), r === "draft-7" && (r = "draft-07"), {
    processors: e.processors ?? {},
    metadataRegistry: e?.metadata ?? H,
    target: r,
    unrepresentable: e?.unrepresentable ?? "throw",
    override: e?.override ?? (() => {
    }),
    io: e?.io ?? "output",
    counter: 0,
    seen: /* @__PURE__ */ new Map(),
    sharedDefsExtractedFor: void 0,
    sharedEmitDoneFor: void 0,
    cycles: e?.cycles ?? "ref",
    reused: e?.reused ?? "inline",
    intersections: [],
    deferred: [],
    external: e?.external ?? void 0
  };
}
s(Be, "initializeContext");
function G(e, r, i, o, t) {
  let n = typeof r.unrepresentable == "function" ? r.unrepresentable({ zodSchema: e, path: o.path, message: t }) : r.unrepresentable;
  if (n === "any")
    return !1;
  if (n === void 0 || n === "throw")
    throw new Error(t);
  return Object.assign(i, n), !0;
}
s(G, "handleUnrepresentable");
function C(e, r, i = { path: [], schemaPath: [] }) {
  var o;
  let t = e._zod.def, n = r.seen.get(e);
  if (n)
    return n.count++, i.schemaPath.includes(e) && (n.cycle = i.path), n.schema;
  let a = { schema: {}, count: 1, cycle: void 0, path: i.path };
  r.seen.set(e, a), r.sharedDefsExtractedFor = void 0, r.sharedEmitDoneFor = void 0;
  let u = e._zod.toJSONSchema?.();
  if (u)
    a.schema = u;
  else {
    let d = {
      ...i,
      schemaPath: [...i.schemaPath, e],
      path: i.path
    };
    if (e._zod.processJSONSchema)
      e._zod.processJSONSchema(r, a.schema, d);
    else {
      let p = a.schema, h = r.processors[t.type];
      if (!h)
        throw new Error(`[toJSONSchema]: Non-representable type encountered: ${t.type}`);
      h(e, r, p, d);
    }
    let f = e._zod.parent;
    f && (a.ref || (a.ref = f), C(f, r, d), r.seen.get(f).isParent = !0);
  }
  let c = r.metadataRegistry.get(e);
  return c && Jr(a.schema, c), r.io === "input" && ne(e) && (delete a.schema.examples, delete a.schema.default), r.io === "input" && "_prefault" in a.schema && ((o = a.schema).default ?? (o.default = a.schema._prefault)), delete a.schema._prefault, r.seen.get(e).schema;
}
s(C, "process");
function jp(e) {
  return e.replace(/~/g, "~0").replace(/\//g, "~1");
}
s(jp, "encodeJSONPointerSegment");
function Je(e, r) {
  let i = e.seen.get(r);
  if (!i)
    throw new Error("Unprocessed schema. This is a bug in Zod.");
  if (e.external && e.sharedDefsExtractedFor === e.external)
    return;
  let o = /* @__PURE__ */ new Map();
  for (let a of e.seen.entries()) {
    let u = e.metadataRegistry.get(a[0])?.id;
    if (u) {
      let c = o.get(u);
      if (c && c !== a[0])
        throw new Error(`Duplicate schema id "${u}" detected during JSON Schema conversion. Two different schemas cannot share the same id when converted together.`);
      o.set(u, a[0]);
    }
  }
  let t = /* @__PURE__ */ s((a) => {
    let u = e.target === "draft-2020-12" ? "$defs" : "definitions";
    if (e.external) {
      let f = e.external.registry.get(a[0])?.id, p = e.external.uri ?? ((v) => v);
      if (f)
        return { ref: p(f) };
      let h = a[1].defId ?? a[1].schema.id ?? `schema${e.counter++}`;
      return a[1].defId = h, { defId: h, ref: `${p("__shared")}#/${u}/${jp(h)}` };
    }
    let c = "#", l = `${c}/${u}/`;
    if (a[1] === i && !a[1].schema.id)
      return { ref: c };
    let d = a[1].schema.id ?? `__schema${e.counter++}`;
    return { defId: d, ref: l + jp(d) };
  }, "makeURI"), n = /* @__PURE__ */ s((a) => {
    if (a[1].schema.$ref)
      return;
    let u = a[1], { ref: c, defId: l } = t(a);
    u.def = { ...u.schema }, l && (u.defId = l);
    let d = u.schema;
    for (let f in d)
      delete d[f];
    d.$ref = c;
  }, "extractToDef");
  if (e.cycles === "throw")
    for (let a of e.seen.entries()) {
      let u = a[1];
      if (u.cycle)
        throw new Error(`Cycle detected: #/${u.cycle?.join("/")}/<root>

Set the \`cycles\` parameter to \`"ref"\` to resolve cyclical schemas with defs.`);
    }
  for (let a of e.seen.entries()) {
    let u = a[1];
    if (r === a[0]) {
      n(a);
      continue;
    }
    if (e.external) {
      let l = e.external.registry.get(a[0])?.id;
      if (r !== a[0] && l) {
        n(a);
        continue;
      }
    }
    if (e.metadataRegistry.get(a[0])?.id) {
      n(a);
      continue;
    }
    if (u.cycle) {
      n(a);
      continue;
    }
    if (u.count > 1 && e.reused === "ref") {
      n(a);
      continue;
    }
  }
  e.external && (e.sharedDefsExtractedFor = e.external);
}
s(Je, "extractDefs");
function Np(e) {
  let r = e.anyOf;
  if (!Array.isArray(r) || r.length === 0 || e.type !== void 0)
    return;
  let i = [];
  for (let o of r) {
    if (!o || typeof o != "object")
      return;
    Np(o);
    let t = Object.keys(o);
    if (t.length !== 1 || t[0] !== "type")
      return;
    let n = o.type;
    for (let a of Array.isArray(n) ? n : [n]) {
      if (typeof a != "string")
        return;
      i.includes(a) || i.push(a);
    }
  }
  delete e.anyOf, e.type = i.length === 1 ? i[0] : i;
}
s(Np, "compactTypeUnion");
var Tp = /* @__PURE__ */ new Set(["type", "properties", "required", "additionalProperties"]), Pp = ["oneOf", "anyOf"];
function Dp(e) {
  let r = e.additionalProperties;
  return r === void 0 || r === !1 || typeof r != "object" || r === null ? null : Object.keys(r).length ? r : null;
}
s(Dp, "undeclaredConstraint");
function ll(e) {
  let r = [];
  for (let n of e) {
    if (typeof n != "object" || n.type !== "object")
      return null;
    for (let a in n)
      if (!Tp.has(a))
        return null;
    r.push(n);
  }
  let i = {}, o = /* @__PURE__ */ new Set();
  for (let n of r) {
    for (let a in n.properties) {
      if (Object.prototype.hasOwnProperty.call(i, a))
        continue;
      let u = [];
      for (let l of r) {
        let d = l.properties?.[a] ?? Dp(l);
        d != null && (u.some((f) => JSON.stringify(f) === JSON.stringify(d)) || u.push(d));
      }
      let c = u.length === 1 ? u[0] : ll(u) ?? { allOf: u };
      q(i, a, c);
    }
    for (let a of n.required ?? [])
      o.add(a);
  }
  let t = { type: "object", properties: i };
  if (o.size && (t.required = [...o]), r.every((n) => n.additionalProperties === !1))
    t.additionalProperties = !1;
  else {
    let n = [];
    for (let a of r) {
      let u = Dp(a);
      u && !n.some((c) => JSON.stringify(c) === JSON.stringify(u)) && n.push(u);
    }
    n.length === 1 ? t.additionalProperties = n[0] : n.length > 1 && (t.additionalProperties = { allOf: n });
  }
  return t;
}
s(ll, "foldObjects");
function Nb(e) {
  let r = e.allOf;
  if (!Array.isArray(r) || r.length < 2)
    return;
  for (let t of Tp)
    if (t in e)
      return;
  let i = r.filter((t) => Pp.some((n) => Array.isArray(t[n]))), o = null;
  if (!i.length)
    o = ll(r);
  else {
    let t = i[0], n = Pp.find((c) => Array.isArray(t[c]));
    if (Object.keys(t).length !== 1)
      return;
    let a = r.filter((c) => c !== t), u = t[n].map((c) => ll([...a, c]));
    if (u.some((c) => !c))
      return;
    o = { [n]: u };
  }
  o && (delete e.allOf, Jr(e, o));
}
s(Nb, "foldIntersection");
function qe(e, r) {
  let i = e.seen.get(r);
  if (!i)
    throw new Error("Unprocessed schema. This is a bug in Zod.");
  let o = /* @__PURE__ */ s((u) => {
    let c = e.seen.get(u);
    if (c.ref === null)
      return;
    let l = c.def ?? c.schema, d = { ...l }, f = c.ref;
    if (c.ref = null, f) {
      o(f);
      let h = e.seen.get(f), v = h.schema;
      if (v.$ref && (e.target === "draft-07" || e.target === "draft-04" || e.target === "openapi-3.0") ? (l.allOf = l.allOf ?? [], l.allOf.push(v)) : Jr(l, v), Jr(l, d), u._zod.parent === f)
        for (let z in l)
          z === "$ref" || z === "allOf" || z in d || delete l[z];
      if (v.$ref && h.def)
        for (let z in l)
          z === "$ref" || z === "allOf" || z in h.def && JSON.stringify(l[z]) === JSON.stringify(h.def[z]) && delete l[z];
    }
    let p = u._zod.parent;
    if (p && p !== f) {
      o(p);
      let h = e.seen.get(p);
      if (h?.schema.$ref && (l.$ref = h.schema.$ref, h.def))
        for (let v in l)
          v === "$ref" || v === "allOf" || v in h.def && JSON.stringify(l[v]) === JSON.stringify(h.def[v]) && delete l[v];
    }
    e.override({
      zodSchema: u,
      jsonSchema: l,
      path: c.path ?? []
    });
  }, "flattenRef");
  if (!e.external || e.sharedEmitDoneFor !== e.external) {
    for (let u of [...e.seen.entries()].reverse())
      o(u[0]);
    if (e.target !== "openapi-3.0")
      for (let u of e.seen.entries())
        Np(u[1].def ?? u[1].schema);
    for (let u of e.deferred)
      u();
    if (e.intersections.length) {
      let u = /* @__PURE__ */ new Map();
      for (let c of e.seen.values())
        for (let l of [c.schema, c.def]) {
          let d = l?.allOf;
          if (!Array.isArray(d))
            continue;
          let f = u.get(d);
          f ? f.push(l) : u.set(d, [l]);
        }
      for (let c of e.intersections)
        for (let l of u.get(c) ?? [])
          Nb(l);
    }
  }
  let t = {};
  if (e.target === "draft-2020-12" ? t.$schema = "https://json-schema.org/draft/2020-12/schema" : e.target === "draft-07" ? t.$schema = "http://json-schema.org/draft-07/schema#" : e.target === "draft-04" ? t.$schema = "http://json-schema.org/draft-04/schema#" : e.target, e.external?.uri) {
    let u = e.external.registry.get(r)?.id;
    if (!u)
      throw new Error("Schema is missing an `id` property");
    t.$id = e.external.uri(u);
  }
  Jr(t, i.defId ? i.schema : i.def ?? i.schema);
  let n = e.metadataRegistry.get(r)?.id;
  n !== void 0 && t.id === n && delete t.id;
  let a = e.external?.defs ?? {};
  if (!e.external || e.sharedEmitDoneFor !== e.external)
    for (let u of e.seen.entries()) {
      let c = u[1];
      c.def && c.defId && (c.def.id === c.defId && delete c.def.id, q(a, c.defId, c.def));
    }
  e.external && (e.sharedEmitDoneFor = e.external), e.external || Object.keys(a).length > 0 && (e.target === "draft-2020-12" ? t.$defs = a : t.definitions = a);
  try {
    let u = JSON.parse(JSON.stringify(t));
    return Object.defineProperty(u, "~standard", {
      value: {
        ...r["~standard"],
        jsonSchema: {
          input: Qt(r, "input", e.processors),
          output: Qt(r, "output", e.processors)
        }
      },
      enumerable: !1,
      writable: !1
    }), u;
  } catch {
    throw new Error("Error converting schema to JSON.");
  }
}
s(qe, "finalize");
function ne(e, r) {
  let i = r ?? { seen: /* @__PURE__ */ new Set() };
  if (i.seen.has(e))
    return !1;
  i.seen.add(e);
  let o = e._zod.def;
  if (o.type === "transform")
    return !0;
  if (o.type === "array")
    return ne(o.element, i);
  if (o.type === "set")
    return ne(o.valueType, i);
  if (o.type === "lazy")
    return ne(o.getter(), i);
  if (o.type === "promise" || o.type === "optional" || o.type === "nonoptional" || o.type === "nullable" || o.type === "readonly" || o.type === "default" || o.type === "prefault" || o.type === "catch")
    return ne(o.innerType, i);
  if (o.type === "intersection")
    return ne(o.left, i) || ne(o.right, i);
  if (o.type === "record" || o.type === "map")
    return ne(o.keyType, i) || ne(o.valueType, i);
  if (o.type === "pipe")
    return e._zod.traits.has("$ZodCodec") ? !0 : ne(o.in, i) || ne(o.out, i);
  if (o.type === "object") {
    for (let t in o.shape)
      if (ne(o.shape[t], i))
        return !0;
    return !1;
  }
  if (o.type === "union") {
    for (let t of o.options)
      if (ne(t, i))
        return !0;
    return !1;
  }
  if (o.type === "tuple") {
    for (let t of o.items)
      if (ne(t, i))
        return !0;
    return !!(o.rest && ne(o.rest, i));
  }
  return !1;
}
s(ne, "isTransforming");
var dl = /* @__PURE__ */ s((e, r = {}) => (i) => {
  let o = Be({ ...i, processors: r });
  return C(e, o), Je(o, e), qe(o, e);
}, "createToJSONSchemaMethod"), Qt = /* @__PURE__ */ s((e, r, i = {}) => (o) => {
  let { libraryOptions: t, target: n } = o ?? {}, a = Be({ ...t ?? {}, target: n, io: r, processors: i });
  return C(e, a), Je(a, e), qe(a, e);
}, "createStandardJSONSchemaMethod");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/json-schema-processors.js
var Tb = {
  guid: "uuid",
  url: "uri",
  datetime: "date-time",
  json_string: "json-string",
  regex: ""
  // do not set
}, ml = /* @__PURE__ */ s((e, r, i, o) => {
  let t = i;
  t.type = "string";
  let { minimum: n, maximum: a, format: u, patterns: c, contentEncoding: l, laxFormat: d } = e._zod.bag;
  if (typeof n == "number" && (t.minLength = n), typeof a == "number" && (t.maxLength = a), u && (t.format = Tb[u] ?? u, t.format === "" && delete t.format, (u === "time" || d) && delete t.format), l && (t.contentEncoding = l), c && c.size > 0) {
    let f = [...c];
    f.length === 1 ? t.pattern = f[0].source : f.length > 1 && (t.allOf = [
      ...f.map((p) => ({
        ...r.target === "draft-07" || r.target === "draft-04" || r.target === "openapi-3.0" ? { type: "string" } : {},
        pattern: p.source
      }))
    ]);
  }
}, "stringProcessor"), gl = /* @__PURE__ */ s((e, r, i, o) => {
  let t = i, { minimum: n, maximum: a, format: u, multipleOf: c, exclusiveMaximum: l, exclusiveMinimum: d } = e._zod.bag;
  typeof u == "string" && u.includes("int") ? t.type = "integer" : t.type = "number";
  let f = typeof d == "number" && d >= (n ?? Number.NEGATIVE_INFINITY), p = typeof l == "number" && l <= (a ?? Number.POSITIVE_INFINITY), h = r.target === "draft-04" || r.target === "openapi-3.0";
  f ? h ? (t.minimum = d, t.exclusiveMinimum = !0) : t.exclusiveMinimum = d : typeof n == "number" && (t.minimum = n), p ? h ? (t.maximum = l, t.exclusiveMaximum = !0) : t.exclusiveMaximum = l : typeof a == "number" && (t.maximum = a), typeof c == "number" && (Number.isFinite(c) && c !== 0 ? t.multipleOf = Math.abs(c) : G(e, r, t, o, `A multipleOf divisor of ${c} cannot be represented in JSON Schema`));
}, "numberProcessor"), hl = /* @__PURE__ */ s((e, r, i, o) => {
  i.type = "boolean";
}, "booleanProcessor"), vl = /* @__PURE__ */ s((e, r, i, o) => {
  G(e, r, i, o, "BigInt cannot be represented in JSON Schema");
}, "bigintProcessor"), yl = /* @__PURE__ */ s((e, r, i, o) => {
  G(e, r, i, o, "Symbols cannot be represented in JSON Schema");
}, "symbolProcessor"), $l = /* @__PURE__ */ s((e, r, i, o) => {
  r.target === "openapi-3.0" ? (i.type = "string", i.nullable = !0, i.enum = [null]) : i.type = "null";
}, "nullProcessor"), bl = /* @__PURE__ */ s((e, r, i, o) => {
  G(e, r, i, o, "Undefined cannot be represented in JSON Schema");
}, "undefinedProcessor"), _l = /* @__PURE__ */ s((e, r, i, o) => {
  G(e, r, i, o, "Void cannot be represented in JSON Schema");
}, "voidProcessor"), xl = /* @__PURE__ */ s((e, r, i, o) => {
  i.not = {};
}, "neverProcessor"), wl = /* @__PURE__ */ s((e, r, i, o) => {
}, "anyProcessor"), kl = /* @__PURE__ */ s((e, r, i, o) => {
}, "unknownProcessor"), Il = /* @__PURE__ */ s((e, r, i, o) => {
  G(e, r, i, o, "Date cannot be represented in JSON Schema");
}, "dateProcessor"), zl = /* @__PURE__ */ s((e, r, i, o) => {
  let t = e._zod.def, n = vr(t.entries);
  if (n.length === 0) {
    i.not = {};
    return;
  }
  n.every((a) => typeof a == "number") && (i.type = "number"), n.every((a) => typeof a == "string") && (i.type = "string"), i.enum = n;
}, "enumProcessor"), Sl = /* @__PURE__ */ s((e, r, i, o) => {
  let t = e._zod.def;
  if (t.values.length === 0) {
    i.not = {};
    return;
  }
  let n = [];
  for (let a of t.values)
    if (a === void 0) {
      if (G(e, r, i, o, "Literal `undefined` cannot be represented in JSON Schema"))
        return;
    } else if (typeof a == "bigint") {
      if (G(e, r, i, o, "BigInt literals cannot be represented in JSON Schema"))
        return;
      n.push(Number(a));
    } else
      n.push(a);
  if (n.length !== 0)
    if (n.length === 1) {
      let a = n[0];
      i.type = a === null ? "null" : typeof a, r.target === "draft-04" || r.target === "openapi-3.0" ? i.enum = [a] : i.const = a;
    } else
      n.every((a) => typeof a == "number") && (i.type = "number"), n.every((a) => typeof a == "string") && (i.type = "string"), n.every((a) => typeof a == "boolean") && (i.type = "boolean"), n.every((a) => a === null) && (i.type = "null"), i.enum = n;
}, "literalProcessor"), Ol = /* @__PURE__ */ s((e, r, i, o) => {
  G(e, r, i, o, "NaN cannot be represented in JSON Schema");
}, "nanProcessor"), jl = /* @__PURE__ */ s((e, r, i, o) => {
  let t = i, n = e._zod.pattern;
  if (!n)
    throw new Error("Pattern not found in template literal");
  t.type = "string", t.pattern = n.source;
}, "templateLiteralProcessor"), Pl = /* @__PURE__ */ s((e, r, i, o) => {
  let t = i, n = {
    type: "string",
    format: "binary",
    contentEncoding: "binary"
  }, { minimum: a, maximum: u, mime: c } = e._zod.bag;
  a !== void 0 && (n.minLength = a), u !== void 0 && (n.maxLength = u), c ? c.length === 1 ? (n.contentMediaType = c[0], Object.assign(t, n)) : (Object.assign(t, n), t.anyOf = c.map((l) => ({ contentMediaType: l }))) : Object.assign(t, n);
}, "fileProcessor"), Dl = /* @__PURE__ */ s((e, r, i, o) => {
  i.type = "boolean";
}, "successProcessor"), Nl = /* @__PURE__ */ s((e, r, i, o) => {
  G(e, r, i, o, "Custom types cannot be represented in JSON Schema");
}, "customProcessor"), Tl = /* @__PURE__ */ s((e, r, i, o) => {
  G(e, r, i, o, "Function types cannot be represented in JSON Schema");
}, "functionProcessor"), Al = /* @__PURE__ */ s((e, r, i, o) => {
  G(e, r, i, o, "Transforms cannot be represented in JSON Schema");
}, "transformProcessor"), Ul = /* @__PURE__ */ s((e, r, i, o) => {
  G(e, r, i, o, "Map cannot be represented in JSON Schema");
}, "mapProcessor"), El = /* @__PURE__ */ s((e, r, i, o) => {
  G(e, r, i, o, "Set cannot be represented in JSON Schema");
}, "setProcessor"), Cl = /* @__PURE__ */ s((e, r, i, o) => {
  let t = i, n = e._zod.def, { minimum: a, maximum: u } = e._zod.bag;
  typeof a == "number" && (t.minItems = a), typeof u == "number" && (t.maxItems = u), t.type = "array", t.items = C(n.element, r, {
    ...o,
    path: [...o.path, "items"]
  });
}, "arrayProcessor");
function qr(e) {
  let r = e._zod.def;
  return r.type === "pipe" && r.in._zod.traits.has("$ZodTransform") ? qr(r.out) : r.type === "catch" ? qr(r.innerType) : e._zod.optin;
}
s(qr, "inputOptin");
var Zl = /* @__PURE__ */ s((e, r, i, o) => {
  let t = i, n = e._zod.def, a = n.shape;
  if (Object.getOwnPropertySymbols(a).length && G(e, r, t, o, "Symbol keys cannot be represented in JSON Schema"))
    return;
  t.type = "object", t.properties = {};
  for (let d in a)
    q(t.properties, d, C(a[d], r, {
      ...o,
      path: [...o.path, "properties", d]
    }));
  let c = new Set(Object.keys(a)), l = new Set([...c].filter((d) => {
    let f = n.shape[d];
    return r.io === "input" ? qr(f) === void 0 : f._zod.optout === void 0;
  }));
  l.size > 0 && (t.required = Array.from(l)), n.catchall?._zod.def.type === "never" ? t.additionalProperties = !1 : n.catchall ? n.catchall && (t.additionalProperties = C(n.catchall, r, {
    ...o,
    path: [...o.path, "additionalProperties"]
  })) : r.io === "output" && (t.additionalProperties = !1);
}, "objectProcessor"), Mi = /* @__PURE__ */ s((e, r, i, o) => {
  let t = e._zod.def, n = t.inclusive === !1, a = t.options.map((u, c) => C(u, r, {
    ...o,
    path: [...o.path, n ? "oneOf" : "anyOf", c]
  }));
  n ? i.oneOf = a : i.anyOf = a;
}, "unionProcessor"), Rl = /* @__PURE__ */ s((e, r, i, o) => {
  let t = e._zod.def, n = C(t.left, r, {
    ...o,
    path: [...o.path, "allOf", 0]
  }), a = C(t.right, r, {
    ...o,
    path: [...o.path, "allOf", 1]
  }), u = /* @__PURE__ */ s((l) => "allOf" in l && Object.keys(l).length === 1, "isSimpleIntersection"), c = [
    ...u(n) ? n.allOf : [n],
    ...u(a) ? a.allOf : [a]
  ];
  i.allOf = c, r.intersections.push(c);
}, "intersectionProcessor"), Fl = /* @__PURE__ */ s((e, r, i, o) => {
  let t = i, n = e._zod.def;
  t.type = "array";
  let a = r.target === "draft-2020-12" ? "prefixItems" : "items", u = r.target === "draft-2020-12" || r.target === "openapi-3.0" ? "items" : "additionalItems", c = n.items.map((k, z) => C(k, r, {
    ...o,
    path: [...o.path, a, z]
  })), l = n.rest ? C(n.rest, r, {
    ...o,
    path: [...o.path, u, ...r.target === "openapi-3.0" ? [n.items.length] : []]
  }) : null, d = n.items.length;
  for (; d > 0; ) {
    let k = n.items[d - 1];
    if (!(r.io === "input" ? qr(k) !== void 0 : k._zod.optout === "optional"))
      break;
    d--;
  }
  let f = n.items.length, p = !n.rest;
  r.target === "draft-2020-12" ? (t.prefixItems = c, p ? t.items = !1 : l && (t.items = l), d > 0 && (t.minItems = d), p && (t.maxItems = f)) : r.target === "openapi-3.0" ? (t.items = {
    anyOf: c
  }, l && t.items.anyOf.push(l), d > 0 && (t.minItems = d), p && (t.maxItems = f)) : (t.items = c, p ? t.additionalItems = !1 : l && (t.additionalItems = l), d > 0 && (t.minItems = d), p && (t.maxItems = f));
  let { minimum: h, maximum: v } = e._zod.bag;
  typeof h == "number" && (t.minItems = h), typeof v == "number" && (t.maxItems = v);
}, "tupleProcessor");
function fl(e, r, i) {
  if (r.$ref) {
    if (i.has(r))
      return r;
    i.add(r);
    let v = e.get(r)?.def;
    if (!v)
      return r;
    let k = fl(e, v, i);
    return k === v ? r : k;
  }
  for (let v of ["anyOf", "oneOf"]) {
    let k = r[v];
    if (!Array.isArray(k))
      continue;
    let z = k.map((Z) => fl(e, Z, i));
    z.some((Z, O) => Z !== k[O]) && (r = { ...r, [v]: z });
  }
  let o = Array.isArray(r.type) ? r.type : [r.type], t = !o.includes("string") && o.some((v) => v === "number" || v === "integer"), n = r.enum ?? (r.const !== void 0 ? [r.const] : void 0);
  if (!t && !n?.some((v) => typeof v == "number"))
    return r;
  let { minimum: a, maximum: u, exclusiveMinimum: c, exclusiveMaximum: l, multipleOf: d, format: f, id: p, ...h } = r;
  return h.enum ? h.enum = h.enum.map((v) => typeof v == "number" ? String(v) : v) : typeof h.const == "number" && (h.const = String(h.const)), t && (h.type = "string", n || (h.pattern = (o.includes("number") ? Ze : Sr).source)), h;
}
s(fl, "stringifyKeyNames");
var pl = /* @__PURE__ */ new WeakMap();
function Ab(e) {
  let r = /* @__PURE__ */ new Map();
  for (let o of e.seen.values())
    o.def && !r.has(o.schema) && r.set(o.schema, o);
  let i = /* @__PURE__ */ new Map();
  for (let o of pl.get(e) ?? []) {
    let t = e.seen.get(o), n = (t?.def ?? t?.schema)?.propertyNames;
    if (!n || n === !0 || i.has(n))
      continue;
    let a = fl(r, n, /* @__PURE__ */ new Set());
    a !== n && i.set(n, a);
  }
  if (i.size)
    for (let o of e.seen.values())
      for (let t of [o.schema, o.def]) {
        let n = t && i.get(t.propertyNames);
        n && (t.propertyNames = n);
      }
}
s(Ab, "rewriteKeyNames");
var Ll = /* @__PURE__ */ s((e, r, i, o) => {
  let t = i, n = e._zod.def;
  t.type = "object";
  let a = n.keyType, c = a._zod.bag?.patterns;
  if (n.mode === "loose" && c && c.size > 0) {
    let f = C(n.valueType, r, {
      ...o,
      path: [...o.path, "patternProperties", "*"]
    });
    t.patternProperties = {};
    for (let p of c)
      q(t.patternProperties, p.source, f);
  } else {
    if (r.target === "draft-07" || r.target === "draft-2020-12") {
      t.propertyNames = C(n.keyType, r, {
        ...o,
        path: [...o.path, "propertyNames"]
      });
      let f = pl.get(r);
      f || (f = [], pl.set(r, f), r.deferred.push(() => Ab(r))), f.push(e);
    }
    t.additionalProperties = C(n.valueType, r, {
      ...o,
      path: [...o.path, "additionalProperties"]
    });
  }
  let l = a._zod.values, d = r.io === "input" && qr(n.valueType) !== void 0;
  if (l && !n.partial && !d) {
    let f = [...l].filter((p) => typeof p == "string" || typeof p == "number");
    f.length > 0 && (t.required = f.map(String));
  }
}, "recordProcessor"), Vl = /* @__PURE__ */ s((e, r, i, o) => {
  let t = e._zod.def, n = C(t.innerType, r, o), a = r.seen.get(e);
  r.target === "openapi-3.0" ? (a.ref = t.innerType, i.nullable = !0) : i.anyOf = [n, { type: "null" }];
}, "nullableProcessor"), Ml = /* @__PURE__ */ s((e, r, i, o) => {
  let t = e._zod.def;
  C(t.innerType, r, o);
  let n = r.seen.get(e);
  n.ref = t.innerType;
}, "nonoptionalProcessor"), Bl = Symbol();
function Ap(e, r, i, o, t) {
  let n = !1, a = JSON.stringify(e, (u, c) => typeof c != "bigint" ? c : (n = !0, null));
  return n ? (G(r, i, o, t, "BigInt defaults cannot be represented in JSON Schema"), Bl) : JSON.parse(a);
}
s(Ap, "serializeDefaultValue");
var Jl = /* @__PURE__ */ s((e, r, i, o) => {
  let t = e._zod.def;
  C(t.innerType, r, o);
  let n = r.seen.get(e);
  n.ref = t.innerType;
  let a = Ap(t.defaultValue, e, r, i, o);
  a !== Bl && (i.default = a);
}, "defaultProcessor"), ql = /* @__PURE__ */ s((e, r, i, o) => {
  let t = e._zod.def;
  C(t.innerType, r, o);
  let n = r.seen.get(e);
  if (n.ref = t.innerType, r.io !== "input")
    return;
  let a = Ap(t.defaultValue, e, r, i, o);
  a !== Bl && (i._prefault = a);
}, "prefaultProcessor"), Kl = /* @__PURE__ */ s((e, r, i, o) => {
  let t = e._zod.def;
  C(t.innerType, r, o);
  let n = r.seen.get(e);
  n.ref = t.innerType;
  let a;
  try {
    a = t.catchValue(void 0);
  } catch {
    G(e, r, i, o, "Dynamic catch values are not supported in JSON Schema");
    return;
  }
  i.default = a;
}, "catchProcessor"), Wl = /* @__PURE__ */ s((e, r, i, o) => {
  let t = e._zod.def, n = t.in._zod.traits.has("$ZodTransform"), a = r.io === "input" ? n ? t.out : t.in : t.out;
  C(a, r, o);
  let u = r.seen.get(e);
  u.ref = a;
}, "pipeProcessor"), Gl = /* @__PURE__ */ s((e, r, i, o) => {
  let t = e._zod.def;
  C(t.innerType, r, o);
  let n = r.seen.get(e);
  n.ref = t.innerType, i.readOnly = !0;
}, "readonlyProcessor"), Xl = /* @__PURE__ */ s((e, r, i, o) => {
  let t = e._zod.def;
  C(t.innerType, r, o);
  let n = r.seen.get(e);
  n.ref = t.innerType;
}, "promiseProcessor"), Bi = /* @__PURE__ */ s((e, r, i, o) => {
  let t = e._zod.def;
  C(t.innerType, r, o);
  let n = r.seen.get(e);
  n.ref = t.innerType;
}, "optionalProcessor"), Hl = /* @__PURE__ */ s((e, r, i, o) => {
  let t = e._zod.innerType;
  C(t, r, o);
  let n = r.seen.get(e);
  n.ref = t;
}, "lazyProcessor"), Vi = {
  string: ml,
  number: gl,
  boolean: hl,
  bigint: vl,
  symbol: yl,
  null: $l,
  undefined: bl,
  void: _l,
  never: xl,
  any: wl,
  unknown: kl,
  date: Il,
  enum: zl,
  literal: Sl,
  nan: Ol,
  template_literal: jl,
  file: Pl,
  success: Dl,
  custom: Nl,
  function: Tl,
  transform: Al,
  map: Ul,
  set: El,
  array: Cl,
  object: Zl,
  union: Mi,
  intersection: Rl,
  tuple: Fl,
  record: Ll,
  nullable: Vl,
  nonoptional: Ml,
  default: Jl,
  prefault: ql,
  catch: Kl,
  pipe: Wl,
  readonly: Gl,
  promise: Xl,
  optional: Bi,
  lazy: Hl
};
function Ji(e, r) {
  if ("_idmap" in e) {
    let o = e, t = Be({ ...r, processors: Vi }), n = {};
    for (let c of o._idmap.entries()) {
      let [l, d] = c;
      C(d, t);
    }
    let a = {}, u = {
      registry: o,
      uri: r?.uri,
      defs: n
    };
    t.external = u;
    for (let c of o._idmap.entries()) {
      let [l, d] = c;
      Je(t, d), q(a, l, qe(t, d));
    }
    if (Object.keys(n).length > 0) {
      let c = t.target === "draft-2020-12" ? "$defs" : "definitions";
      a.__shared = {
        [c]: n
      };
    }
    return { schemas: a };
  }
  let i = Be({ ...r, processors: Vi });
  return C(e, i), Je(i, e), qe(i, e);
}
s(Ji, "toJSONSchema");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/json-schema-generator.js
var qi = class {
  static {
    s(this, "JSONSchemaGenerator");
  }
  /** @deprecated Access via ctx instead */
  get metadataRegistry() {
    return this.ctx.metadataRegistry;
  }
  /** @deprecated Access via ctx instead */
  get target() {
    return this.ctx.target;
  }
  // annotated so the .d.cts emits an indexed access rather than an inline `import()` of an ESM path
  /** @deprecated Access via ctx instead */
  get unrepresentable() {
    return this.ctx.unrepresentable;
  }
  /** @deprecated Access via ctx instead */
  get override() {
    return this.ctx.override;
  }
  /** @deprecated Access via ctx instead */
  get io() {
    return this.ctx.io;
  }
  /** @deprecated Access via ctx instead */
  get counter() {
    return this.ctx.counter;
  }
  set counter(r) {
    this.ctx.counter = r;
  }
  /** @deprecated Access via ctx instead */
  get seen() {
    return this.ctx.seen;
  }
  constructor(r) {
    let i = r?.target ?? "draft-2020-12";
    i === "draft-4" && (i = "draft-04"), i === "draft-7" && (i = "draft-07"), this.ctx = Be({
      processors: Vi,
      target: i,
      ...r?.metadata && { metadata: r.metadata },
      ...r?.unrepresentable && { unrepresentable: r.unrepresentable },
      ...r?.override && { override: r.override },
      ...r?.io && { io: r.io }
    });
  }
  /**
   * Process a schema to prepare it for JSON Schema generation.
   * This must be called before emit().
   */
  process(r, i = { path: [], schemaPath: [] }) {
    return C(r, this.ctx, i);
  }
  /**
   * Emit the final JSON Schema after processing.
   * Must call process() first.
   */
  emit(r, i) {
    i && (i.cycles && (this.ctx.cycles = i.cycles), i.reused && (this.ctx.reused = i.reused), i.external && (this.ctx.external = i.external)), this.ctx.sharedDefsExtractedFor = void 0, this.ctx.sharedEmitDoneFor = void 0, Je(this.ctx, r);
    let o = qe(this.ctx, r), { "~standard": t, ...n } = o;
    return n;
  }
};

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/json-schema.js
var Up = {};

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/external.js
var x = {};
Pe(x, {
  $brand: () => ia,
  $input: () => xc,
  $output: () => _c,
  NEVER: () => na,
  TimePrecision: () => Nc,
  ZodAny: () => yd,
  ZodArray: () => xd,
  ZodBase64: () => fo,
  ZodBase64URL: () => po,
  ZodBigInt: () => or,
  ZodBigIntFormat: () => ho,
  ZodBoolean: () => ir,
  ZodCIDRv4: () => co,
  ZodCIDRv6: () => lo,
  ZodCUID: () => ro,
  ZodCUID2: () => no,
  ZodCatch: () => Md,
  ZodCodec: () => rn,
  ZodCompileAsyncError: () => be,
  ZodCompileUnsupportedError: () => U,
  ZodCreditCard: () => dd,
  ZodCustom: () => nn,
  ZodCustomStringFormat: () => rr,
  ZodDate: () => Xr,
  ZodDefault: () => Cd,
  ZodDiscriminatedUnion: () => kd,
  ZodE164: () => mo,
  ZodEmail: () => Qi,
  ZodEmoji: () => eo,
  ZodEnum: () => er,
  ZodError: () => Eb,
  ZodExactOptional: () => bo,
  ZodFile: () => Td,
  ZodFirstPartyTypeKind: () => rf,
  ZodFunction: () => Yd,
  ZodGUID: () => Yi,
  ZodIPv4: () => so,
  ZodIPv6: () => uo,
  ZodISODate: () => We,
  ZodISODateTime: () => Ke,
  ZodISODuration: () => Xe,
  ZodISOTime: () => Ge,
  ZodIntersection: () => Id,
  ZodIssueCode: () => Rb,
  ZodJWT: () => go,
  ZodKSUID: () => ao,
  ZodLazy: () => Xd,
  ZodLiteral: () => Nd,
  ZodMAC: () => ld,
  ZodMap: () => Pd,
  ZodNaN: () => Jd,
  ZodNanoID: () => to,
  ZodNever: () => bd,
  ZodNonOptional: () => _o,
  ZodNull: () => hd,
  ZodNullable: () => Ed,
  ZodNumber: () => nr,
  ZodNumberFormat: () => $t,
  ZodObject: () => Qr,
  ZodOptional: () => en,
  ZodPipe: () => tn,
  ZodPrefault: () => Rd,
  ZodPreprocess: () => qd,
  ZodPromise: () => Qd,
  ZodReadonly: () => Kd,
  ZodRealError: () => ce,
  ZodRecord: () => Yt,
  ZodSet: () => Dd,
  ZodString: () => tr,
  ZodStringFormat: () => F,
  ZodSuccess: () => Vd,
  ZodSymbol: () => md,
  ZodTemplateLiteral: () => Gd,
  ZodTransform: () => Ad,
  ZodTuple: () => Sd,
  ZodType: () => N,
  ZodULID: () => io,
  ZodURL: () => Gr,
  ZodUUID: () => Oe,
  ZodUndefined: () => gd,
  ZodUnion: () => Yr,
  ZodUnknown: () => $d,
  ZodVoid: () => _d,
  ZodXID: () => oo,
  ZodXor: () => wd,
  _ZodString: () => Hi,
  _default: () => Zd,
  _function: () => Jm,
  any: () => xm,
  array: () => Hr,
  base64: () => im,
  base64url: () => om,
  bigint: () => vm,
  boolean: () => pd,
  catch: () => Bd,
  check: () => qm,
  cidrv4: () => rm,
  cidrv6: () => nm,
  clone: () => A,
  codec: () => Lm,
  coerce: () => nf,
  compile: () => zc,
  config: () => K,
  core: () => Ae,
  creditCard: () => sm,
  cuid: () => Wp,
  cuid2: () => Gp,
  custom: () => Km,
  date: () => km,
  decode: () => nd,
  decodeAsync: () => od,
  deepPartial: () => og,
  describe: () => Wm,
  discriminatedUnion: () => Pm,
  e164: () => am,
  email: () => Zp,
  emoji: () => qp,
  encode: () => rd,
  encodeAsync: () => id,
  endsWith: () => Bt,
  enum: () => yo,
  exactOptional: () => Ud,
  file: () => Cm,
  flattenError: () => kr,
  float32: () => pm,
  float64: () => mm,
  formatError: () => Ir,
  fromJSONSchema: () => ng,
  function: () => Jm,
  getDiscriminatedOption: () => Gs,
  getErrorMap: () => Lb,
  globalRegistry: () => H,
  gt: () => ze,
  gte: () => ge,
  guid: () => Rp,
  hash: () => fm,
  hex: () => dm,
  hostname: () => lm,
  httpUrl: () => Jp,
  includes: () => Vt,
  input: () => sg,
  instanceof: () => Xm,
  int: () => Gi,
  int32: () => gm,
  int64: () => ym,
  intersection: () => zd,
  invertCodec: () => Vm,
  ipv4: () => Yp,
  ipv6: () => tm,
  iso: () => on,
  json: () => Qm,
  jwt: () => um,
  keyof: () => Im,
  ksuid: () => Qp,
  lazy: () => Hd,
  length: () => gt,
  literal: () => Em,
  locales: () => Rr,
  looseObject: () => Om,
  looseRecord: () => Nm,
  lowercase: () => Ft,
  lt: () => Ie,
  lte: () => me,
  mac: () => em,
  map: () => Tm,
  maxLength: () => mt,
  maxSize: () => Me,
  memoizer: () => Ar,
  meta: () => Gm,
  mime: () => Jt,
  minLength: () => Te,
  minSize: () => Se,
  multipleOf: () => Ve,
  nan: () => Fm,
  nanoid: () => Kp,
  nativeEnum: () => Um,
  negative: () => Ci,
  never: () => vo,
  nonnegative: () => Ri,
  nonoptional: () => Ld,
  nonpositive: () => Zi,
  normalize: () => qt,
  null: () => vd,
  nullable: () => Wr,
  nullish: () => Zm,
  number: () => fd,
  object: () => zm,
  optional: () => vt,
  output: () => ug,
  overwrite: () => _e,
  parse: () => Ql,
  parseAsync: () => Yl,
  partialRecord: () => Dm,
  pipe: () => Xi,
  positive: () => Ei,
  prefault: () => Fd,
  preprocess: () => Ym,
  prettifyError: () => ca,
  promise: () => Bm,
  properties: () => Li,
  property: () => Fi,
  readonly: () => Wd,
  record: () => jd,
  refine: () => ef,
  regex: () => Rt,
  regexes: () => te,
  registry: () => pi,
  safeDecode: () => sd,
  safeDecodeAsync: () => cd,
  safeEncode: () => ad,
  safeEncodeAsync: () => ud,
  safeParse: () => ed,
  safeParseAsync: () => td,
  set: () => Am,
  setErrorMap: () => Fb,
  size: () => pt,
  slugify: () => Xt,
  startsWith: () => Mt,
  strictObject: () => Sm,
  string: () => Kr,
  stringFormat: () => cm,
  stringbool: () => Hm,
  success: () => Rm,
  superRefine: () => tf,
  symbol: () => bm,
  templateLiteral: () => Mm,
  toJSONSchema: () => Ji,
  toLowerCase: () => Wt,
  toUpperCase: () => Gt,
  toZod: () => hr,
  transform: () => $o,
  treeifyError: () => ua,
  trim: () => Kt,
  tuple: () => Od,
  uint32: () => hm,
  uint64: () => $m,
  ulid: () => Xp,
  undefined: () => _m,
  union: () => ar,
  unknown: () => ht,
  uppercase: () => Lt,
  url: () => Bp,
  util: () => _,
  uuid: () => Fp,
  uuidv4: () => Lp,
  uuidv6: () => Vp,
  uuidv7: () => Mp,
  validate: () => da,
  validateAsync: () => fa,
  void: () => wm,
  xid: () => Hp,
  xor: () => jm
});

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/schemas.js
var sr = {};
Pe(sr, {
  ZodAny: () => yd,
  ZodArray: () => xd,
  ZodBase64: () => fo,
  ZodBase64URL: () => po,
  ZodBigInt: () => or,
  ZodBigIntFormat: () => ho,
  ZodBoolean: () => ir,
  ZodCIDRv4: () => co,
  ZodCIDRv6: () => lo,
  ZodCUID: () => ro,
  ZodCUID2: () => no,
  ZodCatch: () => Md,
  ZodCodec: () => rn,
  ZodCreditCard: () => dd,
  ZodCustom: () => nn,
  ZodCustomStringFormat: () => rr,
  ZodDate: () => Xr,
  ZodDefault: () => Cd,
  ZodDiscriminatedUnion: () => kd,
  ZodE164: () => mo,
  ZodEmail: () => Qi,
  ZodEmoji: () => eo,
  ZodEnum: () => er,
  ZodExactOptional: () => bo,
  ZodFile: () => Td,
  ZodFunction: () => Yd,
  ZodGUID: () => Yi,
  ZodIPv4: () => so,
  ZodIPv6: () => uo,
  ZodISODate: () => We,
  ZodISODateTime: () => Ke,
  ZodISODuration: () => Xe,
  ZodISOTime: () => Ge,
  ZodIntersection: () => Id,
  ZodJWT: () => go,
  ZodKSUID: () => ao,
  ZodLazy: () => Xd,
  ZodLiteral: () => Nd,
  ZodMAC: () => ld,
  ZodMap: () => Pd,
  ZodNaN: () => Jd,
  ZodNanoID: () => to,
  ZodNever: () => bd,
  ZodNonOptional: () => _o,
  ZodNull: () => hd,
  ZodNullable: () => Ed,
  ZodNumber: () => nr,
  ZodNumberFormat: () => $t,
  ZodObject: () => Qr,
  ZodOptional: () => en,
  ZodPipe: () => tn,
  ZodPrefault: () => Rd,
  ZodPreprocess: () => qd,
  ZodPromise: () => Qd,
  ZodReadonly: () => Kd,
  ZodRecord: () => Yt,
  ZodSet: () => Dd,
  ZodString: () => tr,
  ZodStringFormat: () => F,
  ZodSuccess: () => Vd,
  ZodSymbol: () => md,
  ZodTemplateLiteral: () => Gd,
  ZodTransform: () => Ad,
  ZodTuple: () => Sd,
  ZodType: () => N,
  ZodULID: () => io,
  ZodURL: () => Gr,
  ZodUUID: () => Oe,
  ZodUndefined: () => gd,
  ZodUnion: () => Yr,
  ZodUnknown: () => $d,
  ZodVoid: () => _d,
  ZodXID: () => oo,
  ZodXor: () => wd,
  _ZodString: () => Hi,
  _default: () => Zd,
  _function: () => Jm,
  any: () => xm,
  array: () => Hr,
  base64: () => im,
  base64url: () => om,
  bigint: () => vm,
  boolean: () => pd,
  catch: () => Bd,
  check: () => qm,
  cidrv4: () => rm,
  cidrv6: () => nm,
  codec: () => Lm,
  creditCard: () => sm,
  cuid: () => Wp,
  cuid2: () => Gp,
  custom: () => Km,
  date: () => km,
  describe: () => Wm,
  discriminatedUnion: () => Pm,
  e164: () => am,
  email: () => Zp,
  emoji: () => qp,
  enum: () => yo,
  exactOptional: () => Ud,
  file: () => Cm,
  float32: () => pm,
  float64: () => mm,
  function: () => Jm,
  guid: () => Rp,
  hash: () => fm,
  hex: () => dm,
  hostname: () => lm,
  httpUrl: () => Jp,
  instanceof: () => Xm,
  int: () => Gi,
  int32: () => gm,
  int64: () => ym,
  intersection: () => zd,
  invertCodec: () => Vm,
  ipv4: () => Yp,
  ipv6: () => tm,
  json: () => Qm,
  jwt: () => um,
  keyof: () => Im,
  ksuid: () => Qp,
  lazy: () => Hd,
  literal: () => Em,
  looseObject: () => Om,
  looseRecord: () => Nm,
  mac: () => em,
  map: () => Tm,
  meta: () => Gm,
  nan: () => Fm,
  nanoid: () => Kp,
  nativeEnum: () => Um,
  never: () => vo,
  nonoptional: () => Ld,
  null: () => vd,
  nullable: () => Wr,
  nullish: () => Zm,
  number: () => fd,
  object: () => zm,
  optional: () => vt,
  partialRecord: () => Dm,
  pipe: () => Xi,
  prefault: () => Fd,
  preprocess: () => Ym,
  promise: () => Bm,
  readonly: () => Wd,
  record: () => jd,
  refine: () => ef,
  set: () => Am,
  strictObject: () => Sm,
  string: () => Kr,
  stringFormat: () => cm,
  stringbool: () => Hm,
  success: () => Rm,
  superRefine: () => tf,
  symbol: () => bm,
  templateLiteral: () => Mm,
  transform: () => $o,
  tuple: () => Od,
  uint32: () => hm,
  uint64: () => $m,
  ulid: () => Xp,
  undefined: () => _m,
  union: () => ar,
  unknown: () => ht,
  url: () => Bp,
  uuid: () => Fp,
  uuidv4: () => Lp,
  uuidv6: () => Vp,
  uuidv7: () => Mp,
  void: () => wm,
  xid: () => Hp,
  xor: () => jm
});

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/checks.js
var Ki = {};
Pe(Ki, {
  endsWith: () => Bt,
  gt: () => ze,
  gte: () => ge,
  includes: () => Vt,
  length: () => gt,
  lowercase: () => Ft,
  lt: () => Ie,
  lte: () => me,
  maxLength: () => mt,
  maxSize: () => Me,
  mime: () => Jt,
  minLength: () => Te,
  minSize: () => Se,
  multipleOf: () => Ve,
  negative: () => Ci,
  nonnegative: () => Ri,
  nonpositive: () => Zi,
  normalize: () => qt,
  overwrite: () => _e,
  positive: () => Ei,
  properties: () => Li,
  property: () => Fi,
  regex: () => Rt,
  size: () => pt,
  slugify: () => Xt,
  startsWith: () => Mt,
  toLowerCase: () => Wt,
  toUpperCase: () => Gt,
  trim: () => Kt,
  uppercase: () => Lt
});

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/errors.js
var Ep = /* @__PURE__ */ new WeakSet([Object.prototype, Error.prototype]);
function Wi(e, r, i) {
  Object.defineProperty(e, r, {
    configurable: !0,
    enumerable: !1,
    get() {
      let o = i(this);
      return Object.defineProperty(this, r, { value: o, configurable: !0, writable: !0 }), o;
    },
    set(o) {
      Object.defineProperty(this, r, { value: o, configurable: !0, writable: !0 });
    }
  });
}
s(Wi, "_lazyMethod");
var Cp = /* @__PURE__ */ s((e, r) => {
  nt.init(e, r), e.name = "ZodError";
  let i = Object.getPrototypeOf(e);
  Ep.has(i) || (Ep.add(i), Wi(i, "format", (o) => (t) => Ir(o, t)), Wi(i, "flatten", (o) => (t) => kr(o, t)), Wi(i, "addIssue", (o) => (t) => {
    o.issues.push(t), o.message = JSON.stringify(o.issues, It, 2);
  }), Wi(i, "addIssues", (o) => (t) => {
    o.issues.push(...t), o.message = JSON.stringify(o.issues, It, 2);
  }), Object.defineProperty(i, "isEmpty", {
    configurable: !0,
    enumerable: !1,
    get() {
      return this.issues.length === 0;
    }
  }));
}, "initializer"), Eb = /* @__PURE__ */ m("ZodError", Cp), ce = /* @__PURE__ */ m("ZodError", Cp, void 0, {
  Parent: Error
});

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/parse.js
var Ql = /* @__PURE__ */ Ot(ce), Yl = /* @__PURE__ */ jt(ce), ed = /* @__PURE__ */ Pt(ce), td = /* @__PURE__ */ Dt(ce), rd = /* @__PURE__ */ Dn(ce), nd = /* @__PURE__ */ Nn(ce), id = /* @__PURE__ */ Tn(ce), od = /* @__PURE__ */ An(ce), ad = /* @__PURE__ */ Un(ce), sd = /* @__PURE__ */ En(ce), ud = /* @__PURE__ */ Cn(ce), cd = /* @__PURE__ */ Zn(ce);

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/schemas.js
function Zb() {
  X.localeError || K(Ur());
}
s(Zb, "_ensureDefaultLocale");
function yt() {
  X.memoizer || K({ memoizer: Ar() });
}
s(yt, "_ensureDefaultMemoizer");
var N = /* @__PURE__ */ m("ZodType", (e, r) => (Zb(), S.init(e, r), e.def = r, e.type = r.type, e), {
  check(...e) {
    let r = this.def;
    return this.clone(_.mergeDefs(r, {
      checks: [
        ...r.checks ?? [],
        ...e.map((i) => typeof i == "function" ? { _zod: { check: i, def: { check: "custom" }, onattach: [] } } : i)
      ]
    }), { parent: !0 });
  },
  with(...e) {
    return this.check(...e);
  },
  clone(e, r) {
    return A(this, e, r);
  },
  brand() {
    return this;
  },
  register(e, r) {
    return e.add(this, r), this;
  },
  refine(e, r) {
    return this.check(ef(e, r));
  },
  superRefine(e, r) {
    return this.check(tf(e, r));
  },
  overwrite(e) {
    return this.check(_e(e));
  },
  optional() {
    return vt(this);
  },
  exactOptional() {
    return Ud(this);
  },
  nullable() {
    return Wr(this);
  },
  nullish() {
    return vt(Wr(this));
  },
  nonoptional(e) {
    return Ld(this, e);
  },
  array() {
    return Hr(this);
  },
  or(e) {
    return ar([this, e]);
  },
  and(e) {
    return zd(this, e);
  },
  transform(e) {
    return Xi(this, $o(e));
  },
  default(e) {
    return Zd(this, e);
  },
  prefault(e) {
    return Fd(this, e);
  },
  catch(e) {
    return Bd(this, e);
  },
  pipe(e) {
    return Xi(this, e);
  },
  readonly() {
    return Wd(this);
  },
  describe(e) {
    let r = this.clone();
    return H.add(r, { description: e }), r;
  },
  meta(...e) {
    if (e.length === 0)
      return H.get(this);
    let r = this.clone();
    return H.add(r, e[0]), r;
  },
  isOptional() {
    return this.safeParse(void 0).success;
  },
  isNullable() {
    return this.safeParse(null).success;
  },
  apply(e, ...r) {
    return r.length === 0 ? e(this) : e(this, ...r);
  },
  // Overrides core's `~standard` to add `jsonSchema`. Must stay a prototype entry: redefining it per instance demotes instances to dictionary mode.
  get "~standard"() {
    return _.hide(this, "~standard", {
      ...Gn(this),
      jsonSchema: {
        input: Qt(this, "input"),
        output: Qt(this, "output")
      }
    });
  },
  set "~standard"(e) {
    _.own(this, "~standard", e);
  },
  parse: /* @__PURE__ */ s(function e(r, i) {
    return Ql(this, r, i, { callee: e });
  }, "_parse"),
  parseAsync: /* @__PURE__ */ s(async function e(r, i) {
    return await Yl(this, r, i, { callee: e });
  }, "_parseAsync"),
  safeParse(e, r) {
    return ed(this, e, r);
  },
  async safeParseAsync(e, r) {
    return td(this, e, r);
  },
  // `spa` is an alias: same function object as `safeParseAsync`, as before.
  get spa() {
    return this?.safeParseAsync;
  },
  set spa(e) {
    _.own(this, "spa", e);
  },
  encode: /* @__PURE__ */ s(function e(r, i) {
    return rd(this, r, i, { callee: e });
  }, "_encode"),
  decode: /* @__PURE__ */ s(function e(r, i) {
    return nd(this, r, i, { callee: e });
  }, "_decode"),
  encodeAsync: /* @__PURE__ */ s(async function e(r, i) {
    return await id(this, r, i, { callee: e });
  }, "_encodeAsync"),
  decodeAsync: /* @__PURE__ */ s(async function e(r, i) {
    return await od(this, r, i, { callee: e });
  }, "_decodeAsync"),
  safeEncode(e, r) {
    return ad(this, e, r);
  },
  safeDecode(e, r) {
    return sd(this, e, r);
  },
  async safeEncodeAsync(e, r) {
    return ud(this, e, r);
  },
  async safeDecodeAsync(e, r) {
    return cd(this, e, r);
  },
  toJSONSchema(e) {
    return dl(this, {})(e);
  },
  // Reads through to the registry on every access, so it must not cache.
  get description() {
    return H.get(this)?.description;
  },
  // No setter: `schema._def = x` throws, as it did when `_def` was a non-writable own property.
  get _def() {
    return this._zod.def;
  }
}), Hi = /* @__PURE__ */ m("_ZodString", (e, r) => {
  st.init(e, r), N.init(e, r), e._zod.processJSONSchema = (o, t, n) => ml(e, o, t, n);
  let i = e._zod.bag;
  e.format = i.format ?? null, e.minLength = i.minimum ?? null, e.maxLength = i.maximum ?? null;
}, {
  regex(...e) {
    return this.check(Rt(...e));
  },
  includes(...e) {
    return this.check(Vt(...e));
  },
  startsWith(...e) {
    return this.check(Mt(...e));
  },
  endsWith(...e) {
    return this.check(Bt(...e));
  },
  min(...e) {
    return this.check(Te(...e));
  },
  max(...e) {
    return this.check(mt(...e));
  },
  length(...e) {
    return this.check(gt(...e));
  },
  nonempty(...e) {
    return this.check(Te(1, ...e));
  },
  lowercase(e) {
    return this.check(Ft(e));
  },
  uppercase(e) {
    return this.check(Lt(e));
  },
  trim() {
    return this.check(Kt());
  },
  normalize(...e) {
    return this.check(qt(...e));
  },
  toLowerCase() {
    return this.check(Wt());
  },
  toUpperCase() {
    return this.check(Gt());
  },
  slugify() {
    return this.check(Xt());
  }
}), tr = /* @__PURE__ */ m("ZodString", (e, r) => {
  st.init(e, r), Hi.init(e, r);
}, {
  email(e) {
    return this.check(gi(Qi, e));
  },
  url(e) {
    return this.check(Fr(Gr, e));
  },
  jwt(e) {
    return this.check(Ui(go, e));
  },
  emoji(e) {
    return this.check(_i(eo, e));
  },
  guid(e) {
    return this.check(hi(Yi, e));
  },
  uuid(e) {
    return this.check(vi(Oe, e));
  },
  uuidv4(e) {
    return this.check(yi(Oe, e));
  },
  uuidv6(e) {
    return this.check($i(Oe, e));
  },
  uuidv7(e) {
    return this.check(bi(Oe, e));
  },
  nanoid(e) {
    return this.check(xi(to, e));
  },
  cuid(e) {
    return this.check(wi(ro, e));
  },
  cuid2(e) {
    return this.check(ki(no, e));
  },
  ulid(e) {
    return this.check(Ii(io, e));
  },
  base64(e) {
    return this.check(Ni(fo, e));
  },
  base64url(e) {
    return this.check(Ti(po, e));
  },
  xid(e) {
    return this.check(zi(oo, e));
  },
  ksuid(e) {
    return this.check(Si(ao, e));
  },
  ipv4(e) {
    return this.check(Oi(so, e));
  },
  ipv6(e) {
    return this.check(ji(uo, e));
  },
  cidrv4(e) {
    return this.check(Pi(co, e));
  },
  cidrv6(e) {
    return this.check(Di(lo, e));
  },
  e164(e) {
    return this.check(Ai(mo, e));
  },
  datetime(e) {
    return this.check(Lr(Ke, e));
  },
  date(e) {
    return this.check(Vr(We, e));
  },
  time(e) {
    return this.check(Mr(Ge, e));
  },
  duration(e) {
    return this.check(Br(Xe, e));
  }
});
function Kr(e) {
  return Oc(tr, e);
}
s(Kr, "string");
var F = /* @__PURE__ */ m("ZodStringFormat", (e, r) => {
  R.init(e, r), Hi.init(e, r);
}), Ke = /* @__PURE__ */ m("ZodISODateTime", (e, r) => {
  ws.init(e, r), F.init(e, r);
}), We = /* @__PURE__ */ m("ZodISODate", (e, r) => {
  ks.init(e, r), F.init(e, r);
}), Ge = /* @__PURE__ */ m("ZodISOTime", (e, r) => {
  Is.init(e, r), F.init(e, r);
}), Xe = /* @__PURE__ */ m("ZodISODuration", (e, r) => {
  zs.init(e, r), F.init(e, r);
}), Qi = /* @__PURE__ */ m("ZodEmail", (e, r) => {
  fs.init(e, r), F.init(e, r);
});
function Zp(e) {
  return gi(Qi, e);
}
s(Zp, "email");
var Yi = /* @__PURE__ */ m("ZodGUID", (e, r) => {
  ls.init(e, r), F.init(e, r);
});
function Rp(e) {
  return hi(Yi, e);
}
s(Rp, "guid");
var Oe = /* @__PURE__ */ m("ZodUUID", (e, r) => {
  ds.init(e, r), F.init(e, r);
});
function Fp(e) {
  return vi(Oe, e);
}
s(Fp, "uuid");
function Lp(e) {
  return yi(Oe, e);
}
s(Lp, "uuidv4");
function Vp(e) {
  return $i(Oe, e);
}
s(Vp, "uuidv6");
function Mp(e) {
  return bi(Oe, e);
}
s(Mp, "uuidv7");
var Gr = /* @__PURE__ */ m("ZodURL", (e, r) => {
  gs.init(e, r), F.init(e, r);
});
function Bp(e) {
  return Fr(Gr, e);
}
s(Bp, "url");
function Jp(e) {
  return Fr(Gr, {
    protocol: te.httpProtocol,
    hostname: te.domain,
    ..._.normalizeParams(e)
  });
}
s(Jp, "httpUrl");
var eo = /* @__PURE__ */ m("ZodEmoji", (e, r) => {
  hs.init(e, r), F.init(e, r);
});
function qp(e) {
  return _i(eo, e);
}
s(qp, "emoji");
var to = /* @__PURE__ */ m("ZodNanoID", (e, r) => {
  vs.init(e, r), F.init(e, r);
});
function Kp(e) {
  return xi(to, e);
}
s(Kp, "nanoid");
var ro = /* @__PURE__ */ m("ZodCUID", (e, r) => {
  ys.init(e, r), F.init(e, r);
});
function Wp(e) {
  return wi(ro, e);
}
s(Wp, "cuid");
var no = /* @__PURE__ */ m("ZodCUID2", (e, r) => {
  $s.init(e, r), F.init(e, r);
});
function Gp(e) {
  return ki(no, e);
}
s(Gp, "cuid2");
var io = /* @__PURE__ */ m("ZodULID", (e, r) => {
  bs.init(e, r), F.init(e, r);
});
function Xp(e) {
  return Ii(io, e);
}
s(Xp, "ulid");
var oo = /* @__PURE__ */ m("ZodXID", (e, r) => {
  _s.init(e, r), F.init(e, r);
});
function Hp(e) {
  return zi(oo, e);
}
s(Hp, "xid");
var ao = /* @__PURE__ */ m("ZodKSUID", (e, r) => {
  xs.init(e, r), F.init(e, r);
});
function Qp(e) {
  return Si(ao, e);
}
s(Qp, "ksuid");
var so = /* @__PURE__ */ m("ZodIPv4", (e, r) => {
  Ss.init(e, r), F.init(e, r);
});
function Yp(e) {
  return Oi(so, e);
}
s(Yp, "ipv4");
var ld = /* @__PURE__ */ m("ZodMAC", (e, r) => {
  js.init(e, r), F.init(e, r);
});
function em(e) {
  return Pc(ld, e);
}
s(em, "mac");
var uo = /* @__PURE__ */ m("ZodIPv6", (e, r) => {
  Os.init(e, r), F.init(e, r);
});
function tm(e) {
  return ji(uo, e);
}
s(tm, "ipv6");
var co = /* @__PURE__ */ m("ZodCIDRv4", (e, r) => {
  Ps.init(e, r), F.init(e, r);
});
function rm(e) {
  return Pi(co, e);
}
s(rm, "cidrv4");
var lo = /* @__PURE__ */ m("ZodCIDRv6", (e, r) => {
  Ds.init(e, r), F.init(e, r);
});
function nm(e) {
  return Di(lo, e);
}
s(nm, "cidrv6");
var fo = /* @__PURE__ */ m("ZodBase64", (e, r) => {
  Ns.init(e, r), F.init(e, r);
});
function im(e) {
  return Ni(fo, e);
}
s(im, "base64");
var po = /* @__PURE__ */ m("ZodBase64URL", (e, r) => {
  Ts.init(e, r), F.init(e, r);
});
function om(e) {
  return Ti(po, e);
}
s(om, "base64url");
var mo = /* @__PURE__ */ m("ZodE164", (e, r) => {
  As.init(e, r), F.init(e, r);
});
function am(e) {
  return Ai(mo, e);
}
s(am, "e164");
var dd = /* @__PURE__ */ m("ZodCreditCard", (e, r) => {
  Us.init(e, r), F.init(e, r);
});
function sm(e) {
  return Dc(dd, e);
}
s(sm, "creditCard");
var go = /* @__PURE__ */ m("ZodJWT", (e, r) => {
  Es.init(e, r), F.init(e, r);
});
function um(e) {
  return Ui(go, e);
}
s(um, "jwt");
var rr = /* @__PURE__ */ m("ZodCustomStringFormat", (e, r) => {
  Cs.init(e, r), F.init(e, r);
});
function cm(e, r, i = {}) {
  return Ht(rr, e, r, i);
}
s(cm, "stringFormat");
function lm(e) {
  return Ht(rr, "hostname", te.hostname, e);
}
s(lm, "hostname");
function dm(e) {
  return Ht(rr, "hex", te.hex, e);
}
s(dm, "hex");
function fm(e, r) {
  let i = r?.enc ?? "hex", o = `${e}_${i}`, t = te[o];
  if (!t)
    throw new Error(`Unrecognized hash format: ${o}`);
  return Ht(rr, o, t, r);
}
s(fm, "hash");
var nr = /* @__PURE__ */ m("ZodNumber", (e, r) => {
  ii.init(e, r), N.init(e, r), e._zod.processJSONSchema = (o, t, n) => gl(e, o, t, n);
  let i = e._zod.bag;
  e.minValue = Math.max(i.minimum ?? Number.NEGATIVE_INFINITY, i.exclusiveMinimum ?? Number.NEGATIVE_INFINITY) ?? null, e.maxValue = Math.min(i.maximum ?? Number.POSITIVE_INFINITY, i.exclusiveMaximum ?? Number.POSITIVE_INFINITY) ?? null, e.isInt = (i.format ?? "").includes("int") || Number.isSafeInteger(i.multipleOf ?? 0.5), e.isFinite = !0, e.format = i.format ?? null;
}, {
  gt(e, r) {
    return this.check(ze(e, r));
  },
  gte(e, r) {
    return this.check(ge(e, r));
  },
  min(e, r) {
    return this.check(ge(e, r));
  },
  lt(e, r) {
    return this.check(Ie(e, r));
  },
  lte(e, r) {
    return this.check(me(e, r));
  },
  max(e, r) {
    return this.check(me(e, r));
  },
  int(e) {
    return this.check(Gi(e));
  },
  safe(e) {
    return this.check(Gi(e));
  },
  positive(e) {
    return this.check(ze(0, e));
  },
  nonnegative(e) {
    return this.check(ge(0, e));
  },
  negative(e) {
    return this.check(Ie(0, e));
  },
  nonpositive(e) {
    return this.check(me(0, e));
  },
  multipleOf(e, r) {
    return this.check(Ve(e, r));
  },
  step(e, r) {
    return this.check(Ve(e, r));
  },
  finite() {
    return this;
  }
});
function fd(e) {
  return Tc(nr, e);
}
s(fd, "number");
var $t = /* @__PURE__ */ m("ZodNumberFormat", (e, r) => {
  Zs.init(e, r), nr.init(e, r);
});
function Gi(e) {
  return Uc($t, e);
}
s(Gi, "int");
function pm(e) {
  return Ec($t, e);
}
s(pm, "float32");
function mm(e) {
  return Cc($t, e);
}
s(mm, "float64");
function gm(e) {
  return Zc($t, e);
}
s(gm, "int32");
function hm(e) {
  return Rc($t, e);
}
s(hm, "uint32");
var ir = /* @__PURE__ */ m("ZodBoolean", (e, r) => {
  Nr.init(e, r), N.init(e, r), e._zod.processJSONSchema = (i, o, t) => hl(e, i, o, t);
});
function pd(e) {
  return Fc(ir, e);
}
s(pd, "boolean");
var or = /* @__PURE__ */ m("ZodBigInt", (e, r) => {
  oi.init(e, r), N.init(e, r), e._zod.processJSONSchema = (o, t, n) => vl(e, o, t, n);
  let i = e._zod.bag;
  e.minValue = i.minimum ?? null, e.maxValue = i.maximum ?? null, e.format = i.format ?? null;
}, {
  gte(e, r) {
    return this.check(ge(e, r));
  },
  min(e, r) {
    return this.check(ge(e, r));
  },
  gt(e, r) {
    return this.check(ze(e, r));
  },
  lt(e, r) {
    return this.check(Ie(e, r));
  },
  lte(e, r) {
    return this.check(me(e, r));
  },
  max(e, r) {
    return this.check(me(e, r));
  },
  positive(e) {
    return this.check(ze(BigInt(0), e));
  },
  negative(e) {
    return this.check(Ie(BigInt(0), e));
  },
  nonpositive(e) {
    return this.check(me(BigInt(0), e));
  },
  nonnegative(e) {
    return this.check(ge(BigInt(0), e));
  },
  multipleOf(e, r) {
    return this.check(Ve(e, r));
  }
});
function vm(e) {
  return Vc(or, e);
}
s(vm, "bigint");
var ho = /* @__PURE__ */ m("ZodBigIntFormat", (e, r) => {
  Rs.init(e, r), or.init(e, r);
});
function ym(e) {
  return Bc(ho, e);
}
s(ym, "int64");
function $m(e) {
  return Jc(ho, e);
}
s($m, "uint64");
var md = /* @__PURE__ */ m("ZodSymbol", (e, r) => {
  Fs.init(e, r), N.init(e, r), e._zod.processJSONSchema = (i, o, t) => yl(e, i, o, t);
});
function bm(e) {
  return qc(md, e);
}
s(bm, "symbol");
var gd = /* @__PURE__ */ m("ZodUndefined", (e, r) => {
  Ls.init(e, r), N.init(e, r), e._zod.processJSONSchema = (i, o, t) => bl(e, i, o, t);
});
function _m(e) {
  return Kc(gd, e);
}
s(_m, "_undefined");
var hd = /* @__PURE__ */ m("ZodNull", (e, r) => {
  Vs.init(e, r), N.init(e, r), e._zod.processJSONSchema = (i, o, t) => $l(e, i, o, t);
});
function vd(e) {
  return Wc(hd, e);
}
s(vd, "_null");
var yd = /* @__PURE__ */ m("ZodAny", (e, r) => {
  Ms.init(e, r), N.init(e, r), e._zod.processJSONSchema = (i, o, t) => wl(e, i, o, t);
});
function xm() {
  return Gc(yd);
}
s(xm, "any");
var $d = /* @__PURE__ */ m("ZodUnknown", (e, r) => {
  Bs.init(e, r), N.init(e, r), e._zod.processJSONSchema = (i, o, t) => kl(e, i, o, t);
});
function ht() {
  return Xc($d);
}
s(ht, "unknown");
var bd = /* @__PURE__ */ m("ZodNever", (e, r) => {
  Js.init(e, r), N.init(e, r), e._zod.processJSONSchema = (i, o, t) => xl(e, i, o, t);
});
function vo(e) {
  return Hc(bd, e);
}
s(vo, "never");
var _d = /* @__PURE__ */ m("ZodVoid", (e, r) => {
  qs.init(e, r), N.init(e, r), e._zod.processJSONSchema = (i, o, t) => _l(e, i, o, t);
});
function wm(e) {
  return Qc(_d, e);
}
s(wm, "_void");
var Xr = /* @__PURE__ */ m("ZodDate", (e, r) => {
  Tr.init(e, r), N.init(e, r), e._zod.processJSONSchema = (o, t, n) => Il(e, o, t, n), e.min = (o, t) => e.check(ge(o, t)), e.max = (o, t) => e.check(me(o, t));
  let i = e._zod.bag;
  e.minDate = i.minimum ? new Date(i.minimum) : null, e.maxDate = i.maximum ? new Date(i.maximum) : null;
});
function km(e) {
  return Yc(Xr, e);
}
s(km, "date");
var xd = /* @__PURE__ */ m("ZodArray", (e, r) => {
  yt(), At.init(e, r), N.init(e, r), e._zod.processJSONSchema = (i, o, t) => Cl(e, i, o, t), e.element = r.element;
}, {
  min(e, r) {
    return this.check(Te(e, r));
  },
  nonempty(e) {
    return this.check(Te(1, e));
  },
  max(e, r) {
    return this.check(mt(e, r));
  },
  length(e, r) {
    return this.check(gt(e, r));
  },
  unwrap() {
    return this.element;
  }
});
function Hr(e, r) {
  return rl(xd, e, r);
}
s(Hr, "array");
function Im(e) {
  let r = e._zod.def.shape;
  return yo(Object.keys(r));
}
s(Im, "keyof");
var Qr = /* @__PURE__ */ m("ZodObject", (e, r) => {
  yt(), Ks.init(e, r), N.init(e, r), e._zod.processJSONSchema = (i, o, t) => Zl(e, i, o, t), _.installLazyProp(e, "shape", (i) => i._zod.def.shape, !1);
}, {
  keyof() {
    return yo(Object.keys(this._zod.def.shape));
  },
  catchall(e) {
    return this.clone({ ...this._zod.def, catchall: e });
  },
  passthrough() {
    return this.clone({ ...this._zod.def, catchall: ht() });
  },
  loose() {
    return this.clone({ ...this._zod.def, catchall: ht() });
  },
  strict() {
    return this.clone({ ...this._zod.def, catchall: vo() });
  },
  strip() {
    return this.clone({ ...this._zod.def, catchall: void 0 });
  },
  extend(e) {
    return _.extend(this, e);
  },
  safeExtend(e) {
    return _.safeExtend(this, e);
  },
  merge(e) {
    return _.merge(this, e);
  },
  pick(e) {
    return _.pick(this, e);
  },
  omit(e) {
    return _.omit(this, e);
  },
  partial(...e) {
    return _.partial(en, this, e[0]);
  },
  exactPartial(...e) {
    return _.partial(bo, this, e[0], "exactPartial");
  },
  required(...e) {
    return _.required(_o, this, e[0]);
  }
});
function zm(e, r) {
  let i = {
    type: "object",
    shape: e ?? {},
    ..._.normalizeParams(r)
  };
  return new Qr(i);
}
s(zm, "object");
function Sm(e, r) {
  return new Qr({
    type: "object",
    shape: e,
    catchall: vo(),
    ..._.normalizeParams(r)
  });
}
s(Sm, "strictObject");
function Om(e, r) {
  return new Qr({
    type: "object",
    shape: e,
    catchall: ht(),
    ..._.normalizeParams(r)
  });
}
s(Om, "looseObject");
var Yr = /* @__PURE__ */ m("ZodUnion", (e, r) => {
  fe.init(e, r), N.init(e, r), e._zod.processJSONSchema = (i, o, t) => Mi(e, i, o, t), e.options = r.options;
});
function ar(e, r) {
  return new Yr({
    type: "union",
    options: e,
    ..._.normalizeParams(r)
  });
}
s(ar, "union");
var wd = /* @__PURE__ */ m("ZodXor", (e, r) => {
  Yr.init(e, r), Ws.init(e, r), e._zod.processJSONSchema = (i, o, t) => Mi(e, i, o, t), e.options = r.options;
});
function jm(e, r) {
  return new wd({
    type: "union",
    options: e,
    inclusive: !1,
    ..._.normalizeParams(r)
  });
}
s(jm, "xor");
var kd = /* @__PURE__ */ m("ZodDiscriminatedUnion", (e, r) => {
  Yr.init(e, r), Re.init(e, r);
});
function Pm(e, r, i) {
  return new kd({
    type: "union",
    options: r,
    discriminator: e,
    ..._.normalizeParams(i)
  });
}
s(Pm, "discriminatedUnion");
var Id = /* @__PURE__ */ m("ZodIntersection", (e, r) => {
  Xs.init(e, r), N.init(e, r), e._zod.processJSONSchema = (i, o, t) => Rl(e, i, o, t);
});
function zd(e, r) {
  return new Id({
    type: "intersection",
    left: e,
    right: r
  });
}
s(zd, "intersection");
var Sd = /* @__PURE__ */ m("ZodTuple", (e, r) => {
  yt(), ut.init(e, r), N.init(e, r), e._zod.processJSONSchema = (i, o, t) => Fl(e, i, o, t);
}, {
  rest(e) {
    return this.clone({
      ...this._zod.def,
      rest: e
    });
  },
  partial() {
    let e = this._zod.def;
    if (e.checks?.length)
      throw new Error(".partial() cannot be used on tuple schemas containing refinements");
    return this.clone({
      ...e,
      items: e.items.map((r) => new en({ type: "optional", innerType: r }))
    });
  }
});
function Od(e, r, i) {
  let o = r instanceof S, t = o ? i : r, n = o ? r : null;
  return new Sd({
    type: "tuple",
    items: e,
    rest: n,
    ..._.normalizeParams(t)
  });
}
s(Od, "tuple");
var Yt = /* @__PURE__ */ m("ZodRecord", (e, r) => {
  yt(), Ut.init(e, r), N.init(e, r), e._zod.processJSONSchema = (i, o, t) => Ll(e, i, o, t), e.keyType = r.keyType, e.valueType = r.valueType;
});
function jd(e, r, i) {
  return !r || !r._zod ? new Yt({
    type: "record",
    keyType: Kr(),
    valueType: e,
    ..._.normalizeParams(r)
  }) : new Yt({
    type: "record",
    keyType: e,
    valueType: r,
    ..._.normalizeParams(i)
  });
}
s(jd, "record");
function Dm(e, r, i) {
  return new Yt({
    type: "record",
    keyType: e,
    valueType: r,
    ..._.normalizeParams(i),
    partial: !0
  });
}
s(Dm, "partialRecord");
function Nm(e, r, i) {
  return new Yt({
    type: "record",
    keyType: e,
    valueType: r,
    mode: "loose",
    ..._.normalizeParams(i)
  });
}
s(Nm, "looseRecord");
var Pd = /* @__PURE__ */ m("ZodMap", (e, r) => {
  yt(), Hs.init(e, r), N.init(e, r), e._zod.processJSONSchema = (i, o, t) => Ul(e, i, o, t), e.keyType = r.keyType, e.valueType = r.valueType, e.min = (...i) => e.check(Se(...i)), e.nonempty = (i) => e.check(Se(1, i)), e.max = (...i) => e.check(Me(...i)), e.size = (...i) => e.check(pt(...i));
});
function Tm(e, r, i) {
  return new Pd({
    type: "map",
    keyType: e,
    valueType: r,
    ..._.normalizeParams(i)
  });
}
s(Tm, "map");
var Dd = /* @__PURE__ */ m("ZodSet", (e, r) => {
  yt(), Qs.init(e, r), N.init(e, r), e._zod.processJSONSchema = (i, o, t) => El(e, i, o, t), e.min = (...i) => e.check(Se(...i)), e.nonempty = (i) => e.check(Se(1, i)), e.max = (...i) => e.check(Me(...i)), e.size = (...i) => e.check(pt(...i));
});
function Am(e, r) {
  return new Dd({
    type: "set",
    valueType: e,
    ..._.normalizeParams(r)
  });
}
s(Am, "set");
var er = /* @__PURE__ */ m("ZodEnum", (e, r) => {
  Et.init(e, r), N.init(e, r), e._zod.processJSONSchema = (o, t, n) => zl(e, o, t, n), e.enum = r.entries, e.options = Object.values(r.entries);
  let i = new Set(Object.keys(r.entries));
  e.extract = (o, t) => {
    let n = {};
    for (let a of o)
      if (i.has(a))
        n[a] = r.entries[a];
      else
        throw new Error(`Key ${a} not found in enum`);
    return new er({
      ...r,
      checks: [],
      ..._.normalizeParams(t),
      entries: n
    });
  }, e.exclude = (o, t) => {
    let n = { ...r.entries };
    for (let a of o)
      if (i.has(a))
        delete n[a];
      else
        throw new Error(`Key ${a} not found in enum`);
    return new er({
      ...r,
      checks: [],
      ..._.normalizeParams(t),
      entries: n
    });
  };
});
function yo(e, r) {
  let i = Array.isArray(e) ? Object.fromEntries(e.map((o) => [o, o])) : e;
  return new er({
    type: "enum",
    entries: i,
    ..._.normalizeParams(r)
  });
}
s(yo, "_enum");
function Um(e, r) {
  return new er({
    type: "enum",
    entries: e,
    ..._.normalizeParams(r)
  });
}
s(Um, "nativeEnum");
var Nd = /* @__PURE__ */ m("ZodLiteral", (e, r) => {
  Ct.init(e, r), N.init(e, r), e._zod.processJSONSchema = (i, o, t) => Sl(e, i, o, t), e.values = new Set(r.values), Object.defineProperty(e, "value", {
    get() {
      if (r.values.length > 1)
        throw new Error("This schema contains multiple valid literal values. Use `.values` instead.");
      return r.values[0];
    }
  });
});
function Em(e, r) {
  return new Nd({
    type: "literal",
    values: Array.isArray(e) ? e : [e],
    ..._.normalizeParams(r)
  });
}
s(Em, "literal");
var Td = /* @__PURE__ */ m("ZodFile", (e, r) => {
  Ys.init(e, r), N.init(e, r), e._zod.processJSONSchema = (i, o, t) => Pl(e, i, o, t), e.min = (i, o) => e.check(Se(i, o)), e.max = (i, o) => e.check(Me(i, o)), e.mime = (i, o) => e.check(Jt(Array.isArray(i) ? i : [i], o));
});
function Cm(e) {
  return nl(Td, e);
}
s(Cm, "file");
var Ad = /* @__PURE__ */ m("ZodTransform", (e, r) => {
  yt(), eu.init(e, r), N.init(e, r), e._zod.processJSONSchema = (i, o, t) => Al(e, i, o, t), e._zod.parse = (i, o) => {
    if (o.direction === "backward")
      throw new Ce(e.constructor.name);
    i.addIssue = (n) => {
      if (typeof n == "string")
        i.issues.push(_.issue(n, i.value, r));
      else {
        let a = n;
        a.fatal && (a.continue = !1), a.code ?? (a.code = "custom"), "input" in a || (a.input = i.value), a.inst ?? (a.inst = e), i.issues.push(_.issue(a));
      }
    };
    let t = r.transform(i.value, i);
    return t instanceof Promise ? t.then((n) => (i.value = n, i)) : (i.value = t, i);
  };
});
function $o(e) {
  return new Ad({
    type: "transform",
    transform: e
  });
}
s($o, "transform");
var en = /* @__PURE__ */ m("ZodOptional", (e, r) => {
  W.init(e, r), N.init(e, r), e._zod.processJSONSchema = (i, o, t) => Bi(e, i, o, t), e.unwrap = () => e._zod.def.innerType;
});
function vt(e) {
  return new en({
    type: "optional",
    innerType: e
  });
}
s(vt, "optional");
var bo = /* @__PURE__ */ m("ZodExactOptional", (e, r) => {
  tu.init(e, r), N.init(e, r), e._zod.processJSONSchema = (i, o, t) => Bi(e, i, o, t), e.unwrap = () => e._zod.def.innerType;
});
function Ud(e) {
  return new bo({
    type: "optional",
    innerType: e
  });
}
s(Ud, "exactOptional");
var Ed = /* @__PURE__ */ m("ZodNullable", (e, r) => {
  Ne.init(e, r), N.init(e, r), e._zod.processJSONSchema = (i, o, t) => Vl(e, i, o, t), e.unwrap = () => e._zod.def.innerType;
});
function Wr(e) {
  return new Ed({
    type: "nullable",
    innerType: e
  });
}
s(Wr, "nullable");
function Zm(e) {
  return vt(Wr(e));
}
s(Zm, "nullish");
var Cd = /* @__PURE__ */ m("ZodDefault", (e, r) => {
  ke.init(e, r), N.init(e, r), e._zod.processJSONSchema = (i, o, t) => Jl(e, i, o, t), e.unwrap = () => e._zod.def.innerType, e.removeDefault = e.unwrap;
});
function Zd(e, r) {
  return new Cd({
    type: "default",
    innerType: e,
    get defaultValue() {
      return typeof r == "function" ? r() : _.shallowClone(r);
    }
  });
}
s(Zd, "_default");
var Rd = /* @__PURE__ */ m("ZodPrefault", (e, r) => {
  ru.init(e, r), N.init(e, r), e._zod.processJSONSchema = (i, o, t) => ql(e, i, o, t), e.unwrap = () => e._zod.def.innerType;
});
function Fd(e, r) {
  return new Rd({
    type: "prefault",
    innerType: e,
    get defaultValue() {
      return typeof r == "function" ? r() : _.shallowClone(r);
    }
  });
}
s(Fd, "prefault");
var _o = /* @__PURE__ */ m("ZodNonOptional", (e, r) => {
  nu.init(e, r), N.init(e, r), e._zod.processJSONSchema = (i, o, t) => Ml(e, i, o, t), e.unwrap = () => e._zod.def.innerType;
});
function Ld(e, r) {
  return new _o({
    type: "nonoptional",
    innerType: e,
    ..._.normalizeParams(r)
  });
}
s(Ld, "nonoptional");
var Vd = /* @__PURE__ */ m("ZodSuccess", (e, r) => {
  iu.init(e, r), N.init(e, r), e._zod.processJSONSchema = (i, o, t) => Dl(e, i, o, t), e.unwrap = () => e._zod.def.innerType;
});
function Rm(e) {
  return new Vd({
    type: "success",
    innerType: e
  });
}
s(Rm, "success");
var Md = /* @__PURE__ */ m("ZodCatch", (e, r) => {
  ou.init(e, r), N.init(e, r), e._zod.processJSONSchema = (i, o, t) => Kl(e, i, o, t), e.unwrap = () => e._zod.def.innerType, e.removeCatch = e.unwrap;
});
function Bd(e, r) {
  return new Md({
    type: "catch",
    innerType: e,
    catchValue: typeof r == "function" ? r : _.constantCatch(r)
  });
}
s(Bd, "_catch");
var Jd = /* @__PURE__ */ m("ZodNaN", (e, r) => {
  au.init(e, r), N.init(e, r), e._zod.processJSONSchema = (i, o, t) => Ol(e, i, o, t);
});
function Fm(e) {
  return tl(Jd, e);
}
s(Fm, "nan");
var tn = /* @__PURE__ */ m("ZodPipe", (e, r) => {
  ai.init(e, r), N.init(e, r), e._zod.processJSONSchema = (i, o, t) => Wl(e, i, o, t), e.in = r.in, e.out = r.out;
});
function Xi(e, r) {
  return new tn({
    type: "pipe",
    in: e,
    out: r
    // ...util.normalizeParams(params),
  });
}
s(Xi, "pipe");
var rn = /* @__PURE__ */ m("ZodCodec", (e, r) => {
  tn.init(e, r), Fe.init(e, r);
});
function Lm(e, r, i) {
  return new rn({
    type: "pipe",
    in: e,
    out: r,
    transform: i.decode,
    reverseTransform: i.encode
  });
}
s(Lm, "codec");
function Vm(e) {
  let r = e._zod.def;
  return new rn({
    type: "pipe",
    in: r.out,
    out: r.in,
    transform: r.reverseTransform,
    reverseTransform: r.transform
  });
}
s(Vm, "invertCodec");
var qd = /* @__PURE__ */ m("ZodPreprocess", (e, r) => {
  tn.init(e, r), su.init(e, r);
}), Kd = /* @__PURE__ */ m("ZodReadonly", (e, r) => {
  uu.init(e, r), N.init(e, r), e._zod.processJSONSchema = (i, o, t) => Gl(e, i, o, t), e.unwrap = () => e._zod.def.innerType;
});
function Wd(e) {
  return new Kd({
    type: "readonly",
    innerType: e
  });
}
s(Wd, "readonly");
var Gd = /* @__PURE__ */ m("ZodTemplateLiteral", (e, r) => {
  cu.init(e, r), N.init(e, r), e._zod.processJSONSchema = (i, o, t) => jl(e, i, o, t);
});
function Mm(e, r) {
  return new Gd({
    type: "template_literal",
    parts: e,
    ..._.normalizeParams(r)
  });
}
s(Mm, "templateLiteral");
var Xd = /* @__PURE__ */ m("ZodLazy", (e, r) => {
  Le.init(e, r), N.init(e, r), e._zod.processJSONSchema = (i, o, t) => Hl(e, i, o, t), e.unwrap = () => e._zod.def.getter();
});
function Hd(e) {
  return new Xd({
    type: "lazy",
    getter: e
  });
}
s(Hd, "lazy");
var Qd = /* @__PURE__ */ m("ZodPromise", (e, r) => {
  du.init(e, r), N.init(e, r), e._zod.processJSONSchema = (i, o, t) => Xl(e, i, o, t), e.unwrap = () => e._zod.def.innerType;
});
function Bm(e) {
  return new Qd({
    type: "promise",
    innerType: e
  });
}
s(Bm, "promise");
var Yd = /* @__PURE__ */ m("ZodFunction", (e, r) => {
  lu.init(e, r), N.init(e, r), e._zod.processJSONSchema = (i, o, t) => Tl(e, i, o, t);
});
function Jm(e) {
  return new Yd({
    type: "function",
    input: Array.isArray(e?.input) ? Od(e?.input) : e?.input ?? Hr(ht()),
    output: e?.output ?? ht()
  });
}
s(Jm, "_function");
var nn = /* @__PURE__ */ m("ZodCustom", (e, r) => {
  si.init(e, r), N.init(e, r), e._zod.processJSONSchema = (i, o, t) => Nl(e, i, o, t);
});
function qm(e) {
  let r = new L({
    check: "custom"
    // ...util.normalizeParams(params),
  });
  return r._zod.check = e, r;
}
s(qm, "check");
function Km(e, r) {
  return il(nn, e ?? (() => !0), r);
}
s(Km, "custom");
function ef(e, r = {}) {
  return ol(nn, e, r);
}
s(ef, "refine");
function tf(e, r) {
  return al(e, r);
}
s(tf, "superRefine");
var Wm = sl, Gm = ul;
function Xm(e, r = {}) {
  let i = new nn({
    type: "custom",
    check: "custom",
    fn: /* @__PURE__ */ s((o) => o instanceof e, "fn"),
    abort: !0,
    ..._.normalizeParams(r)
  });
  return i._zod.bag.Class = e, i._zod.check = (o) => {
    o.value instanceof e || o.issues.push({
      code: "invalid_type",
      expected: e.name,
      input: o.value,
      inst: i,
      path: [...i._zod.def.path ?? []]
    });
  }, i;
}
s(Xm, "_instanceof");
var Hm = /* @__PURE__ */ s((...e) => cl({
  Codec: rn,
  Boolean: ir,
  String: tr
}, ...e), "stringbool");
function Qm(e) {
  let r = Hd(() => ar([Kr(e), fd(), pd(), vd(), Hr(r), jd(Kr(), r)]));
  return r;
}
s(Qm, "json");
function Ym(e, r) {
  return new qd({
    type: "pipe",
    in: $o(e),
    out: r
  });
}
s(Ym, "preprocess");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/compat.js
var Rb = {
  invalid_type: "invalid_type",
  too_big: "too_big",
  too_small: "too_small",
  invalid_format: "invalid_format",
  not_multiple_of: "not_multiple_of",
  unrecognized_keys: "unrecognized_keys",
  invalid_union: "invalid_union",
  invalid_key: "invalid_key",
  invalid_element: "invalid_element",
  invalid_value: "invalid_value",
  custom: "custom"
};
function Fb(e) {
  K({
    customError: e
  });
}
s(Fb, "setErrorMap");
function Lb() {
  return K().customError;
}
s(Lb, "getErrorMap");
var rf;
rf || (rf = {});

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/iso.js
var on = {};
Pe(on, {
  ZodISODate: () => We,
  ZodISODateTime: () => Ke,
  ZodISODuration: () => Xe,
  ZodISOTime: () => Ge,
  date: () => Mb,
  datetime: () => Vb,
  duration: () => Jb,
  time: () => Bb
});
function Vb(e) {
  return Lr(Ke, e);
}
s(Vb, "datetime");
function Mb(e) {
  return Vr(We, e);
}
s(Mb, "date");
function Bb(e) {
  return Mr(Ge, e);
}
s(Bb, "time");
function Jb(e) {
  return Br(Xe, e);
}
s(Jb, "duration");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/from-json-schema.js
var I = {
  ...sr,
  ...Ki,
  iso: on
}, qb = /* @__PURE__ */ new Set([
  // Schema identification
  "$schema",
  "$ref",
  "$defs",
  "definitions",
  // Core schema keywords
  "$id",
  "id",
  "$comment",
  "$anchor",
  "$vocabulary",
  "$dynamicRef",
  "$dynamicAnchor",
  // Type
  "type",
  "enum",
  "const",
  // Composition
  "anyOf",
  "oneOf",
  "allOf",
  "not",
  // Object
  "properties",
  "required",
  "additionalProperties",
  "patternProperties",
  "propertyNames",
  "minProperties",
  "maxProperties",
  // Array
  "items",
  "prefixItems",
  "additionalItems",
  "minItems",
  "maxItems",
  "uniqueItems",
  "contains",
  "minContains",
  "maxContains",
  // String
  "minLength",
  "maxLength",
  "pattern",
  "format",
  // Number
  "minimum",
  "maximum",
  "exclusiveMinimum",
  "exclusiveMaximum",
  "multipleOf",
  // Already handled metadata
  "description",
  "default",
  // Content
  "contentEncoding",
  "contentMediaType",
  "contentSchema",
  // Unsupported (error-throwing)
  "unevaluatedItems",
  "unevaluatedProperties",
  "if",
  "then",
  "else",
  "dependentSchemas",
  "dependentRequired",
  // OpenAPI
  "nullable",
  "readOnly"
]);
function Kb(e, r) {
  let i = e.$schema;
  return i === "https://json-schema.org/draft/2020-12/schema" ? "draft-2020-12" : i === "http://json-schema.org/draft-07/schema#" ? "draft-7" : i === "http://json-schema.org/draft-04/schema#" ? "draft-4" : r ?? "draft-2020-12";
}
s(Kb, "detectVersion");
function eg(e, r) {
  return e.map((i, o) => o < r ? i : i.optional());
}
s(eg, "applyMinItems");
function Wb(e) {
  return e.replace(/~1/g, "/").replace(/~0/g, "~");
}
s(Wb, "decodeJSONPointerSegment");
function Gb(e, r) {
  if (!e.startsWith("#"))
    throw new Error("External $ref is not supported, only local refs (#/...) are allowed");
  let i = e.slice(1).split("/").filter(Boolean);
  if (i.length === 0)
    return r.rootSchema;
  let o = r.version === "draft-2020-12" ? "$defs" : "definitions";
  if (i[0] === o) {
    let t = i[1] === void 0 ? void 0 : Wb(i[1]);
    if (!t || !r.defs[t])
      throw new Error(`Reference not found: ${e}`);
    return r.defs[t];
  }
  throw new Error(`Reference not found: ${e}`);
}
s(Gb, "resolveRef");
function Xb(e, r) {
  return I.transform((o) => o).check((o) => {
    let t = o.value;
    if (!(typeof t != "object" || t === null || Array.isArray(t)))
      for (let n of Object.getOwnPropertyNames(t)) {
        let a = r.safeParse(n);
        a.success || o.issues.push({
          code: "invalid_key",
          origin: "record",
          issues: a.error.issues,
          input: n,
          path: [n],
          continue: !0
        });
      }
  }).pipe(e);
}
s(Xb, "checkPropertyNames");
function tg(e, r) {
  if (e !== !1)
    return e === void 0 || e === !0 ? I.any() : le(e, r);
}
s(tg, "getTupleRest");
var Hb = /^(?:[01]\d|2[0-3]):[0-5]\d:[0-5]\d(?:\.\d+)?(?:Z|[+-](?:[01]\d|2[0-3]):[0-5]\d)$/;
function rg(e, r) {
  if (e.not !== void 0) {
    if (typeof e.not == "object" && Object.keys(e.not).length === 0)
      return I.never();
    throw new Error("not is not supported in Zod (except { not: {} } for never)");
  }
  if (e.unevaluatedItems !== void 0)
    throw new Error("unevaluatedItems is not supported");
  if (e.unevaluatedProperties !== void 0)
    throw new Error("unevaluatedProperties is not supported");
  if (e.if !== void 0 || e.then !== void 0 || e.else !== void 0)
    throw new Error("Conditional schemas (if/then/else) are not supported");
  if (e.dependentSchemas !== void 0 || e.dependentRequired !== void 0)
    throw new Error("dependentSchemas and dependentRequired are not supported");
  if (e.$ref) {
    let t = e.$ref;
    if (r.refs.has(t))
      return r.refs.get(t);
    if (r.processing.has(t))
      return I.lazy(() => {
        if (!r.refs.has(t))
          throw new Error(`Circular reference not resolved: ${t}`);
        return r.refs.get(t);
      });
    r.processing.add(t);
    let n = Gb(t, r), a = le(n, r);
    return r.refs.set(t, a), r.processing.delete(t), a;
  }
  if (e.enum !== void 0) {
    let t = e.enum;
    if (r.version === "openapi-3.0" && e.nullable === !0 && t.length === 1 && t[0] === null)
      return I.null();
    if (t.length === 0)
      return I.never();
    if (t.length === 1)
      return I.literal(t[0]);
    if (t.every((a) => typeof a == "string"))
      return I.enum(t);
    let n = t.map((a) => I.literal(a));
    return n.length < 2 ? n[0] : I.union([n[0], n[1], ...n.slice(2)]);
  }
  if (e.const !== void 0)
    return I.literal(e.const);
  let i = e.type;
  if (Array.isArray(i)) {
    let t = i.map((n) => {
      let a = { ...e, type: n };
      return rg(a, r);
    });
    return t.length === 0 ? I.never() : t.length === 1 ? t[0] : I.union(t);
  }
  if (!i)
    return I.any();
  let o;
  switch (i) {
    case "string": {
      let t = I.string();
      if (e.format) {
        let n = e.format;
        n === "email" ? t = t.check(I.email()) : n === "uri" || n === "uri-reference" ? t = t.check(I.url()) : n === "uuid" || n === "guid" ? t = t.check(I.uuid()) : n === "date-time" ? t = t.check(I.iso.datetime({ offset: !0 })) : n === "date" ? t = t.check(I.iso.date()) : n === "time" ? t = t.check(I.regex(Hb)) : n === "duration" ? t = t.check(I.iso.duration()) : n === "hostname" ? t = t.check(I.hostname()) : n === "ipv4" ? t = t.check(I.ipv4()) : n === "ipv6" ? t = t.check(I.ipv6()) : n === "mac" ? t = t.check(I.mac()) : n === "cidr" ? t = t.check(I.cidrv4()) : n === "cidr-v6" ? t = t.check(I.cidrv6()) : n === "base64" ? t = t.check(I.base64()) : n === "base64url" ? t = t.check(I.base64url()) : n === "e164" ? t = t.check(I.e164()) : n === "credit_card" ? t = t.check(I.creditCard()) : n === "jwt" ? t = t.check(I.jwt()) : n === "emoji" ? t = t.check(I.emoji()) : n === "nanoid" ? t = t.check(I.nanoid()) : n === "cuid" ? t = t.check(I.cuid()) : n === "cuid2" ? t = t.check(I.cuid2()) : n === "ulid" ? t = t.check(I.ulid()) : n === "xid" ? t = t.check(I.xid()) : n === "ksuid" && (t = t.check(I.ksuid()));
      }
      typeof e.minLength == "number" && (t = t.min(e.minLength)), typeof e.maxLength == "number" && (t = t.max(e.maxLength)), e.pattern && (t = t.regex(new RegExp(e.pattern))), o = t;
      break;
    }
    case "number":
    case "integer": {
      let t = i === "integer" ? I.number().int() : I.number();
      typeof e.minimum == "number" && e.exclusiveMinimum !== !0 && (t = t.min(e.minimum)), typeof e.maximum == "number" && e.exclusiveMaximum !== !0 && (t = t.max(e.maximum)), typeof e.exclusiveMinimum == "number" ? t = t.gt(e.exclusiveMinimum) : e.exclusiveMinimum === !0 && typeof e.minimum == "number" && (t = t.gt(e.minimum)), typeof e.exclusiveMaximum == "number" ? t = t.lt(e.exclusiveMaximum) : e.exclusiveMaximum === !0 && typeof e.maximum == "number" && (t = t.lt(e.maximum)), typeof e.multipleOf == "number" && (t = t.multipleOf(e.multipleOf)), o = t;
      break;
    }
    case "boolean": {
      o = I.boolean();
      break;
    }
    case "null": {
      o = I.null();
      break;
    }
    case "object": {
      let t = {}, n = e.properties || {}, a = new Set(e.required || []), u = typeof e.additionalProperties == "object" ? le(e.additionalProperties, r) : void 0;
      for (let [c, l] of Object.entries(n)) {
        let d = le(l, r);
        q(t, c, a.has(c) ? d : d.optional());
      }
      if (e.patternProperties) {
        let c = e.patternProperties, l = Object.keys(c), d = [];
        for (let p of l) {
          let h = le(c[p], r), v = I.string().regex(new RegExp(p));
          d.push(I.looseRecord(v, h));
        }
        let f = [];
        if (Object.keys(t).length > 0 && f.push(I.object(t).passthrough()), f.push(...d), f.length === 0)
          o = I.object({}).passthrough();
        else if (f.length === 1)
          o = f[0];
        else {
          let p = I.intersection(f[0], f[1]);
          for (let h = 2; h < f.length; h++)
            p = I.intersection(p, f[h]);
          o = p;
        }
        if (e.additionalProperties === !1) {
          let p = Object.keys(t), h = l.map((k) => new RegExp(k)), v = o;
          o = o.check((k) => {
            if (!ve(k.value))
              return;
            let z = [];
            for (let Z of Object.keys(k.value))
              p.includes(Z) || h.some((O) => O.test(Z)) || z.push(Z);
            z.length && k.issues.push({
              code: "unrecognized_keys",
              keys: z,
              input: k.value,
              inst: v
            });
          });
        }
      } else {
        let c = I.object(t);
        e.additionalProperties === !1 ? o = c.strict() : u ? o = c.catchall(u) : o = c.passthrough();
      }
      if (e.propertyNames !== void 0 && e.propertyNames !== !0) {
        let c = typeof e.propertyNames == "object" && e.propertyNames.type === void 0 ? { type: "string", ...e.propertyNames } : e.propertyNames;
        o = Xb(o, le(c, r));
      }
      break;
    }
    case "array": {
      let t = e.prefixItems, n = e.items;
      if (t && Array.isArray(t)) {
        let a = typeof e.minItems == "number" ? e.minItems : 0, u = t.map((f) => le(f, r)), c = eg(u, a), l = Array.isArray(n) ? void 0 : tg(n, r), d = I.tuple(c);
        o = l ? d.rest(l) : d, typeof e.minItems == "number" && (o = o.check(I.minLength(e.minItems))), typeof e.maxItems == "number" && (o = o.check(I.maxLength(e.maxItems)));
      } else if (Array.isArray(n)) {
        let a = typeof e.minItems == "number" ? e.minItems : 0, u = n.map((f) => le(f, r)), c = eg(u, a), l = tg(e.additionalItems, r), d = I.tuple(c);
        o = l ? d.rest(l) : d, typeof e.minItems == "number" && (o = o.check(I.minLength(e.minItems))), typeof e.maxItems == "number" && (o = o.check(I.maxLength(e.maxItems)));
      } else if (n !== void 0) {
        let a = le(n, r), u = I.array(a);
        typeof e.minItems == "number" && (u = u.min(e.minItems)), typeof e.maxItems == "number" && (u = u.max(e.maxItems)), o = u;
      } else
        o = I.array(I.any());
      break;
    }
    default:
      throw new Error(`Unsupported type: ${i}`);
  }
  return o;
}
s(rg, "convertBaseSchema");
function le(e, r) {
  if (typeof e == "boolean")
    return e ? I.any() : I.never();
  let i = rg(e, r), o = e.type || e.enum !== void 0 || e.const !== void 0;
  if (e.anyOf && Array.isArray(e.anyOf)) {
    let u = e.anyOf.map((l) => le(l, r)), c = I.union(u);
    i = o ? I.intersection(i, c) : c;
  }
  if (e.oneOf && Array.isArray(e.oneOf)) {
    let u = e.oneOf.map((l) => le(l, r)), c = I.xor(u);
    i = o ? I.intersection(i, c) : c;
  }
  if (e.allOf && Array.isArray(e.allOf))
    if (e.allOf.length === 0)
      i = o ? i : I.any();
    else {
      let u = o ? i : le(e.allOf[0], r), c = o ? 0 : 1;
      for (let l = c; l < e.allOf.length; l++)
        u = I.intersection(u, le(e.allOf[l], r));
      i = u;
    }
  e.nullable === !0 && r.version === "openapi-3.0" && (i = I.nullable(i)), e.readOnly === !0 && (i = I.readonly(i)), e.default !== void 0 && (i = i.default(e.default));
  let t = {}, n = ["$id", "id", "$comment", "$anchor", "$vocabulary", "$dynamicRef", "$dynamicAnchor"];
  for (let u of n)
    u in e && (t[u] = e[u]);
  let a = ["contentEncoding", "contentMediaType", "contentSchema"];
  for (let u of a)
    u in e && (t[u] = e[u]);
  e.propertyNames !== void 0 && e.type === "object" && e.$ref === void 0 && (t.propertyNames = e.propertyNames);
  for (let u of Object.keys(e))
    qb.has(u) || q(t, u, e[u]);
  return Object.keys(t).length > 0 && r.registry.add(i, t), e.description && (i = i.describe(e.description)), i;
}
s(le, "convertSchema");
function ng(e, r) {
  if (typeof e == "boolean")
    return e ? I.any() : I.never();
  let i;
  try {
    i = JSON.parse(JSON.stringify(e));
  } catch {
    throw new Error("fromJSONSchema input is not valid JSON (possibly cyclic); use $defs/$ref for recursive schemas");
  }
  let o = Kb(i, r?.defaultTarget), t = i.$defs || i.definitions || {}, n = {
    version: o,
    defs: t,
    refs: /* @__PURE__ */ new Map(),
    processing: /* @__PURE__ */ new Set(),
    rootSchema: i,
    registry: r?.registry ?? H
  };
  return le(i, n);
}
s(ng, "fromJSONSchema");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/visit.js
var ig = Symbol("z.visit/resolving");
function an(e, r) {
  let i = typeof r == "function" ? r : (a, u) => {
    let c = r[a._zod.def.type];
    return c ? c(a, u) : a;
  }, o = /* @__PURE__ */ new Map();
  function t(a) {
    let u = o.get(a);
    if (u === ig)
      return new Le({
        type: "lazy",
        getter: /* @__PURE__ */ s(() => o.get(a), "getter")
      });
    if (u !== void 0)
      return u;
    o.set(a, ig);
    let c = n(a), l = i(c, c !== a);
    return o.set(a, l), l;
  }
  s(t, "run");
  function n(a) {
    let u = a._zod.def, c = u.type;
    switch (c) {
      case "object": {
        let l = u.shape, d = Object.keys(l), f = !1, p = {};
        for (let v of d) {
          let k = t(l[v]);
          k !== l[v] && (f = !0), p[v] = k;
        }
        let h = u.catchall;
        return u.catchall && (h = t(u.catchall), h !== u.catchall && (f = !0)), f ? A(a, { ...u, shape: p, catchall: h }) : a;
      }
      case "array": {
        let l = t(u.element);
        return l === u.element ? a : A(a, { ...u, element: l });
      }
      case "tuple": {
        let l = u.items, d = !1, f = [];
        for (let h of l) {
          let v = t(h);
          v !== h && (d = !0), f.push(v);
        }
        let p = u.rest;
        return u.rest && (p = t(u.rest), p !== u.rest && (d = !0)), d ? A(a, { ...u, items: f, rest: p }) : a;
      }
      case "record":
      case "map": {
        let l = t(u.keyType), d = t(u.valueType);
        return l === u.keyType && d === u.valueType ? a : A(a, { ...u, keyType: l, valueType: d });
      }
      case "set": {
        let l = t(u.valueType);
        return l === u.valueType ? a : A(a, { ...u, valueType: l });
      }
      case "union": {
        let l = u.options, d = !1, f = [];
        for (let p of l) {
          let h = t(p);
          h !== p && (d = !0), f.push(h);
        }
        return d ? A(a, { ...u, options: f }) : a;
      }
      case "intersection": {
        let l = t(u.left), d = t(u.right);
        return l === u.left && d === u.right ? a : A(a, { ...u, left: l, right: d });
      }
      case "optional":
      case "nullable":
      case "default":
      case "prefault":
      case "catch":
      case "readonly":
      case "nonoptional":
      case "promise":
      case "success": {
        let l = t(u.innerType);
        return l === u.innerType ? a : A(a, { ...u, innerType: l });
      }
      case "pipe": {
        let l = t(u.in), d = t(u.out);
        return l === u.in && d === u.out ? a : A(a, { ...u, in: l, out: d });
      }
      case "function": {
        let l = t(u.input), d = t(u.output);
        return l === u.input && d === u.output ? a : A(a, { ...u, input: l, output: d });
      }
      case "lazy": {
        let l = u.getter, { _cachedInner: d, ...f } = u;
        return A(a, { ...f, getter: /* @__PURE__ */ s(() => t(l()), "getter") });
      }
      // A leaf by choice: `parts` are regex fragments, not data positions.
      case "template_literal":
      // Leaves.
      case "string":
      case "number":
      case "int":
      case "boolean":
      case "bigint":
      case "symbol":
      case "undefined":
      case "null":
      case "void":
      case "never":
      case "any":
      case "unknown":
      case "date":
      case "nan":
      case "enum":
      case "literal":
      case "file":
      case "transform":
      case "custom":
        return a;
      default:
        return a;
    }
  }
  return s(n, "mapInner"), t(e);
}
s(an, "visit");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/deep-partial.js
function og(e) {
  return an(e, {
    object: /* @__PURE__ */ s((r) => r.partial(), "object"),
    // Every partialed option now admits `undefined`, which the constructor rejects as a duplicate.
    union: /* @__PURE__ */ s((r) => {
      let i = r._zod.def;
      return i.discriminator === void 0 ? r : ar(i.options);
    }, "union")
  });
}
s(og, "deepPartial");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/in-out.js
function Qb(e, r) {
  if (!r?.length)
    return e;
  let i = e._zod.def;
  return A(e, $e(i, { checks: [...i.checks ?? [], ...r] }), { parent: !0 });
}
s(Qb, "withChecks");
function ag(e) {
  return Qb(e.out, e.checks);
}
s(ag, "outSide");
function Yb(e) {
  return e.in._zod.traits.has("$ZodTransform") ? ag(e) : e.in;
}
s(Yb, "inSide");
function sg(e) {
  return an(e, {
    pipe: /* @__PURE__ */ s((r) => Yb(r._zod.def), "pipe"),
    // A default value belongs to the output side, so a rewritten inner type leaves it stranded. `.default()` widens the declared input type with `undefined`, and `optional` is what carries that across.
    default: /* @__PURE__ */ s((r, i) => i ? vt(r._zod.def.innerType) : r, "default"),
    // A catch value is output-side too, but `.catch()` leaves the declared input type alone, so the inner schema stands on its own.
    catch: /* @__PURE__ */ s((r, i) => i ? r._zod.def.innerType : r, "catch")
  });
}
s(sg, "input");
function ug(e) {
  return an(e, {
    pipe: /* @__PURE__ */ s((r) => ag(r._zod.def), "pipe"),
    // A prefault value is fed through the schema, which makes it input-side, so a rewritten inner type leaves it stranded.
    prefault: /* @__PURE__ */ s((r, i) => i ? r._zod.def.innerType : r, "prefault")
  });
}
s(ug, "output");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/classic/coerce.js
var nf = {};
Pe(nf, {
  bigint: () => n_,
  boolean: () => r_,
  date: () => i_,
  number: () => t_,
  string: () => e_
});
function e_(e) {
  return jc(tr, e);
}
s(e_, "string");
function t_(e) {
  return Ac(nr, e);
}
s(t_, "number");
function r_(e) {
  return Lc(ir, e);
}
s(r_, "boolean");
function n_(e) {
  return Mc(or, e);
}
s(n_, "bigint");
function i_(e) {
  return el(Xr, e);
}
s(i_, "date");

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/functionName.js
var of = Symbol.for("functionName");

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/components/paths.js
var o_ = Symbol.for("toReferencePath");

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/pagination.js
var c_ = y.object({
  numItems: y.number(),
  cursor: y.union(y.string(), y.null()),
  endCursor: y.optional(y.union(y.string(), y.null())),
  id: y.optional(y.number()),
  maximumRowsRead: y.optional(y.number()),
  maximumBytesRead: y.optional(y.number())
});

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/api.js
function cg(e = []) {
  let r = {
    get(i, o) {
      if (typeof o == "string") {
        let t = [...e, o];
        return cg(t);
      } else if (o === of) {
        if (e.length < 2) {
          let a = ["api", ...e].join(".");
          throw new Error(
            `API path is expected to be of the form \`api.moduleName.functionName\`. Found: \`${a}\``
          );
        }
        let t = e.slice(0, -1).join("/"), n = e[e.length - 1];
        return n === "default" ? t : t + ":" + n;
      } else return o === Symbol.toStringTag ? "FunctionReference" : void 0;
    }
  };
  return new Proxy({}, r);
}
s(cg, "createApi");
var l_ = cg();

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/schema.js
var f_ = Object.defineProperty, p_ = /* @__PURE__ */ s((e, r, i) => r in e ? f_(e, r, { enumerable: !0, configurable: !0, writable: !0, value: i }) : e[r] = i, "__defNormalProp"), je = /* @__PURE__ */ s((e, r, i) => p_(e, typeof r != "symbol" ? r + "" : r, i), "__publicField"), xo = class {
  static {
    s(this, "TableDefinition");
  }
  /**
   * @internal
   */
  constructor(r) {
    je(this, "indexes"), je(this, "stagedDbIndexes"), je(this, "searchIndexes"), je(this, "stagedSearchIndexes"), je(this, "vectorIndexes"), je(this, "stagedVectorIndexes"), je(this, "validator"), this.indexes = [], this.stagedDbIndexes = [], this.searchIndexes = [], this.stagedSearchIndexes = [], this.vectorIndexes = [], this.stagedVectorIndexes = [], this.validator = r;
  }
  /**
   * This API is experimental: it may change or disappear.
   *
   * Returns indexes defined on this table.
   * Intended for the advanced use cases of dynamically deciding which index to use for a query.
   * If you think you need this, please chime in on ths issue in the Convex JS GitHub repo.
   * https://github.com/get-convex/convex-js/issues/49
   */
  " indexes"() {
    return this.indexes;
  }
  index(r, i) {
    return Array.isArray(i) ? this.indexes.push({
      indexDescriptor: r,
      fields: i
    }) : i.staged ? this.stagedDbIndexes.push({
      indexDescriptor: r,
      fields: i.fields
    }) : this.indexes.push({
      indexDescriptor: r,
      fields: i.fields
    }), this;
  }
  searchIndex(r, i) {
    return i.staged ? this.stagedSearchIndexes.push({
      indexDescriptor: r,
      searchField: i.searchField,
      filterFields: i.filterFields || []
    }) : this.searchIndexes.push({
      indexDescriptor: r,
      searchField: i.searchField,
      filterFields: i.filterFields || []
    }), this;
  }
  vectorIndex(r, i) {
    return i.staged ? this.stagedVectorIndexes.push({
      indexDescriptor: r,
      vectorField: i.vectorField,
      dimensions: i.dimensions,
      filterFields: i.filterFields || []
    }) : this.vectorIndexes.push({
      indexDescriptor: r,
      vectorField: i.vectorField,
      dimensions: i.dimensions,
      filterFields: i.filterFields || []
    }), this;
  }
  /**
   * Work around for https://github.com/microsoft/TypeScript/issues/57035
   */
  self() {
    return this;
  }
  /**
   * Export the contents of this definition.
   *
   * This is called internally by the Convex framework.
   * @internal
   */
  export() {
    let r = this.validator.json;
    if (typeof r != "object")
      throw new Error(
        "Invalid validator: please make sure that the parameter of `defineTable` is valid (see https://docs.convex.dev/database/schemas)"
      );
    return {
      indexes: this.indexes,
      stagedDbIndexes: this.stagedDbIndexes,
      searchIndexes: this.searchIndexes,
      stagedSearchIndexes: this.stagedSearchIndexes,
      vectorIndexes: this.vectorIndexes,
      stagedVectorIndexes: this.stagedVectorIndexes,
      documentType: r
    };
  }
};
function bt(e) {
  return Tf(e) ? new xo(e) : new xo(y.object(e));
}
s(bt, "defineTable");
var uf = class {
  static {
    s(this, "SchemaDefinition");
  }
  /**
   * @internal
   */
  constructor(r, i) {
    je(this, "tables"), je(this, "strictTableNameTypes"), je(this, "schemaValidation"), this.tables = r, this.schemaValidation = i?.schemaValidation === void 0 ? !0 : i.schemaValidation;
  }
  /**
   * Export the contents of this definition.
   *
   * This is called internally by the Convex framework.
   * @internal
   */
  export() {
    return JSON.stringify({
      tables: Object.entries(this.tables).map(([r, i]) => {
        let {
          indexes: o,
          stagedDbIndexes: t,
          searchIndexes: n,
          stagedSearchIndexes: a,
          vectorIndexes: u,
          stagedVectorIndexes: c,
          documentType: l
        } = i.export();
        return {
          tableName: r,
          indexes: o,
          stagedDbIndexes: t,
          searchIndexes: n,
          stagedSearchIndexes: a,
          vectorIndexes: u,
          stagedVectorIndexes: c,
          documentType: l
        };
      }),
      schemaValidation: this.schemaValidation
    });
  }
};
function wo(e, r) {
  return new uf(e, r);
}
s(wo, "defineSchema");
var gP = wo({
  _scheduled_functions: bt({
    name: y.string(),
    args: y.array(y.any()),
    scheduledTime: y.float64(),
    completedTime: y.optional(y.float64()),
    state: y.union(
      y.object({ kind: y.literal("pending") }),
      y.object({ kind: y.literal("inProgress") }),
      y.object({ kind: y.literal("success") }),
      y.object({ kind: y.literal("failed"), error: y.string() }),
      y.object({ kind: y.literal("canceled") })
    )
  }),
  _storage: bt({
    sha256: y.string(),
    size: y.float64(),
    contentType: y.optional(y.string())
  })
});

// ../../packages/zodvex/dist/server/index.js
function un(e) {
  if (e == null)
    return e;
  if (Array.isArray(e))
    return e.map(un);
  if (typeof e == "object" && e.constructor === Object) {
    let r = {};
    for (let [i, o] of Object.entries(e))
      o !== void 0 && (r[i] = un(o));
    return r;
  }
  return e;
}
s(un, "stripUndefined");
var lg = /* @__PURE__ */ new WeakMap(), So = {
  getMetadata: /* @__PURE__ */ s((e) => lg.get(e), "getMetadata"),
  setMetadata: /* @__PURE__ */ s((e, r) => lg.set(e, r), "setMetadata")
};
function m_(e) {
  let r = e._zod.def.entries, i = Object.keys(r);
  if (i && Array.isArray(i) && i.length > 0) {
    let o = i.filter((t) => t != null).map((t) => y.literal(t));
    if (o.length === 1) {
      let [t] = o;
      return t;
    } else if (o.length >= 2) {
      let [t, n, ...a] = o;
      return y.union(
        t,
        n,
        ...a
      );
    } else
      return y.any();
  } else
    return y.any();
}
s(m_, "convertEnumType");
function g_(e, r, i) {
  let o = e._zod.def.innerType;
  if (o && o instanceof S)
    if (o instanceof W) {
      let t = o._zod.def.innerType, n = i(t, r);
      return {
        validator: y.union(n, y.null()),
        isOptional: !0
        // Mark as optional so it gets wrapped later
      };
    } else {
      let t = i(o, r);
      return {
        validator: y.union(t, y.null()),
        isOptional: !1
      };
    }
  else
    return {
      validator: y.any(),
      isOptional: !1
    };
}
s(g_, "convertNullableType");
function h_(e, r, i) {
  let o = e._zod.def.valueType;
  if (o || (o = e._zod.def.keyType), o && o instanceof S)
    if (o instanceof W || o instanceof ke || o instanceof ke && o._zod.def.innerType instanceof W) {
      let n, a, u = !1;
      if (o instanceof ke) {
        u = !0, a = o._zod.def.defaultValue;
        let d = o._zod.def.innerType;
        d instanceof W ? n = d._zod.def.innerType : n = d;
      } else o instanceof W ? n = o._zod.def.innerType : n = o;
      let c = i(n, r), l = y.union(c, y.null());
      return u && (l._zodDefault = a), y.record(y.string(), l);
    } else
      return y.record(y.string(), i(o, r));
  else
    return y.record(y.string(), y.any());
}
s(h_, "convertRecordType");
function v_(e, r, i) {
  let o = e instanceof Re ? e._zod.def.options : (
    // cast: fallback for non-standard discriminated union variants
    e._zod?.def?.options
  );
  if (o) {
    let t = Array.isArray(o) ? o : Array.from(o);
    if (t.length >= 2) {
      let n = t.map((l) => {
        let d = new Set(r);
        return i(l, d);
      }), [a, u, ...c] = n;
      return y.union(
        a,
        u,
        ...c
      );
    } else
      return y.any();
  } else
    return y.any();
}
s(v_, "convertDiscriminatedUnionType");
function y_(e, r, i) {
  let o = e._zod.def.options;
  if (o && Array.isArray(o) && o.length > 0) {
    if (o.length === 1)
      return i(o[0], r);
    {
      let t = o.map((n) => {
        let a = new Set(r);
        return i(n, a);
      });
      if (t.length >= 2) {
        let [n, a, ...u] = t;
        return y.union(
          n,
          a,
          ...u
        );
      } else
        return y.any();
    }
  } else
    return y.any();
}
s(y_, "convertUnionType");
function $_(e) {
  let r = So.getMetadata(e);
  return r?.isConvexId === !0 && r?.tableName && typeof r.tableName == "string";
}
s($_, "isZid");
var dg = /* @__PURE__ */ new WeakMap();
function de(e, r = /* @__PURE__ */ new Set()) {
  if (!e)
    return y.any();
  let i = dg.get(e);
  if (i)
    return i;
  if (r.has(e))
    return y.any();
  r.add(e);
  let o = e, t = !1, n, a = !1;
  e instanceof ke && (a = !0, n = e._zod.def.defaultValue, o = e._zod.def.innerType), o instanceof W && (t = !0, o = o._zod.def.innerType, o instanceof ke && (a = !0, n = o._zod.def.defaultValue, o = o._zod.def.innerType));
  let u;
  if ($_(o)) {
    let d = So.getMetadata(o)?.tableName || "unknown";
    u = y.id(d);
  } else
    switch (o._zod.def.type) {
      case "string":
        u = y.string();
        break;
      case "number":
        u = y.float64();
        break;
      case "bigint":
        u = y.int64();
        break;
      case "boolean":
        u = y.boolean();
        break;
      case "date":
        u = y.float64();
        break;
      case "null":
        u = y.null();
        break;
      case "nan":
        u = y.float64();
        break;
      case "array": {
        if (o instanceof At) {
          let d = o._zod.def.element;
          u = y.array(de(d, r));
        } else
          u = y.array(y.any());
        break;
      }
      case "object": {
        if (o instanceof Q) {
          let d = o._zod.def.shape, f = {};
          for (let [p, h] of Object.entries(d))
            h && h instanceof S && (f[p] = de(h, r));
          u = y.object(f);
        } else
          u = y.object({});
        break;
      }
      case "union": {
        o instanceof fe ? u = y_(o, r, de) : u = y.any();
        break;
      }
      case "discriminatedUnion": {
        u = v_(
          o,
          r,
          de
        );
        break;
      }
      case "literal": {
        if (o instanceof Ct) {
          let f = o._zod.def.values.values().next().value;
          f != null ? u = y.literal(f) : u = y.any();
        } else
          u = y.any();
        break;
      }
      case "enum": {
        o instanceof Et ? u = m_(o) : u = y.any();
        break;
      }
      case "record": {
        o instanceof Ut ? u = h_(o, r, de) : u = y.record(y.string(), y.any());
        break;
      }
      case "transform":
      case "pipe": {
        if (o instanceof Fe) {
          let d = o._zod.def.in;
          d && d instanceof S ? u = de(d, r) : u = y.any();
        } else {
          let d = So.getMetadata(o);
          if (d?.brand && d?.originalSchema)
            u = de(d.originalSchema, r);
          else {
            let f = o._zod?.def?.in;
            f && f instanceof S ? u = de(f, r) : u = y.any();
          }
        }
        break;
      }
      case "nullable": {
        if (o instanceof Ne) {
          let d = g_(o, r, de);
          u = d.validator, d.isOptional && (t = !0);
        } else
          u = y.any();
        break;
      }
      case "tuple": {
        if (o instanceof ut) {
          let d = o._zod.def.items;
          if (d && d.length > 0) {
            let f = {};
            d.forEach((p, h) => {
              f[`_${h}`] = de(p, r);
            }), u = y.object(f);
          } else
            u = y.object({});
        } else
          u = y.object({});
        break;
      }
      case "lazy": {
        if (o instanceof Le)
          try {
            let d = o._zod.def.getter;
            if (d) {
              let f = d();
              f && f instanceof S ? u = de(f, r) : u = y.any();
            } else
              u = y.any();
          } catch {
            u = y.any();
          }
        else
          u = y.any();
        break;
      }
      case "any":
        u = y.any();
        break;
      case "unknown":
        u = y.any();
        break;
      case "undefined":
      case "void":
      case "never":
        u = y.any();
        break;
      case "intersection":
        u = y.any();
        break;
      case "optional": {
        let d = o._zod?.def?.innerType;
        d && d instanceof S ? (u = de(d, r), t = !0) : (u = y.any(), t = !0);
        break;
      }
      default:
        u = y.any();
        break;
    }
  let c = t || a ? y.optional(u) : u;
  return a && typeof c == "object" && c !== null && (c._zodDefault = n), dg.set(e, c), c;
}
s(de, "zodToConvexInternal");
function b_(e) {
  return typeof e == "object" && e !== null && !(e instanceof S) ? _g(e) : de(e);
}
s(b_, "zodToConvex");
function _g(e) {
  let r = e instanceof Q ? e._zod.def.shape : e, i = {};
  for (let [o, t] of Object.entries(r))
    i[o] = de(t);
  return i;
}
s(_g, "zodToConvexFields");
function xg(e, r) {
  return it(e, r);
}
s(xg, "decodeDoc");
function fg(e, r) {
  return un(De(e, r));
}
s(fg, "encodeDoc");
function pg(e) {
  let r = {};
  for (let [i, o] of Object.entries(e))
    r[i] = o === void 0 ? void 0 : un(o);
  return r;
}
s(pg, "stripUndefinedPreservingTopLevel");
function __(e, r) {
  if (!(e instanceof Q)) {
    let a = De(e, r);
    return a !== null && typeof a == "object" && !Array.isArray(a) ? pg(a) : un(a);
  }
  let i = e._zod.def.shape, o = {};
  for (let [a, u] of Object.entries(i))
    o[a] = u instanceof W ? u : new W({ type: "optional", innerType: u });
  let t = x.object(o), n = De(t, r);
  return pg(n);
}
s(__, "encodePartialDoc");
function wg(e, r, i) {
  return x.codec(e, r, i);
}
s(wg, "zodvexCodec");
function cf(e, r, i) {
  if (r.includes(".")) return i;
  if (e instanceof Q) {
    let o = e.shape[r];
    if (o) return De(o, i);
  }
  if (e instanceof fe) {
    let t = e._zod.def.options.filter((n) => n instanceof Q).map((n) => n.shape[r]).filter(Boolean);
    if (t.length === 1) return De(t[0], i);
    if (t.length > 1)
      return De(x.union(t), i);
  }
  return i;
}
s(cf, "encodeIndexValue");
function Oo(e, r) {
  return new Proxy(e, {
    get(i, o, t) {
      return typeof o == "string" && ["eq", "gt", "gte", "lt", "lte"].includes(o) ? (n, a) => {
        let u = cf(r, n, a), c = i[o](n, u);
        return Oo(c, r);
      } : o === "search" ? (...n) => {
        let a = i.search(...n);
        return Oo(a, r);
      } : Reflect.get(i, o, t);
    }
  });
}
s(Oo, "wrapIndexRangeBuilder");
function lf(e, r) {
  return e != null && Object.prototype.isPrototypeOf.call(r, e);
}
s(lf, "isFilterExpression");
function mg(e, r) {
  if (lf(e, r)) {
    let i = e.serialize();
    if (i && typeof i == "object" && "$field" in i)
      return i.$field;
  }
  return null;
}
s(mg, "extractFieldPath");
function x_(e, r) {
  let i = Object.getPrototypeOf(e.field("_id"));
  return new Proxy(e, {
    get(o, t, n) {
      return typeof t == "string" && ["eq", "neq", "lt", "lte", "gt", "gte"].includes(t) ? (a, u) => {
        let c = mg(a, i), l = mg(u, i);
        return c && !lf(u, i) ? u = cf(r, c, u) : l && !lf(a, i) && (a = cf(r, l, a)), o[t](a, u);
      } : Reflect.get(o, t, n);
    }
  });
}
s(x_, "wrapFilterBuilder");
var mf = class kg {
  static {
    s(this, "_ZodvexQueryChain");
  }
  constructor(r, i) {
    this.inner = r, this.schema = i;
  }
  /** Factory method for intermediate methods. Subclasses override to return their own type. */
  createChain(r) {
    return new kg(r, this.schema);
  }
  /** Decode a wire-format doc and cast to the decoded document type. */
  decode(r) {
    return xg(this.schema, r);
  }
  // --- Intermediate methods: wire-typed TableInfo for Convex machinery ---
  fullTableScan() {
    return this.createChain(this.inner.fullTableScan());
  }
  withIndex(r, i) {
    let o = i ? (t) => i(Oo(t, this.schema)) : void 0;
    return this.createChain(this.inner.withIndex(r, o));
  }
  withSearchIndex(r, i) {
    let o = /* @__PURE__ */ s((t) => i(Oo(t, this.schema)), "wrappedFilter");
    return this.createChain(this.inner.withSearchIndex(r, o));
  }
  order(r) {
    return this.createChain(this.inner.order(r));
  }
  // Implementation
  filter(r) {
    let i = /* @__PURE__ */ s((o) => r(x_(o, this.schema)), "wrappedPredicate");
    return this.createChain(this.inner.filter(i));
  }
  limit(r) {
    return this.createChain(this.inner.limit(r));
  }
  count() {
    return this.inner.count();
  }
  // --- Terminal methods: return decoded Doc type ---
  async first() {
    let r = await this.inner.first();
    return r ? this.decode(r) : null;
  }
  async unique() {
    let r = await this.inner.unique();
    return r ? this.decode(r) : null;
  }
  async collect() {
    return (await this.inner.collect()).map((i) => this.decode(i));
  }
  async take(r) {
    return (await this.inner.take(r)).map((o) => this.decode(o));
  }
  async paginate(r) {
    let i = await this.inner.paginate(r);
    return {
      ...i,
      page: i.page.map((o) => this.decode(o))
    };
  }
  // --- AsyncIterable: decode each yielded document ---
  async *[Symbol.asyncIterator]() {
    for await (let r of this.inner)
      yield this.decode(r);
  }
};
function df(e, r, i) {
  for (let o of Object.keys(r))
    if (e.normalizeId(o, i))
      return o;
  return null;
}
s(df, "resolveTableName");
var gf = class {
  static {
    s(this, "ZodvexDatabaseReader");
  }
  constructor(e, r) {
    this.db = e, this.tableMap = r, this.system = e.system;
  }
  system;
  /** @internal Expose for wrapper construction (rule/audit subclasses) */
  get _internals() {
    return { db: this.db, tableMap: this.tableMap };
  }
  /**
   * Escape hatch (#85/#92): returns the database this codec wrapper delegates
   * to — the composed underlying stack when `underlyingDb` is configured (e.g.
   * a trigger-wrapped writer), the bare Convex db otherwise.
   *
   * The returned db is native-shape: reads are undecoded wire documents and it
   * bypasses codec, `.withRules()`, and `.audit()` layers entirely.
   */
  unwrap() {
    return this.db;
  }
  normalizeId(e, r) {
    return this.db.normalizeId(e, r);
  }
  async get(e, r) {
    let i, o;
    if (r !== void 0 ? (i = e, o = await this.db.get(e, r)) : (o = await this.db.get(e), i = o ? df(this.db, this.tableMap, e) : null), !o) return null;
    let t = i ? this.tableMap[i] : void 0;
    return t ? xg(t.doc, o) : o;
  }
  query(e) {
    let r = this.tableMap[e], i = this.db.query(e);
    return r ? new mf(i, r.doc) : i;
  }
  /**
   * Returns a new ZodvexDatabaseReader that applies per-table read rules.
   * The returned reader is also a ZodvexDatabaseReader, so `.withRules()` can be chained.
   */
  withRules(e, r, i) {
    return new zg(this, e, r, i ?? {});
  }
  /**
   * Returns a new ZodvexDatabaseReader that fires audit callbacks on reads.
   * The returned reader is also a ZodvexDatabaseReader, so `.audit()` can be chained
   * with `.withRules()`.
   */
  audit(e) {
    return new Og(this, e);
  }
}, Po = class extends gf {
  static {
    s(this, "ZodvexDatabaseWriter");
  }
  // Narrows the inherited `protected db` to the writer-typed view without
  // shadowing the underlying instance. Used by the write methods below.
  get writerDb() {
    return this.db;
  }
  constructor(e, r) {
    super(e, r), this.system = e.system;
  }
  /**
   * @internal Expose writer-typed internals for rules / audit subclasses.
   * Includes a `reader` field that aliases `this` (writer IS-A reader after
   * the #64 refactor) so callers expecting `_internals.reader` still work.
   */
  get _internals() {
    return { db: this.writerDb, tableMap: this.tableMap, reader: this };
  }
  /**
   * Escape hatch (#85/#92): returns the writer this codec wrapper delegates
   * to — the composed underlying stack when `underlyingDb` is configured (e.g.
   * a trigger-wrapped writer), the bare Convex db otherwise.
   *
   * The returned db is native-shape: writes must be wire-format and it
   * bypasses codec, `.withRules()`, and `.audit()` layers entirely.
   */
  unwrap() {
    return this.writerDb;
  }
  async insert(e, r) {
    let i = this.tableMap[e], o = i ? fg(i.insert, r) : r;
    return this.writerDb.insert(e, o);
  }
  async patch(e, r, i) {
    let o, t, n;
    i !== void 0 ? (o = e, t = r, n = i) : (t = e, n = r, o = df(this.db, this.tableMap, t));
    let a = o ? this.tableMap[o] : void 0, u = a ? __(a.insert, n) : n;
    return i !== void 0 ? this.writerDb.patch(e, t, u) : this.writerDb.patch(t, u);
  }
  async replace(e, r, i) {
    let o, t, n;
    i !== void 0 ? (o = e, t = r, n = i) : (t = e, n = r, o = df(this.db, this.tableMap, t));
    let a = o ? this.tableMap[o] : void 0, u = a ? fg(a.insert, n) : n;
    return i !== void 0 ? this.writerDb.replace(e, t, u) : this.writerDb.replace(t, u);
  }
  async delete(e, r) {
    return r !== void 0 ? this.writerDb.delete(e, r) : this.writerDb.delete(e);
  }
  /**
   * Returns a new ZodvexDatabaseWriter that applies per-table read and write rules.
   * The returned writer is also a ZodvexDatabaseWriter, so `.withRules()` can be chained.
   *
   * Overrides Reader's signature so a writer chained call returns a writer.
   */
  withRules(e, r, i) {
    return new k_(this, e, r, i ?? {});
  }
  /**
   * Returns a new ZodvexDatabaseWriter that fires audit callbacks on reads and writes.
   * The returned writer is also a ZodvexDatabaseWriter, so `.audit()` can be chained
   * with `.withRules()`.
   *
   * Overrides Reader's signature so a writer chained call returns a writer.
   */
  audit(e) {
    return new z_(this, e);
  }
};
function ko(e, r) {
  return e === !0 ? r : e === !1 ? null : e;
}
s(ko, "normalizeReadResult");
var w_ = class Ig extends mf {
  static {
    s(this, "_RulesQueryChain");
  }
  readRule;
  rulesConfig;
  ctx;
  constructor(r, i, o, t, n = {}) {
    super(r, i), this.readRule = o, this.rulesConfig = t, this.ctx = n;
  }
  createChain(r) {
    return new Ig(r, this.schema, this.readRule, this.rulesConfig, this.ctx);
  }
  async first() {
    for await (let r of this)
      return r;
    return null;
  }
  async unique() {
    let r = await super.unique();
    return r === null ? null : ko(await this.readRule(this.ctx, r), r);
  }
  async collect() {
    let r = [];
    for await (let i of this)
      r.push(i);
    return r;
  }
  async take(r) {
    if (!Number.isInteger(r) || r < 0)
      throw new Error("take requires a non-negative integer");
    let i = [];
    if (r === 0) return i;
    for await (let o of this)
      if (i.push(o), i.length >= r) break;
    return i;
  }
  async paginate(r) {
    let i = await super.paginate(r), o = [];
    for (let t of i.page) {
      let n = ko(await this.readRule(this.ctx, t), t);
      n !== null && o.push(n);
    }
    return { ...i, page: o };
  }
  async count() {
    if (!this.rulesConfig.allowCounting)
      throw new Error("count is not allowed with rules");
    return super.count();
  }
  async *[Symbol.asyncIterator]() {
    for await (let r of super[Symbol.asyncIterator]()) {
      let i = ko(await this.readRule(this.ctx, r), r);
      i !== null && (yield i);
    }
  }
};
function Io(e, r, i, o) {
  for (let t of Object.keys(i))
    if (e.normalizeId(t, r))
      return t;
  if ((o.defaultPolicy ?? "allow") === "deny") {
    for (let t of Object.keys(e._internals.tableMap))
      if (e.normalizeId(t, r))
        return t;
  }
  return null;
}
s(Io, "resolveRulesTableName");
var zg = class extends gf {
  static {
    s(this, "RulesDatabaseReader");
  }
  constructor(e, r, i, o) {
    let { db: t, tableMap: n } = e._internals;
    super(t, n), this.inner = e, this.ctx = r, this.rules = i, this.rulesConfig = o, this.system = e.system;
  }
  async get(e, r) {
    let i = await this.inner.get(e, r);
    if (i === null) return null;
    let o = r !== void 0 ? e : Io(this.inner, e, this.rules, this.rulesConfig);
    return o ? this.applyReadRule(o, i) : i;
  }
  query(e) {
    let r = this.rules[e];
    if (!r?.read && (this.rulesConfig.defaultPolicy ?? "allow") === "allow")
      return this.inner.query(e);
    let i = this.inner.query(e), o = r?.read ?? (async () => null), t = x.any();
    return new w_(i, t, o, this.rulesConfig, this.ctx);
  }
  async applyReadRule(e, r) {
    let i = this.rules[e];
    if (!i?.read)
      return (this.rulesConfig.defaultPolicy ?? "allow") === "deny" ? null : r;
    let o = await i.read(this.ctx, r);
    return ko(o, r);
  }
}, k_ = class extends Po {
  static {
    s(this, "RulesDatabaseWriter");
  }
  constructor(e, r, i, o) {
    let { db: t, tableMap: n, reader: a } = e._internals;
    super(t, n), this.inner = e, this.ctx = r, this.rules = i, this.rulesConfig = o, this.rulesReader = new zg(a, r, i, o), this.system = e.system;
  }
  rulesReader;
  normalizeId(e, r) {
    return this.rulesReader.normalizeId(e, r);
  }
  async get(e, r) {
    return this.rulesReader.get(e, r);
  }
  query(e) {
    return this.rulesReader.query(e);
  }
  async insert(e, r) {
    let i = e, o = this.rules[i];
    if (o?.insert) {
      let t = await o.insert(this.ctx, r);
      return this.inner.insert(
        e,
        t
      );
    }
    if ((this.rulesConfig.defaultPolicy ?? "allow") === "deny")
      throw new Error(`insert not allowed on ${i}`);
    return this.inner.insert(e, r);
  }
  async patch(e, r, i) {
    let o, t;
    i !== void 0 ? (o = r, t = i) : (o = e, t = r);
    let n = await this.rulesReader.get(o);
    if (n === null)
      throw new Error("no read access or doc does not exist");
    let a = Io(this.inner, o, this.rules, this.rulesConfig), u = a ? this.rules[a] : void 0;
    if (u?.patch) {
      let c = await u.patch(this.ctx, n, t);
      return this.inner.patch(
        o,
        c
      );
    }
    if ((this.rulesConfig.defaultPolicy ?? "allow") === "deny")
      throw new Error(`patch not allowed on ${a}`);
    return this.inner.patch(o, t);
  }
  async replace(e, r, i) {
    let o, t;
    i !== void 0 ? (o = r, t = i) : (o = e, t = r);
    let n = await this.rulesReader.get(o);
    if (n === null)
      throw new Error("no read access or doc does not exist");
    let a = Io(this.inner, o, this.rules, this.rulesConfig), u = a ? this.rules[a] : void 0;
    if (u?.replace) {
      let c = await u.replace(this.ctx, n, t);
      return this.inner.replace(o, c);
    }
    if ((this.rulesConfig.defaultPolicy ?? "allow") === "deny")
      throw new Error(`replace not allowed on ${a}`);
    return this.inner.replace(o, t);
  }
  async delete(e, r) {
    let i;
    r !== void 0 ? i = r : i = e;
    let o = await this.rulesReader.get(i);
    if (o === null)
      throw new Error("no read access or doc does not exist");
    let t = Io(this.inner, i, this.rules, this.rulesConfig), n = t ? this.rules[t] : void 0;
    if (n?.delete)
      return await n.delete(this.ctx, o), this.inner.delete(i);
    if ((this.rulesConfig.defaultPolicy ?? "allow") === "deny")
      throw new Error(`delete not allowed on ${t}`);
    return this.inner.delete(i);
  }
}, I_ = class Sg extends mf {
  static {
    s(this, "_AuditQueryChain");
  }
  afterRead;
  tableName;
  constructor(r, i, o, t) {
    super(r, i), this.afterRead = o, this.tableName = t;
  }
  createChain(r) {
    return new Sg(r, this.schema, this.afterRead, this.tableName);
  }
  async first() {
    let r = await super.first();
    return r !== null && await this.afterRead(this.tableName, r), r;
  }
  async unique() {
    let r = await super.unique();
    return r !== null && await this.afterRead(this.tableName, r), r;
  }
  async collect() {
    let r = await super.collect();
    for (let i of r)
      await this.afterRead(this.tableName, i);
    return r;
  }
  async take(r) {
    let i = await super.take(r);
    for (let o of i)
      await this.afterRead(this.tableName, o);
    return i;
  }
  async paginate(r) {
    let i = await super.paginate(r);
    for (let o of i.page)
      await this.afterRead(this.tableName, o);
    return i;
  }
  async *[Symbol.asyncIterator]() {
    for await (let r of super[Symbol.asyncIterator]())
      await this.afterRead(this.tableName, r), yield r;
  }
}, Og = class extends gf {
  static {
    s(this, "AuditDatabaseReader");
  }
  inner;
  afterRead;
  constructor(e, r) {
    let { db: i, tableMap: o } = e._internals;
    super(i, o), this.inner = e, this.afterRead = r.afterRead ?? (() => {
    }), this.system = e.system;
  }
  async get(e, r) {
    let i = await this.inner.get(e, r);
    if (i !== null) {
      let o = this.resolveTableFromId(
        r !== void 0 ? r : e,
        r !== void 0 ? e : void 0
      );
      o && await this.afterRead(o, i);
    }
    return i;
  }
  query(e) {
    let r = this.inner.query(e), i = x.any();
    return new I_(r, i, this.afterRead, e);
  }
  resolveTableFromId(e, r) {
    if (r) return r;
    for (let i of Object.keys(this.tableMap))
      if (this.inner.normalizeId(i, e))
        return i;
    return null;
  }
}, z_ = class extends Po {
  static {
    s(this, "AuditDatabaseWriter");
  }
  inner;
  auditReader;
  afterWrite;
  constructor(e, r) {
    let { db: i, tableMap: o, reader: t } = e._internals;
    super(i, o), this.inner = e, this.afterWrite = r.afterWrite, this.auditReader = r.afterRead ? new Og(t, { afterRead: r.afterRead }) : t, this.system = e.system;
  }
  normalizeId(e, r) {
    return this.auditReader.normalizeId(e, r);
  }
  async get(e, r) {
    return this.auditReader.get(e, r);
  }
  query(e) {
    return this.auditReader.query(e);
  }
  async insert(e, r) {
    let i = await this.inner.insert(e, r);
    return this.afterWrite && await this.afterWrite(e, { type: "insert", id: i, value: r }), i;
  }
  async patch(e, r, i) {
    let o, t;
    i !== void 0 ? (o = r, t = i) : (o = e, t = r);
    let n = await this.inner.get(o);
    if (i !== void 0 ? await this.inner.patch(e, r, i) : await this.inner.patch(o, t), this.afterWrite) {
      let a = this.resolveTableFromId(o);
      a && await this.afterWrite(a, { type: "patch", id: o, doc: n, value: t });
    }
  }
  async replace(e, r, i) {
    let o, t;
    i !== void 0 ? (o = r, t = i) : (o = e, t = r);
    let n = await this.inner.get(o);
    if (i !== void 0 ? await this.inner.replace(e, r, i) : await this.inner.replace(o, t), this.afterWrite) {
      let a = this.resolveTableFromId(o);
      a && await this.afterWrite(a, { type: "replace", id: o, doc: n, value: t });
    }
  }
  async delete(e, r) {
    let i;
    r !== void 0 ? i = r : i = e;
    let o = await this.inner.get(i);
    if (r !== void 0 ? await this.inner.delete(e, r) : await this.inner.delete(i), this.afterWrite) {
      let t = this.resolveTableFromId(i);
      t && await this.afterWrite(t, { type: "delete", id: i, doc: o });
    }
  }
  resolveTableFromId(e) {
    for (let r of Object.keys(this.inner._internals.tableMap))
      if (this.inner.normalizeId(r, e))
        return r;
    return null;
  }
};
var S_ = "__zodvexMeta";
function jg(e) {
  if (!(e == null || typeof e != "object" && typeof e != "function"))
    return e[S_];
}
s(jg, "readMeta");
var O_ = "__zodvexCodecBrand";
function j_(e, r) {
  Object.defineProperty(e, O_, {
    value: r,
    enumerable: !1,
    writable: !1,
    configurable: !1
  });
}
s(j_, "attachCodecBrand");
function jo(e) {
  let r = x.string().check(
    x.refine((o) => typeof o == "string" && o.length > 0, {
      message: `Invalid ID for table "${e}"`
    }),
    x.describe(`convexId:${e}`)
  );
  So.setMetadata(r, {
    isConvexId: !0,
    tableName: e
  });
  let i = r;
  return i._tableName = e, i;
}
s(jo, "id");
function Pg(e) {
  return e instanceof fe || e instanceof Re;
}
s(Pg, "isZodUnion");
function Dg(e) {
  return e instanceof fe, e._zod.def.options;
}
s(Dg, "getUnionOptions");
function P_(e) {
  if (e.length < 2)
    throw new Error(
      `z.union() requires at least 2 options, but received ${e.length}. This indicates an invalid union schema was passed to zodTable().`
    );
}
s(P_, "assertUnionOptions");
function Ng(e) {
  return P_(e), x.union(e);
}
s(Ng, "createUnionFromOptions");
function D_(e, r) {
  if (Pg(r)) {
    let o = Dg(r).map((t) => {
      if (t instanceof Q) {
        let n = {
          ...t._zod.def.shape,
          _id: jo(e),
          _creationTime: x.number()
        };
        return A(t, { ...t._zod.def, shape: n });
      }
      return t;
    });
    return Ng(o);
  }
  if (r instanceof Q) {
    let i = { ...r._zod.def.shape, _id: jo(e), _creationTime: x.number() };
    return A(r, { ...r._zod.def, shape: i });
  }
  return r;
}
s(D_, "addSystemFields");
function N_(e) {
  return e instanceof W ? e : new W({ type: "optional", innerType: e });
}
s(N_, "ensureOptional");
function T_(e) {
  let r = {};
  for (let [i, o] of Object.entries(e))
    r[i] = N_(o);
  return r;
}
s(T_, "createPartialShape");
function gg(e, r) {
  return x.object({
    _id: jo(e),
    _creationTime: x.optional(x.number()),
    ...T_(r)
  });
}
s(gg, "createUpdateObjectSchema");
function A_(e, r) {
  if (Pg(r)) {
    let i = Dg(r).map((o) => o instanceof Q ? gg(e, o._zod.def.shape) : o);
    return Ng(i);
  }
  return r instanceof Q ? gg(e, r._zod.def.shape) : r;
}
s(A_, "createSchemaUpdateSchema");
var hg = /* @__PURE__ */ Symbol.for("zodvex.zxDate");
function U_(e) {
  e[hg] = !0;
  let r = e._zod?.def;
  return r && (r[hg] = !0), e;
}
s(U_, "brandZxDate");
function E_() {
  return U_(
    wg(
      x.number(),
      // Wire: timestamp
      x.custom((e) => e instanceof Date, {
        message: "Expected Date instance"
      }),
      {
        decode: /* @__PURE__ */ s((e) => new Date(e), "decode"),
        encode: /* @__PURE__ */ s((e) => e.getTime(), "encode")
      }
    )
  );
}
s(E_, "date");
function C_(e, r, i, o) {
  let t = wg(e, r, i);
  return o?.brand && j_(t, o.brand), t;
}
s(C_, "codec");
function Do(e) {
  let r = /* @__PURE__ */ Symbol.for(`zodvex.zx.cache.${e}`), i = globalThis, o = i[r];
  if (o) return o;
  let t = /* @__PURE__ */ new WeakMap();
  return i[r] = t, t;
}
s(Do, "sharedWeakMap");
var vg = Do("base"), yg = Do("doc"), $g = Do("update"), bg = Do("docArray");
function hf(e) {
  let r = e.schema;
  return r instanceof S ? r : e.fields;
}
s(hf, "slimCacheKey");
function vf(e) {
  let r = e.schema;
  if (r?.base instanceof S) return r.base;
  if (r instanceof S) return r;
  let i = vg.get(e.fields);
  if (i) return i;
  if (Object.keys(e.fields).length === 0)
    throw new Error(`[zodvex] Cannot derive base schema for model '${e.name}'`);
  let o = x.object(e.fields);
  return vg.set(e.fields, o), o;
}
s(vf, "base");
function Tg(e) {
  let r = e.schema;
  if (r?.doc instanceof S) return r.doc;
  let i = hf(e), o = yg.get(i);
  if (o) return o;
  let t = D_(e.name, vf(e));
  return yg.set(i, t), t;
}
s(Tg, "doc");
function Z_(e) {
  let r = e.schema;
  if (r?.update instanceof S) return r.update;
  let i = hf(e), o = $g.get(i);
  if (o) return o;
  let t = A_(e.name, vf(e));
  return $g.set(i, t), t;
}
s(Z_, "update");
function R_(e) {
  let r = e.schema;
  if (r?.docArray instanceof S) return r.docArray;
  let i = hf(e), o = bg.get(i);
  if (o) return o;
  let t = x.array(Tg(e));
  return bg.set(i, t), t;
}
s(R_, "docArray");
function Ag(e) {
  return new Ne({ type: "nullable", innerType: e });
}
s(Ag, "nullable");
function zo(e) {
  return new W({ type: "optional", innerType: e });
}
s(zo, "optional");
function ff(e) {
  return zo(Ag(e));
}
s(ff, "nullableOptional2");
function F_() {
  return x.object({
    numItems: x.number(),
    cursor: Ag(x.string()),
    endCursor: ff(x.string()),
    id: zo(x.number()),
    maximumRowsRead: zo(x.number()),
    maximumBytesRead: zo(x.number())
  });
}
s(F_, "paginationOpts");
function L_(e) {
  return x.object({
    page: x.array(e),
    isDone: x.boolean(),
    continueCursor: x.string(),
    splitCursor: ff(x.string()),
    pageStatus: ff(x.enum(["SplitRecommended", "SplitRequired"]))
  });
}
s(L_, "paginationResult");
var pf = {
  /**
   * Date ↔ timestamp codec
   * @see {@link date}
   */
  date: E_,
  /**
   * Convex ID validator
   * @see {@link id}
   */
  id: jo,
  /**
   * Custom codec builder
   * @see {@link codec}
   */
  codec: C_,
  /**
   * Pagination options schema matching Convex's PaginationOptions type
   * @see {@link paginationOpts}
   */
  paginationOpts: F_,
  /**
   * Paginated result schema wrapping any item schema in Convex's PaginationResult shape
   * @see {@link paginationResult}
   */
  paginationResult: L_,
  /**
   * Base schema for a model (user fields only; no system fields).
   * For object models reconstructs from fields; for union models returns the
   * user-supplied union. Cached per-model.
   * @see {@link base}
   */
  base: vf,
  /**
   * Doc schema: model fields + _id + _creationTime
   * @see {@link doc}
   */
  doc: Tg,
  /**
   * Update schema: _id required, all other fields optional
   * @see {@link update}
   */
  update: Z_,
  /**
   * Doc array schema: z.array(doc(model))
   * @see {@link docArray}
   */
  docArray: R_
};
function V_(e) {
  return jg(e)?.type === "model";
}
s(V_, "isZodModelEntry");
function Ug(e) {
  let r = jg(e);
  if (!r || r.type !== "model")
    throw new Error(`Model '${e.name}' is missing zodvex model metadata.`);
  return r;
}
s(Ug, "getZodModelMeta");
function M_(e) {
  let r = Ug(e), o = r.definitionSource === "schema" || r.definitionSource == null && Object.keys(e.fields).length === 0 ? bt(b_(pf.base(e))) : bt(_g(e.fields));
  for (let [t, n] of Object.entries(e.indexes)) {
    let a = n.filter((u) => u !== "_creationTime");
    o = o.index(t, a);
  }
  for (let [t, n] of Object.entries(e.searchIndexes))
    o = o.searchIndex(t, n);
  for (let [t, n] of Object.entries(e.vectorIndexes))
    o = o.vectorIndex(t, n);
  return o;
}
s(M_, "tableFromModel");
function Eg(e) {
  let r = {}, i = {};
  for (let [n, a] of Object.entries(e))
    if (V_(a)) {
      if (a.name !== n)
        throw new Error(
          `Model name '${a.name}' does not match key '${n}'. The model name must match the key in the schema definition.`
        );
      r[n] = M_(a);
      let u = Ug(a);
      u.schemas ? i[n] = {
        doc: u.schemas.doc,
        insert: u.schemas.insert
      } : i[n] = {
        doc: pf.doc(a),
        insert: pf.base(a)
      };
    } else
      r[n] = a.table, i[n] = {
        doc: a.schema.doc,
        insert: a.schema.insert
      };
  let o = wo(r);
  return Object.assign(o, { __zodTableMap: i });
}
s(Eg, "defineZodSchema");

// ../../packages/zodvex/dist/index.js
var Cg = /* @__PURE__ */ new WeakMap(), B_ = {
  getMetadata: /* @__PURE__ */ s((e) => Cg.get(e), "getMetadata"),
  setMetadata: /* @__PURE__ */ s((e, r) => Cg.set(e, r), "setMetadata")
};
var Zg = /* @__PURE__ */ Symbol.for("zodvex.zxDate");
function J_(e) {
  e[Zg] = !0;
  let r = e._zod?.def;
  return r && (r[Zg] = !0), e;
}
s(J_, "brandZxDate");
var OD = x.discriminatedUnion("success", [
  x.object({ success: x.literal(!0) }),
  x.object({ success: x.literal(!1), error: x.string() })
]), jD = x.object({
  formErrors: x.array(x.string()),
  fieldErrors: x.record(x.string(), x.array(x.string()))
});
function Jg(e, r, i) {
  return x.codec(e, r, i);
}
s(Jg, "zodvexCodec");
var q_ = "__zodvexMeta";
function qg(e, r) {
  Object.defineProperty(e, q_, {
    value: r,
    enumerable: !1,
    writable: !1,
    configurable: !1
  });
}
s(qg, "attachMeta");
var K_ = "__zodvexCodecBrand";
function W_(e, r) {
  Object.defineProperty(e, K_, {
    value: r,
    enumerable: !1,
    writable: !1,
    configurable: !1
  });
}
s(W_, "attachCodecBrand");
function To(e) {
  let r = x.string().check(
    x.refine((o) => typeof o == "string" && o.length > 0, {
      message: `Invalid ID for table "${e}"`
    }),
    x.describe(`convexId:${e}`)
  );
  B_.setMetadata(r, {
    isConvexId: !0,
    tableName: e
  });
  let i = r;
  return i._tableName = e, i;
}
s(To, "id");
function Kg(e) {
  return e instanceof fe || e instanceof Re;
}
s(Kg, "isZodUnion");
function Wg(e) {
  return e instanceof fe, e._zod.def.options;
}
s(Wg, "getUnionOptions");
function G_(e) {
  if (e.length < 2)
    throw new Error(
      `z.union() requires at least 2 options, but received ${e.length}. This indicates an invalid union schema was passed to zodTable().`
    );
}
s(G_, "assertUnionOptions");
function Gg(e) {
  return G_(e), x.union(e);
}
s(Gg, "createUnionFromOptions");
function bf(e, r) {
  if (Kg(r)) {
    let o = Wg(r).map((t) => {
      if (t instanceof Q) {
        let n = {
          ...t._zod.def.shape,
          _id: To(e),
          _creationTime: x.number()
        };
        return A(t, { ...t._zod.def, shape: n });
      }
      return t;
    });
    return Gg(o);
  }
  if (r instanceof Q) {
    let i = { ...r._zod.def.shape, _id: To(e), _creationTime: x.number() };
    return A(r, { ...r._zod.def, shape: i });
  }
  return r;
}
s(bf, "addSystemFields");
function X_(e) {
  return e instanceof W ? e : new W({ type: "optional", innerType: e });
}
s(X_, "ensureOptional");
function Rg(e) {
  return new W({
    type: "optional",
    innerType: new Ne({ type: "nullable", innerType: e })
  });
}
s(Rg, "nullableOptional2");
function H_(e) {
  let r = {};
  for (let [i, o] of Object.entries(e))
    r[i] = X_(o);
  return r;
}
s(H_, "createPartialShape");
function yf(e, r) {
  return x.object({
    _id: To(e),
    _creationTime: x.optional(x.number()),
    ...H_(r)
  });
}
s(yf, "createUpdateObjectSchema");
function Xg(e) {
  return x.object({
    page: x.array(e),
    isDone: x.boolean(),
    continueCursor: x.string(),
    splitCursor: Rg(x.string()),
    pageStatus: Rg(x.enum(["SplitRecommended", "SplitRequired"]))
  });
}
s(Xg, "createPaginatedDocSchema");
function Q_(e, r, i = x.object(r)) {
  let o = bf(e, i);
  return {
    doc: o,
    base: i,
    insert: i,
    update: yf(e, r),
    docArray: x.array(o),
    paginatedDoc: Xg(o)
  };
}
s(Q_, "createObjectSchemaBundle");
function Hg(e, r) {
  if (Kg(r)) {
    let i = Wg(r).map((o) => o instanceof Q ? yf(e, o._zod.def.shape) : o);
    return Gg(i);
  }
  return r instanceof Q ? yf(e, r._zod.def.shape) : r;
}
s(Hg, "createSchemaUpdateSchema");
function Y_(e, r) {
  let i = bf(e, r);
  return {
    doc: i,
    base: r,
    insert: r,
    update: Hg(e, r),
    docArray: x.array(i),
    paginatedDoc: Xg(i)
  };
}
s(Y_, "createSchemaBundle");
function Qg(e, r) {
  let i;
  return {
    get: /* @__PURE__ */ s(() => i || (i = r ?? x.object(e), i), "get")
  };
}
s(Qg, "lazyValidator");
function cn(e, r, i, o, t = {}, n = {}, a = {}, u = null) {
  let c = Qg(r, u), l = {
    name: e,
    fields: r,
    schema: i,
    indexes: t,
    searchIndexes: n,
    vectorIndexes: a,
    get validator() {
      return c.get();
    },
    index(d, f) {
      return cn(
        e,
        r,
        i,
        o,
        { ...t, [d]: [...f, "_creationTime"] },
        n,
        a,
        u
      );
    },
    searchIndex(d, f) {
      return cn(
        e,
        r,
        i,
        o,
        t,
        { ...n, [d]: f },
        a,
        u
      );
    },
    vectorIndex(d, f) {
      return cn(
        e,
        r,
        i,
        o,
        t,
        n,
        { ...a, [d]: f },
        u
      );
    }
  };
  return qg(l, { type: "model", tableName: e, definitionSource: o, schemas: i }), l;
}
s(cn, "createModel");
function ln(e, r, i, o, t = {}, n = {}, a = {}) {
  let u = Qg(r, i), c = {
    name: e,
    fields: r,
    indexes: t,
    searchIndexes: n,
    vectorIndexes: a,
    get validator() {
      return u.get();
    },
    index(l, d) {
      return ln(
        e,
        r,
        i,
        o,
        { ...t, [l]: [...d, "_creationTime"] },
        n,
        a
      );
    },
    searchIndex(l, d) {
      return ln(
        e,
        r,
        i,
        o,
        t,
        { ...n, [l]: d },
        a
      );
    },
    vectorIndex(l, d) {
      return ln(e, r, i, o, t, n, {
        ...a,
        [l]: d
      });
    }
  };
  return i !== null && (c.schema = i), qg(c, { type: "model", tableName: e, definitionSource: o }), c;
}
s(ln, "createSlimModel");
function Fg(e, r, i) {
  let o = i?.schemaHelpers === !1;
  if (r instanceof S)
    return o ? ln(e, {}, r, "schema") : cn(
      e,
      {},
      Y_(e, r),
      "schema",
      void 0,
      void 0,
      void 0,
      r
    );
  let t = r;
  return o ? ln(e, t, null, "shape") : cn(e, t, Q_(e, t), "shape");
}
s(Fg, "defineZodModel");
function Yg(e, r, i) {
  return r instanceof S, Fg(e, r, i);
}
s(Yg, "defineZodModel2");
function ex() {
  return J_(
    Jg(
      x.number(),
      // Wire: timestamp
      x.custom((e) => e instanceof Date, {
        message: "Expected Date instance"
      }),
      {
        decode: /* @__PURE__ */ s((e) => new Date(e), "decode"),
        encode: /* @__PURE__ */ s((e) => e.getTime(), "encode")
      }
    )
  );
}
s(ex, "date");
function tx(e, r, i, o) {
  let t = Jg(e, r, i);
  return o?.brand && W_(t, o.brand), t;
}
s(tx, "codec");
function Ao(e) {
  let r = /* @__PURE__ */ Symbol.for(`zodvex.zx.cache.${e}`), i = globalThis, o = i[r];
  if (o) return o;
  let t = /* @__PURE__ */ new WeakMap();
  return i[r] = t, t;
}
s(Ao, "sharedWeakMap");
var Lg = Ao("base"), Vg = Ao("doc"), Mg = Ao("update"), Bg = Ao("docArray");
function _f(e) {
  let r = e.schema;
  return r instanceof S ? r : e.fields;
}
s(_f, "slimCacheKey");
function xf(e) {
  let r = e.schema;
  if (r?.base instanceof S) return r.base;
  if (r instanceof S) return r;
  let i = Lg.get(e.fields);
  if (i) return i;
  if (Object.keys(e.fields).length === 0)
    throw new Error(`[zodvex] Cannot derive base schema for model '${e.name}'`);
  let o = x.object(e.fields);
  return Lg.set(e.fields, o), o;
}
s(xf, "base");
function eh(e) {
  let r = e.schema;
  if (r?.doc instanceof S) return r.doc;
  let i = _f(e), o = Vg.get(i);
  if (o) return o;
  let t = bf(e.name, xf(e));
  return Vg.set(i, t), t;
}
s(eh, "doc");
function rx(e) {
  let r = e.schema;
  if (r?.update instanceof S) return r.update;
  let i = _f(e), o = Mg.get(i);
  if (o) return o;
  let t = Hg(e.name, xf(e));
  return Mg.set(i, t), t;
}
s(rx, "update");
function nx(e) {
  let r = e.schema;
  if (r?.docArray instanceof S) return r.docArray;
  let i = _f(e), o = Bg.get(i);
  if (o) return o;
  let t = x.array(eh(e));
  return Bg.set(i, t), t;
}
s(nx, "docArray");
function th(e) {
  return new Ne({ type: "nullable", innerType: e });
}
s(th, "nullable");
function No(e) {
  return new W({ type: "optional", innerType: e });
}
s(No, "optional");
function $f(e) {
  return No(th(e));
}
s($f, "nullableOptional3");
function ix() {
  return x.object({
    numItems: x.number(),
    cursor: th(x.string()),
    endCursor: $f(x.string()),
    id: No(x.number()),
    maximumRowsRead: No(x.number()),
    maximumBytesRead: No(x.number())
  });
}
s(ix, "paginationOpts");
function ox(e) {
  return x.object({
    page: x.array(e),
    isDone: x.boolean(),
    continueCursor: x.string(),
    splitCursor: $f(x.string()),
    pageStatus: $f(x.enum(["SplitRecommended", "SplitRequired"]))
  });
}
s(ox, "paginationResult");
var Uo = {
  /**
   * Date ↔ timestamp codec
   * @see {@link date}
   */
  date: ex,
  /**
   * Convex ID validator
   * @see {@link id}
   */
  id: To,
  /**
   * Custom codec builder
   * @see {@link codec}
   */
  codec: tx,
  /**
   * Pagination options schema matching Convex's PaginationOptions type
   * @see {@link paginationOpts}
   */
  paginationOpts: ix,
  /**
   * Paginated result schema wrapping any item schema in Convex's PaginationResult shape
   * @see {@link paginationResult}
   */
  paginationResult: ox,
  /**
   * Base schema for a model (user fields only; no system fields).
   * For object models reconstructs from fields; for union models returns the
   * user-supplied union. Cached per-model.
   * @see {@link base}
   */
  base: xf,
  /**
   * Doc schema: model fields + _id + _creationTime
   * @see {@link doc}
   */
  doc: eh,
  /**
   * Update schema: _id required, all other fields optional
   * @see {@link update}
   */
  update: rx,
  /**
   * Doc array schema: z.array(doc(model))
   * @see {@link docArray}
   */
  docArray: nx
};

// results/descriptor-experiment-2026-09-09/memory/fixtures/0/counters.mjs
var dn = { models: [], descriptors: [] };

// results/descriptor-experiment-2026-09-09/memory/fixtures/0/codecs.mjs
var lr = class {
  static {
    s(this, "SecretText");
  }
  constructor(r) {
    this.value = r;
  }
  reveal() {
    return this.value;
  }
}, rh = x.codec(x.string(), x.instanceof(lr), {
  decode: /* @__PURE__ */ s((e) => new lr(e), "decode"),
  encode: /* @__PURE__ */ s((e) => e.reveal(), "encode")
}), AD = x.codec(x.string(), x.string().min(3), {
  decode: /* @__PURE__ */ s((e) => e, "decode"),
  encode: /* @__PURE__ */ s((e) => e, "encode")
});

// results/descriptor-experiment-2026-09-09/memory/fixtures/0/models.mjs
function nh() {
  return dn.models.push("probe"), Yg("probe", {
    name: x.string(),
    createdAt: Uo.date(),
    secret: rh,
    updatedAt: x.optional(Uo.date()),
    nested: x.object({ history: x.array(Uo.date()), note: x.string() })
  });
}
s(nh, "probeModel");

// results/descriptor-experiment-2026-09-09/memory/fixtures/0/models/probe.ts
var ih = nh();

// results/descriptor-experiment-2026-09-09/memory/fixtures/0/eager.ts
var ax = Eg({ probe: ih }), wf = ax.__zodTableMap;

// results/descriptor-experiment-2026-09-09/memory/fixtures/0/db-fixture.mjs
function sx(e = []) {
  let r = new Map(e.map((n) => [n._id, n])), i = [], o = /* @__PURE__ */ s((n) => n.length === 2 ? n[1] : n[0], "idFrom");
  return { database: {
    normalizeId(n, a) {
      return String(a).startsWith(`${n}:`) ? a : null;
    },
    async get(...n) {
      return i.push("get"), r.get(o(n)) ?? null;
    },
    query(n) {
      return { async take(a) {
        return i.push("take"), [...r.values()].filter((u) => u._id.startsWith(`${n}:`)).slice(0, a);
      } };
    },
    async insert(n, a) {
      i.push("insert");
      let u = `${n}:${r.size + 1}`;
      return r.set(u, { ...a, _id: u, _creationTime: 100 }), u;
    },
    async patch(...n) {
      i.push("patch");
      let a = n.at(-2), u = n.at(-1), c = { ...r.get(a), ...u };
      for (let [l, d] of Object.entries(u)) d === void 0 && delete c[l];
      r.set(a, c);
    },
    async replace(...n) {
      i.push("replace");
      let a = n.at(-2), u = r.get(a);
      r.set(a, { ...n.at(-1), _id: a, _creationTime: u._creationTime });
    }
  }, calls: i, documents: r };
}
s(sx, "memoryDatabase");
var Qe = 17e11;
function oh() {
  return {
    name: "before",
    createdAt: new Date(Qe),
    secret: new lr("value"),
    nested: { history: [new Date(Qe + 1)], note: "preserved" }
  };
}
s(oh, "runtimeValue");
async function ah(e) {
  let r = sx(), i = new Po(r.database, e), o = await i.insert("probe", oh()), t = await i.get("probe", o), n = r.documents.get(o);
  await i.patch("probe", o, { updatedAt: new Date(Qe + 2), name: "patched" });
  let a = await i.get("probe", o);
  await i.patch("probe", o, { updatedAt: void 0 });
  let u = await i.get("probe", o);
  await i.replace("probe", o, { ...oh(), name: "replaced" });
  let [c] = await i.query("probe").take(1);
  return {
    wireEncoded: n.createdAt === Qe && n.secret === "value" && n.nested.history[0] === Qe + 1,
    decoded: t.createdAt.getTime() === Qe && t.secret.reveal() === "value" && t.nested.history[0].getTime() === Qe + 1,
    codecPatch: a.updatedAt.getTime() === Qe + 2,
    ordinaryPatch: a.name === "patched",
    unset: !("updatedAt" in u),
    replaceAndQuery: c.name === "replaced" && c.secret.reveal() === "value",
    calls: r.calls
  };
}
s(ah, "exercise");

// consumerProbe.ts
var n6 = ux({ args: {}, returns: y.any(), handler: /* @__PURE__ */ s(async () => {
  let e = await ah(wf);
  if (typeof globalThis.gc != "function") throw new Error("GC diagnostic unavailable");
  globalThis.gc(), globalThis.gc();
  let r = Object.keys(wf).sort();
  return {
    nonce: "2ac3e3e5-d534-466f-8da2-1df32cb02c8e",
    kind: "eager",
    count: 0,
    operation: e,
    models: dn.models,
    descriptors: dn.descriptors,
    tables: r,
    checksum: r.reduce((i, o) => i + o.length, 0)
  };
}, "handler") });
export {
  n6 as default
};
