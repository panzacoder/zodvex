import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(10, 32);
