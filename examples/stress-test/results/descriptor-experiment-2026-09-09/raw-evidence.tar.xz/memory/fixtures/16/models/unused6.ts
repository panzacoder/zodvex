import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(6, 32);
