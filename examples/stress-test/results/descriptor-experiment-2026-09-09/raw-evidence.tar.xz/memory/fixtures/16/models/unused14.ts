import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(14, 32);
