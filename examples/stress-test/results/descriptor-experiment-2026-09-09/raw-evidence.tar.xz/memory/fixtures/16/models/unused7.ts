import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(7, 32);
