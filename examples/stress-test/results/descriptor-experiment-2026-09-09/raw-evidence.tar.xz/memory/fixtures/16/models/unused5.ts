import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(5, 32);
