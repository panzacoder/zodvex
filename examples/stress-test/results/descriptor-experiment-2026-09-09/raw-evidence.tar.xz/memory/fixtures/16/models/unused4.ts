import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(4, 32);
