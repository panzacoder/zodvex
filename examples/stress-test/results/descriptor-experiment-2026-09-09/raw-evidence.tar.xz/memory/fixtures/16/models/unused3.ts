import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(3, 32);
