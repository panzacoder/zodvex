// Historical PR80 generated descriptor; experimental and incompatible with current full-read contract

import d_0 from './probe.js'
import d_1 from './unused0.js'
import d_2 from './unused1.js'
import d_3 from './unused10.js'
import d_4 from './unused11.js'
import d_5 from './unused12.js'
import d_6 from './unused13.js'
import d_7 from './unused14.js'
import d_8 from './unused15.js'
import d_9 from './unused2.js'
import d_10 from './unused3.js'
import d_11 from './unused4.js'
import d_12 from './unused5.js'
import d_13 from './unused6.js'
import d_14 from './unused7.js'
import d_15 from './unused8.js'
import d_16 from './unused9.js'

/** Central tableMap: codec-bearing tables only at O(codec fields) cost.
 *  Tables absent here have no codecs — wrapper passthrough is correct. */
export const zodvexTableMap = {
  'probe': d_0,
  'unused0': d_1,
  'unused1': d_2,
  'unused10': d_3,
  'unused11': d_4,
  'unused12': d_5,
  'unused13': d_6,
  'unused14': d_7,
  'unused15': d_8,
  'unused2': d_9,
  'unused3': d_10,
  'unused4': d_11,
  'unused5': d_12,
  'unused6': d_13,
  'unused7': d_14,
  'unused8': d_15,
  'unused9': d_16,
}

/** Fingerprint of the codec-path spec this map was generated from. */
export const zodvexTableMapFingerprint = 'fa4bdec0ee166281c856ae619a92a24491c3375d0a98f09ebc84e3b9ec69630e'
