import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(2, 32);
