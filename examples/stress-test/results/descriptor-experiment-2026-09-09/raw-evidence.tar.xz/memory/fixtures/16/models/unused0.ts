import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(0, 32);
