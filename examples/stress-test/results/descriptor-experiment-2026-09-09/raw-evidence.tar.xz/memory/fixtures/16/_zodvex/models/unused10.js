import { initialized } from '../../counters.mjs';
initialized.descriptors.push("unused10");
// Historical PR80 generated descriptor; experimental and incompatible with current full-read contract

import { z } from 'zod'
import { zx } from 'zodvex'
import { secretCodec } from '../../codecs.mjs'

// Minimal schema: codec subtrees only; unknown keys pass through (loose).
const schema = z.looseObject({ createdAt: zx.date(), nested: z.looseObject({ history: z.array(zx.date()), }), secret: secretCodec, updatedAt: z.optional(zx.date()), })

export default { doc: schema, insert: schema }
