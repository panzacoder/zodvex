import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(13, 32);
