import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(12, 32);
