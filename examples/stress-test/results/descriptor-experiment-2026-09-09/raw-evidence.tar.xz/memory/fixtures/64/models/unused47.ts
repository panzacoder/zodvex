import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(47, 32);
