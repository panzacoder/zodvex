import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(26, 32);
