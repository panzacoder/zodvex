import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(31, 32);
