import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(30, 32);
