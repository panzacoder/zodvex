import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(38, 32);
