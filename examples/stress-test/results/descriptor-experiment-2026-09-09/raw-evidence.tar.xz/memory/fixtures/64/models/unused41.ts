import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(41, 32);
