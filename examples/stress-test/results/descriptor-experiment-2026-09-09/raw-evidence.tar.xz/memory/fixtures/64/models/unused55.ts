import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(55, 32);
