import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(17, 32);
