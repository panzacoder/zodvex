import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(20, 32);
