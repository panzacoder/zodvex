import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(50, 32);
