import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(52, 32);
