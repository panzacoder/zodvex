import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(63, 32);
