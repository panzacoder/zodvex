import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(42, 32);
