import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(27, 32);
