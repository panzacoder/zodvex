import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(23, 32);
