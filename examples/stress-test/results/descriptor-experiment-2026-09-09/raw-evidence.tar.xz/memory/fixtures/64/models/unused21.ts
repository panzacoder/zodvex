import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(21, 32);
