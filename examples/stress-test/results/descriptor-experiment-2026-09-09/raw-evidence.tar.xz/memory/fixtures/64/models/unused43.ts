import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(43, 32);
