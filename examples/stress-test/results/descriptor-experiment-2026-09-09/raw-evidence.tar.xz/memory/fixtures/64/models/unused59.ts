import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(59, 32);
