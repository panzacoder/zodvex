import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(62, 32);
