import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(29, 32);
