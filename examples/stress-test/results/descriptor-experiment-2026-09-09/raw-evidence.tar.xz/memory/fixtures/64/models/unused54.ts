import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(54, 32);
