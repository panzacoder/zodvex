import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(24, 32);
