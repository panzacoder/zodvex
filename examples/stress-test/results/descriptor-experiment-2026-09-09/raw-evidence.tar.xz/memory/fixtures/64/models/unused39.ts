import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(39, 32);
