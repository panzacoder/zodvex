import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(36, 32);
