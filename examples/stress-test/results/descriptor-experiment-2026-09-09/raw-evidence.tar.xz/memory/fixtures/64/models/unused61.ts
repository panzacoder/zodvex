import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(61, 32);
