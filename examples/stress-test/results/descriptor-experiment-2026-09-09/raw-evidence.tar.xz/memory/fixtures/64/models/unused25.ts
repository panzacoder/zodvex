import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(25, 32);
