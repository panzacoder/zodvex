import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(34, 32);
