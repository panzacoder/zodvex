import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(58, 32);
