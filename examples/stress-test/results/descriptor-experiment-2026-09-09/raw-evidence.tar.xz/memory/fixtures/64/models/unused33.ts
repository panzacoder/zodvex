import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(33, 32);
