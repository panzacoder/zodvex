import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(16, 32);
