// Historical PR80 generated descriptor; experimental and incompatible with current full-read contract

import d_0 from './probe.js'
import d_1 from './unused0.js'
import d_2 from './unused1.js'
import d_3 from './unused10.js'
import d_4 from './unused11.js'
import d_5 from './unused12.js'
import d_6 from './unused13.js'
import d_7 from './unused14.js'
import d_8 from './unused15.js'
import d_9 from './unused16.js'
import d_10 from './unused17.js'
import d_11 from './unused18.js'
import d_12 from './unused19.js'
import d_13 from './unused2.js'
import d_14 from './unused20.js'
import d_15 from './unused21.js'
import d_16 from './unused22.js'
import d_17 from './unused23.js'
import d_18 from './unused24.js'
import d_19 from './unused25.js'
import d_20 from './unused26.js'
import d_21 from './unused27.js'
import d_22 from './unused28.js'
import d_23 from './unused29.js'
import d_24 from './unused3.js'
import d_25 from './unused30.js'
import d_26 from './unused31.js'
import d_27 from './unused32.js'
import d_28 from './unused33.js'
import d_29 from './unused34.js'
import d_30 from './unused35.js'
import d_31 from './unused36.js'
import d_32 from './unused37.js'
import d_33 from './unused38.js'
import d_34 from './unused39.js'
import d_35 from './unused4.js'
import d_36 from './unused40.js'
import d_37 from './unused41.js'
import d_38 from './unused42.js'
import d_39 from './unused43.js'
import d_40 from './unused44.js'
import d_41 from './unused45.js'
import d_42 from './unused46.js'
import d_43 from './unused47.js'
import d_44 from './unused48.js'
import d_45 from './unused49.js'
import d_46 from './unused5.js'
import d_47 from './unused50.js'
import d_48 from './unused51.js'
import d_49 from './unused52.js'
import d_50 from './unused53.js'
import d_51 from './unused54.js'
import d_52 from './unused55.js'
import d_53 from './unused56.js'
import d_54 from './unused57.js'
import d_55 from './unused58.js'
import d_56 from './unused59.js'
import d_57 from './unused6.js'
import d_58 from './unused60.js'
import d_59 from './unused61.js'
import d_60 from './unused62.js'
import d_61 from './unused63.js'
import d_62 from './unused7.js'
import d_63 from './unused8.js'
import d_64 from './unused9.js'

/** Central tableMap: codec-bearing tables only at O(codec fields) cost.
 *  Tables absent here have no codecs — wrapper passthrough is correct. */
export const zodvexTableMap = {
  'probe': d_0,
  'unused0': d_1,
  'unused1': d_2,
  'unused10': d_3,
  'unused11': d_4,
  'unused12': d_5,
  'unused13': d_6,
  'unused14': d_7,
  'unused15': d_8,
  'unused16': d_9,
  'unused17': d_10,
  'unused18': d_11,
  'unused19': d_12,
  'unused2': d_13,
  'unused20': d_14,
  'unused21': d_15,
  'unused22': d_16,
  'unused23': d_17,
  'unused24': d_18,
  'unused25': d_19,
  'unused26': d_20,
  'unused27': d_21,
  'unused28': d_22,
  'unused29': d_23,
  'unused3': d_24,
  'unused30': d_25,
  'unused31': d_26,
  'unused32': d_27,
  'unused33': d_28,
  'unused34': d_29,
  'unused35': d_30,
  'unused36': d_31,
  'unused37': d_32,
  'unused38': d_33,
  'unused39': d_34,
  'unused4': d_35,
  'unused40': d_36,
  'unused41': d_37,
  'unused42': d_38,
  'unused43': d_39,
  'unused44': d_40,
  'unused45': d_41,
  'unused46': d_42,
  'unused47': d_43,
  'unused48': d_44,
  'unused49': d_45,
  'unused5': d_46,
  'unused50': d_47,
  'unused51': d_48,
  'unused52': d_49,
  'unused53': d_50,
  'unused54': d_51,
  'unused55': d_52,
  'unused56': d_53,
  'unused57': d_54,
  'unused58': d_55,
  'unused59': d_56,
  'unused6': d_57,
  'unused60': d_58,
  'unused61': d_59,
  'unused62': d_60,
  'unused63': d_61,
  'unused7': d_62,
  'unused8': d_63,
  'unused9': d_64,
}

/** Fingerprint of the codec-path spec this map was generated from. */
export const zodvexTableMapFingerprint = '6e64e94ca19da45bd4d8c9ce04d642e4f8b77958db76b45fc6d89e7dd995d4d6'
