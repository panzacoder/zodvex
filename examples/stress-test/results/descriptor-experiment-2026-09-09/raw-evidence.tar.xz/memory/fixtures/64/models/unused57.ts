import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(57, 32);
