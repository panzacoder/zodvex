import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(40, 32);
