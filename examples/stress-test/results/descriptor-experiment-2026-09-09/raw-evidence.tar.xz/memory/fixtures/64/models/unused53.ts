import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(53, 32);
