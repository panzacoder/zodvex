import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(22, 32);
