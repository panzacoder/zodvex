import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(49, 32);
