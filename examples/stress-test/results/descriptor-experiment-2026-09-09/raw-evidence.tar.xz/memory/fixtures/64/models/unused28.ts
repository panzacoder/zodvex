import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(28, 32);
