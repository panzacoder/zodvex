import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(45, 32);
