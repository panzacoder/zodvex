import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(48, 32);
