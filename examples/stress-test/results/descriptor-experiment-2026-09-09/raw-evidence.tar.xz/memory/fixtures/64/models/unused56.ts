import { backgroundModel } from '../models.mjs';
export const Model = backgroundModel(56, 32);
