export { default } from './eager.ts';
