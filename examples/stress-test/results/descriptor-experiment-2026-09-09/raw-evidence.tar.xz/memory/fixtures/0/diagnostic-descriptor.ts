// Diagnostic adapter only: not a Convex SchemaDefinition.
import {tableMap} from './descriptor.ts';
export default {__zodTableMap:tableMap};
