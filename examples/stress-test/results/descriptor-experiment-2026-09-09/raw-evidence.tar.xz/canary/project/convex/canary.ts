import {internalMutation} from './_generated/server';
import {v} from 'convex/values';
import {z} from 'zod';
import {ZodvexDatabaseWriter} from 'zodvex/server';
import {tableMap as full} from './fixture/eager';
import {tableMap as descriptor} from './fixture/descriptor';
import eventDescriptor from './fixture/_zodvex/models/events.js';
import {validatedTextCodec} from './fixture/codecs.mjs';
import {runtimeValue,TS} from './fixture/db_fixture.mjs';
const eventSchema=z.discriminatedUnion('kind',[z.object({kind:z.literal('checked'),text:validatedTextCodec}),z.object({kind:z.literal('plain'),name:z.string()})]);
const rowValidator=v.object({kind:v.string(),encoded:v.boolean(),decoded:v.boolean(),codecPatch:v.boolean(),ordinaryPatch:v.boolean(),unset:v.boolean(),replace:v.boolean()});
export const verify=internalMutation({args:{},returns:v.object({rows:v.array(rowValidator),wireValidStored:v.boolean(),fullRejected:v.boolean(),descriptorReturnedRaw:v.boolean(),cleaned:v.boolean()}),handler:async(ctx)=>{
 const rows=[];
 for(const [kind,tableMap] of [['full',full],['descriptor',descriptor]] as const){
  const db=new ZodvexDatabaseWriter(ctx.db,tableMap);
  const id=await db.insert('probe',runtimeValue());
  const wire=await ctx.db.get('probe',id);
  const got=await db.get('probe',id);
  await db.patch('probe',id,{updatedAt:new Date(TS+2),name:'patched'});
  const patched=await db.get('probe',id);
  await db.patch('probe',id,{updatedAt:undefined});
  const unset=await db.get('probe',id);
  await db.replace('probe',id,{...runtimeValue(),name:'replaced'});
  const replaced=await db.get('probe',id);
  rows.push({kind,encoded:wire?.createdAt===TS&&wire?.secret==='value',decoded:got?.createdAt.getTime()===TS&&got?.secret.reveal()==='value',codecPatch:patched?.updatedAt?.getTime()===TS+2,ordinaryPatch:patched?.name==='patched',unset:!('updatedAt' in unset!),replace:replaced?.name==='replaced'&&replaced?.secret.reveal()==='value'});
  await ctx.db.delete('probe',id);
 }
 const id=await ctx.db.insert('events',{kind:'checked',text:'x'});
 const wire=await ctx.db.get('events',id);
 const fullDb=new ZodvexDatabaseWriter(ctx.db,{events:{doc:eventSchema,insert:eventSchema}});
 const descriptorDb=new ZodvexDatabaseWriter(ctx.db,{events:eventDescriptor});
 let fullRejected=false;
 try{await fullDb.get('events',id)}catch{fullRejected=true}
 const decoded=await descriptorDb.get('events',id);
 await ctx.db.delete('events',id);
 return {rows,wireValidStored:wire?.kind==='checked'&&wire.text==='x',fullRejected,descriptorReturnedRaw:(decoded as any)?.text==='x',cleaned:(await ctx.db.query('probe').take(1)).length===0&&(await ctx.db.query('events').take(1)).length===0};
}});
