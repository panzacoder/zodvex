import {defineSchema,defineTable} from 'convex/server';
import {v} from 'convex/values';
export default defineSchema({
 probe:defineTable({name:v.string(),createdAt:v.number(),secret:v.string(),updatedAt:v.optional(v.number()),nested:v.object({history:v.array(v.number()),note:v.string()})}),
 events:defineTable(v.union(v.object({kind:v.literal('checked'),text:v.string()}),v.object({kind:v.literal('plain'),name:v.string()})))
});
