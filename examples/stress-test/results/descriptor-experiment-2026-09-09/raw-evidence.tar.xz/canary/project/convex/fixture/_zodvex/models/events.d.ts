import type {$ZodType} from 'zod/v4/core';
declare const descriptor:{doc:$ZodType;insert:$ZodType};export default descriptor;
