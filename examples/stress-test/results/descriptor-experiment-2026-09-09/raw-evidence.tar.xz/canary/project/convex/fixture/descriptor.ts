export { zodvexTableMap as tableMap } from './_zodvex/models/index.js';
