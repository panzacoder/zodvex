import { probeModel } from '../models.mjs';
export const Model = probeModel();
