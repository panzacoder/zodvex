// Historical PR80 generated descriptor; experimental and incompatible with current full-read contract

import { z } from 'zod'
import { validatedTextCodec } from '../../codecs.mjs'

// Minimal schema: codec subtrees only; unknown keys pass through (loose).
const schema = z.union([z.looseObject({ kind: z.literal("checked"), text: validatedTextCodec, }), z.looseObject({})])

export default { doc: schema, insert: schema }
