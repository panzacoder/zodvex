import { defineZodSchema } from 'zodvex/server';
import { Model as M0 } from './models/probe.ts';
const schema = defineZodSchema({"probe":M0});
export const tableMap = schema.__zodTableMap;
export default schema;
