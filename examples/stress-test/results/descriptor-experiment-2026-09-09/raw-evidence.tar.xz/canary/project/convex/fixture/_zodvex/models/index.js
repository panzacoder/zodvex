// Historical PR80 generated descriptor; experimental and incompatible with current full-read contract

import d_0 from './probe.js'

/** Central tableMap: codec-bearing tables only at O(codec fields) cost.
 *  Tables absent here have no codecs — wrapper passthrough is correct. */
export const zodvexTableMap = {
  'probe': d_0,
}

/** Fingerprint of the codec-path spec this map was generated from. */
export const zodvexTableMapFingerprint = 'e800325ea72af5af0f0150b6260335a2168f64e35ff1e68af189ae527e2605a9'
