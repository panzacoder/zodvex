/* eslint-disable */
/**
 * Generated `api` utility.
 *
 * THIS CODE IS AUTOMATICALLY GENERATED.
 *
 * To regenerate, run `npx convex dev`.
 * @module
 */

import type * as canary from "../canary.js";
import type * as fixture__zodvex_models_events from "../fixture/_zodvex/models/events.js";
import type * as fixture__zodvex_models_index from "../fixture/_zodvex/models/index.js";
import type * as fixture__zodvex_models_probe from "../fixture/_zodvex/models/probe.js";
import type * as fixture_codecs from "../fixture/codecs.js";
import type * as fixture_counters from "../fixture/counters.js";
import type * as fixture_db_fixture from "../fixture/db_fixture.js";
import type * as fixture_descriptor from "../fixture/descriptor.js";
import type * as fixture_eager from "../fixture/eager.js";
import type * as fixture_models from "../fixture/models.js";
import type * as fixture_models_probe from "../fixture/models/probe.js";

import type {
  ApiFromModules,
  FilterApi,
  FunctionReference,
} from "convex/server";

declare const fullApi: ApiFromModules<{
  canary: typeof canary;
  "fixture/_zodvex/models/events": typeof fixture__zodvex_models_events;
  "fixture/_zodvex/models/index": typeof fixture__zodvex_models_index;
  "fixture/_zodvex/models/probe": typeof fixture__zodvex_models_probe;
  "fixture/codecs": typeof fixture_codecs;
  "fixture/counters": typeof fixture_counters;
  "fixture/db_fixture": typeof fixture_db_fixture;
  "fixture/descriptor": typeof fixture_descriptor;
  "fixture/eager": typeof fixture_eager;
  "fixture/models": typeof fixture_models;
  "fixture/models/probe": typeof fixture_models_probe;
}>;

/**
 * A utility for referencing Convex functions in your app's public API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = api.myModule.myFunction;
 * ```
 */
export declare const api: FilterApi<
  typeof fullApi,
  FunctionReference<any, "public">
>;

/**
 * A utility for referencing Convex functions in your app's internal API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = internal.myModule.myFunction;
 * ```
 */
export declare const internal: FilterApi<
  typeof fullApi,
  FunctionReference<any, "internal">
>;

export declare const components: {};
