# Same-build repeatability evidence

Six independent collections from the same built Zodvex JavaScript and local
Convex backend, three labeled baseline and three candidate to exercise the
comparison protocol. No optimization occurred between the groups.

Each collection has original manifest, calls, completion summary, source bundles,
and GC excerpts. All are synthetic benchmark fixtures, not customer schemas.
To recheck with the repository comparator after extraction:

bun /path/to/repo/examples/stress-test/memory/compare.mjs --baseline=baseline-1,baseline-2,baseline-3 --candidate=candidate-1,candidate-2,candidate-3

memory/ preserves the exact collector, fixture and comparator source used.
