var fd = Object.defineProperty;
var s = (e, t) => fd(e, "name", { value: t, configurable: !0 });
var et = (e, t) => {
  for (var r in t)
    fd(e, r, { get: t[r], enumerable: !0 });
};

// graphProbe.ts
import { query as Hw } from "convex:/_system/repl/wrappers.js";

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/base64.js
var Pe = [], _e = [], xg = Uint8Array, xi = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
for (tt = 0, pd = xi.length; tt < pd; ++tt)
  Pe[tt] = xi[tt], _e[xi.charCodeAt(tt)] = tt;
var tt, pd;
_e[45] = 62;
_e[95] = 63;
function wg(e) {
  var t = e.length;
  if (t % 4 > 0)
    throw new Error("Invalid string. Length must be a multiple of 4");
  var r = e.indexOf("=");
  r === -1 && (r = t);
  var o = r === t ? 0 : 4 - r % 4;
  return [r, o];
}
s(wg, "getLens");
function Ig(e, t, r) {
  return (t + r) * 3 / 4 - r;
}
s(Ig, "_byteLength");
function Bt(e) {
  var t, r = wg(e), o = r[0], n = r[1], i = new xg(Ig(e, o, n)), a = 0, u = n > 0 ? o - 4 : o, c;
  for (c = 0; c < u; c += 4)
    t = _e[e.charCodeAt(c)] << 18 | _e[e.charCodeAt(c + 1)] << 12 | _e[e.charCodeAt(c + 2)] << 6 | _e[e.charCodeAt(c + 3)], i[a++] = t >> 16 & 255, i[a++] = t >> 8 & 255, i[a++] = t & 255;
  return n === 2 && (t = _e[e.charCodeAt(c)] << 2 | _e[e.charCodeAt(c + 1)] >> 4, i[a++] = t & 255), n === 1 && (t = _e[e.charCodeAt(c)] << 10 | _e[e.charCodeAt(c + 1)] << 4 | _e[e.charCodeAt(c + 2)] >> 2, i[a++] = t >> 8 & 255, i[a++] = t & 255), i;
}
s(Bt, "toByteArray");
function kg(e) {
  return Pe[e >> 18 & 63] + Pe[e >> 12 & 63] + Pe[e >> 6 & 63] + Pe[e & 63];
}
s(kg, "tripletToBase64");
function zg(e, t, r) {
  for (var o, n = [], i = t; i < r; i += 3)
    o = (e[i] << 16 & 16711680) + (e[i + 1] << 8 & 65280) + (e[i + 2] & 255), n.push(kg(o));
  return n.join("");
}
s(zg, "encodeChunk");
function Jt(e) {
  for (var t, r = e.length, o = r % 3, n = [], i = 16383, a = 0, u = r - o; a < u; a += i)
    n.push(
      zg(
        e,
        a,
        a + i > u ? u : a + i
      )
    );
  return o === 1 ? (t = e[r - 1], n.push(Pe[t >> 2] + Pe[t << 4 & 63] + "==")) : o === 2 && (t = (e[r - 2] << 8) + e[r - 1], n.push(
    Pe[t >> 10] + Pe[t >> 4 & 63] + Pe[t << 2 & 63] + "="
  )), n.join("");
}
s(Jt, "fromByteArray");

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/common/index.js
function Ce(e) {
  if (e === void 0)
    return {};
  if (!En(e))
    throw new Error(
      `The arguments to a Convex function must be an object. Received: ${e}`
    );
  return e;
}
s(Ce, "parseArgs");
function En(e) {
  let t = typeof e == "object", r = Object.getPrototypeOf(e), o = r === null || r === Object.prototype || // Objects generated from other contexts (e.g. across Node.js `vm` modules) will not satisfy the previous
  // conditions but are still simple objects.
  r?.constructor?.name === "Object";
  return t && o;
}
s(En, "isSimpleObject");

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/value.js
var vd = !0, vt = BigInt("-9223372036854775808"), zi = BigInt("9223372036854775807"), Ii = BigInt("0"), Sg = BigInt("8"), jg = BigInt("256");
function yd(e) {
  return Number.isNaN(e) || !Number.isFinite(e) || Object.is(e, -0);
}
s(yd, "isSpecial");
function Og(e) {
  e < Ii && (e -= vt + vt);
  let t = e.toString(16);
  t.length % 2 === 1 && (t = "0" + t);
  let r = new Uint8Array(new ArrayBuffer(8)), o = 0;
  for (let n of t.match(/.{2}/g).reverse())
    r.set([parseInt(n, 16)], o++), e >>= Sg;
  return Jt(r);
}
s(Og, "slowBigIntToBase64");
function Dg(e) {
  let t = Bt(e);
  if (t.byteLength !== 8)
    throw new Error(
      `Received ${t.byteLength} bytes, expected 8 for $integer`
    );
  let r = Ii, o = Ii;
  for (let n of t)
    r += BigInt(n) * jg ** o, o++;
  return r > zi && (r += vt + vt), r;
}
s(Dg, "slowBase64ToBigInt");
function Pg(e) {
  if (e < vt || zi < e)
    throw new Error(
      `BigInt ${e} does not fit into a 64-bit signed integer.`
    );
  let t = new ArrayBuffer(8);
  return new DataView(t).setBigInt64(0, e, !0), Jt(new Uint8Array(t));
}
s(Pg, "modernBigIntToBase64");
function Tg(e) {
  let t = Bt(e);
  if (t.byteLength !== 8)
    throw new Error(
      `Received ${t.byteLength} bytes, expected 8 for $integer`
    );
  return new DataView(t.buffer).getBigInt64(0, !0);
}
s(Tg, "modernBase64ToBigInt");
var Ng = DataView.prototype.setBigInt64 ? Pg : Og, Ug = DataView.prototype.getBigInt64 ? Tg : Dg, gd = 1024;
function ki(e) {
  if (e.length > gd)
    throw new Error(
      `Field name ${e} exceeds maximum field name length ${gd}.`
    );
  if (e.startsWith("$"))
    throw new Error(`Field name ${e} starts with a '$', which is reserved.`);
  for (let t = 0; t < e.length; t += 1) {
    let r = e.charCodeAt(t);
    if (r < 32 || r >= 127)
      throw new Error(
        `Field name ${e} has invalid character '${e[t]}': Field names can only contain non-control ASCII characters`
      );
  }
}
s(ki, "validateObjectField");
function Q(e) {
  if (e === null || typeof e == "boolean" || typeof e == "number" || typeof e == "string")
    return e;
  if (Array.isArray(e))
    return e.map((o) => Q(o));
  if (typeof e != "object")
    throw new Error(`Unexpected type of ${e}`);
  let t = Object.entries(e);
  if (t.length === 1) {
    let o = t[0][0];
    if (o === "$bytes") {
      if (typeof e.$bytes != "string")
        throw new Error(`Malformed $bytes field on ${e}`);
      return Bt(e.$bytes).buffer;
    }
    if (o === "$integer") {
      if (typeof e.$integer != "string")
        throw new Error(`Malformed $integer field on ${e}`);
      return Ug(e.$integer);
    }
    if (o === "$float") {
      if (typeof e.$float != "string")
        throw new Error(`Malformed $float field on ${e}`);
      let n = Bt(e.$float);
      if (n.byteLength !== 8)
        throw new Error(
          `Received ${n.byteLength} bytes, expected 8 for $float`
        );
      let a = new DataView(n.buffer).getFloat64(0, vd);
      if (!yd(a))
        throw new Error(`Float ${a} should be encoded as a number`);
      return a;
    }
    if (o === "$set")
      throw new Error(
        "Received a Set which is no longer supported as a Convex type."
      );
    if (o === "$map")
      throw new Error(
        "Received a Map which is no longer supported as a Convex type."
      );
  }
  let r = {};
  for (let [o, n] of Object.entries(e))
    ki(o), r[o] = Q(n);
  return r;
}
s(Q, "jsonToConvex");
var hd = 16384;
function nt(e) {
  let t = JSON.stringify(e, (r, o) => o === void 0 ? "undefined" : typeof o == "bigint" ? `${o.toString()}n` : o);
  if (t.length > hd) {
    let r = "[...truncated]", o = hd - r.length, n = t.codePointAt(o - 1);
    return n !== void 0 && n > 65535 && (o -= 1), t.substring(0, o) + r;
  }
  return t;
}
s(nt, "stringifyValueForError");
function qt(e, t, r, o) {
  if (e === void 0) {
    let a = r && ` (present at path ${r} in original object ${nt(
      t
    )})`;
    throw new Error(
      `undefined is not a valid Convex value${a}. To learn about Convex's supported types, see https://docs.convex.dev/using/types.`
    );
  }
  if (e === null)
    return e;
  if (typeof e == "bigint") {
    if (e < vt || zi < e)
      throw new Error(
        `BigInt ${e} does not fit into a 64-bit signed integer.`
      );
    return { $integer: Ng(e) };
  }
  if (typeof e == "number")
    if (yd(e)) {
      let a = new ArrayBuffer(8);
      return new DataView(a).setFloat64(0, e, vd), { $float: Jt(new Uint8Array(a)) };
    } else
      return e;
  if (typeof e == "boolean" || typeof e == "string")
    return e;
  if (e instanceof ArrayBuffer)
    return { $bytes: Jt(new Uint8Array(e)) };
  if (Array.isArray(e))
    return e.map(
      (a, u) => qt(a, t, r + `[${u}]`, !1)
    );
  if (e instanceof Set)
    throw new Error(
      wi(r, "Set", [...e], t)
    );
  if (e instanceof Map)
    throw new Error(
      wi(r, "Map", [...e], t)
    );
  if (!En(e)) {
    let a = e?.constructor?.name, u = a ? `${a} ` : "";
    throw new Error(
      wi(r, u, e, t)
    );
  }
  let n = {}, i = Object.entries(e);
  i.sort(([a, u], [c, l]) => a === c ? 0 : a < c ? -1 : 1);
  for (let [a, u] of i)
    u !== void 0 ? (ki(a), n[a] = qt(u, t, r + `.${a}`, !1)) : o && (ki(a), n[a] = $d(
      u,
      t,
      r + `.${a}`
    ));
  return n;
}
s(qt, "convexToJsonInternal");
function wi(e, t, r, o) {
  return e ? `${t}${nt(
    r
  )} is not a supported Convex type (present at path ${e} in original object ${nt(
    o
  )}). To learn about Convex's supported types, see https://docs.convex.dev/using/types.` : `${t}${nt(
    r
  )} is not a supported Convex type.`;
}
s(wi, "errorMessageForUnsupportedType");
function $d(e, t, r) {
  if (e === void 0)
    return { $undefined: null };
  if (t === void 0)
    throw new Error(
      `Programming error. Current value is ${nt(
        e
      )} but original value is undefined`
    );
  return qt(e, t, r, !1);
}
s($d, "convexOrUndefinedToJsonInternal");
function K(e) {
  return qt(e, e, "", !1);
}
s(K, "convexToJson");
function xe(e) {
  return $d(e, e, "");
}
s(xe, "convexOrUndefinedToJson");
function bd(e) {
  return qt(e, e, "", !0);
}
s(bd, "patchValueToJson");

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/validators.js
var Ag = Object.defineProperty, Eg = /* @__PURE__ */ s((e, t, r) => t in e ? Ag(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), G = /* @__PURE__ */ s((e, t, r) => Eg(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), Cg = "https://docs.convex.dev/error#undefined-validator";
function Wt(e, t) {
  let r = t !== void 0 ? ` for field "${t}"` : "";
  throw new Error(
    `A validator is undefined${r} in ${e}. This is often caused by circular imports. See ${Cg} for details.`
  );
}
s(Wt, "throwUndefinedValidatorError");
var oe = class {
  static {
    s(this, "BaseValidator");
  }
  constructor({ isOptional: t }) {
    G(this, "type"), G(this, "fieldPaths"), G(this, "isOptional"), G(this, "isConvexValidator"), this.isOptional = t, this.isConvexValidator = !0;
  }
}, Cn = class e extends oe {
  static {
    s(this, "VId");
  }
  /**
   * Usually you'd use `v.id(tableName)` instead.
   */
  constructor({
    isOptional: t,
    tableName: r
  }) {
    if (super({ isOptional: t }), G(this, "tableName"), G(this, "kind", "id"), typeof r != "string")
      throw new Error("v.id(tableName) requires a string");
    this.tableName = r;
  }
  /** @internal */
  get json() {
    return { type: "id", tableName: this.tableName };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      tableName: this.tableName
    });
  }
}, Kt = class e extends oe {
  static {
    s(this, "VFloat64");
  }
  constructor() {
    super(...arguments), G(this, "kind", "float64");
  }
  /** @internal */
  get json() {
    return { type: "number" };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, Gt = class e extends oe {
  static {
    s(this, "VInt64");
  }
  constructor() {
    super(...arguments), G(this, "kind", "int64");
  }
  /** @internal */
  get json() {
    return { type: "bigint" };
  }
  /** @internal */
  asOptional() {
    return new e({ isOptional: "optional" });
  }
}, Zn = class e extends oe {
  static {
    s(this, "VBoolean");
  }
  constructor() {
    super(...arguments), G(this, "kind", "boolean");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, Fn = class e extends oe {
  static {
    s(this, "VBytes");
  }
  constructor() {
    super(...arguments), G(this, "kind", "bytes");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({ isOptional: "optional" });
  }
}, Mn = class e extends oe {
  static {
    s(this, "VString");
  }
  constructor() {
    super(...arguments), G(this, "kind", "string");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, Rn = class e extends oe {
  static {
    s(this, "VNull");
  }
  constructor() {
    super(...arguments), G(this, "kind", "null");
  }
  /** @internal */
  get json() {
    return { type: this.kind };
  }
  /** @internal */
  asOptional() {
    return new e({ isOptional: "optional" });
  }
}, Ln = class e extends oe {
  static {
    s(this, "VAny");
  }
  constructor() {
    super(...arguments), G(this, "kind", "any");
  }
  /** @internal */
  get json() {
    return {
      type: this.kind
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional"
    });
  }
}, Vn = class e extends oe {
  static {
    s(this, "VObject");
  }
  /**
   * Usually you'd use `v.object({ ... })` instead.
   */
  constructor({
    isOptional: t,
    fields: r
  }) {
    super({ isOptional: t }), G(this, "fields"), G(this, "kind", "object"), globalThis.Object.entries(r).forEach(([o, n]) => {
      if (n === void 0 && Wt("v.object()", o), !n.isConvexValidator)
        throw new Error("v.object() entries must be validators");
    }), this.fields = r;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: globalThis.Object.fromEntries(
        globalThis.Object.entries(this.fields).map(([t, r]) => [
          t,
          {
            fieldType: r.json,
            optional: r.isOptional === "optional"
          }
        ])
      )
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      fields: this.fields
    });
  }
  /**
   * Create a new VObject with the specified fields omitted.
   * @param fields The field names to omit from this VObject.
   */
  omit(...t) {
    let r = { ...this.fields };
    for (let o of t)
      delete r[o];
    return new e({
      isOptional: this.isOptional,
      fields: r
    });
  }
  /**
   * Create a new VObject with only the specified fields.
   * @param fields The field names to pick from this VObject.
   */
  pick(...t) {
    let r = {};
    for (let o of t)
      r[o] = this.fields[o];
    return new e({
      isOptional: this.isOptional,
      fields: r
    });
  }
  /**
   * Create a new VObject with all fields marked as optional.
   */
  partial() {
    let t = {};
    for (let [r, o] of globalThis.Object.entries(this.fields))
      t[r] = o.asOptional();
    return new e({
      isOptional: this.isOptional,
      fields: t
    });
  }
  /**
   * Create a new VObject with additional fields merged in.
   * @param fields An object with additional validators to merge into this VObject.
   */
  extend(t) {
    return new e({
      isOptional: this.isOptional,
      fields: { ...this.fields, ...t }
    });
  }
}, Bn = class e extends oe {
  static {
    s(this, "VLiteral");
  }
  /**
   * Usually you'd use `v.literal(value)` instead.
   */
  constructor({ isOptional: t, value: r }) {
    if (super({ isOptional: t }), G(this, "value"), G(this, "kind", "literal"), typeof r != "string" && typeof r != "boolean" && typeof r != "number" && typeof r != "bigint")
      throw new Error("v.literal(value) must be a string, number, or boolean");
    this.value = r;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: K(this.value)
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      value: this.value
    });
  }
}, Jn = class e extends oe {
  static {
    s(this, "VArray");
  }
  /**
   * Usually you'd use `v.array(element)` instead.
   */
  constructor({
    isOptional: t,
    element: r
  }) {
    super({ isOptional: t }), G(this, "element"), G(this, "kind", "array"), r === void 0 && Wt("v.array()"), this.element = r;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: this.element.json
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      element: this.element
    });
  }
}, qn = class e extends oe {
  static {
    s(this, "VRecord");
  }
  /**
   * Usually you'd use `v.record(key, value)` instead.
   */
  constructor({
    isOptional: t,
    key: r,
    value: o
  }) {
    if (super({ isOptional: t }), G(this, "key"), G(this, "value"), G(this, "kind", "record"), r === void 0 && Wt("v.record()", "key"), o === void 0 && Wt("v.record()", "value"), r.isOptional === "optional")
      throw new Error("Record validator cannot have optional keys");
    if (o.isOptional === "optional")
      throw new Error("Record validator cannot have optional values");
    if (!r.isConvexValidator || !o.isConvexValidator)
      throw new Error("Key and value of v.record() but be validators");
    this.key = r, this.value = o;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      // This cast is needed because TypeScript thinks the key type is too wide
      keys: this.key.json,
      values: {
        fieldType: this.value.json,
        optional: !1
      }
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      key: this.key,
      value: this.value
    });
  }
}, Wn = class e extends oe {
  static {
    s(this, "VUnion");
  }
  /**
   * Usually you'd use `v.union(...members)` instead.
   */
  constructor({ isOptional: t, members: r }) {
    super({ isOptional: t }), G(this, "members"), G(this, "kind", "union"), r.forEach((o, n) => {
      if (o === void 0 && Wt("v.union()", `member at index ${n}`), !o.isConvexValidator)
        throw new Error("All members of v.union() must be validators");
    }), this.members = r;
  }
  /** @internal */
  get json() {
    return {
      type: this.kind,
      value: this.members.map((t) => t.json)
    };
  }
  /** @internal */
  asOptional() {
    return new e({
      isOptional: "optional",
      members: this.members
    });
  }
};

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/validator.js
function Si(e) {
  return !!e.isConvexValidator;
}
s(Si, "isValidator");
function Xt(e) {
  return Si(e) ? e : y.object(e);
}
s(Xt, "asObjectValidator");
var y = {
  /**
   * Validates that the value is a document ID for the given table.
   *
   * IDs are strings at runtime but are typed as `Id<"tableName">` in
   * TypeScript for type safety.
   *
   * @example
   * ```typescript
   * args: { userId: v.id("users") }
   * ```
   *
   * @param tableName The name of the table.
   */
  id: /* @__PURE__ */ s((e) => new Cn({
    isOptional: "required",
    tableName: e
  }), "id"),
  /**
   * Validates that the value is `null`.
   *
   * Use `returns: v.null()` for functions that don't return a meaningful value.
   * JavaScript `undefined` is not a valid Convex value, it is automatically
   * converted to `null`.
   */
  null: /* @__PURE__ */ s(() => new Rn({ isOptional: "required" }), "null"),
  /**
   * Validates that the value is a JavaScript `number` (Convex Float64).
   *
   * Supports all IEEE-754 double-precision floating point numbers including
   * NaN and Infinity.
   *
   * Alias for `v.float64()`.
   */
  number: /* @__PURE__ */ s(() => new Kt({ isOptional: "required" }), "number"),
  /**
   * Validates that the value is a JavaScript `number` (Convex Float64).
   *
   * Supports all IEEE-754 double-precision floating point numbers.
   */
  float64: /* @__PURE__ */ s(() => new Kt({ isOptional: "required" }), "float64"),
  /**
   * @deprecated Use `v.int64()` instead.
   */
  bigint: /* @__PURE__ */ s(() => new Gt({ isOptional: "required" }), "bigint"),
  /**
   * Validates that the value is a JavaScript `bigint` (Convex Int64).
   *
   * Supports BigInts between -2^63 and 2^63-1.
   *
   * @example
   * ```typescript
   * args: { timestamp: v.int64() }
   * // Usage: createDoc({ timestamp: 1234567890n })
   * ```
   */
  int64: /* @__PURE__ */ s(() => new Gt({ isOptional: "required" }), "int64"),
  /**
   * Validates that the value is a `boolean`.
   */
  boolean: /* @__PURE__ */ s(() => new Zn({ isOptional: "required" }), "boolean"),
  /**
   * Validates that the value is a `string`.
   *
   * Strings are stored as UTF-8 and their storage size is calculated as their
   * UTF-8 encoded size.
   */
  string: /* @__PURE__ */ s(() => new Mn({ isOptional: "required" }), "string"),
  /**
   * Validates that the value is an `ArrayBuffer` (Convex Bytes).
   *
   * Use for binary data.
   */
  bytes: /* @__PURE__ */ s(() => new Fn({ isOptional: "required" }), "bytes"),
  /**
   * Validates that the value is exactly equal to the given literal.
   *
   * Useful for discriminated unions and enum-like patterns.
   *
   * @example
   * ```typescript
   * // Discriminated union pattern:
   * v.union(
   *   v.object({ kind: v.literal("error"), message: v.string() }),
   *   v.object({ kind: v.literal("success"), value: v.number() }),
   * )
   * ```
   *
   * @param literal The literal value to compare against.
   */
  literal: /* @__PURE__ */ s((e) => new Bn({ isOptional: "required", value: e }), "literal"),
  /**
   * Validates that the value is an `Array` where every element matches the
   * given validator.
   *
   * Arrays can have at most 8192 elements.
   *
   * @example
   * ```typescript
   * args: { tags: v.array(v.string()) }
   * args: { coordinates: v.array(v.number()) }
   * args: { items: v.array(v.object({ name: v.string(), qty: v.number() })) }
   * ```
   *
   * @param element The validator for the elements of the array.
   */
  array: /* @__PURE__ */ s((e) => new Jn({ isOptional: "required", element: e }), "array"),
  /**
   * Validates that the value is an `Object` with the specified properties.
   *
   * Objects can have at most 1024 entries. Field names must be non-empty and
   * must not start with `"$"` or `"_"` (`_` is reserved for system fields
   * like `_id` and `_creationTime`; `$` is reserved for Convex internal use).
   *
   * @example
   * ```typescript
   * args: {
   *   user: v.object({
   *     name: v.string(),
   *     email: v.string(),
   *     age: v.optional(v.number()),
   *   })
   * }
   * ```
   *
   * @param fields An object mapping property names to their validators.
   */
  object: /* @__PURE__ */ s((e) => new Vn({ isOptional: "required", fields: e }), "object"),
  /**
   * Validates that the value is a `Record` (object with dynamic keys).
   *
   * Records are objects at runtime but allow dynamic keys, unlike `v.object()`
   * which requires known property names. Keys must be ASCII characters only,
   * non-empty, and not start with `"$"` or `"_"`.
   *
   * @example
   * ```typescript
   * // Map of user IDs to scores:
   * args: { scores: v.record(v.id("users"), v.number()) }
   *
   * // Map of string keys to string values:
   * args: { metadata: v.record(v.string(), v.string()) }
   * ```
   *
   * @param keys The validator for the keys of the record.
   * @param values The validator for the values of the record.
   */
  record: /* @__PURE__ */ s((e, t) => new qn({
    isOptional: "required",
    key: e,
    value: t
  }), "record"),
  /**
   * Validates that the value matches at least one of the given validators.
   *
   * @example
   * ```typescript
   * // Allow string or number:
   * args: { value: v.union(v.string(), v.number()) }
   *
   * // Discriminated union (recommended pattern):
   * v.union(
   *   v.object({ kind: v.literal("text"), body: v.string() }),
   *   v.object({ kind: v.literal("image"), url: v.string() }),
   * )
   *
   * // Nullable value:
   * returns: v.union(v.object({ ... }), v.null())
   * ```
   *
   * @param members The validators to match against.
   */
  union: /* @__PURE__ */ s((...e) => new Wn({
    isOptional: "required",
    members: e
  }), "union"),
  /**
   * A validator that accepts any Convex value without validation.
   *
   * Prefer using specific validators when possible for better type safety
   * and runtime validation.
   */
  any: /* @__PURE__ */ s(() => new Ln({ isOptional: "required" }), "any"),
  /**
   * Makes a property optional in an object validator.
   *
   * An optional property can be omitted entirely when creating a document or
   * calling a function. This is different from `v.nullable()` which requires
   * the property to be present but allows `null`.
   *
   * @example
   * ```typescript
   * v.object({
   *   name: v.string(),              // required
   *   nickname: v.optional(v.string()), // can be omitted
   * })
   *
   * // Valid: { name: "Alice" }
   * // Valid: { name: "Alice", nickname: "Ali" }
   * // Invalid: { name: "Alice", nickname: null }  - use v.nullable() for this
   * ```
   *
   * @param value The property value validator to make optional.
   */
  optional: /* @__PURE__ */ s((e) => e.asOptional(), "optional"),
  /**
   * Allows a value to be either the given type or `null`.
   *
   * This is shorthand for `v.union(value, v.null())`. Unlike `v.optional()`,
   * the property must still be present, but may be `null`.
   *
   * @example
   * ```typescript
   * v.object({
   *   name: v.string(),
   *   deletedAt: v.nullable(v.number()), // must be present, can be null
   * })
   *
   * // Valid: { name: "Alice", deletedAt: null }
   * // Valid: { name: "Alice", deletedAt: 1234567890 }
   * // Invalid: { name: "Alice" }  - deletedAt is required
   * ```
   */
  nullable: /* @__PURE__ */ s((e) => y.union(e, y.null()), "nullable")
};

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/errors.js
var Zg = Object.defineProperty, Fg = /* @__PURE__ */ s((e, t, r) => t in e ? Zg(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), ji = /* @__PURE__ */ s((e, t, r) => Fg(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), _d, xd, Mg = Symbol.for("ConvexError"), yt = class extends (xd = Error, _d = Mg, xd) {
  static {
    s(this, "ConvexError");
  }
  constructor(t) {
    super(typeof t == "string" ? t : nt(t)), ji(this, "name", "ConvexError"), ji(this, "data"), ji(this, _d, !0), this.data = t;
  }
};

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/values/compare_utf8.js
var wd = /* @__PURE__ */ s(() => Array.from({ length: 4 }, () => 0), "arr"), yI = wd(), $I = wd();

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/index.js
var ee = "1.32.0";

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/syscall.js
function Ht(e, t) {
  if (typeof Convex > "u" || Convex.syscall === void 0)
    throw new Error(
      "The Convex database and auth objects are being used outside of a Convex backend. Did you mean to use `useQuery` or `useMutation` to call a Convex function?"
    );
  let r = Convex.syscall(e, JSON.stringify(t));
  return JSON.parse(r);
}
s(Ht, "performSyscall");
async function F(e, t) {
  if (typeof Convex > "u" || Convex.asyncSyscall === void 0)
    throw new Error(
      "The Convex database and auth objects are being used outside of a Convex backend. Did you mean to use `useQuery` or `useMutation` to call a Convex function?"
    );
  let r;
  try {
    r = await Convex.asyncSyscall(e, JSON.stringify(t));
  } catch (o) {
    if (o.data !== void 0) {
      let n = new yt(o.message);
      throw n.data = Q(o.data), n;
    }
    throw new Error(o.message);
  }
  return JSON.parse(r);
}
s(F, "performAsyncSyscall");
function Kn(e, t) {
  if (typeof Convex > "u" || Convex.jsSyscall === void 0)
    throw new Error(
      "The Convex database and auth objects are being used outside of a Convex backend. Did you mean to use `useQuery` or `useMutation` to call a Convex function?"
    );
  return Convex.jsSyscall(e, t);
}
s(Kn, "performJsSyscall");

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/functionName.js
var Qt = Symbol.for("functionName");

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/components/paths.js
var Id = Symbol.for("toReferencePath");
function Lg(e) {
  return e[Id] ?? null;
}
s(Lg, "extractReferencePath");
function Vg(e) {
  return e.startsWith("function://");
}
s(Vg, "isFunctionHandle");
function ke(e) {
  let t;
  if (typeof e == "string")
    Vg(e) ? t = { functionHandle: e } : t = { name: e };
  else if (e[Qt])
    t = { name: e[Qt] };
  else {
    let r = Lg(e);
    if (!r)
      throw new Error(`${e} is not a functionReference`);
    t = { reference: r };
  }
  return t;
}
s(ke, "getFunctionAddress");

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/actions_impl.js
function Oi(e, t, r) {
  return {
    ...ke(t),
    args: K(Ce(r)),
    version: ee,
    requestId: e
  };
}
s(Oi, "syscallArgs");
function kd(e) {
  return {
    runQuery: /* @__PURE__ */ s(async (t, r) => {
      let o = await F(
        "1.0/actions/query",
        Oi(e, t, r)
      );
      return Q(o);
    }, "runQuery"),
    runMutation: /* @__PURE__ */ s(async (t, r) => {
      let o = await F(
        "1.0/actions/mutation",
        Oi(e, t, r)
      );
      return Q(o);
    }, "runMutation"),
    runAction: /* @__PURE__ */ s(async (t, r) => {
      let o = await F(
        "1.0/actions/action",
        Oi(e, t, r)
      );
      return Q(o);
    }, "runAction")
  };
}
s(kd, "setupActionCalls");

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/vector_search.js
var Bg = Object.defineProperty, Jg = /* @__PURE__ */ s((e, t, r) => t in e ? Bg(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), zd = /* @__PURE__ */ s((e, t, r) => Jg(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), Gn = class {
  static {
    s(this, "FilterExpression");
  }
  /**
   * @internal
   */
  constructor() {
    zd(this, "_isExpression"), zd(this, "_value");
  }
};

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/validate.js
function Z(e, t, r, o) {
  if (e === void 0)
    throw new TypeError(
      `Must provide arg ${t} \`${o}\` to \`${r}\``
    );
}
s(Z, "validateArg");
function Sd(e, t, r, o) {
  if (!Number.isInteger(e) || e < 0)
    throw new TypeError(
      `Arg ${t} \`${o}\` to \`${r}\` must be a non-negative integer`
    );
}
s(Sd, "validateArgIsNonNegativeInteger");

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/vector_search_impl.js
var qg = Object.defineProperty, Wg = /* @__PURE__ */ s((e, t, r) => t in e ? qg(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), Di = /* @__PURE__ */ s((e, t, r) => Wg(e, typeof t != "symbol" ? t + "" : t, r), "__publicField");
function jd(e) {
  return async (t, r, o) => {
    if (Z(t, 1, "vectorSearch", "tableName"), Z(r, 2, "vectorSearch", "indexName"), Z(o, 3, "vectorSearch", "query"), !o.vector || !Array.isArray(o.vector) || o.vector.length === 0)
      throw Error("`vector` must be a non-empty Array in vectorSearch");
    return await new Pi(
      e,
      t + "." + r,
      o
    ).collect();
  };
}
s(jd, "setupActionVectorSearch");
var Pi = class {
  static {
    s(this, "VectorQueryImpl");
  }
  constructor(t, r, o) {
    Di(this, "requestId"), Di(this, "state"), this.requestId = t;
    let n = o.filter ? Xn(o.filter(Kg)) : null;
    this.state = {
      type: "preparing",
      query: {
        indexName: r,
        limit: o.limit,
        vector: o.vector,
        expressions: n
      }
    };
  }
  async collect() {
    if (this.state.type === "consumed")
      throw new Error("This query is closed and can't emit any more values.");
    let t = this.state.query;
    this.state = { type: "consumed" };
    let { results: r } = await F("1.0/actions/vectorSearch", {
      requestId: this.requestId,
      version: ee,
      query: t
    });
    return r;
  }
}, $t = class extends Gn {
  static {
    s(this, "ExpressionImpl");
  }
  constructor(t) {
    super(), Di(this, "inner"), this.inner = t;
  }
  serialize() {
    return this.inner;
  }
};
function Xn(e) {
  return e instanceof $t ? e.serialize() : { $literal: xe(e) };
}
s(Xn, "serializeExpression");
var Kg = {
  //  Comparisons  /////////////////////////////////////////////////////////////
  eq(e, t) {
    if (typeof e != "string")
      throw new Error("The first argument to `q.eq` must be a field name.");
    return new $t({
      $eq: [
        Xn(new $t({ $field: e })),
        Xn(t)
      ]
    });
  },
  //  Logic  ///////////////////////////////////////////////////////////////////
  or(...e) {
    return new $t({ $or: e.map(Xn) });
  }
};

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/authentication_impl.js
function Hn(e) {
  return {
    getUserIdentity: /* @__PURE__ */ s(async () => await F("1.0/getUserIdentity", {
      requestId: e
    }), "getUserIdentity")
  };
}
s(Hn, "setupAuth");

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/filter_builder.js
var Gg = Object.defineProperty, Xg = /* @__PURE__ */ s((e, t, r) => t in e ? Gg(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), Od = /* @__PURE__ */ s((e, t, r) => Xg(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), Qn = class {
  static {
    s(this, "Expression");
  }
  /**
   * @internal
   */
  constructor() {
    Od(this, "_isExpression"), Od(this, "_value");
  }
};

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/filter_builder_impl.js
var Hg = Object.defineProperty, Qg = /* @__PURE__ */ s((e, t, r) => t in e ? Hg(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), Yg = /* @__PURE__ */ s((e, t, r) => Qg(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), ne = class extends Qn {
  static {
    s(this, "ExpressionImpl");
  }
  constructor(t) {
    super(), Yg(this, "inner"), this.inner = t;
  }
  serialize() {
    return this.inner;
  }
};
function B(e) {
  return e instanceof ne ? e.serialize() : { $literal: xe(e) };
}
s(B, "serializeExpression");
var Dd = {
  //  Comparisons  /////////////////////////////////////////////////////////////
  eq(e, t) {
    return new ne({
      $eq: [B(e), B(t)]
    });
  },
  neq(e, t) {
    return new ne({
      $neq: [B(e), B(t)]
    });
  },
  lt(e, t) {
    return new ne({
      $lt: [B(e), B(t)]
    });
  },
  lte(e, t) {
    return new ne({
      $lte: [B(e), B(t)]
    });
  },
  gt(e, t) {
    return new ne({
      $gt: [B(e), B(t)]
    });
  },
  gte(e, t) {
    return new ne({
      $gte: [B(e), B(t)]
    });
  },
  //  Arithmetic  //////////////////////////////////////////////////////////////
  add(e, t) {
    return new ne({
      $add: [B(e), B(t)]
    });
  },
  sub(e, t) {
    return new ne({
      $sub: [B(e), B(t)]
    });
  },
  mul(e, t) {
    return new ne({
      $mul: [B(e), B(t)]
    });
  },
  div(e, t) {
    return new ne({
      $div: [B(e), B(t)]
    });
  },
  mod(e, t) {
    return new ne({
      $mod: [B(e), B(t)]
    });
  },
  neg(e) {
    return new ne({ $neg: B(e) });
  },
  //  Logic  ///////////////////////////////////////////////////////////////////
  and(...e) {
    return new ne({ $and: e.map(B) });
  },
  or(...e) {
    return new ne({ $or: e.map(B) });
  },
  not(e) {
    return new ne({ $not: B(e) });
  },
  //  Other  ///////////////////////////////////////////////////////////////////
  field(e) {
    return new ne({ $field: e });
  }
};

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/index_range_builder.js
var eh = Object.defineProperty, th = /* @__PURE__ */ s((e, t, r) => t in e ? eh(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), nh = /* @__PURE__ */ s((e, t, r) => th(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), Yn = class {
  static {
    s(this, "IndexRange");
  }
  /**
   * @internal
   */
  constructor() {
    nh(this, "_isIndexRange");
  }
};

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/index_range_builder_impl.js
var rh = Object.defineProperty, ih = /* @__PURE__ */ s((e, t, r) => t in e ? rh(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), Pd = /* @__PURE__ */ s((e, t, r) => ih(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), er = class e extends Yn {
  static {
    s(this, "IndexRangeBuilderImpl");
  }
  constructor(t) {
    super(), Pd(this, "rangeExpressions"), Pd(this, "isConsumed"), this.rangeExpressions = t, this.isConsumed = !1;
  }
  static new() {
    return new e([]);
  }
  consume() {
    if (this.isConsumed)
      throw new Error(
        "IndexRangeBuilder has already been used! Chain your method calls like `q => q.eq(...).eq(...)`. See https://docs.convex.dev/using/indexes"
      );
    this.isConsumed = !0;
  }
  eq(t, r) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Eq",
        fieldPath: t,
        value: xe(r)
      })
    );
  }
  gt(t, r) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Gt",
        fieldPath: t,
        value: xe(r)
      })
    );
  }
  gte(t, r) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Gte",
        fieldPath: t,
        value: xe(r)
      })
    );
  }
  lt(t, r) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Lt",
        fieldPath: t,
        value: xe(r)
      })
    );
  }
  lte(t, r) {
    return this.consume(), new e(
      this.rangeExpressions.concat({
        type: "Lte",
        fieldPath: t,
        value: xe(r)
      })
    );
  }
  export() {
    return this.consume(), this.rangeExpressions;
  }
};

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/search_filter_builder.js
var oh = Object.defineProperty, ah = /* @__PURE__ */ s((e, t, r) => t in e ? oh(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), sh = /* @__PURE__ */ s((e, t, r) => ah(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), tr = class {
  static {
    s(this, "SearchFilter");
  }
  /**
   * @internal
   */
  constructor() {
    sh(this, "_isSearchFilter");
  }
};

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/search_filter_builder_impl.js
var uh = Object.defineProperty, ch = /* @__PURE__ */ s((e, t, r) => t in e ? uh(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), Td = /* @__PURE__ */ s((e, t, r) => ch(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), nr = class e extends tr {
  static {
    s(this, "SearchFilterBuilderImpl");
  }
  constructor(t) {
    super(), Td(this, "filters"), Td(this, "isConsumed"), this.filters = t, this.isConsumed = !1;
  }
  static new() {
    return new e([]);
  }
  consume() {
    if (this.isConsumed)
      throw new Error(
        "SearchFilterBuilder has already been used! Chain your method calls like `q => q.search(...).eq(...)`."
      );
    this.isConsumed = !0;
  }
  search(t, r) {
    return Z(t, 1, "search", "fieldName"), Z(r, 2, "search", "query"), this.consume(), new e(
      this.filters.concat({
        type: "Search",
        fieldPath: t,
        value: r
      })
    );
  }
  eq(t, r) {
    return Z(t, 1, "eq", "fieldName"), arguments.length !== 2 && Z(r, 2, "search", "value"), this.consume(), new e(
      this.filters.concat({
        type: "Eq",
        fieldPath: t,
        value: xe(r)
      })
    );
  }
  export() {
    return this.consume(), this.filters;
  }
};

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/query_impl.js
var lh = Object.defineProperty, dh = /* @__PURE__ */ s((e, t, r) => t in e ? lh(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), Ti = /* @__PURE__ */ s((e, t, r) => dh(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), Nd = 256, bt = class {
  static {
    s(this, "QueryInitializerImpl");
  }
  constructor(t) {
    Ti(this, "tableName"), this.tableName = t;
  }
  withIndex(t, r) {
    Z(t, 1, "withIndex", "indexName");
    let o = er.new();
    return r !== void 0 && (o = r(o)), new rt({
      source: {
        type: "IndexRange",
        indexName: this.tableName + "." + t,
        range: o.export(),
        order: null
      },
      operators: []
    });
  }
  withSearchIndex(t, r) {
    Z(t, 1, "withSearchIndex", "indexName"), Z(r, 2, "withSearchIndex", "searchFilter");
    let o = nr.new();
    return new rt({
      source: {
        type: "Search",
        indexName: this.tableName + "." + t,
        filters: r(o).export()
      },
      operators: []
    });
  }
  fullTableScan() {
    return new rt({
      source: {
        type: "FullTableScan",
        tableName: this.tableName,
        order: null
      },
      operators: []
    });
  }
  order(t) {
    return this.fullTableScan().order(t);
  }
  // This is internal API and should not be exposed to developers yet.
  async count() {
    let t = await F("1.0/count", {
      table: this.tableName
    });
    return Q(t);
  }
  filter(t) {
    return this.fullTableScan().filter(t);
  }
  limit(t) {
    return this.fullTableScan().limit(t);
  }
  collect() {
    return this.fullTableScan().collect();
  }
  take(t) {
    return this.fullTableScan().take(t);
  }
  paginate(t) {
    return this.fullTableScan().paginate(t);
  }
  first() {
    return this.fullTableScan().first();
  }
  unique() {
    return this.fullTableScan().unique();
  }
  [Symbol.asyncIterator]() {
    return this.fullTableScan()[Symbol.asyncIterator]();
  }
};
function Ud(e) {
  throw new Error(
    e === "consumed" ? "This query is closed and can't emit any more values." : "This query has been chained with another operator and can't be reused."
  );
}
s(Ud, "throwClosedError");
var rt = class e {
  static {
    s(this, "QueryImpl");
  }
  constructor(t) {
    Ti(this, "state"), Ti(this, "tableNameForErrorMessages"), this.state = { type: "preparing", query: t }, t.source.type === "FullTableScan" ? this.tableNameForErrorMessages = t.source.tableName : this.tableNameForErrorMessages = t.source.indexName.split(".")[0];
  }
  takeQuery() {
    if (this.state.type !== "preparing")
      throw new Error(
        "A query can only be chained once and can't be chained after iteration begins."
      );
    let t = this.state.query;
    return this.state = { type: "closed" }, t;
  }
  startQuery() {
    if (this.state.type === "executing")
      throw new Error("Iteration can only begin on a query once.");
    (this.state.type === "closed" || this.state.type === "consumed") && Ud(this.state.type);
    let t = this.state.query, { queryId: r } = Ht("1.0/queryStream", { query: t, version: ee });
    return this.state = { type: "executing", queryId: r }, r;
  }
  closeQuery() {
    if (this.state.type === "executing") {
      let t = this.state.queryId;
      Ht("1.0/queryCleanup", { queryId: t });
    }
    this.state = { type: "consumed" };
  }
  order(t) {
    Z(t, 1, "order", "order");
    let r = this.takeQuery();
    if (r.source.type === "Search")
      throw new Error(
        "Search queries must always be in relevance order. Can not set order manually."
      );
    if (r.source.order !== null)
      throw new Error("Queries may only specify order at most once");
    return r.source.order = t, new e(r);
  }
  filter(t) {
    Z(t, 1, "filter", "predicate");
    let r = this.takeQuery();
    if (r.operators.length >= Nd)
      throw new Error(
        `Can't construct query with more than ${Nd} operators`
      );
    return r.operators.push({
      filter: B(t(Dd))
    }), new e(r);
  }
  limit(t) {
    Z(t, 1, "limit", "n");
    let r = this.takeQuery();
    return r.operators.push({ limit: t }), new e(r);
  }
  [Symbol.asyncIterator]() {
    return this.startQuery(), this;
  }
  async next() {
    (this.state.type === "closed" || this.state.type === "consumed") && Ud(this.state.type);
    let t = this.state.type === "preparing" ? this.startQuery() : this.state.queryId, { value: r, done: o } = await F("1.0/queryStreamNext", {
      queryId: t
    });
    return o && this.closeQuery(), { value: Q(r), done: o };
  }
  return() {
    return this.closeQuery(), Promise.resolve({ done: !0, value: void 0 });
  }
  async paginate(t) {
    if (Z(t, 1, "paginate", "options"), typeof t?.numItems != "number" || t.numItems < 0)
      throw new Error(
        `\`options.numItems\` must be a positive number. Received \`${t?.numItems}\`.`
      );
    let r = this.takeQuery(), o = t.numItems, n = t.cursor, i = t?.endCursor ?? null, a = t.maximumRowsRead ?? null, { page: u, isDone: c, continueCursor: l, splitCursor: d, pageStatus: f } = await F("1.0/queryPage", {
      query: r,
      cursor: n,
      endCursor: i,
      pageSize: o,
      maximumRowsRead: a,
      maximumBytesRead: t.maximumBytesRead,
      version: ee
    });
    return {
      page: u.map((p) => Q(p)),
      isDone: c,
      continueCursor: l,
      splitCursor: d,
      pageStatus: f
    };
  }
  async collect() {
    let t = [];
    for await (let r of this)
      t.push(r);
    return t;
  }
  async take(t) {
    return Z(t, 1, "take", "n"), Sd(t, 1, "take", "n"), this.limit(t).collect();
  }
  async first() {
    let t = await this.take(1);
    return t.length === 0 ? null : t[0];
  }
  async unique() {
    let t = await this.take(2);
    if (t.length === 0)
      return null;
    if (t.length === 2)
      throw new Error(`unique() query returned more than one result from table ${this.tableNameForErrorMessages}:
 [${t[0]._id}, ${t[1]._id}, ...]`);
    return t[0];
  }
};

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/database_impl.js
async function Ni(e, t, r) {
  if (Z(t, 1, "get", "id"), typeof t != "string")
    throw new Error(
      `Invalid argument \`id\` for \`db.get\`, expected string but got '${typeof t}': ${t}`
    );
  let o = {
    id: K(t),
    isSystem: r,
    version: ee,
    table: e
  }, n = await F("1.0/get", o);
  return Q(n);
}
s(Ni, "get");
function Zi() {
  let e = /* @__PURE__ */ s((n = !1) => ({
    get: /* @__PURE__ */ s(async (i, a) => a !== void 0 ? await Ni(i, a, n) : await Ni(void 0, i, n), "get"),
    query: /* @__PURE__ */ s((i) => new Yt(i, n).query(), "query"),
    normalizeId: /* @__PURE__ */ s((i, a) => {
      Z(i, 1, "normalizeId", "tableName"), Z(a, 2, "normalizeId", "id");
      let u = i.startsWith("_");
      if (u !== n)
        throw new Error(
          `${u ? "System" : "User"} tables can only be accessed from db.${n ? "" : "system."}normalizeId().`
        );
      let c = Ht("1.0/db/normalizeId", {
        table: i,
        idString: a
      });
      return Q(c).id;
    }, "normalizeId"),
    // We set the system reader on the next line
    system: null,
    table: /* @__PURE__ */ s((i) => new Yt(i, n), "table")
  }), "reader"), { system: t, ...r } = e(!0), o = e();
  return o.system = r, o;
}
s(Zi, "setupReader");
async function Ad(e, t) {
  if (e.startsWith("_"))
    throw new Error("System tables (prefixed with `_`) are read-only.");
  Z(e, 1, "insert", "table"), Z(t, 2, "insert", "value");
  let r = await F("1.0/insert", {
    table: e,
    value: K(t)
  });
  return Q(r)._id;
}
s(Ad, "insert");
async function Ui(e, t, r) {
  Z(t, 1, "patch", "id"), Z(r, 2, "patch", "value"), await F("1.0/shallowMerge", {
    id: K(t),
    value: bd(r),
    table: e
  });
}
s(Ui, "patch");
async function Ai(e, t, r) {
  Z(t, 1, "replace", "id"), Z(r, 2, "replace", "value"), await F("1.0/replace", {
    id: K(t),
    value: K(r),
    table: e
  });
}
s(Ai, "replace");
async function Ei(e, t) {
  Z(t, 1, "delete", "id"), await F("1.0/remove", {
    id: K(t),
    table: e
  });
}
s(Ei, "delete_");
function Ed() {
  let e = Zi();
  return {
    get: e.get,
    query: e.query,
    normalizeId: e.normalizeId,
    system: e.system,
    insert: /* @__PURE__ */ s(async (t, r) => await Ad(t, r), "insert"),
    patch: /* @__PURE__ */ s(async (t, r, o) => o !== void 0 ? await Ui(t, r, o) : await Ui(void 0, t, r), "patch"),
    replace: /* @__PURE__ */ s(async (t, r, o) => o !== void 0 ? await Ai(t, r, o) : await Ai(void 0, t, r), "replace"),
    delete: /* @__PURE__ */ s(async (t, r) => r !== void 0 ? await Ei(t, r) : await Ei(void 0, t), "delete"),
    table: /* @__PURE__ */ s((t) => new Ci(t, !1), "table")
  };
}
s(Ed, "setupWriter");
var Yt = class {
  static {
    s(this, "TableReader");
  }
  constructor(t, r) {
    this.tableName = t, this.isSystem = r;
  }
  async get(t) {
    return Ni(this.tableName, t, this.isSystem);
  }
  query() {
    let t = this.tableName.startsWith("_");
    if (t !== this.isSystem)
      throw new Error(
        `${t ? "System" : "User"} tables can only be accessed from db.${this.isSystem ? "" : "system."}query().`
      );
    return new bt(this.tableName);
  }
}, Ci = class extends Yt {
  static {
    s(this, "TableWriter");
  }
  async insert(t) {
    return Ad(this.tableName, t);
  }
  async patch(t, r) {
    return Ui(this.tableName, t, r);
  }
  async replace(t, r) {
    return Ai(this.tableName, t, r);
  }
  async delete(t) {
    return Ei(this.tableName, t);
  }
};

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/scheduler_impl.js
function Cd() {
  return {
    runAfter: /* @__PURE__ */ s(async (e, t, r) => {
      let o = Fd(e, t, r);
      return await F("1.0/schedule", o);
    }, "runAfter"),
    runAt: /* @__PURE__ */ s(async (e, t, r) => {
      let o = Md(
        e,
        t,
        r
      );
      return await F("1.0/schedule", o);
    }, "runAt"),
    cancel: /* @__PURE__ */ s(async (e) => {
      Z(e, 1, "cancel", "id");
      let t = { id: K(e) };
      await F("1.0/cancel_job", t);
    }, "cancel")
  };
}
s(Cd, "setupMutationScheduler");
function Zd(e) {
  return {
    runAfter: /* @__PURE__ */ s(async (t, r, o) => {
      let n = {
        requestId: e,
        ...Fd(t, r, o)
      };
      return await F("1.0/actions/schedule", n);
    }, "runAfter"),
    runAt: /* @__PURE__ */ s(async (t, r, o) => {
      let n = {
        requestId: e,
        ...Md(t, r, o)
      };
      return await F("1.0/actions/schedule", n);
    }, "runAt"),
    cancel: /* @__PURE__ */ s(async (t) => {
      Z(t, 1, "cancel", "id");
      let r = {
        requestId: e,
        id: K(t)
      };
      return await F("1.0/actions/cancel_job", r);
    }, "cancel")
  };
}
s(Zd, "setupActionScheduler");
function Fd(e, t, r) {
  if (typeof e != "number")
    throw new Error("`delayMs` must be a number");
  if (!isFinite(e))
    throw new Error("`delayMs` must be a finite number");
  if (e < 0)
    throw new Error("`delayMs` must be non-negative");
  let o = Ce(r), n = ke(t), i = (Date.now() + e) / 1e3;
  return {
    ...n,
    ts: i,
    args: K(o),
    version: ee
  };
}
s(Fd, "runAfterSyscallArgs");
function Md(e, t, r) {
  let o;
  if (e instanceof Date)
    o = e.valueOf() / 1e3;
  else if (typeof e == "number")
    o = e / 1e3;
  else
    throw new Error("The invoke time must a Date or a timestamp");
  let n = ke(t), i = Ce(r);
  return {
    ...n,
    ts: o,
    args: K(i),
    version: ee
  };
}
s(Md, "runAtSyscallArgs");

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/storage_impl.js
function Fi(e) {
  return {
    getUrl: /* @__PURE__ */ s(async (t) => (Z(t, 1, "getUrl", "storageId"), await F("1.0/storageGetUrl", {
      requestId: e,
      version: ee,
      storageId: t
    })), "getUrl"),
    getMetadata: /* @__PURE__ */ s(async (t) => await F("1.0/storageGetMetadata", {
      requestId: e,
      version: ee,
      storageId: t
    }), "getMetadata")
  };
}
s(Fi, "setupStorageReader");
function Mi(e) {
  let t = Fi(e);
  return {
    generateUploadUrl: /* @__PURE__ */ s(async () => await F("1.0/storageGenerateUploadUrl", {
      requestId: e,
      version: ee
    }), "generateUploadUrl"),
    delete: /* @__PURE__ */ s(async (r) => {
      await F("1.0/storageDelete", {
        requestId: e,
        version: ee,
        storageId: r
      });
    }, "delete"),
    getUrl: t.getUrl,
    getMetadata: t.getMetadata
  };
}
s(Mi, "setupStorageWriter");
function Rd(e) {
  return {
    ...Mi(e),
    store: /* @__PURE__ */ s(async (r, o) => await Kn("storage/storeBlob", {
      requestId: e,
      version: ee,
      blob: r,
      options: o
    }), "store"),
    get: /* @__PURE__ */ s(async (r) => await Kn("storage/getBlob", {
      requestId: e,
      version: ee,
      storageId: r
    }), "get")
  };
}
s(Rd, "setupStorageActionWriter");

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/impl/registration_impl.js
async function Ld(e, t) {
  let o = Q(JSON.parse(t)), n = {
    db: Ed(),
    auth: Hn(""),
    storage: Mi(""),
    scheduler: Cd(),
    runQuery: /* @__PURE__ */ s((a, u) => Ri("query", a, u), "runQuery"),
    runMutation: /* @__PURE__ */ s((a, u) => Ri("mutation", a, u), "runMutation")
  }, i = await Li(e, n, o);
  return Vd(i), JSON.stringify(K(i === void 0 ? null : i));
}
s(Ld, "invokeMutation");
function Vd(e) {
  if (e instanceof bt || e instanceof rt)
    throw new Error(
      "Return value is a Query. Results must be retrieved with `.collect()`, `.take(n), `.unique()`, or `.first()`."
    );
}
s(Vd, "validateReturnValue");
async function Li(e, t, r) {
  let o;
  try {
    o = await Promise.resolve(e(t, ...r));
  } catch (n) {
    throw fh(n);
  }
  return o;
}
s(Li, "invokeFunction");
function _t(e, t) {
  return (r, o) => (globalThis.console.warn(
    `Convex functions should not directly call other Convex functions. Consider calling a helper function instead. e.g. \`export const foo = ${e}(...); await foo(ctx);\` is not supported. See https://docs.convex.dev/production/best-practices/#use-helper-functions-to-write-shared-code`
  ), t(r, o));
}
s(_t, "dontCallDirectly");
function fh(e) {
  if (typeof e == "object" && e !== null && Symbol.for("ConvexError") in e) {
    let t = e;
    return t.data = JSON.stringify(
      K(t.data === void 0 ? null : t.data)
    ), t.ConvexErrorSymbol = Symbol.for("ConvexError"), t;
  } else
    return e;
}
s(fh, "serializeConvexErrorData");
function xt() {
  if (typeof window > "u" || window.__convexAllowFunctionsInBrowser)
    return;
  (Object.getOwnPropertyDescriptor(globalThis, "window")?.get?.toString().includes("[native code]") ?? !1) && console.error(
    "Convex functions should not be imported in the browser. This will throw an error in future versions of `convex`. If this is a false negative, please report it to Convex support."
  );
}
s(xt, "assertNotBrowser");
function Bd(e, t) {
  if (t === void 0)
    throw new Error(
      `A validator is undefined for field "${e}". This is often caused by circular imports. See https://docs.convex.dev/error#undefined-validator for details.`
    );
  return t;
}
s(Bd, "strictReplacer");
function wt(e) {
  return () => {
    let t = y.any();
    return typeof e == "object" && e.args !== void 0 && (t = Xt(e.args)), JSON.stringify(t.json, Bd);
  };
}
s(wt, "exportArgs");
function It(e) {
  return () => {
    let t;
    return typeof e == "object" && e.returns !== void 0 && (t = Xt(e.returns)), JSON.stringify(t ? t.json : null, Bd);
  };
}
s(It, "exportReturns");
var Vi = /* @__PURE__ */ s(((e) => {
  let t = typeof e == "function" ? e : e.handler, r = _t("mutation", t);
  return xt(), r.isMutation = !0, r.isPublic = !0, r.invokeMutation = (o) => Ld(t, o), r.exportArgs = wt(e), r.exportReturns = It(e), r._handler = t, r;
}), "mutationGeneric"), Bi = /* @__PURE__ */ s(((e) => {
  let t = typeof e == "function" ? e : e.handler, r = _t(
    "internalMutation",
    t
  );
  return xt(), r.isMutation = !0, r.isInternal = !0, r.invokeMutation = (o) => Ld(t, o), r.exportArgs = wt(e), r.exportReturns = It(e), r._handler = t, r;
}), "internalMutationGeneric");
async function Jd(e, t) {
  let o = Q(JSON.parse(t)), n = {
    db: Zi(),
    auth: Hn(""),
    storage: Fi(""),
    runQuery: /* @__PURE__ */ s((a, u) => Ri("query", a, u), "runQuery")
  }, i = await Li(e, n, o);
  return Vd(i), JSON.stringify(K(i === void 0 ? null : i));
}
s(Jd, "invokeQuery");
var Ji = /* @__PURE__ */ s(((e) => {
  let t = typeof e == "function" ? e : e.handler, r = _t("query", t);
  return xt(), r.isQuery = !0, r.isPublic = !0, r.invokeQuery = (o) => Jd(t, o), r.exportArgs = wt(e), r.exportReturns = It(e), r._handler = t, r;
}), "queryGeneric"), qi = /* @__PURE__ */ s(((e) => {
  let t = typeof e == "function" ? e : e.handler, r = _t("internalQuery", t);
  return xt(), r.isQuery = !0, r.isInternal = !0, r.invokeQuery = (o) => Jd(t, o), r.exportArgs = wt(e), r.exportReturns = It(e), r._handler = t, r;
}), "internalQueryGeneric");
async function qd(e, t, r) {
  let o = Q(JSON.parse(r)), i = {
    ...kd(t),
    auth: Hn(t),
    scheduler: Zd(t),
    storage: Rd(t),
    vectorSearch: jd(t)
  }, a = await Li(e, i, o);
  return JSON.stringify(K(a === void 0 ? null : a));
}
s(qd, "invokeAction");
var Wi = /* @__PURE__ */ s(((e) => {
  let t = typeof e == "function" ? e : e.handler, r = _t("action", t);
  return xt(), r.isAction = !0, r.isPublic = !0, r.invokeAction = (o, n) => qd(t, o, n), r.exportArgs = wt(e), r.exportReturns = It(e), r._handler = t, r;
}), "actionGeneric"), Ki = /* @__PURE__ */ s(((e) => {
  let t = typeof e == "function" ? e : e.handler, r = _t("internalAction", t);
  return xt(), r.isAction = !0, r.isInternal = !0, r.invokeAction = (o, n) => qd(t, o, n), r.exportArgs = wt(e), r.exportReturns = It(e), r._handler = t, r;
}), "internalActionGeneric");
async function Ri(e, t, r) {
  let o = Ce(r), n = {
    udfType: e,
    args: K(o),
    ...ke(t)
  }, i = await F("1.0/runUdf", n);
  return Q(i);
}
s(Ri, "runUdf");

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/pagination.js
var ph = y.object({
  numItems: y.number(),
  cursor: y.union(y.string(), y.null()),
  endCursor: y.optional(y.union(y.string(), y.null())),
  id: y.optional(y.number()),
  maximumRowsRead: y.optional(y.number()),
  maximumBytesRead: y.optional(y.number())
});

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/api.js
function Wd(e = []) {
  let t = {
    get(r, o) {
      if (typeof o == "string") {
        let n = [...e, o];
        return Wd(n);
      } else if (o === Qt) {
        if (e.length < 2) {
          let a = ["api", ...e].join(".");
          throw new Error(
            `API path is expected to be of the form \`api.moduleName.functionName\`. Found: \`${a}\``
          );
        }
        let n = e.slice(0, -1).join("/"), i = e[e.length - 1];
        return i === "default" ? n : n + ":" + i;
      } else return o === Symbol.toStringTag ? "FunctionReference" : void 0;
    }
  };
  return new Proxy({}, t);
}
s(Wd, "createApi");
var mh = Wd();

// ../../node_modules/.bun/convex@1.32.0+b1ab299f0a400331/node_modules/convex/dist/esm/server/schema.js
var hh = Object.defineProperty, vh = /* @__PURE__ */ s((e, t, r) => t in e ? hh(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, "__defNormalProp"), Te = /* @__PURE__ */ s((e, t, r) => vh(e, typeof t != "symbol" ? t + "" : t, r), "__publicField"), rr = class {
  static {
    s(this, "TableDefinition");
  }
  /**
   * @internal
   */
  constructor(t) {
    Te(this, "indexes"), Te(this, "stagedDbIndexes"), Te(this, "searchIndexes"), Te(this, "stagedSearchIndexes"), Te(this, "vectorIndexes"), Te(this, "stagedVectorIndexes"), Te(this, "validator"), this.indexes = [], this.stagedDbIndexes = [], this.searchIndexes = [], this.stagedSearchIndexes = [], this.vectorIndexes = [], this.stagedVectorIndexes = [], this.validator = t;
  }
  /**
   * This API is experimental: it may change or disappear.
   *
   * Returns indexes defined on this table.
   * Intended for the advanced use cases of dynamically deciding which index to use for a query.
   * If you think you need this, please chime in on ths issue in the Convex JS GitHub repo.
   * https://github.com/get-convex/convex-js/issues/49
   */
  " indexes"() {
    return this.indexes;
  }
  index(t, r) {
    return Array.isArray(r) ? this.indexes.push({
      indexDescriptor: t,
      fields: r
    }) : r.staged ? this.stagedDbIndexes.push({
      indexDescriptor: t,
      fields: r.fields
    }) : this.indexes.push({
      indexDescriptor: t,
      fields: r.fields
    }), this;
  }
  searchIndex(t, r) {
    return r.staged ? this.stagedSearchIndexes.push({
      indexDescriptor: t,
      searchField: r.searchField,
      filterFields: r.filterFields || []
    }) : this.searchIndexes.push({
      indexDescriptor: t,
      searchField: r.searchField,
      filterFields: r.filterFields || []
    }), this;
  }
  vectorIndex(t, r) {
    return r.staged ? this.stagedVectorIndexes.push({
      indexDescriptor: t,
      vectorField: r.vectorField,
      dimensions: r.dimensions,
      filterFields: r.filterFields || []
    }) : this.vectorIndexes.push({
      indexDescriptor: t,
      vectorField: r.vectorField,
      dimensions: r.dimensions,
      filterFields: r.filterFields || []
    }), this;
  }
  /**
   * Work around for https://github.com/microsoft/TypeScript/issues/57035
   */
  self() {
    return this;
  }
  /**
   * Export the contents of this definition.
   *
   * This is called internally by the Convex framework.
   * @internal
   */
  export() {
    let t = this.validator.json;
    if (typeof t != "object")
      throw new Error(
        "Invalid validator: please make sure that the parameter of `defineTable` is valid (see https://docs.convex.dev/database/schemas)"
      );
    return {
      indexes: this.indexes,
      stagedDbIndexes: this.stagedDbIndexes,
      searchIndexes: this.searchIndexes,
      stagedSearchIndexes: this.stagedSearchIndexes,
      vectorIndexes: this.vectorIndexes,
      stagedVectorIndexes: this.stagedVectorIndexes,
      documentType: t
    };
  }
};
function it(e) {
  return Si(e) ? new rr(e) : new rr(y.object(e));
}
s(it, "defineTable");
var Gi = class {
  static {
    s(this, "SchemaDefinition");
  }
  /**
   * @internal
   */
  constructor(t, r) {
    Te(this, "tables"), Te(this, "strictTableNameTypes"), Te(this, "schemaValidation"), this.tables = t, this.schemaValidation = r?.schemaValidation === void 0 ? !0 : r.schemaValidation;
  }
  /**
   * Export the contents of this definition.
   *
   * This is called internally by the Convex framework.
   * @internal
   */
  export() {
    return JSON.stringify({
      tables: Object.entries(this.tables).map(([t, r]) => {
        let {
          indexes: o,
          stagedDbIndexes: n,
          searchIndexes: i,
          stagedSearchIndexes: a,
          vectorIndexes: u,
          stagedVectorIndexes: c,
          documentType: l
        } = r.export();
        return {
          tableName: t,
          indexes: o,
          stagedDbIndexes: n,
          searchIndexes: i,
          stagedSearchIndexes: a,
          vectorIndexes: u,
          stagedVectorIndexes: c,
          documentType: l
        };
      }),
      schemaValidation: this.schemaValidation
    });
  }
};
function ir(e, t) {
  return new Gi(e, t);
}
s(ir, "defineSchema");
var qz = ir({
  _scheduled_functions: it({
    name: y.string(),
    args: y.array(y.any()),
    scheduledTime: y.float64(),
    completedTime: y.optional(y.float64()),
    state: y.union(
      y.object({ kind: y.literal("pending") }),
      y.object({ kind: y.literal("inProgress") }),
      y.object({ kind: y.literal("success") }),
      y.object({ kind: y.literal("failed"), error: y.string() }),
      y.object({ kind: y.literal("canceled") })
    )
  }),
  _storage: it({
    sha256: y.string(),
    size: y.float64(),
    contentType: y.optional(y.string())
  })
});

// memory/profile.mjs
var ot = class {
  static {
    s(this, "SecretText");
  }
  constructor(t) {
    this.value = t;
  }
  toWire() {
    return this.value;
  }
}, Xi = {
  seq: 1,
  at: 17e11,
  secret: "capacity",
  payload: "tiny"
};
function Kd(e) {
  let t = e.kind === "native", r = e.kind === "full" || e.kind === "mini", o = t ? e.v : e.s;
  return /* @__PURE__ */ s(function({ count: i, width: a, profile: u, entries: c = 0 }) {
    if (!Number.isInteger(i) || i < 0 || !Number.isInteger(a) || a < 1 || !Number.isInteger(c) || c < 0 || !["fields-only", "codec-rich"].includes(u))
      throw new Error("Invalid graph fixture arguments");
    let l = {
      schemaConstructors: 0,
      fields: 0,
      codecSites: 0,
      allocatedCodecs: 0
    }, d = /* @__PURE__ */ s((I, ...T) => (l.schemaConstructors++, o[I](...T)), "make"), f = /* @__PURE__ */ s((I) => (l.fields += Object.keys(I).length, d("object", I)), "object"), p = /* @__PURE__ */ s(() => (l.codecSites++, t ? d("number") : (l.allocatedCodecs++, d("codec", d("number"), d("date"), {
      decode: /* @__PURE__ */ s((I) => new Date(I), "decode"),
      encode: /* @__PURE__ */ s((I) => I.getTime(), "encode")
    }))), "date"), h = /* @__PURE__ */ s(() => (l.codecSites++, t ? d("string") : (l.allocatedCodecs++, d("codec", d("string"), d("instanceof", ot), {
      decode: /* @__PURE__ */ s((I) => new ot(I), "decode"),
      encode: /* @__PURE__ */ s((I) => I.toWire(), "encode")
    }))), "secret"), v = /* @__PURE__ */ s((I) => {
      if (u === "fields-only")
        switch (I % 4) {
          case 0:
            return d("string");
          case 1:
            return d("number");
          case 2:
            return d("boolean");
          case 3:
            return d("optional", d("string"));
        }
      switch (I % 4) {
        case 0:
          return p();
        case 1:
          return h();
        case 2:
          return f({ at: p(), tag: d("optional", d("string")) });
        case 3:
          return d(
            "array",
            t ? d("union", d("string"), d("number")) : d("union", [d("string"), d("number")])
          );
      }
    }, "field"), x = {}, k = {}, R = /* @__PURE__ */ s((I, T) => {
      r ? (l.fields += Object.keys(T).length, x[I] = e.defineZodModel(I, T), k[I] = x[I].schema.insert) : (k[I] = f(T), x[I] = t ? e.defineTable(k[I]) : k[I]);
    }, "add");
    R("benchmarkRows", {
      seq: d("number"),
      at: p(),
      secret: h(),
      payload: d("string")
    });
    for (let I = 0; I < i; I++) {
      let T = {};
      for (let q = 0; q < a; q++) T[`f${q}`] = v(q);
      R(`unused${I}`, T);
    }
    let j = r ? e.defineZodSchema(x) : t ? e.defineSchema(x) : null, O = Object.keys(x), U = {};
    for (let I = 0; I < c; I++) {
      let T = O[I % O.length], q = r ? x[T].schema.doc : k[T], Ue = f({
        id: d("string"),
        label: d("optional", d("string"))
      }), Ye = t ? d("union", q, d("null")) : d("nullable", q);
      U[`unused/fn${I}`] = { args: Ue, returns: Ye };
    }
    let M = r ? e.initZodvex(
      j,
      e.server,
      c ? { registry: /* @__PURE__ */ s(() => U, "registry") } : void 0
    ) : e.makeBuilders();
    return {
      kind: e.kind,
      options: { count: i, width: a, profile: u, entries: c },
      models: x,
      sourceSchemas: k,
      schema: j,
      registry: U,
      builders: M,
      manifest: {
        backgroundModels: i,
        totalModels: i + 1,
        backgroundTopLevelFields: i * a,
        fixedProbeFields: 4,
        profile: u,
        registryEntries: c,
        ...l,
        counterScope: "Explicit fixture constructor calls and source fields/codecs; excludes library-generated helper schemas and runtime heap objects."
      },
      operation() {
        let I = { ...Xi }, T = t ? {
          ...I,
          at: new Date(I.at),
          secret: new ot(I.secret)
        } : e.s.parse(k.benchmarkRows, I);
        if (!(T.at instanceof Date) || !(T.secret instanceof ot))
          throw new Error("Codec decode failed");
        T.at = new Date(T.at.getTime() + 1e3), T.secret = new ot(T.secret.toWire().toUpperCase());
        let q = t ? {
          ...T,
          at: T.at.getTime(),
          secret: T.secret.toWire()
        } : e.s.encode(k.benchmarkRows, T);
        if (JSON.stringify(q) !== JSON.stringify({
          ...Xi,
          at: Xi.at + 1e3,
          secret: "CAPACITY"
        }))
          throw new Error("Codec round trip mismatch");
        return q;
      },
      // Call after the operation and after GC measurements. The retained graph
      // includes every model, table schema, registry entry and builder closure.
      checksum() {
        let I = 0;
        for (let [T, q] of Object.entries(x)) {
          if (!q || !k[T]) throw new Error("Missing model");
          if (I += T.length, r && j.__zodTableMap[T].insert !== k[T])
            throw new Error("Lost table-map alias");
        }
        for (let [T, q] of Object.entries(U)) {
          if (!q.args || !q.returns)
            throw new Error("Missing registry schema");
          I += T.length;
        }
        if (Object.keys(M).length === 0)
          throw new Error("Lost builders");
        return I;
      }
    };
  }, "buildGraph");
}
s(Kd, "createGraphFactory");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/mini/external.js
var w = {};
et(w, {
  $brand: () => _o,
  $input: () => Wu,
  $output: () => qu,
  NEVER: () => bo,
  TimePrecision: () => Ic,
  ZodCompileAsyncError: () => De,
  ZodCompileUnsupportedError: () => C,
  ZodMiniAny: () => zp,
  ZodMiniArray: () => Pp,
  ZodMiniBase64: () => vp,
  ZodMiniBase64URL: () => yp,
  ZodMiniBigInt: () => jn,
  ZodMiniBigIntFormat: () => Al,
  ZodMiniBoolean: () => Sn,
  ZodMiniCIDRv4: () => mp,
  ZodMiniCIDRv6: () => gp,
  ZodMiniCUID: () => sp,
  ZodMiniCUID2: () => up,
  ZodMiniCatch: () => Kp,
  ZodMiniCodec: () => ni,
  ZodMiniCreditCard: () => bp,
  ZodMiniCustom: () => Jl,
  ZodMiniCustomStringFormat: () => kn,
  ZodMiniDate: () => Yr,
  ZodMiniDefault: () => Jp,
  ZodMiniDiscriminatedUnion: () => Np,
  ZodMiniE164: () => $p,
  ZodMiniEmail: () => rp,
  ZodMiniEmoji: () => op,
  ZodMiniEnum: () => Ml,
  ZodMiniExactOptional: () => Rl,
  ZodMiniFile: () => Lp,
  ZodMiniFunction: () => nm,
  ZodMiniGUID: () => ip,
  ZodMiniIPv4: () => fp,
  ZodMiniIPv6: () => pp,
  ZodMiniISODate: () => oi,
  ZodMiniISODateTime: () => ii,
  ZodMiniISODuration: () => si,
  ZodMiniISOTime: () => ai,
  ZodMiniIntersection: () => Up,
  ZodMiniJWT: () => _p,
  ZodMiniKSUID: () => dp,
  ZodMiniLazy: () => Qp,
  ZodMiniLiteral: () => Rp,
  ZodMiniMAC: () => hp,
  ZodMiniMap: () => Zp,
  ZodMiniNaN: () => Gp,
  ZodMiniNanoID: () => ap,
  ZodMiniNever: () => jp,
  ZodMiniNonOptional: () => Ll,
  ZodMiniNull: () => Ip,
  ZodMiniNullable: () => Bp,
  ZodMiniNumber: () => zn,
  ZodMiniNumberFormat: () => Mt,
  ZodMiniObject: () => ei,
  ZodMiniOptional: () => Xr,
  ZodMiniPipe: () => Vl,
  ZodMiniPrefault: () => qp,
  ZodMiniPromise: () => em,
  ZodMiniReadonly: () => Xp,
  ZodMiniRecord: () => wn,
  ZodMiniSet: () => Fp,
  ZodMiniString: () => Ft,
  ZodMiniStringFormat: () => J,
  ZodMiniSuccess: () => Wp,
  ZodMiniSymbol: () => xp,
  ZodMiniTemplateLiteral: () => Hp,
  ZodMiniTransform: () => Vp,
  ZodMiniTuple: () => Ap,
  ZodMiniType: () => N,
  ZodMiniULID: () => cp,
  ZodMiniURL: () => Ul,
  ZodMiniUUID: () => In,
  ZodMiniUndefined: () => wp,
  ZodMiniUnion: () => Fl,
  ZodMiniUnknown: () => Sp,
  ZodMiniVoid: () => Dp,
  ZodMiniXID: () => lp,
  ZodMiniXor: () => Tp,
  _default: () => cx,
  _function: () => Sx,
  any: () => C_,
  array: () => On,
  base64: () => y_,
  base64url: () => $_,
  bigint: () => T_,
  boolean: () => Qr,
  catch: () => px,
  catchall: () => G_,
  check: () => bx,
  cidrv4: () => g_,
  cidrv6: () => h_,
  clone: () => E,
  codec: () => Bl,
  coerce: () => Kl,
  compile: () => Hu,
  config: () => ie,
  core: () => Ct,
  creditCard: () => __,
  cuid: () => u_,
  cuid2: () => c_,
  custom: () => tm,
  date: () => El,
  decode: () => Po,
  decodeAsync: () => No,
  deepPartial: () => im,
  describe: () => wx,
  discriminatedUnion: () => H_,
  e164: () => b_,
  email: () => Qb,
  emoji: () => a_,
  encode: () => se,
  encodeAsync: () => To,
  endsWith: () => ml,
  enum: () => Mp,
  exactOptional: () => sx,
  exactPartial: () => W_,
  extend: () => L_,
  file: () => ox,
  flattenError: () => ko,
  float32: () => j_,
  float64: () => O_,
  formatError: () => zo,
  function: () => Sx,
  getDiscriminatedOption: () => $s,
  globalRegistry: () => Oe,
  gt: () => Jr,
  gte: () => bn,
  guid: () => Yb,
  hash: () => z_,
  hex: () => k_,
  hostname: () => I_,
  httpUrl: () => o_,
  includes: () => fl,
  input: () => am,
  instanceof: () => ql,
  int: () => S_,
  int32: () => D_,
  int64: () => N_,
  intersection: () => Q_,
  invertCodec: () => hx,
  ipv4: () => p_,
  ipv6: () => m_,
  iso: () => Wl,
  json: () => zx,
  jwt: () => x_,
  keyof: () => F_,
  ksuid: () => f_,
  lazy: () => Yp,
  length: () => ul,
  literal: () => ix,
  locales: () => yn,
  looseObject: () => R_,
  looseRecord: () => ex,
  lowercase: () => ll,
  lt: () => Br,
  lte: () => $n,
  mac: () => v_,
  map: () => tx,
  maxLength: () => al,
  maxSize: () => rl,
  maximum: () => $n,
  memoizer: () => Fs,
  merge: () => B_,
  meta: () => Ix,
  mime: () => vl,
  minLength: () => sl,
  minSize: () => il,
  minimum: () => bn,
  multipleOf: () => nl,
  nan: () => mx,
  nanoid: () => s_,
  nativeEnum: () => rx,
  negative: () => Yc,
  never: () => Op,
  nonnegative: () => tl,
  nonoptional: () => dx,
  nonpositive: () => el,
  normalize: () => yl,
  null: () => kp,
  nullable: () => ti,
  nullish: () => ux,
  number: () => Hr,
  object: () => Cl,
  omit: () => q_,
  optional: () => Lt,
  output: () => sm,
  overwrite: () => Ke,
  parse: () => ve,
  parseAsync: () => Le,
  partial: () => Zl,
  partialRecord: () => Y_,
  pick: () => J_,
  pipe: () => gx,
  positive: () => Qc,
  prefault: () => lx,
  prettifyError: () => jo,
  promise: () => $x,
  properties: () => hl,
  property: () => gl,
  readonly: () => vx,
  record: () => Cp,
  refine: () => _x,
  regex: () => cl,
  regexes: () => ue,
  registry: () => Rr,
  required: () => K_,
  safeDecode: () => Ao,
  safeDecodeAsync: () => Co,
  safeEncode: () => Uo,
  safeEncodeAsync: () => Eo,
  safeExtend: () => V_,
  safeParse: () => Se,
  safeParseAsync: () => ut,
  set: () => nx,
  size: () => ol,
  startsWith: () => pl,
  strictObject: () => M_,
  string: () => Zt,
  stringFormat: () => w_,
  stringbool: () => kx,
  success: () => fx,
  superRefine: () => xx,
  symbol: () => A_,
  templateLiteral: () => yx,
  toJSONSchema: () => Wr,
  toLowerCase: () => bl,
  toUpperCase: () => _l,
  toZod: () => en,
  transform: () => ax,
  treeifyError: () => So,
  trim: () => $l,
  tuple: () => Ep,
  uint32: () => P_,
  uint64: () => U_,
  ulid: () => l_,
  undefined: () => E_,
  union: () => Rt,
  unknown: () => Gr,
  uppercase: () => dl,
  url: () => i_,
  util: () => z,
  uuid: () => e_,
  uuidv4: () => t_,
  uuidv6: () => n_,
  uuidv7: () => r_,
  validate: () => Oo,
  validateAsync: () => Do,
  void: () => Z_,
  xid: () => d_,
  xor: () => X_
});

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/index.js
var Ct = {};
et(Ct, {
  $ZodAny: () => ms,
  $ZodArray: () => Be,
  $ZodAsyncError: () => ge,
  $ZodBase64: () => rs,
  $ZodBase64URL: () => is,
  $ZodBigInt: () => Ur,
  $ZodBigIntFormat: () => ls,
  $ZodBoolean: () => pn,
  $ZodCIDRv4: () => ts,
  $ZodCIDRv6: () => ns,
  $ZodCUID: () => Va,
  $ZodCUID2: () => Ba,
  $ZodCatch: () => Os,
  $ZodCheck: () => W,
  $ZodCheckBigIntFormat: () => ya,
  $ZodCheckEndsWith: () => Da,
  $ZodCheckGreaterThan: () => $r,
  $ZodCheckIncludes: () => ja,
  $ZodCheckLengthEquals: () => Ia,
  $ZodCheckLessThan: () => yr,
  $ZodCheckLowerCase: () => za,
  $ZodCheckMaxLength: () => xa,
  $ZodCheckMaxSize: () => $a,
  $ZodCheckMimeType: () => Pa,
  $ZodCheckMinLength: () => wa,
  $ZodCheckMinSize: () => ba,
  $ZodCheckMultipleOf: () => ha,
  $ZodCheckNumberFormat: () => va,
  $ZodCheckOverwrite: () => Ta,
  $ZodCheckProperty: () => br,
  $ZodCheckRegex: () => ka,
  $ZodCheckSizeEquals: () => _a,
  $ZodCheckStartsWith: () => Oa,
  $ZodCheckStringFormat: () => Ot,
  $ZodCheckUpperCase: () => Sa,
  $ZodCodec: () => je,
  $ZodCreditCard: () => as,
  $ZodCustom: () => mn,
  $ZodCustomStringFormat: () => us,
  $ZodCyclicError: () => Zr,
  $ZodDate: () => Tt,
  $ZodDefault: () => $e,
  $ZodDiscriminatedUnion: () => Je,
  $ZodE164: () => os,
  $ZodEmail: () => Ca,
  $ZodEmoji: () => Ra,
  $ZodEncodeError: () => jt,
  $ZodEnum: () => Nt,
  $ZodError: () => Ae,
  $ZodExactOptional: () => ks,
  $ZodFile: () => ws,
  $ZodFunction: () => Ns,
  $ZodGUID: () => Aa,
  $ZodIPv4: () => Qa,
  $ZodIPv6: () => Ya,
  $ZodISODate: () => Ga,
  $ZodISODateTime: () => Ka,
  $ZodISODuration: () => Ha,
  $ZodISOTime: () => Xa,
  $ZodIntersection: () => bs,
  $ZodJWT: () => ss,
  $ZodKSUID: () => Wa,
  $ZodLazy: () => We,
  $ZodLiteral: () => Ut,
  $ZodMAC: () => es,
  $ZodMap: () => _s,
  $ZodNaN: () => Ds,
  $ZodNanoID: () => La,
  $ZodNever: () => hs,
  $ZodNonOptional: () => Ss,
  $ZodNull: () => ps,
  $ZodNullable: () => Ie,
  $ZodNumber: () => Nr,
  $ZodNumberFormat: () => cs,
  $ZodObject: () => Y,
  $ZodObjectJIT: () => jv,
  $ZodOptional: () => X,
  $ZodPipe: () => Ar,
  $ZodPrefault: () => zs,
  $ZodPreprocess: () => Ov,
  $ZodPromise: () => Us,
  $ZodReadonly: () => Ps,
  $ZodRealError: () => he,
  $ZodRecord: () => dt,
  $ZodRegistry: () => Mr,
  $ZodSet: () => xs,
  $ZodString: () => Pt,
  $ZodStringFormat: () => V,
  $ZodSuccess: () => js,
  $ZodSymbol: () => ds,
  $ZodTemplateLiteral: () => Ts,
  $ZodTransform: () => Is,
  $ZodTuple: () => qe,
  $ZodType: () => S,
  $ZodULID: () => Ja,
  $ZodURL: () => Ma,
  $ZodUUID: () => Ea,
  $ZodUndefined: () => fs,
  $ZodUnion: () => ce,
  $ZodUnknown: () => gs,
  $ZodVoid: () => vs,
  $ZodXID: () => qa,
  $ZodXor: () => ys,
  $brand: () => _o,
  $constructor: () => g,
  $input: () => Wu,
  $output: () => qu,
  Doc: () => lt,
  INVALID: () => be,
  JSONSchema: () => np,
  JSONSchemaGenerator: () => Kr,
  NEVER: () => bo,
  TimePrecision: () => Ic,
  URL_BAD_FORMAT: () => Za,
  URL_UNPARSEABLE: () => Fa,
  ZodCompileAsyncError: () => De,
  ZodCompileUnsupportedError: () => C,
  _any: () => Jc,
  _array: () => Z$,
  _base64: () => $c,
  _base64url: () => bc,
  _bigint: () => Zc,
  _boolean: () => Ec,
  _catch: () => nb,
  _check: () => Gf,
  _cidrv4: () => vc,
  _cidrv6: () => yc,
  _coercedBigint: () => Fc,
  _coercedBoolean: () => Cc,
  _coercedDate: () => Xc,
  _coercedNumber: () => Dc,
  _coercedString: () => ec,
  _creditCard: () => xc,
  _cuid: () => cc,
  _cuid2: () => lc,
  _custom: () => wl,
  _date: () => Gc,
  _decode: () => of,
  _decodeAsync: () => sf,
  _default: () => Y$,
  _discriminatedUnion: () => R$,
  _e164: () => _c,
  _email: () => tc,
  _emoji: () => sc,
  _encode: () => rf,
  _encodeAsync: () => af,
  _endsWith: () => ml,
  _enum: () => W$,
  _file: () => xl,
  _float32: () => Tc,
  _float64: () => Nc,
  _gt: () => Jr,
  _gte: () => bn,
  _guid: () => nc,
  _includes: () => fl,
  _int: () => Pc,
  _int32: () => Uc,
  _int64: () => Mc,
  _intersection: () => L$,
  _ipv4: () => mc,
  _ipv6: () => gc,
  _isoDate: () => zc,
  _isoDateTime: () => kc,
  _isoDuration: () => jc,
  _isoTime: () => Sc,
  _jwt: () => wc,
  _ksuid: () => pc,
  _lazy: () => ab,
  _length: () => ul,
  _literal: () => G$,
  _lowercase: () => ll,
  _lt: () => Br,
  _lte: () => $n,
  _mac: () => hc,
  _map: () => J$,
  _max: () => $n,
  _maxLength: () => al,
  _maxSize: () => rl,
  _mime: () => vl,
  _min: () => bn,
  _minLength: () => sl,
  _minSize: () => il,
  _multipleOf: () => nl,
  _nan: () => Hc,
  _nanoid: () => uc,
  _nativeEnum: () => K$,
  _negative: () => Yc,
  _never: () => Wc,
  _nonnegative: () => tl,
  _nonoptional: () => eb,
  _nonpositive: () => el,
  _normalize: () => yl,
  _null: () => Bc,
  _nullable: () => Q$,
  _number: () => Oc,
  _optional: () => H$,
  _overwrite: () => Ke,
  _parse: () => dr,
  _parseAsync: () => fr,
  _pipe: () => rb,
  _positive: () => Qc,
  _promise: () => sb,
  _properties: () => hl,
  _property: () => gl,
  _readonly: () => ib,
  _record: () => B$,
  _refine: () => Il,
  _regex: () => cl,
  _safeDecode: () => cf,
  _safeDecodeAsync: () => df,
  _safeEncode: () => uf,
  _safeEncodeAsync: () => lf,
  _safeParse: () => pr,
  _safeParseAsync: () => mr,
  _set: () => q$,
  _size: () => ol,
  _slugify: () => C$,
  _startsWith: () => pl,
  _string: () => Yu,
  _stringFormat: () => Et,
  _stringbool: () => jl,
  _success: () => tb,
  _superRefine: () => kl,
  _symbol: () => Lc,
  _templateLiteral: () => ob,
  _toLowerCase: () => bl,
  _toUpperCase: () => _l,
  _transform: () => X$,
  _trim: () => $l,
  _tuple: () => V$,
  _uint32: () => Ac,
  _uint64: () => Rc,
  _ulid: () => dc,
  _undefined: () => Vc,
  _union: () => F$,
  _unknown: () => qc,
  _uppercase: () => dl,
  _url: () => Vr,
  _uuid: () => rc,
  _uuidv4: () => ic,
  _uuidv6: () => oc,
  _uuidv7: () => ac,
  _void: () => Kc,
  _xid: () => fc,
  _xor: () => M$,
  clone: () => E,
  compile: () => Hu,
  compileFn: () => Lr,
  config: () => ie,
  createStandardJSONSchemaMethod: () => Dl,
  createToJSONSchemaMethod: () => cb,
  decode: () => Po,
  decodeAsync: () => No,
  describe: () => zl,
  encode: () => se,
  encodeAsync: () => To,
  extractDefs: () => Xe,
  finalize: () => He,
  flattenError: () => ko,
  formatError: () => zo,
  getDiscriminatedOption: () => $s,
  globalConfig: () => ae,
  globalRegistry: () => Oe,
  handleUnrepresentable: () => re,
  initializeContext: () => Ge,
  isBackEdge: () => Fr,
  isRecursiveSchema: () => Zs,
  isValidBase64: () => fn,
  isValidBase64URL: () => Dr,
  isValidCIDRv6: () => Or,
  isValidCreditCard: () => Pr,
  isValidIPv6: () => dn,
  isValidJWT: () => Tr,
  locales: () => yn,
  memoizer: () => Fs,
  mergeValues: () => Dt,
  meta: () => Sl,
  parse: () => ve,
  parseAsync: () => Le,
  parseURLObject: () => kr,
  prettifyError: () => jo,
  process: () => L,
  regexes: () => ue,
  registry: () => Rr,
  safeDecode: () => Ao,
  safeDecodeAsync: () => Co,
  safeEncode: () => Uo,
  safeEncodeAsync: () => Eo,
  safeParse: () => Se,
  safeParseAsync: () => ut,
  standardProps: () => Tf,
  stripTabAndNewline: () => zr,
  toDotPath: () => nf,
  toJSONSchema: () => Wr,
  toZod: () => en,
  treeifyError: () => So,
  urlHostnameOk: () => Sr,
  urlProtocolOk: () => jr,
  util: () => z,
  validate: () => Oo,
  validateAsync: () => Do,
  version: () => Na
});

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/util.js
var z = {};
et(z, {
  BIGINT_FORMAT_RANGES: () => ao,
  CONSTANT_CATCH: () => cr,
  Class: () => Qi,
  NUMBER_FORMAT_RANGES: () => oo,
  aborted: () => Re,
  allowsEval: () => no,
  assert: () => xh,
  assertEqual: () => yh,
  assertIs: () => bh,
  assertNever: () => _h,
  assertNotEqual: () => $h,
  assignProp: () => te,
  attachSchema: () => ur,
  base64ToUint8Array: () => Xd,
  base64urlToUint8Array: () => Nh,
  cached: () => zt,
  captureStackTrace: () => ar,
  cleanEnum: () => Th,
  cleanRegex: () => nn,
  clone: () => E,
  cloneDef: () => Ih,
  codePointLength: () => st,
  constantCatch: () => yo,
  createTransparentProxy: () => Dh,
  defineLazy: () => eo,
  defineLazyInternal: () => A,
  esc: () => fe,
  escapeRegex: () => we,
  explicitlyAborted: () => mo,
  extend: () => co,
  finalizeIssue: () => me,
  floatSafeRemainder: () => rn,
  getElementAtPath: () => kh,
  getEnumValues: () => tn,
  getLengthableOrigin: () => sn,
  getParsedType: () => Oh,
  getSizableOrigin: () => an,
  hexToUint8Array: () => Ah,
  hide: () => ho,
  installLazyProp: () => vo,
  isObject: () => at,
  isPlainObject: () => Ne,
  issue: () => St,
  joinValues: () => m,
  jsonStringifyReplacer: () => Yi,
  members: () => go,
  merge: () => fo,
  mergeDefs: () => ze,
  normalizeParams: () => _,
  nullish: () => or,
  numKeys: () => jh,
  objectClone: () => wh,
  omit: () => uo,
  optionalKeys: () => io,
  own: () => Fe,
  parsedType: () => b,
  partial: () => sr,
  pick: () => so,
  prefixIssues: () => pe,
  primitiveTypes: () => ro,
  promiseAllObject: () => zh,
  propertyKeyTypes: () => on,
  randomString: () => Sh,
  required: () => po,
  safeExtend: () => lo,
  shallowClone: () => Me,
  slugify: () => to,
  stringifyPrimitive: () => $,
  toZod: () => en,
  uint8ArrayToBase64: () => Hd,
  uint8ArrayToBase64url: () => Uh,
  uint8ArrayToHex: () => Eh,
  unwrapMessage: () => kt
});
function yh(e) {
  return e;
}
s(yh, "assertEqual");
function $h(e) {
  return e;
}
s($h, "assertNotEqual");
function en() {
  return (e) => e;
}
s(en, "toZod");
function bh(e) {
}
s(bh, "assertIs");
function _h(e) {
  throw new Error("Unexpected value in exhaustive check");
}
s(_h, "assertNever");
function xh(e) {
}
s(xh, "assert");
function tn(e) {
  let t = Object.values(e).filter((o) => typeof o == "number");
  return Object.entries(e).filter(([o, n]) => t.indexOf(+o) === -1).map(([o, n]) => n);
}
s(tn, "getEnumValues");
function m(e, t = "|") {
  return e.map((r) => $(r)).join(t);
}
s(m, "joinValues");
function Yi(e, t) {
  return typeof t == "bigint" ? t.toString() : t;
}
s(Yi, "jsonStringifyReplacer");
function zt(e) {
  return {
    get value() {
      {
        let r = e();
        return Object.defineProperty(this, "value", { value: r }), r;
      }
      throw new Error("cached value already set");
    }
  };
}
s(zt, "cached");
function or(e) {
  return e == null;
}
s(or, "nullish");
function nn(e) {
  let t = e.startsWith("^") ? 1 : 0, r = e.endsWith("$") ? e.length - 1 : e.length;
  return e.slice(t, r);
}
s(nn, "cleanRegex");
function rn(e, t) {
  let r = e / t, o = Math.round(r), n = 4 * Number.EPSILON * Math.max(Math.abs(r), 1);
  return Math.abs(r - o) < n ? 0 : r - o;
}
s(rn, "floatSafeRemainder");
var Gd = /* @__PURE__ */ Symbol("evaluating");
function eo(e, t, r) {
  let o;
  Object.defineProperty(e, t, {
    get() {
      if (o !== Gd)
        return o === void 0 && (o = Gd, o = r()), o;
    },
    set(n) {
      Object.defineProperty(e, t, {
        value: n
        // configurable: true,
      });
    },
    configurable: !0
  });
}
s(eo, "defineLazy");
function wh(e) {
  return Object.create(Object.getPrototypeOf(e), Object.getOwnPropertyDescriptors(e));
}
s(wh, "objectClone");
function te(e, t, r) {
  Object.defineProperty(e, t, {
    value: r,
    writable: !0,
    enumerable: !0,
    configurable: !0
  });
}
s(te, "assignProp");
function ze(...e) {
  let t = {};
  for (let r of e) {
    let o = Object.getOwnPropertyDescriptors(r);
    Object.assign(t, o);
  }
  return Object.defineProperties({}, t);
}
s(ze, "mergeDefs");
function Ih(e) {
  return ze(e._zod.def);
}
s(Ih, "cloneDef");
function kh(e, t) {
  return t ? t.reduce((r, o) => r?.[o], e) : e;
}
s(kh, "getElementAtPath");
function zh(e) {
  let t = Object.keys(e), r = t.map((o) => e[o]);
  return Promise.all(r).then((o) => {
    let n = {};
    for (let i = 0; i < t.length; i++)
      n[t[i]] = o[i];
    return n;
  });
}
s(zh, "promiseAllObject");
function Sh(e = 10) {
  let t = "abcdefghijklmnopqrstuvwxyz", r = "";
  for (let o = 0; o < e; o++)
    r += t[Math.floor(Math.random() * t.length)];
  return r;
}
s(Sh, "randomString");
function fe(e) {
  return JSON.stringify(e);
}
s(fe, "esc");
function to(e) {
  return e.toLowerCase().trim().replace(/[^\w\s-]/g, "").replace(/[\s_-]+/g, "-").replace(/^-+|-+$/g, "");
}
s(to, "slugify");
var ar = "captureStackTrace" in Error ? Error.captureStackTrace : (...e) => {
};
function at(e) {
  return typeof e == "object" && e !== null && !Array.isArray(e);
}
s(at, "isObject");
var no = /* @__PURE__ */ zt(() => {
  if (ae.jitless || typeof navigator < "u" && navigator?.userAgent?.includes("Cloudflare"))
    return !1;
  try {
    let e = Function;
    return new e(""), !0;
  } catch {
    return !1;
  }
});
function Ne(e) {
  if (at(e) === !1)
    return !1;
  let t = e.constructor;
  if (t === void 0 || typeof t != "function")
    return !0;
  let r = t.prototype;
  return !(at(r) === !1 || Object.prototype.hasOwnProperty.call(r, "isPrototypeOf") === !1);
}
s(Ne, "isPlainObject");
function Me(e) {
  return Ne(e) ? { ...e } : Array.isArray(e) ? [...e] : e instanceof Map ? new Map(e) : e instanceof Set ? new Set(e) : e;
}
s(Me, "shallowClone");
function jh(e) {
  let t = 0;
  for (let r in e)
    Object.prototype.hasOwnProperty.call(e, r) && t++;
  return t;
}
s(jh, "numKeys");
var Oh = /* @__PURE__ */ s((e) => {
  let t = typeof e;
  switch (t) {
    case "undefined":
      return "undefined";
    case "string":
      return "string";
    case "number":
      return Number.isNaN(e) ? "nan" : "number";
    case "boolean":
      return "boolean";
    case "function":
      return "function";
    case "bigint":
      return "bigint";
    case "symbol":
      return "symbol";
    case "object":
      return Array.isArray(e) ? "array" : e === null ? "null" : e.then && typeof e.then == "function" && e.catch && typeof e.catch == "function" ? "promise" : typeof Map < "u" && e instanceof Map ? "map" : typeof Set < "u" && e instanceof Set ? "set" : typeof Date < "u" && e instanceof Date ? "date" : typeof File < "u" && e instanceof File ? "file" : "object";
    default:
      throw new Error(`Unknown data type: ${t}`);
  }
}, "getParsedType"), on = /* @__PURE__ */ new Set(["string", "number", "symbol"]), ro = /* @__PURE__ */ new Set([
  "string",
  "number",
  "bigint",
  "boolean",
  "symbol",
  "undefined"
]);
function we(e) {
  return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
s(we, "escapeRegex");
function E(e, t, r) {
  let o = new e._zod.constr(t ?? e._zod.def);
  return (!t || r?.parent) && (o._zod.parent = e), o;
}
s(E, "clone");
function _(e) {
  let t = e;
  if (!t)
    return {};
  if (typeof t == "string")
    return { error: /* @__PURE__ */ s(() => t, "error") };
  if (t?.message !== void 0) {
    if (t?.error !== void 0)
      throw new Error("Cannot specify both `message` and `error` params");
    t.error = t.message;
  }
  return delete t.message, typeof t.error == "string" ? { ...t, error: /* @__PURE__ */ s(() => t.error, "error") } : t;
}
s(_, "normalizeParams");
function Dh(e) {
  let t;
  return new Proxy({}, {
    get(r, o, n) {
      return t ?? (t = e()), Reflect.get(t, o, n);
    },
    set(r, o, n, i) {
      return t ?? (t = e()), Reflect.set(t, o, n, i);
    },
    has(r, o) {
      return t ?? (t = e()), Reflect.has(t, o);
    },
    deleteProperty(r, o) {
      return t ?? (t = e()), Reflect.deleteProperty(t, o);
    },
    ownKeys(r) {
      return t ?? (t = e()), Reflect.ownKeys(t);
    },
    getOwnPropertyDescriptor(r, o) {
      return t ?? (t = e()), Reflect.getOwnPropertyDescriptor(t, o);
    },
    defineProperty(r, o, n) {
      return t ?? (t = e()), Reflect.defineProperty(t, o, n);
    }
  });
}
s(Dh, "createTransparentProxy");
function $(e) {
  return typeof e == "bigint" ? e.toString() + "n" : typeof e == "string" ? `"${e}"` : `${e}`;
}
s($, "stringifyPrimitive");
function io(e) {
  return Object.keys(e).filter((t) => e[t]._zod.optin !== void 0 && e[t]._zod.optout === "optional");
}
s(io, "optionalKeys");
var oo = {
  safeint: [Number.MIN_SAFE_INTEGER, Number.MAX_SAFE_INTEGER],
  int32: [-2147483648, 2147483647],
  uint32: [0, 4294967295],
  float32: [-34028234663852886e22, 34028234663852886e22],
  float64: [-Number.MAX_VALUE, Number.MAX_VALUE]
}, ao = {
  int64: [/* @__PURE__ */ BigInt("-9223372036854775808"), /* @__PURE__ */ BigInt("9223372036854775807")],
  uint64: [/* @__PURE__ */ BigInt(0), /* @__PURE__ */ BigInt("18446744073709551615")]
};
function so(e, t) {
  let r = e._zod.def, o = r.checks;
  if (o && o.length > 0)
    throw new Error(".pick() cannot be used on object schemas containing refinements");
  let i = ze(e._zod.def, {
    get shape() {
      let a = {};
      for (let u of Reflect.ownKeys(t)) {
        if (!Object.prototype.hasOwnProperty.call(r.shape, u))
          throw new Error(`Unrecognized key: "${String(u)}"`);
        t[u] && te(a, u, r.shape[u]);
      }
      return te(this, "shape", a), a;
    },
    checks: []
  });
  return E(e, i);
}
s(so, "pick");
function uo(e, t) {
  let r = e._zod.def, o = r.checks;
  if (o && o.length > 0)
    throw new Error(".omit() cannot be used on object schemas containing refinements");
  let i = ze(e._zod.def, {
    get shape() {
      let a = { ...e._zod.def.shape };
      for (let u of Reflect.ownKeys(t)) {
        if (!Object.prototype.hasOwnProperty.call(r.shape, u))
          throw new Error(`Unrecognized key: "${String(u)}"`);
        t[u] && delete a[u];
      }
      return te(this, "shape", a), a;
    },
    checks: []
  });
  return E(e, i);
}
s(uo, "omit");
function co(e, t) {
  if (!Ne(t))
    throw new Error("Invalid input to extend: expected a plain object");
  let r = e._zod.def.checks;
  if (r && r.length > 0) {
    let i = e._zod.def.shape;
    for (let a of Reflect.ownKeys(t))
      if (Object.getOwnPropertyDescriptor(i, a) !== void 0)
        throw new Error("Cannot overwrite keys on object schemas containing refinements. Use `.safeExtend()` instead.");
  }
  let n = ze(e._zod.def, {
    get shape() {
      let i = { ...e._zod.def.shape, ...t };
      return te(this, "shape", i), i;
    }
  });
  return E(e, n);
}
s(co, "extend");
function lo(e, t) {
  if (!Ne(t))
    throw new Error("Invalid input to safeExtend: expected a plain object");
  let r = ze(e._zod.def, {
    get shape() {
      let o = { ...e._zod.def.shape, ...t };
      return te(this, "shape", o), o;
    }
  });
  return E(e, r);
}
s(lo, "safeExtend");
function fo(e, t) {
  if (!t?._zod?.def)
    throw new Error("Invalid input to merge: expected an object schema. To merge a plain shape, use `.extend()`.");
  if (e._zod.def.checks?.length)
    throw new Error(".merge() cannot be used on object schemas containing refinements. Use .safeExtend() instead.");
  let r = ze(e._zod.def, {
    get shape() {
      let o = { ...e._zod.def.shape, ...t._zod.def.shape };
      return te(this, "shape", o), o;
    },
    get catchall() {
      return t._zod.def.catchall;
    },
    checks: t._zod.def.checks ?? []
  });
  return E(e, r);
}
s(fo, "merge");
function sr(e, t, r, o = "partial") {
  let i = t._zod.def.checks;
  if (i && i.length > 0)
    throw new Error(`.${o}() cannot be used on object schemas containing refinements`);
  let u = ze(t._zod.def, {
    get shape() {
      let c = t._zod.def.shape, l = { ...c };
      if (r)
        for (let d of Reflect.ownKeys(r)) {
          if (!Object.prototype.hasOwnProperty.call(c, d))
            throw new Error(`Unrecognized key: "${String(d)}"`);
          r[d] && (l[d] = e ? new e({
            type: "optional",
            innerType: c[d]
          }) : c[d]);
        }
      else
        for (let d of Reflect.ownKeys(c))
          l[d] = e ? new e({
            type: "optional",
            innerType: c[d]
          }) : c[d];
      return te(this, "shape", l), l;
    },
    checks: []
  });
  return E(t, u);
}
s(sr, "partial");
function po(e, t, r) {
  let o = ze(t._zod.def, {
    get shape() {
      let n = t._zod.def.shape, i = { ...n };
      if (r)
        for (let a of Reflect.ownKeys(r)) {
          if (!Object.prototype.hasOwnProperty.call(i, a))
            throw new Error(`Unrecognized key: "${String(a)}"`);
          r[a] && (i[a] = new e({
            type: "nonoptional",
            innerType: n[a]
          }));
        }
      else
        for (let a of Reflect.ownKeys(n))
          i[a] = new e({
            type: "nonoptional",
            innerType: n[a]
          });
      return te(this, "shape", i), i;
    }
  });
  return E(t, o);
}
s(po, "required");
function Re(e, t = 0) {
  if (e.aborted === !0)
    return !0;
  for (let r = t; r < e.issues.length; r++)
    if (e.issues[r]?.continue !== !0)
      return !0;
  return !1;
}
s(Re, "aborted");
function mo(e, t = 0) {
  if (e.aborted === !0)
    return !0;
  for (let r = t; r < e.issues.length; r++)
    if (e.issues[r]?.continue === !1)
      return !0;
  return !1;
}
s(mo, "explicitlyAborted");
function pe(e, t) {
  return t.map((r) => {
    var o;
    return (o = r).path ?? (o.path = []), r.path.unshift(e), r;
  });
}
s(pe, "prefixIssues");
function kt(e) {
  return typeof e == "string" ? e : e?.message;
}
s(kt, "unwrapMessage");
function ur(e, t, r) {
  var o;
  for (let n = t; n < e.length; n++)
    (o = e[n]).schema ?? (o.schema = r);
}
s(ur, "attachSchema");
function me(e, t, r) {
  var o;
  let n = e.inst?._zod?.traits;
  n?.has("$ZodType") && (n.has("$ZodCheck") ? (o = e).schema ?? (o.schema = e.inst) : e.schema = e.inst);
  let i = e.schema !== e.inst ? e.schema?._zod.def?.error : void 0, a = e.message ? e.message : kt(e.inst?._zod.def?.error?.(e)) ?? kt(i?.(e)) ?? kt(t?.error?.(e)) ?? kt(r.customError?.(e)) ?? kt(r.localeError?.(e)) ?? "Invalid input", { inst: u, schema: c, continue: l, input: d, ...f } = e;
  return f.path ?? (f.path = []), f.message = a, t?.reportInput && (f.input = d), f;
}
s(me, "finalizeIssue");
function an(e) {
  return e instanceof Set ? "set" : e instanceof Map ? "map" : e instanceof File ? "file" : "unknown";
}
s(an, "getSizableOrigin");
var Ph = /[\uD800-\uDBFF]/;
function st(e) {
  let t = e.length;
  if (!Ph.test(e))
    return t;
  let r = t;
  for (let o = 0; o < t - 1; o++)
    (e.charCodeAt(o) & 64512) === 55296 && (e.charCodeAt(o + 1) & 64512) === 56320 && (r--, o++);
  return r;
}
s(st, "codePointLength");
function sn(e) {
  return Array.isArray(e) ? "array" : typeof e == "string" ? "string" : "unknown";
}
s(sn, "getLengthableOrigin");
function b(e) {
  let t = typeof e;
  switch (t) {
    case "number":
      return Number.isNaN(e) ? "nan" : "number";
    case "object": {
      if (e === null)
        return "null";
      if (Array.isArray(e))
        return "array";
      let r = e;
      if (r && Object.getPrototypeOf(r) !== Object.prototype && "constructor" in r && r.constructor)
        return r.constructor.name;
    }
  }
  return t;
}
s(b, "parsedType");
function St(...e) {
  let [t, r, o] = e;
  return typeof t == "string" ? {
    message: t,
    code: "custom",
    input: r,
    inst: o
  } : { ...t };
}
s(St, "issue");
function Th(e) {
  return Object.entries(e).filter(([t, r]) => Number.isNaN(Number.parseInt(t, 10))).map((t) => t[1]);
}
s(Th, "cleanEnum");
function Xd(e) {
  let t = atob(e), r = new Uint8Array(t.length);
  for (let o = 0; o < t.length; o++)
    r[o] = t.charCodeAt(o);
  return r;
}
s(Xd, "base64ToUint8Array");
function Hd(e) {
  let t = "";
  for (let r = 0; r < e.length; r++)
    t += String.fromCharCode(e[r]);
  return btoa(t);
}
s(Hd, "uint8ArrayToBase64");
function Nh(e) {
  let t = e.replace(/-/g, "+").replace(/_/g, "/"), r = "=".repeat((4 - t.length % 4) % 4);
  return Xd(t + r);
}
s(Nh, "base64urlToUint8Array");
function Uh(e) {
  return Hd(e).replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, "");
}
s(Uh, "uint8ArrayToBase64url");
function Ah(e) {
  let t = e.replace(/^0x/, "");
  if (t.length % 2 !== 0)
    throw new Error("Invalid hex string length");
  let r = new Uint8Array(t.length / 2);
  for (let o = 0; o < t.length; o += 2)
    r[o / 2] = Number.parseInt(t.slice(o, o + 2), 16);
  return r;
}
s(Ah, "hexToUint8Array");
function Eh(e) {
  return Array.from(e).map((t) => t.toString(16).padStart(2, "0")).join("");
}
s(Eh, "uint8ArrayToHex");
var Qi = class {
  static {
    s(this, "Class");
  }
  constructor(...t) {
  }
};
function go(e, t) {
  for (let r in t) {
    let o = Object.getOwnPropertyDescriptor(t, r);
    o.get ? Object.defineProperty(e, r, { ...o, enumerable: !1 }) : Ch(e, r, o.value);
  }
}
s(go, "members");
function Fe(e, t, r, o = !0) {
  return Object.defineProperty(e, t, { configurable: !0, writable: !0, enumerable: o, value: r }), r;
}
s(Fe, "own");
function ho(e, t, r) {
  return Fe(e, t, r, !1);
}
s(ho, "hide");
function Ch(e, t, r) {
  Object.defineProperty(e, t, {
    configurable: !0,
    get() {
      return this == null ? r : Fe(this, t, r.bind(this));
    },
    set(o) {
      Fe(this, t, o);
    }
  });
}
s(Ch, "defineBound");
function Zh(e, t) {
  let r = Object.getPrototypeOf(e);
  return t in r ? void 0 : r;
}
s(Zh, "claim");
var Hi, Ze = !1, Fh = {
  configurable: !0,
  get() {
    Ze = !0;
  }
};
function A(e, t, r) {
  let o = Object.getPrototypeOf(e._zod);
  if (t in o && Hi !== e._zod) {
    Hi = void 0;
    return;
  }
  Hi = e._zod, Object.defineProperty(o, t, {
    configurable: !0,
    get() {
      Object.defineProperty(this, t, Fh);
      let n = Ze;
      Ze = !1;
      try {
        let i = r(this);
        return Ze ? delete this[t] : Object.defineProperty(this, t, { configurable: !0, writable: !0, value: i }), Ze = Ze || n, i;
      } catch (i) {
        throw delete this[t], Ze = Ze || n, i;
      }
    },
    set(n) {
      Object.defineProperty(this, t, { configurable: !0, writable: !0, value: n });
    }
  });
}
s(A, "defineLazyInternal");
function vo(e, t, r, o) {
  let n = Zh(e, t);
  n && Object.defineProperty(n, t, {
    configurable: !0,
    get() {
      let i = { configurable: !0, writable: !0, enumerable: o, value: void 0 };
      return Object.defineProperty(this, t, i), i.value = r(this), Object.defineProperty(this, t, i), i.value;
    },
    set(i) {
      Object.defineProperty(this, t, { configurable: !0, writable: !0, enumerable: o, value: i });
    }
  });
}
s(vo, "installLazyProp");
var cr = "~constantCatch";
function yo(e) {
  let t = /* @__PURE__ */ s(() => e, "fn");
  return t[cr] = !0, t;
}
s(yo, "constantCatch");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/core.js
var Qd, bo = /* @__PURE__ */ Object.freeze({
  status: "aborted"
}), $o = { value: void 0, enumerable: !1 }, Yd = "captureStackTrace" in Error ? Error : null;
function Mh(e) {
  let t = Yd;
  if (t) {
    let r = t.stackTraceLimit;
    if (typeof r == "number") {
      try {
        t.stackTraceLimit = 0;
      } catch {
        return Yd = null, new e();
      }
      try {
        return new e();
      } finally {
        t.stackTraceLimit = r;
      }
    }
  }
  return new e();
}
s(Mh, "newError");
// @__NO_SIDE_EFFECTS__
function g(e, t, r, o) {
  let n = {};
  function i(p) {
    this.def = p, this.constr = f, this.traits = /* @__PURE__ */ new Set();
  }
  s(i, "Internals"), i.prototype = n;
  let a = r, u = a && /* @__PURE__ */ new WeakSet();
  function c(p, h) {
    if (!p._zod) {
      $o.value = new i(h);
      try {
        Object.defineProperty(p, "_zod", $o);
      } finally {
        $o.value = void 0;
      }
    }
    if (p._zod.traits.has(e))
      return;
    if (p._zod.traits.add(e), t(p, h), u) {
      let x = Object.getPrototypeOf(p), k = p._zod.constr.prototype, R = x;
      for (; R && R !== k; )
        R = Object.getPrototypeOf(R);
      let j = R ?? x;
      u.has(j) || (u.add(j), go(j, a));
    }
    let v = f.prototype;
    for (let x in v)
      Object.prototype.hasOwnProperty.call(v, x) && (x in p || (p[x] = v[x].bind(p)));
  }
  s(c, "init");
  let l = o?.Parent ?? Object;
  class d extends l {
    static {
      s(this, "Definition");
    }
  }
  Object.defineProperty(d, "name", { value: e });
  function f(p) {
    let h = o?.Parent ? Mh(d) : this;
    c(h, p);
    let v = h._zod.deferred;
    if (v) {
      for (let k of v)
        k();
      h._zod.deferred = void 0;
    }
    let x = globalThis.__zod_globalConfig?.postProcessor;
    return x && x(h), h;
  }
  return s(f, "_"), Object.defineProperty(f, "init", { value: c }), Object.defineProperty(f, Symbol.hasInstance, {
    value: /* @__PURE__ */ s((p) => o?.Parent && p instanceof o.Parent ? !0 : p?._zod?.traits?.has(e), "value")
  }), Object.defineProperty(f, "name", { value: e }), f;
}
s(g, "$constructor");
var _o = /* @__PURE__ */ Symbol("zod_brand"), ge = class extends Error {
  static {
    s(this, "$ZodAsyncError");
  }
  constructor() {
    super("Encountered Promise during synchronous parse. Use .parseAsync() instead.");
  }
}, jt = class extends Error {
  static {
    s(this, "$ZodEncodeError");
  }
  constructor(t) {
    super(`Encountered unidirectional transform during encode: ${t}`), this.name = "ZodEncodeError";
  }
};
(Qd = globalThis).__zod_globalConfig ?? (Qd.__zod_globalConfig = {});
var ae = globalThis.__zod_globalConfig;
function ie(e) {
  return e && Object.assign(ae, e), ae;
}
s(ie, "config");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/errors.js
function Rh() {
  let e = this._zod;
  return e.message ?? (e.message = JSON.stringify(e.def, Yi, 2)), e.message;
}
s(Rh, "_getMessage");
function Lh(e) {
  this._zod.message = e;
}
s(Lh, "_setMessage");
var Vh = {
  get: Rh,
  set: Lh,
  enumerable: !0,
  configurable: !0
}, wo = { value: void 0, enumerable: !1 }, Io = { value: void 0, enumerable: !1 }, ef = /* @__PURE__ */ new WeakSet([Object.prototype, Error.prototype]), tf = /* @__PURE__ */ s((e, t) => {
  e.name = "$ZodError", wo.value = e._zod, Object.defineProperty(e, "_zod", wo), Io.value = t, Object.defineProperty(e, "issues", Io), wo.value = void 0, Io.value = void 0, Object.defineProperty(e, "message", Vh);
  let r = Object.getPrototypeOf(e);
  ef.has(r) || (ef.add(r), Object.defineProperty(r, "toString", {
    configurable: !0,
    enumerable: !1,
    get() {
      let o = /* @__PURE__ */ s(() => this.message, "value");
      return Object.defineProperty(this, "toString", { value: o, configurable: !0, writable: !0 }), o;
    },
    set(o) {
      Object.defineProperty(this, "toString", { value: o, configurable: !0, writable: !0 });
    }
  }));
}, "initializer"), Ae = g("$ZodError", tf), he = g("$ZodError", tf, void 0, {
  Parent: Error
});
function Bh(e, t, r) {
  return Object.prototype.hasOwnProperty.call(e, t) || (t === "__proto__" ? Object.defineProperty(e, t, { value: r(), writable: !0, enumerable: !0, configurable: !0 }) : e[t] = r()), e[t];
}
s(Bh, "node");
function ko(e, t = (r) => r.message) {
  let r = {}, o = [];
  for (let n of e.issues)
    n.path.length > 0 ? Bh(r, n.path[0], () => []).push(t(n)) : o.push(t(n));
  return { formErrors: o, fieldErrors: r };
}
s(ko, "flattenError");
function zo(e, t = (r) => r.message) {
  let r = { _errors: [] }, o = /* @__PURE__ */ s((n, i = []) => {
    for (let a of n.issues)
      if (a.code === "invalid_union" && a.errors.length)
        a.errors.map((u) => o({ issues: u }, [...i, ...a.path]));
      else if (a.code === "invalid_key")
        o({ issues: a.issues }, [...i, ...a.path]);
      else if (a.code === "invalid_element")
        o({ issues: a.issues }, [...i, ...a.path]);
      else {
        let u = [...i, ...a.path];
        if (u.length === 0)
          r._errors.push(t(a));
        else {
          let c = r, l = 0;
          for (; l < u.length; ) {
            let d = u[l], f = l === u.length - 1;
            if (d === "_errors") {
              f && c._errors.push(t(a)), l++;
              continue;
            }
            Object.prototype.hasOwnProperty.call(c, d) || Object.defineProperty(c, d, {
              value: { _errors: [] },
              enumerable: !0,
              writable: !0,
              configurable: !0
            });
            let p = c[d];
            f && p._errors.push(t(a)), c = p, l++;
          }
        }
      }
  }, "processError");
  return o(e), r;
}
s(zo, "formatError");
function So(e, t = (r) => r.message) {
  let r = { errors: [] }, o = /* @__PURE__ */ s((n, i = []) => {
    var a;
    for (let u of n.issues)
      if (u.code === "invalid_union" && u.errors.length)
        u.errors.map((c) => o({ issues: c }, [...i, ...u.path]));
      else if (u.code === "invalid_key")
        o({ issues: u.issues }, [...i, ...u.path]);
      else if (u.code === "invalid_element")
        o({ issues: u.issues }, [...i, ...u.path]);
      else {
        let c = [...i, ...u.path];
        if (c.length === 0) {
          r.errors.push(t(u));
          continue;
        }
        let l = r, d = 0;
        for (; d < c.length; ) {
          let f = c[d], p = d === c.length - 1;
          typeof f == "string" ? (l.properties ?? (l.properties = {}), Object.prototype.hasOwnProperty.call(l.properties, f) || Object.defineProperty(l.properties, f, {
            value: { errors: [] },
            enumerable: !0,
            writable: !0,
            configurable: !0
          }), l = l.properties[f]) : (l.items ?? (l.items = []), (a = l.items)[f] ?? (a[f] = { errors: [] }), l = l.items[f]), p && l.errors.push(t(u)), d++;
        }
      }
  }, "processError");
  return o(e), r;
}
s(So, "treeifyError");
function nf(e) {
  let t = [], r = e.map((o) => typeof o == "object" ? o.key : o);
  for (let o of r)
    typeof o == "number" ? t.push(`[${o}]`) : typeof o == "symbol" ? t.push(`[${JSON.stringify(String(o))}]`) : /[^\w$]/.test(o) ? t.push(`[${JSON.stringify(o)}]`) : (t.length && t.push("."), t.push(o));
  return t.join("");
}
s(nf, "toDotPath");
function jo(e) {
  let t = [], r = [...e.issues].sort((o, n) => (o.path ?? []).length - (n.path ?? []).length);
  for (let o of r)
    t.push(`\u2716 ${o.message}`), o.path?.length && t.push(`  \u2192 at ${nf(o.path)}`);
  return t.join(`
`);
}
s(jo, "prettifyError");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/parse.js
function lr(e, t) {
  return { callee: t?.callee ?? e, Err: t?.Err };
}
s(lr, "finalizeParams");
var dr = /* @__PURE__ */ s((e) => {
  let t = /* @__PURE__ */ s((r, o, n, i) => {
    let a = n ? { ...n, async: !1 } : { async: !1 }, u = r._zod.run({ value: o, issues: [] }, a);
    if (u instanceof Promise)
      throw new ge();
    if (u.issues.length) {
      let c = new (i?.Err ?? e)(u.issues.map((l) => me(l, a, ie())));
      throw ar(c, i?.callee ?? t), c;
    }
    return u.value;
  }, "fn");
  return t;
}, "_parse"), ve = /* @__PURE__ */ dr(he), fr = /* @__PURE__ */ s((e) => {
  let t = /* @__PURE__ */ s(async (r, o, n, i) => {
    let a = n ? { ...n, async: !0 } : { async: !0 }, u = r._zod.run({ value: o, issues: [] }, a);
    if (u instanceof Promise && (u = await u), u.issues.length) {
      let c = new (i?.Err ?? e)(u.issues.map((l) => me(l, a, ie())));
      throw ar(c, i?.callee ?? t), c;
    }
    return u.value;
  }, "fn");
  return t;
}, "_parseAsync"), Le = /* @__PURE__ */ fr(he), pr = /* @__PURE__ */ s((e) => (t, r, o) => {
  let n = o ? { ...o, async: !1 } : { async: !1 }, i = t._zod.run({ value: r, issues: [] }, n);
  if (i instanceof Promise)
    throw new ge();
  return i.issues.length ? {
    success: !1,
    error: new (e ?? Ae)(i.issues.map((a) => me(a, n, ie())))
  } : { success: !0, data: i.value };
}, "_safeParse"), Se = /* @__PURE__ */ pr(he), mr = /* @__PURE__ */ s((e) => async (t, r, o) => {
  let n = o ? { ...o, async: !0 } : { async: !0 }, i = t._zod.run({ value: r, issues: [] }, n);
  return i instanceof Promise && (i = await i), i.issues.length ? {
    success: !1,
    error: new e(i.issues.map((a) => me(a, n, ie())))
  } : { success: !0, data: i.value };
}, "_safeParseAsync"), ut = /* @__PURE__ */ mr(he), qh = /* @__PURE__ */ Symbol.for("zod.compile.invalid"), Wh = /* @__PURE__ */ Symbol.for("zod.compile.fallback"), Oo = /* @__PURE__ */ s(((e, t, r) => {
  let o = e._zod.bag.validator;
  return o !== void 0 && o(t) !== qh ? !0 : Kh(e, t, r);
}), "validate");
function Kh(e, t, r) {
  let o = r ? { ...r, async: !1 } : { async: !1 }, n = e._zod.bag.fallbackRun, i;
  if (n ? (o[Wh] = !0, i = n({ value: t, issues: [] }, o)) : i = e._zod.run({ value: t, issues: [] }, o), i instanceof Promise)
    throw new ge();
  return i.issues.length === 0;
}
s(Kh, "validateFallback");
var Do = /* @__PURE__ */ s(async (e, t, r) => {
  let o = r ? { ...r, async: !0 } : { async: !0 }, n = e._zod.run({ value: t, issues: [] }, o);
  return n instanceof Promise && (n = await n), n.issues.length === 0;
}, "validateAsync"), rf = /* @__PURE__ */ s((e) => {
  let t = dr(e), r = /* @__PURE__ */ s((o, n, i, a) => {
    let u = i ? { ...i, direction: "backward" } : { direction: "backward" };
    return t(o, n, u, lr(r, a));
  }, "fn");
  return r;
}, "_encode"), se = /* @__PURE__ */ rf(he), of = /* @__PURE__ */ s((e) => {
  let t = dr(e), r = /* @__PURE__ */ s((o, n, i, a) => t(o, n, i, lr(r, a)), "fn");
  return r;
}, "_decode"), Po = /* @__PURE__ */ of(he), af = /* @__PURE__ */ s((e) => {
  let t = fr(e), r = /* @__PURE__ */ s(async (o, n, i, a) => {
    let u = i ? { ...i, direction: "backward" } : { direction: "backward" };
    return await t(o, n, u, lr(r, a));
  }, "fn");
  return r;
}, "_encodeAsync"), To = /* @__PURE__ */ af(he), sf = /* @__PURE__ */ s((e) => {
  let t = fr(e), r = /* @__PURE__ */ s(async (o, n, i, a) => await t(o, n, i, lr(r, a)), "fn");
  return r;
}, "_decodeAsync"), No = /* @__PURE__ */ sf(he), uf = /* @__PURE__ */ s((e) => (t, r, o) => {
  let n = o ? { ...o, direction: "backward" } : { direction: "backward" };
  return pr(e)(t, r, n);
}, "_safeEncode"), Uo = /* @__PURE__ */ uf(he), cf = /* @__PURE__ */ s((e) => (t, r, o) => pr(e)(t, r, o), "_safeDecode"), Ao = /* @__PURE__ */ cf(he), lf = /* @__PURE__ */ s((e) => async (t, r, o) => {
  let n = o ? { ...o, direction: "backward" } : { direction: "backward" };
  return mr(e)(t, r, n);
}, "_safeEncodeAsync"), Eo = /* @__PURE__ */ lf(he), df = /* @__PURE__ */ s((e) => async (t, r, o) => mr(e)(t, r, o), "_safeDecodeAsync"), Co = /* @__PURE__ */ df(he);

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/regexes.js
var ue = {};
et(ue, {
  base64: () => ta,
  base64url: () => gr,
  bigint: () => ua,
  boolean: () => ca,
  browserEmail: () => nv,
  cidrv4: () => Yo,
  cidrv6: () => ea,
  creditCard: () => hr,
  cuid: () => Fo,
  cuid2: () => Mo,
  date: () => ia,
  datetime: () => aa,
  domain: () => ov,
  duration: () => qo,
  e164: () => ra,
  email: () => Ko,
  emoji: () => Go,
  extendedDuration: () => Gh,
  guid: () => Wo,
  hex: () => sv,
  hostname: () => iv,
  html5Email: () => Yh,
  httpProtocol: () => na,
  idnEmail: () => tv,
  integer: () => un,
  ipv4: () => Xo,
  ipv6: () => Ho,
  ksuid: () => Vo,
  lowercase: () => fa,
  mac: () => Qo,
  md5_base64: () => cv,
  md5_base64url: () => lv,
  md5_hex: () => uv,
  nanoid: () => Bo,
  nanoidOfLength: () => Jo,
  null: () => la,
  number: () => Ve,
  rfc5322Email: () => ev,
  sha1_base64: () => fv,
  sha1_base64url: () => pv,
  sha1_hex: () => dv,
  sha256_base64: () => gv,
  sha256_base64url: () => hv,
  sha256_hex: () => mv,
  sha384_base64: () => yv,
  sha384_base64url: () => $v,
  sha384_hex: () => vv,
  sha512_base64: () => _v,
  sha512_base64url: () => xv,
  sha512_hex: () => bv,
  string: () => sa,
  time: () => oa,
  ulid: () => Ro,
  undefined: () => da,
  unicodeEmail: () => ff,
  uppercase: () => pa,
  uuid: () => ct,
  uuid4: () => Xh,
  uuid6: () => Hh,
  uuid7: () => Qh,
  xid: () => Lo
});
var Fo = /^[cC][0-9a-z]{6,}$/, Mo = /^[0-9a-z]+$/, Ro = /^[0-7][0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{25}$/, Lo = /^[0-9a-vA-V]{20}$/, Vo = /^[A-Za-z0-9]{27}$/, Bo = /^[a-zA-Z0-9_-]{21}$/;
function Jo(e) {
  return new RegExp(`^[a-zA-Z0-9_-]{${e}}$`);
}
s(Jo, "nanoidOfLength");
var qo = /^P(?:(\d+W)|(?!.*W)(?=\d|T\d)(\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+([.,]\d+)?S)?)?)$/, Gh = /^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/, Wo = /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/, ct = /* @__PURE__ */ s((e) => e ? new RegExp(`^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${e}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`) : /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/, "uuid"), Xh = /* @__PURE__ */ ct(4), Hh = /* @__PURE__ */ ct(6), Qh = /* @__PURE__ */ ct(7), Ko = /^(?!\.)(?!.*\.\.)([A-Za-z0-9_'+\-\.]*)[A-Za-z0-9_+-]@([A-Za-z0-9][A-Za-z0-9\-]*\.)+[A-Za-z]{2,}$/, Yh = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/, ev = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/, ff = /^[^\s@"]{1,64}@[^\s@]{1,255}$/u, tv = ff, nv = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/, rv = "^[\\p{Extended_Pictographic}\\p{Emoji_Component}]+$";
function Go() {
  return new RegExp(rv, "u");
}
s(Go, "emoji");
var Xo = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/, Ho = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))$/, Qo = /* @__PURE__ */ s((e) => {
  let t = we(e ?? ":");
  return new RegExp(`^(?:[0-9A-F]{2}${t}){5}[0-9A-F]{2}$|^(?:[0-9a-f]{2}${t}){5}[0-9a-f]{2}$`);
}, "mac"), Yo = /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/([0-9]|[1-2][0-9]|3[0-2])$/, ea = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/, ta = /^$|^(?:[0-9a-zA-Z+/]{4})*(?:(?:[0-9a-zA-Z+/]{2}==)|(?:[0-9a-zA-Z+/]{3}=))?$/, gr = /^[A-Za-z0-9_-]*$/, iv = /^(?=.{1,253}\.?$)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[-0-9a-zA-Z]{0,61}[0-9a-zA-Z])?)*\.?$/, ov = /^(?=.{1,253}$)([a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,63}$/, na = /^https?$/, ra = /^\+[1-9]\d{6,14}$/, hr = /^\d(?:[ -]?\d){11,18}$/, pf = "(?:(?:\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-(?:(?:0[13578]|1[02])-(?:0[1-9]|[12]\\d|3[01])|(?:0[469]|11)-(?:0[1-9]|[12]\\d|30)|(?:02)-(?:0[1-9]|1\\d|2[0-8])))";
function av(e) {
  return new RegExp(`^${e}$`);
}
s(av, "anchor");
var ia = /* @__PURE__ */ av(pf);
function Zo(e) {
  let t = "(?:[01]\\d|2[0-3]):[0-5]\\d";
  return typeof e.precision == "number" ? e.precision === -1 ? `${t}` : e.precision === 0 ? `${t}:[0-5]\\d` : `${t}:[0-5]\\d\\.\\d{${e.precision}}` : e.seconds ? `${t}:[0-5]\\d(?:\\.\\d+)?` : `${t}(?::[0-5]\\d(?:\\.\\d+)?)?`;
}
s(Zo, "timeSource");
function oa(e) {
  return new RegExp(`^${Zo(e)}$`);
}
s(oa, "time");
function aa(e) {
  let t = ["Z"];
  e.offset && t.push("([+-](?:[01]\\d|2[0-3]):[0-5]\\d)");
  let r = `${Zo({ precision: e.precision, seconds: !0 })}(?:${t.join("|")})`, o = e.local ? `${r}|${Zo({ precision: e.precision })}` : r;
  return new RegExp(`^${pf}T(?:${o})$`);
}
s(aa, "datetime");
var sa = /* @__PURE__ */ s((e) => {
  let t = e ? `[\\s\\S]{${e?.minimum ?? 0},${e?.maximum ?? ""}}` : "[\\s\\S]*";
  return new RegExp(`^${t}$`);
}, "string"), ua = /^-?\d+n?$/, un = /^-?\d+$/, Ve = /^-?\d+(?:\.\d+)?$/, ca = /^(?:true|false)$/i, la = /^null$/i;
var da = /^undefined$/i;
var fa = /^[^A-Z]*$/, pa = /^[^a-z]*$/, sv = /^[0-9a-fA-F]*$/;
function cn(e, t) {
  return new RegExp(`^[A-Za-z0-9+/]{${e}}${t}$`);
}
s(cn, "fixedBase64");
function ln(e) {
  return new RegExp(`^[A-Za-z0-9_-]{${e}}$`);
}
s(ln, "fixedBase64url");
var uv = /^[0-9a-fA-F]{32}$/, cv = /* @__PURE__ */ cn(22, "=="), lv = /* @__PURE__ */ ln(22), dv = /^[0-9a-fA-F]{40}$/, fv = /* @__PURE__ */ cn(27, "="), pv = /* @__PURE__ */ ln(27), mv = /^[0-9a-fA-F]{64}$/, gv = /* @__PURE__ */ cn(43, "="), hv = /* @__PURE__ */ ln(43), vv = /^[0-9a-fA-F]{96}$/, yv = /* @__PURE__ */ cn(64, ""), $v = /* @__PURE__ */ ln(64), bv = /^[0-9a-fA-F]{128}$/, _v = /* @__PURE__ */ cn(86, "=="), xv = /* @__PURE__ */ ln(86);

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/checks.js
var W = /* @__PURE__ */ g("$ZodCheck", (e, t) => {
  var r;
  e._zod ?? (e._zod = {}), e._zod.def = t, (r = e._zod).onattach ?? (r.onattach = []);
}), ma = /* @__PURE__ */ s((e) => {
  let t = e.value;
  return !or(t) && t.size !== void 0;
}, "_whenHasSize"), ga = /* @__PURE__ */ s((e) => {
  let t = e.value;
  return !or(t) && t.length !== void 0;
}, "_whenHasLength"), vr = {
  number: "number",
  bigint: "bigint",
  object: "date"
}, yr = /* @__PURE__ */ g("$ZodCheckLessThan", (e, t) => {
  W.init(e, t);
  let r = vr[typeof t.value];
  e._zod.onattach.push((o) => {
    let n = o._zod.bag, i = (t.inclusive ? n.maximum : n.exclusiveMaximum) ?? Number.POSITIVE_INFINITY;
    t.value < i && (t.inclusive ? n.maximum = t.value : n.exclusiveMaximum = t.value);
  }), e._zod.check = (o) => {
    (t.inclusive ? o.value <= t.value : o.value < t.value) || o.issues.push({
      origin: vr[typeof o.value] ?? r,
      code: "too_big",
      maximum: typeof t.value == "object" ? t.value.getTime() : t.value,
      input: o.value,
      inclusive: t.inclusive,
      inst: e,
      continue: !t.abort
    });
  };
}), $r = /* @__PURE__ */ g("$ZodCheckGreaterThan", (e, t) => {
  W.init(e, t);
  let r = vr[typeof t.value];
  e._zod.onattach.push((o) => {
    let n = o._zod.bag, i = (t.inclusive ? n.minimum : n.exclusiveMinimum) ?? Number.NEGATIVE_INFINITY;
    t.value > i && (t.inclusive ? n.minimum = t.value : n.exclusiveMinimum = t.value);
  }), e._zod.check = (o) => {
    (t.inclusive ? o.value >= t.value : o.value > t.value) || o.issues.push({
      origin: vr[typeof o.value] ?? r,
      code: "too_small",
      minimum: typeof t.value == "object" ? t.value.getTime() : t.value,
      input: o.value,
      inclusive: t.inclusive,
      inst: e,
      continue: !t.abort
    });
  };
}), ha = /* @__PURE__ */ g("$ZodCheckMultipleOf", (e, t) => {
  W.init(e, t), e._zod.onattach.push((r) => {
    var o;
    (o = r._zod.bag).multipleOf ?? (o.multipleOf = t.value);
  }), e._zod.check = (r) => {
    if (typeof r.value != typeof t.value)
      throw new Error("Cannot mix number and bigint in multiple_of check.");
    (typeof r.value == "bigint" ? (
      // `value % 0n` throws, and nothing is a multiple of zero — the number branch already fails this way via NaN
      t.value !== BigInt(0) && r.value % t.value === BigInt(0)
    ) : rn(r.value, t.value) === 0) || r.issues.push({
      origin: typeof r.value,
      code: "not_multiple_of",
      divisor: t.value,
      input: r.value,
      inst: e,
      continue: !t.abort
    });
  };
}), va = /* @__PURE__ */ g("$ZodCheckNumberFormat", (e, t) => {
  W.init(e, t), t.format = t.format || "float64";
  let r = t.format?.includes("int"), o = r ? "int" : "number", [n, i] = oo[t.format];
  e._zod.onattach.push((a) => {
    let u = a._zod.bag;
    u.format = t.format, u.minimum = n, u.maximum = i, r && (u.pattern = un);
  }), e._zod.check = (a) => {
    let u = a.value;
    if (r) {
      if (!Number.isInteger(u)) {
        a.issues.push({
          expected: o,
          format: t.format,
          code: "invalid_type",
          continue: !1,
          input: u,
          inst: e
        });
        return;
      }
      if (!Number.isSafeInteger(u)) {
        u > 0 ? a.issues.push({
          input: u,
          code: "too_big",
          maximum: Number.MAX_SAFE_INTEGER,
          note: "Integers must be within the safe integer range.",
          inst: e,
          origin: o,
          inclusive: !0,
          continue: !t.abort
        }) : a.issues.push({
          input: u,
          code: "too_small",
          minimum: Number.MIN_SAFE_INTEGER,
          note: "Integers must be within the safe integer range.",
          inst: e,
          origin: o,
          inclusive: !0,
          continue: !t.abort
        });
        return;
      }
    }
    u < n && a.issues.push({
      origin: "number",
      input: u,
      code: "too_small",
      minimum: n,
      inclusive: !0,
      inst: e,
      continue: !t.abort
    }), u > i && a.issues.push({
      origin: "number",
      input: u,
      code: "too_big",
      maximum: i,
      inclusive: !0,
      inst: e,
      continue: !t.abort
    });
  };
}), ya = /* @__PURE__ */ g("$ZodCheckBigIntFormat", (e, t) => {
  W.init(e, t);
  let [r, o] = ao[t.format];
  e._zod.onattach.push((n) => {
    let i = n._zod.bag;
    i.format = t.format, i.minimum = r, i.maximum = o;
  }), e._zod.check = (n) => {
    let i = n.value;
    i < r && n.issues.push({
      origin: "bigint",
      input: i,
      code: "too_small",
      minimum: r,
      inclusive: !0,
      inst: e,
      continue: !t.abort
    }), i > o && n.issues.push({
      origin: "bigint",
      input: i,
      code: "too_big",
      maximum: o,
      inclusive: !0,
      inst: e,
      continue: !t.abort
    });
  };
}), $a = /* @__PURE__ */ g("$ZodCheckMaxSize", (e, t) => {
  var r;
  W.init(e, t), (r = e._zod.def).when ?? (r.when = ma), e._zod.onattach.push((o) => {
    let n = o._zod.bag.maximum ?? Number.POSITIVE_INFINITY;
    t.maximum < n && (o._zod.bag.maximum = t.maximum);
  }), e._zod.check = (o) => {
    let n = o.value;
    n.size <= t.maximum || o.issues.push({
      origin: an(n),
      code: "too_big",
      maximum: t.maximum,
      inclusive: !0,
      input: n,
      inst: e,
      continue: !t.abort
    });
  };
}), ba = /* @__PURE__ */ g("$ZodCheckMinSize", (e, t) => {
  var r;
  W.init(e, t), (r = e._zod.def).when ?? (r.when = ma), e._zod.onattach.push((o) => {
    let n = o._zod.bag.minimum ?? Number.NEGATIVE_INFINITY;
    t.minimum > n && (o._zod.bag.minimum = t.minimum);
  }), e._zod.check = (o) => {
    let n = o.value;
    n.size >= t.minimum || o.issues.push({
      origin: an(n),
      code: "too_small",
      minimum: t.minimum,
      inclusive: !0,
      input: n,
      inst: e,
      continue: !t.abort
    });
  };
}), _a = /* @__PURE__ */ g("$ZodCheckSizeEquals", (e, t) => {
  var r;
  W.init(e, t), (r = e._zod.def).when ?? (r.when = ma), e._zod.onattach.push((o) => {
    let n = o._zod.bag;
    n.minimum = t.size, n.maximum = t.size, n.size = t.size;
  }), e._zod.check = (o) => {
    let n = o.value, i = n.size;
    if (i === t.size)
      return;
    let a = i > t.size;
    o.issues.push({
      origin: an(n),
      ...a ? { code: "too_big", maximum: t.size } : { code: "too_small", minimum: t.size },
      inclusive: !0,
      exact: !0,
      input: o.value,
      inst: e,
      continue: !t.abort
    });
  };
}), xa = /* @__PURE__ */ g("$ZodCheckMaxLength", (e, t) => {
  var r;
  W.init(e, t), (r = e._zod.def).when ?? (r.when = ga), e._zod.onattach.push((o) => {
    let n = o._zod.bag.maximum ?? Number.POSITIVE_INFINITY;
    t.maximum < n && (o._zod.bag.maximum = t.maximum);
  }), e._zod.check = (o) => {
    let n = o.value, i = n.length;
    if ((typeof n == "string" && i > t.maximum ? st(n) : i) <= t.maximum)
      return;
    let u = sn(n);
    o.issues.push({
      origin: u,
      code: "too_big",
      maximum: t.maximum,
      inclusive: !0,
      input: n,
      inst: e,
      continue: !t.abort
    });
  };
}), wa = /* @__PURE__ */ g("$ZodCheckMinLength", (e, t) => {
  var r;
  W.init(e, t), (r = e._zod.def).when ?? (r.when = ga), e._zod.onattach.push((o) => {
    let n = o._zod.bag.minimum ?? Number.NEGATIVE_INFINITY;
    t.minimum > n && (o._zod.bag.minimum = t.minimum);
  }), e._zod.check = (o) => {
    let n = o.value, i = n.length;
    if ((typeof n == "string" && i >= t.minimum && i < t.minimum * 2 ? st(n) : i) >= t.minimum)
      return;
    let u = sn(n);
    o.issues.push({
      origin: u,
      code: "too_small",
      minimum: t.minimum,
      inclusive: !0,
      input: n,
      inst: e,
      continue: !t.abort
    });
  };
}), Ia = /* @__PURE__ */ g("$ZodCheckLengthEquals", (e, t) => {
  var r;
  W.init(e, t), (r = e._zod.def).when ?? (r.when = ga), e._zod.onattach.push((o) => {
    let n = o._zod.bag;
    n.minimum = t.length, n.maximum = t.length, n.length = t.length;
  }), e._zod.check = (o) => {
    let n = o.value, i = n.length, a = typeof n == "string" && i >= t.length && i <= t.length * 2 ? st(n) : i;
    if (a === t.length)
      return;
    let u = sn(n), c = a > t.length;
    o.issues.push({
      origin: u,
      ...c ? { code: "too_big", maximum: t.length } : { code: "too_small", minimum: t.length },
      inclusive: !0,
      exact: !0,
      input: o.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Ot = /* @__PURE__ */ g("$ZodCheckStringFormat", (e, t) => {
  var r, o;
  W.init(e, t), e._zod.onattach.push((n) => {
    let i = n._zod.bag;
    i.format = t.format, t.pattern && (i.patterns ?? (i.patterns = /* @__PURE__ */ new Set()), i.patterns.add(t.pattern));
  }), t.pattern ? (r = e._zod).check ?? (r.check = (n) => {
    t.pattern.lastIndex = 0, !t.pattern.test(n.value) && n.issues.push({
      origin: "string",
      code: "invalid_format",
      format: t.format,
      input: n.value,
      ...t.pattern ? { pattern: t.pattern.toString() } : {},
      inst: e,
      continue: !t.abort
    });
  }) : (o = e._zod).check ?? (o.check = () => {
  });
}), ka = /* @__PURE__ */ g("$ZodCheckRegex", (e, t) => {
  Ot.init(e, t), e._zod.check = (r) => {
    t.pattern.lastIndex = 0, !t.pattern.test(r.value) && r.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "regex",
      input: r.value,
      pattern: t.pattern.toString(),
      inst: e,
      continue: !t.abort
    });
  };
}), za = /* @__PURE__ */ g("$ZodCheckLowerCase", (e, t) => {
  t.pattern ?? (t.pattern = fa), Ot.init(e, t);
}), Sa = /* @__PURE__ */ g("$ZodCheckUpperCase", (e, t) => {
  t.pattern ?? (t.pattern = pa), Ot.init(e, t);
}), ja = /* @__PURE__ */ g("$ZodCheckIncludes", (e, t) => {
  W.init(e, t);
  let r = we(t.includes), o = new RegExp(typeof t.position == "number" ? `^.{${t.position},}${r}` : r);
  t.pattern = o, e._zod.onattach.push((n) => {
    let i = n._zod.bag;
    i.patterns ?? (i.patterns = /* @__PURE__ */ new Set()), i.patterns.add(o);
  }), e._zod.check = (n) => {
    n.value.includes(t.includes, t.position) || n.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "includes",
      includes: t.includes,
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Oa = /* @__PURE__ */ g("$ZodCheckStartsWith", (e, t) => {
  W.init(e, t);
  let r = new RegExp(`^${we(t.prefix)}.*`);
  t.pattern ?? (t.pattern = r), e._zod.onattach.push((o) => {
    let n = o._zod.bag;
    n.patterns ?? (n.patterns = /* @__PURE__ */ new Set()), n.patterns.add(r);
  }), e._zod.check = (o) => {
    o.value.startsWith(t.prefix) || o.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "starts_with",
      prefix: t.prefix,
      input: o.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Da = /* @__PURE__ */ g("$ZodCheckEndsWith", (e, t) => {
  W.init(e, t);
  let r = new RegExp(`.*${we(t.suffix)}$`);
  t.pattern ?? (t.pattern = r), e._zod.onattach.push((o) => {
    let n = o._zod.bag;
    n.patterns ?? (n.patterns = /* @__PURE__ */ new Set()), n.patterns.add(r);
  }), e._zod.check = (o) => {
    o.value.endsWith(t.suffix) || o.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "ends_with",
      suffix: t.suffix,
      input: o.value,
      inst: e,
      continue: !t.abort
    });
  };
});
function mf(e, t, r) {
  e.issues.length && t.issues.push(...pe(r, e.issues));
}
s(mf, "handleCheckPropertyResult");
var br = /* @__PURE__ */ g("$ZodCheckProperty", (e, t) => {
  W.init(e, t), e._zod.check = (r) => {
    let o = t.schema._zod.run({
      value: r.value[t.property],
      issues: []
    }, {});
    if (o instanceof Promise)
      return o.then((n) => mf(n, r, t.property));
    mf(o, r, t.property);
  };
}), Pa = /* @__PURE__ */ g("$ZodCheckMimeType", (e, t) => {
  W.init(e, t);
  let r = new Set(t.mime);
  e._zod.onattach.push((o) => {
    o._zod.bag.mime = t.mime;
  }), e._zod.check = (o) => {
    r.has(o.value.type) || o.issues.push({
      code: "invalid_value",
      values: t.mime,
      input: o.value.type,
      inst: e,
      continue: !t.abort
    });
  };
}), Ta = /* @__PURE__ */ g("$ZodCheckOverwrite", (e, t) => {
  W.init(e, t), e._zod.check = (r) => {
    r.value = t.tx(r.value);
  };
});

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/doc.js
var lt = class {
  static {
    s(this, "Doc");
  }
  constructor(t = [], r = {}) {
    this.content = [], this.indent = 0, this.args = t, this.closed = r;
  }
  indented(t) {
    this.indent += 1, t(this), this.indent -= 1;
  }
  write(t) {
    if (typeof t == "function") {
      t(this, { execution: "sync" }), t(this, { execution: "async" });
      return;
    }
    let o = t.split(`
`).filter((a) => a), n = Math.min(...o.map((a) => a.length - a.trimStart().length)), i = o.map((a) => a.slice(n)).map((a) => " ".repeat(this.indent * 2) + a);
    for (let a of i)
      this.content.push(a);
  }
  compile() {
    let t = Function, r = this?.content ?? [""];
    return new t(...Object.keys(this.closed), `return function (${this.args.join(", ")}) {
${r.join(`
`)}
};`)(...Object.values(this.closed));
  }
};

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/versions.js
var Na = {
  major: 4,
  minor: 5,
  patch: 4
};

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/schemas.js
var S = /* @__PURE__ */ g("$ZodType", (e, t) => {
  var r;
  e ?? (e = {}), e._zod.def = t, e._zod.bag = e._zod.bag || {}, e._zod.version = Na;
  let o = e._zod.def.checks, n = e._zod.traits.has("$ZodCheck") ? [e, ...o ?? []] : o?.length ? [...o] : [];
  for (let i of n)
    for (let a of i._zod.onattach)
      a(e);
  if (n.length === 0)
    (r = e._zod).deferred ?? (r.deferred = []), e._zod.deferred?.push(() => {
      e._zod.run = e._zod.parse;
    });
  else {
    let i = /* @__PURE__ */ s((u, c, l) => {
      if (u.memo)
        return u;
      let d = Re(u), f;
      for (let p of c) {
        if (p._zod.def.when) {
          if (mo(u) || !p._zod.def.when(u))
            continue;
        } else if (d)
          continue;
        let h = u.issues.length, v = p._zod.check(u);
        if (v instanceof Promise && l?.async === !1)
          throw new ge();
        if (f || v instanceof Promise)
          f = (f ?? Promise.resolve()).then(async () => {
            await v, u.issues.length !== h && (ur(u.issues, h, e), d || (d = Re(u, h)));
          });
        else {
          if (u.issues.length === h)
            continue;
          ur(u.issues, h, e), d || (d = Re(u, h));
        }
      }
      return f ? f.then(() => u) : u;
    }, "runChecks"), a = /* @__PURE__ */ s((u, c, l) => {
      if (Re(u))
        return u.aborted = !0, u;
      let d = i(c, n, l);
      if (d instanceof Promise) {
        if (l.async === !1)
          throw new ge();
        return d.then((f) => e._zod.parse(f, l));
      }
      return e._zod.parse(d, l);
    }, "handleCanaryResult");
    e._zod.run = (u, c) => {
      if (c.skipChecks)
        return e._zod.parse(u, c);
      if (c.direction === "backward") {
        let d = e._zod.parse({ value: u.value, issues: [] }, { ...c, skipChecks: !0 });
        return d instanceof Promise ? d.then((f) => a(f, u, c)) : a(d, u, c);
      }
      let l = e._zod.parse(u, c);
      if (l instanceof Promise) {
        if (c.async === !1)
          throw new ge();
        return l.then((d) => i(d, n, c));
      }
      return i(l, n, c);
    };
  }
}, {
  // Wrappers extend this by installing a richer factory over it; reading it eagerly would defeat the laziness.
  get "~standard"() {
    return ho(this, "~standard", Tf(this));
  },
  set "~standard"(e) {
    Fe(this, "~standard", e);
  }
}), hf = /* @__PURE__ */ s((e) => e.success ? { value: e.data } : { issues: e.error?.issues }, "toStandardResult");
function Tf(e) {
  return {
    validate: /* @__PURE__ */ s((t) => {
      try {
        return hf(Se(e, t));
      } catch {
        return ut(e, t).then(hf);
      }
    }, "validate"),
    vendor: "zod",
    version: 1
  };
}
s(Tf, "standardProps");
var Pt = /* @__PURE__ */ g("$ZodString", (e, t) => {
  S.init(e, t), e._zod.pattern = [...e?._zod.bag?.patterns ?? []].pop() ?? sa(e._zod.bag), e._zod.parse = (r, o) => {
    if (t.coerce)
      try {
        r.value = String(r.value);
      } catch {
      }
    return typeof r.value == "string" || r.issues.push({
      expected: "string",
      code: "invalid_type",
      input: r.value,
      inst: e
    }), r;
  };
}), V = /* @__PURE__ */ g("$ZodStringFormat", (e, t) => {
  Ot.init(e, t), Pt.init(e, t);
}), Aa = /* @__PURE__ */ g("$ZodGUID", (e, t) => {
  t.pattern ?? (t.pattern = Wo), V.init(e, t);
}), Ea = /* @__PURE__ */ g("$ZodUUID", (e, t) => {
  if (t.version) {
    let o = {
      v1: 1,
      v2: 2,
      v3: 3,
      v4: 4,
      v5: 5,
      v6: 6,
      v7: 7,
      v8: 8
    }[t.version];
    if (o === void 0)
      throw new Error(`Invalid UUID version: "${t.version}"`);
    t.pattern ?? (t.pattern = ct(o));
  } else
    t.pattern ?? (t.pattern = ct());
  V.init(e, t);
}), Ca = /* @__PURE__ */ g("$ZodEmail", (e, t) => {
  t.pattern ?? (t.pattern = Ko), V.init(e, t);
}), Za = 1, Fa = 2;
function kr(e, t) {
  if (!t.normalize && t.protocol?.source === na.source && !/^https?:\/\//i.test(e))
    return Za;
  try {
    return new URL(e);
  } catch {
    return Fa;
  }
}
s(kr, "parseURLObject");
var wv = /[\t\n\r]/g;
function zr(e) {
  return e.replace(wv, "");
}
s(zr, "stripTabAndNewline");
function Sr(e, t) {
  return t.lastIndex = 0, t.test(e.hostname);
}
s(Sr, "urlHostnameOk");
function jr(e, t) {
  return t.lastIndex = 0, t.test(e.protocol.endsWith(":") ? e.protocol.slice(0, -1) : e.protocol);
}
s(jr, "urlProtocolOk");
var Ma = /* @__PURE__ */ g("$ZodURL", (e, t) => {
  V.init(e, t), e._zod.check = (r) => {
    try {
      let o = r.value.trim(), n = kr(o, t);
      if (n === Za) {
        r.issues.push({
          code: "invalid_format",
          format: "url",
          note: "Invalid URL format",
          input: r.value,
          inst: e,
          continue: !t.abort
        });
        return;
      }
      if (n === Fa) {
        r.issues.push({
          code: "invalid_format",
          format: "url",
          input: r.value,
          inst: e,
          continue: !t.abort
        });
        return;
      }
      t.hostname && !Sr(n, t.hostname) && r.issues.push({
        code: "invalid_format",
        format: "url",
        note: "Invalid hostname",
        pattern: t.hostname.source,
        input: r.value,
        inst: e,
        continue: !t.abort
      }), t.protocol && !jr(n, t.protocol) && r.issues.push({
        code: "invalid_format",
        format: "url",
        note: "Invalid protocol",
        pattern: t.protocol.source,
        input: r.value,
        inst: e,
        continue: !t.abort
      }), r.value = t.normalize ? n.href : zr(o);
      return;
    } catch {
      r.issues.push({
        code: "invalid_format",
        format: "url",
        input: r.value,
        inst: e,
        continue: !t.abort
      });
    }
  };
}), Ra = /* @__PURE__ */ g("$ZodEmoji", (e, t) => {
  t.pattern ?? (t.pattern = Go()), V.init(e, t);
}), La = /* @__PURE__ */ g("$ZodNanoID", (e, t) => {
  if (t.length !== void 0 && (!Number.isInteger(t.length) || t.length < 1))
    throw new Error(`Invalid nanoid length: ${t.length}`);
  t.pattern ?? (t.pattern = t.length === void 0 ? Bo : Jo(t.length)), V.init(e, t);
}), Va = /* @__PURE__ */ g("$ZodCUID", (e, t) => {
  t.pattern ?? (t.pattern = Fo), V.init(e, t);
}), Ba = /* @__PURE__ */ g("$ZodCUID2", (e, t) => {
  t.pattern ?? (t.pattern = Mo), V.init(e, t);
}), Ja = /* @__PURE__ */ g("$ZodULID", (e, t) => {
  t.pattern ?? (t.pattern = Ro), V.init(e, t);
}), qa = /* @__PURE__ */ g("$ZodXID", (e, t) => {
  t.pattern ?? (t.pattern = Lo), V.init(e, t);
}), Wa = /* @__PURE__ */ g("$ZodKSUID", (e, t) => {
  t.pattern ?? (t.pattern = Vo), V.init(e, t);
}), Ka = /* @__PURE__ */ g("$ZodISODateTime", (e, t) => {
  t.pattern ?? (t.pattern = aa(t)), V.init(e, t), (t.local || t.precision === -1) && (e._zod.bag.laxFormat = !0, e._zod.onattach.push((r) => {
    r._zod.bag.laxFormat = !0;
  }));
}), Ga = /* @__PURE__ */ g("$ZodISODate", (e, t) => {
  t.pattern ?? (t.pattern = ia), V.init(e, t);
}), Xa = /* @__PURE__ */ g("$ZodISOTime", (e, t) => {
  t.pattern ?? (t.pattern = oa(t)), V.init(e, t);
}), Ha = /* @__PURE__ */ g("$ZodISODuration", (e, t) => {
  t.pattern ?? (t.pattern = qo), V.init(e, t);
}), Qa = /* @__PURE__ */ g("$ZodIPv4", (e, t) => {
  t.pattern ?? (t.pattern = Xo), V.init(e, t), e._zod.bag.format = "ipv4";
}), Iv = /^[0-9a-fA-F:.]+$/;
function dn(e) {
  if (!Iv.test(e))
    return !1;
  try {
    return new URL(`http://[${e}]`), !0;
  } catch {
    return !1;
  }
}
s(dn, "isValidIPv6");
var Ya = /* @__PURE__ */ g("$ZodIPv6", (e, t) => {
  t.pattern ?? (t.pattern = Ho), V.init(e, t), e._zod.bag.format = "ipv6", e._zod.check = (r) => {
    dn(r.value) || r.issues.push({
      code: "invalid_format",
      format: "ipv6",
      input: r.value,
      inst: e,
      continue: !t.abort
    });
  };
}), es = /* @__PURE__ */ g("$ZodMAC", (e, t) => {
  t.pattern ?? (t.pattern = Qo(t.delimiter)), V.init(e, t), e._zod.bag.format = "mac";
}), ts = /* @__PURE__ */ g("$ZodCIDRv4", (e, t) => {
  t.pattern ?? (t.pattern = Yo), V.init(e, t);
});
function Or(e) {
  let t = e.split("/");
  if (t.length !== 2)
    return !1;
  let [r, o] = t;
  if (!o)
    return !1;
  let n = Number(o);
  return `${n}` !== o || n < 0 || n > 128 ? !1 : dn(r);
}
s(Or, "isValidCIDRv6");
var ns = /* @__PURE__ */ g("$ZodCIDRv6", (e, t) => {
  t.pattern ?? (t.pattern = ea), V.init(e, t), e._zod.check = (r) => {
    Or(r.value) || r.issues.push({
      code: "invalid_format",
      format: "cidrv6",
      input: r.value,
      inst: e,
      continue: !t.abort
    });
  };
});
function fn(e) {
  if (e === "")
    return !0;
  if (/\s/.test(e) || e.length % 4 !== 0)
    return !1;
  try {
    return atob(e), !0;
  } catch {
    return !1;
  }
}
s(fn, "isValidBase64");
var rs = /* @__PURE__ */ g("$ZodBase64", (e, t) => {
  t.pattern ?? (t.pattern = ta), V.init(e, t), e._zod.bag.contentEncoding = "base64", e._zod.check = (r) => {
    fn(r.value) || r.issues.push({
      code: "invalid_format",
      format: "base64",
      input: r.value,
      inst: e,
      continue: !t.abort
    });
  };
});
function Dr(e) {
  if (!gr.test(e))
    return !1;
  let t = e.replace(/[-_]/g, (o) => o === "-" ? "+" : "/"), r = t.padEnd(Math.ceil(t.length / 4) * 4, "=");
  return fn(r);
}
s(Dr, "isValidBase64URL");
var is = /* @__PURE__ */ g("$ZodBase64URL", (e, t) => {
  t.pattern ?? (t.pattern = gr), V.init(e, t), e._zod.bag.contentEncoding = "base64url", e._zod.check = (r) => {
    Dr(r.value) || r.issues.push({
      code: "invalid_format",
      format: "base64url",
      input: r.value,
      inst: e,
      continue: !t.abort
    });
  };
}), os = /* @__PURE__ */ g("$ZodE164", (e, t) => {
  t.pattern ?? (t.pattern = ra), V.init(e, t);
}), kv = /[- ]/g;
function zv(e) {
  let t = e.length, r = 1, o = 0;
  for (; t; ) {
    let n = +e[--t];
    r ^= 1, o += r ? [0, 2, 4, 6, 8, 1, 3, 5, 7, 9][n] : n;
  }
  return o % 10 === 0;
}
s(zv, "isLuhnAlgo");
function Pr(e) {
  return hr.test(e) ? zv(e.replace(kv, "")) : !1;
}
s(Pr, "isValidCreditCard");
var as = /* @__PURE__ */ g("$ZodCreditCard", (e, t) => {
  t.pattern ?? (t.pattern = hr), V.init(e, t), e._zod.check = (r) => {
    Pr(r.value) || r.issues.push({
      code: "invalid_format",
      format: "credit_card",
      input: r.value,
      inst: e,
      continue: !t.abort
    });
  };
});
function Tr(e, t = null) {
  try {
    let r = e.split(".");
    if (r.length !== 3)
      return !1;
    let [o] = r;
    if (!o)
      return !1;
    let n = JSON.parse(atob(o));
    return !("typ" in n && n?.typ !== "JWT" || !n.alg || t && (!("alg" in n) || n.alg !== t));
  } catch {
    return !1;
  }
}
s(Tr, "isValidJWT");
var ss = /* @__PURE__ */ g("$ZodJWT", (e, t) => {
  V.init(e, t), e._zod.check = (r) => {
    Tr(r.value, t.alg) || r.issues.push({
      code: "invalid_format",
      format: "jwt",
      input: r.value,
      inst: e,
      continue: !t.abort
    });
  };
}), us = /* @__PURE__ */ g("$ZodCustomStringFormat", (e, t) => {
  V.init(e, t), e._zod.check = (r) => {
    t.fn(r.value) || r.issues.push({
      code: "invalid_format",
      format: t.format,
      input: r.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Nr = /* @__PURE__ */ g("$ZodNumber", (e, t) => {
  S.init(e, t), e._zod.pattern = e._zod.bag.pattern ?? Ve, e._zod.parse = (r, o) => {
    if (t.coerce)
      try {
        r.value = Number(r.value);
      } catch {
      }
    let n = r.value;
    if (typeof n == "number" && !Number.isNaN(n) && Number.isFinite(n))
      return r;
    let i = typeof n == "number" ? Number.isNaN(n) ? "NaN" : Number.isFinite(n) ? void 0 : String(n) : void 0;
    return r.issues.push({
      expected: "number",
      code: "invalid_type",
      input: n,
      inst: e,
      ...i ? { received: i } : {}
    }), r;
  };
}), cs = /* @__PURE__ */ g("$ZodNumberFormat", (e, t) => {
  va.init(e, t), Nr.init(e, t);
}), pn = /* @__PURE__ */ g("$ZodBoolean", (e, t) => {
  S.init(e, t), e._zod.pattern = ca, e._zod.parse = (r, o) => {
    if (t.coerce)
      try {
        r.value = !!r.value;
      } catch {
      }
    let n = r.value;
    return typeof n == "boolean" || r.issues.push({
      expected: "boolean",
      code: "invalid_type",
      input: n,
      inst: e
    }), r;
  };
}), Ur = /* @__PURE__ */ g("$ZodBigInt", (e, t) => {
  S.init(e, t), e._zod.pattern = ua, e._zod.parse = (r, o) => {
    if (t.coerce)
      try {
        r.value = BigInt(r.value);
      } catch {
      }
    return typeof r.value == "bigint" || r.issues.push({
      expected: "bigint",
      code: "invalid_type",
      input: r.value,
      inst: e
    }), r;
  };
}), ls = /* @__PURE__ */ g("$ZodBigIntFormat", (e, t) => {
  ya.init(e, t), Ur.init(e, t);
}), ds = /* @__PURE__ */ g("$ZodSymbol", (e, t) => {
  S.init(e, t), e._zod.parse = (r, o) => {
    let n = r.value;
    return typeof n == "symbol" || r.issues.push({
      expected: "symbol",
      code: "invalid_type",
      input: n,
      inst: e
    }), r;
  };
}), fs = /* @__PURE__ */ g("$ZodUndefined", (e, t) => {
  S.init(e, t), e._zod.pattern = da, e._zod.values = /* @__PURE__ */ new Set([void 0]), e._zod.parse = (r, o) => {
    let n = r.value;
    return typeof n > "u" || r.issues.push({
      expected: "undefined",
      code: "invalid_type",
      input: n,
      inst: e
    }), r;
  };
}), ps = /* @__PURE__ */ g("$ZodNull", (e, t) => {
  S.init(e, t), e._zod.pattern = la, e._zod.values = /* @__PURE__ */ new Set([null]), e._zod.parse = (r, o) => {
    let n = r.value;
    return n === null || r.issues.push({
      expected: "null",
      code: "invalid_type",
      input: n,
      inst: e
    }), r;
  };
}), ms = /* @__PURE__ */ g("$ZodAny", (e, t) => {
  S.init(e, t), e._zod.parse = (r) => r;
}), gs = /* @__PURE__ */ g("$ZodUnknown", (e, t) => {
  S.init(e, t), e._zod.parse = (r) => r;
}), hs = /* @__PURE__ */ g("$ZodNever", (e, t) => {
  S.init(e, t), e._zod.parse = (r, o) => (r.issues.push({
    expected: "never",
    code: "invalid_type",
    input: r.value,
    inst: e
  }), r);
}), vs = /* @__PURE__ */ g("$ZodVoid", (e, t) => {
  S.init(e, t), e._zod.parse = (r, o) => {
    let n = r.value;
    return typeof n > "u" || r.issues.push({
      expected: "void",
      code: "invalid_type",
      input: n,
      inst: e
    }), r;
  };
}), Tt = /* @__PURE__ */ g("$ZodDate", (e, t) => {
  S.init(e, t), e._zod.parse = (r, o) => {
    if (t.coerce)
      try {
        r.value = new Date(r.value);
      } catch {
      }
    let n = r.value, i = n instanceof Date;
    return i && !Number.isNaN(n.getTime()) || r.issues.push({
      expected: "date",
      code: "invalid_type",
      input: n,
      ...i ? { received: "Invalid Date" } : {},
      inst: e
    }), r;
  };
});
function vf(e, t, r) {
  e.issues.length && t.issues.push(...pe(r, e.issues)), t.value[r] = e.value;
}
s(vf, "handleArrayResult");
var Be = /* @__PURE__ */ g("$ZodArray", (e, t) => {
  S.init(e, t);
  let r = ae.memoizer;
  r?.attach(e), e._zod.parse = (o, n) => {
    let i = o.value;
    if (!Array.isArray(i))
      return o.issues.push({
        expected: "array",
        code: "invalid_type",
        input: i,
        inst: e
      }), o;
    o.value = r ? r.alloc(e, o, Array(i.length), n) : Array(i.length);
    let a = [];
    for (let u = 0; u < i.length; u++) {
      let c = i[u], l = t.element._zod.run({
        value: c,
        issues: []
      }, n);
      l instanceof Promise ? a.push(l.then((d) => vf(d, o, u))) : vf(l, o, u);
    }
    return a.length ? Promise.all(a).then(() => o) : o;
  };
});
function Ir(e, t, r, o, n, i) {
  let a = r in o, u = i === "optional";
  if (!(!a && u && n === "optional")) {
    if (e.issues.length) {
      if (n !== void 0 && u && !a)
        return;
      t.issues.push(...pe(r, e.issues));
    }
    if (!a && n === void 0) {
      e.issues.length || t.issues.push({
        code: "invalid_type",
        expected: "nonoptional",
        input: void 0,
        path: [r]
      });
      return;
    }
    e.value === void 0 ? a && (t.value[r] = void 0) : t.value[r] = e.value;
  }
}
s(Ir, "handlePropertyResult");
var Sv = [];
function Nf(e) {
  let t = Object.keys(e.shape), r = Object.getOwnPropertySymbols(e.shape), o = r.length ? r : Sv, n = o.length ? [...t, ...o] : t;
  for (let a of n)
    if (!e.shape?.[a]?._zod?.traits?.has("$ZodType"))
      throw new Error(`Invalid element at key "${String(a)}": expected a Zod schema`);
  let i = io(e.shape);
  return {
    ...e,
    allKeys: n,
    symbolKeys: o,
    // string-only: handleCatchall matches it against `for...in`, which never yields a symbol
    keySet: new Set(t),
    numKeys: t.length,
    optionalKeys: new Set(i)
  };
}
s(Nf, "normalizeDef");
function Uf(e, t, r, o, n, i) {
  let a = [], u = n.keySet, c = n.catchall._zod, l = c.def.type, d = c.optin, f = c.optout;
  for (let p in t) {
    if (u.has(p))
      continue;
    if (p === "__proto__") {
      l === "never" && a.push(p);
      continue;
    }
    if (l === "never") {
      a.push(p);
      continue;
    }
    let h = c.run({ value: t[p], issues: [] }, o);
    h instanceof Promise ? e.push(h.then((v) => Ir(v, r, p, t, d, f))) : Ir(h, r, p, t, d, f);
  }
  return a.length && r.issues.push({
    code: "unrecognized_keys",
    keys: a,
    input: t,
    inst: i,
    // Describes the shape of the input, not the validity of the parsed value, so it never aborts. The parse still fails; the schema's own checks just get to run first, and an enclosing intersection can reconcile the key against a sibling operand.
    continue: !0
  }), e.length ? Promise.all(e).then(() => r) : r;
}
s(Uf, "handleCatchall");
var Ua = /* @__PURE__ */ new WeakMap(), Y = /* @__PURE__ */ g("$ZodObject", (e, t) => {
  if (S.init(e, t), !Object.getOwnPropertyDescriptor(t, "shape")?.get) {
    let c = t.shape;
    Ua.set(t, c), Object.defineProperty(t, "shape", {
      get: /* @__PURE__ */ s(() => {
        let l = { ...c };
        return Object.defineProperty(t, "shape", {
          value: l
        }), Ua.set(t, l), l;
      }, "get")
    });
  }
  let o = zt(() => Nf(t));
  A(e, "propValues", (c) => {
    let l = c.def.shape, d = {};
    for (let f in l) {
      let p = l[f]._zod;
      if (p.values) {
        Object.prototype.hasOwnProperty.call(d, f) || te(d, f, /* @__PURE__ */ new Set());
        for (let h of p.values)
          d[f].add(h);
        p.optin !== void 0 && d[f].add(void 0);
      }
    }
    return d;
  });
  let n = at, i = t.catchall, a, u = ae.memoizer;
  u?.attach(e), e._zod.parse = (c, l) => {
    a ?? (a = o.value);
    let d = c.value;
    if (!n(d))
      return c.issues.push({
        expected: "object",
        code: "invalid_type",
        input: d,
        inst: e
      }), c;
    c.value = u ? u.alloc(e, c, {}, l) : {};
    let f = [], p = a.shape;
    for (let h of a.allKeys) {
      if (h === "__proto__")
        continue;
      let v = p[h], x = v._zod.optin, k = v._zod.optout, R = v._zod.run({ value: d[h], issues: [] }, l);
      R instanceof Promise ? f.push(R.then((j) => Ir(j, c, h, d, x, k))) : Ir(R, c, h, d, x, k);
    }
    return i ? Uf(f, d, c, l, o.value, e) : f.length ? Promise.all(f).then(() => c) : c;
  };
}), jv = /* @__PURE__ */ g("$ZodObjectJIT", (e, t) => {
  Y.init(e, t);
  let r = e._zod.parse, o = zt(() => Nf(t)), n = ae.memoizer, i = /* @__PURE__ */ s((h) => {
    let v = o.value, x = v.symbolKeys, k = new lt(["payload", "ctx"], { shape: h, inst: e, memo: n, syms: x }), R = /* @__PURE__ */ s((M) => `shape[${M}]._zod.run({ value: input[${M}], issues: [] }, ctx)`, "parseStr"), j = /* @__PURE__ */ s((M, I) => `
          for (let i = 0; i < ${M}.issues.length; i++) {
            const iss = ${M}.issues[i];
            iss.path = iss.path ? [${I}, ...iss.path] : [${I}];
            payload.issues.push(iss);
          }`, "prefixStr");
    k.write("const input = payload.value;");
    let O = /* @__PURE__ */ Object.create(null), U = 0;
    for (let M of v.allKeys)
      O[M] = `key_${U++}`;
    k.write(n ? "const newResult = memo.alloc(inst, payload, {}, ctx);" : "const newResult = {};");
    for (let M of v.allKeys) {
      if (M === "__proto__")
        continue;
      let I = O[M], T = typeof M == "symbol" ? `syms[${x.indexOf(M)}]` : fe(M), q = `${T} in input`, Ue = h[M], Ye = Ue?._zod?.optin, Un = Ye !== void 0, _i = Ue?._zod?.optout === "optional";
      if (k.write(`const ${I} = ${R(T)};`), Un && _i) {
        let An = Ye === "optional" ? `${I}_present` : `${I}.value !== undefined || ${I}_present`;
        k.write(`
        const ${I}_present = ${q};
        if (!${I}.issues.length || ${I}_present) {
          if (${I}.issues.length) {${j(I, T)}
          }

          if (${An}) {
            newResult[${T}] = ${I}.value;
          }
        }

      `);
      } else Un ? k.write(`
        if (${I}.issues.length) {${j(I, T)}
        }
        
        if (${I}.value === undefined) {
          if (${q}) {
            newResult[${T}] = undefined;
          }
        } else {
          newResult[${T}] = ${I}.value;
        }

      `) : k.write(`
        const ${I}_present = ${q};
        if (${I}.issues.length) {${j(I, T)}
        }
        if (!${I}_present && !${I}.issues.length) {
          payload.issues.push({
            code: "invalid_type",
            expected: "nonoptional",
            input: undefined,
            path: [${T}]
          });
        }

        if (${I}_present) {
          newResult[${T}] = ${I}.value;
        }

      `);
    }
    return k.write("payload.value = newResult;"), k.write("return payload;"), k.compile();
  }, "generateFastpass"), a, u = at, c = !ae.jitless, d = c && no.value, f = t.catchall, p;
  e._zod.parse = (h, v) => {
    p ?? (p = o.value);
    let x = h.value;
    return u(x) ? c && d && v?.async === !1 && v.jitless !== !0 ? (a || (a = i(t.shape)), h = a(h, v), f ? Uf([], x, h, v, p, e) : h) : r(h, v) : (h.issues.push({
      expected: "object",
      code: "invalid_type",
      input: x,
      inst: e
    }), h);
  };
});
function yf(e, t, r, o) {
  for (let i of e)
    if (i.issues.length === 0)
      return t.value = i.value, t;
  let n = e.filter((i) => !Re(i));
  return n.length === 1 ? (t.value = n[0].value, n[0]) : (t.issues.push({
    code: "invalid_union",
    input: t.value,
    inst: r,
    errors: e.map((i) => i.issues.map((a) => me(a, o, ie())))
  }), t);
}
s(yf, "handleUnionResults");
var ce = /* @__PURE__ */ g("$ZodUnion", (e, t) => {
  S.init(e, t), A(e, "optin", (o) => o.def.options.some((n) => n._zod.optin === "defaulted") ? "defaulted" : o.def.options.some((n) => n._zod.optin !== void 0) ? "optional" : void 0), A(e, "optout", (o) => o.def.options.some((n) => n._zod.optout === "optional") ? "optional" : void 0), A(e, "values", (o) => {
    if (o.def.options.every((n) => n._zod.values))
      return new Set(o.def.options.flatMap((n) => Array.from(n._zod.values)));
  }), A(e, "pattern", (o) => {
    if (o.def.options.every((n) => n._zod.pattern)) {
      let n = o.def.options.map((i) => i._zod.pattern);
      return new RegExp(`^(${n.map((i) => nn(i.source)).join("|")})$`);
    }
  });
  let r = t.options.length === 1 ? t.options[0]._zod.run : null;
  e._zod.parse = (o, n) => {
    if (r)
      return r(o, n);
    let i = !1, a = [];
    for (let u of t.options) {
      let c = u._zod.run({
        value: o.value,
        issues: []
      }, n);
      if (c instanceof Promise)
        a.push(c), i = !0;
      else {
        if (c.issues.length === 0)
          return c;
        a.push(c);
      }
    }
    return i ? Promise.all(a).then((u) => yf(u, o, e, n)) : yf(a, o, e, n);
  };
});
function $f(e, t, r, o) {
  let n = [];
  for (let i = 0; i < e.length; i++)
    e[i].issues.length === 0 && n.push(i);
  return n.length === 1 ? (t.value = e[n[0]].value, t) : (n.length === 0 ? t.issues.push({
    code: "invalid_union",
    input: t.value,
    inst: r,
    errors: e.map((i) => i.issues.map((a) => me(a, o, ie())))
  }) : t.issues.push({
    code: "invalid_union",
    input: t.value,
    inst: r,
    errors: [],
    inclusive: !1,
    matches: n
  }), t);
}
s($f, "handleExclusiveUnionResults");
var ys = /* @__PURE__ */ g("$ZodXor", (e, t) => {
  ce.init(e, t), t.inclusive = !1;
  let r = t.options.length === 1 ? t.options[0]._zod.run : null;
  e._zod.parse = (o, n) => {
    if (r)
      return r(o, n);
    let i = !1, a = [];
    for (let u of t.options) {
      let c = u._zod.run({
        value: o.value,
        issues: []
      }, n);
      c instanceof Promise ? (a.push(c), i = !0) : a.push(c);
    }
    return i ? Promise.all(a).then((u) => $f(u, o, e, n)) : $f(a, o, e, n);
  };
});
function $s(e, t) {
  let r = e._zod, o = r.bag.optionsMap;
  if (!o) {
    o = /* @__PURE__ */ new Map();
    let { options: n, discriminator: i } = r.def;
    for (let a of n)
      for (let u of a._zod.propValues?.[i] ?? [])
        o.has(u) || o.set(u, a);
    r.bag.optionsMap = o;
  }
  return o.get(t);
}
s($s, "getDiscriminatedOption");
var Je = /* @__PURE__ */ g("$ZodDiscriminatedUnion", (e, t) => {
  t.inclusive = !1, ce.init(e, t);
  let r = e._zod.parse;
  A(e, "propValues", (n) => {
    let i = {};
    for (let a of n.def.options) {
      let u = a._zod.propValues;
      if (!u || Object.keys(u).length === 0)
        throw new Error(`Invalid discriminated union option at index "${n.def.options.indexOf(a)}"`);
      for (let [c, l] of Object.entries(u)) {
        Object.prototype.hasOwnProperty.call(i, c) || te(i, c, /* @__PURE__ */ new Set());
        for (let d of l)
          i[c].add(d);
      }
    }
    return i;
  }), t.options.forEach((n, i) => {
    let a = Ua.get(n._zod.def);
    if (a && !Object.prototype.hasOwnProperty.call(a, t.discriminator))
      throw new Error(`Invalid discriminated union option at index "${i}"`);
  });
  let o = zt(() => {
    let n = t.options, i = /* @__PURE__ */ new Map();
    for (let a of n) {
      let u = a._zod.propValues?.[t.discriminator];
      if (!u || u.size === 0)
        throw new Error(`Invalid discriminated union option at index "${t.options.indexOf(a)}"`);
      for (let c of u) {
        if (i.has(c))
          throw new Error(`Duplicate discriminator value "${String(c)}"`);
        i.set(c, a);
      }
    }
    return i;
  });
  e._zod.parse = (n, i) => {
    let a = n.value;
    if (!at(a))
      return n.issues.push({
        code: "invalid_type",
        expected: "object",
        input: a,
        inst: e
      }), n;
    let u = o.value.get(a?.[t.discriminator]);
    return u ? u._zod.run(n, i) : t.unionFallback || i.direction === "backward" ? r(n, i) : (n.issues.push({
      code: "invalid_union",
      errors: [],
      note: "No matching discriminator",
      discriminator: t.discriminator,
      options: Array.from(o.value.keys()),
      input: a,
      path: [t.discriminator],
      inst: e
    }), n);
  };
}), bs = /* @__PURE__ */ g("$ZodIntersection", (e, t) => {
  S.init(e, t), e._zod.parse = (r, o) => {
    let n = r.value, i = t.left._zod.run({ value: n, issues: [] }, o), a = t.right._zod.run({ value: n, issues: [] }, o);
    return i instanceof Promise || a instanceof Promise ? Promise.all([i, a]).then(([c, l]) => bf(r, c, l)) : bf(r, i, a);
  };
});
function Dt(e, t) {
  if (e === t)
    return { valid: !0, data: e };
  if (e instanceof Date && t instanceof Date && +e == +t)
    return { valid: !0, data: e };
  if (Ne(e) && Ne(t)) {
    let r = Object.keys(t), o = Object.keys(e).filter((i) => r.indexOf(i) !== -1), n = { ...e, ...t };
    Object.prototype.hasOwnProperty.call(n, "__proto__") && delete n.__proto__;
    for (let i of o) {
      if (i === "__proto__")
        continue;
      let a = Dt(e[i], t[i]);
      if (!a.valid)
        return {
          valid: !1,
          mergeErrorPath: [i, ...a.mergeErrorPath]
        };
      n[i] = a.data;
    }
    return { valid: !0, data: n };
  }
  if (Array.isArray(e) && Array.isArray(t)) {
    if (e.length !== t.length)
      return { valid: !1, mergeErrorPath: [] };
    let r = [];
    for (let o = 0; o < e.length; o++) {
      let n = e[o], i = t[o], a = Dt(n, i);
      if (!a.valid)
        return {
          valid: !1,
          mergeErrorPath: [o, ...a.mergeErrorPath]
        };
      r.push(a.data);
    }
    return { valid: !0, data: r };
  }
  return { valid: !1, mergeErrorPath: [] };
}
s(Dt, "mergeValues");
function bf(e, t, r) {
  let o = /* @__PURE__ */ new Map(), n, i = /* @__PURE__ */ new Map(), a = /* @__PURE__ */ s((l, d) => {
    let f;
    if (l.code === "unrecognized_keys" && !l.path?.length)
      n ?? (n = l), f = l.keys;
    else if (l.code === "invalid_key" && l.origin === "record" && l.path?.length === 1) {
      let p = String(l.path[0]);
      i.has(p) || i.set(p, l), f = [p];
    } else
      return !1;
    for (let p of f)
      o.has(p) || o.set(p, {}), o.get(p)[d] = !0;
    return !0;
  }, "collect");
  for (let l of t.issues)
    a(l, "l") || e.issues.push(l);
  for (let l of r.issues)
    a(l, "r") || e.issues.push(l);
  let u = [...o].filter(([, l]) => l.l && l.r).map(([l]) => l);
  if (u.length) {
    let l = n ? u.filter((d) => n.keys.includes(d)) : [];
    l.length && e.issues.push({ ...n, keys: l });
    for (let d of u)
      !l.includes(d) && i.has(d) && e.issues.push(i.get(d));
  }
  let c = Dt(t.value, r.value);
  if (!c.valid) {
    if (Re(e))
      return e;
    throw new Error(`Unmergable intersection. Error path: ${JSON.stringify(c.mergeErrorPath)}`);
  }
  return e.value = c.data, e;
}
s(bf, "handleIntersectionResults");
var qe = /* @__PURE__ */ g("$ZodTuple", (e, t) => {
  S.init(e, t);
  let r = t.items, o = ae.memoizer;
  o?.attach(e), e._zod.parse = (n, i) => {
    let a = n.value;
    if (!Array.isArray(a))
      return n.issues.push({
        input: a,
        inst: e,
        expected: "tuple",
        code: "invalid_type"
      }), n;
    n.value = o ? o.alloc(e, n, [], i) : [];
    let u = [], c = _f(r, "optin"), l = _f(r, "optout");
    if (!t.rest) {
      if (a.length < c)
        return n.issues.push({
          code: "too_small",
          minimum: c,
          inclusive: !0,
          input: a,
          inst: e,
          origin: "array"
        }), n;
      a.length > r.length && n.issues.push({
        code: "too_big",
        maximum: r.length,
        inclusive: !0,
        input: a,
        inst: e,
        origin: "array"
      });
    }
    let d = new Array(r.length);
    for (let f = 0; f < r.length; f++) {
      let p = r[f]._zod.run({ value: a[f], issues: [] }, i);
      p instanceof Promise ? u.push(p.then((h) => {
        d[f] = h;
      })) : d[f] = p;
    }
    if (t.rest) {
      let f = r.length - 1, p = a.slice(r.length);
      for (let h of p) {
        f++;
        let v = t.rest._zod.run({ value: h, issues: [] }, i);
        v instanceof Promise ? u.push(v.then((x) => xf(x, n, f))) : xf(v, n, f);
      }
    }
    return u.length ? Promise.all(u).then(() => wf(d, n, r, a, l)) : wf(d, n, r, a, l);
  };
});
function _f(e, t) {
  for (let r = e.length - 1; r >= 0; r--)
    if (!(t === "optin" ? e[r]._zod.optin !== void 0 : e[r]._zod.optout === "optional"))
      return r + 1;
  return 0;
}
s(_f, "getTupleOptStart");
function xf(e, t, r) {
  e.issues.length && t.issues.push(...pe(r, e.issues)), t.value[r] = e.value;
}
s(xf, "handleTupleResult");
function wf(e, t, r, o, n) {
  for (let i = 0; i < r.length; i++) {
    let a = e[i], u = i < o.length;
    if (!u && i >= n && r[i]._zod.optin === "optional") {
      t.value.length = i;
      break;
    }
    if (a.issues.length) {
      if (!u && i >= n) {
        t.value.length = i;
        break;
      }
      t.issues.push(...pe(i, a.issues));
    }
    t.value[i] = a.value;
  }
  for (let i = t.value.length - 1; i >= o.length && (r[i]._zod.optout === "optional" && t.value[i] === void 0); i--)
    t.value.length = i;
  return t;
}
s(wf, "handleTupleResults");
var dt = /* @__PURE__ */ g("$ZodRecord", (e, t) => {
  S.init(e, t);
  let r = ae.memoizer;
  r?.attach(e), e._zod.parse = (o, n) => {
    let i = o.value;
    if (!Ne(i))
      return o.issues.push({
        expected: "record",
        code: "invalid_type",
        input: i,
        inst: e
      }), o;
    let a = [], u = t.keyType._zod.values;
    if (u && !t.partial) {
      o.value = r ? r.alloc(e, o, {}, n) : {};
      let c = /* @__PURE__ */ new Set();
      for (let d of u)
        if (typeof d == "string" || typeof d == "number" || typeof d == "symbol") {
          if (c.add(typeof d == "number" ? d.toString() : d), d === "__proto__")
            continue;
          let f = t.keyType._zod.run({ value: d, issues: [] }, n);
          if (f instanceof Promise)
            throw new Error("Async schemas not supported in object keys currently");
          if (f.issues.length) {
            o.issues.push({
              code: "invalid_key",
              origin: "record",
              issues: f.issues.map((v) => me(v, n, ie())),
              input: d,
              path: [d],
              inst: e
            });
            continue;
          }
          let p = f.value;
          if (p === "__proto__")
            continue;
          let h = t.valueType._zod.run({ value: i[d], issues: [] }, n);
          h instanceof Promise ? a.push(h.then((v) => {
            v.issues.length && o.issues.push(...pe(d, v.issues)), o.value[p] = v.value;
          })) : (h.issues.length && o.issues.push(...pe(d, h.issues)), o.value[p] = h.value);
        }
      let l;
      for (let d in i)
        if (!c.has(d))
          if (t.mode === "loose") {
            if (d === "__proto__")
              continue;
            o.value[d] = i[d];
          } else
            l = l ?? [], l.push(d);
      l && l.length > 0 && o.issues.push({
        code: "unrecognized_keys",
        input: i,
        inst: e,
        keys: l,
        continue: !0
      });
    } else {
      o.value = r ? r.alloc(e, o, {}, n) : {};
      let c;
      for (let l of Reflect.ownKeys(i)) {
        if (l === "__proto__" || !Object.prototype.propertyIsEnumerable.call(i, l))
          continue;
        let d = t.keyType._zod.run({ value: l, issues: [] }, n);
        if (d instanceof Promise)
          throw new Error("Async schemas not supported in object keys currently");
        if (typeof l == "string" && Ve.test(l) && d.issues.length) {
          let v = t.keyType._zod.run({ value: Number(l), issues: [] }, n);
          if (v instanceof Promise)
            throw new Error("Async schemas not supported in object keys currently");
          v.issues.length === 0 && (d = v);
        }
        if (d.issues.length) {
          t.mode === "loose" ? o.value[l] = i[l] : u ? (c = c ?? [], c.push(l)) : o.issues.push({
            code: "invalid_key",
            origin: "record",
            issues: d.issues.map((v) => me(v, n, ie())),
            input: l,
            path: [l],
            inst: e
          });
          continue;
        }
        let p = d.value;
        if (p === "__proto__")
          continue;
        let h = t.valueType._zod.run({ value: i[l], issues: [] }, n);
        h instanceof Promise ? a.push(h.then((v) => {
          v.issues.length && o.issues.push(...pe(l, v.issues)), o.value[p] = v.value;
        })) : (h.issues.length && o.issues.push(...pe(l, h.issues)), o.value[p] = h.value);
      }
      c && c.length > 0 && o.issues.push({
        code: "unrecognized_keys",
        input: i,
        inst: e,
        keys: c,
        continue: !0
      });
    }
    return a.length ? Promise.all(a).then(() => o) : o;
  };
}), _s = /* @__PURE__ */ g("$ZodMap", (e, t) => {
  S.init(e, t);
  let r = ae.memoizer;
  r?.attach(e), e._zod.parse = (o, n) => {
    let i = o.value;
    if (!(i instanceof Map))
      return o.issues.push({
        expected: "map",
        code: "invalid_type",
        input: i,
        inst: e
      }), o;
    let a = [];
    o.value = r ? r.alloc(e, o, /* @__PURE__ */ new Map(), n) : /* @__PURE__ */ new Map();
    for (let [u, c] of i) {
      let l = t.keyType._zod.run({ value: u, issues: [] }, n), d = t.valueType._zod.run({ value: c, issues: [] }, n);
      l instanceof Promise || d instanceof Promise ? a.push(Promise.all([l, d]).then(([f, p]) => {
        If(f, p, o, u, i, e, n);
      })) : If(l, d, o, u, i, e, n);
    }
    return a.length ? Promise.all(a).then(() => o) : o;
  };
});
function If(e, t, r, o, n, i, a) {
  e.issues.length && (on.has(typeof o) ? r.issues.push(...pe(o, e.issues)) : r.issues.push({
    code: "invalid_key",
    origin: "map",
    input: n,
    inst: i,
    issues: e.issues.map((u) => me(u, a, ie()))
  })), t.issues.length && (on.has(typeof o) ? r.issues.push(...pe(o, t.issues)) : r.issues.push({
    origin: "map",
    code: "invalid_element",
    input: n,
    inst: i,
    key: o,
    issues: t.issues.map((u) => me(u, a, ie()))
  })), r.value.set(e.value, t.value);
}
s(If, "handleMapResult");
var xs = /* @__PURE__ */ g("$ZodSet", (e, t) => {
  S.init(e, t);
  let r = ae.memoizer;
  r?.attach(e), e._zod.parse = (o, n) => {
    let i = o.value;
    if (!(i instanceof Set))
      return o.issues.push({
        input: i,
        inst: e,
        expected: "set",
        code: "invalid_type"
      }), o;
    let a = [];
    o.value = r ? r.alloc(e, o, /* @__PURE__ */ new Set(), n) : /* @__PURE__ */ new Set();
    for (let u of i) {
      let c = t.valueType._zod.run({ value: u, issues: [] }, n);
      c instanceof Promise ? a.push(c.then((l) => kf(l, o))) : kf(c, o);
    }
    return a.length ? Promise.all(a).then(() => o) : o;
  };
});
function kf(e, t) {
  e.issues.length && t.issues.push(...e.issues), t.value.add(e.value);
}
s(kf, "handleSetResult");
var Nt = /* @__PURE__ */ g("$ZodEnum", (e, t) => {
  S.init(e, t);
  let r = tn(t.entries), o = new Set(r);
  e._zod.values = o;
  let n = r.filter((i) => on.has(typeof i));
  e._zod.pattern = new RegExp(n.length ? `^(${n.map((i) => we(i.toString())).join("|")})$` : "^[^\\s\\S]$"), e._zod.parse = (i, a) => {
    let u = i.value;
    return o.has(u) || i.issues.push({
      code: "invalid_value",
      values: r,
      input: u,
      inst: e
    }), i;
  };
}), Ut = /* @__PURE__ */ g("$ZodLiteral", (e, t) => {
  S.init(e, t);
  let r = new Set(t.values);
  e._zod.values = r, e._zod.pattern = new RegExp(t.values.length ? `^(${t.values.map((o) => typeof o == "string" ? we(o) : o ? we(o.toString()) : String(o)).join("|")})$` : "^[^\\s\\S]$"), e._zod.parse = (o, n) => {
    let i = o.value;
    return r.has(i) || o.issues.push({
      code: "invalid_value",
      values: t.values,
      input: i,
      inst: e
    }), o;
  };
}), ws = /* @__PURE__ */ g("$ZodFile", (e, t) => {
  S.init(e, t), e._zod.parse = (r, o) => {
    let n = r.value;
    return n instanceof File || r.issues.push({
      expected: "file",
      code: "invalid_type",
      input: n,
      inst: e
    }), r;
  };
}), Is = /* @__PURE__ */ g("$ZodTransform", (e, t) => {
  S.init(e, t), e._zod.optin = "optional", ae.memoizer?.guard(e), e._zod.parse = (r, o) => {
    if (o.direction === "backward")
      throw new jt(e.constructor.name);
    let n = t.transform(r.value, r);
    if (o.async)
      return (n instanceof Promise ? n : Promise.resolve(n)).then((a) => (r.value = a, r));
    if (n instanceof Promise)
      throw new ge();
    return r.value = n, r;
  };
});
function zf(e, t) {
  return e.value = t.issues.length ? void 0 : t.value, e;
}
s(zf, "handleOptionalResult");
var X = /* @__PURE__ */ g("$ZodOptional", (e, t) => {
  S.init(e, t), A(e, "optin", (r) => r.def.innerType._zod.optin === "defaulted" ? "defaulted" : "optional"), e._zod.optout = "optional", A(e, "values", (r) => {
    let o = r.def.innerType._zod.values;
    return o ? /* @__PURE__ */ new Set([...o, void 0]) : void 0;
  }), A(e, "pattern", (r) => {
    let o = r.def.innerType._zod.pattern;
    return o ? new RegExp(`^(${nn(o.source)})?$`) : void 0;
  }), e._zod.parse = (r, o) => {
    if (r.value === void 0) {
      if (t.innerType._zod.optin !== "defaulted")
        return r;
      let n = t.innerType._zod.run({ value: r.value, issues: [] }, o);
      return n instanceof Promise ? n.then((i) => zf(r, i)) : zf(r, n);
    }
    return t.innerType._zod.run(r, o);
  };
}), ks = /* @__PURE__ */ g("$ZodExactOptional", (e, t) => {
  X.init(e, t), A(e, "values", (r) => r.def.innerType._zod.values), A(e, "pattern", (r) => r.def.innerType._zod.pattern), e._zod.parse = (r, o) => t.innerType._zod.run(r, o);
}), Ie = /* @__PURE__ */ g("$ZodNullable", (e, t) => {
  S.init(e, t), A(e, "optin", (r) => r.def.innerType._zod.optin), A(e, "optout", (r) => r.def.innerType._zod.optout), A(e, "pattern", (r) => {
    let o = r.def.innerType._zod.pattern;
    return o ? new RegExp(`^(${nn(o.source)}|null)$`) : void 0;
  }), A(e, "values", (r) => r.def.innerType._zod.values ? /* @__PURE__ */ new Set([...r.def.innerType._zod.values, null]) : void 0), e._zod.parse = (r, o) => r.value === null ? r : t.innerType._zod.run(r, o);
}), $e = /* @__PURE__ */ g("$ZodDefault", (e, t) => {
  S.init(e, t), e._zod.optin = "defaulted", A(e, "values", (r) => r.def.innerType._zod.values), e._zod.parse = (r, o) => {
    if (o.direction === "backward")
      return t.innerType._zod.run(r, o);
    if (r.value === void 0)
      return r.value = t.defaultValue, r;
    let n = t.innerType._zod.run(r, o);
    return n instanceof Promise ? n.then((i) => Sf(i, t)) : Sf(n, t);
  };
});
function Sf(e, t) {
  return e.value === void 0 && (e.value = t.defaultValue), e;
}
s(Sf, "handleDefaultResult");
var zs = /* @__PURE__ */ g("$ZodPrefault", (e, t) => {
  S.init(e, t), e._zod.optin = "defaulted", A(e, "values", (r) => r.def.innerType._zod.values), e._zod.parse = (r, o) => (o.direction === "backward" || r.value === void 0 && (r.value = t.defaultValue), t.innerType._zod.run(r, o));
}), Ss = /* @__PURE__ */ g("$ZodNonOptional", (e, t) => {
  S.init(e, t), A(e, "values", (r) => {
    let o = r.def.innerType._zod.values;
    return o ? new Set([...o].filter((n) => n !== void 0)) : void 0;
  }), e._zod.parse = (r, o) => {
    let n = t.innerType._zod.run(r, o);
    return n instanceof Promise ? n.then((i) => jf(i, e)) : jf(n, e);
  };
});
function jf(e, t) {
  return !e.issues.length && e.value === void 0 && e.issues.push({
    code: "invalid_type",
    expected: "nonoptional",
    input: e.value,
    inst: t
  }), e;
}
s(jf, "handleNonOptionalResult");
var js = /* @__PURE__ */ g("$ZodSuccess", (e, t) => {
  S.init(e, t), e._zod.parse = (r, o) => {
    if (o.direction === "backward")
      throw new jt("ZodSuccess");
    let n = t.innerType._zod.run(r, o);
    return n instanceof Promise ? n.then((i) => (r.value = i.issues.length === 0, r)) : (r.value = n.issues.length === 0, r);
  };
});
function Of(e, t, r, o) {
  return t.issues.length ? (e.value = r.catchValue({
    ...t,
    value: e.value,
    error: {
      issues: t.issues.map((n) => me(n, o, ie()))
    },
    input: e.value
  }), e) : (e.value = t.value, t.memo && (e.memo = !0), e);
}
s(Of, "handleCatchResult");
var Os = /* @__PURE__ */ g("$ZodCatch", (e, t) => {
  S.init(e, t), A(e, "optin", (r) => r.def.innerType._zod.optin === "defaulted" ? "defaulted" : "optional"), A(e, "optout", (r) => r.def.innerType._zod.optout), A(e, "values", (r) => r.def.innerType._zod.values), e._zod.parse = (r, o) => {
    if (o.direction === "backward")
      return t.innerType._zod.run(r, o);
    let n = t.innerType._zod.run({ value: r.value, issues: [] }, o);
    return n instanceof Promise ? n.then((i) => Of(r, i, t, o)) : Of(r, n, t, o);
  };
}), Ds = /* @__PURE__ */ g("$ZodNaN", (e, t) => {
  S.init(e, t), e._zod.parse = (r, o) => ((typeof r.value != "number" || !Number.isNaN(r.value)) && r.issues.push({
    input: r.value,
    inst: e,
    expected: "nan",
    code: "invalid_type"
  }), r);
}), Ar = /* @__PURE__ */ g("$ZodPipe", (e, t) => {
  S.init(e, t), A(e, "values", (r) => r.def.in._zod.values), A(e, "optin", (r) => r.def.in._zod.optin), A(e, "optout", (r) => r.def.out._zod.optout), A(e, "propValues", (r) => r.def.in._zod.propValues), e._zod.parse = (r, o) => {
    if (o.direction === "backward") {
      let i = t.out._zod.run(r, o);
      return i instanceof Promise ? i.then((a) => _r(a, t.in, o)) : _r(i, t.in, o);
    }
    let n = t.in._zod.run(r, o);
    return n instanceof Promise ? n.then((i) => _r(i, t.out, o)) : _r(n, t.out, o);
  };
});
function _r(e, t, r) {
  return e.issues.some((o) => o.code !== "unrecognized_keys") ? (e.aborted = !0, e) : t._zod.run({ value: e.value, issues: e.issues }, r);
}
s(_r, "handlePipeResult");
var je = /* @__PURE__ */ g("$ZodCodec", (e, t) => {
  S.init(e, t), A(e, "values", (r) => r.def.in._zod.values), A(e, "optin", (r) => r.def.in._zod.optin), A(e, "optout", (r) => r.def.out._zod.optout), A(e, "propValues", (r) => r.def.in._zod.propValues), e._zod.parse = (r, o) => {
    if ((o.direction || "forward") === "forward") {
      let i = t.in._zod.run(r, o);
      return i instanceof Promise ? i.then((a) => xr(a, t, o)) : xr(i, t, o);
    } else {
      let i = t.out._zod.run(r, o);
      return i instanceof Promise ? i.then((a) => xr(a, t, o)) : xr(i, t, o);
    }
  };
});
function xr(e, t, r) {
  if (e.issues.length)
    return e.aborted = !0, e;
  if ((r.direction || "forward") === "forward") {
    let n = t.transform(e.value, e);
    return n instanceof Promise ? n.then((i) => wr(e, i, t.out, r)) : wr(e, n, t.out, r);
  } else {
    let n = t.reverseTransform(e.value, e);
    return n instanceof Promise ? n.then((i) => wr(e, i, t.in, r)) : wr(e, n, t.in, r);
  }
}
s(xr, "handleCodecAResult");
function wr(e, t, r, o) {
  return e.issues.length ? (e.aborted = !0, e) : r._zod.run({ value: t, issues: e.issues }, o);
}
s(wr, "handleCodecTxResult");
var Ov = /* @__PURE__ */ g("$ZodPreprocess", (e, t) => {
  Ar.init(e, t);
}), Ps = /* @__PURE__ */ g("$ZodReadonly", (e, t) => {
  S.init(e, t), A(e, "propValues", (r) => r.def.innerType._zod.propValues), A(e, "values", (r) => r.def.innerType._zod.values), A(e, "optin", (r) => r.def.innerType?._zod?.optin), A(e, "optout", (r) => r.def.innerType?._zod?.optout), e._zod.parse = (r, o) => {
    if (o.direction === "backward")
      return t.innerType._zod.run(r, o);
    let n = t.innerType._zod.run(r, o);
    return n instanceof Promise ? n.then(Df) : Df(n);
  };
});
function Df(e) {
  return e.memo || (e.value = Object.freeze(e.value)), e;
}
s(Df, "handleReadonlyResult");
var Ts = /* @__PURE__ */ g("$ZodTemplateLiteral", (e, t) => {
  S.init(e, t);
  let r = [];
  for (let o of t.parts)
    if (typeof o == "object" && o !== null) {
      if (!o._zod.pattern)
        throw new Error(`Invalid template literal part, no pattern found: ${[...o._zod.traits].shift()}`);
      let n = o._zod.pattern instanceof RegExp ? o._zod.pattern.source : o._zod.pattern;
      if (!n)
        throw new Error(`Invalid template literal part: ${o._zod.traits}`);
      let i = n.startsWith("^") ? 1 : 0, a = n.endsWith("$") ? n.length - 1 : n.length;
      r.push(n.slice(i, a));
    } else if (o === null || ro.has(typeof o))
      r.push(we(`${o}`));
    else
      throw new Error(`Invalid template literal part: ${o}`);
  e._zod.pattern = new RegExp(`^${r.join("")}$`), e._zod.parse = (o, n) => typeof o.value != "string" ? (o.issues.push({
    input: o.value,
    inst: e,
    expected: "string",
    code: "invalid_type"
  }), o) : (e._zod.pattern.lastIndex = 0, e._zod.pattern.test(o.value) || o.issues.push({
    input: o.value,
    inst: e,
    code: "invalid_format",
    format: t.format ?? "template_literal",
    pattern: e._zod.pattern.source
  }), o);
}), Ns = /* @__PURE__ */ g("$ZodFunction", (e, t) => (S.init(e, t), Object.defineProperty(e, "_def", { value: t }), e._zod.def = t, e.implement = (r) => {
  if (typeof r != "function")
    throw new Error("implement() must be called with a function");
  return Object.defineProperty(function(...o) {
    let n = e._def.input ? ve(e._def.input, o) : o, i = Reflect.apply(r, this, n);
    return e._def.output ? ve(e._def.output, i) : i;
  }, "_zod", { value: e._zod, enumerable: !1 });
}, e.implementAsync = (r) => {
  if (typeof r != "function")
    throw new Error("implementAsync() must be called with a function");
  return Object.defineProperty(async function(...o) {
    let n = e._def.input ? await Le(e._def.input, o) : o, i = await Reflect.apply(r, this, n);
    return e._def.output ? await Le(e._def.output, i) : i;
  }, "_zod", { value: e._zod, enumerable: !1 });
}, e._zod.parse = (r, o) => typeof r.value != "function" ? (r.issues.push({
  code: "invalid_type",
  expected: "function",
  input: r.value,
  inst: e
}), r) : (e._def.output && e._def.output._zod.def.type === "promise" ? r.value = e.implementAsync(r.value) : r.value = e.implement(r.value), r), e.input = (...r) => {
  let o = e.constructor;
  return Array.isArray(r[0]) ? new o({
    type: "function",
    input: new qe({
      type: "tuple",
      items: r[0],
      rest: r[1]
    }),
    output: e._def.output
  }) : new o({
    type: "function",
    input: r[0],
    output: e._def.output
  });
}, e.output = (r) => {
  let o = e.constructor;
  return new o({
    type: "function",
    input: e._def.input,
    output: r
  });
}, e)), Us = /* @__PURE__ */ g("$ZodPromise", (e, t) => {
  S.init(e, t), e._zod.parse = (r, o) => Promise.resolve(r.value).then((n) => t.innerType._zod.run({ value: n, issues: [] }, o));
}), We = /* @__PURE__ */ g("$ZodLazy", (e, t) => {
  S.init(e, t), eo(e._zod, "innerType", () => {
    let r = t;
    return r._cachedInner || (r._cachedInner = t.getter()), r._cachedInner;
  }), A(e, "pattern", (r) => r.innerType?._zod?.pattern), A(e, "propValues", (r) => r.innerType?._zod?.propValues), A(e, "optin", (r) => r.innerType?._zod?.optin ?? void 0), A(e, "optout", (r) => r.innerType?._zod?.optout ?? void 0), e._zod.parse = (r, o) => e._zod.innerType._zod.run(r, o);
}), mn = /* @__PURE__ */ g("$ZodCustom", (e, t) => {
  W.init(e, t), S.init(e, t), e._zod.parse = (r, o) => r, e._zod.check = (r) => {
    let o = r.value, n = t.fn(o);
    if (n instanceof Promise)
      return n.then((i) => Pf(i, r, o, e));
    Pf(n, r, o, e);
  };
});
function Pf(e, t, r, o) {
  if (!e) {
    let n = {
      code: "custom",
      input: r,
      inst: o,
      // incorporates params.error into issue reporting
      path: [...o._zod.def.path ?? []],
      // incorporates params.error into issue reporting
      continue: !o._zod.def.abort
      // params: inst._zod.def.params,
    };
    o._zod.def.params && (n.params = o._zod.def.params), t.issues.push(St(n));
  }
}
s(Pf, "handleRefineResult");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/memoizer.js
var Zr = class extends Error {
  static {
    s(this, "$ZodCyclicError");
  }
  constructor() {
    super("Cannot parse a reference cycle that closes through a transform"), this.name = "ZodCyclicError";
  }
}, Es = "~memo", Ef = [];
function As(e) {
  return e.map((t) => t.path ? { ...t, path: t.path.slice() } : { ...t });
}
s(As, "cloneIssues");
var Cf = /* @__PURE__ */ new WeakMap();
function Cs(e, t) {
  let r = Cf.get(e);
  if (r !== void 0)
    return r;
  if (t.has(e))
    return !0;
  t.add(e);
  let o = !1, n = /* @__PURE__ */ s((u) => {
    !o && u?._zod && Cs(u, t) && (o = !0);
  }, "check"), i = e._zod.def, a = i.type;
  switch (a) {
    case "object": {
      for (let u of Reflect.ownKeys(i.shape))
        n(i.shape[u]);
      n(i.catchall);
      break;
    }
    case "array":
      n(i.element);
      break;
    case "tuple":
      for (let u of i.items)
        n(u);
      n(i.rest);
      break;
    case "record":
    case "map":
      n(i.keyType), n(i.valueType);
      break;
    case "set":
      n(i.valueType);
      break;
    case "union":
      for (let u of i.options)
        n(u);
      break;
    case "intersection":
      n(i.left), n(i.right);
      break;
    case "optional":
    case "nullable":
    case "default":
    case "prefault":
    case "catch":
    case "readonly":
    case "nonoptional":
    case "promise":
    case "success":
      n(i.innerType);
      break;
    case "pipe":
      n(i.in), n(i.out);
      break;
    case "function":
      n(i.input), n(i.output);
      break;
    // reading `_zod.innerType` resolves the getter once and caches it
    case "lazy":
      n(e._zod.innerType);
      break;
    // a leaf by choice: `parts` are regex fragments, not data positions
    case "template_literal":
    // leaves
    case "string":
    case "number":
    case "int":
    case "boolean":
    case "bigint":
    case "symbol":
    case "undefined":
    case "null":
    case "void":
    case "never":
    case "any":
    case "unknown":
    case "date":
    case "nan":
    case "enum":
    case "literal":
    case "file":
    case "transform":
    case "custom":
      break;
    default:
      for (let u in i) {
        let c = Object.getOwnPropertyDescriptor(i, u);
        if (!c || c.get)
          continue;
        let l = c.value;
        if (!(!l || typeof l != "object")) {
          if (l._zod)
            n(l);
          else if (Array.isArray(l))
            for (let d of l)
              n(d);
        }
      }
  }
  return t.delete(e), Cf.set(e, o), o;
}
s(Cs, "isRecursive");
function Zs(e) {
  return Cs(e, /* @__PURE__ */ new Set());
}
s(Zs, "isRecursiveSchema");
function Dv(e, t) {
  let r = e.buckets.get(t);
  return r || (r = /* @__PURE__ */ new Map(), e.buckets.set(t, r)), r;
}
s(Dv, "bucketFor");
var Er, Cr = [], Pv = {
  alloc(e, t, r) {
    let o = Er;
    if (!o)
      return r;
    Er = void 0;
    let n = { value: r, issues: null };
    return o.set(t.value, n), Cr.push(n), r;
  },
  guard(e) {
    var t;
    (t = e._zod).deferred ?? (t.deferred = []), e._zod.deferred.push(() => {
      let r = e._zod.parse, o = /* @__PURE__ */ s((n, i) => {
        if (i.direction !== "backward" && Fr(i, n.value))
          throw new Zr();
        return r(n, i);
      }, "wrapped");
      e._zod.parse = o, e._zod.run === r && (e._zod.run = o);
    });
  },
  attach(e) {
    var t;
    let r, o, n;
    (t = e._zod).deferred ?? (t.deferred = []), e._zod.deferred.push(() => {
      let i = e._zod.parse, a = /* @__PURE__ */ s((u, c) => {
        if (r === void 0 && (r = Cs(e, /* @__PURE__ */ new Set()), !r))
          return e._zod.parse = i, e._zod.run === a && (e._zod.run = i), i(u, c);
        let l = u.value;
        if (l === null || typeof l != "object")
          return i(u, c);
        let d = c[Es];
        d || (d = { buckets: /* @__PURE__ */ new Map(), backEdges: void 0 }, c[Es] = d);
        let f;
        o === c ? f = n : (f = Dv(d, e), o = c, n = f);
        let p = f.get(l);
        if (p)
          return u.value = p.value, p.issues ? p.issues.length && u.issues.push(...As(p.issues)) : (u.memo = !0, d.backEdges ?? (d.backEdges = /* @__PURE__ */ new Set()), d.backEdges.add(p.value)), u;
        Er = f;
        let h = Cr.length, v = i(u, c);
        Er = void 0;
        let x = Cr.length > h ? Cr.pop() : void 0;
        return v instanceof Promise ? v.then((k) => (x && (x.issues = k.issues.length ? As(k.issues) : Ef), k)) : (x && (x.issues = v.issues.length ? As(v.issues) : Ef), v);
      }, "wrapped");
      e._zod.parse = a, e._zod.run === i && (e._zod.run = a);
    });
  }
};
function Fs() {
  return Pv;
}
s(Fs, "memoizer");
function Fr(e, t) {
  let r = e[Es]?.backEdges;
  return r !== void 0 && t !== null && typeof t == "object" && r.has(t);
}
s(Fr, "isBackEdge");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/index.js
var yn = {};
et(yn, {
  ar: () => Ms,
  az: () => Rs,
  be: () => Ls,
  bg: () => Vs,
  bn: () => Bs,
  ca: () => Js,
  ckb: () => qs,
  cs: () => Ws,
  da: () => Ks,
  de: () => Gs,
  el: () => Xs,
  en: () => Hs,
  eo: () => Qs,
  es: () => Ys,
  fa: () => eu,
  fi: () => tu,
  fr: () => nu,
  frCA: () => ru,
  gu: () => iu,
  he: () => ou,
  hi: () => au,
  hr: () => su,
  hu: () => uu,
  hy: () => cu,
  id: () => lu,
  is: () => du,
  it: () => fu,
  ja: () => pu,
  ka: () => mu,
  kh: () => gu,
  km: () => gn,
  kn: () => hu,
  ko: () => vu,
  lt: () => yu,
  mk: () => $u,
  ms: () => bu,
  ne: () => _u,
  nl: () => xu,
  nn: () => wu,
  no: () => Iu,
  ota: () => ku,
  pl: () => Su,
  ps: () => zu,
  pt: () => ju,
  ptBR: () => Ou,
  ro: () => Du,
  ru: () => Pu,
  sk: () => Tu,
  sl: () => Nu,
  sv: () => Uu,
  ta: () => Au,
  th: () => Eu,
  tk: () => Cu,
  tr: () => Zu,
  ua: () => Fu,
  uk: () => vn,
  ur: () => Mu,
  uz: () => Ru,
  vi: () => Lu,
  yo: () => Ju,
  zhCN: () => Vu,
  zhTW: () => Bu
});

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ar.js
var Tv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u062D\u0631\u0641", verb: "\u0623\u0646 \u064A\u062D\u0648\u064A" },
    file: { unit: "\u0628\u0627\u064A\u062A", verb: "\u0623\u0646 \u064A\u062D\u0648\u064A" },
    array: { unit: "\u0639\u0646\u0635\u0631", verb: "\u0623\u0646 \u064A\u062D\u0648\u064A" },
    set: { unit: "\u0639\u0646\u0635\u0631", verb: "\u0623\u0646 \u064A\u062D\u0648\u064A" },
    map: { unit: "\u0639\u0646\u0635\u0631", verb: "\u0623\u0646 \u064A\u062D\u0648\u064A" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "\u0645\u062F\u062E\u0644",
    email: "\u0628\u0631\u064A\u062F \u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A",
    url: "\u0631\u0627\u0628\u0637",
    emoji: "\u0625\u064A\u0645\u0648\u062C\u064A",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u062A\u0627\u0631\u064A\u062E \u0648\u0648\u0642\u062A \u0628\u0645\u0639\u064A\u0627\u0631 ISO",
    date: "\u062A\u0627\u0631\u064A\u062E \u0628\u0645\u0639\u064A\u0627\u0631 ISO",
    time: "\u0648\u0642\u062A \u0628\u0645\u0639\u064A\u0627\u0631 ISO",
    duration: "\u0645\u062F\u0629 \u0628\u0645\u0639\u064A\u0627\u0631 ISO",
    ipv4: "\u0639\u0646\u0648\u0627\u0646 IPv4",
    ipv6: "\u0639\u0646\u0648\u0627\u0646 IPv6",
    mac: "\u0639\u0646\u0648\u0627\u0646 MAC",
    cidrv4: "\u0645\u062F\u0649 \u0639\u0646\u0627\u0648\u064A\u0646 \u0628\u0635\u064A\u063A\u0629 IPv4",
    cidrv6: "\u0645\u062F\u0649 \u0639\u0646\u0627\u0648\u064A\u0646 \u0628\u0635\u064A\u063A\u0629 IPv6",
    base64: "\u0646\u064E\u0635 \u0628\u062A\u0631\u0645\u064A\u0632 base64-encoded",
    base64url: "\u0646\u064E\u0635 \u0628\u062A\u0631\u0645\u064A\u0632 base64url-encoded",
    json_string: "\u0646\u064E\u0635 \u0639\u0644\u0649 \u0647\u064A\u0626\u0629 JSON",
    e164: "\u0631\u0642\u0645 \u0647\u0627\u062A\u0641 \u0628\u0645\u0639\u064A\u0627\u0631 E.164",
    credit_card: "\u0631\u0642\u0645 \u0628\u0637\u0627\u0642\u0629 \u0627\u0644\u0627\u0626\u062A\u0645\u0627\u0646",
    jwt: "JWT",
    template_literal: "\u0645\u062F\u062E\u0644"
  }, o = {
    nan: "NaN"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `\u0645\u062F\u062E\u0644\u0627\u062A \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644\u0629: \u064A\u0641\u062A\u0631\u0636 \u0625\u062F\u062E\u0627\u0644 instanceof ${n.expected}\u060C \u0648\u0644\u0643\u0646 \u062A\u0645 \u0625\u062F\u062E\u0627\u0644 ${u}` : `\u0645\u062F\u062E\u0644\u0627\u062A \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644\u0629: \u064A\u0641\u062A\u0631\u0636 \u0625\u062F\u062E\u0627\u0644 ${i}\u060C \u0648\u0644\u0643\u0646 \u062A\u0645 \u0625\u062F\u062E\u0627\u0644 ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `\u0645\u062F\u062E\u0644\u0627\u062A \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644\u0629: \u064A\u0641\u062A\u0631\u0636 \u0625\u062F\u062E\u0627\u0644 ${$(n.values[0])}` : `\u0627\u062E\u062A\u064A\u0627\u0631 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062A\u0648\u0642\u0639 \u0627\u0646\u062A\u0642\u0627\u0621 \u0623\u062D\u062F \u0647\u0630\u0647 \u0627\u0644\u062E\u064A\u0627\u0631\u0627\u062A: ${m(n.values, "|")}`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin);
        return a ? ` \u0623\u0643\u0628\u0631 \u0645\u0646 \u0627\u0644\u0644\u0627\u0632\u0645: \u064A\u0641\u062A\u0631\u0636 \u0623\u0646 \u062A\u0643\u0648\u0646 ${n.origin ?? "\u0627\u0644\u0642\u064A\u0645\u0629"} ${i} ${n.maximum.toString()} ${a.unit ?? "\u0639\u0646\u0635\u0631"}` : `\u0623\u0643\u0628\u0631 \u0645\u0646 \u0627\u0644\u0644\u0627\u0632\u0645: \u064A\u0641\u062A\u0631\u0636 \u0623\u0646 \u062A\u0643\u0648\u0646 ${n.origin ?? "\u0627\u0644\u0642\u064A\u0645\u0629"} ${i} ${n.maximum.toString()}`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin);
        return a ? `\u0623\u0635\u063A\u0631 \u0645\u0646 \u0627\u0644\u0644\u0627\u0632\u0645: \u064A\u0641\u062A\u0631\u0636 \u0644\u0640 ${n.origin} \u0623\u0646 \u064A\u0643\u0648\u0646 ${i} ${n.minimum.toString()} ${a.unit}` : `\u0623\u0635\u063A\u0631 \u0645\u0646 \u0627\u0644\u0644\u0627\u0632\u0645: \u064A\u0641\u062A\u0631\u0636 \u0644\u0640 ${n.origin} \u0623\u0646 \u064A\u0643\u0648\u0646 ${i} ${n.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `\u0646\u064E\u0635 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u0628\u062F\u0623 \u0628\u0640 "${n.prefix}"` : i.format === "ends_with" ? `\u0646\u064E\u0635 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u0646\u062A\u0647\u064A \u0628\u0640 "${i.suffix}"` : i.format === "includes" ? `\u0646\u064E\u0635 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u062A\u0636\u0645\u0651\u064E\u0646 "${i.includes}"` : i.format === "regex" ? `\u0646\u064E\u0635 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u0637\u0627\u0628\u0642 \u0627\u0644\u0646\u0645\u0637 ${i.pattern}` : `${r[i.format] ?? n.format} \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644`;
      }
      case "not_multiple_of":
        return `\u0631\u0642\u0645 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644: \u064A\u062C\u0628 \u0623\u0646 \u064A\u0643\u0648\u0646 \u0645\u0646 \u0645\u0636\u0627\u0639\u0641\u0627\u062A ${n.divisor}`;
      case "unrecognized_keys":
        return `\u0645\u0639\u0631\u0641${n.keys.length > 1 ? "\u0627\u062A" : ""} \u063A\u0631\u064A\u0628${n.keys.length > 1 ? "\u0629" : ""}: ${m(n.keys, "\u060C ")}`;
      case "invalid_key":
        return `\u0645\u0639\u0631\u0641 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644 \u0641\u064A ${n.origin}`;
      case "invalid_union":
        return "\u0645\u062F\u062E\u0644 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644";
      case "invalid_element":
        return `\u0645\u062F\u062E\u0644 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644 \u0641\u064A ${n.origin}`;
      default:
        return "\u0645\u062F\u062E\u0644 \u063A\u064A\u0631 \u0645\u0642\u0628\u0648\u0644";
    }
  };
}, "error");
function Ms() {
  return {
    localeError: Tv()
  };
}
s(Ms, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/az.js
var Nv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "simvol", verb: "olmal\u0131d\u0131r" },
    file: { unit: "bayt", verb: "olmal\u0131d\u0131r" },
    array: { unit: "element", verb: "olmal\u0131d\u0131r" },
    set: { unit: "element", verb: "olmal\u0131d\u0131r" },
    map: { unit: "element", verb: "olmal\u0131d\u0131r" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "input",
    email: "email address",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datetime",
    date: "ISO date",
    time: "ISO time",
    duration: "ISO duration",
    ipv4: "IPv4 address",
    ipv6: "IPv6 address",
    mac: "MAC address",
    cidrv4: "IPv4 range",
    cidrv6: "IPv6 range",
    base64: "base64-encoded string",
    base64url: "base64url-encoded string",
    json_string: "JSON string",
    e164: "E.164 number",
    credit_card: "kredit kart\u0131 n\xF6mr\u0259si",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `Yanl\u0131\u015F d\u0259y\u0259r: g\xF6zl\u0259nil\u0259n instanceof ${n.expected}, daxil olan ${u}` : `Yanl\u0131\u015F d\u0259y\u0259r: g\xF6zl\u0259nil\u0259n ${i}, daxil olan ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `Yanl\u0131\u015F d\u0259y\u0259r: g\xF6zl\u0259nil\u0259n ${$(n.values[0])}` : `Yanl\u0131\u015F se\xE7im: a\u015Fa\u011F\u0131dak\u0131lardan biri olmal\u0131d\u0131r: ${m(n.values, "|")}`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin);
        return a ? `\xC7ox b\xF6y\xFCk: g\xF6zl\u0259nil\u0259n ${n.origin ?? "d\u0259y\u0259r"} ${i}${n.maximum.toString()} ${a.unit ?? "element"}` : `\xC7ox b\xF6y\xFCk: g\xF6zl\u0259nil\u0259n ${n.origin ?? "d\u0259y\u0259r"} ${i}${n.maximum.toString()}`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin);
        return a ? `\xC7ox ki\xE7ik: g\xF6zl\u0259nil\u0259n ${n.origin} ${i}${n.minimum.toString()} ${a.unit}` : `\xC7ox ki\xE7ik: g\xF6zl\u0259nil\u0259n ${n.origin} ${i}${n.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `Yanl\u0131\u015F m\u0259tn: "${i.prefix}" il\u0259 ba\u015Flamal\u0131d\u0131r` : i.format === "ends_with" ? `Yanl\u0131\u015F m\u0259tn: "${i.suffix}" il\u0259 bitm\u0259lidir` : i.format === "includes" ? `Yanl\u0131\u015F m\u0259tn: "${i.includes}" daxil olmal\u0131d\u0131r` : i.format === "regex" ? `Yanl\u0131\u015F m\u0259tn: ${i.pattern} \u015Fablonuna uy\u011Fun olmal\u0131d\u0131r` : `Yanl\u0131\u015F ${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `Yanl\u0131\u015F \u0259d\u0259d: ${n.divisor} il\u0259 b\xF6l\xFCn\u0259 bil\u0259n olmal\u0131d\u0131r`;
      case "unrecognized_keys":
        return `Tan\u0131nmayan a\xE7ar${n.keys.length > 1 ? "lar" : ""}: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `${n.origin} daxilind\u0259 yanl\u0131\u015F a\xE7ar`;
      case "invalid_union":
        return "Yanl\u0131\u015F d\u0259y\u0259r";
      case "invalid_element":
        return `${n.origin} daxilind\u0259 yanl\u0131\u015F d\u0259y\u0259r`;
      default:
        return "Yanl\u0131\u015F d\u0259y\u0259r";
    }
  };
}, "error");
function Rs() {
  return {
    localeError: Nv()
  };
}
s(Rs, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/be.js
function Zf(e, t, r, o) {
  let n = Math.abs(e), i = n % 10, a = n % 100;
  return a >= 11 && a <= 19 ? o : i === 1 ? t : i >= 2 && i <= 4 ? r : o;
}
s(Zf, "getBelarusianPlural");
var Uv = /* @__PURE__ */ s(() => {
  let e = {
    string: {
      unit: {
        one: "\u0441\u0456\u043C\u0432\u0430\u043B",
        few: "\u0441\u0456\u043C\u0432\u0430\u043B\u044B",
        many: "\u0441\u0456\u043C\u0432\u0430\u043B\u0430\u045E"
      },
      verb: "\u043C\u0435\u0446\u044C"
    },
    array: {
      unit: {
        one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
        few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u044B",
        many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430\u045E"
      },
      verb: "\u043C\u0435\u0446\u044C"
    },
    set: {
      unit: {
        one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
        few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u044B",
        many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430\u045E"
      },
      verb: "\u043C\u0435\u0446\u044C"
    },
    map: {
      unit: {
        one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
        few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u044B",
        many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430\u045E"
      },
      verb: "\u043C\u0435\u0446\u044C"
    },
    file: {
      unit: {
        one: "\u0431\u0430\u0439\u0442",
        few: "\u0431\u0430\u0439\u0442\u044B",
        many: "\u0431\u0430\u0439\u0442\u0430\u045E"
      },
      verb: "\u043C\u0435\u0446\u044C"
    }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "\u0443\u0432\u043E\u0434",
    email: "email \u0430\u0434\u0440\u0430\u0441",
    url: "URL",
    emoji: "\u044D\u043C\u043E\u0434\u0437\u0456",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0434\u0430\u0442\u0430 \u0456 \u0447\u0430\u0441",
    date: "ISO \u0434\u0430\u0442\u0430",
    time: "ISO \u0447\u0430\u0441",
    duration: "ISO \u043F\u0440\u0430\u0446\u044F\u0433\u043B\u0430\u0441\u0446\u044C",
    ipv4: "IPv4 \u0430\u0434\u0440\u0430\u0441",
    ipv6: "IPv6 \u0430\u0434\u0440\u0430\u0441",
    mac: "MAC \u0430\u0434\u0440\u0430\u0441",
    cidrv4: "IPv4 \u0434\u044B\u044F\u043F\u0430\u0437\u043E\u043D",
    cidrv6: "IPv6 \u0434\u044B\u044F\u043F\u0430\u0437\u043E\u043D",
    base64: "\u0440\u0430\u0434\u043E\u043A \u0443 \u0444\u0430\u0440\u043C\u0430\u0446\u0435 base64",
    base64url: "\u0440\u0430\u0434\u043E\u043A \u0443 \u0444\u0430\u0440\u043C\u0430\u0446\u0435 base64url",
    json_string: "JSON \u0440\u0430\u0434\u043E\u043A",
    e164: "\u043D\u0443\u043C\u0430\u0440 E.164",
    credit_card: "\u043D\u0443\u043C\u0430\u0440 \u043A\u0440\u044D\u0434\u044B\u0442\u043D\u0430\u0439 \u043A\u0430\u0440\u0442\u044B",
    jwt: "JWT",
    template_literal: "\u0443\u0432\u043E\u0434"
  }, o = {
    nan: "NaN",
    number: "\u043B\u0456\u043A",
    array: "\u043C\u0430\u0441\u0456\u045E"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434: \u0447\u0430\u043A\u0430\u045E\u0441\u044F instanceof ${n.expected}, \u0430\u0442\u0440\u044B\u043C\u0430\u043D\u0430 ${u}` : `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434: \u0447\u0430\u043A\u0430\u045E\u0441\u044F ${i}, \u0430\u0442\u0440\u044B\u043C\u0430\u043D\u0430 ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F ${$(n.values[0])}` : `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0432\u0430\u0440\u044B\u044F\u043D\u0442: \u0447\u0430\u043A\u0430\u045E\u0441\u044F \u0430\u0434\u0437\u0456\u043D \u0437 ${m(n.values, "|")}`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin);
        if (a) {
          let u = Number(n.maximum), c = Zf(u, a.unit.one, a.unit.few, a.unit.many);
          return `\u0417\u0430\u043D\u0430\u0434\u0442\u0430 \u0432\u044F\u043B\u0456\u043A\u0456: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F, \u0448\u0442\u043E ${n.origin ?? "\u0437\u043D\u0430\u0447\u044D\u043D\u043D\u0435"} \u043F\u0430\u0432\u0456\u043D\u043D\u0430 ${a.verb} ${i}${n.maximum.toString()} ${c}`;
        }
        return `\u0417\u0430\u043D\u0430\u0434\u0442\u0430 \u0432\u044F\u043B\u0456\u043A\u0456: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F, \u0448\u0442\u043E ${n.origin ?? "\u0437\u043D\u0430\u0447\u044D\u043D\u043D\u0435"} \u043F\u0430\u0432\u0456\u043D\u043D\u0430 \u0431\u044B\u0446\u044C ${i}${n.maximum.toString()}`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin);
        if (a) {
          let u = Number(n.minimum), c = Zf(u, a.unit.one, a.unit.few, a.unit.many);
          return `\u0417\u0430\u043D\u0430\u0434\u0442\u0430 \u043C\u0430\u043B\u044B: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F, \u0448\u0442\u043E ${n.origin} \u043F\u0430\u0432\u0456\u043D\u043D\u0430 ${a.verb} ${i}${n.minimum.toString()} ${c}`;
        }
        return `\u0417\u0430\u043D\u0430\u0434\u0442\u0430 \u043C\u0430\u043B\u044B: \u0447\u0430\u043A\u0430\u043B\u0430\u0441\u044F, \u0448\u0442\u043E ${n.origin} \u043F\u0430\u0432\u0456\u043D\u043D\u0430 \u0431\u044B\u0446\u044C ${i}${n.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0440\u0430\u0434\u043E\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u043F\u0430\u0447\u044B\u043D\u0430\u0446\u0446\u0430 \u0437 "${i.prefix}"` : i.format === "ends_with" ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0440\u0430\u0434\u043E\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u0437\u0430\u043A\u0430\u043D\u0447\u0432\u0430\u0446\u0446\u0430 \u043D\u0430 "${i.suffix}"` : i.format === "includes" ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0440\u0430\u0434\u043E\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u0437\u043C\u044F\u0448\u0447\u0430\u0446\u044C "${i.includes}"` : i.format === "regex" ? `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u0440\u0430\u0434\u043E\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u0430\u0434\u043F\u0430\u0432\u044F\u0434\u0430\u0446\u044C \u0448\u0430\u0431\u043B\u043E\u043D\u0443 ${i.pattern}` : `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B ${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u043B\u0456\u043A: \u043F\u0430\u0432\u0456\u043D\u0435\u043D \u0431\u044B\u0446\u044C \u043A\u0440\u0430\u0442\u043D\u044B\u043C ${n.divisor}`;
      case "unrecognized_keys":
        return `\u041D\u0435\u0440\u0430\u0441\u043F\u0430\u0437\u043D\u0430\u043D\u044B ${n.keys.length > 1 ? "\u043A\u043B\u044E\u0447\u044B" : "\u043A\u043B\u044E\u0447"}: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u043A\u043B\u044E\u0447 \u0443 ${n.origin}`;
      case "invalid_union":
        return "\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434";
      case "invalid_element":
        return `\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u0430\u0435 \u0437\u043D\u0430\u0447\u044D\u043D\u043D\u0435 \u045E ${n.origin}`;
      default:
        return "\u041D\u044F\u043F\u0440\u0430\u0432\u0456\u043B\u044C\u043D\u044B \u045E\u0432\u043E\u0434";
    }
  };
}, "error");
function Ls() {
  return {
    localeError: Uv()
  };
}
s(Ls, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/bg.js
var Av = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0441\u0438\u043C\u0432\u043E\u043B\u0430", verb: "\u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430" },
    file: { unit: "\u0431\u0430\u0439\u0442\u0430", verb: "\u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430" },
    array: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0430", verb: "\u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430" },
    set: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0430", verb: "\u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430" },
    map: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0430", verb: "\u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "\u0432\u0445\u043E\u0434",
    email: "\u0438\u043C\u0435\u0439\u043B \u0430\u0434\u0440\u0435\u0441",
    url: "URL",
    emoji: "\u0435\u043C\u043E\u0434\u0436\u0438",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0432\u0440\u0435\u043C\u0435",
    date: "ISO \u0434\u0430\u0442\u0430",
    time: "ISO \u0432\u0440\u0435\u043C\u0435",
    duration: "ISO \u043F\u0440\u043E\u0434\u044A\u043B\u0436\u0438\u0442\u0435\u043B\u043D\u043E\u0441\u0442",
    ipv4: "IPv4 \u0430\u0434\u0440\u0435\u0441",
    ipv6: "IPv6 \u0430\u0434\u0440\u0435\u0441",
    mac: "MAC \u0430\u0434\u0440\u0435\u0441",
    cidrv4: "IPv4 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D",
    cidrv6: "IPv6 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D",
    base64: "base64-\u043A\u043E\u0434\u0438\u0440\u0430\u043D \u043D\u0438\u0437",
    base64url: "base64url-\u043A\u043E\u0434\u0438\u0440\u0430\u043D \u043D\u0438\u0437",
    json_string: "JSON \u043D\u0438\u0437",
    e164: "E.164 \u043D\u043E\u043C\u0435\u0440",
    credit_card: "\u043D\u043E\u043C\u0435\u0440 \u043D\u0430 \u043A\u0440\u0435\u0434\u0438\u0442\u043D\u0430 \u043A\u0430\u0440\u0442\u0430",
    jwt: "JWT",
    template_literal: "\u0432\u0445\u043E\u0434"
  }, o = {
    nan: "NaN",
    number: "\u0447\u0438\u0441\u043B\u043E",
    array: "\u043C\u0430\u0441\u0438\u0432"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434: \u043E\u0447\u0430\u043A\u0432\u0430\u043D instanceof ${n.expected}, \u043F\u043E\u043B\u0443\u0447\u0435\u043D ${u}` : `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434: \u043E\u0447\u0430\u043A\u0432\u0430\u043D ${i}, \u043F\u043E\u043B\u0443\u0447\u0435\u043D ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434: \u043E\u0447\u0430\u043A\u0432\u0430\u043D ${$(n.values[0])}` : `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u0430 \u043E\u043F\u0446\u0438\u044F: \u043E\u0447\u0430\u043A\u0432\u0430\u043D\u043E \u0435\u0434\u043D\u043E \u043E\u0442 ${m(n.values, "|")}`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin);
        return a ? `\u0422\u0432\u044A\u0440\u0434\u0435 \u0433\u043E\u043B\u044F\u043C\u043E: \u043E\u0447\u0430\u043A\u0432\u0430 \u0441\u0435 ${n.origin ?? "\u0441\u0442\u043E\u0439\u043D\u043E\u0441\u0442"} \u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430 ${i}${n.maximum.toString()} ${a.unit ?? "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0430"}` : `\u0422\u0432\u044A\u0440\u0434\u0435 \u0433\u043E\u043B\u044F\u043C\u043E: \u043E\u0447\u0430\u043A\u0432\u0430 \u0441\u0435 ${n.origin ?? "\u0441\u0442\u043E\u0439\u043D\u043E\u0441\u0442"} \u0434\u0430 \u0431\u044A\u0434\u0435 ${i}${n.maximum.toString()}`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin);
        return a ? `\u0422\u0432\u044A\u0440\u0434\u0435 \u043C\u0430\u043B\u043A\u043E: \u043E\u0447\u0430\u043A\u0432\u0430 \u0441\u0435 ${n.origin} \u0434\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430 ${i}${n.minimum.toString()} ${a.unit}` : `\u0422\u0432\u044A\u0440\u0434\u0435 \u043C\u0430\u043B\u043A\u043E: \u043E\u0447\u0430\u043A\u0432\u0430 \u0441\u0435 ${n.origin} \u0434\u0430 \u0431\u044A\u0434\u0435 ${i}${n.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = n;
        if (i.format === "starts_with")
          return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043D\u0438\u0437: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0437\u0430\u043F\u043E\u0447\u0432\u0430 \u0441 "${i.prefix}"`;
        if (i.format === "ends_with")
          return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043D\u0438\u0437: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0437\u0430\u0432\u044A\u0440\u0448\u0432\u0430 \u0441 "${i.suffix}"`;
        if (i.format === "includes")
          return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043D\u0438\u0437: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0432\u043A\u043B\u044E\u0447\u0432\u0430 "${i.includes}"`;
        if (i.format === "regex")
          return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043D\u0438\u0437: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0441\u044A\u0432\u043F\u0430\u0434\u0430 \u0441 ${i.pattern}`;
        let a = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D";
        return i.format === "emoji" && (a = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u043E"), i.format === "datetime" && (a = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u043E"), i.format === "date" && (a = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u0430"), i.format === "time" && (a = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u043E"), i.format === "duration" && (a = "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u0430"), `${a} ${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u043E \u0447\u0438\u0441\u043B\u043E: \u0442\u0440\u044F\u0431\u0432\u0430 \u0434\u0430 \u0431\u044A\u0434\u0435 \u043A\u0440\u0430\u0442\u043D\u043E \u043D\u0430 ${n.divisor}`;
      case "unrecognized_keys":
        return `\u041D\u0435\u0440\u0430\u0437\u043F\u043E\u0437\u043D\u0430\u0442${n.keys.length > 1 ? "\u0438" : ""} \u043A\u043B\u044E\u0447${n.keys.length > 1 ? "\u043E\u0432\u0435" : ""}: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u043A\u043B\u044E\u0447 \u0432 ${n.origin}`;
      case "invalid_union":
        return "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434";
      case "invalid_element":
        return `\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u043D\u0430 \u0441\u0442\u043E\u0439\u043D\u043E\u0441\u0442 \u0432 ${n.origin}`;
      default:
        return "\u041D\u0435\u0432\u0430\u043B\u0438\u0434\u0435\u043D \u0432\u0445\u043E\u0434";
    }
  };
}, "error");
function Vs() {
  return {
    localeError: Av()
  };
}
s(Vs, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/bn.js
var Ev = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0985\u0995\u09CD\u09B7\u09B0", verb: "\u09A5\u09BE\u0995\u09A4\u09C7 \u09B9\u09AC\u09C7" },
    file: { unit: "\u09AC\u09BE\u0987\u099F", verb: "\u09A5\u09BE\u0995\u09A4\u09C7 \u09B9\u09AC\u09C7" },
    array: { unit: "\u0986\u0987\u099F\u09C7\u09AE", verb: "\u09A5\u09BE\u0995\u09A4\u09C7 \u09B9\u09AC\u09C7" },
    set: { unit: "\u0986\u0987\u099F\u09C7\u09AE", verb: "\u09A5\u09BE\u0995\u09A4\u09C7 \u09B9\u09AC\u09C7" },
    map: { unit: "\u098F\u09A8\u09CD\u099F\u09CD\u09B0\u09BF", verb: "\u09A5\u09BE\u0995\u09A4\u09C7 \u09B9\u09AC\u09C7" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "\u0987\u09A8\u09AA\u09C1\u099F",
    email: "\u0987\u09AE\u09C7\u0987\u09B2 \u09A0\u09BF\u0995\u09BE\u09A8\u09BE",
    url: "URL",
    emoji: "\u0987\u09AE\u09CB\u099C\u09BF",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u09A4\u09BE\u09B0\u09BF\u0996 \u0993 \u09B8\u09AE\u09AF\u09BC",
    date: "ISO \u09A4\u09BE\u09B0\u09BF\u0996",
    time: "ISO \u09B8\u09AE\u09AF\u09BC",
    duration: "ISO \u09B8\u09AE\u09AF\u09BC\u0995\u09BE\u09B2",
    ipv4: "IPv4 \u09A0\u09BF\u0995\u09BE\u09A8\u09BE",
    ipv6: "IPv6 \u09A0\u09BF\u0995\u09BE\u09A8\u09BE",
    mac: "MAC \u09A0\u09BF\u0995\u09BE\u09A8\u09BE",
    cidrv4: "IPv4 \u09B0\u09C7\u099E\u09CD\u099C",
    cidrv6: "IPv6 \u09B0\u09C7\u099E\u09CD\u099C",
    base64: "base64-\u098F\u09A8\u0995\u09CB\u09A1\u09C7\u09A1 \u09B8\u09CD\u099F\u09CD\u09B0\u09BF\u0982",
    base64url: "base64url-\u098F\u09A8\u0995\u09CB\u09A1\u09C7\u09A1 \u09B8\u09CD\u099F\u09CD\u09B0\u09BF\u0982",
    json_string: "JSON \u09B8\u09CD\u099F\u09CD\u09B0\u09BF\u0982",
    e164: "E.164 \u09A8\u09AE\u09CD\u09AC\u09B0",
    credit_card: "\u0995\u09CD\u09B0\u09C7\u09A1\u09BF\u099F \u0995\u09BE\u09B0\u09CD\u09A1 \u09A8\u09AE\u09CD\u09AC\u09B0",
    jwt: "JWT",
    template_literal: "\u0987\u09A8\u09AA\u09C1\u099F"
  }, o = {
    nan: "NaN"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return `\u0985\u09AC\u09C8\u09A7 \u0987\u09A8\u09AA\u09C1\u099F: \u09AA\u09CD\u09B0\u09A4\u09CD\u09AF\u09BE\u09B6\u09BF\u09A4 ${i}, \u09AA\u09CD\u09B0\u09BE\u09AA\u09CD\u09A4 ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `\u0985\u09AC\u09C8\u09A7 \u0987\u09A8\u09AA\u09C1\u099F: \u09AA\u09CD\u09B0\u09A4\u09CD\u09AF\u09BE\u09B6\u09BF\u09A4 ${$(n.values[0])}` : `\u0985\u09AC\u09C8\u09A7 \u0985\u09AA\u09B6\u09A8: ${m(n.values, " | ")} \u098F\u09B0 \u09AE\u09A7\u09CD\u09AF\u09C7 \u098F\u0995\u099F\u09BF \u09AA\u09CD\u09B0\u09A4\u09CD\u09AF\u09BE\u09B6\u09BF\u09A4`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin);
        return a ? `\u0985\u09A8\u09C7\u0995 \u09AC\u09A1\u09BC: ${n.origin ?? "\u09AE\u09BE\u09A8"} ${i}${n.maximum.toString()} ${a.unit ?? "\u098F\u09B2\u09BF\u09AE\u09C7\u09A8\u09CD\u099F"} \u09B9\u09A4\u09C7 \u09B9\u09AC\u09C7` : `\u0985\u09A8\u09C7\u0995 \u09AC\u09A1\u09BC: ${n.origin ?? "\u09AE\u09BE\u09A8"} ${i}${n.maximum.toString()} \u09B9\u09A4\u09C7 \u09B9\u09AC\u09C7`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin);
        return a ? `\u0985\u09A8\u09C7\u0995 \u099B\u09CB\u099F: ${n.origin} ${i}${n.minimum.toString()} ${a.unit} \u09B9\u09A4\u09C7 \u09B9\u09AC\u09C7` : `\u0985\u09A8\u09C7\u0995 \u099B\u09CB\u099F: ${n.origin} ${i}${n.minimum.toString()} \u09B9\u09A4\u09C7 \u09B9\u09AC\u09C7`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `\u0985\u09AC\u09C8\u09A7 \u09B8\u09CD\u099F\u09CD\u09B0\u09BF\u0982: "${i.prefix}" \u09A6\u09BF\u09AF\u09BC\u09C7 \u09B6\u09C1\u09B0\u09C1 \u09B9\u09A4\u09C7 \u09B9\u09AC\u09C7` : i.format === "ends_with" ? `\u0985\u09AC\u09C8\u09A7 \u09B8\u09CD\u099F\u09CD\u09B0\u09BF\u0982: "${i.suffix}" \u09A6\u09BF\u09AF\u09BC\u09C7 \u09B6\u09C7\u09B7 \u09B9\u09A4\u09C7 \u09B9\u09AC\u09C7` : i.format === "includes" ? `\u0985\u09AC\u09C8\u09A7 \u09B8\u09CD\u099F\u09CD\u09B0\u09BF\u0982: "${i.includes}" \u0985\u09A8\u09CD\u09A4\u09B0\u09CD\u09AD\u09C1\u0995\u09CD\u09A4 \u09A5\u09BE\u0995\u09A4\u09C7 \u09B9\u09AC\u09C7` : i.format === "regex" ? `\u0985\u09AC\u09C8\u09A7 \u09B8\u09CD\u099F\u09CD\u09B0\u09BF\u0982: ${i.pattern} \u09AA\u09CD\u09AF\u09BE\u099F\u09BE\u09B0\u09CD\u09A8 \u09AE\u09BF\u09B2\u09A4\u09C7 \u09B9\u09AC\u09C7` : `\u0985\u09AC\u09C8\u09A7 ${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `\u0985\u09AC\u09C8\u09A7 \u09A8\u09AE\u09CD\u09AC\u09B0: ${n.divisor} \u098F\u09B0 \u0997\u09C1\u09A3\u09BF\u09A4\u0995 \u09B9\u09A4\u09C7 \u09B9\u09AC\u09C7`;
      case "unrecognized_keys":
        return `\u0985\u099A\u09C7\u09A8\u09BE \u0995\u09C0${n.keys.length > 1 ? "\u0997\u09C1\u09B2\u09CB" : ""}: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `${n.origin} \u098F \u0985\u09AC\u09C8\u09A7 \u0995\u09C0`;
      case "invalid_union":
        return n.options && Array.isArray(n.options) && n.options.length > 0 ? `\u0985\u09AC\u09C8\u09A7 \u09A1\u09BF\u09B8\u0995\u09CD\u09B0\u09BF\u09AE\u09BF\u09A8\u09C7\u099F\u09B0 \u09AE\u09BE\u09A8\u0964 \u09AA\u09CD\u09B0\u09A4\u09CD\u09AF\u09BE\u09B6\u09BF\u09A4 ${n.options.map((a) => `'${a}'`).join(" | ")}` : "\u0985\u09AC\u09C8\u09A7 \u0987\u09A8\u09AA\u09C1\u099F";
      case "invalid_element":
        return `${n.origin} \u098F \u0985\u09AC\u09C8\u09A7 \u09AE\u09BE\u09A8`;
      default:
        return "\u0985\u09AC\u09C8\u09A7 \u0987\u09A8\u09AA\u09C1\u099F";
    }
  };
}, "error");
function Bs() {
  return {
    localeError: Ev()
  };
}
s(Bs, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ca.js
var Cv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "car\xE0cters", verb: "contenir" },
    file: { unit: "bytes", verb: "contenir" },
    array: { unit: "elements", verb: "contenir" },
    set: { unit: "elements", verb: "contenir" },
    map: { unit: "elements", verb: "contenir" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "entrada",
    email: "adre\xE7a electr\xF2nica",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "data i hora ISO",
    date: "data ISO",
    time: "hora ISO",
    duration: "durada ISO",
    ipv4: "adre\xE7a IPv4",
    ipv6: "adre\xE7a IPv6",
    mac: "adre\xE7a MAC",
    cidrv4: "rang IPv4",
    cidrv6: "rang IPv6",
    base64: "cadena codificada en base64",
    base64url: "cadena codificada en base64url",
    json_string: "cadena JSON",
    e164: "n\xFAmero E.164",
    credit_card: "n\xFAmero de targeta de cr\xE8dit",
    jwt: "JWT",
    template_literal: "entrada"
  }, o = {
    nan: "NaN"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `Tipus inv\xE0lid: s'esperava instanceof ${n.expected}, s'ha rebut ${u}` : `Tipus inv\xE0lid: s'esperava ${i}, s'ha rebut ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `Valor inv\xE0lid: s'esperava ${$(n.values[0])}` : `Opci\xF3 inv\xE0lida: s'esperava una de ${m(n.values, " o ")}`;
      case "too_big": {
        let i = n.inclusive ? "com a m\xE0xim" : "menys de", a = t(n.origin);
        return a ? `Massa gran: s'esperava que ${n.origin ?? "el valor"} contingu\xE9s ${i} ${n.maximum.toString()} ${a.unit ?? "elements"}` : `Massa gran: s'esperava que ${n.origin ?? "el valor"} fos ${i} ${n.maximum.toString()}`;
      }
      case "too_small": {
        let i = n.inclusive ? "com a m\xEDnim" : "m\xE9s de", a = t(n.origin);
        return a ? `Massa petit: s'esperava que ${n.origin} contingu\xE9s ${i} ${n.minimum.toString()} ${a.unit}` : `Massa petit: s'esperava que ${n.origin} fos ${i} ${n.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `Format inv\xE0lid: ha de comen\xE7ar amb "${i.prefix}"` : i.format === "ends_with" ? `Format inv\xE0lid: ha d'acabar amb "${i.suffix}"` : i.format === "includes" ? `Format inv\xE0lid: ha d'incloure "${i.includes}"` : i.format === "regex" ? `Format inv\xE0lid: ha de coincidir amb el patr\xF3 ${i.pattern}` : `Format inv\xE0lid per a ${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `N\xFAmero inv\xE0lid: ha de ser m\xFAltiple de ${n.divisor}`;
      case "unrecognized_keys":
        return `Clau${n.keys.length > 1 ? "s" : ""} no reconeguda${n.keys.length > 1 ? "s" : ""}: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `Clau inv\xE0lida a ${n.origin}`;
      case "invalid_union":
        return "Entrada inv\xE0lida";
      // Could also be "Tipus d'unió invàlid" but "Entrada invàlida" is more general
      case "invalid_element":
        return `Element inv\xE0lid a ${n.origin}`;
      default:
        return "Entrada inv\xE0lida";
    }
  };
}, "error");
function Js() {
  return {
    localeError: Cv()
  };
}
s(Js, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ckb.js
var Zv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u067E\u06CC\u062A", verb: "\u0628\u06CE\u062A" },
    file: { unit: "\u0628\u0627\u06CC\u062A", verb: "\u0628\u06CE\u062A" },
    array: { unit: "\u062F\u0627\u0646\u06D5", verb: "\u0628\u06CE\u062A" },
    set: { unit: "\u062F\u0627\u0646\u06D5", verb: "\u0628\u06CE\u062A" },
    map: { unit: "\u062F\u0627\u0646\u06D5", verb: "\u0628\u06CE\u062A" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "regex",
    email: "\u0626\u06CC\u0645\u06D5\u06CC\u06B5",
    url: "\u0628\u06D5\u0633\u062A\u06D5\u0631 (URL)",
    emoji: "\u0626\u06CC\u0645\u06C6\u062C\u06CC",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u0695\u06CE\u06A9\u06D5\u0648\u062A \u0648 \u06A9\u0627\u062A",
    date: "\u0695\u06CE\u06A9\u06D5\u0648\u062A",
    time: "\u06A9\u0627\u062A",
    duration: "\u0645\u0627\u0648\u06D5",
    ipv4: "\u0646\u0627\u0648\u0646\u06CC\u0634\u0627\u0646\u06CC IPv4",
    ipv6: "\u0646\u0627\u0648\u0646\u06CC\u0634\u0627\u0646\u06CC IPv6",
    mac: "\u0646\u0627\u0648\u0646\u06CC\u0634\u0627\u0646\u06CC MAC",
    cidrv4: "\u0645\u06D5\u0648\u062F\u0627\u06CC IPv4",
    cidrv6: "\u0645\u06D5\u0648\u062F\u0627\u06CC IPv6",
    base64: "\u062F\u06D5\u0642\u06CC base64",
    base64url: "\u062F\u06D5\u0642\u06CC base64url",
    json_string: "\u062F\u06D5\u0642\u06CC JSON",
    e164: "\u0698\u0645\u0627\u0631\u06D5\u06CC E.164",
    credit_card: "\u0698\u0645\u0627\u0631\u06D5\u06CC \u06A9\u0627\u0631\u062A\u06CC \u06A9\u0631\u06CE\u062F\u06CC\u062A",
    jwt: "JWT",
    template_literal: "\u062A\u06CE\u06A9\u0631\u062F\u06D5"
  }, o = {
    nan: "NaN",
    string: "\u0646\u0648\u0648\u0633\u06CC\u0646",
    number: "\u0698\u0645\u0627\u0631\u06D5",
    boolean: "boolean",
    array: "array",
    object: "object",
    date: "\u0695\u06CE\u06A9\u06D5\u0648\u062A",
    integer: "\u0698\u0645\u0627\u0631\u06D5",
    float: "\u0698\u0645\u0627\u0631\u06D5",
    null: "null",
    undefined: "undefined",
    function: "function",
    symbol: "symbol",
    unknown: "unknown",
    promise: "promise",
    void: "void",
    never: "never",
    map: "map",
    set: "set"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a, c = ["\u0627", "\u0648", "\u06C6", "\u0648\u0648", "\u06D5", "\u06CC", "\u06CE"].some((d) => u.endsWith(d)) ? "\u06CC\u06D5" : "\u06D5", l = /^[a-zA-Z]+$/.test(u);
        return a === "null" || a === "undefined" ? "\u062F\u0627\u0648\u0627\u06A9\u0631\u0627\u0648\u06D5" : `\u0686\u0627\u0648\u06D5\u0695\u0648\u0627\u0646\u06A9\u0631\u0627\u0648\u06D5 ${i} \u0628\u06CE\u062A\u060C \u0628\u06D5\u06B5\u0627\u0645 ${u}${l ? "" : c}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `\u0628\u06D5\u0647\u0627\u06A9\u06D5 \u0646\u0627\u062F\u0631\u0648\u0648\u0633\u062A\u06D5: \u0686\u0627\u0648\u06D5\u0695\u0648\u0627\u0646\u06A9\u0631\u0627\u0648\u06D5 ${$(n.values[0])} \u0628\u06CE\u062A` : `\u0647\u06D5\u06B5\u0628\u0698\u0627\u0631\u062F\u06D5\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A: \u0686\u0627\u0648\u06D5\u0695\u0648\u0627\u0646\u06A9\u0631\u0627\u0648\u06D5 \u06CC\u06D5\u06A9\u06CE\u06A9 \u0628\u06CE\u062A \u0644\u06D5 ${m(n.values, "|")}`;
      case "too_big": {
        let i = t(n.origin);
        return i ? `\u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 \u0628\u06D5 \u0644\u0627\u06CC\u06D5\u0646\u06CC \u0632\u06C6\u0631\u06D5\u0648\u06D5 ${n.maximum.toString()} ${i.unit} ${i.verb}` : `\u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 \u0628\u06D5 \u0644\u0627\u06CC\u06D5\u0646\u06CC \u0632\u06C6\u0631\u06D5\u0648\u06D5 ${n.maximum.toString()} \u0628\u06CE\u062A`;
      }
      case "too_small": {
        let i = t(n.origin);
        return i ? `\u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 \u0628\u06D5 \u0644\u0627\u06CC\u06D5\u0646\u06CC \u06A9\u06D5\u0645\u06D5\u0648\u06D5 ${n.minimum.toString()} ${i.unit} ${i.verb}` : `\u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 \u0628\u06D5 \u0644\u0627\u06CC\u06D5\u0646\u06CC \u06A9\u06D5\u0645\u06D5\u0648\u06D5 ${n.minimum.toString()} \u0628\u06CE\u062A`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `\u062F\u06D5\u0642\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A: \u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 \u062F\u06D5\u0633\u062A\u067E\u06CE\u0628\u06A9\u0627\u062A \u0628\u06D5 "${i.prefix}"` : i.format === "ends_with" ? `\u062F\u06D5\u0642\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A: \u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 \u06A9\u06C6\u062A\u0627\u06CC\u06CC\u0628\u06CE\u062A \u0628\u06D5 "${i.suffix}"` : i.format === "includes" ? `\u062F\u06D5\u0642\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A: \u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 "${i.includes}" \u0644\u06D5\u062E\u06C6\u0628\u06AF\u0631\u06CE\u062A` : i.format === "regex" ? `\u062F\u06D5\u0642\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A: \u067E\u06CE\u0648\u06CC\u0633\u062A\u06D5 \u0644\u06D5\u06AF\u06D5\u06B5 \u067E\u0627\u062A\u06CE\u0631\u0646\u06CC ${i.pattern} \u0628\u06AF\u0648\u0646\u062C\u06CE\u062A` : `\u0628\u06D5\u0647\u0627\u06CC ${r[i.format] ?? n.format} \u0646\u0627\u062F\u0631\u0648\u0633\u062A\u06D5`;
      }
      case "not_multiple_of":
        return `\u0698\u0645\u0627\u0631\u06D5\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A: \u062F\u06D5\u0628\u06CE\u062A \u0686\u06D5\u0646\u062F \u0647\u06CE\u0646\u062F\u06D5 \u0628\u06CE\u062A \u0628\u06C6 ${n.divisor}`;
      case "unrecognized_keys":
        return `\u06A9\u0644\u06CC\u0644\u06CC \u0646\u06D5\u0646\u0627\u0633\u0631\u0627\u0648: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `\u06A9\u0644\u06CC\u0644\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A \u0644\u06D5 ${n.origin}`;
      case "invalid_union":
        return n.options && Array.isArray(n.options) && n.options.length > 0 ? `\u0628\u06D5\u0647\u0627\u06CC \u0646\u06D5\u0646\u0627\u0633\u0631\u0627\u0648 \u0647\u06D5\u06CC\u06D5. \u0628\u06D5\u0647\u0627\u06CC \u0686\u0627\u0648\u06D5\u0695\u0648\u0627\u0646\u06A9\u0631\u0627\u0648: ${n.options.map((a) => `'${a}'`).join(" | ")}` : "\u06CC\u06D5\u06A9\u06AF\u0631\u062A\u0646\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A";
      case "invalid_element":
        return `${n.origin} \u0628\u06D5\u0647\u0627\u06A9\u06D5 \u0646\u0627\u062F\u0631\u0648\u0633\u062A\u06D5`;
      default:
        return "\u062A\u06CE\u06A9\u0631\u062F\u06D5\u06CC \u0646\u0627\u062F\u0631\u0648\u0633\u062A";
    }
  };
}, "error");
function qs() {
  return {
    localeError: Zv()
  };
}
s(qs, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/cs.js
var Fv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "znak\u016F", verb: "m\xEDt" },
    file: { unit: "bajt\u016F", verb: "m\xEDt" },
    array: { unit: "prvk\u016F", verb: "m\xEDt" },
    set: { unit: "prvk\u016F", verb: "m\xEDt" },
    map: { unit: "prvk\u016F", verb: "m\xEDt" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "regul\xE1rn\xED v\xFDraz",
    email: "e-mailov\xE1 adresa",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "datum a \u010Das ve form\xE1tu ISO",
    date: "datum ve form\xE1tu ISO",
    time: "\u010Das ve form\xE1tu ISO",
    duration: "doba trv\xE1n\xED ISO",
    ipv4: "IPv4 adresa",
    ipv6: "IPv6 adresa",
    mac: "MAC adresa",
    cidrv4: "rozsah IPv4",
    cidrv6: "rozsah IPv6",
    base64: "\u0159et\u011Bzec zak\xF3dovan\xFD ve form\xE1tu base64",
    base64url: "\u0159et\u011Bzec zak\xF3dovan\xFD ve form\xE1tu base64url",
    json_string: "\u0159et\u011Bzec ve form\xE1tu JSON",
    e164: "\u010D\xEDslo E.164",
    credit_card: "\u010D\xEDslo kreditn\xED karty",
    jwt: "JWT",
    template_literal: "vstup"
  }, o = {
    nan: "NaN",
    number: "\u010D\xEDslo",
    string: "\u0159et\u011Bzec",
    function: "funkce",
    array: "pole"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `Neplatn\xFD vstup: o\u010Dek\xE1v\xE1no instanceof ${n.expected}, obdr\u017Eeno ${u}` : `Neplatn\xFD vstup: o\u010Dek\xE1v\xE1no ${i}, obdr\u017Eeno ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `Neplatn\xFD vstup: o\u010Dek\xE1v\xE1no ${$(n.values[0])}` : `Neplatn\xE1 mo\u017Enost: o\u010Dek\xE1v\xE1na jedna z hodnot ${m(n.values, "|")}`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin);
        return a ? `Hodnota je p\u0159\xEDli\u0161 velk\xE1: ${n.origin ?? "hodnota"} mus\xED m\xEDt ${i}${n.maximum.toString()} ${a.unit ?? "prvk\u016F"}` : `Hodnota je p\u0159\xEDli\u0161 velk\xE1: ${n.origin ?? "hodnota"} mus\xED b\xFDt ${i}${n.maximum.toString()}`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin);
        return a ? `Hodnota je p\u0159\xEDli\u0161 mal\xE1: ${n.origin ?? "hodnota"} mus\xED m\xEDt ${i}${n.minimum.toString()} ${a.unit ?? "prvk\u016F"}` : `Hodnota je p\u0159\xEDli\u0161 mal\xE1: ${n.origin ?? "hodnota"} mus\xED b\xFDt ${i}${n.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `Neplatn\xFD \u0159et\u011Bzec: mus\xED za\u010D\xEDnat na "${i.prefix}"` : i.format === "ends_with" ? `Neplatn\xFD \u0159et\u011Bzec: mus\xED kon\u010Dit na "${i.suffix}"` : i.format === "includes" ? `Neplatn\xFD \u0159et\u011Bzec: mus\xED obsahovat "${i.includes}"` : i.format === "regex" ? `Neplatn\xFD \u0159et\u011Bzec: mus\xED odpov\xEDdat vzoru ${i.pattern}` : `Neplatn\xFD form\xE1t ${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `Neplatn\xE9 \u010D\xEDslo: mus\xED b\xFDt n\xE1sobkem ${n.divisor}`;
      case "unrecognized_keys":
        return `Nezn\xE1m\xE9 kl\xED\u010De: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `Neplatn\xFD kl\xED\u010D v ${n.origin}`;
      case "invalid_union":
        return "Neplatn\xFD vstup";
      case "invalid_element":
        return `Neplatn\xE1 hodnota v ${n.origin}`;
      default:
        return "Neplatn\xFD vstup";
    }
  };
}, "error");
function Ws() {
  return {
    localeError: Fv()
  };
}
s(Ws, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/da.js
var Mv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "tegn", verb: "havde" },
    file: { unit: "bytes", verb: "havde" },
    array: { unit: "elementer", verb: "indeholdt" },
    set: { unit: "elementer", verb: "indeholdt" },
    map: { unit: "elementer", verb: "indeholdt" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "input",
    email: "e-mailadresse",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO dato- og klokkesl\xE6t",
    date: "ISO-dato",
    time: "ISO-klokkesl\xE6t",
    duration: "ISO-varighed",
    ipv4: "IPv4-adresse",
    ipv6: "IPv6-adresse",
    mac: "MAC-adresse",
    cidrv4: "IPv4-spektrum",
    cidrv6: "IPv6-spektrum",
    base64: "base64-kodet streng",
    base64url: "base64url-kodet streng",
    json_string: "JSON-streng",
    e164: "E.164-nummer",
    credit_card: "kreditkortnummer",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN",
    string: "streng",
    number: "tal",
    boolean: "boolean",
    array: "liste",
    object: "objekt",
    set: "s\xE6t",
    file: "fil"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `Ugyldigt input: forventede instanceof ${n.expected}, fik ${u}` : `Ugyldigt input: forventede ${i}, fik ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `Ugyldig v\xE6rdi: forventede ${$(n.values[0])}` : `Ugyldigt valg: forventede en af f\xF8lgende ${m(n.values, "|")}`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin), u = o[n.origin] ?? n.origin;
        return a ? `For stor: forventede ${u ?? "value"} ${a.verb} ${i} ${n.maximum.toString()} ${a.unit ?? "elementer"}` : `For stor: forventede ${u ?? "value"} havde ${i} ${n.maximum.toString()}`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin), u = o[n.origin] ?? n.origin;
        return a ? `For lille: forventede ${u} ${a.verb} ${i} ${n.minimum.toString()} ${a.unit}` : `For lille: forventede ${u} havde ${i} ${n.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `Ugyldig streng: skal starte med "${i.prefix}"` : i.format === "ends_with" ? `Ugyldig streng: skal ende med "${i.suffix}"` : i.format === "includes" ? `Ugyldig streng: skal indeholde "${i.includes}"` : i.format === "regex" ? `Ugyldig streng: skal matche m\xF8nsteret ${i.pattern}` : `Ugyldig ${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `Ugyldigt tal: skal v\xE6re deleligt med ${n.divisor}`;
      case "unrecognized_keys":
        return `${n.keys.length > 1 ? "Ukendte n\xF8gler" : "Ukendt n\xF8gle"}: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `Ugyldig n\xF8gle i ${n.origin}`;
      case "invalid_union":
        return "Ugyldigt input: matcher ingen af de tilladte typer";
      case "invalid_element":
        return `Ugyldig v\xE6rdi i ${n.origin}`;
      default:
        return "Ugyldigt input";
    }
  };
}, "error");
function Ks() {
  return {
    localeError: Mv()
  };
}
s(Ks, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/de.js
var Rv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "Zeichen", verb: "zu haben" },
    file: { unit: "Bytes", verb: "zu haben" },
    array: { unit: "Elemente", verb: "zu haben" },
    set: { unit: "Elemente", verb: "zu haben" },
    map: { unit: "Elemente", verb: "zu haben" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "Eingabe",
    email: "E-Mail-Adresse",
    url: "URL",
    emoji: "Emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO-Datum und -Uhrzeit",
    date: "ISO-Datum",
    time: "ISO-Uhrzeit",
    duration: "ISO-Dauer",
    ipv4: "IPv4-Adresse",
    ipv6: "IPv6-Adresse",
    mac: "MAC-Adresse",
    cidrv4: "IPv4-Bereich",
    cidrv6: "IPv6-Bereich",
    base64: "Base64-codierter String",
    base64url: "Base64-URL-codierter String",
    json_string: "JSON-String",
    e164: "E.164-Nummer",
    credit_card: "Kreditkartennummer",
    jwt: "JWT",
    template_literal: "Eingabe"
  }, o = {
    nan: "NaN",
    number: "Zahl",
    array: "Array"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `Ung\xFCltige Eingabe: erwartet instanceof ${n.expected}, erhalten ${u}` : `Ung\xFCltige Eingabe: erwartet ${i}, erhalten ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `Ung\xFCltige Eingabe: erwartet ${$(n.values[0])}` : `Ung\xFCltige Option: erwartet eine von ${m(n.values, "|")}`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin);
        return a ? `Zu gro\xDF: erwartet, dass ${n.origin ?? "Wert"} ${i}${n.maximum.toString()} ${a.unit ?? "Elemente"} hat` : `Zu gro\xDF: erwartet, dass ${n.origin ?? "Wert"} ${i}${n.maximum.toString()} ist`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin);
        return a ? `Zu klein: erwartet, dass ${n.origin} ${i}${n.minimum.toString()} ${a.unit} hat` : `Zu klein: erwartet, dass ${n.origin} ${i}${n.minimum.toString()} ist`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `Ung\xFCltiger String: muss mit "${i.prefix}" beginnen` : i.format === "ends_with" ? `Ung\xFCltiger String: muss mit "${i.suffix}" enden` : i.format === "includes" ? `Ung\xFCltiger String: muss "${i.includes}" enthalten` : i.format === "regex" ? `Ung\xFCltiger String: muss dem Muster ${i.pattern} entsprechen` : `Ung\xFCltig: ${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `Ung\xFCltige Zahl: muss ein Vielfaches von ${n.divisor} sein`;
      case "unrecognized_keys":
        return `${n.keys.length > 1 ? "Unbekannte Schl\xFCssel" : "Unbekannter Schl\xFCssel"}: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `Ung\xFCltiger Schl\xFCssel in ${n.origin}`;
      case "invalid_union":
        return "Ung\xFCltige Eingabe";
      case "invalid_element":
        return `Ung\xFCltiger Wert in ${n.origin}`;
      default:
        return "Ung\xFCltige Eingabe";
    }
  };
}, "error");
function Gs() {
  return {
    localeError: Rv()
  };
}
s(Gs, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/el.js
var Lv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u03C7\u03B1\u03C1\u03B1\u03BA\u03C4\u03AE\u03C1\u03B5\u03C2", verb: "\u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9" },
    file: { unit: "bytes", verb: "\u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9" },
    array: { unit: "\u03C3\u03C4\u03BF\u03B9\u03C7\u03B5\u03AF\u03B1", verb: "\u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9" },
    set: { unit: "\u03C3\u03C4\u03BF\u03B9\u03C7\u03B5\u03AF\u03B1", verb: "\u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9" },
    map: { unit: "\u03BA\u03B1\u03C4\u03B1\u03C7\u03C9\u03C1\u03AE\u03C3\u03B5\u03B9\u03C2", verb: "\u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "\u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2",
    email: "\u03B4\u03B9\u03B5\u03CD\u03B8\u03C5\u03BD\u03C3\u03B7 email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u03B7\u03BC\u03B5\u03C1\u03BF\u03BC\u03B7\u03BD\u03AF\u03B1 \u03BA\u03B1\u03B9 \u03CE\u03C1\u03B1",
    date: "ISO \u03B7\u03BC\u03B5\u03C1\u03BF\u03BC\u03B7\u03BD\u03AF\u03B1",
    time: "ISO \u03CE\u03C1\u03B1",
    duration: "ISO \u03B4\u03B9\u03AC\u03C1\u03BA\u03B5\u03B9\u03B1",
    ipv4: "\u03B4\u03B9\u03B5\u03CD\u03B8\u03C5\u03BD\u03C3\u03B7 IPv4",
    ipv6: "\u03B4\u03B9\u03B5\u03CD\u03B8\u03C5\u03BD\u03C3\u03B7 IPv6",
    mac: "\u03B4\u03B9\u03B5\u03CD\u03B8\u03C5\u03BD\u03C3\u03B7 MAC",
    cidrv4: "\u03B5\u03CD\u03C1\u03BF\u03C2 IPv4",
    cidrv6: "\u03B5\u03CD\u03C1\u03BF\u03C2 IPv6",
    base64: "\u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC \u03BA\u03C9\u03B4\u03B9\u03BA\u03BF\u03C0\u03BF\u03B9\u03B7\u03BC\u03AD\u03BD\u03B7 \u03C3\u03B5 base64",
    base64url: "\u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC \u03BA\u03C9\u03B4\u03B9\u03BA\u03BF\u03C0\u03BF\u03B9\u03B7\u03BC\u03AD\u03BD\u03B7 \u03C3\u03B5 base64url",
    json_string: "\u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC JSON",
    e164: "\u03B1\u03C1\u03B9\u03B8\u03BC\u03CC\u03C2 E.164",
    credit_card: "\u03B1\u03C1\u03B9\u03B8\u03BC\u03CC\u03C2 \u03C0\u03B9\u03C3\u03C4\u03C9\u03C4\u03B9\u03BA\u03AE\u03C2 \u03BA\u03AC\u03C1\u03C4\u03B1\u03C2",
    jwt: "JWT",
    template_literal: "\u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2"
  }, o = {
    nan: "NaN"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return typeof n.expected == "string" && /^[A-Z]/.test(n.expected) ? `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD instanceof ${n.expected}, \u03BB\u03AE\u03C6\u03B8\u03B7\u03BA\u03B5 ${u}` : `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${i}, \u03BB\u03AE\u03C6\u03B8\u03B7\u03BA\u03B5 ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${$(n.values[0])}` : `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03C0\u03B9\u03BB\u03BF\u03B3\u03AE: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD \u03AD\u03BD\u03B1 \u03B1\u03C0\u03CC ${m(n.values, "|")}`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin);
        return a ? `\u03A0\u03BF\u03BB\u03CD \u03BC\u03B5\u03B3\u03AC\u03BB\u03BF: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${n.origin ?? "\u03C4\u03B9\u03BC\u03AE"} \u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9 ${i}${n.maximum.toString()} ${a.unit ?? "\u03C3\u03C4\u03BF\u03B9\u03C7\u03B5\u03AF\u03B1"}` : `\u03A0\u03BF\u03BB\u03CD \u03BC\u03B5\u03B3\u03AC\u03BB\u03BF: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${n.origin ?? "\u03C4\u03B9\u03BC\u03AE"} \u03BD\u03B1 \u03B5\u03AF\u03BD\u03B1\u03B9 ${i}${n.maximum.toString()}`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin);
        return a ? `\u03A0\u03BF\u03BB\u03CD \u03BC\u03B9\u03BA\u03C1\u03CC: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${n.origin} \u03BD\u03B1 \u03AD\u03C7\u03B5\u03B9 ${i}${n.minimum.toString()} ${a.unit}` : `\u03A0\u03BF\u03BB\u03CD \u03BC\u03B9\u03BA\u03C1\u03CC: \u03B1\u03BD\u03B1\u03BC\u03B5\u03BD\u03CC\u03C4\u03B1\u03BD ${n.origin} \u03BD\u03B1 \u03B5\u03AF\u03BD\u03B1\u03B9 ${i}${n.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC: \u03C0\u03C1\u03AD\u03C0\u03B5\u03B9 \u03BD\u03B1 \u03BE\u03B5\u03BA\u03B9\u03BD\u03AC \u03BC\u03B5 "${i.prefix}"` : i.format === "ends_with" ? `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC: \u03C0\u03C1\u03AD\u03C0\u03B5\u03B9 \u03BD\u03B1 \u03C4\u03B5\u03BB\u03B5\u03B9\u03CE\u03BD\u03B5\u03B9 \u03BC\u03B5 "${i.suffix}"` : i.format === "includes" ? `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC: \u03C0\u03C1\u03AD\u03C0\u03B5\u03B9 \u03BD\u03B1 \u03C0\u03B5\u03C1\u03B9\u03AD\u03C7\u03B5\u03B9 "${i.includes}"` : i.format === "regex" ? `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03C3\u03C5\u03BC\u03B2\u03BF\u03BB\u03BF\u03C3\u03B5\u03B9\u03C1\u03AC: \u03C0\u03C1\u03AD\u03C0\u03B5\u03B9 \u03BD\u03B1 \u03C4\u03B1\u03B9\u03C1\u03B9\u03AC\u03B6\u03B5\u03B9 \u03BC\u03B5 \u03C4\u03BF \u03BC\u03BF\u03C4\u03AF\u03B2\u03BF ${i.pattern}` : `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03BF: ${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03BF\u03C2 \u03B1\u03C1\u03B9\u03B8\u03BC\u03CC\u03C2: \u03C0\u03C1\u03AD\u03C0\u03B5\u03B9 \u03BD\u03B1 \u03B5\u03AF\u03BD\u03B1\u03B9 \u03C0\u03BF\u03BB\u03BB\u03B1\u03C0\u03BB\u03AC\u03C3\u03B9\u03BF \u03C4\u03BF\u03C5 ${n.divisor}`;
      case "unrecognized_keys":
        return `\u0386\u03B3\u03BD\u03C9\u03C3\u03C4${n.keys.length > 1 ? "\u03B1" : "\u03BF"} \u03BA\u03BB\u03B5\u03B9\u03B4${n.keys.length > 1 ? "\u03B9\u03AC" : "\u03AF"}: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03BF \u03BA\u03BB\u03B5\u03B9\u03B4\u03AF \u03C3\u03C4\u03BF ${n.origin}`;
      case "invalid_union":
        return "\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2";
      case "invalid_element":
        return `\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03C4\u03B9\u03BC\u03AE \u03C3\u03C4\u03BF ${n.origin}`;
      default:
        return "\u039C\u03B7 \u03AD\u03B3\u03BA\u03C5\u03C1\u03B7 \u03B5\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2";
    }
  };
}, "error");
function Xs() {
  return {
    localeError: Lv()
  };
}
s(Xs, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/en.js
var Vv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "characters", verb: "to have" },
    file: { unit: "bytes", verb: "to have" },
    array: { unit: "items", verb: "to have" },
    set: { unit: "items", verb: "to have" },
    map: { unit: "entries", verb: "to have" }
  };
  function t(i) {
    return e[i] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "input",
    email: "email address",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datetime",
    date: "ISO date",
    time: "ISO time",
    duration: "ISO duration",
    ipv4: "IPv4 address",
    ipv6: "IPv6 address",
    mac: "MAC address",
    cidrv4: "IPv4 range",
    cidrv6: "IPv6 range",
    base64: "base64-encoded string",
    base64url: "base64url-encoded string",
    json_string: "JSON string",
    e164: "E.164 number",
    credit_card: "credit card number",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    // Compatibility: "nan" -> "NaN" for display
    nan: "NaN"
    // All other type names omitted - they fall back to raw values via ?? operator
  };
  function n(i, a) {
    return i === "number" && typeof a == "number" && !Number.isFinite(a) ? String(a) : o[i] ?? i;
  }
  return s(n, "getTypeName"), (i) => {
    switch (i.code) {
      case "invalid_type": {
        let a = n(i.expected), u = b(i.input), c = n(u, i.input);
        return `Invalid input: expected ${a}, received ${c}`;
      }
      case "invalid_value":
        return i.values.length === 1 ? `Invalid input: expected ${$(i.values[0])}` : `Invalid option: expected one of ${m(i.values, "|")}`;
      case "too_big": {
        let a = i.exact ? "exactly " : i.inclusive ? "<=" : "<", u = t(i.origin);
        return u ? `Too big: expected ${i.origin ?? "value"} to have ${a}${i.maximum.toString()} ${u.unit ?? "elements"}` : `Too big: expected ${i.origin ?? "value"} to be ${a}${i.maximum.toString()}`;
      }
      case "too_small": {
        let a = i.exact ? "exactly " : i.inclusive ? ">=" : ">", u = t(i.origin);
        return u ? `Too small: expected ${i.origin} to have ${a}${i.minimum.toString()} ${u.unit}` : `Too small: expected ${i.origin} to be ${a}${i.minimum.toString()}`;
      }
      case "invalid_format": {
        let a = i;
        return a.format === "starts_with" ? `Invalid string: must start with "${a.prefix}"` : a.format === "ends_with" ? `Invalid string: must end with "${a.suffix}"` : a.format === "includes" ? `Invalid string: must include "${a.includes}"` : a.format === "regex" ? `Invalid string: must match pattern ${a.pattern}` : `Invalid ${r[a.format] ?? i.format}`;
      }
      case "not_multiple_of":
        return `Invalid number: must be a multiple of ${i.divisor}`;
      case "unrecognized_keys":
        return `Unrecognized key${i.keys.length > 1 ? "s" : ""}: ${m(i.keys, ", ")}`;
      case "invalid_key":
        return `Invalid key in ${i.origin}`;
      case "invalid_union":
        return i.options && Array.isArray(i.options) && i.options.length > 0 ? `Invalid discriminator value. Expected ${i.options.map((u) => `'${u}'`).join(" | ")}` : i.inclusive === !1 ? "Invalid input: more than one option matched" : "Invalid input";
      case "invalid_element":
        return `Invalid value in ${i.origin}`;
      default:
        return "Invalid input";
    }
  };
}, "error");
function Hs() {
  return {
    localeError: Vv()
  };
}
s(Hs, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/eo.js
var Bv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "karaktrojn", verb: "havi" },
    file: { unit: "bajtojn", verb: "havi" },
    array: { unit: "elementojn", verb: "havi" },
    set: { unit: "elementojn", verb: "havi" },
    map: { unit: "elementojn", verb: "havi" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "enigo",
    email: "retadreso",
    url: "URL",
    emoji: "emo\u011Dio",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO-datotempo",
    date: "ISO-dato",
    time: "ISO-tempo",
    duration: "ISO-da\u016Dro",
    ipv4: "IPv4-adreso",
    ipv6: "IPv6-adreso",
    mac: "MAC-adreso",
    cidrv4: "IPv4-rango",
    cidrv6: "IPv6-rango",
    base64: "64-ume kodita karaktraro",
    base64url: "URL-64-ume kodita karaktraro",
    json_string: "JSON-karaktraro",
    e164: "E.164-nombro",
    credit_card: "kreditkarta numero",
    jwt: "JWT",
    template_literal: "enigo"
  }, o = {
    nan: "NaN",
    number: "nombro",
    array: "tabelo",
    null: "senvalora"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `Nevalida enigo: atendi\u011Dis instanceof ${n.expected}, ricevi\u011Dis ${u}` : `Nevalida enigo: atendi\u011Dis ${i}, ricevi\u011Dis ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `Nevalida enigo: atendi\u011Dis ${$(n.values[0])}` : `Nevalida opcio: atendi\u011Dis unu el ${m(n.values, "|")}`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin);
        return a ? `Tro granda: atendi\u011Dis ke ${n.origin ?? "valoro"} havu ${i}${n.maximum.toString()} ${a.unit ?? "elementojn"}` : `Tro granda: atendi\u011Dis ke ${n.origin ?? "valoro"} havu ${i}${n.maximum.toString()}`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin);
        return a ? `Tro malgranda: atendi\u011Dis ke ${n.origin} havu ${i}${n.minimum.toString()} ${a.unit}` : `Tro malgranda: atendi\u011Dis ke ${n.origin} estu ${i}${n.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `Nevalida karaktraro: devas komenci\u011Di per "${i.prefix}"` : i.format === "ends_with" ? `Nevalida karaktraro: devas fini\u011Di per "${i.suffix}"` : i.format === "includes" ? `Nevalida karaktraro: devas inkluzivi "${i.includes}"` : i.format === "regex" ? `Nevalida karaktraro: devas kongrui kun la modelo ${i.pattern}` : `Nevalida ${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `Nevalida nombro: devas esti oblo de ${n.divisor}`;
      case "unrecognized_keys":
        return `Nekonata${n.keys.length > 1 ? "j" : ""} \u015Dlosilo${n.keys.length > 1 ? "j" : ""}: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `Nevalida \u015Dlosilo en ${n.origin}`;
      case "invalid_union":
        return "Nevalida enigo";
      case "invalid_element":
        return `Nevalida valoro en ${n.origin}`;
      default:
        return "Nevalida enigo";
    }
  };
}, "error");
function Qs() {
  return {
    localeError: Bv()
  };
}
s(Qs, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/es.js
var Jv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "caracteres", verb: "tener" },
    file: { unit: "bytes", verb: "tener" },
    array: { unit: "elementos", verb: "tener" },
    set: { unit: "elementos", verb: "tener" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "entrada",
    email: "direcci\xF3n de correo electr\xF3nico",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "fecha y hora ISO",
    date: "fecha ISO",
    time: "hora ISO",
    duration: "duraci\xF3n ISO",
    ipv4: "direcci\xF3n IPv4",
    ipv6: "direcci\xF3n IPv6",
    mac: "direcci\xF3n MAC",
    cidrv4: "rango IPv4",
    cidrv6: "rango IPv6",
    base64: "cadena codificada en base64",
    base64url: "URL codificada en base64",
    json_string: "cadena JSON",
    e164: "n\xFAmero E.164",
    credit_card: "n\xFAmero de tarjeta de cr\xE9dito",
    jwt: "JWT",
    template_literal: "entrada"
  }, o = {
    nan: "NaN",
    string: "texto",
    number: "n\xFAmero",
    boolean: "booleano",
    array: "arreglo",
    object: "objeto",
    set: "conjunto",
    file: "archivo",
    date: "fecha",
    bigint: "n\xFAmero grande",
    symbol: "s\xEDmbolo",
    undefined: "indefinido",
    null: "nulo",
    function: "funci\xF3n",
    map: "mapa",
    record: "registro",
    tuple: "tupla",
    enum: "enumeraci\xF3n",
    union: "uni\xF3n",
    literal: "literal",
    promise: "promesa",
    void: "vac\xEDo",
    never: "nunca",
    unknown: "desconocido",
    any: "cualquiera"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `Entrada inv\xE1lida: se esperaba instanceof ${n.expected}, recibido ${u}` : `Entrada inv\xE1lida: se esperaba ${i}, recibido ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `Entrada inv\xE1lida: se esperaba ${$(n.values[0])}` : `Opci\xF3n inv\xE1lida: se esperaba una de ${m(n.values, "|")}`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin), u = o[n.origin] ?? n.origin;
        return a ? `Demasiado grande: se esperaba que ${u ?? "valor"} tuviera ${i}${n.maximum.toString()} ${a.unit ?? "elementos"}` : `Demasiado grande: se esperaba que ${u ?? "valor"} fuera ${i}${n.maximum.toString()}`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin), u = o[n.origin] ?? n.origin;
        return a ? `Demasiado peque\xF1o: se esperaba que ${u} tuviera ${i}${n.minimum.toString()} ${a.unit}` : `Demasiado peque\xF1o: se esperaba que ${u} fuera ${i}${n.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `Cadena inv\xE1lida: debe comenzar con "${i.prefix}"` : i.format === "ends_with" ? `Cadena inv\xE1lida: debe terminar en "${i.suffix}"` : i.format === "includes" ? `Cadena inv\xE1lida: debe incluir "${i.includes}"` : i.format === "regex" ? `Cadena inv\xE1lida: debe coincidir con el patr\xF3n ${i.pattern}` : `Inv\xE1lido ${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `N\xFAmero inv\xE1lido: debe ser m\xFAltiplo de ${n.divisor}`;
      case "unrecognized_keys":
        return `Llave${n.keys.length > 1 ? "s" : ""} desconocida${n.keys.length > 1 ? "s" : ""}: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `Llave inv\xE1lida en ${o[n.origin] ?? n.origin}`;
      case "invalid_union":
        return "Entrada inv\xE1lida";
      case "invalid_element":
        return `Valor inv\xE1lido en ${o[n.origin] ?? n.origin}`;
      default:
        return "Entrada inv\xE1lida";
    }
  };
}, "error");
function Ys() {
  return {
    localeError: Jv()
  };
}
s(Ys, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/fa.js
var qv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u06A9\u0627\u0631\u0627\u06A9\u062A\u0631", verb: "\u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F" },
    file: { unit: "\u0628\u0627\u06CC\u062A", verb: "\u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F" },
    array: { unit: "\u0622\u06CC\u062A\u0645", verb: "\u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F" },
    set: { unit: "\u0622\u06CC\u062A\u0645", verb: "\u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F" },
    map: { unit: "\u0622\u06CC\u062A\u0645", verb: "\u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "\u0648\u0631\u0648\u062F\u06CC",
    email: "\u0622\u062F\u0631\u0633 \u0627\u06CC\u0645\u06CC\u0644",
    url: "URL",
    emoji: "\u0627\u06CC\u0645\u0648\u062C\u06CC",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u062A\u0627\u0631\u06CC\u062E \u0648 \u0632\u0645\u0627\u0646 \u0627\u06CC\u0632\u0648",
    date: "\u062A\u0627\u0631\u06CC\u062E \u0627\u06CC\u0632\u0648",
    time: "\u0632\u0645\u0627\u0646 \u0627\u06CC\u0632\u0648",
    duration: "\u0645\u062F\u062A \u0632\u0645\u0627\u0646 \u0627\u06CC\u0632\u0648",
    ipv4: "IPv4 \u0622\u062F\u0631\u0633",
    ipv6: "IPv6 \u0622\u062F\u0631\u0633",
    mac: "MAC \u0622\u062F\u0631\u0633",
    cidrv4: "IPv4 \u062F\u0627\u0645\u0646\u0647",
    cidrv6: "IPv6 \u062F\u0627\u0645\u0646\u0647",
    base64: "base64-encoded \u0631\u0634\u062A\u0647",
    base64url: "base64url-encoded \u0631\u0634\u062A\u0647",
    json_string: "JSON \u0631\u0634\u062A\u0647",
    e164: "E.164 \u0639\u062F\u062F",
    credit_card: "\u0634\u0645\u0627\u0631\u0647 \u06A9\u0627\u0631\u062A \u0627\u0639\u062A\u0628\u0627\u0631\u06CC",
    jwt: "JWT",
    template_literal: "\u0648\u0631\u0648\u062F\u06CC"
  }, o = {
    nan: "NaN",
    number: "\u0639\u062F\u062F",
    array: "\u0622\u0631\u0627\u06CC\u0647"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0645\u06CC\u200C\u0628\u0627\u06CC\u0633\u062A instanceof ${n.expected} \u0645\u06CC\u200C\u0628\u0648\u062F\u060C ${u} \u062F\u0631\u06CC\u0627\u0641\u062A \u0634\u062F` : `\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0645\u06CC\u200C\u0628\u0627\u06CC\u0633\u062A ${i} \u0645\u06CC\u200C\u0628\u0648\u062F\u060C ${u} \u062F\u0631\u06CC\u0627\u0641\u062A \u0634\u062F`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0645\u06CC\u200C\u0628\u0627\u06CC\u0633\u062A ${$(n.values[0])} \u0645\u06CC\u200C\u0628\u0648\u062F` : `\u06AF\u0632\u06CC\u0646\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0645\u06CC\u200C\u0628\u0627\u06CC\u0633\u062A \u06CC\u06A9\u06CC \u0627\u0632 ${m(n.values, "|")} \u0645\u06CC\u200C\u0628\u0648\u062F`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin);
        return a ? `\u062E\u06CC\u0644\u06CC \u0628\u0632\u0631\u06AF: ${n.origin ?? "\u0645\u0642\u062F\u0627\u0631"} \u0628\u0627\u06CC\u062F ${i}${n.maximum.toString()} ${a.unit ?? "\u0639\u0646\u0635\u0631"} \u0628\u0627\u0634\u062F` : `\u062E\u06CC\u0644\u06CC \u0628\u0632\u0631\u06AF: ${n.origin ?? "\u0645\u0642\u062F\u0627\u0631"} \u0628\u0627\u06CC\u062F ${i}${n.maximum.toString()} \u0628\u0627\u0634\u062F`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin);
        return a ? `\u062E\u06CC\u0644\u06CC \u06A9\u0648\u0686\u06A9: ${n.origin} \u0628\u0627\u06CC\u062F ${i}${n.minimum.toString()} ${a.unit} \u0628\u0627\u0634\u062F` : `\u062E\u06CC\u0644\u06CC \u06A9\u0648\u0686\u06A9: ${n.origin} \u0628\u0627\u06CC\u062F ${i}${n.minimum.toString()} \u0628\u0627\u0634\u062F`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `\u0631\u0634\u062A\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0628\u0627 "${i.prefix}" \u0634\u0631\u0648\u0639 \u0634\u0648\u062F` : i.format === "ends_with" ? `\u0631\u0634\u062A\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0628\u0627 "${i.suffix}" \u062A\u0645\u0627\u0645 \u0634\u0648\u062F` : i.format === "includes" ? `\u0631\u0634\u062A\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0634\u0627\u0645\u0644 "${i.includes}" \u0628\u0627\u0634\u062F` : i.format === "regex" ? `\u0631\u0634\u062A\u0647 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0628\u0627 \u0627\u0644\u06AF\u0648\u06CC ${i.pattern} \u0645\u0637\u0627\u0628\u0642\u062A \u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F` : `${r[i.format] ?? n.format} \u0646\u0627\u0645\u0639\u062A\u0628\u0631`;
      }
      case "not_multiple_of":
        return `\u0639\u062F\u062F \u0646\u0627\u0645\u0639\u062A\u0628\u0631: \u0628\u0627\u06CC\u062F \u0645\u0636\u0631\u0628 ${n.divisor} \u0628\u0627\u0634\u062F`;
      case "unrecognized_keys":
        return `\u06A9\u0644\u06CC\u062F${n.keys.length > 1 ? "\u0647\u0627\u06CC" : ""} \u0646\u0627\u0634\u0646\u0627\u0633: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `\u06A9\u0644\u06CC\u062F \u0646\u0627\u0634\u0646\u0627\u0633 \u062F\u0631 ${n.origin}`;
      case "invalid_union":
        return "\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631";
      case "invalid_element":
        return `\u0645\u0642\u062F\u0627\u0631 \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u062F\u0631 ${n.origin}`;
      default:
        return "\u0648\u0631\u0648\u062F\u06CC \u0646\u0627\u0645\u0639\u062A\u0628\u0631";
    }
  };
}, "error");
function eu() {
  return {
    localeError: qv()
  };
}
s(eu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/fi.js
var Wv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "merkki\xE4", subject: "merkkijonon" },
    file: { unit: "tavua", subject: "tiedoston" },
    array: { unit: "alkiota", subject: "listan" },
    set: { unit: "alkiota", subject: "joukon" },
    map: { unit: "alkiota", subject: "kuvauksen" },
    number: { unit: "", subject: "luvun" },
    bigint: { unit: "", subject: "suuren kokonaisluvun" },
    int: { unit: "", subject: "kokonaisluvun" },
    date: { unit: "", subject: "p\xE4iv\xE4m\xE4\xE4r\xE4n" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "s\xE4\xE4nn\xF6llinen lauseke",
    email: "s\xE4hk\xF6postiosoite",
    url: "URL-osoite",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO-aikaleima",
    date: "ISO-p\xE4iv\xE4m\xE4\xE4r\xE4",
    time: "ISO-aika",
    duration: "ISO-kesto",
    ipv4: "IPv4-osoite",
    ipv6: "IPv6-osoite",
    mac: "MAC-osoite",
    cidrv4: "IPv4-alue",
    cidrv6: "IPv6-alue",
    base64: "base64-koodattu merkkijono",
    base64url: "base64url-koodattu merkkijono",
    json_string: "JSON-merkkijono",
    e164: "E.164-luku",
    credit_card: "luottokortin numero",
    jwt: "JWT",
    template_literal: "templaattimerkkijono"
  }, o = {
    nan: "NaN"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `Virheellinen tyyppi: odotettiin instanceof ${n.expected}, oli ${u}` : `Virheellinen tyyppi: odotettiin ${i}, oli ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `Virheellinen sy\xF6te: t\xE4ytyy olla ${$(n.values[0])}` : `Virheellinen valinta: t\xE4ytyy olla yksi seuraavista: ${m(n.values, "|")}`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin);
        return a ? `Liian suuri: ${a.subject} t\xE4ytyy olla ${i}${n.maximum.toString()} ${a.unit}`.trim() : `Liian suuri: arvon t\xE4ytyy olla ${i}${n.maximum.toString()}`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin);
        return a ? `Liian pieni: ${a.subject} t\xE4ytyy olla ${i}${n.minimum.toString()} ${a.unit}`.trim() : `Liian pieni: arvon t\xE4ytyy olla ${i}${n.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `Virheellinen sy\xF6te: t\xE4ytyy alkaa "${i.prefix}"` : i.format === "ends_with" ? `Virheellinen sy\xF6te: t\xE4ytyy loppua "${i.suffix}"` : i.format === "includes" ? `Virheellinen sy\xF6te: t\xE4ytyy sis\xE4lt\xE4\xE4 "${i.includes}"` : i.format === "regex" ? `Virheellinen sy\xF6te: t\xE4ytyy vastata s\xE4\xE4nn\xF6llist\xE4 lauseketta ${i.pattern}` : `Virheellinen ${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `Virheellinen luku: t\xE4ytyy olla luvun ${n.divisor} monikerta`;
      case "unrecognized_keys":
        return `${n.keys.length > 1 ? "Tuntemattomat avaimet" : "Tuntematon avain"}: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return "Virheellinen avain tietueessa";
      case "invalid_union":
        return "Virheellinen unioni";
      case "invalid_element":
        return "Virheellinen arvo joukossa";
      default:
        return "Virheellinen sy\xF6te";
    }
  };
}, "error");
function tu() {
  return {
    localeError: Wv()
  };
}
s(tu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/fr.js
var Kv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "caract\xE8res", verb: "avoir" },
    file: { unit: "octets", verb: "avoir" },
    array: { unit: "\xE9l\xE9ments", verb: "avoir" },
    set: { unit: "\xE9l\xE9ments", verb: "avoir" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "expression r\xE9guli\xE8re",
    email: "adresse e-mail",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "date et heure ISO",
    date: "date ISO",
    time: "heure ISO",
    duration: "dur\xE9e ISO",
    ipv4: "adresse IPv4",
    ipv6: "adresse IPv6",
    mac: "adresse MAC",
    cidrv4: "plage IPv4",
    cidrv6: "plage IPv6",
    base64: "cha\xEEne de caract\xE8res encod\xE9e en base64",
    base64url: "cha\xEEne de caract\xE8res encod\xE9e en base64url",
    json_string: "cha\xEEne de caract\xE8res JSON",
    e164: "num\xE9ro au format E.164",
    credit_card: "num\xE9ro de carte de cr\xE9dit",
    jwt: "JWT",
    template_literal: "entr\xE9e"
  }, o = {
    string: "cha\xEEne de caract\xE8res",
    number: "nombre",
    int: "entier",
    boolean: "bool\xE9en",
    bigint: "grand entier",
    symbol: "symbole",
    undefined: "ind\xE9fini",
    null: "null",
    never: "jamais",
    void: "vide",
    date: "date",
    array: "tableau",
    object: "objet",
    tuple: "tuple",
    record: "record",
    map: "map",
    set: "ensemble",
    file: "fichier",
    nonoptional: "non optionnel",
    nan: "NaN",
    function: "fonction"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `Entr\xE9e invalide : instance de ${n.expected} attendu, ${u} re\xE7u` : `Entr\xE9e invalide : ${i} attendu, ${u} re\xE7u`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `Entr\xE9e invalide : ${$(n.values[0])} attendu` : `Option invalide : une valeur parmi ${m(n.values, "|")} attendue`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin);
        return a ? `Trop grand : ${o[n.origin] ?? "valeur"} doit ${a.verb} ${i}${n.maximum.toString()} ${a.unit ?? "\xE9l\xE9ment(s)"}` : `Trop grand : ${o[n.origin] ?? "valeur"} doit \xEAtre ${i}${n.maximum.toString()}`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin);
        return a ? `Trop petit : ${o[n.origin] ?? "valeur"} doit ${a.verb} ${i}${n.minimum.toString()} ${a.unit}` : `Trop petit : ${o[n.origin] ?? "valeur"} doit \xEAtre ${i}${n.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `Cha\xEEne de caract\xE8res invalide : doit commencer par "${i.prefix}"` : i.format === "ends_with" ? `Cha\xEEne de caract\xE8res invalide : doit se terminer par "${i.suffix}"` : i.format === "includes" ? `Cha\xEEne de caract\xE8res invalide : doit inclure "${i.includes}"` : i.format === "regex" ? `Cha\xEEne de caract\xE8res invalide : doit correspondre au motif ${i.pattern}` : `${r[i.format] ?? n.format} invalide`;
      }
      case "not_multiple_of":
        return `Nombre invalide : doit \xEAtre un multiple de ${n.divisor}`;
      case "unrecognized_keys":
        return `Cl\xE9${n.keys.length > 1 ? "s" : ""} non reconnue${n.keys.length > 1 ? "s" : ""} : ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `Cl\xE9 invalide dans ${n.origin}`;
      case "invalid_union":
        return "Entr\xE9e invalide";
      case "invalid_element":
        return `Valeur invalide dans ${n.origin}`;
      default:
        return "Entr\xE9e invalide";
    }
  };
}, "error");
function nu() {
  return {
    localeError: Kv()
  };
}
s(nu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/fr-CA.js
var Gv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "caract\xE8res", verb: "avoir" },
    file: { unit: "octets", verb: "avoir" },
    array: { unit: "\xE9l\xE9ments", verb: "avoir" },
    set: { unit: "\xE9l\xE9ments", verb: "avoir" },
    map: { unit: "\xE9l\xE9ments", verb: "avoir" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "entr\xE9e",
    email: "adresse courriel",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "date-heure ISO",
    date: "date ISO",
    time: "heure ISO",
    duration: "dur\xE9e ISO",
    ipv4: "adresse IPv4",
    ipv6: "adresse IPv6",
    mac: "adresse MAC",
    cidrv4: "plage IPv4",
    cidrv6: "plage IPv6",
    base64: "cha\xEEne encod\xE9e en base64",
    base64url: "cha\xEEne encod\xE9e en base64url",
    json_string: "cha\xEEne JSON",
    e164: "num\xE9ro E.164",
    credit_card: "num\xE9ro de carte de cr\xE9dit",
    jwt: "JWT",
    template_literal: "entr\xE9e"
  }, o = {
    nan: "NaN"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `Entr\xE9e invalide : attendu instanceof ${n.expected}, re\xE7u ${u}` : `Entr\xE9e invalide : attendu ${i}, re\xE7u ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `Entr\xE9e invalide : attendu ${$(n.values[0])}` : `Option invalide : attendu l'une des valeurs suivantes ${m(n.values, "|")}`;
      case "too_big": {
        let i = n.inclusive ? "\u2264" : "<", a = t(n.origin);
        return a ? `Trop grand : attendu que ${n.origin ?? "la valeur"} ait ${i}${n.maximum.toString()} ${a.unit}` : `Trop grand : attendu que ${n.origin ?? "la valeur"} soit ${i}${n.maximum.toString()}`;
      }
      case "too_small": {
        let i = n.inclusive ? "\u2265" : ">", a = t(n.origin);
        return a ? `Trop petit : attendu que ${n.origin} ait ${i}${n.minimum.toString()} ${a.unit}` : `Trop petit : attendu que ${n.origin} soit ${i}${n.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `Cha\xEEne invalide : doit commencer par "${i.prefix}"` : i.format === "ends_with" ? `Cha\xEEne invalide : doit se terminer par "${i.suffix}"` : i.format === "includes" ? `Cha\xEEne invalide : doit inclure "${i.includes}"` : i.format === "regex" ? `Cha\xEEne invalide : doit correspondre au motif ${i.pattern}` : `${r[i.format] ?? n.format} invalide`;
      }
      case "not_multiple_of":
        return `Nombre invalide : doit \xEAtre un multiple de ${n.divisor}`;
      case "unrecognized_keys":
        return `Cl\xE9${n.keys.length > 1 ? "s" : ""} non reconnue${n.keys.length > 1 ? "s" : ""} : ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `Cl\xE9 invalide dans ${n.origin}`;
      case "invalid_union":
        return "Entr\xE9e invalide";
      case "invalid_element":
        return `Valeur invalide dans ${n.origin}`;
      default:
        return "Entr\xE9e invalide";
    }
  };
}, "error");
function ru() {
  return {
    localeError: Gv()
  };
}
s(ru, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/gu.js
var Xv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0A85\u0A95\u0ACD\u0AB7\u0AB0", verb: "\u0AB9\u0ACB\u0AB5\u0ABE \u0A9C\u0ACB\u0A88\u0A8F" },
    file: { unit: "\u0AAC\u0ABE\u0AAF\u0A9F", verb: "\u0AB9\u0ACB\u0AB5\u0ABE \u0A9C\u0ACB\u0A88\u0A8F" },
    array: { unit: "\u0A86\u0A87\u0A9F\u0AAE", verb: "\u0AB9\u0ACB\u0AB5\u0ABE \u0A9C\u0ACB\u0A88\u0A8F" },
    set: { unit: "\u0A86\u0A87\u0A9F\u0AAE", verb: "\u0AB9\u0ACB\u0AB5\u0ABE \u0A9C\u0ACB\u0A88\u0A8F" },
    map: { unit: "\u0A8F\u0AA8\u0ACD\u0A9F\u0ACD\u0AB0\u0AC0", verb: "\u0AB9\u0ACB\u0AB5\u0ABE \u0A9C\u0ACB\u0A88\u0A8F" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "\u0A87\u0AA8\u0AAA\u0AC1\u0A9F",
    email: "\u0A88\u0AAE\u0AC7\u0A87\u0AB2 \u0A8F\u0AA1\u0ACD\u0AB0\u0AC7\u0AB8",
    url: "URL",
    emoji: "\u0A87\u0AAE\u0ACB\u0A9C\u0AC0",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0AA4\u0ABE\u0AB0\u0AC0\u0A96 \u0A85\u0AA8\u0AC7 \u0AB8\u0AAE\u0AAF",
    date: "ISO \u0AA4\u0ABE\u0AB0\u0AC0\u0A96",
    time: "ISO \u0AB8\u0AAE\u0AAF",
    duration: "ISO \u0A85\u0AB5\u0AA7\u0ABF",
    ipv4: "IPv4 \u0A8F\u0AA1\u0ACD\u0AB0\u0AC7\u0AB8",
    ipv6: "IPv6 \u0A8F\u0AA1\u0ACD\u0AB0\u0AC7\u0AB8",
    mac: "MAC \u0A8F\u0AA1\u0ACD\u0AB0\u0AC7\u0AB8",
    cidrv4: "IPv4 \u0AB6\u0ACD\u0AB0\u0AC7\u0AA3\u0AC0",
    cidrv6: "IPv6 \u0AB6\u0ACD\u0AB0\u0AC7\u0AA3\u0AC0",
    base64: "base64-\u0A8F\u0AA8\u0ACD\u0A95\u0ACB\u0AA1\u0AC7\u0AA1 \u0AB8\u0ACD\u0A9F\u0ACD\u0AB0\u0ABF\u0A82\u0A97",
    base64url: "base64url-\u0A8F\u0AA8\u0ACD\u0A95\u0ACB\u0AA1\u0AC7\u0AA1 \u0AB8\u0ACD\u0A9F\u0ACD\u0AB0\u0ABF\u0A82\u0A97",
    json_string: "JSON \u0AB8\u0ACD\u0A9F\u0ACD\u0AB0\u0ABF\u0A82\u0A97",
    e164: "E.164 \u0AA8\u0A82\u0AAC\u0AB0",
    credit_card: "\u0A95\u0ACD\u0AB0\u0AC7\u0AA1\u0ABF\u0A9F \u0A95\u0ABE\u0AB0\u0ACD\u0AA1 \u0AA8\u0A82\u0AAC\u0AB0",
    jwt: "JWT",
    template_literal: "\u0A87\u0AA8\u0AAA\u0AC1\u0A9F"
  }, o = {
    nan: "NaN"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0A87\u0AA8\u0AAA\u0AC1\u0A9F: \u0A85\u0AAA\u0AC7\u0A95\u0ACD\u0AB7\u0ABF\u0AA4 ${i}, \u0AAA\u0ACD\u0AB0\u0ABE\u0AAA\u0ACD\u0AA4 ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0A87\u0AA8\u0AAA\u0AC1\u0A9F: \u0A85\u0AAA\u0AC7\u0A95\u0ACD\u0AB7\u0ABF\u0AA4 ${$(n.values[0])}` : `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AB5\u0ABF\u0A95\u0AB2\u0ACD\u0AAA: ${m(n.values, " | ")} \u0AAE\u0ABE\u0AA7\u0ACD\u0AAF\u0AAE\u0AA5\u0AC0 \u0A8F\u0A95 \u0A85\u0AAA\u0AC7\u0A95\u0ACD\u0AB7\u0ABF\u0AA4`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin);
        return a ? `\u0A96\u0AC2\u0AAC \u0AAE\u0ACB\u0A9F\u0AC1\u0A82: ${n.origin ?? "\u0AAE\u0AC2\u0AB2\u0ACD\u0AAF"} ${i}${n.maximum.toString()} ${a.unit ?? "\u0A8F\u0AB2\u0ABF\u0AAE\u0AC7\u0AA8\u0ACD\u0A9F"} \u0AB9\u0ACB\u0AB5\u0ABE \u0A9C\u0ACB\u0A88\u0A8F` : `\u0A96\u0AC2\u0AAC \u0AAE\u0ACB\u0A9F\u0AC1\u0A82: ${n.origin ?? "\u0AAE\u0AC2\u0AB2\u0ACD\u0AAF"} ${i}${n.maximum.toString()} \u0AB9\u0ACB\u0AB5\u0AC1\u0A82 \u0A9C\u0ACB\u0A88\u0A8F`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin);
        return a ? `\u0A96\u0AC2\u0AAC \u0AA8\u0ABE\u0AA8\u0AC1\u0A82: ${n.origin} ${i}${n.minimum.toString()} ${a.unit} \u0AB9\u0ACB\u0AB5\u0ABE \u0A9C\u0ACB\u0A88\u0A8F` : `\u0A96\u0AC2\u0AAC \u0AA8\u0ABE\u0AA8\u0AC1\u0A82: ${n.origin} ${i}${n.minimum.toString()} \u0AB9\u0ACB\u0AB5\u0AC1\u0A82 \u0A9C\u0ACB\u0A88\u0A8F`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AB8\u0ACD\u0A9F\u0ACD\u0AB0\u0ABF\u0A82\u0A97: "${i.prefix}" \u0AA5\u0AC0 \u0AB6\u0AB0\u0AC2 \u0AA5\u0AB5\u0AC1\u0A82 \u0A9C\u0ACB\u0A88\u0A8F` : i.format === "ends_with" ? `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AB8\u0ACD\u0A9F\u0ACD\u0AB0\u0ABF\u0A82\u0A97: "${i.suffix}" \u0AAA\u0AB0 \u0AB8\u0AAE\u0ABE\u0AAA\u0ACD\u0AA4 \u0AA5\u0AB5\u0AC1\u0A82 \u0A9C\u0ACB\u0A88\u0A8F` : i.format === "includes" ? `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AB8\u0ACD\u0A9F\u0ACD\u0AB0\u0ABF\u0A82\u0A97: "${i.includes}" \u0AB6\u0ABE\u0AAE\u0AC7\u0AB2 \u0AB9\u0ACB\u0AB5\u0AC1\u0A82 \u0A9C\u0ACB\u0A88\u0A8F` : i.format === "regex" ? `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AB8\u0ACD\u0A9F\u0ACD\u0AB0\u0ABF\u0A82\u0A97: \u0AAA\u0AC7\u0A9F\u0AB0\u0ACD\u0AA8 ${i.pattern} \u0AB8\u0ABE\u0AA5\u0AC7 \u0AAE\u0AC7\u0AB3 \u0A96\u0ABE\u0AB5\u0AC1\u0A82 \u0A9C\u0ACB\u0A88\u0A8F` : `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF ${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AA8\u0A82\u0AAC\u0AB0: ${n.divisor} \u0AA8\u0ACB \u0A97\u0AC1\u0AA3\u0ABE\u0A82\u0A95 \u0AB9\u0ACB\u0AB5\u0ACB \u0A9C\u0ACB\u0A88\u0A8F`;
      case "unrecognized_keys":
        return `\u0A93\u0AB3\u0A96\u0AC0 \u0AB6\u0A95\u0ABE\u0AA4\u0ABE \u0AA8\u0AB9\u0AC0\u0A82 \u0AA4\u0AC7 \u0A95\u0AC0${n.keys.length > 1 ? "\u0A93" : ""}: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `${n.origin} \u0AAE\u0ABE\u0A82 \u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0A95\u0AC0`;
      case "invalid_union":
        return n.options && Array.isArray(n.options) && n.options.length > 0 ? `\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AA1\u0ABF\u0AB8\u0ACD\u0A95\u0ACD\u0AB0\u0ABF\u0AAE\u0ABF\u0AA8\u0AC7\u0A9F\u0AB0 \u0AAE\u0AC2\u0AB2\u0ACD\u0AAF. \u0A85\u0AAA\u0AC7\u0A95\u0ACD\u0AB7\u0ABF\u0AA4 ${n.options.map((a) => `'${a}'`).join(" | ")}` : "\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0A87\u0AA8\u0AAA\u0AC1\u0A9F";
      case "invalid_element":
        return `${n.origin} \u0AAE\u0ABE\u0A82 \u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0AAE\u0AC2\u0AB2\u0ACD\u0AAF`;
      default:
        return "\u0A85\u0AAE\u0ABE\u0AA8\u0ACD\u0AAF \u0A87\u0AA8\u0AAA\u0AC1\u0A9F";
    }
  };
}, "error");
function iu() {
  return {
    localeError: Xv()
  };
}
s(iu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/he.js
var Hv = /* @__PURE__ */ s(() => {
  let e = {
    string: { label: "\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA", gender: "f" },
    number: { label: "\u05DE\u05E1\u05E4\u05E8", gender: "m" },
    boolean: { label: "\u05E2\u05E8\u05DA \u05D1\u05D5\u05DC\u05D9\u05D0\u05E0\u05D9", gender: "m" },
    bigint: { label: "BigInt", gender: "m" },
    date: { label: "\u05EA\u05D0\u05E8\u05D9\u05DA", gender: "m" },
    array: { label: "\u05DE\u05E2\u05E8\u05DA", gender: "m" },
    object: { label: "\u05D0\u05D5\u05D1\u05D9\u05D9\u05E7\u05D8", gender: "m" },
    null: { label: "\u05E2\u05E8\u05DA \u05E8\u05D9\u05E7 (null)", gender: "m" },
    undefined: { label: "\u05E2\u05E8\u05DA \u05DC\u05D0 \u05DE\u05D5\u05D2\u05D3\u05E8 (undefined)", gender: "m" },
    symbol: { label: "\u05E1\u05D9\u05DE\u05D1\u05D5\u05DC (Symbol)", gender: "m" },
    function: { label: "\u05E4\u05D5\u05E0\u05E7\u05E6\u05D9\u05D4", gender: "f" },
    map: { label: "\u05DE\u05E4\u05D4 (Map)", gender: "f" },
    set: { label: "\u05E7\u05D1\u05D5\u05E6\u05D4 (Set)", gender: "f" },
    file: { label: "\u05E7\u05D5\u05D1\u05E5", gender: "m" },
    promise: { label: "Promise", gender: "m" },
    NaN: { label: "NaN", gender: "m" },
    unknown: { label: "\u05E2\u05E8\u05DA \u05DC\u05D0 \u05D9\u05D3\u05D5\u05E2", gender: "m" },
    value: { label: "\u05E2\u05E8\u05DA", gender: "m" }
  }, t = {
    string: { unit: "\u05EA\u05D5\u05D5\u05D9\u05DD", shortLabel: "\u05E7\u05E6\u05E8", longLabel: "\u05D0\u05E8\u05D5\u05DA" },
    file: { unit: "\u05D1\u05D9\u05D9\u05D8\u05D9\u05DD", shortLabel: "\u05E7\u05D8\u05DF", longLabel: "\u05D2\u05D3\u05D5\u05DC" },
    array: { unit: "\u05E4\u05E8\u05D9\u05D8\u05D9\u05DD", shortLabel: "\u05E7\u05D8\u05DF", longLabel: "\u05D2\u05D3\u05D5\u05DC" },
    set: { unit: "\u05E4\u05E8\u05D9\u05D8\u05D9\u05DD", shortLabel: "\u05E7\u05D8\u05DF", longLabel: "\u05D2\u05D3\u05D5\u05DC" },
    number: { unit: "", shortLabel: "\u05E7\u05D8\u05DF", longLabel: "\u05D2\u05D3\u05D5\u05DC" }
    // no unit
  }, r = /* @__PURE__ */ s((l) => l ? e[l] : void 0, "typeEntry"), o = /* @__PURE__ */ s((l) => {
    let d = r(l);
    return d ? d.label : l ?? e.unknown.label;
  }, "typeLabel"), n = /* @__PURE__ */ s((l) => `\u05D4${o(l)}`, "withDefinite"), i = /* @__PURE__ */ s((l) => (r(l)?.gender ?? "m") === "f" ? "\u05E6\u05E8\u05D9\u05DB\u05D4 \u05DC\u05D4\u05D9\u05D5\u05EA" : "\u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA", "verbFor"), a = /* @__PURE__ */ s((l) => l ? t[l] ?? null : null, "getSizing"), u = {
    regex: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    email: { label: "\u05DB\u05EA\u05D5\u05D1\u05EA \u05D0\u05D9\u05DE\u05D9\u05D9\u05DC", gender: "f" },
    url: { label: "\u05DB\u05EA\u05D5\u05D1\u05EA \u05E8\u05E9\u05EA", gender: "f" },
    emoji: { label: "\u05D0\u05D9\u05DE\u05D5\u05D2'\u05D9", gender: "m" },
    uuid: { label: "UUID", gender: "m" },
    uuidv4: { label: "UUIDv4", gender: "m" },
    uuidv6: { label: "UUIDv6", gender: "m" },
    nanoid: { label: "nanoid", gender: "m" },
    guid: { label: "GUID", gender: "m" },
    cuid: { label: "cuid", gender: "m" },
    cuid2: { label: "cuid2", gender: "m" },
    ulid: { label: "ULID", gender: "m" },
    xid: { label: "XID", gender: "m" },
    ksuid: { label: "KSUID", gender: "m" },
    datetime: { label: "\u05EA\u05D0\u05E8\u05D9\u05DA \u05D5\u05D6\u05DE\u05DF ISO", gender: "m" },
    date: { label: "\u05EA\u05D0\u05E8\u05D9\u05DA ISO", gender: "m" },
    time: { label: "\u05D6\u05DE\u05DF ISO", gender: "m" },
    duration: { label: "\u05DE\u05E9\u05DA \u05D6\u05DE\u05DF ISO", gender: "m" },
    ipv4: { label: "\u05DB\u05EA\u05D5\u05D1\u05EA IPv4", gender: "f" },
    ipv6: { label: "\u05DB\u05EA\u05D5\u05D1\u05EA IPv6", gender: "f" },
    mac: { label: "\u05DB\u05EA\u05D5\u05D1\u05EA MAC", gender: "f" },
    cidrv4: { label: "\u05D8\u05D5\u05D5\u05D7 IPv4", gender: "m" },
    cidrv6: { label: "\u05D8\u05D5\u05D5\u05D7 IPv6", gender: "m" },
    base64: { label: "\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D1\u05D1\u05E1\u05D9\u05E1 64", gender: "f" },
    base64url: { label: "\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D1\u05D1\u05E1\u05D9\u05E1 64 \u05DC\u05DB\u05EA\u05D5\u05D1\u05D5\u05EA \u05E8\u05E9\u05EA", gender: "f" },
    json_string: { label: "\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA JSON", gender: "f" },
    e164: { label: "\u05DE\u05E1\u05E4\u05E8 E.164", gender: "m" },
    credit_card: { label: "\u05DE\u05E1\u05E4\u05E8 \u05DB\u05E8\u05D8\u05D9\u05E1 \u05D0\u05E9\u05E8\u05D0\u05D9", gender: "m" },
    jwt: { label: "JWT", gender: "m" },
    template_literal: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    ends_with: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    includes: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    lowercase: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    starts_with: { label: "\u05E7\u05DC\u05D8", gender: "m" },
    uppercase: { label: "\u05E7\u05DC\u05D8", gender: "m" }
  }, c = {
    nan: "NaN"
  };
  return (l) => {
    switch (l.code) {
      case "invalid_type": {
        let d = l.expected, f = c[d ?? ""] ?? o(d), p = b(l.input), h = c[p] ?? e[p]?.label ?? p;
        return /^[A-Z]/.test(l.expected) ? `\u05E7\u05DC\u05D8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA instanceof ${l.expected}, \u05D4\u05EA\u05E7\u05D1\u05DC ${h}` : `\u05E7\u05DC\u05D8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA ${f}, \u05D4\u05EA\u05E7\u05D1\u05DC ${h}`;
      }
      case "invalid_value": {
        if (l.values.length === 1)
          return `\u05E2\u05E8\u05DA \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05D4\u05E2\u05E8\u05DA \u05D7\u05D9\u05D9\u05D1 \u05DC\u05D4\u05D9\u05D5\u05EA ${$(l.values[0])}`;
        let d = l.values.map((h) => $(h));
        if (l.values.length === 2)
          return `\u05E2\u05E8\u05DA \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05D4\u05D0\u05E4\u05E9\u05E8\u05D5\u05D9\u05D5\u05EA \u05D4\u05DE\u05EA\u05D0\u05D9\u05DE\u05D5\u05EA \u05D4\u05DF ${d[0]} \u05D0\u05D5 ${d[1]}`;
        let f = d[d.length - 1];
        return `\u05E2\u05E8\u05DA \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05D4\u05D0\u05E4\u05E9\u05E8\u05D5\u05D9\u05D5\u05EA \u05D4\u05DE\u05EA\u05D0\u05D9\u05DE\u05D5\u05EA \u05D4\u05DF ${d.slice(0, -1).join(", ")} \u05D0\u05D5 ${f}`;
      }
      case "too_big": {
        let d = a(l.origin), f = n(l.origin ?? "value");
        if (l.origin === "string")
          return `${d?.longLabel ?? "\u05D0\u05E8\u05D5\u05DA"} \u05DE\u05D3\u05D9: ${f} \u05E6\u05E8\u05D9\u05DB\u05D4 \u05DC\u05D4\u05DB\u05D9\u05DC ${l.maximum.toString()} ${d?.unit ?? ""} ${l.inclusive ? "\u05D0\u05D5 \u05E4\u05D7\u05D5\u05EA" : "\u05DC\u05DB\u05DC \u05D4\u05D9\u05D5\u05EA\u05E8"}`.trim();
        if (l.origin === "number") {
          let v = l.inclusive ? `\u05E7\u05D8\u05DF \u05D0\u05D5 \u05E9\u05D5\u05D5\u05D4 \u05DC-${l.maximum}` : `\u05E7\u05D8\u05DF \u05DE-${l.maximum}`;
          return `\u05D2\u05D3\u05D5\u05DC \u05DE\u05D3\u05D9: ${f} \u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA ${v}`;
        }
        if (l.origin === "array" || l.origin === "set") {
          let v = l.origin === "set" ? "\u05E6\u05E8\u05D9\u05DB\u05D4" : "\u05E6\u05E8\u05D9\u05DA", x = l.inclusive ? `${l.maximum} ${d?.unit ?? ""} \u05D0\u05D5 \u05E4\u05D7\u05D5\u05EA` : `\u05E4\u05D7\u05D5\u05EA \u05DE-${l.maximum} ${d?.unit ?? ""}`;
          return `\u05D2\u05D3\u05D5\u05DC \u05DE\u05D3\u05D9: ${f} ${v} \u05DC\u05D4\u05DB\u05D9\u05DC ${x}`.trim();
        }
        let p = l.inclusive ? "<=" : "<", h = i(l.origin ?? "value");
        return d?.unit ? `${d.longLabel} \u05DE\u05D3\u05D9: ${f} ${h} ${p}${l.maximum.toString()} ${d.unit}` : `${d?.longLabel ?? "\u05D2\u05D3\u05D5\u05DC"} \u05DE\u05D3\u05D9: ${f} ${h} ${p}${l.maximum.toString()}`;
      }
      case "too_small": {
        let d = a(l.origin), f = n(l.origin ?? "value");
        if (l.origin === "string")
          return `${d?.shortLabel ?? "\u05E7\u05E6\u05E8"} \u05DE\u05D3\u05D9: ${f} \u05E6\u05E8\u05D9\u05DB\u05D4 \u05DC\u05D4\u05DB\u05D9\u05DC ${l.minimum.toString()} ${d?.unit ?? ""} ${l.inclusive ? "\u05D0\u05D5 \u05D9\u05D5\u05EA\u05E8" : "\u05DC\u05E4\u05D7\u05D5\u05EA"}`.trim();
        if (l.origin === "number") {
          let v = l.inclusive ? `\u05D2\u05D3\u05D5\u05DC \u05D0\u05D5 \u05E9\u05D5\u05D5\u05D4 \u05DC-${l.minimum}` : `\u05D2\u05D3\u05D5\u05DC \u05DE-${l.minimum}`;
          return `\u05E7\u05D8\u05DF \u05DE\u05D3\u05D9: ${f} \u05E6\u05E8\u05D9\u05DA \u05DC\u05D4\u05D9\u05D5\u05EA ${v}`;
        }
        if (l.origin === "array" || l.origin === "set") {
          let v = l.origin === "set" ? "\u05E6\u05E8\u05D9\u05DB\u05D4" : "\u05E6\u05E8\u05D9\u05DA";
          if (l.minimum === 1 && l.inclusive) {
            let k = (l.origin === "set", "\u05DC\u05E4\u05D7\u05D5\u05EA \u05E4\u05E8\u05D9\u05D8 \u05D0\u05D7\u05D3");
            return `\u05E7\u05D8\u05DF \u05DE\u05D3\u05D9: ${f} ${v} \u05DC\u05D4\u05DB\u05D9\u05DC ${k}`;
          }
          let x = l.inclusive ? `${l.minimum} ${d?.unit ?? ""} \u05D0\u05D5 \u05D9\u05D5\u05EA\u05E8` : `\u05D9\u05D5\u05EA\u05E8 \u05DE-${l.minimum} ${d?.unit ?? ""}`;
          return `\u05E7\u05D8\u05DF \u05DE\u05D3\u05D9: ${f} ${v} \u05DC\u05D4\u05DB\u05D9\u05DC ${x}`.trim();
        }
        let p = l.inclusive ? ">=" : ">", h = i(l.origin ?? "value");
        return d?.unit ? `${d.shortLabel} \u05DE\u05D3\u05D9: ${f} ${h} ${p}${l.minimum.toString()} ${d.unit}` : `${d?.shortLabel ?? "\u05E7\u05D8\u05DF"} \u05DE\u05D3\u05D9: ${f} ${h} ${p}${l.minimum.toString()}`;
      }
      case "invalid_format": {
        let d = l;
        if (d.format === "starts_with")
          return `\u05D4\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D7\u05D9\u05D9\u05D1\u05EA \u05DC\u05D4\u05EA\u05D7\u05D9\u05DC \u05D1 "${d.prefix}"`;
        if (d.format === "ends_with")
          return `\u05D4\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D7\u05D9\u05D9\u05D1\u05EA \u05DC\u05D4\u05E1\u05EA\u05D9\u05D9\u05DD \u05D1 "${d.suffix}"`;
        if (d.format === "includes")
          return `\u05D4\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D7\u05D9\u05D9\u05D1\u05EA \u05DC\u05DB\u05DC\u05D5\u05DC "${d.includes}"`;
        if (d.format === "regex")
          return `\u05D4\u05DE\u05D7\u05E8\u05D5\u05D6\u05EA \u05D7\u05D9\u05D9\u05D1\u05EA \u05DC\u05D4\u05EA\u05D0\u05D9\u05DD \u05DC\u05EA\u05D1\u05E0\u05D9\u05EA ${d.pattern}`;
        let f = u[d.format], p = f?.label ?? d.format, v = (f?.gender ?? "m") === "f" ? "\u05EA\u05E7\u05D9\u05E0\u05D4" : "\u05EA\u05E7\u05D9\u05DF";
        return `${p} \u05DC\u05D0 ${v}`;
      }
      case "not_multiple_of":
        return `\u05DE\u05E1\u05E4\u05E8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF: \u05D7\u05D9\u05D9\u05D1 \u05DC\u05D4\u05D9\u05D5\u05EA \u05DE\u05DB\u05E4\u05DC\u05D4 \u05E9\u05DC ${l.divisor}`;
      case "unrecognized_keys":
        return `\u05DE\u05E4\u05EA\u05D7${l.keys.length > 1 ? "\u05D5\u05EA" : ""} \u05DC\u05D0 \u05DE\u05D6\u05D5\u05D4${l.keys.length > 1 ? "\u05D9\u05DD" : "\u05D4"}: ${m(l.keys, ", ")}`;
      case "invalid_key":
        return "\u05E9\u05D3\u05D4 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF \u05D1\u05D0\u05D5\u05D1\u05D9\u05D9\u05E7\u05D8";
      case "invalid_union":
        return "\u05E7\u05DC\u05D8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF";
      case "invalid_element":
        return `\u05E2\u05E8\u05DA \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF \u05D1${n(l.origin ?? "array")}`;
      default:
        return "\u05E7\u05DC\u05D8 \u05DC\u05D0 \u05EA\u05E7\u05D9\u05DF";
    }
  };
}, "error");
function ou() {
  return {
    localeError: Hv()
  };
}
s(ou, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/hi.js
var Qv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0905\u0915\u094D\u0937\u0930", verb: "\u0930\u0916\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F" },
    file: { unit: "\u092C\u093E\u0907\u091F\u094D\u0938", verb: "\u0930\u0916\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F" },
    array: { unit: "\u0924\u0924\u094D\u0935", verb: "\u0930\u0916\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F" },
    set: { unit: "\u0924\u0924\u094D\u0935", verb: "\u0930\u0916\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F" },
    map: { unit: "\u092A\u094D\u0930\u0935\u093F\u0937\u094D\u091F\u093F\u092F\u093E\u0901", verb: "\u0930\u0916\u0928\u0947 \u0915\u0947 \u0932\u093F\u090F" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "\u0907\u0928\u092A\u0941\u091F",
    email: "\u0908\u092E\u0947\u0932 \u092A\u0924\u093E",
    url: "URL",
    emoji: "\u0907\u092E\u094B\u091C\u0940",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0924\u093F\u0925\u093F \u0914\u0930 \u0938\u092E\u092F",
    date: "ISO \u0924\u093F\u0925\u093F",
    time: "ISO \u0938\u092E\u092F",
    duration: "ISO \u0905\u0935\u0927\u093F",
    ipv4: "IPv4 \u092A\u0924\u093E",
    ipv6: "IPv6 \u092A\u0924\u093E",
    mac: "MAC \u092A\u0924\u093E",
    cidrv4: "IPv4 \u0936\u094D\u0930\u0947\u0923\u0940",
    cidrv6: "IPv6 \u0936\u094D\u0930\u0947\u0923\u0940",
    base64: "Base64-\u090F\u0928\u094D\u0915\u094B\u0921\u0947\u0921 \u0938\u094D\u091F\u094D\u0930\u093F\u0902\u0917",
    base64url: "Base64URL-\u090F\u0928\u094D\u0915\u094B\u0921\u0947\u0921 \u0938\u094D\u091F\u094D\u0930\u093F\u0902\u0917",
    json_string: "JSON \u0938\u094D\u091F\u094D\u0930\u093F\u0902\u0917",
    e164: "E.164 \u0938\u0902\u0916\u094D\u092F\u093E",
    credit_card: "\u0915\u094D\u0930\u0947\u0921\u093F\u091F \u0915\u093E\u0930\u094D\u0921 \u0938\u0902\u0916\u094D\u092F\u093E",
    jwt: "JWT",
    template_literal: "\u0907\u0928\u092A\u0941\u091F"
  }, o = {
    nan: "NaN"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return `\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 ${i}, \u092A\u094D\u0930\u093E\u092A\u094D\u0924 ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 ${$(n.values[0])}` : `\u0905\u092E\u093E\u0928\u094D\u092F \u0935\u093F\u0915\u0932\u094D\u092A: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 \u092E\u093E\u0928\u094B\u0902 \u092E\u0947\u0902 \u0938\u0947 \u090F\u0915 ${m(n.values, "|")}`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin);
        return a ? `\u092C\u0939\u0941\u0924 \u092C\u0921\u093C\u093E: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 \u0925\u093E \u0915\u093F ${n.origin ?? "\u092E\u093E\u0928"} \u092E\u0947\u0902 ${i}${n.maximum} ${a.unit} \u0939\u094B\u0902` : `\u092C\u0939\u0941\u0924 \u092C\u0921\u093C\u093E: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 \u0925\u093E \u0915\u093F ${n.origin ?? "\u092E\u093E\u0928"} ${i}${n.maximum} \u0939\u094B`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin);
        return a ? `\u092C\u0939\u0941\u0924 \u091B\u094B\u091F\u093E: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 \u0925\u093E \u0915\u093F ${n.origin} \u092E\u0947\u0902 ${i}${n.minimum} ${a.unit} \u0939\u094B\u0902` : `\u092C\u0939\u0941\u0924 \u091B\u094B\u091F\u093E: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 \u0925\u093E \u0915\u093F ${n.origin} ${i}${n.minimum} \u0939\u094B`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0902\u0917: "${i.prefix}" \u0938\u0947 \u0936\u0941\u0930\u0942 \u0939\u094B\u0928\u093E \u091A\u093E\u0939\u093F\u090F` : i.format === "ends_with" ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0902\u0917: "${i.suffix}" \u092A\u0930 \u0938\u092E\u093E\u092A\u094D\u0924 \u0939\u094B\u0928\u093E \u091A\u093E\u0939\u093F\u090F` : i.format === "includes" ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0902\u0917: \u0907\u0938\u092E\u0947\u0902 "${i.includes}" \u0936\u093E\u092E\u093F\u0932 \u0939\u094B\u0928\u093E \u091A\u093E\u0939\u093F\u090F` : i.format === "regex" ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0902\u0917: \u092A\u0948\u091F\u0930\u094D\u0928 ${i.pattern} \u0938\u0947 \u092E\u0947\u0932 \u0916\u093E\u0928\u093E \u091A\u093E\u0939\u093F\u090F` : `\u0905\u092E\u093E\u0928\u094D\u092F ${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u0902\u0916\u094D\u092F\u093E: \u092F\u0939 ${n.divisor} \u0915\u093E \u0917\u0941\u0923\u091C \u0939\u094B\u0928\u093E \u091A\u093E\u0939\u093F\u090F`;
      case "unrecognized_keys":
        return `\u0905\u092A\u0930\u093F\u091A\u093F\u0924 \u0915\u0941\u0902\u091C\u0940${n.keys.length > 1 ? "\u092F\u093E\u0901" : ""}: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `\u0905\u092E\u093E\u0928\u094D\u092F \u0915\u0941\u0902\u091C\u0940: ${n.origin} \u092E\u0947\u0902`;
      case "invalid_union":
        return n.options && Array.isArray(n.options) && n.options.length > 0 ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0921\u093F\u0938\u094D\u0915\u094D\u0930\u093F\u092E\u093F\u0928\u0947\u091F\u0930 \u092E\u093E\u0928: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 ${n.options.map((a) => `'${a}'`).join(" | ")}` : "\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F";
      case "invalid_element":
        return `\u0905\u092E\u093E\u0928\u094D\u092F \u092E\u093E\u0928: ${n.origin} \u092E\u0947\u0902`;
      default:
        return "\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F";
    }
  };
}, "error");
function au() {
  return {
    localeError: Qv()
  };
}
s(au, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/hr.js
var Yv = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "znakova", verb: "imati" },
    file: { unit: "bajtova", verb: "imati" },
    array: { unit: "stavki", verb: "imati" },
    set: { unit: "stavki", verb: "imati" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "unos",
    email: "email adresa",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datum i vrijeme",
    date: "ISO datum",
    time: "ISO vrijeme",
    duration: "ISO trajanje",
    ipv4: "IPv4 adresa",
    ipv6: "IPv6 adresa",
    mac: "MAC adresa",
    cidrv4: "IPv4 raspon",
    cidrv6: "IPv6 raspon",
    base64: "base64 kodirani tekst",
    base64url: "base64url kodirani tekst",
    json_string: "JSON tekst",
    e164: "E.164 broj",
    credit_card: "broj kreditne kartice",
    jwt: "JWT",
    template_literal: "unos"
  }, o = {
    nan: "NaN",
    string: "tekst",
    number: "broj",
    boolean: "boolean",
    array: "niz",
    object: "objekt",
    set: "skup",
    file: "datoteka",
    date: "datum",
    bigint: "bigint",
    symbol: "simbol",
    undefined: "undefined",
    null: "null",
    function: "funkcija",
    map: "mapa"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `Neispravan unos: o\u010Dekuje se instanceof ${n.expected}, a primljeno je ${u}` : `Neispravan unos: o\u010Dekuje se ${i}, a primljeno je ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `Neispravna vrijednost: o\u010Dekivano ${$(n.values[0])}` : `Neispravna opcija: o\u010Dekivano jedno od ${m(n.values, "|")}`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin), u = o[n.origin] ?? n.origin;
        return a ? `Preveliko: o\u010Dekivano da ${u ?? "vrijednost"} ima ${i}${n.maximum.toString()} ${a.unit ?? "elemenata"}` : `Preveliko: o\u010Dekivano da ${u ?? "vrijednost"} bude ${i}${n.maximum.toString()}`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin), u = o[n.origin] ?? n.origin;
        return a ? `Premalo: o\u010Dekivano da ${u} ima ${i}${n.minimum.toString()} ${a.unit}` : `Premalo: o\u010Dekivano da ${u} bude ${i}${n.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `Neispravan tekst: mora zapo\u010Dinjati s "${i.prefix}"` : i.format === "ends_with" ? `Neispravan tekst: mora zavr\u0161avati s "${i.suffix}"` : i.format === "includes" ? `Neispravan tekst: mora sadr\u017Eavati "${i.includes}"` : i.format === "regex" ? `Neispravan tekst: mora odgovarati uzorku ${i.pattern}` : `Neispravna ${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `Neispravan broj: mora biti vi\u0161ekratnik od ${n.divisor}`;
      case "unrecognized_keys":
        return `Neprepoznat${n.keys.length > 1 ? "i klju\u010Devi" : " klju\u010D"}: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `Neispravan klju\u010D u ${o[n.origin] ?? n.origin}`;
      case "invalid_union":
        return "Neispravan unos";
      case "invalid_element":
        return `Neispravna vrijednost u ${o[n.origin] ?? n.origin}`;
      default:
        return "Neispravan unos";
    }
  };
}, "error");
function su() {
  return {
    localeError: Yv()
  };
}
s(su, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/hu.js
var ey = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "karakter", verb: "legyen" },
    file: { unit: "byte", verb: "legyen" },
    array: { unit: "elem", verb: "legyen" },
    set: { unit: "elem", verb: "legyen" },
    map: { unit: "elem", verb: "legyen" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "bemenet",
    email: "email c\xEDm",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO id\u0151b\xE9lyeg",
    date: "ISO d\xE1tum",
    time: "ISO id\u0151",
    duration: "ISO id\u0151intervallum",
    ipv4: "IPv4 c\xEDm",
    ipv6: "IPv6 c\xEDm",
    mac: "MAC c\xEDm",
    cidrv4: "IPv4 tartom\xE1ny",
    cidrv6: "IPv6 tartom\xE1ny",
    base64: "base64-k\xF3dolt string",
    base64url: "base64url-k\xF3dolt string",
    json_string: "JSON string",
    e164: "E.164 sz\xE1m",
    credit_card: "hitelk\xE1rtyasz\xE1m",
    jwt: "JWT",
    template_literal: "bemenet"
  }, o = {
    nan: "NaN",
    number: "sz\xE1m",
    array: "t\xF6mb"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `\xC9rv\xE9nytelen bemenet: a v\xE1rt \xE9rt\xE9k instanceof ${n.expected}, a kapott \xE9rt\xE9k ${u}` : `\xC9rv\xE9nytelen bemenet: a v\xE1rt \xE9rt\xE9k ${i}, a kapott \xE9rt\xE9k ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `\xC9rv\xE9nytelen bemenet: a v\xE1rt \xE9rt\xE9k ${$(n.values[0])}` : `\xC9rv\xE9nytelen opci\xF3: valamelyik \xE9rt\xE9k v\xE1rt ${m(n.values, "|")}`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin);
        return a ? `T\xFAl nagy: ${n.origin ?? "\xE9rt\xE9k"} m\xE9rete t\xFAl nagy ${i}${n.maximum.toString()} ${a.unit ?? "elem"}` : `T\xFAl nagy: a bemeneti \xE9rt\xE9k ${n.origin ?? "\xE9rt\xE9k"} t\xFAl nagy: ${i}${n.maximum.toString()}`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin);
        return a ? `T\xFAl kicsi: a bemeneti \xE9rt\xE9k ${n.origin} m\xE9rete t\xFAl kicsi ${i}${n.minimum.toString()} ${a.unit}` : `T\xFAl kicsi: a bemeneti \xE9rt\xE9k ${n.origin} t\xFAl kicsi ${i}${n.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `\xC9rv\xE9nytelen string: "${i.prefix}" \xE9rt\xE9kkel kell kezd\u0151dnie` : i.format === "ends_with" ? `\xC9rv\xE9nytelen string: "${i.suffix}" \xE9rt\xE9kkel kell v\xE9gz\u0151dnie` : i.format === "includes" ? `\xC9rv\xE9nytelen string: "${i.includes}" \xE9rt\xE9ket kell tartalmaznia` : i.format === "regex" ? `\xC9rv\xE9nytelen string: ${i.pattern} mint\xE1nak kell megfelelnie` : `\xC9rv\xE9nytelen ${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `\xC9rv\xE9nytelen sz\xE1m: ${n.divisor} t\xF6bbsz\xF6r\xF6s\xE9nek kell lennie`;
      case "unrecognized_keys":
        return `Ismeretlen kulcs${n.keys.length > 1 ? "s" : ""}: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `\xC9rv\xE9nytelen kulcs ${n.origin}`;
      case "invalid_union":
        return "\xC9rv\xE9nytelen bemenet";
      case "invalid_element":
        return `\xC9rv\xE9nytelen \xE9rt\xE9k: ${n.origin}`;
      default:
        return "\xC9rv\xE9nytelen bemenet";
    }
  };
}, "error");
function uu() {
  return {
    localeError: ey()
  };
}
s(uu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/hy.js
function Ff(e, t, r) {
  return Math.abs(e) === 1 ? t : r;
}
s(Ff, "getArmenianPlural");
function At(e) {
  if (!e)
    return "";
  let t = ["\u0561", "\u0565", "\u0568", "\u056B", "\u0578", "\u0578\u0582", "\u0585"], r = e[e.length - 1];
  return e + (t.includes(r) ? "\u0576" : "\u0568");
}
s(At, "withDefiniteArticle");
var ty = /* @__PURE__ */ s(() => {
  let e = {
    string: {
      unit: {
        one: "\u0576\u0577\u0561\u0576",
        many: "\u0576\u0577\u0561\u0576\u0576\u0565\u0580"
      },
      verb: "\u0578\u0582\u0576\u0565\u0576\u0561\u056C"
    },
    file: {
      unit: {
        one: "\u0562\u0561\u0575\u0569",
        many: "\u0562\u0561\u0575\u0569\u0565\u0580"
      },
      verb: "\u0578\u0582\u0576\u0565\u0576\u0561\u056C"
    },
    array: {
      unit: {
        one: "\u057F\u0561\u0580\u0580",
        many: "\u057F\u0561\u0580\u0580\u0565\u0580"
      },
      verb: "\u0578\u0582\u0576\u0565\u0576\u0561\u056C"
    },
    set: {
      unit: {
        one: "\u057F\u0561\u0580\u0580",
        many: "\u057F\u0561\u0580\u0580\u0565\u0580"
      },
      verb: "\u0578\u0582\u0576\u0565\u0576\u0561\u056C"
    },
    map: {
      unit: {
        one: "\u057F\u0561\u0580\u0580",
        many: "\u057F\u0561\u0580\u0580\u0565\u0580"
      },
      verb: "\u0578\u0582\u0576\u0565\u0576\u0561\u056C"
    }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "\u0574\u0578\u0582\u057F\u0584",
    email: "\u0567\u056C. \u0570\u0561\u057D\u0581\u0565",
    url: "URL",
    emoji: "\u0567\u0574\u0578\u057B\u056B",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0561\u0574\u057D\u0561\u0569\u056B\u057E \u0587 \u056A\u0561\u0574",
    date: "ISO \u0561\u0574\u057D\u0561\u0569\u056B\u057E",
    time: "ISO \u056A\u0561\u0574",
    duration: "ISO \u057F\u0587\u0578\u0572\u0578\u0582\u0569\u0575\u0578\u0582\u0576",
    ipv4: "IPv4 \u0570\u0561\u057D\u0581\u0565",
    ipv6: "IPv6 \u0570\u0561\u057D\u0581\u0565",
    mac: "MAC \u0570\u0561\u057D\u0581\u0565",
    cidrv4: "IPv4 \u0574\u056B\u057B\u0561\u056F\u0561\u0575\u0584",
    cidrv6: "IPv6 \u0574\u056B\u057B\u0561\u056F\u0561\u0575\u0584",
    base64: "base64 \u0571\u0587\u0561\u0579\u0561\u0583\u0578\u057E \u057F\u0578\u0572",
    base64url: "base64url \u0571\u0587\u0561\u0579\u0561\u0583\u0578\u057E \u057F\u0578\u0572",
    json_string: "JSON \u057F\u0578\u0572",
    e164: "E.164 \u0570\u0561\u0574\u0561\u0580",
    credit_card: "\u056F\u0580\u0565\u0564\u056B\u057F \u0584\u0561\u0580\u057F\u056B \u0570\u0561\u0574\u0561\u0580",
    jwt: "JWT",
    template_literal: "\u0574\u0578\u0582\u057F\u0584"
  }, o = {
    nan: "NaN",
    number: "\u0569\u056B\u057E",
    array: "\u0566\u0561\u0576\u0563\u057E\u0561\u056E"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567\u0580 instanceof ${n.expected}, \u057D\u057F\u0561\u0581\u057E\u0565\u056C \u0567 ${u}` : `\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567\u0580 ${i}, \u057D\u057F\u0561\u0581\u057E\u0565\u056C \u0567 ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567\u0580 ${$(n.values[1])}` : `\u054D\u056D\u0561\u056C \u057F\u0561\u0580\u0562\u0565\u0580\u0561\u056F\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567\u0580 \u0570\u0565\u057F\u0587\u0575\u0561\u056C\u0576\u0565\u0580\u056B\u0581 \u0574\u0565\u056F\u0568\u055D ${m(n.values, "|")}`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin);
        if (a) {
          let u = Number(n.maximum), c = Ff(u, a.unit.one, a.unit.many);
          return `\u0549\u0561\u0583\u0561\u0566\u0561\u0576\u0581 \u0574\u0565\u056E \u0561\u0580\u056A\u0565\u0584\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567, \u0578\u0580 ${At(n.origin ?? "\u0561\u0580\u056A\u0565\u0584")} \u056F\u0578\u0582\u0576\u0565\u0576\u0561 ${i}${n.maximum.toString()} ${c}`;
        }
        return `\u0549\u0561\u0583\u0561\u0566\u0561\u0576\u0581 \u0574\u0565\u056E \u0561\u0580\u056A\u0565\u0584\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567, \u0578\u0580 ${At(n.origin ?? "\u0561\u0580\u056A\u0565\u0584")} \u056C\u056B\u0576\u056B ${i}${n.maximum.toString()}`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin);
        if (a) {
          let u = Number(n.minimum), c = Ff(u, a.unit.one, a.unit.many);
          return `\u0549\u0561\u0583\u0561\u0566\u0561\u0576\u0581 \u0583\u0578\u0584\u0580 \u0561\u0580\u056A\u0565\u0584\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567, \u0578\u0580 ${At(n.origin)} \u056F\u0578\u0582\u0576\u0565\u0576\u0561 ${i}${n.minimum.toString()} ${c}`;
        }
        return `\u0549\u0561\u0583\u0561\u0566\u0561\u0576\u0581 \u0583\u0578\u0584\u0580 \u0561\u0580\u056A\u0565\u0584\u2024 \u057D\u057A\u0561\u057D\u057E\u0578\u0582\u0574 \u0567, \u0578\u0580 ${At(n.origin)} \u056C\u056B\u0576\u056B ${i}${n.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `\u054D\u056D\u0561\u056C \u057F\u0578\u0572\u2024 \u057A\u0565\u057F\u0584 \u0567 \u057D\u056F\u057D\u057E\u056B "${i.prefix}"-\u0578\u057E` : i.format === "ends_with" ? `\u054D\u056D\u0561\u056C \u057F\u0578\u0572\u2024 \u057A\u0565\u057F\u0584 \u0567 \u0561\u057E\u0561\u0580\u057F\u057E\u056B "${i.suffix}"-\u0578\u057E` : i.format === "includes" ? `\u054D\u056D\u0561\u056C \u057F\u0578\u0572\u2024 \u057A\u0565\u057F\u0584 \u0567 \u057A\u0561\u0580\u0578\u0582\u0576\u0561\u056F\u056B "${i.includes}"` : i.format === "regex" ? `\u054D\u056D\u0561\u056C \u057F\u0578\u0572\u2024 \u057A\u0565\u057F\u0584 \u0567 \u0570\u0561\u0574\u0561\u057A\u0561\u057F\u0561\u057D\u056D\u0561\u0576\u056B ${i.pattern} \u0571\u0587\u0561\u0579\u0561\u0583\u056B\u0576` : `\u054D\u056D\u0561\u056C ${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `\u054D\u056D\u0561\u056C \u0569\u056B\u057E\u2024 \u057A\u0565\u057F\u0584 \u0567 \u0562\u0561\u0566\u0574\u0561\u057A\u0561\u057F\u056B\u056F \u056C\u056B\u0576\u056B ${n.divisor}-\u056B`;
      case "unrecognized_keys":
        return `\u0549\u0573\u0561\u0576\u0561\u0579\u057E\u0561\u056E \u0562\u0561\u0576\u0561\u056C\u056B${n.keys.length > 1 ? "\u0576\u0565\u0580" : ""}. ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `\u054D\u056D\u0561\u056C \u0562\u0561\u0576\u0561\u056C\u056B ${At(n.origin)}-\u0578\u0582\u0574`;
      case "invalid_union":
        return "\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574";
      case "invalid_element":
        return `\u054D\u056D\u0561\u056C \u0561\u0580\u056A\u0565\u0584 ${At(n.origin)}-\u0578\u0582\u0574`;
      default:
        return "\u054D\u056D\u0561\u056C \u0574\u0578\u0582\u057F\u0584\u0561\u0563\u0580\u0578\u0582\u0574";
    }
  };
}, "error");
function cu() {
  return {
    localeError: ty()
  };
}
s(cu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/id.js
var ny = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "karakter", verb: "memiliki" },
    file: { unit: "byte", verb: "memiliki" },
    array: { unit: "item", verb: "memiliki" },
    set: { unit: "item", verb: "memiliki" },
    map: { unit: "item", verb: "memiliki" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "input",
    email: "alamat email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "tanggal dan waktu format ISO",
    date: "tanggal format ISO",
    time: "jam format ISO",
    duration: "durasi format ISO",
    ipv4: "alamat IPv4",
    ipv6: "alamat IPv6",
    mac: "alamat MAC",
    cidrv4: "rentang alamat IPv4",
    cidrv6: "rentang alamat IPv6",
    base64: "string dengan enkode base64",
    base64url: "string dengan enkode base64url",
    json_string: "string JSON",
    e164: "angka E.164",
    credit_card: "nomor kartu kredit",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `Input tidak valid: diharapkan instanceof ${n.expected}, diterima ${u}` : `Input tidak valid: diharapkan ${i}, diterima ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `Input tidak valid: diharapkan ${$(n.values[0])}` : `Pilihan tidak valid: diharapkan salah satu dari ${m(n.values, "|")}`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin);
        return a ? `Terlalu besar: diharapkan ${n.origin ?? "value"} memiliki ${i}${n.maximum.toString()} ${a.unit ?? "elemen"}` : `Terlalu besar: diharapkan ${n.origin ?? "value"} menjadi ${i}${n.maximum.toString()}`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin);
        return a ? `Terlalu kecil: diharapkan ${n.origin} memiliki ${i}${n.minimum.toString()} ${a.unit}` : `Terlalu kecil: diharapkan ${n.origin} menjadi ${i}${n.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `String tidak valid: harus dimulai dengan "${i.prefix}"` : i.format === "ends_with" ? `String tidak valid: harus berakhir dengan "${i.suffix}"` : i.format === "includes" ? `String tidak valid: harus menyertakan "${i.includes}"` : i.format === "regex" ? `String tidak valid: harus sesuai pola ${i.pattern}` : `${r[i.format] ?? n.format} tidak valid`;
      }
      case "not_multiple_of":
        return `Angka tidak valid: harus kelipatan dari ${n.divisor}`;
      case "unrecognized_keys":
        return `Kunci tidak dikenali ${n.keys.length > 1 ? "s" : ""}: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `Kunci tidak valid di ${n.origin}`;
      case "invalid_union":
        return "Input tidak valid";
      case "invalid_element":
        return `Nilai tidak valid di ${n.origin}`;
      default:
        return "Input tidak valid";
    }
  };
}, "error");
function lu() {
  return {
    localeError: ny()
  };
}
s(lu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/is.js
var ry = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "stafi", verb: "a\xF0 hafa" },
    file: { unit: "b\xE6ti", verb: "a\xF0 hafa" },
    array: { unit: "hluti", verb: "a\xF0 hafa" },
    set: { unit: "hluti", verb: "a\xF0 hafa" },
    map: { unit: "hluti", verb: "a\xF0 hafa" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "gildi",
    email: "netfang",
    url: "vefsl\xF3\xF0",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO dagsetning og t\xEDmi",
    date: "ISO dagsetning",
    time: "ISO t\xEDmi",
    duration: "ISO t\xEDmalengd",
    ipv4: "IPv4 address",
    ipv6: "IPv6 address",
    mac: "MAC address",
    cidrv4: "IPv4 range",
    cidrv6: "IPv6 range",
    base64: "base64-encoded strengur",
    base64url: "base64url-encoded strengur",
    json_string: "JSON strengur",
    e164: "E.164 t\xF6lugildi",
    credit_card: "kreditkortan\xFAmer",
    jwt: "JWT",
    template_literal: "gildi"
  }, o = {
    nan: "NaN",
    number: "n\xFAmer",
    array: "fylki"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `Rangt gildi: \xDE\xFA sl\xF3st inn ${u} \xFEar sem \xE1 a\xF0 vera instanceof ${n.expected}` : `Rangt gildi: \xDE\xFA sl\xF3st inn ${u} \xFEar sem \xE1 a\xF0 vera ${i}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `Rangt gildi: gert r\xE1\xF0 fyrir ${$(n.values[0])}` : `\xD3gilt val: m\xE1 vera eitt af eftirfarandi ${m(n.values, "|")}`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin);
        return a ? `Of st\xF3rt: gert er r\xE1\xF0 fyrir a\xF0 ${n.origin ?? "gildi"} hafi ${i}${n.maximum.toString()} ${a.unit ?? "hluti"}` : `Of st\xF3rt: gert er r\xE1\xF0 fyrir a\xF0 ${n.origin ?? "gildi"} s\xE9 ${i}${n.maximum.toString()}`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin);
        return a ? `Of l\xEDti\xF0: gert er r\xE1\xF0 fyrir a\xF0 ${n.origin} hafi ${i}${n.minimum.toString()} ${a.unit}` : `Of l\xEDti\xF0: gert er r\xE1\xF0 fyrir a\xF0 ${n.origin} s\xE9 ${i}${n.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `\xD3gildur strengur: ver\xF0ur a\xF0 byrja \xE1 "${i.prefix}"` : i.format === "ends_with" ? `\xD3gildur strengur: ver\xF0ur a\xF0 enda \xE1 "${i.suffix}"` : i.format === "includes" ? `\xD3gildur strengur: ver\xF0ur a\xF0 innihalda "${i.includes}"` : i.format === "regex" ? `\xD3gildur strengur: ver\xF0ur a\xF0 fylgja mynstri ${i.pattern}` : `Rangt ${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `R\xF6ng tala: ver\xF0ur a\xF0 vera margfeldi af ${n.divisor}`;
      case "unrecognized_keys":
        return `\xD3\xFEekkt ${n.keys.length > 1 ? "ir lyklar" : "ur lykill"}: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `Rangur lykill \xED ${n.origin}`;
      case "invalid_union":
        return "Rangt gildi";
      case "invalid_element":
        return `Rangt gildi \xED ${n.origin}`;
      default:
        return "Rangt gildi";
    }
  };
}, "error");
function du() {
  return {
    localeError: ry()
  };
}
s(du, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/it.js
var iy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "caratteri", verb: "avere" },
    file: { unit: "byte", verb: "avere" },
    array: { unit: "elementi", verb: "avere" },
    set: { unit: "elementi", verb: "avere" },
    map: { unit: "elementi", verb: "avere" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "input",
    email: "indirizzo email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "data e ora ISO",
    date: "data ISO",
    time: "ora ISO",
    duration: "durata ISO",
    ipv4: "indirizzo IPv4",
    ipv6: "indirizzo IPv6",
    mac: "indirizzo MAC",
    cidrv4: "intervallo IPv4",
    cidrv6: "intervallo IPv6",
    base64: "stringa codificata in base64",
    base64url: "URL codificata in base64",
    json_string: "stringa JSON",
    e164: "numero E.164",
    credit_card: "numero di carta di credito",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN",
    number: "numero",
    array: "vettore"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `Input non valido: atteso instanceof ${n.expected}, ricevuto ${u}` : `Input non valido: atteso ${i}, ricevuto ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `Input non valido: atteso ${$(n.values[0])}` : `Opzione non valida: atteso uno tra ${m(n.values, "|")}`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin);
        return a ? `Troppo grande: ${n.origin ?? "valore"} deve avere ${i}${n.maximum.toString()} ${a.unit ?? "elementi"}` : `Troppo grande: ${n.origin ?? "valore"} deve essere ${i}${n.maximum.toString()}`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin);
        return a ? `Troppo piccolo: ${n.origin} deve avere ${i}${n.minimum.toString()} ${a.unit}` : `Troppo piccolo: ${n.origin} deve essere ${i}${n.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `Stringa non valida: deve iniziare con "${i.prefix}"` : i.format === "ends_with" ? `Stringa non valida: deve terminare con "${i.suffix}"` : i.format === "includes" ? `Stringa non valida: deve includere "${i.includes}"` : i.format === "regex" ? `Stringa non valida: deve corrispondere al pattern ${i.pattern}` : `Input non valido: ${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `Numero non valido: deve essere un multiplo di ${n.divisor}`;
      case "unrecognized_keys":
        return `Chiav${n.keys.length > 1 ? "i" : "e"} non riconosciut${n.keys.length > 1 ? "e" : "a"}: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `Chiave non valida in ${n.origin}`;
      case "invalid_union":
        return "Input non valido";
      case "invalid_element":
        return `Valore non valido in ${n.origin}`;
      default:
        return "Input non valido";
    }
  };
}, "error");
function fu() {
  return {
    localeError: iy()
  };
}
s(fu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ja.js
var oy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u6587\u5B57", verb: "\u3067\u3042\u308B" },
    file: { unit: "\u30D0\u30A4\u30C8", verb: "\u3067\u3042\u308B" },
    array: { unit: "\u8981\u7D20", verb: "\u3067\u3042\u308B" },
    set: { unit: "\u8981\u7D20", verb: "\u3067\u3042\u308B" },
    map: { unit: "\u8981\u7D20", verb: "\u3067\u3042\u308B" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "\u5165\u529B\u5024",
    email: "\u30E1\u30FC\u30EB\u30A2\u30C9\u30EC\u30B9",
    url: "URL",
    emoji: "\u7D75\u6587\u5B57",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO\u65E5\u6642",
    date: "ISO\u65E5\u4ED8",
    time: "ISO\u6642\u523B",
    duration: "ISO\u671F\u9593",
    ipv4: "IPv4\u30A2\u30C9\u30EC\u30B9",
    ipv6: "IPv6\u30A2\u30C9\u30EC\u30B9",
    mac: "MAC\u30A2\u30C9\u30EC\u30B9",
    cidrv4: "IPv4\u7BC4\u56F2",
    cidrv6: "IPv6\u7BC4\u56F2",
    base64: "base64\u30A8\u30F3\u30B3\u30FC\u30C9\u6587\u5B57\u5217",
    base64url: "base64url\u30A8\u30F3\u30B3\u30FC\u30C9\u6587\u5B57\u5217",
    json_string: "JSON\u6587\u5B57\u5217",
    e164: "E.164\u756A\u53F7",
    credit_card: "\u30AF\u30EC\u30B8\u30C3\u30C8\u30AB\u30FC\u30C9\u756A\u53F7",
    jwt: "JWT",
    template_literal: "\u5165\u529B\u5024"
  }, o = {
    nan: "NaN",
    number: "\u6570\u5024",
    array: "\u914D\u5217"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `\u7121\u52B9\u306A\u5165\u529B: instanceof ${n.expected}\u304C\u671F\u5F85\u3055\u308C\u307E\u3057\u305F\u304C\u3001${u}\u304C\u5165\u529B\u3055\u308C\u307E\u3057\u305F` : `\u7121\u52B9\u306A\u5165\u529B: ${i}\u304C\u671F\u5F85\u3055\u308C\u307E\u3057\u305F\u304C\u3001${u}\u304C\u5165\u529B\u3055\u308C\u307E\u3057\u305F`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `\u7121\u52B9\u306A\u5165\u529B: ${$(n.values[0])}\u304C\u671F\u5F85\u3055\u308C\u307E\u3057\u305F` : `\u7121\u52B9\u306A\u9078\u629E: ${m(n.values, "\u3001")}\u306E\u3044\u305A\u308C\u304B\u3067\u3042\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`;
      case "too_big": {
        let i = n.inclusive ? "\u4EE5\u4E0B\u3067\u3042\u308B" : "\u3088\u308A\u5C0F\u3055\u3044", a = t(n.origin);
        return a ? `\u5927\u304D\u3059\u304E\u308B\u5024: ${n.origin ?? "\u5024"}\u306F${n.maximum.toString()}${a.unit ?? "\u8981\u7D20"}${i}\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : `\u5927\u304D\u3059\u304E\u308B\u5024: ${n.origin ?? "\u5024"}\u306F${n.maximum.toString()}${i}\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`;
      }
      case "too_small": {
        let i = n.inclusive ? "\u4EE5\u4E0A\u3067\u3042\u308B" : "\u3088\u308A\u5927\u304D\u3044", a = t(n.origin);
        return a ? `\u5C0F\u3055\u3059\u304E\u308B\u5024: ${n.origin}\u306F${n.minimum.toString()}${a.unit}${i}\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : `\u5C0F\u3055\u3059\u304E\u308B\u5024: ${n.origin}\u306F${n.minimum.toString()}${i}\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `\u7121\u52B9\u306A\u6587\u5B57\u5217: "${i.prefix}"\u3067\u59CB\u307E\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : i.format === "ends_with" ? `\u7121\u52B9\u306A\u6587\u5B57\u5217: "${i.suffix}"\u3067\u7D42\u308F\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : i.format === "includes" ? `\u7121\u52B9\u306A\u6587\u5B57\u5217: "${i.includes}"\u3092\u542B\u3080\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : i.format === "regex" ? `\u7121\u52B9\u306A\u6587\u5B57\u5217: \u30D1\u30BF\u30FC\u30F3${i.pattern}\u306B\u4E00\u81F4\u3059\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059` : `\u7121\u52B9\u306A${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `\u7121\u52B9\u306A\u6570\u5024: ${n.divisor}\u306E\u500D\u6570\u3067\u3042\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059`;
      case "unrecognized_keys":
        return `\u8A8D\u8B58\u3055\u308C\u3066\u3044\u306A\u3044\u30AD\u30FC${n.keys.length > 1 ? "\u7FA4" : ""}: ${m(n.keys, "\u3001")}`;
      case "invalid_key":
        return `${n.origin}\u5185\u306E\u7121\u52B9\u306A\u30AD\u30FC`;
      case "invalid_union":
        return "\u7121\u52B9\u306A\u5165\u529B";
      case "invalid_element":
        return `${n.origin}\u5185\u306E\u7121\u52B9\u306A\u5024`;
      default:
        return "\u7121\u52B9\u306A\u5165\u529B";
    }
  };
}, "error");
function pu() {
  return {
    localeError: oy()
  };
}
s(pu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ka.js
var ay = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u10E1\u10D8\u10DB\u10D1\u10DD\u10DA\u10DD", verb: "\u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1" },
    file: { unit: "\u10D1\u10D0\u10D8\u10E2\u10D8", verb: "\u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1" },
    array: { unit: "\u10D4\u10DA\u10D4\u10DB\u10D4\u10DC\u10E2\u10D8", verb: "\u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1" },
    set: { unit: "\u10D4\u10DA\u10D4\u10DB\u10D4\u10DC\u10E2\u10D8", verb: "\u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1" },
    map: { unit: "\u10D4\u10DA\u10D4\u10DB\u10D4\u10DC\u10E2\u10D8", verb: "\u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "\u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0",
    email: "\u10D4\u10DA-\u10E4\u10DD\u10E1\u10E2\u10D8\u10E1 \u10DB\u10D8\u10E1\u10D0\u10DB\u10D0\u10E0\u10D7\u10D8",
    url: "URL",
    emoji: "\u10D4\u10DB\u10DD\u10EF\u10D8",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u10D7\u10D0\u10E0\u10D8\u10E6\u10D8-\u10D3\u10E0\u10DD",
    date: "\u10D7\u10D0\u10E0\u10D8\u10E6\u10D8",
    time: "\u10D3\u10E0\u10DD",
    duration: "\u10EE\u10D0\u10DC\u10D2\u10E0\u10EB\u10DA\u10D8\u10D5\u10DD\u10D1\u10D0",
    ipv4: "IPv4 \u10DB\u10D8\u10E1\u10D0\u10DB\u10D0\u10E0\u10D7\u10D8",
    ipv6: "IPv6 \u10DB\u10D8\u10E1\u10D0\u10DB\u10D0\u10E0\u10D7\u10D8",
    mac: "MAC \u10DB\u10D8\u10E1\u10D0\u10DB\u10D0\u10E0\u10D7\u10D8",
    cidrv4: "IPv4 \u10D3\u10D8\u10D0\u10DE\u10D0\u10D6\u10DD\u10DC\u10D8",
    cidrv6: "IPv6 \u10D3\u10D8\u10D0\u10DE\u10D0\u10D6\u10DD\u10DC\u10D8",
    base64: "base64-\u10D9\u10DD\u10D3\u10D8\u10E0\u10D4\u10D1\u10E3\u10DA\u10D8 \u10D5\u10D4\u10DA\u10D8",
    base64url: "base64url-\u10D9\u10DD\u10D3\u10D8\u10E0\u10D4\u10D1\u10E3\u10DA\u10D8 \u10D5\u10D4\u10DA\u10D8",
    json_string: "JSON \u10D5\u10D4\u10DA\u10D8",
    e164: "E.164 \u10DC\u10DD\u10DB\u10D4\u10E0\u10D8",
    credit_card: "\u10E1\u10D0\u10D9\u10E0\u10D4\u10D3\u10D8\u10E2\u10DD \u10D1\u10D0\u10E0\u10D0\u10D7\u10D8\u10E1 \u10DC\u10DD\u10DB\u10D4\u10E0\u10D8",
    jwt: "JWT",
    template_literal: "\u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0"
  }, o = {
    nan: "NaN",
    number: "\u10E0\u10D8\u10EA\u10EE\u10D5\u10D8",
    string: "\u10D5\u10D4\u10DA\u10D8",
    boolean: "\u10D1\u10E3\u10DA\u10D4\u10D0\u10DC\u10D8",
    function: "\u10E4\u10E3\u10DC\u10E5\u10EA\u10D8\u10D0",
    array: "\u10DB\u10D0\u10E1\u10D8\u10D5\u10D8"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 instanceof ${n.expected}, \u10DB\u10D8\u10E6\u10D4\u10D1\u10E3\u10DA\u10D8 ${u}` : `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${i}, \u10DB\u10D8\u10E6\u10D4\u10D1\u10E3\u10DA\u10D8 ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${$(n.values[0])}` : `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D5\u10D0\u10E0\u10D8\u10D0\u10DC\u10E2\u10D8: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8\u10D0 \u10D4\u10E0\u10D7-\u10D4\u10E0\u10D7\u10D8 ${m(n.values, "|")}-\u10D3\u10D0\u10DC`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin);
        return a ? `\u10D6\u10D4\u10D3\u10DB\u10D4\u10E2\u10D0\u10D3 \u10D3\u10D8\u10D3\u10D8: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${n.origin ?? "\u10DB\u10DC\u10D8\u10E8\u10D5\u10DC\u10D4\u10DA\u10DD\u10D1\u10D0"} ${a.verb} ${i}${n.maximum.toString()} ${a.unit}` : `\u10D6\u10D4\u10D3\u10DB\u10D4\u10E2\u10D0\u10D3 \u10D3\u10D8\u10D3\u10D8: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${n.origin ?? "\u10DB\u10DC\u10D8\u10E8\u10D5\u10DC\u10D4\u10DA\u10DD\u10D1\u10D0"} \u10D8\u10E7\u10DD\u10E1 ${i}${n.maximum.toString()}`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin);
        return a ? `\u10D6\u10D4\u10D3\u10DB\u10D4\u10E2\u10D0\u10D3 \u10DE\u10D0\u10E2\u10D0\u10E0\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${n.origin} ${a.verb} ${i}${n.minimum.toString()} ${a.unit}` : `\u10D6\u10D4\u10D3\u10DB\u10D4\u10E2\u10D0\u10D3 \u10DE\u10D0\u10E2\u10D0\u10E0\u10D0: \u10DB\u10DD\u10E1\u10D0\u10DA\u10DD\u10D3\u10DC\u10D4\u10DA\u10D8 ${n.origin} \u10D8\u10E7\u10DD\u10E1 ${i}${n.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D5\u10D4\u10DA\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10D8\u10EC\u10E7\u10D4\u10D1\u10DD\u10D3\u10D4\u10E1 "${i.prefix}"-\u10D8\u10D7` : i.format === "ends_with" ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D5\u10D4\u10DA\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10DB\u10D7\u10D0\u10D5\u10E0\u10D3\u10D4\u10D1\u10DD\u10D3\u10D4\u10E1 "${i.suffix}"-\u10D8\u10D7` : i.format === "includes" ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D5\u10D4\u10DA\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D8\u10EA\u10D0\u10D5\u10D3\u10D4\u10E1 "${i.includes}"-\u10E1` : i.format === "regex" ? `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D5\u10D4\u10DA\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10E8\u10D4\u10D4\u10E1\u10D0\u10D1\u10D0\u10DB\u10D4\u10D1\u10DD\u10D3\u10D4\u10E1 \u10E8\u10D0\u10D1\u10DA\u10DD\u10DC\u10E1 ${i.pattern}` : `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 ${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E0\u10D8\u10EA\u10EE\u10D5\u10D8: \u10E3\u10DC\u10D3\u10D0 \u10D8\u10E7\u10DD\u10E1 ${n.divisor}-\u10D8\u10E1 \u10EF\u10D4\u10E0\u10D0\u10D3\u10D8`;
      case "unrecognized_keys":
        return `\u10E3\u10EA\u10DC\u10DD\u10D1\u10D8 \u10D2\u10D0\u10E1\u10D0\u10E6\u10D4\u10D1${n.keys.length > 1 ? "\u10D4\u10D1\u10D8" : "\u10D8"}: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10D2\u10D0\u10E1\u10D0\u10E6\u10D4\u10D1\u10D8 ${n.origin}-\u10E8\u10D8`;
      case "invalid_union":
        return "\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0";
      case "invalid_element":
        return `\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10DB\u10DC\u10D8\u10E8\u10D5\u10DC\u10D4\u10DA\u10DD\u10D1\u10D0 ${n.origin}-\u10E8\u10D8`;
      default:
        return "\u10D0\u10E0\u10D0\u10E1\u10EC\u10DD\u10E0\u10D8 \u10E8\u10D4\u10E7\u10D5\u10D0\u10DC\u10D0";
    }
  };
}, "error");
function mu() {
  return {
    localeError: ay()
  };
}
s(mu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/km.js
var sy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u178F\u17BD\u17A2\u1780\u17D2\u179F\u179A", verb: "\u1782\u17BD\u179A\u1798\u17B6\u1793" },
    file: { unit: "\u1794\u17C3", verb: "\u1782\u17BD\u179A\u1798\u17B6\u1793" },
    array: { unit: "\u1792\u17B6\u178F\u17BB", verb: "\u1782\u17BD\u179A\u1798\u17B6\u1793" },
    set: { unit: "\u1792\u17B6\u178F\u17BB", verb: "\u1782\u17BD\u179A\u1798\u17B6\u1793" },
    map: { unit: "\u1792\u17B6\u178F\u17BB", verb: "\u1782\u17BD\u179A\u1798\u17B6\u1793" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B",
    email: "\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793\u17A2\u17CA\u17B8\u1798\u17C2\u179B",
    url: "URL",
    emoji: "\u179F\u1789\u17D2\u1789\u17B6\u17A2\u17B6\u179A\u1798\u17D2\u1798\u178E\u17CD",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u1780\u17B6\u179B\u1794\u179A\u17B7\u1785\u17D2\u1786\u17C1\u1791 \u1793\u17B7\u1784\u1798\u17C9\u17C4\u1784 ISO",
    date: "\u1780\u17B6\u179B\u1794\u179A\u17B7\u1785\u17D2\u1786\u17C1\u1791 ISO",
    time: "\u1798\u17C9\u17C4\u1784 ISO",
    duration: "\u179A\u1799\u17C8\u1796\u17C1\u179B ISO",
    ipv4: "\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793 IPv4",
    ipv6: "\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793 IPv6",
    mac: "\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793 MAC",
    cidrv4: "\u178A\u17C2\u1793\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793 IPv4",
    cidrv6: "\u178A\u17C2\u1793\u17A2\u17B6\u179F\u1799\u178A\u17D2\u178B\u17B6\u1793 IPv6",
    base64: "\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u17A2\u17CA\u17B7\u1780\u17BC\u178A base64",
    base64url: "\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u17A2\u17CA\u17B7\u1780\u17BC\u178A base64url",
    json_string: "\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A JSON",
    e164: "\u179B\u17C1\u1781 E.164",
    credit_card: "\u179B\u17C1\u1781\u1794\u17D0\u178E\u17D2\u178E\u17A5\u178E\u1791\u17B6\u1793",
    jwt: "JWT",
    template_literal: "\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B"
  }, o = {
    nan: "NaN",
    number: "\u179B\u17C1\u1781",
    array: "\u17A2\u17B6\u179A\u17C1 (Array)",
    null: "\u1782\u17D2\u1798\u17B6\u1793\u178F\u1798\u17D2\u179B\u17C3 (null)"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A instanceof ${n.expected} \u1794\u17C9\u17BB\u1793\u17D2\u178F\u17C2\u1791\u1791\u17BD\u179B\u1794\u17B6\u1793 ${u}` : `\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${i} \u1794\u17C9\u17BB\u1793\u17D2\u178F\u17C2\u1791\u1791\u17BD\u179B\u1794\u17B6\u1793 ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1794\u1789\u17D2\u1785\u17BC\u179B\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${$(n.values[0])}` : `\u1787\u1798\u17D2\u179A\u17BE\u179F\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1787\u17B6\u1798\u17BD\u1799\u1780\u17D2\u1793\u17BB\u1784\u1785\u17C6\u178E\u17C4\u1798 ${m(n.values, "|")}`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin);
        return a ? `\u1792\u17C6\u1796\u17C1\u1780\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${n.origin ?? "\u178F\u1798\u17D2\u179B\u17C3"} ${i} ${n.maximum.toString()} ${a.unit ?? "\u1792\u17B6\u178F\u17BB"}` : `\u1792\u17C6\u1796\u17C1\u1780\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${n.origin ?? "\u178F\u1798\u17D2\u179B\u17C3"} ${i} ${n.maximum.toString()}`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin);
        return a ? `\u178F\u17BC\u1785\u1796\u17C1\u1780\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${n.origin} ${i} ${n.minimum.toString()} ${a.unit}` : `\u178F\u17BC\u1785\u1796\u17C1\u1780\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1780\u17B6\u179A ${n.origin} ${i} ${n.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1785\u17B6\u1794\u17CB\u1795\u17D2\u178F\u17BE\u1798\u178A\u17C4\u1799 "${i.prefix}"` : i.format === "ends_with" ? `\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1794\u1789\u17D2\u1785\u1794\u17CB\u178A\u17C4\u1799 "${i.suffix}"` : i.format === "includes" ? `\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u1798\u17B6\u1793 "${i.includes}"` : i.format === "regex" ? `\u1781\u17D2\u179F\u17C2\u17A2\u1780\u17D2\u179F\u179A\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u178F\u17C2\u1795\u17D2\u1782\u17BC\u1795\u17D2\u1782\u1784\u1793\u17B9\u1784\u1791\u1798\u17D2\u179A\u1784\u17CB\u178A\u17C2\u179B\u1794\u17B6\u1793\u1780\u17C6\u178E\u178F\u17CB ${i.pattern}` : `\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 ${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `\u179B\u17C1\u1781\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u17D6 \u178F\u17D2\u179A\u17BC\u179C\u178F\u17C2\u1787\u17B6\u1796\u17A0\u17BB\u1782\u17BB\u178E\u1793\u17C3 ${n.divisor}`;
      case "unrecognized_keys":
        return `\u179A\u1780\u1783\u17BE\u1789\u179F\u17C4\u1798\u17B7\u1793\u179F\u17D2\u1782\u17B6\u179B\u17CB\u17D6 ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `\u179F\u17C4\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u1793\u17C5\u1780\u17D2\u1793\u17BB\u1784 ${n.origin}`;
      case "invalid_union":
        return "\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C";
      case "invalid_element":
        return `\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C\u1793\u17C5\u1780\u17D2\u1793\u17BB\u1784 ${n.origin}`;
      default:
        return "\u1791\u17B7\u1793\u17D2\u1793\u1793\u17D0\u1799\u1798\u17B7\u1793\u178F\u17D2\u179A\u17B9\u1798\u178F\u17D2\u179A\u17BC\u179C";
    }
  };
}, "error");
function gn() {
  return {
    localeError: sy()
  };
}
s(gn, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/kh.js
function gu() {
  return gn();
}
s(gu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/kn.js
var uy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0C85\u0C95\u0CCD\u0CB7\u0CB0\u0C97\u0CB3\u0CC1", verb: "\u0CB9\u0CCA\u0C82\u0CA6\u0CB2\u0CC1" },
    file: { unit: "\u0CAC\u0CC8\u0C9F\u0CCD\u200C\u0C97\u0CB3\u0CC1", verb: "\u0CB9\u0CCA\u0C82\u0CA6\u0CB2\u0CC1" },
    array: { unit: "\u0CB5\u0CB8\u0CCD\u0CA4\u0CC1\u0C97\u0CB3\u0CC1", verb: "\u0CB9\u0CCA\u0C82\u0CA6\u0CB2\u0CC1" },
    set: { unit: "\u0CB5\u0CB8\u0CCD\u0CA4\u0CC1\u0C97\u0CB3\u0CC1", verb: "\u0CB9\u0CCA\u0C82\u0CA6\u0CB2\u0CC1" },
    map: { unit: "entries", verb: "\u0CB9\u0CCA\u0C82\u0CA6\u0CB2\u0CC1" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "\u0C87\u0CA8\u0CCD\u0CAA\u0CC1\u0C9F\u0CCD",
    email: "email \u0CB5\u0CBF\u0CB3\u0CBE\u0CB8",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0CA6\u0CBF\u0CA8\u0CBE\u0C82\u0C95\u0CA6 \u0CB8\u0CAE\u0CAF",
    date: "ISO \u0CA6\u0CBF\u0CA8\u0CBE\u0C82\u0C95",
    time: "ISO \u0CB8\u0CAE\u0CAF",
    duration: "ISO \u0C85\u0CB5\u0CA7\u0CBF",
    ipv4: "IPv4 \u0CB5\u0CBF\u0CB3\u0CBE\u0CB8",
    ipv6: "IPv6 \u0CB5\u0CBF\u0CB3\u0CBE\u0CB8",
    mac: "MAC \u0CB5\u0CBF\u0CB3\u0CBE\u0CB8",
    cidrv4: "IPv4 \u0CB5\u0CCD\u0CAF\u0CBE\u0CAA\u0CCD\u0CA4\u0CBF\u0CAF",
    cidrv6: "IPv6 \u0CB5\u0CCD\u0CAF\u0CBE\u0CAA\u0CCD\u0CA4\u0CBF\u0CAF",
    base64: "base64-encoded\u0CB8\u0CCD\u0C9F\u0CCD\u0CB0\u0CBF\u0C82\u0C97\u0CCD",
    base64url: "base64url-encoded\u0CB8\u0CCD\u0C9F\u0CCD\u0CB0\u0CBF\u0C82\u0C97\u0CCD",
    json_string: "JSON\u0CB8\u0CCD\u0C9F\u0CCD\u0CB0\u0CBF\u0C82\u0C97\u0CCD",
    e164: "E.164 \u0CB8\u0C82\u0C96\u0CCD\u0CAF\u0CC6",
    credit_card: "\u0C95\u0CCD\u0CB0\u0CC6\u0CA1\u0CBF\u0C9F\u0CCD \u0C95\u0CBE\u0CB0\u0CCD\u0CA1\u0CCD \u0CB8\u0C82\u0C96\u0CCD\u0CAF\u0CC6",
    jwt: "JWT",
    template_literal: "\u0C87\u0CA8\u0CCD\u0CAA\u0CC1\u0C9F\u0CCD"
  }, o = {
    // Compatibility: "nan" -> "NaN" for display
    nan: "NaN"
    // All other type names omitted - they fall back to raw values via ?? operator
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0C87\u0CA8\u0CCD\u200C\u0CAA\u0CC1\u0C9F\u0CCD: \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${i}, \u0CB8\u0CCD\u0CB5\u0CC0\u0C95\u0CB0\u0CBF\u0CB8\u0CBF\u0CA6\u0CA8\u0CC1 ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0C87\u0CA8\u0CCD\u200C\u0CAA\u0CC1\u0C9F\u0CCD: \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${$(n.values[0])}` : `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0C86\u0CAF\u0CCD\u0C95\u0CC6: \u0C87\u0CB5\u0CC1\u0C97\u0CB3\u0CB2\u0CCD\u0CB2\u0CBF \u0C92\u0C82\u0CA6\u0CA8\u0CCD\u0CA8\u0CC1 \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${m(n.values, "|")}`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin);
        return a ? `\u0CA4\u0CC1\u0C82\u0CAC\u0CBE \u0CA6\u0CCA\u0CA1\u0CCD\u0CA1\u0CA6\u0CC1: \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${n.origin ?? "value"} \u0CB9\u0CCA\u0C82\u0CA6\u0CB2\u0CC1 ${i}${n.maximum.toString()} ${a.unit ?? "\u0C85\u0C82\u0CB6\u0C97\u0CB3\u0CC1"}` : `\u0CA4\u0CC1\u0C82\u0CAC\u0CBE \u0CA6\u0CCA\u0CA1\u0CCD\u0CA1\u0CA6\u0CC1: \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${n.origin ?? "value"} \u0C8E\u0C82\u0CA6\u0CC1 ${i}${n.maximum.toString()}`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin);
        return a ? `\u0CA4\u0CC1\u0C82\u0CAC\u0CBE \u0C9A\u0CBF\u0C95\u0CCD\u0C95\u0CA6\u0CC1: \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${n.origin} \u0CB9\u0CCA\u0C82\u0CA6\u0CB2\u0CC1 ${i}${n.minimum.toString()} ${a.unit}` : `\u0CA4\u0CC1\u0C82\u0CAC\u0CBE \u0C9A\u0CBF\u0C95\u0CCD\u0C95\u0CA6\u0CC1: \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${n.origin} \u0C8E\u0C82\u0CA6\u0CC1 ${i}${n.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF\u0CB5\u0CBE\u0CA6 \u0CB8\u0CCD\u0C9F\u0CCD\u0CB0\u0CBF\u0C82\u0C97\u0CCD: \u0C87\u0CA6\u0CB0\u0CCA\u0C82\u0CA6\u0CBF\u0C97\u0CC6 \u0CAA\u0CCD\u0CB0\u0CBE\u0CB0\u0C82\u0CAD\u0CBF\u0CB8\u0CAC\u0CC7\u0C95\u0CC1 "${i.prefix}"` : i.format === "ends_with" ? `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF\u0CB5\u0CBE\u0CA6 \u0CB8\u0CCD\u0C9F\u0CCD\u0CB0\u0CBF\u0C82\u0C97\u0CCD: \u0C87\u0CA6\u0CB0\u0CCA\u0C82\u0CA6\u0CBF\u0C97\u0CC6 \u0C95\u0CCA\u0CA8\u0CC6\u0C97\u0CCA\u0CB3\u0CCD\u0CB3\u0CAC\u0CC7\u0C95\u0CC1 "${i.suffix}"` : i.format === "includes" ? `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0CB8\u0CCD\u0C9F\u0CCD\u0CB0\u0CBF\u0C82\u0C97\u0CCD: \u0C92\u0CB3\u0C97\u0CCA\u0C82\u0CA1\u0CBF\u0CB0\u0CAC\u0CC7\u0C95\u0CC1 "${i.includes}"` : i.format === "regex" ? `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF\u0CB5\u0CBE\u0CA6 \u0CB8\u0CCD\u0C9F\u0CCD\u0CB0\u0CBF\u0C82\u0C97\u0CCD: \u0CAE\u0CBE\u0CA6\u0CB0\u0CBF\u0C97\u0CC6 \u0CB9\u0CCA\u0C82\u0CA6\u0CBF\u0C95\u0CC6\u0CAF\u0CBE\u0C97\u0CAC\u0CC7\u0C95\u0CC1 ${i.pattern}` : `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF ${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0CB8\u0C82\u0C96\u0CCD\u0CAF\u0CC6: \u0CAC\u0CB9\u0CC1\u0CB8\u0C82\u0C96\u0CCD\u0CAF\u0CC6\u0CAF\u0CBE\u0C97\u0CBF\u0CB0\u0CAC\u0CC7\u0C95\u0CC1 ${n.divisor}`;
      case "unrecognized_keys":
        return `\u0C97\u0CC1\u0CB0\u0CC1\u0CA4\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CA6 \u0C95\u0CC0 ${n.keys.length > 1 ? "s" : ""}: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF\u0CB5\u0CBE\u0CA6 \u0C95\u0CC0 \u0C87\u0CA8\u0CCD ${n.origin}`;
      case "invalid_union":
        return n.options && Array.isArray(n.options) && n.options.length > 0 ? `\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0CA4\u0CBE\u0CB0\u0CA4\u0CAE\u0CCD\u0CAF \u0CAE\u0CCC\u0CB2\u0CCD\u0CAF. \u0CA8\u0CBF\u0CB0\u0CC0\u0C95\u0CCD\u0CB7\u0CBF\u0CB8\u0CB2\u0CBE\u0C97\u0CBF\u0CA6\u0CC6 ${n.options.map((a) => `'${a}'`).join(" | ")}` : "\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0C87\u0CA8\u0CCD\u200C\u0CAA\u0CC1\u0C9F\u0CCD";
      case "invalid_element":
        return `\u0CB0\u0CB2\u0CCD\u0CB2\u0CBF \u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0CAE\u0CCC\u0CB2\u0CCD\u0CAF ${n.origin}`;
      default:
        return "\u0C85\u0CAE\u0CBE\u0CA8\u0CCD\u0CAF \u0C87\u0CA8\u0CCD\u200C\u0CAA\u0CC1\u0C9F\u0CCD";
    }
  };
}, "error");
function hu() {
  return {
    localeError: uy()
  };
}
s(hu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ko.js
var cy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\uBB38\uC790", verb: "to have" },
    file: { unit: "\uBC14\uC774\uD2B8", verb: "to have" },
    array: { unit: "\uAC1C", verb: "to have" },
    set: { unit: "\uAC1C", verb: "to have" },
    map: { unit: "\uAC1C", verb: "to have" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "\uC785\uB825",
    email: "\uC774\uBA54\uC77C \uC8FC\uC18C",
    url: "URL",
    emoji: "\uC774\uBAA8\uC9C0",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \uB0A0\uC9DC\uC2DC\uAC04",
    date: "ISO \uB0A0\uC9DC",
    time: "ISO \uC2DC\uAC04",
    duration: "ISO \uAE30\uAC04",
    ipv4: "IPv4 \uC8FC\uC18C",
    ipv6: "IPv6 \uC8FC\uC18C",
    mac: "MAC \uC8FC\uC18C",
    cidrv4: "IPv4 \uBC94\uC704",
    cidrv6: "IPv6 \uBC94\uC704",
    base64: "base64 \uC778\uCF54\uB529 \uBB38\uC790\uC5F4",
    base64url: "base64url \uC778\uCF54\uB529 \uBB38\uC790\uC5F4",
    json_string: "JSON \uBB38\uC790\uC5F4",
    e164: "E.164 \uBC88\uD638",
    credit_card: "\uC2E0\uC6A9\uCE74\uB4DC \uBC88\uD638",
    jwt: "JWT",
    template_literal: "\uC785\uB825"
  }, o = {
    nan: "NaN"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `\uC798\uBABB\uB41C \uC785\uB825: \uC608\uC0C1 \uD0C0\uC785\uC740 instanceof ${n.expected}, \uBC1B\uC740 \uD0C0\uC785\uC740 ${u}\uC785\uB2C8\uB2E4` : `\uC798\uBABB\uB41C \uC785\uB825: \uC608\uC0C1 \uD0C0\uC785\uC740 ${i}, \uBC1B\uC740 \uD0C0\uC785\uC740 ${u}\uC785\uB2C8\uB2E4`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `\uC798\uBABB\uB41C \uC785\uB825: \uAC12\uC740 ${$(n.values[0])} \uC774\uC5B4\uC57C \uD569\uB2C8\uB2E4` : `\uC798\uBABB\uB41C \uC635\uC158: ${m(n.values, "\uB610\uB294 ")} \uC911 \uD558\uB098\uC5EC\uC57C \uD569\uB2C8\uB2E4`;
      case "too_big": {
        let i = n.inclusive ? "\uC774\uD558" : "\uBBF8\uB9CC", a = i === "\uBBF8\uB9CC" ? "\uC774\uC5B4\uC57C \uD569\uB2C8\uB2E4" : "\uC5EC\uC57C \uD569\uB2C8\uB2E4", u = t(n.origin), c = u?.unit ?? "\uC694\uC18C";
        return u ? `${n.origin ?? "\uAC12"}\uC774 \uB108\uBB34 \uD07D\uB2C8\uB2E4: ${n.maximum.toString()}${c} ${i}${a}` : `${n.origin ?? "\uAC12"}\uC774 \uB108\uBB34 \uD07D\uB2C8\uB2E4: ${n.maximum.toString()} ${i}${a}`;
      }
      case "too_small": {
        let i = n.inclusive ? "\uC774\uC0C1" : "\uCD08\uACFC", a = i === "\uC774\uC0C1" ? "\uC774\uC5B4\uC57C \uD569\uB2C8\uB2E4" : "\uC5EC\uC57C \uD569\uB2C8\uB2E4", u = t(n.origin), c = u?.unit ?? "\uC694\uC18C";
        return u ? `${n.origin ?? "\uAC12"}\uC774 \uB108\uBB34 \uC791\uC2B5\uB2C8\uB2E4: ${n.minimum.toString()}${c} ${i}${a}` : `${n.origin ?? "\uAC12"}\uC774 \uB108\uBB34 \uC791\uC2B5\uB2C8\uB2E4: ${n.minimum.toString()} ${i}${a}`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `\uC798\uBABB\uB41C \uBB38\uC790\uC5F4: "${i.prefix}"(\uC73C)\uB85C \uC2DC\uC791\uD574\uC57C \uD569\uB2C8\uB2E4` : i.format === "ends_with" ? `\uC798\uBABB\uB41C \uBB38\uC790\uC5F4: "${i.suffix}"(\uC73C)\uB85C \uB05D\uB098\uC57C \uD569\uB2C8\uB2E4` : i.format === "includes" ? `\uC798\uBABB\uB41C \uBB38\uC790\uC5F4: "${i.includes}"\uC744(\uB97C) \uD3EC\uD568\uD574\uC57C \uD569\uB2C8\uB2E4` : i.format === "regex" ? `\uC798\uBABB\uB41C \uBB38\uC790\uC5F4: \uC815\uADDC\uC2DD ${i.pattern} \uD328\uD134\uACFC \uC77C\uCE58\uD574\uC57C \uD569\uB2C8\uB2E4` : `\uC798\uBABB\uB41C ${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `\uC798\uBABB\uB41C \uC22B\uC790: ${n.divisor}\uC758 \uBC30\uC218\uC5EC\uC57C \uD569\uB2C8\uB2E4`;
      case "unrecognized_keys":
        return `\uC778\uC2DD\uD560 \uC218 \uC5C6\uB294 \uD0A4: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `\uC798\uBABB\uB41C \uD0A4: ${n.origin}`;
      case "invalid_union":
        return "\uC798\uBABB\uB41C \uC785\uB825";
      case "invalid_element":
        return `\uC798\uBABB\uB41C \uAC12: ${n.origin}`;
      default:
        return "\uC798\uBABB\uB41C \uC785\uB825";
    }
  };
}, "error");
function vu() {
  return {
    localeError: cy()
  };
}
s(vu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/lt.js
var hn = /* @__PURE__ */ s((e) => e.charAt(0).toUpperCase() + e.slice(1), "capitalizeFirstCharacter");
function Mf(e) {
  let t = Math.abs(e), r = t % 10, o = t % 100;
  return o >= 11 && o <= 19 || r === 0 ? "many" : r === 1 ? "one" : "few";
}
s(Mf, "getUnitTypeFromNumber");
var ly = /* @__PURE__ */ s(() => {
  let e = {
    string: {
      unit: {
        one: "simbolis",
        few: "simboliai",
        many: "simboli\u0173"
      },
      verb: {
        smaller: {
          inclusive: "turi b\u016Bti ne ilgesn\u0117 kaip",
          notInclusive: "turi b\u016Bti trumpesn\u0117 kaip"
        },
        bigger: {
          inclusive: "turi b\u016Bti ne trumpesn\u0117 kaip",
          notInclusive: "turi b\u016Bti ilgesn\u0117 kaip"
        }
      }
    },
    file: {
      unit: {
        one: "baitas",
        few: "baitai",
        many: "bait\u0173"
      },
      verb: {
        smaller: {
          inclusive: "turi b\u016Bti ne didesnis kaip",
          notInclusive: "turi b\u016Bti ma\u017Eesnis kaip"
        },
        bigger: {
          inclusive: "turi b\u016Bti ne ma\u017Eesnis kaip",
          notInclusive: "turi b\u016Bti didesnis kaip"
        }
      }
    },
    array: {
      unit: {
        one: "element\u0105",
        few: "elementus",
        many: "element\u0173"
      },
      verb: {
        smaller: {
          inclusive: "turi tur\u0117ti ne daugiau kaip",
          notInclusive: "turi tur\u0117ti ma\u017Eiau kaip"
        },
        bigger: {
          inclusive: "turi tur\u0117ti ne ma\u017Eiau kaip",
          notInclusive: "turi tur\u0117ti daugiau kaip"
        }
      }
    },
    set: {
      unit: {
        one: "element\u0105",
        few: "elementus",
        many: "element\u0173"
      },
      verb: {
        smaller: {
          inclusive: "turi tur\u0117ti ne daugiau kaip",
          notInclusive: "turi tur\u0117ti ma\u017Eiau kaip"
        },
        bigger: {
          inclusive: "turi tur\u0117ti ne ma\u017Eiau kaip",
          notInclusive: "turi tur\u0117ti daugiau kaip"
        }
      }
    }
  };
  function t(n, i, a, u) {
    let c = e[n] ?? null;
    return c === null ? c : {
      unit: c.unit[i],
      verb: c.verb[u][a ? "inclusive" : "notInclusive"]
    };
  }
  s(t, "getSizing");
  let r = {
    regex: "\u012Fvestis",
    email: "el. pa\u0161to adresas",
    url: "URL",
    emoji: "jaustukas",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO data ir laikas",
    date: "ISO data",
    time: "ISO laikas",
    duration: "ISO trukm\u0117",
    ipv4: "IPv4 adresas",
    ipv6: "IPv6 adresas",
    mac: "MAC adresas",
    cidrv4: "IPv4 tinklo prefiksas (CIDR)",
    cidrv6: "IPv6 tinklo prefiksas (CIDR)",
    base64: "base64 u\u017Ekoduota eilut\u0117",
    base64url: "base64url u\u017Ekoduota eilut\u0117",
    json_string: "JSON eilut\u0117",
    e164: "E.164 numeris",
    credit_card: "kredito kortel\u0117s numeris",
    jwt: "JWT",
    template_literal: "\u012Fvestis"
  }, o = {
    nan: "NaN",
    number: "skai\u010Dius",
    bigint: "sveikasis skai\u010Dius",
    string: "eilut\u0117",
    boolean: "login\u0117 reik\u0161m\u0117",
    undefined: "neapibr\u0117\u017Eta reik\u0161m\u0117",
    function: "funkcija",
    symbol: "simbolis",
    array: "masyvas",
    object: "objektas",
    null: "nulin\u0117 reik\u0161m\u0117"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `Gautas tipas ${u}, o tik\u0117tasi - instanceof ${n.expected}` : `Gautas tipas ${u}, o tik\u0117tasi - ${i}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `Privalo b\u016Bti ${$(n.values[0])}` : `Privalo b\u016Bti vienas i\u0161 ${m(n.values, "|")} pasirinkim\u0173`;
      case "too_big": {
        let i = o[n.origin] ?? n.origin, a = t(n.origin, Mf(Number(n.maximum)), n.inclusive ?? !1, "smaller");
        if (a?.verb)
          return `${hn(i ?? n.origin ?? "reik\u0161m\u0117")} ${a.verb} ${n.maximum.toString()} ${a.unit ?? "element\u0173"}`;
        let u = n.inclusive ? "ne didesnis kaip" : "ma\u017Eesnis kaip";
        return `${hn(i ?? n.origin ?? "reik\u0161m\u0117")} turi b\u016Bti ${u} ${n.maximum.toString()} ${a?.unit}`;
      }
      case "too_small": {
        let i = o[n.origin] ?? n.origin, a = t(n.origin, Mf(Number(n.minimum)), n.inclusive ?? !1, "bigger");
        if (a?.verb)
          return `${hn(i ?? n.origin ?? "reik\u0161m\u0117")} ${a.verb} ${n.minimum.toString()} ${a.unit ?? "element\u0173"}`;
        let u = n.inclusive ? "ne ma\u017Eesnis kaip" : "didesnis kaip";
        return `${hn(i ?? n.origin ?? "reik\u0161m\u0117")} turi b\u016Bti ${u} ${n.minimum.toString()} ${a?.unit}`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `Eilut\u0117 privalo prasid\u0117ti "${i.prefix}"` : i.format === "ends_with" ? `Eilut\u0117 privalo pasibaigti "${i.suffix}"` : i.format === "includes" ? `Eilut\u0117 privalo \u012Ftraukti "${i.includes}"` : i.format === "regex" ? `Eilut\u0117 privalo atitikti ${i.pattern}` : `Neteisingas ${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `Skai\u010Dius privalo b\u016Bti ${n.divisor} kartotinis.`;
      case "unrecognized_keys":
        return `Neatpa\u017Eint${n.keys.length > 1 ? "i" : "as"} rakt${n.keys.length > 1 ? "ai" : "as"}: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return "Rastas klaidingas raktas";
      case "invalid_union":
        return "Klaidinga \u012Fvestis";
      case "invalid_element": {
        let i = o[n.origin] ?? n.origin;
        return `${hn(i ?? n.origin ?? "reik\u0161m\u0117")} turi klaiding\u0105 \u012Fvest\u012F`;
      }
      default:
        return "Klaidinga \u012Fvestis";
    }
  };
}, "error");
function yu() {
  return {
    localeError: ly()
  };
}
s(yu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/mk.js
var dy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0437\u043D\u0430\u0446\u0438", verb: "\u0434\u0430 \u0438\u043C\u0430\u0430\u0442" },
    file: { unit: "\u0431\u0430\u0458\u0442\u0438", verb: "\u0434\u0430 \u0438\u043C\u0430\u0430\u0442" },
    array: { unit: "\u0441\u0442\u0430\u0432\u043A\u0438", verb: "\u0434\u0430 \u0438\u043C\u0430\u0430\u0442" },
    set: { unit: "\u0441\u0442\u0430\u0432\u043A\u0438", verb: "\u0434\u0430 \u0438\u043C\u0430\u0430\u0442" },
    map: { unit: "\u0441\u0442\u0430\u0432\u043A\u0438", verb: "\u0434\u0430 \u0438\u043C\u0430\u0430\u0442" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "\u0432\u043D\u0435\u0441",
    email: "\u0430\u0434\u0440\u0435\u0441\u0430 \u043D\u0430 \u0435-\u043F\u043E\u0448\u0442\u0430",
    url: "URL",
    emoji: "\u0435\u043C\u043E\u045F\u0438",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0434\u0430\u0442\u0443\u043C \u0438 \u0432\u0440\u0435\u043C\u0435",
    date: "ISO \u0434\u0430\u0442\u0443\u043C",
    time: "ISO \u0432\u0440\u0435\u043C\u0435",
    duration: "ISO \u0432\u0440\u0435\u043C\u0435\u0442\u0440\u0430\u0435\u045A\u0435",
    ipv4: "IPv4 \u0430\u0434\u0440\u0435\u0441\u0430",
    ipv6: "IPv6 \u0430\u0434\u0440\u0435\u0441\u0430",
    mac: "MAC \u0430\u0434\u0440\u0435\u0441\u0430",
    cidrv4: "IPv4 \u043E\u043F\u0441\u0435\u0433",
    cidrv6: "IPv6 \u043E\u043F\u0441\u0435\u0433",
    base64: "base64-\u0435\u043D\u043A\u043E\u0434\u0438\u0440\u0430\u043D\u0430 \u043D\u0438\u0437\u0430",
    base64url: "base64url-\u0435\u043D\u043A\u043E\u0434\u0438\u0440\u0430\u043D\u0430 \u043D\u0438\u0437\u0430",
    json_string: "JSON \u043D\u0438\u0437\u0430",
    e164: "E.164 \u0431\u0440\u043E\u0458",
    credit_card: "\u0431\u0440\u043E\u0458 \u043D\u0430 \u043A\u0440\u0435\u0434\u0438\u0442\u043D\u0430 \u043A\u0430\u0440\u0442\u0438\u0447\u043A\u0430",
    jwt: "JWT",
    template_literal: "\u0432\u043D\u0435\u0441"
  }, o = {
    nan: "NaN",
    number: "\u0431\u0440\u043E\u0458",
    array: "\u043D\u0438\u0437\u0430"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `\u0413\u0440\u0435\u0448\u0435\u043D \u0432\u043D\u0435\u0441: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 instanceof ${n.expected}, \u043F\u0440\u0438\u043C\u0435\u043D\u043E ${u}` : `\u0413\u0440\u0435\u0448\u0435\u043D \u0432\u043D\u0435\u0441: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${i}, \u043F\u0440\u0438\u043C\u0435\u043D\u043E ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `Invalid input: expected ${$(n.values[0])}` : `\u0413\u0440\u0435\u0448\u0430\u043D\u0430 \u043E\u043F\u0446\u0438\u0458\u0430: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 \u0435\u0434\u043D\u0430 ${m(n.values, "|")}`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin);
        return a ? `\u041F\u0440\u0435\u043C\u043D\u043E\u0433\u0443 \u0433\u043E\u043B\u0435\u043C: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${n.origin ?? "\u0432\u0440\u0435\u0434\u043D\u043E\u0441\u0442\u0430"} \u0434\u0430 \u0438\u043C\u0430 ${i}${n.maximum.toString()} ${a.unit ?? "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0438"}` : `\u041F\u0440\u0435\u043C\u043D\u043E\u0433\u0443 \u0433\u043E\u043B\u0435\u043C: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${n.origin ?? "\u0432\u0440\u0435\u0434\u043D\u043E\u0441\u0442\u0430"} \u0434\u0430 \u0431\u0438\u0434\u0435 ${i}${n.maximum.toString()}`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin);
        return a ? `\u041F\u0440\u0435\u043C\u043D\u043E\u0433\u0443 \u043C\u0430\u043B: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${n.origin} \u0434\u0430 \u0438\u043C\u0430 ${i}${n.minimum.toString()} ${a.unit}` : `\u041F\u0440\u0435\u043C\u043D\u043E\u0433\u0443 \u043C\u0430\u043B: \u0441\u0435 \u043E\u0447\u0435\u043A\u0443\u0432\u0430 ${n.origin} \u0434\u0430 \u0431\u0438\u0434\u0435 ${i}${n.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `\u041D\u0435\u0432\u0430\u0436\u0435\u0447\u043A\u0430 \u043D\u0438\u0437\u0430: \u043C\u043E\u0440\u0430 \u0434\u0430 \u0437\u0430\u043F\u043E\u0447\u043D\u0443\u0432\u0430 \u0441\u043E "${i.prefix}"` : i.format === "ends_with" ? `\u041D\u0435\u0432\u0430\u0436\u0435\u0447\u043A\u0430 \u043D\u0438\u0437\u0430: \u043C\u043E\u0440\u0430 \u0434\u0430 \u0437\u0430\u0432\u0440\u0448\u0443\u0432\u0430 \u0441\u043E "${i.suffix}"` : i.format === "includes" ? `\u041D\u0435\u0432\u0430\u0436\u0435\u0447\u043A\u0430 \u043D\u0438\u0437\u0430: \u043C\u043E\u0440\u0430 \u0434\u0430 \u0432\u043A\u043B\u0443\u0447\u0443\u0432\u0430 "${i.includes}"` : i.format === "regex" ? `\u041D\u0435\u0432\u0430\u0436\u0435\u0447\u043A\u0430 \u043D\u0438\u0437\u0430: \u043C\u043E\u0440\u0430 \u0434\u0430 \u043E\u0434\u0433\u043E\u0430\u0440\u0430 \u043D\u0430 \u043F\u0430\u0442\u0435\u0440\u043D\u043E\u0442 ${i.pattern}` : `Invalid ${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `\u0413\u0440\u0435\u0448\u0435\u043D \u0431\u0440\u043E\u0458: \u043C\u043E\u0440\u0430 \u0434\u0430 \u0431\u0438\u0434\u0435 \u0434\u0435\u043B\u0438\u0432 \u0441\u043E ${n.divisor}`;
      case "unrecognized_keys":
        return `${n.keys.length > 1 ? "\u041D\u0435\u043F\u0440\u0435\u043F\u043E\u0437\u043D\u0430\u0435\u043D\u0438 \u043A\u043B\u0443\u0447\u0435\u0432\u0438" : "\u041D\u0435\u043F\u0440\u0435\u043F\u043E\u0437\u043D\u0430\u0435\u043D \u043A\u043B\u0443\u0447"}: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `\u0413\u0440\u0435\u0448\u0435\u043D \u043A\u043B\u0443\u0447 \u0432\u043E ${n.origin}`;
      case "invalid_union":
        return "\u0413\u0440\u0435\u0448\u0435\u043D \u0432\u043D\u0435\u0441";
      case "invalid_element":
        return `\u0413\u0440\u0435\u0448\u043D\u0430 \u0432\u0440\u0435\u0434\u043D\u043E\u0441\u0442 \u0432\u043E ${n.origin}`;
      default:
        return "\u0413\u0440\u0435\u0448\u0435\u043D \u0432\u043D\u0435\u0441";
    }
  };
}, "error");
function $u() {
  return {
    localeError: dy()
  };
}
s($u, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ms.js
var fy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "aksara", verb: "mempunyai" },
    file: { unit: "bait", verb: "mempunyai" },
    array: { unit: "elemen", verb: "mempunyai" },
    set: { unit: "elemen", verb: "mempunyai" },
    map: { unit: "elemen", verb: "mempunyai" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "input",
    email: "alamat e-mel",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "tarikh masa ISO",
    date: "tarikh ISO",
    time: "masa ISO",
    duration: "tempoh ISO",
    ipv4: "alamat IPv4",
    ipv6: "alamat IPv6",
    mac: "alamat MAC",
    cidrv4: "julat IPv4",
    cidrv6: "julat IPv6",
    base64: "string dikodkan base64",
    base64url: "string dikodkan base64url",
    json_string: "string JSON",
    e164: "nombor E.164",
    credit_card: "nombor kad kredit",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN",
    number: "nombor"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `Input tidak sah: dijangka instanceof ${n.expected}, diterima ${u}` : `Input tidak sah: dijangka ${i}, diterima ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `Input tidak sah: dijangka ${$(n.values[0])}` : `Pilihan tidak sah: dijangka salah satu daripada ${m(n.values, "|")}`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin);
        return a ? `Terlalu besar: dijangka ${n.origin ?? "nilai"} ${a.verb} ${i}${n.maximum.toString()} ${a.unit ?? "elemen"}` : `Terlalu besar: dijangka ${n.origin ?? "nilai"} adalah ${i}${n.maximum.toString()}`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin);
        return a ? `Terlalu kecil: dijangka ${n.origin} ${a.verb} ${i}${n.minimum.toString()} ${a.unit}` : `Terlalu kecil: dijangka ${n.origin} adalah ${i}${n.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `String tidak sah: mesti bermula dengan "${i.prefix}"` : i.format === "ends_with" ? `String tidak sah: mesti berakhir dengan "${i.suffix}"` : i.format === "includes" ? `String tidak sah: mesti mengandungi "${i.includes}"` : i.format === "regex" ? `String tidak sah: mesti sepadan dengan corak ${i.pattern}` : `${r[i.format] ?? n.format} tidak sah`;
      }
      case "not_multiple_of":
        return `Nombor tidak sah: perlu gandaan ${n.divisor}`;
      case "unrecognized_keys":
        return `Kunci tidak dikenali: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `Kunci tidak sah dalam ${n.origin}`;
      case "invalid_union":
        return "Input tidak sah";
      case "invalid_element":
        return `Nilai tidak sah dalam ${n.origin}`;
      default:
        return "Input tidak sah";
    }
  };
}, "error");
function bu() {
  return {
    localeError: fy()
  };
}
s(bu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ne.js
var py = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0905\u0915\u094D\u0937\u0930", verb: "\u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B" },
    file: { unit: "\u092C\u093E\u0907\u091F", verb: "\u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B" },
    array: { unit: "\u0924\u0924\u094D\u0935", verb: "\u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B" },
    set: { unit: "\u0924\u0924\u094D\u0935", verb: "\u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B" },
    map: { unit: "\u092A\u094D\u0930\u0935\u093F\u0937\u094D\u091F\u093F", verb: "\u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "\u0907\u0928\u092A\u0941\u091F",
    email: "\u0907\u092E\u0947\u0932 \u0920\u0947\u0917\u093E\u0928\u093E",
    url: "URL",
    emoji: "\u0907\u092E\u094B\u091C\u0940",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u092E\u093F\u0924\u093F \u0930 \u0938\u092E\u092F",
    date: "ISO \u092E\u093F\u0924\u093F",
    time: "ISO \u0938\u092E\u092F",
    duration: "ISO \u0905\u0935\u0927\u093F",
    ipv4: "IPv4 \u0920\u0947\u0917\u093E\u0928\u093E",
    ipv6: "IPv6 \u0920\u0947\u0917\u093E\u0928\u093E",
    mac: "MAC \u0920\u0947\u0917\u093E\u0928\u093E",
    cidrv4: "IPv4 \u0926\u093E\u092F\u0930\u093E",
    cidrv6: "IPv6 \u0926\u093E\u092F\u0930\u093E",
    base64: "base64-\u0907\u0928\u094D\u0915\u094B\u0921 \u0917\u0930\u093F\u090F\u0915\u094B \u0938\u094D\u091F\u094D\u0930\u093F\u0919",
    base64url: "base64url-\u0907\u0928\u094D\u0915\u094B\u0921 \u0917\u0930\u093F\u090F\u0915\u094B \u0938\u094D\u091F\u094D\u0930\u093F\u0919",
    json_string: "JSON \u0938\u094D\u091F\u094D\u0930\u093F\u0919",
    e164: "E.164 \u0928\u092E\u094D\u092C\u0930",
    credit_card: "\u0915\u094D\u0930\u0947\u0921\u093F\u091F \u0915\u093E\u0930\u094D\u0921 \u0928\u092E\u094D\u092C\u0930",
    jwt: "JWT",
    template_literal: "\u0907\u0928\u092A\u0941\u091F"
  }, o = {
    nan: "NaN"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return `\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 ${i}, \u092A\u094D\u0930\u093E\u092A\u094D\u0924 ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 ${$(n.values[0])}` : `\u0905\u092E\u093E\u0928\u094D\u092F \u0935\u093F\u0915\u0932\u094D\u092A: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 \u092E\u093E\u0928\u0939\u0930\u0942 \u092E\u0927\u094D\u092F\u0947 \u090F\u0915 ${m(n.values, "|")}`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin);
        return a ? `\u0927\u0947\u0930\u0948 \u0920\u0942\u0932\u094B: ${n.origin ?? "\u092E\u093E\u0928"} \u092E\u093E ${i}${n.maximum.toString()} ${a.unit} ${a.verb}` : `\u0927\u0947\u0930\u0948 \u0920\u0942\u0932\u094B: ${n.origin ?? "\u092E\u093E\u0928"} ${i}${n.maximum.toString()} \u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin);
        return a ? `\u0927\u0947\u0930\u0948 \u0938\u093E\u0928\u094B: ${n.origin} \u092E\u093E ${i}${n.minimum.toString()} ${a.unit} ${a.verb}` : `\u0927\u0947\u0930\u0948 \u0938\u093E\u0928\u094B: ${n.origin} ${i}${n.minimum.toString()} \u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0919: "${i.prefix}" \u092C\u093E\u091F \u0938\u0941\u0930\u0941 \u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B` : i.format === "ends_with" ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0919: "${i.suffix}" \u092E\u093E \u0938\u092E\u093E\u092A\u094D\u0924 \u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B` : i.format === "includes" ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0919: "${i.includes}" \u0938\u092E\u093E\u0935\u0947\u0936 \u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B` : i.format === "regex" ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u094D\u091F\u094D\u0930\u093F\u0919: \u0922\u093E\u0901\u091A\u093E ${i.pattern} \u0938\u0901\u0917 \u092E\u0947\u0932 \u0916\u093E\u0928\u0941\u092A\u0930\u094D\u091B` : `\u0905\u092E\u093E\u0928\u094D\u092F ${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `\u0905\u092E\u093E\u0928\u094D\u092F \u0938\u0902\u0916\u094D\u092F\u093E: ${n.divisor} \u0915\u094B \u0917\u0941\u0923\u091C \u0939\u0941\u0928\u0941\u092A\u0930\u094D\u091B`;
      case "unrecognized_keys":
        return `\u0905\u092A\u0930\u093F\u091A\u093F\u0924 \u0915\u0941\u091E\u094D\u091C\u0940${n.keys.length > 1 ? "\u0939\u0930\u0942" : ""}: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `\u0905\u092E\u093E\u0928\u094D\u092F \u0915\u0941\u091E\u094D\u091C\u0940: ${n.origin} \u092E\u093E`;
      case "invalid_union":
        return n.options && Array.isArray(n.options) && n.options.length > 0 ? `\u0905\u092E\u093E\u0928\u094D\u092F \u0921\u093F\u0938\u094D\u0915\u094D\u0930\u093F\u092E\u093F\u0928\u0947\u091F\u0930 \u092E\u093E\u0928: \u0905\u092A\u0947\u0915\u094D\u0937\u093F\u0924 ${n.options.map((a) => `'${a}'`).join(" | ")}` : "\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F";
      case "invalid_element":
        return `\u0905\u092E\u093E\u0928\u094D\u092F \u092E\u093E\u0928: ${n.origin} \u092E\u093E`;
      default:
        return "\u0905\u092E\u093E\u0928\u094D\u092F \u0907\u0928\u092A\u0941\u091F";
    }
  };
}, "error");
function _u() {
  return {
    localeError: py()
  };
}
s(_u, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/nl.js
var my = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "tekens", verb: "heeft" },
    file: { unit: "bytes", verb: "heeft" },
    array: { unit: "elementen", verb: "heeft" },
    set: { unit: "elementen", verb: "heeft" },
    map: { unit: "elementen", verb: "heeft" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "invoer",
    email: "emailadres",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datum en tijd",
    date: "ISO datum",
    time: "ISO tijd",
    duration: "ISO duur",
    ipv4: "IPv4-adres",
    ipv6: "IPv6-adres",
    mac: "MAC-adres",
    cidrv4: "IPv4-bereik",
    cidrv6: "IPv6-bereik",
    base64: "base64-gecodeerde tekst",
    base64url: "base64 URL-gecodeerde tekst",
    json_string: "JSON string",
    e164: "E.164-nummer",
    credit_card: "creditcardnummer",
    jwt: "JWT",
    template_literal: "invoer"
  }, o = {
    nan: "NaN",
    number: "getal"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `Ongeldige invoer: verwacht instanceof ${n.expected}, ontving ${u}` : `Ongeldige invoer: verwacht ${i}, ontving ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `Ongeldige invoer: verwacht ${$(n.values[0])}` : `Ongeldige optie: verwacht \xE9\xE9n van ${m(n.values, "|")}`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin), u = n.origin === "date" ? "laat" : n.origin === "string" ? "lang" : "groot";
        return a ? `Te ${u}: verwacht dat ${n.origin ?? "waarde"} ${i}${n.maximum.toString()} ${a.unit ?? "elementen"} ${a.verb}` : `Te ${u}: verwacht dat ${n.origin ?? "waarde"} ${i}${n.maximum.toString()} is`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin), u = n.origin === "date" ? "vroeg" : n.origin === "string" ? "kort" : "klein";
        return a ? `Te ${u}: verwacht dat ${n.origin} ${i}${n.minimum.toString()} ${a.unit} ${a.verb}` : `Te ${u}: verwacht dat ${n.origin} ${i}${n.minimum.toString()} is`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `Ongeldige tekst: moet met "${i.prefix}" beginnen` : i.format === "ends_with" ? `Ongeldige tekst: moet op "${i.suffix}" eindigen` : i.format === "includes" ? `Ongeldige tekst: moet "${i.includes}" bevatten` : i.format === "regex" ? `Ongeldige tekst: moet overeenkomen met patroon ${i.pattern}` : `Ongeldig: ${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `Ongeldig getal: moet een veelvoud van ${n.divisor} zijn`;
      case "unrecognized_keys":
        return `Onbekende key${n.keys.length > 1 ? "s" : ""}: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `Ongeldige key in ${n.origin}`;
      case "invalid_union":
        return "Ongeldige invoer";
      case "invalid_element":
        return `Ongeldige waarde in ${n.origin}`;
      default:
        return "Ongeldige invoer";
    }
  };
}, "error");
function xu() {
  return {
    localeError: my()
  };
}
s(xu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/nn.js
var gy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "teikn", verb: "\xE5 ha" },
    file: { unit: "bytes", verb: "\xE5 ha" },
    array: { unit: "element", verb: "\xE5 innehalde" },
    set: { unit: "element", verb: "\xE5 innehalde" },
    map: { unit: "element", verb: "\xE5 innehalde" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "input",
    email: "e-postadresse",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO dato- og klokkeslett",
    date: "ISO-dato",
    time: "ISO-klokkeslett",
    duration: "ISO-varigheit",
    ipv4: "IPv4-adresse",
    ipv6: "IPv6-adresse",
    mac: "MAC-adresse",
    cidrv4: "IPv4-spekter",
    cidrv6: "IPv6-spekter",
    base64: "base64-enkoda streng",
    base64url: "base64url-enkoda streng",
    json_string: "JSON-streng",
    e164: "E.164-nummer",
    credit_card: "kredittkortnummer",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN",
    number: "tal",
    array: "liste"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `Ugyldig input: forventa instanceof ${n.expected}, fekk ${u}` : `Ugyldig input: forventa ${i}, fekk ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `Ugyldig verdi: forventa ${$(n.values[0])}` : `Ugyldig val: forventa eitt av ${m(n.values, "|")}`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin);
        return a ? `For stor(t): forventa ${n.origin ?? "value"} til \xE5 ha ${i}${n.maximum.toString()} ${a.unit ?? "element"}` : `For stor(t): forventa ${n.origin ?? "value"} til \xE5 ha ${i}${n.maximum.toString()}`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin);
        return a ? `For lite(n): forventa ${n.origin} til \xE5 ha ${i}${n.minimum.toString()} ${a.unit}` : `For lite(n): forventa ${n.origin} til \xE5 ha ${i}${n.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `Ugyldig streng: m\xE5 starte med "${i.prefix}"` : i.format === "ends_with" ? `Ugyldig streng: m\xE5 slutte med "${i.suffix}"` : i.format === "includes" ? `Ugyldig streng: m\xE5 innehalde "${i.includes}"` : i.format === "regex" ? `Ugyldig streng: m\xE5 matche m\xF8nsteret ${i.pattern}` : `Ugyldig ${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `Ugyldig tal: m\xE5 vere eit multiplum av ${n.divisor}`;
      case "unrecognized_keys":
        return `${n.keys.length > 1 ? "Ukjende n\xF8klar" : "Ukjend n\xF8kkel"}: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `Ugyldig n\xF8kkel i ${n.origin}`;
      case "invalid_union":
        return "Ugyldig input";
      case "invalid_element":
        return `Ugyldig verdi i ${n.origin}`;
      default:
        return "Ugyldig input";
    }
  };
}, "error");
function wu() {
  return {
    localeError: gy()
  };
}
s(wu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/no.js
var hy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "tegn", verb: "\xE5 ha" },
    file: { unit: "bytes", verb: "\xE5 ha" },
    array: { unit: "elementer", verb: "\xE5 inneholde" },
    set: { unit: "elementer", verb: "\xE5 inneholde" },
    map: { unit: "elementer", verb: "\xE5 inneholde" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "input",
    email: "e-postadresse",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO dato- og klokkeslett",
    date: "ISO-dato",
    time: "ISO-klokkeslett",
    duration: "ISO-varighet",
    ipv4: "IPv4-adresse",
    ipv6: "IPv6-adresse",
    mac: "MAC-adresse",
    cidrv4: "IPv4-spekter",
    cidrv6: "IPv6-spekter",
    base64: "base64-enkodet streng",
    base64url: "base64url-enkodet streng",
    json_string: "JSON-streng",
    e164: "E.164-nummer",
    credit_card: "kredittkortnummer",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN",
    number: "tall",
    array: "liste"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `Ugyldig input: forventet instanceof ${n.expected}, fikk ${u}` : `Ugyldig input: forventet ${i}, fikk ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `Ugyldig verdi: forventet ${$(n.values[0])}` : `Ugyldig valg: forventet en av ${m(n.values, "|")}`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin);
        return a ? `For stor(t): forventet ${n.origin ?? "value"} til \xE5 ha ${i}${n.maximum.toString()} ${a.unit ?? "elementer"}` : `For stor(t): forventet ${n.origin ?? "value"} til \xE5 ha ${i}${n.maximum.toString()}`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin);
        return a ? `For lite(n): forventet ${n.origin} til \xE5 ha ${i}${n.minimum.toString()} ${a.unit}` : `For lite(n): forventet ${n.origin} til \xE5 ha ${i}${n.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `Ugyldig streng: m\xE5 starte med "${i.prefix}"` : i.format === "ends_with" ? `Ugyldig streng: m\xE5 ende med "${i.suffix}"` : i.format === "includes" ? `Ugyldig streng: m\xE5 inneholde "${i.includes}"` : i.format === "regex" ? `Ugyldig streng: m\xE5 matche m\xF8nsteret ${i.pattern}` : `Ugyldig ${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `Ugyldig tall: m\xE5 v\xE6re et multiplum av ${n.divisor}`;
      case "unrecognized_keys":
        return `${n.keys.length > 1 ? "Ukjente n\xF8kler" : "Ukjent n\xF8kkel"}: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `Ugyldig n\xF8kkel i ${n.origin}`;
      case "invalid_union":
        return "Ugyldig input";
      case "invalid_element":
        return `Ugyldig verdi i ${n.origin}`;
      default:
        return "Ugyldig input";
    }
  };
}, "error");
function Iu() {
  return {
    localeError: hy()
  };
}
s(Iu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ota.js
var vy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "harf", verb: "olmal\u0131d\u0131r" },
    file: { unit: "bayt", verb: "olmal\u0131d\u0131r" },
    array: { unit: "unsur", verb: "olmal\u0131d\u0131r" },
    set: { unit: "unsur", verb: "olmal\u0131d\u0131r" },
    map: { unit: "unsur", verb: "olmal\u0131d\u0131r" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "giren",
    email: "epostag\xE2h",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO heng\xE2m\u0131",
    date: "ISO tarihi",
    time: "ISO zaman\u0131",
    duration: "ISO m\xFCddeti",
    ipv4: "IPv4 ni\u015F\xE2n\u0131",
    ipv6: "IPv6 ni\u015F\xE2n\u0131",
    mac: "MAC ni\u015F\xE2n\u0131",
    cidrv4: "IPv4 menzili",
    cidrv6: "IPv6 menzili",
    base64: "base64-\u015Fifreli metin",
    base64url: "base64url-\u015Fifreli metin",
    json_string: "JSON metin",
    e164: "E.164 say\u0131s\u0131",
    credit_card: "i'tib\xE2r kart\u0131 numaras\u0131",
    jwt: "JWT",
    template_literal: "giren"
  }, o = {
    nan: "NaN",
    number: "numara",
    array: "saf",
    null: "gayb"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `F\xE2sit giren: umulan instanceof ${n.expected}, al\u0131nan ${u}` : `F\xE2sit giren: umulan ${i}, al\u0131nan ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `F\xE2sit giren: umulan ${$(n.values[0])}` : `F\xE2sit tercih: m\xFBteberler ${m(n.values, "|")}`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin);
        return a ? `Fazla b\xFCy\xFCk: ${n.origin ?? "value"}, ${i}${n.maximum.toString()} ${a.unit ?? "elements"} sahip olmal\u0131yd\u0131.` : `Fazla b\xFCy\xFCk: ${n.origin ?? "value"}, ${i}${n.maximum.toString()} olmal\u0131yd\u0131.`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin);
        return a ? `Fazla k\xFC\xE7\xFCk: ${n.origin}, ${i}${n.minimum.toString()} ${a.unit} sahip olmal\u0131yd\u0131.` : `Fazla k\xFC\xE7\xFCk: ${n.origin}, ${i}${n.minimum.toString()} olmal\u0131yd\u0131.`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `F\xE2sit metin: "${i.prefix}" ile ba\u015Flamal\u0131.` : i.format === "ends_with" ? `F\xE2sit metin: "${i.suffix}" ile bitmeli.` : i.format === "includes" ? `F\xE2sit metin: "${i.includes}" ihtiv\xE2 etmeli.` : i.format === "regex" ? `F\xE2sit metin: ${i.pattern} nak\u015F\u0131na uymal\u0131.` : `F\xE2sit ${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `F\xE2sit say\u0131: ${n.divisor} kat\u0131 olmal\u0131yd\u0131.`;
      case "unrecognized_keys":
        return `Tan\u0131nmayan anahtar ${n.keys.length > 1 ? "s" : ""}: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `${n.origin} i\xE7in tan\u0131nmayan anahtar var.`;
      case "invalid_union":
        return "Giren tan\u0131namad\u0131.";
      case "invalid_element":
        return `${n.origin} i\xE7in tan\u0131nmayan k\u0131ymet var.`;
      default:
        return "K\u0131ymet tan\u0131namad\u0131.";
    }
  };
}, "error");
function ku() {
  return {
    localeError: vy()
  };
}
s(ku, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ps.js
var yy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u062A\u0648\u06A9\u064A", verb: "\u0648\u0644\u0631\u064A" },
    file: { unit: "\u0628\u0627\u06CC\u067C\u0633", verb: "\u0648\u0644\u0631\u064A" },
    array: { unit: "\u062A\u0648\u06A9\u064A", verb: "\u0648\u0644\u0631\u064A" },
    set: { unit: "\u062A\u0648\u06A9\u064A", verb: "\u0648\u0644\u0631\u064A" },
    map: { unit: "\u062A\u0648\u06A9\u064A", verb: "\u0648\u0644\u0631\u064A" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "\u0648\u0631\u0648\u062F\u064A",
    email: "\u0628\u0631\u06CC\u069A\u0646\u0627\u0644\u06CC\u06A9",
    url: "\u06CC\u0648 \u0622\u0631 \u0627\u0644",
    emoji: "\u0627\u06CC\u0645\u0648\u062C\u064A",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u0646\u06CC\u067C\u0647 \u0627\u0648 \u0648\u062E\u062A",
    date: "\u0646\u06D0\u067C\u0647",
    time: "\u0648\u062E\u062A",
    duration: "\u0645\u0648\u062F\u0647",
    ipv4: "\u062F IPv4 \u067E\u062A\u0647",
    ipv6: "\u062F IPv6 \u067E\u062A\u0647",
    mac: "\u062F MAC \u067E\u062A\u0647",
    cidrv4: "\u062F IPv4 \u0633\u0627\u062D\u0647",
    cidrv6: "\u062F IPv6 \u0633\u0627\u062D\u0647",
    base64: "base64-encoded \u0645\u062A\u0646",
    base64url: "base64url-encoded \u0645\u062A\u0646",
    json_string: "JSON \u0645\u062A\u0646",
    e164: "\u062F E.164 \u0634\u0645\u06D0\u0631\u0647",
    credit_card: "\u062F \u06A9\u0631\u06CC\u0689\u06CC\u067C \u06A9\u0627\u0631\u062A \u0634\u0645\u06CC\u0631\u0647",
    jwt: "JWT",
    template_literal: "\u0648\u0631\u0648\u062F\u064A"
  }, o = {
    nan: "NaN",
    number: "\u0639\u062F\u062F",
    array: "\u0627\u0631\u06D0"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `\u0646\u0627\u0633\u0645 \u0648\u0631\u0648\u062F\u064A: \u0628\u0627\u06CC\u062F instanceof ${n.expected} \u0648\u0627\u06CC, \u0645\u06AB\u0631 ${u} \u062A\u0631\u0644\u0627\u0633\u0647 \u0634\u0648` : `\u0646\u0627\u0633\u0645 \u0648\u0631\u0648\u062F\u064A: \u0628\u0627\u06CC\u062F ${i} \u0648\u0627\u06CC, \u0645\u06AB\u0631 ${u} \u062A\u0631\u0644\u0627\u0633\u0647 \u0634\u0648`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `\u0646\u0627\u0633\u0645 \u0648\u0631\u0648\u062F\u064A: \u0628\u0627\u06CC\u062F ${$(n.values[0])} \u0648\u0627\u06CC` : `\u0646\u0627\u0633\u0645 \u0627\u0646\u062A\u062E\u0627\u0628: \u0628\u0627\u06CC\u062F \u06CC\u0648 \u0644\u0647 ${m(n.values, "|")} \u0685\u062E\u0647 \u0648\u0627\u06CC`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin);
        return a ? `\u0689\u06CC\u0631 \u0644\u0648\u06CC: ${n.origin ?? "\u0627\u0631\u0632\u069A\u062A"} \u0628\u0627\u06CC\u062F ${i}${n.maximum.toString()} ${a.unit ?? "\u0639\u0646\u0635\u0631\u0648\u0646\u0647"} \u0648\u0644\u0631\u064A` : `\u0689\u06CC\u0631 \u0644\u0648\u06CC: ${n.origin ?? "\u0627\u0631\u0632\u069A\u062A"} \u0628\u0627\u06CC\u062F ${i}${n.maximum.toString()} \u0648\u064A`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin);
        return a ? `\u0689\u06CC\u0631 \u06A9\u0648\u0686\u0646\u06CC: ${n.origin} \u0628\u0627\u06CC\u062F ${i}${n.minimum.toString()} ${a.unit} \u0648\u0644\u0631\u064A` : `\u0689\u06CC\u0631 \u06A9\u0648\u0686\u0646\u06CC: ${n.origin} \u0628\u0627\u06CC\u062F ${i}${n.minimum.toString()} \u0648\u064A`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `\u0646\u0627\u0633\u0645 \u0645\u062A\u0646: \u0628\u0627\u06CC\u062F \u062F "${i.prefix}" \u0633\u0631\u0647 \u067E\u06CC\u0644 \u0634\u064A` : i.format === "ends_with" ? `\u0646\u0627\u0633\u0645 \u0645\u062A\u0646: \u0628\u0627\u06CC\u062F \u062F "${i.suffix}" \u0633\u0631\u0647 \u067E\u0627\u06CC \u062A\u0647 \u0648\u0631\u0633\u064A\u0696\u064A` : i.format === "includes" ? `\u0646\u0627\u0633\u0645 \u0645\u062A\u0646: \u0628\u0627\u06CC\u062F "${i.includes}" \u0648\u0644\u0631\u064A` : i.format === "regex" ? `\u0646\u0627\u0633\u0645 \u0645\u062A\u0646: \u0628\u0627\u06CC\u062F \u062F ${i.pattern} \u0633\u0631\u0647 \u0645\u0637\u0627\u0628\u0642\u062A \u0648\u0644\u0631\u064A` : `${r[i.format] ?? n.format} \u0646\u0627\u0633\u0645 \u062F\u06CC`;
      }
      case "not_multiple_of":
        return `\u0646\u0627\u0633\u0645 \u0639\u062F\u062F: \u0628\u0627\u06CC\u062F \u062F ${n.divisor} \u0645\u0636\u0631\u0628 \u0648\u064A`;
      case "unrecognized_keys":
        return `\u0646\u0627\u0633\u0645 ${n.keys.length > 1 ? "\u06A9\u0644\u06CC\u0689\u0648\u0646\u0647" : "\u06A9\u0644\u06CC\u0689"}: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `\u0646\u0627\u0633\u0645 \u06A9\u0644\u06CC\u0689 \u067E\u0647 ${n.origin} \u06A9\u06D0`;
      case "invalid_union":
        return "\u0646\u0627\u0633\u0645\u0647 \u0648\u0631\u0648\u062F\u064A";
      case "invalid_element":
        return `\u0646\u0627\u0633\u0645 \u0639\u0646\u0635\u0631 \u067E\u0647 ${n.origin} \u06A9\u06D0`;
      default:
        return "\u0646\u0627\u0633\u0645\u0647 \u0648\u0631\u0648\u062F\u064A";
    }
  };
}, "error");
function zu() {
  return {
    localeError: yy()
  };
}
s(zu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/pl.js
var $y = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "znak\xF3w", verb: "mie\u0107" },
    file: { unit: "bajt\xF3w", verb: "mie\u0107" },
    array: { unit: "element\xF3w", verb: "mie\u0107" },
    set: { unit: "element\xF3w", verb: "mie\u0107" },
    map: { unit: "element\xF3w", verb: "mie\u0107" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "wyra\u017Cenie",
    email: "adres email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "data i godzina w formacie ISO",
    date: "data w formacie ISO",
    time: "godzina w formacie ISO",
    duration: "czas trwania ISO",
    ipv4: "adres IPv4",
    ipv6: "adres IPv6",
    mac: "adres MAC",
    cidrv4: "zakres IPv4",
    cidrv6: "zakres IPv6",
    base64: "ci\u0105g znak\xF3w zakodowany w formacie base64",
    base64url: "ci\u0105g znak\xF3w zakodowany w formacie base64url",
    json_string: "ci\u0105g znak\xF3w w formacie JSON",
    e164: "liczba E.164",
    credit_card: "numer karty kredytowej",
    jwt: "JWT",
    template_literal: "wej\u015Bcie"
  }, o = {
    nan: "NaN",
    number: "liczba",
    array: "tablica"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `Nieprawid\u0142owe dane wej\u015Bciowe: oczekiwano instanceof ${n.expected}, otrzymano ${u}` : `Nieprawid\u0142owe dane wej\u015Bciowe: oczekiwano ${i}, otrzymano ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `Nieprawid\u0142owe dane wej\u015Bciowe: oczekiwano ${$(n.values[0])}` : `Nieprawid\u0142owa opcja: oczekiwano jednej z warto\u015Bci ${m(n.values, "|")}`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin);
        return a ? `Za du\u017Ca warto\u015B\u0107: oczekiwano, \u017Ce ${n.origin ?? "warto\u015B\u0107"} b\u0119dzie mie\u0107 ${i}${n.maximum.toString()} ${a.unit ?? "element\xF3w"}` : `Zbyt du\u017C(y/a/e): oczekiwano, \u017Ce ${n.origin ?? "warto\u015B\u0107"} b\u0119dzie wynosi\u0107 ${i}${n.maximum.toString()}`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin);
        return a ? `Za ma\u0142a warto\u015B\u0107: oczekiwano, \u017Ce ${n.origin ?? "warto\u015B\u0107"} b\u0119dzie mie\u0107 ${i}${n.minimum.toString()} ${a.unit ?? "element\xF3w"}` : `Zbyt ma\u0142(y/a/e): oczekiwano, \u017Ce ${n.origin ?? "warto\u015B\u0107"} b\u0119dzie wynosi\u0107 ${i}${n.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `Nieprawid\u0142owy ci\u0105g znak\xF3w: musi zaczyna\u0107 si\u0119 od "${i.prefix}"` : i.format === "ends_with" ? `Nieprawid\u0142owy ci\u0105g znak\xF3w: musi ko\u0144czy\u0107 si\u0119 na "${i.suffix}"` : i.format === "includes" ? `Nieprawid\u0142owy ci\u0105g znak\xF3w: musi zawiera\u0107 "${i.includes}"` : i.format === "regex" ? `Nieprawid\u0142owy ci\u0105g znak\xF3w: musi odpowiada\u0107 wzorcowi ${i.pattern}` : `Nieprawid\u0142ow(y/a/e) ${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `Nieprawid\u0142owa liczba: musi by\u0107 wielokrotno\u015Bci\u0105 ${n.divisor}`;
      case "unrecognized_keys":
        return `Nierozpoznane klucze${n.keys.length > 1 ? "s" : ""}: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `Nieprawid\u0142owy klucz w ${n.origin}`;
      case "invalid_union":
        return "Nieprawid\u0142owe dane wej\u015Bciowe";
      case "invalid_element":
        return `Nieprawid\u0142owa warto\u015B\u0107 w ${n.origin}`;
      default:
        return "Nieprawid\u0142owe dane wej\u015Bciowe";
    }
  };
}, "error");
function Su() {
  return {
    localeError: $y()
  };
}
s(Su, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/pt.js
var by = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "caracteres" },
    file: { unit: "bytes" },
    array: { unit: "elementos" },
    set: { unit: "elementos" },
    map: { unit: "entradas" }
  };
  function t(a) {
    return e[a] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "a entrada",
    email: "o endere\xE7o de e-mail",
    url: "o URL",
    emoji: "o emoji",
    uuid: "o UUID",
    uuidv4: "o UUIDv4",
    uuidv6: "o UUIDv6",
    nanoid: "o nanoid",
    guid: "o GUID",
    cuid: "o cuid",
    cuid2: "o cuid2",
    ulid: "o ULID",
    xid: "o XID",
    ksuid: "o KSUID",
    datetime: "a data e hora ISO",
    date: "a data ISO",
    time: "a hora ISO",
    duration: "a dura\xE7\xE3o ISO",
    ipv4: "o endere\xE7o IPv4",
    ipv6: "o endere\xE7o IPv6",
    mac: "o endere\xE7o MAC",
    cidrv4: "o intervalo de endere\xE7os IPv4",
    cidrv6: "o intervalo de endere\xE7os IPv6",
    base64: "o texto codificado em base64",
    base64url: "o texto codificado em base64url",
    json_string: "o texto JSON",
    e164: "o n\xFAmero E.164",
    credit_card: "o n\xFAmero de cart\xE3o de cr\xE9dito",
    jwt: "o JWT",
    template_literal: "a entrada"
  }, o = {
    masculine: { definite: "o", indefinite: "um" },
    feminine: { definite: "a", indefinite: "uma" }
  }, n = {
    string: { name: "texto", articles: o.masculine },
    number: { name: "n\xFAmero", articles: o.masculine },
    int: { name: "n\xFAmero inteiro", articles: o.masculine },
    boolean: { name: "valor booleano", articles: o.masculine },
    bigint: { name: "n\xFAmero bigint", articles: o.masculine },
    symbol: { name: "s\xEDmbolo", articles: o.masculine },
    undefined: { name: 'valor "undefined"', articles: o.masculine },
    null: { name: 'valor "nulo"', articles: o.masculine },
    never: { name: 'valor "never"', articles: o.masculine },
    void: { name: 'valor "void"', articles: o.masculine },
    date: { name: "data", articles: o.feminine },
    array: { name: "vetor", articles: o.masculine },
    object: { name: "objeto", articles: o.masculine },
    tuple: { name: "tuplo", articles: o.masculine },
    record: { name: "registo", articles: o.masculine },
    map: { name: "mapa", articles: o.masculine },
    set: { name: "conjunto", articles: o.masculine },
    file: { name: "ficheiro", articles: o.masculine },
    nonoptional: { name: "valor n\xE3o opcional", articles: o.masculine },
    nan: { name: 'valor "NaN"', articles: o.masculine },
    // Compatibility: "nan" -> "NaN" for display
    function: { name: "fun\xE7\xE3o", articles: o.feminine }
  };
  function i(a, u) {
    let c = n[a] ?? { name: `valor "${a}"`, articles: o.masculine };
    return `${c.articles[u]} ${c.name}`;
  }
  return s(i, "translateOriginWithArticle"), (a) => {
    switch (a.code) {
      case "invalid_type": {
        let u = i(a.expected, "indefinite"), c = b(a.input), l = i(c, "indefinite");
        return `Entrada inv\xE1lida: esperava ${u}, recebeu ${l}`;
      }
      case "invalid_value":
        return a.values.length === 1 ? `Entrada inv\xE1lida: esperava ${$(a.values[0])}` : `Op\xE7\xE3o inv\xE1lida: esperava uma das seguintes op\xE7\xF5es: ${m(a.values, "|")}`;
      case "too_big": {
        let u = a.inclusive ? "<=" : "<", c = t(a.origin);
        return c ? `Demasiado grande: esperava que ${i(a.origin, "definite")} tivesse ${u} ${a.maximum.toString()} ${c.unit ?? "elementos"}` : `Demasiado grande: esperava que ${i(a.origin, "definite")} fosse ${u} ${a.maximum.toString()}`;
      }
      case "too_small": {
        let u = a.inclusive ? ">=" : ">", c = t(a.origin);
        return c ? `Demasiado pequeno: esperava que ${i(a.origin, "definite")} tivesse ${u} ${a.minimum.toString()} ${c.unit ?? "elementos"}` : `Demasiado pequeno: esperava que ${i(a.origin, "definite")} fosse ${u} ${a.minimum.toString()}`;
      }
      case "invalid_format": {
        let u = a;
        return u.format === "starts_with" ? `Texto inv\xE1lido: deve come\xE7ar por "${u.prefix}"` : u.format === "ends_with" ? `Texto inv\xE1lido: deve terminar em "${u.suffix}"` : u.format === "includes" ? `Texto inv\xE1lido: deve incluir "${u.includes}"` : u.format === "regex" ? `Texto inv\xE1lido: deve corresponder ao padr\xE3o ${u.pattern}` : `Formato d${r[u.format] ?? a.format} inv\xE1lido`;
      }
      case "not_multiple_of":
        return `N\xFAmero inv\xE1lido: deve ser m\xFAltiplo de ${a.divisor}`;
      case "unrecognized_keys": {
        let u = a.keys.length > 1 ? "s" : "";
        return `Chave${u} inv\xE1lida${u}: ${m(a.keys, ", ")}`;
      }
      case "invalid_key":
        return `Entrada inv\xE1lida n${i(a.origin, "definite")}`;
      case "invalid_union":
        return a.options && Array.isArray(a.options) && a.options.length > 0 ? `Valor de discrimina\xE7\xE3o inv\xE1lido. Esperava ${a.options.map((c) => `'${c}'`).join(" | ")}` : "Entrada inv\xE1lida";
      case "invalid_element":
        return `Entrada inv\xE1lida n${i(a.origin, "definite")}`;
      default:
        return "Entrada inv\xE1lida";
    }
  };
}, "error");
function ju() {
  return {
    localeError: by()
  };
}
s(ju, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/pt-BR.js
var _y = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "caracteres" },
    file: { unit: "bytes" },
    array: { unit: "elementos" },
    set: { unit: "elementos" },
    map: { unit: "entradas" }
  };
  function t(a) {
    return e[a] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "a entrada",
    email: "o endere\xE7o de e-mail",
    url: "o URL",
    emoji: "o emoji",
    uuid: "o UUID",
    uuidv4: "o UUIDv4",
    uuidv6: "o UUIDv6",
    nanoid: "o nanoid",
    guid: "o GUID",
    cuid: "o cuid",
    cuid2: "o cuid2",
    ulid: "o ULID",
    xid: "o XID",
    ksuid: "o KSUID",
    datetime: "a data e hora ISO",
    date: "a data ISO",
    time: "a hora ISO",
    duration: "a dura\xE7\xE3o ISO",
    ipv4: "o endere\xE7o IPv4",
    ipv6: "o endere\xE7o IPv6",
    mac: "o endere\xE7o MAC",
    cidrv4: "a faixa de endere\xE7os IPv4",
    cidrv6: "a faixa de endere\xE7os IPv6",
    base64: "o texto codificado em base64",
    base64url: "o texto codificado em base64url",
    json_string: "o texto JSON",
    e164: "o n\xFAmero E.164",
    credit_card: "o n\xFAmero de cart\xE3o de cr\xE9dito",
    jwt: "o JWT",
    template_literal: "a entrada"
  }, o = {
    masculine: { definite: "o", indefinite: "um" },
    feminine: { definite: "a", indefinite: "uma" }
  }, n = {
    string: { name: "texto", articles: o.masculine },
    number: { name: "n\xFAmero", articles: o.masculine },
    int: { name: "n\xFAmero inteiro", articles: o.masculine },
    boolean: { name: "valor booleano", articles: o.masculine },
    bigint: { name: "n\xFAmero bigint", articles: o.masculine },
    symbol: { name: "s\xEDmbolo", articles: o.masculine },
    undefined: { name: 'valor "undefined"', articles: o.masculine },
    null: { name: 'valor "nulo"', articles: o.masculine },
    never: { name: 'valor "never"', articles: o.masculine },
    void: { name: 'valor "void"', articles: o.masculine },
    date: { name: "data", articles: o.feminine },
    array: { name: "vetor", articles: o.masculine },
    object: { name: "objeto", articles: o.masculine },
    tuple: { name: "tupla", articles: o.feminine },
    record: { name: "registro", articles: o.masculine },
    map: { name: "mapa", articles: o.masculine },
    set: { name: "conjunto", articles: o.masculine },
    file: { name: "arquivo", articles: o.masculine },
    nonoptional: { name: "valor n\xE3o opcional", articles: o.masculine },
    nan: { name: 'valor "NaN"', articles: o.masculine },
    // Compatibility: "nan" -> "NaN" for display
    function: { name: "fun\xE7\xE3o", articles: o.feminine }
  };
  function i(a, u) {
    let c = n[a] ?? { name: `valor "${a}"`, articles: o.masculine };
    return `${c.articles[u]} ${c.name}`;
  }
  return s(i, "translateOriginWithArticle"), (a) => {
    switch (a.code) {
      case "invalid_type": {
        let u = i(a.expected, "indefinite"), c = b(a.input), l = i(c, "indefinite");
        return `Entrada inv\xE1lida: esperava ${u}, recebeu ${l}`;
      }
      case "invalid_value":
        return a.values.length === 1 ? `Entrada inv\xE1lida: esperava ${$(a.values[0])}` : `Op\xE7\xE3o inv\xE1lida: esperava uma das seguintes op\xE7\xF5es: ${m(a.values, "|")}`;
      case "too_big": {
        let u = a.inclusive ? "<=" : "<", c = t(a.origin);
        return c ? `Grande demais: esperava que ${i(a.origin, "definite")} tivesse ${u} ${a.maximum.toString()} ${c.unit ?? "elementos"}` : `Grande demais: esperava que ${i(a.origin, "definite")} fosse ${u} ${a.maximum.toString()}`;
      }
      case "too_small": {
        let u = a.inclusive ? ">=" : ">", c = t(a.origin);
        return c ? `Pequeno demais: esperava que ${i(a.origin, "definite")} tivesse ${u} ${a.minimum.toString()} ${c.unit ?? "elementos"}` : `Pequeno demais: esperava que ${i(a.origin, "definite")} fosse ${u} ${a.minimum.toString()}`;
      }
      case "invalid_format": {
        let u = a;
        return u.format === "starts_with" ? `Texto inv\xE1lido: deve come\xE7ar com "${u.prefix}"` : u.format === "ends_with" ? `Texto inv\xE1lido: deve terminar com "${u.suffix}"` : u.format === "includes" ? `Texto inv\xE1lido: deve incluir "${u.includes}"` : u.format === "regex" ? `Texto inv\xE1lido: deve corresponder ao padr\xE3o ${u.pattern}` : `Formato d${r[u.format] ?? a.format} inv\xE1lido`;
      }
      case "not_multiple_of":
        return `N\xFAmero inv\xE1lido: deve ser m\xFAltiplo de ${a.divisor}`;
      case "unrecognized_keys": {
        let u = a.keys.length > 1 ? "s" : "";
        return `Chave${u} inv\xE1lida${u}: ${m(a.keys, ", ")}`;
      }
      case "invalid_key":
        return `Entrada inv\xE1lida n${i(a.origin, "definite")}`;
      case "invalid_union":
        return a.options && Array.isArray(a.options) && a.options.length > 0 ? `Valor de discrimina\xE7\xE3o inv\xE1lido. Esperava ${a.options.map((c) => `'${c}'`).join(" | ")}` : "Entrada inv\xE1lida";
      case "invalid_element":
        return `Entrada inv\xE1lida n${i(a.origin, "definite")}`;
      default:
        return "Entrada inv\xE1lida";
    }
  };
}, "error");
function Ou() {
  return {
    localeError: _y()
  };
}
s(Ou, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ro.js
var xy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "caractere", verb: "s\u0103 aib\u0103" },
    file: { unit: "octe\u021Bi", verb: "s\u0103 aib\u0103" },
    array: { unit: "elemente", verb: "s\u0103 aib\u0103" },
    set: { unit: "elemente", verb: "s\u0103 aib\u0103" },
    map: { unit: "intr\u0103ri", verb: "s\u0103 aib\u0103" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "intrare",
    email: "adres\u0103 de email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "dat\u0103 \u0219i or\u0103 ISO",
    date: "dat\u0103 ISO",
    time: "or\u0103 ISO",
    duration: "durat\u0103 ISO",
    ipv4: "adres\u0103 IPv4",
    ipv6: "adres\u0103 IPv6",
    mac: "adres\u0103 MAC",
    cidrv4: "interval IPv4",
    cidrv6: "interval IPv6",
    base64: "\u0219ir codat base64",
    base64url: "\u0219ir codat base64url",
    json_string: "\u0219ir JSON",
    e164: "num\u0103r E.164",
    credit_card: "num\u0103r de card de credit",
    jwt: "JWT",
    template_literal: "intrare"
  }, o = {
    nan: "NaN",
    string: "\u0219ir",
    number: "num\u0103r",
    boolean: "boolean",
    function: "func\u021Bie",
    array: "matrice",
    object: "obiect",
    undefined: "nedefinit",
    symbol: "simbol",
    bigint: "num\u0103r mare",
    void: "void",
    never: "never",
    map: "hart\u0103",
    set: "set"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return `Intrare invalid\u0103: a\u0219teptat ${i}, primit ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `Intrare invalid\u0103: a\u0219teptat ${$(n.values[0])}` : `Op\u021Biune invalid\u0103: a\u0219teptat una dintre ${m(n.values, "|")}`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin);
        return a ? `Prea mare: a\u0219teptat ca ${n.origin ?? "valoarea"} ${a.verb} ${i}${n.maximum.toString()} ${a.unit ?? "elemente"}` : `Prea mare: a\u0219teptat ca ${n.origin ?? "valoarea"} s\u0103 fie ${i}${n.maximum.toString()}`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin);
        return a ? `Prea mic: a\u0219teptat ca ${n.origin} ${a.verb} ${i}${n.minimum.toString()} ${a.unit}` : `Prea mic: a\u0219teptat ca ${n.origin} s\u0103 fie ${i}${n.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `\u0218ir invalid: trebuie s\u0103 \xEEnceap\u0103 cu "${i.prefix}"` : i.format === "ends_with" ? `\u0218ir invalid: trebuie s\u0103 se termine cu "${i.suffix}"` : i.format === "includes" ? `\u0218ir invalid: trebuie s\u0103 includ\u0103 "${i.includes}"` : i.format === "regex" ? `\u0218ir invalid: trebuie s\u0103 se potriveasc\u0103 cu modelul ${i.pattern}` : `Format invalid: ${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `Num\u0103r invalid: trebuie s\u0103 fie multiplu de ${n.divisor}`;
      case "unrecognized_keys":
        return `Chei nerecunoscute: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `Cheie invalid\u0103 \xEEn ${n.origin}`;
      case "invalid_union":
        return "Intrare invalid\u0103";
      case "invalid_element":
        return `Valoare invalid\u0103 \xEEn ${n.origin}`;
      default:
        return "Intrare invalid\u0103";
    }
  };
}, "error");
function Du() {
  return {
    localeError: xy()
  };
}
s(Du, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ru.js
function Rf(e, t, r, o) {
  let n = Math.abs(e), i = n % 10, a = n % 100;
  return a >= 11 && a <= 19 ? o : i === 1 ? t : i >= 2 && i <= 4 ? r : o;
}
s(Rf, "getRussianPlural");
var wy = /* @__PURE__ */ s(() => {
  let e = {
    string: {
      unit: {
        one: "\u0441\u0438\u043C\u0432\u043E\u043B",
        few: "\u0441\u0438\u043C\u0432\u043E\u043B\u0430",
        many: "\u0441\u0438\u043C\u0432\u043E\u043B\u043E\u0432"
      },
      verb: "\u0438\u043C\u0435\u0442\u044C"
    },
    file: {
      unit: {
        one: "\u0431\u0430\u0439\u0442",
        few: "\u0431\u0430\u0439\u0442\u0430",
        many: "\u0431\u0430\u0439\u0442"
      },
      verb: "\u0438\u043C\u0435\u0442\u044C"
    },
    array: {
      unit: {
        one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
        few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430",
        many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u043E\u0432"
      },
      verb: "\u0438\u043C\u0435\u0442\u044C"
    },
    set: {
      unit: {
        one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
        few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430",
        many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u043E\u0432"
      },
      verb: "\u0438\u043C\u0435\u0442\u044C"
    },
    map: {
      unit: {
        one: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442",
        few: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u0430",
        many: "\u044D\u043B\u0435\u043C\u0435\u043D\u0442\u043E\u0432"
      },
      verb: "\u0438\u043C\u0435\u0442\u044C"
    }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "\u0432\u0432\u043E\u0434",
    email: "email \u0430\u0434\u0440\u0435\u0441",
    url: "URL",
    emoji: "\u044D\u043C\u043E\u0434\u0437\u0438",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0434\u0430\u0442\u0430 \u0438 \u0432\u0440\u0435\u043C\u044F",
    date: "ISO \u0434\u0430\u0442\u0430",
    time: "ISO \u0432\u0440\u0435\u043C\u044F",
    duration: "ISO \u0434\u043B\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C",
    ipv4: "IPv4 \u0430\u0434\u0440\u0435\u0441",
    ipv6: "IPv6 \u0430\u0434\u0440\u0435\u0441",
    mac: "MAC \u0430\u0434\u0440\u0435\u0441",
    cidrv4: "IPv4 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D",
    cidrv6: "IPv6 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D",
    base64: "\u0441\u0442\u0440\u043E\u043A\u0430 \u0432 \u0444\u043E\u0440\u043C\u0430\u0442\u0435 base64",
    base64url: "\u0441\u0442\u0440\u043E\u043A\u0430 \u0432 \u0444\u043E\u0440\u043C\u0430\u0442\u0435 base64url",
    json_string: "JSON \u0441\u0442\u0440\u043E\u043A\u0430",
    e164: "\u043D\u043E\u043C\u0435\u0440 E.164",
    credit_card: "\u043D\u043E\u043C\u0435\u0440 \u043A\u0440\u0435\u0434\u0438\u0442\u043D\u043E\u0439 \u043A\u0430\u0440\u0442\u044B",
    jwt: "JWT",
    template_literal: "\u0432\u0432\u043E\u0434"
  }, o = {
    nan: "NaN",
    number: "\u0447\u0438\u0441\u043B\u043E",
    array: "\u043C\u0430\u0441\u0441\u0438\u0432"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0432\u0432\u043E\u0434: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C instanceof ${n.expected}, \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u043E ${u}` : `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0432\u0432\u043E\u0434: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C ${i}, \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u043E ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0432\u0432\u043E\u0434: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C ${$(n.values[0])}` : `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0432\u0430\u0440\u0438\u0430\u043D\u0442: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C \u043E\u0434\u043D\u043E \u0438\u0437 ${m(n.values, "|")}`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin);
        if (a) {
          let u = Number(n.maximum), c = Rf(u, a.unit.one, a.unit.few, a.unit.many);
          return `\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C, \u0447\u0442\u043E ${n.origin ?? "\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435"} \u0431\u0443\u0434\u0435\u0442 \u0438\u043C\u0435\u0442\u044C ${i}${n.maximum.toString()} ${c}`;
        }
        return `\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u0431\u043E\u043B\u044C\u0448\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C, \u0447\u0442\u043E ${n.origin ?? "\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435"} \u0431\u0443\u0434\u0435\u0442 ${i}${n.maximum.toString()}`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin);
        if (a) {
          let u = Number(n.minimum), c = Rf(u, a.unit.one, a.unit.few, a.unit.many);
          return `\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u043C\u0430\u043B\u0435\u043D\u044C\u043A\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C, \u0447\u0442\u043E ${n.origin} \u0431\u0443\u0434\u0435\u0442 \u0438\u043C\u0435\u0442\u044C ${i}${n.minimum.toString()} ${c}`;
        }
        return `\u0421\u043B\u0438\u0448\u043A\u043E\u043C \u043C\u0430\u043B\u0435\u043D\u044C\u043A\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435: \u043E\u0436\u0438\u0434\u0430\u043B\u043E\u0441\u044C, \u0447\u0442\u043E ${n.origin} \u0431\u0443\u0434\u0435\u0442 ${i}${n.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u0441\u0442\u0440\u043E\u043A\u0430: \u0434\u043E\u043B\u0436\u043D\u0430 \u043D\u0430\u0447\u0438\u043D\u0430\u0442\u044C\u0441\u044F \u0441 "${i.prefix}"` : i.format === "ends_with" ? `\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u0441\u0442\u0440\u043E\u043A\u0430: \u0434\u043E\u043B\u0436\u043D\u0430 \u0437\u0430\u043A\u0430\u043D\u0447\u0438\u0432\u0430\u0442\u044C\u0441\u044F \u043D\u0430 "${i.suffix}"` : i.format === "includes" ? `\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u0441\u0442\u0440\u043E\u043A\u0430: \u0434\u043E\u043B\u0436\u043D\u0430 \u0441\u043E\u0434\u0435\u0440\u0436\u0430\u0442\u044C "${i.includes}"` : i.format === "regex" ? `\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u0441\u0442\u0440\u043E\u043A\u0430: \u0434\u043E\u043B\u0436\u043D\u0430 \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u043E\u0432\u0430\u0442\u044C \u0448\u0430\u0431\u043B\u043E\u043D\u0443 ${i.pattern}` : `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 ${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `\u041D\u0435\u0432\u0435\u0440\u043D\u043E\u0435 \u0447\u0438\u0441\u043B\u043E: \u0434\u043E\u043B\u0436\u043D\u043E \u0431\u044B\u0442\u044C \u043A\u0440\u0430\u0442\u043D\u044B\u043C ${n.divisor}`;
      case "unrecognized_keys":
        return `\u041D\u0435\u0440\u0430\u0441\u043F\u043E\u0437\u043D\u0430\u043D\u043D${n.keys.length > 1 ? "\u044B\u0435" : "\u044B\u0439"} \u043A\u043B\u044E\u0447${n.keys.length > 1 ? "\u0438" : ""}: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u043A\u043B\u044E\u0447 \u0432 ${n.origin}`;
      case "invalid_union":
        return "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0435 \u0432\u0445\u043E\u0434\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435";
      case "invalid_element":
        return `\u041D\u0435\u0432\u0435\u0440\u043D\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u0432 ${n.origin}`;
      default:
        return "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0435 \u0432\u0445\u043E\u0434\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435";
    }
  };
}, "error");
function Pu() {
  return {
    localeError: wy()
  };
}
s(Pu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/sk.js
var Iy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "znakov", verb: "ma\u0165" },
    file: { unit: "bajtov", verb: "ma\u0165" },
    array: { unit: "prvkov", verb: "ma\u0165" },
    set: { unit: "prvkov", verb: "ma\u0165" },
    map: { unit: "polo\u017Eiek", verb: "ma\u0165" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "regul\xE1rny v\xFDraz",
    email: "e-mailov\xE1 adresa",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "d\xE1tum a \u010Das vo form\xE1te ISO",
    date: "d\xE1tum vo form\xE1te ISO",
    time: "\u010Das vo form\xE1te ISO",
    duration: "doba trvania ISO",
    ipv4: "IPv4 adresa",
    ipv6: "IPv6 adresa",
    mac: "MAC adresa",
    cidrv4: "rozsah IPv4",
    cidrv6: "rozsah IPv6",
    base64: "re\u0165azec zak\xF3dovan\xFD vo form\xE1te base64",
    base64url: "re\u0165azec zak\xF3dovan\xFD vo form\xE1te base64url",
    json_string: "re\u0165azec vo form\xE1te JSON",
    e164: "\u010D\xEDslo E.164",
    credit_card: "\u010D\xEDslo kreditnej karty",
    jwt: "JWT",
    template_literal: "vstup"
  }, o = {
    nan: "NaN",
    number: "\u010D\xEDslo",
    string: "re\u0165azec",
    function: "funkcia",
    array: "pole"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `Neplatn\xFD vstup: o\u010Dak\xE1van\xE9 instanceof ${n.expected}, obdr\u017Ean\xE9 ${u}` : `Neplatn\xFD vstup: o\u010Dak\xE1van\xE9 ${i}, obdr\u017Ean\xE9 ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `Neplatn\xFD vstup: o\u010Dak\xE1van\xE9 ${$(n.values[0])}` : `Neplatn\xFD vstup: o\u010Dak\xE1van\xE1 jedna z hodn\xF4t ${m(n.values, "|")}`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin);
        return a ? `Hodnota je pr\xEDli\u0161 ve\u013Ek\xE1: ${n.origin ?? "hodnota"} mus\xED ma\u0165 ${i}${n.maximum.toString()} ${a.unit ?? "prvkov"}` : `Hodnota je pr\xEDli\u0161 ve\u013Ek\xE1: ${n.origin ?? "hodnota"} mus\xED by\u0165 ${i}${n.maximum.toString()}`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin);
        return a ? `Hodnota je pr\xEDli\u0161 mal\xE1: ${n.origin ?? "hodnota"} mus\xED ma\u0165 ${i}${n.minimum.toString()} ${a.unit ?? "prvkov"}` : `Hodnota je pr\xEDli\u0161 mal\xE1: ${n.origin ?? "hodnota"} mus\xED by\u0165 ${i}${n.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `Neplatn\xFD re\u0165azec: mus\xED za\u010D\xEDna\u0165 na "${i.prefix}"` : i.format === "ends_with" ? `Neplatn\xFD re\u0165azec: mus\xED kon\u010Di\u0165 na "${i.suffix}"` : i.format === "includes" ? `Neplatn\xFD re\u0165azec: mus\xED obsahova\u0165 "${i.includes}"` : i.format === "regex" ? `Neplatn\xFD re\u0165azec: mus\xED zodpoveda\u0165 vzoru ${i.pattern}` : `Neplatn\xFD form\xE1t ${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `Neplatn\xE9 \u010D\xEDslo: mus\xED by\u0165 n\xE1sobkom ${n.divisor}`;
      case "unrecognized_keys":
        return `Nezn\xE1me kl\xFA\u010De: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `Neplatn\xFD kl\xFA\u010D v ${n.origin}`;
      case "invalid_union":
        return "Neplatn\xFD vstup";
      case "invalid_element":
        return `Neplatn\xE1 hodnota v ${n.origin}`;
      default:
        return "Neplatn\xFD vstup";
    }
  };
}, "error");
function Tu() {
  return {
    localeError: Iy()
  };
}
s(Tu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/sl.js
var ky = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "znakov", verb: "imeti" },
    file: { unit: "bajtov", verb: "imeti" },
    array: { unit: "elementov", verb: "imeti" },
    set: { unit: "elementov", verb: "imeti" },
    map: { unit: "elementov", verb: "imeti" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "vnos",
    email: "e-po\u0161tni naslov",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datum in \u010Das",
    date: "ISO datum",
    time: "ISO \u010Das",
    duration: "ISO trajanje",
    ipv4: "IPv4 naslov",
    ipv6: "IPv6 naslov",
    mac: "MAC naslov",
    cidrv4: "obseg IPv4",
    cidrv6: "obseg IPv6",
    base64: "base64 kodiran niz",
    base64url: "base64url kodiran niz",
    json_string: "JSON niz",
    e164: "E.164 \u0161tevilka",
    credit_card: "\u0161tevilka kreditne kartice",
    jwt: "JWT",
    template_literal: "vnos"
  }, o = {
    nan: "NaN",
    number: "\u0161tevilo",
    array: "tabela"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `Neveljaven vnos: pri\u010Dakovano instanceof ${n.expected}, prejeto ${u}` : `Neveljaven vnos: pri\u010Dakovano ${i}, prejeto ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `Neveljaven vnos: pri\u010Dakovano ${$(n.values[0])}` : `Neveljavna mo\u017Enost: pri\u010Dakovano eno izmed ${m(n.values, "|")}`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin);
        return a ? `Preveliko: pri\u010Dakovano, da bo ${n.origin ?? "vrednost"} imelo ${i}${n.maximum.toString()} ${a.unit ?? "elementov"}` : `Preveliko: pri\u010Dakovano, da bo ${n.origin ?? "vrednost"} ${i}${n.maximum.toString()}`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin);
        return a ? `Premajhno: pri\u010Dakovano, da bo ${n.origin} imelo ${i}${n.minimum.toString()} ${a.unit}` : `Premajhno: pri\u010Dakovano, da bo ${n.origin} ${i}${n.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `Neveljaven niz: mora se za\u010Deti z "${i.prefix}"` : i.format === "ends_with" ? `Neveljaven niz: mora se kon\u010Dati z "${i.suffix}"` : i.format === "includes" ? `Neveljaven niz: mora vsebovati "${i.includes}"` : i.format === "regex" ? `Neveljaven niz: mora ustrezati vzorcu ${i.pattern}` : `Neveljaven ${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `Neveljavno \u0161tevilo: mora biti ve\u010Dkratnik ${n.divisor}`;
      case "unrecognized_keys":
        return `Neprepoznan${n.keys.length > 1 ? "i klju\u010Di" : " klju\u010D"}: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `Neveljaven klju\u010D v ${n.origin}`;
      case "invalid_union":
        return "Neveljaven vnos";
      case "invalid_element":
        return `Neveljavna vrednost v ${n.origin}`;
      default:
        return "Neveljaven vnos";
    }
  };
}, "error");
function Nu() {
  return {
    localeError: ky()
  };
}
s(Nu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/sv.js
var zy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "tecken", verb: "att ha" },
    file: { unit: "bytes", verb: "att ha" },
    array: { unit: "objekt", verb: "att inneh\xE5lla" },
    set: { unit: "objekt", verb: "att inneh\xE5lla" },
    map: { unit: "objekt", verb: "att inneh\xE5lla" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "regulj\xE4rt uttryck",
    email: "e-postadress",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO-datum och tid",
    date: "ISO-datum",
    time: "ISO-tid",
    duration: "ISO-varaktighet",
    ipv4: "IPv4-adress",
    ipv6: "IPv6-adress",
    mac: "MAC-adress",
    cidrv4: "IPv4-spektrum",
    cidrv6: "IPv6-spektrum",
    base64: "base64-kodad str\xE4ng",
    base64url: "base64url-kodad str\xE4ng",
    json_string: "JSON-str\xE4ng",
    e164: "E.164-nummer",
    credit_card: "kreditkortsnummer",
    jwt: "JWT",
    template_literal: "mall-literal"
  }, o = {
    nan: "NaN",
    number: "antal",
    array: "lista"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `Ogiltig inmatning: f\xF6rv\xE4ntat instanceof ${n.expected}, fick ${u}` : `Ogiltig inmatning: f\xF6rv\xE4ntat ${i}, fick ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `Ogiltig inmatning: f\xF6rv\xE4ntat ${$(n.values[0])}` : `Ogiltigt val: f\xF6rv\xE4ntade en av ${m(n.values, "|")}`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin);
        return a ? `F\xF6r stor(t): f\xF6rv\xE4ntade ${n.origin ?? "v\xE4rdet"} att ha ${i}${n.maximum.toString()} ${a.unit ?? "element"}` : `F\xF6r stor(t): f\xF6rv\xE4ntat ${n.origin ?? "v\xE4rdet"} att ha ${i}${n.maximum.toString()}`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin);
        return a ? `F\xF6r lite(t): f\xF6rv\xE4ntade ${n.origin ?? "v\xE4rdet"} att ha ${i}${n.minimum.toString()} ${a.unit}` : `F\xF6r lite(t): f\xF6rv\xE4ntade ${n.origin ?? "v\xE4rdet"} att ha ${i}${n.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `Ogiltig str\xE4ng: m\xE5ste b\xF6rja med "${i.prefix}"` : i.format === "ends_with" ? `Ogiltig str\xE4ng: m\xE5ste sluta med "${i.suffix}"` : i.format === "includes" ? `Ogiltig str\xE4ng: m\xE5ste inneh\xE5lla "${i.includes}"` : i.format === "regex" ? `Ogiltig str\xE4ng: m\xE5ste matcha m\xF6nstret "${i.pattern}"` : `Ogiltig(t) ${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `Ogiltigt tal: m\xE5ste vara en multipel av ${n.divisor}`;
      case "unrecognized_keys":
        return `${n.keys.length > 1 ? "Ok\xE4nda nycklar" : "Ok\xE4nd nyckel"}: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `Ogiltig nyckel i ${n.origin ?? "v\xE4rdet"}`;
      case "invalid_union":
        return "Ogiltig input";
      case "invalid_element":
        return `Ogiltigt v\xE4rde i ${n.origin ?? "v\xE4rdet"}`;
      default:
        return "Ogiltig input";
    }
  };
}, "error");
function Uu() {
  return {
    localeError: zy()
  };
}
s(Uu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ta.js
var Sy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0B8E\u0BB4\u0BC1\u0BA4\u0BCD\u0BA4\u0BC1\u0B95\u0BCD\u0B95\u0BB3\u0BCD", verb: "\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD" },
    file: { unit: "\u0BAA\u0BC8\u0B9F\u0BCD\u0B9F\u0BC1\u0B95\u0BB3\u0BCD", verb: "\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD" },
    array: { unit: "\u0B89\u0BB1\u0BC1\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD", verb: "\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD" },
    set: { unit: "\u0B89\u0BB1\u0BC1\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD", verb: "\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD" },
    map: { unit: "\u0B89\u0BB1\u0BC1\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD", verb: "\u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "\u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1",
    email: "\u0BAE\u0BBF\u0BA9\u0BCD\u0BA9\u0B9E\u0BCD\u0B9A\u0BB2\u0BCD \u0BAE\u0BC1\u0B95\u0BB5\u0BB0\u0BBF",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u0BA4\u0BC7\u0BA4\u0BBF \u0BA8\u0BC7\u0BB0\u0BAE\u0BCD",
    date: "ISO \u0BA4\u0BC7\u0BA4\u0BBF",
    time: "ISO \u0BA8\u0BC7\u0BB0\u0BAE\u0BCD",
    duration: "ISO \u0B95\u0BBE\u0BB2 \u0B85\u0BB3\u0BB5\u0BC1",
    ipv4: "IPv4 \u0BAE\u0BC1\u0B95\u0BB5\u0BB0\u0BBF",
    ipv6: "IPv6 \u0BAE\u0BC1\u0B95\u0BB5\u0BB0\u0BBF",
    mac: "MAC \u0BAE\u0BC1\u0B95\u0BB5\u0BB0\u0BBF",
    cidrv4: "IPv4 \u0BB5\u0BB0\u0BAE\u0BCD\u0BAA\u0BC1",
    cidrv6: "IPv6 \u0BB5\u0BB0\u0BAE\u0BCD\u0BAA\u0BC1",
    base64: "base64-encoded \u0B9A\u0BB0\u0BAE\u0BCD",
    base64url: "base64url-encoded \u0B9A\u0BB0\u0BAE\u0BCD",
    json_string: "JSON \u0B9A\u0BB0\u0BAE\u0BCD",
    e164: "E.164 \u0B8E\u0BA3\u0BCD",
    credit_card: "\u0B95\u0B9F\u0BA9\u0BCD \u0B85\u0B9F\u0BCD\u0B9F\u0BC8 \u0B8E\u0BA3\u0BCD",
    jwt: "JWT",
    template_literal: "input"
  }, o = {
    nan: "NaN",
    number: "\u0B8E\u0BA3\u0BCD",
    array: "\u0B85\u0BA3\u0BBF",
    null: "\u0BB5\u0BC6\u0BB1\u0BC1\u0BAE\u0BC8"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 instanceof ${n.expected}, \u0BAA\u0BC6\u0BB1\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${u}` : `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${i}, \u0BAA\u0BC6\u0BB1\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${$(n.values[0])}` : `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0BB5\u0BBF\u0BB0\u0BC1\u0BAA\u0BCD\u0BAA\u0BAE\u0BCD: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${m(n.values, "|")} \u0B87\u0BB2\u0BCD \u0B92\u0BA9\u0BCD\u0BB1\u0BC1`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin);
        return a ? `\u0BAE\u0BBF\u0B95 \u0BAA\u0BC6\u0BB0\u0BBF\u0BAF\u0BA4\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${n.origin ?? "\u0BAE\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1"} ${i}${n.maximum.toString()} ${a.unit ?? "\u0B89\u0BB1\u0BC1\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD"} \u0B86\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : `\u0BAE\u0BBF\u0B95 \u0BAA\u0BC6\u0BB0\u0BBF\u0BAF\u0BA4\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${n.origin ?? "\u0BAE\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1"} ${i}${n.maximum.toString()} \u0B86\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin);
        return a ? `\u0BAE\u0BBF\u0B95\u0B9A\u0BCD \u0B9A\u0BBF\u0BB1\u0BBF\u0BAF\u0BA4\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${n.origin} ${i}${n.minimum.toString()} ${a.unit} \u0B86\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : `\u0BAE\u0BBF\u0B95\u0B9A\u0BCD \u0B9A\u0BBF\u0BB1\u0BBF\u0BAF\u0BA4\u0BC1: \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1 ${n.origin} ${i}${n.minimum.toString()} \u0B86\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B9A\u0BB0\u0BAE\u0BCD: "${i.prefix}" \u0B87\u0BB2\u0BCD \u0BA4\u0BCA\u0B9F\u0B99\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : i.format === "ends_with" ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B9A\u0BB0\u0BAE\u0BCD: "${i.suffix}" \u0B87\u0BB2\u0BCD \u0BAE\u0BC1\u0B9F\u0BBF\u0BB5\u0B9F\u0BC8\u0BAF \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : i.format === "includes" ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B9A\u0BB0\u0BAE\u0BCD: "${i.includes}" \u0B90 \u0B89\u0BB3\u0BCD\u0BB3\u0B9F\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : i.format === "regex" ? `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B9A\u0BB0\u0BAE\u0BCD: ${i.pattern} \u0BAE\u0BC1\u0BB1\u0BC8\u0BAA\u0BBE\u0B9F\u0BCD\u0B9F\u0BC1\u0B9F\u0BA9\u0BCD \u0BAA\u0BCA\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD` : `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 ${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B8E\u0BA3\u0BCD: ${n.divisor} \u0B87\u0BA9\u0BCD \u0BAA\u0BB2\u0BAE\u0BBE\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD`;
      case "unrecognized_keys":
        return `\u0B85\u0B9F\u0BC8\u0BAF\u0BBE\u0BB3\u0BAE\u0BCD \u0BA4\u0BC6\u0BB0\u0BBF\u0BAF\u0BBE\u0BA4 \u0BB5\u0BBF\u0B9A\u0BC8${n.keys.length > 1 ? "\u0B95\u0BB3\u0BCD" : ""}: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `${n.origin} \u0B87\u0BB2\u0BCD \u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0BB5\u0BBF\u0B9A\u0BC8`;
      case "invalid_union":
        return "\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1";
      case "invalid_element":
        return `${n.origin} \u0B87\u0BB2\u0BCD \u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0BAE\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1`;
      default:
        return "\u0BA4\u0BB5\u0BB1\u0BBE\u0BA9 \u0B89\u0BB3\u0BCD\u0BB3\u0BC0\u0B9F\u0BC1";
    }
  };
}, "error");
function Au() {
  return {
    localeError: Sy()
  };
}
s(Au, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/th.js
var jy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0E15\u0E31\u0E27\u0E2D\u0E31\u0E01\u0E29\u0E23", verb: "\u0E04\u0E27\u0E23\u0E21\u0E35" },
    file: { unit: "\u0E44\u0E1A\u0E15\u0E4C", verb: "\u0E04\u0E27\u0E23\u0E21\u0E35" },
    array: { unit: "\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23", verb: "\u0E04\u0E27\u0E23\u0E21\u0E35" },
    set: { unit: "\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23", verb: "\u0E04\u0E27\u0E23\u0E21\u0E35" },
    map: { unit: "\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23", verb: "\u0E04\u0E27\u0E23\u0E21\u0E35" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E17\u0E35\u0E48\u0E1B\u0E49\u0E2D\u0E19",
    email: "\u0E17\u0E35\u0E48\u0E2D\u0E22\u0E39\u0E48\u0E2D\u0E35\u0E40\u0E21\u0E25",
    url: "URL",
    emoji: "\u0E2D\u0E34\u0E42\u0E21\u0E08\u0E34",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48\u0E40\u0E27\u0E25\u0E32\u0E41\u0E1A\u0E1A ISO",
    date: "\u0E27\u0E31\u0E19\u0E17\u0E35\u0E48\u0E41\u0E1A\u0E1A ISO",
    time: "\u0E40\u0E27\u0E25\u0E32\u0E41\u0E1A\u0E1A ISO",
    duration: "\u0E0A\u0E48\u0E27\u0E07\u0E40\u0E27\u0E25\u0E32\u0E41\u0E1A\u0E1A ISO",
    ipv4: "\u0E17\u0E35\u0E48\u0E2D\u0E22\u0E39\u0E48 IPv4",
    ipv6: "\u0E17\u0E35\u0E48\u0E2D\u0E22\u0E39\u0E48 IPv6",
    mac: "\u0E17\u0E35\u0E48\u0E2D\u0E22\u0E39\u0E48 MAC",
    cidrv4: "\u0E0A\u0E48\u0E27\u0E07 IP \u0E41\u0E1A\u0E1A IPv4",
    cidrv6: "\u0E0A\u0E48\u0E27\u0E07 IP \u0E41\u0E1A\u0E1A IPv6",
    base64: "\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E41\u0E1A\u0E1A Base64",
    base64url: "\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E41\u0E1A\u0E1A Base64 \u0E2A\u0E33\u0E2B\u0E23\u0E31\u0E1A URL",
    json_string: "\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E41\u0E1A\u0E1A JSON",
    e164: "\u0E40\u0E1A\u0E2D\u0E23\u0E4C\u0E42\u0E17\u0E23\u0E28\u0E31\u0E1E\u0E17\u0E4C\u0E23\u0E30\u0E2B\u0E27\u0E48\u0E32\u0E07\u0E1B\u0E23\u0E30\u0E40\u0E17\u0E28 (E.164)",
    credit_card: "\u0E2B\u0E21\u0E32\u0E22\u0E40\u0E25\u0E02\u0E1A\u0E31\u0E15\u0E23\u0E40\u0E04\u0E23\u0E14\u0E34\u0E15",
    jwt: "\u0E42\u0E17\u0E40\u0E04\u0E19 JWT",
    template_literal: "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E17\u0E35\u0E48\u0E1B\u0E49\u0E2D\u0E19"
  }, o = {
    nan: "NaN",
    number: "\u0E15\u0E31\u0E27\u0E40\u0E25\u0E02",
    array: "\u0E2D\u0E32\u0E23\u0E4C\u0E40\u0E23\u0E22\u0E4C (Array)",
    null: "\u0E44\u0E21\u0E48\u0E21\u0E35\u0E04\u0E48\u0E32 (null)"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `\u0E1B\u0E23\u0E30\u0E40\u0E20\u0E17\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E04\u0E27\u0E23\u0E40\u0E1B\u0E47\u0E19 instanceof ${n.expected} \u0E41\u0E15\u0E48\u0E44\u0E14\u0E49\u0E23\u0E31\u0E1A ${u}` : `\u0E1B\u0E23\u0E30\u0E40\u0E20\u0E17\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E04\u0E27\u0E23\u0E40\u0E1B\u0E47\u0E19 ${i} \u0E41\u0E15\u0E48\u0E44\u0E14\u0E49\u0E23\u0E31\u0E1A ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `\u0E04\u0E48\u0E32\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E04\u0E27\u0E23\u0E40\u0E1B\u0E47\u0E19 ${$(n.values[0])}` : `\u0E15\u0E31\u0E27\u0E40\u0E25\u0E37\u0E2D\u0E01\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E04\u0E27\u0E23\u0E40\u0E1B\u0E47\u0E19\u0E2B\u0E19\u0E36\u0E48\u0E07\u0E43\u0E19 ${m(n.values, "|")}`;
      case "too_big": {
        let i = n.inclusive ? "\u0E44\u0E21\u0E48\u0E40\u0E01\u0E34\u0E19" : "\u0E19\u0E49\u0E2D\u0E22\u0E01\u0E27\u0E48\u0E32", a = t(n.origin);
        return a ? `\u0E40\u0E01\u0E34\u0E19\u0E01\u0E33\u0E2B\u0E19\u0E14: ${n.origin ?? "\u0E04\u0E48\u0E32"} \u0E04\u0E27\u0E23\u0E21\u0E35${i} ${n.maximum.toString()} ${a.unit ?? "\u0E23\u0E32\u0E22\u0E01\u0E32\u0E23"}` : `\u0E40\u0E01\u0E34\u0E19\u0E01\u0E33\u0E2B\u0E19\u0E14: ${n.origin ?? "\u0E04\u0E48\u0E32"} \u0E04\u0E27\u0E23\u0E21\u0E35${i} ${n.maximum.toString()}`;
      }
      case "too_small": {
        let i = n.inclusive ? "\u0E2D\u0E22\u0E48\u0E32\u0E07\u0E19\u0E49\u0E2D\u0E22" : "\u0E21\u0E32\u0E01\u0E01\u0E27\u0E48\u0E32", a = t(n.origin);
        return a ? `\u0E19\u0E49\u0E2D\u0E22\u0E01\u0E27\u0E48\u0E32\u0E01\u0E33\u0E2B\u0E19\u0E14: ${n.origin} \u0E04\u0E27\u0E23\u0E21\u0E35${i} ${n.minimum.toString()} ${a.unit}` : `\u0E19\u0E49\u0E2D\u0E22\u0E01\u0E27\u0E48\u0E32\u0E01\u0E33\u0E2B\u0E19\u0E14: ${n.origin} \u0E04\u0E27\u0E23\u0E21\u0E35${i} ${n.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E15\u0E49\u0E2D\u0E07\u0E02\u0E36\u0E49\u0E19\u0E15\u0E49\u0E19\u0E14\u0E49\u0E27\u0E22 "${i.prefix}"` : i.format === "ends_with" ? `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E15\u0E49\u0E2D\u0E07\u0E25\u0E07\u0E17\u0E49\u0E32\u0E22\u0E14\u0E49\u0E27\u0E22 "${i.suffix}"` : i.format === "includes" ? `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21\u0E15\u0E49\u0E2D\u0E07\u0E21\u0E35 "${i.includes}" \u0E2D\u0E22\u0E39\u0E48\u0E43\u0E19\u0E02\u0E49\u0E2D\u0E04\u0E27\u0E32\u0E21` : i.format === "regex" ? `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E15\u0E49\u0E2D\u0E07\u0E15\u0E23\u0E07\u0E01\u0E31\u0E1A\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E17\u0E35\u0E48\u0E01\u0E33\u0E2B\u0E19\u0E14 ${i.pattern}` : `\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: ${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `\u0E15\u0E31\u0E27\u0E40\u0E25\u0E02\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E15\u0E49\u0E2D\u0E07\u0E40\u0E1B\u0E47\u0E19\u0E08\u0E33\u0E19\u0E27\u0E19\u0E17\u0E35\u0E48\u0E2B\u0E32\u0E23\u0E14\u0E49\u0E27\u0E22 ${n.divisor} \u0E44\u0E14\u0E49\u0E25\u0E07\u0E15\u0E31\u0E27`;
      case "unrecognized_keys":
        return `\u0E1E\u0E1A\u0E04\u0E35\u0E22\u0E4C\u0E17\u0E35\u0E48\u0E44\u0E21\u0E48\u0E23\u0E39\u0E49\u0E08\u0E31\u0E01: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `\u0E04\u0E35\u0E22\u0E4C\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07\u0E43\u0E19 ${n.origin}`;
      case "invalid_union":
        return "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07: \u0E44\u0E21\u0E48\u0E15\u0E23\u0E07\u0E01\u0E31\u0E1A\u0E23\u0E39\u0E1B\u0E41\u0E1A\u0E1A\u0E22\u0E39\u0E40\u0E19\u0E35\u0E22\u0E19\u0E17\u0E35\u0E48\u0E01\u0E33\u0E2B\u0E19\u0E14\u0E44\u0E27\u0E49";
      case "invalid_element":
        return `\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07\u0E43\u0E19 ${n.origin}`;
      default:
        return "\u0E02\u0E49\u0E2D\u0E21\u0E39\u0E25\u0E44\u0E21\u0E48\u0E16\u0E39\u0E01\u0E15\u0E49\u0E2D\u0E07";
    }
  };
}, "error");
function Eu() {
  return {
    localeError: jy()
  };
}
s(Eu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/tk.js
var Oy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "simwol", verb: "bolmaly" },
    file: { unit: "ba\xFDt", verb: "bolmaly" },
    array: { unit: "elementler", verb: "bolmaly" },
    set: { unit: "elementler", verb: "bolmaly" },
    map: { unit: "elementler", verb: "bolmaly" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "giri\u015F",
    email: "e-po\xE7ta salgysy",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO sene we wagt",
    date: "ISO sene",
    time: "ISO wagt",
    duration: "ISO wagt aralygy",
    ipv4: "IPv4 salgysy",
    ipv6: "IPv6 salgysy",
    mac: "MAC salgysy",
    cidrv4: "IPv4 aralygy",
    cidrv6: "IPv6 aralygy",
    base64: "base64 bilen \u015Fifrlenen setir",
    base64url: "base64url bilen \u015Fifrlenen setir",
    json_string: "JSON setiri",
    e164: "E.164 nomeri",
    credit_card: "kredit kartyny\u0148 nomeri",
    jwt: "JWT",
    template_literal: "\u015Fablon"
  }, o = {
    nan: "NaN"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return `N\xE4dogry baha: gara\u015Fylan ${i} \xFDerine ${u} alyndy`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `N\xE4dogry baha: ${$(n.values[0])} bolmaly` : `N\xE4dogry sa\xFDlaw: a\u015Fakdakylardan biri bolmaly: ${m(n.values, "|")}`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin);
        return a ? `Has uly: gara\u015Fyl\xFDan ${n.origin ?? "baha"} ${i} ${n.maximum.toString()} ${a.unit ?? "element"}` : `Has uly: gara\u015Fyl\xFDan ${n.origin ?? "baha"} ${i} ${n.maximum.toString()}`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin);
        return a ? `Has ki\xE7i: gara\u015Fyl\xFDan ${n.origin} ${i} ${n.minimum.toString()} ${a.unit}` : `Has ki\xE7i: gara\u015Fyl\xFDan ${n.origin} ${i} ${n.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `N\xE4dogry setir: "${i.prefix}" bilen ba\u015Flamaly` : i.format === "ends_with" ? `N\xE4dogry setir: "${i.suffix}" bilen gutarmaly` : i.format === "includes" ? `N\xE4dogry setir: "${i.includes}" saklamaly` : i.format === "regex" ? `N\xE4dogry setir: ${i.pattern} nusga la\xFDyk bolmaly` : `N\xE4dogry ${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `N\xE4dogry san: ${n.divisor} bilen galyndysyz b\xF6l\xFCnmeli`;
      case "unrecognized_keys":
        return `Tanalma\xFDan a\xE7ar${n.keys.length > 1 ? "lar" : ""}: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `${n.origin} i\xE7inde n\xE4dogry a\xE7ar`;
      case "invalid_union":
        return "N\xE4dogry baha";
      case "invalid_element":
        return `${n.origin} i\xE7inde n\xE4dogry baha`;
      default:
        return "N\xE4dogry baha";
    }
  };
}, "error");
function Cu() {
  return {
    localeError: Oy()
  };
}
s(Cu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/tr.js
var Dy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "karakter", verb: "olmal\u0131" },
    file: { unit: "bayt", verb: "olmal\u0131" },
    array: { unit: "\xF6\u011Fe", verb: "olmal\u0131" },
    set: { unit: "\xF6\u011Fe", verb: "olmal\u0131" },
    map: { unit: "\xF6\u011Fe", verb: "olmal\u0131" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "girdi",
    email: "e-posta adresi",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO tarih ve saat",
    date: "ISO tarih",
    time: "ISO saat",
    duration: "ISO s\xFCre",
    ipv4: "IPv4 adresi",
    ipv6: "IPv6 adresi",
    mac: "MAC adresi",
    cidrv4: "IPv4 aral\u0131\u011F\u0131",
    cidrv6: "IPv6 aral\u0131\u011F\u0131",
    base64: "base64 ile \u015Fifrelenmi\u015F metin",
    base64url: "base64url ile \u015Fifrelenmi\u015F metin",
    json_string: "JSON dizesi",
    e164: "E.164 say\u0131s\u0131",
    credit_card: "kredi kart\u0131 numaras\u0131",
    jwt: "JWT",
    template_literal: "\u015Eablon dizesi"
  }, o = {
    nan: "NaN"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `Ge\xE7ersiz de\u011Fer: beklenen instanceof ${n.expected}, al\u0131nan ${u}` : `Ge\xE7ersiz de\u011Fer: beklenen ${i}, al\u0131nan ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `Ge\xE7ersiz de\u011Fer: beklenen ${$(n.values[0])}` : `Ge\xE7ersiz se\xE7enek: a\u015Fa\u011F\u0131dakilerden biri olmal\u0131: ${m(n.values, "|")}`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin);
        return a ? `\xC7ok b\xFCy\xFCk: beklenen ${n.origin ?? "de\u011Fer"} ${i}${n.maximum.toString()} ${a.unit ?? "\xF6\u011Fe"}` : `\xC7ok b\xFCy\xFCk: beklenen ${n.origin ?? "de\u011Fer"} ${i}${n.maximum.toString()}`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin);
        return a ? `\xC7ok k\xFC\xE7\xFCk: beklenen ${n.origin} ${i}${n.minimum.toString()} ${a.unit}` : `\xC7ok k\xFC\xE7\xFCk: beklenen ${n.origin} ${i}${n.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `Ge\xE7ersiz metin: "${i.prefix}" ile ba\u015Flamal\u0131` : i.format === "ends_with" ? `Ge\xE7ersiz metin: "${i.suffix}" ile bitmeli` : i.format === "includes" ? `Ge\xE7ersiz metin: "${i.includes}" i\xE7ermeli` : i.format === "regex" ? `Ge\xE7ersiz metin: ${i.pattern} desenine uymal\u0131` : `Ge\xE7ersiz ${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `Ge\xE7ersiz say\u0131: ${n.divisor} ile tam b\xF6l\xFCnebilmeli`;
      case "unrecognized_keys":
        return `Tan\u0131nmayan anahtar${n.keys.length > 1 ? "lar" : ""}: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `${n.origin} i\xE7inde ge\xE7ersiz anahtar`;
      case "invalid_union":
        return "Ge\xE7ersiz de\u011Fer";
      case "invalid_element":
        return `${n.origin} i\xE7inde ge\xE7ersiz de\u011Fer`;
      default:
        return "Ge\xE7ersiz de\u011Fer";
    }
  };
}, "error");
function Zu() {
  return {
    localeError: Dy()
  };
}
s(Zu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/uk.js
var Py = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u0441\u0438\u043C\u0432\u043E\u043B\u0456\u0432", verb: "\u043C\u0430\u0442\u0438\u043C\u0435" },
    file: { unit: "\u0431\u0430\u0439\u0442\u0456\u0432", verb: "\u043C\u0430\u0442\u0438\u043C\u0435" },
    array: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0456\u0432", verb: "\u043C\u0430\u0442\u0438\u043C\u0435" },
    set: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0456\u0432", verb: "\u043C\u0430\u0442\u0438\u043C\u0435" },
    map: { unit: "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0456\u0432", verb: "\u043C\u0430\u0442\u0438\u043C\u0435" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "\u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456",
    email: "\u0430\u0434\u0440\u0435\u0441\u0430 \u0435\u043B\u0435\u043A\u0442\u0440\u043E\u043D\u043D\u043E\u0457 \u043F\u043E\u0448\u0442\u0438",
    url: "URL",
    emoji: "\u0435\u043C\u043E\u0434\u0437\u0456",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\u0434\u0430\u0442\u0430 \u0442\u0430 \u0447\u0430\u0441 ISO",
    date: "\u0434\u0430\u0442\u0430 ISO",
    time: "\u0447\u0430\u0441 ISO",
    duration: "\u0442\u0440\u0438\u0432\u0430\u043B\u0456\u0441\u0442\u044C ISO",
    ipv4: "\u0430\u0434\u0440\u0435\u0441\u0430 IPv4",
    ipv6: "\u0430\u0434\u0440\u0435\u0441\u0430 IPv6",
    mac: "\u0430\u0434\u0440\u0435\u0441\u0430 MAC",
    cidrv4: "\u0434\u0456\u0430\u043F\u0430\u0437\u043E\u043D IPv4",
    cidrv6: "\u0434\u0456\u0430\u043F\u0430\u0437\u043E\u043D IPv6",
    base64: "\u0440\u044F\u0434\u043E\u043A \u0443 \u043A\u043E\u0434\u0443\u0432\u0430\u043D\u043D\u0456 base64",
    base64url: "\u0440\u044F\u0434\u043E\u043A \u0443 \u043A\u043E\u0434\u0443\u0432\u0430\u043D\u043D\u0456 base64url",
    json_string: "\u0440\u044F\u0434\u043E\u043A JSON",
    e164: "\u043D\u043E\u043C\u0435\u0440 E.164",
    credit_card: "\u043D\u043E\u043C\u0435\u0440 \u043A\u0440\u0435\u0434\u0438\u0442\u043D\u043E\u0457 \u043A\u0430\u0440\u0442\u043A\u0438",
    jwt: "JWT",
    template_literal: "\u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456"
  }, o = {
    nan: "NaN",
    number: "\u0447\u0438\u0441\u043B\u043E",
    array: "\u043C\u0430\u0441\u0438\u0432"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F instanceof ${n.expected}, \u043E\u0442\u0440\u0438\u043C\u0430\u043D\u043E ${u}` : `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F ${i}, \u043E\u0442\u0440\u0438\u043C\u0430\u043D\u043E ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F ${$(n.values[0])}` : `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0430 \u043E\u043F\u0446\u0456\u044F: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F \u043E\u0434\u043D\u0435 \u0437 ${m(n.values, "|")}`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin);
        return a ? `\u0417\u0430\u043D\u0430\u0434\u0442\u043E \u0432\u0435\u043B\u0438\u043A\u0435: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F, \u0449\u043E ${n.origin ?? "\u0437\u043D\u0430\u0447\u0435\u043D\u043D\u044F"} ${a.verb} ${i}${n.maximum.toString()} ${a.unit ?? "\u0435\u043B\u0435\u043C\u0435\u043D\u0442\u0456\u0432"}` : `\u0417\u0430\u043D\u0430\u0434\u0442\u043E \u0432\u0435\u043B\u0438\u043A\u0435: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F, \u0449\u043E ${n.origin ?? "\u0437\u043D\u0430\u0447\u0435\u043D\u043D\u044F"} \u0431\u0443\u0434\u0435 ${i}${n.maximum.toString()}`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin);
        return a ? `\u0417\u0430\u043D\u0430\u0434\u0442\u043E \u043C\u0430\u043B\u0435: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F, \u0449\u043E ${n.origin} ${a.verb} ${i}${n.minimum.toString()} ${a.unit}` : `\u0417\u0430\u043D\u0430\u0434\u0442\u043E \u043C\u0430\u043B\u0435: \u043E\u0447\u0456\u043A\u0443\u0454\u0442\u044C\u0441\u044F, \u0449\u043E ${n.origin} \u0431\u0443\u0434\u0435 ${i}${n.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u0440\u044F\u0434\u043E\u043A: \u043F\u043E\u0432\u0438\u043D\u0435\u043D \u043F\u043E\u0447\u0438\u043D\u0430\u0442\u0438\u0441\u044F \u0437 "${i.prefix}"` : i.format === "ends_with" ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u0440\u044F\u0434\u043E\u043A: \u043F\u043E\u0432\u0438\u043D\u0435\u043D \u0437\u0430\u043A\u0456\u043D\u0447\u0443\u0432\u0430\u0442\u0438\u0441\u044F \u043D\u0430 "${i.suffix}"` : i.format === "includes" ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u0440\u044F\u0434\u043E\u043A: \u043F\u043E\u0432\u0438\u043D\u0435\u043D \u043C\u0456\u0441\u0442\u0438\u0442\u0438 "${i.includes}"` : i.format === "regex" ? `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u0440\u044F\u0434\u043E\u043A: \u043F\u043E\u0432\u0438\u043D\u0435\u043D \u0432\u0456\u0434\u043F\u043E\u0432\u0456\u0434\u0430\u0442\u0438 \u0448\u0430\u0431\u043B\u043E\u043D\u0443 ${i.pattern}` : `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 ${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0435 \u0447\u0438\u0441\u043B\u043E: \u043F\u043E\u0432\u0438\u043D\u043D\u043E \u0431\u0443\u0442\u0438 \u043A\u0440\u0430\u0442\u043D\u0438\u043C ${n.divisor}`;
      case "unrecognized_keys":
        return `\u041D\u0435\u0440\u043E\u0437\u043F\u0456\u0437\u043D\u0430\u043D\u0438\u0439 \u043A\u043B\u044E\u0447${n.keys.length > 1 ? "\u0456" : ""}: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0438\u0439 \u043A\u043B\u044E\u0447 \u0443 ${n.origin}`;
      case "invalid_union":
        return "\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456";
      case "invalid_element":
        return `\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u043D\u044F \u0443 ${n.origin}`;
      default:
        return "\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0456 \u0432\u0445\u0456\u0434\u043D\u0456 \u0434\u0430\u043D\u0456";
    }
  };
}, "error");
function vn() {
  return {
    localeError: Py()
  };
}
s(vn, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ua.js
function Fu() {
  return vn();
}
s(Fu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/ur.js
var Ty = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u062D\u0631\u0648\u0641", verb: "\u06C1\u0648\u0646\u0627" },
    file: { unit: "\u0628\u0627\u0626\u0679\u0633", verb: "\u06C1\u0648\u0646\u0627" },
    array: { unit: "\u0622\u0626\u0679\u0645\u0632", verb: "\u06C1\u0648\u0646\u0627" },
    set: { unit: "\u0622\u0626\u0679\u0645\u0632", verb: "\u06C1\u0648\u0646\u0627" },
    map: { unit: "\u0622\u0626\u0679\u0645\u0632", verb: "\u06C1\u0648\u0646\u0627" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "\u0627\u0646 \u067E\u0679",
    email: "\u0627\u06CC \u0645\u06CC\u0644 \u0627\u06CC\u0688\u0631\u06CC\u0633",
    url: "\u06CC\u0648 \u0622\u0631 \u0627\u06CC\u0644",
    emoji: "\u0627\u06CC\u0645\u0648\u062C\u06CC",
    uuid: "\u06CC\u0648 \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC",
    uuidv4: "\u06CC\u0648 \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC \u0648\u06CC 4",
    uuidv6: "\u06CC\u0648 \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC \u0648\u06CC 6",
    nanoid: "\u0646\u06CC\u0646\u0648 \u0622\u0626\u06CC \u0688\u06CC",
    guid: "\u062C\u06CC \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC",
    cuid: "\u0633\u06CC \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC",
    cuid2: "\u0633\u06CC \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC 2",
    ulid: "\u06CC\u0648 \u0627\u06CC\u0644 \u0622\u0626\u06CC \u0688\u06CC",
    xid: "\u0627\u06CC\u06A9\u0633 \u0622\u0626\u06CC \u0688\u06CC",
    ksuid: "\u06A9\u06D2 \u0627\u06CC\u0633 \u06CC\u0648 \u0622\u0626\u06CC \u0688\u06CC",
    datetime: "\u0622\u0626\u06CC \u0627\u06CC\u0633 \u0627\u0648 \u0688\u06CC\u0679 \u0679\u0627\u0626\u0645",
    date: "\u0622\u0626\u06CC \u0627\u06CC\u0633 \u0627\u0648 \u062A\u0627\u0631\u06CC\u062E",
    time: "\u0622\u0626\u06CC \u0627\u06CC\u0633 \u0627\u0648 \u0648\u0642\u062A",
    duration: "\u0622\u0626\u06CC \u0627\u06CC\u0633 \u0627\u0648 \u0645\u062F\u062A",
    ipv4: "\u0622\u0626\u06CC \u067E\u06CC \u0648\u06CC 4 \u0627\u06CC\u0688\u0631\u06CC\u0633",
    ipv6: "\u0622\u0626\u06CC \u067E\u06CC \u0648\u06CC 6 \u0627\u06CC\u0688\u0631\u06CC\u0633",
    mac: "\u0627\u06CC\u0645 \u0627\u06D2 \u0633\u06CC \u0627\u06CC\u0688\u0631\u06CC\u0633",
    cidrv4: "\u0622\u0626\u06CC \u067E\u06CC \u0648\u06CC 4 \u0631\u06CC\u0646\u062C",
    cidrv6: "\u0622\u0626\u06CC \u067E\u06CC \u0648\u06CC 6 \u0631\u06CC\u0646\u062C",
    base64: "\u0628\u06CC\u0633 64 \u0627\u0646 \u06A9\u0648\u0688\u0688 \u0633\u0679\u0631\u0646\u06AF",
    base64url: "\u0628\u06CC\u0633 64 \u06CC\u0648 \u0622\u0631 \u0627\u06CC\u0644 \u0627\u0646 \u06A9\u0648\u0688\u0688 \u0633\u0679\u0631\u0646\u06AF",
    json_string: "\u062C\u06D2 \u0627\u06CC\u0633 \u0627\u0648 \u0627\u06CC\u0646 \u0633\u0679\u0631\u0646\u06AF",
    e164: "\u0627\u06CC 164 \u0646\u0645\u0628\u0631",
    credit_card: "\u06A9\u0631\u06CC\u0688\u0679 \u06A9\u0627\u0631\u0688 \u0646\u0645\u0628\u0631",
    jwt: "\u062C\u06D2 \u0688\u0628\u0644\u06CC\u0648 \u0679\u06CC",
    template_literal: "\u0627\u0646 \u067E\u0679"
  }, o = {
    nan: "NaN",
    number: "\u0646\u0645\u0628\u0631",
    array: "\u0622\u0631\u06D2",
    null: "\u0646\u0644"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679: instanceof ${n.expected} \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627\u060C ${u} \u0645\u0648\u0635\u0648\u0644 \u06C1\u0648\u0627` : `\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679: ${i} \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627\u060C ${u} \u0645\u0648\u0635\u0648\u0644 \u06C1\u0648\u0627`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679: ${$(n.values[0])} \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627` : `\u063A\u0644\u0637 \u0622\u067E\u0634\u0646: ${m(n.values, "|")} \u0645\u06CC\u06BA \u0633\u06D2 \u0627\u06CC\u06A9 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin);
        return a ? `\u0628\u06C1\u062A \u0628\u0691\u0627: ${n.origin ?? "\u0648\u06CC\u0644\u06CC\u0648"} \u06A9\u06D2 ${i}${n.maximum.toString()} ${a.unit ?? "\u0639\u0646\u0627\u0635\u0631"} \u06C1\u0648\u0646\u06D2 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u06D2` : `\u0628\u06C1\u062A \u0628\u0691\u0627: ${n.origin ?? "\u0648\u06CC\u0644\u06CC\u0648"} \u06A9\u0627 ${i}${n.maximum.toString()} \u06C1\u0648\u0646\u0627 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin);
        return a ? `\u0628\u06C1\u062A \u0686\u06BE\u0648\u0679\u0627: ${n.origin} \u06A9\u06D2 ${i}${n.minimum.toString()} ${a.unit} \u06C1\u0648\u0646\u06D2 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u06D2` : `\u0628\u06C1\u062A \u0686\u06BE\u0648\u0679\u0627: ${n.origin} \u06A9\u0627 ${i}${n.minimum.toString()} \u06C1\u0648\u0646\u0627 \u0645\u062A\u0648\u0642\u0639 \u062A\u06BE\u0627`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `\u063A\u0644\u0637 \u0633\u0679\u0631\u0646\u06AF: "${i.prefix}" \u0633\u06D2 \u0634\u0631\u0648\u0639 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2` : i.format === "ends_with" ? `\u063A\u0644\u0637 \u0633\u0679\u0631\u0646\u06AF: "${i.suffix}" \u067E\u0631 \u062E\u062A\u0645 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2` : i.format === "includes" ? `\u063A\u0644\u0637 \u0633\u0679\u0631\u0646\u06AF: "${i.includes}" \u0634\u0627\u0645\u0644 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2` : i.format === "regex" ? `\u063A\u0644\u0637 \u0633\u0679\u0631\u0646\u06AF: \u067E\u06CC\u0679\u0631\u0646 ${i.pattern} \u0633\u06D2 \u0645\u06CC\u0686 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2` : `\u063A\u0644\u0637 ${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `\u063A\u0644\u0637 \u0646\u0645\u0628\u0631: ${n.divisor} \u06A9\u0627 \u0645\u0636\u0627\u0639\u0641 \u06C1\u0648\u0646\u0627 \u0686\u0627\u06C1\u06CC\u06D2`;
      case "unrecognized_keys":
        return `\u063A\u06CC\u0631 \u062A\u0633\u0644\u06CC\u0645 \u0634\u062F\u06C1 \u06A9\u06CC${n.keys.length > 1 ? "\u0632" : ""}: ${m(n.keys, "\u060C ")}`;
      case "invalid_key":
        return `${n.origin} \u0645\u06CC\u06BA \u063A\u0644\u0637 \u06A9\u06CC`;
      case "invalid_union":
        return "\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679";
      case "invalid_element":
        return `${n.origin} \u0645\u06CC\u06BA \u063A\u0644\u0637 \u0648\u06CC\u0644\u06CC\u0648`;
      default:
        return "\u063A\u0644\u0637 \u0627\u0646 \u067E\u0679";
    }
  };
}, "error");
function Mu() {
  return {
    localeError: Ty()
  };
}
s(Mu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/uz.js
var Ny = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "belgi", verb: "bo\u2018lishi kerak" },
    file: { unit: "bayt", verb: "bo\u2018lishi kerak" },
    array: { unit: "element", verb: "bo\u2018lishi kerak" },
    set: { unit: "element", verb: "bo\u2018lishi kerak" },
    map: { unit: "yozuv", verb: "bo\u2018lishi kerak" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "kirish",
    email: "elektron pochta manzili",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO sana va vaqti",
    date: "ISO sana",
    time: "ISO vaqt",
    duration: "ISO davomiylik",
    ipv4: "IPv4 manzil",
    ipv6: "IPv6 manzil",
    mac: "MAC manzil",
    cidrv4: "IPv4 diapazon",
    cidrv6: "IPv6 diapazon",
    base64: "base64 kodlangan satr",
    base64url: "base64url kodlangan satr",
    json_string: "JSON satr",
    e164: "E.164 raqam",
    credit_card: "kredit karta raqami",
    jwt: "JWT",
    template_literal: "kirish"
  }, o = {
    nan: "NaN",
    number: "raqam",
    array: "massiv"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `Noto\u2018g\u2018ri kirish: kutilgan instanceof ${n.expected}, qabul qilingan ${u}` : `Noto\u2018g\u2018ri kirish: kutilgan ${i}, qabul qilingan ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `Noto\u2018g\u2018ri kirish: kutilgan ${$(n.values[0])}` : `Noto\u2018g\u2018ri variant: quyidagilardan biri kutilgan ${m(n.values, "|")}`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin);
        return a ? `Juda katta: kutilgan ${n.origin ?? "qiymat"} ${i}${n.maximum.toString()} ${a.unit} ${a.verb}` : `Juda katta: kutilgan ${n.origin ?? "qiymat"} ${i}${n.maximum.toString()}`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin);
        return a ? `Juda kichik: kutilgan ${n.origin} ${i}${n.minimum.toString()} ${a.unit} ${a.verb}` : `Juda kichik: kutilgan ${n.origin} ${i}${n.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `Noto\u2018g\u2018ri satr: "${i.prefix}" bilan boshlanishi kerak` : i.format === "ends_with" ? `Noto\u2018g\u2018ri satr: "${i.suffix}" bilan tugashi kerak` : i.format === "includes" ? `Noto\u2018g\u2018ri satr: "${i.includes}" ni o\u2018z ichiga olishi kerak` : i.format === "regex" ? `Noto\u2018g\u2018ri satr: ${i.pattern} shabloniga mos kelishi kerak` : `Noto\u2018g\u2018ri ${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `Noto\u2018g\u2018ri raqam: ${n.divisor} ning karralisi bo\u2018lishi kerak`;
      case "unrecognized_keys":
        return `Noma\u2019lum kalit${n.keys.length > 1 ? "lar" : ""}: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `${n.origin} dagi kalit noto\u2018g\u2018ri`;
      case "invalid_union":
        return "Noto\u2018g\u2018ri kirish";
      case "invalid_element":
        return `${n.origin} da noto\u2018g\u2018ri qiymat`;
      default:
        return "Noto\u2018g\u2018ri kirish";
    }
  };
}, "error");
function Ru() {
  return {
    localeError: Ny()
  };
}
s(Ru, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/vi.js
var Uy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "k\xFD t\u1EF1", verb: "c\xF3" },
    file: { unit: "byte", verb: "c\xF3" },
    array: { unit: "ph\u1EA7n t\u1EED", verb: "c\xF3" },
    set: { unit: "ph\u1EA7n t\u1EED", verb: "c\xF3" },
    map: { unit: "ph\u1EA7n t\u1EED", verb: "c\xF3" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "\u0111\u1EA7u v\xE0o",
    email: "\u0111\u1ECBa ch\u1EC9 email",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ng\xE0y gi\u1EDD ISO",
    date: "ng\xE0y ISO",
    time: "gi\u1EDD ISO",
    duration: "kho\u1EA3ng th\u1EDDi gian ISO",
    ipv4: "\u0111\u1ECBa ch\u1EC9 IPv4",
    ipv6: "\u0111\u1ECBa ch\u1EC9 IPv6",
    mac: "\u0111\u1ECBa ch\u1EC9 MAC",
    cidrv4: "d\u1EA3i IPv4",
    cidrv6: "d\u1EA3i IPv6",
    base64: "chu\u1ED7i m\xE3 h\xF3a base64",
    base64url: "chu\u1ED7i m\xE3 h\xF3a base64url",
    json_string: "chu\u1ED7i JSON",
    e164: "s\u1ED1 E.164",
    credit_card: "s\u1ED1 th\u1EBB t\xEDn d\u1EE5ng",
    jwt: "JWT",
    template_literal: "\u0111\u1EA7u v\xE0o"
  }, o = {
    nan: "NaN",
    number: "s\u1ED1",
    array: "m\u1EA3ng"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7: mong \u0111\u1EE3i instanceof ${n.expected}, nh\u1EADn \u0111\u01B0\u1EE3c ${u}` : `\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7: mong \u0111\u1EE3i ${i}, nh\u1EADn \u0111\u01B0\u1EE3c ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7: mong \u0111\u1EE3i ${$(n.values[0])}` : `T\xF9y ch\u1ECDn kh\xF4ng h\u1EE3p l\u1EC7: mong \u0111\u1EE3i m\u1ED9t trong c\xE1c gi\xE1 tr\u1ECB ${m(n.values, "|")}`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin);
        return a ? `Qu\xE1 l\u1EDBn: mong \u0111\u1EE3i ${n.origin ?? "gi\xE1 tr\u1ECB"} ${a.verb} ${i}${n.maximum.toString()} ${a.unit ?? "ph\u1EA7n t\u1EED"}` : `Qu\xE1 l\u1EDBn: mong \u0111\u1EE3i ${n.origin ?? "gi\xE1 tr\u1ECB"} ${i}${n.maximum.toString()}`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin);
        return a ? `Qu\xE1 nh\u1ECF: mong \u0111\u1EE3i ${n.origin} ${a.verb} ${i}${n.minimum.toString()} ${a.unit}` : `Qu\xE1 nh\u1ECF: mong \u0111\u1EE3i ${n.origin} ${i}${n.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `Chu\u1ED7i kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i b\u1EAFt \u0111\u1EA7u b\u1EB1ng "${i.prefix}"` : i.format === "ends_with" ? `Chu\u1ED7i kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i k\u1EBFt th\xFAc b\u1EB1ng "${i.suffix}"` : i.format === "includes" ? `Chu\u1ED7i kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i bao g\u1ED3m "${i.includes}"` : i.format === "regex" ? `Chu\u1ED7i kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i kh\u1EDBp v\u1EDBi m\u1EABu ${i.pattern}` : `${r[i.format] ?? n.format} kh\xF4ng h\u1EE3p l\u1EC7`;
      }
      case "not_multiple_of":
        return `S\u1ED1 kh\xF4ng h\u1EE3p l\u1EC7: ph\u1EA3i l\xE0 b\u1ED9i s\u1ED1 c\u1EE7a ${n.divisor}`;
      case "unrecognized_keys":
        return `Kh\xF3a kh\xF4ng \u0111\u01B0\u1EE3c nh\u1EADn d\u1EA1ng: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `Kh\xF3a kh\xF4ng h\u1EE3p l\u1EC7 trong ${n.origin}`;
      case "invalid_union":
        return "\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7";
      case "invalid_element":
        return `Gi\xE1 tr\u1ECB kh\xF4ng h\u1EE3p l\u1EC7 trong ${n.origin}`;
      default:
        return "\u0110\u1EA7u v\xE0o kh\xF4ng h\u1EE3p l\u1EC7";
    }
  };
}, "error");
function Lu() {
  return {
    localeError: Uy()
  };
}
s(Lu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/zh-CN.js
var Ay = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u5B57\u7B26", verb: "\u5305\u542B" },
    file: { unit: "\u5B57\u8282", verb: "\u5305\u542B" },
    array: { unit: "\u9879", verb: "\u5305\u542B" },
    set: { unit: "\u9879", verb: "\u5305\u542B" },
    map: { unit: "\u9879", verb: "\u5305\u542B" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "\u8F93\u5165",
    email: "\u7535\u5B50\u90AE\u4EF6",
    url: "URL",
    emoji: "\u8868\u60C5\u7B26\u53F7",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO\u65E5\u671F\u65F6\u95F4",
    date: "ISO\u65E5\u671F",
    time: "ISO\u65F6\u95F4",
    duration: "ISO\u65F6\u957F",
    ipv4: "IPv4\u5730\u5740",
    ipv6: "IPv6\u5730\u5740",
    mac: "MAC\u5730\u5740",
    cidrv4: "IPv4\u7F51\u6BB5",
    cidrv6: "IPv6\u7F51\u6BB5",
    base64: "base64\u7F16\u7801\u5B57\u7B26\u4E32",
    base64url: "base64url\u7F16\u7801\u5B57\u7B26\u4E32",
    json_string: "JSON\u5B57\u7B26\u4E32",
    e164: "E.164\u53F7\u7801",
    credit_card: "\u4FE1\u7528\u5361\u53F7",
    jwt: "JWT",
    template_literal: "\u8F93\u5165"
  }, o = {
    nan: "NaN",
    number: "\u6570\u5B57",
    array: "\u6570\u7EC4",
    null: "\u7A7A\u503C(null)"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `\u65E0\u6548\u8F93\u5165\uFF1A\u671F\u671B instanceof ${n.expected}\uFF0C\u5B9E\u9645\u63A5\u6536 ${u}` : `\u65E0\u6548\u8F93\u5165\uFF1A\u671F\u671B ${i}\uFF0C\u5B9E\u9645\u63A5\u6536 ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `\u65E0\u6548\u8F93\u5165\uFF1A\u671F\u671B ${$(n.values[0])}` : `\u65E0\u6548\u9009\u9879\uFF1A\u671F\u671B\u4EE5\u4E0B\u4E4B\u4E00 ${m(n.values, "|")}`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin);
        return a ? `\u6570\u503C\u8FC7\u5927\uFF1A\u671F\u671B ${n.origin ?? "\u503C"} ${i}${n.maximum.toString()} ${a.unit ?? "\u4E2A\u5143\u7D20"}` : `\u6570\u503C\u8FC7\u5927\uFF1A\u671F\u671B ${n.origin ?? "\u503C"} ${i}${n.maximum.toString()}`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin);
        return a ? `\u6570\u503C\u8FC7\u5C0F\uFF1A\u671F\u671B ${n.origin} ${i}${n.minimum.toString()} ${a.unit}` : `\u6570\u503C\u8FC7\u5C0F\uFF1A\u671F\u671B ${n.origin} ${i}${n.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `\u65E0\u6548\u5B57\u7B26\u4E32\uFF1A\u5FC5\u987B\u4EE5 "${i.prefix}" \u5F00\u5934` : i.format === "ends_with" ? `\u65E0\u6548\u5B57\u7B26\u4E32\uFF1A\u5FC5\u987B\u4EE5 "${i.suffix}" \u7ED3\u5C3E` : i.format === "includes" ? `\u65E0\u6548\u5B57\u7B26\u4E32\uFF1A\u5FC5\u987B\u5305\u542B "${i.includes}"` : i.format === "regex" ? `\u65E0\u6548\u5B57\u7B26\u4E32\uFF1A\u5FC5\u987B\u6EE1\u8DB3\u6B63\u5219\u8868\u8FBE\u5F0F ${i.pattern}` : `\u65E0\u6548${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `\u65E0\u6548\u6570\u5B57\uFF1A\u5FC5\u987B\u662F ${n.divisor} \u7684\u500D\u6570`;
      case "unrecognized_keys":
        return `\u51FA\u73B0\u672A\u77E5\u7684\u952E(key): ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `${n.origin} \u4E2D\u7684\u952E(key)\u65E0\u6548`;
      case "invalid_union":
        return "\u65E0\u6548\u8F93\u5165";
      case "invalid_element":
        return `${n.origin} \u4E2D\u5305\u542B\u65E0\u6548\u503C(value)`;
      default:
        return "\u65E0\u6548\u8F93\u5165";
    }
  };
}, "error");
function Vu() {
  return {
    localeError: Ay()
  };
}
s(Vu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/zh-TW.js
var Ey = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\u5B57\u5143", verb: "\u64C1\u6709" },
    file: { unit: "\u4F4D\u5143\u7D44", verb: "\u64C1\u6709" },
    array: { unit: "\u9805\u76EE", verb: "\u64C1\u6709" },
    set: { unit: "\u9805\u76EE", verb: "\u64C1\u6709" },
    map: { unit: "\u9805\u76EE", verb: "\u64C1\u6709" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "\u8F38\u5165",
    email: "\u90F5\u4EF6\u5730\u5740",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO \u65E5\u671F\u6642\u9593",
    date: "ISO \u65E5\u671F",
    time: "ISO \u6642\u9593",
    duration: "ISO \u671F\u9593",
    ipv4: "IPv4 \u4F4D\u5740",
    ipv6: "IPv6 \u4F4D\u5740",
    mac: "MAC \u4F4D\u5740",
    cidrv4: "IPv4 \u7BC4\u570D",
    cidrv6: "IPv6 \u7BC4\u570D",
    base64: "base64 \u7DE8\u78BC\u5B57\u4E32",
    base64url: "base64url \u7DE8\u78BC\u5B57\u4E32",
    json_string: "JSON \u5B57\u4E32",
    e164: "E.164 \u6578\u503C",
    credit_card: "\u4FE1\u7528\u5361\u865F",
    jwt: "JWT",
    template_literal: "\u8F38\u5165"
  }, o = {
    nan: "NaN"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `\u7121\u6548\u7684\u8F38\u5165\u503C\uFF1A\u9810\u671F\u70BA instanceof ${n.expected}\uFF0C\u4F46\u6536\u5230 ${u}` : `\u7121\u6548\u7684\u8F38\u5165\u503C\uFF1A\u9810\u671F\u70BA ${i}\uFF0C\u4F46\u6536\u5230 ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `\u7121\u6548\u7684\u8F38\u5165\u503C\uFF1A\u9810\u671F\u70BA ${$(n.values[0])}` : `\u7121\u6548\u7684\u9078\u9805\uFF1A\u9810\u671F\u70BA\u4EE5\u4E0B\u5176\u4E2D\u4E4B\u4E00 ${m(n.values, "|")}`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin);
        return a ? `\u6578\u503C\u904E\u5927\uFF1A\u9810\u671F ${n.origin ?? "\u503C"} \u61C9\u70BA ${i}${n.maximum.toString()} ${a.unit ?? "\u500B\u5143\u7D20"}` : `\u6578\u503C\u904E\u5927\uFF1A\u9810\u671F ${n.origin ?? "\u503C"} \u61C9\u70BA ${i}${n.maximum.toString()}`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin);
        return a ? `\u6578\u503C\u904E\u5C0F\uFF1A\u9810\u671F ${n.origin} \u61C9\u70BA ${i}${n.minimum.toString()} ${a.unit}` : `\u6578\u503C\u904E\u5C0F\uFF1A\u9810\u671F ${n.origin} \u61C9\u70BA ${i}${n.minimum.toString()}`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `\u7121\u6548\u7684\u5B57\u4E32\uFF1A\u5FC5\u9808\u4EE5 "${i.prefix}" \u958B\u982D` : i.format === "ends_with" ? `\u7121\u6548\u7684\u5B57\u4E32\uFF1A\u5FC5\u9808\u4EE5 "${i.suffix}" \u7D50\u5C3E` : i.format === "includes" ? `\u7121\u6548\u7684\u5B57\u4E32\uFF1A\u5FC5\u9808\u5305\u542B "${i.includes}"` : i.format === "regex" ? `\u7121\u6548\u7684\u5B57\u4E32\uFF1A\u5FC5\u9808\u7B26\u5408\u683C\u5F0F ${i.pattern}` : `\u7121\u6548\u7684 ${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `\u7121\u6548\u7684\u6578\u5B57\uFF1A\u5FC5\u9808\u70BA ${n.divisor} \u7684\u500D\u6578`;
      case "unrecognized_keys":
        return `\u7121\u6CD5\u8B58\u5225\u7684\u9375\u503C${n.keys.length > 1 ? "\u5011" : ""}\uFF1A${m(n.keys, "\u3001")}`;
      case "invalid_key":
        return `${n.origin} \u4E2D\u6709\u7121\u6548\u7684\u9375\u503C`;
      case "invalid_union":
        return "\u7121\u6548\u7684\u8F38\u5165\u503C";
      case "invalid_element":
        return `${n.origin} \u4E2D\u6709\u7121\u6548\u7684\u503C`;
      default:
        return "\u7121\u6548\u7684\u8F38\u5165\u503C";
    }
  };
}, "error");
function Bu() {
  return {
    localeError: Ey()
  };
}
s(Bu, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/locales/yo.js
var Cy = /* @__PURE__ */ s(() => {
  let e = {
    string: { unit: "\xE0mi", verb: "n\xED" },
    file: { unit: "bytes", verb: "n\xED" },
    array: { unit: "nkan", verb: "n\xED" },
    set: { unit: "nkan", verb: "n\xED" },
    map: { unit: "nkan", verb: "n\xED" }
  };
  function t(n) {
    return e[n] ?? null;
  }
  s(t, "getSizing");
  let r = {
    regex: "\u1EB9\u0300r\u1ECD \xECb\xE1w\u1ECDl\xE9",
    email: "\xE0d\xEDr\u1EB9\u0301s\xEC \xECm\u1EB9\u0301l\xEC",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "\xE0k\xF3k\xF2 ISO",
    date: "\u1ECDj\u1ECD\u0301 ISO",
    time: "\xE0k\xF3k\xF2 ISO",
    duration: "\xE0k\xF3k\xF2 t\xF3 p\xE9 ISO",
    ipv4: "\xE0d\xEDr\u1EB9\u0301s\xEC IPv4",
    ipv6: "\xE0d\xEDr\u1EB9\u0301s\xEC IPv6",
    mac: "\xE0d\xEDr\u1EB9\u0301s\xEC MAC",
    cidrv4: "\xE0gb\xE8gb\xE8 IPv4",
    cidrv6: "\xE0gb\xE8gb\xE8 IPv6",
    base64: "\u1ECD\u0300r\u1ECD\u0300 t\xED a k\u1ECD\u0301 n\xED base64",
    base64url: "\u1ECD\u0300r\u1ECD\u0300 base64url",
    json_string: "\u1ECD\u0300r\u1ECD\u0300 JSON",
    e164: "n\u1ECD\u0301mb\xE0 E.164",
    credit_card: "n\u1ECDmba kaadi gbese",
    jwt: "JWT",
    template_literal: "\u1EB9\u0300r\u1ECD \xECb\xE1w\u1ECDl\xE9"
  }, o = {
    nan: "NaN",
    number: "n\u1ECD\u0301mb\xE0",
    array: "akop\u1ECD"
  };
  return (n) => {
    switch (n.code) {
      case "invalid_type": {
        let i = o[n.expected] ?? n.expected, a = b(n.input), u = o[a] ?? a;
        return /^[A-Z]/.test(n.expected) ? `\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e: a n\xED l\xE1ti fi instanceof ${n.expected}, \xE0m\u1ECD\u0300 a r\xED ${u}` : `\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e: a n\xED l\xE1ti fi ${i}, \xE0m\u1ECD\u0300 a r\xED ${u}`;
      }
      case "invalid_value":
        return n.values.length === 1 ? `\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e: a n\xED l\xE1ti fi ${$(n.values[0])}` : `\xC0\u1E63\xE0y\xE0n a\u1E63\xEC\u1E63e: yan \u1ECD\u0300kan l\xE1ra ${m(n.values, "|")}`;
      case "too_big": {
        let i = n.inclusive ? "<=" : "<", a = t(n.origin);
        return a ? `T\xF3 p\u1ECD\u0300 j\xF9: a n\xED l\xE1ti j\u1EB9\u0301 p\xE9 ${n.origin ?? "iye"} ${a.verb} ${i}${n.maximum} ${a.unit}` : `T\xF3 p\u1ECD\u0300 j\xF9: a n\xED l\xE1ti j\u1EB9\u0301 ${i}${n.maximum}`;
      }
      case "too_small": {
        let i = n.inclusive ? ">=" : ">", a = t(n.origin);
        return a ? `K\xE9r\xE9 ju: a n\xED l\xE1ti j\u1EB9\u0301 p\xE9 ${n.origin} ${a.verb} ${i}${n.minimum} ${a.unit}` : `K\xE9r\xE9 ju: a n\xED l\xE1ti j\u1EB9\u0301 ${i}${n.minimum}`;
      }
      case "invalid_format": {
        let i = n;
        return i.format === "starts_with" ? `\u1ECC\u0300r\u1ECD\u0300 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 b\u1EB9\u0300r\u1EB9\u0300 p\u1EB9\u0300l\xFA "${i.prefix}"` : i.format === "ends_with" ? `\u1ECC\u0300r\u1ECD\u0300 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 par\xED p\u1EB9\u0300l\xFA "${i.suffix}"` : i.format === "includes" ? `\u1ECC\u0300r\u1ECD\u0300 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 n\xED "${i.includes}"` : i.format === "regex" ? `\u1ECC\u0300r\u1ECD\u0300 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 b\xE1 \xE0p\u1EB9\u1EB9r\u1EB9 mu ${i.pattern}` : `A\u1E63\xEC\u1E63e: ${r[i.format] ?? n.format}`;
      }
      case "not_multiple_of":
        return `N\u1ECD\u0301mb\xE0 a\u1E63\xEC\u1E63e: gb\u1ECD\u0301d\u1ECD\u0300 j\u1EB9\u0301 \xE8y\xE0 p\xEDp\xEDn ti ${n.divisor}`;
      case "unrecognized_keys":
        return `B\u1ECDt\xECn\xEC \xE0\xECm\u1ECD\u0300: ${m(n.keys, ", ")}`;
      case "invalid_key":
        return `B\u1ECDt\xECn\xEC a\u1E63\xEC\u1E63e n\xEDn\xFA ${n.origin}`;
      case "invalid_union":
        return "\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e";
      case "invalid_element":
        return `Iye a\u1E63\xEC\u1E63e n\xEDn\xFA ${n.origin}`;
      default:
        return "\xCCb\xE1w\u1ECDl\xE9 a\u1E63\xEC\u1E63e";
    }
  };
}, "error");
function Ju() {
  return {
    localeError: Cy()
  };
}
s(Ju, "default");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/registries.js
var Lf, qu = /* @__PURE__ */ Symbol("ZodOutput"), Wu = /* @__PURE__ */ Symbol("ZodInput"), Mr = class {
  static {
    s(this, "$ZodRegistry");
  }
  constructor() {
    this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map();
  }
  add(t, ...r) {
    let o = r[0];
    return this._map.set(t, o), o && typeof o == "object" && "id" in o && this._idmap.set(o.id, t), this;
  }
  clear() {
    return this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map(), this;
  }
  remove(t) {
    let r = this._map.get(t);
    return r && typeof r == "object" && "id" in r && this._idmap.delete(r.id), this._map.delete(t), this;
  }
  get(t) {
    let r = t._zod.parent;
    if (r) {
      let o = { ...this.get(r) ?? {} };
      delete o.id;
      let n = { ...o, ...this._map.get(t) };
      return Object.keys(n).length ? n : void 0;
    }
    return this._map.get(t);
  }
  has(t) {
    return this._map.has(t);
  }
};
function Rr() {
  return new Mr();
}
s(Rr, "registry");
(Lf = globalThis).__zod_globalRegistry ?? (Lf.__zod_globalRegistry = Rr());
var Oe = globalThis.__zod_globalRegistry;

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/compile.js
var be = Symbol.for("zod.compile.invalid"), Vf = Symbol.for("zod.compile.fallback"), De = class extends Error {
  static {
    s(this, "ZodCompileAsyncError");
  }
  constructor(t = "z.compile does not support async refinements, transforms, or checks") {
    super(t), this.name = "ZodCompileAsyncError";
  }
}, C = class extends Error {
  static {
    s(this, "ZodCompileUnsupportedError");
  }
  constructor(t, r = !0) {
    super(`z.compile does not support ${t}; this schema must use the runtime parser`), this.name = "ZodCompileUnsupportedError", this.islandable = r;
  }
};
function Fy(e, t) {
  try {
    return Lr(e, { assertOnly: !0 });
  } catch {
    return t;
  }
}
s(Fy, "compileValidator");
function Hu(e, t) {
  try {
    let r = Lr(e), o = E(e), n = e._zod.run, i = n.__originalRun ?? n, a = /* @__PURE__ */ s((u, c) => {
      if (c?.async || c?.direction === "backward" || c?.skipChecks || c?.[Vf] || c && Fr(c, u.value))
        return i(u, c);
      let l = r(u.value);
      return l !== be ? (u.value = l, u) : (c && (c[Vf] = !0), i(u, c));
    }, "wrapped");
    return a.__originalRun = i, o._zod.bag.fallbackRun = i, o._zod.bag.validator = Fy(e, r), o._zod.run = a, n.__originalRun || My(o, e, r), o;
  } catch (r) {
    if (t?.strict)
      throw r;
    return e;
  }
}
s(Hu, "compile");
function My(e, t, r) {
  let o = e, n = t;
  if (typeof n.safeParse == "function") {
    let i = n.safeParse;
    o.safeParse = (a, u) => {
      let c = r(a);
      return c !== be ? { success: !0, data: c } : i(a, u);
    };
  }
  if (typeof n.parse == "function") {
    let i = n.parse;
    o.parse = (a, u) => {
      let c = r(a);
      return c !== be ? c : i(a, u);
    };
  }
}
s(My, "installCompiledUserMethods");
function Lr(e, t) {
  let r = !0;
  try {
    r = Zs(e);
  } catch {
  }
  if (r)
    throw new C("a schema whose subtree contains a reference cycle");
  let o = {
    constants: /* @__PURE__ */ new Map(),
    constantCounter: 0,
    varCounter: 0
  }, n = new lt(["input"]), i = H(n, o, e, "input", !t?.assertOnly);
  n.write(i === null ? "return true;" : `return ${i};`);
  let a = ["INVALID", ...o.constants.keys()], u = [be, ...o.constants.values()], c = n.content.join(`
`), l = t?.debug ? a.length > 0 ? `// Constants: ${a.join(", ")}
${c}` : c : "", d = Function, f = `return (input) => {
${c}
}`, p;
  try {
    p = new d(...a, f)(...u);
  } catch (h) {
    throw new C(`this schema (generated code failed to evaluate: ${h.message})`);
  }
  return t?.debug && (p.code = l), p;
}
s(Lr, "compileFn");
function D(e, t) {
  for (let [o, n] of e.constants)
    if (n === t)
      return o;
  let r = `c${e.constantCounter++}`;
  return e.constants.set(r, t), r;
}
s(D, "addConstant");
function P(e) {
  return `v${e.varCounter++}`;
}
s(P, "newVar");
function Ry(e, t) {
  let r = e._zod.run({ value: t, issues: [] }, {});
  if (r && typeof r.then == "function")
    return be;
  let o = r;
  return o.issues.length === 0 ? o.value : be;
}
s(Ry, "runtimeRun");
function le(e, t, r, o, n = !0) {
  let i = e.content.length, a = t.constants.size, u = t.constantCounter, c = t.varCounter;
  try {
    return H(e, t, r, o, n);
  } catch (l) {
    if (!(l instanceof C) || !l.islandable)
      throw l;
    if (e.content.length = i, t.constants.size > a) {
      let d = Array.from(t.constants.keys()).slice(a);
      for (let f of d)
        t.constants.delete(f);
    }
    return t.constantCounter = u, t.varCounter = c, Ly(e, t, r, o);
  }
}
s(le, "compileChild");
function Ly(e, t, r, o) {
  let n = D(t, r), i = D(t, Ry), a = P(t);
  return e.write(`const ${a} = ${i}(${n}, ${o});`), e.write(`if (${a} === INVALID) return INVALID;`), a;
}
s(Ly, "emitRuntimeIsland");
var Vy = /* @__PURE__ */ new Set([
  "max_size",
  "min_size",
  "size_equals",
  "max_length",
  "min_length",
  "length_equals"
]);
function By(e, t, r, o) {
  let n = r._zod.def.checks;
  if (!n || n.length === 0)
    return o;
  let i = o;
  for (let a of n) {
    let u = a._zod.def;
    if (u.when && !Vy.has(u.check))
      throw new C('check with a custom "when" condition');
    switch (u.check) {
      case "greater_than":
        Jy(e, t, u, i);
        break;
      case "less_than":
        qy(e, t, u, i);
        break;
      case "multiple_of":
        Wy(e, t, u, i);
        break;
      case "number_format":
        Wf(e, u, i);
        break;
      case "min_length": {
        let c = ft(u.minimum, "min_length"), l = Ku(e, t, i, `${i}.length >= ${c} && ${i}.length < ${u.minimum * 2}`);
        e.write(`if (${l} < ${c}) return INVALID;`);
        break;
      }
      case "max_length": {
        let c = ft(u.maximum, "max_length"), l = Ku(e, t, i, `${i}.length > ${c}`);
        e.write(`if (${l} > ${c}) return INVALID;`);
        break;
      }
      case "length_equals": {
        let c = ft(u.length, "length_equals"), l = Ku(e, t, i, `${i}.length >= ${c} && ${i}.length <= ${u.length * 2}`);
        e.write(`if (${l} !== ${c}) return INVALID;`);
        break;
      }
      case "min_size":
        e.write(`if (${i}.size < ${ft(u.minimum, "min_size")}) return INVALID;`);
        break;
      case "max_size":
        e.write(`if (${i}.size > ${ft(u.maximum, "max_size")}) return INVALID;`);
        break;
      case "size_equals":
        e.write(`if (${i}.size !== ${ft(u.size, "size_equals")}) return INVALID;`);
        break;
      case "string_format":
        i = Kf(e, t, u, i);
        break;
      case "custom":
        i = Qy(e, t, a, i);
        break;
      case "bigint_format":
        Ky(e, u, i);
        break;
      case "mime_type":
        Gy(e, t, u, i);
        break;
      case "property":
        Xy(e, t, u, i);
        break;
      case "overwrite": {
        let c = P(t);
        Hy(e, t, a, i, c), i = c;
        break;
      }
      default:
        throw new C(`check type ${u.check}`);
    }
  }
  return i;
}
s(By, "generateChecks");
function Ku(e, t, r, o) {
  let n = D(t, st), i = P(t);
  return e.write(`const ${i} = typeof ${r} === "string" && ${o} ? ${n}(${r}) : ${r}.length;`), i;
}
s(Ku, "codePointLengthVar");
function ft(e, t) {
  if (typeof e != "number" || !Number.isFinite(e))
    throw new C(`${t} bound of type ${typeof e}`);
  return `${e}`;
}
s(ft, "numericOperand");
function qf(e, t) {
  if (typeof t == "bigint")
    return `${t}n`;
  if (typeof t == "number") {
    if (Number.isNaN(t))
      throw new C("comparison check with NaN bound");
    return `${t}`;
  }
  if (t instanceof Date) {
    if (Number.isNaN(t.getTime()))
      throw new C("comparison check with Invalid Date bound");
    return D(e, t);
  }
  throw new C(`comparison check bound of type ${typeof t}`);
}
s(qf, "comparisonOperand");
function Jy(e, t, r, o) {
  let n = r.inclusive ? "<" : "<=";
  e.write(`if (${o} ${n} ${qf(t, r.value)}) return INVALID;`);
}
s(Jy, "generateGreaterThanCheck");
function qy(e, t, r, o) {
  let n = r.inclusive ? ">" : ">=";
  e.write(`if (${o} ${n} ${qf(t, r.value)}) return INVALID;`);
}
s(qy, "generateLessThanCheck");
function Wy(e, t, r, o) {
  if (typeof r.value == "bigint") {
    if (r.value === BigInt(0))
      throw new C("multiple_of check with a zero divisor");
    e.write(`if (${o} % ${r.value}n !== 0n) return INVALID;`);
  } else {
    let n = D(t, rn);
    e.write(`if (${n}(${o}, ${ft(r.value, "multiple_of")}) !== 0) return INVALID;`);
  }
}
s(Wy, "generateMultipleOfCheck");
function Wf(e, t, r) {
  let o = t.format;
  switch (o) {
    case "safeint":
      e.write(`if (!Number.isSafeInteger(${r})) return INVALID;`);
      break;
    case "int32":
      e.write(`if (!Number.isInteger(${r}) || ${r} < -2147483648 || ${r} > 2147483647) return INVALID;`);
      break;
    case "uint32":
      e.write(`if (!Number.isInteger(${r}) || ${r} < 0 || ${r} > 4294967295) return INVALID;`);
      break;
    case "float32":
      e.write(`if (!Number.isFinite(${r}) || ${r} < -3.4028234663852886e38 || ${r} > 3.4028234663852886e38) return INVALID;`);
      break;
    case "float64":
      e.write(`if (!Number.isFinite(${r})) return INVALID;`);
      break;
    default:
      throw new C(`number format ${o}`);
  }
}
s(Wf, "generateNumberFormatCheck");
function Ky(e, t, r) {
  let o = t.format;
  if (o)
    switch (o) {
      case "int64":
        e.write(`if (${r} < -9223372036854775808n || ${r} > 9223372036854775807n) return INVALID;`);
        break;
      case "uint64":
        e.write(`if (${r} < 0n || ${r} > 18446744073709551615n) return INVALID;`);
        break;
      default:
        throw new C(`bigint format ${o}`);
    }
}
s(Ky, "generateBigIntFormatCheck");
function Gy(e, t, r, o) {
  let n = r.mime;
  if (n && n.length > 0) {
    let i = D(t, new Set(n));
    e.write(`if (!${i}.has(${o}.type)) return INVALID;`);
  }
}
s(Gy, "generateMimeTypeCheck");
function Xy(e, t, r, o) {
  let n = `${o}[${JSON.stringify(r.property)}]`;
  H(e, t, r.schema, n);
}
s(Xy, "generatePropertyCheck");
function Hy(e, t, r, o, n) {
  let i = r._zod.def.tx;
  if (!i)
    throw new C("overwrite check without a transform function");
  if (gt(i))
    throw new De("z.compile: async overwrite transforms are not supported");
  let a = D(t, i);
  e.write(`const ${n} = ${a}(${o});`);
}
s(Hy, "generateOverwriteCheck");
function Gu() {
  throw new ge();
}
s(Gu, "throwAsync");
function Qu(e) {
  this.issues.push(e);
}
s(Qu, "pushIssue");
function Qy(e, t, r, o) {
  let n = r._zod.def;
  if (n.fn) {
    if (gt(n.fn))
      throw new De("z.compile: async .refine() predicates are not supported");
    let i = D(t, n.fn), a = D(t, Gu), u = P(t);
    return e.write(`const ${u} = ${i}(${o});`), e.write(`if (${u} instanceof Promise) ${a}();`), e.write(`if (!${u}) return INVALID;`), o;
  }
  if (r._zod.check) {
    if (gt(r._zod.check))
      throw new De("z.compile: async .superRefine() / check functions are not supported");
    let i = r._zod.check, u = D(t, /* @__PURE__ */ s((l) => {
      let d = { value: l, issues: [], addIssue: Qu };
      return i(d) instanceof Promise && Gu(), d.issues.length === 0 ? d.value : be;
    }, "helperFn")), c = P(t);
    return e.write(`const ${c} = ${u}(${o});`), e.write(`if (${c} === INVALID) return INVALID;`), c;
  }
  throw new C("custom check without a predicate or check function");
}
s(Qy, "generateCustomRefineCheck");
var Yy = /* @__PURE__ */ new Set([
  "cidrv4",
  "cuid",
  "cuid2",
  "date",
  "datetime",
  "duration",
  "e164",
  "email",
  "emoji",
  "ends_with",
  "guid",
  "includes",
  "ipv4",
  "ksuid",
  "lowercase",
  "mac",
  "nanoid",
  "regex",
  "starts_with",
  "time",
  "ulid",
  "uppercase",
  "uuid",
  "xid"
]);
function Kf(e, t, r, o) {
  let n = r.format;
  if (n === "base64") {
    let c = D(t, fn);
    return e.write(`if (!${c}(${o})) return INVALID;`), o;
  }
  if (n === "base64url") {
    let c = D(t, Dr);
    return e.write(`if (!${c}(${o})) return INVALID;`), o;
  }
  if (n === "jwt") {
    let c = D(t, Tr), l = D(t, r.alg ?? null);
    return e.write(`if (!${c}(${o}, ${l})) return INVALID;`), o;
  }
  if (n === "ipv6") {
    let c = D(t, dn);
    return e.write(`if (!${c}(${o})) return INVALID;`), o;
  }
  if (n === "cidrv6") {
    let c = D(t, Or);
    return e.write(`if (!${c}(${o})) return INVALID;`), o;
  }
  if (n === "credit_card") {
    let c = D(t, Pr);
    return e.write(`if (!${c}(${o})) return INVALID;`), o;
  }
  let i = r;
  if (n === "url" || n === "httpurl" || i.normalize || i.hostname !== void 0 || i.protocol !== void 0) {
    let c = D(t, kr), l = D(t, r), d = P(t), f = P(t);
    if (e.write(`const ${d} = ${o}.trim();`), e.write(`const ${f} = ${c}(${d}, ${l});`), e.write(`if (typeof ${f} === "number") return INVALID;`), i.hostname !== void 0) {
      let v = D(t, Sr);
      e.write(`if (!${v}(${f}, ${l}.hostname)) return INVALID;`);
    }
    if (i.protocol !== void 0) {
      let v = D(t, jr);
      e.write(`if (!${v}(${f}, ${l}.protocol)) return INVALID;`);
    }
    let p = P(t), h = i.normalize ? `${f}.href` : `${D(t, zr)}(${d})`;
    return e.write(`const ${p} = ${h};`), p;
  }
  let a = r.fn;
  if (a) {
    if (gt(a))
      throw new C(`async string format ${n}`);
    let c = D(t, a);
    return e.write(`if (!${c}(${o})) return INVALID;`), o;
  }
  if (Yy.has(n) && r.pattern) {
    let c = D(t, r.pattern);
    return e.write(`${c}.lastIndex = 0;`), e.write(`if (!${c}.test(${o})) return INVALID;`), o;
  }
  let u = r.format;
  switch (u) {
    case "regex":
      throw new C("regex format without a pattern");
    case "lowercase":
      e.write(`if (${o} !== ${o}.toLowerCase()) return INVALID;`);
      break;
    case "uppercase":
      e.write(`if (${o} !== ${o}.toUpperCase()) return INVALID;`);
      break;
    case "includes":
      e.write(`if (!${o}.includes(${fe(r.includes)})) return INVALID;`);
      break;
    case "starts_with": {
      let c = r.prefix;
      e.write(`if (${o}.slice(0, ${c.length}) !== ${fe(c)}) return INVALID;`);
      break;
    }
    case "ends_with": {
      let c = r.suffix;
      e.write(`if (${o}.slice(-${c.length}) !== ${fe(c)}) return INVALID;`);
      break;
    }
    default:
      throw new C(`string format ${u}`);
  }
  return o;
}
s(Kf, "generateStringFormatCheck");
function H(e, t, r, o, n = !0) {
  let i = r._zod.def, a = i.type;
  if (i.coerce)
    throw new C(`coercion (z.coerce.${a}())`);
  let u = n || !!i.checks?.length, c;
  switch (a) {
    case "string":
      c = e$(e, t, r, o);
      break;
    case "number":
      c = t$(e, r, o);
      break;
    case "boolean":
      c = n$(e, o);
      break;
    case "bigint":
      c = r$(e, r, o);
      break;
    case "symbol":
      c = i$(e, o);
      break;
    case "undefined":
      c = o$(e, o);
      break;
    case "null":
      c = a$(e, o);
      break;
    case "any":
    case "unknown":
      c = o;
      break;
    case "never":
      e.write("return INVALID;"), c = o;
      break;
    case "void":
      c = s$(e, o);
      break;
    case "nan":
      c = u$(e, o);
      break;
    case "date":
      c = c$(e, o);
      break;
    case "object":
      c = l$(e, t, r, o, u);
      break;
    case "optional":
      c = d$(e, t, r, o, u);
      break;
    case "nullable":
      c = m$(e, t, r, o, u);
      break;
    case "array":
      c = g$(e, t, r, o, u);
      break;
    case "literal":
      c = h$(e, t, r, o);
      break;
    case "enum":
      c = v$(e, t, r, o);
      break;
    case "readonly": {
      let l = Bf(e, t, r, o), d = P(t);
      e.write(`const ${d} = Object.freeze(${l});`), c = d;
      break;
    }
    case "success":
      Bf(e, t, r, o), c = "true";
      break;
    case "default":
    case "prefault":
      c = y$(e, t, r, o);
      break;
    case "nonoptional":
      c = $$(e, t, r, o);
      break;
    case "tuple":
      c = b$(e, t, r, o);
      break;
    case "union":
      c = _$(e, t, r, o);
      break;
    case "intersection":
      c = I$(e, t, r, o);
      break;
    case "record":
      c = k$(e, t, r, o);
      break;
    case "map":
      c = S$(e, t, r, o);
      break;
    case "set":
      c = j$(e, t, r, o);
      break;
    case "file":
      c = O$(e, o);
      break;
    case "template_literal":
      c = D$(e, t, r, o);
      break;
    case "lazy":
      c = P$(e, t, r, o);
      break;
    case "pipe":
      c = T$(e, t, r, o);
      break;
    case "custom":
      c = N$(e, t, r, o);
      break;
    case "transform":
      c = E$(e, t, r, o);
      break;
    case "catch":
      c = A$(e, t, r, o);
      break;
    default:
      throw new C(`schema type ${a}`);
  }
  return c === null ? null : By(e, t, r, c);
}
s(H, "generateCheck");
function e$(e, t, r, o) {
  e.write(`if (typeof ${o} !== "string") return INVALID;`);
  let n = r._zod.def;
  return n.format === void 0 ? o : Kf(e, t, n, o);
}
s(e$, "generateStringCheck");
function t$(e, t, r) {
  e.write(`if (typeof ${r} !== "number" || !Number.isFinite(${r})) return INVALID;`);
  let o = t._zod.def;
  return o.check === "number_format" && o.format && Wf(e, { format: o.format }, r), r;
}
s(t$, "generateNumberCheck");
function n$(e, t) {
  return e.write(`if (typeof ${t} !== "boolean") return INVALID;`), t;
}
s(n$, "generateBooleanCheck");
function r$(e, t, r) {
  e.write(`if (typeof ${r} !== "bigint") return INVALID;`);
  let o = t._zod.def;
  if (o.format)
    switch (o.format) {
      case "int64":
        e.write(`if (${r} < -9223372036854775808n || ${r} > 9223372036854775807n) return INVALID;`);
        break;
      case "uint64":
        e.write(`if (${r} < 0n || ${r} > 18446744073709551615n) return INVALID;`);
        break;
    }
  return r;
}
s(r$, "generateBigIntCheck");
function i$(e, t) {
  return e.write(`if (typeof ${t} !== "symbol") return INVALID;`), t;
}
s(i$, "generateSymbolCheck");
function o$(e, t) {
  return e.write(`if (${t} !== undefined) return INVALID;`), t;
}
s(o$, "generateUndefinedCheck");
function a$(e, t) {
  return e.write(`if (${t} !== null) return INVALID;`), t;
}
s(a$, "generateNullCheck");
function s$(e, t) {
  return e.write(`if (${t} !== undefined) return INVALID;`), t;
}
s(s$, "generateVoidCheck");
function u$(e, t) {
  return e.write(`if (typeof ${t} !== "number" || !Number.isNaN(${t})) return INVALID;`), t;
}
s(u$, "generateNaNCheck");
function c$(e, t) {
  return e.write(`if (!(${t} instanceof Date) || Number.isNaN(${t}.getTime())) return INVALID;`), t;
}
s(c$, "generateDateCheck");
function l$(e, t, r, o, n = !0) {
  let i = r._zod.def;
  e.write(`if (typeof ${o} !== "object" || ${o} === null || Array.isArray(${o})) return INVALID;`);
  let a = i.shape, u = Object.keys(a), c = Object.getOwnPropertySymbols(a), l = c.length ? [...u, ...c] : u, d = /* @__PURE__ */ s((j) => typeof j == "symbol" ? D(t, j) : fe(j), "keyExpr"), f = /* @__PURE__ */ s((j) => typeof j == "symbol" ? `[${d(j)}]` : fe(j), "propKey"), p = a;
  if (u.includes("__proto__"))
    throw new C('object shape key "__proto__"');
  let h = /* @__PURE__ */ new Map();
  for (let j of l) {
    let O = p[j], U = d(j), M = P(t);
    if (e.write(`const ${M} = ${o}[${U}];`), O._zod.optin !== void 0) {
      let I = P(t);
      e.write(`let ${I} = (() => {`), e.indented((T) => {
        let q = le(T, t, O, M);
        T.write(`return ${q};`);
      }), e.write("})();"), O._zod.optout === "optional" ? (e.write(`if (${I} === INVALID) {`), e.indented((T) => {
        T.write(`if (${U} in ${o}) return INVALID;`), T.write(`${I} = undefined;`);
      }), e.write("}")) : e.write(`if (${I} === INVALID) return INVALID;`), h.set(j, I);
    } else {
      p$(O) && e.write(`if (!(${U} in ${o})) return INVALID;`);
      let I = le(e, t, O, M, n);
      I !== null && h.set(j, I);
    }
  }
  let v = i.catchall, x = "none";
  if (v) {
    let j = v._zod.def.type;
    if (j === "never") {
      let O = u.map((U) => `k !== ${fe(U)}`).join(" && ") || "true";
      e.write(`for (const k in ${o}) {`), e.indented((U) => {
        U.write(`if (${O}) return INVALID;`);
      }), e.write("}");
    } else (j === "unknown" || j === "any") && !v._zod.def.checks?.length ? x = "passthrough" : x = "schema";
  }
  let k = P(t), R = l.some((j) => mt(p[j]) || Xu(p[j]));
  if (!n) {
    if (x === "schema") {
      let j = u.length > 0 ? D(t, new Set(u)) : null;
      e.write(`for (const k in ${o}) {`), e.indented((O) => {
        O.write('if (k === "__proto__") continue;'), j && O.write(`if (${j}.has(k)) continue;`);
        let U = P(t);
        O.write(`const ${U} = ${o}[k];`), le(O, t, v, U, !1);
      }), e.write("}");
    }
    return null;
  }
  if (R) {
    e.write(`const ${k} = {};`);
    for (let j of l) {
      let O = d(j), U = h.get(j);
      Xu(p[j]) ? e.write(`if (${O} in ${o}) ${k}[${O}] = ${U};`) : mt(p[j]) ? e.write(`if (${U} !== undefined || ${O} in ${o}) ${k}[${O}] = ${U};`) : e.write(`${k}[${O}] = ${U};`);
    }
  } else {
    let j = l.map((O) => `${f(O)}: ${h.get(O)}`).join(", ");
    e.write(`const ${k} = { ${j} };`);
  }
  if (x !== "none") {
    let j = u.length > 0 ? D(t, new Set(u)) : null;
    e.write(`for (const k in ${o}) {`), e.indented((O) => {
      if (O.write('if (k === "__proto__") continue;'), j && O.write(`if (${j}.has(k)) continue;`), x === "passthrough")
        O.write(`${k}[k] = ${o}[k];`);
      else {
        let U = P(t);
        O.write(`const ${U} = ${o}[k];`);
        let M = le(O, t, v, U);
        O.write(`${k}[k] = ${M};`);
      }
    }), e.write("}");
  }
  return k;
}
s(l$, "generateObjectCheck");
function d$(e, t, r, o, n = !0) {
  let i = r._zod.def;
  if (f$(r))
    return H(e, t, i.innerType, o, n);
  if (i.innerType._zod.optin === "defaulted") {
    let u = P(t), c = P(t);
    return e.write(`let ${u};`), e.write(`if (${o} === undefined) {`), e.indented((l) => {
      l.write(`const ${c} = (() => {`), l.indented((d) => {
        let f = H(d, t, i.innerType, o);
        d.write(`return ${f};`);
      }), l.write("})();"), l.write(`if (${c} !== INVALID) ${u} = ${c};`);
    }), e.write("} else {"), e.indented((l) => {
      let d = H(l, t, i.innerType, o);
      l.write(`${u} = ${d};`);
    }), e.write("}"), u;
  }
  let a = n ? P(t) : null;
  return a && e.write(`let ${a};`), e.write(`if (${o} !== undefined) {`), e.indented((u) => {
    let c = H(u, t, i.innerType, o, n);
    a && c !== null && u.write(`${a} = ${c};`);
  }), e.write("}"), a;
}
s(d$, "generateOptionalCheck");
function f$(e) {
  return e._zod.traits?.has("$ZodExactOptional") === !0;
}
s(f$, "isExactOptional");
function p$(e) {
  return e._zod.optin === void 0 && pt(e);
}
s(p$, "requiresPresenceCheck");
function pt(e) {
  if (e._zod.def.coerce)
    return !0;
  let t = e._zod.def;
  switch (t.type) {
    case "any":
    case "unknown":
    case "undefined":
    case "void":
    case "default":
    case "prefault":
    case "transform":
    case "custom":
    case "lazy":
      return !0;
    case "string":
    case "number":
    case "boolean":
    case "bigint":
    case "symbol":
    case "null":
    case "never":
    case "nan":
    case "date":
    case "object":
    case "array":
    case "tuple":
    case "record":
    case "map":
    case "set":
    case "file":
    case "template_literal":
      return !1;
    case "nonoptional":
      return t.innerType ? pt(t.innerType) : !1;
    case "literal":
      return !!t.values?.includes(void 0);
    case "enum":
      return !!e._zod.values?.has(void 0);
    case "optional":
    case "nullable":
    case "readonly":
    case "success":
      return t.innerType ? pt(t.innerType) : !0;
    case "catch":
      return !0;
    case "union":
      return t.options ? t.options.some(pt) : !0;
    case "intersection":
      return !t.left || !t.right ? !0 : pt(t.left) && pt(t.right);
    case "pipe":
      return t.in ? pt(t.in) : !0;
    default:
      return !0;
  }
}
s(pt, "fastPathAcceptsAbsence");
function Xu(e) {
  return e._zod.optin === "optional" && e._zod.optout === "optional";
}
s(Xu, "dropsWhenAbsent");
function mt(e) {
  let t = e._zod.def;
  switch (t.type) {
    case "string":
    case "number":
    case "boolean":
    case "bigint":
    case "symbol":
    case "null":
    case "nan":
    case "date":
    case "object":
    case "array":
    case "tuple":
    case "record":
    case "map":
    case "set":
    case "file":
    case "template_literal":
    case "never":
    case "success":
      return !1;
    case "literal":
      return !!t.values?.includes(void 0);
    case "enum":
      return !!e._zod.values?.has(void 0);
    case "optional":
      return !0;
    case "nullable":
    case "readonly":
    case "nonoptional":
      return t.innerType ? mt(t.innerType) : !0;
    case "union":
      return t.options ? t.options.some(mt) : !0;
    case "intersection":
      return !t.left || !t.right || mt(t.left) || mt(t.right);
    case "pipe":
      return t.out ? mt(t.out) : !0;
    default:
      return !0;
  }
}
s(mt, "mayOutputUndefined");
function m$(e, t, r, o, n = !0) {
  let i = r._zod.def, a = n ? P(t) : null;
  return a && e.write(`let ${a} = null;`), e.write(`if (${o} !== null) {`), e.indented((u) => {
    let c = H(u, t, i.innerType, o, n);
    a && c !== null && u.write(`${a} = ${c};`);
  }), e.write("}"), a;
}
s(m$, "generateNullableCheck");
function g$(e, t, r, o, n = !0) {
  let i = r._zod.def;
  e.write(`if (!Array.isArray(${o})) return INVALID;`);
  let a = n ? P(t) : null, u = P(t), c = P(t);
  return a && e.write(`const ${a} = new Array(${o}.length);`), e.write(`for (let ${u} = 0; ${u} < ${o}.length; ${u}++) {`), e.indented((l) => {
    l.write(`const ${c} = ${o}[${u}];`);
    let d = le(l, t, i.element, c, n);
    a && d !== null && l.write(`${a}[${u}] = ${d};`);
  }), e.write("}"), a;
}
s(g$, "generateArrayCheck");
function h$(e, t, r, o) {
  let i = r._zod.def.values;
  if (i.length !== 1) {
    let u = D(t, new Set(i));
    return e.write(`if (!${u}.has(${o})) return INVALID;`), o;
  }
  let a = i[0];
  if (typeof a == "number" && Number.isNaN(a)) {
    let u = D(t, new Set(i));
    return e.write(`if (!${u}.has(${o})) return INVALID;`), o;
  }
  if (typeof a == "string")
    e.write(`if (${o} !== ${fe(a)}) return INVALID;`);
  else if (typeof a == "number" || typeof a == "boolean")
    e.write(`if (${o} !== ${a}) return INVALID;`);
  else if (a === null)
    e.write(`if (${o} !== null) return INVALID;`);
  else if (a === void 0)
    e.write(`if (${o} !== undefined) return INVALID;`);
  else if (typeof a == "bigint")
    e.write(`if (${o} !== ${a}n) return INVALID;`);
  else
    throw new C(`literal type ${typeof a}`);
  return o;
}
s(h$, "generateLiteralCheck");
function v$(e, t, r, o) {
  let n = r._zod.values;
  if (!n)
    throw new C("enum schema without enumerated values");
  let i = D(t, n);
  return e.write(`if (!${i}.has(${o})) return INVALID;`), o;
}
s(v$, "generateEnumCheck");
function Bf(e, t, r, o) {
  let n = r._zod.def;
  return H(e, t, n.innerType, o);
}
s(Bf, "generateWrapperCheck");
function y$(e, t, r, o) {
  let n = r._zod.def, a = Object.getOwnPropertyDescriptor(r._zod.def, "defaultValue") ? () => r._zod.def.defaultValue : void 0;
  if (r._zod.def.type === "prefault") {
    if (!a)
      return H(e, t, n.innerType, o);
    let c = D(t, a), l = P(t);
    return e.write(`let ${l} = ${o};`), e.write(`if (${o} === undefined) ${l} = ${c}();`), H(e, t, n.innerType, l);
  }
  let u = P(t);
  if (a) {
    let c = D(t, a), l = D(t, Me);
    e.write(`let ${u};`), e.write(`if (${o} === undefined) {`), e.indented((d) => {
      d.write(`${u} = ${l}(${c}());`);
    }), e.write("} else {"), e.indented((d) => {
      let f = H(d, t, n.innerType, o);
      d.write(`${u} = ${f} === undefined ? ${l}(${c}()) : ${f};`);
    }), e.write("}");
  } else
    e.write(`let ${u};`), e.write(`if (${o} !== undefined) {`), e.indented((c) => {
      let l = H(c, t, n.innerType, o);
      c.write(`${u} = ${l};`);
    }), e.write("}");
  return u;
}
s(y$, "generateDefaultCheck");
function $$(e, t, r, o) {
  let n = r._zod.def, i = H(e, t, n.innerType, o), a = P(t);
  return e.write(`const ${a} = ${i};`), e.write(`if (${a} === undefined) return INVALID;`), a;
}
s($$, "generateNonOptionalCheck");
function b$(e, t, r, o) {
  let n = r._zod.def, i = n.items, a = n.rest;
  e.write(`if (!Array.isArray(${o})) return INVALID;`);
  let u = Jf(i, "optin"), c = Jf(i, "optout");
  a ? e.write(`if (${o}.length < ${u}) return INVALID;`) : e.write(`if (${o}.length < ${u} || ${o}.length > ${i.length}) return INVALID;`);
  let l = P(t);
  e.write(`const ${l} = [];`);
  for (let d = 0; d < i.length; d++) {
    let f = i[d];
    if (d >= c)
      e.write(`if (${l}.length === ${d}) {`), e.indented((p) => {
        p.write(`if (${d} < ${o}.length) {`), p.indented((h) => {
          let v = P(t);
          h.write(`const ${v} = ${o}[${d}];`);
          let x = le(h, t, f, v);
          h.write(`${l}[${d}] = ${x};`);
        }), p.write("} else {"), p.indented((h) => {
          if (Xu(f)) {
            h.write(`${l}.length = ${d};`);
            return;
          }
          let v = P(t), x = P(t);
          h.write(`const ${v} = undefined;`), h.write(`const ${x} = (() => {`), h.indented((k) => {
            let R = le(k, t, f, v);
            k.write(`return ${R};`);
          }), h.write("})();"), h.write(`if (${x} === INVALID || ${x} === undefined) ${l}.length = ${d};`), h.write(`else ${l}[${d}] = ${x};`);
        }), p.write("}");
      }), e.write("}");
    else {
      let p = P(t);
      e.write(`const ${p} = ${o}[${d}];`);
      let h = le(e, t, f, p);
      e.write(`${l}[${d}] = ${h};`);
    }
  }
  if (a) {
    let d = P(t), f = P(t);
    e.write(`for (let ${d} = ${i.length}; ${d} < ${o}.length; ${d}++) {`), e.indented((p) => {
      p.write(`const ${f} = ${o}[${d}];`);
      let h = le(p, t, a, f);
      p.write(`${l}[${d}] = ${h};`);
    }), e.write("}");
  }
  return l;
}
s(b$, "generateTupleCheck");
function Jf(e, t) {
  for (let r = e.length - 1; r >= 0; r--)
    if (!(t === "optin" ? e[r]._zod.optin !== void 0 : e[r]._zod.optout === "optional"))
      return r + 1;
  return 0;
}
s(Jf, "getTupleOptStart");
function _$(e, t, r, o) {
  let n = r._zod.def, i = n.options;
  if (n.discriminator)
    return x$(e, t, n, o);
  if (n.inclusive === !1)
    throw new C("exclusive unions (z.xor)");
  if (i.length === 0)
    return e.write("return INVALID;"), o;
  if (i.length === 1)
    return H(e, t, i[0], o);
  if (i.every((c) => c._zod.def.type === "literal" && !c._zod.def.checks?.length)) {
    let c = new Set(i.flatMap((d) => d._zod.def.values)), l = D(t, c);
    return e.write(`if (!${l}.has(${o})) return INVALID;`), o;
  }
  let u = P(t);
  e.write(`let ${u};`);
  for (let c = 0; c < i.length; c++) {
    let l = i[c];
    c === 0 ? e.write(`${u} = (() => {`) : e.write(`if (${u} === INVALID) ${u} = (() => {`), e.indented((d) => {
      let f = H(d, t, l, o);
      d.write(`return ${f};`);
    }), e.write("})();");
  }
  return e.write(`if (${u} === INVALID) return INVALID;`), u;
}
s(_$, "generateUnionCheck");
function x$(e, t, r, o) {
  if (r.unionFallback)
    throw new C("discriminated union with unionFallback");
  if (r.options.length === 0)
    return e.write("return INVALID;"), o;
  let n = P(t), i = P(t);
  e.write(`const ${n} = ${o}?.[${fe(r.discriminator)}];`), e.write(`let ${i};`);
  let a = !0, u = /* @__PURE__ */ new Set();
  for (let c of r.options) {
    let l = c._zod.propValues?.[r.discriminator];
    if (!l || l.size === 0)
      throw new C("discriminated union option without static discriminator values");
    for (let p of l) {
      if (u.has(p))
        throw new C(`duplicate discriminator value ${String(p)}`);
      u.add(p);
    }
    let d = Array.from(l, (p) => w$(t, n, p)), f = a ? "if" : "else if";
    e.write(`${f} (${d.join(" || ")}) {`), e.indented((p) => {
      let h = H(p, t, c, o);
      p.write(`${i} = ${h};`);
    }), e.write("}"), a = !1;
  }
  return e.write("else { return INVALID; }"), i;
}
s(x$, "generateDiscriminatedUnionCheck");
function w$(e, t, r) {
  if (typeof r == "string")
    return `${t} === ${fe(r)}`;
  if (typeof r == "number")
    return Number.isNaN(r) ? `Number.isNaN(${t})` : `${t} === ${r}`;
  if (typeof r == "boolean")
    return `${t} === ${r}`;
  if (r === null)
    return `${t} === null`;
  if (r === void 0)
    return `${t} === undefined`;
  if (typeof r == "bigint")
    return `${t} === ${r}n`;
  if (typeof r == "symbol") {
    let o = D(e, r);
    return `${t} === ${o}`;
  }
  throw new C(`literal discriminator value ${String(r)}`);
}
s(w$, "literalEquality");
function I$(e, t, r, o) {
  let n = r._zod.def, i = le(e, t, n.left, o), a = le(e, t, n.right, o), u = D(t, Dt), c = P(t);
  return e.write(`const ${c} = ${u}(${i}, ${a});`), e.write(`if (!${c}.valid) return INVALID;`), `${c}.data`;
}
s(I$, "generateIntersectionCheck");
function k$(e, t, r, o) {
  let n = r._zod.def, i = D(t, Ne);
  e.write(`if (!${i}(${o})) return INVALID;`);
  let a = P(t), u = P(t), c = P(t);
  e.write(`const ${a} = {};`);
  let l = n, d = l.partial ? void 0 : n.keyType._zod.values;
  if (d) {
    let v = [];
    for (let k of d) {
      if (!(typeof k == "string" || typeof k == "number" || typeof k == "symbol"))
        throw new C(`record key value ${String(k)}`);
      let R = typeof k == "number" ? k.toString() : k;
      if (R === "__proto__")
        throw new C('record key "__proto__"');
      v.push(R);
      let j = D(t, k), O = H(e, t, n.keyType, j), U = P(t);
      e.write(`const ${U} = ${o}[${z$(t, R)}];`);
      let M = le(e, t, n.valueType, U);
      e.write(`${a}[${O}] = ${M};`);
    }
    let x = D(t, new Set(v));
    return e.write(`for (const ${u} in ${o}) {`), e.indented((k) => {
      k.write(`if (${x}.has(${u})) continue;`), l.mode === "loose" ? k.write(`if (${u} !== "__proto__") ${a}[${u}] = ${o}[${u}];`) : k.write("return INVALID;");
    }), e.write("}"), a;
  }
  let f = n.keyType._zod.def;
  if (!(f.type === "string" && f.format === void 0 && !f.coerce && (f.checks?.length ?? 0) === 0)) {
    let v = n.mode === "loose", x = D(t, Lr(n.keyType)), k = D(t, Ve), R = D(t, Object.prototype.propertyIsEnumerable), j = P(t);
    return e.write(`for (const ${u} of Reflect.ownKeys(${o})) {`), e.indented((O) => {
      O.write(`if (${u} === "__proto__") continue;`), O.write(`if (!${R}.call(${o}, ${u})) continue;`), O.write(`let ${j} = ${x}(${u});`), O.write(`if (${j} === INVALID && typeof ${u} === "string" && ${k}.test(${u})) ${j} = ${x}(Number(${u}));`), v ? O.write(`if (${j} === INVALID) { ${a}[${u}] = ${o}[${u}]; continue; }`) : O.write(`if (${j} === INVALID) return INVALID;`), O.write(`if (${j} === "__proto__") continue;`);
      let U = P(t);
      O.write(`const ${U} = ${o}[${u}];`);
      let M = le(O, t, n.valueType, U);
      O.write(`${a}[${j}] = ${M};`);
    }), e.write("}"), a;
  }
  let h = D(t, Object.prototype.propertyIsEnumerable);
  return e.write(`for (const ${u} of Reflect.ownKeys(${o})) {`), e.indented((v) => {
    v.write(`if (${u} === "__proto__") continue;`), v.write(`if (!${h}.call(${o}, ${u})) continue;`), v.write(`if (typeof ${u} !== "string") return INVALID;`), v.write(`const ${c} = ${o}[${u}];`);
    let x = le(v, t, n.valueType, c);
    v.write(`${a}[${u}] = ${x};`);
  }), e.write("}"), a;
}
s(k$, "generateRecordCheck");
function z$(e, t) {
  return typeof t == "string" ? fe(t) : D(e, t);
}
s(z$, "literalPropertyKey");
function S$(e, t, r, o) {
  let n = r._zod.def;
  e.write(`if (!(${o} instanceof Map)) return INVALID;`);
  let i = P(t), a = P(t), u = P(t);
  return e.write(`const ${i} = new Map();`), e.write(`for (const [${a}, ${u}] of ${o}) {`), e.indented((c) => {
    let l = H(c, t, n.keyType, a), d = H(c, t, n.valueType, u);
    c.write(`${i}.set(${l}, ${d});`);
  }), e.write("}"), i;
}
s(S$, "generateMapCheck");
function j$(e, t, r, o) {
  let n = r._zod.def;
  e.write(`if (!(${o} instanceof Set)) return INVALID;`);
  let i = P(t), a = P(t);
  return e.write(`const ${i} = new Set();`), e.write(`for (const ${a} of ${o}) {`), e.indented((u) => {
    let c = H(u, t, n.valueType, a);
    u.write(`${i}.add(${c});`);
  }), e.write("}"), i;
}
s(j$, "generateSetCheck");
function O$(e, t) {
  return e.write(`if (!(${t} instanceof File)) return INVALID;`), t;
}
s(O$, "generateFileCheck");
function D$(e, t, r, o) {
  e.write(`if (typeof ${o} !== "string") return INVALID;`);
  let n = r._zod.pattern;
  if (n) {
    let i = D(t, n);
    e.write(`${i}.lastIndex = 0;`), e.write(`if (!${i}.test(${o})) return INVALID;`);
  }
  return o;
}
s(D$, "generateTemplateLiteralCheck");
function P$(e, t, r, o) {
  let n = r._zod.def, i = D(t, n.getter), a = D(t, { parser: null });
  e.write(`if (!${a}.parser) {`), e.indented((c) => {
    c.write(`const inner = ${i}();`), c.write(`${a}.parser = function(input) {`), c.indented((l) => {
      l.write("const result = inner._zod.run({ value: input, issues: [] }, {});"), l.write("return result.issues.length === 0 ? result.value : INVALID;");
    }), c.write("};");
  }), e.write("}");
  let u = P(t);
  return e.write(`const ${u} = ${a}.parser(${o});`), e.write(`if (${u} === INVALID) return INVALID;`), u;
}
s(P$, "generateLazyCheck");
function T$(e, t, r, o) {
  let n = r._zod.def, i = H(e, t, n.in, o);
  if (n.transform) {
    if (gt(n.transform))
      throw new De("z.compile: async transforms in pipes are not supported");
    let a = n.transform, c = D(t, /* @__PURE__ */ s((d) => {
      let f = { value: d, issues: [], addIssue: Qu }, p = a(d, f);
      return p instanceof Promise ? be : f.issues.length === 0 ? p : be;
    }, "helperFn")), l = P(t);
    return e.write(`const ${l} = ${c}(${i});`), e.write(`if (${l} === INVALID) return INVALID;`), H(e, t, n.out, l);
  } else
    return H(e, t, n.out, i);
}
s(T$, "generatePipeCheck");
function gt(e) {
  return typeof e == "function" && (e.constructor.name === "AsyncFunction" || e[Symbol.toStringTag] === "AsyncFunction");
}
s(gt, "isAsyncFunction");
function N$(e, t, r, o) {
  let n = r._zod.def;
  if (n.fn) {
    if (gt(n.fn))
      throw new De("z.compile: async custom predicates are not supported");
    let i = D(t, n.fn), a = D(t, Gu), u = P(t);
    e.write(`const ${u} = ${i}(${o});`), e.write(`if (${u} instanceof Promise) ${a}();`), e.write(`if (!${u}) return INVALID;`);
  } else
    throw new C("custom schema without a predicate function");
  return o;
}
s(N$, "generateCustomCheck");
function U$(e, t, r) {
  let o = e._zod.run({ value: r, issues: [] }, {});
  if (o && typeof o.then == "function")
    return be;
  let n = o;
  return n.issues.length === 0 ? n.value : t();
}
s(U$, "runtimeCatch");
function A$(e, t, r, o) {
  let n = r._zod.def;
  if (!n.catchValue[cr])
    throw new C("catch with a callback (only a constant catch value compiles)", !1);
  let i = P(t);
  e.write(`let ${i} = (() => {`), e.indented((l) => {
    let d = le(l, t, n.innerType, o);
    l.write(`return ${d};`);
  }), e.write("})();");
  let a = D(t, n.innerType), u = D(t, n.catchValue), c = D(t, U$);
  return e.write(`if (${i} === INVALID) {`), e.indented((l) => {
    l.write(`${i} = ${c}(${a}, ${u}, ${o});`), l.write(`if (${i} === INVALID) return INVALID;`);
  }), e.write("}"), i;
}
s(A$, "generateCatchCheck");
function E$(e, t, r, o) {
  let n = r._zod.def;
  if (n.transform) {
    if (gt(n.transform))
      throw new De("z.compile: async transforms are not supported");
    let i = n.transform, u = D(t, /* @__PURE__ */ s((l) => {
      let d = { value: l, issues: [], addIssue: Qu }, f = i(l, d);
      return f instanceof Promise ? be : d.issues.length === 0 ? f : be;
    }, "helperFn")), c = P(t);
    return e.write(`const ${c} = ${u}(${o});`), e.write(`if (${c} === INVALID) return INVALID;`), c;
  }
  return o;
}
s(E$, "generateTransformCheck");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/api.js
// @__NO_SIDE_EFFECTS__
function Yu(e, t) {
  return new e({
    type: "string",
    ..._(t)
  });
}
s(Yu, "_string");
// @__NO_SIDE_EFFECTS__
function ec(e, t) {
  return new e({
    type: "string",
    coerce: !0,
    ..._(t)
  });
}
s(ec, "_coercedString");
// @__NO_SIDE_EFFECTS__
function tc(e, t) {
  return new e({
    type: "string",
    format: "email",
    check: "string_format",
    abort: !1,
    ..._(t)
  });
}
s(tc, "_email");
// @__NO_SIDE_EFFECTS__
function nc(e, t) {
  return new e({
    type: "string",
    format: "guid",
    check: "string_format",
    abort: !1,
    ..._(t)
  });
}
s(nc, "_guid");
// @__NO_SIDE_EFFECTS__
function rc(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    ..._(t)
  });
}
s(rc, "_uuid");
// @__NO_SIDE_EFFECTS__
function ic(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v4",
    ..._(t)
  });
}
s(ic, "_uuidv4");
// @__NO_SIDE_EFFECTS__
function oc(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v6",
    ..._(t)
  });
}
s(oc, "_uuidv6");
// @__NO_SIDE_EFFECTS__
function ac(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v7",
    ..._(t)
  });
}
s(ac, "_uuidv7");
// @__NO_SIDE_EFFECTS__
function Vr(e, t) {
  return new e({
    type: "string",
    format: "url",
    check: "string_format",
    abort: !1,
    ..._(t)
  });
}
s(Vr, "_url");
// @__NO_SIDE_EFFECTS__
function sc(e, t) {
  return new e({
    type: "string",
    format: "emoji",
    check: "string_format",
    abort: !1,
    ..._(t)
  });
}
s(sc, "_emoji");
// @__NO_SIDE_EFFECTS__
function uc(e, t) {
  return new e({
    type: "string",
    format: "nanoid",
    check: "string_format",
    abort: !1,
    ..._(t)
  });
}
s(uc, "_nanoid");
// @__NO_SIDE_EFFECTS__
function cc(e, t) {
  return new e({
    type: "string",
    format: "cuid",
    check: "string_format",
    abort: !1,
    ..._(t)
  });
}
s(cc, "_cuid");
// @__NO_SIDE_EFFECTS__
function lc(e, t) {
  return new e({
    type: "string",
    format: "cuid2",
    check: "string_format",
    abort: !1,
    ..._(t)
  });
}
s(lc, "_cuid2");
// @__NO_SIDE_EFFECTS__
function dc(e, t) {
  return new e({
    type: "string",
    format: "ulid",
    check: "string_format",
    abort: !1,
    ..._(t)
  });
}
s(dc, "_ulid");
// @__NO_SIDE_EFFECTS__
function fc(e, t) {
  return new e({
    type: "string",
    format: "xid",
    check: "string_format",
    abort: !1,
    ..._(t)
  });
}
s(fc, "_xid");
// @__NO_SIDE_EFFECTS__
function pc(e, t) {
  return new e({
    type: "string",
    format: "ksuid",
    check: "string_format",
    abort: !1,
    ..._(t)
  });
}
s(pc, "_ksuid");
// @__NO_SIDE_EFFECTS__
function mc(e, t) {
  return new e({
    type: "string",
    format: "ipv4",
    check: "string_format",
    abort: !1,
    ..._(t)
  });
}
s(mc, "_ipv4");
// @__NO_SIDE_EFFECTS__
function gc(e, t) {
  return new e({
    type: "string",
    format: "ipv6",
    check: "string_format",
    abort: !1,
    ..._(t)
  });
}
s(gc, "_ipv6");
// @__NO_SIDE_EFFECTS__
function hc(e, t) {
  return new e({
    type: "string",
    format: "mac",
    check: "string_format",
    abort: !1,
    ..._(t)
  });
}
s(hc, "_mac");
// @__NO_SIDE_EFFECTS__
function vc(e, t) {
  return new e({
    type: "string",
    format: "cidrv4",
    check: "string_format",
    abort: !1,
    ..._(t)
  });
}
s(vc, "_cidrv4");
// @__NO_SIDE_EFFECTS__
function yc(e, t) {
  return new e({
    type: "string",
    format: "cidrv6",
    check: "string_format",
    abort: !1,
    ..._(t)
  });
}
s(yc, "_cidrv6");
// @__NO_SIDE_EFFECTS__
function $c(e, t) {
  return new e({
    type: "string",
    format: "base64",
    check: "string_format",
    abort: !1,
    ..._(t)
  });
}
s($c, "_base64");
// @__NO_SIDE_EFFECTS__
function bc(e, t) {
  return new e({
    type: "string",
    format: "base64url",
    check: "string_format",
    abort: !1,
    ..._(t)
  });
}
s(bc, "_base64url");
// @__NO_SIDE_EFFECTS__
function _c(e, t) {
  return new e({
    type: "string",
    format: "e164",
    check: "string_format",
    abort: !1,
    ..._(t)
  });
}
s(_c, "_e164");
// @__NO_SIDE_EFFECTS__
function xc(e, t) {
  return new e({
    type: "string",
    format: "credit_card",
    check: "string_format",
    abort: !1,
    ..._(t)
  });
}
s(xc, "_creditCard");
// @__NO_SIDE_EFFECTS__
function wc(e, t) {
  return new e({
    type: "string",
    format: "jwt",
    check: "string_format",
    abort: !1,
    ..._(t)
  });
}
s(wc, "_jwt");
var Ic = {
  Any: null,
  Minute: -1,
  Second: 0,
  Millisecond: 3,
  Microsecond: 6
};
// @__NO_SIDE_EFFECTS__
function kc(e, t) {
  return new e({
    type: "string",
    format: "datetime",
    check: "string_format",
    offset: !1,
    local: !1,
    precision: null,
    ..._(t)
  });
}
s(kc, "_isoDateTime");
// @__NO_SIDE_EFFECTS__
function zc(e, t) {
  return new e({
    type: "string",
    format: "date",
    check: "string_format",
    ..._(t)
  });
}
s(zc, "_isoDate");
// @__NO_SIDE_EFFECTS__
function Sc(e, t) {
  return new e({
    type: "string",
    format: "time",
    check: "string_format",
    precision: null,
    ..._(t)
  });
}
s(Sc, "_isoTime");
// @__NO_SIDE_EFFECTS__
function jc(e, t) {
  return new e({
    type: "string",
    format: "duration",
    check: "string_format",
    ..._(t)
  });
}
s(jc, "_isoDuration");
// @__NO_SIDE_EFFECTS__
function Oc(e, t) {
  return new e({
    type: "number",
    checks: [],
    ..._(t)
  });
}
s(Oc, "_number");
// @__NO_SIDE_EFFECTS__
function Dc(e, t) {
  return new e({
    type: "number",
    coerce: !0,
    checks: [],
    ..._(t)
  });
}
s(Dc, "_coercedNumber");
// @__NO_SIDE_EFFECTS__
function Pc(e, t) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "safeint",
    ..._(t)
  });
}
s(Pc, "_int");
// @__NO_SIDE_EFFECTS__
function Tc(e, t) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "float32",
    ..._(t)
  });
}
s(Tc, "_float32");
// @__NO_SIDE_EFFECTS__
function Nc(e, t) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "float64",
    ..._(t)
  });
}
s(Nc, "_float64");
// @__NO_SIDE_EFFECTS__
function Uc(e, t) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "int32",
    ..._(t)
  });
}
s(Uc, "_int32");
// @__NO_SIDE_EFFECTS__
function Ac(e, t) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "uint32",
    ..._(t)
  });
}
s(Ac, "_uint32");
// @__NO_SIDE_EFFECTS__
function Ec(e, t) {
  return new e({
    type: "boolean",
    ..._(t)
  });
}
s(Ec, "_boolean");
// @__NO_SIDE_EFFECTS__
function Cc(e, t) {
  return new e({
    type: "boolean",
    coerce: !0,
    ..._(t)
  });
}
s(Cc, "_coercedBoolean");
// @__NO_SIDE_EFFECTS__
function Zc(e, t) {
  return new e({
    type: "bigint",
    ..._(t)
  });
}
s(Zc, "_bigint");
// @__NO_SIDE_EFFECTS__
function Fc(e, t) {
  return new e({
    type: "bigint",
    coerce: !0,
    ..._(t)
  });
}
s(Fc, "_coercedBigint");
// @__NO_SIDE_EFFECTS__
function Mc(e, t) {
  return new e({
    type: "bigint",
    check: "bigint_format",
    abort: !1,
    format: "int64",
    ..._(t)
  });
}
s(Mc, "_int64");
// @__NO_SIDE_EFFECTS__
function Rc(e, t) {
  return new e({
    type: "bigint",
    check: "bigint_format",
    abort: !1,
    format: "uint64",
    ..._(t)
  });
}
s(Rc, "_uint64");
// @__NO_SIDE_EFFECTS__
function Lc(e, t) {
  return new e({
    type: "symbol",
    ..._(t)
  });
}
s(Lc, "_symbol");
// @__NO_SIDE_EFFECTS__
function Vc(e, t) {
  return new e({
    type: "undefined",
    ..._(t)
  });
}
s(Vc, "_undefined");
// @__NO_SIDE_EFFECTS__
function Bc(e, t) {
  return new e({
    type: "null",
    ..._(t)
  });
}
s(Bc, "_null");
// @__NO_SIDE_EFFECTS__
function Jc(e) {
  return new e({
    type: "any"
  });
}
s(Jc, "_any");
// @__NO_SIDE_EFFECTS__
function qc(e) {
  return new e({
    type: "unknown"
  });
}
s(qc, "_unknown");
// @__NO_SIDE_EFFECTS__
function Wc(e, t) {
  return new e({
    type: "never",
    ..._(t)
  });
}
s(Wc, "_never");
// @__NO_SIDE_EFFECTS__
function Kc(e, t) {
  return new e({
    type: "void",
    ..._(t)
  });
}
s(Kc, "_void");
// @__NO_SIDE_EFFECTS__
function Gc(e, t) {
  return new e({
    type: "date",
    ..._(t)
  });
}
s(Gc, "_date");
// @__NO_SIDE_EFFECTS__
function Xc(e, t) {
  return new e({
    type: "date",
    coerce: !0,
    ..._(t)
  });
}
s(Xc, "_coercedDate");
// @__NO_SIDE_EFFECTS__
function Hc(e, t) {
  return new e({
    type: "nan",
    ..._(t)
  });
}
s(Hc, "_nan");
// @__NO_SIDE_EFFECTS__
function Br(e, t) {
  return new yr({
    check: "less_than",
    ..._(t),
    value: e,
    inclusive: !1
  });
}
s(Br, "_lt");
// @__NO_SIDE_EFFECTS__
function $n(e, t) {
  return new yr({
    check: "less_than",
    ..._(t),
    value: e,
    inclusive: !0
  });
}
s($n, "_lte");
// @__NO_SIDE_EFFECTS__
function Jr(e, t) {
  return new $r({
    check: "greater_than",
    ..._(t),
    value: e,
    inclusive: !1
  });
}
s(Jr, "_gt");
// @__NO_SIDE_EFFECTS__
function bn(e, t) {
  return new $r({
    check: "greater_than",
    ..._(t),
    value: e,
    inclusive: !0
  });
}
s(bn, "_gte");
// @__NO_SIDE_EFFECTS__
function Qc(e) {
  return /* @__PURE__ */ Jr(0, e);
}
s(Qc, "_positive");
// @__NO_SIDE_EFFECTS__
function Yc(e) {
  return /* @__PURE__ */ Br(0, e);
}
s(Yc, "_negative");
// @__NO_SIDE_EFFECTS__
function el(e) {
  return /* @__PURE__ */ $n(0, e);
}
s(el, "_nonpositive");
// @__NO_SIDE_EFFECTS__
function tl(e) {
  return /* @__PURE__ */ bn(0, e);
}
s(tl, "_nonnegative");
// @__NO_SIDE_EFFECTS__
function nl(e, t) {
  return new ha({
    check: "multiple_of",
    ..._(t),
    value: e
  });
}
s(nl, "_multipleOf");
// @__NO_SIDE_EFFECTS__
function rl(e, t) {
  return new $a({
    check: "max_size",
    ..._(t),
    maximum: e
  });
}
s(rl, "_maxSize");
// @__NO_SIDE_EFFECTS__
function il(e, t) {
  return new ba({
    check: "min_size",
    ..._(t),
    minimum: e
  });
}
s(il, "_minSize");
// @__NO_SIDE_EFFECTS__
function ol(e, t) {
  return new _a({
    check: "size_equals",
    ..._(t),
    size: e
  });
}
s(ol, "_size");
// @__NO_SIDE_EFFECTS__
function al(e, t) {
  return new xa({
    check: "max_length",
    ..._(t),
    maximum: e
  });
}
s(al, "_maxLength");
// @__NO_SIDE_EFFECTS__
function sl(e, t) {
  return new wa({
    check: "min_length",
    ..._(t),
    minimum: e
  });
}
s(sl, "_minLength");
// @__NO_SIDE_EFFECTS__
function ul(e, t) {
  return new Ia({
    check: "length_equals",
    ..._(t),
    length: e
  });
}
s(ul, "_length");
// @__NO_SIDE_EFFECTS__
function cl(e, t) {
  return new ka({
    check: "string_format",
    format: "regex",
    ..._(t),
    pattern: e
  });
}
s(cl, "_regex");
// @__NO_SIDE_EFFECTS__
function ll(e) {
  return new za({
    check: "string_format",
    format: "lowercase",
    ..._(e)
  });
}
s(ll, "_lowercase");
// @__NO_SIDE_EFFECTS__
function dl(e) {
  return new Sa({
    check: "string_format",
    format: "uppercase",
    ..._(e)
  });
}
s(dl, "_uppercase");
// @__NO_SIDE_EFFECTS__
function fl(e, t) {
  return new ja({
    check: "string_format",
    format: "includes",
    ..._(t),
    includes: e
  });
}
s(fl, "_includes");
// @__NO_SIDE_EFFECTS__
function pl(e, t) {
  return new Oa({
    check: "string_format",
    format: "starts_with",
    ..._(t),
    prefix: e
  });
}
s(pl, "_startsWith");
// @__NO_SIDE_EFFECTS__
function ml(e, t) {
  return new Da({
    check: "string_format",
    format: "ends_with",
    ..._(t),
    suffix: e
  });
}
s(ml, "_endsWith");
// @__NO_SIDE_EFFECTS__
function gl(e, t, r) {
  return new br({
    check: "property",
    property: e,
    schema: t,
    ..._(r)
  });
}
s(gl, "_property");
// @__NO_SIDE_EFFECTS__
function hl(e) {
  return Object.entries(e).map(([t, r]) => new br({ check: "property", property: t, schema: r }));
}
s(hl, "_properties");
// @__NO_SIDE_EFFECTS__
function vl(e, t) {
  return new Pa({
    check: "mime_type",
    mime: e,
    ..._(t)
  });
}
s(vl, "_mime");
// @__NO_SIDE_EFFECTS__
function Ke(e) {
  return new Ta({
    check: "overwrite",
    tx: e
  });
}
s(Ke, "_overwrite");
// @__NO_SIDE_EFFECTS__
function yl(e) {
  return /* @__PURE__ */ Ke((t) => t.normalize(e));
}
s(yl, "_normalize");
// @__NO_SIDE_EFFECTS__
function $l() {
  return /* @__PURE__ */ Ke((e) => e.trim());
}
s($l, "_trim");
// @__NO_SIDE_EFFECTS__
function bl() {
  return /* @__PURE__ */ Ke((e) => e.toLowerCase());
}
s(bl, "_toLowerCase");
// @__NO_SIDE_EFFECTS__
function _l() {
  return /* @__PURE__ */ Ke((e) => e.toUpperCase());
}
s(_l, "_toUpperCase");
// @__NO_SIDE_EFFECTS__
function C$() {
  return /* @__PURE__ */ Ke((e) => to(e));
}
s(C$, "_slugify");
// @__NO_SIDE_EFFECTS__
function Z$(e, t, r) {
  return new e({
    type: "array",
    element: t,
    // get element() {
    //   return element;
    // },
    ..._(r)
  });
}
s(Z$, "_array");
// @__NO_SIDE_EFFECTS__
function F$(e, t, r) {
  return new e({
    type: "union",
    options: t,
    ..._(r)
  });
}
s(F$, "_union");
function M$(e, t, r) {
  return new e({
    type: "union",
    options: t,
    inclusive: !1,
    ..._(r)
  });
}
s(M$, "_xor");
// @__NO_SIDE_EFFECTS__
function R$(e, t, r, o) {
  return new e({
    type: "union",
    options: r,
    discriminator: t,
    ..._(o)
  });
}
s(R$, "_discriminatedUnion");
// @__NO_SIDE_EFFECTS__
function L$(e, t, r) {
  return new e({
    type: "intersection",
    left: t,
    right: r
  });
}
s(L$, "_intersection");
// @__NO_SIDE_EFFECTS__
function V$(e, t, r, o) {
  let n = r instanceof S, i = n ? o : r, a = n ? r : null;
  return new e({
    type: "tuple",
    items: t,
    rest: a,
    ..._(i)
  });
}
s(V$, "_tuple");
// @__NO_SIDE_EFFECTS__
function B$(e, t, r, o) {
  return new e({
    type: "record",
    keyType: t,
    valueType: r,
    ..._(o)
  });
}
s(B$, "_record");
// @__NO_SIDE_EFFECTS__
function J$(e, t, r, o) {
  return new e({
    type: "map",
    keyType: t,
    valueType: r,
    ..._(o)
  });
}
s(J$, "_map");
// @__NO_SIDE_EFFECTS__
function q$(e, t, r) {
  return new e({
    type: "set",
    valueType: t,
    ..._(r)
  });
}
s(q$, "_set");
// @__NO_SIDE_EFFECTS__
function W$(e, t, r) {
  let o = Array.isArray(t) ? Object.fromEntries(t.map((n) => [n, n])) : t;
  return new e({
    type: "enum",
    entries: o,
    ..._(r)
  });
}
s(W$, "_enum");
// @__NO_SIDE_EFFECTS__
function K$(e, t, r) {
  return new e({
    type: "enum",
    entries: t,
    ..._(r)
  });
}
s(K$, "_nativeEnum");
// @__NO_SIDE_EFFECTS__
function G$(e, t, r) {
  return new e({
    type: "literal",
    values: Array.isArray(t) ? t : [t],
    ..._(r)
  });
}
s(G$, "_literal");
// @__NO_SIDE_EFFECTS__
function xl(e, t) {
  return new e({
    type: "file",
    ..._(t)
  });
}
s(xl, "_file");
// @__NO_SIDE_EFFECTS__
function X$(e, t) {
  return new e({
    type: "transform",
    transform: t
  });
}
s(X$, "_transform");
// @__NO_SIDE_EFFECTS__
function H$(e, t) {
  return new e({
    type: "optional",
    innerType: t
  });
}
s(H$, "_optional");
// @__NO_SIDE_EFFECTS__
function Q$(e, t) {
  return new e({
    type: "nullable",
    innerType: t
  });
}
s(Q$, "_nullable");
// @__NO_SIDE_EFFECTS__
function Y$(e, t, r) {
  return new e({
    type: "default",
    innerType: t,
    get defaultValue() {
      return typeof r == "function" ? r() : Me(r);
    }
  });
}
s(Y$, "_default");
// @__NO_SIDE_EFFECTS__
function eb(e, t, r) {
  return new e({
    type: "nonoptional",
    innerType: t,
    ..._(r)
  });
}
s(eb, "_nonoptional");
// @__NO_SIDE_EFFECTS__
function tb(e, t) {
  return new e({
    type: "success",
    innerType: t
  });
}
s(tb, "_success");
// @__NO_SIDE_EFFECTS__
function nb(e, t, r) {
  return new e({
    type: "catch",
    innerType: t,
    catchValue: typeof r == "function" ? r : yo(r)
  });
}
s(nb, "_catch");
// @__NO_SIDE_EFFECTS__
function rb(e, t, r) {
  return new e({
    type: "pipe",
    in: t,
    out: r
  });
}
s(rb, "_pipe");
// @__NO_SIDE_EFFECTS__
function ib(e, t) {
  return new e({
    type: "readonly",
    innerType: t
  });
}
s(ib, "_readonly");
// @__NO_SIDE_EFFECTS__
function ob(e, t, r) {
  return new e({
    type: "template_literal",
    parts: t,
    ..._(r)
  });
}
s(ob, "_templateLiteral");
// @__NO_SIDE_EFFECTS__
function ab(e, t) {
  return new e({
    type: "lazy",
    getter: t
  });
}
s(ab, "_lazy");
// @__NO_SIDE_EFFECTS__
function sb(e, t) {
  return new e({
    type: "promise",
    innerType: t
  });
}
s(sb, "_promise");
// @__NO_SIDE_EFFECTS__
function wl(e, t, r) {
  let o = _(r);
  return o.abort ?? (o.abort = !0), new e({
    type: "custom",
    check: "custom",
    fn: t,
    ...o
  });
}
s(wl, "_custom");
// @__NO_SIDE_EFFECTS__
function Il(e, t, r) {
  return new e({
    type: "custom",
    check: "custom",
    fn: t,
    ..._(r)
  });
}
s(Il, "_refine");
// @__NO_SIDE_EFFECTS__
function kl(e, t) {
  let r = /* @__PURE__ */ Gf((o) => (o.addIssue = (n) => {
    if (typeof n == "string")
      o.issues.push(St(n, o.value, r._zod.def));
    else {
      let i = n;
      i.fatal && (i.continue = !1), i.code ?? (i.code = "custom"), "input" in i || (i.input = o.value), i.inst ?? (i.inst = r), i.continue ?? (i.continue = !r._zod.def.abort), o.issues.push(St(i));
    }
  }, e(o.value, o)), t);
  return r;
}
s(kl, "_superRefine");
// @__NO_SIDE_EFFECTS__
function Gf(e, t) {
  let r = new W({
    check: "custom",
    ..._(t)
  });
  return r._zod.check = e, r;
}
s(Gf, "_check");
// @__NO_SIDE_EFFECTS__
function zl(e) {
  let t = new W({ check: "describe" });
  return t._zod.onattach = [
    (r) => {
      let o = Oe.get(r) ?? {};
      Oe.add(r, { ...o, description: e });
    }
  ], t._zod.check = () => {
  }, t;
}
s(zl, "describe");
// @__NO_SIDE_EFFECTS__
function Sl(e) {
  let t = new W({ check: "meta" });
  return t._zod.onattach = [
    (r) => {
      let o = Oe.get(r) ?? {};
      Oe.add(r, { ...o, ...e });
    }
  ], t._zod.check = () => {
  }, t;
}
s(Sl, "meta");
// @__NO_SIDE_EFFECTS__
function jl(e, t) {
  let r = _(t), o = r.truthy ?? ["true", "1", "yes", "on", "y", "enabled"], n = r.falsy ?? ["false", "0", "no", "off", "n", "disabled"];
  r.case !== "sensitive" && (o = o.map((h) => typeof h == "string" ? h.toLowerCase() : h), n = n.map((h) => typeof h == "string" ? h.toLowerCase() : h));
  let i = new Set(o), a = new Set(n), u = e.Codec ?? je, c = e.Boolean ?? pn, l = e.String ?? Pt, d = new l({ type: "string", error: r.error }), f = new c({ type: "boolean", error: r.error }), p = new u({
    type: "pipe",
    in: d,
    out: f,
    transform: /* @__PURE__ */ s(((h, v) => {
      let x = h;
      return r.case !== "sensitive" && (x = x.toLowerCase()), i.has(x) ? !0 : a.has(x) ? !1 : (v.issues.push({
        code: "invalid_value",
        expected: "stringbool",
        values: [...i, ...a],
        input: v.value,
        inst: p,
        continue: !1
      }), {});
    }), "transform"),
    reverseTransform: /* @__PURE__ */ s(((h, v) => h === !0 ? o[0] || "true" : n[0] || "false"), "reverseTransform"),
    error: r.error
  });
  return p._zod.bag.truthy = o, p._zod.bag.falsy = n, p._zod.bag.case = r.case ?? "insensitive", p;
}
s(jl, "_stringbool");
// @__NO_SIDE_EFFECTS__
function Et(e, t, r, o = {}) {
  let n = _(o), i = {
    check: "string_format",
    type: "string",
    format: t,
    fn: typeof r == "function" ? r : (u) => r.test(u),
    ...n
  };
  return r instanceof RegExp && (i.pattern = r), new e(i);
}
s(Et, "_stringFormat");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/to-json-schema.js
function _n(e, ...t) {
  for (let r of t)
    for (let o of Reflect.ownKeys(r))
      Object.prototype.propertyIsEnumerable.call(r, o) && te(e, o, r[o]);
  return e;
}
s(_n, "assignProps");
function Ge(e) {
  let t = e?.target ?? "draft-2020-12";
  return t === "draft-4" && (t = "draft-04"), t === "draft-7" && (t = "draft-07"), {
    processors: e.processors ?? {},
    metadataRegistry: e?.metadata ?? Oe,
    target: t,
    unrepresentable: e?.unrepresentable ?? "throw",
    override: e?.override ?? (() => {
    }),
    io: e?.io ?? "output",
    counter: 0,
    seen: /* @__PURE__ */ new Map(),
    sharedDefsExtractedFor: void 0,
    sharedEmitDoneFor: void 0,
    cycles: e?.cycles ?? "ref",
    reused: e?.reused ?? "inline",
    intersections: [],
    deferred: [],
    external: e?.external ?? void 0
  };
}
s(Ge, "initializeContext");
function re(e, t, r, o, n) {
  let i = typeof t.unrepresentable == "function" ? t.unrepresentable({ zodSchema: e, path: o.path, message: n }) : t.unrepresentable;
  if (i === "any")
    return !1;
  if (i === void 0 || i === "throw")
    throw new Error(n);
  return Object.assign(r, i), !0;
}
s(re, "handleUnrepresentable");
function L(e, t, r = { path: [], schemaPath: [] }) {
  var o;
  let n = e._zod.def, i = t.seen.get(e);
  if (i)
    return i.count++, r.schemaPath.includes(e) && (i.cycle = r.path), i.schema;
  let a = { schema: {}, count: 1, cycle: void 0, path: r.path };
  t.seen.set(e, a), t.sharedDefsExtractedFor = void 0, t.sharedEmitDoneFor = void 0;
  let u = e._zod.toJSONSchema?.();
  if (u)
    a.schema = u;
  else {
    let d = {
      ...r,
      schemaPath: [...r.schemaPath, e],
      path: r.path
    };
    if (e._zod.processJSONSchema)
      e._zod.processJSONSchema(t, a.schema, d);
    else {
      let p = a.schema, h = t.processors[n.type];
      if (!h)
        throw new Error(`[toJSONSchema]: Non-representable type encountered: ${n.type}`);
      h(e, t, p, d);
    }
    let f = e._zod.parent;
    f && (a.ref || (a.ref = f), L(f, t, d), t.seen.get(f).isParent = !0);
  }
  let c = t.metadataRegistry.get(e);
  return c && _n(a.schema, c), t.io === "input" && de(e) && (delete a.schema.examples, delete a.schema.default), t.io === "input" && "_prefault" in a.schema && ((o = a.schema).default ?? (o.default = a.schema._prefault)), delete a.schema._prefault, t.seen.get(e).schema;
}
s(L, "process");
function Xf(e) {
  return e.replace(/~/g, "~0").replace(/\//g, "~1");
}
s(Xf, "encodeJSONPointerSegment");
function Xe(e, t) {
  let r = e.seen.get(t);
  if (!r)
    throw new Error("Unprocessed schema. This is a bug in Zod.");
  if (e.external && e.sharedDefsExtractedFor === e.external)
    return;
  let o = /* @__PURE__ */ new Map();
  for (let a of e.seen.entries()) {
    let u = e.metadataRegistry.get(a[0])?.id;
    if (u) {
      let c = o.get(u);
      if (c && c !== a[0])
        throw new Error(`Duplicate schema id "${u}" detected during JSON Schema conversion. Two different schemas cannot share the same id when converted together.`);
      o.set(u, a[0]);
    }
  }
  let n = /* @__PURE__ */ s((a) => {
    let u = e.target === "draft-2020-12" ? "$defs" : "definitions";
    if (e.external) {
      let f = e.external.registry.get(a[0])?.id, p = e.external.uri ?? ((v) => v);
      if (f)
        return { ref: p(f) };
      let h = a[1].defId ?? a[1].schema.id ?? `schema${e.counter++}`;
      return a[1].defId = h, { defId: h, ref: `${p("__shared")}#/${u}/${Xf(h)}` };
    }
    let c = "#", l = `${c}/${u}/`;
    if (a[1] === r && !a[1].schema.id)
      return { ref: c };
    let d = a[1].schema.id ?? `__schema${e.counter++}`;
    return { defId: d, ref: l + Xf(d) };
  }, "makeURI"), i = /* @__PURE__ */ s((a) => {
    if (a[1].schema.$ref)
      return;
    let u = a[1], { ref: c, defId: l } = n(a);
    u.def = { ...u.schema }, l && (u.defId = l);
    let d = u.schema;
    for (let f in d)
      delete d[f];
    d.$ref = c;
  }, "extractToDef");
  if (e.cycles === "throw")
    for (let a of e.seen.entries()) {
      let u = a[1];
      if (u.cycle)
        throw new Error(`Cycle detected: #/${u.cycle?.join("/")}/<root>

Set the \`cycles\` parameter to \`"ref"\` to resolve cyclical schemas with defs.`);
    }
  for (let a of e.seen.entries()) {
    let u = a[1];
    if (t === a[0]) {
      i(a);
      continue;
    }
    if (e.external) {
      let l = e.external.registry.get(a[0])?.id;
      if (t !== a[0] && l) {
        i(a);
        continue;
      }
    }
    if (e.metadataRegistry.get(a[0])?.id) {
      i(a);
      continue;
    }
    if (u.cycle) {
      i(a);
      continue;
    }
    if (u.count > 1 && e.reused === "ref") {
      i(a);
      continue;
    }
  }
  e.external && (e.sharedDefsExtractedFor = e.external);
}
s(Xe, "extractDefs");
function Yf(e) {
  let t = e.anyOf;
  if (!Array.isArray(t) || t.length === 0 || e.type !== void 0)
    return;
  let r = [];
  for (let o of t) {
    if (!o || typeof o != "object")
      return;
    Yf(o);
    let n = Object.keys(o);
    if (n.length !== 1 || n[0] !== "type")
      return;
    let i = o.type;
    for (let a of Array.isArray(i) ? i : [i]) {
      if (typeof a != "string")
        return;
      r.includes(a) || r.push(a);
    }
  }
  delete e.anyOf, e.type = r.length === 1 ? r[0] : r;
}
s(Yf, "compactTypeUnion");
var ep = /* @__PURE__ */ new Set(["type", "properties", "required", "additionalProperties"]), Hf = ["oneOf", "anyOf"];
function Qf(e) {
  let t = e.additionalProperties;
  return t === void 0 || t === !1 || typeof t != "object" || t === null ? null : Object.keys(t).length ? t : null;
}
s(Qf, "undeclaredConstraint");
function Ol(e) {
  let t = [];
  for (let i of e) {
    if (typeof i != "object" || i.type !== "object")
      return null;
    for (let a in i)
      if (!ep.has(a))
        return null;
    t.push(i);
  }
  let r = {}, o = /* @__PURE__ */ new Set();
  for (let i of t) {
    for (let a in i.properties) {
      if (Object.prototype.hasOwnProperty.call(r, a))
        continue;
      let u = [];
      for (let l of t) {
        let d = l.properties?.[a] ?? Qf(l);
        d != null && (u.some((f) => JSON.stringify(f) === JSON.stringify(d)) || u.push(d));
      }
      let c = u.length === 1 ? u[0] : Ol(u) ?? { allOf: u };
      te(r, a, c);
    }
    for (let a of i.required ?? [])
      o.add(a);
  }
  let n = { type: "object", properties: r };
  if (o.size && (n.required = [...o]), t.every((i) => i.additionalProperties === !1))
    n.additionalProperties = !1;
  else {
    let i = [];
    for (let a of t) {
      let u = Qf(a);
      u && !i.some((c) => JSON.stringify(c) === JSON.stringify(u)) && i.push(u);
    }
    i.length === 1 ? n.additionalProperties = i[0] : i.length > 1 && (n.additionalProperties = { allOf: i });
  }
  return n;
}
s(Ol, "foldObjects");
function ub(e) {
  let t = e.allOf;
  if (!Array.isArray(t) || t.length < 2)
    return;
  for (let n of ep)
    if (n in e)
      return;
  let r = t.filter((n) => Hf.some((i) => Array.isArray(n[i]))), o = null;
  if (!r.length)
    o = Ol(t);
  else {
    let n = r[0], i = Hf.find((c) => Array.isArray(n[c]));
    if (Object.keys(n).length !== 1)
      return;
    let a = t.filter((c) => c !== n), u = n[i].map((c) => Ol([...a, c]));
    if (u.some((c) => !c))
      return;
    o = { [i]: u };
  }
  o && (delete e.allOf, _n(e, o));
}
s(ub, "foldIntersection");
function He(e, t) {
  let r = e.seen.get(t);
  if (!r)
    throw new Error("Unprocessed schema. This is a bug in Zod.");
  let o = /* @__PURE__ */ s((u) => {
    let c = e.seen.get(u);
    if (c.ref === null)
      return;
    let l = c.def ?? c.schema, d = { ...l }, f = c.ref;
    if (c.ref = null, f) {
      o(f);
      let h = e.seen.get(f), v = h.schema;
      if (v.$ref && (e.target === "draft-07" || e.target === "draft-04" || e.target === "openapi-3.0") ? (l.allOf = l.allOf ?? [], l.allOf.push(v)) : _n(l, v), _n(l, d), u._zod.parent === f)
        for (let k in l)
          k === "$ref" || k === "allOf" || k in d || delete l[k];
      if (v.$ref && h.def)
        for (let k in l)
          k === "$ref" || k === "allOf" || k in h.def && JSON.stringify(l[k]) === JSON.stringify(h.def[k]) && delete l[k];
    }
    let p = u._zod.parent;
    if (p && p !== f) {
      o(p);
      let h = e.seen.get(p);
      if (h?.schema.$ref && (l.$ref = h.schema.$ref, h.def))
        for (let v in l)
          v === "$ref" || v === "allOf" || v in h.def && JSON.stringify(l[v]) === JSON.stringify(h.def[v]) && delete l[v];
    }
    e.override({
      zodSchema: u,
      jsonSchema: l,
      path: c.path ?? []
    });
  }, "flattenRef");
  if (!e.external || e.sharedEmitDoneFor !== e.external) {
    for (let u of [...e.seen.entries()].reverse())
      o(u[0]);
    if (e.target !== "openapi-3.0")
      for (let u of e.seen.entries())
        Yf(u[1].def ?? u[1].schema);
    for (let u of e.deferred)
      u();
    if (e.intersections.length) {
      let u = /* @__PURE__ */ new Map();
      for (let c of e.seen.values())
        for (let l of [c.schema, c.def]) {
          let d = l?.allOf;
          if (!Array.isArray(d))
            continue;
          let f = u.get(d);
          f ? f.push(l) : u.set(d, [l]);
        }
      for (let c of e.intersections)
        for (let l of u.get(c) ?? [])
          ub(l);
    }
  }
  let n = {};
  if (e.target === "draft-2020-12" ? n.$schema = "https://json-schema.org/draft/2020-12/schema" : e.target === "draft-07" ? n.$schema = "http://json-schema.org/draft-07/schema#" : e.target === "draft-04" ? n.$schema = "http://json-schema.org/draft-04/schema#" : e.target, e.external?.uri) {
    let u = e.external.registry.get(t)?.id;
    if (!u)
      throw new Error("Schema is missing an `id` property");
    n.$id = e.external.uri(u);
  }
  _n(n, r.defId ? r.schema : r.def ?? r.schema);
  let i = e.metadataRegistry.get(t)?.id;
  i !== void 0 && n.id === i && delete n.id;
  let a = e.external?.defs ?? {};
  if (!e.external || e.sharedEmitDoneFor !== e.external)
    for (let u of e.seen.entries()) {
      let c = u[1];
      c.def && c.defId && (c.def.id === c.defId && delete c.def.id, te(a, c.defId, c.def));
    }
  e.external && (e.sharedEmitDoneFor = e.external), e.external || Object.keys(a).length > 0 && (e.target === "draft-2020-12" ? n.$defs = a : n.definitions = a);
  try {
    let u = JSON.parse(JSON.stringify(n));
    return Object.defineProperty(u, "~standard", {
      value: {
        ...t["~standard"],
        jsonSchema: {
          input: Dl(t, "input", e.processors),
          output: Dl(t, "output", e.processors)
        }
      },
      enumerable: !1,
      writable: !1
    }), u;
  } catch {
    throw new Error("Error converting schema to JSON.");
  }
}
s(He, "finalize");
function de(e, t) {
  let r = t ?? { seen: /* @__PURE__ */ new Set() };
  if (r.seen.has(e))
    return !1;
  r.seen.add(e);
  let o = e._zod.def;
  if (o.type === "transform")
    return !0;
  if (o.type === "array")
    return de(o.element, r);
  if (o.type === "set")
    return de(o.valueType, r);
  if (o.type === "lazy")
    return de(o.getter(), r);
  if (o.type === "promise" || o.type === "optional" || o.type === "nonoptional" || o.type === "nullable" || o.type === "readonly" || o.type === "default" || o.type === "prefault" || o.type === "catch")
    return de(o.innerType, r);
  if (o.type === "intersection")
    return de(o.left, r) || de(o.right, r);
  if (o.type === "record" || o.type === "map")
    return de(o.keyType, r) || de(o.valueType, r);
  if (o.type === "pipe")
    return e._zod.traits.has("$ZodCodec") ? !0 : de(o.in, r) || de(o.out, r);
  if (o.type === "object") {
    for (let n in o.shape)
      if (de(o.shape[n], r))
        return !0;
    return !1;
  }
  if (o.type === "union") {
    for (let n of o.options)
      if (de(n, r))
        return !0;
    return !1;
  }
  if (o.type === "tuple") {
    for (let n of o.items)
      if (de(n, r))
        return !0;
    return !!(o.rest && de(o.rest, r));
  }
  return !1;
}
s(de, "isTransforming");
var cb = /* @__PURE__ */ s((e, t = {}) => (r) => {
  let o = Ge({ ...r, processors: t });
  return L(e, o), Xe(o, e), He(o, e);
}, "createToJSONSchemaMethod"), Dl = /* @__PURE__ */ s((e, t, r = {}) => (o) => {
  let { libraryOptions: n, target: i } = o ?? {}, a = Ge({ ...n ?? {}, target: i, io: t, processors: r });
  return L(e, a), Xe(a, e), He(a, e);
}, "createStandardJSONSchemaMethod");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/json-schema-processors.js
var lb = {
  guid: "uuid",
  url: "uri",
  datetime: "date-time",
  json_string: "json-string",
  regex: ""
  // do not set
}, db = /* @__PURE__ */ s((e, t, r, o) => {
  let n = r;
  n.type = "string";
  let { minimum: i, maximum: a, format: u, patterns: c, contentEncoding: l, laxFormat: d } = e._zod.bag;
  if (typeof i == "number" && (n.minLength = i), typeof a == "number" && (n.maxLength = a), u && (n.format = lb[u] ?? u, n.format === "" && delete n.format, (u === "time" || d) && delete n.format), l && (n.contentEncoding = l), c && c.size > 0) {
    let f = [...c];
    f.length === 1 ? n.pattern = f[0].source : f.length > 1 && (n.allOf = [
      ...f.map((p) => ({
        ...t.target === "draft-07" || t.target === "draft-04" || t.target === "openapi-3.0" ? { type: "string" } : {},
        pattern: p.source
      }))
    ]);
  }
}, "stringProcessor"), fb = /* @__PURE__ */ s((e, t, r, o) => {
  let n = r, { minimum: i, maximum: a, format: u, multipleOf: c, exclusiveMaximum: l, exclusiveMinimum: d } = e._zod.bag;
  typeof u == "string" && u.includes("int") ? n.type = "integer" : n.type = "number";
  let f = typeof d == "number" && d >= (i ?? Number.NEGATIVE_INFINITY), p = typeof l == "number" && l <= (a ?? Number.POSITIVE_INFINITY), h = t.target === "draft-04" || t.target === "openapi-3.0";
  f ? h ? (n.minimum = d, n.exclusiveMinimum = !0) : n.exclusiveMinimum = d : typeof i == "number" && (n.minimum = i), p ? h ? (n.maximum = l, n.exclusiveMaximum = !0) : n.exclusiveMaximum = l : typeof a == "number" && (n.maximum = a), typeof c == "number" && (Number.isFinite(c) && c !== 0 ? n.multipleOf = Math.abs(c) : re(e, t, n, o, `A multipleOf divisor of ${c} cannot be represented in JSON Schema`));
}, "numberProcessor"), pb = /* @__PURE__ */ s((e, t, r, o) => {
  r.type = "boolean";
}, "booleanProcessor"), mb = /* @__PURE__ */ s((e, t, r, o) => {
  re(e, t, r, o, "BigInt cannot be represented in JSON Schema");
}, "bigintProcessor"), gb = /* @__PURE__ */ s((e, t, r, o) => {
  re(e, t, r, o, "Symbols cannot be represented in JSON Schema");
}, "symbolProcessor"), hb = /* @__PURE__ */ s((e, t, r, o) => {
  t.target === "openapi-3.0" ? (r.type = "string", r.nullable = !0, r.enum = [null]) : r.type = "null";
}, "nullProcessor"), vb = /* @__PURE__ */ s((e, t, r, o) => {
  re(e, t, r, o, "Undefined cannot be represented in JSON Schema");
}, "undefinedProcessor"), yb = /* @__PURE__ */ s((e, t, r, o) => {
  re(e, t, r, o, "Void cannot be represented in JSON Schema");
}, "voidProcessor"), $b = /* @__PURE__ */ s((e, t, r, o) => {
  r.not = {};
}, "neverProcessor"), bb = /* @__PURE__ */ s((e, t, r, o) => {
}, "anyProcessor"), _b = /* @__PURE__ */ s((e, t, r, o) => {
}, "unknownProcessor"), xb = /* @__PURE__ */ s((e, t, r, o) => {
  re(e, t, r, o, "Date cannot be represented in JSON Schema");
}, "dateProcessor"), wb = /* @__PURE__ */ s((e, t, r, o) => {
  let n = e._zod.def, i = tn(n.entries);
  if (i.length === 0) {
    r.not = {};
    return;
  }
  i.every((a) => typeof a == "number") && (r.type = "number"), i.every((a) => typeof a == "string") && (r.type = "string"), r.enum = i;
}, "enumProcessor"), Ib = /* @__PURE__ */ s((e, t, r, o) => {
  let n = e._zod.def;
  if (n.values.length === 0) {
    r.not = {};
    return;
  }
  let i = [];
  for (let a of n.values)
    if (a === void 0) {
      if (re(e, t, r, o, "Literal `undefined` cannot be represented in JSON Schema"))
        return;
    } else if (typeof a == "bigint") {
      if (re(e, t, r, o, "BigInt literals cannot be represented in JSON Schema"))
        return;
      i.push(Number(a));
    } else
      i.push(a);
  if (i.length !== 0)
    if (i.length === 1) {
      let a = i[0];
      r.type = a === null ? "null" : typeof a, t.target === "draft-04" || t.target === "openapi-3.0" ? r.enum = [a] : r.const = a;
    } else
      i.every((a) => typeof a == "number") && (r.type = "number"), i.every((a) => typeof a == "string") && (r.type = "string"), i.every((a) => typeof a == "boolean") && (r.type = "boolean"), i.every((a) => a === null) && (r.type = "null"), r.enum = i;
}, "literalProcessor"), kb = /* @__PURE__ */ s((e, t, r, o) => {
  re(e, t, r, o, "NaN cannot be represented in JSON Schema");
}, "nanProcessor"), zb = /* @__PURE__ */ s((e, t, r, o) => {
  let n = r, i = e._zod.pattern;
  if (!i)
    throw new Error("Pattern not found in template literal");
  n.type = "string", n.pattern = i.source;
}, "templateLiteralProcessor"), Sb = /* @__PURE__ */ s((e, t, r, o) => {
  let n = r, i = {
    type: "string",
    format: "binary",
    contentEncoding: "binary"
  }, { minimum: a, maximum: u, mime: c } = e._zod.bag;
  a !== void 0 && (i.minLength = a), u !== void 0 && (i.maxLength = u), c ? c.length === 1 ? (i.contentMediaType = c[0], Object.assign(n, i)) : (Object.assign(n, i), n.anyOf = c.map((l) => ({ contentMediaType: l }))) : Object.assign(n, i);
}, "fileProcessor"), jb = /* @__PURE__ */ s((e, t, r, o) => {
  r.type = "boolean";
}, "successProcessor"), Ob = /* @__PURE__ */ s((e, t, r, o) => {
  re(e, t, r, o, "Custom types cannot be represented in JSON Schema");
}, "customProcessor"), Db = /* @__PURE__ */ s((e, t, r, o) => {
  re(e, t, r, o, "Function types cannot be represented in JSON Schema");
}, "functionProcessor"), Pb = /* @__PURE__ */ s((e, t, r, o) => {
  re(e, t, r, o, "Transforms cannot be represented in JSON Schema");
}, "transformProcessor"), Tb = /* @__PURE__ */ s((e, t, r, o) => {
  re(e, t, r, o, "Map cannot be represented in JSON Schema");
}, "mapProcessor"), Nb = /* @__PURE__ */ s((e, t, r, o) => {
  re(e, t, r, o, "Set cannot be represented in JSON Schema");
}, "setProcessor"), Ub = /* @__PURE__ */ s((e, t, r, o) => {
  let n = r, i = e._zod.def, { minimum: a, maximum: u } = e._zod.bag;
  typeof a == "number" && (n.minItems = a), typeof u == "number" && (n.maxItems = u), n.type = "array", n.items = L(i.element, t, {
    ...o,
    path: [...o.path, "items"]
  });
}, "arrayProcessor");
function xn(e) {
  let t = e._zod.def;
  return t.type === "pipe" && t.in._zod.traits.has("$ZodTransform") ? xn(t.out) : t.type === "catch" ? xn(t.innerType) : e._zod.optin;
}
s(xn, "inputOptin");
var Ab = /* @__PURE__ */ s((e, t, r, o) => {
  let n = r, i = e._zod.def, a = i.shape;
  if (Object.getOwnPropertySymbols(a).length && re(e, t, n, o, "Symbol keys cannot be represented in JSON Schema"))
    return;
  n.type = "object", n.properties = {};
  for (let d in a)
    te(n.properties, d, L(a[d], t, {
      ...o,
      path: [...o.path, "properties", d]
    }));
  let c = new Set(Object.keys(a)), l = new Set([...c].filter((d) => {
    let f = i.shape[d];
    return t.io === "input" ? xn(f) === void 0 : f._zod.optout === void 0;
  }));
  l.size > 0 && (n.required = Array.from(l)), i.catchall?._zod.def.type === "never" ? n.additionalProperties = !1 : i.catchall ? i.catchall && (n.additionalProperties = L(i.catchall, t, {
    ...o,
    path: [...o.path, "additionalProperties"]
  })) : t.io === "output" && (n.additionalProperties = !1);
}, "objectProcessor"), Eb = /* @__PURE__ */ s((e, t, r, o) => {
  let n = e._zod.def, i = n.inclusive === !1, a = n.options.map((u, c) => L(u, t, {
    ...o,
    path: [...o.path, i ? "oneOf" : "anyOf", c]
  }));
  i ? r.oneOf = a : r.anyOf = a;
}, "unionProcessor"), Cb = /* @__PURE__ */ s((e, t, r, o) => {
  let n = e._zod.def, i = L(n.left, t, {
    ...o,
    path: [...o.path, "allOf", 0]
  }), a = L(n.right, t, {
    ...o,
    path: [...o.path, "allOf", 1]
  }), u = /* @__PURE__ */ s((l) => "allOf" in l && Object.keys(l).length === 1, "isSimpleIntersection"), c = [
    ...u(i) ? i.allOf : [i],
    ...u(a) ? a.allOf : [a]
  ];
  r.allOf = c, t.intersections.push(c);
}, "intersectionProcessor"), Zb = /* @__PURE__ */ s((e, t, r, o) => {
  let n = r, i = e._zod.def;
  n.type = "array";
  let a = t.target === "draft-2020-12" ? "prefixItems" : "items", u = t.target === "draft-2020-12" || t.target === "openapi-3.0" ? "items" : "additionalItems", c = i.items.map((x, k) => L(x, t, {
    ...o,
    path: [...o.path, a, k]
  })), l = i.rest ? L(i.rest, t, {
    ...o,
    path: [...o.path, u, ...t.target === "openapi-3.0" ? [i.items.length] : []]
  }) : null, d = i.items.length;
  for (; d > 0; ) {
    let x = i.items[d - 1];
    if (!(t.io === "input" ? xn(x) !== void 0 : x._zod.optout === "optional"))
      break;
    d--;
  }
  let f = i.items.length, p = !i.rest;
  t.target === "draft-2020-12" ? (n.prefixItems = c, p ? n.items = !1 : l && (n.items = l), d > 0 && (n.minItems = d), p && (n.maxItems = f)) : t.target === "openapi-3.0" ? (n.items = {
    anyOf: c
  }, l && n.items.anyOf.push(l), d > 0 && (n.minItems = d), p && (n.maxItems = f)) : (n.items = c, p ? n.additionalItems = !1 : l && (n.additionalItems = l), d > 0 && (n.minItems = d), p && (n.maxItems = f));
  let { minimum: h, maximum: v } = e._zod.bag;
  typeof h == "number" && (n.minItems = h), typeof v == "number" && (n.maxItems = v);
}, "tupleProcessor");
function Pl(e, t, r) {
  if (t.$ref) {
    if (r.has(t))
      return t;
    r.add(t);
    let v = e.get(t)?.def;
    if (!v)
      return t;
    let x = Pl(e, v, r);
    return x === v ? t : x;
  }
  for (let v of ["anyOf", "oneOf"]) {
    let x = t[v];
    if (!Array.isArray(x))
      continue;
    let k = x.map((R) => Pl(e, R, r));
    k.some((R, j) => R !== x[j]) && (t = { ...t, [v]: k });
  }
  let o = Array.isArray(t.type) ? t.type : [t.type], n = !o.includes("string") && o.some((v) => v === "number" || v === "integer"), i = t.enum ?? (t.const !== void 0 ? [t.const] : void 0);
  if (!n && !i?.some((v) => typeof v == "number"))
    return t;
  let { minimum: a, maximum: u, exclusiveMinimum: c, exclusiveMaximum: l, multipleOf: d, format: f, id: p, ...h } = t;
  return h.enum ? h.enum = h.enum.map((v) => typeof v == "number" ? String(v) : v) : typeof h.const == "number" && (h.const = String(h.const)), n && (h.type = "string", i || (h.pattern = (o.includes("number") ? Ve : un).source)), h;
}
s(Pl, "stringifyKeyNames");
var Tl = /* @__PURE__ */ new WeakMap();
function Fb(e) {
  let t = /* @__PURE__ */ new Map();
  for (let o of e.seen.values())
    o.def && !t.has(o.schema) && t.set(o.schema, o);
  let r = /* @__PURE__ */ new Map();
  for (let o of Tl.get(e) ?? []) {
    let n = e.seen.get(o), i = (n?.def ?? n?.schema)?.propertyNames;
    if (!i || i === !0 || r.has(i))
      continue;
    let a = Pl(t, i, /* @__PURE__ */ new Set());
    a !== i && r.set(i, a);
  }
  if (r.size)
    for (let o of e.seen.values())
      for (let n of [o.schema, o.def]) {
        let i = n && r.get(n.propertyNames);
        i && (n.propertyNames = i);
      }
}
s(Fb, "rewriteKeyNames");
var Mb = /* @__PURE__ */ s((e, t, r, o) => {
  let n = r, i = e._zod.def;
  n.type = "object";
  let a = i.keyType, c = a._zod.bag?.patterns;
  if (i.mode === "loose" && c && c.size > 0) {
    let f = L(i.valueType, t, {
      ...o,
      path: [...o.path, "patternProperties", "*"]
    });
    n.patternProperties = {};
    for (let p of c)
      te(n.patternProperties, p.source, f);
  } else {
    if (t.target === "draft-07" || t.target === "draft-2020-12") {
      n.propertyNames = L(i.keyType, t, {
        ...o,
        path: [...o.path, "propertyNames"]
      });
      let f = Tl.get(t);
      f || (f = [], Tl.set(t, f), t.deferred.push(() => Fb(t))), f.push(e);
    }
    n.additionalProperties = L(i.valueType, t, {
      ...o,
      path: [...o.path, "additionalProperties"]
    });
  }
  let l = a._zod.values, d = t.io === "input" && xn(i.valueType) !== void 0;
  if (l && !i.partial && !d) {
    let f = [...l].filter((p) => typeof p == "string" || typeof p == "number");
    f.length > 0 && (n.required = f.map(String));
  }
}, "recordProcessor"), Rb = /* @__PURE__ */ s((e, t, r, o) => {
  let n = e._zod.def, i = L(n.innerType, t, o), a = t.seen.get(e);
  t.target === "openapi-3.0" ? (a.ref = n.innerType, r.nullable = !0) : r.anyOf = [i, { type: "null" }];
}, "nullableProcessor"), Lb = /* @__PURE__ */ s((e, t, r, o) => {
  let n = e._zod.def;
  L(n.innerType, t, o);
  let i = t.seen.get(e);
  i.ref = n.innerType;
}, "nonoptionalProcessor"), Nl = Symbol();
function tp(e, t, r, o, n) {
  let i = !1, a = JSON.stringify(e, (u, c) => typeof c != "bigint" ? c : (i = !0, null));
  return i ? (re(t, r, o, n, "BigInt defaults cannot be represented in JSON Schema"), Nl) : JSON.parse(a);
}
s(tp, "serializeDefaultValue");
var Vb = /* @__PURE__ */ s((e, t, r, o) => {
  let n = e._zod.def;
  L(n.innerType, t, o);
  let i = t.seen.get(e);
  i.ref = n.innerType;
  let a = tp(n.defaultValue, e, t, r, o);
  a !== Nl && (r.default = a);
}, "defaultProcessor"), Bb = /* @__PURE__ */ s((e, t, r, o) => {
  let n = e._zod.def;
  L(n.innerType, t, o);
  let i = t.seen.get(e);
  if (i.ref = n.innerType, t.io !== "input")
    return;
  let a = tp(n.defaultValue, e, t, r, o);
  a !== Nl && (r._prefault = a);
}, "prefaultProcessor"), Jb = /* @__PURE__ */ s((e, t, r, o) => {
  let n = e._zod.def;
  L(n.innerType, t, o);
  let i = t.seen.get(e);
  i.ref = n.innerType;
  let a;
  try {
    a = n.catchValue(void 0);
  } catch {
    re(e, t, r, o, "Dynamic catch values are not supported in JSON Schema");
    return;
  }
  r.default = a;
}, "catchProcessor"), qb = /* @__PURE__ */ s((e, t, r, o) => {
  let n = e._zod.def, i = n.in._zod.traits.has("$ZodTransform"), a = t.io === "input" ? i ? n.out : n.in : n.out;
  L(a, t, o);
  let u = t.seen.get(e);
  u.ref = a;
}, "pipeProcessor"), Wb = /* @__PURE__ */ s((e, t, r, o) => {
  let n = e._zod.def;
  L(n.innerType, t, o);
  let i = t.seen.get(e);
  i.ref = n.innerType, r.readOnly = !0;
}, "readonlyProcessor"), Kb = /* @__PURE__ */ s((e, t, r, o) => {
  let n = e._zod.def;
  L(n.innerType, t, o);
  let i = t.seen.get(e);
  i.ref = n.innerType;
}, "promiseProcessor"), Gb = /* @__PURE__ */ s((e, t, r, o) => {
  let n = e._zod.def;
  L(n.innerType, t, o);
  let i = t.seen.get(e);
  i.ref = n.innerType;
}, "optionalProcessor"), Xb = /* @__PURE__ */ s((e, t, r, o) => {
  let n = e._zod.innerType;
  L(n, t, o);
  let i = t.seen.get(e);
  i.ref = n;
}, "lazyProcessor"), qr = {
  string: db,
  number: fb,
  boolean: pb,
  bigint: mb,
  symbol: gb,
  null: hb,
  undefined: vb,
  void: yb,
  never: $b,
  any: bb,
  unknown: _b,
  date: xb,
  enum: wb,
  literal: Ib,
  nan: kb,
  template_literal: zb,
  file: Sb,
  success: jb,
  custom: Ob,
  function: Db,
  transform: Pb,
  map: Tb,
  set: Nb,
  array: Ub,
  object: Ab,
  union: Eb,
  intersection: Cb,
  tuple: Zb,
  record: Mb,
  nullable: Rb,
  nonoptional: Lb,
  default: Vb,
  prefault: Bb,
  catch: Jb,
  pipe: qb,
  readonly: Wb,
  promise: Kb,
  optional: Gb,
  lazy: Xb
};
function Wr(e, t) {
  if ("_idmap" in e) {
    let o = e, n = Ge({ ...t, processors: qr }), i = {};
    for (let c of o._idmap.entries()) {
      let [l, d] = c;
      L(d, n);
    }
    let a = {}, u = {
      registry: o,
      uri: t?.uri,
      defs: i
    };
    n.external = u;
    for (let c of o._idmap.entries()) {
      let [l, d] = c;
      Xe(n, d), te(a, l, He(n, d));
    }
    if (Object.keys(i).length > 0) {
      let c = n.target === "draft-2020-12" ? "$defs" : "definitions";
      a.__shared = {
        [c]: i
      };
    }
    return { schemas: a };
  }
  let r = Ge({ ...t, processors: qr });
  return L(e, r), Xe(r, e), He(r, e);
}
s(Wr, "toJSONSchema");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/json-schema-generator.js
var Kr = class {
  static {
    s(this, "JSONSchemaGenerator");
  }
  /** @deprecated Access via ctx instead */
  get metadataRegistry() {
    return this.ctx.metadataRegistry;
  }
  /** @deprecated Access via ctx instead */
  get target() {
    return this.ctx.target;
  }
  // annotated so the .d.cts emits an indexed access rather than an inline `import()` of an ESM path
  /** @deprecated Access via ctx instead */
  get unrepresentable() {
    return this.ctx.unrepresentable;
  }
  /** @deprecated Access via ctx instead */
  get override() {
    return this.ctx.override;
  }
  /** @deprecated Access via ctx instead */
  get io() {
    return this.ctx.io;
  }
  /** @deprecated Access via ctx instead */
  get counter() {
    return this.ctx.counter;
  }
  set counter(t) {
    this.ctx.counter = t;
  }
  /** @deprecated Access via ctx instead */
  get seen() {
    return this.ctx.seen;
  }
  constructor(t) {
    let r = t?.target ?? "draft-2020-12";
    r === "draft-4" && (r = "draft-04"), r === "draft-7" && (r = "draft-07"), this.ctx = Ge({
      processors: qr,
      target: r,
      ...t?.metadata && { metadata: t.metadata },
      ...t?.unrepresentable && { unrepresentable: t.unrepresentable },
      ...t?.override && { override: t.override },
      ...t?.io && { io: t.io }
    });
  }
  /**
   * Process a schema to prepare it for JSON Schema generation.
   * This must be called before emit().
   */
  process(t, r = { path: [], schemaPath: [] }) {
    return L(t, this.ctx, r);
  }
  /**
   * Emit the final JSON Schema after processing.
   * Must call process() first.
   */
  emit(t, r) {
    r && (r.cycles && (this.ctx.cycles = r.cycles), r.reused && (this.ctx.reused = r.reused), r.external && (this.ctx.external = r.external)), this.ctx.sharedDefsExtractedFor = void 0, this.ctx.sharedEmitDoneFor = void 0, Xe(this.ctx, t);
    let o = He(this.ctx, t), { "~standard": n, ...i } = o;
    return i;
  }
};

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/json-schema.js
var np = {};

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/mini/schemas.js
var N = /* @__PURE__ */ g("ZodMiniType", (e, t) => {
  if (!e._zod)
    throw new Error("Uninitialized schema in ZodMiniType.");
  S.init(e, t), e.def = t, e.type = t.type;
}, {
  // `with` is an alias for `check`: the same function object, not a wrapper.
  get with() {
    return this.check;
  },
  set with(e) {
    Fe(this, "with", e);
  },
  parse(e, t) {
    return ve(this, e, t, { callee: this.parse });
  },
  parseAsync(e, t) {
    return Le(this, e, t, { callee: this.parseAsync });
  },
  safeParse(e, t) {
    return Se(this, e, t);
  },
  safeParseAsync(e, t) {
    return ut(this, e, t);
  },
  check(...e) {
    let t = this.def;
    return this.clone({
      ...t,
      checks: [
        ...t.checks ?? [],
        ...e.map((r) => typeof r == "function" ? { _zod: { check: r, def: { check: "custom" }, onattach: [] } } : r)
      ]
    }, { parent: !0 });
  },
  clone(e, t) {
    return E(this, e, t);
  },
  brand() {
    return this;
  },
  register(e, t) {
    return e.add(this, t), this;
  },
  apply(e, ...t) {
    return t.length === 0 ? e(this) : e(this, ...t);
  }
}), Ft = /* @__PURE__ */ g("ZodMiniString", (e, t) => {
  Pt.init(e, t), N.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Zt(e) {
  return Yu(Ft, e);
}
s(Zt, "string");
var J = /* @__PURE__ */ g("ZodMiniStringFormat", (e, t) => {
  V.init(e, t), Ft.init(e, t);
}), rp = /* @__PURE__ */ g("ZodMiniEmail", (e, t) => {
  Ca.init(e, t), J.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Qb(e) {
  return tc(rp, e);
}
s(Qb, "email");
var ip = /* @__PURE__ */ g("ZodMiniGUID", (e, t) => {
  Aa.init(e, t), J.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Yb(e) {
  return nc(ip, e);
}
s(Yb, "guid");
var In = /* @__PURE__ */ g("ZodMiniUUID", (e, t) => {
  Ea.init(e, t), J.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function e_(e) {
  return rc(In, e);
}
s(e_, "uuid");
// @__NO_SIDE_EFFECTS__
function t_(e) {
  return ic(In, e);
}
s(t_, "uuidv4");
// @__NO_SIDE_EFFECTS__
function n_(e) {
  return oc(In, e);
}
s(n_, "uuidv6");
// @__NO_SIDE_EFFECTS__
function r_(e) {
  return ac(In, e);
}
s(r_, "uuidv7");
var Ul = /* @__PURE__ */ g("ZodMiniURL", (e, t) => {
  Ma.init(e, t), J.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function i_(e) {
  return Vr(Ul, e);
}
s(i_, "url");
// @__NO_SIDE_EFFECTS__
function o_(e) {
  return Vr(Ul, {
    protocol: ue.httpProtocol,
    hostname: ue.domain,
    ..._(e)
  });
}
s(o_, "httpUrl");
var op = /* @__PURE__ */ g("ZodMiniEmoji", (e, t) => {
  Ra.init(e, t), J.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function a_(e) {
  return sc(op, e);
}
s(a_, "emoji");
var ap = /* @__PURE__ */ g("ZodMiniNanoID", (e, t) => {
  La.init(e, t), J.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function s_(e) {
  return uc(ap, e);
}
s(s_, "nanoid");
var sp = /* @__PURE__ */ g("ZodMiniCUID", (e, t) => {
  Va.init(e, t), J.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function u_(e) {
  return cc(sp, e);
}
s(u_, "cuid");
var up = /* @__PURE__ */ g("ZodMiniCUID2", (e, t) => {
  Ba.init(e, t), J.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function c_(e) {
  return lc(up, e);
}
s(c_, "cuid2");
var cp = /* @__PURE__ */ g("ZodMiniULID", (e, t) => {
  Ja.init(e, t), J.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function l_(e) {
  return dc(cp, e);
}
s(l_, "ulid");
var lp = /* @__PURE__ */ g("ZodMiniXID", (e, t) => {
  qa.init(e, t), J.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function d_(e) {
  return fc(lp, e);
}
s(d_, "xid");
var dp = /* @__PURE__ */ g("ZodMiniKSUID", (e, t) => {
  Wa.init(e, t), J.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function f_(e) {
  return pc(dp, e);
}
s(f_, "ksuid");
var fp = /* @__PURE__ */ g("ZodMiniIPv4", (e, t) => {
  Qa.init(e, t), J.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function p_(e) {
  return mc(fp, e);
}
s(p_, "ipv4");
var pp = /* @__PURE__ */ g("ZodMiniIPv6", (e, t) => {
  Ya.init(e, t), J.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function m_(e) {
  return gc(pp, e);
}
s(m_, "ipv6");
var mp = /* @__PURE__ */ g("ZodMiniCIDRv4", (e, t) => {
  ts.init(e, t), J.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function g_(e) {
  return vc(mp, e);
}
s(g_, "cidrv4");
var gp = /* @__PURE__ */ g("ZodMiniCIDRv6", (e, t) => {
  ns.init(e, t), J.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function h_(e) {
  return yc(gp, e);
}
s(h_, "cidrv6");
var hp = /* @__PURE__ */ g("ZodMiniMAC", (e, t) => {
  es.init(e, t), J.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function v_(e) {
  return hc(hp, e);
}
s(v_, "mac");
var vp = /* @__PURE__ */ g("ZodMiniBase64", (e, t) => {
  rs.init(e, t), J.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function y_(e) {
  return $c(vp, e);
}
s(y_, "base64");
var yp = /* @__PURE__ */ g("ZodMiniBase64URL", (e, t) => {
  is.init(e, t), J.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function $_(e) {
  return bc(yp, e);
}
s($_, "base64url");
var $p = /* @__PURE__ */ g("ZodMiniE164", (e, t) => {
  os.init(e, t), J.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function b_(e) {
  return _c($p, e);
}
s(b_, "e164");
var bp = /* @__PURE__ */ g("ZodMiniCreditCard", (e, t) => {
  as.init(e, t), J.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function __(e) {
  return xc(bp, e);
}
s(__, "creditCard");
var _p = /* @__PURE__ */ g("ZodMiniJWT", (e, t) => {
  ss.init(e, t), J.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function x_(e) {
  return wc(_p, e);
}
s(x_, "jwt");
var kn = /* @__PURE__ */ g("ZodMiniCustomStringFormat", (e, t) => {
  us.init(e, t), J.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function w_(e, t, r = {}) {
  return Et(kn, e, t, r);
}
s(w_, "stringFormat");
// @__NO_SIDE_EFFECTS__
function I_(e) {
  return Et(kn, "hostname", ue.hostname, e);
}
s(I_, "hostname");
// @__NO_SIDE_EFFECTS__
function k_(e) {
  return Et(kn, "hex", ue.hex, e);
}
s(k_, "hex");
// @__NO_SIDE_EFFECTS__
function z_(e, t) {
  let r = t?.enc ?? "hex", o = `${e}_${r}`, n = ue[o];
  if (!n)
    throw new Error(`Unrecognized hash format: ${o}`);
  return Et(kn, o, n, t);
}
s(z_, "hash");
var zn = /* @__PURE__ */ g("ZodMiniNumber", (e, t) => {
  Nr.init(e, t), N.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Hr(e) {
  return Oc(zn, e);
}
s(Hr, "number");
var Mt = /* @__PURE__ */ g("ZodMiniNumberFormat", (e, t) => {
  cs.init(e, t), zn.init(e, t);
});
function S_(e) {
  return Pc(Mt, e);
}
s(S_, "int");
function j_(e) {
  return Tc(Mt, e);
}
s(j_, "float32");
function O_(e) {
  return Nc(Mt, e);
}
s(O_, "float64");
function D_(e) {
  return Uc(Mt, e);
}
s(D_, "int32");
function P_(e) {
  return Ac(Mt, e);
}
s(P_, "uint32");
var Sn = /* @__PURE__ */ g("ZodMiniBoolean", (e, t) => {
  pn.init(e, t), N.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Qr(e) {
  return Ec(Sn, e);
}
s(Qr, "boolean");
var jn = /* @__PURE__ */ g("ZodMiniBigInt", (e, t) => {
  Ur.init(e, t), N.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function T_(e) {
  return Zc(jn, e);
}
s(T_, "bigint");
var Al = /* @__PURE__ */ g("ZodMiniBigIntFormat", (e, t) => {
  ls.init(e, t), jn.init(e, t);
});
function N_(e) {
  return Mc(Al, e);
}
s(N_, "int64");
function U_(e) {
  return Rc(Al, e);
}
s(U_, "uint64");
var xp = /* @__PURE__ */ g("ZodMiniSymbol", (e, t) => {
  ds.init(e, t), N.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function A_(e) {
  return Lc(xp, e);
}
s(A_, "symbol");
var wp = /* @__PURE__ */ g("ZodMiniUndefined", (e, t) => {
  fs.init(e, t), N.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function E_(e) {
  return Vc(wp, e);
}
s(E_, "_undefined");
var Ip = /* @__PURE__ */ g("ZodMiniNull", (e, t) => {
  ps.init(e, t), N.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function kp(e) {
  return Bc(Ip, e);
}
s(kp, "_null");
var zp = /* @__PURE__ */ g("ZodMiniAny", (e, t) => {
  ms.init(e, t), N.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function C_() {
  return Jc(zp);
}
s(C_, "any");
var Sp = /* @__PURE__ */ g("ZodMiniUnknown", (e, t) => {
  gs.init(e, t), N.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Gr() {
  return qc(Sp);
}
s(Gr, "unknown");
var jp = /* @__PURE__ */ g("ZodMiniNever", (e, t) => {
  hs.init(e, t), N.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Op(e) {
  return Wc(jp, e);
}
s(Op, "never");
var Dp = /* @__PURE__ */ g("ZodMiniVoid", (e, t) => {
  vs.init(e, t), N.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Z_(e) {
  return Kc(Dp, e);
}
s(Z_, "_void");
var Yr = /* @__PURE__ */ g("ZodMiniDate", (e, t) => {
  Tt.init(e, t), N.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function El(e) {
  return Gc(Yr, e);
}
s(El, "date");
var Pp = /* @__PURE__ */ g("ZodMiniArray", (e, t) => {
  Be.init(e, t), N.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function On(e, t) {
  return new Pp({
    type: "array",
    element: e,
    ..._(t)
  });
}
s(On, "array");
// @__NO_SIDE_EFFECTS__
function F_(e) {
  let t = e._zod.def.shape;
  return /* @__PURE__ */ Mp(Object.keys(t));
}
s(F_, "keyof");
var ei = /* @__PURE__ */ g("ZodMiniObject", (e, t) => {
  Y.init(e, t), N.init(e, t), vo(e, "shape", (r) => r._zod.def.shape, !1);
});
// @__NO_SIDE_EFFECTS__
function Cl(e, t) {
  let r = {
    type: "object",
    shape: e ?? {},
    ..._(t)
  };
  return new ei(r);
}
s(Cl, "object");
// @__NO_SIDE_EFFECTS__
function M_(e, t) {
  return new ei({
    type: "object",
    shape: e,
    catchall: /* @__PURE__ */ Op(),
    ..._(t)
  });
}
s(M_, "strictObject");
// @__NO_SIDE_EFFECTS__
function R_(e, t) {
  return new ei({
    type: "object",
    shape: e,
    catchall: /* @__PURE__ */ Gr(),
    ..._(t)
  });
}
s(R_, "looseObject");
// @__NO_SIDE_EFFECTS__
function L_(e, t) {
  return co(e, t);
}
s(L_, "extend");
// @__NO_SIDE_EFFECTS__
function V_(e, t) {
  return lo(e, t);
}
s(V_, "safeExtend");
// @__NO_SIDE_EFFECTS__
function B_(e, t) {
  return fo(e, t);
}
s(B_, "merge");
// @__NO_SIDE_EFFECTS__
function J_(e, t) {
  return so(e, t);
}
s(J_, "pick");
// @__NO_SIDE_EFFECTS__
function q_(e, t) {
  return uo(e, t);
}
s(q_, "omit");
// @__NO_SIDE_EFFECTS__
function Zl(e, t) {
  let r = e._zod.def;
  if (r.type !== "tuple")
    return sr(Xr, e, t);
  if (r.checks?.length)
    throw new Error(".partial() cannot be used on tuple schemas containing refinements");
  return E(e, {
    ...r,
    items: r.items.map((o) => new Xr({ type: "optional", innerType: o }))
  });
}
s(Zl, "partial");
// @__NO_SIDE_EFFECTS__
function W_(e, t) {
  return sr(Rl, e, t, "exactPartial");
}
s(W_, "exactPartial");
// @__NO_SIDE_EFFECTS__
function K_(e, t) {
  return po(Ll, e, t);
}
s(K_, "required");
// @__NO_SIDE_EFFECTS__
function G_(e, t) {
  return e.clone({ ...e._zod.def, catchall: t });
}
s(G_, "catchall");
var Fl = /* @__PURE__ */ g("ZodMiniUnion", (e, t) => {
  ce.init(e, t), N.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Rt(e, t) {
  return new Fl({
    type: "union",
    options: e,
    ..._(t)
  });
}
s(Rt, "union");
var Tp = /* @__PURE__ */ g("ZodMiniXor", (e, t) => {
  Fl.init(e, t), ys.init(e, t);
});
function X_(e, t) {
  return new Tp({
    type: "union",
    options: e,
    inclusive: !1,
    ..._(t)
  });
}
s(X_, "xor");
var Np = /* @__PURE__ */ g("ZodMiniDiscriminatedUnion", (e, t) => {
  Je.init(e, t), N.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function H_(e, t, r) {
  return new Np({
    type: "union",
    options: t,
    discriminator: e,
    ..._(r)
  });
}
s(H_, "discriminatedUnion");
var Up = /* @__PURE__ */ g("ZodMiniIntersection", (e, t) => {
  bs.init(e, t), N.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Q_(e, t) {
  return new Up({
    type: "intersection",
    left: e,
    right: t
  });
}
s(Q_, "intersection");
var Ap = /* @__PURE__ */ g("ZodMiniTuple", (e, t) => {
  qe.init(e, t), N.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Ep(e, t, r) {
  let o = t instanceof S, n = o ? r : t, i = o ? t : null;
  return new Ap({
    type: "tuple",
    items: e,
    rest: i,
    ..._(n)
  });
}
s(Ep, "tuple");
var wn = /* @__PURE__ */ g("ZodMiniRecord", (e, t) => {
  dt.init(e, t), N.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Cp(e, t, r) {
  return !t || !t._zod ? new wn({
    type: "record",
    keyType: /* @__PURE__ */ Zt(),
    valueType: e,
    ..._(t)
  }) : new wn({
    type: "record",
    keyType: e,
    valueType: t,
    ..._(r)
  });
}
s(Cp, "record");
// @__NO_SIDE_EFFECTS__
function Y_(e, t, r) {
  return new wn({
    type: "record",
    keyType: e,
    valueType: t,
    ..._(r),
    partial: !0
  });
}
s(Y_, "partialRecord");
function ex(e, t, r) {
  return new wn({
    type: "record",
    keyType: e,
    valueType: t,
    mode: "loose",
    ..._(r)
  });
}
s(ex, "looseRecord");
var Zp = /* @__PURE__ */ g("ZodMiniMap", (e, t) => {
  _s.init(e, t), N.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function tx(e, t, r) {
  return new Zp({
    type: "map",
    keyType: e,
    valueType: t,
    ..._(r)
  });
}
s(tx, "map");
var Fp = /* @__PURE__ */ g("ZodMiniSet", (e, t) => {
  xs.init(e, t), N.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function nx(e, t) {
  return new Fp({
    type: "set",
    valueType: e,
    ..._(t)
  });
}
s(nx, "set");
var Ml = /* @__PURE__ */ g("ZodMiniEnum", (e, t) => {
  Nt.init(e, t), N.init(e, t), e.options = Object.values(t.entries);
});
// @__NO_SIDE_EFFECTS__
function Mp(e, t) {
  let r = Array.isArray(e) ? Object.fromEntries(e.map((o) => [o, o])) : e;
  return new Ml({
    type: "enum",
    entries: r,
    ..._(t)
  });
}
s(Mp, "_enum");
// @__NO_SIDE_EFFECTS__
function rx(e, t) {
  return new Ml({
    type: "enum",
    entries: e,
    ..._(t)
  });
}
s(rx, "nativeEnum");
var Rp = /* @__PURE__ */ g("ZodMiniLiteral", (e, t) => {
  Ut.init(e, t), N.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function ix(e, t) {
  return new Rp({
    type: "literal",
    values: Array.isArray(e) ? e : [e],
    ..._(t)
  });
}
s(ix, "literal");
var Lp = /* @__PURE__ */ g("ZodMiniFile", (e, t) => {
  ws.init(e, t), N.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function ox(e) {
  return xl(Lp, e);
}
s(ox, "file");
var Vp = /* @__PURE__ */ g("ZodMiniTransform", (e, t) => {
  Is.init(e, t), N.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function ax(e) {
  return new Vp({
    type: "transform",
    transform: e
  });
}
s(ax, "transform");
var Xr = /* @__PURE__ */ g("ZodMiniOptional", (e, t) => {
  X.init(e, t), N.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Lt(e) {
  return new Xr({
    type: "optional",
    innerType: e
  });
}
s(Lt, "optional");
var Rl = /* @__PURE__ */ g("ZodMiniExactOptional", (e, t) => {
  ks.init(e, t), N.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function sx(e) {
  return new Rl({
    type: "optional",
    innerType: e
  });
}
s(sx, "exactOptional");
var Bp = /* @__PURE__ */ g("ZodMiniNullable", (e, t) => {
  Ie.init(e, t), N.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function ti(e) {
  return new Bp({
    type: "nullable",
    innerType: e
  });
}
s(ti, "nullable");
// @__NO_SIDE_EFFECTS__
function ux(e) {
  return /* @__PURE__ */ Lt(/* @__PURE__ */ ti(e));
}
s(ux, "nullish");
var Jp = /* @__PURE__ */ g("ZodMiniDefault", (e, t) => {
  $e.init(e, t), N.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function cx(e, t) {
  return new Jp({
    type: "default",
    innerType: e,
    get defaultValue() {
      return typeof t == "function" ? t() : Me(t);
    }
  });
}
s(cx, "_default");
var qp = /* @__PURE__ */ g("ZodMiniPrefault", (e, t) => {
  zs.init(e, t), N.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function lx(e, t) {
  return new qp({
    type: "prefault",
    innerType: e,
    get defaultValue() {
      return typeof t == "function" ? t() : Me(t);
    }
  });
}
s(lx, "prefault");
var Ll = /* @__PURE__ */ g("ZodMiniNonOptional", (e, t) => {
  Ss.init(e, t), N.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function dx(e, t) {
  return new Ll({
    type: "nonoptional",
    innerType: e,
    ..._(t)
  });
}
s(dx, "nonoptional");
var Wp = /* @__PURE__ */ g("ZodMiniSuccess", (e, t) => {
  js.init(e, t), N.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function fx(e) {
  return new Wp({
    type: "success",
    innerType: e
  });
}
s(fx, "success");
var Kp = /* @__PURE__ */ g("ZodMiniCatch", (e, t) => {
  Os.init(e, t), N.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function px(e, t) {
  return new Kp({
    type: "catch",
    innerType: e,
    catchValue: typeof t == "function" ? t : z.constantCatch(t)
  });
}
s(px, "_catch");
var Gp = /* @__PURE__ */ g("ZodMiniNaN", (e, t) => {
  Ds.init(e, t), N.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function mx(e) {
  return Hc(Gp, e);
}
s(mx, "nan");
var Vl = /* @__PURE__ */ g("ZodMiniPipe", (e, t) => {
  Ar.init(e, t), N.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function gx(e, t) {
  return new Vl({
    type: "pipe",
    in: e,
    out: t
  });
}
s(gx, "pipe");
var ni = /* @__PURE__ */ g("ZodMiniCodec", (e, t) => {
  Vl.init(e, t), je.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Bl(e, t, r) {
  return new ni({
    type: "pipe",
    in: e,
    out: t,
    transform: r.decode,
    reverseTransform: r.encode
  });
}
s(Bl, "codec");
// @__NO_SIDE_EFFECTS__
function hx(e) {
  let t = e._zod.def;
  return new ni({
    type: "pipe",
    in: t.out,
    out: t.in,
    transform: t.reverseTransform,
    reverseTransform: t.transform
  });
}
s(hx, "invertCodec");
var Xp = /* @__PURE__ */ g("ZodMiniReadonly", (e, t) => {
  Ps.init(e, t), N.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function vx(e) {
  return new Xp({
    type: "readonly",
    innerType: e
  });
}
s(vx, "readonly");
var Hp = /* @__PURE__ */ g("ZodMiniTemplateLiteral", (e, t) => {
  Ts.init(e, t), N.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function yx(e, t) {
  return new Hp({
    type: "template_literal",
    parts: e,
    ..._(t)
  });
}
s(yx, "templateLiteral");
var Qp = /* @__PURE__ */ g("ZodMiniLazy", (e, t) => {
  We.init(e, t), N.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Yp(e) {
  return new Qp({
    type: "lazy",
    getter: e
  });
}
s(Yp, "_lazy");
var em = /* @__PURE__ */ g("ZodMiniPromise", (e, t) => {
  Us.init(e, t), N.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function $x(e) {
  return new em({
    type: "promise",
    innerType: e
  });
}
s($x, "promise");
var Jl = /* @__PURE__ */ g("ZodMiniCustom", (e, t) => {
  mn.init(e, t), N.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function bx(e, t) {
  let r = new W({
    check: "custom",
    ..._(t)
  });
  return r._zod.check = e, r;
}
s(bx, "check");
// @__NO_SIDE_EFFECTS__
function tm(e, t) {
  return wl(Jl, e ?? (() => !0), t);
}
s(tm, "custom");
// @__NO_SIDE_EFFECTS__
function _x(e, t = {}) {
  return Il(Jl, e, t);
}
s(_x, "refine");
// @__NO_SIDE_EFFECTS__
function xx(e, t) {
  return kl(e, t);
}
s(xx, "superRefine");
var wx = zl, Ix = Sl;
// @__NO_SIDE_EFFECTS__
function ql(e, t = {}) {
  let r = /* @__PURE__ */ tm((o) => o instanceof e, t);
  return r._zod.bag.Class = e, r._zod.check = (o) => {
    o.value instanceof e || o.issues.push({
      code: "invalid_type",
      expected: e.name,
      input: o.value,
      inst: r,
      path: [...r._zod.def.path ?? []]
    });
  }, r;
}
s(ql, "_instanceof");
var kx = /* @__PURE__ */ s((...e) => jl({
  Codec: ni,
  Boolean: Sn,
  String: Ft
}, ...e), "stringbool");
// @__NO_SIDE_EFFECTS__
function zx() {
  let e = /* @__PURE__ */ Yp(() => /* @__PURE__ */ Rt([/* @__PURE__ */ Zt(), /* @__PURE__ */ Hr(), /* @__PURE__ */ Qr(), /* @__PURE__ */ kp(), /* @__PURE__ */ On(e), /* @__PURE__ */ Cp(/* @__PURE__ */ Zt(), e)]));
  return e;
}
s(zx, "json");
var nm = /* @__PURE__ */ g("ZodMiniFunction", (e, t) => {
  Ns.init(e, t), N.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Sx(e) {
  return new nm({
    type: "function",
    input: Array.isArray(e?.input) ? /* @__PURE__ */ Ep(e?.input) : e?.input ?? /* @__PURE__ */ On(/* @__PURE__ */ Gr()),
    output: e?.output ?? /* @__PURE__ */ Gr()
  });
}
s(Sx, "_function");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/core/visit.js
var rm = Symbol("z.visit/resolving");
function Dn(e, t) {
  let r = typeof t == "function" ? t : (a, u) => {
    let c = t[a._zod.def.type];
    return c ? c(a, u) : a;
  }, o = /* @__PURE__ */ new Map();
  function n(a) {
    let u = o.get(a);
    if (u === rm)
      return new We({
        type: "lazy",
        getter: /* @__PURE__ */ s(() => o.get(a), "getter")
      });
    if (u !== void 0)
      return u;
    o.set(a, rm);
    let c = i(a), l = r(c, c !== a);
    return o.set(a, l), l;
  }
  s(n, "run");
  function i(a) {
    let u = a._zod.def, c = u.type;
    switch (c) {
      case "object": {
        let l = u.shape, d = Object.keys(l), f = !1, p = {};
        for (let v of d) {
          let x = n(l[v]);
          x !== l[v] && (f = !0), p[v] = x;
        }
        let h = u.catchall;
        return u.catchall && (h = n(u.catchall), h !== u.catchall && (f = !0)), f ? E(a, { ...u, shape: p, catchall: h }) : a;
      }
      case "array": {
        let l = n(u.element);
        return l === u.element ? a : E(a, { ...u, element: l });
      }
      case "tuple": {
        let l = u.items, d = !1, f = [];
        for (let h of l) {
          let v = n(h);
          v !== h && (d = !0), f.push(v);
        }
        let p = u.rest;
        return u.rest && (p = n(u.rest), p !== u.rest && (d = !0)), d ? E(a, { ...u, items: f, rest: p }) : a;
      }
      case "record":
      case "map": {
        let l = n(u.keyType), d = n(u.valueType);
        return l === u.keyType && d === u.valueType ? a : E(a, { ...u, keyType: l, valueType: d });
      }
      case "set": {
        let l = n(u.valueType);
        return l === u.valueType ? a : E(a, { ...u, valueType: l });
      }
      case "union": {
        let l = u.options, d = !1, f = [];
        for (let p of l) {
          let h = n(p);
          h !== p && (d = !0), f.push(h);
        }
        return d ? E(a, { ...u, options: f }) : a;
      }
      case "intersection": {
        let l = n(u.left), d = n(u.right);
        return l === u.left && d === u.right ? a : E(a, { ...u, left: l, right: d });
      }
      case "optional":
      case "nullable":
      case "default":
      case "prefault":
      case "catch":
      case "readonly":
      case "nonoptional":
      case "promise":
      case "success": {
        let l = n(u.innerType);
        return l === u.innerType ? a : E(a, { ...u, innerType: l });
      }
      case "pipe": {
        let l = n(u.in), d = n(u.out);
        return l === u.in && d === u.out ? a : E(a, { ...u, in: l, out: d });
      }
      case "function": {
        let l = n(u.input), d = n(u.output);
        return l === u.input && d === u.output ? a : E(a, { ...u, input: l, output: d });
      }
      case "lazy": {
        let l = u.getter, { _cachedInner: d, ...f } = u;
        return E(a, { ...f, getter: /* @__PURE__ */ s(() => n(l()), "getter") });
      }
      // A leaf by choice: `parts` are regex fragments, not data positions.
      case "template_literal":
      // Leaves.
      case "string":
      case "number":
      case "int":
      case "boolean":
      case "bigint":
      case "symbol":
      case "undefined":
      case "null":
      case "void":
      case "never":
      case "any":
      case "unknown":
      case "date":
      case "nan":
      case "enum":
      case "literal":
      case "file":
      case "transform":
      case "custom":
        return a;
      default:
        return a;
    }
  }
  return s(i, "mapInner"), n(e);
}
s(Dn, "visit");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/mini/deep-partial.js
function im(e) {
  return Dn(e, {
    object: /* @__PURE__ */ s((t) => Zl(t), "object"),
    // See `classic/deep-partial.ts`.
    union: /* @__PURE__ */ s((t) => {
      let r = t._zod.def;
      return r.discriminator === void 0 ? t : Rt(r.options);
    }, "union")
  });
}
s(im, "deepPartial");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/mini/in-out.js
function jx(e, t) {
  if (!t?.length)
    return e;
  let r = e._zod.def;
  return E(e, ze(r, { checks: [...r.checks ?? [], ...t] }), { parent: !0 });
}
s(jx, "withChecks");
function om(e) {
  return jx(e.out, e.checks);
}
s(om, "outSide");
function Ox(e) {
  return e.in._zod.traits.has("$ZodTransform") ? om(e) : e.in;
}
s(Ox, "inSide");
function am(e) {
  return Dn(e, {
    pipe: /* @__PURE__ */ s((t) => Ox(t._zod.def), "pipe"),
    // A default value belongs to the output side, so a rewritten inner type leaves it stranded. `.default()` widens the declared input type with `undefined`, and `optional` is what carries that across.
    default: /* @__PURE__ */ s((t, r) => r ? Lt(t._zod.def.innerType) : t, "default"),
    // A catch value is output-side too, but `.catch()` leaves the declared input type alone, so the inner schema stands on its own.
    catch: /* @__PURE__ */ s((t, r) => r ? t._zod.def.innerType : t, "catch")
  });
}
s(am, "input");
function sm(e) {
  return Dn(e, {
    pipe: /* @__PURE__ */ s((t) => om(t._zod.def), "pipe"),
    // A prefault value is fed through the schema, which makes it input-side, so a rewritten inner type leaves it stranded.
    prefault: /* @__PURE__ */ s((t, r) => r ? t._zod.def.innerType : t, "prefault")
  });
}
s(sm, "output");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/mini/iso.js
var Wl = {};
et(Wl, {
  ZodMiniISODate: () => oi,
  ZodMiniISODateTime: () => ii,
  ZodMiniISODuration: () => si,
  ZodMiniISOTime: () => ai,
  date: () => Px,
  datetime: () => Dx,
  duration: () => Nx,
  time: () => Tx
});
var ii = /* @__PURE__ */ g("ZodMiniISODateTime", (e, t) => {
  Ka.init(e, t), J.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Dx(e) {
  return kc(ii, e);
}
s(Dx, "datetime");
var oi = /* @__PURE__ */ g("ZodMiniISODate", (e, t) => {
  Ga.init(e, t), J.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Px(e) {
  return zc(oi, e);
}
s(Px, "date");
var ai = /* @__PURE__ */ g("ZodMiniISOTime", (e, t) => {
  Xa.init(e, t), J.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Tx(e) {
  return Sc(ai, e);
}
s(Tx, "time");
var si = /* @__PURE__ */ g("ZodMiniISODuration", (e, t) => {
  Ha.init(e, t), J.init(e, t);
});
// @__NO_SIDE_EFFECTS__
function Nx(e) {
  return jc(si, e);
}
s(Nx, "duration");

// ../../node_modules/.bun/zod@4.5.4/node_modules/zod/v4/mini/coerce.js
var Kl = {};
et(Kl, {
  bigint: () => Cx,
  boolean: () => Ex,
  date: () => Zx,
  number: () => Ax,
  string: () => Ux
});
// @__NO_SIDE_EFFECTS__
function Ux(e) {
  return ec(Ft, e);
}
s(Ux, "string");
// @__NO_SIDE_EFFECTS__
function Ax(e) {
  return Dc(zn, e);
}
s(Ax, "number");
// @__NO_SIDE_EFFECTS__
function Ex(e) {
  return Cc(Sn, e);
}
s(Ex, "boolean");
// @__NO_SIDE_EFFECTS__
function Cx(e) {
  return Fc(jn, e);
}
s(Cx, "bigint");
// @__NO_SIDE_EFFECTS__
function Zx(e) {
  return Xc(Yr, e);
}
s(Zx, "date");

// ../../packages/zodvex/dist/mini/index.js
var um = /* @__PURE__ */ new WeakMap(), Mx = {
  getMetadata: /* @__PURE__ */ s((e) => um.get(e), "getMetadata"),
  setMetadata: /* @__PURE__ */ s((e, t) => um.set(e, t), "setMetadata")
};
var cm = /* @__PURE__ */ Symbol.for("zodvex.zxDate");
function Rx(e) {
  e[cm] = !0;
  let t = e._zod?.def;
  return t && (t[cm] = !0), e;
}
s(Rx, "brandZxDate");
var I6 = w.discriminatedUnion("success", [
  w.object({ success: w.literal(!0) }),
  w.object({ success: w.literal(!1), error: w.string() })
]), k6 = w.object({
  formErrors: w.array(w.string()),
  fieldErrors: w.record(w.string(), w.array(w.string()))
});
var Lx = "__zodvexMeta";
function hm(e, t) {
  Object.defineProperty(e, Lx, {
    value: t,
    enumerable: !1,
    writable: !1,
    configurable: !1
  });
}
s(hm, "attachMeta");
var Vx = "__zodvexCodecBrand";
function Bx(e, t) {
  Object.defineProperty(e, Vx, {
    value: t,
    enumerable: !1,
    writable: !1,
    configurable: !1
  });
}
s(Bx, "attachCodecBrand");
function vm(e, t, r) {
  return w.codec(e, t, r);
}
s(vm, "zodvexCodec");
function ci(e) {
  let t = w.string().check(
    w.refine((o) => typeof o == "string" && o.length > 0, {
      message: `Invalid ID for table "${e}"`
    }),
    w.describe(`convexId:${e}`)
  );
  Mx.setMetadata(t, {
    isConvexId: !0,
    tableName: e
  });
  let r = t;
  return r._tableName = e, r;
}
s(ci, "id");
function ym(e) {
  return e instanceof ce || e instanceof Je;
}
s(ym, "isZodUnion");
function $m(e) {
  return e instanceof ce, e._zod.def.options;
}
s($m, "getUnionOptions");
function Jx(e) {
  if (e.length < 2)
    throw new Error(
      `z.union() requires at least 2 options, but received ${e.length}. This indicates an invalid union schema was passed to zodTable().`
    );
}
s(Jx, "assertUnionOptions");
function bm(e) {
  return Jx(e), w.union(e);
}
s(bm, "createUnionFromOptions");
function Hl(e, t) {
  if (ym(t)) {
    let o = $m(t).map((n) => {
      if (n instanceof Y) {
        let i = {
          ...n._zod.def.shape,
          _id: ci(e),
          _creationTime: w.number()
        };
        return E(n, { ...n._zod.def, shape: i });
      }
      return n;
    });
    return bm(o);
  }
  if (t instanceof Y) {
    let r = { ...t._zod.def.shape, _id: ci(e), _creationTime: w.number() };
    return E(t, { ...t._zod.def, shape: r });
  }
  return t;
}
s(Hl, "addSystemFields");
function qx(e) {
  return e instanceof X ? e : new X({ type: "optional", innerType: e });
}
s(qx, "ensureOptional");
function lm(e) {
  return new X({
    type: "optional",
    innerType: new Ie({ type: "nullable", innerType: e })
  });
}
s(lm, "nullableOptional2");
function Wx(e) {
  let t = {};
  for (let [r, o] of Object.entries(e))
    t[r] = qx(o);
  return t;
}
s(Wx, "createPartialShape");
function Gl(e, t) {
  return w.object({
    _id: ci(e),
    _creationTime: w.optional(w.number()),
    ...Wx(t)
  });
}
s(Gl, "createUpdateObjectSchema");
function _m(e) {
  return w.object({
    page: w.array(e),
    isDone: w.boolean(),
    continueCursor: w.string(),
    splitCursor: lm(w.string()),
    pageStatus: lm(w.enum(["SplitRecommended", "SplitRequired"]))
  });
}
s(_m, "createPaginatedDocSchema");
function Kx(e, t, r = w.object(t)) {
  let o = Hl(e, r);
  return {
    doc: o,
    base: r,
    insert: r,
    update: Gl(e, t),
    docArray: w.array(o),
    paginatedDoc: _m(o)
  };
}
s(Kx, "createObjectSchemaBundle");
function xm(e, t) {
  if (ym(t)) {
    let r = $m(t).map((o) => o instanceof Y ? Gl(e, o._zod.def.shape) : o);
    return bm(r);
  }
  return t instanceof Y ? Gl(e, t._zod.def.shape) : t;
}
s(xm, "createSchemaUpdateSchema");
function Gx(e, t) {
  let r = Hl(e, t);
  return {
    doc: r,
    base: t,
    insert: t,
    update: xm(e, t),
    docArray: w.array(r),
    paginatedDoc: _m(r)
  };
}
s(Gx, "createSchemaBundle");
function wm(e, t) {
  let r;
  return {
    get: /* @__PURE__ */ s(() => r || (r = t ?? w.object(e), r), "get")
  };
}
s(wm, "lazyValidator");
function Pn(e, t, r, o, n = {}, i = {}, a = {}, u = null) {
  let c = wm(t, u), l = {
    name: e,
    fields: t,
    schema: r,
    indexes: n,
    searchIndexes: i,
    vectorIndexes: a,
    get validator() {
      return c.get();
    },
    index(d, f) {
      return Pn(
        e,
        t,
        r,
        o,
        { ...n, [d]: [...f, "_creationTime"] },
        i,
        a,
        u
      );
    },
    searchIndex(d, f) {
      return Pn(
        e,
        t,
        r,
        o,
        n,
        { ...i, [d]: f },
        a,
        u
      );
    },
    vectorIndex(d, f) {
      return Pn(
        e,
        t,
        r,
        o,
        n,
        i,
        { ...a, [d]: f },
        u
      );
    }
  };
  return hm(l, { type: "model", tableName: e, definitionSource: o, schemas: r }), l;
}
s(Pn, "createModel");
function Tn(e, t, r, o, n = {}, i = {}, a = {}) {
  let u = wm(t, r), c = {
    name: e,
    fields: t,
    indexes: n,
    searchIndexes: i,
    vectorIndexes: a,
    get validator() {
      return u.get();
    },
    index(l, d) {
      return Tn(
        e,
        t,
        r,
        o,
        { ...n, [l]: [...d, "_creationTime"] },
        i,
        a
      );
    },
    searchIndex(l, d) {
      return Tn(
        e,
        t,
        r,
        o,
        n,
        { ...i, [l]: d },
        a
      );
    },
    vectorIndex(l, d) {
      return Tn(e, t, r, o, n, i, {
        ...a,
        [l]: d
      });
    }
  };
  return r !== null && (c.schema = r), hm(c, { type: "model", tableName: e, definitionSource: o }), c;
}
s(Tn, "createSlimModel");
function dm(e, t, r) {
  let o = r?.schemaHelpers === !1;
  if (t instanceof S)
    return o ? Tn(e, {}, t, "schema") : Pn(
      e,
      {},
      Gx(e, t),
      "schema",
      void 0,
      void 0,
      void 0,
      t
    );
  let n = t;
  return o ? Tn(e, n, null, "shape") : Pn(e, n, Kx(e, n), "shape");
}
s(dm, "defineZodModel");
function Im(e, t, r) {
  return t instanceof S, dm(e, t, r);
}
s(Im, "defineZodModel2");
function Xx() {
  return Rx(
    vm(
      w.number(),
      // Wire: timestamp
      w.custom((e) => e instanceof Date, {
        message: "Expected Date instance"
      }),
      {
        decode: /* @__PURE__ */ s((e) => new Date(e), "decode"),
        encode: /* @__PURE__ */ s((e) => e.getTime(), "encode")
      }
    )
  );
}
s(Xx, "date");
function Hx(e, t, r, o) {
  let n = vm(e, t, r);
  return o?.brand && Bx(n, o.brand), n;
}
s(Hx, "codec");
function li(e) {
  let t = /* @__PURE__ */ Symbol.for(`zodvex.zx.cache.${e}`), r = globalThis, o = r[t];
  if (o) return o;
  let n = /* @__PURE__ */ new WeakMap();
  return r[t] = n, n;
}
s(li, "sharedWeakMap");
var fm = li("base"), pm = li("doc"), mm = li("update"), gm = li("docArray");
function Ql(e) {
  let t = e.schema;
  return t instanceof S ? t : e.fields;
}
s(Ql, "slimCacheKey");
function Yl(e) {
  let t = e.schema;
  if (t?.base instanceof S) return t.base;
  if (t instanceof S) return t;
  let r = fm.get(e.fields);
  if (r) return r;
  if (Object.keys(e.fields).length === 0)
    throw new Error(`[zodvex] Cannot derive base schema for model '${e.name}'`);
  let o = w.object(e.fields);
  return fm.set(e.fields, o), o;
}
s(Yl, "base");
function km(e) {
  let t = e.schema;
  if (t?.doc instanceof S) return t.doc;
  let r = Ql(e), o = pm.get(r);
  if (o) return o;
  let n = Hl(e.name, Yl(e));
  return pm.set(r, n), n;
}
s(km, "doc");
function Qx(e) {
  let t = e.schema;
  if (t?.update instanceof S) return t.update;
  let r = Ql(e), o = mm.get(r);
  if (o) return o;
  let n = xm(e.name, Yl(e));
  return mm.set(r, n), n;
}
s(Qx, "update");
function Yx(e) {
  let t = e.schema;
  if (t?.docArray instanceof S) return t.docArray;
  let r = Ql(e), o = gm.get(r);
  if (o) return o;
  let n = w.array(km(e));
  return gm.set(r, n), n;
}
s(Yx, "docArray");
function zm(e) {
  return new Ie({ type: "nullable", innerType: e });
}
s(zm, "nullable");
function ui(e) {
  return new X({ type: "optional", innerType: e });
}
s(ui, "optional");
function Xl(e) {
  return ui(zm(e));
}
s(Xl, "nullableOptional3");
function ew() {
  return w.object({
    numItems: w.number(),
    cursor: zm(w.string()),
    endCursor: Xl(w.string()),
    id: ui(w.number()),
    maximumRowsRead: ui(w.number()),
    maximumBytesRead: ui(w.number())
  });
}
s(ew, "paginationOpts");
function tw(e) {
  return w.object({
    page: w.array(e),
    isDone: w.boolean(),
    continueCursor: w.string(),
    splitCursor: Xl(w.string()),
    pageStatus: Xl(w.enum(["SplitRecommended", "SplitRequired"]))
  });
}
s(tw, "paginationResult");
var Ee = {
  /**
   * Date ↔ timestamp codec
   * @see {@link date}
   */
  date: Xx,
  /**
   * Convex ID validator
   * @see {@link id}
   */
  id: ci,
  /**
   * Custom codec builder
   * @see {@link codec}
   */
  codec: Hx,
  /**
   * Pagination options schema matching Convex's PaginationOptions type
   * @see {@link paginationOpts}
   */
  paginationOpts: ew,
  /**
   * Paginated result schema wrapping any item schema in Convex's PaginationResult shape
   * @see {@link paginationResult}
   */
  paginationResult: tw,
  /**
   * Base schema for a model (user fields only; no system fields).
   * For object models reconstructs from fields; for union models returns the
   * user-supplied union. Cached per-model.
   * @see {@link base}
   */
  base: Yl,
  /**
   * Doc schema: model fields + _id + _creationTime
   * @see {@link doc}
   */
  doc: km,
  /**
   * Update schema: _id required, all other fields optional
   * @see {@link update}
   */
  update: Qx,
  /**
   * Doc array schema: z.array(doc(model))
   * @see {@link docArray}
   */
  docArray: Yx
};
function nw() {
  return Ee.date();
}
s(nw, "date2");
function rw(e) {
  return Ee.id(e);
}
s(rw, "id2");
function iw(e, t, r, o) {
  return Ee.codec(e, t, r, o);
}
s(iw, "codec2");
var z6 = {
  date: nw,
  id: rw,
  codec: iw,
  paginationOpts: Ee.paginationOpts,
  paginationResult: Ee.paginationResult,
  base: Ee.base,
  doc: Ee.doc,
  update: Ee.update,
  docArray: Ee.docArray
};

// ../../node_modules/.bun/convex-helpers@0.1.113+b9ed8f5244cf7f28/node_modules/convex-helpers/index.js
var O6 = Symbol();

// ../../node_modules/.bun/convex-helpers@0.1.113+b9ed8f5244cf7f28/node_modules/convex-helpers/validators.js
var A6 = y.string(), E6 = y.float64(), C6 = y.float64(), Z6 = y.boolean(), F6 = y.int64(), M6 = y.int64(), R6 = y.any(), L6 = y.null(), { id: V6, object: B6, array: J6, bytes: q6, literal: W6, optional: K6, union: G6 } = y, X6 = y.bytes();
var H6 = y.optional(y.any());

// ../../node_modules/.bun/convex-helpers@0.1.113+b9ed8f5244cf7f28/node_modules/convex-helpers/server/customFunctions.js
var di = {
  args: {},
  input() {
    return { args: {}, ctx: {} };
  }
};

// ../../packages/zodvex/dist/mini/server/index.js
function Sm(e) {
  let t = e;
  for (let r = 0; r < 10; r++) {
    if (t instanceof X || t instanceof Ie || t instanceof $e) {
      t = t._zod.def.innerType;
      continue;
    }
    break;
  }
  return t;
}
s(Sm, "unwrapOuter");
function ow(e, t) {
  let r = [], o = t;
  for (let n of e) {
    if (o = Sm(o), o instanceof je)
      break;
    if (o instanceof Y && typeof n == "string") {
      let i = o._zod.def.shape[n];
      if (!i) {
        r.push(n);
        break;
      }
      if (r.push(n), Sm(i) instanceof je)
        break;
      o = i;
      continue;
    }
    if (o instanceof Be && typeof n == "number") {
      r.push(n), o = o._zod.def.element;
      continue;
    }
    r.push(n);
  }
  return r;
}
s(ow, "truncateAtCodecBoundary");
function aw(e, t) {
  let r = e.issues.map((o) => ({
    ...o,
    path: ow(o.path, t)
  }));
  return new Ae(r);
}
s(aw, "normalizeCodecPaths");
function sw(e, t) {
  try {
    return se(e, t);
  } catch (r) {
    throw r instanceof Ae ? aw(r, e) : r;
  }
}
s(sw, "safeEncode");
function Qe(e) {
  if (e == null)
    return e;
  if (Array.isArray(e))
    return e.map(Qe);
  if (typeof e == "object" && e.constructor === Object) {
    let t = {};
    for (let [r, o] of Object.entries(e))
      o !== void 0 && (t[r] = Qe(o));
    return t;
  }
  return e;
}
s(Qe, "stripUndefined");
var uw = /* @__PURE__ */ Symbol.for("functionName");
function jm(e) {
  if (typeof e == "string") return e;
  let t = e[uw];
  return t || null;
}
s(jm, "resolveFunctionPath");
var cw = class extends Ae {
  static {
    s(this, "ZodvexDecodeError");
  }
  functionPath;
  wireData;
  constructor(e, t, r) {
    super(t), this.functionPath = e, this.wireData = r, this.name = "ZodvexDecodeError";
  }
}, Om = /* @__PURE__ */ new Set();
function lw(e, t) {
  let r = t?.onDecodeError ?? "warn", o = t?.warnWirePreview === !0;
  function n(a, u) {
    if (u == null) return u;
    let c = jm(a);
    if (c == null) return u;
    let l = e[c];
    return l?.args ? Qe(sw(l.args, u)) : (l === void 0 && !Om.has(c) && (Om.add(c), console.debug(
      `[zodvex] No registry entry for "${c}" \u2014 args/returns pass through unencoded. This is expected when the target is a raw (non-zodvex) function; if it should be codec-aware, run \`zodvex generate\` to update the registry.`
    )), u);
  }
  s(n, "encodeArgs");
  function i(a, u) {
    let c = jm(a);
    if (c == null) return u;
    let l = e[c];
    if (!l?.returns) return u;
    let d = Se(l.returns, u);
    if (d.success) return d.data;
    if (r === "throw")
      throw new cw(c, d.error.issues, u);
    let f = d.error.issues.map((h) => `${h.path.join(".")}: ${h.message}`).join(", "), p = `[zodvex] Decode failed for ${c}: ${f}. Returning raw wire data.`;
    if (o) {
      let h = "[unavailable]";
      try {
        h = JSON.stringify(u) ?? "[unavailable]";
      } catch {
      }
      let v = h.length > 200 ? `${h.slice(0, 200)}...` : h;
      p += ` Preview: ${v}`;
    }
    return console.warn(p), u;
  }
  return s(i, "decodeResult"), { encodeArgs: n, decodeResult: i };
}
s(lw, "createBoundaryHelpers");
function Dm(e, t) {
  return async (r, ...o) => {
    let n = t.encodeArgs(r, o[0]), i = await e(r, n);
    return t.decodeResult(r, i);
  };
}
s(Dm, "wrapRun");
function dw(e, t) {
  let r = { ...e };
  return r.runAfter = (o, n, ...i) => {
    let a = t.encodeArgs(n, i[0]);
    return e.runAfter(o, n, ...i.length ? [a] : []);
  }, r.runAt = (o, n, ...i) => {
    let a = t.encodeArgs(n, i[0]);
    return e.runAt(o, n, ...i.length ? [a] : []);
  }, r;
}
s(dw, "wrapScheduler");
function Hm(e, t, r) {
  let o = lw(e, r), n = {};
  return typeof t.runQuery == "function" && (n.runQuery = Dm(t.runQuery, o)), typeof t.runMutation == "function" && (n.runMutation = Dm(t.runMutation, o)), t.scheduler && (n.scheduler = dw(t.scheduler, o)), n;
}
s(Hm, "createCodecCallOverrides");
var Pm = /* @__PURE__ */ new WeakMap(), gi = {
  getMetadata: /* @__PURE__ */ s((e) => Pm.get(e), "getMetadata"),
  setMetadata: /* @__PURE__ */ s((e, t) => Pm.set(e, t), "setMetadata")
};
function fw(e) {
  let t = e._zod.def.entries, r = Object.keys(t);
  if (r && Array.isArray(r) && r.length > 0) {
    let o = r.filter((n) => n != null).map((n) => y.literal(n));
    if (o.length === 1) {
      let [n] = o;
      return n;
    } else if (o.length >= 2) {
      let [n, i, ...a] = o;
      return y.union(
        n,
        i,
        ...a
      );
    } else
      return y.any();
  } else
    return y.any();
}
s(fw, "convertEnumType");
function pw(e, t, r) {
  let o = e._zod.def.innerType;
  if (o && o instanceof S)
    if (o instanceof X) {
      let n = o._zod.def.innerType, i = r(n, t);
      return {
        validator: y.union(i, y.null()),
        isOptional: !0
        // Mark as optional so it gets wrapped later
      };
    } else {
      let n = r(o, t);
      return {
        validator: y.union(n, y.null()),
        isOptional: !1
      };
    }
  else
    return {
      validator: y.any(),
      isOptional: !1
    };
}
s(pw, "convertNullableType");
function mw(e, t, r) {
  let o = e._zod.def.valueType;
  if (o || (o = e._zod.def.keyType), o && o instanceof S)
    if (o instanceof X || o instanceof $e || o instanceof $e && o._zod.def.innerType instanceof X) {
      let i, a, u = !1;
      if (o instanceof $e) {
        u = !0, a = o._zod.def.defaultValue;
        let d = o._zod.def.innerType;
        d instanceof X ? i = d._zod.def.innerType : i = d;
      } else o instanceof X ? i = o._zod.def.innerType : i = o;
      let c = r(i, t), l = y.union(c, y.null());
      return u && (l._zodDefault = a), y.record(y.string(), l);
    } else
      return y.record(y.string(), r(o, t));
  else
    return y.record(y.string(), y.any());
}
s(mw, "convertRecordType");
function gw(e, t, r) {
  let o = e instanceof Je ? e._zod.def.options : (
    // cast: fallback for non-standard discriminated union variants
    e._zod?.def?.options
  );
  if (o) {
    let n = Array.isArray(o) ? o : Array.from(o);
    if (n.length >= 2) {
      let i = n.map((l) => {
        let d = new Set(t);
        return r(l, d);
      }), [a, u, ...c] = i;
      return y.union(
        a,
        u,
        ...c
      );
    } else
      return y.any();
  } else
    return y.any();
}
s(gw, "convertDiscriminatedUnionType");
function hw(e, t, r) {
  let o = e._zod.def.options;
  if (o && Array.isArray(o) && o.length > 0) {
    if (o.length === 1)
      return r(o[0], t);
    {
      let n = o.map((i) => {
        let a = new Set(t);
        return r(i, a);
      });
      if (n.length >= 2) {
        let [i, a, ...u] = n;
        return y.union(
          i,
          a,
          ...u
        );
      } else
        return y.any();
    }
  } else
    return y.any();
}
s(hw, "convertUnionType");
function vw(e) {
  let t = gi.getMetadata(e);
  return t?.isConvexId === !0 && t?.tableName && typeof t.tableName == "string";
}
s(vw, "isZid");
var Tm = /* @__PURE__ */ new WeakMap();
function ye(e, t = /* @__PURE__ */ new Set()) {
  if (!e)
    return y.any();
  let r = Tm.get(e);
  if (r)
    return r;
  if (t.has(e))
    return y.any();
  t.add(e);
  let o = e, n = !1, i, a = !1;
  e instanceof $e && (a = !0, i = e._zod.def.defaultValue, o = e._zod.def.innerType), o instanceof X && (n = !0, o = o._zod.def.innerType, o instanceof $e && (a = !0, i = o._zod.def.defaultValue, o = o._zod.def.innerType));
  let u;
  if (vw(o)) {
    let d = gi.getMetadata(o)?.tableName || "unknown";
    u = y.id(d);
  } else
    switch (o._zod.def.type) {
      case "string":
        u = y.string();
        break;
      case "number":
        u = y.float64();
        break;
      case "bigint":
        u = y.int64();
        break;
      case "boolean":
        u = y.boolean();
        break;
      case "date":
        u = y.float64();
        break;
      case "null":
        u = y.null();
        break;
      case "nan":
        u = y.float64();
        break;
      case "array": {
        if (o instanceof Be) {
          let d = o._zod.def.element;
          u = y.array(ye(d, t));
        } else
          u = y.array(y.any());
        break;
      }
      case "object": {
        if (o instanceof Y) {
          let d = o._zod.def.shape, f = {};
          for (let [p, h] of Object.entries(d))
            h && h instanceof S && (f[p] = ye(h, t));
          u = y.object(f);
        } else
          u = y.object({});
        break;
      }
      case "union": {
        o instanceof ce ? u = hw(o, t, ye) : u = y.any();
        break;
      }
      case "discriminatedUnion": {
        u = gw(
          o,
          t,
          ye
        );
        break;
      }
      case "literal": {
        if (o instanceof Ut) {
          let f = o._zod.def.values.values().next().value;
          f != null ? u = y.literal(f) : u = y.any();
        } else
          u = y.any();
        break;
      }
      case "enum": {
        o instanceof Nt ? u = fw(o) : u = y.any();
        break;
      }
      case "record": {
        o instanceof dt ? u = mw(o, t, ye) : u = y.record(y.string(), y.any());
        break;
      }
      case "transform":
      case "pipe": {
        if (o instanceof je) {
          let d = o._zod.def.in;
          d && d instanceof S ? u = ye(d, t) : u = y.any();
        } else {
          let d = gi.getMetadata(o);
          if (d?.brand && d?.originalSchema)
            u = ye(d.originalSchema, t);
          else {
            let f = o._zod?.def?.in;
            f && f instanceof S ? u = ye(f, t) : u = y.any();
          }
        }
        break;
      }
      case "nullable": {
        if (o instanceof Ie) {
          let d = pw(o, t, ye);
          u = d.validator, d.isOptional && (n = !0);
        } else
          u = y.any();
        break;
      }
      case "tuple": {
        if (o instanceof qe) {
          let d = o._zod.def.items;
          if (d && d.length > 0) {
            let f = {};
            d.forEach((p, h) => {
              f[`_${h}`] = ye(p, t);
            }), u = y.object(f);
          } else
            u = y.object({});
        } else
          u = y.object({});
        break;
      }
      case "lazy": {
        if (o instanceof We)
          try {
            let d = o._zod.def.getter;
            if (d) {
              let f = d();
              f && f instanceof S ? u = ye(f, t) : u = y.any();
            } else
              u = y.any();
          } catch {
            u = y.any();
          }
        else
          u = y.any();
        break;
      }
      case "any":
        u = y.any();
        break;
      case "unknown":
        u = y.any();
        break;
      case "undefined":
      case "void":
      case "never":
        u = y.any();
        break;
      case "intersection":
        u = y.any();
        break;
      case "optional": {
        let d = o._zod?.def?.innerType;
        d && d instanceof S ? (u = ye(d, t), n = !0) : (u = y.any(), n = !0);
        break;
      }
      default:
        u = y.any();
        break;
    }
  let c = n || a ? y.optional(u) : u;
  return a && typeof c == "object" && c !== null && (c._zodDefault = i), Tm.set(e, c), c;
}
s(ye, "zodToConvexInternal");
function Qm(e) {
  return typeof e == "object" && e !== null && !(e instanceof S) ? hi(e) : ye(e);
}
s(Qm, "zodToConvex");
function hi(e) {
  let t = e instanceof Y ? e._zod.def.shape : e, r = {};
  for (let [o, n] of Object.entries(t))
    r[o] = ye(n);
  return r;
}
s(hi, "zodToConvexFields");
function ht(e) {
  if (e instanceof Tt) return !0;
  if (e instanceof je) return !1;
  if (e instanceof X || e instanceof Ie || e instanceof $e)
    return ht(e._zod.def.innerType);
  if (e instanceof Y)
    return Object.values(e._zod.def.shape).some((t) => ht(t));
  if (e instanceof Be)
    return ht(e._zod.def.element);
  if (e instanceof ce)
    return e._zod.def.options.some((t) => ht(t));
  if (e instanceof dt)
    return ht(e._zod.def.valueType);
  if (e instanceof qe) {
    let t = e._zod.def.items;
    return t ? t.some((r) => ht(r)) : !1;
  }
  return !1;
}
s(ht, "containsNativeZodDate");
function Nm(e, t) {
  if (ht(e))
    throw new Error(
      `[zodvex] Native z.date() found in ${t}. Convex stores dates as timestamps (numbers), which z.date() cannot parse.

Fix: Replace z.date() with zx.date()

Before: { createdAt: z.date() }
After:  { createdAt: zx.date() }

zx.date() is a codec that handles timestamp \u2194 Date conversion automatically.`
    );
}
s(Nm, "assertNoNativeZodDate");
function Ym(e, t) {
  return ve(e, t);
}
s(Ym, "decodeDoc");
function Um(e, t) {
  return Qe(se(e, t));
}
s(Um, "encodeDoc");
function Am(e) {
  let t = {};
  for (let [r, o] of Object.entries(e))
    t[r] = o === void 0 ? void 0 : Qe(o);
  return t;
}
s(Am, "stripUndefinedPreservingTopLevel");
function yw(e, t) {
  if (!(e instanceof Y)) {
    let a = se(e, t);
    return a !== null && typeof a == "object" && !Array.isArray(a) ? Am(a) : Qe(a);
  }
  let r = e._zod.def.shape, o = {};
  for (let [a, u] of Object.entries(r))
    o[a] = u instanceof X ? u : new X({ type: "optional", innerType: u });
  let n = w.object(o), i = se(n, t);
  return Am(i);
}
s(yw, "encodePartialDoc");
function eg(e, t, r) {
  return w.codec(e, t, r);
}
s(eg, "zodvexCodec");
function ed(e, t, r) {
  if (t.includes(".")) return r;
  if (e instanceof Y) {
    let o = e.shape[t];
    if (o) return se(o, r);
  }
  if (e instanceof ce) {
    let n = e._zod.def.options.filter((i) => i instanceof Y).map((i) => i.shape[t]).filter(Boolean);
    if (n.length === 1) return se(n[0], r);
    if (n.length > 1)
      return se(w.union(n), r);
  }
  return r;
}
s(ed, "encodeIndexValue");
function vi(e, t) {
  return new Proxy(e, {
    get(r, o, n) {
      return typeof o == "string" && ["eq", "gt", "gte", "lt", "lte"].includes(o) ? (i, a) => {
        let u = ed(t, i, a), c = r[o](i, u);
        return vi(c, t);
      } : o === "search" ? (...i) => {
        let a = r.search(...i);
        return vi(a, t);
      } : Reflect.get(r, o, n);
    }
  });
}
s(vi, "wrapIndexRangeBuilder");
function td(e, t) {
  return e != null && Object.prototype.isPrototypeOf.call(t, e);
}
s(td, "isFilterExpression");
function Em(e, t) {
  if (td(e, t)) {
    let r = e.serialize();
    if (r && typeof r == "object" && "$field" in r)
      return r.$field;
  }
  return null;
}
s(Em, "extractFieldPath");
function $w(e, t) {
  let r = Object.getPrototypeOf(e.field("_id"));
  return new Proxy(e, {
    get(o, n, i) {
      return typeof n == "string" && ["eq", "neq", "lt", "lte", "gt", "gte"].includes(n) ? (a, u) => {
        let c = Em(a, r), l = Em(u, r);
        return c && !td(u, r) ? u = ed(t, c, u) : l && !td(a, r) && (a = ed(t, l, a)), o[n](a, u);
      } : Reflect.get(o, n, i);
    }
  });
}
s($w, "wrapFilterBuilder");
var ad = class tg {
  static {
    s(this, "_ZodvexQueryChain");
  }
  constructor(t, r) {
    this.inner = t, this.schema = r;
  }
  /** Factory method for intermediate methods. Subclasses override to return their own type. */
  createChain(t) {
    return new tg(t, this.schema);
  }
  /** Decode a wire-format doc and cast to the decoded document type. */
  decode(t) {
    return Ym(this.schema, t);
  }
  // --- Intermediate methods: wire-typed TableInfo for Convex machinery ---
  fullTableScan() {
    return this.createChain(this.inner.fullTableScan());
  }
  withIndex(t, r) {
    let o = r ? (n) => r(vi(n, this.schema)) : void 0;
    return this.createChain(this.inner.withIndex(t, o));
  }
  withSearchIndex(t, r) {
    let o = /* @__PURE__ */ s((n) => r(vi(n, this.schema)), "wrappedFilter");
    return this.createChain(this.inner.withSearchIndex(t, o));
  }
  order(t) {
    return this.createChain(this.inner.order(t));
  }
  // Implementation
  filter(t) {
    let r = /* @__PURE__ */ s((o) => t($w(o, this.schema)), "wrappedPredicate");
    return this.createChain(this.inner.filter(r));
  }
  limit(t) {
    return this.createChain(this.inner.limit(t));
  }
  count() {
    return this.inner.count();
  }
  // --- Terminal methods: return decoded Doc type ---
  async first() {
    let t = await this.inner.first();
    return t ? this.decode(t) : null;
  }
  async unique() {
    let t = await this.inner.unique();
    return t ? this.decode(t) : null;
  }
  async collect() {
    return (await this.inner.collect()).map((r) => this.decode(r));
  }
  async take(t) {
    return (await this.inner.take(t)).map((o) => this.decode(o));
  }
  async paginate(t) {
    let r = await this.inner.paginate(t);
    return {
      ...r,
      page: r.page.map((o) => this.decode(o))
    };
  }
  // --- AsyncIterable: decode each yielded document ---
  async *[Symbol.asyncIterator]() {
    for await (let t of this.inner)
      yield this.decode(t);
  }
};
function nd(e, t, r) {
  for (let o of Object.keys(t))
    if (e.normalizeId(o, r))
      return o;
  return null;
}
s(nd, "resolveTableName");
var $i = class {
  static {
    s(this, "ZodvexDatabaseReader");
  }
  constructor(e, t) {
    this.db = e, this.tableMap = t, this.system = e.system;
  }
  system;
  /** @internal Expose for wrapper construction (rule/audit subclasses) */
  get _internals() {
    return { db: this.db, tableMap: this.tableMap };
  }
  /**
   * Escape hatch (#85/#92): returns the database this codec wrapper delegates
   * to — the composed underlying stack when `underlyingDb` is configured (e.g.
   * a trigger-wrapped writer), the bare Convex db otherwise.
   *
   * The returned db is native-shape: reads are undecoded wire documents and it
   * bypasses codec, `.withRules()`, and `.audit()` layers entirely.
   */
  unwrap() {
    return this.db;
  }
  normalizeId(e, t) {
    return this.db.normalizeId(e, t);
  }
  async get(e, t) {
    let r, o;
    if (t !== void 0 ? (r = e, o = await this.db.get(e, t)) : (o = await this.db.get(e), r = o ? nd(this.db, this.tableMap, e) : null), !o) return null;
    let n = r ? this.tableMap[r] : void 0;
    return n ? Ym(n.doc, o) : o;
  }
  query(e) {
    let t = this.tableMap[e], r = this.db.query(e);
    return t ? new ad(r, t.doc) : r;
  }
  /**
   * Returns a new ZodvexDatabaseReader that applies per-table read rules.
   * The returned reader is also a ZodvexDatabaseReader, so `.withRules()` can be chained.
   */
  withRules(e, t, r) {
    return new rg(this, e, t, r ?? {});
  }
  /**
   * Returns a new ZodvexDatabaseReader that fires audit callbacks on reads.
   * The returned reader is also a ZodvexDatabaseReader, so `.audit()` can be chained
   * with `.withRules()`.
   */
  audit(e) {
    return new og(this, e);
  }
}, sd = class extends $i {
  static {
    s(this, "ZodvexDatabaseWriter");
  }
  // Narrows the inherited `protected db` to the writer-typed view without
  // shadowing the underlying instance. Used by the write methods below.
  get writerDb() {
    return this.db;
  }
  constructor(e, t) {
    super(e, t), this.system = e.system;
  }
  /**
   * @internal Expose writer-typed internals for rules / audit subclasses.
   * Includes a `reader` field that aliases `this` (writer IS-A reader after
   * the #64 refactor) so callers expecting `_internals.reader` still work.
   */
  get _internals() {
    return { db: this.writerDb, tableMap: this.tableMap, reader: this };
  }
  /**
   * Escape hatch (#85/#92): returns the writer this codec wrapper delegates
   * to — the composed underlying stack when `underlyingDb` is configured (e.g.
   * a trigger-wrapped writer), the bare Convex db otherwise.
   *
   * The returned db is native-shape: writes must be wire-format and it
   * bypasses codec, `.withRules()`, and `.audit()` layers entirely.
   */
  unwrap() {
    return this.writerDb;
  }
  async insert(e, t) {
    let r = this.tableMap[e], o = r ? Um(r.insert, t) : t;
    return this.writerDb.insert(e, o);
  }
  async patch(e, t, r) {
    let o, n, i;
    r !== void 0 ? (o = e, n = t, i = r) : (n = e, i = t, o = nd(this.db, this.tableMap, n));
    let a = o ? this.tableMap[o] : void 0, u = a ? yw(a.insert, i) : i;
    return r !== void 0 ? this.writerDb.patch(e, n, u) : this.writerDb.patch(n, u);
  }
  async replace(e, t, r) {
    let o, n, i;
    r !== void 0 ? (o = e, n = t, i = r) : (n = e, i = t, o = nd(this.db, this.tableMap, n));
    let a = o ? this.tableMap[o] : void 0, u = a ? Um(a.insert, i) : i;
    return r !== void 0 ? this.writerDb.replace(e, n, u) : this.writerDb.replace(n, u);
  }
  async delete(e, t) {
    return t !== void 0 ? this.writerDb.delete(e, t) : this.writerDb.delete(e);
  }
  /**
   * Returns a new ZodvexDatabaseWriter that applies per-table read and write rules.
   * The returned writer is also a ZodvexDatabaseWriter, so `.withRules()` can be chained.
   *
   * Overrides Reader's signature so a writer chained call returns a writer.
   */
  withRules(e, t, r) {
    return new _w(this, e, t, r ?? {});
  }
  /**
   * Returns a new ZodvexDatabaseWriter that fires audit callbacks on reads and writes.
   * The returned writer is also a ZodvexDatabaseWriter, so `.audit()` can be chained
   * with `.withRules()`.
   *
   * Overrides Reader's signature so a writer chained call returns a writer.
   */
  audit(e) {
    return new ww(this, e);
  }
};
function fi(e, t) {
  return e === !0 ? t : e === !1 ? null : e;
}
s(fi, "normalizeReadResult");
var bw = class ng extends ad {
  static {
    s(this, "_RulesQueryChain");
  }
  readRule;
  rulesConfig;
  ctx;
  constructor(t, r, o, n, i = {}) {
    super(t, r), this.readRule = o, this.rulesConfig = n, this.ctx = i;
  }
  createChain(t) {
    return new ng(t, this.schema, this.readRule, this.rulesConfig, this.ctx);
  }
  async first() {
    for await (let t of this)
      return t;
    return null;
  }
  async unique() {
    let t = await super.unique();
    return t === null ? null : fi(await this.readRule(this.ctx, t), t);
  }
  async collect() {
    let t = [];
    for await (let r of this)
      t.push(r);
    return t;
  }
  async take(t) {
    if (!Number.isInteger(t) || t < 0)
      throw new Error("take requires a non-negative integer");
    let r = [];
    if (t === 0) return r;
    for await (let o of this)
      if (r.push(o), r.length >= t) break;
    return r;
  }
  async paginate(t) {
    let r = await super.paginate(t), o = [];
    for (let n of r.page) {
      let i = fi(await this.readRule(this.ctx, n), n);
      i !== null && o.push(i);
    }
    return { ...r, page: o };
  }
  async count() {
    if (!this.rulesConfig.allowCounting)
      throw new Error("count is not allowed with rules");
    return super.count();
  }
  async *[Symbol.asyncIterator]() {
    for await (let t of super[Symbol.asyncIterator]()) {
      let r = fi(await this.readRule(this.ctx, t), t);
      r !== null && (yield r);
    }
  }
};
function pi(e, t, r, o) {
  for (let n of Object.keys(r))
    if (e.normalizeId(n, t))
      return n;
  if ((o.defaultPolicy ?? "allow") === "deny") {
    for (let n of Object.keys(e._internals.tableMap))
      if (e.normalizeId(n, t))
        return n;
  }
  return null;
}
s(pi, "resolveRulesTableName");
var rg = class extends $i {
  static {
    s(this, "RulesDatabaseReader");
  }
  constructor(e, t, r, o) {
    let { db: n, tableMap: i } = e._internals;
    super(n, i), this.inner = e, this.ctx = t, this.rules = r, this.rulesConfig = o, this.system = e.system;
  }
  async get(e, t) {
    let r = await this.inner.get(e, t);
    if (r === null) return null;
    let o = t !== void 0 ? e : pi(this.inner, e, this.rules, this.rulesConfig);
    return o ? this.applyReadRule(o, r) : r;
  }
  query(e) {
    let t = this.rules[e];
    if (!t?.read && (this.rulesConfig.defaultPolicy ?? "allow") === "allow")
      return this.inner.query(e);
    let r = this.inner.query(e), o = t?.read ?? (async () => null), n = w.any();
    return new bw(r, n, o, this.rulesConfig, this.ctx);
  }
  async applyReadRule(e, t) {
    let r = this.rules[e];
    if (!r?.read)
      return (this.rulesConfig.defaultPolicy ?? "allow") === "deny" ? null : t;
    let o = await r.read(this.ctx, t);
    return fi(o, t);
  }
}, _w = class extends sd {
  static {
    s(this, "RulesDatabaseWriter");
  }
  constructor(e, t, r, o) {
    let { db: n, tableMap: i, reader: a } = e._internals;
    super(n, i), this.inner = e, this.ctx = t, this.rules = r, this.rulesConfig = o, this.rulesReader = new rg(a, t, r, o), this.system = e.system;
  }
  rulesReader;
  normalizeId(e, t) {
    return this.rulesReader.normalizeId(e, t);
  }
  async get(e, t) {
    return this.rulesReader.get(e, t);
  }
  query(e) {
    return this.rulesReader.query(e);
  }
  async insert(e, t) {
    let r = e, o = this.rules[r];
    if (o?.insert) {
      let n = await o.insert(this.ctx, t);
      return this.inner.insert(
        e,
        n
      );
    }
    if ((this.rulesConfig.defaultPolicy ?? "allow") === "deny")
      throw new Error(`insert not allowed on ${r}`);
    return this.inner.insert(e, t);
  }
  async patch(e, t, r) {
    let o, n;
    r !== void 0 ? (o = t, n = r) : (o = e, n = t);
    let i = await this.rulesReader.get(o);
    if (i === null)
      throw new Error("no read access or doc does not exist");
    let a = pi(this.inner, o, this.rules, this.rulesConfig), u = a ? this.rules[a] : void 0;
    if (u?.patch) {
      let c = await u.patch(this.ctx, i, n);
      return this.inner.patch(
        o,
        c
      );
    }
    if ((this.rulesConfig.defaultPolicy ?? "allow") === "deny")
      throw new Error(`patch not allowed on ${a}`);
    return this.inner.patch(o, n);
  }
  async replace(e, t, r) {
    let o, n;
    r !== void 0 ? (o = t, n = r) : (o = e, n = t);
    let i = await this.rulesReader.get(o);
    if (i === null)
      throw new Error("no read access or doc does not exist");
    let a = pi(this.inner, o, this.rules, this.rulesConfig), u = a ? this.rules[a] : void 0;
    if (u?.replace) {
      let c = await u.replace(this.ctx, i, n);
      return this.inner.replace(o, c);
    }
    if ((this.rulesConfig.defaultPolicy ?? "allow") === "deny")
      throw new Error(`replace not allowed on ${a}`);
    return this.inner.replace(o, n);
  }
  async delete(e, t) {
    let r;
    t !== void 0 ? r = t : r = e;
    let o = await this.rulesReader.get(r);
    if (o === null)
      throw new Error("no read access or doc does not exist");
    let n = pi(this.inner, r, this.rules, this.rulesConfig), i = n ? this.rules[n] : void 0;
    if (i?.delete)
      return await i.delete(this.ctx, o), this.inner.delete(r);
    if ((this.rulesConfig.defaultPolicy ?? "allow") === "deny")
      throw new Error(`delete not allowed on ${n}`);
    return this.inner.delete(r);
  }
}, xw = class ig extends ad {
  static {
    s(this, "_AuditQueryChain");
  }
  afterRead;
  tableName;
  constructor(t, r, o, n) {
    super(t, r), this.afterRead = o, this.tableName = n;
  }
  createChain(t) {
    return new ig(t, this.schema, this.afterRead, this.tableName);
  }
  async first() {
    let t = await super.first();
    return t !== null && await this.afterRead(this.tableName, t), t;
  }
  async unique() {
    let t = await super.unique();
    return t !== null && await this.afterRead(this.tableName, t), t;
  }
  async collect() {
    let t = await super.collect();
    for (let r of t)
      await this.afterRead(this.tableName, r);
    return t;
  }
  async take(t) {
    let r = await super.take(t);
    for (let o of r)
      await this.afterRead(this.tableName, o);
    return r;
  }
  async paginate(t) {
    let r = await super.paginate(t);
    for (let o of r.page)
      await this.afterRead(this.tableName, o);
    return r;
  }
  async *[Symbol.asyncIterator]() {
    for await (let t of super[Symbol.asyncIterator]())
      await this.afterRead(this.tableName, t), yield t;
  }
}, og = class extends $i {
  static {
    s(this, "AuditDatabaseReader");
  }
  inner;
  afterRead;
  constructor(e, t) {
    let { db: r, tableMap: o } = e._internals;
    super(r, o), this.inner = e, this.afterRead = t.afterRead ?? (() => {
    }), this.system = e.system;
  }
  async get(e, t) {
    let r = await this.inner.get(e, t);
    if (r !== null) {
      let o = this.resolveTableFromId(
        t !== void 0 ? t : e,
        t !== void 0 ? e : void 0
      );
      o && await this.afterRead(o, r);
    }
    return r;
  }
  query(e) {
    let t = this.inner.query(e), r = w.any();
    return new xw(t, r, this.afterRead, e);
  }
  resolveTableFromId(e, t) {
    if (t) return t;
    for (let r of Object.keys(this.tableMap))
      if (this.inner.normalizeId(r, e))
        return r;
    return null;
  }
}, ww = class extends sd {
  static {
    s(this, "AuditDatabaseWriter");
  }
  inner;
  auditReader;
  afterWrite;
  constructor(e, t) {
    let { db: r, tableMap: o, reader: n } = e._internals;
    super(r, o), this.inner = e, this.afterWrite = t.afterWrite, this.auditReader = t.afterRead ? new og(n, { afterRead: t.afterRead }) : n, this.system = e.system;
  }
  normalizeId(e, t) {
    return this.auditReader.normalizeId(e, t);
  }
  async get(e, t) {
    return this.auditReader.get(e, t);
  }
  query(e) {
    return this.auditReader.query(e);
  }
  async insert(e, t) {
    let r = await this.inner.insert(e, t);
    return this.afterWrite && await this.afterWrite(e, { type: "insert", id: r, value: t }), r;
  }
  async patch(e, t, r) {
    let o, n;
    r !== void 0 ? (o = t, n = r) : (o = e, n = t);
    let i = await this.inner.get(o);
    if (r !== void 0 ? await this.inner.patch(e, t, r) : await this.inner.patch(o, n), this.afterWrite) {
      let a = this.resolveTableFromId(o);
      a && await this.afterWrite(a, { type: "patch", id: o, doc: i, value: n });
    }
  }
  async replace(e, t, r) {
    let o, n;
    r !== void 0 ? (o = t, n = r) : (o = e, n = t);
    let i = await this.inner.get(o);
    if (r !== void 0 ? await this.inner.replace(e, t, r) : await this.inner.replace(o, n), this.afterWrite) {
      let a = this.resolveTableFromId(o);
      a && await this.afterWrite(a, { type: "replace", id: o, doc: i, value: n });
    }
  }
  async delete(e, t) {
    let r;
    t !== void 0 ? r = t : r = e;
    let o = await this.inner.get(r);
    if (t !== void 0 ? await this.inner.delete(e, t) : await this.inner.delete(r), this.afterWrite) {
      let n = this.resolveTableFromId(r);
      n && await this.afterWrite(n, { type: "delete", id: r, doc: o });
    }
  }
  resolveTableFromId(e) {
    for (let t of Object.keys(this.inner._internals.tableMap))
      if (this.inner.normalizeId(t, e))
        return t;
    return null;
  }
};
function Iw(e, t) {
  let r = t?.underlyingDb?.query, o = t?.underlyingDb?.mutation;
  return {
    query: {
      args: {},
      input: /* @__PURE__ */ s(async (n, i, a) => ({
        ctx: {
          db: new $i(r ? r(n) : n.db, e)
        },
        args: {}
      }), "input")
    },
    mutation: {
      args: {},
      input: /* @__PURE__ */ s(async (n, i, a) => ({
        ctx: {
          db: new sd(o ? o(n) : n.db, e)
        },
        args: {}
      }), "input")
    }
  };
}
s(Iw, "createZodvexCustomization");
function ag(e, t) {
  let r = {};
  for (let o of t)
    o in e && (r[o] = e[o]);
  return r;
}
s(ag, "pick");
var sg = "__zodvexMeta";
function kw(e, t) {
  Object.defineProperty(e, sg, {
    value: t,
    enumerable: !1,
    writable: !1,
    configurable: !1
  });
}
s(kw, "attachMeta");
function ug(e) {
  if (!(e == null || typeof e != "object" && typeof e != "function"))
    return e[sg];
}
s(ug, "readMeta");
var zw = "__zodvexCodecBrand";
function Sw(e, t) {
  Object.defineProperty(e, zw, {
    value: t,
    enumerable: !1,
    writable: !1,
    configurable: !1
  });
}
s(Sw, "attachCodecBrand");
function jw(e, t) {
  return {
    error: "ZodValidationError",
    context: t,
    issues: e.issues.map((r) => ({
      path: Array.isArray(r.path) ? r.path.join(".") : String(r.path ?? ""),
      code: r.code,
      message: r.message
    })),
    // Keep a flattened snapshot for easier debugging without cyclic refs
    flatten: JSON.parse(JSON.stringify(e.flatten?.() ?? {}))
  };
}
s(jw, "formatZodIssues");
function rd(e, t) {
  throw e instanceof Ae ? new yt(jw(e, t)) : e;
}
s(rd, "handleZodValidationError");
function Ow(e, t) {
  try {
    return se(e, t);
  } catch (r) {
    if (r?.message?.includes("unidirectional transform"))
      try {
        return ve(e, t);
      } catch (o) {
        rd(o, "returns");
      }
    rd(r, "returns");
  }
  throw new Error("Unreachable");
}
s(Ow, "validateReturns");
function cg(e) {
  if (e)
    return e instanceof S ? e : w.object(e);
}
s(cg, "normalizeFunctionSchema");
function Dw(e) {
  if (e) {
    if (e instanceof Y)
      return e;
    if (!(e instanceof S))
      return w.object(e);
  }
}
s(Dw, "normalizeFunctionMetaArgs");
function Cm(e, t, r) {
  kw(e, {
    type: "function",
    zodArgs: Dw(t),
    zodReturns: cg(r)
  });
}
s(Cm, "attachFunctionMeta");
var Zm = /* @__PURE__ */ new WeakMap();
function Nn(e, t = 50, r = 0) {
  let o = Zm.get(e);
  if (o !== void 0)
    return o;
  if (r > t)
    return !1;
  let n = !1;
  return e instanceof mn ? n = !0 : e instanceof ce ? n = e._zod.def.options.some((i) => Nn(i, t, r + 1)) : (e instanceof X || e instanceof Ie || e instanceof $e) && (n = Nn(e._zod.def.innerType, t, r + 1)), Zm.set(e, n), n;
}
s(Nn, "containsCustom");
function Pw(e) {
  if (e instanceof S) {
    if (e instanceof Y)
      return {
        argsSchema: e,
        argsValidator: e._zod.def.shape
      };
    throw new Error(
      "Unsupported non-object Zod schema for args; please provide an args schema using z.object({...}), e.g. z.object({ foo: z.string() })"
    );
  }
  return {
    argsValidator: e,
    argsSchema: w.object(e)
  };
}
s(Pw, "normalizeCustomArgsValidator");
function Tw(e, t) {
  if (!(!e || t?.skipConvexValidation) && !(t?.skipCustomSchemas && Nn(e)))
    return Qm(e);
}
s(Tw, "createConvexReturnsValidator");
function lg(e, t) {
  let r = Se(e, t);
  return r.success || rd(r.error, "args"), r.data;
}
s(lg, "parseObjectArgsOrThrow");
async function Fm(e, t, r, o, n, i) {
  let a = ag(r, Object.keys(o)), u = i ? lg(i, a) : a;
  return await e(t, u, n);
}
s(Fm, "runCustomizationInput");
function Mm(e, t, r) {
  let o = { ...e, ...r?.ctx ?? {} }, n = r?.args ?? {};
  return {
    finalCtx: o,
    finalArgs: { ...t, ...n }
  };
}
s(Mm, "applyCustomizationResult");
async function Rm(e, t) {
  if (t?.added?.onSuccess && await t.added.onSuccess({
    ctx: t.ctx,
    args: t.args,
    result: e
  }), t?.returns) {
    let r = Ow(t.returns, e);
    return Qe(r);
  }
  return Qe(e);
}
s(Rm, "finalizeFunctionReturn");
function ud(e, t) {
  let r = t.input ?? di.input, o = t.args ?? di.args, n = Object.entries(o), i = n.length > 0 && n.every(([, c]) => c instanceof S), a = i ? hi(o) : o, u = i ? w.object(o) : void 0;
  return /* @__PURE__ */ s(function(l) {
    let { args: d, handler: f = l, returns: p, ...h } = l, v = l.skipConvexValidation ?? !1, x = cg(p), k = Tw(x, { skipConvexValidation: v }), R = k ? { returns: k } : void 0;
    if (x && Nm(x, "returns"), d) {
      let { argsValidator: O, argsSchema: U } = Pw(d), M = v ? a : { ...hi(O), ...a };
      Nm(U, "args");
      let I = e({
        args: M,
        ...R,
        handler: /* @__PURE__ */ s(async (q, Ue) => {
          let Ye = await Fm(
            r,
            q,
            Ue,
            a,
            h,
            u
          ), Un = Object.keys(O), _i = ag(Ue, Un), An = lg(U, _i), { finalCtx: $g, finalArgs: bg } = Mm(q, An, Ye), _g = await f($g, bg);
          return Rm(_g, { ctx: q, args: An, added: Ye, returns: x });
        }, "handler")
      }), T = u ? w.object({
        ...U._zod.def.shape,
        ...u._zod.def.shape
      }) : U;
      return Cm(I, T, x), I;
    }
    let j = e({
      args: a,
      ...R,
      handler: /* @__PURE__ */ s(async (O, U) => {
        let M = U, I = await Fm(
          r,
          O,
          U,
          a,
          h,
          u
        ), { finalCtx: T, finalArgs: q } = Mm(O, M, I), Ue = await f(T, q);
        return Rm(Ue, { ctx: O, args: M, added: I, returns: x });
      }, "handler")
    });
    return Cm(j, u ?? void 0, x), j;
  }, "customBuilder");
}
s(ud, "customFnBuilder");
function Lm(e, t) {
  return ud(e, t);
}
s(Lm, "zCustomQuery");
function Vm(e, t) {
  return ud(
    e,
    t
  );
}
s(Vm, "zCustomMutation");
function Bm(e, t) {
  return ud(
    e,
    t
  );
}
s(Bm, "zCustomAction");
function dg(e, t, r) {
  let o = r?.wrapDb !== !1;
  if (!o && r?.underlyingDb)
    throw new Error(
      "[zodvex] initZodvex: `underlyingDb` requires the codec db wrapper \u2014 remove `wrapDb: false` or drop `underlyingDb`."
    );
  let n = Iw(e.__zodTableMap, {
    underlyingDb: r?.underlyingDb
  }), i = Nw(), a = r?.registry, u = Uw(a, i), c = {
    query: o ? n.query : i,
    mutation: Aw(o ? n.mutation : i, a),
    action: u
  };
  return {
    zq: Vt(t.query, c.query, Lm),
    zm: Vt(t.mutation, c.mutation, Vm),
    za: Vt(t.action, c.action, Bm),
    ziq: Vt(t.internalQuery, c.query, Lm),
    zim: Vt(t.internalMutation, c.mutation, Vm),
    zia: Vt(t.internalAction, c.action, Bm)
  };
}
s(dg, "initZodvex");
function Nw() {
  return { args: {}, input: di.input };
}
s(Nw, "createNoOpCustomization");
function Uw(e, t) {
  return e ? {
    args: {},
    input: /* @__PURE__ */ s(async (r) => ({
      // Auto-encode codec args at outbound call sites: runQuery/runMutation
      // (encode args, decode result) and scheduler.runAfter/runAt (encode args).
      ctx: Hm(e(), r),
      args: {}
    }), "input")
  } : t;
}
s(Uw, "createActionCustomization");
function Aw(e, t) {
  return t ? {
    args: {},
    input: /* @__PURE__ */ s(async (r, o, n) => {
      let i = await e.input(r, {}, n), a = Hm(t(), r);
      return {
        ctx: { ...i.ctx, ...a },
        args: {}
      };
    }, "input")
  } : e;
}
s(Aw, "createMutationCustomization");
function Ew(e, t) {
  return {
    args: t.args ?? {},
    input: /* @__PURE__ */ s(async (r, o, n) => {
      let i = await e.input(r, {}, n), a = { ...r, ...i.ctx };
      if (!t.input)
        return { ctx: i.ctx, args: {} };
      let u = await t.input(a, o, n);
      return {
        ctx: { ...i.ctx, ...u.ctx ?? {} },
        args: u.args ?? {},
        ...u.onSuccess && { onSuccess: u.onSuccess }
      };
    }, "input")
  };
}
s(Ew, "composeCustomizations");
function Vt(e, t, r) {
  let o = r(e, t);
  return o.withContext = (n) => {
    let i = Ew(t, n);
    return r(e, i);
  }, o;
}
s(Vt, "createZodvexBuilder");
function yi(e) {
  let t = w.string().check(
    w.refine((o) => typeof o == "string" && o.length > 0, {
      message: `Invalid ID for table "${e}"`
    }),
    w.describe(`convexId:${e}`)
  );
  gi.setMetadata(t, {
    isConvexId: !0,
    tableName: e
  });
  let r = t;
  return r._tableName = e, r;
}
s(yi, "id");
function fg(e) {
  return e instanceof ce || e instanceof Je;
}
s(fg, "isZodUnion");
function pg(e) {
  return e instanceof ce, e._zod.def.options;
}
s(pg, "getUnionOptions");
function Cw(e) {
  if (e.length < 2)
    throw new Error(
      `z.union() requires at least 2 options, but received ${e.length}. This indicates an invalid union schema was passed to zodTable().`
    );
}
s(Cw, "assertUnionOptions");
function mg(e) {
  return Cw(e), w.union(e);
}
s(mg, "createUnionFromOptions");
function Zw(e, t) {
  if (fg(t)) {
    let o = pg(t).map((n) => {
      if (n instanceof Y) {
        let i = {
          ...n._zod.def.shape,
          _id: yi(e),
          _creationTime: w.number()
        };
        return E(n, { ...n._zod.def, shape: i });
      }
      return n;
    });
    return mg(o);
  }
  if (t instanceof Y) {
    let r = { ...t._zod.def.shape, _id: yi(e), _creationTime: w.number() };
    return E(t, { ...t._zod.def, shape: r });
  }
  return t;
}
s(Zw, "addSystemFields");
function Fw(e) {
  return e instanceof X ? e : new X({ type: "optional", innerType: e });
}
s(Fw, "ensureOptional");
function Mw(e) {
  let t = {};
  for (let [r, o] of Object.entries(e))
    t[r] = Fw(o);
  return t;
}
s(Mw, "createPartialShape");
function Jm(e, t) {
  return w.object({
    _id: yi(e),
    _creationTime: w.optional(w.number()),
    ...Mw(t)
  });
}
s(Jm, "createUpdateObjectSchema");
function Rw(e, t) {
  if (fg(t)) {
    let r = pg(t).map((o) => o instanceof Y ? Jm(e, o._zod.def.shape) : o);
    return mg(r);
  }
  return t instanceof Y ? Jm(e, t._zod.def.shape) : t;
}
s(Rw, "createSchemaUpdateSchema");
var qm = /* @__PURE__ */ Symbol.for("zodvex.zxDate");
function Lw(e) {
  e[qm] = !0;
  let t = e._zod?.def;
  return t && (t[qm] = !0), e;
}
s(Lw, "brandZxDate");
function Vw() {
  return Lw(
    eg(
      w.number(),
      // Wire: timestamp
      w.custom((e) => e instanceof Date, {
        message: "Expected Date instance"
      }),
      {
        decode: /* @__PURE__ */ s((e) => new Date(e), "decode"),
        encode: /* @__PURE__ */ s((e) => e.getTime(), "encode")
      }
    )
  );
}
s(Vw, "date");
function Bw(e, t, r, o) {
  let n = eg(e, t, r);
  return o?.brand && Sw(n, o.brand), n;
}
s(Bw, "codec");
function bi(e) {
  let t = /* @__PURE__ */ Symbol.for(`zodvex.zx.cache.${e}`), r = globalThis, o = r[t];
  if (o) return o;
  let n = /* @__PURE__ */ new WeakMap();
  return r[t] = n, n;
}
s(bi, "sharedWeakMap");
var Wm = bi("base"), Km = bi("doc"), Gm = bi("update"), Xm = bi("docArray");
function cd(e) {
  let t = e.schema;
  return t instanceof S ? t : e.fields;
}
s(cd, "slimCacheKey");
function ld(e) {
  let t = e.schema;
  if (t?.base instanceof S) return t.base;
  if (t instanceof S) return t;
  let r = Wm.get(e.fields);
  if (r) return r;
  if (Object.keys(e.fields).length === 0)
    throw new Error(`[zodvex] Cannot derive base schema for model '${e.name}'`);
  let o = w.object(e.fields);
  return Wm.set(e.fields, o), o;
}
s(ld, "base");
function gg(e) {
  let t = e.schema;
  if (t?.doc instanceof S) return t.doc;
  let r = cd(e), o = Km.get(r);
  if (o) return o;
  let n = Zw(e.name, ld(e));
  return Km.set(r, n), n;
}
s(gg, "doc");
function Jw(e) {
  let t = e.schema;
  if (t?.update instanceof S) return t.update;
  let r = cd(e), o = Gm.get(r);
  if (o) return o;
  let n = Rw(e.name, ld(e));
  return Gm.set(r, n), n;
}
s(Jw, "update");
function qw(e) {
  let t = e.schema;
  if (t?.docArray instanceof S) return t.docArray;
  let r = cd(e), o = Xm.get(r);
  if (o) return o;
  let n = w.array(gg(e));
  return Xm.set(r, n), n;
}
s(qw, "docArray");
function hg(e) {
  return new Ie({ type: "nullable", innerType: e });
}
s(hg, "nullable");
function mi(e) {
  return new X({ type: "optional", innerType: e });
}
s(mi, "optional");
function id(e) {
  return mi(hg(e));
}
s(id, "nullableOptional2");
function Ww() {
  return w.object({
    numItems: w.number(),
    cursor: hg(w.string()),
    endCursor: id(w.string()),
    id: mi(w.number()),
    maximumRowsRead: mi(w.number()),
    maximumBytesRead: mi(w.number())
  });
}
s(Ww, "paginationOpts");
function Kw(e) {
  return w.object({
    page: w.array(e),
    isDone: w.boolean(),
    continueCursor: w.string(),
    splitCursor: id(w.string()),
    pageStatus: id(w.enum(["SplitRecommended", "SplitRequired"]))
  });
}
s(Kw, "paginationResult");
var od = {
  /**
   * Date ↔ timestamp codec
   * @see {@link date}
   */
  date: Vw,
  /**
   * Convex ID validator
   * @see {@link id}
   */
  id: yi,
  /**
   * Custom codec builder
   * @see {@link codec}
   */
  codec: Bw,
  /**
   * Pagination options schema matching Convex's PaginationOptions type
   * @see {@link paginationOpts}
   */
  paginationOpts: Ww,
  /**
   * Paginated result schema wrapping any item schema in Convex's PaginationResult shape
   * @see {@link paginationResult}
   */
  paginationResult: Kw,
  /**
   * Base schema for a model (user fields only; no system fields).
   * For object models reconstructs from fields; for union models returns the
   * user-supplied union. Cached per-model.
   * @see {@link base}
   */
  base: ld,
  /**
   * Doc schema: model fields + _id + _creationTime
   * @see {@link doc}
   */
  doc: gg,
  /**
   * Update schema: _id required, all other fields optional
   * @see {@link update}
   */
  update: Jw,
  /**
   * Doc array schema: z.array(doc(model))
   * @see {@link docArray}
   */
  docArray: qw
};
function Gw(e) {
  return ug(e)?.type === "model";
}
s(Gw, "isZodModelEntry");
function vg(e) {
  let t = ug(e);
  if (!t || t.type !== "model")
    throw new Error(`Model '${e.name}' is missing zodvex model metadata.`);
  return t;
}
s(vg, "getZodModelMeta");
function Xw(e) {
  let t = vg(e), o = t.definitionSource === "schema" || t.definitionSource == null && Object.keys(e.fields).length === 0 ? it(Qm(od.base(e))) : it(hi(e.fields));
  for (let [n, i] of Object.entries(e.indexes)) {
    let a = i.filter((u) => u !== "_creationTime");
    o = o.index(n, a);
  }
  for (let [n, i] of Object.entries(e.searchIndexes))
    o = o.searchIndex(n, i);
  for (let [n, i] of Object.entries(e.vectorIndexes))
    o = o.vectorIndex(n, i);
  return o;
}
s(Xw, "tableFromModel");
function yg(e) {
  let t = {}, r = {};
  for (let [i, a] of Object.entries(e))
    if (Gw(a)) {
      if (a.name !== i)
        throw new Error(
          `Model name '${a.name}' does not match key '${i}'. The model name must match the key in the schema definition.`
        );
      t[i] = Xw(a);
      let u = vg(a);
      u.schemas ? r[i] = {
        doc: u.schemas.doc,
        insert: u.schemas.insert
      } : r[i] = {
        doc: od.doc(a),
        insert: od.base(a)
      };
    } else
      t[i] = a.table, r[i] = {
        doc: a.schema.doc,
        insert: a.schema.insert
      };
  let o = ir(t);
  return Object.assign(o, { __zodTableMap: r });
}
s(yg, "defineZodSchema");

// graphProbe.ts
var Qw = { query: Ji, mutation: Vi, action: Wi, internalQuery: qi, internalMutation: Bi, internalAction: Ki }, Yw = { kind: "mini", server: Qw, s: { number: Hr, string: Zt, boolean: Qr, optional: Lt, nullable: ti, object: Cl, array: On, union: Rt, date: El, codec: Bl, instanceof: ql, parse: ve, encode: se }, defineZodModel: Im, defineZodSchema: yg, initZodvex: dg }, eI = Kd(Yw), tI = { count: 0, width: 32, profile: "codec-rich", entries: 0 }, dd = eI(tI), JP = Hw({ args: {}, returns: y.object({ checksum: y.number(), output: y.object({ seq: y.number(), at: y.number(), secret: y.string(), payload: y.string() }), manifest: y.any(), nonce: y.string() }), handler: /* @__PURE__ */ s(() => {
  let e = dd.operation();
  return globalThis.gc(), globalThis.gc(), { checksum: dd.checksum(), output: e, manifest: dd.manifest, nonce: "b0394057-6157-4975-8c9a-509dbe01092f" };
}, "handler") });
export {
  JP as default
};
