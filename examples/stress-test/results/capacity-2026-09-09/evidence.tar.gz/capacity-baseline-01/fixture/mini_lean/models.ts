import * as s from 'zod/mini'
import { defineZodModel, zx } from 'zodvex/mini'
import { SecretText } from '../workload'
// Identical forward schema expressions; Mini is a separate dependency graph.
const date = s.codec(s.number(), s.date(), { decode: n => new Date(n), encode: d => d.getTime() })

export const model0 = defineZodModel('benchmarkRows', {
  seq: s.number(), createdAt: s.codec(s.number(), s.date(), { decode: n => new Date(n), encode: d => d.getTime() }),
  secret: s.codec(s.string(), s.instanceof(SecretText), { decode: t => new SecretText(t), encode: t => t.toWire() }),
  payload: s.string(), tags: s.array(s.string()), checkpoints: s.array(s.object({ at: date, value: s.number() })),
  reviewedAt: s.optional(s.nullable(date)),
}).index('by_seq', ['seq'])
