import { z as s } from 'zod'
import { defineZodModel, zx } from 'zodvex'
import { SecretText } from '../workload'
// Identical forward schema expressions; Mini is a separate dependency graph.
const date = s.codec(s.number(), s.date(), { decode: n => new Date(n), encode: d => d.getTime() })

export const model0 = defineZodModel('benchmarkRows', {
  seq: s.number(), createdAt: s.codec(s.number(), s.date(), { decode: n => new Date(n), encode: d => d.getTime() }),
  secret: s.codec(s.string(), s.instanceof(SecretText), { decode: t => new SecretText(t), encode: t => t.toWire() }),
  payload: s.string(), tags: s.array(s.string()), checkpoints: s.array(s.object({ at: date, value: s.number() })),
  reviewedAt: s.optional(s.nullable(date)),
}).index('by_seq', ['seq'])
export const model1 = defineZodModel('unused1', {
  seq: s.number(), createdAt: s.codec(s.number(), s.date(), { decode: n => new Date(n), encode: d => d.getTime() }),
  secret: s.codec(s.string(), s.instanceof(SecretText), { decode: t => new SecretText(t), encode: t => t.toWire() }),
  payload: s.string(), tags: s.array(s.string()), checkpoints: s.array(s.object({ at: date, value: s.number() })),
  reviewedAt: s.optional(s.nullable(date)),
}).index('by_seq', ['seq'])
export const model2 = defineZodModel('unused2', {
  seq: s.number(), createdAt: s.codec(s.number(), s.date(), { decode: n => new Date(n), encode: d => d.getTime() }),
  secret: s.codec(s.string(), s.instanceof(SecretText), { decode: t => new SecretText(t), encode: t => t.toWire() }),
  payload: s.string(), tags: s.array(s.string()), checkpoints: s.array(s.object({ at: date, value: s.number() })),
  reviewedAt: s.optional(s.nullable(date)),
}).index('by_seq', ['seq'])
export const model3 = defineZodModel('unused3', {
  seq: s.number(), createdAt: s.codec(s.number(), s.date(), { decode: n => new Date(n), encode: d => d.getTime() }),
  secret: s.codec(s.string(), s.instanceof(SecretText), { decode: t => new SecretText(t), encode: t => t.toWire() }),
  payload: s.string(), tags: s.array(s.string()), checkpoints: s.array(s.object({ at: date, value: s.number() })),
  reviewedAt: s.optional(s.nullable(date)),
}).index('by_seq', ['seq'])
export const model4 = defineZodModel('unused4', {
  seq: s.number(), createdAt: s.codec(s.number(), s.date(), { decode: n => new Date(n), encode: d => d.getTime() }),
  secret: s.codec(s.string(), s.instanceof(SecretText), { decode: t => new SecretText(t), encode: t => t.toWire() }),
  payload: s.string(), tags: s.array(s.string()), checkpoints: s.array(s.object({ at: date, value: s.number() })),
  reviewedAt: s.optional(s.nullable(date)),
}).index('by_seq', ['seq'])
export const model5 = defineZodModel('unused5', {
  seq: s.number(), createdAt: s.codec(s.number(), s.date(), { decode: n => new Date(n), encode: d => d.getTime() }),
  secret: s.codec(s.string(), s.instanceof(SecretText), { decode: t => new SecretText(t), encode: t => t.toWire() }),
  payload: s.string(), tags: s.array(s.string()), checkpoints: s.array(s.object({ at: date, value: s.number() })),
  reviewedAt: s.optional(s.nullable(date)),
}).index('by_seq', ['seq'])
export const model6 = defineZodModel('unused6', {
  seq: s.number(), createdAt: s.codec(s.number(), s.date(), { decode: n => new Date(n), encode: d => d.getTime() }),
  secret: s.codec(s.string(), s.instanceof(SecretText), { decode: t => new SecretText(t), encode: t => t.toWire() }),
  payload: s.string(), tags: s.array(s.string()), checkpoints: s.array(s.object({ at: date, value: s.number() })),
  reviewedAt: s.optional(s.nullable(date)),
}).index('by_seq', ['seq'])
export const model7 = defineZodModel('unused7', {
  seq: s.number(), createdAt: s.codec(s.number(), s.date(), { decode: n => new Date(n), encode: d => d.getTime() }),
  secret: s.codec(s.string(), s.instanceof(SecretText), { decode: t => new SecretText(t), encode: t => t.toWire() }),
  payload: s.string(), tags: s.array(s.string()), checkpoints: s.array(s.object({ at: date, value: s.number() })),
  reviewedAt: s.optional(s.nullable(date)),
}).index('by_seq', ['seq'])
export const model8 = defineZodModel('unused8', {
  seq: s.number(), createdAt: s.codec(s.number(), s.date(), { decode: n => new Date(n), encode: d => d.getTime() }),
  secret: s.codec(s.string(), s.instanceof(SecretText), { decode: t => new SecretText(t), encode: t => t.toWire() }),
  payload: s.string(), tags: s.array(s.string()), checkpoints: s.array(s.object({ at: date, value: s.number() })),
  reviewedAt: s.optional(s.nullable(date)),
}).index('by_seq', ['seq'])
export const model9 = defineZodModel('unused9', {
  seq: s.number(), createdAt: s.codec(s.number(), s.date(), { decode: n => new Date(n), encode: d => d.getTime() }),
  secret: s.codec(s.string(), s.instanceof(SecretText), { decode: t => new SecretText(t), encode: t => t.toWire() }),
  payload: s.string(), tags: s.array(s.string()), checkpoints: s.array(s.object({ at: date, value: s.number() })),
  reviewedAt: s.optional(s.nullable(date)),
}).index('by_seq', ['seq'])
export const model10 = defineZodModel('unused10', {
  seq: s.number(), createdAt: s.codec(s.number(), s.date(), { decode: n => new Date(n), encode: d => d.getTime() }),
  secret: s.codec(s.string(), s.instanceof(SecretText), { decode: t => new SecretText(t), encode: t => t.toWire() }),
  payload: s.string(), tags: s.array(s.string()), checkpoints: s.array(s.object({ at: date, value: s.number() })),
  reviewedAt: s.optional(s.nullable(date)),
}).index('by_seq', ['seq'])
export const model11 = defineZodModel('unused11', {
  seq: s.number(), createdAt: s.codec(s.number(), s.date(), { decode: n => new Date(n), encode: d => d.getTime() }),
  secret: s.codec(s.string(), s.instanceof(SecretText), { decode: t => new SecretText(t), encode: t => t.toWire() }),
  payload: s.string(), tags: s.array(s.string()), checkpoints: s.array(s.object({ at: date, value: s.number() })),
  reviewedAt: s.optional(s.nullable(date)),
}).index('by_seq', ['seq'])
export const model12 = defineZodModel('unused12', {
  seq: s.number(), createdAt: s.codec(s.number(), s.date(), { decode: n => new Date(n), encode: d => d.getTime() }),
  secret: s.codec(s.string(), s.instanceof(SecretText), { decode: t => new SecretText(t), encode: t => t.toWire() }),
  payload: s.string(), tags: s.array(s.string()), checkpoints: s.array(s.object({ at: date, value: s.number() })),
  reviewedAt: s.optional(s.nullable(date)),
}).index('by_seq', ['seq'])
export const model13 = defineZodModel('unused13', {
  seq: s.number(), createdAt: s.codec(s.number(), s.date(), { decode: n => new Date(n), encode: d => d.getTime() }),
  secret: s.codec(s.string(), s.instanceof(SecretText), { decode: t => new SecretText(t), encode: t => t.toWire() }),
  payload: s.string(), tags: s.array(s.string()), checkpoints: s.array(s.object({ at: date, value: s.number() })),
  reviewedAt: s.optional(s.nullable(date)),
}).index('by_seq', ['seq'])
export const model14 = defineZodModel('unused14', {
  seq: s.number(), createdAt: s.codec(s.number(), s.date(), { decode: n => new Date(n), encode: d => d.getTime() }),
  secret: s.codec(s.string(), s.instanceof(SecretText), { decode: t => new SecretText(t), encode: t => t.toWire() }),
  payload: s.string(), tags: s.array(s.string()), checkpoints: s.array(s.object({ at: date, value: s.number() })),
  reviewedAt: s.optional(s.nullable(date)),
}).index('by_seq', ['seq'])
export const model15 = defineZodModel('unused15', {
  seq: s.number(), createdAt: s.codec(s.number(), s.date(), { decode: n => new Date(n), encode: d => d.getTime() }),
  secret: s.codec(s.string(), s.instanceof(SecretText), { decode: t => new SecretText(t), encode: t => t.toWire() }),
  payload: s.string(), tags: s.array(s.string()), checkpoints: s.array(s.object({ at: date, value: s.number() })),
  reviewedAt: s.optional(s.nullable(date)),
}).index('by_seq', ['seq'])
export const model16 = defineZodModel('unused16', {
  seq: s.number(), createdAt: s.codec(s.number(), s.date(), { decode: n => new Date(n), encode: d => d.getTime() }),
  secret: s.codec(s.string(), s.instanceof(SecretText), { decode: t => new SecretText(t), encode: t => t.toWire() }),
  payload: s.string(), tags: s.array(s.string()), checkpoints: s.array(s.object({ at: date, value: s.number() })),
  reviewedAt: s.optional(s.nullable(date)),
}).index('by_seq', ['seq'])
export const model17 = defineZodModel('unused17', {
  seq: s.number(), createdAt: s.codec(s.number(), s.date(), { decode: n => new Date(n), encode: d => d.getTime() }),
  secret: s.codec(s.string(), s.instanceof(SecretText), { decode: t => new SecretText(t), encode: t => t.toWire() }),
  payload: s.string(), tags: s.array(s.string()), checkpoints: s.array(s.object({ at: date, value: s.number() })),
  reviewedAt: s.optional(s.nullable(date)),
}).index('by_seq', ['seq'])
export const model18 = defineZodModel('unused18', {
  seq: s.number(), createdAt: s.codec(s.number(), s.date(), { decode: n => new Date(n), encode: d => d.getTime() }),
  secret: s.codec(s.string(), s.instanceof(SecretText), { decode: t => new SecretText(t), encode: t => t.toWire() }),
  payload: s.string(), tags: s.array(s.string()), checkpoints: s.array(s.object({ at: date, value: s.number() })),
  reviewedAt: s.optional(s.nullable(date)),
}).index('by_seq', ['seq'])
export const model19 = defineZodModel('unused19', {
  seq: s.number(), createdAt: s.codec(s.number(), s.date(), { decode: n => new Date(n), encode: d => d.getTime() }),
  secret: s.codec(s.string(), s.instanceof(SecretText), { decode: t => new SecretText(t), encode: t => t.toWire() }),
  payload: s.string(), tags: s.array(s.string()), checkpoints: s.array(s.object({ at: date, value: s.number() })),
  reviewedAt: s.optional(s.nullable(date)),
}).index('by_seq', ['seq'])
export const model20 = defineZodModel('unused20', {
  seq: s.number(), createdAt: s.codec(s.number(), s.date(), { decode: n => new Date(n), encode: d => d.getTime() }),
  secret: s.codec(s.string(), s.instanceof(SecretText), { decode: t => new SecretText(t), encode: t => t.toWire() }),
  payload: s.string(), tags: s.array(s.string()), checkpoints: s.array(s.object({ at: date, value: s.number() })),
  reviewedAt: s.optional(s.nullable(date)),
}).index('by_seq', ['seq'])
export const model21 = defineZodModel('unused21', {
  seq: s.number(), createdAt: s.codec(s.number(), s.date(), { decode: n => new Date(n), encode: d => d.getTime() }),
  secret: s.codec(s.string(), s.instanceof(SecretText), { decode: t => new SecretText(t), encode: t => t.toWire() }),
  payload: s.string(), tags: s.array(s.string()), checkpoints: s.array(s.object({ at: date, value: s.number() })),
  reviewedAt: s.optional(s.nullable(date)),
}).index('by_seq', ['seq'])
export const model22 = defineZodModel('unused22', {
  seq: s.number(), createdAt: s.codec(s.number(), s.date(), { decode: n => new Date(n), encode: d => d.getTime() }),
  secret: s.codec(s.string(), s.instanceof(SecretText), { decode: t => new SecretText(t), encode: t => t.toWire() }),
  payload: s.string(), tags: s.array(s.string()), checkpoints: s.array(s.object({ at: date, value: s.number() })),
  reviewedAt: s.optional(s.nullable(date)),
}).index('by_seq', ['seq'])
export const model23 = defineZodModel('unused23', {
  seq: s.number(), createdAt: s.codec(s.number(), s.date(), { decode: n => new Date(n), encode: d => d.getTime() }),
  secret: s.codec(s.string(), s.instanceof(SecretText), { decode: t => new SecretText(t), encode: t => t.toWire() }),
  payload: s.string(), tags: s.array(s.string()), checkpoints: s.array(s.object({ at: date, value: s.number() })),
  reviewedAt: s.optional(s.nullable(date)),
}).index('by_seq', ['seq'])
export const model24 = defineZodModel('unused24', {
  seq: s.number(), createdAt: s.codec(s.number(), s.date(), { decode: n => new Date(n), encode: d => d.getTime() }),
  secret: s.codec(s.string(), s.instanceof(SecretText), { decode: t => new SecretText(t), encode: t => t.toWire() }),
  payload: s.string(), tags: s.array(s.string()), checkpoints: s.array(s.object({ at: date, value: s.number() })),
  reviewedAt: s.optional(s.nullable(date)),
}).index('by_seq', ['seq'])
export const model25 = defineZodModel('unused25', {
  seq: s.number(), createdAt: s.codec(s.number(), s.date(), { decode: n => new Date(n), encode: d => d.getTime() }),
  secret: s.codec(s.string(), s.instanceof(SecretText), { decode: t => new SecretText(t), encode: t => t.toWire() }),
  payload: s.string(), tags: s.array(s.string()), checkpoints: s.array(s.object({ at: date, value: s.number() })),
  reviewedAt: s.optional(s.nullable(date)),
}).index('by_seq', ['seq'])
export const model26 = defineZodModel('unused26', {
  seq: s.number(), createdAt: s.codec(s.number(), s.date(), { decode: n => new Date(n), encode: d => d.getTime() }),
  secret: s.codec(s.string(), s.instanceof(SecretText), { decode: t => new SecretText(t), encode: t => t.toWire() }),
  payload: s.string(), tags: s.array(s.string()), checkpoints: s.array(s.object({ at: date, value: s.number() })),
  reviewedAt: s.optional(s.nullable(date)),
}).index('by_seq', ['seq'])
export const model27 = defineZodModel('unused27', {
  seq: s.number(), createdAt: s.codec(s.number(), s.date(), { decode: n => new Date(n), encode: d => d.getTime() }),
  secret: s.codec(s.string(), s.instanceof(SecretText), { decode: t => new SecretText(t), encode: t => t.toWire() }),
  payload: s.string(), tags: s.array(s.string()), checkpoints: s.array(s.object({ at: date, value: s.number() })),
  reviewedAt: s.optional(s.nullable(date)),
}).index('by_seq', ['seq'])
export const model28 = defineZodModel('unused28', {
  seq: s.number(), createdAt: s.codec(s.number(), s.date(), { decode: n => new Date(n), encode: d => d.getTime() }),
  secret: s.codec(s.string(), s.instanceof(SecretText), { decode: t => new SecretText(t), encode: t => t.toWire() }),
  payload: s.string(), tags: s.array(s.string()), checkpoints: s.array(s.object({ at: date, value: s.number() })),
  reviewedAt: s.optional(s.nullable(date)),
}).index('by_seq', ['seq'])
export const model29 = defineZodModel('unused29', {
  seq: s.number(), createdAt: s.codec(s.number(), s.date(), { decode: n => new Date(n), encode: d => d.getTime() }),
  secret: s.codec(s.string(), s.instanceof(SecretText), { decode: t => new SecretText(t), encode: t => t.toWire() }),
  payload: s.string(), tags: s.array(s.string()), checkpoints: s.array(s.object({ at: date, value: s.number() })),
  reviewedAt: s.optional(s.nullable(date)),
}).index('by_seq', ['seq'])
export const model30 = defineZodModel('unused30', {
  seq: s.number(), createdAt: s.codec(s.number(), s.date(), { decode: n => new Date(n), encode: d => d.getTime() }),
  secret: s.codec(s.string(), s.instanceof(SecretText), { decode: t => new SecretText(t), encode: t => t.toWire() }),
  payload: s.string(), tags: s.array(s.string()), checkpoints: s.array(s.object({ at: date, value: s.number() })),
  reviewedAt: s.optional(s.nullable(date)),
}).index('by_seq', ['seq'])
export const model31 = defineZodModel('unused31', {
  seq: s.number(), createdAt: s.codec(s.number(), s.date(), { decode: n => new Date(n), encode: d => d.getTime() }),
  secret: s.codec(s.string(), s.instanceof(SecretText), { decode: t => new SecretText(t), encode: t => t.toWire() }),
  payload: s.string(), tags: s.array(s.string()), checkpoints: s.array(s.object({ at: date, value: s.number() })),
  reviewedAt: s.optional(s.nullable(date)),
}).index('by_seq', ['seq'])
