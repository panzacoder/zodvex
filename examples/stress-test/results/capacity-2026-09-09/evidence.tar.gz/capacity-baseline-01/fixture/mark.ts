export function mark(limit: number, run: string, sample: string) {
  if (!Number.isInteger(limit) || limit < 1 || limit > 8192) throw new Error('Invalid benchmark batch')
  console.log('ZODVEX_CAPACITY ' + JSON.stringify({ run, sample, limit }))
}
