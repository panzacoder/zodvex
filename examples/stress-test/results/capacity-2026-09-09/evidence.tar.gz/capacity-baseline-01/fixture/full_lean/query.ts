import { initZodvex, defineZodSchema } from 'zodvex/server'
import * as convex from '../_generated/server'
import { z as s } from 'zod'
import { model0 } from './models'

import { processRows } from '../workload'
import { mark } from '../mark'
const schema = defineZodSchema({ benchmarkRows: model0 })
const { ziq } = initZodvex(schema, convex)
export const read = ziq({
  args: { limit: s.number(), run: s.string(), sample: s.string() },
  returns: s.object({ rows: s.array(model0.schema.doc), digest: s.number(), nonce: s.string() }),
  handler: async (ctx, a) => {
    mark(a.limit, a.run, a.sample)
    const rows = await ctx.db.query('benchmarkRows').withIndex('by_seq').take(a.limit)
    return { ...processRows(rows), nonce: a.sample }
  },
})
