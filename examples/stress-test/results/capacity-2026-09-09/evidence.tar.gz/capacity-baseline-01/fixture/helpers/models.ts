import { z as s } from 'zod'
import { zid } from 'convex-helpers/server/zod4'
import { SecretText } from '../workload'
// Identical forward schema expressions; Mini is a separate dependency graph.
const date = s.codec(s.number(), s.date(), { decode: n => new Date(n), encode: d => d.getTime() })
const secret = s.codec(s.string(), s.instanceof(SecretText), { decode: text => new SecretText(text), encode: value => value.toWire() })
const reverseDate = s.codec(s.date(), s.number(), { decode: d => d.getTime(), encode: n => new Date(n) })
const reverseSecret = s.codec(s.instanceof(SecretText), s.string(), { decode: value => value.toWire(), encode: text => new SecretText(text) })
const shape = <D extends typeof date | typeof reverseDate, S extends typeof secret | typeof reverseSecret>(at: D, text: S) => ({
  seq: s.number(), createdAt: at, secret: text, payload: s.string(), tags: s.array(s.string()),
  checkpoints: s.array(s.object({ at, value: s.number() })), reviewedAt: s.optional(s.nullable(at)),
})
export const forwardFields = shape(date, secret)
export const forwardDoc = s.object({ ...forwardFields, _id: zid('benchmarkRows'), _creationTime: s.number() })
export const reverseDoc = s.object({ ...shape(reverseDate, reverseSecret), _id: zid('benchmarkRows'), _creationTime: s.number() })

