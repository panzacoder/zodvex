import { zCustomQuery } from 'convex-helpers/server/zod4'
import { NoOp } from 'convex-helpers/server/customFunctions'
import { internalQuery } from '../_generated/server'
import { z as s } from 'zod'
import { forwardDoc, reverseDoc } from './models'
import { processRows } from '../workload'
import { mark } from '../mark'
const query = zCustomQuery(internalQuery, NoOp)
export const read = query({
  args: { limit: s.number(), run: s.string(), sample: s.string() },
  // Helpers parse returns forward; reversed codecs deliberately produce wire values.
  returns: s.object({ rows: s.array(reverseDoc), digest: s.number(), nonce: s.string() }),
  handler: async (ctx, a) => {
    mark(a.limit, a.run, a.sample)
    const raw = await ctx.db.query('benchmarkRows').withIndex('by_seq').take(a.limit)
    const result = processRows(raw.map(row => s.parse(forwardDoc, row)))
    return { ...result, nonce: a.sample }
  },
})
