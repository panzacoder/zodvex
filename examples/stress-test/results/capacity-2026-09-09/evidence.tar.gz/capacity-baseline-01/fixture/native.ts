import { internalQuery } from './_generated/server'
import { args, result } from './wire'
import { decodeRow, encodeRow, processRows } from './workload'
import { mark } from './mark'
export const read = internalQuery({ args, returns: result, handler: async (ctx, a) => {
  mark(a.limit, a.run, a.sample)
  const raw = await ctx.db.query('benchmarkRows').withIndex('by_seq').take(a.limit)
  const result = processRows(raw.map(row => decodeRow(row)))
  return { rows: result.rows.map(row => encodeRow(row)), digest: result.digest, nonce: a.sample }
}})
