import { initZodvex, defineZodSchema } from 'zodvex/mini/server'
import * as convex from '../_generated/server'
import * as s from 'zod/mini'
import { model0, model1, model2, model3, model4, model5, model6, model7, model8, model9, model10, model11, model12, model13, model14, model15, model16, model17, model18, model19, model20, model21, model22, model23, model24, model25, model26, model27, model28, model29, model30, model31 } from './models'
import { registry } from './registry'
import { processRows } from '../workload'
import { mark } from '../mark'
const schema = defineZodSchema({ benchmarkRows: model0, unused1: model1, unused2: model2, unused3: model3, unused4: model4, unused5: model5, unused6: model6, unused7: model7, unused8: model8, unused9: model9, unused10: model10, unused11: model11, unused12: model12, unused13: model13, unused14: model14, unused15: model15, unused16: model16, unused17: model17, unused18: model18, unused19: model19, unused20: model20, unused21: model21, unused22: model22, unused23: model23, unused24: model24, unused25: model25, unused26: model26, unused27: model27, unused28: model28, unused29: model29, unused30: model30, unused31: model31 })
const { ziq } = initZodvex(schema, convex, { registry: () => registry })
export const read = ziq({
  args: { limit: s.number(), run: s.string(), sample: s.string() },
  returns: s.object({ rows: s.array(model0.schema.doc), digest: s.number(), nonce: s.string() }),
  handler: async (ctx, a) => {
    mark(a.limit, a.run, a.sample)
    const rows = await ctx.db.query('benchmarkRows').withIndex('by_seq').take(a.limit)
    return { ...processRows(rows), nonce: a.sample }
  },
})
