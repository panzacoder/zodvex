import { v } from 'convex/values'
export const fields = {
  seq: v.number(), createdAt: v.number(), secret: v.string(), payload: v.string(),
  tags: v.array(v.string()), checkpoints: v.array(v.object({ at: v.number(), value: v.number() })),
  reviewedAt: v.optional(v.union(v.number(), v.null())),
}
export const doc = v.object({ ...fields, _id: v.id('benchmarkRows'), _creationTime: v.number() })
export const args = { limit: v.number(), run: v.string(), sample: v.string() }
export const result = v.object({ rows: v.array(doc), digest: v.number(), nonce: v.string() })
