# Zodvex codec workload benchmark

**VALID: complete observations and attributable capacity outcomes.**


Run fd4c96d2-5067-48ee-ae1b-4394c7406aef; library commit dc0179e38ff51d8827ddadceb10945253df19362; fixture 5092dac18dfb0e21f03d559f7d4deb1c91f0ba60f03423c4db0445b962057acf.

Started 2026-09-09T18:27:11.610Z; target lovable-donkey-430. Payload field: 640 ASCII bytes; seeded rows: 256; batch sizes: 1, 64, 256; rounds: 7; order seed: 42. Payload is not full document size; actual resource counts are in results.json.

All variants use one model. Native/helpers and lean import one; models/registry import 32. Registry profiles additionally load 128 unused schema entries. These counts describe this synthetic fixture, not typical applications.

{"convex":"1.32.0","convex-helpers":"0.1.113","zod":"4.5.4","zodvex":"0.7.10"}

One indexed read, modeled decode, domain transform and complete return encoding. Driver correctness checking and client transport are outside query execution time. Native performs manual codec transforms, without full Zod modeled validation. No measured heap or true cold-start claim.

176/176 planned calls recorded, including initial calls. All phases are checked for validity; the table below excludes initial calls. Named query capacity failures are outcomes; correctness, collection and attribution failures invalidate the run.

| Variant | Rows | Verified calls | Timing samples / planned | Missing telemetry | Cache hits | Server ms median [Q1, Q3] | User ms median | Paired native ratio | Errors |
|---|---:|---:|---:|---:|---:|---|---:|---:|---|
| native | 1 | 7/7 | 7/7 | 0 | 0 | 7.32 [6.93, 8.08] | 1.94 | 1.00 | none |
| native | 64 | 7/7 | 7/7 | 0 | 0 | 16.05 [15.42, 18.89] | 5.41 | 1.00 | none |
| native | 256 | 7/7 | 7/7 | 0 | 0 | 45.49 [43.72, 47.16] | 15.06 | 1.00 | none |
| helpers | 1 | 7/7 | 7/7 | 0 | 0 | 14.52 [13.85, 16.18] | 8.83 | 2.15 | none |
| helpers | 64 | 7/7 | 7/7 | 0 | 0 | 24.82 [23.30, 25.19] | 14.16 | 1.55 | none |
| helpers | 256 | 7/7 | 7/7 | 0 | 0 | 58.23 [56.89, 60.72] | 29.27 | 1.30 | none |
| full_lean | 1 | 7/7 | 7/7 | 0 | 0 | 15.45 [15.15, 16.31] | 10.35 | 2.18 | none |
| full_lean | 64 | 7/7 | 7/7 | 0 | 0 | 29.42 [26.61, 32.61] | 19.96 | 1.61 | none |
| full_lean | 256 | 7/7 | 7/7 | 0 | 0 | 67.88 [64.36, 71.33] | 37.11 | 1.44 | none |
| full_models | 1 | 7/7 | 7/7 | 0 | 0 | 32.27 [25.52, 33.02] | 27.22 | 3.95 | none |
| full_models | 64 | 7/7 | 7/7 | 0 | 0 | 41.90 [35.40, 42.87] | 26.34 | 2.42 | none |
| full_models | 256 | 7/7 | 7/7 | 0 | 0 | 77.24 [73.67, 77.32] | 48.36 | 1.64 | none |
| full_registry | 1 | 7/7 | 7/7 | 0 | 0 | 36.28 [29.14, 37.46] | 31.42 | 4.65 | none |
| full_registry | 64 | 7/7 | 7/7 | 0 | 0 | 40.95 [39.27, 45.49] | 29.72 | 2.52 | none |
| full_registry | 256 | 7/7 | 7/7 | 0 | 0 | 82.24 [76.56, 83.59] | 53.31 | 1.78 | none |
| mini_lean | 1 | 7/7 | 7/7 | 0 | 0 | 17.29 [13.86, 17.64] | 8.15 | 2.02 | none |
| mini_lean | 64 | 7/7 | 7/7 | 0 | 0 | 24.47 [22.88, 26.69] | 14.03 | 1.65 | none |
| mini_lean | 256 | 7/7 | 7/7 | 0 | 0 | 58.16 [56.93, 61.20] | 29.14 | 1.30 | none |
| mini_models | 1 | 7/7 | 7/7 | 0 | 0 | 22.69 [22.07, 27.38] | 16.26 | 3.37 | none |
| mini_models | 64 | 7/7 | 7/7 | 0 | 0 | 32.51 [32.03, 36.32] | 22.60 | 2.12 | none |
| mini_models | 256 | 7/7 | 7/7 | 0 | 0 | 71.53 [68.65, 77.03] | 43.22 | 1.65 | none |
| mini_registry | 1 | 7/7 | 7/7 | 0 | 0 | 28.39 [24.47, 30.69] | 20.74 | 3.52 | none |
| mini_registry | 64 | 7/7 | 7/7 | 0 | 0 | 34.67 [34.06, 37.94] | 24.83 | 2.19 | none |
| mini_registry | 256 | 7/7 | 7/7 | 0 | 0 | 75.82 [71.80, 79.97] | 47.07 | 1.71 | none |

The largest tested successful batch is a lower bound under this fixture, not a maximum or a general row/table allowance. Timings describe successful uncached samples only; they do not conceal failed attempts shown alongside them. Full failure text/source, resource counters, optional user-timer sample counts, and exact call order are retained in results.json.
