# Zodvex codec workload benchmark

Run e6e121b4-0e13-4a16-a45c-9f7b91080a0f; library commit ad4a23241b7a351e2406fe555283f9e81591139a; fixture edd610ac1221e0fbeaddf15e67a9733b9faab0fff55f9efc9f1693dfa6ab6db8.

{"convex":"1.32.0","convex-helpers":"0.1.113","zod":"4.5.4","zodvex":"0.7.10"}

One indexed read, modeled decode, domain transform and complete return encoding. Driver correctness checking and client transport are outside query execution time. Native performs manual codec transforms, without full Zod modeled validation. No measured heap or true cold-start claim.

| Variant | Rows | Verified calls | Server ms median [Q1, Q3] | User ms median | Paired native ratio | Errors |
|---|---:|---:|---|---:|---:|---|
| native | 64 | 7/7 | 15.80 [15.66, 17.83] | 6.25 | 1.00 | none |
| native | 256 | 7/7 | 46.62 [44.39, 47.82] | 18.58 | 1.00 | none |
| native | 8192 | 7/7 | 1087.21 [1082.44, 1110.92] | 311.52 | 1.00 | none |
| helpers | 64 | 7/7 | 25.70 [24.61, 31.50] | 16.30 | 1.57 | none |
| helpers | 256 | 7/7 | 62.31 [61.18, 63.06] | 33.83 | 1.33 | none |
| helpers | 8192 | 7/7 | 1209.74 [1171.14, 1225.57] | 376.17 | 1.09 | none |
| full_lean | 64 | 7/7 | 27.55 [26.57, 30.95] | 17.88 | 1.65 | none |
| full_lean | 256 | 7/7 | 66.46 [62.92, 68.57] | 36.39 | 1.39 | none |
| full_lean | 8192 | 7/7 | 1209.44 [1205.42, 1236.42] | 414.81 | 1.11 | none |
| full_models | 64 | 7/7 | 43.73 [42.38, 47.15] | 34.58 | 2.60 | none |
| full_models | 256 | 7/7 | 80.59 [76.08, 80.89] | 51.00 | 1.69 | none |
| full_models | 8192 | 7/7 | 1225.75 [1219.83, 1265.04] | 431.80 | 1.13 | none |
| full_registry | 64 | 7/7 | 49.45 [48.14, 49.69] | 39.14 | 3.13 | none |
| full_registry | 256 | 7/7 | 82.21 [77.55, 87.57] | 54.92 | 1.81 | none |
| full_registry | 8192 | 7/7 | 1295.82 [1281.02, 1301.13] | 438.87 | 1.18 | none |
| mini_lean | 64 | 7/7 | 28.32 [25.56, 31.71] | 18.94 | 1.63 | none |
| mini_lean | 256 | 7/7 | 63.03 [61.41, 63.28] | 33.99 | 1.32 | none |
| mini_lean | 8192 | 7/7 | 1207.54 [1179.94, 1219.30] | 400.71 | 1.09 | none |
| mini_models | 64 | 7/7 | 40.83 [32.10, 41.14] | 31.28 | 2.19 | none |
| mini_models | 256 | 7/7 | 70.62 [65.76, 74.36] | 43.54 | 1.50 | none |
| mini_models | 8192 | 7/7 | 1202.37 [1200.75, 1224.06] | 423.23 | 1.12 | none |
| mini_registry | 64 | 7/7 | 44.56 [40.39, 45.69] | 33.62 | 2.89 | none |
| mini_registry | 256 | 7/7 | 74.87 [73.53, 77.78] | 46.65 | 1.65 | none |
| mini_registry | 8192 | 7/7 | 1227.66 [1210.34, 1314.67] | 428.34 | 1.13 | none |

The largest tested successful batch is a lower bound under this fixture, not a maximum or a general row/table allowance. Missing telemetry and cache hits are recorded in results.json and excluded from timing. Each run records the seed and exact call order.
