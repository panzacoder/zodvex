# Zodvex codec workload benchmark

**VALID: complete observations and attributable capacity outcomes.**


Run abcbfa6a-a6f9-484d-82e6-7844c07b9494; library commit ad4a23241b7a351e2406fe555283f9e81591139a; fixture 5092dac18dfb0e21f03d559f7d4deb1c91f0ba60f03423c4db0445b962057acf.

{"convex":"1.32.0","convex-helpers":"0.1.113","zod":"4.5.4","zodvex":"0.7.10"}

One indexed read, modeled decode, domain transform and complete return encoding. Driver correctness checking and client transport are outside query execution time. Native performs manual codec transforms, without full Zod modeled validation. No measured heap or true cold-start claim.

56/56 planned calls recorded, including initial calls. All phases are checked for validity; the table below excludes initial calls. Named query capacity failures are outcomes; correctness, collection and attribution failures invalidate the run.

| Variant | Rows | Verified calls | Timing samples / planned | Missing telemetry | Cache hits | Server ms median [Q1, Q3] | User ms median | Paired native ratio | Errors |
|---|---:|---:|---:|---:|---:|---|---:|---:|---|
| native | 64 | 3/3 | 3/3 | 0 | 0 | 19.67 [18.39, 21.85] | 6.18 | 1.00 | none |
| native | 8192 | 0/3 | 0/3 | 0 | 0 | unavailable [unavailable, unavailable] | unavailable | unavailable | read-limit, read-limit, read-limit |
| helpers | 64 | 3/3 | 3/3 | 0 | 0 | 25.80 [25.63, 29.89] | 14.97 | 1.49 | none |
| helpers | 8192 | 0/3 | 0/3 | 0 | 0 | unavailable [unavailable, unavailable] | unavailable | unavailable | read-limit, read-limit, read-limit |
| full_lean | 64 | 3/3 | 3/3 | 0 | 0 | 30.35 [29.65, 32.89] | 18.22 | 1.69 | none |
| full_lean | 8192 | 0/3 | 0/3 | 0 | 0 | unavailable [unavailable, unavailable] | unavailable | unavailable | read-limit, read-limit, read-limit |
| full_models | 64 | 3/3 | 3/3 | 0 | 0 | 39.59 [38.65, 45.59] | 27.78 | 2.15 | none |
| full_models | 8192 | 0/3 | 0/3 | 0 | 0 | unavailable [unavailable, unavailable] | unavailable | unavailable | read-limit, read-limit, read-limit |
| full_registry | 64 | 3/3 | 3/3 | 0 | 0 | 54.55 [51.93, 54.65] | 41.67 | 2.78 | none |
| full_registry | 8192 | 0/3 | 0/3 | 0 | 0 | unavailable [unavailable, unavailable] | unavailable | unavailable | read-limit, read-limit, read-limit |
| mini_lean | 64 | 3/3 | 3/3 | 0 | 0 | 32.69 [31.25, 35.87] | 19.59 | 1.66 | none |
| mini_lean | 8192 | 0/3 | 0/3 | 0 | 0 | unavailable [unavailable, unavailable] | unavailable | unavailable | read-limit, read-limit, read-limit |
| mini_models | 64 | 3/3 | 3/3 | 0 | 0 | 37.04 [35.98, 42.90] | 24.31 | 2.03 | none |
| mini_models | 8192 | 0/3 | 0/3 | 0 | 0 | unavailable [unavailable, unavailable] | unavailable | unavailable | read-limit, read-limit, read-limit |
| mini_registry | 64 | 3/3 | 3/3 | 0 | 0 | 43.57 [42.88, 44.84] | 33.34 | 2.34 | none |
| mini_registry | 8192 | 0/3 | 0/3 | 0 | 0 | unavailable [unavailable, unavailable] | unavailable | unavailable | read-limit, read-limit, read-limit |

The largest tested successful batch is a lower bound under this fixture, not a maximum or a general row/table allowance. Timings describe successful uncached samples only; they do not conceal failed attempts shown alongside them. Full failure text/source, resource counters, optional user-timer sample counts, and exact call order are retained in results.json.
